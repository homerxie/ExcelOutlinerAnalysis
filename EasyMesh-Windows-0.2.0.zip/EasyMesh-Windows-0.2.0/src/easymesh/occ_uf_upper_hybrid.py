"""OCC-backed XYZ-graded TET/PYR mesh for the UF above the C4 top.

The protected UF below the connected-bump top ends on an annular Cartesian
QUAD partition.  This module preserves that complete partition, tapers its
outer boundary towards the analytic rectangular-fillet apex, and fills the
resulting annular volume with one PYRAMID5 behind every locked QUAD followed
by TET4.  No upper HEX collar or repeated XY drag is introduced.

This implementation deliberately reuses the audited low-level extraction and
quality helpers from :mod:`easymesh.occ_locked_hybrid`.  The public contract is
independent and specific to the annular UF volume.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
import math
from statistics import median
from types import MappingProxyType
from typing import Any, TypeAlias

from .gmsh_runtime import isolated_gmsh_model
from .occ_locked_hybrid import (
    ConstrainedHybridError,
    DirectionalGrowth,
    HybridVolumeElement,
    _PreparedDocking,
    _PreparedSidePatch,
    _add_exact_locked_curves,
    _all_nodes,
    _coordinate_key,
    _directional_growth,
    _edge_growth,
    _edge_key,
    _element_volume,
    _extract_candidate,
    _face_key,
    _finite,
    _load_gmsh,
    _prepare_one_side_patch,
    _replace_locked_surfaces,
)
from .uf_skin import RectangularUfEnvelope
from .volume_mesh import ELEMENT_SPECS


Point3D: TypeAlias = tuple[float, float, float]
FaceKey: TypeAlias = tuple[int, ...]

_TET4 = 4
_PYRAMID5 = 7
_COORDINATE_TOLERANCE_MM = 1.0e-10
_OCC_BOUNDING_TOLERANCE_MM = 1.0e-6
_MIN_ADAPTER_XY_EDGE_GROWTH = 1.25
_TRACE_TOE_APEX_INSET_FRACTION = 0.8


def _envelope_contains_with_tolerance(
    envelope: RectangularUfEnvelope,
    point: Sequence[float],
) -> bool:
    """Closed UF membership with only a coordinate-roundoff allowance."""

    x, y, z = point
    tolerance = _COORDINATE_TOLERANCE_MM
    dx = abs(x - envelope.center_x)
    dy = abs(y - envelope.center_y)
    outside_die = (
        dx >= envelope.half_die_width - tolerance
        or dy >= envelope.half_die_length - tolerance
    )
    return (
        outside_die
        and envelope.outside_distance(x, y)
        <= envelope.fillet_width + tolerance
        and z >= envelope.base_z - tolerance
        and z <= envelope.top_height(x, y) + tolerance
    )


@dataclass(frozen=True, slots=True)
class ConstrainedUfHybridVolume:
    """Audited upper-UF hybrid using result-local node IDs."""

    node_coordinates: Mapping[int, Point3D]
    source_node_id_by_local_id: Mapping[int, int]
    elements: tuple[HybridVolumeElement, ...]
    die_wall_facets: tuple[tuple[int, ...], ...]
    free_surface_facets: tuple[tuple[int, ...], ...]
    top_cap_facets: tuple[tuple[int, ...], ...]
    locked_bottom_face_count: int
    bottom_quad_pyramid_base_count: int
    tet4_count: int
    pyramid5_count: int
    near_median_edge_mm: float
    far_median_edge_mm: float
    minimum_sicn: float
    minimum_sige: float
    minimum_scaled_jacobian: float
    minimum_determinant: float
    duplicate_node_count: int
    duplicate_element_count: int
    growth_by_axis: Mapping[str, DirectionalGrowth]
    cad_volume_mm3: float
    element_volume_mm3: float
    relative_volume_error: float
    bottom_base_aspect_median: float
    bottom_base_aspect_p90: float
    bottom_base_aspect_maximum: float
    transition_z_mm: float
    cap_z_mm: float
    random_seed: int
    adapter_cap_z_mm: float | None = None
    adapter_top_face_count: int = 0
    remainder_tet4_count: int = 0
    adapter_bottom_median_edge_mm: float = 0.0
    adapter_top_median_edge_mm: float = 0.0
    locked_side_face_count: int = 0
    locked_side_triangle_count: int = 0
    locked_side_quad_count: int = 0

    @property
    def node_count(self) -> int:
        return len(self.node_coordinates)

    @property
    def element_count(self) -> int:
        return len(self.elements)

    @property
    def locked_face_count(self) -> int:
        return self.locked_bottom_face_count + self.locked_side_face_count

    @property
    def far_face_count(self) -> int:
        return len(self.top_cap_facets)

    @property
    def adapter_xy_edge_growth_ratio(self) -> float:
        if self.adapter_bottom_median_edge_mm <= 0.0:
            return 0.0
        return (
            self.adapter_top_median_edge_mm
            / self.adapter_bottom_median_edge_mm
        )

    @property
    def adapter_surface_face_reduction_ratio(self) -> float:
        """TRI-equivalent bottom faces divided by adapter-top TRI faces."""

        if self.adapter_top_face_count <= 0:
            return 0.0
        return 2.0 * self.locked_bottom_face_count / self.adapter_top_face_count


@dataclass(frozen=True, slots=True)
class _PreparedUf:
    source_coordinates: Mapping[int, Point3D]
    source_facets: tuple[tuple[int, ...], ...]
    outer_loop: tuple[int, ...]
    inner_loop: tuple[int, ...]
    envelope: RectangularUfEnvelope
    transition_z: float
    cap_z: float
    cap_outer_points: tuple[Point3D, ...]
    dummy_docking: _PreparedDocking
    bottom_aspects: tuple[float, ...]

    @property
    def locked_side_facets(self) -> tuple[tuple[int, ...], ...]:
        return tuple(
            facet
            for patch in self.dummy_docking.side_patches
            for facet in patch.source_facets
        )


@dataclass(frozen=True, slots=True)
class _DiscreteShell:
    coordinates: Mapping[int, Point3D]
    source_id_by_node: Mapping[int, int]
    triangles: tuple[tuple[int, int, int], ...]
    bottom_quads: tuple[tuple[int, int, int, int], ...]
    side_quads: tuple[tuple[int, int, int, int], ...]
    die_wall_keys: frozenset[FaceKey]
    free_surface_keys: frozenset[FaceKey]
    top_cap_keys: frozenset[FaceKey]
    volume_mm3: float


@dataclass(frozen=True, slots=True)
class _PreparedTetRemainder:
    """A coarsened TRI3 annulus used after the one-time QUAD adapter."""

    source_coordinates: Mapping[int, Point3D]
    source_facets: tuple[tuple[int, int, int], ...]
    outer_loop: tuple[int, ...]
    inner_loop: tuple[int, ...]
    envelope: RectangularUfEnvelope
    transition_z: float
    cap_z: float


@dataclass(frozen=True, slots=True)
class _TetRemainderVolume:
    """Audited all-TET continuation above a coarsened adapter cap."""

    node_coordinates: Mapping[int, Point3D]
    source_node_id_by_local_id: Mapping[int, int]
    elements: tuple[HybridVolumeElement, ...]
    die_wall_facets: tuple[tuple[int, ...], ...]
    free_surface_facets: tuple[tuple[int, ...], ...]
    top_cap_facets: tuple[tuple[int, ...], ...]
    locked_bottom_facets: tuple[tuple[int, ...], ...]
    near_median_edge_mm: float
    far_median_edge_mm: float
    minimum_sicn: float
    minimum_sige: float
    minimum_scaled_jacobian: float
    minimum_determinant: float
    duplicate_node_count: int
    duplicate_element_count: int
    growth_by_axis: Mapping[str, DirectionalGrowth]
    cad_volume_mm3: float
    element_volume_mm3: float
    relative_volume_error: float
    transition_z_mm: float
    cap_z_mm: float
    random_seed: int


@dataclass(frozen=True, slots=True)
class _TetShell:
    coordinates: Mapping[int, Point3D]
    source_id_by_node: Mapping[int, int]
    triangles: tuple[tuple[int, int, int], ...]
    bottom_keys: frozenset[FaceKey]
    volume_mm3: float


@dataclass(frozen=True, slots=True)
class _ExplicitTraceCollar:
    """One explicit PYRAMID5 behind every locked QUAD plus a TRI shell.

    The pyramids are deliberately created by EasyMesh, not by Gmsh.  Their
    exterior bases are the immutable source QUADs and their four lateral
    faces form part of the closed shell subsequently filled with TET4.  This
    separates exact trace ownership from the independently sized bulk mesh.
    """

    coordinates: Mapping[int, Point3D]
    triangles: tuple[tuple[int, int, int], ...]
    pyramids: tuple[HybridVolumeElement, ...]
    exterior_facets: tuple[tuple[int, ...], ...]
    full_volume_mm3: float
    remainder_volume_mm3: float


def _signed_xy_area(
    nodes: Sequence[int], coordinates: Mapping[int, Point3D]
) -> float:
    return 0.5 * math.fsum(
        coordinates[nodes[index]][0]
        * coordinates[nodes[(index + 1) % len(nodes)]][1]
        - coordinates[nodes[(index + 1) % len(nodes)]][0]
        * coordinates[nodes[index]][1]
        for index in range(len(nodes))
    )


def _trace_boundary_loops(
    facets: Sequence[Sequence[int]],
    coordinates: Mapping[int, Point3D],
) -> tuple[tuple[int, ...], tuple[int, ...]]:
    edge_counts: Counter[tuple[int, int]] = Counter()
    facet_neighbors: dict[int, set[int]] = defaultdict(set)
    owners_by_edge: dict[tuple[int, int], list[int]] = defaultdict(list)
    for index, facet in enumerate(facets):
        for first, second in zip(facet, (*facet[1:], facet[0])):
            edge = _edge_key(first, second)
            edge_counts[edge] += 1
            owners_by_edge[edge].append(index)
    if any(count not in {1, 2} for count in edge_counts.values()):
        raise ConstrainedHybridError("upper-UF docking partition is non-manifold")
    for owners in owners_by_edge.values():
        if len(owners) == 2:
            facet_neighbors[owners[0]].add(owners[1])
            facet_neighbors[owners[1]].add(owners[0])
    visited: set[int] = set()
    queue = deque([0])
    while queue:
        current = queue.popleft()
        if current in visited:
            continue
        visited.add(current)
        queue.extend(facet_neighbors[current].difference(visited))
    if len(visited) != len(facets):
        raise ConstrainedHybridError(
            "upper-UF docking facets must form one connected annulus"
        )

    adjacency: dict[int, set[int]] = defaultdict(set)
    boundary_edges = {
        edge for edge, count in edge_counts.items() if count == 1
    }
    for first, second in boundary_edges:
        adjacency[first].add(second)
        adjacency[second].add(first)
    if not adjacency or any(len(neighbors) != 2 for neighbors in adjacency.values()):
        raise ConstrainedHybridError(
            "upper-UF docking boundary must contain simple closed loops"
        )
    unused = set(boundary_edges)
    loops: list[tuple[int, ...]] = []
    while unused:
        first_edge = min(unused)
        start = first_edge[0]
        previous: int | None = None
        current = start
        loop: list[int] = []
        while True:
            loop.append(current)
            candidates = sorted(
                neighbor
                for neighbor in adjacency[current]
                if _edge_key(current, neighbor) in unused
            )
            if not candidates:
                if current == start:
                    break
                raise ConstrainedHybridError("upper-UF docking boundary has a gap")
            if previous is not None and len(candidates) > 1:
                non_backtracking = [value for value in candidates if value != previous]
                if non_backtracking:
                    candidates = non_backtracking
            following = candidates[0]
            unused.remove(_edge_key(current, following))
            previous, current = current, following
            if current == start:
                break
        loops.append(tuple(loop))
    if len(loops) != 2:
        raise ConstrainedHybridError(
            "upper-UF docking partition must have exactly outer and inner loops"
        )
    by_area = sorted(loops, key=lambda loop: abs(_signed_xy_area(loop, coordinates)))
    inner, outer = by_area
    if abs(_signed_xy_area(inner, coordinates)) <= _COORDINATE_TOLERANCE_MM**2:
        raise ConstrainedHybridError("upper-UF docking loop has zero area")
    return outer, inner


def _percentile90(values: Sequence[float]) -> float:
    ordered = sorted(values)
    return float(ordered[min(len(ordered) - 1, math.ceil(0.9 * len(ordered)) - 1)])


def _facet_median_edge_length(
    facets: Sequence[Sequence[int]],
    coordinates: Mapping[int, Point3D],
) -> float:
    """Return the median unique boundary-edge length of a surface mesh."""

    edges = {
        _edge_key(first, second)
        for facet in facets
        for first, second in zip(facet, (*facet[1:], facet[0]))
    }
    if not edges:
        raise ConstrainedHybridError("surface mesh has no edges")
    return float(
        median(math.dist(coordinates[first], coordinates[second]) for first, second in edges)
    )


def _canonical_loop(
    loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> tuple[int, ...]:
    """Make a closed polygon sequence independent of caller node tags."""

    values = tuple(loop)
    candidates: list[tuple[tuple[tuple[float, float, float], ...], tuple[int, ...]]] = []
    for direction in (values, tuple(reversed(values))):
        for start in range(len(direction)):
            rotated = direction[start:] + direction[:start]
            keys = tuple(_coordinate_key(coordinates[node]) for node in rotated)
            candidates.append((keys, rotated))
    return min(candidates, key=lambda item: item[0])[1]


def _rotate_loop(
    loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> tuple[int, ...]:
    values = tuple(loop)
    rotations = tuple(values[index:] + values[:index] for index in range(len(values)))
    return min(
        rotations,
        key=lambda cycle: tuple(_coordinate_key(coordinates[node]) for node in cycle),
    )


def _canonical_quad(
    facet: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> tuple[int, ...]:
    values = tuple(facet)
    if _signed_xy_area(values, coordinates) < 0.0:
        values = tuple(reversed(values))
    rotations = tuple(values[index:] + values[:index] for index in range(4))
    return min(
        rotations,
        key=lambda cycle: tuple(_coordinate_key(coordinates[node]) for node in cycle),
    )


def _prepare_inputs(
    docking_node_coordinates: Mapping[int, Sequence[float]],
    docking_facets: Sequence[Sequence[int]],
    envelope: RectangularUfEnvelope,
    transition_z_mm: float,
    cap_z_mm: float,
    locked_side_node_coordinates: Mapping[int, Sequence[float]] | None = None,
    locked_side_facets: Sequence[Sequence[int]] = (),
) -> _PreparedUf:
    if not isinstance(envelope, RectangularUfEnvelope):
        raise ConstrainedHybridError("upper-UF envelope must be RectangularUfEnvelope")
    transition_z = _finite(transition_z_mm, name="upper-UF transition Z")
    cap_z = _finite(cap_z_mm, name="upper-UF cap Z")
    if not (
        envelope.base_z - _COORDINATE_TOLERANCE_MM
        <= transition_z
        < cap_z
        < envelope.apex_z
        and cap_z - transition_z > _COORDINATE_TOLERANCE_MM
    ):
        raise ConstrainedHybridError(
            "upper-UF transition/cap must lie inside the fillet height"
        )
    if not isinstance(docking_node_coordinates, Mapping):
        raise ConstrainedHybridError("upper-UF docking coordinates must be a mapping")
    coordinates: dict[int, Point3D] = {}
    for raw_id, raw_point in docking_node_coordinates.items():
        if isinstance(raw_id, bool) or not isinstance(raw_id, int) or raw_id < 1:
            raise ConstrainedHybridError("upper-UF docking IDs must be positive integers")
        try:
            values = tuple(raw_point)
        except TypeError as error:
            raise ConstrainedHybridError(
                "upper-UF docking coordinate must contain x,y,z"
            ) from error
        if len(values) != 3:
            raise ConstrainedHybridError(
                "upper-UF docking coordinate must contain x,y,z"
            )
        point = tuple(
            _finite(value, name=f"upper-UF docking node {raw_id}")
            for value in values
        )
        if abs(point[2] - transition_z) > _COORDINATE_TOLERANCE_MM:
            raise ConstrainedHybridError(
                "every upper-UF docking node must lie on the transition plane"
            )
        if not _envelope_contains_with_tolerance(envelope, point):
            raise ConstrainedHybridError(
                "upper-UF docking node lies outside the analytic fillet"
            )
        coordinates[raw_id] = point  # type: ignore[assignment]
    if not coordinates:
        raise ConstrainedHybridError("upper-UF docking surface is empty")
    coordinate_keys = [_coordinate_key(point) for point in coordinates.values()]
    if len(set(coordinate_keys)) != len(coordinate_keys):
        raise ConstrainedHybridError("upper-UF docking has duplicate coordinates")

    try:
        raw_facets = tuple(tuple(facet) for facet in docking_facets)
    except TypeError as error:
        raise ConstrainedHybridError("upper-UF docking facets must be QUAD4") from error
    if not raw_facets:
        raise ConstrainedHybridError("upper-UF docking surface is empty")
    facets: list[tuple[int, ...]] = []
    aspects: list[float] = []
    for raw_facet in raw_facets:
        if len(raw_facet) != 4:
            raise ConstrainedHybridError("upper-UF docking facets must all be QUAD4")
        if any(isinstance(node, bool) or not isinstance(node, int) for node in raw_facet):
            raise ConstrainedHybridError("upper-UF docking node IDs must be integers")
        facet = tuple(int(node) for node in raw_facet)
        if len(set(facet)) != 4 or any(node not in coordinates for node in facet):
            raise ConstrainedHybridError("upper-UF docking facet is invalid")
        area = abs(_signed_xy_area(facet, coordinates))
        if area <= _COORDINATE_TOLERANCE_MM**2:
            raise ConstrainedHybridError("upper-UF docking facet has zero area")
        lengths = tuple(
            math.dist(coordinates[first], coordinates[second])
            for first, second in zip(facet, (*facet[1:], facet[0]))
        )
        if min(lengths) <= _COORDINATE_TOLERANCE_MM:
            raise ConstrainedHybridError("upper-UF docking facet has a zero edge")
        aspects.append(max(lengths) / min(lengths))
        facets.append(facet)
    if len({_face_key(facet) for facet in facets}) != len(facets):
        raise ConstrainedHybridError("upper-UF docking facets must be unique")
    if {node for facet in facets for node in facet} != set(coordinates):
        raise ConstrainedHybridError("every upper-UF docking node must be referenced")

    outer_loop, inner_loop = _trace_boundary_loops(facets, coordinates)
    outer_loop = _canonical_loop(outer_loop, coordinates)
    inner_loop = _canonical_loop(inner_loop, coordinates)
    if _signed_xy_area(outer_loop, coordinates) < 0.0:
        outer_loop = tuple(reversed(outer_loop))
    outer_loop = _rotate_loop(outer_loop, coordinates)
    die_x_min = envelope.center_x - envelope.half_die_width
    die_x_max = envelope.center_x + envelope.half_die_width
    die_y_min = envelope.center_y - envelope.half_die_length
    die_y_max = envelope.center_y + envelope.half_die_length
    for node in inner_loop:
        x, y, _z = coordinates[node]
        on_die = (
            abs(x - die_x_min) <= _COORDINATE_TOLERANCE_MM
            or abs(x - die_x_max) <= _COORDINATE_TOLERANCE_MM
            or abs(y - die_y_min) <= _COORDINATE_TOLERANCE_MM
            or abs(y - die_y_max) <= _COORDINATE_TOLERANCE_MM
        )
        within = (
            die_x_min - _COORDINATE_TOLERANCE_MM
            <= x
            <= die_x_max + _COORDINATE_TOLERANCE_MM
            and die_y_min - _COORDINATE_TOLERANCE_MM
            <= y
            <= die_y_max + _COORDINATE_TOLERANCE_MM
        )
        if not (on_die and within):
            raise ConstrainedHybridError(
                "upper-UF inner docking loop must equal the die perimeter"
            )
    inner_area = abs(_signed_xy_area(inner_loop, coordinates))
    expected_inner_area = envelope.die_width * envelope.die_length
    if not math.isclose(
        inner_area,
        expected_inner_area,
        rel_tol=1.0e-9,
        abs_tol=_COORDINATE_TOLERANCE_MM**2,
    ):
        raise ConstrainedHybridError("upper-UF inner loop does not enclose the die")
    outer_area = abs(_signed_xy_area(outer_loop, coordinates))
    partition_area = math.fsum(abs(_signed_xy_area(facet, coordinates)) for facet in facets)
    if not math.isclose(
        partition_area,
        outer_area - inner_area,
        rel_tol=1.0e-9,
        abs_tol=_COORDINATE_TOLERANCE_MM**2,
    ):
        raise ConstrainedHybridError("upper-UF QUAD partition does not close its annulus")

    bottom_radius = envelope.fillet_width * (
        envelope.apex_z - transition_z
    ) / envelope.height
    cap_radius = envelope.fillet_width * (
        envelope.apex_z - cap_z
    ) / envelope.height
    if not (0.0 < cap_radius < bottom_radius):
        raise ConstrainedHybridError("upper-UF cap radius must shrink from the seam")
    scale = cap_radius / bottom_radius
    cap_outer: list[Point3D] = []
    for node in outer_loop:
        x, y, _z = coordinates[node]
        anchor_x = min(max(x, die_x_min), die_x_max)
        anchor_y = min(max(y, die_y_min), die_y_max)
        point = (
            anchor_x + scale * (x - anchor_x),
            anchor_y + scale * (y - anchor_y),
            cap_z,
        )
        # Scaling exact interface vertices can differ from the analytic top
        # height by one floating-point ULP.  This is still on the envelope;
        # use the same tolerance as every subsequent boundary audit.
        if not _envelope_contains_with_tolerance(envelope, point):
            raise ConstrainedHybridError("upper-UF tapered cap escapes the envelope")
        cap_outer.append(point)

    try:
        raw_side_facets = tuple(tuple(facet) for facet in locked_side_facets)
    except TypeError as error:
        raise ConstrainedHybridError(
            "locked upper-UF side facets must contain TRI3/QUAD4 faces"
        ) from error
    raw_side_coordinates = locked_side_node_coordinates or {}
    if not isinstance(raw_side_coordinates, Mapping):
        raise ConstrainedHybridError(
            "locked upper-UF side coordinates must be a mapping"
        )
    if bool(raw_side_coordinates) != bool(raw_side_facets):
        raise ConstrainedHybridError(
            "locked upper-UF side coordinates and facets must both be empty "
            "or non-empty"
        )
    side_patches: tuple[_PreparedSidePatch, ...] = ()
    if raw_side_facets:
        side_declared_ids: set[int] = set()
        for raw_id, raw_point in raw_side_coordinates.items():
            if isinstance(raw_id, bool) or not isinstance(raw_id, int) or raw_id < 1:
                raise ConstrainedHybridError(
                    "locked upper-UF side IDs must be positive integers"
                )
            try:
                values = tuple(raw_point)
            except TypeError as error:
                raise ConstrainedHybridError(
                    "locked upper-UF side coordinate must contain x,y,z"
                ) from error
            if len(values) != 3:
                raise ConstrainedHybridError(
                    "locked upper-UF side coordinate must contain x,y,z"
                )
            point = tuple(
                _finite(value, name=f"locked upper-UF side node {raw_id}")
                for value in values
            )
            if not (
                transition_z - _COORDINATE_TOLERANCE_MM
                <= point[2]
                <= cap_z + _COORDINATE_TOLERANCE_MM
            ):
                raise ConstrainedHybridError(
                    "locked upper-UF side node escapes the transition height"
                )
            on_die_wall = (
                abs(point[0] - die_x_min) <= _COORDINATE_TOLERANCE_MM
                or abs(point[0] - die_x_max) <= _COORDINATE_TOLERANCE_MM
                or abs(point[1] - die_y_min) <= _COORDINATE_TOLERANCE_MM
                or abs(point[1] - die_y_max) <= _COORDINATE_TOLERANCE_MM
            ) and (
                die_x_min - _COORDINATE_TOLERANCE_MM
                <= point[0]
                <= die_x_max + _COORDINATE_TOLERANCE_MM
                and die_y_min - _COORDINATE_TOLERANCE_MM
                <= point[1]
                <= die_y_max + _COORDINATE_TOLERANCE_MM
            )
            if not on_die_wall:
                raise ConstrainedHybridError(
                    "locked upper-UF side node is not on the die wall"
                )
            existing = coordinates.get(raw_id)
            if existing is not None and math.dist(existing, point) > (
                _COORDINATE_TOLERANCE_MM
            ):
                raise ConstrainedHybridError(
                    "locked upper-UF side ID conflicts with a docking node"
                )
            coordinates[raw_id] = point  # type: ignore[assignment]
            side_declared_ids.add(raw_id)
        if len({_coordinate_key(point) for point in coordinates.values()}) != len(
            coordinates
        ):
            raise ConstrainedHybridError(
                "locked upper-UF bottom/side nodes contain duplicate coordinates"
            )

        grouped: dict[str, list[tuple[int, ...]]] = defaultdict(list)
        parsed_side_facets: list[tuple[int, ...]] = []
        for raw_facet in raw_side_facets:
            if len(raw_facet) not in {3, 4}:
                raise ConstrainedHybridError(
                    "locked upper-UF side facets must be TRI3 or QUAD4"
                )
            if any(
                isinstance(node, bool) or not isinstance(node, int)
                for node in raw_facet
            ):
                raise ConstrainedHybridError(
                    "locked upper-UF side node IDs must be integers"
                )
            facet = tuple(int(node) for node in raw_facet)
            if len(set(facet)) != len(facet) or any(
                node not in coordinates for node in facet
            ):
                raise ConstrainedHybridError(
                    "locked upper-UF side facet is invalid"
                )
            points = tuple(coordinates[node] for node in facet)
            candidates: list[str] = []
            if all(
                abs(point[0] - die_x_min) <= _COORDINATE_TOLERANCE_MM
                for point in points
            ):
                candidates.append("x_min")
            if all(
                abs(point[0] - die_x_max) <= _COORDINATE_TOLERANCE_MM
                for point in points
            ):
                candidates.append("x_max")
            if all(
                abs(point[1] - die_y_min) <= _COORDINATE_TOLERANCE_MM
                for point in points
            ):
                candidates.append("y_min")
            if all(
                abs(point[1] - die_y_max) <= _COORDINATE_TOLERANCE_MM
                for point in points
            ):
                candidates.append("y_max")
            if len(candidates) != 1:
                raise ConstrainedHybridError(
                    "each locked upper-UF side facet must lie on exactly one die wall"
                )
            grouped[candidates[0]].append(facet)
            parsed_side_facets.append(facet)
        if len({_face_key(facet) for facet in parsed_side_facets}) != len(
            parsed_side_facets
        ):
            raise ConstrainedHybridError(
                "locked upper-UF side facets must be unique"
            )
        if side_declared_ids.difference(
            {node for facet in parsed_side_facets for node in facet}
        ):
            raise ConstrainedHybridError(
                "locked upper-UF side coordinates contain unused nodes"
            )
        expected_groups = {"x_min", "x_max", "y_min", "y_max"}
        if set(grouped) != expected_groups:
            raise ConstrainedHybridError(
                "locked upper-UF side facets must cover all four die walls"
            )
        side_patches = tuple(
            _prepare_one_side_patch(
                name,
                grouped[name],
                coordinates,
                transition_z,
                cap_z,
            )
            for name in ("x_min", "x_max", "y_min", "y_max")
        )

    x_values = tuple(point[0] for point in coordinates.values())
    y_values = tuple(point[1] for point in coordinates.values())
    if side_patches:
        dummy_coordinates = dict(coordinates)
        canonical_facets = tuple(facets)
        dummy_side_patches = side_patches
    else:
        ordered_source_ids = tuple(
            sorted(coordinates, key=lambda node: _coordinate_key(coordinates[node]))
        )
        canonical_by_source = {
            source_id: index
            for index, source_id in enumerate(ordered_source_ids, start=1)
        }
        dummy_coordinates = {
            canonical_by_source[source_id]: coordinates[source_id]
            for source_id in ordered_source_ids
        }
        canonical_facets = tuple(
            sorted(
                (
                    tuple(
                        canonical_by_source[node]
                        for node in _canonical_quad(facet, coordinates)
                    )
                    for facet in facets
                ),
                key=lambda facet: (tuple(sorted(facet)), facet),
            )
        )
        dummy_side_patches = ()
    dummy = _PreparedDocking(
        source_coordinates=MappingProxyType(dummy_coordinates),
        source_facets=canonical_facets,
        bounds=(min(x_values), max(x_values), min(y_values), max(y_values)),
        interface_z=transition_z,
        far_z=cap_z,
        side_chains=MappingProxyType({}),
        side_patches=dummy_side_patches,
    )
    return _PreparedUf(
        source_coordinates=MappingProxyType(coordinates),
        source_facets=tuple(facets),
        outer_loop=outer_loop,
        inner_loop=inner_loop,
        envelope=envelope,
        transition_z=transition_z,
        cap_z=cap_z,
        cap_outer_points=tuple(cap_outer),
        dummy_docking=dummy,
        bottom_aspects=tuple(aspects),
    )


def _add_polygon_wire(gmsh: Any, points: Sequence[Point3D]) -> int:
    point_tags = tuple(int(gmsh.model.occ.addPoint(*point)) for point in points)
    curve_tags = tuple(
        int(gmsh.model.occ.addLine(point_tags[index], point_tags[(index + 1) % len(points)]))
        for index in range(len(points))
    )
    return int(gmsh.model.occ.addWire(curve_tags))


def _coarse_rounded_rectangle(
    envelope: RectangularUfEnvelope,
    z_value: float,
    target_size: float,
) -> tuple[Point3D, ...]:
    """Return a conservative, coarsened polygon for one offset rectangle."""

    radius = envelope.fillet_width * (
        envelope.apex_z - z_value
    ) / envelope.height
    if radius <= _COORDINATE_TOLERANCE_MM:
        raise ConstrainedHybridError("upper-UF cap radius is zero")
    x_min = envelope.center_x - envelope.half_die_width
    x_max = envelope.center_x + envelope.half_die_width
    y_min = envelope.center_y - envelope.half_die_length
    y_max = envelope.center_y + envelope.half_die_length
    points: list[Point3D] = []

    def append_line(first: tuple[float, float], second: tuple[float, float]) -> None:
        length = math.dist(first, second)
        count = max(1, math.ceil(length / target_size))
        for index in range(count):
            fraction = index / count
            point = (
                first[0] + fraction * (second[0] - first[0]),
                first[1] + fraction * (second[1] - first[1]),
                z_value,
            )
            if not points or _coordinate_key(points[-1]) != _coordinate_key(point):
                points.append(point)

    def append_arc(
        center: tuple[float, float], start_angle: float, end_angle: float
    ) -> None:
        count = max(2, math.ceil(radius * (end_angle - start_angle) / target_size))
        for index in range(count):
            angle = start_angle + (end_angle - start_angle) * index / count
            point = (
                center[0] + radius * math.cos(angle),
                center[1] + radius * math.sin(angle),
                z_value,
            )
            if not points or _coordinate_key(points[-1]) != _coordinate_key(point):
                points.append(point)

    # Counter-clockwise: right side, top, left side, bottom.
    append_line((x_max + radius, y_min), (x_max + radius, y_max))
    append_arc((x_max, y_max), 0.0, 0.5 * math.pi)
    append_line((x_max, y_max + radius), (x_min, y_max + radius))
    append_arc((x_min, y_max), 0.5 * math.pi, math.pi)
    append_line((x_min - radius, y_max), (x_min - radius, y_min))
    append_arc((x_min, y_min), math.pi, 1.5 * math.pi)
    append_line((x_min, y_min - radius), (x_max, y_min - radius))
    append_arc((x_max, y_min), 1.5 * math.pi, 2.0 * math.pi)
    if len(points) < 8:
        raise ConstrainedHybridError("upper-UF cap polygon is under-resolved")
    if not all(_envelope_contains_with_tolerance(envelope, point) for point in points):
        raise ConstrainedHybridError("upper-UF cap polygon escapes the envelope")
    return tuple(points)


def _coarse_rectangle(
    envelope: RectangularUfEnvelope,
    z_value: float,
    target_size: float,
) -> tuple[Point3D, ...]:
    x_min = envelope.center_x - envelope.half_die_width
    x_max = envelope.center_x + envelope.half_die_width
    y_min = envelope.center_y - envelope.half_die_length
    y_max = envelope.center_y + envelope.half_die_length
    corners = (
        (x_max, y_min),
        (x_max, y_max),
        (x_min, y_max),
        (x_min, y_min),
    )
    points: list[Point3D] = []
    for first, second in zip(corners, (*corners[1:], corners[0])):
        count = max(1, math.ceil(math.dist(first, second) / target_size))
        for index in range(count):
            fraction = index / count
            points.append(
                (
                    first[0] + fraction * (second[0] - first[0]),
                    first[1] + fraction * (second[1] - first[1]),
                    z_value,
                )
            )
    return tuple(points)


def _outer_phase(point: Point3D, envelope: RectangularUfEnvelope) -> float:
    """Radius-independent phase around an offset rectangle (0..8 CCW)."""

    x, y, _z = point
    x_min = envelope.center_x - envelope.half_die_width
    x_max = envelope.center_x + envelope.half_die_width
    y_min = envelope.center_y - envelope.half_die_length
    y_max = envelope.center_y + envelope.half_die_length
    tolerance = _COORDINATE_TOLERANCE_MM
    if x >= x_max - tolerance and y_min - tolerance <= y <= y_max + tolerance:
        return min(1.0, max(0.0, (y - y_min) / envelope.die_length))
    if x >= x_max - tolerance and y >= y_max - tolerance:
        return 1.0 + 2.0 * math.atan2(y - y_max, x - x_max) / math.pi
    if y >= y_max - tolerance and x_min - tolerance <= x <= x_max + tolerance:
        return 2.0 + min(
            1.0, max(0.0, (x_max - x) / envelope.die_width)
        )
    if x <= x_min + tolerance and y >= y_max - tolerance:
        return 3.0 + 2.0 * math.atan2(x_min - x, y - y_max) / math.pi
    if x <= x_min + tolerance and y_min - tolerance <= y <= y_max + tolerance:
        return 4.0 + min(
            1.0, max(0.0, (y_max - y) / envelope.die_length)
        )
    if x <= x_min + tolerance and y <= y_min + tolerance:
        return 5.0 + 2.0 * math.atan2(y_min - y, x_min - x) / math.pi
    if y <= y_min + tolerance and x_min - tolerance <= x <= x_max + tolerance:
        return 6.0 + min(
            1.0, max(0.0, (x - x_min) / envelope.die_width)
        )
    if x >= x_max - tolerance and y <= y_min + tolerance:
        return 7.0 + 2.0 * math.atan2(x - x_max, y_min - y) / math.pi
    raise ConstrainedHybridError(
        f"upper-UF outer-loop point cannot be classified: {point}"
    )


def _inner_phase(point: Point3D, envelope: RectangularUfEnvelope) -> float:
    """Phase around the die rectangle itself (0..4 CCW)."""

    x, y, _z = point
    x_min = envelope.center_x - envelope.half_die_width
    x_max = envelope.center_x + envelope.half_die_width
    y_min = envelope.center_y - envelope.half_die_length
    y_max = envelope.center_y + envelope.half_die_length
    tolerance = _COORDINATE_TOLERANCE_MM
    if abs(x - x_max) <= tolerance and y < y_max - tolerance:
        return min(1.0, max(0.0, (y - y_min) / envelope.die_length))
    if abs(y - y_max) <= tolerance and x > x_min + tolerance:
        return 1.0 + min(
            1.0, max(0.0, (x_max - x) / envelope.die_width)
        )
    if abs(x - x_min) <= tolerance and y > y_min + tolerance:
        return 2.0 + min(
            1.0, max(0.0, (y_max - y) / envelope.die_length)
        )
    if abs(y - y_min) <= tolerance:
        return 3.0 + min(
            1.0, max(0.0, (x - x_min) / envelope.die_width)
        )
    # Four exact corners are assigned to the side that starts there.
    if abs(x - x_max) <= tolerance and abs(y - y_max) <= tolerance:
        return 1.0
    if abs(x - x_min) <= tolerance and abs(y - y_max) <= tolerance:
        return 2.0
    if abs(x - x_min) <= tolerance and abs(y - y_min) <= tolerance:
        return 3.0
    if abs(x - x_max) <= tolerance and abs(y - y_min) <= tolerance:
        return 0.0
    raise ConstrainedHybridError(
        f"upper-UF inner-loop point is not on the die perimeter: {point}"
    )


def _segment_loop(
    nodes: Sequence[int],
    coordinates: Mapping[int, Point3D],
    phase: Any,
    period: int,
) -> tuple[tuple[int, ...], ...]:
    """Split one CCW loop at common geometric landmarks.

    The bottom staircase and the coarsened cap can have very different
    perimeters.  Splitting first prevents a global arc-length zipper from
    connecting (for example) a bottom top-side edge to a cap right-side edge.
    """

    values = tuple(nodes)
    if len(values) < period:
        raise ConstrainedHybridError("upper-UF shell loop is under-resolved")
    raw = tuple(float(phase(coordinates[node])) for node in values)
    start = min(range(len(values)), key=lambda index: (raw[index], index))
    values = values[start:] + values[:start]
    raw = raw[start:] + raw[:start]
    unwrapped: list[float] = []
    offset = 0.0
    previous = -math.inf
    for current in raw:
        candidate = current + offset
        if candidate < previous - 1.0e-9:
            offset += float(period)
            candidate = current + offset
        if candidate < previous - 1.0e-9:
            raise ConstrainedHybridError("upper-UF shell loop phase is not monotone")
        unwrapped.append(candidate)
        previous = candidate
    if unwrapped[-1] >= period + 1.0e-7:
        raise ConstrainedHybridError("upper-UF shell loop wraps more than once")
    extended_nodes = values + (values[0],)
    extended_phase = tuple((*unwrapped, float(period)))
    landmarks = [0]
    for boundary in range(1, period):
        minimum_index = landmarks[-1] + 1
        maximum_index = len(values) - (period - boundary)
        if minimum_index > maximum_index:
            raise ConstrainedHybridError("upper-UF shell lacks segment landmarks")
        index = min(
            range(minimum_index, maximum_index + 1),
            key=lambda item: (abs(extended_phase[item] - boundary), item),
        )
        landmarks.append(index)
    landmarks.append(len(values))
    segments = tuple(
        tuple(extended_nodes[landmarks[index] : landmarks[index + 1] + 1])
        for index in range(period)
    )
    if any(len(segment) < 2 for segment in segments):
        raise ConstrainedHybridError("upper-UF shell contains an empty segment")
    return segments


def _zipper_chains(
    first_chain: Sequence[int],
    second_chain: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> tuple[tuple[int, int, int], ...]:
    """Triangulate between two open chains with identical endpoints roles."""

    first = tuple(first_chain)
    second = tuple(second_chain)
    if len(first) < 2 or len(second) < 2:
        raise ConstrainedHybridError("upper-UF zipper chain is under-resolved")

    def parameters(chain: Sequence[int]) -> tuple[float, ...]:
        lengths = tuple(
            math.dist(coordinates[a], coordinates[b])
            for a, b in zip(chain, chain[1:])
        )
        total = math.fsum(lengths)
        if total <= _COORDINATE_TOLERANCE_MM:
            raise ConstrainedHybridError("upper-UF zipper chain has zero length")
        result = [0.0]
        running = 0.0
        for length in lengths:
            running += length
            result.append(running / total)
        result[-1] = 1.0
        return tuple(result)

    first_t = parameters(first)
    second_t = parameters(second)
    i = 0
    j = 0
    result: list[tuple[int, int, int]] = []

    def area(facet: Sequence[int]) -> float:
        return math.sqrt(
            math.fsum(value * value for value in _normal(facet, coordinates))
        )

    while i < len(first) - 1 or j < len(second) - 1:
        first_next_t = first_t[i + 1] if i < len(first) - 1 else math.inf
        second_next_t = second_t[j + 1] if j < len(second) - 1 else math.inf
        a = first[i]
        c = second[j]
        if abs(first_next_t - second_next_t) <= 1.0e-12:
            b = first[i + 1]
            d = second[j + 1]
            alternatives = (
                ((a, b, d), (a, d, c)),
                ((a, b, c), (b, d, c)),
            )
            selected = max(
                alternatives,
                key=lambda pair: min(area(facet) for facet in pair),
            )
            if min(area(facet) for facet in selected) <= 1.0e-14:
                raise ConstrainedHybridError(
                    "upper-UF open zipper has an aligned interval"
                )
            result.extend(selected)
            i += 1
            j += 1
        elif first_next_t < second_next_t:
            facet = (a, first[i + 1], c)
            if area(facet) <= 1.0e-14:
                raise ConstrainedHybridError("upper-UF open zipper collapsed")
            result.append(facet)
            i += 1
        else:
            facet = (a, second[j + 1], c)
            if area(facet) <= 1.0e-14:
                raise ConstrainedHybridError("upper-UF open zipper collapsed")
            result.append(facet)
            j += 1
    return tuple(result)


def _subdivide_open_triangle_surface_once(
    facets: Sequence[tuple[int, int, int]],
    coordinates: Mapping[int, Point3D],
    add_point: Callable[[Point3D], int],
) -> tuple[tuple[int, int, int], ...]:
    """Split every original interior edge once, preserving both open seams.

    The ruled free wall is already known to be non-self-intersecting.  A
    shared midpoint is inserted on each edge with two TRI owners, while the
    one-owner Source/PYR and top-cap seams are frozen.  Standard red/green
    templates then replace each parent according to whether zero, one, two or
    three of its edges were split.  Children are never split again, making the
    resource bound exact and avoiding an impossible refinement cascade beside
    immutable long Source edges.
    """

    initial = tuple(tuple(facet) for facet in facets)
    if not initial:
        raise ConstrainedHybridError("trace-core free wall contains no TRI3")
    def edge_counts(
        values: Sequence[Sequence[int]],
    ) -> Counter[tuple[int, int]]:
        return Counter(
            _edge_key(first, second)
            for facet in values
            for first, second in zip(facet, (*facet[1:], facet[0]))
        )

    original_edges = edge_counts(initial)
    if any(count not in {1, 2} for count in original_edges.values()):
        raise ConstrainedHybridError(
            "trace-core free wall is non-manifold before subdivision"
        )
    original_boundary = frozenset(
        edge for edge, count in original_edges.items() if count == 1
    )
    split_edges = tuple(
        sorted(edge for edge, count in original_edges.items() if count == 2)
    )
    expected_face_count = len(initial) + 2 * len(split_edges)
    if expected_face_count > 500_000:
        raise ConstrainedHybridError(
            "trace-core free wall exceeds the one-level subdivision cap; "
            f"faces={expected_face_count}, cap=500000"
        )
    existing_nodes = set(coordinates)
    midpoint_nodes: set[int] = set()
    midpoint_by_edge: dict[tuple[int, int], int] = {}
    for edge in split_edges:
        midpoint = tuple(
            0.5 * (
                coordinates[edge[0]][axis] + coordinates[edge[1]][axis]
            )
            for axis in range(3)
        )
        if not all(math.isfinite(value) for value in midpoint):
            raise ConstrainedHybridError(
                "trace-core free-wall midpoint is non-finite"
            )
        midpoint_node = add_point(midpoint)  # type: ignore[arg-type]
        if midpoint_node in existing_nodes or midpoint_node in midpoint_nodes:
            raise ConstrainedHybridError(
                "trace-core free-wall midpoint is not unique"
            )
        midpoint_nodes.add(midpoint_node)
        midpoint_by_edge[edge] = midpoint_node

    def twice_area(facet: Sequence[int]) -> float:
        normal = _normal(facet, coordinates)
        return math.sqrt(math.fsum(value * value for value in normal))

    result: list[tuple[int, int, int]] = []
    for facet in initial:
        if len(set(facet)) != 3:
            raise ConstrainedHybridError(
                "trace-core free wall contains a collapsed TRI3"
            )
        parent_normal = _normal(facet, coordinates)
        parent_area = math.sqrt(
            math.fsum(value * value for value in parent_normal)
        )
        if not math.isfinite(parent_area) or parent_area <= 1.0e-14:
            raise ConstrainedHybridError(
                "trace-core free wall contains a zero-area TRI3"
            )
        split_count = sum(
            _edge_key(facet[index], facet[(index + 1) % 3])
            in midpoint_by_edge
            for index in range(3)
        )
        if split_count == 0:
            children = (facet,)
        elif split_count == 1:
            split_index = next(
                index
                for index in range(3)
                if _edge_key(facet[index], facet[(index + 1) % 3])
                in midpoint_by_edge
            )
            first = facet[split_index]
            second = facet[(split_index + 1) % 3]
            third = facet[(split_index + 2) % 3]
            midpoint = midpoint_by_edge[_edge_key(first, second)]
            children = (
                (first, midpoint, third),
                (midpoint, second, third),
            )
        elif split_count == 2:
            split_index = next(
                index
                for index in range(3)
                if (
                    _edge_key(facet[index], facet[(index + 1) % 3])
                    in midpoint_by_edge
                    and _edge_key(
                        facet[(index + 1) % 3],
                        facet[(index + 2) % 3],
                    )
                    in midpoint_by_edge
                )
            )
            first = facet[split_index]
            second = facet[(split_index + 1) % 3]
            third = facet[(split_index + 2) % 3]
            first_midpoint = midpoint_by_edge[_edge_key(first, second)]
            second_midpoint = midpoint_by_edge[_edge_key(second, third)]
            children = (
                (first, first_midpoint, third),
                (first_midpoint, second_midpoint, third),
                (first_midpoint, second, second_midpoint),
            )
        else:
            first, second, third = facet
            first_midpoint = midpoint_by_edge[_edge_key(first, second)]
            second_midpoint = midpoint_by_edge[_edge_key(second, third)]
            third_midpoint = midpoint_by_edge[_edge_key(third, first)]
            children = (
                (first, first_midpoint, third_midpoint),
                (second, second_midpoint, first_midpoint),
                (third, third_midpoint, second_midpoint),
                (first_midpoint, second_midpoint, third_midpoint),
            )
        child_areas = tuple(
            twice_area(child)
            for child in children
        )
        if (
            any(
                not math.isfinite(area) or area <= 1.0e-14
                for area in child_areas
            )
            or abs(math.fsum(child_areas) - parent_area)
            > 1.0e-10 * parent_area
        ):
            raise ConstrainedHybridError(
                "trace-core free-wall children do not partition "
                "their parent TRI3"
            )
        if any(
            math.fsum(
                parent_normal[axis] * _normal(child, coordinates)[axis]
                for axis in range(3)
            )
            <= 0.0
            for child in children
        ):
            raise ConstrainedHybridError(
                "trace-core free-wall child is misoriented"
            )
        result.extend(children)

    refined = tuple(result)
    if len(refined) != expected_face_count:
        raise ConstrainedHybridError(
            "trace-core free-wall subdivision count is inconsistent"
        )
    if len({_face_key(facet) for facet in refined}) != len(refined):
        raise ConstrainedHybridError(
            "trace-core free-wall subdivision produced duplicate TRI3"
        )
    refined_edges = edge_counts(refined)
    if any(count not in {1, 2} for count in refined_edges.values()):
        raise ConstrainedHybridError(
            "trace-core free-wall subdivision produced a non-manifold edge"
        )
    refined_boundary = frozenset(
        edge for edge, count in refined_edges.items() if count == 1
    )
    if refined_boundary != original_boundary:
        raise ConstrainedHybridError(
            "trace-core free-wall subdivision changed a locked seam"
        )
    return refined


def _rotate_ids_to_point(
    nodes: Sequence[int],
    coordinates: Mapping[int, Point3D],
    point: Point3D,
) -> tuple[int, ...]:
    values = tuple(nodes)
    start = min(
        range(len(values)),
        key=lambda index: (
            math.dist(coordinates[values[index]], point),
            _coordinate_key(coordinates[values[index]]),
        ),
    )
    return values[start:] + values[:start]


def _loop_parameters(
    nodes: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> tuple[float, ...]:
    lengths = tuple(
        math.dist(coordinates[first], coordinates[second])
        for first, second in zip(nodes, (*nodes[1:], nodes[0]))
    )
    total = math.fsum(lengths)
    if total <= _COORDINATE_TOLERANCE_MM:
        raise ConstrainedHybridError("upper-UF shell loop has zero length")
    values = [0.0]
    running = 0.0
    for length in lengths:
        running += length
        values.append(running / total)
    values[-1] = 1.0
    return tuple(values)


def _zipper_loops(
    first_loop: Sequence[int],
    second_loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> tuple[tuple[int, int, int], ...]:
    """Triangulate between two nested, CCW, geometrically aligned loops."""

    first = tuple(first_loop)
    second = tuple(second_loop)
    first_t = _loop_parameters(first, coordinates)
    second_t = _loop_parameters(second, coordinates)
    i = 0
    j = 0
    result: list[tuple[int, int, int]] = []
    tolerance = 1.0e-12

    def twice_area(facet: Sequence[int]) -> float:
        return math.sqrt(
            math.fsum(value * value for value in _normal(facet, coordinates))
        )

    while i < len(first) or j < len(second):
        first_current = first[i % len(first)]
        second_current = second[j % len(second)]
        first_next_t = first_t[i + 1] if i < len(first) else math.inf
        second_next_t = second_t[j + 1] if j < len(second) else math.inf
        if abs(first_next_t - second_next_t) <= tolerance:
            first_next = first[(i + 1) % len(first)]
            second_next = second[(j + 1) % len(second)]
            diagonal_a = (
                (first_current, first_next, second_next),
                (first_current, second_next, second_current),
            )
            diagonal_b = (
                (first_current, first_next, second_current),
                (first_next, second_next, second_current),
            )
            candidates = (diagonal_a, diagonal_b)
            selected = max(
                candidates,
                key=lambda pair: min(twice_area(facet) for facet in pair),
            )
            if min(twice_area(facet) for facet in selected) <= 1.0e-14:
                raise ConstrainedHybridError(
                    "upper-UF zipper cannot triangulate an aligned loop interval"
                )
            result.extend(selected)
            i += 1
            j += 1
        elif first_next_t < second_next_t:
            first_next = first[(i + 1) % len(first)]
            result.append((first_current, first_next, second_current))
            i += 1
        else:
            second_next = second[(j + 1) % len(second)]
            result.append((first_current, second_next, second_current))
            j += 1
    if any(len(set(facet)) != 3 for facet in result):
        raise ConstrainedHybridError("upper-UF zipper produced a collapsed triangle")
    if any(twice_area(facet) <= 1.0e-14 for facet in result):
        raise ConstrainedHybridError("upper-UF zipper produced a zero-area facet")
    return tuple(result)


def _normal(
    facet: Sequence[int], coordinates: Mapping[int, Point3D]
) -> Point3D:
    first, second, third = (coordinates[node] for node in facet[:3])
    ab = tuple(second[index] - first[index] for index in range(3))
    ac = tuple(third[index] - first[index] for index in range(3))
    return (
        ab[1] * ac[2] - ab[2] * ac[1],
        ab[2] * ac[0] - ab[0] * ac[2],
        ab[0] * ac[1] - ab[1] * ac[0],
    )


def _orient_facet(
    facet: Sequence[int],
    coordinates: Mapping[int, Point3D],
    outward: Point3D,
) -> tuple[int, ...]:
    values = tuple(facet)
    normal = _normal(values, coordinates)
    dot = math.fsum(normal[index] * outward[index] for index in range(3))
    if abs(dot) <= 1.0e-18:
        raise ConstrainedHybridError(
            "upper-UF shell facet has ambiguous orientation: "
            f"facet={values}, points={tuple(coordinates[node] for node in values)}, "
            f"normal={normal}, outward={outward}"
        )
    return values if dot > 0.0 else tuple(reversed(values))


def _shell_volume(
    facets: Sequence[Sequence[int]], coordinates: Mapping[int, Point3D]
) -> float:
    contributions: list[float] = []
    for facet in facets:
        triangles = [(facet[0], facet[1], facet[2])]
        if len(facet) == 4:
            triangles.append((facet[0], facet[2], facet[3]))
        for first_id, second_id, third_id in triangles:
            first, second, third = (
                coordinates[first_id],
                coordinates[second_id],
                coordinates[third_id],
            )
            cross = (
                second[1] * third[2] - second[2] * third[1],
                second[2] * third[0] - second[0] * third[2],
                second[0] * third[1] - second[1] * third[0],
            )
            contributions.append(
                math.fsum(first[index] * cross[index] for index in range(3)) / 6.0
            )
    return abs(math.fsum(contributions))


def _build_discrete_shell(
    prepared: _PreparedUf,
    *,
    top_target_size: float,
    free_wall_subdivision_levels: int = 0,
) -> _DiscreteShell:
    if (
        isinstance(free_wall_subdivision_levels, bool)
        or not isinstance(free_wall_subdivision_levels, int)
        or free_wall_subdivision_levels not in {0, 1, 2}
    ):
        raise ConstrainedHybridError(
            "trace-core free-wall subdivision levels must be 0, 1 or 2"
        )
    ordered_source = tuple(
        sorted(
            prepared.source_coordinates,
            key=lambda node: _coordinate_key(prepared.source_coordinates[node]),
        )
    )
    node_by_source = {
        source: index for index, source in enumerate(ordered_source, start=1)
    }
    coordinates: dict[int, Point3D] = {
        node_by_source[source]: prepared.source_coordinates[source]
        for source in ordered_source
    }
    source_by_node = {local: source for source, local in node_by_source.items()}
    node_by_coordinate = {
        _coordinate_key(point): node for node, point in coordinates.items()
    }
    next_node = len(coordinates) + 1

    def add_point(point: Point3D) -> int:
        nonlocal next_node
        key = _coordinate_key(point)
        existing = node_by_coordinate.get(key)
        if existing is not None:
            return existing
        node = next_node
        next_node += 1
        coordinates[node] = point
        node_by_coordinate[key] = node
        return node

    bottom_outer = tuple(node_by_source[node] for node in prepared.outer_loop)
    bottom_inner_source = prepared.inner_loop
    if _signed_xy_area(bottom_inner_source, prepared.source_coordinates) < 0.0:
        bottom_inner_source = tuple(reversed(bottom_inner_source))
    bottom_inner = tuple(node_by_source[node] for node in bottom_inner_source)
    top_outer_points = _coarse_rounded_rectangle(
        prepared.envelope, prepared.cap_z, top_target_size
    )
    top_outer = tuple(add_point(point) for point in top_outer_points)
    envelope = prepared.envelope
    outer_phase = lambda point: _outer_phase(point, envelope)
    inner_phase = lambda point: _inner_phase(point, envelope)
    bottom_outer_segments = _segment_loop(
        bottom_outer, coordinates, outer_phase, 8
    )
    top_outer_segments = _segment_loop(top_outer, coordinates, outer_phase, 8)
    side_triangles: list[tuple[int, int, int]] = []
    side_quads: list[tuple[int, int, int, int]] = []
    if prepared.locked_side_facets:
        side_local = tuple(
            tuple(node_by_source[node] for node in facet)
            for facet in prepared.locked_side_facets
        )
        incidence: Counter[tuple[int, int]] = Counter()
        directed: dict[tuple[int, int], tuple[int, int]] = {}
        for facet in side_local:
            for first, second in zip(facet, (*facet[1:], facet[0])):
                edge = _edge_key(first, second)
                incidence[edge] += 1
                directed[edge] = (first, second)
        top_edges = tuple(
            directed[edge]
            for edge, count in incidence.items()
            if count == 1
            and all(
                abs(coordinates[node][2] - prepared.cap_z)
                <= _COORDINATE_TOLERANCE_MM
                for node in edge
            )
        )
        adjacency: dict[int, set[int]] = defaultdict(set)
        for first, second in top_edges:
            adjacency[first].add(second)
            adjacency[second].add(first)
        if not adjacency or any(len(values) != 2 for values in adjacency.values()):
            raise ConstrainedHybridError("locked upper-UF side has no closed top loop")
        top_values = [min(adjacency, key=lambda node: _coordinate_key(coordinates[node]))]
        previous: int | None = None
        while True:
            current = top_values[-1]
            choices = adjacency[current] - ({previous} if previous is not None else set())
            following = min(choices, key=lambda node: _coordinate_key(coordinates[node]))
            if following == top_values[0]:
                break
            top_values.append(following)
            previous = current
            if len(top_values) > len(adjacency):
                raise ConstrainedHybridError("locked upper-UF side top loop is invalid")
        if len(top_values) != len(adjacency):
            raise ConstrainedHybridError("locked upper-UF side top loop is incomplete")
        top_inner = tuple(top_values)
        if _signed_xy_area(top_inner, coordinates) < 0.0:
            top_inner = tuple(reversed(top_inner))
        for facet in side_local:
            centroid = tuple(
                math.fsum(coordinates[node][axis] for node in facet) / len(facet)
                for axis in range(3)
            )
            oriented = _orient_facet(
                facet,
                coordinates,
                (envelope.center_x - centroid[0], envelope.center_y - centroid[1], 0.0),
            )
            if len(oriented) == 3:
                side_triangles.append(oriented)  # type: ignore[arg-type]
            else:
                side_quads.append(oriented)  # type: ignore[arg-type]
    else:
        top_inner_points = _coarse_rectangle(
            prepared.envelope, prepared.cap_z, top_target_size
        )
        top_inner = tuple(add_point(point) for point in top_inner_points)
        bottom_inner_segments = _segment_loop(
            bottom_inner, coordinates, inner_phase, 4
        )
    top_inner_segments = _segment_loop(top_inner, coordinates, inner_phase, 4)

    bottom_quads = tuple(
        _orient_facet(
            tuple(node_by_source[node] for node in facet),
            coordinates,
            (0.0, 0.0, -1.0),
        )
        for facet in prepared.source_facets
    )
    raw_outer: tuple[tuple[int, int, int], ...] = tuple(
        facet
        for bottom_segment, top_segment in zip(
            bottom_outer_segments, top_outer_segments
        )
        for facet in _zipper_chains(bottom_segment, top_segment, coordinates)
    )
    for _level in range(free_wall_subdivision_levels):
        raw_outer = _subdivide_open_triangle_surface_once(
            raw_outer,
            coordinates,
            add_point,
        )
    raw_inner = () if prepared.locked_side_facets else tuple(
        facet
        for bottom_segment, top_segment in zip(
            bottom_inner_segments, top_inner_segments
        )
        for facet in _zipper_chains(bottom_segment, top_segment, coordinates)
    )
    raw_top_list: list[tuple[int, int, int]] = []
    for side_index in range(4):
        raw_top_list.extend(
            _zipper_chains(
                top_inner_segments[side_index],
                top_outer_segments[2 * side_index],
                coordinates,
            )
        )
        corner = top_inner_segments[side_index][-1]
        corner_segment = top_outer_segments[2 * side_index + 1]
        for first, second in zip(corner_segment, corner_segment[1:]):
            facet = (corner, first, second)
            if math.sqrt(
                math.fsum(
                    value * value for value in _normal(facet, coordinates)
                )
            ) <= 1.0e-14:
                raise ConstrainedHybridError(
                    "upper-UF top corner fan contains a zero-area facet"
                )
            raw_top_list.append(facet)
    raw_top = tuple(raw_top_list)
    outer_triangles: list[tuple[int, int, int]] = []
    for facet in raw_outer:
        centroid = tuple(
            math.fsum(coordinates[node][axis] for node in facet) / 3.0
            for axis in range(3)
        )
        if prepared.locked_side_facets:
            # A frozen side trace can meet the rounded toe exactly at a die
            # landmark; the centre ray remains unambiguous there.
            outward = (
                centroid[0] - prepared.envelope.center_x,
                centroid[1] - prepared.envelope.center_y,
                0.0,
            )
        else:
            anchor_x = min(
                max(
                    centroid[0],
                    prepared.envelope.center_x - prepared.envelope.half_die_width,
                ),
                prepared.envelope.center_x + prepared.envelope.half_die_width,
            )
            anchor_y = min(
                max(
                    centroid[1],
                    prepared.envelope.center_y - prepared.envelope.half_die_length,
                ),
                prepared.envelope.center_y + prepared.envelope.half_die_length,
            )
            outward = (centroid[0] - anchor_x, centroid[1] - anchor_y, 0.0)
        outer_triangles.append(_orient_facet(facet, coordinates, outward))
    inner_triangles: list[tuple[int, int, int]] = []
    for facet in raw_inner:
        centroid = tuple(
            math.fsum(coordinates[node][axis] for node in facet) / 3.0
            for axis in range(3)
        )
        outward = (
            prepared.envelope.center_x - centroid[0],
            prepared.envelope.center_y - centroid[1],
            0.0,
        )
        inner_triangles.append(_orient_facet(facet, coordinates, outward))
    top_triangles = tuple(
        _orient_facet(facet, coordinates, (0.0, 0.0, 1.0))
        for facet in raw_top
    )
    triangles = tuple((*outer_triangles, *inner_triangles, *side_triangles, *top_triangles))
    all_facets: tuple[tuple[int, ...], ...] = tuple(
        (*bottom_quads, *side_quads, *triangles)
    )
    edge_owners: dict[tuple[int, int], list[tuple[int, int]]] = defaultdict(list)
    for facet in all_facets:
        for first, second in zip(facet, (*facet[1:], facet[0])):
            edge_owners[_edge_key(first, second)].append((first, second))
    invalid_edges = tuple(
        (edge, tuple(owners))
        for edge, owners in edge_owners.items()
        if len(owners) != 2 or owners[0] != tuple(reversed(owners[1]))
    )
    if invalid_edges:
        raise ConstrainedHybridError(
            "upper-UF discrete shell is not watertight and consistently oriented; "
            f"invalid_edges={len(invalid_edges)}, first={invalid_edges[0]}, "
            f"coordinates={tuple(coordinates[node] for node in invalid_edges[0][0])}"
        )
    for point in coordinates.values():
        if not _envelope_contains_with_tolerance(prepared.envelope, point):
            raise ConstrainedHybridError(
                "upper-UF discrete shell escapes the analytic envelope"
            )
    volume = _shell_volume(all_facets, coordinates)
    if not math.isfinite(volume) or volume <= 0.0:
        raise ConstrainedHybridError("upper-UF discrete shell has zero volume")
    return _DiscreteShell(
        coordinates=MappingProxyType(coordinates),
        source_id_by_node=MappingProxyType(source_by_node),
        triangles=triangles,
        bottom_quads=bottom_quads,  # type: ignore[arg-type]
        side_quads=tuple(side_quads),
        die_wall_keys=frozenset(
            _face_key(facet)
            for facet in (*inner_triangles, *side_triangles, *side_quads)
        ),
        free_surface_keys=frozenset(_face_key(facet) for facet in outer_triangles),
        top_cap_keys=frozenset(_face_key(facet) for facet in top_triangles),
        volume_mm3=volume,
    )


def _build_explicit_trace_collar(
    prepared: _PreparedUf,
    *,
    top_target_size: float,
) -> _ExplicitTraceCollar:
    """Replace every locked QUAD by a deterministic positive PYR collar.

    Gmsh's automatic QUAD-to-PYR conversion is sensitive to the ordering of
    this large mixed shell and can create zero-height pyramids at a handful of
    vertices.  Here each apex is placed deterministically from the locked
    surface alone.  The initial height is the larger of ``0.125 * shortest``
    and ``0.025 * longest`` edge.  This avoids flat collars on near-square
    faces while retaining the height needed by the audited anisotropic high-UF
    trace (audited base aspect ratio at most 73.184); the complete Gmsh quality
    audit below remains the authority for every emitted element.

    A bottom QUAD and the first die-wall QUAD sharing an orthogonal fold edge
    use one common apex.  If that apex crosses a thin side row, the adjacent
    coplanar row joins the same cluster.  This removes the only local overlap
    otherwise caused by independently extruding two perpendicular bases.  All
    remaining orthogonal folds are checked by the exact normal-section
    non-overlap inequality before Gmsh is called.

    Removing the exterior QUAD bases and retaining the four lateral TRI faces
    of every pyramid produces one independent, all-TRI, closed remainder
    shell.  Its volume plus the explicit pyramid volume must reproduce the
    original shell before Gmsh is allowed to tetrahedralize it.
    """

    shell = _build_discrete_shell(
        prepared,
        top_target_size=top_target_size,
        free_wall_subdivision_levels=0,
    )
    coordinates: dict[int, Point3D] = dict(shell.coordinates)
    by_coordinate = {
        _coordinate_key(point): node for node, point in coordinates.items()
    }
    next_node = max(coordinates, default=0) + 1
    bases = tuple((*shell.bottom_quads, *shell.side_quads))
    bottom_count = len(shell.bottom_quads)
    if not bases or not shell.side_quads:
        raise ConstrainedHybridError(
            "explicit trace collar requires bottom and side locked QUADs"
        )

    local_by_source = {
        source: local for local, source in shell.source_id_by_node.items()
    }
    try:
        outer_loop = tuple(local_by_source[node] for node in prepared.outer_loop)
    except KeyError as error:
        raise ConstrainedHybridError(
            "explicit trace collar lost a bottom outer-loop node"
        ) from error
    outer_edges = {
        _edge_key(first, second)
        for first, second in zip(outer_loop, (*outer_loop[1:], outer_loop[0]))
    }

    centroids: list[Point3D] = []
    apex_origins: list[Point3D] = []
    inward_normals: list[Point3D] = []
    face_areas: list[float] = []
    minimum_edge_lengths: list[float] = []
    maximum_edge_lengths: list[float] = []
    heights: list[float] = []
    for base_index, outward_base in enumerate(bases):
        centroid = tuple(
            math.fsum(coordinates[node][axis] for node in outward_base) / 4.0
            for axis in range(3)
        )
        raw_normal = _normal(outward_base, coordinates)
        normal_length = math.sqrt(math.fsum(value * value for value in raw_normal))
        if not math.isfinite(normal_length) or normal_length <= 1.0e-18:
            raise ConstrainedHybridError(
                "locked trace QUAD has an ambiguous collar direction"
            )
        inward = tuple(-value / normal_length for value in raw_normal)
        edge_lengths = tuple(
            math.dist(coordinates[first], coordinates[second])
            for first, second in zip(
                outward_base,
                (*outward_base[1:], outward_base[0]),
            )
        )
        if any(not math.isfinite(value) or value <= 0.0 for value in edge_lengths):
            raise ConstrainedHybridError("locked trace QUAD has an invalid edge")
        apex_origin = centroid
        if base_index < bottom_count:
            boundary_edges = tuple(
                edge
                for edge in (
                    _edge_key(first, second)
                    for first, second in zip(
                        outward_base,
                        (*outward_base[1:], outward_base[0]),
                    )
                )
                if edge in outer_edges
            )
            if len(boundary_edges) > 2:
                raise ConstrainedHybridError(
                    "locked trace bottom QUAD has too many outer edges"
                )
            if boundary_edges:
                # A centred apex makes the PYR lateral face and the ruled toe
                # wall meet at a very shallow, fixed dihedral angle.  Moving
                # the apex towards the opposite edge stays strictly inside
                # the base projection while opening that unavoidable first
                # TET.  Corner cells contribute both outer-edge directions.
                inset = [0.0, 0.0, 0.0]
                for first, second in boundary_edges:
                    midpoint = tuple(
                        0.5
                        * (coordinates[first][axis] + coordinates[second][axis])
                        for axis in range(3)
                    )
                    for axis in range(3):
                        inset[axis] += centroid[axis] - midpoint[axis]
                apex_origin = tuple(
                    centroid[axis]
                    + _TRACE_TOE_APEX_INSET_FRACTION * inset[axis]
                    for axis in range(3)
                )
                cross_values = tuple(
                    (coordinates[second][0] - coordinates[first][0])
                    * (apex_origin[1] - coordinates[first][1])
                    - (coordinates[second][1] - coordinates[first][1])
                    * (apex_origin[0] - coordinates[first][0])
                    for first, second in zip(
                        outward_base,
                        (*outward_base[1:], outward_base[0]),
                    )
                )
                strictly_positive = all(
                    value > _COORDINATE_TOLERANCE_MM**2
                    for value in cross_values
                )
                strictly_negative = all(
                    value < -_COORDINATE_TOLERANCE_MM**2
                    for value in cross_values
                )
                if not (strictly_positive or strictly_negative):
                    raise ConstrainedHybridError(
                        "trace toe collar apex does not stay inside its base"
                    )

        height = max(
            0.125 * min(edge_lengths),
            0.025 * max(edge_lengths),
        )
        if base_index < bottom_count:
            clearance = min(
                prepared.cap_z - centroid[2],
                prepared.envelope.top_height(apex_origin[0], apex_origin[1])
                - centroid[2],
            )
            if not math.isfinite(clearance) or clearance <= (
                10.0 * _COORDINATE_TOLERANCE_MM
            ):
                raise ConstrainedHybridError(
                    "locked trace bottom QUAD has no positive collar clearance"
                )
            height = min(height, 0.9 * clearance)
        if height <= 10.0 * _COORDINATE_TOLERANCE_MM:
            raise ConstrainedHybridError(
                "locked trace QUAD has no positive collar height"
            )
        centroids.append(centroid)  # type: ignore[arg-type]
        apex_origins.append(apex_origin)  # type: ignore[arg-type]
        inward_normals.append(inward)  # type: ignore[arg-type]
        face_areas.append(normal_length)
        minimum_edge_lengths.append(min(edge_lengths))
        maximum_edge_lengths.append(max(edge_lengths))
        heights.append(height)

    edge_owners: dict[tuple[int, int], list[int]] = defaultdict(list)
    for base_index, base in enumerate(bases):
        for first, second in zip(base, (*base[1:], base[0])):
            key = _edge_key(first, second)
            edge_owners[key].append(base_index)

    group_by_base: dict[int, int] = {}
    apex_by_group: dict[int, Point3D] = {}
    next_group = 1
    for edge, owners in sorted(edge_owners.items()):
        if len(owners) != 2:
            continue
        bottom = tuple(index for index in owners if index < bottom_count)
        side = tuple(index for index in owners if index >= bottom_count)
        if len(bottom) != 1 or len(side) != 1:
            continue
        bottom_index = bottom[0]
        side_index = side[0]
        dot = math.fsum(
            inward_normals[bottom_index][axis]
            * inward_normals[side_index][axis]
            for axis in range(3)
        )
        if abs(dot) > 1.0e-8:
            raise ConstrainedHybridError(
                "bottom/side trace fold is not orthogonal"
            )
        if bottom_index in group_by_base or side_index in group_by_base:
            raise ConstrainedHybridError(
                "locked trace QUAD participates in multiple bottom/side folds"
            )
        first, second = edge
        midpoint = tuple(
            0.5 * (coordinates[first][axis] + coordinates[second][axis])
            for axis in range(3)
        )
        apex = tuple(
            midpoint[axis]
            + heights[bottom_index] * inward_normals[bottom_index][axis]
            + heights[side_index] * inward_normals[side_index][axis]
            for axis in range(3)
        )
        members = [bottom_index, side_index]
        current_side = side_index
        while True:
            z_values = tuple(coordinates[node][2] for node in bases[current_side])
            z_min = min(z_values)
            z_max = max(z_values)
            if z_min + _COORDINATE_TOLERANCE_MM < apex[2] < (
                z_max - _COORDINATE_TOLERANCE_MM
            ):
                break
            if apex[2] <= z_min + _COORDINATE_TOLERANCE_MM:
                raise ConstrainedHybridError(
                    "shared trace-collar apex does not enter its side column"
                )
            top_edges = tuple(
                edge_key
                for edge_key in (
                    _edge_key(a, b)
                    for a, b in zip(
                        bases[current_side],
                        (*bases[current_side][1:], bases[current_side][0]),
                    )
                )
                if all(
                    abs(coordinates[node][2] - z_max)
                    <= _COORDINATE_TOLERANCE_MM
                    for node in edge_key
                )
            )
            if len(top_edges) != 1:
                raise ConstrainedHybridError(
                    "trace side row has no unique upper edge"
                )
            candidates = tuple(
                index
                for index in edge_owners[top_edges[0]]
                if index != current_side and index >= bottom_count
            )
            if len(candidates) != 1:
                raise ConstrainedHybridError(
                    "shared trace-collar apex crosses an open side column"
                )
            following = candidates[0]
            parallel = math.fsum(
                inward_normals[current_side][axis]
                * inward_normals[following][axis]
                for axis in range(3)
            )
            if parallel < 1.0 - 1.0e-8:
                raise ConstrainedHybridError(
                    "trace side column changes plane across a collar cluster"
                )
            if following in members or following in group_by_base:
                raise ConstrainedHybridError(
                    "trace side column collar cluster overlaps another cluster"
                )
            members.append(following)
            current_side = following
            if len(members) > len(shell.side_quads) + 1:
                raise ConstrainedHybridError(
                    "trace side column collar cluster does not terminate"
                )

        if (
            not all(math.isfinite(value) for value in apex)
            or apex[2] <= prepared.transition_z + _COORDINATE_TOLERANCE_MM
            or apex[2] >= prepared.cap_z - _COORDINATE_TOLERANCE_MM
            or not _envelope_contains_with_tolerance(prepared.envelope, apex)
        ):
            raise ConstrainedHybridError(
                "shared trace-collar apex lies outside the UF"
            )
        group = next_group
        next_group += 1
        apex_by_group[group] = apex  # type: ignore[assignment]
        for member in members:
            group_by_base[member] = group

    # A shallow apex is required at orthogonal folds, where two independent
    # normal prisms can otherwise overlap.  Away from those folds, the very
    # thin and highly anisotropic Frozen side rows need a deeper local collar
    # so the first remainder TET is not forced to span a nearly flat TRI.  The
    # bottom collar remains shallow: increasing its height was independently
    # shown to move the same sliver failure to the rounded toe.
    orthogonal_fold_bases: set[int] = set()
    for owners in edge_owners.values():
        if len(owners) != 2:
            continue
        first_index, second_index = owners
        dot = math.fsum(
            inward_normals[first_index][axis]
            * inward_normals[second_index][axis]
            for axis in range(3)
        )
        if abs(dot) <= 1.0e-8:
            orthogonal_fold_bases.update(owners)
    for base_index in range(bottom_count, len(bases)):
        if (
            base_index not in group_by_base
            and base_index not in orthogonal_fold_bases
        ):
            heights[base_index] = max(
                0.125 * minimum_edge_lengths[base_index],
                0.05 * maximum_edge_lengths[base_index],
            )

    for base_index, centroid in enumerate(centroids):
        if base_index in group_by_base:
            continue
        apex_origin = apex_origins[base_index]
        apex = tuple(
            apex_origin[axis]
            + heights[base_index] * inward_normals[base_index][axis]
            for axis in range(3)
        )
        if (
            not all(math.isfinite(value) for value in apex)
            or apex[2] <= prepared.transition_z + _COORDINATE_TOLERANCE_MM
            or apex[2] >= prepared.cap_z - _COORDINATE_TOLERANCE_MM
            or not _envelope_contains_with_tolerance(prepared.envelope, apex)
        ):
            raise ConstrainedHybridError(
                "locked trace QUAD cannot place an interior PYRAMID5 apex"
            )
        group = next_group
        next_group += 1
        group_by_base[base_index] = group
        apex_by_group[group] = apex  # type: ignore[assignment]

    # Coplanar independent pyramids stay inside disjoint normal prisms.  At an
    # orthogonal fold their normal-section triangles are disjoint iff this
    # strict inequality holds.  Shared-apex clusters are conformal by
    # construction and are excluded from the test.
    for edge, owners in edge_owners.items():
        if len(owners) != 2:
            continue
        first_index, second_index = owners
        dot = math.fsum(
            inward_normals[first_index][axis]
            * inward_normals[second_index][axis]
            for axis in range(3)
        )
        if abs(dot) > 1.0e-8:
            continue
        if group_by_base[first_index] == group_by_base[second_index]:
            continue
        edge_length = math.dist(coordinates[edge[0]], coordinates[edge[1]])
        first_width = face_areas[first_index] / edge_length
        second_width = face_areas[second_index] / edge_length
        first_apex = apex_by_group[group_by_base[first_index]]
        second_apex = apex_by_group[group_by_base[second_index]]
        first_height = abs(
            math.fsum(
                (first_apex[axis] - centroids[first_index][axis])
                * inward_normals[first_index][axis]
                for axis in range(3)
            )
        )
        second_height = abs(
            math.fsum(
                (second_apex[axis] - centroids[second_index][axis])
                * inward_normals[second_index][axis]
                for axis in range(3)
            )
        )
        if 4.0 * first_height * second_height >= (
            first_width * second_width
        ):
            raise ConstrainedHybridError(
                "independent trace-collar pyramids overlap across a fold"
            )

    pyramids: list[HybridVolumeElement] = []
    lateral_by_key: dict[FaceKey, list[tuple[int, int, int]]] = defaultdict(list)
    apex_node_by_group: dict[int, int] = {}
    for group, apex in sorted(apex_by_group.items()):
        key = _coordinate_key(apex)
        if key in by_coordinate:
            raise ConstrainedHybridError(
                "explicit trace collar produced coincident cluster apexes"
            )
        apex_node_by_group[group] = next_node
        coordinates[next_node] = apex
        by_coordinate[key] = next_node
        next_node += 1

    for base_index, outward_base in enumerate(bases):
        apex_node = apex_node_by_group[group_by_base[base_index]]
        # The source shell cycle points out of the volume.  Gmsh PYRAMID5
        # expects its QUAD base normal to point towards the apex.
        inward_base = tuple(reversed(outward_base))
        pyramid = HybridVolumeElement(
            _PYRAMID5,
            (*inward_base, apex_node),
        )
        pyramids.append(pyramid)
        for local_face in ELEMENT_SPECS[_PYRAMID5][2][1:]:
            facet = tuple(pyramid.node_ids[index] for index in local_face)
            lateral_by_key[_face_key(facet)].append(facet)  # type: ignore[arg-type]

    if not pyramids:
        raise ConstrainedHybridError("explicit trace collar contains no pyramids")
    if any(len(facets) > 2 for facets in lateral_by_key.values()):
        raise ConstrainedHybridError(
            "explicit trace collar contains a non-manifold lateral face"
        )
    exposed_lateral = tuple(
        facets[0]
        for _key, facets in sorted(lateral_by_key.items())
        if len(facets) == 1
    )
    raw_remainder = tuple((*shell.triangles, *exposed_lateral))
    remainder_triangles, remainder_volume = _orient_closed_triangle_shell(
        raw_remainder,
        coordinates,
    )
    pyramid_volume = math.fsum(
        _element_volume(element, coordinates) for element in pyramids
    )
    if (
        not math.isfinite(pyramid_volume)
        or pyramid_volume <= 0.0
        or not math.isfinite(remainder_volume)
        or remainder_volume <= 0.0
    ):
        raise ConstrainedHybridError(
            "explicit trace collar has a non-positive sub-volume"
        )
    relative_error = abs(
        remainder_volume + pyramid_volume - shell.volume_mm3
    ) / shell.volume_mm3
    if relative_error > 1.0e-9:
        raise ConstrainedHybridError(
            "explicit trace collar/remainder volume does not partition the UF; "
            f"relative_error={relative_error:.8g}"
        )
    return _ExplicitTraceCollar(
        coordinates=MappingProxyType(coordinates),
        triangles=remainder_triangles,
        pyramids=tuple(pyramids),
        exterior_facets=tuple(
            (*shell.bottom_quads, *shell.side_quads, *shell.triangles)
        ),
        full_volume_mm3=shell.volume_mm3,
        remainder_volume_mm3=remainder_volume,
    )


def _prepare_tet_remainder(
    docking_node_coordinates: Mapping[int, Sequence[float]],
    docking_facets: Sequence[Sequence[int]],
    envelope: RectangularUfEnvelope,
    transition_z_mm: float,
    cap_z_mm: float,
) -> _PreparedTetRemainder:
    """Validate the coarsened TRI3 cap emitted by the QUAD adapter."""

    transition_z = _finite(transition_z_mm, name="upper-UF TET transition Z")
    cap_z = _finite(cap_z_mm, name="upper-UF TET cap Z")
    if not (
        envelope.base_z < transition_z < cap_z < envelope.apex_z
        and cap_z - transition_z > _COORDINATE_TOLERANCE_MM
    ):
        raise ConstrainedHybridError(
            "upper-UF TET transition/cap must lie strictly inside the fillet"
        )
    coordinates: dict[int, Point3D] = {}
    for raw_node, raw_point in docking_node_coordinates.items():
        if isinstance(raw_node, bool) or not isinstance(raw_node, int) or raw_node < 1:
            raise ConstrainedHybridError(
                "upper-UF TET docking IDs must be positive integers"
            )
        try:
            values = tuple(raw_point)
        except TypeError as error:
            raise ConstrainedHybridError(
                "upper-UF TET docking coordinate must contain x,y,z"
            ) from error
        if len(values) != 3:
            raise ConstrainedHybridError(
                "upper-UF TET docking coordinate must contain x,y,z"
            )
        point = tuple(
            _finite(value, name=f"upper-UF TET docking node {raw_node}")
            for value in values
        )
        if abs(point[2] - transition_z) > _COORDINATE_TOLERANCE_MM:
            raise ConstrainedHybridError(
                "every upper-UF TET docking node must lie on one plane"
            )
        if not _envelope_contains_with_tolerance(envelope, point):
            raise ConstrainedHybridError(
                "upper-UF TET docking node lies outside the analytic fillet"
            )
        coordinates[raw_node] = point  # type: ignore[assignment]
    if not coordinates:
        raise ConstrainedHybridError("upper-UF TET docking surface is empty")
    if len({_coordinate_key(point) for point in coordinates.values()}) != len(
        coordinates
    ):
        raise ConstrainedHybridError(
            "upper-UF TET docking surface has duplicate coordinates"
        )
    try:
        raw_facets = tuple(tuple(facet) for facet in docking_facets)
    except TypeError as error:
        raise ConstrainedHybridError(
            "upper-UF TET docking facets must be TRI3"
        ) from error
    facets: list[tuple[int, int, int]] = []
    for raw_facet in raw_facets:
        if len(raw_facet) != 3:
            raise ConstrainedHybridError(
                "upper-UF TET docking facets must all be TRI3"
            )
        facet = tuple(int(node) for node in raw_facet)
        if len(set(facet)) != 3 or any(node not in coordinates for node in facet):
            raise ConstrainedHybridError("upper-UF TET docking facet is invalid")
        normal = _normal(facet, coordinates)
        if math.sqrt(math.fsum(value * value for value in normal)) <= 1.0e-14:
            raise ConstrainedHybridError("upper-UF TET docking facet has zero area")
        facets.append(facet)  # type: ignore[arg-type]
    if not facets or len({_face_key(facet) for facet in facets}) != len(facets):
        raise ConstrainedHybridError(
            "upper-UF TET docking facets must be non-empty and unique"
        )
    if {node for facet in facets for node in facet} != set(coordinates):
        raise ConstrainedHybridError(
            "every upper-UF TET docking node must be referenced"
        )
    outer_loop, inner_loop = _trace_boundary_loops(facets, coordinates)
    outer_loop = _canonical_loop(outer_loop, coordinates)
    inner_loop = _canonical_loop(inner_loop, coordinates)
    if _signed_xy_area(outer_loop, coordinates) < 0.0:
        outer_loop = tuple(reversed(outer_loop))
    outer_loop = _rotate_loop(outer_loop, coordinates)
    die_area = envelope.die_width * envelope.die_length
    if not math.isclose(
        abs(_signed_xy_area(inner_loop, coordinates)),
        die_area,
        rel_tol=1.0e-9,
        abs_tol=_COORDINATE_TOLERANCE_MM**2,
    ):
        raise ConstrainedHybridError(
            "upper-UF TET inner loop does not enclose the die"
        )
    return _PreparedTetRemainder(
        source_coordinates=MappingProxyType(coordinates),
        source_facets=tuple(facets),
        outer_loop=outer_loop,
        inner_loop=inner_loop,
        envelope=envelope,
        transition_z=transition_z,
        cap_z=cap_z,
    )


def _orient_closed_triangle_shell(
    raw_facets: Sequence[Sequence[int]],
    coordinates: Mapping[int, Point3D],
) -> tuple[tuple[tuple[int, int, int], ...], float]:
    """Orient one connected TRI shell by adjacency, then make it outward."""

    facets = tuple(tuple(int(node) for node in facet) for facet in raw_facets)
    if not facets or any(len(facet) != 3 for facet in facets):
        raise ConstrainedHybridError("upper-UF TET shell must contain only TRI3")
    owners: dict[tuple[int, int], list[tuple[int, int]]] = defaultdict(list)
    for index, facet in enumerate(facets):
        for first, second in zip(facet, (*facet[1:], facet[0])):
            key = _edge_key(first, second)
            direction = 1 if (first, second) == key else -1
            owners[key].append((index, direction))
    invalid = tuple((edge, entries) for edge, entries in owners.items() if len(entries) != 2)
    if invalid:
        raise ConstrainedHybridError(
            "upper-UF TET shell is not watertight: "
            f"bad_edges={len(invalid)}, first={invalid[0]}"
        )
    signs: dict[int, int] = {0: 1}
    queue = deque([0])
    while queue:
        current = queue.popleft()
        facet = facets[current]
        for first, second in zip(facet, (*facet[1:], facet[0])):
            entries = owners[_edge_key(first, second)]
            current_entry = entries[0] if entries[0][0] == current else entries[1]
            other_entry = entries[1] if entries[0][0] == current else entries[0]
            required = -signs[current] * current_entry[1] * other_entry[1]
            other = other_entry[0]
            existing = signs.get(other)
            if existing is not None and existing != required:
                raise ConstrainedHybridError(
                    "upper-UF TET shell orientation is inconsistent"
                )
            if existing is None:
                signs[other] = required
                queue.append(other)
    if len(signs) != len(facets):
        raise ConstrainedHybridError("upper-UF TET shell is disconnected")
    oriented = tuple(
        facet if signs[index] > 0 else tuple(reversed(facet))
        for index, facet in enumerate(facets)
    )
    signed_volume = math.fsum(
        math.fsum(
            coordinates[facet[0]][axis]
            * (
                coordinates[facet[1]][(axis + 1) % 3]
                * coordinates[facet[2]][(axis + 2) % 3]
                - coordinates[facet[1]][(axis + 2) % 3]
                * coordinates[facet[2]][(axis + 1) % 3]
            )
            for axis in range(3)
        )
        / 6.0
        for facet in oriented
    )
    if signed_volume < 0.0:
        oriented = tuple(tuple(reversed(facet)) for facet in oriented)
        signed_volume = -signed_volume
    if not math.isfinite(signed_volume) or signed_volume <= 0.0:
        raise ConstrainedHybridError("upper-UF TET shell has non-positive volume")
    return oriented, signed_volume


def _build_tet_remainder_shell(
    prepared: _PreparedTetRemainder,
    *,
    top_target_size: float,
) -> _TetShell:
    ordered_source = tuple(
        sorted(
            prepared.source_coordinates,
            key=lambda node: _coordinate_key(prepared.source_coordinates[node]),
        )
    )
    node_by_source = {
        source: index for index, source in enumerate(ordered_source, start=1)
    }
    coordinates: dict[int, Point3D] = {
        node_by_source[source]: prepared.source_coordinates[source]
        for source in ordered_source
    }
    source_by_node = {local: source for source, local in node_by_source.items()}
    node_by_coordinate = {
        _coordinate_key(point): node for node, point in coordinates.items()
    }
    next_node = len(coordinates) + 1

    def add_point(point: Point3D) -> int:
        nonlocal next_node
        key = _coordinate_key(point)
        existing = node_by_coordinate.get(key)
        if existing is not None:
            return existing
        node = next_node
        next_node += 1
        coordinates[node] = point
        node_by_coordinate[key] = node
        return node

    bottom_outer = tuple(node_by_source[node] for node in prepared.outer_loop)
    bottom_inner_source = prepared.inner_loop
    if _signed_xy_area(bottom_inner_source, prepared.source_coordinates) < 0.0:
        bottom_inner_source = tuple(reversed(bottom_inner_source))
    bottom_inner = tuple(node_by_source[node] for node in bottom_inner_source)
    top_outer = tuple(
        add_point(point)
        for point in _coarse_rounded_rectangle(
            prepared.envelope,
            prepared.cap_z,
            top_target_size,
        )
    )
    top_inner = tuple(
        add_point(point)
        for point in _coarse_rectangle(
            prepared.envelope,
            prepared.cap_z,
            top_target_size,
        )
    )
    outer_phase = lambda point: _outer_phase(point, prepared.envelope)
    inner_phase = lambda point: _inner_phase(point, prepared.envelope)
    bottom_outer_segments = _segment_loop(
        bottom_outer, coordinates, outer_phase, 8
    )
    top_outer_segments = _segment_loop(top_outer, coordinates, outer_phase, 8)
    bottom_inner_segments = _segment_loop(
        bottom_inner, coordinates, inner_phase, 4
    )
    top_inner_segments = _segment_loop(top_inner, coordinates, inner_phase, 4)
    side_outer = tuple(
        facet
        for bottom, top in zip(bottom_outer_segments, top_outer_segments)
        for facet in _zipper_chains(bottom, top, coordinates)
    )
    side_inner = tuple(
        facet
        for bottom, top in zip(bottom_inner_segments, top_inner_segments)
        for facet in _zipper_chains(bottom, top, coordinates)
    )
    top_facets: list[tuple[int, int, int]] = []
    for side_index in range(4):
        top_facets.extend(
            _zipper_chains(
                top_inner_segments[side_index],
                top_outer_segments[2 * side_index],
                coordinates,
            )
        )
        corner = top_inner_segments[side_index][-1]
        corner_segment = top_outer_segments[2 * side_index + 1]
        top_facets.extend(
            (corner, first, second)
            for first, second in zip(corner_segment, corner_segment[1:])
        )
    bottom_facets = tuple(
        tuple(node_by_source[node] for node in facet)
        for facet in prepared.source_facets
    )
    oriented, volume = _orient_closed_triangle_shell(
        (*bottom_facets, *side_outer, *side_inner, *top_facets),
        coordinates,
    )
    for point in coordinates.values():
        if not _envelope_contains_with_tolerance(prepared.envelope, point):
            raise ConstrainedHybridError(
                "upper-UF TET shell escapes the analytic envelope"
            )
    return _TetShell(
        coordinates=MappingProxyType(coordinates),
        source_id_by_node=MappingProxyType(source_by_node),
        triangles=oriented,
        bottom_keys=frozenset(_face_key(facet) for facet in bottom_facets),
        volume_mm3=volume,
    )


def _add_exact_bottom_curves(
    gmsh: Any,
    prepared: _PreparedUf,
    surface_tag: int,
) -> None:
    edge_counts: Counter[tuple[int, int]] = Counter(
        _edge_key(first, second)
        for facet in prepared.dummy_docking.source_facets
        for first, second in zip(facet, (*facet[1:], facet[0]))
    )
    boundary_edges = {edge for edge, count in edge_counts.items() if count == 1}
    boundary_nodes = {node for edge in boundary_edges for node in edge}
    curve_tags = tuple(
        int(tag)
        for dimension, tag in gmsh.model.getBoundary(
            [(2, surface_tag)], oriented=False, recursive=False
        )
        if int(dimension) == 1
    )
    if not curve_tags:
        raise ConstrainedHybridError("OCC upper-UF docking surface has no curves")
    gmsh.model.mesh.generate(1)
    gmsh.model.mesh.clear([(1, tag) for tag in curve_tags])
    next_node = int(gmsh.model.mesh.getMaxNodeTag()) + 1
    next_element = int(gmsh.model.mesh.getMaxElementTag()) + 1
    by_coordinate = {
        _coordinate_key(point): tag for tag, point in _all_nodes(gmsh).items()
    }
    installed_edges: set[tuple[int, int]] = set()
    for curve_tag in sorted(curve_tags):
        bounds = gmsh.model.getBoundingBox(1, curve_tag)
        candidates: list[tuple[float, int]] = []
        for source_id in boundary_nodes:
            point = prepared.dummy_docking.source_coordinates[source_id]
            if not all(
                bounds[axis] - _OCC_BOUNDING_TOLERANCE_MM
                <= point[axis]
                <= bounds[axis + 3] + _OCC_BOUNDING_TOLERANCE_MM
                for axis in range(3)
            ):
                continue
            try:
                parameter = float(
                    gmsh.model.getParametrization(1, curve_tag, list(point))[0]
                )
                closest, _ = gmsh.model.getClosestPoint(1, curve_tag, list(point))
            except Exception:
                continue
            closest_point = tuple(float(closest[index]) for index in range(3))
            if math.dist(point, closest_point) <= _OCC_BOUNDING_TOLERANCE_MM:
                candidates.append((parameter, source_id))
        ordered = tuple(sorted(candidates))
        chain = tuple(source_id for _parameter, source_id in ordered)
        actual_edges = {
            _edge_key(first, second) for first, second in zip(chain, chain[1:])
        }
        if len(chain) < 2 or not actual_edges or not actual_edges.issubset(
            boundary_edges
        ):
            raise ConstrainedHybridError(
                "could not match an OCC upper-UF curve to source edges"
            )
        line_nodes: list[int] = []
        new_tags: list[int] = []
        new_coordinates: list[float] = []
        new_parameters: list[float] = []
        for parameter, source_id in ordered:
            point = prepared.dummy_docking.source_coordinates[source_id]
            key = _coordinate_key(point)
            node_tag = by_coordinate.get(key)
            if node_tag is None:
                node_tag = next_node
                next_node += 1
                by_coordinate[key] = node_tag
                new_tags.append(node_tag)
                new_coordinates.extend(point)
                new_parameters.append(parameter)
            line_nodes.append(node_tag)
        if new_tags:
            gmsh.model.mesh.addNodes(
                1,
                curve_tag,
                new_tags,
                new_coordinates,
                new_parameters,
            )
        element_tags = list(
            range(next_element, next_element + len(line_nodes) - 1)
        )
        next_element += len(element_tags)
        gmsh.model.mesh.addElementsByType(
            curve_tag,
            1,
            element_tags,
            [node for pair in zip(line_nodes, line_nodes[1:]) for node in pair],
        )
        installed_edges.update(actual_edges)
    if installed_edges != boundary_edges:
        raise ConstrainedHybridError(
            "OCC upper-UF curves do not preserve every docking edge"
        )
    gmsh.model.mesh.generate(1)


def _mesh_candidate(
    gmsh: Any,
    prepared: _PreparedUf,
    *,
    maximum_size: float,
    near_size: float,
    transition_distance: float,
    optimization_rounds: int,
    seed: int,
    verbose: bool,
) -> tuple[Any, float]:
    slope = max(0.0, (maximum_size - near_size) / transition_distance)
    options = {
        "General.Terminal": 1.0 if verbose else 0.0,
        "Mesh.ElementOrder": 1.0,
        "Mesh.Algorithm": 6.0,
        "Mesh.Algorithm3D": 1.0,
        "Mesh.MeshOnlyEmpty": 1.0,
        "Mesh.MeshSizeMin": near_size,
        "Mesh.MeshSizeMax": maximum_size,
        "Mesh.MeshSizeExtendFromBoundary": 0.0,
        "Mesh.MeshSizeFromCurvature": 0.0,
        "Mesh.MeshSizeFromPoints": 0.0,
        "Mesh.Optimize": 1.0 if optimization_rounds else 0.0,
        "Mesh.OptimizePyramids": 1.0,
        "Mesh.RandomSeed": float(seed),
    }
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_occ_uf_upper_hybrid",
        number_options=options,
    ):
        bottom_outer_points = tuple(
            prepared.source_coordinates[node] for node in prepared.outer_loop
        )
        bottom_wire = _add_polygon_wire(gmsh, bottom_outer_points)
        cap_points = _coarse_rounded_rectangle(
            prepared.envelope,
            prepared.cap_z,
            maximum_size,
        )
        cap_wire = _add_polygon_wire(gmsh, cap_points)
        loft_entities = gmsh.model.occ.addThruSections(
            [bottom_wire, cap_wire],
            makeSolid=True,
            makeRuled=False,
        )
        outer_volumes = [int(tag) for dimension, tag in loft_entities if int(dimension) == 3]
        if len(outer_volumes) != 1:
            raise ConstrainedHybridError("OCC did not create one upper-UF outer loft")
        envelope = prepared.envelope
        # The cutter must extend beyond OpenCASCADE's own ~1e-7 modelling
        # tolerance; a smaller epsilon can leave four microscopic corner
        # edges and an apparently open 1-D surface loop.
        epsilon = max(1.0e-6, 1.0e-4 * (prepared.cap_z - prepared.transition_z))
        inner = int(
            gmsh.model.occ.addBox(
                envelope.center_x - envelope.half_die_width,
                envelope.center_y - envelope.half_die_length,
                prepared.transition_z - epsilon,
                envelope.die_width,
                envelope.die_length,
                prepared.cap_z - prepared.transition_z + 2.0 * epsilon,
            )
        )
        gmsh.model.occ.cut(
            [(3, outer_volumes[0])],
            [(3, inner)],
            removeObject=True,
            removeTool=True,
        )
        gmsh.model.occ.synchronize()
        volume_tags = tuple(int(tag) for _dimension, tag in gmsh.model.getEntities(3))
        if len(volume_tags) != 1:
            raise ConstrainedHybridError("OCC upper-UF cut did not preserve one volume")
        volume_tag = volume_tags[0]
        cad_volume = float(gmsh.model.occ.getMass(3, volume_tag))
        if not math.isfinite(cad_volume) or cad_volume <= 0.0:
            raise ConstrainedHybridError("OCC upper-UF volume is not positive")
        surfaces = tuple(
            int(tag)
            for dimension, tag in gmsh.model.getBoundary(
                [(3, volume_tag)], oriented=False, recursive=False
            )
            if int(dimension) == 2
        )
        flat_surfaces = []
        for surface in surfaces:
            bounds = gmsh.model.getBoundingBox(2, surface)
            if abs(bounds[5] - bounds[2]) <= _OCC_BOUNDING_TOLERANCE_MM:
                flat_surfaces.append((0.5 * (bounds[2] + bounds[5]), surface))
        bottom_matches = [
            surface
            for z_value, surface in flat_surfaces
            if abs(z_value - prepared.transition_z) <= _OCC_BOUNDING_TOLERANCE_MM
        ]
        if len(bottom_matches) != 1:
            raise ConstrainedHybridError("OCC upper-UF has no unique docking surface")
        bottom_surface = bottom_matches[0]
        locked_surfaces: dict[str, int] = {"bottom": bottom_surface}
        if prepared.dummy_docking.side_patches:
            die_x_min = envelope.center_x - envelope.half_die_width
            die_x_max = envelope.center_x + envelope.half_die_width
            die_y_min = envelope.center_y - envelope.half_die_length
            die_y_max = envelope.center_y + envelope.half_die_length
            plane_by_name = {
                "x_min": (0, die_x_min),
                "x_max": (0, die_x_max),
                "y_min": (1, die_y_min),
                "y_max": (1, die_y_max),
            }
            for patch in prepared.dummy_docking.side_patches:
                axis, plane = plane_by_name[patch.name]
                matches: list[int] = []
                for surface in surfaces:
                    if surface == bottom_surface:
                        continue
                    bounds = gmsh.model.getBoundingBox(2, surface)
                    lower = bounds[axis]
                    upper = bounds[axis + 3]
                    if (
                        abs(upper - lower) <= _OCC_BOUNDING_TOLERANCE_MM
                        and abs(0.5 * (lower + upper) - plane)
                        <= _OCC_BOUNDING_TOLERANCE_MM
                        and bounds[2]
                        <= prepared.transition_z + _OCC_BOUNDING_TOLERANCE_MM
                        and bounds[5]
                        >= prepared.cap_z - _OCC_BOUNDING_TOLERANCE_MM
                    ):
                        matches.append(surface)
                if len(matches) != 1:
                    raise ConstrainedHybridError(
                        f"OCC upper-UF has no unique locked die wall {patch.name}"
                    )
                locked_surfaces[patch.name] = matches[0]
            if len(set(locked_surfaces.values())) != len(locked_surfaces):
                raise ConstrainedHybridError(
                    "OCC upper-UF locked surfaces do not have distinct entities"
                )
            _add_exact_locked_curves(
                gmsh,
                prepared.dummy_docking,
                locked_surfaces,
            )
        else:
            _add_exact_bottom_curves(gmsh, prepared, bottom_surface)
        field = gmsh.model.mesh.field.add("MathEval")
        gmsh.model.mesh.field.setString(
            field,
            "F",
            f"Min({maximum_size:.17g},{near_size:.17g}+"
            f"{slope:.17g}*Abs(z-({prepared.transition_z:.17g})))",
        )
        gmsh.model.mesh.field.setAsBackgroundMesh(field)
        gmsh.model.mesh.generate(2)
        if prepared.dummy_docking.side_patches:
            _replace_locked_surfaces(
                gmsh,
                prepared.dummy_docking,
                locked_surfaces,
                outward_by_group={
                    "bottom": (0.0, 0.0, -1.0),
                    "x_min": (1.0, 0.0, 0.0),
                    "x_max": (-1.0, 0.0, 0.0),
                    "y_min": (0.0, 1.0, 0.0),
                    "y_max": (0.0, -1.0, 0.0),
                },
            )
        else:
            _replace_locked_surfaces(
                gmsh,
                prepared.dummy_docking,
                {"bottom": bottom_surface},
            )
        try:
            gmsh.model.mesh.generate(3)
        except Exception as error:
            raise ConstrainedHybridError(
                "Gmsh could not fill the tapered upper-UF volume"
            ) from error
        for _iteration in range(optimization_rounds):
            gmsh.model.mesh.optimize(
                "Relocate3D", force=True, niter=3, dimTags=[(3, volume_tag)]
            )
            gmsh.model.mesh.optimize(
                "", force=True, niter=50, dimTags=[(3, volume_tag)]
            )
        return _extract_candidate(gmsh, volume_tag, seed), cad_volume


def _mesh_discrete_candidate(
    gmsh: Any,
    prepared: _PreparedUf,
    *,
    maximum_size: float,
    near_size: float,
    transition_distance: float,
    optimization_rounds: int,
    seed: int,
    verbose: bool,
) -> tuple[Any, float]:
    """Fill a pre-triangulated coarsening shell as one discrete volume."""

    shell = _build_discrete_shell(
        prepared,
        top_target_size=maximum_size,
    )
    slope = max(0.0, (maximum_size - near_size) / transition_distance)
    options = {
        "General.Terminal": 1.0 if verbose else 0.0,
        "Mesh.ElementOrder": 1.0,
        "Mesh.Algorithm3D": 1.0,
        "Mesh.MeshOnlyEmpty": 1.0,
        "Mesh.MeshSizeMin": near_size,
        "Mesh.MeshSizeMax": maximum_size,
        "Mesh.MeshSizeExtendFromBoundary": 0.0,
        "Mesh.MeshSizeFromCurvature": 0.0,
        "Mesh.MeshSizeFromPoints": 0.0,
        "Mesh.Optimize": 1.0 if optimization_rounds else 0.0,
        "Mesh.OptimizePyramids": 1.0,
        "Mesh.RandomSeed": float(seed),
    }
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_discrete_uf_upper_hybrid",
        number_options=options,
    ):
        surface = int(gmsh.model.addDiscreteEntity(2))
        node_tags = sorted(shell.coordinates)
        gmsh.model.mesh.addNodes(
            2,
            surface,
            node_tags,
            [value for tag in node_tags for value in shell.coordinates[tag]],
        )
        next_element = 1
        if shell.triangles:
            tags = list(range(next_element, next_element + len(shell.triangles)))
            next_element += len(tags)
            gmsh.model.mesh.addElementsByType(
                surface,
                2,
                tags,
                [node for facet in shell.triangles for node in facet],
            )
        if shell.bottom_quads:
            tags = list(range(next_element, next_element + len(shell.bottom_quads)))
            gmsh.model.mesh.addElementsByType(
                surface,
                3,
                tags,
                [node for facet in shell.bottom_quads for node in facet],
            )
        if shell.side_quads:
            tags = list(range(next_element, next_element + len(shell.side_quads)))
            gmsh.model.mesh.addElementsByType(
                surface,
                3,
                tags,
                [node for facet in shell.side_quads for node in facet],
            )
        gmsh.model.mesh.reclassifyNodes()
        volume_tag = int(gmsh.model.addDiscreteEntity(3, boundary=[surface]))
        gmsh.model.mesh.createGeometry([(3, volume_tag)])
        if prepared.locked_side_facets:
            # Discrete-entity node tags are not 0-D Gmsh point entities, so a
            # Distance/NodesList field emits ``Unknown point`` and silently
            # loses the intended trace control.  Evaluate distance to the
            # locked base plane or die rectangle analytically instead.
            x_min = prepared.envelope.center_x - prepared.envelope.half_die_width
            x_max = prepared.envelope.center_x + prepared.envelope.half_die_width
            y_min = prepared.envelope.center_y - prepared.envelope.half_die_length
            y_max = prepared.envelope.center_y + prepared.envelope.half_die_length
            dx = (
                f"Max(0,Max(({x_min:.17g})-x,x-({x_max:.17g})))"
            )
            dy = (
                f"Max(0,Max(({y_min:.17g})-y,y-({y_max:.17g})))"
            )
            distance = (
                f"Min(Abs(z-({prepared.transition_z:.17g})),"
                f"Sqrt(({dx})^2+({dy})^2))"
            )
            field = gmsh.model.mesh.field.add("MathEval")
            gmsh.model.mesh.field.setString(
                field,
                "F",
                f"Min({maximum_size:.17g},{near_size:.17g}+"
                f"{slope:.17g}*({distance}))",
            )
        else:
            field = gmsh.model.mesh.field.add("MathEval")
            gmsh.model.mesh.field.setString(
                field,
                "F",
                f"Min({maximum_size:.17g},{near_size:.17g}+"
                f"{slope:.17g}*Abs(z-({prepared.transition_z:.17g})))",
            )
        gmsh.model.mesh.field.setAsBackgroundMesh(field)
        try:
            gmsh.model.mesh.generate(3)
        except Exception as error:
            raise ConstrainedHybridError(
                "Gmsh could not fill the discrete upper-UF shell"
            ) from error
        for _iteration in range(optimization_rounds):
            gmsh.model.mesh.optimize(
                "Relocate3D", force=True, niter=3, dimTags=[(3, volume_tag)]
            )
            gmsh.model.mesh.optimize(
                "", force=True, niter=50, dimTags=[(3, volume_tag)]
            )
        return _extract_candidate(gmsh, volume_tag, seed), shell.volume_mm3


def _mesh_explicit_trace_collar_candidate(
    gmsh: Any,
    prepared: _PreparedUf,
    *,
    maximum_size: float,
    near_size: float,
    transition_distance: float,
    optimization_rounds: int,
    seed: int,
    verbose: bool,
) -> tuple[Any, float, _ExplicitTraceCollar]:
    """Tetrahedralize only the TRI remainder, then append explicit PYRs.

    This intentionally presents no QUAD surface to Gmsh's 3-D generator, so
    it cannot synthesize a topology-dependent or zero-height pyramid.  Once
    the all-TET fill is complete, the already-audited collar elements are
    attached to the same volume entity and extracted as one candidate.  The
    ordinary finalizer then checks quality and face ownership across the
    complete TET/PYR complex.
    """

    collar = _build_explicit_trace_collar(
        prepared,
        top_target_size=maximum_size,
    )
    slope = max(0.0, (maximum_size - near_size) / transition_distance)
    options = {
        "General.Terminal": 1.0 if verbose else 0.0,
        "Mesh.ElementOrder": 1.0,
        "Mesh.Algorithm3D": 1.0,
        "Mesh.MeshOnlyEmpty": 1.0,
        "Mesh.MeshSizeMin": near_size,
        "Mesh.MeshSizeMax": maximum_size,
        "Mesh.MeshSizeExtendFromBoundary": 0.0,
        "Mesh.MeshSizeFromCurvature": 0.0,
        "Mesh.MeshSizeFromPoints": 0.0,
        "Mesh.Optimize": 1.0 if optimization_rounds else 0.0,
        "Mesh.RandomSeed": float(seed),
    }
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_explicit_uf_trace_collar",
        number_options=options,
    ):
        surface = int(gmsh.model.addDiscreteEntity(2))
        node_tags = sorted(collar.coordinates)
        gmsh.model.mesh.addNodes(
            2,
            surface,
            node_tags,
            [value for tag in node_tags for value in collar.coordinates[tag]],
        )
        gmsh.model.mesh.addElementsByType(
            surface,
            2,
            list(range(1, len(collar.triangles) + 1)),
            [node for facet in collar.triangles for node in facet],
        )
        gmsh.model.mesh.reclassifyNodes()
        volume_tag = int(gmsh.model.addDiscreteEntity(3, boundary=[surface]))
        gmsh.model.mesh.createGeometry([(3, volume_tag)])

        x_min = prepared.envelope.center_x - prepared.envelope.half_die_width
        x_max = prepared.envelope.center_x + prepared.envelope.half_die_width
        y_min = prepared.envelope.center_y - prepared.envelope.half_die_length
        y_max = prepared.envelope.center_y + prepared.envelope.half_die_length
        dx = f"Max(0,Max(({x_min:.17g})-x,x-({x_max:.17g})))"
        dy = f"Max(0,Max(({y_min:.17g})-y,y-({y_max:.17g})))"
        distance = (
            f"Min(Abs(z-({prepared.transition_z:.17g})),"
            f"Sqrt(({dx})^2+({dy})^2))"
        )
        field = gmsh.model.mesh.field.add("MathEval")
        gmsh.model.mesh.field.setString(
            field,
            "F",
            f"Min({maximum_size:.17g},{near_size:.17g}+"
            f"{slope:.17g}*({distance}))",
        )
        gmsh.model.mesh.field.setAsBackgroundMesh(field)
        try:
            gmsh.model.mesh.generate(3)
        except Exception as error:
            raise ConstrainedHybridError(
                "Gmsh could not fill the explicit-collar TRI remainder"
            ) from error
        for _iteration in range(optimization_rounds):
            gmsh.model.mesh.optimize(
                "Relocate3D", force=True, niter=3, dimTags=[(3, volume_tag)]
            )
            gmsh.model.mesh.optimize(
                "", force=True, niter=50, dimTags=[(3, volume_tag)]
            )
        first_tag = int(gmsh.model.mesh.getMaxElementTag()) + 1
        pyramid_tags = list(
            range(first_tag, first_tag + len(collar.pyramids))
        )
        gmsh.model.mesh.addElementsByType(
            volume_tag,
            _PYRAMID5,
            pyramid_tags,
            [node for element in collar.pyramids for node in element.node_ids],
        )
        return (
            _extract_candidate(gmsh, volume_tag, seed),
            collar.full_volume_mm3,
            collar,
        )


def _mesh_tet_remainder_candidate(
    gmsh: Any,
    prepared: _PreparedTetRemainder,
    *,
    maximum_size: float,
    near_size: float,
    transition_distance: float,
    optimization_rounds: int,
    seed: int,
    verbose: bool,
) -> tuple[Any, _TetShell]:
    """Fill the post-adapter annulus with TET4 only."""

    shell = _build_tet_remainder_shell(
        prepared,
        top_target_size=maximum_size,
    )
    slope = max(0.0, (maximum_size - near_size) / transition_distance)
    options = {
        "General.Terminal": 1.0 if verbose else 0.0,
        "Mesh.ElementOrder": 1.0,
        # Delaunay is deterministic on this small all-TRI shell and, unlike
        # the large one-shot hybrid, does not need to invent any pyramids.
        "Mesh.Algorithm3D": 1.0,
        "Mesh.MeshOnlyEmpty": 1.0,
        "Mesh.MeshSizeMin": near_size,
        "Mesh.MeshSizeMax": maximum_size,
        "Mesh.MeshSizeExtendFromBoundary": 0.0,
        "Mesh.MeshSizeFromCurvature": 0.0,
        "Mesh.MeshSizeFromPoints": 0.0,
        "Mesh.Optimize": 1.0 if optimization_rounds else 0.0,
        "Mesh.RandomSeed": float(seed),
    }
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_discrete_uf_tet_remainder",
        number_options=options,
    ):
        surface = int(gmsh.model.addDiscreteEntity(2))
        node_tags = sorted(shell.coordinates)
        gmsh.model.mesh.addNodes(
            2,
            surface,
            node_tags,
            [value for tag in node_tags for value in shell.coordinates[tag]],
        )
        gmsh.model.mesh.addElementsByType(
            surface,
            2,
            list(range(1, len(shell.triangles) + 1)),
            [node for facet in shell.triangles for node in facet],
        )
        gmsh.model.mesh.reclassifyNodes()
        volume_tag = int(gmsh.model.addDiscreteEntity(3, boundary=[surface]))
        gmsh.model.mesh.createGeometry([(3, volume_tag)])
        field = gmsh.model.mesh.field.add("MathEval")
        gmsh.model.mesh.field.setString(
            field,
            "F",
            f"Min({maximum_size:.17g},{near_size:.17g}+"
            f"{slope:.17g}*Abs(z-({prepared.transition_z:.17g})))",
        )
        gmsh.model.mesh.field.setAsBackgroundMesh(field)
        try:
            gmsh.model.mesh.generate(3)
        except Exception as error:
            raise ConstrainedHybridError(
                "Gmsh could not fill the upper-UF TET remainder"
            ) from error
        # Mesh.Optimize runs the standard tetrahedral flips during generation.
        # A final relocation is safe here because the complete discrete shell
        # is classified on the 2-D entity and is audited bit-for-bit below.
        for _iteration in range(optimization_rounds):
            gmsh.model.mesh.optimize(
                "Relocate3D", force=True, niter=3, dimTags=[(3, volume_tag)]
            )
        return _extract_candidate(gmsh, volume_tag, seed), shell


def _on_die_wall(
    facet: Sequence[int],
    coordinates: Mapping[int, Point3D],
    envelope: RectangularUfEnvelope,
) -> bool:
    points = tuple(coordinates[node] for node in facet)
    x_min = envelope.center_x - envelope.half_die_width
    x_max = envelope.center_x + envelope.half_die_width
    y_min = envelope.center_y - envelope.half_die_length
    y_max = envelope.center_y + envelope.half_die_length
    on_x = (
        all(abs(point[0] - x_min) <= _COORDINATE_TOLERANCE_MM for point in points)
        or all(abs(point[0] - x_max) <= _COORDINATE_TOLERANCE_MM for point in points)
    ) and all(
        y_min - _COORDINATE_TOLERANCE_MM <= point[1] <= y_max + _COORDINATE_TOLERANCE_MM
        for point in points
    )
    on_y = (
        all(abs(point[1] - y_min) <= _COORDINATE_TOLERANCE_MM for point in points)
        or all(abs(point[1] - y_max) <= _COORDINATE_TOLERANCE_MM for point in points)
    ) and all(
        x_min - _COORDINATE_TOLERANCE_MM <= point[0] <= x_max + _COORDINATE_TOLERANCE_MM
        for point in points
    )
    return on_x or on_y


def _finalize_candidate(
    candidate: Any,
    prepared: _PreparedUf,
    cad_volume: float,
    *,
    minimum_quality: float,
    allow_sparse_growth: bool = False,
    expected_exterior: _ExplicitTraceCollar | None = None,
) -> ConstrainedUfHybridVolume:
    if candidate.duplicate_node_count:
        raise ConstrainedHybridError("Gmsh produced duplicate upper-UF nodes")
    if any(
        len(point) != 3 or any(not math.isfinite(value) for value in point)
        for point in candidate.coordinates.values()
    ):
        raise ConstrainedHybridError(
            "upper-UF hybrid contains a non-finite node coordinate"
        )
    if any(not math.isfinite(value) or value <= 0.0 for value in candidate.determinants):
        bad = tuple(
            index
            for index, value in enumerate(candidate.determinants)
            if not math.isfinite(value) or value <= 0.0
        )
        kinds = Counter(candidate.elements[index][0] for index in bad)
        first = min(
            bad,
            key=lambda index: (
                candidate.determinants[index],
                candidate.elements[index][1],
            ),
        )
        kind, element_tag, nodes = candidate.elements[first]
        point_text = tuple(
            tuple(round(value, 12) for value in candidate.coordinates[node])
            for node in nodes
        )
        raise ConstrainedHybridError(
            "upper-UF hybrid contains non-positive elements: "
            f"count={len(bad)}, kinds={dict(sorted(kinds.items()))}, "
            f"worst=(gmsh_type={kind}, tag={element_tag}, "
            f"minDetJac={candidate.determinants[first]:.8g}, nodes={point_text})"
        )
    quality_values = (*candidate.sicn, *candidate.sige, *candidate.scaled_jacobian)
    if any(not math.isfinite(value) for value in quality_values):
        raise ConstrainedHybridError("upper-UF hybrid contains a non-finite quality")
    minima = (
        min(candidate.sicn),
        min(candidate.sige),
        min(candidate.scaled_jacobian),
    )
    if any(not math.isfinite(value) or value < minimum_quality for value in minima):
        def worst_metric(values: Sequence[float]) -> tuple[object, ...]:
            index = min(range(len(values)), key=values.__getitem__)
            kind, tag, nodes = candidate.elements[index]
            return (
                float(values[index]),
                int(kind),
                int(tag),
                tuple(
                    tuple(round(value, 12) for value in candidate.coordinates[node])
                    for node in nodes
                ),
            )

        raise ConstrainedHybridError(
            "upper-UF quality floor was not met: "
            f"minSJ={min(candidate.scaled_jacobian):.8g}, "
            f"minSICN={min(candidate.sicn):.8g}, "
            f"minSIGE={min(candidate.sige):.8g}, required={minimum_quality:.8g}, "
            f"worstSICN={worst_metric(candidate.sicn)}, "
            f"worstSIGE={worst_metric(candidate.sige)}"
        )

    gmsh_by_coordinate: dict[tuple[float, float, float], int] = {}
    for gmsh_tag, point in candidate.coordinates.items():
        key = _coordinate_key(point)
        if key in gmsh_by_coordinate:
            raise ConstrainedHybridError("upper-UF hybrid has coincident nodes")
        gmsh_by_coordinate[key] = gmsh_tag
    gmsh_source_by_tag: dict[int, int] = {}
    for source_id, point in prepared.source_coordinates.items():
        gmsh_tag = gmsh_by_coordinate.get(_coordinate_key(point))
        if gmsh_tag is None or math.dist(candidate.coordinates[gmsh_tag], point) > (
            _COORDINATE_TOLERANCE_MM
        ):
            raise ConstrainedHybridError("Gmsh changed an upper-UF docking node")
        gmsh_source_by_tag[gmsh_tag] = source_id
    interface_tags = {
        tag
        for tag, point in candidate.coordinates.items()
        if abs(point[2] - prepared.transition_z) <= _COORDINATE_TOLERANCE_MM
    }
    expected_interface_tags = {
        gmsh_tag
        for gmsh_tag, source_id in gmsh_source_by_tag.items()
        if abs(
            prepared.source_coordinates[source_id][2] - prepared.transition_z
        )
        <= _COORDINATE_TOLERANCE_MM
    }
    if interface_tags != expected_interface_tags:
        raise ConstrainedHybridError("Gmsh changed the upper-UF docking node set")

    sorted_gmsh = tuple(
        sorted(candidate.coordinates, key=lambda tag: (_coordinate_key(candidate.coordinates[tag]), tag))
    )
    local_by_gmsh = {tag: index for index, tag in enumerate(sorted_gmsh, start=1)}
    coordinates = {
        local_by_gmsh[tag]: candidate.coordinates[tag] for tag in sorted_gmsh
    }
    source_by_local = {
        local_by_gmsh[gmsh_tag]: source_id
        for gmsh_tag, source_id in gmsh_source_by_tag.items()
    }
    elements = tuple(
        sorted(
            (
                HybridVolumeElement(
                    gmsh_type,
                    tuple(local_by_gmsh[node] for node in nodes),
                )
                for gmsh_type, _tag, nodes in candidate.elements
            ),
            key=lambda element: (
                element.gmsh_type,
                tuple(sorted(element.node_ids)),
                element.node_ids,
            ),
        )
    )
    duplicate_elements = len(elements) - len(
        {(element.gmsh_type, _face_key(element.node_ids)) for element in elements}
    )
    if duplicate_elements:
        raise ConstrainedHybridError("Gmsh produced duplicate upper-UF elements")
    owners: dict[FaceKey, list[tuple[int, int, tuple[int, ...]]]] = defaultdict(list)
    for element_index, element in enumerate(elements):
        for face_index, local_face in enumerate(ELEMENT_SPECS[element.gmsh_type][2]):
            cycle = tuple(element.node_ids[index] for index in local_face)
            owners[_face_key(cycle)].append((element_index, face_index, cycle))
    if any(len(face_owners) not in {1, 2} for face_owners in owners.values()):
        raise ConstrainedHybridError("upper-UF hybrid contains a non-manifold face")

    local_by_source = {source: local for local, source in source_by_local.items()}
    bottom_keys: set[FaceKey] = set()
    for facet in prepared.source_facets:
        key = _face_key(tuple(local_by_source[node] for node in facet))
        bottom_keys.add(key)
        face_owners = owners.get(key, ())
        if len(face_owners) != 1:
            raise ConstrainedHybridError("locked upper-UF QUAD does not have one owner")
        element_index, face_index, _cycle = face_owners[0]
        if elements[element_index].gmsh_type != _PYRAMID5 or face_index != 0:
            raise ConstrainedHybridError(
                "locked upper-UF QUAD is not one complete PYRAMID5 base"
            )
    side_keys: set[FaceKey] = set()
    for facet in prepared.locked_side_facets:
        key = _face_key(tuple(local_by_source[node] for node in facet))
        side_keys.add(key)
        face_owners = owners.get(key, ())
        if len(face_owners) != 1:
            raise ConstrainedHybridError(
                "locked upper-UF side facet does not have one owner"
            )
        element_index, face_index, _cycle = face_owners[0]
        owner = elements[element_index]
        if len(facet) == 3:
            if owner.gmsh_type != _TET4:
                raise ConstrainedHybridError(
                    "locked upper-UF side TRI3 is not owned by one TET4"
                )
        elif owner.gmsh_type != _PYRAMID5 or face_index != 0:
            raise ConstrainedHybridError(
                "locked upper-UF side QUAD4 is not one complete PYRAMID5 base"
            )
    if len(side_keys) != len(prepared.locked_side_facets):
        raise ConstrainedHybridError("locked upper-UF side facets overlap")
    boundary = {
        key: face_owners[0][2]
        for key, face_owners in owners.items()
        if len(face_owners) == 1
    }
    if expected_exterior is not None:
        expected_boundary: set[FaceKey] = set()
        for facet in expected_exterior.exterior_facets:
            mapped: list[int] = []
            for node in facet:
                point = expected_exterior.coordinates[node]
                gmsh_tag = gmsh_by_coordinate.get(_coordinate_key(point))
                if gmsh_tag is None or math.dist(
                    candidate.coordinates[gmsh_tag], point
                ) > _COORDINATE_TOLERANCE_MM:
                    raise ConstrainedHybridError(
                        "Gmsh changed an explicit trace-collar exterior node"
                    )
                mapped.append(local_by_gmsh[gmsh_tag])
            expected_boundary.add(_face_key(mapped))
        if len(expected_boundary) != len(expected_exterior.exterior_facets):
            raise ConstrainedHybridError(
                "explicit trace-collar exterior facets overlap"
            )
        if set(boundary) != expected_boundary:
            unexpected = set(boundary) - expected_boundary
            missing = expected_boundary - set(boundary)
            raise ConstrainedHybridError(
                "explicit trace collar/TET remainder leaves a crack or changes "
                "the exterior face set: "
                f"unexpected={len(unexpected)}, missing={len(missing)}"
            )
    interface_boundary = {
        key
        for key in boundary
        if all(
            abs(coordinates[node][2] - prepared.transition_z)
            <= _COORDINATE_TOLERANCE_MM
            for node in key
        )
    }
    if interface_boundary != bottom_keys:
        raise ConstrainedHybridError("Gmsh changed the upper-UF docking facets")
    top_keys = {
        key
        for key in boundary
        if all(
            abs(coordinates[node][2] - prepared.cap_z)
            <= _COORDINATE_TOLERANCE_MM
            for node in key
        )
    }
    die_keys = {
        key
        for key, cycle in boundary.items()
        if key not in bottom_keys
        and key not in top_keys
        and _on_die_wall(cycle, coordinates, prepared.envelope)
    }
    if side_keys and die_keys != side_keys:
        raise ConstrainedHybridError(
            "Gmsh changed the locked upper-UF die-wall facet set"
        )
    free_keys = set(boundary) - bottom_keys - top_keys - die_keys
    if not top_keys or not die_keys or not free_keys:
        raise ConstrainedHybridError("upper-UF boundary classification is incomplete")
    for key in set(boundary) - bottom_keys:
        for node in key:
            x, y, z = coordinates[node]
            if z < prepared.transition_z - _COORDINATE_TOLERANCE_MM or z > (
                prepared.cap_z + _COORDINATE_TOLERANCE_MM
            ):
                raise ConstrainedHybridError("upper-UF boundary escapes its Z range")
            if not _envelope_contains_with_tolerance(
                prepared.envelope,
                (x, y, min(z, prepared.envelope.top_height(x, y))),
            ):
                raise ConstrainedHybridError("upper-UF boundary escapes the fillet footprint")

    element_volume = math.fsum(
        _element_volume(element, coordinates) for element in elements
    )
    relative_volume_error = abs(element_volume - cad_volume) / cad_volume
    if relative_volume_error > 1.0e-6:
        raise ConstrainedHybridError(
            f"upper-UF mesh/CAD volume mismatch is {relative_volume_error:.3g}"
        )
    near_edge, far_edge = _edge_growth(
        coordinates, elements, prepared.transition_z, prepared.cap_z
    )
    try:
        growth = _directional_growth(
            coordinates, elements, prepared.transition_z, prepared.cap_z
        )
    except ConstrainedHybridError as error:
        if not allow_sparse_growth or "empty XYZ growth bands" not in str(error):
            raise
        growth = MappingProxyType({})
    ordered_cycles = lambda keys: tuple(
        boundary[key] for key in sorted(keys)
    )
    top_cap_facets = ordered_cycles(top_keys)
    adapter_bottom_median_edge = _facet_median_edge_length(
        prepared.source_facets,
        prepared.source_coordinates,
    )
    adapter_top_median_edge = _facet_median_edge_length(
        top_cap_facets,
        coordinates,
    )
    return ConstrainedUfHybridVolume(
        node_coordinates=MappingProxyType(coordinates),
        source_node_id_by_local_id=MappingProxyType(source_by_local),
        elements=elements,
        die_wall_facets=ordered_cycles(die_keys),
        free_surface_facets=ordered_cycles(free_keys),
        top_cap_facets=top_cap_facets,
        locked_bottom_face_count=len(bottom_keys),
        bottom_quad_pyramid_base_count=len(bottom_keys),
        tet4_count=sum(element.gmsh_type == _TET4 for element in elements),
        pyramid5_count=sum(element.gmsh_type == _PYRAMID5 for element in elements),
        near_median_edge_mm=near_edge,
        far_median_edge_mm=far_edge,
        minimum_sicn=min(candidate.sicn),
        minimum_sige=min(candidate.sige),
        minimum_scaled_jacobian=min(candidate.scaled_jacobian),
        minimum_determinant=min(candidate.determinants),
        duplicate_node_count=candidate.duplicate_node_count,
        duplicate_element_count=duplicate_elements,
        growth_by_axis=growth,
        cad_volume_mm3=cad_volume,
        element_volume_mm3=element_volume,
        relative_volume_error=relative_volume_error,
        bottom_base_aspect_median=float(median(prepared.bottom_aspects)),
        bottom_base_aspect_p90=_percentile90(prepared.bottom_aspects),
        bottom_base_aspect_maximum=max(prepared.bottom_aspects),
        transition_z_mm=prepared.transition_z,
        cap_z_mm=prepared.cap_z,
        random_seed=candidate.seed,
        adapter_cap_z_mm=prepared.cap_z,
        adapter_top_face_count=len(top_keys),
        remainder_tet4_count=(
            sum(element.gmsh_type == _TET4 for element in elements)
            if prepared.locked_side_facets else 0
        ),
        adapter_bottom_median_edge_mm=adapter_bottom_median_edge,
        adapter_top_median_edge_mm=adapter_top_median_edge,
        locked_side_face_count=len(side_keys),
        locked_side_triangle_count=sum(
            len(facet) == 3 for facet in prepared.locked_side_facets
        ),
        locked_side_quad_count=sum(
            len(facet) == 4 for facet in prepared.locked_side_facets
        ),
    )


def _finalize_tet_remainder(
    candidate: Any,
    prepared: _PreparedTetRemainder,
    shell: _TetShell,
    *,
    minimum_quality: float,
) -> _TetRemainderVolume:
    if candidate.duplicate_node_count:
        raise ConstrainedHybridError(
            "Gmsh produced duplicate upper-UF TET remainder nodes"
        )
    if not candidate.elements or any(kind != _TET4 for kind, _tag, _nodes in candidate.elements):
        raise ConstrainedHybridError("upper-UF remainder must contain only TET4")
    if any(not math.isfinite(value) or value <= 0.0 for value in candidate.determinants):
        raise ConstrainedHybridError(
            "upper-UF TET remainder contains a non-positive element"
        )
    quality_values = (*candidate.sicn, *candidate.sige, *candidate.scaled_jacobian)
    if any(not math.isfinite(value) for value in quality_values):
        raise ConstrainedHybridError(
            "upper-UF TET remainder contains a non-finite quality"
        )
    minima = (
        min(candidate.sicn),
        min(candidate.sige),
        min(candidate.scaled_jacobian),
    )
    if any(not math.isfinite(value) or value < minimum_quality for value in minima):
        raise ConstrainedHybridError(
            "upper-UF TET remainder quality floor was not met: "
            f"minSJ={min(candidate.scaled_jacobian):.8g}, "
            f"minSICN={min(candidate.sicn):.8g}, "
            f"minSIGE={min(candidate.sige):.8g}, required={minimum_quality:.8g}"
        )
    gmsh_by_coordinate: dict[tuple[float, float, float], int] = {}
    for gmsh_tag, point in candidate.coordinates.items():
        key = _coordinate_key(point)
        if key in gmsh_by_coordinate:
            raise ConstrainedHybridError(
                "upper-UF TET remainder has coincident nodes"
            )
        gmsh_by_coordinate[key] = gmsh_tag
    gmsh_source_by_tag: dict[int, int] = {}
    for source_id, point in prepared.source_coordinates.items():
        gmsh_tag = gmsh_by_coordinate.get(_coordinate_key(point))
        if gmsh_tag is None or math.dist(candidate.coordinates[gmsh_tag], point) > (
            _COORDINATE_TOLERANCE_MM
        ):
            raise ConstrainedHybridError(
                "Gmsh changed an upper-UF TET docking node"
            )
        gmsh_source_by_tag[gmsh_tag] = source_id
    interface_tags = {
        tag
        for tag, point in candidate.coordinates.items()
        if abs(point[2] - prepared.transition_z) <= _COORDINATE_TOLERANCE_MM
    }
    if interface_tags != set(gmsh_source_by_tag):
        raise ConstrainedHybridError(
            "Gmsh changed the upper-UF TET docking node set"
        )

    sorted_gmsh = tuple(
        sorted(
            candidate.coordinates,
            key=lambda tag: (_coordinate_key(candidate.coordinates[tag]), tag),
        )
    )
    local_by_gmsh = {tag: index for index, tag in enumerate(sorted_gmsh, start=1)}
    coordinates = {
        local_by_gmsh[tag]: candidate.coordinates[tag] for tag in sorted_gmsh
    }
    source_by_local = {
        local_by_gmsh[gmsh_tag]: source_id
        for gmsh_tag, source_id in gmsh_source_by_tag.items()
    }
    elements = tuple(
        sorted(
            (
                HybridVolumeElement(
                    gmsh_type,
                    tuple(local_by_gmsh[node] for node in nodes),
                )
                for gmsh_type, _tag, nodes in candidate.elements
            ),
            key=lambda element: (
                tuple(sorted(element.node_ids)),
                element.node_ids,
            ),
        )
    )
    duplicate_elements = len(elements) - len(
        {(element.gmsh_type, tuple(sorted(element.node_ids))) for element in elements}
    )
    if duplicate_elements:
        raise ConstrainedHybridError(
            "Gmsh produced duplicate upper-UF TET remainder elements"
        )
    owners: dict[FaceKey, list[tuple[int, int, tuple[int, ...]]]] = defaultdict(list)
    for element_index, element in enumerate(elements):
        for face_index, local_face in enumerate(ELEMENT_SPECS[element.gmsh_type][2]):
            cycle = tuple(element.node_ids[index] for index in local_face)
            owners[_face_key(cycle)].append((element_index, face_index, cycle))
    if any(len(face_owners) not in {1, 2} for face_owners in owners.values()):
        raise ConstrainedHybridError(
            "upper-UF TET remainder contains a non-manifold face"
        )
    local_by_source = {source: local for local, source in source_by_local.items()}
    bottom_keys = {
        _face_key(tuple(local_by_source[node] for node in facet))
        for facet in prepared.source_facets
    }
    boundary = {
        key: face_owners[0][2]
        for key, face_owners in owners.items()
        if len(face_owners) == 1
    }
    interface_boundary = {
        key
        for key in boundary
        if all(
            abs(coordinates[node][2] - prepared.transition_z)
            <= _COORDINATE_TOLERANCE_MM
            for node in key
        )
    }
    if interface_boundary != bottom_keys:
        raise ConstrainedHybridError(
            "Gmsh changed the upper-UF TET docking facets"
        )
    for key in bottom_keys:
        face_owners = owners.get(key, ())
        if len(face_owners) != 1 or elements[face_owners[0][0]].gmsh_type != _TET4:
            raise ConstrainedHybridError(
                "upper-UF TET docking TRI does not have one TET4 owner"
            )
    top_keys = {
        key
        for key in boundary
        if all(
            abs(coordinates[node][2] - prepared.cap_z)
            <= _COORDINATE_TOLERANCE_MM
            for node in key
        )
    }
    die_keys = {
        key
        for key, cycle in boundary.items()
        if key not in bottom_keys
        and key not in top_keys
        and _on_die_wall(cycle, coordinates, prepared.envelope)
    }
    free_keys = set(boundary) - bottom_keys - top_keys - die_keys
    if not top_keys or not die_keys or not free_keys:
        raise ConstrainedHybridError(
            "upper-UF TET boundary classification is incomplete"
        )
    shell_local_by_candidate: dict[int, int] = {}
    for shell_node, point in shell.coordinates.items():
        gmsh_tag = gmsh_by_coordinate.get(_coordinate_key(point))
        if gmsh_tag is None:
            raise ConstrainedHybridError(
                "Gmsh changed an upper-UF TET shell node"
            )
        shell_local_by_candidate[shell_node] = local_by_gmsh[gmsh_tag]
    expected_boundary = {
        _face_key(tuple(shell_local_by_candidate[node] for node in facet))
        for facet in shell.triangles
    }
    if set(boundary) != expected_boundary:
        raise ConstrainedHybridError(
            "Gmsh changed the upper-UF TET boundary facets"
        )
    element_volume = math.fsum(
        _element_volume(element, coordinates) for element in elements
    )
    relative_volume_error = abs(element_volume - shell.volume_mm3) / shell.volume_mm3
    if relative_volume_error > 1.0e-6:
        raise ConstrainedHybridError(
            f"upper-UF TET mesh/shell volume mismatch is {relative_volume_error:.3g}"
        )
    near_edge, far_edge = _edge_growth(
        coordinates, elements, prepared.transition_z, prepared.cap_z
    )
    try:
        growth = _directional_growth(
            coordinates, elements, prepared.transition_z, prepared.cap_z
        )
    except ConstrainedHybridError as error:
        # A deliberately coarse continuation can contain only one element row
        # in one direction. Its topology and quality are still fully audited;
        # the caller recomputes XYZ growth on the combined adapter+remainder.
        if "empty XYZ growth bands" not in str(error):
            raise
        growth = MappingProxyType({})
    ordered_cycles = lambda keys: tuple(boundary[key] for key in sorted(keys))
    return _TetRemainderVolume(
        node_coordinates=MappingProxyType(coordinates),
        source_node_id_by_local_id=MappingProxyType(source_by_local),
        elements=elements,
        die_wall_facets=ordered_cycles(die_keys),
        free_surface_facets=ordered_cycles(free_keys),
        top_cap_facets=ordered_cycles(top_keys),
        locked_bottom_facets=ordered_cycles(bottom_keys),
        near_median_edge_mm=near_edge,
        far_median_edge_mm=far_edge,
        minimum_sicn=min(candidate.sicn),
        minimum_sige=min(candidate.sige),
        minimum_scaled_jacobian=min(candidate.scaled_jacobian),
        minimum_determinant=min(candidate.determinants),
        duplicate_node_count=candidate.duplicate_node_count,
        duplicate_element_count=duplicate_elements,
        growth_by_axis=growth,
        cad_volume_mm3=shell.volume_mm3,
        element_volume_mm3=element_volume,
        relative_volume_error=relative_volume_error,
        transition_z_mm=prepared.transition_z,
        cap_z_mm=prepared.cap_z,
        random_seed=candidate.seed,
    )


def _generate_locked_uf_conversion_stage(
    docking_node_coordinates: Mapping[int, Sequence[float]],
    docking_facets: Sequence[Sequence[int]],
    envelope: RectangularUfEnvelope,
    transition_z_mm: float,
    cap_z_mm: float,
    *,
    maximum_size_mm: float,
    near_size_mm: float,
    transition_distance_mm: float | None = None,
    minimum_quality: float = 0.03,
    random_seeds: Sequence[int] = (1, 2, 3),
    optimization_rounds: int = 2,
    verbose: bool = False,
) -> ConstrainedUfHybridVolume:
    """Generate the one-time QUAD-to-PYR/TET conversion stage."""

    prepared = _prepare_inputs(
        docking_node_coordinates,
        docking_facets,
        envelope,
        transition_z_mm,
        cap_z_mm,
    )
    maximum_size = _finite(maximum_size_mm, name="upper-UF maximum size")
    near_size = _finite(near_size_mm, name="upper-UF near size")
    transition_distance = (
        prepared.cap_z - prepared.transition_z
        if transition_distance_mm is None
        else _finite(transition_distance_mm, name="upper-UF transition distance")
    )
    quality_floor = _finite(minimum_quality, name="upper-UF minimum quality")
    if (
        maximum_size <= 0.0
        or near_size <= 0.0
        or maximum_size < near_size
        or transition_distance <= 0.0
        or quality_floor <= 0.0
        or quality_floor >= 1.0
    ):
        raise ConstrainedHybridError("upper-UF sizes or quality floor are invalid")
    try:
        seeds = tuple(random_seeds)
    except TypeError as error:
        raise ConstrainedHybridError("upper-UF seeds must be a sequence") from error
    if not seeds or any(
        isinstance(seed, bool) or not isinstance(seed, int) or seed < 1
        for seed in seeds
    ):
        raise ConstrainedHybridError("upper-UF seeds must be positive integers")
    seeds = tuple(dict.fromkeys(seeds))
    if (
        isinstance(optimization_rounds, bool)
        or not isinstance(optimization_rounds, int)
        or optimization_rounds < 0
        or optimization_rounds > 4
    ):
        raise ConstrainedHybridError("upper-UF optimization rounds must be 0..4")
    gmsh = _load_gmsh()
    failures: list[str] = []
    for seed in seeds:
        try:
            candidate, cad_volume = _mesh_discrete_candidate(
                gmsh,
                prepared,
                maximum_size=maximum_size,
                near_size=near_size,
                transition_distance=transition_distance,
                optimization_rounds=optimization_rounds,
                seed=seed,
                verbose=verbose,
            )
            return _finalize_candidate(
                candidate,
                prepared,
                cad_volume,
                minimum_quality=quality_floor,
            )
        except ConstrainedHybridError as error:
            failures.append(f"seed {seed}: {error}")
        except Exception as error:  # pragma: no cover - Gmsh runtime failure
            failures.append(f"seed {seed}: Gmsh runtime failure: {error}")
    raise ConstrainedHybridError(
        "all OCC upper-UF candidates failed; " + "; ".join(failures)
    )


def _generate_tet_remainder(
    docking_node_coordinates: Mapping[int, Sequence[float]],
    docking_facets: Sequence[Sequence[int]],
    envelope: RectangularUfEnvelope,
    transition_z_mm: float,
    cap_z_mm: float,
    *,
    maximum_size_mm: float,
    near_size_mm: float,
    transition_distance_mm: float,
    minimum_quality: float,
    random_seeds: Sequence[int],
    optimization_rounds: int,
    verbose: bool,
) -> _TetRemainderVolume:
    prepared = _prepare_tet_remainder(
        docking_node_coordinates,
        docking_facets,
        envelope,
        transition_z_mm,
        cap_z_mm,
    )
    gmsh = _load_gmsh()
    failures: list[str] = []
    for seed in random_seeds:
        try:
            candidate, shell = _mesh_tet_remainder_candidate(
                gmsh,
                prepared,
                maximum_size=maximum_size_mm,
                near_size=near_size_mm,
                transition_distance=transition_distance_mm,
                optimization_rounds=optimization_rounds,
                seed=seed,
                verbose=verbose,
            )
            return _finalize_tet_remainder(
                candidate,
                prepared,
                shell,
                minimum_quality=minimum_quality,
            )
        except ConstrainedHybridError as error:
            failures.append(f"seed {seed}: {error}")
        except Exception as error:  # pragma: no cover - Gmsh runtime failure
            failures.append(f"seed {seed}: Gmsh runtime failure: {error}")
    raise ConstrainedHybridError(
        "all upper-UF TET remainder candidates failed; " + "; ".join(failures)
    )


def _combine_upper_uf_stages(
    conversion: ConstrainedUfHybridVolume,
    remainder: _TetRemainderVolume,
) -> ConstrainedUfHybridVolume:
    """Join the exact TRI adapter cap to the all-TET continuation."""

    coordinates: dict[int, Point3D] = dict(conversion.node_coordinates)
    by_coordinate = {
        _coordinate_key(point): node for node, point in coordinates.items()
    }
    local_by_remainder: dict[int, int] = {}
    next_node = max(coordinates, default=0) + 1
    for local_id in sorted(remainder.node_coordinates):
        point = remainder.node_coordinates[local_id]
        conversion_id = remainder.source_node_id_by_local_id.get(local_id)
        if conversion_id is not None:
            expected = coordinates.get(conversion_id)
            if expected is None or math.dist(expected, point) > _COORDINATE_TOLERANCE_MM:
                raise ConstrainedHybridError(
                    "upper-UF stages disagree on an adapter-cap node"
                )
            local_by_remainder[local_id] = conversion_id
            continue
        key = _coordinate_key(point)
        if key in by_coordinate:
            raise ConstrainedHybridError(
                "upper-UF stages contain an undeclared coincident node"
            )
        local_by_remainder[local_id] = next_node
        coordinates[next_node] = point
        by_coordinate[key] = next_node
        next_node += 1

    def mapped_facet(facet: Sequence[int]) -> tuple[int, ...]:
        return tuple(local_by_remainder[node] for node in facet)

    mapped_remainder_elements = tuple(
        HybridVolumeElement(
            element.gmsh_type,
            tuple(local_by_remainder[node] for node in element.node_ids),
        )
        for element in remainder.elements
    )
    elements = tuple((*conversion.elements, *mapped_remainder_elements))
    duplicate_elements = len(elements) - len(
        {(element.gmsh_type, tuple(sorted(element.node_ids))) for element in elements}
    )
    if duplicate_elements:
        raise ConstrainedHybridError("upper-UF stages contain duplicate elements")
    owners: dict[FaceKey, list[tuple[int, ...]]] = defaultdict(list)
    for element in elements:
        for local_face in ELEMENT_SPECS[element.gmsh_type][2]:
            cycle = tuple(element.node_ids[index] for index in local_face)
            owners[_face_key(cycle)].append(cycle)
    if any(len(face_owners) not in {1, 2} for face_owners in owners.values()):
        raise ConstrainedHybridError(
            "combined upper-UF stages contain a non-manifold face"
        )
    conversion_interface = {
        _face_key(facet) for facet in conversion.top_cap_facets
    }
    remainder_interface = {
        _face_key(mapped_facet(facet)) for facet in remainder.locked_bottom_facets
    }
    if conversion_interface != remainder_interface:
        raise ConstrainedHybridError(
            "upper-UF conversion/remainder interfaces do not match"
        )
    if any(len(owners.get(key, ())) != 2 for key in conversion_interface):
        raise ConstrainedHybridError(
            "upper-UF conversion/remainder interface is not internal"
        )
    mapped_die = tuple(mapped_facet(facet) for facet in remainder.die_wall_facets)
    mapped_free = tuple(mapped_facet(facet) for facet in remainder.free_surface_facets)
    mapped_top = tuple(mapped_facet(facet) for facet in remainder.top_cap_facets)
    die_facets = tuple((*conversion.die_wall_facets, *mapped_die))
    free_facets = tuple((*conversion.free_surface_facets, *mapped_free))
    source_by_local = dict(conversion.source_node_id_by_local_id)
    local_by_source = {source: local for local, source in source_by_local.items()}
    # The original locked QUADs plus the two physical walls and final cap must
    # be exactly the skin of the combined two-stage volume.
    prepared_bottom = {
        key
        for key, face_owners in owners.items()
        if len(face_owners) == 1
        and len(key) == 4
        and all(
            abs(coordinates[node][2] - conversion.transition_z_mm)
            <= _COORDINATE_TOLERANCE_MM
            for node in key
        )
    }
    if len(prepared_bottom) != conversion.locked_bottom_face_count:
        raise ConstrainedHybridError(
            "combined upper-UF changed the locked bottom QUADs"
        )
    expected_boundary = {
        *prepared_bottom,
        *(_face_key(facet) for facet in die_facets),
        *(_face_key(facet) for facet in free_facets),
        *(_face_key(facet) for facet in mapped_top),
    }
    actual_boundary = {
        key for key, face_owners in owners.items() if len(face_owners) == 1
    }
    if actual_boundary != expected_boundary:
        raise ConstrainedHybridError(
            "combined upper-UF stages leave a crack or extra exterior face"
        )
    element_volume = math.fsum(
        _element_volume(element, coordinates) for element in elements
    )
    cad_volume = conversion.cad_volume_mm3 + remainder.cad_volume_mm3
    relative_volume_error = abs(element_volume - cad_volume) / cad_volume
    if relative_volume_error > 1.0e-6:
        raise ConstrainedHybridError(
            f"combined upper-UF volume mismatch is {relative_volume_error:.3g}"
        )
    near_edge, far_edge = _edge_growth(
        coordinates,
        elements,
        conversion.transition_z_mm,
        remainder.cap_z_mm,
    )
    growth = _directional_growth(
        coordinates,
        elements,
        conversion.transition_z_mm,
        remainder.cap_z_mm,
    )
    if len(by_coordinate) != len(coordinates):
        raise ConstrainedHybridError("combined upper-UF has duplicate coordinates")
    return ConstrainedUfHybridVolume(
        node_coordinates=MappingProxyType(coordinates),
        source_node_id_by_local_id=MappingProxyType(source_by_local),
        elements=elements,
        die_wall_facets=tuple(
            sorted(die_facets, key=lambda facet: (_face_key(facet), facet))
        ),
        free_surface_facets=tuple(
            sorted(free_facets, key=lambda facet: (_face_key(facet), facet))
        ),
        top_cap_facets=tuple(
            sorted(mapped_top, key=lambda facet: (_face_key(facet), facet))
        ),
        locked_bottom_face_count=conversion.locked_bottom_face_count,
        bottom_quad_pyramid_base_count=conversion.bottom_quad_pyramid_base_count,
        tet4_count=conversion.tet4_count + len(remainder.elements),
        pyramid5_count=conversion.pyramid5_count,
        near_median_edge_mm=near_edge,
        far_median_edge_mm=far_edge,
        minimum_sicn=min(conversion.minimum_sicn, remainder.minimum_sicn),
        minimum_sige=min(conversion.minimum_sige, remainder.minimum_sige),
        minimum_scaled_jacobian=min(
            conversion.minimum_scaled_jacobian,
            remainder.minimum_scaled_jacobian,
        ),
        minimum_determinant=min(
            conversion.minimum_determinant,
            remainder.minimum_determinant,
        ),
        duplicate_node_count=0,
        duplicate_element_count=0,
        growth_by_axis=growth,
        cad_volume_mm3=cad_volume,
        element_volume_mm3=element_volume,
        relative_volume_error=relative_volume_error,
        bottom_base_aspect_median=conversion.bottom_base_aspect_median,
        bottom_base_aspect_p90=conversion.bottom_base_aspect_p90,
        bottom_base_aspect_maximum=conversion.bottom_base_aspect_maximum,
        transition_z_mm=conversion.transition_z_mm,
        cap_z_mm=remainder.cap_z_mm,
        random_seed=conversion.random_seed,
        adapter_cap_z_mm=conversion.cap_z_mm,
        adapter_top_face_count=len(conversion.top_cap_facets),
        remainder_tet4_count=len(remainder.elements),
        adapter_bottom_median_edge_mm=(
            conversion.adapter_bottom_median_edge_mm
        ),
        adapter_top_median_edge_mm=conversion.adapter_top_median_edge_mm,
    )


def generate_locked_uf_upper_hybrid(
    docking_node_coordinates: Mapping[int, Sequence[float]],
    docking_facets: Sequence[Sequence[int]],
    envelope: RectangularUfEnvelope,
    transition_z_mm: float,
    cap_z_mm: float,
    *,
    maximum_size_mm: float,
    near_size_mm: float,
    transition_distance_mm: float | None = None,
    minimum_quality: float = 0.03,
    random_seeds: Sequence[int] = (1, 2, 3),
    optimization_rounds: int = 2,
    verbose: bool = False,
) -> ConstrainedUfHybridVolume:
    """Immediately convert locked QUADs, then continue with a coarse TET bulk.

    Short UF caps are filled in one hybrid volume.  Taller fillets use a
    bounded adapter no taller than 2.5 near-field sizes; its already coarsened
    TRI cap then becomes the exact boundary of an all-TET continuation.  The
    original fine XY partition is therefore paid once and never dragged
    through the remaining UF height.
    """

    maximum_size = _finite(maximum_size_mm, name="upper-UF maximum size")
    near_size = _finite(near_size_mm, name="upper-UF near size")
    transition_z = _finite(transition_z_mm, name="upper-UF transition Z")
    cap_z = _finite(cap_z_mm, name="upper-UF cap Z")
    transition_distance = (
        cap_z - transition_z
        if transition_distance_mm is None
        else _finite(transition_distance_mm, name="upper-UF transition distance")
    )
    quality_floor = _finite(minimum_quality, name="upper-UF minimum quality")
    if (
        maximum_size <= 0.0
        or near_size <= 0.0
        or maximum_size < near_size
        or transition_distance <= 0.0
        or quality_floor <= 0.0
        or quality_floor >= 1.0
    ):
        raise ConstrainedHybridError("upper-UF sizes or quality floor are invalid")
    try:
        seeds = tuple(random_seeds)
    except TypeError as error:
        raise ConstrainedHybridError("upper-UF seeds must be a sequence") from error
    if not seeds or any(
        isinstance(seed, bool) or not isinstance(seed, int) or seed < 1
        for seed in seeds
    ):
        raise ConstrainedHybridError("upper-UF seeds must be positive integers")
    seeds = tuple(dict.fromkeys(seeds))
    if (
        isinstance(optimization_rounds, bool)
        or not isinstance(optimization_rounds, int)
        or optimization_rounds < 0
        or optimization_rounds > 4
    ):
        raise ConstrainedHybridError("upper-UF optimization rounds must be 0..4")
    total_height = cap_z - transition_z
    adapter_height = min(total_height, 2.5 * near_size)
    if adapter_height <= _COORDINATE_TOLERANCE_MM:
        raise ConstrainedHybridError("upper-UF hybrid height is not positive")
    adapter_cap = transition_z + adapter_height
    # The one-time interface adapter needs enough in-plane relief to replace
    # the dense docking partition without creating a thin forest of slivers.
    # Keep the deliberate 3:1 target explicit, but never exceed the caller's
    # reported maximum size.
    adapter_maximum = min(
        maximum_size,
        max(3.0 * near_size, adapter_height),
    )
    conversion = _generate_locked_uf_conversion_stage(
        docking_node_coordinates,
        docking_facets,
        envelope,
        transition_z,
        adapter_cap,
        maximum_size_mm=adapter_maximum,
        near_size_mm=near_size,
        transition_distance_mm=transition_distance,
        minimum_quality=quality_floor,
        random_seeds=seeds,
        optimization_rounds=optimization_rounds,
        verbose=verbose,
    )
    if conversion.adapter_surface_face_reduction_ratio <= 1.0:
        raise ConstrainedHybridError(
            "upper-UF adapter did not reduce the fine XY surface topology"
        )
    if (
        conversion.adapter_xy_edge_growth_ratio
        < _MIN_ADAPTER_XY_EDGE_GROWTH
    ):
        raise ConstrainedHybridError(
            "upper-UF adapter did not enlarge its median XY edge by at least "
            f"{_MIN_ADAPTER_XY_EDGE_GROWTH:.3g}x"
        )
    if adapter_cap >= cap_z - _COORDINATE_TOLERANCE_MM:
        return conversion
    top_nodes = {node for facet in conversion.top_cap_facets for node in facet}
    top_coordinates = {
        node: conversion.node_coordinates[node] for node in top_nodes
    }
    remainder_near_size = min(
        maximum_size,
        max(near_size, 0.75 * adapter_height),
    )
    remainder = _generate_tet_remainder(
        top_coordinates,
        conversion.top_cap_facets,
        envelope,
        adapter_cap,
        cap_z,
        maximum_size_mm=maximum_size,
        near_size_mm=remainder_near_size,
        transition_distance_mm=transition_distance,
        minimum_quality=quality_floor,
        random_seeds=seeds,
        optimization_rounds=optimization_rounds,
        verbose=verbose,
    )
    return _combine_upper_uf_stages(conversion, remainder)


def _generate_locked_uf_trace_core_hybrid_unsupported(
    docking_node_coordinates: Mapping[int, Sequence[float]],
    docking_facets: Sequence[Sequence[int]],
    locked_side_node_coordinates: Mapping[int, Sequence[float]],
    locked_side_facets: Sequence[Sequence[int]],
    envelope: RectangularUfEnvelope,
    cap_z_mm: float,
    *,
    target_edge_mm: float,
    transition_distance_mm: float,
    near_size_mm: float | None = None,
    minimum_quality: float = 0.03,
    random_seeds: Sequence[int] = tuple(range(1, 13)),
    optimization_rounds: int = 2,
    verbose: bool = False,
) -> ConstrainedUfHybridVolume:
    """Retain the rejected all-TET trace-core experiment for diagnostics only.

    The complete ring/UF base annulus and the connected-bump inner wall are
    immutable boundary meshes.  EasyMesh constructs the locked-face
    PYRAMID5 collar and Gmsh owns the all-TET remainder, tapered free surface
    and upper split surface.  ``target_edge_mm`` therefore controls the newly
    generated bulk while the locked trace alone determines the unavoidable
    near-interface resolution.

    This function is deliberately private and unsupported: the real high-UF
    geometry does not meet the fixed 0.03 quality floor on this topology.
    Production dispatch uses the fresh radial-QUAD/HEX8 lower-UF path in
    :mod:`easymesh.package_builder` instead.
    """

    target_edge = _finite(target_edge_mm, name="trace-core target edge")
    transition_distance = _finite(
        transition_distance_mm,
        name="trace-core transition distance",
    )
    quality_floor = _finite(minimum_quality, name="trace-core minimum quality")
    resolved_near_size = (
        target_edge
        if near_size_mm is None
        else _finite(near_size_mm, name="trace-core near size")
    )
    if (
        target_edge <= 0.0
        or resolved_near_size <= 0.0
        or resolved_near_size > target_edge
        or transition_distance <= 0.0
        or quality_floor <= 0.0
        or quality_floor >= 1.0
    ):
        raise ConstrainedHybridError(
            "trace-core sizes, transition distance or quality floor are invalid"
        )
    try:
        seeds = tuple(random_seeds)
    except TypeError as error:
        raise ConstrainedHybridError(
            "trace-core random seeds must be a sequence"
        ) from error
    if not seeds or any(
        isinstance(seed, bool) or not isinstance(seed, int) or seed < 1
        for seed in seeds
    ):
        raise ConstrainedHybridError(
            "trace-core random seeds must be positive integers"
        )
    seeds = tuple(dict.fromkeys(seeds))
    if (
        isinstance(optimization_rounds, bool)
        or not isinstance(optimization_rounds, int)
        or optimization_rounds < 0
        or optimization_rounds > 4
    ):
        raise ConstrainedHybridError(
            "trace-core optimization rounds must be 0..4"
        )
    prepared = _prepare_inputs(
        docking_node_coordinates,
        docking_facets,
        envelope,
        envelope.base_z,
        cap_z_mm,
        locked_side_node_coordinates,
        locked_side_facets,
    )
    gmsh = _load_gmsh()
    failures: list[str] = []
    for seed in seeds:
        try:
            candidate, cad_volume, collar = _mesh_explicit_trace_collar_candidate(
                gmsh,
                prepared,
                maximum_size=target_edge,
                near_size=resolved_near_size,
                transition_distance=transition_distance,
                optimization_rounds=optimization_rounds,
                seed=seed,
                verbose=verbose,
            )
            return _finalize_candidate(
                candidate,
                prepared,
                cad_volume,
                minimum_quality=quality_floor,
                allow_sparse_growth=True,
                expected_exterior=collar,
            )
        except ConstrainedHybridError as error:
            failures.append(f"seed {seed}: {error}")
        except Exception as error:  # pragma: no cover - Gmsh runtime failure
            failures.append(f"seed {seed}: Gmsh runtime failure: {error}")
    raise ConstrainedHybridError(
        "all locked trace-core candidates failed; " + "; ".join(failures)
    )


def generate_locked_uf_upper_tet_hybrid(
    docking_node_coordinates: Mapping[int, Sequence[float]],
    docking_facets: Sequence[Sequence[int]],
    envelope: RectangularUfEnvelope,
    transition_z_mm: float,
    cap_z_mm: float,
    *,
    maximum_size_mm: float,
    near_size_mm: float,
    transition_distance_mm: float,
    minimum_quality: float = 0.03,
    random_seeds: Sequence[int] = tuple(range(1, 13)),
    optimization_rounds: int = 2,
    verbose: bool = False,
) -> _TetRemainderVolume:
    """Continue a generated TRI3 lower-core seam with an all-TET upper UF."""

    maximum_size = _finite(maximum_size_mm, name="upper-UF TET maximum size")
    near_size = _finite(near_size_mm, name="upper-UF TET near size")
    transition_distance = _finite(
        transition_distance_mm,
        name="upper-UF TET transition distance",
    )
    quality_floor = _finite(minimum_quality, name="upper-UF TET minimum quality")
    try:
        seeds = tuple(dict.fromkeys(tuple(random_seeds)))
    except TypeError as error:
        raise ConstrainedHybridError("upper-UF TET seeds must be a sequence") from error
    if (
        maximum_size <= 0.0
        or near_size <= 0.0
        or near_size > maximum_size
        or transition_distance <= 0.0
        or quality_floor <= 0.0
        or quality_floor >= 1.0
        or not seeds
        or any(
            isinstance(seed, bool) or not isinstance(seed, int) or seed < 1
            for seed in seeds
        )
    ):
        raise ConstrainedHybridError("upper-UF TET controls are invalid")
    return _generate_tet_remainder(
        docking_node_coordinates,
        docking_facets,
        envelope,
        transition_z_mm,
        cap_z_mm,
        maximum_size_mm=maximum_size,
        near_size_mm=near_size,
        transition_distance_mm=transition_distance,
        minimum_quality=quality_floor,
        random_seeds=seeds,
        optimization_rounds=optimization_rounds,
        verbose=verbose,
    )


__all__ = [
    "ConstrainedUfHybridVolume",
    "generate_locked_uf_upper_hybrid",
    "generate_locked_uf_upper_tet_hybrid",
]
