"""Read-only contact JSON; never runs a volume mesher or edits Source.

One-shot audited diagnostics share the worker's strict discovery. The GUI uses
a persistent geometry-only service, with streamed results and boundary caching.
Neither its cache nor its preview payload is accepted as execution evidence.
"""
from __future__ import annotations

import contextlib
import json
import signal
import sys
import time
import queue
import threading

from .package_v2_compile import compile_package_v2
from .package_v2_frozen import load_compiled_frozen_source
from .package_v2_mixed_source_lowering import (
    lower_mixed_source, _lower_generated_components, _lower_generated_interfaces,
)
from .package_v2_mixed_execution_context import discover_mixed_contacts
from .package_v2_adjacency_execution import plan_component_adjacency_execution
from .package_v2_adjacency_execution import _enumerate_component_pair_sides
from .package_v2_component_adjacency import extract_component_adjacencies
from .package_v2_geometry import CanonicalGeneratedGeometry
from .package_v2_mesh_ordering import plan_mesh_ordering, _complete_side_area, _area_is_complete


def contact_preview(compiled):
    """Return derived evidence, including local names and exact source identity."""
    if len(compiled.frozen_sources) > 1:
        raise ValueError("接触预览与当前 worker 一致：最多支持一个 Frozen Source")
    lowered = _lower_generated_components(compiled)
    components, fragments, controls, requirements = lowered[2], lowered[5], lowered[7], lowered[8]
    adjacency, policies, continuity = _lower_generated_interfaces(
        components, requirements, controls, compiled.interface_geometry_tolerance_mm,
    )
    patches, matches = {}, {}
    frozen_artifacts = []
    if compiled.frozen_sources:
        snapshot = load_compiled_frozen_source(compiled.frozen_sources[0])
        lowering, plan, patches = discover_mixed_contacts(lower_mixed_source(compiled, snapshot), snapshot)
        matches = lowering.frozen_interface_matches
        continuity = lowering.generated_interface_continuity_plan
        frozen_artifacts = [
            {"role": role, "path": item.runtime_path, "sha256": item.sha256}
            for role, item in sorted(snapshot.artifacts.items())
        ]
    else:
        plan = plan_component_adjacency_execution(
            CanonicalGeneratedGeometry("source", tuple(components.values())),
            requirements, adjacency, policies,
            interface_geometry_tolerance_mm=compiled.interface_geometry_tolerance_mm,
        )
    names = {
        component.global_component_id: {
            "instance": instance.instance_id, "component": component.local_component_id,
        }
        for instance in compiled.generated_instances for component in instance.components
    }
    rows = []
    for key, values in patches.items():
        match = matches[key]
        rows.append({
            "kind": "Frozen→Generated",
            "first": {"instance": match.frozen_source_id, "component": match.frozen_component_local_id},
            "second": names[key.generated_component_global_id],
            "first_global_id": key.frozen_component_global_id,
            "second_global_id": key.generated_component_global_id,
            "area_mm2": sum(p.area_mm2 for p in values),
            "facet_count": sum(len(p.facets) for p in values),
            "sides": sorted({p.side_name for p in values}),
            "mode": "preserve_interface_trace",
        })
    for pair in plan.face_pairs:
        first, second = pair.first_side, pair.second_side
        if controls[first.component_id].mesh_priority > controls[second.component_id].mesh_priority:
            first, second = second, first
        producer, consumer = fragments[first.fragment_id], fragments[second.fragment_id]
        rows.append({
            "kind": "Generated→Generated",
            "first": names[first.component_id], "second": names[second.component_id],
            "first_global_id": first.component_id, "second_global_id": second.component_id,
            "area_mm2": pair.area_mm2,
            "sides": [first.side_name, second.side_name], "mode": pair.surface_policy,
            "producer_priority": controls[first.component_id].mesh_priority,
            "consumer_priority": controls[second.component_id].mesh_priority,
            "producer_side_area_mm2": _complete_side_area(producer, first.side_name),
            "consumer_side_area_mm2": _complete_side_area(consumer, second.side_name),
            "producer_side_complete": _area_is_complete(producer, first.side_name, pair.area_mm2),
            "consumer_side_complete": _area_is_complete(consumer, second.side_name, pair.area_mm2),
        })
    ordering_error = None
    try:
        plan_mesh_ordering(components, controls, requirements, plan, continuity, matches, patches)
    except ValueError as error:
        ordering_error = str(error)
    return {
        "schema": "easymesh-package-v2-contact-preview-v1",
        "raw_source_sha256": compiled.raw_source_digest,
        "plan_sha256": compiled.plan_digest,
        "interface_geometry_tolerance_mm": compiled.interface_geometry_tolerance_mm,
        "frozen_artifacts": frozen_artifacts,
        "geometry_contacts_complete": True,
        "mesh_ordering_error": ordering_error,
        "interfaces": rows,
        "contact_discovery": "automatic_geometry",
    }


def geometry_contact_preview(compiled, *, cache=None, emit=None):
    """Fast UI evidence; never bypasses the worker's full Frozen audit."""
    from .package_v2_contact_geometry import BoundaryCache, frozen_geometry_rows
    if len(compiled.frozen_sources) > 1:
        raise ValueError("接触预览与当前 worker 一致：最多支持一个 Frozen Source")
    start = time.perf_counter()
    lowered = _lower_generated_components(compiled)
    components, fragments, controls = lowered[2], lowered[5], lowered[7]
    names = {c.global_component_id: {"instance": i.instance_id, "component": c.local_component_id}
             for i in compiled.generated_instances for c in i.components}
    tolerance = compiled.interface_geometry_tolerance_mm
    rows = []
    # These are the same geometric primitives used by execution, without
    # negotiating topology, sweep directions or mesh priority constraints.
    adjacencies = extract_component_adjacencies(tuple(components.values()),
        interface_namespace="generated/source", interface_geometry_tolerance_mm=tolerance)
    for adjacency in adjacencies:
        first = components[adjacency.first_component_id]
        second = components[adjacency.second_component_id]
        if controls[first.component_id].mesh_priority > controls[second.component_id].mesh_priority:
            first, second = second, first
        for pair in _enumerate_component_pair_sides(first, second, tolerance):
            producer, consumer = fragments[pair.first_fragment_id], fragments[pair.second_fragment_id]
            rows.append({"kind": "Generated→Generated", "first": names[first.component_id],
                "second": names[second.component_id], "first_global_id": first.component_id,
                "second_global_id": second.component_id, "area_mm2": pair.area_mm2,
                "sides": [pair.first_side_name, pair.second_side_name], "mode": "geometry_contact",
                "producer_priority": controls[first.component_id].mesh_priority,
                "consumer_priority": controls[second.component_id].mesh_priority,
                "producer_side_area_mm2": _complete_side_area(producer, pair.first_side_name),
                "consumer_side_area_mm2": _complete_side_area(consumer, pair.second_side_name),
                "producer_side_complete": _area_is_complete(producer, pair.first_side_name, pair.area_mm2),
                "consumer_side_complete": _area_is_complete(consumer, pair.second_side_name, pair.area_mm2)})
    payload = dict(schema="easymesh-package-v2-contact-preview-v1",
                   raw_source_sha256=compiled.raw_source_digest, plan_sha256=compiled.plan_digest,
                   interface_geometry_tolerance_mm=tolerance, interfaces=rows,
                   contact_discovery="automatic_geometry", mesh_ordering_error=None,
                   mesh_ordering_checked=False, check_scope="geometry_preview", mesh_validation_complete=False,
                   mesh_validation_status="pending_execution_audit",
                   geometry_contacts_complete=not bool(compiled.frozen_sources),
                   stage="generated_geometry", preview_rows_available=True)
    if emit and compiled.frozen_sources:
        emit(dict(payload))
    try:
        rows, evidence = frozen_geometry_rows(compiled, lowered[2], names, cache or BoundaryCache())
    except Exception as error:
        payload.update(stage="geometry_failed", error=str(error), geometry_contacts_complete=False)
    else:
        payload["interfaces"] = rows + payload["interfaces"]
        payload.update(stage="geometry_complete", geometry_contacts_complete=True,
                       frozen_geometry_cache=evidence)
    payload["elapsed_seconds"] = time.perf_counter() - start
    return payload


def main():
    # Graceful GUI cancellation unwinds private Frozen snapshot directories.
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(130))
    def run(request, cache=None):
        def emit(payload):
            payload["generation"] = request.get("generation")
            print(json.dumps(payload, ensure_ascii=False, allow_nan=False), flush=True)

        try:
            with contextlib.redirect_stdout(sys.stderr):
                compiled = compile_package_v2(request["source_text"].encode("utf-8"),
                                              source_root=request["source_root"])
            if request.get("realtime"):
                # Gmsh terminal output is disabled by the boundary reader.
                payload = geometry_contact_preview(compiled, cache=cache, emit=emit)
            else:
                with contextlib.redirect_stdout(sys.stderr):
                    payload = contact_preview(compiled)
        except Exception as error:
            payload = {"geometry_contacts_complete": False, "error": str(error), "interfaces": []}
        emit(payload)
        return payload

    try:
        first_line = sys.stdin.readline()
        try:
            request = json.loads(first_line)
        except ValueError:
            # Preserve pretty-printed one-shot requests. Service requests are
            # always one compact JSON object per line.
            request = json.loads(first_line + sys.stdin.read())
        if request.get("service"):
            from .package_v2_contact_geometry import BoundaryCache
            pending = queue.Queue()
            def read_requests():
                for line in sys.stdin:
                    try:
                        pending.put(json.loads(line))
                    except ValueError:
                        continue
                pending.put(None)
            threading.Thread(target=read_requests, daemon=True).start()
            cache = BoundaryCache()
            while request is not None:
                while not pending.empty():
                    latest = pending.get_nowait()
                    if latest is None:
                        return 0
                    request = latest
                run(request, cache)
                request = pending.get()
            return 0
        payload = run(request)
    except Exception as error:
        payload = {"geometry_contacts_complete": False, "error": str(error), "interfaces": []}
        print(json.dumps(payload, ensure_ascii=False), flush=True)
    return 0 if payload["geometry_contacts_complete"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
