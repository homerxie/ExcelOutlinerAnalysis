"""Cartesian Gmsh volume meshing for canonical Box and Frame fragments.

This is the ``orthogonal_hex`` backend for extrudable rectilinear geometry.
It builds one complete Cartesian QUAD section from analytic geometry and any
immutable boundary QUAD locks, then asks its own Gmsh model to create every
three-dimensional HEX8 by native extrusion.  It does not call or select the
``structured_sweep`` materializer.  The two topologies merely share Gmsh's
native extrusion capability; their geometry proofs, element-family contracts
and execution evidence remain separate.

Component names, materials, package roles and stack position never participate
in a decision.  A set of boundary locks that cannot be represented by one
rectilinear tensor partition is rejected instead of deleting or subdividing a
locked facet.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import math
from types import MappingProxyType
from typing import Any, TypeAlias

from .package_v2_mesh_sizing import MeshSeedPolicy, geometry_origin, interval_levels, meeting_levels
from .component_interface import ComponentMeshRequirement
from .gmsh_runtime import isolated_gmsh_model
from .package_assembly import (
    ComponentLocalDirection,
    OrthogonalHexMeshStrategy,
)
from .package_v2_geometry import (
    CanonicalBox,
    CanonicalGeometryFragment,
    CanonicalRectangularFrameExtrusion,
    CanonicalRigidPlacement,
)
from .package_v2_mixed_mesh_assembly import (
    ComponentLocalMeshFragment,
    ComponentMeshElement,
    ComponentMeshNode,
)
from .volume_mesh import ELEMENT_SPECS


Point3D: TypeAlias = tuple[float, float, float]
_QUALITY_FLOOR = 0.03


class OrthogonalBoxFrameMaterializationError(ValueError):
    """A Box/Frame cannot retain every lock as Cartesian HEX8 geometry."""


@dataclass(frozen=True, slots=True)
class OrthogonalBoxFrameComponentMesh:
    canonical_fragment: CanonicalGeometryFragment
    requirement: ComponentMeshRequirement
    component_fragment: ComponentLocalMeshFragment
    locked_facets_by_geometric_side: Mapping[
        str, tuple[tuple[int, ...], ...]
    ]
    boundary_facets_by_geometric_side: Mapping[
        str, tuple[tuple[int, ...], ...]
    ]
    element_count: int
    boundary_face_count: int
    analytic_volume_mm3: float
    element_volume_mm3: float
    relative_volume_error: float
    minimum_determinant: float
    minimum_sicn: float
    minimum_sige: float
    minimum_scaled_jacobian: float
    cartesian_hex_verified: bool
    gmsh_owns_all_volume_connectivity: bool = True
    immutable_target_edge_override_count: int = 0
    immutable_maximum_edge_mm: float = 0.0

    def __post_init__(self) -> None:
        for field_name in (
            "locked_facets_by_geometric_side",
            "boundary_facets_by_geometric_side",
        ):
            object.__setattr__(
                self,
                field_name,
                MappingProxyType(dict(getattr(self, field_name))),
            )
        if self.requirement.volume_topology != "orthogonal_hex":
            raise OrthogonalBoxFrameMaterializationError(
                "orthogonal Box/Frame result has the wrong requested topology"
            )
        if not self.gmsh_owns_all_volume_connectivity:
            raise OrthogonalBoxFrameMaterializationError(
                "orthogonal volume connectivity must remain Gmsh-owned"
            )
        if not self.cartesian_hex_verified:
            raise OrthogonalBoxFrameMaterializationError(
                "orthogonal Box/Frame result was not proved Cartesian"
            )
        if self.element_count != len(self.component_fragment.elements):
            raise OrthogonalBoxFrameMaterializationError(
                "orthogonal element-count evidence is inconsistent"
            )
        if any(
            element.kind.value != "HEX8"
            for element in self.component_fragment.elements
        ):
            raise OrthogonalBoxFrameMaterializationError(
                "orthogonal Box/Frame emitted a non-HEX8 element"
            )
        if self.relative_volume_error > 1.0e-9:
            raise OrthogonalBoxFrameMaterializationError(
                "orthogonal Box/Frame volume differs from analytic geometry"
            )
        if (
            self.minimum_determinant <= 0.0
            or self.minimum_sicn <= 0.0
            or min(
                self.minimum_sige,
                self.minimum_scaled_jacobian,
            )
            < _QUALITY_FLOOR
        ):
            raise OrthogonalBoxFrameMaterializationError(
                "orthogonal Box/Frame quality is below 0.03"
            )


def _rotation_matrix(
    placement: CanonicalRigidPlacement,
) -> tuple[Point3D, Point3D, Point3D]:
    rx, ry, rz = (math.radians(value) for value in placement.rotation_deg_xyz)
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    x = ((1.0, 0.0, 0.0), (0.0, cx, -sx), (0.0, sx, cx))
    y = ((cy, 0.0, sy), (0.0, 1.0, 0.0), (-sy, 0.0, cy))
    z = ((cz, -sz, 0.0), (sz, cz, 0.0), (0.0, 0.0, 1.0))

    def product(
        left: Sequence[Sequence[float]],
        right: Sequence[Sequence[float]],
    ) -> tuple[Point3D, Point3D, Point3D]:
        return tuple(
            tuple(
                math.fsum(
                    left[row][inner] * right[inner][column]
                    for inner in range(3)
                )
                for column in range(3)
            )
            for row in range(3)
        )  # type: ignore[return-value]

    return product(z, product(y, x))


def _to_local(point: Point3D, placement: CanonicalRigidPlacement) -> Point3D:
    pivot = placement.pivot_xyz_mm
    translated = tuple(
        point[axis] - placement.translation_xyz_mm[axis] - pivot[axis]
        for axis in range(3)
    )
    rotation = _rotation_matrix(placement)
    return tuple(
        pivot[axis]
        + math.fsum(
            rotation[source_axis][axis] * translated[source_axis]
            for source_axis in range(3)
        )
        for axis in range(3)
    )  # type: ignore[return-value]


def _to_package(point: Point3D, placement: CanonicalRigidPlacement) -> Point3D:
    pivot = placement.pivot_xyz_mm
    relative = tuple(point[index] - pivot[index] for index in range(3))
    rotation = _rotation_matrix(placement)
    return tuple(
        placement.translation_xyz_mm[row]
        + pivot[row]
        + math.fsum(
            rotation[row][column] * relative[column]
            for column in range(3)
        )
        for row in range(3)
    )  # type: ignore[return-value]


def _require_axis_permutation(placement: CanonicalRigidPlacement) -> None:
    """Require local Cartesian axes to remain package Cartesian axes."""

    tolerance = 1.0e-10
    rotation = _rotation_matrix(placement)
    if any(
        sum(abs(value) > tolerance for value in row) != 1
        or not math.isclose(
            max(abs(value) for value in row),
            1.0,
            rel_tol=0.0,
            abs_tol=tolerance,
        )
        for row in rotation
    ) or any(
        sum(abs(rotation[row][column]) > tolerance for row in range(3)) != 1
        for column in range(3)
    ):
        raise OrthogonalBoxFrameMaterializationError(
            "orthogonal_hex requires placement axes to be a signed permutation "
            "of package Cartesian axes"
        )


def _bounds(
    fragment: CanonicalGeometryFragment,
) -> tuple[
    tuple[float, float, float, float, float, float],
    tuple[float, float, float, float] | None,
]:
    root = fragment.root
    if type(root) is CanonicalBox:
        x0, y0, z0 = root.origin_xyz_mm
        sx, sy, sz = root.size_xyz_mm
        return (x0, x0 + sx, y0, y0 + sy, z0, z0 + sz), None
    if type(root) is CanonicalRectangularFrameExtrusion:
        x0, y0, z0 = root.outer_origin_xyz_mm
        x1 = x0 + root.outer_size_xy_mm[0]
        y1 = y0 + root.outer_size_xy_mm[1]
        ix0 = x0 + root.opening_offset_xy_mm[0]
        iy0 = y0 + root.opening_offset_xy_mm[1]
        return (
            x0,
            x1,
            y0,
            y1,
            z0,
            z0 + root.height_mm,
        ), (
            ix0,
            ix0 + root.opening_size_xy_mm[0],
            iy0,
            iy0 + root.opening_size_xy_mm[1],
        )
    raise OrthogonalBoxFrameMaterializationError(
        "orthogonal Box/Frame backend requires canonical Box or Frame geometry"
    )


def _expected_side_plane(
    fragment: CanonicalGeometryFragment,
    side: str,
) -> tuple[int, float]:
    bounds, opening = _bounds(fragment)
    x0, x1, y0, y1, z0, z1 = bounds
    if opening is None:
        values = {
            "x_min": (0, x0),
            "x_max": (0, x1),
            "y_min": (1, y0),
            "y_max": (1, y1),
            "bottom": (2, z0),
            "top": (2, z1),
        }
    else:
        ix0, ix1, iy0, iy1 = opening
        values = {
            "outer_x_min": (0, x0),
            "outer_x_max": (0, x1),
            "outer_y_min": (1, y0),
            "outer_y_max": (1, y1),
            "inner_x_min": (0, ix0),
            "inner_x_max": (0, ix1),
            "inner_y_min": (1, iy0),
            "inner_y_max": (1, iy1),
            "bottom": (2, z0),
            "top": (2, z1),
        }
    try:
        return values[side]
    except KeyError as error:
        raise OrthogonalBoxFrameMaterializationError(
            f"orthogonal Box/Frame received unknown geometric side {side!r}"
        ) from error


def _cluster(values: Sequence[float], tolerance: float) -> tuple[float, ...]:
    groups: list[list[float]] = []
    for value in sorted(values):
        if not groups or abs(value - groups[-1][-1]) > tolerance:
            groups.append([value])
        else:
            groups[-1].append(value)
    return tuple(math.fsum(group) / len(group) for group in groups)


def _validate_locked_quads(
    fragment: CanonicalGeometryFragment,
    coordinates: Mapping[int, Point3D],
    facets_by_side: Mapping[str, Sequence[Sequence[int]]],
    *,
    tolerance: float,
) -> Mapping[int, tuple[tuple[float, float], ...]]:
    protected: dict[int, set[tuple[float, float]]] = {
        0: set(),
        1: set(),
        2: set(),
    }
    for side, raw_facets in facets_by_side.items():
        normal_axis, normal_value = _expected_side_plane(fragment, side)
        for raw_facet in raw_facets:
            facet = tuple(raw_facet)
            if (
                len(facet) != 4
                or len(set(facet)) != 4
                or any(node not in coordinates for node in facet)
            ):
                raise OrthogonalBoxFrameMaterializationError(
                    "orthogonal boundary locks must contain only valid QUAD4 facets"
                )
            points = tuple(coordinates[node] for node in facet)
            if any(
                abs(point[normal_axis] - normal_value) > tolerance
                for point in points
            ):
                raise OrthogonalBoxFrameMaterializationError(
                    f"locked QUAD4 is not on canonical side {side!r}"
                )
            levels = tuple(
                _cluster(tuple(point[axis] for point in points), tolerance)
                for axis in range(3)
            )
            if len(levels[normal_axis]) != 1 or any(
                len(levels[axis]) != 2
                for axis in range(3)
                if axis != normal_axis
            ):
                raise OrthogonalBoxFrameMaterializationError(
                    "locked orthogonal QUAD4 is not one Cartesian rectangle"
                )
            expected = {
                (x, y, z)
                for x in levels[0]
                for y in levels[1]
                for z in levels[2]
            }
            if any(
                not any(math.dist(point, value) <= tolerance for value in expected)
                for point in points
            ):
                raise OrthogonalBoxFrameMaterializationError(
                    "locked orthogonal QUAD4 omits a Cartesian rectangle corner"
                )
            for axis in range(3):
                if axis == normal_axis:
                    continue
                lower, upper = levels[axis]
                protected[axis].add((lower, upper))
    return MappingProxyType(
        {axis: tuple(sorted(values)) for axis, values in protected.items()}
    )


def _partition_axis(
    feature_values: Sequence[float],
    locked_values: Sequence[float],
    protected_segments: Sequence[tuple[float, float]],
    target: float,
    *,
    tolerance: float,
    partition_origin: float | None = None,
    negative_target: float | None = None,
    positive_target: float | None = None,
    sizing: MeshSeedPolicy = MeshSeedPolicy(),
    meeting_span: tuple[float, float] | None = None,
) -> tuple[float, ...]:
    anchors = (*feature_values, *locked_values)
    if (
        partition_origin is not None
        and meeting_span is None
        and min(feature_values) < partition_origin < max(feature_values)
        and not any(
            a + tolerance < partition_origin < b - tolerance
            for a, b in protected_segments
        )
    ):
        anchors = (*anchors, partition_origin)
    base = _cluster(anchors, tolerance)
    if len(base) < 2:
        raise OrthogonalBoxFrameMaterializationError(
            "orthogonal axis has no positive interval"
        )
    protected_keys: set[tuple[int, int]] = set()
    for lower, upper in protected_segments:
        inside = tuple(
            index
            for index, value in enumerate(base)
            if lower - tolerance <= value <= upper + tolerance
        )
        if (
            len(inside) != 2
            or abs(base[inside[0]] - lower) > tolerance
            or abs(base[inside[1]] - upper) > tolerance
            or inside[1] != inside[0] + 1
        ):
            raise OrthogonalBoxFrameMaterializationError(
                "locked QUAD partitions are incompatible with one global "
                "Cartesian tensor grid"
            )
        protected_keys.add((inside[0], inside[1]))

    output: list[float] = [base[0]]
    for index, (lower, upper) in enumerate(zip(base, base[1:])):
        length = upper - lower
        if length <= tolerance:
            raise OrthogonalBoxFrameMaterializationError(
                "orthogonal axis contains a non-positive interval"
            )
        if (index, index + 1) in protected_keys:
            output.append(upper)
            continue
        negative = target if negative_target is None else negative_target
        positive = target if positive_target is None else positive_target
        origin = lower if partition_origin is None else partition_origin
        if (meeting_span is not None and abs(lower-meeting_span[0]) <= tolerance
                and abs(upper-meeting_span[1]) <= tolerance):
            levels = meeting_levels(lower, upper, positive, negative, origin, sizing)
        else:
            levels = interval_levels(lower, upper, negative, positive, origin, sizing)
        output.extend(levels[1:])
    return tuple(output)


def _section_grid(
    x_values: Sequence[float],
    y_values: Sequence[float],
    z: float,
    opening: tuple[float, float, float, float] | None,
) -> tuple[Mapping[int, Point3D], tuple[tuple[int, ...], ...]]:
    coordinates: dict[int, Point3D] = {}
    node_by_index: dict[tuple[int, int], int] = {}

    def node(x_index: int, y_index: int) -> int:
        key = (x_index, y_index)
        existing = node_by_index.get(key)
        if existing is not None:
            return existing
        node_id = len(coordinates) + 1
        node_by_index[key] = node_id
        coordinates[node_id] = (x_values[x_index], y_values[y_index], z)
        return node_id

    facets: list[tuple[int, ...]] = []
    for x_index in range(len(x_values) - 1):
        for y_index in range(len(y_values) - 1):
            center_x = 0.5 * (x_values[x_index] + x_values[x_index + 1])
            center_y = 0.5 * (y_values[y_index] + y_values[y_index + 1])
            if opening is not None:
                ix0, ix1, iy0, iy1 = opening
                if ix0 < center_x < ix1 and iy0 < center_y < iy1:
                    continue
            facets.append(
                (
                    node(x_index, y_index),
                    node(x_index + 1, y_index),
                    node(x_index + 1, y_index + 1),
                    node(x_index, y_index + 1),
                )
            )
    if not facets:
        raise OrthogonalBoxFrameMaterializationError(
            "orthogonal Cartesian section contains no QUAD4 cells"
        )
    return MappingProxyType(coordinates), tuple(facets)


def _load_gmsh() -> Any:
    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:  # pragma: no cover
        raise RuntimeError("Gmsh is required for orthogonal Box/Frame meshing") from error
    return gmsh


def _face_key(nodes: Sequence[int]) -> tuple[int, ...]:
    return tuple(sorted(nodes))


def _boundary_faces(
    element_rows: Sequence[tuple[int, tuple[int, ...]]],
) -> tuple[tuple[tuple[int, ...], ...], Mapping[int, int]]:
    counts: Counter[tuple[int, ...]] = Counter()
    cycles: dict[tuple[int, ...], tuple[int, ...]] = {}
    for _tag, nodes in element_rows:
        for local_face in ELEMENT_SPECS[5][2]:
            face = tuple(nodes[index] for index in local_face)
            key = _face_key(face)
            counts[key] += 1
            cycles.setdefault(key, face)
    if any(value not in {1, 2} for value in counts.values()):
        raise OrthogonalBoxFrameMaterializationError(
            "Gmsh orthogonal Box/Frame mesh is non-manifold"
        )
    return (
        tuple(cycles[key] for key, count in counts.items() if count == 1),
        MappingProxyType(dict(sorted(Counter(counts.values()).items()))),
    )


def _classify_boundary_face(
    face: Sequence[int],
    coordinates: Mapping[int, Point3D],
    fragment: CanonicalGeometryFragment,
    *,
    tolerance: float,
) -> str:
    bounds, opening = _bounds(fragment)
    x0, x1, y0, y1, z0, z1 = bounds
    points = tuple(coordinates[node] for node in face)

    def on(axis: int, value: float) -> bool:
        return all(abs(point[axis] - value) <= tolerance for point in points)

    if on(2, z0):
        return "bottom"
    if on(2, z1):
        return "top"
    for name, axis, value in (
        ("outer_x_min", 0, x0),
        ("outer_x_max", 0, x1),
        ("outer_y_min", 1, y0),
        ("outer_y_max", 1, y1),
    ):
        if on(axis, value):
            return name[6:] if opening is None else name
    if opening is not None:
        ix0, ix1, iy0, iy1 = opening
        for name, axis, value in (
            ("inner_x_min", 0, ix0),
            ("inner_x_max", 0, ix1),
            ("inner_y_min", 1, iy0),
            ("inner_y_max", 1, iy1),
        ):
            if on(axis, value):
                return name
    raise OrthogonalBoxFrameMaterializationError(
        "Gmsh orthogonal boundary facet escaped canonical geometry"
    )


def _analytic_volume(
    bounds: tuple[float, float, float, float, float, float],
    opening: tuple[float, float, float, float] | None,
) -> float:
    x0, x1, y0, y1, z0, z1 = bounds
    area = (x1 - x0) * (y1 - y0)
    if opening is not None:
        ix0, ix1, iy0, iy1 = opening
        area -= (ix1 - ix0) * (iy1 - iy0)
    return area * (z1 - z0)


def _gmsh_extrude_cartesian_section(
    canonical_fragment: CanonicalGeometryFragment,
    requirement: ComponentMeshRequirement,
    source_local: Mapping[int, Point3D],
    source_facets: Sequence[Sequence[int]],
    z_values: Sequence[float],
    *,
    source_side: str,
    material_name: str,
    fragment_key: str | None,
    token_by_coordinate: Mapping[tuple[int, int, int], str],
    locked_local: Mapping[int, Point3D],
    locked_facets: Mapping[str, Sequence[Sequence[int]]],
    minimum_quality: float,
    tolerance: float,
    verbose: bool,
) -> OrthogonalBoxFrameComponentMesh:
    """Run the orthogonal backend's own native Gmsh extrusion and audits."""

    bounds, opening = _bounds(canonical_fragment)
    _x0, _x1, _y0, _y1, z0, z1 = bounds
    height = z1 - z0
    layer_count = len(z_values) - 1
    if layer_count < 1:
        raise OrthogonalBoxFrameMaterializationError(
            "orthogonal extrusion requires at least one positive axial interval"
        )
    if source_side == "bottom":
        direction = height
        cumulative_heights = [
            (value - z0) / height for value in z_values[1:]
        ]
    else:
        direction = -height
        cumulative_heights = [
            (z1 - value) / height for value in reversed(z_values[:-1])
        ]

    gmsh = _load_gmsh()
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_orthogonal_box_frame",
        number_options={
            "General.Terminal": 1.0 if verbose else 0.0,
            "Mesh.ElementOrder": 1.0,
            "Mesh.Optimize": 0.0,
        },
    ):
        source_surface = int(gmsh.model.addDiscreteEntity(2))
        source_ids = tuple(sorted(source_local))
        gmsh.model.mesh.addNodes(
            2,
            source_surface,
            source_ids,
            tuple(
                coordinate
                for node in source_ids
                for coordinate in source_local[node]
            ),
        )
        gmsh.model.mesh.addElementsByType(
            source_surface,
            3,
            tuple(range(1, len(source_facets) + 1)),
            tuple(node for facet in source_facets for node in facet),
        )
        gmsh.model.geo.extrude(
            [(2, source_surface)],
            0.0,
            0.0,
            direction,
            numElements=[1] * layer_count,
            heights=cumulative_heights,
            recombine=True,
        )
        gmsh.model.geo.synchronize()
        gmsh.model.mesh.generate(3)

        raw_node_tags, raw_coordinates, _ = gmsh.model.mesh.getNodes()
        local_coordinates = {
            int(tag): (
                float(raw_coordinates[3 * index]),
                float(raw_coordinates[3 * index + 1]),
                float(raw_coordinates[3 * index + 2]),
            )
            for index, tag in enumerate(raw_node_tags)
        }
        element_rows: list[tuple[int, tuple[int, ...]]] = []
        element_tags: list[int] = []
        types, tag_blocks, connectivity_blocks = gmsh.model.mesh.getElements(3)
        for raw_type, raw_tags, raw_connectivity in zip(
            types, tag_blocks, connectivity_blocks
        ):
            gmsh_type = int(raw_type)
            if gmsh_type != 5:
                raise OrthogonalBoxFrameMaterializationError(
                    "Gmsh orthogonal Box/Frame emitted a non-HEX8 element"
                )
            connectivity = tuple(int(value) for value in raw_connectivity)
            for index, raw_tag in enumerate(raw_tags):
                tag = int(raw_tag)
                nodes = connectivity[8 * index : 8 * index + 8]
                element_tags.append(tag)
                element_rows.append((tag, nodes))
        if not element_rows:
            raise OrthogonalBoxFrameMaterializationError(
                "Gmsh orthogonal Box/Frame returned no volume elements"
            )
        if len(element_rows) != len(source_facets) * layer_count:
            raise OrthogonalBoxFrameMaterializationError(
                "Gmsh changed the one-HEX-per-QUAD-per-layer orthogonal topology"
            )
        quality: dict[str, float] = {}
        for name in ("minDetJac", "minSJ", "minSICN", "minSIGE"):
            values = tuple(
                float(value)
                for value in gmsh.model.mesh.getElementQualities(
                    element_tags, name
                )
            )
            minimum = min(values, default=0.0)
            failed = (
                minimum <= 0.0
                if name in {"minDetJac", "minSICN"}
                else minimum < minimum_quality
            )
            if not math.isfinite(minimum) or failed:
                raise OrthogonalBoxFrameMaterializationError(
                    f"Gmsh orthogonal Box/Frame {name}={minimum:.12g} failed "
                    f"the requested quality floor {minimum_quality:.12g}"
                )
            quality[name] = minimum
        volumes = tuple(
            float(value)
            for value in gmsh.model.mesh.getElementQualities(
                element_tags, "volume"
            )
        )
        if len(volumes) != len(element_rows) or any(
            not math.isfinite(value) or value <= 0.0 for value in volumes
        ):
            raise OrthogonalBoxFrameMaterializationError(
                "Gmsh orthogonal Box/Frame returned invalid element volumes"
            )
        element_volume = math.fsum(volumes)

    if not all(
        _cartesian_hex(nodes, local_coordinates, tolerance=tolerance)
        for _tag, nodes in element_rows
    ):
        raise OrthogonalBoxFrameMaterializationError(
            "Gmsh orthogonal Box/Frame result contains a non-Cartesian HEX8"
        )
    boundary_faces, incidence = _boundary_faces(element_rows)
    boundary: dict[str, list[tuple[int, ...]]] = defaultdict(list)
    for face in boundary_faces:
        boundary[
            _classify_boundary_face(
                face,
                local_coordinates,
                canonical_fragment,
                tolerance=tolerance,
            )
        ].append(face)

    source_edge_counts: Counter[tuple[int, int]] = Counter()
    for facet in source_facets:
        for first, second in zip(facet, (*facet[1:], facet[0])):
            source_edge_counts[tuple(sorted((first, second)))] += 1
    if any(value not in {1, 2} for value in source_edge_counts.values()):
        raise OrthogonalBoxFrameMaterializationError(
            "orthogonal source QUAD section is non-manifold"
        )
    source_boundary_edges = sum(
        value == 1 for value in source_edge_counts.values()
    )
    expected_boundary_faces = (
        2 * len(source_facets) + source_boundary_edges * layer_count
    )
    if len(boundary_faces) != expected_boundary_faces or (
        incidence.get(1, 0) != expected_boundary_faces
    ):
        raise OrthogonalBoxFrameMaterializationError(
            "orthogonal extrusion deleted or duplicated a peripheral boundary facet"
        )

    nodes_by_coordinate: dict[tuple[int, int, int], list[int]] = defaultdict(list)
    for node, point in local_coordinates.items():
        nodes_by_coordinate[
            tuple(round(value / tolerance) for value in point)
        ].append(node)
    locked_output: dict[str, tuple[tuple[int, ...], ...]] = {}
    for side, facets in locked_facets.items():
        remapped: list[tuple[int, ...]] = []
        for facet in facets:
            mapped: list[int] = []
            for source_node in facet:
                expected = locked_local[source_node]
                key = tuple(round(value / tolerance) for value in expected)
                candidates = tuple(
                    node
                    for node in nodes_by_coordinate.get(key, ())
                    if math.dist(local_coordinates[node], expected) <= tolerance
                )
                if len(candidates) != 1:
                    raise OrthogonalBoxFrameMaterializationError(
                        "Gmsh did not retain one exact node per locked QUAD node"
                    )
                mapped.append(candidates[0])
            remapped.append(tuple(mapped))
        expected_keys = {_face_key(value) for value in remapped}
        boundary_keys = {_face_key(value) for value in boundary.get(side, ())}
        # The lock owns the actual contact patch, not necessarily this entire
        # side. Exact face membership proves all locked nodes/connectivity;
        # the independent boundary-incidence and volume audits keep the rest.
        if not expected_keys or not expected_keys.issubset(boundary_keys):
            raise OrthogonalBoxFrameMaterializationError(
                f"locked {side!r} Orth partition is incompatible or "
                "was changed by Gmsh"
            )
        locked_output[side] = tuple(remapped)

    analytic_volume = _analytic_volume(bounds, opening)
    relative_volume_error = abs(element_volume - analytic_volume) / analytic_volume
    if relative_volume_error > 1.0e-9:
        raise OrthogonalBoxFrameMaterializationError(
            "orthogonal HEX volume does not equal analytic Box/Frame volume"
        )
    package_coordinates = {
        node: _to_package(point, canonical_fragment.placement)
        for node, point in local_coordinates.items()
    }
    component_fragment = ComponentLocalMeshFragment(
        canonical_fragment.fragment_id if fragment_key is None else fragment_key,
        requirement.component_id,
        material_name,
        tuple(
            ComponentMeshNode(
                node,
                package_coordinates[node],
                token_by_coordinate.get(
                    tuple(
                        round(value / tolerance)
                        for value in local_coordinates[node]
                    )
                ),
            )
            for node in sorted(package_coordinates)
        ),
        tuple(
            ComponentMeshElement(
                tag,
                5,
                nodes,
                "gmsh_orthogonal_hex_box_frame",
            )
            for tag, nodes in sorted(element_rows)
        ),
    )
    immutable_edges = {
        tuple(sorted((first, second)))
        for facets in locked_facets.values()
        for facet in facets
        for first, second in zip(facet, (*facet[1:], facet[0]))
    }
    immutable_edge_lengths = tuple(
        math.dist(locked_local[first], locked_local[second])
        for first, second in immutable_edges
    )
    return OrthogonalBoxFrameComponentMesh(
        canonical_fragment,
        requirement,
        component_fragment,
        MappingProxyType(dict(sorted(locked_output.items()))),
        MappingProxyType(
            {side: tuple(values) for side, values in sorted(boundary.items())}
        ),
        len(element_rows),
        len(boundary_faces),
        analytic_volume,
        element_volume,
        relative_volume_error,
        quality["minDetJac"],
        quality["minSICN"],
        quality["minSIGE"],
        quality["minSJ"],
        True,
        True,
        sum(
            length > requirement.target_edge_mm + tolerance
            for length in immutable_edge_lengths
        ),
        max(immutable_edge_lengths, default=0.0),
    )


def _cartesian_hex(
    nodes: Sequence[int],
    coordinates: Mapping[int, Point3D],
    *,
    tolerance: float,
) -> bool:
    points = tuple(coordinates[node] for node in nodes)
    levels = tuple(
        _cluster(tuple(point[axis] for point in points), tolerance)
        for axis in range(3)
    )
    if any(len(values) != 2 for values in levels):
        return False
    expected = {
        (x, y, z)
        for x in levels[0]
        for y in levels[1]
        for z in levels[2]
    }
    return len(expected) == 8 and all(
        any(math.dist(point, value) <= tolerance for value in expected)
        for point in points
    )


def materialize_orthogonal_box_frame_component(
    canonical_fragment: CanonicalGeometryFragment,
    requirement: ComponentMeshRequirement,
    *,
    orthogonal_strategy: OrthogonalHexMeshStrategy | None = None,
    material_name: str,
    fragment_key: str | None = None,
    locked_boundary_node_coordinates_package_mm: Mapping[
        int, Sequence[float]
    ] | None = None,
    locked_boundary_facets_by_geometric_side: Mapping[
        str, Sequence[Sequence[int]]
    ] | None = None,
    semantic_tokens_by_locked_node_id: Mapping[int, str] | None = None,
    contact_partition_points_package_mm=(),
    minimum_quality: float = _QUALITY_FLOOR,
    verbose: bool = False,
) -> OrthogonalBoxFrameComponentMesh:
    """Create a complete Gmsh-owned Cartesian HEX mesh without cell deletion."""

    if type(canonical_fragment) is not CanonicalGeometryFragment:
        raise OrthogonalBoxFrameMaterializationError(
            "canonical_fragment must be canonical geometry"
        )
    if type(requirement) is not ComponentMeshRequirement or (
        requirement.volume_topology != "orthogonal_hex"
    ):
        raise OrthogonalBoxFrameMaterializationError(
            "materializer requires orthogonal_hex topology"
        )
    if orthogonal_strategy is not None and type(
        orthogonal_strategy
    ) is not OrthogonalHexMeshStrategy:
        raise OrthogonalBoxFrameMaterializationError(
            "orthogonal_strategy must be an exact OrthogonalHexMeshStrategy"
        )
    if not isinstance(verbose, bool):
        raise OrthogonalBoxFrameMaterializationError("verbose must be boolean")
    if (
        isinstance(minimum_quality, bool)
        or not isinstance(minimum_quality, (int, float))
        or not math.isfinite(float(minimum_quality))
        or not _QUALITY_FLOOR <= float(minimum_quality) < 1.0
    ):
        raise OrthogonalBoxFrameMaterializationError(
            "minimum_quality must be finite, at least 0.03, and below one"
        )
    _require_axis_permutation(canonical_fragment.placement)
    if type(canonical_fragment.root) is CanonicalBox and orthogonal_strategy is not None:
        orthogonal_strategy.validate_single_box_sizes()
    bounds, opening = _bounds(canonical_fragment)
    x0, x1, y0, y1, z0, z1 = bounds
    tolerance = 1.0e-9 * max(1.0, *(abs(value) for value in bounds))

    if (locked_boundary_node_coordinates_package_mm is None) != (
        locked_boundary_facets_by_geometric_side is None
    ):
        raise OrthogonalBoxFrameMaterializationError(
            "locked boundary coordinates and facets must be supplied together"
        )
    locked_package: dict[int, Point3D] = {}
    locked_local: dict[int, Point3D] = {}
    locked_facets: dict[str, tuple[tuple[int, ...], ...]] = {}
    locked_tokens = (
        {}
        if semantic_tokens_by_locked_node_id is None
        else dict(semantic_tokens_by_locked_node_id)
    )
    if locked_boundary_node_coordinates_package_mm is not None:
        assert locked_boundary_facets_by_geometric_side is not None
        for node, raw_point in locked_boundary_node_coordinates_package_mm.items():
            try:
                point = tuple(float(value) for value in raw_point)
            except (TypeError, ValueError, OverflowError) as error:
                raise OrthogonalBoxFrameMaterializationError(
                    "locked boundary coordinate must contain finite x,y,z"
                ) from error
            if (
                isinstance(node, bool)
                or not isinstance(node, int)
                or node < 1
                or len(point) != 3
                or any(not math.isfinite(value) for value in point)
            ):
                raise OrthogonalBoxFrameMaterializationError(
                    "locked boundary coordinates are invalid"
                )
            locked_package[node] = point  # type: ignore[assignment]
            locked_local[node] = _to_local(
                point, canonical_fragment.placement  # type: ignore[arg-type]
            )
        for side, group in locked_boundary_facets_by_geometric_side.items():
            values = tuple(tuple(facet) for facet in group)
            if values:
                locked_facets[side] = values
        referenced = {
            node
            for group in locked_facets.values()
            for facet in group
            for node in facet
        }
        if referenced != set(locked_package) or set(locked_tokens) != referenced:
            raise OrthogonalBoxFrameMaterializationError(
                "every locked boundary node requires exactly one coordinate and token"
            )
    elif locked_tokens:
        raise OrthogonalBoxFrameMaterializationError(
            "locked semantic tokens require locked boundary geometry"
        )

    locked_sides = tuple(sorted(side for side, facets in locked_facets.items() if facets))
    locked_end_sides = tuple(
        side for side in ("bottom", "top") if locked_facets.get(side)
    )
    sizing = MeshSeedPolicy() if orthogonal_strategy is None else orthogonal_strategy.sizing
    partition_origin = (None if orthogonal_strategy is None else geometry_origin(
        canonical_fragment.root, sizing, orthogonal_strategy.partition_origin_mm))
    # Legacy jobs keep their explicit origin requirement; new presets resolve
    # independently of inherited tangential interfaces.
    if not locked_sides and orthogonal_strategy is not None and partition_origin is None:
        raise OrthogonalBoxFrameMaterializationError(
            "an unconstrained Orth Box/Frame requires partition_origin_mm or an origin preset")

    protected = _validate_locked_quads(
        canonical_fragment,
        locked_local,
        locked_facets,
        tolerance=tolerance,
    )
    x_features = (x0, x1) if opening is None else (x0, opening[0], opening[1], x1)
    y_features = (y0, y1) if opening is None else (y0, opening[2], opening[3], y1)
    contact_points = tuple(_to_local(tuple(p), canonical_fragment.placement) for p in contact_partition_points_package_mm)
    x_features += tuple(p[0] for p in contact_points if x0 < p[0] < x1)
    y_features += tuple(p[1] for p in contact_points if y0 < p[1] < y1)
    directional = (
        None
        if orthogonal_strategy is None
        else orthogonal_strategy.directional_near_edge_mm
    )
    # A face freezes only the axes in which its edges have nonzero span.
    free_origins = tuple(None if partition_origin is None else partition_origin[axis] for axis in range(3))
    visible_hole = (opening is not None and partition_origin is not None
                    and opening[0] < partition_origin[0] < opening[1]
                    and opening[2] < partition_origin[1] < opening[3])
    x_values = _partition_axis(
        x_features,
        tuple(point[0] for point in locked_local.values()),
        protected[0],
        requirement.target_edge_mm,
        tolerance=tolerance,
        partition_origin=free_origins[0],
        sizing=sizing,
        meeting_span=(opening[0:2] if visible_hole and free_origins[0] is not None else None),
        negative_target=(
            None
            if directional is None
            else directional[ComponentLocalDirection.NEGATIVE_X]
        ),
        positive_target=(
            None
            if directional is None
            else directional[ComponentLocalDirection.POSITIVE_X]
        ),
    )
    y_values = _partition_axis(
        y_features,
        tuple(point[1] for point in locked_local.values()),
        protected[1],
        requirement.target_edge_mm,
        tolerance=tolerance,
        partition_origin=free_origins[1],
        sizing=sizing,
        meeting_span=(opening[2:4] if visible_hole and free_origins[1] is not None else None),
        negative_target=(
            None
            if directional is None
            else directional[ComponentLocalDirection.NEGATIVE_Y]
        ),
        positive_target=(
            None
            if directional is None
            else directional[ComponentLocalDirection.POSITIVE_Y]
        ),
    )
    source_side = (
        "top"
        if locked_facets.get("top") and not locked_facets.get("bottom")
        else "bottom"
    )
    normal_z_target = requirement.target_edge_mm
    if directional is not None and locked_end_sides:
        normal_z_target = directional[
            ComponentLocalDirection.POSITIVE_Z
            if source_side == "bottom"
            else ComponentLocalDirection.NEGATIVE_Z
        ]
    z_values = _partition_axis(
        (z0, z1, *(p[2] for p in contact_points if z0 < p[2] < z1)),
        tuple(point[2] for point in locked_local.values()),
        protected[2],
        normal_z_target,
        tolerance=tolerance,
        partition_origin=free_origins[2],
        sizing=sizing,
        negative_target=(
            None
            if directional is None
            else directional[ComponentLocalDirection.NEGATIVE_Z]
        ),
        positive_target=(
            None
            if directional is None
            else directional[ComponentLocalDirection.POSITIVE_Z]
        ),
    )
    source_z = z1 if source_side == "top" else z0
    source_local, source_facets = _section_grid(
        x_values,
        y_values,
        source_z,
        opening,
    )
    token_by_coordinate = {
        tuple(round(value / tolerance) for value in point): locked_tokens[node]
        for node, point in locked_local.items()
    }
    try:
        return _gmsh_extrude_cartesian_section(
            canonical_fragment,
            requirement,
            source_local,
            source_facets,
            z_values,
            source_side=source_side,
            material_name=material_name,
            fragment_key=fragment_key,
            token_by_coordinate=token_by_coordinate,
            locked_local=locked_local,
            locked_facets=locked_facets,
            minimum_quality=minimum_quality,
            tolerance=tolerance,
            verbose=verbose,
        )
    except OrthogonalBoxFrameMaterializationError:
        raise
    except Exception as error:
        raise OrthogonalBoxFrameMaterializationError(
            f"Gmsh orthogonal Box/Frame extrusion failed: {error}"
        ) from error


__all__ = [
    "OrthogonalBoxFrameComponentMesh",
    "OrthogonalBoxFrameMaterializationError",
    "materialize_orthogonal_box_frame_component",
]
