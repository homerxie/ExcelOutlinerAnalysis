"""Immutable Package V2 worker requests and launch identities.

The GUI and CLI are allowed to assemble a request, but the worker remains the
authority that recompiles the embedded source and reloads every frozen
artifact.  This module gives both sides one canonical identity contract without
performing filesystem I/O or starting Gmsh.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Mapping, Sequence

from .output_artifacts import normalized_mesh_output
from .package_template import TEMPLATE_EVALUATOR_VERSION
from .package_v2_compile import PackageV2CompileResult
from .package_v2_frozen import FrozenSourceSnapshot
from .package_v2_source import MAX_JSON_NESTING, MAX_SOURCE_BYTES, parse_package_v2_json


PACKAGE_V2_LAUNCH_IDENTITY_SCHEMA = (
    "easymesh-package-v2-launch-identity-v1"
)
PACKAGE_V2_JOB_REQUEST_SCHEMA = "easymesh-package-v2-job-request-v1"
MAX_JOB_REQUEST_BYTES = 32 * 1024 * 1024
MAX_JOB_REQUEST_STRUCTURAL_TOKENS = 100_000
_MAX_JOB_REQUEST_NUMBER_CHARACTERS = 64

_ARTIFACT_ROLES = ("mesh",)
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_JOB_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_PORTABLE_VERSION = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+-]{0,127}$")
_WINDOWS_RESERVED_NAMES = frozenset(
    {"CON", "PRN", "AUX", "NUL"}
    | {f"COM{index}" for index in range(1, 10)}
    | {f"LPT{index}" for index in range(1, 10)}
)


class PackageV2JobError(ValueError):
    """Raised when a Package V2 launch identity or request is invalid."""


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _canonical_json(value: object) -> str:
    try:
        result = json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        result.encode("utf-8")
    except (OverflowError, TypeError, UnicodeEncodeError, ValueError) as error:
        raise PackageV2JobError("job evidence is not canonical UTF-8 JSON") from error
    return result


def _sha256_text(value: str) -> str:
    try:
        encoded = value.encode("utf-8")
    except UnicodeEncodeError as error:
        raise PackageV2JobError("job evidence is not valid Unicode text") from error
    return _sha256_bytes(encoded)


def _update_digest_record(digest: object, value: object) -> None:
    encoded = _canonical_json(value).encode("utf-8")
    digest.update(len(encoded).to_bytes(8, "big"))  # type: ignore[attr-defined]
    digest.update(encoded)  # type: ignore[attr-defined]


def _canonical_number(value: object, *, field_name: str) -> float:
    if isinstance(value, bool):
        raise PackageV2JobError(f"{field_name} must be a finite number")
    try:
        number = float(value)
    except (OverflowError, TypeError, ValueError) as error:
        raise PackageV2JobError(f"{field_name} must be a finite number") from error
    if not math.isfinite(number):
        raise PackageV2JobError(f"{field_name} must be a finite number")
    return 0.0 if number == 0.0 else number


def _nonempty_text(value: object, *, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip() or "\x00" in value:
        raise PackageV2JobError(f"{field_name} must be non-empty text")
    return value


def _sha256(value: object, *, field_name: str) -> str:
    if not isinstance(value, str) or not _SHA256.fullmatch(value):
        raise PackageV2JobError(
            f"{field_name} must be a lower-case SHA-256 digest"
        )
    return value


def _identifier(value: object, *, field_name: str) -> str:
    if not isinstance(value, str) or not _IDENTIFIER.fullmatch(value):
        raise PackageV2JobError(f"{field_name} must be an ASCII identifier")
    return value


def _artifact_declaration(value: object) -> str:
    text = _nonempty_text(value, field_name="artifact pin declaration")
    path = PurePosixPath(text)
    if (
        "\\" in text
        or ":" in text
        or any(character in '<>"|?*' for character in text)
        or any(ord(character) < 32 for character in text)
        or path.is_absolute()
        or str(path) != text
        or any(part in ("", ".", "..") for part in path.parts)
    ):
        raise PackageV2JobError(
            "artifact pin declaration must be a normalized relative POSIX path"
        )
    for part in path.parts:
        stem = unicodedata.normalize("NFKC", part.split(".", 1)[0]).upper()
        if part.endswith((" ", ".")) or stem in _WINDOWS_RESERVED_NAMES:
            raise PackageV2JobError(
                "artifact pin declaration is not portable to Windows"
            )
    return text


def _nonnegative_integer(value: object, *, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise PackageV2JobError(f"{field_name} must be a non-negative integer")
    return value


def _absolute_path(value: object, *, field_name: str) -> str:
    text = _nonempty_text(value, field_name=field_name)
    try:
        path = Path(text).expanduser()
        if not path.is_absolute():
            raise PackageV2JobError(f"{field_name} must be absolute")
        resolved = str(path.resolve())
    except PackageV2JobError:
        raise
    except (TypeError, ValueError, OSError) as error:
        raise PackageV2JobError(f"{field_name} is not a valid path") from error
    except RuntimeError as error:
        raise PackageV2JobError(f"{field_name} cannot be resolved") from error
    if resolved != text:
        raise PackageV2JobError(f"{field_name} must be a canonical absolute path")
    return resolved


def _strict_tuple(
    value: object,
    expected_type: type[object],
    *,
    field_name: str,
) -> tuple[object, ...]:
    if type(value) is not tuple:
        raise PackageV2JobError(f"{field_name} must be a tuple")
    if any(type(item) is not expected_type for item in value):
        raise PackageV2JobError(
            f"{field_name} must contain only {expected_type.__name__} values"
        )
    return value


@dataclass(frozen=True, slots=True, order=True)
class PackageV2ArtifactPin:
    """Portable content identity for one frozen dependency artifact."""

    role: str
    declaration: str
    size_bytes: int
    sha256: str

    def __post_init__(self) -> None:
        if self.role not in _ARTIFACT_ROLES:
            raise PackageV2JobError("artifact pin role is invalid")
        object.__setattr__(
            self,
            "declaration",
            _artifact_declaration(self.declaration),
        )
        object.__setattr__(
            self,
            "size_bytes",
            _nonnegative_integer(
                self.size_bytes,
                field_name="artifact pin size_bytes",
            ),
        )
        object.__setattr__(
            self,
            "sha256",
            _sha256(self.sha256, field_name="artifact pin sha256"),
        )

    def to_jsonable(self) -> dict[str, object]:
        return {
            "role": self.role,
            "declaration": self.declaration,
            "size_bytes": self.size_bytes,
            "sha256": self.sha256,
        }


@dataclass(frozen=True, slots=True, order=True)
class PackageV2FrozenSourcePin:
    """Portable identity of one complete frozen Source snapshot."""

    source_id: str
    snapshot_content_sha256: str
    artifacts: tuple[PackageV2ArtifactPin, ...]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "source_id",
            _identifier(self.source_id, field_name="frozen pin source_id"),
        )
        object.__setattr__(
            self,
            "snapshot_content_sha256",
            _sha256(
                self.snapshot_content_sha256,
                field_name="frozen pin snapshot_content_sha256",
            ),
        )
        artifacts = _strict_tuple(
            self.artifacts,
            PackageV2ArtifactPin,
            field_name="frozen pin artifacts",
        )
        ordered = tuple(sorted(artifacts, key=lambda item: item.role))
        if tuple(item.role for item in ordered) != tuple(sorted(_ARTIFACT_ROLES)):
            raise PackageV2JobError(
                "frozen pin must contain exactly one mesh identity"
            )
        object.__setattr__(self, "artifacts", ordered)

    def to_jsonable(self) -> dict[str, object]:
        return {
            "source_id": self.source_id,
            "snapshot_content_sha256": self.snapshot_content_sha256,
            "artifacts": [value.to_jsonable() for value in self.artifacts],
        }


@dataclass(frozen=True, slots=True)
class PackageV2RuntimeProfile:
    """Trusted worker implementation and dependency versions."""

    profile_id: str
    implementation_version: str
    gmsh_version: str
    frozen_import_version: str

    def __post_init__(self) -> None:
        for field_name in (
            "profile_id",
            "implementation_version",
            "gmsh_version",
            "frozen_import_version",
        ):
            value = getattr(self, field_name)
            if not isinstance(value, str) or not _PORTABLE_VERSION.fullmatch(value):
                raise PackageV2JobError(
                    f"{field_name} must be a portable ASCII version token"
                )
            object.__setattr__(self, field_name, value)

    def to_jsonable(self) -> dict[str, str]:
        return {
            "profile_id": self.profile_id,
            "implementation_version": self.implementation_version,
            "gmsh_version": self.gmsh_version,
            "frozen_import_version": self.frozen_import_version,
        }


@dataclass(frozen=True, slots=True)
class PackageV2LaunchIdentity:
    """Semantic launch identity independent of runtime path spelling."""

    raw_source_sha256: str
    plan_sha256: str
    evaluator_version: str
    runtime_profile: PackageV2RuntimeProfile
    frozen_sources: tuple[PackageV2FrozenSourcePin, ...] = ()
    canonical_json: str = field(init=False, repr=False)
    sha256: str = field(init=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "raw_source_sha256",
            _sha256(self.raw_source_sha256, field_name="raw_source_sha256"),
        )
        object.__setattr__(
            self,
            "plan_sha256",
            _sha256(self.plan_sha256, field_name="plan_sha256"),
        )
        if (
            not isinstance(self.evaluator_version, str)
            or not _PORTABLE_VERSION.fullmatch(self.evaluator_version)
        ):
            raise PackageV2JobError(
                "evaluator_version must be a portable ASCII version token"
            )
        if type(self.runtime_profile) is not PackageV2RuntimeProfile:
            raise PackageV2JobError(
                "runtime_profile must be a PackageV2RuntimeProfile"
            )
        sources = _strict_tuple(
            self.frozen_sources,
            PackageV2FrozenSourcePin,
            field_name="frozen_sources",
        )
        ordered = tuple(sorted(sources, key=lambda item: item.source_id))
        if len({value.source_id for value in ordered}) != len(ordered):
            raise PackageV2JobError("frozen Source pins must have unique IDs")
        object.__setattr__(self, "frozen_sources", ordered)
        canonical = _canonical_json(self.to_jsonable(include_sha256=False))
        object.__setattr__(self, "canonical_json", canonical)
        object.__setattr__(self, "sha256", _sha256_text(canonical))

    def to_jsonable(self, *, include_sha256: bool = True) -> dict[str, object]:
        payload: dict[str, object] = {
            "schema": PACKAGE_V2_LAUNCH_IDENTITY_SCHEMA,
            "raw_source_sha256": self.raw_source_sha256,
            "plan_sha256": self.plan_sha256,
            "evaluator_version": self.evaluator_version,
            "runtime_profile": self.runtime_profile.to_jsonable(),
            "frozen_sources": [
                value.to_jsonable() for value in self.frozen_sources
            ],
        }
        if include_sha256:
            payload["sha256"] = self.sha256
        return payload


@dataclass(frozen=True, slots=True, order=True)
class PackageV2RuntimeDependency:
    """Runtime path paired with one portable artifact pin."""

    source_id: str
    role: str
    declaration: str
    runtime_path: str
    size_bytes: int
    sha256: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "source_id",
            _identifier(
                self.source_id,
                field_name="runtime dependency source_id",
            ),
        )
        pin = PackageV2ArtifactPin(
            self.role,
            self.declaration,
            self.size_bytes,
            self.sha256,
        )
        object.__setattr__(self, "role", pin.role)
        object.__setattr__(self, "declaration", pin.declaration)
        object.__setattr__(self, "size_bytes", pin.size_bytes)
        object.__setattr__(self, "sha256", pin.sha256)
        object.__setattr__(
            self,
            "runtime_path",
            _absolute_path(
                self.runtime_path,
                field_name="runtime dependency path",
            ),
        )

    @property
    def pin(self) -> PackageV2ArtifactPin:
        return PackageV2ArtifactPin(
            self.role,
            self.declaration,
            self.size_bytes,
            self.sha256,
        )

    def to_jsonable(self) -> dict[str, object]:
        return {
            "source_id": self.source_id,
            "role": self.role,
            "declaration": self.declaration,
            "runtime_path": self.runtime_path,
            "size_bytes": self.size_bytes,
            "sha256": self.sha256,
        }


@dataclass(frozen=True, slots=True)
class PackageV2JobRequest:
    """Complete immutable request passed to a Package V2 worker."""

    job_id: str
    source_name: str
    source_text: str
    source_root: str | None
    output_mesh_path: str
    launch_identity: PackageV2LaunchIdentity
    runtime_dependencies: tuple[PackageV2RuntimeDependency, ...] = ()
    canonical_json: str = field(init=False, repr=False)
    sha256: str = field(init=False)

    def __post_init__(self) -> None:
        if not isinstance(self.job_id, str) or not _JOB_ID.fullmatch(self.job_id):
            raise PackageV2JobError("job_id is invalid")
        object.__setattr__(
            self,
            "source_name",
            _nonempty_text(self.source_name, field_name="source_name"),
        )
        if not isinstance(self.source_text, str) or "\x00" in self.source_text:
            raise PackageV2JobError("source_text must be text without NUL")
        try:
            source_bytes = self.source_text.encode("utf-8")
        except UnicodeEncodeError as error:
            raise PackageV2JobError("source_text is not valid Unicode") from error
        if len(source_bytes) > MAX_SOURCE_BYTES:
            raise PackageV2JobError("source_text exceeds the Package V2 limit")
        if type(self.launch_identity) is not PackageV2LaunchIdentity:
            raise PackageV2JobError(
                "launch_identity must be a PackageV2LaunchIdentity"
            )
        if _sha256_bytes(source_bytes) != self.launch_identity.raw_source_sha256:
            raise PackageV2JobError(
                "source_text does not match the launch raw source identity"
            )
        root = self.source_root
        if root is not None:
            root = _absolute_path(root, field_name="source_root")
        if self.launch_identity.frozen_sources and root is None:
            raise PackageV2JobError(
                "source_root is required when frozen dependencies exist"
            )
        object.__setattr__(self, "source_root", root)
        output = _absolute_path(
            self.output_mesh_path,
            field_name="output_mesh_path",
        )
        if Path(output).suffix != ".msh":
            raise PackageV2JobError("output_mesh_path must end in lower-case .msh")
        object.__setattr__(self, "output_mesh_path", output)
        dependencies = _strict_tuple(
            self.runtime_dependencies,
            PackageV2RuntimeDependency,
            field_name="runtime_dependencies",
        )
        ordered = tuple(
            sorted(dependencies, key=lambda item: (item.source_id, item.role))
        )
        if len({(item.source_id, item.role) for item in ordered}) != len(ordered):
            raise PackageV2JobError("runtime dependency identities must be unique")
        expected = {
            (source.source_id, artifact.role): artifact
            for source in self.launch_identity.frozen_sources
            for artifact in source.artifacts
        }
        actual = {
            (value.source_id, value.role): value.pin for value in ordered
        }
        if actual != expected:
            raise PackageV2JobError(
                "runtime dependencies do not match the launch artifact pins"
            )
        if any(value.runtime_path == output for value in ordered):
            raise PackageV2JobError(
                "output_mesh_path must not equal a frozen dependency path"
            )
        object.__setattr__(self, "runtime_dependencies", ordered)
        canonical = _canonical_json(self.to_jsonable(include_sha256=False))
        encoded = canonical.encode("utf-8")
        if len(encoded) > MAX_JOB_REQUEST_BYTES:
            raise PackageV2JobError("job request exceeds the byte limit")
        _preflight_json_structure(canonical)
        object.__setattr__(self, "canonical_json", canonical)
        object.__setattr__(self, "sha256", _sha256_bytes(encoded))
        transport = _canonical_json(self.to_jsonable()).encode("utf-8")
        if len(transport) > MAX_JOB_REQUEST_BYTES:
            raise PackageV2JobError("job request exceeds the byte limit")
        _preflight_json_structure(transport.decode("utf-8"))
        try:
            parse_package_v2_json(source_bytes, source_name=self.source_name)
        except ValueError as error:
            raise PackageV2JobError(f"Job requires a valid current Source: {error}") from error

    def to_jsonable(self, *, include_sha256: bool = True) -> dict[str, object]:
        payload: dict[str, object] = {
            "schema": PACKAGE_V2_JOB_REQUEST_SCHEMA,
            "job_id": self.job_id,
            "source_name": self.source_name,
            "source_text": self.source_text,
            "source_root": self.source_root,
            "output_mesh_path": self.output_mesh_path,
            "launch_identity": self.launch_identity.to_jsonable(),
            "runtime_dependencies": [
                value.to_jsonable() for value in self.runtime_dependencies
            ],
        }
        if include_sha256:
            payload["sha256"] = self.sha256
        return payload


def _snapshot_pin(
    compiled_source: object,
    snapshot: FrozenSourceSnapshot,
) -> tuple[PackageV2FrozenSourcePin, tuple[PackageV2RuntimeDependency, ...]]:
    source_id = getattr(compiled_source, "source_id", None)
    if source_id != snapshot.source_id:
        raise PackageV2JobError("compiled and loaded frozen Source IDs differ")
    if getattr(compiled_source, "placement", None) != snapshot.placement:
        raise PackageV2JobError("frozen Source placement changed after compilation")
    compiled_artifacts = getattr(compiled_source, "artifacts", None)
    declarations = dict(getattr(compiled_artifacts, "declarations", {}))
    runtime_paths = dict(getattr(compiled_artifacts, "runtime_paths", {}))
    if set(snapshot.artifacts) != set(_ARTIFACT_ROLES):
        raise PackageV2JobError("loaded frozen Source mesh artifact is missing")
    pins: list[PackageV2ArtifactPin] = []
    runtime: list[PackageV2RuntimeDependency] = []
    for role in _ARTIFACT_ROLES:
        identity = snapshot.artifacts[role]
        expected_sha256 = getattr(compiled_artifacts, "sha256", None)
        if expected_sha256 is not None and identity.sha256 != expected_sha256:
            raise PackageV2JobError("网格文件内容与工程记录的指纹不一致")
        if identity.role != role:
            raise PackageV2JobError("loaded frozen artifact role is inconsistent")
        if declarations.get(role) != identity.declaration:
            raise PackageV2JobError(
                "loaded frozen artifact declaration changed after compilation"
            )
        compiled_path = runtime_paths.get(role)
        if compiled_path is None or str(Path(compiled_path).resolve()) != str(
            Path(identity.runtime_path).resolve()
        ):
            raise PackageV2JobError(
                "loaded frozen artifact runtime path changed after compilation"
            )
        pin = PackageV2ArtifactPin(
            role,
            identity.declaration,
            identity.size_bytes,
            identity.sha256,
        )
        pins.append(pin)
        runtime.append(
            PackageV2RuntimeDependency(
                source_id,
                role,
                identity.declaration,
                str(Path(identity.runtime_path).resolve()),
                identity.size_bytes,
                identity.sha256,
            )
        )
    return (
        PackageV2FrozenSourcePin(
            source_id,
            _snapshot_content_sha256(snapshot, tuple(pins)),
            tuple(pins),
        ),
        tuple(runtime),
    )


def _snapshot_content_sha256(
    snapshot: FrozenSourceSnapshot,
    artifact_pins: tuple[PackageV2ArtifactPin, ...],
) -> str:
    """Return a path-neutral digest of one fully audited frozen snapshot."""

    digest = hashlib.sha256()
    _update_digest_record(
        digest,
        {
            "schema": "easymesh-package-v2-frozen-content-pin-v2",
            "source_id": snapshot.source_id,
            "placement": {
                "translation_xyz_mm": [
                    _canonical_number(value, field_name="frozen translation")
                    for value in snapshot.placement.translation_xyz_mm
                ],
                "rotation_matrix": [
                    [
                        _canonical_number(value, field_name="frozen rotation")
                        for value in row
                    ]
                    for row in snapshot.placement.rotation_matrix
                ],
            },
            "artifacts": [value.to_jsonable() for value in artifact_pins],
            "node_count": snapshot.node_count,
            "element_count": snapshot.element_count,
            "preflight_estimated_memory_bytes": (
                snapshot.preflight_estimated_memory_bytes
            ),
            "element_kind_counts": dict(
                sorted(snapshot.element_kind_counts.items())
            ),
            "dimensional_element_counts": list(
                snapshot.mesh.dimensional_element_counts
            ),
            "minimum_jacobian_determinant": _canonical_number(
                snapshot.mesh.min_jacobian_determinant,
                field_name="frozen mesh minimum Jacobian",
            ),
        },
    )
    for node in snapshot.mesh.nodes:
        _update_digest_record(
            digest,
            [
                "node",
                node.tag,
                _canonical_number(node.x, field_name="frozen node x"),
                _canonical_number(node.y, field_name="frozen node y"),
                _canonical_number(node.z, field_name="frozen node z"),
            ],
        )
    for element in snapshot.mesh.elements:
        _update_digest_record(
            digest,
            [
                "element",
                element.tag,
                element.kind.value,
                element.gmsh_type,
                list(element.node_tags),
                element.entity_tag,
                [
                    [group.tag, group.name, group.explicitly_named]
                    for group in element.physical_groups
                ],
                _canonical_number(
                    element.min_jacobian_determinant,
                    field_name="frozen element minimum Jacobian",
                ),
            ],
        )
    for entity_tag, groups in sorted(snapshot.mesh.entity_physical_groups.items()):
        _update_digest_record(
            digest,
            [
                "entity_physical_groups",
                entity_tag,
                [
                    [group.tag, group.name, group.explicitly_named]
                    for group in groups
                ],
            ],
        )
    for local_id, value in sorted(snapshot.components.items()):
        _update_digest_record(
            digest,
            {
                "component": local_id,
                "local_component_id": value.local_component_id,
                "global_component_id": value.global_component_id,
                "physical_group_tag": value.physical_group_tag,
                "element_count": value.element_count,
                "node_count": value.node_count,
                "element_kind_counts": dict(
                    sorted(value.element_kind_counts.items())
                ),
                "node_numbered_sha256": value.node_numbered_sha256,
                "element_numbered_sha256": value.element_numbered_sha256,
                "numbered_sha256": value.numbered_sha256,
            },
        )
        for node_tag in value.node_tags:
            _update_digest_record(digest, ["component_node", local_id, node_tag])
        for element_tag in value.element_tags:
            _update_digest_record(
                digest,
                ["component_element", local_id, element_tag],
            )
    return digest.hexdigest()


def build_package_v2_launch_identity(
    compiled: PackageV2CompileResult,
    snapshots: Sequence[FrozenSourceSnapshot],
    *,
    runtime_profile: PackageV2RuntimeProfile,
) -> PackageV2LaunchIdentity:
    """Bind one pure plan to exact frozen artifacts and mesher policy."""

    if type(compiled) is not PackageV2CompileResult:
        raise PackageV2JobError("compiled must be a PackageV2CompileResult")
    if isinstance(snapshots, (str, bytes)):
        raise PackageV2JobError("snapshots must be a sequence")
    try:
        snapshot_values = tuple(snapshots)
    except TypeError as error:
        raise PackageV2JobError("snapshots must be a sequence") from error
    if any(type(value) is not FrozenSourceSnapshot for value in snapshot_values):
        raise PackageV2JobError(
            "snapshots must contain only FrozenSourceSnapshot values"
        )
    by_id = {value.source_id: value for value in snapshot_values}
    if len(by_id) != len(snapshot_values):
        raise PackageV2JobError("snapshot Source IDs must be unique")
    compiled_by_id = compiled.frozen_source_by_id
    if set(by_id) != set(compiled_by_id):
        raise PackageV2JobError(
            "snapshot Source IDs do not match the compiled frozen Sources"
        )
    pins = tuple(
        _snapshot_pin(compiled_by_id[source_id], by_id[source_id])[0]
        for source_id in sorted(by_id)
    )
    return PackageV2LaunchIdentity(
        compiled.raw_source_digest,
        compiled.plan_digest,
        TEMPLATE_EVALUATOR_VERSION,
        runtime_profile,
        pins,
    )


def build_package_v2_job_request(
    compiled: PackageV2CompileResult,
    snapshots: Sequence[FrozenSourceSnapshot],
    *,
    job_id: str,
    output_mesh_path: str | os.PathLike[str],
    source_root: str | os.PathLike[str] | None,
    runtime_profile: PackageV2RuntimeProfile,
) -> PackageV2JobRequest:
    """Create a complete request without rereading source or artifact files."""

    try:
        snapshot_values = tuple(snapshots)
    except TypeError as error:
        raise PackageV2JobError("snapshots must be a sequence") from error
    launch = build_package_v2_launch_identity(
        compiled,
        snapshot_values,
        runtime_profile=runtime_profile,
    )
    by_id = {value.source_id: value for value in snapshot_values}
    runtime: list[PackageV2RuntimeDependency] = []
    for source_id in sorted(compiled.frozen_source_by_id):
        runtime.extend(
            _snapshot_pin(
                compiled.frozen_source_by_id[source_id],
                by_id[source_id],
            )[1]
        )
    try:
        root = (
            None
            if source_root is None
            else str(Path(source_root).expanduser().resolve())
        )
        output = normalized_mesh_output(output_mesh_path)
    except (OSError, RuntimeError, TypeError, ValueError) as error:
        raise PackageV2JobError("job request paths cannot be resolved") from error
    return PackageV2JobRequest(
        job_id,
        compiled.parsed_source.source_name,
        compiled.parsed_source.raw_text,
        root,
        str(output),
        launch,
        tuple(runtime),
    )


def verify_package_v2_job_request(
    request: PackageV2JobRequest,
    compiled: PackageV2CompileResult,
    snapshots: Sequence[FrozenSourceSnapshot],
    *,
    expected_runtime_profile: PackageV2RuntimeProfile,
) -> None:
    """Recompute worker-side evidence and reject any stale request."""

    if type(request) is not PackageV2JobRequest:
        raise PackageV2JobError("request must be a PackageV2JobRequest")
    try:
        snapshot_values = tuple(snapshots)
    except TypeError as error:
        raise PackageV2JobError("snapshots must be a sequence") from error
    if any(type(value) is not FrozenSourceSnapshot for value in snapshot_values):
        raise PackageV2JobError(
            "snapshots must contain only FrozenSourceSnapshot values"
        )
    if type(expected_runtime_profile) is not PackageV2RuntimeProfile:
        raise PackageV2JobError(
            "expected_runtime_profile must be a PackageV2RuntimeProfile"
        )
    try:
        source_bytes = request.source_text.encode("utf-8")
    except UnicodeEncodeError as error:
        raise PackageV2JobError("request source_text is not valid Unicode") from error
    if source_bytes != compiled.parsed_source.raw_bytes:
        raise PackageV2JobError("worker source bytes differ from the request")
    if request.source_name != compiled.parsed_source.source_name:
        raise PackageV2JobError("worker source name differs from the request")
    rebuilt = build_package_v2_launch_identity(
        compiled,
        snapshot_values,
        runtime_profile=expected_runtime_profile,
    )
    if rebuilt.sha256 != request.launch_identity.sha256:
        raise PackageV2JobError("Package V2 job request is stale")
    runtime = {
        (value.source_id, value.role): value
        for value in request.runtime_dependencies
    }
    for snapshot in snapshot_values:
        for role, identity in snapshot.artifacts.items():
            key = (snapshot.source_id, role)
            value = runtime.get(key)
            if value is None or (
                value.runtime_path != str(Path(identity.runtime_path).resolve())
                or value.size_bytes != identity.size_bytes
                or value.sha256 != identity.sha256
                or value.declaration != identity.declaration
            ):
                raise PackageV2JobError(
                    "worker frozen dependencies differ from the request"
                )


class _Pairs(list[tuple[str, object]]):
    pass


def _pairs_hook(value: list[tuple[str, object]]) -> _Pairs:
    return _Pairs(value)


def _parse_json_integer(value: str) -> int:
    if len(value) > _MAX_JOB_REQUEST_NUMBER_CHARACTERS:
        raise PackageV2JobError("job request integer token is too long")
    try:
        return int(value)
    except (OverflowError, ValueError) as error:
        raise PackageV2JobError("job request integer token is invalid") from error


def _parse_json_float(value: str) -> float:
    if len(value) > _MAX_JOB_REQUEST_NUMBER_CHARACTERS:
        raise PackageV2JobError("job request number token is too long")
    try:
        result = float(value)
    except (OverflowError, ValueError) as error:
        raise PackageV2JobError("job request number token is invalid") from error
    if not math.isfinite(result):
        raise PackageV2JobError("job request number token is not finite")
    return result


def _materialize(value: object, *, depth: int = 0) -> object:
    if depth > MAX_JSON_NESTING:
        raise PackageV2JobError("job request JSON nesting is too deep")
    if type(value) is _Pairs:
        output: dict[str, object] = {}
        for key, item in value:
            if key in output:
                raise PackageV2JobError(f"duplicate job request key {key!r}")
            output[key] = _materialize(item, depth=depth + 1)
        return output
    if type(value) is list:
        return [_materialize(item, depth=depth + 1) for item in value]
    if value is None or type(value) in (bool, int, float, str):
        if isinstance(value, float) and not math.isfinite(value):
            raise PackageV2JobError("job request contains a non-finite number")
        return value
    raise PackageV2JobError("job request contains an unsupported JSON value")


def _preflight_json_structure(text: str) -> None:
    """Bound container work before the standard decoder allocates an object tree."""

    in_string = False
    escaped = False
    depth = 0
    token_count = 0
    for character in text:
        if in_string:
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == '"':
                in_string = False
            continue
        if character == '"':
            in_string = True
            continue
        if character in "[{":
            depth += 1
            token_count += 1
            if depth > MAX_JSON_NESTING:
                raise PackageV2JobError("job request JSON nesting is too deep")
        elif character in "]}":
            depth -= 1
            token_count += 1
            if depth < 0:
                break
        elif character in ",:":
            token_count += 1
        if token_count > MAX_JOB_REQUEST_STRUCTURAL_TOKENS:
            raise PackageV2JobError(
                "job request exceeds the structural token limit"
            )


def _mapping(value: object, *, field_name: str) -> Mapping[str, object]:
    if type(value) is not dict:
        raise PackageV2JobError(f"{field_name} must be an object")
    return value


def _array(value: object, *, field_name: str) -> list[object]:
    if type(value) is not list:
        raise PackageV2JobError(f"{field_name} must be an array")
    return value


def _exact_keys(
    value: Mapping[str, object],
    expected: frozenset[str],
    *,
    field_name: str,
) -> None:
    if set(value) != set(expected):
        raise PackageV2JobError(f"{field_name} fields are incomplete or unknown")


def _parse_artifact_pin(value: object) -> PackageV2ArtifactPin:
    item = _mapping(value, field_name="artifact pin")
    _exact_keys(
        item,
        frozenset(("role", "declaration", "size_bytes", "sha256")),
        field_name="artifact pin",
    )
    return PackageV2ArtifactPin(
        item["role"],  # type: ignore[arg-type]
        item["declaration"],  # type: ignore[arg-type]
        item["size_bytes"],  # type: ignore[arg-type]
        item["sha256"],  # type: ignore[arg-type]
    )


def _parse_frozen_pin(value: object) -> PackageV2FrozenSourcePin:
    item = _mapping(value, field_name="frozen Source pin")
    _exact_keys(
        item,
        frozenset(("source_id", "snapshot_content_sha256", "artifacts")),
        field_name="frozen Source pin",
    )
    artifacts = tuple(
        _parse_artifact_pin(raw)
        for raw in _array(item["artifacts"], field_name="artifact pins")
    )
    return PackageV2FrozenSourcePin(
        item["source_id"],  # type: ignore[arg-type]
        item["snapshot_content_sha256"],  # type: ignore[arg-type]
        artifacts,
    )


def _parse_runtime_profile(value: object) -> PackageV2RuntimeProfile:
    item = _mapping(value, field_name="runtime_profile")
    _exact_keys(
        item,
        frozenset(
            (
                "profile_id",
                "implementation_version",
                "gmsh_version",
                "frozen_import_version",
            )
        ),
        field_name="runtime_profile",
    )
    return PackageV2RuntimeProfile(
        item["profile_id"],  # type: ignore[arg-type]
        item["implementation_version"],  # type: ignore[arg-type]
        item["gmsh_version"],  # type: ignore[arg-type]
        item["frozen_import_version"],  # type: ignore[arg-type]
    )


def _parse_launch_identity(value: object) -> PackageV2LaunchIdentity:
    item = _mapping(value, field_name="launch_identity")
    _exact_keys(
        item,
        frozenset(
            (
                "schema",
                "raw_source_sha256",
                "plan_sha256",
                "evaluator_version",
                "runtime_profile",
                "frozen_sources",
                "sha256",
            )
        ),
        field_name="launch_identity",
    )
    if item["schema"] != PACKAGE_V2_LAUNCH_IDENTITY_SCHEMA:
        raise PackageV2JobError("unsupported launch identity schema")
    sources = tuple(
        _parse_frozen_pin(raw)
        for raw in _array(item["frozen_sources"], field_name="frozen_sources")
    )
    identity = PackageV2LaunchIdentity(
        item["raw_source_sha256"],  # type: ignore[arg-type]
        item["plan_sha256"],  # type: ignore[arg-type]
        item["evaluator_version"],  # type: ignore[arg-type]
        _parse_runtime_profile(item["runtime_profile"]),
        sources,
    )
    if item["sha256"] != identity.sha256:
        raise PackageV2JobError("launch identity SHA-256 is stale")
    return identity


def _parse_runtime_dependency(value: object) -> PackageV2RuntimeDependency:
    item = _mapping(value, field_name="runtime dependency")
    _exact_keys(
        item,
        frozenset(
            (
                "source_id",
                "role",
                "declaration",
                "runtime_path",
                "size_bytes",
                "sha256",
            )
        ),
        field_name="runtime dependency",
    )
    return PackageV2RuntimeDependency(
        item["source_id"],  # type: ignore[arg-type]
        item["role"],  # type: ignore[arg-type]
        item["declaration"],  # type: ignore[arg-type]
        item["runtime_path"],  # type: ignore[arg-type]
        item["size_bytes"],  # type: ignore[arg-type]
        item["sha256"],  # type: ignore[arg-type]
    )


def parse_package_v2_job_request(data: bytes) -> PackageV2JobRequest:
    """Parse one strict, bounded canonical-compatible request document."""

    if not isinstance(data, bytes):
        raise PackageV2JobError("job request input must be bytes")
    if len(data) > MAX_JOB_REQUEST_BYTES:
        raise PackageV2JobError("job request exceeds the byte limit")
    try:
        text = data.decode("utf-8", errors="strict")
    except UnicodeDecodeError as error:
        raise PackageV2JobError("job request is not valid UTF-8") from error
    _preflight_json_structure(text)
    try:
        raw = json.loads(
            text,
            object_pairs_hook=_pairs_hook,
            parse_int=_parse_json_integer,
            parse_float=_parse_json_float,
            parse_constant=lambda value: (_ for _ in ()).throw(
                PackageV2JobError(
                    f"job request contains non-finite token {value!r}"
                )
            ),
        )
    except json.JSONDecodeError as error:
        raise PackageV2JobError(f"invalid job request JSON: {error.msg}") from error
    except RecursionError as error:
        raise PackageV2JobError("job request JSON nesting is too deep") from error
    except ValueError as error:
        raise PackageV2JobError("job request contains an invalid number") from error
    root = _mapping(_materialize(raw), field_name="job request")
    _exact_keys(
        root,
        frozenset(
            (
                "schema",
                "job_id",
                "source_name",
                "source_text",
                "source_root",
                "output_mesh_path",
                "launch_identity",
                "runtime_dependencies",
                "sha256",
            )
        ),
        field_name="job request",
    )
    if root["schema"] != PACKAGE_V2_JOB_REQUEST_SCHEMA:
        raise PackageV2JobError("unsupported Package V2 job request schema")
    dependencies = tuple(
        _parse_runtime_dependency(raw_value)
        for raw_value in _array(
            root["runtime_dependencies"],
            field_name="runtime_dependencies",
        )
    )
    request = PackageV2JobRequest(
        root["job_id"],  # type: ignore[arg-type]
        root["source_name"],  # type: ignore[arg-type]
        root["source_text"],  # type: ignore[arg-type]
        root["source_root"],  # type: ignore[arg-type]
        root["output_mesh_path"],  # type: ignore[arg-type]
        _parse_launch_identity(root["launch_identity"]),
        dependencies,
    )
    if root["sha256"] != request.sha256:
        raise PackageV2JobError("job request SHA-256 is stale")
    return request


__all__ = [
    "MAX_JOB_REQUEST_BYTES",
    "MAX_JOB_REQUEST_STRUCTURAL_TOKENS",
    "PACKAGE_V2_JOB_REQUEST_SCHEMA",
    "PACKAGE_V2_LAUNCH_IDENTITY_SCHEMA",
    "PackageV2ArtifactPin",
    "PackageV2FrozenSourcePin",
    "PackageV2JobError",
    "PackageV2JobRequest",
    "PackageV2LaunchIdentity",
    "PackageV2RuntimeDependency",
    "PackageV2RuntimeProfile",
    "build_package_v2_job_request",
    "build_package_v2_launch_identity",
    "parse_package_v2_job_request",
    "verify_package_v2_job_request",
]
