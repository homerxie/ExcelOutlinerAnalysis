"""OCC-backed TET4/PYRAMID5 fill behind immutable box interfaces.

The caller owns one rectangular TRI3/QUAD4 docking partition.  This module
uses an OCC box only for the five non-docking exterior faces, installs the
caller's exact one-dimensional perimeter mesh on the four docking curves,
then replaces the temporary docking-face mesh with the caller's facets.
Gmsh's classic 3-D Delaunay algorithm can consequently place one PYRAMID5
behind every QUAD4 and one TET4 behind every TRI3 while coarsening freely in
X, Y and Z away from the interface.  Optional rectangular partitions on the
four vertical box sides are imprinted into the OCC boundary and replaced by
the caller's exact UF-contact facets through the same locked-surface contract.

Gmsh is allowed to renumber temporary nodes during boundary reconstruction.
The returned pure-data plan therefore restores caller ownership by exact
coordinate/facet matching; no Gmsh node tag is treated as an interface ID.
The generator fails closed on changed docking facets, the wrong owner kind,
duplicate nodes/elements, internal cracks, non-positive elements, insufficient
quality or a volume mismatch.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
import math
from statistics import median
from types import MappingProxyType
from typing import Any, TypeAlias

from .gmsh_runtime import isolated_gmsh_model
from .volume_mesh import ELEMENT_SPECS


Point3D: TypeAlias = tuple[float, float, float]
FaceKey: TypeAlias = tuple[int, ...]
CoordinateKey: TypeAlias = tuple[float, float, float]

_COORDINATE_TOLERANCE_MM = 1.0e-10
_ROUND_DIGITS = 12
_TET4 = 4
_PYRAMID5 = 7
_TRI3 = 2
_QUAD4 = 3


class ConstrainedHybridError(ValueError):
    """Raised when an OCC locked-interface hybrid cannot be generated safely."""


@dataclass(frozen=True, slots=True)
class HybridVolumeElement:
    """One first-order volume element using result-local node IDs."""

    gmsh_type: int
    node_ids: tuple[int, ...]

    def __post_init__(self) -> None:
        expected = {_TET4: 4, _PYRAMID5: 5}.get(self.gmsh_type)
        if expected is None or len(self.node_ids) != expected:
            raise ConstrainedHybridError("hybrid element must be TET4 or PYRAMID5")
        if len(set(self.node_ids)) != expected:
            raise ConstrainedHybridError("hybrid element contains repeated nodes")


@dataclass(frozen=True, slots=True)
class DirectionalGrowth:
    """Element-span comparison between the near and far quartiles."""

    near_median_span_mm: float
    far_median_span_mm: float
    ratio: float
    near_element_count: int
    far_element_count: int


@dataclass(frozen=True, slots=True)
class ConstrainedHybridVolume:
    """Pure, audited result compatible with the package assembly adapter."""

    node_coordinates: Mapping[int, Point3D]
    source_node_id_by_local_id: Mapping[int, int]
    elements: tuple[HybridVolumeElement, ...]
    locked_face_count: int
    locked_bottom_face_count: int
    locked_side_face_count: int
    far_face_count: int
    tet4_count: int
    pyramid5_count: int
    near_median_edge_mm: float
    far_median_edge_mm: float
    minimum_sicn: float
    minimum_sige: float
    minimum_scaled_jacobian: float
    minimum_determinant: float
    duplicate_node_count: int
    duplicate_element_count: int
    docking_triangle_count: int
    docking_quad_count: int
    triangle_tet_owner_count: int
    quad_pyramid_base_count: int
    locked_side_triangle_count: int
    locked_side_quad_count: int
    side_triangle_tet_owner_count: int
    side_quad_pyramid_base_count: int
    growth_by_axis: Mapping[str, DirectionalGrowth]
    box_volume_mm3: float
    element_volume_mm3: float
    relative_volume_error: float
    random_seed: int
    optimized_interior_pyramid_node_count: int = 0
    optimized_interior_quality_node_count: int = 0

    @property
    def node_count(self) -> int:
        return len(self.node_coordinates)

    @property
    def element_count(self) -> int:
        return len(self.elements)


@dataclass(frozen=True, slots=True)
class _PreparedSidePatch:
    name: str
    source_facets: tuple[tuple[int, ...], ...]
    tangent_axis: int
    tangent_min: float
    tangent_max: float
    z_min: float
    z_max: float


@dataclass(frozen=True, slots=True)
class _PreparedDocking:
    source_coordinates: Mapping[int, Point3D]
    source_facets: tuple[tuple[int, ...], ...]
    bounds: tuple[float, float, float, float]
    interface_z: float
    far_z: float
    side_chains: Mapping[str, tuple[int, ...]]
    side_patches: tuple[_PreparedSidePatch, ...]

    @property
    def side_facets(self) -> tuple[tuple[int, ...], ...]:
        return tuple(
            facet for patch in self.side_patches for facet in patch.source_facets
        )


@dataclass(frozen=True, slots=True)
class _RawCandidate:
    coordinates: Mapping[int, Point3D]
    elements: tuple[tuple[int, int, tuple[int, ...]], ...]
    determinants: tuple[float, ...]
    sicn: tuple[float, ...]
    sige: tuple[float, ...]
    scaled_jacobian: tuple[float, ...]
    duplicate_node_count: int
    seed: int
    optimized_interior_pyramid_node_count: int = 0
    optimized_interior_quality_node_count: int = 0


def _load_gmsh() -> Any:
    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:  # pragma: no cover - dependency failure
        raise RuntimeError("Gmsh is required for OCC locked hybrid meshing") from error
    return gmsh


def _finite(value: object, *, name: str) -> float:
    if isinstance(value, bool):
        raise ConstrainedHybridError(f"{name} must be finite")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise ConstrainedHybridError(f"{name} must be finite") from error
    if not math.isfinite(result):
        raise ConstrainedHybridError(f"{name} must be finite")
    return result


def _coordinate_key(point: Sequence[float]) -> CoordinateKey:
    return tuple(  # type: ignore[return-value]
        round(float(value), _ROUND_DIGITS) for value in point
    )


def _face_key(nodes: Sequence[int]) -> FaceKey:
    return tuple(sorted(int(node) for node in nodes))


def _edge_key(first: int, second: int) -> tuple[int, int]:
    return (first, second) if first < second else (second, first)


def _signed_xy_area(face: Sequence[int], coordinates: Mapping[int, Point3D]) -> float:
    return 0.5 * math.fsum(
        coordinates[face[index]][0]
        * coordinates[face[(index + 1) % len(face)]][1]
        - coordinates[face[(index + 1) % len(face)]][0]
        * coordinates[face[index]][1]
        for index in range(len(face))
    )


def _parse_bounds(values: Sequence[float]) -> tuple[float, float, float, float]:
    try:
        raw = tuple(values)
    except TypeError as error:
        raise ConstrainedHybridError(
            "bounds_xy_mm must contain x_min,x_max,y_min,y_max"
        ) from error
    if len(raw) != 4:
        raise ConstrainedHybridError(
            "bounds_xy_mm must contain x_min,x_max,y_min,y_max"
        )
    bounds = tuple(_finite(value, name="hybrid XY bound") for value in raw)
    x_min, x_max, y_min, y_max = bounds
    if x_max <= x_min or y_max <= y_min:
        raise ConstrainedHybridError("hybrid XY bounds must be strictly increasing")
    return bounds  # type: ignore[return-value]


def _rectangular_side_chains(
    facets: Sequence[Sequence[int]],
    coordinates: Mapping[int, Point3D],
    bounds: tuple[float, float, float, float],
) -> Mapping[str, tuple[int, ...]]:
    x_min, x_max, y_min, y_max = bounds
    edge_counts: Counter[tuple[int, int]] = Counter()
    adjacency: dict[int, set[int]] = defaultdict(set)
    facet_neighbors: dict[int, set[int]] = defaultdict(set)
    owner_by_edge: dict[tuple[int, int], list[int]] = defaultdict(list)
    for facet_index, facet in enumerate(facets):
        for first, second in zip(facet, (*facet[1:], facet[0])):
            edge = _edge_key(first, second)
            edge_counts[edge] += 1
            owner_by_edge[edge].append(facet_index)
    if any(count not in {1, 2} for count in edge_counts.values()):
        raise ConstrainedHybridError("docking surface is non-manifold")
    for owners in owner_by_edge.values():
        if len(owners) == 2:
            facet_neighbors[owners[0]].add(owners[1])
            facet_neighbors[owners[1]].add(owners[0])
    visited: set[int] = set()
    queue = deque([0])
    while queue:
        current = queue.popleft()
        if current in visited:
            continue
        visited.add(current)
        queue.extend(facet_neighbors[current].difference(visited))
    if len(visited) != len(facets):
        raise ConstrainedHybridError("docking surface must be one connected partition")

    boundary_edges = {edge for edge, count in edge_counts.items() if count == 1}
    if not boundary_edges:
        raise ConstrainedHybridError("docking surface has no rectangular boundary")
    side_edges: dict[str, set[tuple[int, int]]] = {
        "y_min": set(),
        "x_max": set(),
        "y_max": set(),
        "x_min": set(),
    }
    side_nodes: dict[str, set[int]] = {side: set() for side in side_edges}
    tolerance = _COORDINATE_TOLERANCE_MM
    for edge in boundary_edges:
        first, second = (coordinates[node] for node in edge)
        candidates: list[str] = []
        if abs(first[1] - y_min) <= tolerance and abs(second[1] - y_min) <= tolerance:
            candidates.append("y_min")
        if abs(first[0] - x_max) <= tolerance and abs(second[0] - x_max) <= tolerance:
            candidates.append("x_max")
        if abs(first[1] - y_max) <= tolerance and abs(second[1] - y_max) <= tolerance:
            candidates.append("y_max")
        if abs(first[0] - x_min) <= tolerance and abs(second[0] - x_min) <= tolerance:
            candidates.append("x_min")
        if len(candidates) != 1:
            raise ConstrainedHybridError(
                "every docking boundary edge must lie on exactly one box side"
            )
        side = candidates[0]
        side_edges[side].add(edge)
        side_nodes[side].update(edge)
        adjacency[edge[0]].add(edge[1])
        adjacency[edge[1]].add(edge[0])
    if any(len(neighbors) != 2 for neighbors in adjacency.values()):
        raise ConstrainedHybridError("docking boundary is not one closed simple loop")

    chains: dict[str, tuple[int, ...]] = {}
    for side in ("y_min", "x_max", "y_max", "x_min"):
        axis = 0 if side.startswith("y_") else 1
        chain = tuple(sorted(side_nodes[side], key=lambda node: coordinates[node][axis]))
        if len(chain) < 2:
            raise ConstrainedHybridError(f"docking side {side} is incomplete")
        actual_edges = {
            _edge_key(first, second) for first, second in zip(chain, chain[1:])
        }
        if actual_edges != side_edges[side]:
            raise ConstrainedHybridError(
                f"docking side {side} has a gap, branch or hanging boundary node"
            )
        chains[side] = chain
    if set().union(*side_edges.values()) != boundary_edges:
        raise ConstrainedHybridError("docking boundary classification is incomplete")
    return MappingProxyType(chains)


def _signed_projected_area(
    facet: Sequence[int],
    coordinates: Mapping[int, Point3D],
    first_axis: int,
    second_axis: int,
) -> float:
    return 0.5 * math.fsum(
        coordinates[facet[index]][first_axis]
        * coordinates[facet[(index + 1) % len(facet)]][second_axis]
        - coordinates[facet[(index + 1) % len(facet)]][first_axis]
        * coordinates[facet[index]][second_axis]
        for index in range(len(facet))
    )


def _prepare_one_side_patch(
    name: str,
    facets: Sequence[Sequence[int]],
    coordinates: Mapping[int, Point3D],
    interface_z: float,
    far_z: float,
) -> _PreparedSidePatch:
    tangent_axis = 1 if name.startswith("x_") else 0
    edge_counts: Counter[tuple[int, int]] = Counter()
    owner_by_edge: dict[tuple[int, int], list[int]] = defaultdict(list)
    facet_neighbors: dict[int, set[int]] = defaultdict(set)
    for facet_index, facet in enumerate(facets):
        for first, second in zip(facet, (*facet[1:], facet[0])):
            edge = _edge_key(first, second)
            edge_counts[edge] += 1
            owner_by_edge[edge].append(facet_index)
    if any(count not in {1, 2} for count in edge_counts.values()):
        raise ConstrainedHybridError(f"locked side {name} is non-manifold")
    for owners in owner_by_edge.values():
        if len(owners) == 2:
            facet_neighbors[owners[0]].add(owners[1])
            facet_neighbors[owners[1]].add(owners[0])
    visited: set[int] = set()
    queue = deque([0])
    while queue:
        current = queue.popleft()
        if current in visited:
            continue
        visited.add(current)
        queue.extend(facet_neighbors[current].difference(visited))
    if len(visited) != len(facets):
        raise ConstrainedHybridError(
            f"locked side {name} must be one connected partition"
        )

    used_nodes = {node for facet in facets for node in facet}
    tangent_values = tuple(coordinates[node][tangent_axis] for node in used_nodes)
    z_values = tuple(coordinates[node][2] for node in used_nodes)
    tangent_min, tangent_max = min(tangent_values), max(tangent_values)
    z_min, z_max = min(z_values), max(z_values)
    if (
        tangent_max - tangent_min <= _COORDINATE_TOLERANCE_MM
        or z_max - z_min <= _COORDINATE_TOLERANCE_MM
    ):
        raise ConstrainedHybridError(f"locked side {name} has zero extent")
    expected_interface_z = z_min if far_z > interface_z else z_max
    if abs(expected_interface_z - interface_z) > _COORDINATE_TOLERANCE_MM:
        raise ConstrainedHybridError(
            f"locked side {name} must start at the docking interface"
        )

    boundary_edges = {edge for edge, count in edge_counts.items() if count == 1}
    if not boundary_edges:
        raise ConstrainedHybridError(f"locked side {name} has no boundary")
    classified: set[tuple[int, int]] = set()
    for edge in boundary_edges:
        points = tuple(coordinates[node] for node in edge)
        on_patch_boundary = any(
            all(abs(point[axis] - value) <= _COORDINATE_TOLERANCE_MM for point in points)
            for axis, value in (
                (tangent_axis, tangent_min),
                (tangent_axis, tangent_max),
                (2, z_min),
                (2, z_max),
            )
        )
        if not on_patch_boundary:
            raise ConstrainedHybridError(
                f"locked side {name} boundary is not rectangular"
            )
        classified.add(edge)
    if classified != boundary_edges:
        raise ConstrainedHybridError(
            f"locked side {name} boundary classification is incomplete"
        )
    area = math.fsum(
        abs(_signed_projected_area(facet, coordinates, tangent_axis, 2))
        for facet in facets
    )
    expected_area = (tangent_max - tangent_min) * (z_max - z_min)
    if not math.isclose(
        area,
        expected_area,
        rel_tol=1.0e-9,
        abs_tol=_COORDINATE_TOLERANCE_MM**2,
    ):
        raise ConstrainedHybridError(
            f"locked side {name} does not cover its rectangle exactly"
        )
    return _PreparedSidePatch(
        name=name,
        source_facets=tuple(tuple(facet) for facet in facets),
        tangent_axis=tangent_axis,
        tangent_min=tangent_min,
        tangent_max=tangent_max,
        z_min=z_min,
        z_max=z_max,
    )


def _prepare_side_facets(
    locked_side_node_coordinates: Mapping[int, Sequence[float]] | None,
    locked_side_facets: Sequence[Sequence[int]],
    bottom_coordinates: Mapping[int, Point3D],
    bounds: tuple[float, float, float, float],
    interface_z: float,
    far_z: float,
) -> tuple[Mapping[int, Point3D], tuple[_PreparedSidePatch, ...]]:
    try:
        raw_facets = tuple(tuple(facet) for facet in locked_side_facets)
    except TypeError as error:
        raise ConstrainedHybridError(
            "locked_side_facets must contain TRI3/QUAD4 faces"
        ) from error
    raw_coordinates = locked_side_node_coordinates or {}
    if not isinstance(raw_coordinates, Mapping):
        raise ConstrainedHybridError(
            "locked_side_node_coordinates must be a mapping"
        )
    if bool(raw_coordinates) != bool(raw_facets):
        raise ConstrainedHybridError(
            "locked side coordinates and facets must both be empty or non-empty"
        )
    if not raw_facets:
        return MappingProxyType(dict(bottom_coordinates)), ()

    coordinates = dict(bottom_coordinates)
    side_declared_ids: set[int] = set()
    x_min, x_max, y_min, y_max = bounds
    z_min_box, z_max_box = sorted((interface_z, far_z))
    for raw_id, raw_point in raw_coordinates.items():
        if isinstance(raw_id, bool) or not isinstance(raw_id, int) or raw_id < 1:
            raise ConstrainedHybridError(
                "locked side node IDs must be positive integers"
            )
        try:
            values = tuple(raw_point)
        except TypeError as error:
            raise ConstrainedHybridError(
                "locked side coordinate must contain x,y,z"
            ) from error
        if len(values) != 3:
            raise ConstrainedHybridError(
                "locked side coordinate must contain x,y,z"
            )
        point = tuple(
            _finite(value, name=f"locked side node {raw_id} coordinate")
            for value in values
        )
        if not (
            x_min - _COORDINATE_TOLERANCE_MM <= point[0] <= x_max + _COORDINATE_TOLERANCE_MM
            and y_min - _COORDINATE_TOLERANCE_MM <= point[1] <= y_max + _COORDINATE_TOLERANCE_MM
            and z_min_box - _COORDINATE_TOLERANCE_MM <= point[2] <= z_max_box + _COORDINATE_TOLERANCE_MM
        ):
            raise ConstrainedHybridError("locked side node lies outside the box")
        existing = coordinates.get(raw_id)
        if existing is not None and math.dist(existing, point) > _COORDINATE_TOLERANCE_MM:
            raise ConstrainedHybridError(
                "locked side node ID conflicts with a docking node"
            )
        coordinates[raw_id] = point  # type: ignore[assignment]
        side_declared_ids.add(raw_id)
    coordinate_keys = [_coordinate_key(point) for point in coordinates.values()]
    if len(set(coordinate_keys)) != len(coordinate_keys):
        raise ConstrainedHybridError(
            "locked bottom/side nodes contain duplicate coordinates"
        )

    grouped: dict[str, list[tuple[int, ...]]] = defaultdict(list)
    parsed_facets: list[tuple[int, ...]] = []
    for raw_facet in raw_facets:
        if len(raw_facet) not in {3, 4}:
            raise ConstrainedHybridError("locked side facets must be TRI3 or QUAD4")
        if any(isinstance(node, bool) or not isinstance(node, int) for node in raw_facet):
            raise ConstrainedHybridError("locked side facet node IDs must be integers")
        facet = tuple(int(node) for node in raw_facet)
        if len(set(facet)) != len(facet):
            raise ConstrainedHybridError("locked side facet contains a repeated node")
        if any(node not in coordinates for node in facet):
            raise ConstrainedHybridError("locked side facet references an unknown node")
        points = tuple(coordinates[node] for node in facet)
        candidates: list[str] = []
        if all(abs(point[0] - x_min) <= _COORDINATE_TOLERANCE_MM for point in points):
            candidates.append("x_min")
        if all(abs(point[0] - x_max) <= _COORDINATE_TOLERANCE_MM for point in points):
            candidates.append("x_max")
        if all(abs(point[1] - y_min) <= _COORDINATE_TOLERANCE_MM for point in points):
            candidates.append("y_min")
        if all(abs(point[1] - y_max) <= _COORDINATE_TOLERANCE_MM for point in points):
            candidates.append("y_max")
        if len(candidates) != 1:
            raise ConstrainedHybridError(
                "each locked side facet must lie on exactly one vertical box side"
            )
        name = candidates[0]
        first_axis = 1 if name.startswith("x_") else 0
        if abs(_signed_projected_area(facet, coordinates, first_axis, 2)) <= (
            _COORDINATE_TOLERANCE_MM**2
        ):
            raise ConstrainedHybridError("locked side facet has zero projected area")
        grouped[name].append(facet)
        parsed_facets.append(facet)
    if len({_face_key(facet) for facet in parsed_facets}) != len(parsed_facets):
        raise ConstrainedHybridError("locked side facets must be unique")
    referenced = {node for facet in parsed_facets for node in facet}
    if side_declared_ids.difference(referenced):
        raise ConstrainedHybridError("locked side coordinates contain unused nodes")
    patches = tuple(
        _prepare_one_side_patch(
            name,
            grouped[name],
            coordinates,
            interface_z,
            far_z,
        )
        for name in ("x_min", "x_max", "y_min", "y_max")
        if name in grouped
    )
    return MappingProxyType(coordinates), patches


def _prepare_inputs(
    docking_node_coordinates: Mapping[int, Sequence[float]],
    docking_facets: Sequence[Sequence[int]],
    bounds_xy_mm: Sequence[float],
    interface_z_mm: float,
    far_z_mm: float,
    locked_side_node_coordinates: Mapping[int, Sequence[float]] | None = None,
    locked_side_facets: Sequence[Sequence[int]] = (),
) -> _PreparedDocking:
    bounds = _parse_bounds(bounds_xy_mm)
    interface_z = _finite(interface_z_mm, name="hybrid interface Z")
    far_z = _finite(far_z_mm, name="hybrid far Z")
    if math.isclose(
        interface_z,
        far_z,
        rel_tol=0.0,
        abs_tol=_COORDINATE_TOLERANCE_MM,
    ):
        raise ConstrainedHybridError("hybrid interface Z and far Z must differ")
    if not isinstance(docking_node_coordinates, Mapping):
        raise ConstrainedHybridError("docking_node_coordinates must be a mapping")
    coordinates: dict[int, Point3D] = {}
    for raw_id, raw_point in docking_node_coordinates.items():
        if isinstance(raw_id, bool) or not isinstance(raw_id, int) or raw_id < 1:
            raise ConstrainedHybridError("docking node IDs must be positive integers")
        try:
            point_values = tuple(raw_point)
        except TypeError as error:
            raise ConstrainedHybridError("docking coordinate must contain x,y,z") from error
        if len(point_values) != 3:
            raise ConstrainedHybridError("docking coordinate must contain x,y,z")
        point = tuple(
            _finite(value, name=f"docking node {raw_id} coordinate")
            for value in point_values
        )
        if abs(point[2] - interface_z) > _COORDINATE_TOLERANCE_MM:
            raise ConstrainedHybridError(
                "every docking node must lie on the interface plane"
            )
        x_min, x_max, y_min, y_max = bounds
        if not (
            x_min - _COORDINATE_TOLERANCE_MM
            <= point[0]
            <= x_max + _COORDINATE_TOLERANCE_MM
            and y_min - _COORDINATE_TOLERANCE_MM
            <= point[1]
            <= y_max + _COORDINATE_TOLERANCE_MM
        ):
            raise ConstrainedHybridError("docking node lies outside the XY bounds")
        coordinates[raw_id] = point  # type: ignore[assignment]
    if not coordinates:
        raise ConstrainedHybridError("docking surface must contain nodes")
    coordinate_keys = [_coordinate_key(point) for point in coordinates.values()]
    if len(set(coordinate_keys)) != len(coordinate_keys):
        raise ConstrainedHybridError("docking nodes contain duplicate coordinates")

    try:
        raw_facets = tuple(tuple(facet) for facet in docking_facets)
    except TypeError as error:
        raise ConstrainedHybridError("docking_facets must contain TRI3/QUAD4 faces") from error
    if not raw_facets:
        raise ConstrainedHybridError("docking surface must contain facets")
    facets: list[tuple[int, ...]] = []
    for raw_facet in raw_facets:
        if len(raw_facet) not in {3, 4}:
            raise ConstrainedHybridError("docking facets must be TRI3 or QUAD4")
        if any(isinstance(node, bool) or not isinstance(node, int) for node in raw_facet):
            raise ConstrainedHybridError("docking facet node IDs must be integers")
        facet = tuple(int(node) for node in raw_facet)
        if len(set(facet)) != len(facet):
            raise ConstrainedHybridError("docking facet contains a repeated node")
        if any(node not in coordinates for node in facet):
            raise ConstrainedHybridError("docking facet references an unknown node")
        area = _signed_xy_area(facet, coordinates)
        if abs(area) <= _COORDINATE_TOLERANCE_MM**2:
            raise ConstrainedHybridError("docking facet has zero projected area")
        facets.append(facet)
    if len({_face_key(facet) for facet in facets}) != len(facets):
        raise ConstrainedHybridError("docking facets must be unique")
    referenced = {node for facet in facets for node in facet}
    if referenced != set(coordinates):
        raise ConstrainedHybridError("every docking node must be used by a facet")

    side_chains = _rectangular_side_chains(facets, coordinates, bounds)
    partition_area = math.fsum(abs(_signed_xy_area(facet, coordinates)) for facet in facets)
    box_area = (bounds[1] - bounds[0]) * (bounds[3] - bounds[2])
    if not math.isclose(
        partition_area,
        box_area,
        rel_tol=1.0e-9,
        abs_tol=_COORDINATE_TOLERANCE_MM**2,
    ):
        raise ConstrainedHybridError(
            "docking facets do not cover the rectangular interface exactly"
        )
    source_coordinates, side_patches = _prepare_side_facets(
        locked_side_node_coordinates,
        locked_side_facets,
        coordinates,
        bounds,
        interface_z,
        far_z,
    )
    return _PreparedDocking(
        source_coordinates=source_coordinates,
        source_facets=tuple(facets),
        bounds=bounds,
        interface_z=interface_z,
        far_z=far_z,
        side_chains=side_chains,
        side_patches=side_patches,
    )


def _all_nodes(gmsh: Any) -> dict[int, Point3D]:
    raw_tags, raw_coordinates, _ = gmsh.model.mesh.getNodes()
    if len(raw_coordinates) != 3 * len(raw_tags):
        raise ConstrainedHybridError("Gmsh returned inconsistent node coordinates")
    return {
        int(tag): (
            float(raw_coordinates[3 * index]),
            float(raw_coordinates[3 * index + 1]),
            float(raw_coordinates[3 * index + 2]),
        )
        for index, tag in enumerate(raw_tags)
    }


def _surface_records(gmsh: Any) -> tuple[tuple[int, int, tuple[int, ...]], ...]:
    result: list[tuple[int, int, tuple[int, ...]]] = []
    raw_types, tag_blocks, connectivity_blocks = gmsh.model.mesh.getElements(2)
    for raw_type, raw_tags, raw_connectivity in zip(
        raw_types,
        tag_blocks,
        connectivity_blocks,
    ):
        gmsh_type = int(raw_type)
        node_count = {_TRI3: 3, _QUAD4: 4}.get(gmsh_type)
        if node_count is None:
            raise ConstrainedHybridError(
                f"unsupported exterior surface element type {gmsh_type}"
            )
        connectivity = tuple(int(node) for node in raw_connectivity)
        if len(connectivity) != node_count * len(raw_tags):
            raise ConstrainedHybridError("Gmsh surface connectivity is inconsistent")
        for index, raw_tag in enumerate(raw_tags):
            start = index * node_count
            result.append(
                (
                    gmsh_type,
                    int(raw_tag),
                    connectivity[start : start + node_count],
                )
            )
    return tuple(result)


def _surface_shell_is_watertight(gmsh: Any) -> None:
    counts: Counter[tuple[int, int]] = Counter()
    for _gmsh_type, _tag, nodes in _surface_records(gmsh):
        for first, second in zip(nodes, (*nodes[1:], nodes[0])):
            counts[_edge_key(first, second)] += 1
    bad = [edge for edge, count in counts.items() if count != 2]
    if bad:
        owner_count_histogram = Counter(counts[edge] for edge in bad)
        coordinates = _all_nodes(gmsh)
        sample = tuple(
            (
                counts[edge],
                coordinates.get(edge[0]),
                coordinates.get(edge[1]),
            )
            for edge in bad[:4]
        )
        raise ConstrainedHybridError(
            f"OCC boundary shell is not watertight ({len(bad)} bad edge(s)); "
            f"owner_counts={dict(sorted(owner_count_histogram.items()))!r}; "
            f"sample={sample!r}"
        )


def _side_for_curve(
    gmsh: Any,
    curve_tag: int,
    bounds: tuple[float, float, float, float],
) -> str:
    point_tags = tuple(
        int(tag)
        for dimension, tag in gmsh.model.getBoundary(
            [(1, curve_tag)],
            oriented=False,
            recursive=False,
        )
        if int(dimension) == 0
    )
    if len(point_tags) != 2:
        raise ConstrainedHybridError("OCC docking curve must have two endpoints")
    endpoints: list[Point3D] = []
    for point_tag in point_tags:
        raw_tags, raw_coordinates, _ = gmsh.model.mesh.getNodes(
            0,
            point_tag,
            includeBoundary=True,
            returnParametricCoord=False,
        )
        if len(raw_tags) != 1:
            raise ConstrainedHybridError("OCC point does not own exactly one mesh node")
        endpoints.append(  # type: ignore[arg-type]
            tuple(float(raw_coordinates[index]) for index in range(3))
        )
    x_min, x_max, y_min, y_max = bounds
    candidates: list[str] = []
    if all(abs(point[1] - y_min) <= _COORDINATE_TOLERANCE_MM for point in endpoints):
        candidates.append("y_min")
    if all(abs(point[0] - x_max) <= _COORDINATE_TOLERANCE_MM for point in endpoints):
        candidates.append("x_max")
    if all(abs(point[1] - y_max) <= _COORDINATE_TOLERANCE_MM for point in endpoints):
        candidates.append("y_max")
    if all(abs(point[0] - x_min) <= _COORDINATE_TOLERANCE_MM for point in endpoints):
        candidates.append("x_min")
    if len(candidates) != 1:
        raise ConstrainedHybridError("could not match OCC curve to a docking side")
    return candidates[0]


def _add_exact_docking_curves(
    gmsh: Any,
    docking: _PreparedDocking,
    curve_tags: Sequence[int],
) -> None:
    gmsh.model.mesh.generate(1)
    gmsh.model.mesh.clear([(1, int(curve_tag)) for curve_tag in curve_tags])
    next_node = int(gmsh.model.mesh.getMaxNodeTag()) + 1
    next_element = int(gmsh.model.mesh.getMaxElementTag()) + 1
    by_coordinate = {
        _coordinate_key(point): tag for tag, point in _all_nodes(gmsh).items()
    }
    used_sides: set[str] = set()
    for raw_curve_tag in curve_tags:
        curve_tag = int(raw_curve_tag)
        side = _side_for_curve(gmsh, curve_tag, docking.bounds)
        if side in used_sides:
            raise ConstrainedHybridError("OCC docking face has duplicate side curves")
        used_sides.add(side)
        source_chain = docking.side_chains[side]
        points = tuple(docking.source_coordinates[node] for node in source_chain)
        parameters = tuple(
            float(gmsh.model.getParametrization(1, curve_tag, list(point))[0])
            for point in points
        )
        ordered = tuple(
            sorted(zip(parameters, points), key=lambda item: item[0])
        )
        line_nodes: list[int] = []
        new_tags: list[int] = []
        new_coordinates: list[float] = []
        new_parameters: list[float] = []
        for parameter, point in ordered:
            key = _coordinate_key(point)
            tag = by_coordinate.get(key)
            if tag is None:
                tag = next_node
                next_node += 1
                by_coordinate[key] = tag
                new_tags.append(tag)
                new_coordinates.extend(point)
                new_parameters.append(parameter)
            line_nodes.append(tag)
        if new_tags:
            gmsh.model.mesh.addNodes(
                1,
                curve_tag,
                new_tags,
                new_coordinates,
                new_parameters,
            )
        element_tags = list(
            range(next_element, next_element + len(line_nodes) - 1)
        )
        next_element += len(element_tags)
        gmsh.model.mesh.addElementsByType(
            curve_tag,
            1,
            element_tags,
            [
                node
                for pair in zip(line_nodes, line_nodes[1:])
                for node in pair
            ],
        )
    if used_sides != set(docking.side_chains):
        raise ConstrainedHybridError("OCC docking face does not expose four sides")
    gmsh.model.mesh.generate(1)


def _replace_docking_surface(
    gmsh: Any,
    docking: _PreparedDocking,
    surface_tag: int,
) -> None:
    gmsh.model.mesh.clear([(2, surface_tag)])
    by_coordinate = {
        _coordinate_key(point): tag for tag, point in _all_nodes(gmsh).items()
    }
    next_node = int(gmsh.model.mesh.getMaxNodeTag()) + 1
    new_tags: list[int] = []
    new_coordinates: list[float] = []
    gmsh_tag_by_source: dict[int, int] = {}
    for source_id, point in sorted(docking.source_coordinates.items()):
        key = _coordinate_key(point)
        tag = by_coordinate.get(key)
        if tag is None:
            tag = next_node
            next_node += 1
            by_coordinate[key] = tag
            new_tags.append(tag)
            new_coordinates.extend(point)
        gmsh_tag_by_source[source_id] = tag
    if new_tags:
        gmsh.model.mesh.addNodes(2, surface_tag, new_tags, new_coordinates)

    outward_positive_z = docking.far_z < docking.interface_z
    oriented: list[tuple[int, ...]] = []
    for facet in docking.source_facets:
        area = _signed_xy_area(facet, docking.source_coordinates)
        source_cycle = (
            facet
            if (area > 0.0) == outward_positive_z
            else tuple(reversed(facet))
        )
        oriented.append(tuple(gmsh_tag_by_source[node] for node in source_cycle))
    next_element = int(gmsh.model.mesh.getMaxElementTag()) + 1
    for node_count, gmsh_type in ((3, _TRI3), (4, _QUAD4)):
        block = tuple(facet for facet in oriented if len(facet) == node_count)
        if not block:
            continue
        element_tags = list(range(next_element, next_element + len(block)))
        next_element += len(element_tags)
        gmsh.model.mesh.addElementsByType(
            surface_tag,
            gmsh_type,
            element_tags,
            [node for facet in block for node in facet],
        )
    _surface_shell_is_watertight(gmsh)


def _add_side_patch_surface(gmsh: Any, patch: _PreparedSidePatch, docking: _PreparedDocking) -> int:
    x_min, x_max, y_min, y_max = docking.bounds
    if patch.name == "x_min":
        points = (
            (x_min, patch.tangent_min, patch.z_min),
            (x_min, patch.tangent_max, patch.z_min),
            (x_min, patch.tangent_max, patch.z_max),
            (x_min, patch.tangent_min, patch.z_max),
        )
    elif patch.name == "x_max":
        points = (
            (x_max, patch.tangent_min, patch.z_min),
            (x_max, patch.tangent_max, patch.z_min),
            (x_max, patch.tangent_max, patch.z_max),
            (x_max, patch.tangent_min, patch.z_max),
        )
    elif patch.name == "y_min":
        points = (
            (patch.tangent_min, y_min, patch.z_min),
            (patch.tangent_max, y_min, patch.z_min),
            (patch.tangent_max, y_min, patch.z_max),
            (patch.tangent_min, y_min, patch.z_max),
        )
    else:
        points = (
            (patch.tangent_min, y_max, patch.z_min),
            (patch.tangent_max, y_max, patch.z_min),
            (patch.tangent_max, y_max, patch.z_max),
            (patch.tangent_min, y_max, patch.z_max),
        )
    point_tags = tuple(int(gmsh.model.occ.addPoint(*point)) for point in points)
    curve_tags = tuple(
        int(gmsh.model.occ.addLine(point_tags[index], point_tags[(index + 1) % 4]))
        for index in range(4)
    )
    loop = int(gmsh.model.occ.addCurveLoop(curve_tags))
    return int(gmsh.model.occ.addPlaneSurface([loop]))


def _locked_surface_groups(
    docking: _PreparedDocking,
) -> Mapping[str, tuple[tuple[int, ...], ...]]:
    return MappingProxyType(
        {
            "bottom": docking.source_facets,
            **{
                patch.name: patch.source_facets for patch in docking.side_patches
            },
        }
    )


def _facet_boundary_edges(
    facets: Sequence[Sequence[int]],
) -> set[tuple[int, int]]:
    counts: Counter[tuple[int, int]] = Counter(
        _edge_key(first, second)
        for facet in facets
        for first, second in zip(facet, (*facet[1:], facet[0]))
    )
    if any(count not in {1, 2} for count in counts.values()):
        raise ConstrainedHybridError("locked surface is non-manifold")
    return {edge for edge, count in counts.items() if count == 1}


def _curve_source_chain(
    gmsh: Any,
    curve_tag: int,
    source_boundary_edges: set[tuple[int, int]],
    coordinates: Mapping[int, Point3D],
) -> tuple[int, ...]:
    bounding_box = gmsh.model.getBoundingBox(1, curve_tag)
    lower, upper = bounding_box[:3], bounding_box[3:]
    boundary_nodes = {node for edge in source_boundary_edges for node in edge}
    candidates: list[tuple[float, int]] = []
    for source_id in boundary_nodes:
        point = coordinates[source_id]
        if not all(
            lower[axis] - _COORDINATE_TOLERANCE_MM
            <= point[axis]
            <= upper[axis] + _COORDINATE_TOLERANCE_MM
            for axis in range(3)
        ):
            continue
        try:
            parameter = float(
                gmsh.model.getParametrization(1, curve_tag, list(point))[0]
            )
            closest, _ = gmsh.model.getClosestPoint(1, curve_tag, list(point))
        except Exception:
            continue
        if math.dist(point, tuple(float(closest[index]) for index in range(3))) <= (
            _COORDINATE_TOLERANCE_MM
        ):
            candidates.append((parameter, source_id))
    chain = tuple(source_id for _parameter, source_id in sorted(candidates))
    actual_edges = {
        _edge_key(first, second) for first, second in zip(chain, chain[1:])
    }
    if len(chain) < 2 or not actual_edges or not actual_edges.issubset(
        source_boundary_edges
    ):
        raise ConstrainedHybridError(
            "could not match an OCC locked-surface curve to source edges"
        )
    return chain


def _add_exact_locked_curves(
    gmsh: Any,
    docking: _PreparedDocking,
    surface_by_group: Mapping[str, int],
) -> None:
    groups = _locked_surface_groups(docking)
    expected_edges = set().union(
        *(_facet_boundary_edges(groups[name]) for name in surface_by_group)
    )
    curve_tags = {
        int(tag)
        for surface_tag in surface_by_group.values()
        for dimension, tag in gmsh.model.getBoundary(
            [(2, surface_tag)], oriented=False, recursive=False
        )
        if int(dimension) == 1
    }
    gmsh.model.mesh.generate(1)
    gmsh.model.mesh.clear([(1, tag) for tag in sorted(curve_tags)])
    next_node = int(gmsh.model.mesh.getMaxNodeTag()) + 1
    next_element = int(gmsh.model.mesh.getMaxElementTag()) + 1
    by_coordinate = {
        _coordinate_key(point): tag for tag, point in _all_nodes(gmsh).items()
    }
    installed_edges: set[tuple[int, int]] = set()
    for curve_tag in sorted(curve_tags):
        chain = _curve_source_chain(
            gmsh,
            curve_tag,
            expected_edges,
            docking.source_coordinates,
        )
        ordered = tuple(
            sorted(
                (
                    float(
                        gmsh.model.getParametrization(
                            1,
                            curve_tag,
                            list(docking.source_coordinates[source_id]),
                        )[0]
                    ),
                    source_id,
                )
                for source_id in chain
            )
        )
        line_nodes: list[int] = []
        new_tags: list[int] = []
        new_coordinates: list[float] = []
        new_parameters: list[float] = []
        for parameter, source_id in ordered:
            point = docking.source_coordinates[source_id]
            coordinate_key = _coordinate_key(point)
            node_tag = by_coordinate.get(coordinate_key)
            if node_tag is None:
                node_tag = next_node
                next_node += 1
                by_coordinate[coordinate_key] = node_tag
                new_tags.append(node_tag)
                new_coordinates.extend(point)
                new_parameters.append(parameter)
            line_nodes.append(node_tag)
        if new_tags:
            gmsh.model.mesh.addNodes(
                1,
                curve_tag,
                new_tags,
                new_coordinates,
                new_parameters,
            )
        element_tags = list(
            range(next_element, next_element + len(line_nodes) - 1)
        )
        next_element += len(element_tags)
        gmsh.model.mesh.addElementsByType(
            curve_tag,
            1,
            element_tags,
            [node for pair in zip(line_nodes, line_nodes[1:]) for node in pair],
        )
        installed_edges.update(
            _edge_key(first, second) for first, second in zip(chain, chain[1:])
        )
    if installed_edges != expected_edges:
        raise ConstrainedHybridError(
            "OCC locked-surface curves do not preserve every source edge"
        )
    gmsh.model.mesh.generate(1)


def _facet_outward_normal(name: str, docking: _PreparedDocking) -> Point3D:
    if name == "bottom":
        return (0.0, 0.0, 1.0 if docking.far_z < docking.interface_z else -1.0)
    return {
        "x_min": (-1.0, 0.0, 0.0),
        "x_max": (1.0, 0.0, 0.0),
        "y_min": (0.0, -1.0, 0.0),
        "y_max": (0.0, 1.0, 0.0),
    }[name]


def _oriented_source_facet(
    facet: Sequence[int],
    coordinates: Mapping[int, Point3D],
    outward: Point3D,
) -> tuple[int, ...]:
    first, second, third = (coordinates[node] for node in facet[:3])
    first_edge = tuple(second[index] - first[index] for index in range(3))
    second_edge = tuple(third[index] - first[index] for index in range(3))
    normal = (
        first_edge[1] * second_edge[2] - first_edge[2] * second_edge[1],
        first_edge[2] * second_edge[0] - first_edge[0] * second_edge[2],
        first_edge[0] * second_edge[1] - first_edge[1] * second_edge[0],
    )
    if math.fsum(normal[index] * outward[index] for index in range(3)) < 0.0:
        return tuple(reversed(facet))
    return tuple(facet)


def _replace_locked_surfaces(
    gmsh: Any,
    docking: _PreparedDocking,
    surface_by_group: Mapping[str, int],
    *,
    outward_by_group: Mapping[str, Point3D] | None = None,
) -> None:
    for surface_tag in surface_by_group.values():
        gmsh.model.mesh.clear([(2, surface_tag)])
    groups = _locked_surface_groups(docking)
    by_coordinate = {
        _coordinate_key(point): tag for tag, point in _all_nodes(gmsh).items()
    }
    next_node = int(gmsh.model.mesh.getMaxNodeTag()) + 1
    next_element = int(gmsh.model.mesh.getMaxElementTag()) + 1
    gmsh_tag_by_source: dict[int, int] = {}
    for name, surface_tag in surface_by_group.items():
        source_ids = sorted({node for facet in groups[name] for node in facet})
        new_tags: list[int] = []
        new_coordinates: list[float] = []
        for source_id in source_ids:
            point = docking.source_coordinates[source_id]
            node_tag = by_coordinate.get(_coordinate_key(point))
            if node_tag is None:
                node_tag = next_node
                next_node += 1
                by_coordinate[_coordinate_key(point)] = node_tag
                new_tags.append(node_tag)
                new_coordinates.extend(point)
            gmsh_tag_by_source[source_id] = node_tag
        if new_tags:
            gmsh.model.mesh.addNodes(2, surface_tag, new_tags, new_coordinates)
        oriented = tuple(
            _oriented_source_facet(
                facet,
                docking.source_coordinates,
                (
                    outward_by_group[name]
                    if outward_by_group is not None and name in outward_by_group
                    else _facet_outward_normal(name, docking)
                ),
            )
            for facet in groups[name]
        )
        for node_count, gmsh_type in ((3, _TRI3), (4, _QUAD4)):
            block = tuple(facet for facet in oriented if len(facet) == node_count)
            if not block:
                continue
            element_tags = list(range(next_element, next_element + len(block)))
            next_element += len(element_tags)
            gmsh.model.mesh.addElementsByType(
                surface_tag,
                gmsh_type,
                element_tags,
                [gmsh_tag_by_source[node] for facet in block for node in facet],
            )
    if set(gmsh_tag_by_source) != set(docking.source_coordinates):
        raise ConstrainedHybridError(
            "OCC locked surfaces did not classify every source node"
        )
    _surface_shell_is_watertight(gmsh)


def _extract_candidate(gmsh: Any, volume_tag: int, seed: int) -> _RawCandidate:
    coordinates = _all_nodes(gmsh)
    raw_types, tag_blocks, connectivity_blocks = gmsh.model.mesh.getElements(
        3,
        volume_tag,
    )
    elements: list[tuple[int, int, tuple[int, ...]]] = []
    quality_tags: list[int] = []
    for raw_type, raw_tags, raw_connectivity in zip(
        raw_types,
        tag_blocks,
        connectivity_blocks,
    ):
        gmsh_type = int(raw_type)
        if gmsh_type not in {_TET4, _PYRAMID5}:
            raise ConstrainedHybridError(
                f"Gmsh produced unsupported volume element type {gmsh_type}"
            )
        node_count = ELEMENT_SPECS[gmsh_type][1]
        connectivity = tuple(int(node) for node in raw_connectivity)
        if len(connectivity) != node_count * len(raw_tags):
            raise ConstrainedHybridError("Gmsh volume connectivity is inconsistent")
        for index, raw_tag in enumerate(raw_tags):
            start = index * node_count
            elements.append(
                (
                    gmsh_type,
                    int(raw_tag),
                    connectivity[start : start + node_count],
                )
            )
            quality_tags.append(int(raw_tag))
    if not elements:
        raise ConstrainedHybridError("Gmsh produced an empty hybrid volume")
    referenced = {node for _kind, _tag, nodes in elements for node in nodes}
    missing = referenced.difference(coordinates)
    if missing:
        raise ConstrainedHybridError("Gmsh volume references an unavailable node")
    metrics = {
        name: tuple(
            float(value)
            for value in gmsh.model.mesh.getElementQualities(quality_tags, name)
        )
        for name in ("minDetJac", "minSICN", "minSIGE", "minSJ")
    }
    if any(len(values) != len(elements) for values in metrics.values()):
        raise ConstrainedHybridError("Gmsh returned inconsistent quality arrays")
    return _RawCandidate(
        coordinates=MappingProxyType(coordinates),
        elements=tuple(elements),
        determinants=metrics["minDetJac"],
        sicn=metrics["minSICN"],
        sige=metrics["minSIGE"],
        scaled_jacobian=metrics["minSJ"],
        duplicate_node_count=len(tuple(gmsh.model.mesh.getDuplicateNodes())),
        seed=seed,
    )


def _optimize_interior_pyramid_apices(gmsh, candidate, minimum_quality):
    """Improve deficient pyramids without changing connectivity or boundary nodes.

    Accept a normal displacement only when Gmsh reports a better worst quality
    over *every* incident cell. The final volume audit still checks folds,
    locked coordinates, closure and volume independently.
    """
    incident = defaultdict(list)
    for _kind, tag, nodes in candidate.elements:
        for node in nodes:
            incident[node].append(tag)
    changed = set()
    for (kind, _tag, nodes), sicn, sige, sj in zip(
        candidate.elements, candidate.sicn, candidate.sige, candidate.scaled_jacobian
    ):
        if kind != _PYRAMID5 or min(sicn, sige, sj) >= minimum_quality:
            continue
        apex = nodes[-1]
        coordinates, _parameters, dimension, _entity = gmsh.model.mesh.getNode(apex)
        if dimension != 3:
            continue
        current = tuple(float(v) for v in coordinates)
        base = [tuple(gmsh.model.mesh.getNode(node)[0]) for node in nodes[:4]]
        center = tuple(sum(point[a] for point in base) / 4 for a in range(3))
        u = tuple(base[1][a] - base[0][a] for a in range(3))
        v = tuple(base[2][a] - base[0][a] for a in range(3))
        normal = (u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0])
        length = math.sqrt(sum(value*value for value in normal))
        if length <= 0:
            continue
        normal = tuple(value / length for value in normal)
        height = sum((current[a] - center[a]) * normal[a] for a in range(3))

        def score():
            determinants = gmsh.model.mesh.getElementQualities(incident[apex], "minDetJac")
            if any(not math.isfinite(value) or value <= 0 for value in determinants):
                return -math.inf
            values = [float(value) for name in ("minSJ", "minSICN", "minSIGE")
                      for value in gmsh.model.mesh.getElementQualities(incident[apex], name)]
            return min(values) if all(map(math.isfinite, values)) else -math.inf

        best, best_score = current, score()
        try:
            for factor in (1.1, 1.25, 1.5, 2., 3., 4., 6., .75, .5):
                point = tuple(current[a] + (factor - 1) * height * normal[a] for a in range(3))
                gmsh.model.mesh.setNode(apex, point, [])
                value = score()
                if value > best_score:
                    best, best_score = point, value
        finally:
            gmsh.model.mesh.setNode(apex, best, [])
        if best != current:
            changed.add(apex)
    return len(changed)


def _optimize_deficient_interior_stars(gmsh, volume_tag, candidate, minimum_quality):
    """Move interior nodes only if the worst quality of their entire star improves.

    A pyramid's normal alone cannot resolve slivers shared with adjacent TETs.
    A bounded spatial search also permits tangential movement. Connectivity and
    all boundary coordinates stay fixed; final independent audits still apply.
    """
    from itertools import product

    incident = defaultdict(list)
    neighbors = defaultdict(set)
    faces = Counter()
    for kind, tag, nodes in candidate.elements:
        for node in nodes:
            incident[node].append(tag)
            neighbors[node].update(nodes)
        for indices in ELEMENT_SPECS[kind][2]:
            faces[tuple(sorted(nodes[i] for i in indices))] += 1
    boundary = {n for face, count in faces.items() if count == 1 for n in face}
    directions = tuple(d for d in product((-1, 0, 1), repeat=3) if any(d))
    changed = set()
    for _pass in range(4):
        current_candidate = _extract_candidate(gmsh, volume_tag, candidate.seed)
        deficient = {
            node for element, sicn, sige, sj in zip(
                current_candidate.elements, current_candidate.sicn,
                current_candidate.sige, current_candidate.scaled_jacobian
            ) if min(sicn, sige, sj) < minimum_quality for node in element[2]
        }
        pass_changed = False
        for node in sorted(deficient - boundary):
            coordinates, _parameters, dimension, _entity = gmsh.model.mesh.getNode(node)
            if dimension != 3:
                continue
            initial = best = tuple(float(v) for v in coordinates)

            def score():
                determinants = gmsh.model.mesh.getElementQualities(incident[node], "minDetJac")
                if any(not math.isfinite(v) or v <= 0 for v in determinants):
                    return -math.inf
                values = [float(v) for name in ("minSICN", "minSIGE", "minSJ")
                          for v in gmsh.model.mesh.getElementQualities(incident[node], name)]
                return min(values) if all(map(math.isfinite, values)) else -math.inf

            best_score = score()
            step = .5 * min(math.dist(initial, gmsh.model.mesh.getNode(other)[0])
                            for other in neighbors[node] if other != node)
            try:
                for _level in range(12):
                    center, previous_score = best, best_score
                    for direction in directions:
                        point = tuple(center[a] + direction[a] * step for a in range(3))
                        gmsh.model.mesh.setNode(node, point, [])
                        value = score()
                        if value > best_score + 1.e-12:
                            best, best_score = point, value
                    gmsh.model.mesh.setNode(node, best, [])
                    if best_score == previous_score:
                        step *= .5
            finally:
                gmsh.model.mesh.setNode(node, best, [])
            if best != initial:
                changed.add(node)
                pass_changed = True
        if not pass_changed:
            break
    return len(changed)


def _mesh_candidate(
    gmsh: Any,
    docking: _PreparedDocking,
    *,
    maximum_size: float,
    near_size: float,
    transition_distance: float,
    seed: int,
    verbose: bool,
    minimum_quality: float = 0.03,
) -> _RawCandidate:
    slope = max(0.0, (maximum_size - near_size) / transition_distance)
    options = {
        "General.Terminal": 1.0 if verbose else 0.0,
        "Mesh.ElementOrder": 1.0,
        "Mesh.Algorithm": 6.0,
        "Mesh.Algorithm3D": 1.0,
        "Mesh.MeshOnlyEmpty": 1.0,
        "Mesh.MeshSizeMin": near_size,
        "Mesh.MeshSizeMax": maximum_size,
        "Mesh.MeshSizeExtendFromBoundary": 0.0,
        "Mesh.MeshSizeFromCurvature": 0.0,
        "Mesh.MeshSizeFromPoints": 0.0,
        "Mesh.Optimize": 1.0,
        "Mesh.OptimizePyramids": 1.0,
        "Mesh.RandomSeed": float(seed),
    }
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_occ_locked_hybrid",
        number_options=options,
    ):
        x_min, x_max, y_min, y_max = docking.bounds
        z_min = min(docking.interface_z, docking.far_z)
        raw_volume_tag = int(
            gmsh.model.occ.addBox(
                x_min,
                y_min,
                z_min,
                x_max - x_min,
                y_max - y_min,
                abs(docking.far_z - docking.interface_z),
            )
        )
        fragment_maps: Sequence[Sequence[tuple[int, int]]] = ()
        if docking.side_patches:
            patch_surfaces = tuple(
                _add_side_patch_surface(gmsh, patch, docking)
                for patch in docking.side_patches
            )
            _fragment_output, fragment_maps = gmsh.model.occ.fragment(
                [(3, raw_volume_tag)],
                [(2, surface_tag) for surface_tag in patch_surfaces],
            )
        gmsh.model.occ.synchronize()
        volume_tags = tuple(int(tag) for _dimension, tag in gmsh.model.getEntities(3))
        if len(volume_tags) != 1:
            raise ConstrainedHybridError(
                "OCC side imprint did not preserve one box volume"
            )
        volume_tag = volume_tags[0]
        surface_tags = tuple(
            int(tag)
            for dimension, tag in gmsh.model.getBoundary(
                [(3, volume_tag)],
                oriented=False,
                recursive=False,
            )
            if int(dimension) == 2
        )
        if not docking.side_patches and len(surface_tags) != 6:
            raise ConstrainedHybridError("OCC box does not have six surfaces")
        docking_surface = min(
            surface_tags,
            key=lambda tag: abs(
                0.5
                * (
                    gmsh.model.getBoundingBox(2, tag)[2]
                    + gmsh.model.getBoundingBox(2, tag)[5]
                )
                - docking.interface_z
            ),
        )
        surface_by_group: dict[str, int] = {"bottom": docking_surface}
        if docking.side_patches:
            if len(fragment_maps) != 1 + len(docking.side_patches):
                raise ConstrainedHybridError(
                    "OCC side imprint returned inconsistent entity maps"
                )
            boundary_surface_set = set(surface_tags)
            for index, patch in enumerate(docking.side_patches, start=1):
                mapped = {
                    int(tag)
                    for dimension, tag in fragment_maps[index]
                    if int(dimension) == 2 and int(tag) in boundary_surface_set
                }
                if len(mapped) != 1:
                    raise ConstrainedHybridError(
                        f"OCC locked side {patch.name} did not map to one surface"
                    )
                surface_by_group[patch.name] = mapped.pop()
            if len(set(surface_by_group.values())) != len(surface_by_group):
                raise ConstrainedHybridError(
                    "OCC locked surfaces do not have distinct entities"
                )
            _add_exact_locked_curves(gmsh, docking, surface_by_group)
        else:
            docking_curves = tuple(
                int(tag)
                for dimension, tag in gmsh.model.getBoundary(
                    [(2, docking_surface)],
                    oriented=False,
                    recursive=False,
                )
                if int(dimension) == 1
            )
            if len(docking_curves) != 4:
                raise ConstrainedHybridError(
                    "OCC docking surface does not have four curves"
                )
            _add_exact_docking_curves(gmsh, docking, docking_curves)

        size_field = gmsh.model.mesh.field.add("MathEval")
        gmsh.model.mesh.field.setString(
            size_field,
            "F",
            f"Min({maximum_size:.17g},{near_size:.17g}+"
            f"{slope:.17g}*Abs(z-({docking.interface_z:.17g})))",
        )
        gmsh.model.mesh.field.setAsBackgroundMesh(size_field)
        gmsh.model.mesh.generate(2)
        if docking.side_patches:
            _replace_locked_surfaces(gmsh, docking, surface_by_group)
        else:
            _replace_docking_surface(gmsh, docking, docking_surface)
        try:
            gmsh.model.mesh.generate(3)
        except Exception as error:
            raise ConstrainedHybridError(
                "Gmsh could not fill the OCC locked hybrid box"
            ) from error

        from .gmsh_closed_shell_remainder import _folded_internal_face_count
        from .package_v2_quality_history import emit_quality_snapshot

        candidate = _extract_candidate(gmsh, volume_tag, seed)
        emit_quality_snapshot(candidate, 0, phase="原生 TET/PYRAMID 初始网格")
        folded = _folded_internal_face_count(candidate.elements, candidate.coordinates)
        if folded:
            raise ConstrainedHybridError(f"initial hybrid mesh folds across internal faces: {folded}")
        # Never let relocation invert cells and then let flips hide the inverted
        # orientation. Restore that relocation before any connectivity changes.
        for iteration, (method, count) in enumerate((("Relocate3D", 3), ("", 50)) * 2, 1):
            before = candidate
            gmsh.model.mesh.optimize(method, force=True, niter=count, dimTags=[(3, volume_tag)])
            candidate = _extract_candidate(gmsh, volume_tag, seed)
            unsafe = (any(not math.isfinite(v) or v <= 0 for v in candidate.determinants)
                      or _folded_internal_face_count(candidate.elements, candidate.coordinates))
            phase = "内部节点平滑" if method else "原生 TET 拓扑优化"
            if unsafe and method == "Relocate3D":
                for node, point in before.coordinates.items():
                    if candidate.coordinates.get(node) != point:
                        _coord, parameters, _dim, _entity = gmsh.model.mesh.getNode(node)
                        gmsh.model.mesh.setNode(node, point, parameters)
                candidate = _extract_candidate(gmsh, volume_tag, seed)
                phase += "（产生无效单元，已回退）"
            elif unsafe:
                emit_quality_snapshot(candidate, iteration, phase=phase + "（无效，丢弃候选）")
                raise ConstrainedHybridError("native hybrid topology optimization produced invalid cells")
            emit_quality_snapshot(candidate, iteration, phase=phase)
        changed = _optimize_interior_pyramid_apices(gmsh, candidate, minimum_quality)
        candidate = replace(
            _extract_candidate(gmsh, volume_tag, seed) if changed else candidate,
            optimized_interior_pyramid_node_count=changed,
        )
        if changed:
            emit_quality_snapshot(candidate, 5, phase="内部 PYRAMID 顶点优化后")
        if min((*candidate.sicn, *candidate.sige, *candidate.scaled_jacobian)) < minimum_quality:
            improved = _optimize_deficient_interior_stars(gmsh, volume_tag, candidate, minimum_quality)
            candidate = replace(
                _extract_candidate(gmsh, volume_tag, seed),
                optimized_interior_pyramid_node_count=changed,
                optimized_interior_quality_node_count=improved,
            )
            emit_quality_snapshot(candidate, 6, phase="内部相邻单元联合质量优化后")
        return candidate


def _tetra_volume(first: Point3D, second: Point3D, third: Point3D, fourth: Point3D) -> float:
    ab = tuple(second[index] - first[index] for index in range(3))
    ac = tuple(third[index] - first[index] for index in range(3))
    ad = tuple(fourth[index] - first[index] for index in range(3))
    cross = (
        ac[1] * ad[2] - ac[2] * ad[1],
        ac[2] * ad[0] - ac[0] * ad[2],
        ac[0] * ad[1] - ac[1] * ad[0],
    )
    return abs(math.fsum(ab[index] * cross[index] for index in range(3))) / 6.0


def _element_volume(
    element: HybridVolumeElement,
    coordinates: Mapping[int, Point3D],
) -> float:
    points = tuple(coordinates[node] for node in element.node_ids)
    if element.gmsh_type == _TET4:
        return _tetra_volume(*points)  # type: ignore[arg-type]
    return _tetra_volume(points[0], points[1], points[2], points[4]) + _tetra_volume(
        points[0], points[2], points[3], points[4]
    )


def _edge_growth(
    coordinates: Mapping[int, Point3D],
    elements: Sequence[HybridVolumeElement],
    interface_z: float,
    far_z: float,
) -> tuple[float, float]:
    edge_indices = {
        _TET4: ((0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)),
        _PYRAMID5: (
            (0, 1),
            (1, 2),
            (2, 3),
            (3, 0),
            (0, 4),
            (1, 4),
            (2, 4),
            (3, 4),
        ),
    }
    seen: set[tuple[int, int]] = set()
    near: list[float] = []
    far: list[float] = []
    height = abs(far_z - interface_z)
    for element in elements:
        for first_index, second_index in edge_indices[element.gmsh_type]:
            edge = _edge_key(
                element.node_ids[first_index],
                element.node_ids[second_index],
            )
            if edge in seen:
                continue
            seen.add(edge)
            first, second = coordinates[edge[0]], coordinates[edge[1]]
            normalized = abs(0.5 * (first[2] + second[2]) - interface_z) / height
            length = math.dist(first, second)
            if normalized <= 0.25:
                near.append(length)
            if normalized >= 0.75:
                far.append(length)
    if not near or not far:
        raise ConstrainedHybridError("hybrid mesh has empty near/far edge bands")
    return float(median(near)), float(median(far))


def _directional_growth(
    coordinates: Mapping[int, Point3D],
    elements: Sequence[HybridVolumeElement],
    interface_z: float,
    far_z: float,
) -> Mapping[str, DirectionalGrowth]:
    height = abs(far_z - interface_z)
    near: dict[int, list[float]] = {0: [], 1: [], 2: []}
    far: dict[int, list[float]] = {0: [], 1: [], 2: []}
    near_count = 0
    far_count = 0
    for element in elements:
        if element.gmsh_type != _TET4:
            continue
        points = tuple(coordinates[node] for node in element.node_ids)
        centroid_z = math.fsum(point[2] for point in points) / len(points)
        normalized = abs(centroid_z - interface_z) / height
        target = near if normalized <= 0.25 else far if normalized >= 0.75 else None
        if target is None:
            continue
        if target is near:
            near_count += 1
        else:
            far_count += 1
        for axis in range(3):
            target[axis].append(
                max(point[axis] for point in points)
                - min(point[axis] for point in points)
            )
    if near_count == 0 or far_count == 0 or any(not near[i] or not far[i] for i in range(3)):
        raise ConstrainedHybridError("hybrid mesh has empty XYZ growth bands")
    return MappingProxyType(
        {
            axis_name: DirectionalGrowth(
                near_median_span_mm=float(median(near[axis])),
                far_median_span_mm=float(median(far[axis])),
                ratio=float(median(far[axis]) / median(near[axis])),
                near_element_count=near_count,
                far_element_count=far_count,
            )
            for axis, axis_name in enumerate(("x", "y", "z"))
        }
    )


def _finalize_candidate(
    candidate: _RawCandidate,
    docking: _PreparedDocking,
    *,
    minimum_quality: float,
) -> ConstrainedHybridVolume:
    from .gmsh_closed_shell_remainder import _folded_internal_face_count

    folded = _folded_internal_face_count(candidate.elements, candidate.coordinates)
    if folded:
        raise ConstrainedHybridError(f"hybrid mesh folds across internal faces: {folded}")
    if candidate.duplicate_node_count:
        raise ConstrainedHybridError("Gmsh produced duplicate hybrid nodes")
    if any(
        not math.isfinite(value) or value <= 0.0
        for value in candidate.determinants
    ):
        raise ConstrainedHybridError("hybrid mesh contains a non-positive element")
    metric_values = (
        candidate.sicn,
        candidate.sige,
        candidate.scaled_jacobian,
    )
    if any(
        not math.isfinite(value)
        for values in metric_values
        for value in values
    ):
        raise ConstrainedHybridError("hybrid mesh quality is non-finite")
    metric_minima = tuple(min(values) for values in metric_values)
    if any(value < minimum_quality for value in metric_minima):
        raise ConstrainedHybridError(
            "hybrid quality floor was not met: "
            f"minSJ={min(candidate.scaled_jacobian):.8g}, "
            f"minSICN={min(candidate.sicn):.8g}, "
            f"minSIGE={min(candidate.sige):.8g}, required={minimum_quality:.8g}"
        )

    gmsh_by_coordinate: dict[CoordinateKey, int] = {}
    for gmsh_tag, point in candidate.coordinates.items():
        key = _coordinate_key(point)
        if key in gmsh_by_coordinate:
            raise ConstrainedHybridError("hybrid nodes contain coincident coordinates")
        gmsh_by_coordinate[key] = gmsh_tag
    gmsh_source_by_tag: dict[int, int] = {}
    for source_id, point in docking.source_coordinates.items():
        gmsh_tag = gmsh_by_coordinate.get(_coordinate_key(point))
        if gmsh_tag is None or (
            math.dist(candidate.coordinates[gmsh_tag], point)
            > _COORDINATE_TOLERANCE_MM
        ):
            raise ConstrainedHybridError("Gmsh changed a locked docking node")
        gmsh_source_by_tag[gmsh_tag] = source_id
    interface_gmsh_tags = {
        tag
        for tag, point in candidate.coordinates.items()
        if abs(point[2] - docking.interface_z) <= _COORDINATE_TOLERANCE_MM
    }
    expected_interface_tags = {
        gmsh_tag
        for gmsh_tag, source_id in gmsh_source_by_tag.items()
        if abs(
            docking.source_coordinates[source_id][2] - docking.interface_z
        )
        <= _COORDINATE_TOLERANCE_MM
    }
    if interface_gmsh_tags != expected_interface_tags:
        raise ConstrainedHybridError("Gmsh added or removed a docking-plane node")

    sorted_gmsh_tags = tuple(
        sorted(
            candidate.coordinates,
            key=lambda tag: (_coordinate_key(candidate.coordinates[tag]), tag),
        )
    )
    local_by_gmsh = {
        gmsh_tag: local_id
        for local_id, gmsh_tag in enumerate(sorted_gmsh_tags, start=1)
    }
    coordinates = {
        local_by_gmsh[tag]: candidate.coordinates[tag] for tag in sorted_gmsh_tags
    }
    source_by_local = {
        local_by_gmsh[gmsh_tag]: source_id
        for gmsh_tag, source_id in gmsh_source_by_tag.items()
    }
    elements = tuple(
        sorted(
            (
                HybridVolumeElement(
                    gmsh_type,
                    tuple(local_by_gmsh[node] for node in nodes),
                )
                for gmsh_type, _tag, nodes in candidate.elements
            ),
            key=lambda element: (
                element.gmsh_type,
                tuple(sorted(element.node_ids)),
                element.node_ids,
            ),
        )
    )
    duplicate_elements = len(elements) - len(
        {(element.gmsh_type, _face_key(element.node_ids)) for element in elements}
    )
    if duplicate_elements:
        raise ConstrainedHybridError("Gmsh produced duplicate hybrid elements")

    owners: dict[FaceKey, list[tuple[int, int]]] = defaultdict(list)
    for element_index, element in enumerate(elements):
        for face_index, local_face in enumerate(ELEMENT_SPECS[element.gmsh_type][2]):
            owners[
                _face_key(tuple(element.node_ids[index] for index in local_face))
            ].append((element_index, face_index))
    if any(len(face_owners) not in {1, 2} for face_owners in owners.values()):
        raise ConstrainedHybridError("hybrid volume contains a non-manifold face")

    local_by_source = {source: local for local, source in source_by_local.items()}
    def audit_locked_facets(
        source_facets: Sequence[Sequence[int]],
        label: str,
    ) -> tuple[set[FaceKey], int, int]:
        keys: set[FaceKey] = set()
        triangle_count = 0
        quad_count = 0
        for source_facet in source_facets:
            key = _face_key(tuple(local_by_source[node] for node in source_facet))
            keys.add(key)
            face_owners = owners.get(key, ())
            if len(face_owners) != 1:
                raise ConstrainedHybridError(
                    f"locked {label} facet does not have one owner"
                )
            element_index, face_index = face_owners[0]
            owner = elements[element_index]
            if len(source_facet) == 3:
                if owner.gmsh_type != _TET4:
                    raise ConstrainedHybridError(
                        f"locked {label} TRI3 is not owned by one TET4"
                    )
                triangle_count += 1
            else:
                if owner.gmsh_type != _PYRAMID5 or face_index != 0:
                    raise ConstrainedHybridError(
                        f"locked {label} QUAD4 is not the complete base of one PYRAMID5"
                    )
                quad_count += 1
        return keys, triangle_count, quad_count

    bottom_locked_keys, triangle_owner_count, quad_base_count = audit_locked_facets(
        docking.source_facets,
        "bottom",
    )
    side_locked_keys, side_triangle_owner_count, side_quad_base_count = (
        audit_locked_facets(docking.side_facets, "side")
        if docking.side_facets
        else (set(), 0, 0)
    )
    locked_keys = bottom_locked_keys | side_locked_keys
    if len(locked_keys) != len(bottom_locked_keys) + len(side_locked_keys):
        raise ConstrainedHybridError("locked bottom and side facet sets overlap")
    boundary_keys = {key for key, value in owners.items() if len(value) == 1}
    interface_boundary = {
        key
        for key in boundary_keys
        if all(
            abs(coordinates[node][2] - docking.interface_z)
            <= _COORDINATE_TOLERANCE_MM
            for node in key
        )
    }
    if interface_boundary != bottom_locked_keys:
        raise ConstrainedHybridError("Gmsh changed the docking facet set")
    if not side_locked_keys.issubset(boundary_keys):
        raise ConstrainedHybridError("Gmsh changed the locked side facet set")

    x_min, x_max, y_min, y_max = docking.bounds
    planes = (
        (0, x_min),
        (0, x_max),
        (1, y_min),
        (1, y_max),
        (2, docking.interface_z),
        (2, docking.far_z),
    )
    for key in boundary_keys:
        if not any(
            all(
                abs(coordinates[node][axis] - value)
                <= _COORDINATE_TOLERANCE_MM
                for node in key
            )
            for axis, value in planes
        ):
            raise ConstrainedHybridError("hybrid volume contains an internal crack")
    far_keys = {
        key
        for key in boundary_keys
        if all(
            abs(coordinates[node][2] - docking.far_z)
            <= _COORDINATE_TOLERANCE_MM
            for node in key
        )
    }
    if not far_keys:
        raise ConstrainedHybridError("hybrid volume has no far boundary faces")

    element_volume = math.fsum(
        _element_volume(element, coordinates) for element in elements
    )
    box_volume = (
        (x_max - x_min)
        * (y_max - y_min)
        * abs(docking.far_z - docking.interface_z)
    )
    relative_volume_error = abs(element_volume - box_volume) / box_volume
    # Summing more than one hundred thousand first-order cell volumes loses a
    # few ulps per cell; the real substrate case is still within 3e-7 of the
    # analytic OCC box.  This bound is tight enough to detect a missing surface
    # layer while remaining stable at package scale.
    if relative_volume_error > 1.0e-6:
        raise ConstrainedHybridError(
            f"hybrid element volume differs from OCC box by {relative_volume_error:.3g}"
        )

    near_edge, far_edge = _edge_growth(
        coordinates,
        elements,
        docking.interface_z,
        docking.far_z,
    )
    growth = _directional_growth(
        coordinates,
        elements,
        docking.interface_z,
        docking.far_z,
    )
    return ConstrainedHybridVolume(
        node_coordinates=MappingProxyType(coordinates),
        source_node_id_by_local_id=MappingProxyType(source_by_local),
        elements=elements,
        locked_face_count=len(locked_keys),
        locked_bottom_face_count=len(bottom_locked_keys),
        locked_side_face_count=len(side_locked_keys),
        far_face_count=len(far_keys),
        tet4_count=sum(element.gmsh_type == _TET4 for element in elements),
        pyramid5_count=sum(element.gmsh_type == _PYRAMID5 for element in elements),
        near_median_edge_mm=near_edge,
        far_median_edge_mm=far_edge,
        minimum_sicn=min(candidate.sicn),
        minimum_sige=min(candidate.sige),
        minimum_scaled_jacobian=min(candidate.scaled_jacobian),
        minimum_determinant=min(candidate.determinants),
        duplicate_node_count=candidate.duplicate_node_count,
        duplicate_element_count=duplicate_elements,
        docking_triangle_count=sum(len(facet) == 3 for facet in docking.source_facets),
        docking_quad_count=sum(len(facet) == 4 for facet in docking.source_facets),
        triangle_tet_owner_count=triangle_owner_count,
        quad_pyramid_base_count=quad_base_count,
        locked_side_triangle_count=sum(
            len(facet) == 3 for facet in docking.side_facets
        ),
        locked_side_quad_count=sum(len(facet) == 4 for facet in docking.side_facets),
        side_triangle_tet_owner_count=side_triangle_owner_count,
        side_quad_pyramid_base_count=side_quad_base_count,
        growth_by_axis=growth,
        box_volume_mm3=box_volume,
        element_volume_mm3=element_volume,
        relative_volume_error=relative_volume_error,
        random_seed=candidate.seed,
        optimized_interior_pyramid_node_count=candidate.optimized_interior_pyramid_node_count,
        optimized_interior_quality_node_count=candidate.optimized_interior_quality_node_count,
    )


def generate_locked_box_hybrid(
    docking_node_coordinates: Mapping[int, Sequence[float]],
    docking_facets: Sequence[Sequence[int]],
    bounds_xy_mm: Sequence[float],
    interface_z_mm: float,
    far_z_mm: float,
    *,
    maximum_size_mm: float,
    near_size_mm: float,
    transition_distance_mm: float | None = None,
    locked_side_node_coordinates: Mapping[int, Sequence[float]] | None = None,
    locked_side_facets: Sequence[Sequence[int]] = (),
    minimum_quality: float = 0.03,
    random_seeds: Sequence[int] = (1, 2, 3),
    verbose: bool = False,
) -> ConstrainedHybridVolume:
    """Fill a +Z or -Z rectangular bulk while retaining every docking facet.

    ``far_z_mm > interface_z_mm`` generates the die-side orientation and the
    reverse generates the substrate-side orientation. Optional locked side
    facets must form at most one rectangular partition per vertical box side,
    start at the docking interface and share source IDs with docking nodes on
    common edges. The first deterministic seed meeting ``minimum_quality`` is
    returned.
    """

    docking = _prepare_inputs(
        docking_node_coordinates,
        docking_facets,
        bounds_xy_mm,
        interface_z_mm,
        far_z_mm,
        locked_side_node_coordinates,
        locked_side_facets,
    )
    maximum_size = _finite(maximum_size_mm, name="hybrid maximum size")
    near_size = _finite(near_size_mm, name="hybrid near size")
    transition_distance = (
        abs(docking.far_z - docking.interface_z)
        if transition_distance_mm is None
        else _finite(transition_distance_mm, name="hybrid transition distance")
    )
    quality_floor = _finite(minimum_quality, name="hybrid minimum quality")
    if (
        maximum_size <= 0.0
        or near_size <= 0.0
        or transition_distance <= 0.0
        or maximum_size < near_size
        or quality_floor <= 0.0
        or quality_floor >= 1.0
    ):
        raise ConstrainedHybridError(
            "hybrid sizes, transition distance and quality floor are invalid"
        )
    try:
        seeds = tuple(random_seeds)
    except TypeError as error:
        raise ConstrainedHybridError("random_seeds must be a non-empty sequence") from error
    if not seeds or any(
        isinstance(seed, bool) or not isinstance(seed, int) or seed < 1
        for seed in seeds
    ):
        raise ConstrainedHybridError("random_seeds must contain positive integers")
    seeds = tuple(dict.fromkeys(seeds))

    gmsh = _load_gmsh()
    failures: list[str] = []
    for seed in seeds:
        try:
            candidate = _mesh_candidate(
                gmsh,
                docking,
                maximum_size=maximum_size,
                near_size=near_size,
                transition_distance=transition_distance,
                seed=seed,
                verbose=verbose,
                minimum_quality=quality_floor,
            )
            return _finalize_candidate(
                candidate,
                docking,
                minimum_quality=quality_floor,
            )
        except ConstrainedHybridError as error:
            failures.append(f"seed {seed}: {error}")
        except Exception as error:  # pragma: no cover - Gmsh runtime failure
            failures.append(f"seed {seed}: Gmsh runtime failure: {error}")
    raise ConstrainedHybridError(
        "all OCC locked-hybrid candidates failed; " + "; ".join(failures)
    )


__all__ = [
    "ConstrainedHybridError",
    "ConstrainedHybridVolume",
    "DirectionalGrowth",
    "HybridVolumeElement",
    "generate_locked_box_hybrid",
]
