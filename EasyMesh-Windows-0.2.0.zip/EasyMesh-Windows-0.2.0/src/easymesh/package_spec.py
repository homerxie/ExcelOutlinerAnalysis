"""Parse the package assembly and parametric component DSLs.

The package files used by the examples form a deliberately small two-level
language.  ``*.component`` files describe parameterised polygon sweeps while a
``*.pack`` file places generated components and pre-meshed assets in assembly
order.  This module is the syntax and validation boundary for those files; it
does not create geometry or mutate a mesh.

All length values exposed by the public API are normalised to millimetres.
Expressions are parsed with :mod:`ast` and interpreted by a strict whitelist;
Python evaluation is never used.
"""

from __future__ import annotations

import ast
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field, replace
from enum import Enum
import hashlib
import math
from pathlib import Path
import re
from typing import TypeAlias


_IDENTIFIER = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\Z")
_NUMBER = r"(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?"
_UNIT_LITERAL = re.compile(
    rf"(?<![A-Za-z0-9_.])(?P<number>{_NUMBER})\s*"
    r"(?P<unit>mm|um|\N{MICRO SIGN}m|\N{GREEK SMALL LETTER MU}m)"
    r"(?![A-Za-z0-9_])",
    re.IGNORECASE,
)
_UNIT_HELPER = "__easymesh_length__"
_LENGTH_POWER = 1
_NUMBER_POWER = 0


def _line_error(line_number: int, message: str) -> ValueError:
    return ValueError(f"line {line_number}: {message}")


def _non_empty(value: object, *, line_number: int, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise _line_error(line_number, f"{field_name} must not be empty")
    return value.strip()


def _identifier(value: object, *, line_number: int, field_name: str) -> str:
    name = _non_empty(value, line_number=line_number, field_name=field_name)
    if _IDENTIFIER.fullmatch(name) is None:
        raise _line_error(
            line_number,
            f"{field_name} must be an identifier, got {name!r}",
        )
    return name


def _finite(value: object, *, field_name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{field_name} must be finite")
    try:
        number = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{field_name} must be finite") from error
    if not math.isfinite(number):
        raise ValueError(f"{field_name} must be finite")
    return number


def split_top_level_commas(
    value: str,
    *,
    line_number: int = 1,
    field_name: str = "record",
) -> tuple[str, ...]:
    """Split one record without splitting nested vectors or polygons."""

    matching = {")": "(", "]": "[", "}": "{"}
    stack: list[str] = []
    fields: list[str] = []
    start = 0
    quote: str | None = None
    index = 0
    while index < len(value):
        character = value[index]
        if quote is not None:
            if character == quote:
                if index + 1 < len(value) and value[index + 1] == quote:
                    index += 2
                    continue
                quote = None
        elif character in {'"', "'"}:
            quote = character
        elif character in "([{":
            stack.append(character)
        elif character in ")]}":
            if not stack or stack[-1] != matching[character]:
                raise _line_error(
                    line_number,
                    f"mismatched delimiter in {field_name}",
                )
            stack.pop()
        elif character == "," and not stack:
            fields.append(value[start:index].strip())
            start = index + 1
        index += 1

    if quote is not None:
        raise _line_error(line_number, f"unterminated quote in {field_name}")
    if stack:
        raise _line_error(line_number, f"unclosed delimiter in {field_name}")
    fields.append(value[start:].strip())
    return tuple(fields)


def _unit_call(match: re.Match[str]) -> str:
    return (
        f"{_UNIT_HELPER}({match.group('number')},"
        f"{match.group('unit').lower()!r})"
    )


def _normalised_expression_source(
    source: str,
    *,
    line_number: int,
    field_name: str,
) -> str:
    stripped = source.strip()
    if not stripped:
        raise _line_error(line_number, f"{field_name} must not be empty")
    if _UNIT_HELPER in stripped:
        raise _line_error(line_number, f"invalid expression in {field_name}")
    return _UNIT_LITERAL.sub(_unit_call, stripped)


def _unit_factor(unit: str) -> float:
    return 1.0 if unit.lower() == "mm" else 1.0e-3


@dataclass(frozen=True, slots=True)
class _Quantity:
    value: float
    length_power: int | None


def _unit_literal_from_node(node: ast.AST) -> _Quantity | None:
    if not isinstance(node, ast.Call):
        return None
    if not isinstance(node.func, ast.Name) or node.func.id != _UNIT_HELPER:
        return None
    if node.keywords or len(node.args) != 2:
        return None
    number_node, unit_node = node.args
    if (
        not isinstance(number_node, ast.Constant)
        or isinstance(number_node.value, bool)
        or not isinstance(number_node.value, (int, float))
        or not isinstance(unit_node, ast.Constant)
        or not isinstance(unit_node.value, str)
    ):
        return None
    number = _finite(number_node.value, field_name="length literal")
    return _Quantity(number * _unit_factor(unit_node.value), _LENGTH_POWER)


def _combine_add(left: _Quantity, right: _Quantity, *, subtract: bool) -> _Quantity:
    right_value = -right.value if subtract else right.value
    if left.length_power == right.length_power:
        return _Quantity(left.value + right_value, left.length_power)
    # An unqualified literal zero is intentionally accepted in length vectors.
    if left.length_power is None and left.value == 0.0:
        return _Quantity(left.value + right_value, right.length_power)
    if right.length_power is None and right.value == 0.0:
        return _Quantity(left.value + right_value, left.length_power)
    raise ValueError("cannot add values with incompatible dimensions")


def _evaluate_node(node: ast.AST, variables_mm: Mapping[str, float]) -> _Quantity:
    unit_literal = _unit_literal_from_node(node)
    if unit_literal is not None:
        return unit_literal
    if isinstance(node, ast.Constant):
        if isinstance(node.value, bool) or not isinstance(node.value, (int, float)):
            raise ValueError("only numeric constants are allowed")
        value = _finite(node.value, field_name="numeric constant")
        return _Quantity(value, None if value == 0.0 else _NUMBER_POWER)
    if isinstance(node, ast.Name):
        if node.id not in variables_mm:
            raise ValueError(f"unknown expression variable {node.id!r}")
        return _Quantity(
            _finite(variables_mm[node.id], field_name=f"variable {node.id!r}"),
            _LENGTH_POWER,
        )
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        operand = _evaluate_node(node.operand, variables_mm)
        value = -operand.value if isinstance(node.op, ast.USub) else operand.value
        return _Quantity(value, operand.length_power)
    if isinstance(node, ast.BinOp):
        left = _evaluate_node(node.left, variables_mm)
        right = _evaluate_node(node.right, variables_mm)
        if isinstance(node.op, ast.Add):
            return _combine_add(left, right, subtract=False)
        if isinstance(node.op, ast.Sub):
            return _combine_add(left, right, subtract=True)
        if isinstance(node.op, ast.Mult):
            if left.length_power is None:
                return _Quantity(left.value * right.value, right.length_power)
            if right.length_power is None:
                return _Quantity(left.value * right.value, left.length_power)
            return _Quantity(
                left.value * right.value,
                left.length_power + right.length_power,
            )
        if isinstance(node.op, ast.Div):
            if right.value == 0.0:
                raise ValueError("division by zero")
            if left.length_power is None:
                power = None if left.value == 0.0 else -int(right.length_power or 0)
            elif right.length_power is None:
                power = left.length_power
            else:
                power = left.length_power - right.length_power
            return _Quantity(left.value / right.value, power)
    raise ValueError("only names, numeric literals, parentheses, and + - * / are allowed")


def _expression_names(node: ast.AST) -> frozenset[str]:
    return frozenset(
        item.id
        for item in ast.walk(node)
        if isinstance(item, ast.Name) and item.id != _UNIT_HELPER
    )


@dataclass(frozen=True, slots=True)
class ScalarExpression:
    """A safe scalar expression with an expected physical dimension."""

    source: str
    names: frozenset[str]
    expected_length_power: int
    _tree: ast.Expression = field(repr=False, compare=False)

    @classmethod
    def parse(
        cls,
        source: str,
        *,
        allowed_names: Sequence[str] = (),
        expected_length_power: int = _LENGTH_POWER,
        line_number: int = 1,
        field_name: str = "expression",
    ) -> "ScalarExpression":
        transformed = _normalised_expression_source(
            source,
            line_number=line_number,
            field_name=field_name,
        )
        try:
            parsed = ast.parse(transformed, mode="eval")
        except SyntaxError as error:
            raise _line_error(
                line_number,
                f"invalid expression in {field_name}: {source.strip()!r}",
            ) from error
        names = _expression_names(parsed)
        unknown = sorted(names.difference(allowed_names))
        if unknown:
            raise _line_error(
                line_number,
                f"unknown expression variable {unknown[0]!r} in {field_name}",
            )
        # A dry evaluation rejects every non-whitelisted AST construct.  Using
        # distinct values avoids false division-by-zero for common a-b terms.
        dry_variables = {
            name: float(index + 2) for index, name in enumerate(allowed_names)
        }
        try:
            quantity = _evaluate_node(parsed.body, dry_variables)
        except ValueError as error:
            if str(error) == "division by zero":
                # The expression may be valid for its real arguments.  Its AST
                # has already been traversed safely; defer the numeric check.
                quantity = None
            else:
                raise _line_error(
                    line_number,
                    f"invalid expression in {field_name}: {error}",
                ) from error
        if (
            quantity is not None
            and quantity.length_power not in (None, expected_length_power)
        ):
            expected = "a length" if expected_length_power == 1 else "dimensionless"
            raise _line_error(
                line_number,
                f"{field_name} must evaluate to {expected}",
            )
        return cls(
            source=source.strip(),
            names=names,
            expected_length_power=expected_length_power,
            _tree=parsed,
        )

    def evaluate(self, variables_mm: Mapping[str, float] | None = None) -> float:
        variables = variables_mm or {}
        missing = self.names.difference(variables)
        if missing:
            raise ValueError(f"missing expression variable {sorted(missing)[0]!r}")
        # Extra bound component parameters are normal and deliberately ignored.
        selected = {name: variables[name] for name in self.names}
        quantity = _evaluate_node(self._tree.body, selected)
        if quantity.length_power is None and quantity.value == 0.0:
            return 0.0
        if quantity.length_power != self.expected_length_power:
            expected = (
                "a length" if self.expected_length_power == 1 else "dimensionless"
            )
            raise ValueError(f"expression {self.source!r} must evaluate to {expected}")
        return _finite(quantity.value, field_name=f"expression {self.source!r}")

    def evaluate_mm(self, variables_mm: Mapping[str, float] | None = None) -> float:
        if self.expected_length_power != _LENGTH_POWER:
            raise ValueError("evaluate_mm requires a length expression")
        return self.evaluate(variables_mm)


@dataclass(frozen=True, slots=True)
class VectorExpression:
    values: tuple[ScalarExpression, ...]

    def evaluate(self, variables_mm: Mapping[str, float]) -> tuple[float, ...]:
        return tuple(value.evaluate(variables_mm) for value in self.values)


@dataclass(frozen=True, slots=True)
class PolygonSection:
    vertices: tuple[VectorExpression, ...]

    def evaluate_mm(
        self,
        variables_mm: Mapping[str, float],
    ) -> tuple[tuple[float, float, float], ...]:
        return tuple(
            tuple(vertex.evaluate(variables_mm))  # type: ignore[misc]
            for vertex in self.vertices
        )


class BooleanOperation(str, Enum):
    ADD = "+"
    SUBTRACT = "-"


@dataclass(frozen=True, slots=True)
class TranslationSweep:
    vector: VectorExpression


@dataclass(frozen=True, slots=True)
class RotationSweep:
    angles_deg: VectorExpression
    pivot: VectorExpression


Sweep: TypeAlias = TranslationSweep | RotationSweep


@dataclass(frozen=True, slots=True)
class SweepFeature:
    operation: BooleanOperation
    region_name: str
    section: PolygonSection
    sweep: Sweep
    line_number: int


@dataclass(frozen=True, slots=True)
class EvaluatedTranslationSweep:
    vector_mm: tuple[float, float, float]


@dataclass(frozen=True, slots=True)
class EvaluatedRotationSweep:
    angles_deg: tuple[float, float, float]
    pivot_mm: tuple[float, float, float]


EvaluatedSweep: TypeAlias = EvaluatedTranslationSweep | EvaluatedRotationSweep


@dataclass(frozen=True, slots=True)
class EvaluatedSweepFeature:
    operation: BooleanOperation
    region_name: str
    polygon_mm: tuple[tuple[float, float, float], ...]
    sweep: EvaluatedSweep


@dataclass(frozen=True, slots=True)
class EvaluatedComponent:
    name: str
    parameters_mm: Mapping[str, float]
    features: tuple[EvaluatedSweepFeature, ...]


@dataclass(frozen=True, slots=True)
class ComponentSpec:
    name: str
    parameters: tuple[str, ...]
    features: tuple[SweepFeature, ...]
    anchor_name: str = "loc"
    source_path: Path | None = None
    source_size_bytes: int | None = None
    source_sha256: str | None = None

    def bind_arguments(
        self,
        arguments_mm: Sequence[float] | Mapping[str, float],
    ) -> dict[str, float]:
        if isinstance(arguments_mm, Mapping):
            missing = set(self.parameters).difference(arguments_mm)
            extra = set(arguments_mm).difference(self.parameters)
            if missing or extra:
                details: list[str] = []
                if missing:
                    details.append(f"missing {sorted(missing)!r}")
                if extra:
                    details.append(f"unknown {sorted(extra)!r}")
                raise ValueError(
                    f"component {self.name!r} arguments: " + ", ".join(details)
                )
            raw_values = [arguments_mm[name] for name in self.parameters]
        else:
            raw_values = list(arguments_mm)
            if len(raw_values) != len(self.parameters):
                raise ValueError(
                    f"component {self.name!r} expects {len(self.parameters)} arguments, "
                    f"got {len(raw_values)}"
                )
        bound = {
            name: _finite(value, field_name=f"component parameter {name!r}")
            for name, value in zip(self.parameters, raw_values)
        }
        return bound

    def instantiate(
        self,
        arguments_mm: Sequence[float] | Mapping[str, float],
    ) -> EvaluatedComponent:
        bound = self.bind_arguments(arguments_mm)
        evaluated: list[EvaluatedSweepFeature] = []
        for feature in self.features:
            if isinstance(feature.sweep, TranslationSweep):
                vector = feature.sweep.vector.evaluate(bound)
                evaluated_sweep: EvaluatedSweep = EvaluatedTranslationSweep(
                    vector_mm=tuple(vector),  # type: ignore[arg-type]
                )
            else:
                angles = feature.sweep.angles_deg.evaluate(bound)
                pivot = feature.sweep.pivot.evaluate(bound)
                evaluated_sweep = EvaluatedRotationSweep(
                    angles_deg=tuple(angles),  # type: ignore[arg-type]
                    pivot_mm=tuple(pivot),  # type: ignore[arg-type]
                )
            evaluated.append(
                EvaluatedSweepFeature(
                    operation=feature.operation,
                    region_name=feature.region_name,
                    polygon_mm=feature.section.evaluate_mm(bound),
                    sweep=evaluated_sweep,
                )
            )
        return EvaluatedComponent(
            name=self.name,
            parameters_mm=dict(bound),
            features=tuple(evaluated),
        )


class PackageTransform(str, Enum):
    RX180 = "RX180"


@dataclass(frozen=True, slots=True)
class MeshSource:
    alias: str
    raw_path: str
    mesh_path: Path
    line_number: int


@dataclass(frozen=True, slots=True)
class MeshPlacement:
    operation: BooleanOperation
    source_alias: str
    loc_xy_mm: tuple[float, float]
    transform: PackageTransform
    line_number: int


@dataclass(frozen=True, slots=True)
class GeneratedPart:
    operation: BooleanOperation
    material_name: str
    loc_xy_mm: tuple[float, float]
    component_name: str
    arguments_mm: tuple[float, ...]
    line_number: int


PackageRecord: TypeAlias = MeshSource | MeshPlacement | GeneratedPart
PackagePlacement: TypeAlias = MeshPlacement | GeneratedPart


@dataclass(frozen=True, slots=True)
class PackageSpec:
    records: tuple[PackageRecord, ...]
    source_path: Path | None = None
    source_size_bytes: int | None = None
    source_sha256: str | None = None

    @property
    def mesh_sources(self) -> tuple[MeshSource, ...]:
        return tuple(item for item in self.records if isinstance(item, MeshSource))

    @property
    def placements(self) -> tuple[PackagePlacement, ...]:
        return tuple(item for item in self.records if not isinstance(item, MeshSource))

    @property
    def mesh_placements(self) -> tuple[MeshPlacement, ...]:
        return tuple(item for item in self.records if isinstance(item, MeshPlacement))

    @property
    def generated_parts(self) -> tuple[GeneratedPart, ...]:
        return tuple(item for item in self.records if isinstance(item, GeneratedPart))

    @property
    def mesh_source_by_alias(self) -> dict[str, MeshSource]:
        return {item.alias: item for item in self.mesh_sources}

    def validate_components(self, components: Mapping[str, ComponentSpec]) -> None:
        validate_package_components(self, components)


@dataclass(frozen=True, slots=True)
class PackageBundle:
    package: PackageSpec
    components: Mapping[str, ComponentSpec]


def _parse_vector_expression(
    source: str,
    *,
    expected_size: int,
    allowed_names: Sequence[str],
    expected_length_power: int,
    line_number: int,
    field_name: str,
) -> VectorExpression:
    stripped = source.strip()
    if len(stripped) < 2 or stripped[0] != "(" or stripped[-1] != ")":
        raise _line_error(line_number, f"{field_name} must be parenthesised")
    fields = split_top_level_commas(
        stripped[1:-1],
        line_number=line_number,
        field_name=field_name,
    )
    if len(fields) != expected_size:
        raise _line_error(
            line_number,
            f"{field_name} must contain {expected_size} values",
        )
    return VectorExpression(
        tuple(
            ScalarExpression.parse(
                value,
                allowed_names=allowed_names,
                expected_length_power=expected_length_power,
                line_number=line_number,
                field_name=f"{field_name}[{index}]",
            )
            for index, value in enumerate(fields)
        )
    )


def _parse_polygon_expression(
    source: str,
    *,
    allowed_names: Sequence[str],
    line_number: int,
) -> PolygonSection:
    stripped = source.strip()
    if len(stripped) < 2 or stripped[0] != "[" or stripped[-1] != "]":
        raise _line_error(line_number, "polygon vertices must be bracketed")
    vertices = split_top_level_commas(
        stripped[1:-1],
        line_number=line_number,
        field_name="polygon vertices",
    )
    if len(vertices) < 3:
        raise _line_error(line_number, "polygon must contain at least three vertices")
    return PolygonSection(
        tuple(
            _parse_vector_expression(
                vertex,
                expected_size=3,
                allowed_names=allowed_names,
                expected_length_power=_LENGTH_POWER,
                line_number=line_number,
                field_name=f"polygon vertex {index}",
            )
            for index, vertex in enumerate(vertices, start=1)
        )
    )


def parse_component_text(
    text: str,
    *,
    source_path: str | Path | None = None,
) -> ComponentSpec:
    """Parse and validate one component definition."""

    header: tuple[str, ...] | None = None
    header_line = 0
    feature_rows: list[tuple[int, tuple[str, ...]]] = []
    for line_number, raw_line in enumerate(text.splitlines(), start=1):
        if line_number == 1:
            raw_line = raw_line.removeprefix("\ufeff")
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        row = split_top_level_commas(
            raw_line,
            line_number=line_number,
            field_name="component record",
        )
        if header is None:
            header = row
            header_line = line_number
        else:
            feature_rows.append((line_number, row))

    if header is None:
        raise ValueError("component definition is empty")
    if len(header) < 4 or header[0].strip().lower() not in {"component", "define"}:
        raise _line_error(
            header_line,
            "component header must be 'component,name,loc,param,...'",
        )
    name = _identifier(
        header[1], line_number=header_line, field_name="component name"
    )
    anchor_name = _identifier(
        header[2], line_number=header_line, field_name="component anchor"
    )
    if anchor_name.lower() != "loc":
        raise _line_error(header_line, "component anchor must be loc")
    parameters = tuple(
        _identifier(
            value,
            line_number=header_line,
            field_name="component parameter",
        )
        for value in header[3:]
    )
    duplicates = sorted(name for name in set(parameters) if parameters.count(name) > 1)
    if duplicates:
        raise _line_error(
            header_line,
            f"duplicate component parameter {duplicates[0]!r}",
        )
    if anchor_name in parameters:
        raise _line_error(header_line, "component anchor cannot also be a parameter")

    features: list[SweepFeature] = []
    for line_number, row in feature_rows:
        if len(row) < 7:
            raise _line_error(line_number, "incomplete component sweep record")
        try:
            operation = BooleanOperation(row[0].strip())
        except ValueError as error:
            raise _line_error(line_number, "component operation must be + or -") from error
        region_name = _identifier(
            row[1], line_number=line_number, field_name="feature region name"
        )
        if row[2].strip().lower() != "sweep":
            raise _line_error(line_number, "component generation mode must be sweep")
        if row[3].strip().lower() != "polygon":
            raise _line_error(line_number, "component sweep section must be polygon")
        section = _parse_polygon_expression(
            row[4],
            allowed_names=parameters,
            line_number=line_number,
        )
        mode = row[5].strip().lower()
        if mode == "u":
            if len(row) != 7:
                raise _line_error(
                    line_number,
                    "translation sweep requires exactly one vector",
                )
            sweep: Sweep = TranslationSweep(
                _parse_vector_expression(
                    row[6],
                    expected_size=3,
                    allowed_names=parameters,
                    expected_length_power=_LENGTH_POWER,
                    line_number=line_number,
                    field_name="translation vector",
                )
            )
        elif mode == "r":
            if len(row) != 8:
                raise _line_error(
                    line_number,
                    "rotation sweep requires an angle vector and pivot",
                )
            sweep = RotationSweep(
                angles_deg=_parse_vector_expression(
                    row[6],
                    expected_size=3,
                    allowed_names=parameters,
                    expected_length_power=_NUMBER_POWER,
                    line_number=line_number,
                    field_name="rotation angle vector",
                ),
                pivot=_parse_vector_expression(
                    row[7],
                    expected_size=3,
                    allowed_names=parameters,
                    expected_length_power=_LENGTH_POWER,
                    line_number=line_number,
                    field_name="rotation pivot",
                ),
            )
        else:
            raise _line_error(line_number, "sweep mode must be u or r")
        features.append(
            SweepFeature(
                operation=operation,
                region_name=region_name,
                section=section,
                sweep=sweep,
                line_number=line_number,
            )
        )

    if not features:
        raise ValueError(f"component {name!r} must define at least one feature")
    resolved_source = (
        Path(source_path).expanduser().resolve() if source_path is not None else None
    )
    return ComponentSpec(
        name=name,
        parameters=parameters,
        features=tuple(features),
        anchor_name=anchor_name,
        source_path=resolved_source,
    )


def load_component_spec(path: str | Path) -> ComponentSpec:
    source = Path(path).expanduser().resolve()
    raw = source.read_bytes()
    parsed = parse_component_text(
        raw.decode("utf-8-sig"), source_path=source
    )
    return replace(
        parsed,
        source_size_bytes=len(raw),
        source_sha256=hashlib.sha256(raw).hexdigest(),
    )


def _unquote(value: str, *, line_number: int, field_name: str) -> str:
    stripped = value.strip()
    if not stripped:
        raise _line_error(line_number, f"{field_name} must not be empty")
    if stripped[0] not in {'"', "'"}:
        return stripped
    quote = stripped[0]
    if len(stripped) < 2 or stripped[-1] != quote:
        raise _line_error(line_number, f"unterminated quote in {field_name}")
    return stripped[1:-1].replace(quote + quote, quote)


def _package_loc(value: str, *, line_number: int) -> tuple[float, float]:
    vector = _parse_vector_expression(
        value,
        expected_size=2,
        allowed_names=(),
        expected_length_power=_LENGTH_POWER,
        line_number=line_number,
        field_name="package location",
    ).evaluate({})
    return tuple(vector)  # type: ignore[return-value]


def parse_package_text(
    text: str,
    base_directory: str | Path,
    *,
    source_path: str | Path | None = None,
) -> PackageSpec:
    """Parse a package assembly, resolving mesh paths against its directory."""

    base = Path(base_directory).expanduser().resolve()
    rows: list[tuple[int, tuple[str, ...]]] = []
    for line_number, raw_line in enumerate(text.splitlines(), start=1):
        if line_number == 1:
            raw_line = raw_line.removeprefix("\ufeff")
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        rows.append(
            (
                line_number,
                split_top_level_commas(
                    raw_line,
                    line_number=line_number,
                    field_name="package record",
                ),
            )
        )
    if not rows:
        raise ValueError("package definition is empty")

    sources: dict[str, MeshSource] = {}
    for line_number, row in rows:
        if row[0].strip() in {"+", "-"}:
            continue
        if len(row) != 2:
            raise _line_error(
                line_number,
                "mesh source declaration requires alias and path",
            )
        alias = _identifier(
            row[0], line_number=line_number, field_name="mesh source alias"
        )
        if alias in sources:
            raise _line_error(line_number, f"duplicate mesh source alias {alias!r}")
        raw_path = _unquote(
            row[1], line_number=line_number, field_name="mesh source path"
        )
        path = Path(raw_path).expanduser()
        mesh_path = path.resolve() if path.is_absolute() else (base / path).resolve()
        sources[alias] = MeshSource(
            alias=alias,
            raw_path=raw_path,
            mesh_path=mesh_path,
            line_number=line_number,
        )

    records: list[PackageRecord] = []
    for line_number, row in rows:
        if row[0].strip() not in {"+", "-"}:
            source = sources[row[0].strip()]
            records.append(source)
            continue
        try:
            operation = BooleanOperation(row[0].strip())
        except ValueError as error:  # pragma: no cover - guarded above
            raise _line_error(line_number, "package operation must be + or -") from error
        if len(row) < 2:
            raise _line_error(line_number, "incomplete package placement")
        placed_name = _non_empty(
            row[1], line_number=line_number, field_name="placed name"
        )
        if placed_name in sources:
            if len(row) != 4:
                raise _line_error(
                    line_number,
                    "mesh placement requires alias, location, and transform",
                )
            transform_token = row[3].strip().upper()
            try:
                transform = PackageTransform(transform_token)
            except ValueError as error:
                raise _line_error(
                    line_number,
                    f"unsupported mesh transform {row[3].strip()!r}",
                ) from error
            records.append(
                MeshPlacement(
                    operation=operation,
                    source_alias=placed_name,
                    loc_xy_mm=_package_loc(row[2], line_number=line_number),
                    transform=transform,
                    line_number=line_number,
                )
            )
            continue
        if len(row) < 5:
            raise _line_error(
                line_number,
                "generated part requires material, location, component, and arguments",
            )
        material_name = placed_name
        component_name = _identifier(
            row[3], line_number=line_number, field_name="component name"
        )
        arguments: list[float] = []
        for index, expression in enumerate(row[4:], start=1):
            value = ScalarExpression.parse(
                expression,
                expected_length_power=_LENGTH_POWER,
                line_number=line_number,
                field_name=f"component argument {index}",
            ).evaluate_mm()
            if value <= 0.0:
                raise _line_error(
                    line_number,
                    f"component argument {index} must be positive",
                )
            arguments.append(value)
        records.append(
            GeneratedPart(
                operation=operation,
                material_name=material_name,
                loc_xy_mm=_package_loc(row[2], line_number=line_number),
                component_name=component_name,
                arguments_mm=tuple(arguments),
                line_number=line_number,
            )
        )

    if not sources:
        raise ValueError("package must declare at least one mesh source")
    if not any(not isinstance(item, MeshSource) for item in records):
        raise ValueError("package must contain at least one placement")
    resolved_source = (
        Path(source_path).expanduser().resolve() if source_path is not None else None
    )
    return PackageSpec(records=tuple(records), source_path=resolved_source)


def load_package_spec(path: str | Path) -> PackageSpec:
    source = Path(path).expanduser().resolve()
    raw = source.read_bytes()
    parsed = parse_package_text(
        raw.decode("utf-8-sig"),
        source.parent,
        source_path=source,
    )
    return replace(
        parsed,
        source_size_bytes=len(raw),
        source_sha256=hashlib.sha256(raw).hexdigest(),
    )


def validate_package_components(
    package: PackageSpec,
    components: Mapping[str, ComponentSpec],
) -> None:
    for part in package.generated_parts:
        component = components.get(part.component_name)
        if component is None:
            raise ValueError(
                f"line {part.line_number}: unknown component {part.component_name!r}"
            )
        if len(part.arguments_mm) != len(component.parameters):
            raise ValueError(
                f"line {part.line_number}: component {part.component_name!r} expects "
                f"{len(component.parameters)} arguments, got {len(part.arguments_mm)}"
            )


def load_component_library(
    directory: str | Path,
    component_names: Sequence[str] | None = None,
) -> dict[str, ComponentSpec]:
    """Load named ``*.component`` files or every component in a directory."""

    root = Path(directory).expanduser().resolve()
    paths = (
        tuple(root / f"{name}.component" for name in component_names)
        if component_names is not None
        else tuple(sorted(root.glob("*.component")))
    )
    components: dict[str, ComponentSpec] = {}
    for path in paths:
        component = load_component_spec(path)
        if component.name in components:
            first = components[component.name].source_path
            raise ValueError(
                f"duplicate component name {component.name!r}: {first} and {path}"
            )
        components[component.name] = component
    return components


def load_package_bundle(
    path: str | Path,
    *,
    component_directory: str | Path | None = None,
) -> PackageBundle:
    package = load_package_spec(path)
    root = (
        Path(component_directory).expanduser().resolve()
        if component_directory is not None
        else package.source_path.parent  # type: ignore[union-attr]
    )
    names = tuple(dict.fromkeys(part.component_name for part in package.generated_parts))
    components = load_component_library(root, names)
    validate_package_components(package, components)
    return PackageBundle(package=package, components=components)


__all__ = [
    "BooleanOperation",
    "ComponentSpec",
    "EvaluatedComponent",
    "EvaluatedRotationSweep",
    "EvaluatedSweepFeature",
    "EvaluatedTranslationSweep",
    "GeneratedPart",
    "MeshPlacement",
    "MeshSource",
    "PackageBundle",
    "PackageSpec",
    "PackageTransform",
    "PolygonSection",
    "RotationSweep",
    "ScalarExpression",
    "SweepFeature",
    "TranslationSweep",
    "VectorExpression",
    "load_component_library",
    "load_component_spec",
    "load_package_bundle",
    "load_package_spec",
    "parse_component_text",
    "parse_package_text",
    "split_top_level_commas",
    "validate_package_components",
]
