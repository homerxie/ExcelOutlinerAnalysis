"""Atomic Gmsh writer for a trusted in-process multi-source assembly plan.

This module is intentionally downstream-only and never changes assembly
topology.  It consumes the complete Frozen snapshots named by the plan, deeply
replays their artifact-bound public audit, replays the public plan audit, and
then reverse-binds every plan node, element, and declared Physical Group to the
canonical snapshots.  Elements with the same complete 3-D Physical Group
membership signature are written to one deterministic discrete volume entity;
every plan node is registered once and shared output tags are never merged by
coordinate.

The plan's provenance SHA is intentionally opaque here: this writer cannot
independently re-prove that a shared output node was authorized by a particular
``DeclaredSharedInterface``.  A worker or persisted-plan consumer must first
rebuild the plan from the complete ``MultiSourceInput`` and shared-interface
declarations in a trusted process, then pass that freshly rebuilt plan here.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json
import math
from pathlib import Path
import re
from types import MappingProxyType
from typing import Any, Iterable, Mapping, Sequence

from .gmsh_runtime import isolated_gmsh_model
from .output_artifacts import (
    atomic_output_path,
    exclusive_output_lock,
    file_artifact,
    normalized_mesh_output,
    paths_refer_to_same_file,
)
from .package_v2_multi_source import (
    AssemblyElement,
    AssemblyNode,
    AssemblyPhysicalGroup,
    MultiSourceAssemblyError,
    MultiSourceAssemblyPlan,
    audit_multi_source_assembly_plan,
)
from .package_v2_frozen import (
    FrozenArtifactIdentity,
    FrozenSourceError,
    FrozenSourceSnapshot,
    audit_frozen_source_snapshot,
)
from .volume_mesh import ElementKind, PhysicalGroup, VolumeMesh, load_volume_mesh
from .package_v2_instance_transform import placed_connectivity


_ARTIFACT_ROLES = ("mesh",)
_QUALITY_METRICS = ("minDetJac", "minSJ", "minSICN", "minSIGE")
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
_QUALITY_ROUNDTRIP_RELATIVE_TOLERANCE = 1.0e-8
_COORDINATE_ROUNDTRIP_ULPS = 64.0
_COORDINATE_ASSEMBLY_RELATIVE_CAP = 1.0e-12
_MAXIMUM_NAME_UTF8_BYTES = 4_096
_MAPPING_PROXY_TYPE = type(MappingProxyType({}))

_HARD_RESOURCE_CEILINGS = {
    "maximum_source_count": 256,
    "maximum_node_count": 10_000_000,
    "maximum_element_count": 20_000_000,
    "maximum_connectivity_count": 160_000_000,
    "maximum_entity_count": 1_000_000,
    "maximum_physical_group_count": 1_000_000,
    "maximum_physical_group_membership_count": 20_000_000,
    "maximum_metadata_utf8_bytes": 64 * 1024 * 1024,
    "maximum_estimated_working_bytes": 4 * 1024 * 1024 * 1024,
    "maximum_output_file_bytes": 16 * 1024 * 1024 * 1024,
}


class MultiSourceWriterError(RuntimeError):
    """Raised when a plan cannot be safely published as Gmsh MSH 4.1."""


def _positive_integer(value: object, *, field_name: str) -> int:
    if type(value) is not int or value < 1:
        raise MultiSourceWriterError(f"{field_name} must be a positive integer")
    return value


def _canonical_name(value: object, *, field_name: str) -> str:
    if (
        type(value) is not str
        or not value
        or value != value.strip()
        or len(value) > _MAXIMUM_NAME_UTF8_BYTES
        or any(
            ord(character) < 32
            or 127 <= ord(character) <= 159
            or character == '"'
            for character in value
        )
    ):
        raise MultiSourceWriterError(
            f"{field_name} must be a non-empty canonical string"
        )
    if len(value.encode("utf-8")) > _MAXIMUM_NAME_UTF8_BYTES:
        raise MultiSourceWriterError(
            f"{field_name} exceeds the UTF-8 byte limit"
        )
    return value


def _sha256(value: object, *, field_name: str) -> str:
    if type(value) is not str or _SHA256.fullmatch(value) is None:
        raise MultiSourceWriterError(f"{field_name} must be a lowercase SHA-256")
    return value


def _strictly_increasing(values: Iterable[Any]) -> bool:
    iterator = iter(values)
    try:
        previous = next(iterator)
    except StopIteration:
        return True
    for current in iterator:
        if not previous < current:
            return False
        previous = current
    return True


def _canonical_json_bytes(value: object) -> bytes:
    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    except (OverflowError, TypeError, ValueError) as error:
        raise MultiSourceWriterError("cannot encode writer evidence") from error


def _digest(value: object) -> str:
    return hashlib.sha256(_canonical_json_bytes(value)).hexdigest()


def _update_digest_record(digest: Any, value: object) -> None:
    encoded = _canonical_json_bytes(value)
    digest.update(len(encoded).to_bytes(8, "big"))
    digest.update(encoded)


def _stream_digest(
    *,
    schema: str,
    metadata: object,
    sections: Iterable[tuple[str, int, Iterable[object]]],
) -> str:
    digest = hashlib.sha256()
    _update_digest_record(digest, {"schema": schema, "metadata": metadata})
    for name, expected_count, rows in sections:
        _update_digest_record(
            digest,
            {"section": name, "count": expected_count},
        )
        actual_count = 0
        for row in rows:
            _update_digest_record(digest, row)
            actual_count += 1
        if actual_count != expected_count:
            raise MultiSourceWriterError(
                f"writer digest section {name!r} has inconsistent length"
            )
    return digest.hexdigest()


@dataclass(frozen=True, slots=True)
class MultiSourceWriterLimits:
    """Caller-lowerable writer quotas bounded by fixed safety ceilings."""

    maximum_source_count: int = 256
    maximum_node_count: int = 10_000_000
    maximum_element_count: int = 20_000_000
    maximum_connectivity_count: int = 160_000_000
    maximum_entity_count: int = 1_000_000
    maximum_physical_group_count: int = 1_000_000
    maximum_physical_group_membership_count: int = 20_000_000
    maximum_metadata_utf8_bytes: int = 64 * 1024 * 1024
    maximum_estimated_working_bytes: int = 4 * 1024 * 1024 * 1024
    maximum_output_file_bytes: int = 16 * 1024 * 1024 * 1024

    def __post_init__(self) -> None:
        for field_name, ceiling in _HARD_RESOURCE_CEILINGS.items():
            value = _positive_integer(getattr(self, field_name), field_name=field_name)
            if value > ceiling:
                raise MultiSourceWriterError(
                    f"{field_name} exceeds the implementation safety ceiling"
                )
            object.__setattr__(self, field_name, value)


@dataclass(frozen=True, slots=True)
class MultiSourceWriterResourceEvidence:
    source_count: int
    node_count: int
    element_count: int
    connectivity_count: int
    entity_count: int
    physical_group_count: int
    physical_group_membership_count: int
    metadata_utf8_bytes: int
    estimated_working_bytes: int
    estimated_output_file_bytes: int

    def __post_init__(self) -> None:
        ceiling_by_field = {
            "source_count": _HARD_RESOURCE_CEILINGS["maximum_source_count"],
            "node_count": _HARD_RESOURCE_CEILINGS["maximum_node_count"],
            "element_count": _HARD_RESOURCE_CEILINGS["maximum_element_count"],
            "connectivity_count": _HARD_RESOURCE_CEILINGS[
                "maximum_connectivity_count"
            ],
            "entity_count": _HARD_RESOURCE_CEILINGS["maximum_entity_count"],
            "physical_group_count": _HARD_RESOURCE_CEILINGS[
                "maximum_physical_group_count"
            ],
            "physical_group_membership_count": _HARD_RESOURCE_CEILINGS[
                "maximum_physical_group_membership_count"
            ],
            "metadata_utf8_bytes": _HARD_RESOURCE_CEILINGS[
                "maximum_metadata_utf8_bytes"
            ],
            "estimated_working_bytes": _HARD_RESOURCE_CEILINGS[
                "maximum_estimated_working_bytes"
            ],
            "estimated_output_file_bytes": _HARD_RESOURCE_CEILINGS[
                "maximum_output_file_bytes"
            ],
        }
        for field_name, ceiling in ceiling_by_field.items():
            value = _positive_integer(
                getattr(self, field_name),
                field_name=field_name,
            )
            if value > ceiling:
                raise MultiSourceWriterError(
                    f"{field_name} exceeds the implementation safety ceiling"
                )


@dataclass(frozen=True, slots=True)
class MultiSourceWriterQualityEvidence:
    element_count: int
    minimum_determinant: float
    minimum_scaled_jacobian: float
    minimum_sicn: float
    minimum_sige: float
    values_numbered_sha256: str

    def __post_init__(self) -> None:
        _positive_integer(self.element_count, field_name="quality element_count")
        for field_name in (
            "minimum_determinant",
            "minimum_scaled_jacobian",
            "minimum_sicn",
            "minimum_sige",
        ):
            value = getattr(self, field_name)
            if type(value) is not float or not math.isfinite(value):
                raise MultiSourceWriterError(
                    f"quality {field_name} must be finite"
                )
        if self.minimum_determinant <= 0.0:
            raise MultiSourceWriterError(
                "quality minimum_determinant must be positive"
            )
        if any(
            getattr(self, field_name) <= 0.0
            for field_name in (
                "minimum_scaled_jacobian",
                "minimum_sicn",
                "minimum_sige",
            )
        ):
            raise MultiSourceWriterError(
                "all minimum Gmsh quality metrics must be positive"
            )
        _sha256(
            self.values_numbered_sha256,
            field_name="quality values_numbered_sha256",
        )


@dataclass(frozen=True, slots=True)
class MultiSourceEntityEvidence:
    entity_tag: int
    physical_group_tags: tuple[int, ...]
    element_tags: tuple[int, ...]

    def __post_init__(self) -> None:
        _positive_integer(self.entity_tag, field_name="entity_tag")
        if (
            type(self.physical_group_tags) is not tuple
            or not self.physical_group_tags
            or any(
                _positive_integer(value, field_name="Physical Group tag") != value
                for value in self.physical_group_tags
            )
            or not _strictly_increasing(self.physical_group_tags)
        ):
            raise MultiSourceWriterError(
                "entity Physical Group signature must be sorted and unique"
            )
        if (
            type(self.element_tags) is not tuple
            or not self.element_tags
            or any(
                _positive_integer(value, field_name="entity element tag") != value
                for value in self.element_tags
            )
            or not _strictly_increasing(self.element_tags)
        ):
            raise MultiSourceWriterError(
                "entity element membership must be sorted and unique"
            )


@dataclass(frozen=True, slots=True)
class MultiSourceWriterSummary:
    """Report-ready evidence constructed before atomic publication commits."""

    output_path: str
    plan_numbered_sha256: str
    plan_provenance_sha256: str
    protected_artifacts_numbered_sha256: str
    entity_evidence: tuple[MultiSourceEntityEvidence, ...]
    physical_groups: tuple[tuple[int, str], ...]
    resources: MultiSourceWriterResourceEvidence
    quality: MultiSourceWriterQualityEvidence
    numbered_mesh_sha256: str
    live_quality_numbered_sha256: str
    output_size_bytes: int
    output_sha256: str
    reopened_verified: bool
    canonical_frozen_snapshot_content_bound: bool
    shared_node_authorization_independently_replayed: bool
    binding_sha256: str = field(init=False)

    def __post_init__(self) -> None:
        if (
            type(self.output_path) is not str
            or not Path(self.output_path).is_absolute()
        ):
            raise MultiSourceWriterError("summary output_path must be absolute")
        for field_name in (
            "plan_numbered_sha256",
            "plan_provenance_sha256",
            "protected_artifacts_numbered_sha256",
            "numbered_mesh_sha256",
            "live_quality_numbered_sha256",
            "output_sha256",
        ):
            _sha256(getattr(self, field_name), field_name=field_name)
        if type(self.resources) is not MultiSourceWriterResourceEvidence:
            raise MultiSourceWriterError("summary resource evidence is invalid")
        self.resources.__post_init__()
        if type(self.quality) is not MultiSourceWriterQualityEvidence:
            raise MultiSourceWriterError("summary quality evidence is invalid")
        self.quality.__post_init__()
        if (
            type(self.entity_evidence) is not tuple
            or not self.entity_evidence
            or len(self.entity_evidence) > self.resources.entity_count
            or any(
                type(value) is not MultiSourceEntityEvidence
                for value in self.entity_evidence
            )
        ):
            raise MultiSourceWriterError("summary entity evidence is invalid")
        for value in self.entity_evidence:
            value.__post_init__()
        if tuple(value.entity_tag for value in self.entity_evidence) != tuple(
            range(1, len(self.entity_evidence) + 1)
        ):
            raise MultiSourceWriterError("summary entity tags must be dense")
        if type(self.physical_groups) is not tuple or not self.physical_groups:
            raise MultiSourceWriterError("summary Physical Groups must be non-empty")
        if len(self.physical_groups) > self.resources.physical_group_count:
            raise MultiSourceWriterError(
                "summary Physical Group evidence exceeds its resource count"
            )
        for group in self.physical_groups:
            if (
                type(group) is not tuple
                or len(group) != 2
                or _positive_integer(group[0], field_name="Physical Group tag")
                != group[0]
                or _canonical_name(group[1], field_name="Physical Group name")
                != group[1]
            ):
                raise MultiSourceWriterError("summary Physical Group is invalid")
        if len(self.entity_evidence) != self.resources.entity_count:
            raise MultiSourceWriterError(
                "summary entity count differs from resource evidence"
            )
        if len(self.physical_groups) != self.resources.physical_group_count:
            raise MultiSourceWriterError(
                "summary Physical Group count differs from resource evidence"
            )
        if any(
            value[0] != expected_tag
            for expected_tag, value in enumerate(self.physical_groups, 1)
        ):
            raise MultiSourceWriterError(
                "summary Physical Group tags must be dense"
            )
        seen_elements = bytearray(self.resources.element_count + 1)
        element_count = 0
        for entity in self.entity_evidence:
            if any(
                tag > self.resources.physical_group_count
                for tag in entity.physical_group_tags
            ):
                raise MultiSourceWriterError(
                    "summary entity references an unknown Physical Group"
                )
            for element_tag in entity.element_tags:
                if (
                    element_tag > self.resources.element_count
                    or seen_elements[element_tag]
                ):
                    raise MultiSourceWriterError(
                        "summary entities must partition every dense element "
                        "tag once"
                    )
                seen_elements[element_tag] = 1
                element_count += 1
        if element_count != self.resources.element_count:
            raise MultiSourceWriterError(
                "summary entities must partition every dense element tag once"
            )
        membership_count = sum(
            len(entity.physical_group_tags) * len(entity.element_tags)
            for entity in self.entity_evidence
        )
        if membership_count != self.resources.physical_group_membership_count:
            raise MultiSourceWriterError(
                "summary Physical Group membership count is inconsistent"
            )
        if self.quality.element_count != self.resources.element_count:
            raise MultiSourceWriterError(
                "summary quality element count differs from resources"
            )
        output_size = _positive_integer(
            self.output_size_bytes,
            field_name="output_size_bytes",
        )
        if output_size > _HARD_RESOURCE_CEILINGS["maximum_output_file_bytes"]:
            raise MultiSourceWriterError(
                "summary output size exceeds the implementation safety ceiling"
            )
        if self.reopened_verified is not True:
            raise MultiSourceWriterError("summary must prove the written MSH reopened")
        if self.canonical_frozen_snapshot_content_bound is not True:
            raise MultiSourceWriterError(
                "summary must prove canonical Frozen snapshot content binding"
            )
        if self.shared_node_authorization_independently_replayed is not False:
            raise MultiSourceWriterError(
                "writer cannot claim independent shared-node authorization replay"
            )
        object.__setattr__(
            self,
            "binding_sha256",
            _summary_binding_sha256(self),
        )

    def to_report_dict(self) -> dict[str, object]:
        """Return JSON-ready evidence without weakening immutable DTO checks."""

        audit_multi_source_writer_summary(self)
        return {
            "schema": "easymesh-package-v2-multi-source-writer-report-v2",
            "output_path": self.output_path,
            "plan_numbered_sha256": self.plan_numbered_sha256,
            "plan_provenance_sha256": self.plan_provenance_sha256,
            "protected_artifacts_numbered_sha256": (
                self.protected_artifacts_numbered_sha256
            ),
            "node_count": self.resources.node_count,
            "element_count": self.resources.element_count,
            "entity_count": self.resources.entity_count,
            "physical_group_count": self.resources.physical_group_count,
            "numbered_mesh_sha256": self.numbered_mesh_sha256,
            "quality": {
                "minimum_determinant": self.quality.minimum_determinant,
                "minimum_scaled_jacobian": self.quality.minimum_scaled_jacobian,
                "minimum_sicn": self.quality.minimum_sicn,
                "minimum_sige": self.quality.minimum_sige,
                "values_numbered_sha256": self.quality.values_numbered_sha256,
            },
            "artifact": {
                "path": self.output_path,
                "size_bytes": self.output_size_bytes,
                "sha256": self.output_sha256,
            },
            "capabilities": {
                "canonical_frozen_snapshot_content_bound": (
                    self.canonical_frozen_snapshot_content_bound
                ),
                "shared_node_authorization_independently_replayed": (
                    self.shared_node_authorization_independently_replayed
                ),
                "trusted_in_process_planner_provenance_required": True,
            },
            "binding_sha256": self.binding_sha256,
            "reopened_verified": self.reopened_verified,
        }


def _summary_binding_sha256(value: MultiSourceWriterSummary) -> str:
    entity_group_count = sum(
        len(entity.physical_group_tags) for entity in value.entity_evidence
    )
    entity_element_count = sum(
        len(entity.element_tags) for entity in value.entity_evidence
    )
    resources = value.resources
    quality = value.quality
    return _stream_digest(
        schema="easymesh-package-v2-multi-source-writer-summary-v3",
        metadata={
            "output_path": value.output_path,
            "plan_numbered_sha256": value.plan_numbered_sha256,
            "plan_provenance_sha256": value.plan_provenance_sha256,
            "protected_artifacts_numbered_sha256": (
                value.protected_artifacts_numbered_sha256
            ),
            "resources": [
                resources.source_count,
                resources.node_count,
                resources.element_count,
                resources.connectivity_count,
                resources.entity_count,
                resources.physical_group_count,
                resources.physical_group_membership_count,
                resources.metadata_utf8_bytes,
                resources.estimated_working_bytes,
                resources.estimated_output_file_bytes,
            ],
            "quality": [
                quality.element_count,
                quality.minimum_determinant,
                quality.minimum_scaled_jacobian,
                quality.minimum_sicn,
                quality.minimum_sige,
                quality.values_numbered_sha256,
            ],
            "numbered_mesh_sha256": value.numbered_mesh_sha256,
            "live_quality_numbered_sha256": value.live_quality_numbered_sha256,
            "artifact": [value.output_size_bytes, value.output_sha256],
            "reopened_verified": value.reopened_verified,
            "canonical_frozen_snapshot_content_bound": (
                value.canonical_frozen_snapshot_content_bound
            ),
            "shared_node_authorization_independently_replayed": (
                value.shared_node_authorization_independently_replayed
            ),
        },
        sections=(
            (
                "entities",
                len(value.entity_evidence),
                (
                    [
                        entity.entity_tag,
                        len(entity.physical_group_tags),
                        len(entity.element_tags),
                    ]
                    for entity in value.entity_evidence
                ),
            ),
            (
                "entity_group_memberships",
                entity_group_count,
                (
                    [entity.entity_tag, group_tag]
                    for entity in value.entity_evidence
                    for group_tag in entity.physical_group_tags
                ),
            ),
            (
                "entity_element_memberships",
                entity_element_count,
                (
                    [entity.entity_tag, element_tag]
                    for entity in value.entity_evidence
                    for element_tag in entity.element_tags
                ),
            ),
            (
                "physical_groups",
                len(value.physical_groups),
                ([tag, name] for tag, name in value.physical_groups),
            ),
        ),
    )


def audit_multi_source_writer_summary(
    value: MultiSourceWriterSummary,
) -> MultiSourceWriterSummary:
    """Deeply replay report-ready writer evidence before downstream use."""

    if type(value) is not MultiSourceWriterSummary:
        raise MultiSourceWriterError(
            "summary must be an exact MultiSourceWriterSummary"
        )
    try:
        resources = MultiSourceWriterResourceEvidence(
            value.resources.source_count,
            value.resources.node_count,
            value.resources.element_count,
            value.resources.connectivity_count,
            value.resources.entity_count,
            value.resources.physical_group_count,
            value.resources.physical_group_membership_count,
            value.resources.metadata_utf8_bytes,
            value.resources.estimated_working_bytes,
            value.resources.estimated_output_file_bytes,
        )
        if (
            type(value.entity_evidence) is not tuple
            or len(value.entity_evidence) > resources.entity_count
            or type(value.physical_groups) is not tuple
            or len(value.physical_groups) > resources.physical_group_count
        ):
            raise MultiSourceWriterError(
                "writer summary outer evidence exceeds its resource counts"
            )
        entities = tuple(
            MultiSourceEntityEvidence(
                entity.entity_tag,
                entity.physical_group_tags,
                entity.element_tags,
            )
            for entity in value.entity_evidence
        )
        quality = MultiSourceWriterQualityEvidence(
            value.quality.element_count,
            value.quality.minimum_determinant,
            value.quality.minimum_scaled_jacobian,
            value.quality.minimum_sicn,
            value.quality.minimum_sige,
            value.quality.values_numbered_sha256,
        )
        replayed = MultiSourceWriterSummary(
            value.output_path,
            value.plan_numbered_sha256,
            value.plan_provenance_sha256,
            value.protected_artifacts_numbered_sha256,
            entities,
            value.physical_groups,
            resources,
            quality,
            value.numbered_mesh_sha256,
            value.live_quality_numbered_sha256,
            value.output_size_bytes,
            value.output_sha256,
            value.reopened_verified,
            value.canonical_frozen_snapshot_content_bound,
            value.shared_node_authorization_independently_replayed,
        )
    except (AttributeError, TypeError, ValueError) as error:
        raise MultiSourceWriterError(
            "writer summary evidence is stale or invalid"
        ) from error
    if replayed != value:
        raise MultiSourceWriterError(
            "writer summary evidence is stale or non-canonical"
        )
    return replayed


@dataclass(frozen=True, slots=True)
class _EntityLayout:
    entities: tuple[MultiSourceEntityEvidence, ...]
    entity_by_element_tag: Mapping[int, int]
    entity_by_tag: Mapping[int, MultiSourceEntityEvidence]
    entity_tags_by_physical_group: Mapping[int, tuple[int, ...]]


@dataclass(frozen=True, slots=True)
class _QualityValues:
    element_tags: tuple[int, ...]
    metrics: Mapping[str, tuple[float, ...]]

    @property
    def numbered_sha256(self) -> str:
        return _stream_digest(
            schema="easymesh-package-v2-writer-quality-values-v2",
            metadata={"metrics": list(_QUALITY_METRICS)},
            sections=(
                (
                    "element_quality",
                    len(self.element_tags),
                    (
                        [
                            tag,
                            *(self.metrics[name][index] for name in _QUALITY_METRICS),
                        ]
                        for index, tag in enumerate(self.element_tags)
                    ),
                ),
            ),
        )

    @property
    def evidence(self) -> MultiSourceWriterQualityEvidence:
        return MultiSourceWriterQualityEvidence(
            len(self.element_tags),
            min(self.metrics["minDetJac"]),
            min(self.metrics["minSJ"]),
            min(self.metrics["minSICN"]),
            min(self.metrics["minSIGE"]),
            self.numbered_sha256,
        )


def _audit_limits(limits: MultiSourceWriterLimits) -> MultiSourceWriterLimits:
    if type(limits) is not MultiSourceWriterLimits:
        raise MultiSourceWriterError("limits must be MultiSourceWriterLimits")
    replayed = MultiSourceWriterLimits(
        maximum_source_count=limits.maximum_source_count,
        maximum_node_count=limits.maximum_node_count,
        maximum_element_count=limits.maximum_element_count,
        maximum_connectivity_count=limits.maximum_connectivity_count,
        maximum_entity_count=limits.maximum_entity_count,
        maximum_physical_group_count=limits.maximum_physical_group_count,
        maximum_physical_group_membership_count=(
            limits.maximum_physical_group_membership_count
        ),
        maximum_metadata_utf8_bytes=limits.maximum_metadata_utf8_bytes,
        maximum_estimated_working_bytes=limits.maximum_estimated_working_bytes,
        maximum_output_file_bytes=limits.maximum_output_file_bytes,
    )
    if replayed != limits:
        raise MultiSourceWriterError("writer limits are stale or non-canonical")
    return replayed


@dataclass(frozen=True, slots=True)
class _CheapPlanCounts:
    source_count: int
    connectivity_count: int
    source_node_membership_count: int
    physical_group_provenance_count: int
    physical_group_membership_count: int
    metadata_utf8_bytes: int


def _cheap_plan_preflight(
    plan: MultiSourceAssemblyPlan,
    limits: MultiSourceWriterLimits,
) -> _CheapPlanCounts:
    """Apply caller quotas before the public plan audit hashes/builds maps."""

    if (
        type(plan.nodes) is not tuple
        or type(plan.elements) is not tuple
        or type(plan.physical_groups) is not tuple
        or type(plan.source_component_global_ids) is not _MAPPING_PROXY_TYPE
        or type(plan.source_snapshot_numbered_sha256) is not _MAPPING_PROXY_TYPE
    ):
        raise MultiSourceWriterError("multi-source plan outer evidence is invalid")
    source_count = len(plan.source_component_global_ids)
    if len(plan.source_snapshot_numbered_sha256) != source_count:
        raise MultiSourceWriterError("multi-source plan source maps differ in size")
    fixed_checks = (
        ("source count", source_count, limits.maximum_source_count),
        ("node count", len(plan.nodes), limits.maximum_node_count),
        ("element count", len(plan.elements), limits.maximum_element_count),
        (
            "Physical Group count",
            len(plan.physical_groups),
            limits.maximum_physical_group_count,
        ),
    )
    for label, actual, maximum in fixed_checks:
        if actual < 1 or actual > maximum:
            raise MultiSourceWriterError(
                f"writer {label} exceeds the resource limit: {actual} > {maximum}"
            )

    metadata_bytes = 0

    def add_name(value: object, *, field_name: str) -> None:
        nonlocal metadata_bytes
        name = _canonical_name(value, field_name=field_name)
        metadata_bytes += len(name.encode("utf-8"))
        if metadata_bytes > limits.maximum_metadata_utf8_bytes:
            raise MultiSourceWriterError(
                "writer metadata UTF-8 bytes exceed the resource limit"
            )

    for source_id, component_id in plan.source_component_global_ids.items():
        add_name(source_id, field_name="plan source ID")
        add_name(component_id, field_name="plan global Component ID")
    for source_id in plan.source_snapshot_numbered_sha256:
        add_name(source_id, field_name="plan snapshot source ID")

    source_node_membership_count = 0
    for node in plan.nodes:
        if type(node) is not AssemblyNode or type(node.source_nodes) is not tuple:
            raise MultiSourceWriterError("plan contains invalid outer node evidence")
        source_node_membership_count += len(node.source_nodes)
        for source_node in node.source_nodes:
            if type(source_node) is not tuple or len(source_node) != 2:
                raise MultiSourceWriterError(
                    "plan node provenance has invalid outer evidence"
                )
            source_id, _source_tag = source_node
            add_name(source_id, field_name="node provenance source ID")

    connectivity_count = 0
    for element in plan.elements:
        if type(element) is not AssemblyElement or type(element.node_tags) is not tuple:
            raise MultiSourceWriterError(
                "plan contains invalid outer element evidence"
            )
        connectivity_count += len(element.node_tags)
        if connectivity_count > limits.maximum_connectivity_count:
            raise MultiSourceWriterError(
                "writer connectivity count exceeds the resource limit"
            )
        add_name(element.source_id, field_name="element source ID")
        add_name(
            element.source_component_global_id,
            field_name="element global Component ID",
        )

    membership_count = 0
    provenance_count = 0
    for group in plan.physical_groups:
        if (
            type(group) is not AssemblyPhysicalGroup
            or type(group.element_tags) is not tuple
            or type(group.source_groups) is not tuple
        ):
            raise MultiSourceWriterError(
                "plan contains invalid outer Physical Group evidence"
            )
        membership_count += len(group.element_tags)
        provenance_count += len(group.source_groups)
        if membership_count > limits.maximum_physical_group_membership_count:
            raise MultiSourceWriterError(
                "writer Physical Group memberships exceed the resource limit"
            )
        add_name(group.name, field_name="Physical Group name")
        for source_group in group.source_groups:
            if type(source_group) is not tuple or len(source_group) != 3:
                raise MultiSourceWriterError(
                    "plan Physical Group provenance has invalid outer evidence"
                )
            source_id, _source_tag, source_name = source_group
            add_name(source_id, field_name="Physical Group provenance source ID")
            add_name(source_name, field_name="source Physical Group name")
    return _CheapPlanCounts(
        source_count,
        connectivity_count,
        source_node_membership_count,
        provenance_count,
        membership_count,
        metadata_bytes,
    )


def _add_frozen_metadata_preflight(
    counts: _CheapPlanCounts,
    values: tuple[FrozenSourceSnapshot, ...],
    limits: MultiSourceWriterLimits,
) -> _CheapPlanCounts:
    metadata_bytes = counts.metadata_utf8_bytes
    for snapshot in values:
        if (
            type(snapshot) is not FrozenSourceSnapshot
            or type(snapshot.artifacts) is not _MAPPING_PROXY_TYPE
            or tuple(snapshot.artifacts) != _ARTIFACT_ROLES
        ):
            raise MultiSourceWriterError(
                "frozen_sources contains invalid outer artifact evidence"
            )
        for role in _ARTIFACT_ROLES:
            identity = snapshot.artifacts[role]
            if type(identity) is not FrozenArtifactIdentity:
                raise MultiSourceWriterError(
                    "frozen_sources contains invalid artifact evidence"
                )
            for field_name, text in (
                ("artifact declaration", identity.declaration),
                ("artifact runtime path", identity.runtime_path),
            ):
                if type(text) is not str or not text:
                    raise MultiSourceWriterError(
                        f"Frozen {field_name} must be non-empty text"
                    )
                try:
                    size = len(text.encode("utf-8"))
                except UnicodeError as error:
                    raise MultiSourceWriterError(
                        f"Frozen {field_name} must be valid UTF-8"
                    ) from error
                if size > _MAXIMUM_NAME_UTF8_BYTES:
                    raise MultiSourceWriterError(
                        f"Frozen {field_name} exceeds the UTF-8 byte limit"
                    )
                metadata_bytes += size
                if metadata_bytes > limits.maximum_metadata_utf8_bytes:
                    raise MultiSourceWriterError(
                        "writer metadata UTF-8 bytes exceed the resource limit"
                    )
    return _CheapPlanCounts(
        counts.source_count,
        counts.connectivity_count,
        counts.source_node_membership_count,
        counts.physical_group_provenance_count,
        counts.physical_group_membership_count,
        metadata_bytes,
    )


def _resource_evidence(
    plan: MultiSourceAssemblyPlan,
    *,
    entity_count: int,
    counts: _CheapPlanCounts,
) -> MultiSourceWriterResourceEvidence:
    estimated_working = (
        len(plan.nodes) * 512
        + len(plan.elements) * 3_072
        + counts.connectivity_count * 24
        # The caller snapshots remain live while the public Frozen audit
        # returns fresh canonical meshes.  Account both full source-node
        # populations, not only the deduplicated assembly nodes.
        + counts.source_node_membership_count * 1_024
        + entity_count * 512
        + len(plan.physical_groups) * 256
        + counts.physical_group_provenance_count * 96
        + counts.physical_group_membership_count * 96
        + counts.metadata_utf8_bytes * 2
    )
    estimated_file = (
        4_096
        + len(plan.nodes) * 128
        + len(plan.elements) * 128
        + counts.connectivity_count * 24
        + entity_count * 256
        + len(plan.physical_groups) * 256
        + counts.metadata_utf8_bytes * 2
    )
    return MultiSourceWriterResourceEvidence(
        counts.source_count,
        len(plan.nodes),
        len(plan.elements),
        counts.connectivity_count,
        entity_count,
        len(plan.physical_groups),
        counts.physical_group_membership_count,
        counts.metadata_utf8_bytes,
        estimated_working,
        estimated_file,
    )


def _require_resources(
    evidence: MultiSourceWriterResourceEvidence,
    limits: MultiSourceWriterLimits,
) -> None:
    checks = (
        ("source count", evidence.source_count, limits.maximum_source_count),
        ("node count", evidence.node_count, limits.maximum_node_count),
        ("element count", evidence.element_count, limits.maximum_element_count),
        (
            "connectivity count",
            evidence.connectivity_count,
            limits.maximum_connectivity_count,
        ),
        ("entity count", evidence.entity_count, limits.maximum_entity_count),
        (
            "Physical Group count",
            evidence.physical_group_count,
            limits.maximum_physical_group_count,
        ),
        (
            "Physical Group membership count",
            evidence.physical_group_membership_count,
            limits.maximum_physical_group_membership_count,
        ),
        (
            "metadata UTF-8 bytes",
            evidence.metadata_utf8_bytes,
            limits.maximum_metadata_utf8_bytes,
        ),
        (
            "estimated working bytes",
            evidence.estimated_working_bytes,
            limits.maximum_estimated_working_bytes,
        ),
        (
            "estimated output file bytes",
            evidence.estimated_output_file_bytes,
            limits.maximum_output_file_bytes,
        ),
    )
    for label, actual, maximum in checks:
        if actual > maximum:
            raise MultiSourceWriterError(
                f"writer {label} exceeds the resource limit: {actual} > {maximum}"
            )


def _build_entity_layout(plan: MultiSourceAssemblyPlan) -> _EntityLayout:
    memberships: dict[int, list[int]] = {
        element.output_tag: [] for element in plan.elements
    }
    for group in plan.physical_groups:
        for element_tag in group.element_tags:
            memberships[element_tag].append(group.output_tag)
    signature_by_element = {
        element_tag: tuple(tags) for element_tag, tags in memberships.items()
    }
    signatures = tuple(sorted(set(signature_by_element.values())))
    if not signatures or any(not value for value in signatures):
        raise MultiSourceWriterError(
            "every output element must have one Physical Group signature"
        )
    entity_by_signature = {
        signature: index for index, signature in enumerate(signatures, 1)
    }
    entity_by_element = {
        element_tag: entity_by_signature[signature]
        for element_tag, signature in signature_by_element.items()
    }
    elements_by_entity: dict[int, list[int]] = {
        entity_tag: [] for entity_tag in entity_by_signature.values()
    }
    for element in plan.elements:
        elements_by_entity[entity_by_element[element.output_tag]].append(
            element.output_tag
        )
    entities = tuple(
        MultiSourceEntityEvidence(
            entity_tag,
            signature,
            tuple(elements_by_entity[entity_tag]),
        )
        for signature, entity_tag in sorted(
            entity_by_signature.items(), key=lambda value: value[1]
        )
    )
    entity_by_tag = {entity.entity_tag: entity for entity in entities}
    entities_by_group: dict[int, list[int]] = {
        group.output_tag: [] for group in plan.physical_groups
    }
    for entity in entities:
        for group_tag in entity.physical_group_tags:
            entities_by_group[group_tag].append(entity.entity_tag)
    return _EntityLayout(
        entities,
        MappingProxyType(dict(sorted(entity_by_element.items()))),
        MappingProxyType(entity_by_tag),
        MappingProxyType(
            {
                group_tag: tuple(entity_tags)
                for group_tag, entity_tags in sorted(entities_by_group.items())
            }
        ),
    )


def _audit_frozen_sources(
    plan: MultiSourceAssemblyPlan,
    values: tuple[FrozenSourceSnapshot, ...],
    output: Path,
    *,
    deep_replay: bool,
) -> tuple[tuple[FrozenSourceSnapshot, ...], str]:
    if type(values) is not tuple:
        raise MultiSourceWriterError(
            "frozen_sources must be a bounded tuple"
        )
    expected_source_ids = tuple(plan.source_component_global_ids)
    expected_sources = set(expected_source_ids)
    if len(values) != len(expected_source_ids):
        raise MultiSourceWriterError(
            "frozen_sources must contain one exact snapshot per plan source"
        )
    replayed: list[FrozenSourceSnapshot] = []
    supplied_source_ids: set[str] = set()
    for value in values:
        if type(value) is not FrozenSourceSnapshot:
            raise MultiSourceWriterError(
                "frozen_sources contains an invalid snapshot DTO"
            )
        source_id = _canonical_name(
            value.source_id,
            field_name="Frozen snapshot source ID",
        )
        if source_id not in expected_sources or source_id in supplied_source_ids:
            raise MultiSourceWriterError(
                "frozen_sources do not uniquely cover every plan source"
            )
        supplied_source_ids.add(source_id)
        expected_digest = plan.source_snapshot_numbered_sha256.get(source_id)
        if (
            type(value.numbered_sha256) is not str
            or type(expected_digest) is not str
            or value.numbered_sha256 != expected_digest
        ):
            raise MultiSourceWriterError(
                "Frozen snapshot numbered digest differs from the plan"
            )
        if (
            type(value.artifacts) is not _MAPPING_PROXY_TYPE
            or tuple(value.artifacts) != _ARTIFACT_ROLES
        ):
            raise MultiSourceWriterError(
                "Frozen snapshot mesh artifact identity changed"
            )
        try:
            replayed.append(
                audit_frozen_source_snapshot(value) if deep_replay else value
            )
        except FrozenSourceError as error:
            raise MultiSourceWriterError(
                "Frozen source snapshot audit failed"
            ) from error
    canonical_by_source = {value.source_id: value for value in replayed}
    canonical = tuple(
        canonical_by_source[source_id] for source_id in expected_source_ids
    )
    if supplied_source_ids != expected_sources:
        raise MultiSourceWriterError(
            "frozen_sources do not uniquely cover every plan source"
        )
    for snapshot in canonical:
        source_id = snapshot.source_id
        if snapshot.numbered_sha256 != plan.source_snapshot_numbered_sha256[
            source_id
        ]:
            raise MultiSourceWriterError(
                "Frozen snapshot numbered digest differs from the plan"
            )
        if not deep_replay:
            continue
        if (
            type(snapshot.components) is not _MAPPING_PROXY_TYPE
            or len(snapshot.components) != 1
        ):
            raise MultiSourceWriterError(
                "writer requires one exact Component per Frozen snapshot"
            )
        component = next(iter(snapshot.components.values()))
        if component.global_component_id != plan.source_component_global_ids[
            source_id
        ]:
            raise MultiSourceWriterError(
                "Frozen snapshot Component identity differs from the plan"
            )
    filesystem_identities: dict[tuple[int, int], tuple[str, str, str]] = {}
    records: list[list[object]] = []
    for snapshot in canonical:
        for role in _ARTIFACT_ROLES:
            value = snapshot.artifacts[role]
            if type(value) is not FrozenArtifactIdentity or value.role != role:
                raise MultiSourceWriterError(
                    "Frozen snapshot artifact identity changed"
                )
            try:
                rebuilt = FrozenArtifactIdentity(
                    value.role,
                    value.declaration,
                    value.runtime_path,
                    value.size_bytes,
                    value.sha256,
                )
                path = Path(value.runtime_path)
            except (FrozenSourceError, TypeError, ValueError) as error:
                raise MultiSourceWriterError(
                    "Frozen snapshot artifact identity changed"
                ) from error
            if rebuilt != value:
                raise MultiSourceWriterError(
                    "Frozen snapshot artifact identity is non-canonical"
                )
            if path.is_symlink() or not path.is_file():
                raise MultiSourceWriterError(
                    f"protected Frozen artifact is not a regular file: {path}"
                )
            try:
                file_stat = path.stat()
            except OSError as error:
                raise MultiSourceWriterError(
                    f"cannot stat protected Frozen artifact: {path}"
                ) from error
            if int(file_stat.st_size) != value.size_bytes:
                raise MultiSourceWriterError(
                    "protected Frozen artifact size changed after snapshot audit"
                )
            identity = (int(file_stat.st_dev), int(file_stat.st_ino))
            artifact_key = (role, str(path), value.sha256)
            if identity in filesystem_identities and filesystem_identities[identity] != artifact_key:
                raise MultiSourceWriterError(
                    "protected Frozen artifact role paths alias one file"
                )
            # Instances may intentionally reuse the identical immutable mesh.
            # Different roles or path aliases still fail the original audit.
            filesystem_identities[identity] = artifact_key
            if paths_refer_to_same_file(output, path):
                raise MultiSourceWriterError(
                    "multi-source output aliases an immutable Frozen artifact"
                )
            records.append(
                [
                    snapshot.source_id,
                    snapshot.numbered_sha256,
                    role,
                    value.declaration,
                    value.runtime_path,
                    value.size_bytes,
                    value.sha256,
                    file_stat.st_dev,
                    file_stat.st_ino,
                    int(
                        getattr(
                            file_stat,
                            "st_mtime_ns",
                            round(file_stat.st_mtime * 1.0e9),
                        )
                    ),
                    int(
                        getattr(
                            file_stat,
                            "st_ctime_ns",
                            round(file_stat.st_ctime * 1.0e9),
                        )
                    ),
                ]
            )
    return canonical, _stream_digest(
        schema="easymesh-package-v2-writer-protected-artifacts-v2",
        metadata={"source_count": len(canonical)},
        sections=(("artifacts", len(records), iter(records)),),
    )


def _placed_snapshot_coordinates(
    coordinates: tuple[float, float, float],
    snapshot: FrozenSourceSnapshot,
) -> tuple[float, float, float]:
    """Apply the canonical Frozen placement exactly once, as the planner does."""

    rotation = snapshot.placement.rotation_matrix
    translation = snapshot.placement.translation_xyz_mm
    return tuple(
        0.0
        if (value := translation[row] + math.fsum(
            rotation[row][column] * coordinates[column]
            for column in range(3)
        )) == 0.0
        else value
        for row in range(3)
    )  # type: ignore[return-value]


def _audit_plan_against_frozen_sources(
    plan: MultiSourceAssemblyPlan,
    snapshots: tuple[FrozenSourceSnapshot, ...],
) -> None:
    """Reverse-bind all plan content that canonical Frozen snapshots can prove.

    This linear replay proves placed node coordinates, copied volume-element
    evidence, and membership of every source Physical Group claimed by the
    plan.  It deliberately does not claim to replay the builder-only shared
    interface declarations hidden behind ``plan.provenance_sha256``.
    """

    nodes_by_output_tag = plan.nodes
    elements_by_output_tag = plan.elements
    groups_by_output_tag = plan.physical_groups

    output_group_by_source_group: dict[tuple[str, int, str], int] = {}
    expected_group_members: list[list[int]] = [
        [] for _ in range(len(groups_by_output_tag) + 1)
    ]
    for group in groups_by_output_tag:
        for source_group in group.source_groups:
            if source_group in output_group_by_source_group:
                raise MultiSourceWriterError(
                    "plan Physical Group provenance is not unique"
                )
            output_group_by_source_group[source_group] = group.output_tag

    actual_source_groups: set[tuple[str, int, str]] = set()
    for snapshot in snapshots:
        source_id = snapshot.source_id
        source_node_map = plan.source_node_output_tags[source_id]
        source_element_map = plan.source_element_output_tags[source_id]
        component_global_id = plan.source_component_global_ids[source_id]

        for source_node in snapshot.mesh.nodes:
            output_tag = source_node_map[source_node.tag]
            output_node = nodes_by_output_tag[output_tag - 1]
            expected_coordinates = _placed_snapshot_coordinates(
                source_node.coordinates,
                snapshot,
            )
            if output_node.package_coordinates_mm != expected_coordinates:
                raise MultiSourceWriterError(
                    "plan node coordinates differ from the placed Frozen snapshot"
                )

        for entity_groups in snapshot.mesh.entity_physical_groups.values():
            for source_group in entity_groups:
                if source_group.explicitly_named is True:
                    actual_source_groups.add(
                        (source_id, source_group.tag, source_group.name)
                    )

        for source_element in snapshot.mesh.elements:
            output_tag = source_element_map[source_element.tag]
            output_element = elements_by_output_tag[output_tag - 1]
            expected_connectivity = tuple(
                source_node_map[source_tag]
                for source_tag in placed_connectivity(source_element.gmsh_type, source_element.node_tags,
                                                       snapshot.placement.rotation_matrix)
            )
            if not (
                output_element.output_tag == output_tag
                and output_element.kind is source_element.kind
                and output_element.gmsh_type == source_element.gmsh_type
                and output_element.node_tags == expected_connectivity
                and output_element.source_id == source_id
                and output_element.source_component_global_id
                == component_global_id
                and output_element.source_element_tag == source_element.tag
                and output_element.source_entity_tag == source_element.entity_tag
                and output_element.minimum_jacobian_determinant
                == source_element.min_jacobian_determinant
            ):
                raise MultiSourceWriterError(
                    "plan element evidence differs from the Frozen snapshot"
                )
            for source_group in source_element.physical_groups:
                source_group_key = (
                    source_id,
                    source_group.tag,
                    source_group.name,
                )
                output_group_tag = output_group_by_source_group.get(
                    source_group_key
                )
                if output_group_tag is not None:
                    if source_group.explicitly_named is not True:
                        raise MultiSourceWriterError(
                            "plan Physical Group provenance is not explicitly named"
                        )
                    expected_group_members[output_group_tag].append(output_tag)

    if not set(output_group_by_source_group).issubset(actual_source_groups):
        raise MultiSourceWriterError(
            "plan Physical Group provenance is absent from the Frozen snapshots"
        )
    for group in groups_by_output_tag:
        expected_members = expected_group_members[group.output_tag]
        if (
            len(expected_members) != len(set(expected_members))
            or tuple(sorted(expected_members)) != group.element_tags
        ):
            raise MultiSourceWriterError(
                "plan Physical Group membership differs from the Frozen snapshots"
            )


def _load_gmsh() -> Any:
    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:  # pragma: no cover - dependency failure
        raise RuntimeError("Gmsh is required for multi-source writing") from error
    return gmsh


def _quality_values(
    gmsh: Any,
    element_tags: tuple[int, ...],
) -> _QualityValues:
    if not element_tags:
        raise MultiSourceWriterError("writer quality audit has no elements")
    metrics: dict[str, tuple[float, ...]] = {}
    for metric in _QUALITY_METRICS:
        values = tuple(
            float(value)
            for value in gmsh.model.mesh.getElementQualities(
                list(element_tags), metric
            )
        )
        if len(values) != len(element_tags):
            raise MultiSourceWriterError(
                f"Gmsh returned the wrong number of {metric} quality values"
            )
        if any(not math.isfinite(value) for value in values):
            raise MultiSourceWriterError(
                f"Gmsh returned non-finite {metric} quality evidence"
            )
        metrics[metric] = values
    for metric in _QUALITY_METRICS:
        if any(value <= 0.0 for value in metrics[metric]):
            raise MultiSourceWriterError(
                f"multi-source output contains a non-positive {metric} value"
            )
    return _QualityValues(
        element_tags,
        MappingProxyType(metrics),
    )


def _add_live_model(
    gmsh: Any,
    plan: MultiSourceAssemblyPlan,
    layout: _EntityLayout,
) -> _QualityValues:
    elements_by_tag = {element.output_tag: element for element in plan.elements}
    for entity in layout.entities:
        actual = int(gmsh.model.addDiscreteEntity(3, entity.entity_tag))
        if actual != entity.entity_tag:
            raise MultiSourceWriterError("Gmsh changed a discrete entity tag")
    host_entity = layout.entities[0].entity_tag
    gmsh.model.mesh.addNodes(
        3,
        host_entity,
        [node.output_tag for node in plan.nodes],
        [
            coordinate
            for node in plan.nodes
            for coordinate in node.package_coordinates_mm
        ],
    )
    for entity in layout.entities:
        selected = tuple(elements_by_tag[tag] for tag in entity.element_tags)
        for gmsh_type in sorted({element.gmsh_type for element in selected}):
            block = tuple(
                element for element in selected if element.gmsh_type == gmsh_type
            )
            gmsh.model.mesh.addElementsByType(
                entity.entity_tag,
                gmsh_type,
                [element.output_tag for element in block],
                [tag for element in block for tag in element.node_tags],
            )
    for group in plan.physical_groups:
        entity_tags = layout.entity_tags_by_physical_group[group.output_tag]
        actual = int(
            gmsh.model.addPhysicalGroup(3, list(entity_tags), group.output_tag)
        )
        if actual != group.output_tag:
            raise MultiSourceWriterError("Gmsh changed a Physical Group tag")
        gmsh.model.setPhysicalName(3, group.output_tag, group.name)
    return _quality_values(
        gmsh,
        tuple(element.output_tag for element in plan.elements),
    )


def _coordinates_match(
    actual: float,
    expected: float,
    *,
    assembly_axis_extent: float,
) -> bool:
    if actual == expected:
        return True
    ulp_tolerance = _COORDINATE_ROUNDTRIP_ULPS * max(
        math.ulp(actual), math.ulp(expected)
    )
    relative_cap = (
        _COORDINATE_ASSEMBLY_RELATIVE_CAP * assembly_axis_extent
    )
    return abs(actual - expected) <= min(ulp_tolerance, relative_cap)


def _assembly_axis_extents(
    plan: MultiSourceAssemblyPlan,
) -> tuple[float, float, float]:
    return tuple(
        max(node.package_coordinates_mm[axis] for node in plan.nodes)
        - min(node.package_coordinates_mm[axis] for node in plan.nodes)
        for axis in range(3)
    )


def _numbered_mesh_sha256(mesh: VolumeMesh) -> str:
    nodes = mesh.nodes
    elements = mesh.elements
    if any(
        nodes[index - 1].tag >= nodes[index].tag
        for index in range(1, len(nodes))
    ) or any(
        elements[index - 1].tag >= elements[index].tag
        for index in range(1, len(elements))
    ):
        raise MultiSourceWriterError(
            "reopened mesh records are not in canonical tag order"
        )
    group_membership_count = sum(
        len(element.physical_groups) for element in elements
    )
    return _stream_digest(
        schema="easymesh-package-v2-multi-source-written-mesh-v2",
        metadata={
            "dimensional_element_counts": list(mesh.dimensional_element_counts),
        },
        sections=(
            (
                "nodes",
                len(nodes),
                ([node.tag, *node.coordinates] for node in nodes),
            ),
            (
                "elements",
                len(elements),
                (
                    [
                        element.tag,
                        element.kind.value,
                        element.gmsh_type,
                        list(element.node_tags),
                        element.entity_tag,
                    ]
                    for element in elements
                ),
            ),
            (
                "element_physical_groups",
                group_membership_count,
                (
                    [
                        element.tag,
                        group.tag,
                        group.name,
                        group.explicitly_named,
                    ]
                    for element in elements
                    for group in element.physical_groups
                ),
            ),
        ),
    )


def _audit_reopened_mesh(
    mesh: VolumeMesh,
    plan: MultiSourceAssemblyPlan,
    layout: _EntityLayout,
) -> str:
    if mesh.dimensional_element_counts != (0, 0, 0, len(plan.elements)):
        raise MultiSourceWriterError(
            "reopened MSH is not the expected volume-only element set"
        )
    expected_nodes = {
        node.output_tag: node.package_coordinates_mm for node in plan.nodes
    }
    actual_nodes = mesh.node_map()
    if set(actual_nodes) != set(expected_nodes):
        raise MultiSourceWriterError("reopened MSH node tags changed")
    if len({node.coordinates for node in actual_nodes.values()}) != len(
        actual_nodes
    ):
        raise MultiSourceWriterError(
            "reopened MSH collapsed distinct tags to one exact coordinate"
        )
    axis_extents = _assembly_axis_extents(plan)
    for tag, expected in expected_nodes.items():
        actual = actual_nodes[tag].coordinates
        if not all(
            _coordinates_match(
                actual[index],
                expected[index],
                assembly_axis_extent=axis_extents[index],
            )
            for index in range(3)
        ):
            raise MultiSourceWriterError("reopened MSH node coordinates changed")

    expected_elements = {
        element.output_tag: element for element in plan.elements
    }
    entity_by_element = layout.entity_by_element_tag
    if len(mesh.elements) != len(expected_elements):
        raise MultiSourceWriterError("reopened MSH element count changed")
    group_by_tag = {group.output_tag: group for group in plan.physical_groups}
    for element in mesh.elements:
        expected = expected_elements.get(element.tag)
        if expected is None:
            raise MultiSourceWriterError("reopened MSH element tags changed")
        if (
            element.kind is not expected.kind
            or element.gmsh_type != expected.gmsh_type
            or element.node_tags != expected.node_tags
            or element.entity_tag != entity_by_element[element.tag]
        ):
            raise MultiSourceWriterError(
                "reopened MSH element kind/connectivity/entity changed"
            )
        expected_signature = layout.entity_by_tag[
            element.entity_tag
        ].physical_group_tags
        expected_groups = tuple(
            PhysicalGroup(tag, group_by_tag[tag].name, True)
            for tag in expected_signature
        )
        if element.physical_groups != expected_groups:
            raise MultiSourceWriterError(
                "reopened MSH Physical Group membership changed"
            )
        if (
            not math.isfinite(element.min_jacobian_determinant)
            or element.min_jacobian_determinant <= 0.0
        ):
            raise MultiSourceWriterError(
                "reopened MSH contains non-positive Jacobian evidence"
            )
    expected_entity_groups = {
        entity.entity_tag: tuple(
            PhysicalGroup(tag, group_by_tag[tag].name, True)
            for tag in entity.physical_group_tags
        )
        for entity in layout.entities
    }
    if dict(mesh.entity_physical_groups) != expected_entity_groups:
        raise MultiSourceWriterError(
            "reopened MSH entity Physical Group signatures changed"
        )
    return _numbered_mesh_sha256(mesh)


def _audit_reopened_gmsh(
    gmsh: Any,
    path: Path,
    plan: MultiSourceAssemblyPlan,
    layout: _EntityLayout,
) -> _QualityValues:
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_package_v2_multi_source_reopen",
        number_options={"General.Terminal": 0.0},
    ):
        gmsh.merge(str(path))
        actual_entities = tuple(
            sorted(
                (int(dimension), int(tag))
                for dimension, tag in gmsh.model.getEntities()
            )
        )
        expected_entities = tuple(
            (3, value.entity_tag) for value in layout.entities
        )
        if actual_entities != expected_entities:
            raise MultiSourceWriterError(
                "reopened Gmsh contains unexpected entities"
            )
        expected_group_entities = {
            group.output_tag: layout.entity_tags_by_physical_group[
                group.output_tag
            ]
            for group in plan.physical_groups
        }
        actual_groups: dict[
            tuple[int, int], tuple[str, tuple[int, ...]]
        ] = {}
        for dimension, raw_tag in gmsh.model.getPhysicalGroups():
            resolved_dimension = int(dimension)
            tag = int(raw_tag)
            actual_groups[(resolved_dimension, tag)] = (
                str(gmsh.model.getPhysicalName(resolved_dimension, tag)),
                tuple(
                    sorted(
                        int(value)
                        for value in gmsh.model.getEntitiesForPhysicalGroup(
                            resolved_dimension,
                            tag,
                        )
                    )
                ),
            )
        expected_groups = {
            (3, group.output_tag): (
                group.name,
                expected_group_entities[group.output_tag],
            )
            for group in plan.physical_groups
        }
        if actual_groups != expected_groups:
            raise MultiSourceWriterError(
                "reopened Gmsh Physical Group entities changed"
            )
        return _quality_values(
            gmsh,
            tuple(element.output_tag for element in plan.elements),
        )


def _same_quality(first: _QualityValues, second: _QualityValues) -> bool:
    if first.element_tags != second.element_tags:
        return False
    return all(
        math.isclose(
            first.metrics[name][index],
            second.metrics[name][index],
            rel_tol=_QUALITY_ROUNDTRIP_RELATIVE_TOLERANCE,
            abs_tol=0.0,
        )
        for name in _QUALITY_METRICS
        for index in range(len(first.element_tags))
    )


def write_multi_source_assembly_plan(
    plan: MultiSourceAssemblyPlan,
    output_path: str | Path,
    *,
    frozen_sources: tuple[FrozenSourceSnapshot, ...],
    limits: MultiSourceWriterLimits | None = None,
    verbose: bool = False,
) -> MultiSourceWriterSummary:
    """Audit, write, reopen, and atomically publish one assembly plan.

    ``plan`` must come from the trusted in-process planner.  Callers loading a
    persisted plan must first rebuild it from the complete source inputs and
    declared shared interfaces; the opaque provenance SHA alone is not an
    independently replayable shared-node authorization proof.
    """

    if type(plan) is not MultiSourceAssemblyPlan:
        raise MultiSourceWriterError("plan must be a MultiSourceAssemblyPlan")
    if limits is None:
        limits = MultiSourceWriterLimits()
    limits = _audit_limits(limits)
    if type(verbose) is not bool:
        raise MultiSourceWriterError("verbose must be boolean")
    counts = _cheap_plan_preflight(plan, limits)
    if type(frozen_sources) is not tuple or len(frozen_sources) != (
        counts.source_count
    ):
        raise MultiSourceWriterError(
            "frozen_sources must contain one exact snapshot per plan source"
        )
    counts = _add_frozen_metadata_preflight(counts, frozen_sources, limits)
    try:
        output = normalized_mesh_output(output_path)
    except (OSError, RuntimeError, TypeError, ValueError) as error:
        raise MultiSourceWriterError("cannot canonicalize output path") from error
    _audit_frozen_sources(
        plan,
        frozen_sources,
        output,
        deep_replay=False,
    )
    # Count-only working/file estimates protect both downstream deep audits.
    preflight = _resource_evidence(plan, entity_count=1, counts=counts)
    _require_resources(preflight, limits)
    try:
        audit_multi_source_assembly_plan(plan)
    except MultiSourceAssemblyError as error:
        raise MultiSourceWriterError("multi-source plan audit failed") from error
    canonical_sources, protected_digest = _audit_frozen_sources(
        plan,
        frozen_sources,
        output,
        deep_replay=True,
    )
    _audit_plan_against_frozen_sources(plan, canonical_sources)

    # The exact entity count is checked immediately after the deterministic
    # linear membership pass.
    layout = _build_entity_layout(plan)
    resources = _resource_evidence(
        plan,
        entity_count=len(layout.entities),
        counts=counts,
    )
    _require_resources(resources, limits)

    gmsh = _load_gmsh()
    options = {
        "General.Terminal": 1.0 if verbose else 0.0,
        "General.NumThreads": 1.0,
        "Mesh.MshFileVersion": 4.1,
        "Mesh.Binary": 0.0,
        "Mesh.SaveAll": 0.0,
        "Mesh.ElementOrder": 1.0,
        "Mesh.MaxNumThreads1D": 1.0,
        "Mesh.MaxNumThreads2D": 1.0,
        "Mesh.MaxNumThreads3D": 1.0,
    }
    with exclusive_output_lock(output):
        # Recheck path identity under the writer lock.  os.replace remains
        # safe if another process changes a directory entry afterwards.
        _locked_sources, locked_digest = _audit_frozen_sources(
            plan,
            canonical_sources,
            output,
            deep_replay=False,
        )
        if locked_digest != protected_digest:
            raise MultiSourceWriterError(
                "a protected Frozen artifact changed before writing"
            )
        with atomic_output_path(output) as temporary_mesh:
            try:
                with isolated_gmsh_model(
                    gmsh,
                    "__easymesh_package_v2_multi_source_writer",
                    number_options=options,
                ):
                    live_quality = _add_live_model(gmsh, plan, layout)
                    gmsh.write(str(temporary_mesh))
                if temporary_mesh.stat().st_size > limits.maximum_output_file_bytes:
                    raise MultiSourceWriterError(
                        "written MSH exceeds maximum_output_file_bytes"
                    )
                reopened_mesh = load_volume_mesh(temporary_mesh)
                numbered_mesh_sha256 = _audit_reopened_mesh(
                    reopened_mesh,
                    plan,
                    layout,
                )
                reopened_quality = _audit_reopened_gmsh(
                    gmsh,
                    temporary_mesh,
                    plan,
                    layout,
                )
                if not _same_quality(live_quality, reopened_quality):
                    raise MultiSourceWriterError(
                        "reopened Gmsh quality values differ from the live model"
                    )
                artifact = file_artifact(
                    temporary_mesh,
                    published_path=output,
                )
                _final_sources, final_digest = _audit_frozen_sources(
                    plan,
                    canonical_sources,
                    output,
                    deep_replay=False,
                )
                if final_digest != protected_digest:
                    raise MultiSourceWriterError(
                        "a protected Frozen artifact changed while writing"
                    )
            except MultiSourceWriterError:
                raise
            except Exception as error:
                raise MultiSourceWriterError(
                    "cannot assemble, write, or reopen the multi-source MSH"
                ) from error

            # Summary construction is intentionally inside the atomic boundary.
            # Any validation failure leaves a previous published file untouched.
            summary = MultiSourceWriterSummary(
                str(output),
                plan.numbered_sha256,
                plan.provenance_sha256,
                protected_digest,
                layout.entities,
                tuple(
                    (group.output_tag, group.name)
                    for group in plan.physical_groups
                ),
                resources,
                reopened_quality.evidence,
                numbered_mesh_sha256,
                live_quality.numbered_sha256,
                int(artifact["size_bytes"]),
                str(artifact["sha256"]),
                True,
                True,
                False,
            )
        return summary


__all__ = [
    "MultiSourceEntityEvidence",
    "MultiSourceWriterError",
    "MultiSourceWriterLimits",
    "MultiSourceWriterQualityEvidence",
    "MultiSourceWriterResourceEvidence",
    "MultiSourceWriterSummary",
    "audit_multi_source_writer_summary",
    "write_multi_source_assembly_plan",
]
