"""Validation of external mesh group names, separate from Source identifiers."""


def mesh_group_name_error(name: str) -> str:
    if not name.strip():
        return "网格分组名称不能为空"
    if name != name.strip():
        return "网格分组名称不能包含首尾空白"
    if any(ord(character) < 32 or 127 <= ord(character) <= 159 for character in name):
        return "网格分组名称不能包含控制字符"
    return ""
