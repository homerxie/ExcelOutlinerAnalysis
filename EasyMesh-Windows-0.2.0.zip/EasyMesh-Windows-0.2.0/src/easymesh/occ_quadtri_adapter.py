"""Gmsh-owned QUAD-to-TRI transition volumes for locked surface patches.

This module is intentionally geometry-role neutral.  A caller supplies one
connected QUAD4 surface patch and one exact target coordinate per source node.
Gmsh's official mapped boundary-layer plus ``QuadTri`` extrusion owns all
three-dimensional connectivity: EasyMesh only validates the locked source
mesh, invokes Gmsh and audits the resulting adapter.

The adapter is useful at a negotiated QUAD/triangular interface.  Its source
QUADs are retained verbatim, its opposite surface is TRI3, and its lateral
facets are exposed so a caller can include them in a residual Gmsh fill.  A
quality miss fails closed; this module never substitutes Cartesian cells or a
hand-built star split.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from hashlib import sha256
import math
from pathlib import Path
from tempfile import NamedTemporaryFile
from types import MappingProxyType
from typing import Any, TypeAlias
from uuid import uuid4

from .gmsh_runtime import isolated_gmsh_model
from .gmsh_closed_shell_remainder import (
    _folded_internal_face_count,
    _orient_closed_shell,
)
from .occ_locked_hybrid import (
    ConstrainedHybridError,
    _all_nodes,
    _coordinate_key,
    _face_key,
    _finite,
    _load_gmsh,
)
from .volume_mesh import ELEMENT_SPECS


Point3D: TypeAlias = tuple[float, float, float]

_TRI3 = 2
_QUAD4 = 3
_TET4 = 4
_HEX8 = 5
_WEDGE6 = 6
_PYRAMID5 = 7
_VOLUME_TYPES = frozenset({_TET4, _HEX8, _WEDGE6, _PYRAMID5})
_COORDINATE_TOLERANCE = 1.0e-10

_METHODS = MappingProxyType(
    {
        "no_new_vertices": "QuadTriNoNewVerts",
        "add_vertices": "QuadTriAddVerts",
    }
)

_MAPPED_GEO_TEMPLATE = """\
__OUTPUT_SYMBOL__[] = Extrude {
  Surface{__SURFACE_SYMBOL__};
  Layers{{1, 1}, {__FIRST_LAYER_SYMBOL__, 1}};
  Using View[__VIEW_INDEX_SYMBOL__];
  Recombine;
  quadtri_directive RecombLaterals;
};
"""

@dataclass(frozen=True, slots=True)
class GmshQuadTriElement:
    """One first-order adapter element whose connectivity came from Gmsh."""

    gmsh_type: int
    node_ids: tuple[int, ...]

    def __post_init__(self) -> None:
        expected = ELEMENT_SPECS.get(self.gmsh_type, (None, 0, ()))[1]
        if self.gmsh_type not in _VOLUME_TYPES or len(self.node_ids) != expected:
            raise ConstrainedHybridError(
                "Gmsh QuadTri adapter element has an unsupported type"
            )
        if len(set(self.node_ids)) != expected:
            raise ConstrainedHybridError(
                "Gmsh QuadTri adapter element contains repeated nodes"
            )


@dataclass(frozen=True, slots=True)
class GmshQuadTriAdapter:
    """Audited Gmsh QuadTri adapter between locked QUADs and TRI3 facets."""

    node_coordinates: Mapping[int, Point3D]
    source_node_id_by_local_id: Mapping[int, int]
    elements: tuple[GmshQuadTriElement, ...]
    source_facets: tuple[tuple[int, ...], ...]
    interface_facets: tuple[tuple[int, ...], ...]
    lateral_facets: tuple[tuple[int, ...], ...]
    extrusion_vector: Point3D
    method: str
    tet4_count: int
    hex8_count: int
    wedge6_count: int
    pyramid5_count: int
    minimum_sicn: float
    minimum_sige: float
    minimum_scaled_jacobian: float
    minimum_determinant: float
    source_hex_element_ids: tuple[int, ...]
    source_hex_minimum_sicn: float
    source_hex_minimum_sige: float
    source_hex_minimum_scaled_jacobian: float
    source_hex_sicn_aspect_quality_exempted: bool
    transition_element_count: int
    transition_minimum_sicn: float
    transition_minimum_sige: float
    transition_minimum_scaled_jacobian: float
    duplicate_node_count: int
    duplicate_element_count: int
    interface_node_id_by_source_node_id: Mapping[int, int] = field(
        default_factory=lambda: MappingProxyType({})
    )
    layer_cumulative_fractions: tuple[float, ...] = (1.0,)
    mapped_target_coordinates_by_source_node_id: Mapping[int, Point3D] = (
        field(default_factory=lambda: MappingProxyType({}))
    )
    source_quad_hex_owner_count: int = 0
    boundary_shell_volume_mm3: float = 0.0
    element_volume_mm3: float = 0.0
    relative_volume_error: float = 0.0
    folded_internal_face_count: int = 0
    first_layer_node_id_by_source_node_id: Mapping[int, int] = field(
        default_factory=lambda: MappingProxyType({})
    )
    node_ordering: str = "xyz"

    @property
    def node_count(self) -> int:
        return len(self.node_coordinates)

    @property
    def element_count(self) -> int:
        return len(self.elements)


@dataclass(frozen=True, slots=True)
class _PreparedPatch:
    coordinates: Mapping[int, Point3D]
    facets: tuple[tuple[int, int, int, int], ...]
    vector: Point3D
    maximum_edge_ratio: float


@dataclass(frozen=True, slots=True)
class _PreparedMappedPatch:
    patch: _PreparedPatch
    targets: Mapping[int, Point3D]
    displacements: Mapping[int, Point3D]
    first_layer_fraction: float


def _edge_key(first: int, second: int) -> tuple[int, int]:
    return (first, second) if first < second else (second, first)


def _ordered_source_ids(
    prepared: _PreparedPatch,
    ordering: str,
) -> tuple[int, ...]:
    axes_by_ordering = {
        "xyz": (0, 1, 2),
        "yxz": (1, 0, 2),
        "x_reverse_yz": (0, 1, 2),
        "xy_reverse_z": (0, 1, 2),
        "yx_reverse_z": (1, 0, 2),
        "yx_z_reverse": (1, 0, 2),
    }
    if ordering == "coordinate_digest":
        return tuple(
            sorted(
                prepared.coordinates,
                key=lambda source_id: (
                    sha256(
                        ":".join(
                            value.hex()
                            for value in prepared.coordinates[source_id]
                        ).encode("ascii")
                    ).digest(),
                    _coordinate_key(prepared.coordinates[source_id]),
                ),
            )
        )
    axes = axes_by_ordering.get(ordering)
    if axes is None:
        raise ConstrainedHybridError(
            "mapped QuadTri node_ordering is unsupported"
        )

    def key(source_id: int) -> tuple[float, float, float, int]:
        point = prepared.coordinates[source_id]
        signs = {
            "xyz": (1.0, 1.0, 1.0),
            "yxz": (1.0, 1.0, 1.0),
            "x_reverse_yz": (-1.0, 1.0, 1.0),
            "xy_reverse_z": (1.0, -1.0, 1.0),
            "yx_reverse_z": (-1.0, 1.0, 1.0),
            "yx_z_reverse": (1.0, -1.0, 1.0),
        }[ordering]
        return (
            signs[0] * point[axes[0]],
            signs[1] * point[axes[1]],
            signs[2] * point[axes[2]],
            source_id,
        )

    return tuple(sorted(prepared.coordinates, key=key))


def _normal(points: Sequence[Point3D]) -> Point3D:
    first = tuple(points[1][axis] - points[0][axis] for axis in range(3))
    second = tuple(points[2][axis] - points[0][axis] for axis in range(3))
    return (
        first[1] * second[2] - first[2] * second[1],
        first[2] * second[0] - first[0] * second[2],
        first[0] * second[1] - first[1] * second[0],
    )


def _prepare_patch(
    node_coordinates: Mapping[int, Sequence[float]],
    facets: Sequence[Sequence[int]],
    extrusion_vector: Sequence[float],
) -> _PreparedPatch:
    if not isinstance(node_coordinates, Mapping):
        raise ConstrainedHybridError("QuadTri source coordinates must be a mapping")
    coordinates: dict[int, Point3D] = {}
    for raw_id, raw_point in node_coordinates.items():
        if isinstance(raw_id, bool) or not isinstance(raw_id, int) or raw_id < 1:
            raise ConstrainedHybridError(
                "QuadTri source node IDs must be positive integers"
            )
        values = tuple(raw_point)
        if len(values) != 3:
            raise ConstrainedHybridError("QuadTri source point must contain x,y,z")
        coordinates[raw_id] = tuple(
            _finite(value, name=f"QuadTri source node {raw_id}") for value in values
        )  # type: ignore[assignment]
    if len({_coordinate_key(point) for point in coordinates.values()}) != len(
        coordinates
    ):
        raise ConstrainedHybridError("QuadTri source nodes contain duplicates")

    vector_values = tuple(extrusion_vector)
    if len(vector_values) != 3:
        raise ConstrainedHybridError("QuadTri extrusion vector must contain dx,dy,dz")
    vector = tuple(
        _finite(value, name="QuadTri extrusion vector") for value in vector_values
    )
    vector_length = math.sqrt(math.fsum(value * value for value in vector))
    if vector_length <= _COORDINATE_TOLERANCE:
        raise ConstrainedHybridError("QuadTri extrusion vector must be non-zero")

    try:
        raw_facets = tuple(tuple(facet) for facet in facets)
    except TypeError as error:
        raise ConstrainedHybridError("QuadTri source facets must be QUAD4") from error
    if not raw_facets:
        raise ConstrainedHybridError("QuadTri source patch must not be empty")
    prepared_facets: list[tuple[int, int, int, int]] = []
    edge_ratios: list[float] = []
    face_keys: set[tuple[int, ...]] = set()
    edge_owners: dict[tuple[int, int], list[int]] = defaultdict(list)
    referenced: set[int] = set()
    for index, facet in enumerate(raw_facets):
        if len(facet) != 4 or any(
            isinstance(node, bool) or not isinstance(node, int) for node in facet
        ):
            raise ConstrainedHybridError("QuadTri source facets must be QUAD4")
        cycle = tuple(int(node) for node in facet)
        if len(set(cycle)) != 4 or any(node not in coordinates for node in cycle):
            raise ConstrainedHybridError("QuadTri source facet is invalid")
        key = _face_key(cycle)
        if key in face_keys:
            raise ConstrainedHybridError("QuadTri source facets must be unique")
        face_keys.add(key)
        points = tuple(coordinates[node] for node in cycle)
        normal = _normal(points)
        normal_length = math.sqrt(math.fsum(value * value for value in normal))
        normal_component = math.fsum(
            normal[axis] * vector[axis] for axis in range(3)
        )
        if normal_length <= _COORDINATE_TOLERANCE**2:
            raise ConstrainedHybridError("QuadTri source facet has zero area")
        if abs(normal_component) <= (
            _COORDINATE_TOLERANCE * normal_length * vector_length
        ):
            raise ConstrainedHybridError(
                "QuadTri extrusion vector is tangent to a source facet"
            )
        if normal_component < 0.0:
            cycle = tuple(reversed(cycle))
        # Gmsh's QuadTri diagonal choices are tag/order sensitive.  Normalize
        # the positive-normal cycle by geometry so semantically identical
        # locked patches produce the same discrete input even when upstream
        # local node IDs or facet order differ between processes.
        cycle = min(
            (
                cycle[offset:] + cycle[:offset]
                for offset in range(len(cycle))
            ),
            key=lambda value: tuple(
                _coordinate_key(coordinates[node]) for node in value
            ),
        )
        edge_lengths = tuple(
            math.dist(first, second)
            for first, second in zip(points, (*points[1:], points[0]))
        )
        edge_ratios.append(max(edge_lengths) / min(edge_lengths))
        prepared_facets.append(cycle)  # type: ignore[arg-type]
        referenced.update(cycle)
        for first, second in zip(cycle, (*cycle[1:], cycle[0])):
            edge_owners[_edge_key(first, second)].append(index)
    if referenced != set(coordinates):
        raise ConstrainedHybridError(
            "every QuadTri source node must be referenced by a facet"
        )
    if any(len(owners) not in {1, 2} for owners in edge_owners.values()):
        raise ConstrainedHybridError("QuadTri source patch is non-manifold")
    adjacency: dict[int, set[int]] = defaultdict(set)
    for owners in edge_owners.values():
        if len(owners) == 2:
            adjacency[owners[0]].add(owners[1])
            adjacency[owners[1]].add(owners[0])
    seen: set[int] = set()
    queue = deque([0])
    while queue:
        current = queue.popleft()
        if current in seen:
            continue
        seen.add(current)
        queue.extend(adjacency[current].difference(seen))
    if len(seen) != len(prepared_facets):
        raise ConstrainedHybridError("QuadTri source patch must be connected")
    return _PreparedPatch(
        coordinates=MappingProxyType(coordinates),
        facets=tuple(
            sorted(
                prepared_facets,
                key=lambda facet: tuple(
                    _coordinate_key(coordinates[node]) for node in facet
                ),
            )
        ),
        vector=vector,  # type: ignore[arg-type]
        maximum_edge_ratio=max(edge_ratios),
    )


def _prepare_mapped_patch(
    node_coordinates: Mapping[int, Sequence[float]],
    facets: Sequence[Sequence[int]],
    target_coordinates_by_source_node_id: Mapping[int, Sequence[float]],
    first_layer_fraction: float,
) -> _PreparedMappedPatch:
    if not isinstance(target_coordinates_by_source_node_id, Mapping):
        raise ConstrainedHybridError(
            "QuadTri mapped target coordinates must be a mapping"
        )
    # A representative positive-z vector lets the shared QUAD validation fix
    # source orientation.  The exact, node-varying vectors are validated below.
    prepared = _prepare_patch(node_coordinates, facets, (0.0, 0.0, 1.0))
    if set(target_coordinates_by_source_node_id) != set(prepared.coordinates):
        raise ConstrainedHybridError(
            "QuadTri mapped targets must cover every source node exactly once"
        )
    targets: dict[int, Point3D] = {}
    displacements: dict[int, Point3D] = {}
    for source_id, source_point in prepared.coordinates.items():
        values = tuple(target_coordinates_by_source_node_id[source_id])
        if len(values) != 3:
            raise ConstrainedHybridError(
                "QuadTri mapped target point must contain x,y,z"
            )
        target = tuple(
            _finite(value, name=f"QuadTri mapped target node {source_id}")
            for value in values
        )
        displacement = tuple(
            target[axis] - source_point[axis] for axis in range(3)
        )
        if displacement[2] <= _COORDINATE_TOLERANCE:
            raise ConstrainedHybridError(
                "QuadTri mapped targets must lie strictly above the source plane"
            )
        targets[source_id] = target  # type: ignore[assignment]
        displacements[source_id] = displacement  # type: ignore[assignment]
    if len({_coordinate_key(point) for point in targets.values()}) != len(targets):
        raise ConstrainedHybridError("QuadTri mapped target nodes contain duplicates")
    representative_vector = tuple(
        math.fsum(displacement[axis] for displacement in displacements.values())
        / len(displacements)
        for axis in range(3)
    )
    prepared = _PreparedPatch(
        coordinates=prepared.coordinates,
        facets=prepared.facets,
        vector=representative_vector,  # type: ignore[arg-type]
        maximum_edge_ratio=prepared.maximum_edge_ratio,
    )
    fraction = _finite(
        first_layer_fraction,
        name="QuadTri first-layer cumulative fraction",
    )
    if fraction <= 0.0 or fraction >= 1.0:
        raise ConstrainedHybridError(
            "QuadTri first-layer cumulative fraction must lie in (0,1)"
        )
    return _PreparedMappedPatch(
        patch=prepared,
        targets=MappingProxyType(targets),
        displacements=MappingProxyType(displacements),
        first_layer_fraction=fraction,
    )


def _write_mapped_geo_template(
    directive: str,
    *,
    surface_symbol: str,
    first_layer_symbol: str,
    view_index_symbol: str,
    output_symbol: str,
) -> Path:
    stream = NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        suffix=".geo",
        prefix="easymesh_quadtri_mapped_",
        delete=False,
    )
    try:
        rendered = _MAPPED_GEO_TEMPLATE.replace("quadtri_directive", directive)
        rendered = rendered.replace("__SURFACE_SYMBOL__", surface_symbol)
        rendered = rendered.replace("__FIRST_LAYER_SYMBOL__", first_layer_symbol)
        rendered = rendered.replace("__VIEW_INDEX_SYMBOL__", view_index_symbol)
        rendered = rendered.replace("__OUTPUT_SYMBOL__", output_symbol)
        stream.write(rendered)
        return Path(stream.name)
    finally:
        stream.close()


def _extract_adapter(
    gmsh: Any,
    prepared: _PreparedPatch,
    volume_tags: int | Sequence[int],
    top_surface_tag: int,
    method: str,
    minimum_quality: float,
    *,
    target_coordinates_by_source_node_id: Mapping[int, Point3D] | None = None,
    first_layer_target_coordinates_by_source_node_id: Mapping[
        int, Point3D
    ] | None = None,
    layer_cumulative_fractions: tuple[float, ...] = (1.0,),
    require_source_hex: bool = False,
    allow_source_hex_sicn_aspect_exemption: bool = False,
    interface_gmsh_type: int = _TRI3,
    require_non_source_transition: bool = True,
    node_ordering: str = "xyz",
    cartesian_tolerance_mm: float = _COORDINATE_TOLERANCE,
) -> GmshQuadTriAdapter:
    if interface_gmsh_type not in {_TRI3, _QUAD4}:
        raise ConstrainedHybridError(
            "Gmsh mapped adapter interface must be TRI3 or QUAD4"
        )
    gmsh_coordinates = _all_nodes(gmsh)
    if tuple(gmsh.model.mesh.getDuplicateNodes()):
        raise ConstrainedHybridError("Gmsh QuadTri adapter contains duplicate nodes")
    raw_elements: list[tuple[int, int, tuple[int, ...]]] = []
    quality_tags: list[int] = []
    requested_volumes = (
        (int(volume_tags),)
        if isinstance(volume_tags, int)
        else tuple(int(value) for value in volume_tags)
    )
    if not requested_volumes or len(set(requested_volumes)) != len(
        requested_volumes
    ):
        raise ConstrainedHybridError(
            "Gmsh QuadTri adapter volume set is empty or duplicated"
        )
    for volume_tag in requested_volumes:
        element_types, tag_blocks, connectivity_blocks = (
            gmsh.model.mesh.getElements(3, volume_tag)
        )
        for raw_type, raw_tags, raw_connectivity in zip(
            element_types, tag_blocks, connectivity_blocks
        ):
            gmsh_type = int(raw_type)
            if gmsh_type not in _VOLUME_TYPES:
                raise ConstrainedHybridError(
                    f"Gmsh QuadTri produced unsupported volume type {gmsh_type}"
                )
            node_count = ELEMENT_SPECS[gmsh_type][1]
            connectivity = tuple(int(node) for node in raw_connectivity)
            if len(connectivity) != node_count * len(raw_tags):
                raise ConstrainedHybridError(
                    "Gmsh QuadTri connectivity is inconsistent"
                )
            for index, raw_tag in enumerate(raw_tags):
                start = index * node_count
                raw_elements.append(
                    (
                        gmsh_type,
                        int(raw_tag),
                        connectivity[start : start + node_count],
                    )
                )
                quality_tags.append(int(raw_tag))
    if len(set(quality_tags)) != len(quality_tags):
        raise ConstrainedHybridError(
            "Gmsh QuadTri adapter volumes repeat a volume element"
        )
    if not raw_elements:
        raise ConstrainedHybridError("Gmsh QuadTri produced an empty adapter")
    qualities = {
        name: tuple(
            float(value)
            for value in gmsh.model.mesh.getElementQualities(quality_tags, name)
        )
        for name in ("minDetJac", "minSICN", "minSIGE", "minSJ")
    }
    if any(len(values) != len(raw_elements) for values in qualities.values()):
        raise ConstrainedHybridError(
            "Gmsh QuadTri returned inconsistent quality arrays"
        )
    element_volumes = tuple(
        float(value)
        for value in gmsh.model.mesh.getElementQualities(quality_tags, "volume")
    )
    if len(element_volumes) != len(raw_elements):
        raise ConstrainedHybridError(
            "Gmsh QuadTri returned an inconsistent element-volume array"
        )
    invalid_volume_indices = tuple(
        index
        for index, value in enumerate(element_volumes)
        if not math.isfinite(value) or value <= 0.0
    )
    if invalid_volume_indices:
        worst_index = min(
            invalid_volume_indices,
            key=lambda index: (
                element_volumes[index]
                if math.isfinite(element_volumes[index])
                else -math.inf,
                raw_elements[index][1],
            ),
        )
        worst_type, worst_tag, _worst_nodes = raw_elements[worst_index]
        raise ConstrainedHybridError(
            "Gmsh QuadTri returned invalid element volumes: "
            f"count={len(invalid_volume_indices)}, "
            f"worst_volume={element_volumes[worst_index]:.12g}, "
            f"worst_type={worst_type}, worst_tag={worst_tag}, "
            f"worst_minDetJac={qualities['minDetJac'][worst_index]:.12g}, "
            f"worst_minSJ={qualities['minSJ'][worst_index]:.12g}, "
            f"worst_minSICN={qualities['minSICN'][worst_index]:.12g}, "
            f"worst_minSIGE={qualities['minSIGE'][worst_index]:.12g}"
        )
    if any(
        not math.isfinite(value) or value <= 0.0
        for value in qualities["minDetJac"]
    ):
        raise ConstrainedHybridError("Gmsh QuadTri produced a non-positive element")
    if any(
        not math.isfinite(value)
        for name in ("minSICN", "minSIGE", "minSJ")
        for value in qualities[name]
    ):
        raise ConstrainedHybridError("Gmsh QuadTri quality is non-finite")
    by_coordinate: dict[tuple[float, float, float], int] = {}
    for gmsh_tag, point in gmsh_coordinates.items():
        key = _coordinate_key(point)
        if key in by_coordinate:
            raise ConstrainedHybridError("Gmsh QuadTri nodes are coincident")
        by_coordinate[key] = gmsh_tag
    gmsh_source: dict[int, int] = {}
    for source_id, point in prepared.coordinates.items():
        gmsh_tag = by_coordinate.get(_coordinate_key(point))
        if gmsh_tag is None or math.dist(gmsh_coordinates[gmsh_tag], point) > (
            _COORDINATE_TOLERANCE
        ):
            raise ConstrainedHybridError("Gmsh changed a QuadTri source node")
        gmsh_source[gmsh_tag] = source_id

    ordered_gmsh = tuple(
        sorted(
            gmsh_coordinates,
            key=lambda tag: (_coordinate_key(gmsh_coordinates[tag]), tag),
        )
    )
    local_by_gmsh = {
        gmsh_tag: local_id
        for local_id, gmsh_tag in enumerate(ordered_gmsh, start=1)
    }
    local_coordinates = {
        local_by_gmsh[tag]: gmsh_coordinates[tag] for tag in ordered_gmsh
    }
    source_by_local = {
        local_by_gmsh[tag]: source_id for tag, source_id in gmsh_source.items()
    }
    ordered_element_rows = tuple(
        sorted(
            (
                (
                    GmshQuadTriElement(
                        gmsh_type,
                        tuple(local_by_gmsh[node] for node in nodes),
                    ),
                    raw_index,
                )
                for raw_index, (gmsh_type, _tag, nodes) in enumerate(
                    raw_elements
                )
            ),
            key=lambda row: (
                row[0].gmsh_type,
                tuple(sorted(row[0].node_ids)),
                row[0].node_ids,
            ),
        )
    )
    elements = tuple(row[0] for row in ordered_element_rows)
    raw_index_by_element_index = tuple(row[1] for row in ordered_element_rows)
    duplicate_elements = len(elements) - len(
        {(element.gmsh_type, _face_key(element.node_ids)) for element in elements}
    )
    if duplicate_elements:
        raise ConstrainedHybridError("Gmsh QuadTri produced duplicate elements")

    owners: dict[
        tuple[int, ...], list[tuple[int, tuple[int, ...]]]
    ] = defaultdict(list)
    for element_index, element in enumerate(elements):
        for face in ELEMENT_SPECS[element.gmsh_type][2]:
            cycle = tuple(element.node_ids[index] for index in face)
            owners[_face_key(cycle)].append((element_index, cycle))
    if any(len(values) not in {1, 2} for values in owners.values()):
        raise ConstrainedHybridError("Gmsh QuadTri adapter is non-manifold")
    boundary = {
        key: values[0][1] for key, values in owners.items() if len(values) == 1
    }
    local_by_source = {
        source_id: local_id for local_id, source_id in source_by_local.items()
    }
    source_facets = tuple(
        tuple(local_by_source[node] for node in facet) for facet in prepared.facets
    )
    source_keys = {_face_key(facet) for facet in source_facets}
    if any(key not in boundary for key in source_keys):
        raise ConstrainedHybridError("Gmsh changed a QuadTri source facet")
    if require_source_hex and any(
        elements[owners[key][0][0]].gmsh_type != _HEX8 for key in source_keys
    ):
        raise ConstrainedHybridError(
            "Gmsh mapped QuadTri source QUAD is not owned by exactly one HEX8"
        )
    source_owner_element_indices = {
        owners[key][0][0] for key in source_keys
    }
    if require_source_hex and len(source_owner_element_indices) != len(source_keys):
        raise ConstrainedHybridError(
            "Gmsh mapped QuadTri source QUADs do not have one distinct HEX8 "
            "continuation per locked QUAD"
        )
    source_hex_element_indices = tuple(
        sorted(
            index
            for index in source_owner_element_indices
            if elements[index].gmsh_type == _HEX8
        )
    )
    source_hex_raw_indices = tuple(
        raw_index_by_element_index[index]
        for index in source_hex_element_indices
    )
    transition_raw_indices = tuple(
        index
        for index in range(len(raw_elements))
        if index not in frozenset(source_hex_raw_indices)
    )
    if (
        require_source_hex
        and require_non_source_transition
        and not transition_raw_indices
    ):
        raise ConstrainedHybridError(
            "Gmsh mapped QuadTri adapter contains no non-HEX transition cells"
        )

    def minimum_for(metric: str, indices: Sequence[int]) -> float:
        return (
            min(qualities[metric][index] for index in indices)
            if indices
            else math.inf
        )

    source_hex_minimum_sicn = minimum_for(
        "minSICN", source_hex_raw_indices
    )
    source_hex_minimum_sige = minimum_for(
        "minSIGE", source_hex_raw_indices
    )
    source_hex_minimum_sj = minimum_for("minSJ", source_hex_raw_indices)
    transition_minimum_sicn = minimum_for(
        "minSICN", transition_raw_indices
    )
    transition_minimum_sige = minimum_for(
        "minSIGE", transition_raw_indices
    )
    transition_minimum_sj = minimum_for("minSJ", transition_raw_indices)
    def cartesian_hex(element: GmshQuadTriElement) -> bool:
        points = tuple(local_coordinates[node] for node in element.node_ids)
        axis_levels: list[tuple[float, ...]] = []
        for axis in range(3):
            levels: list[float] = []
            for value in sorted(point[axis] for point in points):
                if not levels or value - levels[-1] > cartesian_tolerance_mm:
                    levels.append(value)
            axis_levels.append(tuple(levels))
        if any(len(levels) != 2 for levels in axis_levels):
            return False
        expected = {
            (x_value, y_value, z_value)
            for x_value in axis_levels[0]
            for y_value in axis_levels[1]
            for z_value in axis_levels[2]
        }
        return len(expected) == 8 and all(
            any(
                math.dist(point, expected_point) <= cartesian_tolerance_mm
                for expected_point in expected
            )
            for point in points
        )

    source_hex_cartesian = bool(source_hex_element_indices) and all(
        cartesian_hex(elements[index]) for index in source_hex_element_indices
    )
    source_hex_sicn_aspect_quality_exempted = (
        allow_source_hex_sicn_aspect_exemption
        and source_hex_cartesian
        and source_hex_minimum_sicn < minimum_quality
    )
    # Only a source HEX that is itself proved Cartesian may treat low positive
    # SICN as aspect-ratio evidence.  Merely touching an Orth producer is not
    # sufficient: a laterally mapped/skewed Hybrid HEX keeps the full floor.
    # Positive determinant, minSJ and minSIGE remain hard gates in all cases.
    quality_misses = []
    if source_hex_minimum_sicn <= 0.0:
        quality_misses.append("source_hex_minSICN_non_positive")
    elif (
        not source_hex_sicn_aspect_quality_exempted
        and source_hex_minimum_sicn < minimum_quality
    ):
        quality_misses.append("source_hex_minSICN")
    if source_hex_minimum_sj < minimum_quality:
        quality_misses.append("source_hex_minSJ")
    if source_hex_minimum_sige < minimum_quality:
        quality_misses.append("source_hex_minSIGE")
    for metric, value in (
        ("transition_minSJ", transition_minimum_sj),
        ("transition_minSICN", transition_minimum_sicn),
        ("transition_minSIGE", transition_minimum_sige),
    ):
        if value < minimum_quality:
            quality_misses.append(metric)
    if quality_misses:
        worst_rows = []
        for metric_name, indices in (
            ("minSJ", transition_raw_indices),
            ("minSICN", transition_raw_indices),
            ("minSIGE", transition_raw_indices),
        ):
            if not indices:
                continue
            worst_index = min(
                indices,
                key=lambda index: (
                    qualities[metric_name][index],
                    raw_elements[index][1],
                ),
            )
            gmsh_type, gmsh_tag, _nodes = raw_elements[worst_index]
            worst_rows.append(
                f"{metric_name}=(value={qualities[metric_name][worst_index]:.8g},"
                f"type={gmsh_type},tag={gmsh_tag})"
            )
        raise ConstrainedHybridError(
            "Gmsh QuadTri quality floor was not met: "
            f"failed={tuple(quality_misses)!r}, "
            "source_orth_hex=("
            f"count={len(source_hex_raw_indices)}, "
            f"minSJ={source_hex_minimum_sj:.8g}, "
            f"raw_minSICN={source_hex_minimum_sicn:.8g}, "
            f"raw_minSIGE={source_hex_minimum_sige:.8g}), "
            "transition=("
            f"count={len(transition_raw_indices)}, "
            f"minSJ={transition_minimum_sj:.8g}, "
            f"minSICN={transition_minimum_sicn:.8g}, "
            f"minSIGE={transition_minimum_sige:.8g}), "
            "transition_worst=(" + ", ".join(worst_rows) + "), "
            f"required={minimum_quality:.8g}"
        )
    source_nodes = set(local_by_source.values())
    boundary_entirely_on_source = {
        key for key in boundary if set(key).issubset(source_nodes)
    }
    if boundary_entirely_on_source != source_keys:
        raise ConstrainedHybridError(
            "Gmsh mapped QuadTri source boundary facet set is not exact"
        )

    interface_key_rows: list[tuple[int, ...]] = []
    top_types, _top_tags, top_connectivity = gmsh.model.mesh.getElements(
        2, top_surface_tag
    )
    for raw_type, raw_nodes in zip(top_types, top_connectivity):
        if int(raw_type) != interface_gmsh_type:
            raise ConstrainedHybridError(
                "Gmsh mapped adapter opposite interface has an unexpected "
                "facet type"
            )
        nodes = tuple(int(node) for node in raw_nodes)
        node_count = 3 if interface_gmsh_type == _TRI3 else 4
        for start in range(0, len(nodes), node_count):
            interface_key_rows.append(
                _face_key(
                    tuple(
                        local_by_gmsh[node]
                        for node in nodes[start : start + node_count]
                    )
                )
            )
    interface_keys = set(interface_key_rows)
    if len(interface_keys) != len(interface_key_rows):
        raise ConstrainedHybridError(
            "Gmsh QuadTri opposite interface contains duplicate TRI3 facets"
        )
    if not interface_keys or any(key not in boundary for key in interface_keys):
        raise ConstrainedHybridError("Gmsh QuadTri interface is incomplete")
    interface_by_source: dict[int, int] = {}
    first_layer_by_source: dict[int, int] = {}
    if target_coordinates_by_source_node_id is not None:
        target_by_coordinate = {
            _coordinate_key(point): source_id
            for source_id, point in target_coordinates_by_source_node_id.items()
        }
        if len(target_by_coordinate) != len(target_coordinates_by_source_node_id):
            raise ConstrainedHybridError(
                "Gmsh mapped QuadTri target coordinates are not unique"
            )
        interface_nodes = {
            node for key in interface_keys for node in key
        }
        for local_id in interface_nodes:
            source_id = target_by_coordinate.get(
                _coordinate_key(local_coordinates[local_id])
            )
            if source_id is None or math.dist(
                local_coordinates[local_id],
                target_coordinates_by_source_node_id[source_id],
            ) > _COORDINATE_TOLERANCE:
                raise ConstrainedHybridError(
                    "Gmsh mapped QuadTri interface contains an unexpected node"
                )
            if source_id in interface_by_source:
                raise ConstrainedHybridError(
                    "Gmsh mapped QuadTri interface duplicates a target node"
                )
            interface_by_source[source_id] = local_id
        if set(interface_by_source) != set(target_coordinates_by_source_node_id):
            raise ConstrainedHybridError(
                "Gmsh mapped QuadTri interface did not retain every target node"
            )
        mapped_interface_nodes = set(interface_by_source.values())
        boundary_entirely_on_interface = {
            key for key in boundary if set(key).issubset(mapped_interface_nodes)
        }
        if boundary_entirely_on_interface != interface_keys:
            raise ConstrainedHybridError(
                "Gmsh mapped QuadTri opposite boundary facet set is not exact"
            )
        interface_owner_quads: dict[tuple[int, ...], int] = Counter()
        for source_facet in prepared.facets:
            mapped_quad_nodes = {
                interface_by_source[node] for node in source_facet
            }
            if interface_gmsh_type == _QUAD4:
                mapped_key = _face_key(tuple(mapped_quad_nodes))
                if mapped_key not in interface_keys:
                    raise ConstrainedHybridError(
                        "Gmsh mapped HEX adapter changed an opposite QUAD4"
                    )
                interface_owner_quads[mapped_key] += 1
                continue
            mapped_triangles = tuple(
                key for key in interface_keys if set(key).issubset(mapped_quad_nodes)
            )
            if (
                len(mapped_triangles) != 2
                or set().union(*(set(key) for key in mapped_triangles))
                != mapped_quad_nodes
            ):
                raise ConstrainedHybridError(
                    "Gmsh mapped QuadTri did not cover one mapped source QUAD "
                    "with exactly two TRI3 facets"
                )
            triangle_edges = Counter(
                _edge_key(first, second)
                for triangle in mapped_triangles
                for first, second in zip(
                    triangle, (*triangle[1:], triangle[0])
                )
            )
            if sorted(triangle_edges.values()) != [1, 1, 1, 1, 2]:
                raise ConstrainedHybridError(
                    "Gmsh mapped QuadTri source-QUAD triangles do not form "
                    "one unsplit quadrilateral"
                )
            for key in mapped_triangles:
                interface_owner_quads[key] += 1
        if set(interface_owner_quads) != interface_keys or any(
            count != 1 for count in interface_owner_quads.values()
        ):
            raise ConstrainedHybridError(
                "Gmsh mapped adapter interface ownership by source QUAD "
                "is not one-to-one"
            )
        first_fraction = layer_cumulative_fractions[0]
        for source_facet in prepared.facets:
            source_key = _face_key(
                tuple(local_by_source[node] for node in source_facet)
            )
            owner = elements[owners[source_key][0][0]]
            hex_faces = ELEMENT_SPECS[_HEX8][2][:2]
            source_face_index = next(
                (
                    index
                    for index, face in enumerate(hex_faces)
                    if _face_key(
                        tuple(owner.node_ids[position] for position in face)
                    )
                    == source_key
                ),
                None,
            )
            if source_face_index is None:
                raise ConstrainedHybridError(
                    "Gmsh mapped QuadTri HEX does not expose the locked QUAD "
                    "as an end face"
                )
            source_face = hex_faces[source_face_index]
            opposite_face = hex_faces[1 - source_face_index]
            for source_position, opposite_position in zip(
                source_face, opposite_face
            ):
                source_local = owner.node_ids[source_position]
                source_id = source_by_local[source_local]
                first_local = owner.node_ids[opposite_position]
                previous = first_layer_by_source.setdefault(
                    source_id, first_local
                )
                if previous != first_local:
                    raise ConstrainedHybridError(
                        "adjacent Gmsh source HEX8 cells disagree on their "
                        "first-layer node continuation"
                    )
        if len(set(first_layer_by_source.values())) != len(first_layer_by_source):
            raise ConstrainedHybridError(
                "Gmsh mapped QuadTri first layer duplicates a mapped node"
            )
        if set(first_layer_by_source) != set(target_coordinates_by_source_node_id):
            raise ConstrainedHybridError(
                "Gmsh mapped QuadTri first layer does not continue every source node"
            )
        if first_layer_target_coordinates_by_source_node_id is not None and (
            set(first_layer_target_coordinates_by_source_node_id)
            != set(target_coordinates_by_source_node_id)
        ):
            raise ConstrainedHybridError(
                "Gmsh mapped QuadTri first-layer targets are incomplete"
            )
        for source_id, target in target_coordinates_by_source_node_id.items():
            source_local = local_by_source[source_id]
            source_point = local_coordinates[source_local]
            expected = (
                tuple(first_layer_target_coordinates_by_source_node_id[source_id])
                if first_layer_target_coordinates_by_source_node_id is not None
                else tuple(
                    source_point[axis]
                    + first_fraction * (target[axis] - source_point[axis])
                    for axis in range(3)
                )
            )
            first_local = first_layer_by_source[source_id]
            if math.dist(
                local_coordinates[first_local], expected
            ) > _COORDINATE_TOLERANCE:
                raise ConstrainedHybridError(
                    "Gmsh mapped QuadTri changed a first-layer mapped node"
                )
        for source_facet in prepared.facets:
            source_key = _face_key(
                tuple(local_by_source[node] for node in source_facet)
            )
            owner = elements[owners[source_key][0][0]]
            expected_hex_nodes = {
                *(local_by_source[node] for node in source_facet),
                *(first_layer_by_source[node] for node in source_facet),
            }
            if owner.gmsh_type != _HEX8 or set(owner.node_ids) != expected_hex_nodes:
                raise ConstrainedHybridError(
                    "Gmsh mapped QuadTri first-layer HEX does not follow the "
                    "exact per-node displacement field"
                )

    element_adjacency: dict[int, set[int]] = defaultdict(set)
    for face_owners in owners.values():
        if len(face_owners) == 2:
            first = face_owners[0][0]
            second = face_owners[1][0]
            element_adjacency[first].add(second)
            element_adjacency[second].add(first)
    seen_elements: set[int] = set()
    pending_elements = deque([0])
    while pending_elements:
        current = pending_elements.popleft()
        if current in seen_elements:
            continue
        seen_elements.add(current)
        pending_elements.extend(element_adjacency[current].difference(seen_elements))
    if len(seen_elements) != len(elements):
        raise ConstrainedHybridError(
            "Gmsh QuadTri volume elements are not face-connected"
        )
    raw_elements_for_fold = tuple(
        (element.gmsh_type, index, element.node_ids)
        for index, element in enumerate(elements, start=1)
    )
    folded_internal_faces = _folded_internal_face_count(
        raw_elements_for_fold,
        local_coordinates,
    )
    if folded_internal_faces:
        raise ConstrainedHybridError(
            "Gmsh QuadTri volume connectivity folds across internal faces: "
            f"folded_internal_face_count={folded_internal_faces}"
        )
    lateral_keys = set(boundary).difference(source_keys, interface_keys)
    if not lateral_keys:
        raise ConstrainedHybridError("Gmsh QuadTri adapter has no lateral facets")

    _oriented_boundary, boundary_shell_volume = _orient_closed_shell(
        tuple(boundary.values()),
        local_coordinates,
    )
    element_volume = math.fsum(element_volumes)
    relative_volume_error = abs(element_volume - boundary_shell_volume) / (
        boundary_shell_volume
    )
    if relative_volume_error > 1.0e-8:
        raise ConstrainedHybridError(
            "Gmsh QuadTri element volume differs from its closed boundary shell: "
            f"relative_error={relative_volume_error:.8g}"
        )

    ordered = lambda keys: tuple(boundary[key] for key in sorted(keys))
    return GmshQuadTriAdapter(
        node_coordinates=MappingProxyType(local_coordinates),
        source_node_id_by_local_id=MappingProxyType(source_by_local),
        elements=elements,
        source_facets=source_facets,
        interface_facets=ordered(interface_keys),
        lateral_facets=ordered(lateral_keys),
        extrusion_vector=prepared.vector,
        method=method,
        tet4_count=sum(element.gmsh_type == _TET4 for element in elements),
        hex8_count=sum(element.gmsh_type == _HEX8 for element in elements),
        wedge6_count=sum(element.gmsh_type == _WEDGE6 for element in elements),
        pyramid5_count=sum(element.gmsh_type == _PYRAMID5 for element in elements),
        minimum_sicn=min(qualities["minSICN"]),
        minimum_sige=min(qualities["minSIGE"]),
        minimum_scaled_jacobian=min(qualities["minSJ"]),
        minimum_determinant=min(qualities["minDetJac"]),
        source_hex_element_ids=tuple(
            index + 1 for index in source_hex_element_indices
        ),
        source_hex_minimum_sicn=source_hex_minimum_sicn,
        source_hex_minimum_sige=source_hex_minimum_sige,
        source_hex_minimum_scaled_jacobian=source_hex_minimum_sj,
        source_hex_sicn_aspect_quality_exempted=(
            source_hex_sicn_aspect_quality_exempted
        ),
        transition_element_count=len(transition_raw_indices),
        transition_minimum_sicn=transition_minimum_sicn,
        transition_minimum_sige=transition_minimum_sige,
        transition_minimum_scaled_jacobian=transition_minimum_sj,
        duplicate_node_count=0,
        duplicate_element_count=duplicate_elements,
        interface_node_id_by_source_node_id=MappingProxyType(interface_by_source),
        layer_cumulative_fractions=layer_cumulative_fractions,
        mapped_target_coordinates_by_source_node_id=MappingProxyType(
            dict(target_coordinates_by_source_node_id or {})
        ),
        source_quad_hex_owner_count=sum(
            elements[owners[key][0][0]].gmsh_type == _HEX8
            for key in source_keys
        ),
        boundary_shell_volume_mm3=boundary_shell_volume,
        element_volume_mm3=element_volume,
        relative_volume_error=relative_volume_error,
        folded_internal_face_count=folded_internal_faces,
        first_layer_node_id_by_source_node_id=MappingProxyType(
            first_layer_by_source
        ),
        node_ordering=node_ordering,
    )


def generate_gmsh_mapped_quadtri_adapter(
    node_coordinates: Mapping[int, Sequence[float]],
    source_facets: Sequence[Sequence[int]],
    target_coordinates_by_source_node_id: Mapping[int, Sequence[float]],
    *,
    first_layer_fraction: float,
    minimum_quality: float = 0.03,
    allow_source_hex_sicn_aspect_exemption: bool = False,
    interface_geometry_tolerance_mm: float = _COORDINATE_TOLERANCE,
    methods: Sequence[str] = ("add_vertices", "no_new_vertices"),
    node_ordering: str = "xyz",
    verbose: bool = False,
) -> GmshQuadTriAdapter:
    """Generate a two-layer, node-mapped Gmsh QUAD-to-TRI adapter.

    Gmsh receives one displacement vector for every immutable source node.
    Layer one is recombined and therefore leaves one Gmsh-owned HEX8 behind
    every source QUAD; layer two invokes Gmsh's official ``QuadTri``
    transition and exposes an all-TRI opposite interface.  No 3D
    connectivity is assembled by EasyMesh.
    """

    prepared = _prepare_mapped_patch(
        node_coordinates,
        source_facets,
        target_coordinates_by_source_node_id,
        first_layer_fraction,
    )
    quality_floor = _finite(minimum_quality, name="QuadTri minimum quality")
    if quality_floor <= 0.0 or quality_floor >= 1.0:
        raise ConstrainedHybridError("QuadTri minimum quality must lie in (0,1)")
    if not isinstance(allow_source_hex_sicn_aspect_exemption, bool):
        raise ConstrainedHybridError(
            "QuadTri source-HEX SICN exemption flag must be boolean"
        )
    geometry_tolerance = _finite(
        interface_geometry_tolerance_mm,
        name="QuadTri interface geometry tolerance",
    )
    if geometry_tolerance <= 0.0:
        raise ConstrainedHybridError(
            "QuadTri interface geometry tolerance must be positive"
        )
    try:
        requested_methods = tuple(dict.fromkeys(methods))
    except TypeError as error:
        raise ConstrainedHybridError("QuadTri methods must be a sequence") from error
    if not requested_methods or any(method not in _METHODS for method in requested_methods):
        raise ConstrainedHybridError(
            "QuadTri method must be no_new_vertices or add_vertices"
        )
    gmsh = _load_gmsh()
    failures: list[str] = []
    quality_failure_count = 0
    source_ids = _ordered_source_ids(prepared.patch, node_ordering)
    for method in requested_methods:
        symbol_suffix = uuid4().hex
        surface_symbol = f"easymesh_quadtri_surface_{symbol_suffix}"
        first_layer_symbol = f"easymesh_quadtri_first_layer_{symbol_suffix}"
        view_index_symbol = f"easymesh_quadtri_view_index_{symbol_suffix}"
        output_symbol = f"easymesh_quadtri_output_{symbol_suffix}"
        parser_symbols = (
            surface_symbol,
            first_layer_symbol,
            view_index_symbol,
            output_symbol,
        )
        template_path = _write_mapped_geo_template(
            _METHODS[method],
            surface_symbol=surface_symbol,
            first_layer_symbol=first_layer_symbol,
            view_index_symbol=view_index_symbol,
            output_symbol=output_symbol,
        )
        try:
            with isolated_gmsh_model(
                gmsh,
                "__easymesh_occ_quadtri_mapped_adapter",
                number_options={
                    "General.Terminal": 1.0 if verbose else 0.0,
                    "General.NumThreads": 1.0,
                    "Mesh.ElementOrder": 1.0,
                    "Mesh.Optimize": 1.0,
                    "Mesh.OptimizePyramids": 1.0,
                    "Mesh.MaxNumThreads1D": 1.0,
                    "Mesh.MaxNumThreads2D": 1.0,
                    "Mesh.MaxNumThreads3D": 1.0,
                },
            ) as model_name:
                surface_tag = int(gmsh.model.addDiscreteEntity(2, 1))
                gmsh_by_source = {
                    source_id: index
                    for index, source_id in enumerate(source_ids, start=1)
                }
                gmsh.model.mesh.addNodes(
                    2,
                    surface_tag,
                    [gmsh_by_source[node] for node in source_ids],
                    [
                        value
                        for node in source_ids
                        for value in prepared.patch.coordinates[node]
                    ],
                )
                gmsh.model.mesh.addElementsByType(
                    surface_tag,
                    _QUAD4,
                    list(range(1, len(prepared.patch.facets) + 1)),
                    [
                        gmsh_by_source[node]
                        for facet in prepared.patch.facets
                        for node in facet
                    ],
                )
                view_tag = int(gmsh.view.add("mapped_quadtri_displacement"))
                try:
                    gmsh.view.addModelData(
                        view_tag,
                        0,
                        model_name,
                        "NodeData",
                        [gmsh_by_source[node] for node in source_ids],
                        [list(prepared.displacements[node]) for node in source_ids],
                        0.0,
                        3,
                    )
                    view_index = int(gmsh.view.getIndex(view_tag))
                    for name, values in (
                        (surface_symbol, [float(surface_tag)]),
                        (first_layer_symbol, [prepared.first_layer_fraction]),
                        (view_index_symbol, [float(view_index)]),
                    ):
                        gmsh.parser.setNumber(name, values)
                    gmsh.parser.parse(str(template_path))
                    gmsh.model.geo.synchronize()
                    volumes = tuple(
                        int(tag) for _dimension, tag in gmsh.model.getEntities(3)
                    )
                    top_surfaces = tuple(
                        int(tag)
                        for _dimension, tag in gmsh.model.getEntities(2)
                        if int(tag) != surface_tag
                    )
                    if (
                        len(volumes) != 1
                        or len(top_surfaces) != 1
                    ):
                        raise ConstrainedHybridError(
                            "Gmsh mapped QuadTri did not create its expected "
                            "adapter volumes and one interface"
                        )
                    gmsh.model.mesh.generate(3)
                    return _extract_adapter(
                        gmsh,
                        prepared.patch,
                        volumes,
                        top_surfaces[0],
                        method,
                        quality_floor,
                        target_coordinates_by_source_node_id=prepared.targets,
                        layer_cumulative_fractions=(
                            prepared.first_layer_fraction,
                            1.0,
                        ),
                        require_source_hex=True,
                        allow_source_hex_sicn_aspect_exemption=(
                            allow_source_hex_sicn_aspect_exemption
                        ),
                        node_ordering=node_ordering,
                        cartesian_tolerance_mm=geometry_tolerance,
                    )
                finally:
                    try:
                        gmsh.view.remove(view_tag)
                    except Exception:
                        pass
                    for symbol in parser_symbols:
                        try:
                            gmsh.parser.clear(symbol)
                        except Exception:
                            pass
        except ConstrainedHybridError as error:
            failures.append(f"{method}: {error}")
            if "quality floor was not met" in str(error):
                quality_failure_count += 1
        except Exception as error:  # pragma: no cover - Gmsh runtime failure
            failures.append(f"{method}: Gmsh runtime failure: {error}")
        finally:
            try:
                template_path.unlink()
            except OSError:
                pass
    prefix = (
        "locked_surface_quality_incompatible: "
        if quality_failure_count == len(requested_methods)
        else ""
    )
    raise ConstrainedHybridError(
        prefix
        + "all mapped Gmsh QuadTri adapter candidates failed; "
        + f"first_layer_fraction={prepared.first_layer_fraction:.8g}; "
        + f"max_source_quad_edge_ratio={prepared.patch.maximum_edge_ratio:.8g}; "
        + "; ".join(failures)
    )


def generate_gmsh_mapped_hex_adapter(
    node_coordinates: Mapping[int, Sequence[float]],
    source_facets: Sequence[Sequence[int]],
    target_coordinates_by_source_node_id: Mapping[int, Sequence[float]],
    *,
    minimum_quality: float = 0.03,
    allow_source_hex_sicn_aspect_exemption: bool = False,
    interface_geometry_tolerance_mm: float = _COORDINATE_TOLERANCE,
    node_ordering: str = "xyz",
    verbose: bool = False,
) -> GmshQuadTriAdapter:
    """Map an immutable QUAD patch to one Gmsh-owned HEX continuation layer.

    The opposite interface remains QUAD4.  This deliberately contains no
    transition cells: a separate Gmsh Hybrid remainder can consume the
    shrunken QUAD annulus after the protected Orth-origin HEX layer.
    """

    prepared = _prepare_mapped_patch(
        node_coordinates,
        source_facets,
        target_coordinates_by_source_node_id,
        0.5,
    )
    quality_floor = _finite(minimum_quality, name="mapped HEX minimum quality")
    if quality_floor <= 0.0 or quality_floor >= 1.0:
        raise ConstrainedHybridError(
            "mapped HEX minimum quality must lie in (0,1)"
        )
    if not isinstance(allow_source_hex_sicn_aspect_exemption, bool):
        raise ConstrainedHybridError(
            "mapped HEX source-HEX SICN exemption flag must be boolean"
        )
    geometry_tolerance = _finite(
        interface_geometry_tolerance_mm,
        name="mapped HEX interface geometry tolerance",
    )
    if geometry_tolerance <= 0.0:
        raise ConstrainedHybridError(
            "mapped HEX interface geometry tolerance must be positive"
        )
    if not isinstance(verbose, bool):
        raise ConstrainedHybridError("mapped HEX verbose must be boolean")

    gmsh = _load_gmsh()
    source_ids = _ordered_source_ids(prepared.patch, node_ordering)
    try:
        with isolated_gmsh_model(
            gmsh,
            "__easymesh_occ_mapped_hex_adapter",
            number_options={
                "General.Terminal": 1.0 if verbose else 0.0,
                "General.NumThreads": 1.0,
                "Mesh.ElementOrder": 1.0,
                "Mesh.Optimize": 0.0,
                "Mesh.MaxNumThreads1D": 1.0,
                "Mesh.MaxNumThreads2D": 1.0,
                "Mesh.MaxNumThreads3D": 1.0,
            },
        ) as model_name:
            surface_tag = int(gmsh.model.addDiscreteEntity(2, 1))
            gmsh_by_source = {
                source_id: index
                for index, source_id in enumerate(source_ids, start=1)
            }
            gmsh.model.mesh.addNodes(
                2,
                surface_tag,
                [gmsh_by_source[node] for node in source_ids],
                [
                    value
                    for node in source_ids
                    for value in prepared.patch.coordinates[node]
                ],
            )
            gmsh.model.mesh.addElementsByType(
                surface_tag,
                _QUAD4,
                list(range(1, len(prepared.patch.facets) + 1)),
                [
                    gmsh_by_source[node]
                    for facet in prepared.patch.facets
                    for node in facet
                ],
            )
            view_tag = int(gmsh.view.add("mapped_hex_displacement"))
            try:
                gmsh.view.addModelData(
                    view_tag,
                    0,
                    model_name,
                    "NodeData",
                    [gmsh_by_source[node] for node in source_ids],
                    [list(prepared.displacements[node]) for node in source_ids],
                    0.0,
                    3,
                )
                outputs = tuple(
                    (int(dimension), int(tag))
                    for dimension, tag in gmsh.model.geo.extrudeBoundaryLayer(
                        [(2, surface_tag)],
                        numElements=[1],
                        heights=[1.0],
                        recombine=True,
                        viewIndex=int(gmsh.view.getIndex(view_tag)),
                    )
                )
                gmsh.model.geo.synchronize()
                if (
                    not outputs
                    or outputs[0][0] != 2
                    or sum(dimension == 3 for dimension, _tag in outputs) != 1
                ):
                    raise ConstrainedHybridError(
                        "Gmsh mapped HEX extrusion did not create one volume "
                        "and one opposite surface"
                    )
                top_surface_tag = outputs[0][1]
                volume_tag = next(
                    tag for dimension, tag in outputs if dimension == 3
                )
                gmsh.model.mesh.generate(3)
                result = _extract_adapter(
                    gmsh,
                    prepared.patch,
                    volume_tag,
                    top_surface_tag,
                    "mapped_hex",
                    quality_floor,
                    target_coordinates_by_source_node_id=prepared.targets,
                    layer_cumulative_fractions=(1.0,),
                    require_source_hex=True,
                    allow_source_hex_sicn_aspect_exemption=(
                        allow_source_hex_sicn_aspect_exemption
                    ),
                    interface_gmsh_type=_QUAD4,
                    require_non_source_transition=False,
                    node_ordering=node_ordering,
                    cartesian_tolerance_mm=geometry_tolerance,
                )
            finally:
                try:
                    gmsh.view.remove(view_tag)
                except Exception:
                    pass
    except ConstrainedHybridError:
        raise
    except Exception as error:  # pragma: no cover - Gmsh runtime failure
        raise ConstrainedHybridError(
            f"Gmsh mapped HEX adapter failed: {error}"
        ) from error
    if (
        result.hex8_count != len(prepared.patch.facets)
        or result.transition_element_count != 0
        or any(len(facet) != 4 for facet in result.interface_facets)
    ):
        raise ConstrainedHybridError(
            "Gmsh mapped HEX adapter changed its one-HEX-per-QUAD topology"
        )
    return result


__all__ = [
    "GmshQuadTriAdapter",
    "GmshQuadTriElement",
    "generate_gmsh_mapped_hex_adapter",
    "generate_gmsh_mapped_quadtri_adapter",
]
