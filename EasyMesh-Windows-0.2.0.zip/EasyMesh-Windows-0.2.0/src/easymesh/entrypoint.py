from __future__ import annotations

import argparse
import json
import os
import stat
import sys
from pathlib import Path
from typing import Mapping, Sequence

from .axisymmetric import (
    AxisymmetricMeshParameters,
    MeshParameterSet,
    load_parameters_json,
)
from .bump_layout import BumpLayout, load_bump_layout
from .gmsh_builder import build_mesh as build_legacy_mesh
from .parameters import MeshParameters, SymmetryMode, parse_diameters


def _transition_material_argument(value: str) -> tuple[str, str]:
    """Parse and normalize one CLI SOURCE=TARGET material mapping."""

    if value != value.strip() or value.count("=") != 1:
        raise argparse.ArgumentTypeError(
            "transition material must use SOURCE=TARGET without whitespace"
        )
    raw_source, raw_target = value.split("=", 1)
    try:
        from .layout_builder import normalize_material_name

        source = normalize_material_name(
            raw_source,
            field_name="transition material source",
        )
        target = normalize_material_name(
            raw_target,
            field_name="transition material target",
        )
    except (TypeError, ValueError) as error:
        raise argparse.ArgumentTypeError(str(error)) from error
    return source, target


def _transition_material_override_map(
    values: Sequence[tuple[str, str]],
) -> dict[str, str]:
    """Reject conflicting repeated CLI mappings after name normalization."""

    overrides: dict[str, str] = {}
    for source, target in values:
        if source in overrides:
            raise ValueError(f"duplicate --transition-material source: {source}")
        overrides[source] = target
    return overrides


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="easymesh-demo",
        allow_abbrev=False,
        description=(
            "生成同心圆模板，或用原生模板外圈连接多 bump 的 "
            "HEX8/WEDGE6 Gmsh 网格。"
        ),
    )
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--package-v2-contact-preview", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--job-id", help=argparse.SUPPRESS)
    geometry_source = parser.add_mutually_exclusive_group()
    geometry_source.add_argument(
        "--config",
        type=Path,
        help="参数 JSON 文件（自动识别 Layer 轴对称格式或旧平板格式）",
    )
    geometry_source.add_argument(
        "--layer",
        type=Path,
        help="直接读取 .layer 截面定义（XY/Z 尺寸由对应命令行选项指定）",
    )
    geometry_source.add_argument(
        "--layout",
        "--loc",
        dest="layout",
        type=Path,
        help="读取多 bump .loc 布局及其复用网格模板",
    )
    geometry_source.add_argument(
        "--package",
        type=Path,
        help="读取 .pack 装配定义并生成完整封装体网格",
    )
    geometry_source.add_argument(
        "--package-v2-job",
        type=Path,
        help=(
            "执行不可变 Package V2 Job JSON；输出 MSH 与 sidecar 路径由 Job 绑定"
        ),
    )
    parser.add_argument(
        "--progress-jsonl",
        type=Path,
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--progress-run-id",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--package-bulk-mode",
        choices=("sweep", "hybrid"),
        default="sweep",
        help=(
            "Package bulk 网格模式：sweep 对附加 Si 和 substrate 厚度共形拖拽"
            "（默认）；hybrid 从 connected-bump 顶/底面立即在 die/Si 与 "
            "SBT substrate 内做 XY+Z 渐粗；UF 在 bump 顶以上也只保留一次 "
            "QUAD→PYRAMID/TET 适配，随后用粗 TET 同时放大 X/Y/Z。"
            "connected-bump connectivity、50×50 µm 角区、bump 高度内 UF "
            "和 rings 保持不变；"
            "hybrid MSH 转 CDB 只支持 SOLID185"
        ),
    )
    geometry_source.add_argument(
        "--convert-msh",
        type=Path,
        help="把现有 Gmsh MSH 4.1 体网格转换为 ANSYS CDB",
    )
    parser.add_argument("--output", type=Path, help="输出 .msh 或 .cdb 文件")
    parser.add_argument(
        "--cdb-element-type",
        type=int,
        choices=(185, 186),
        default=185,
        help=(
            "CDB 体单元类型：SOLID185（默认）或 SOLID186；"
            "含 TET4/PYRAMID5 的 hybrid package 只能使用 SOLID185"
        ),
    )
    parser.add_argument(
        "--cdb-coordinate-scale",
        type=float,
        default=1.0,
        help="CDB 坐标缩放系数；EasyMesh 的 mm→mm 保持默认 1.0",
    )
    parser.add_argument(
        "--cdb-units",
        choices=("MPA", "NONE"),
        default="MPA",
        help="CDB /UNITS 标签；NONE 表示不写单位标签",
    )
    parser.add_argument("--preview", action="store_true", help="生成后打开 Gmsh 原生预览")
    parser.add_argument("--verbose", action="store_true", help="显示完整 Gmsh 建网日志")
    parser.add_argument("--diameters", help="直径列表，单位 µm，例如 80,70,66,50,40")
    parser.add_argument("--thickness", type=float, default=2.7, help="厚度，单位 µm")
    parser.add_argument("--xy-size", type=float, default=4.0, help="平面目标网格尺寸，单位 µm")
    parser.add_argument("--z-size", type=float, default=1.35, help="厚度方向目标网格尺寸，单位 µm")
    parser.add_argument(
        "--far-field-size",
        type=float,
        default=80.0,
        help="多 bump 布局与 Package 未受保护区的远场平面目标尺寸，单位 µm",
    )
    parser.add_argument(
        "--transition-distance",
        type=float,
        default=120.0,
        help="多 bump 布局/Package 由受保护边界向远场过渡的距离，单位 µm",
    )
    parser.add_argument(
        "--transition-material",
        action="append",
        default=[],
        type=_transition_material_argument,
        metavar="SOURCE=TARGET",
        help=(
            "覆写模板边缘材料向外延伸的材料，可重复；例如 "
            "Cu=UF；输出材料组直接使用这些原名，不添加前缀"
        ),
    )
    parser.add_argument(
        "--symmetry-mode",
        choices=tuple(mode.value for mode in SymmetryMode),
        default=SymmetryMode.XY_45.value,
        help="平面对称约束：xy_45 强制 X/Y 与 45°轴；xy 仅强制 X/Y 轴",
    )
    return parser


def _argument_was_supplied(
    arguments: Sequence[str],
    *option_names: str,
) -> bool:
    """Return whether one long option appeared, including ``--name=value``."""

    return any(
        argument == option or argument.startswith(f"{option}=")
        for argument in arguments
        for option in option_names
    )


def _reject_package_v2_job_overrides(
    parser: argparse.ArgumentParser,
    arguments: Sequence[str],
) -> None:
    """Reject CLI state that is not part of the immutable V2 Job identity."""

    forbidden = (
        "--output",
        "--package-bulk-mode",
        "--cdb-element-type",
        "--cdb-coordinate-scale",
        "--cdb-units",
        "--preview",
        "--verbose",
        "--diameters",
        "--thickness",
        "--xy-size",
        "--z-size",
        "--far-field-size",
        "--transition-distance",
        "--transition-material",
        "--symmetry-mode",
        "--job-id",
    )
    supplied = tuple(
        option
        for option in forbidden
        if _argument_was_supplied(arguments, option)
    )
    if supplied:
        parser.error(
            f"{', '.join(supplied)} cannot be used with --package-v2-job"
        )


def _read_bounded_regular_file(path: Path, *, maximum_bytes: int) -> bytes:
    """Read one regular file without crossing its parser resource budget."""

    if type(maximum_bytes) is not int or maximum_bytes <= 0:
        raise ValueError("input byte limit must be a positive integer")
    flags = os.O_RDONLY
    for name in ("O_BINARY", "O_CLOEXEC", "O_NONBLOCK"):
        flags |= getattr(os, name, 0)
    descriptor = os.open(path, flags)
    try:
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            raise ValueError("Package V2 Job input must be a regular file")
        with os.fdopen(descriptor, "rb", closefd=True) as stream:
            descriptor = -1
            value = stream.read(maximum_bytes + 1)
    finally:
        if descriptor >= 0:
            os.close(descriptor)
    if len(value) > maximum_bytes:
        raise ValueError(
            f"Package V2 Job input exceeds {maximum_bytes} bytes"
        )
    return value


def _parameters_from_args(args: argparse.Namespace) -> MeshParameterSet | BumpLayout:
    if args.config:
        return load_parameters_json(args.config)
    if args.layer:
        layer_text = args.layer.read_text(encoding="utf-8-sig")
        return AxisymmetricMeshParameters(
            layer_text=layer_text,
            target_xy_um=args.xy_size,
            target_z_um=args.z_size,
            model_name=args.layer.stem or "axisymmetric_layer_model",
            symmetry_mode=args.symmetry_mode,
        )
    if args.layout:
        return load_bump_layout(args.layout)
    diameters = parse_diameters(args.diameters or "80,70,66,50,40")
    return MeshParameters(
        diameters_um=diameters,
        thickness_um=args.thickness,
        target_xy_um=args.xy_size,
        target_z_um=args.z_size,
        symmetry_mode=args.symmetry_mode,
    )


def _build_mesh_from_parameters(
    parameters: MeshParameterSet | BumpLayout,
    mesh_path: str | Path,
    *,
    far_field_size_um: float = 80.0,
    transition_distance_um: float = 120.0,
    transition_material_overrides: Mapping[str, str] | None = None,
    preview: bool = False,
    verbose: bool = False,
    job_id: str | None = None,
):
    """Route each persisted parameter schema to its matching mesh builder."""

    if isinstance(parameters, AxisymmetricMeshParameters):
        if transition_material_overrides:
            raise ValueError(
                "transition material overrides are only valid for bump layouts"
            )
        # Keep the material builder independent from the legacy flat builder at
        # module-import time; it reuses some of the latter's reporting helpers.
        from .axisymmetric_builder import build_axisymmetric_mesh

        job_options = {"job_id": job_id} if job_id is not None else {}
        return build_axisymmetric_mesh(
            parameters,
            mesh_path,
            preview=preview,
            verbose=verbose,
            **job_options,
        )
    if isinstance(parameters, BumpLayout):
        from .layout_builder import build_layout_mesh

        job_options = {"job_id": job_id} if job_id is not None else {}
        return build_layout_mesh(
            parameters,
            mesh_path,
            far_field_size_um=far_field_size_um,
            transition_distance_um=transition_distance_um,
            transition_material_overrides=transition_material_overrides,
            preview=preview,
            verbose=verbose,
            **job_options,
        )
    if transition_material_overrides:
        raise ValueError(
            "transition material overrides are only valid for bump layouts"
        )
    return build_legacy_mesh(
        parameters,
        mesh_path,
        preview=preview,
        verbose=verbose,
    )


def main(argv: list[str] | None = None) -> int:
    arguments = sys.argv[1:] if argv is None else argv
    if not arguments:
        from .gui import run_gui

        run_gui()
        return 0

    parser = _parser()
    args = parser.parse_args(arguments)
    if args.package_v2_contact_preview:
        from .package_v2_contact_preview import main as contact_preview_main
        return contact_preview_main()
    if args.package_v2_job is not None:
        _reject_package_v2_job_overrides(parser, arguments)
        if (args.progress_jsonl is None) != (args.progress_run_id is None):
            parser.error(
                "--progress-jsonl and --progress-run-id must be supplied together"
            )
        if args.progress_jsonl is not None and not args.worker:
            parser.error("Package V2 progress transport requires --worker")

        from .package_v2_job import MAX_JOB_REQUEST_BYTES
        from .package_v2_progress import (
            PackageV2ProgressError,
            PackageV2ProgressJsonlWriter,
        )
        from .package_v2_worker import (
            PackageV2WorkerError,
            current_package_v2_runtime_profile,
            execute_package_v2_job_bytes,
        )

        progress_writer = None
        try:
            if args.progress_jsonl is not None:
                progress_writer = PackageV2ProgressJsonlWriter(
                    args.progress_jsonl,
                    run_id=args.progress_run_id,
                )
                progress_writer.__enter__()
            summary = execute_package_v2_job_bytes(
                _read_bounded_regular_file(
                    args.package_v2_job,
                    maximum_bytes=MAX_JOB_REQUEST_BYTES,
                ),
                expected_runtime_profile=current_package_v2_runtime_profile(),
                progress=progress_writer,
            )
        except (
            OSError,
            PackageV2ProgressError,
            PackageV2WorkerError,
            RuntimeError,
            ValueError,
        ) as error:
            if progress_writer is not None:
                progress_writer.fail(str(error))
            print(f"Package V2 Job 执行失败：{error}", file=sys.stderr)
            return 2
        finally:
            if progress_writer is not None:
                progress_writer.__exit__()
        print(
            json.dumps(
                summary.to_report_dict(),
                indent=2,
                ensure_ascii=False,
            )
        )
        return 0
    if args.progress_jsonl is not None or args.progress_run_id is not None:
        parser.error("Package V2 progress transport requires --package-v2-job")
    if args.package is None and args.package_bulk_mode != "sweep":
        parser.error("--package-bulk-mode hybrid requires --package")
    if args.convert_msh is not None:
        if args.transition_material:
            parser.error("--transition-material requires --layout/--loc")
        if args.preview:
            parser.error("--preview is not supported with --convert-msh")

        from .cdb_exporter import (
            CdbExportError,
            CdbExportOptions,
            export_msh_to_cdb,
        )

        output = args.output or args.convert_msh.with_suffix(".cdb")
        try:
            job_options = {"job_id": args.job_id} if args.job_id else {}
            summary = export_msh_to_cdb(
                args.convert_msh,
                output,
                options=CdbExportOptions(
                    element_type=args.cdb_element_type,
                    coordinate_scale=args.cdb_coordinate_scale,
                    units_label=(
                        None if args.cdb_units == "NONE" else args.cdb_units
                    ),
                ),
                **job_options,
            )
        except (CdbExportError, OSError, RuntimeError) as error:
            print(f"MSH→CDB 转换失败：{error}", file=sys.stderr)
            return 2
        print(json.dumps(summary.to_dict(), indent=2, ensure_ascii=False))
        return 0

    if args.package is not None:
        if args.transition_material:
            parser.error("--transition-material requires --layout/--loc")
        if args.preview:
            parser.error("--preview is not supported with --package")
        if (
            args.cdb_element_type != 185
            or args.cdb_coordinate_scale != 1.0
            or args.cdb_units != "MPA"
        ):
            parser.error(
                "--cdb-element-type/--cdb-coordinate-scale/--cdb-units "
                "require --convert-msh"
            )

        from .package_builder import PackageBuildError, build_package_mesh

        output = args.output or Path.cwd() / "output" / "package.msh"
        job_options = {"job_id": args.job_id} if args.job_id else {}
        try:
            summary = build_package_mesh(
                args.package,
                output,
                bulk_mesh_mode=args.package_bulk_mode,
                far_field_size_mm=args.far_field_size / 1000.0,
                transition_distance_mm=args.transition_distance / 1000.0,
                verbose=args.verbose,
                **job_options,
            )
        except (PackageBuildError, ValueError, OSError, RuntimeError) as error:
            print(f"Package 网格生成失败：{error}", file=sys.stderr)
            return 2
        print(json.dumps(summary.to_dict(), indent=2, ensure_ascii=False))
        return 0

    try:
        transition_material_overrides = _transition_material_override_map(
            args.transition_material
        )
    except ValueError as error:
        parser.error(str(error))
    parameters = _parameters_from_args(args)
    if transition_material_overrides and not isinstance(parameters, BumpLayout):
        parser.error("--transition-material requires --layout/--loc")
    default_name = (
        "bumps_connected.msh"
        if isinstance(parameters, BumpLayout)
        else "concentric_demo.msh"
    )
    output = args.output or Path.cwd() / "output" / default_name
    job_options = {"job_id": args.job_id} if args.job_id else {}
    summary = _build_mesh_from_parameters(
        parameters,
        output,
        far_field_size_um=args.far_field_size,
        transition_distance_um=args.transition_distance,
        transition_material_overrides=transition_material_overrides,
        preview=args.preview,
        verbose=args.verbose,
        **job_options,
    )
    print(json.dumps(summary.to_dict(), indent=2, ensure_ascii=False))
    return 0
