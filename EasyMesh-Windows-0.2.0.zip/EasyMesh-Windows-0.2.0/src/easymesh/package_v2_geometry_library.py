"""Token-aware expression traversal and identifier rewriting."""
from __future__ import annotations

from copy import deepcopy
import io
import tokenize


def expression_names(expression: str) -> set[str]:
    return {token.string for token in tokenize.generate_tokens(io.StringIO(expression).readline)
            if token.type == tokenize.NAME}


def rewrite_expression(expression: str, names: dict[str, str], *, allow_incomplete=False) -> str:
    """Rename complete identifiers without changing units or numeric exponents."""
    if not names:
        return expression
    lines = expression.splitlines(keepends=True)
    offsets = [0]
    for line in lines:
        offsets.append(offsets[-1] + len(line))
    edits = []
    try:
        for token in tokenize.generate_tokens(io.StringIO(expression).readline):
            if token.type == tokenize.NAME and token.string in names:
                edits.append((offsets[token.start[0] - 1] + token.start[1],
                              offsets[token.end[0] - 1] + token.end[1], names[token.string]))
    except (tokenize.TokenError, SyntaxError) as error:
        if not allow_incomplete:
            raise ValueError(f"公式语法错误：{error}") from error
    for start, end, value in reversed(edits):
        expression = expression[:start] + value + expression[end:]
    return expression


def rewrite_scope_references(scope, names, *, allow_incomplete=False):
    """Rewrite a Global or Local scope, without entering child template scopes."""
    def rewrite(text):
        return rewrite_expression(text, names, allow_incomplete=allow_incomplete)

    for variable in scope["derived"]:
        if isinstance(variable["expression"], str):
            variable["expression"] = rewrite(variable["expression"])
    if "solids" in scope:
        scope["solids"] = map_expressions(scope["solids"], rewrite)
    for instance in scope["instances"]:
        for key in ("bindings", "origin", "rotation", "mesh_control"):
            if key in instance:
                instance[key] = map_expressions(instance[key], rewrite)


def map_expressions(value, transform):
    """Visit numeric-expression fields, excluding geometry/strategy metadata."""
    if isinstance(value, dict):
        return {key: deepcopy(child) if key in {"id", "kind", "direction", "sizing"}
                else map_expressions(child, transform) for key, child in value.items()}
    if isinstance(value, list):
        return [map_expressions(child, transform) for child in value]
    return transform(value) if isinstance(value, str) else value
