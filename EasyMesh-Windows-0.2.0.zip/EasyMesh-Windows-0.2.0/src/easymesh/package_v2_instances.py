"""Current Frozen transform inputs and numerical geometry reflection."""
from __future__ import annotations


from .package_assembly import ResolvedTemplateParameters, TemplateDimension
from .package_v2_instance_transform import (
    discrete_matrix,
)


def transform_values(translation, rotations, mirrors, pivot):
    resolved = ResolvedTemplateParameters(())
    def length_vector(values):
        if len(values) != 3:
            raise ValueError("坐标必须包含 X/Y/Z 三项。")
        return tuple(resolved.evaluate_expression(value, dimension=TemplateDimension.LENGTH) for value in values)
    return length_vector(translation), discrete_matrix(rotations, mirrors), length_vector(pivot)


def _reflect_geometry_x(geometry):
    kind = geometry["kind"]
    if kind == "union":
        for child in geometry["children"]:
            _reflect_geometry_x(child)
    elif kind == "difference":
        _reflect_geometry_x(geometry["base"])
        for child in geometry["cutters"]:
            _reflect_geometry_x(child)
    else:
        origin_key, size_key = {"box": ("origin", "size"),
            "rectangular_frame_extrusion": ("outer_origin", "outer_size"),
            "rectangular_underfill_fillet": ("die_origin", "die_size")}[kind]
        geometry[origin_key][0] = f"-(({geometry[origin_key][0]}) + ({geometry[size_key][0]}))"
        if kind == "rectangular_frame_extrusion":
            geometry["opening_offset"][0] = f"({geometry['outer_size'][0]}) - ({geometry['opening_offset'][0]}) - ({geometry['opening_size'][0]})"
        if kind == "rectangular_underfill_fillet":
            for key in ("side_widths", "top_widths"):
                if key in geometry:
                    geometry[key][0], geometry[key][1] = geometry[key][1], geometry[key][0]
