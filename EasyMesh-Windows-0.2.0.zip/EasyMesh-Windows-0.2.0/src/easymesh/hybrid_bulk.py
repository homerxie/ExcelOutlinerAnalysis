"""Deterministic, Gmsh-independent star fill for a hybrid bulk shell.

``fill_hybrid_bulk`` fills one closed, outward-oriented TRI3/QUAD4 boundary
shell from one caller-supplied kernel point.  Each TRI3 produces one TET4 and
each QUAD4 produces one PYRAMID5.  In particular, a locked QUAD4 is never
split: its four-node cycle is retained as the source boundary of exactly one
pyramid.

The boundary facets use the conventional outward orientation.  First-order
volume elements use the opposite (inward) base orientation so that their
signed volumes are positive.  ``StarElement.source_facet_node_ids`` records
the unchanged, outward-oriented boundary cycle; this makes a locked docking
quad explicit without emitting an inverted solver element.

The shell is checked as one connected, closed combinatorial 2-manifold and
each facet is checked locally.  General intersections between non-adjacent
facets are deliberately not searched here: the caller must supply an embedded
(non-self-intersecting) shell.  This limitation matters for arbitrary or
untrusted surface meshes; the volume-sum check alone cannot detect overlapping
volume cells caused by geometric self-intersection.

This module deliberately has no Gmsh imports and is not wired into the package
builder.  It is the Phase-2a geometry/topology kernel only.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from enum import Enum
import math
from types import MappingProxyType
from typing import TypeAlias


Point3D: TypeAlias = tuple[float, float, float]
EdgeKey: TypeAlias = tuple[int, int]


class HybridBulkError(ValueError):
    """Raised when a boundary shell cannot be filled safely."""


class BoundaryFacetKind(str, Enum):
    """Supported first-order boundary facets."""

    TRI3 = "TRI3"
    QUAD4 = "QUAD4"


class StarElementKind(str, Enum):
    """Volume elements emitted by the star fill."""

    TET4 = "TET4"
    PYRAMID5 = "PYRAMID5"


@dataclass(frozen=True, slots=True)
class BoundaryFacet:
    """One outward-oriented boundary facet.

    ``locked`` is meaningful for QUAD4 facets.  A locked quad is guaranteed
    to remain one complete pyramid base and is never diagonally split.
    """

    kind: BoundaryFacetKind
    node_ids: tuple[int, ...]
    locked: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.kind, BoundaryFacetKind):
            raise HybridBulkError("boundary facet kind must be TRI3 or QUAD4")
        if not isinstance(self.locked, bool):
            raise HybridBulkError("boundary facet locked flag must be a bool")
        try:
            canonical_node_ids = tuple(self.node_ids)
        except TypeError as exc:
            raise HybridBulkError("boundary facet node_ids must be a sequence") from exc
        object.__setattr__(self, "node_ids", canonical_node_ids)
        expected = 3 if self.kind is BoundaryFacetKind.TRI3 else 4
        if len(self.node_ids) != expected:
            raise HybridBulkError(
                f"{self.kind.value} requires {expected} node ids, "
                f"got {len(self.node_ids)}"
            )
        if any(
            isinstance(node_id, bool)
            or not isinstance(node_id, int)
            for node_id in self.node_ids
        ):
            raise HybridBulkError("boundary node ids must be integers")
        if len(set(self.node_ids)) != expected:
            raise HybridBulkError(
                f"{self.kind.value} contains repeated node ids: {self.node_ids}"
            )
        if self.locked and self.kind is not BoundaryFacetKind.QUAD4:
            raise HybridBulkError("only a QUAD4 boundary facet can be locked")

    @classmethod
    def tri3(cls, node_ids: Sequence[int]) -> BoundaryFacet:
        """Construct an outward-oriented TRI3 facet."""

        return cls(BoundaryFacetKind.TRI3, node_ids)  # type: ignore[arg-type]

    @classmethod
    def quad4(
        cls,
        node_ids: Sequence[int],
        *,
        locked: bool = False,
    ) -> BoundaryFacet:
        """Construct an outward-oriented QUAD4 facet."""

        return cls(
            BoundaryFacetKind.QUAD4,
            node_ids,  # type: ignore[arg-type]
            locked=locked,
        )


@dataclass(frozen=True, slots=True)
class StarElement:
    """One positive-volume TET4 or PYRAMID5 produced from one shell facet."""

    kind: StarElementKind
    node_ids: tuple[int, ...]
    source_facet_node_ids: tuple[int, ...]
    source_facet_locked: bool

    @property
    def kernel_node_id(self) -> int:
        """The final node in both supported volume-element connectivities."""

        return self.node_ids[-1]

    @property
    def base_node_ids(self) -> tuple[int, ...]:
        """The inward-oriented solver base, excluding the kernel node."""

        return self.node_ids[:-1]


@dataclass(frozen=True, slots=True)
class HybridBulkMesh:
    """Checked result for a caller-certified embedded boundary shell."""

    node_coordinates: Mapping[int, Point3D]
    kernel_node_id: int
    boundary_facets: tuple[BoundaryFacet, ...]
    elements: tuple[StarElement, ...]
    shell_volume: float
    element_volume_sum: float
    minimum_element_volume: float
    length_tolerance: float
    volume_tolerance: float

    def element_signed_volume(self, element: StarElement) -> float:
        """Return the signed volume using first-order solver connectivity."""

        points = tuple(self.node_coordinates[node_id] for node_id in element.node_ids)
        if element.kind is StarElementKind.TET4:
            return _signed_tetra_volume(*points)  # type: ignore[arg-type]
        if element.kind is StarElementKind.PYRAMID5:
            return _signed_tetra_volume(
                points[0], points[1], points[2], points[4]
            ) + _signed_tetra_volume(
                points[0], points[2], points[3], points[4]
            )
        raise AssertionError(f"unsupported star element kind: {element.kind}")


def _subtract(first: Point3D, second: Point3D) -> Point3D:
    return (
        first[0] - second[0],
        first[1] - second[1],
        first[2] - second[2],
    )


def _dot(first: Point3D, second: Point3D) -> float:
    return first[0] * second[0] + first[1] * second[1] + first[2] * second[2]


def _cross(first: Point3D, second: Point3D) -> Point3D:
    return (
        first[1] * second[2] - first[2] * second[1],
        first[2] * second[0] - first[0] * second[2],
        first[0] * second[1] - first[1] * second[0],
    )


def _norm(vector: Point3D) -> float:
    return math.sqrt(_dot(vector, vector))


def _signed_tetra_volume(
    first: Point3D,
    second: Point3D,
    third: Point3D,
    fourth: Point3D,
) -> float:
    return _dot(
        _cross(_subtract(second, first), _subtract(third, first)),
        _subtract(fourth, first),
    ) / 6.0


def _canonical_point(point: Sequence[float], *, label: str) -> Point3D:
    if isinstance(point, (str, bytes, bytearray)):
        raise HybridBulkError(f"{label} must contain exactly three coordinates")
    try:
        raw_values = tuple(point)
    except TypeError as exc:
        raise HybridBulkError(
            f"{label} must contain exactly three coordinates"
        ) from exc
    if len(raw_values) != 3:
        raise HybridBulkError(f"{label} must contain exactly three coordinates")
    if any(isinstance(value, bool) for value in raw_values):
        raise HybridBulkError(f"{label} coordinates must be finite numbers")
    try:
        result = tuple(float(value) for value in raw_values)
    except (TypeError, ValueError, OverflowError) as exc:
        raise HybridBulkError(f"{label} coordinates must be finite numbers") from exc
    if any(not math.isfinite(value) for value in result):
        raise HybridBulkError(f"{label} coordinates must be finite numbers")
    return result  # type: ignore[return-value]


def _canonical_cycle(node_ids: tuple[int, ...]) -> tuple[int, ...]:
    """Rotate a directed cycle deterministically without reversing it."""

    anchor = min(range(len(node_ids)), key=lambda index: node_ids[index])
    return node_ids[anchor:] + node_ids[:anchor]


def _facet_sort_key(facet: BoundaryFacet) -> tuple[object, ...]:
    return (
        tuple(sorted(facet.node_ids)),
        facet.kind.value,
        facet.node_ids,
        facet.locked,
    )


def _triangles(facet: BoundaryFacet) -> tuple[tuple[int, int, int], ...]:
    if facet.kind is BoundaryFacetKind.TRI3:
        first, second, third = facet.node_ids
        return ((first, second, third),)
    first, second, third, fourth = facet.node_ids
    return ((first, second, third), (first, third, fourth))


def _facet_edges(facet: BoundaryFacet) -> tuple[tuple[int, int], ...]:
    nodes = facet.node_ids
    return tuple(
        (nodes[index], nodes[(index + 1) % len(nodes)])
        for index in range(len(nodes))
    )


def _validate_shell_topology(facets: Sequence[BoundaryFacet]) -> None:
    """Require one closed, oriented combinatorial 2-manifold."""

    incidences: dict[EdgeKey, list[tuple[int, int, int]]] = defaultdict(list)
    facets_by_vertex: dict[int, list[tuple[int, int, int]]] = defaultdict(list)
    for facet_index, facet in enumerate(facets):
        for start, end in _facet_edges(facet):
            incidences[min(start, end), max(start, end)].append(
                (facet_index, start, end)
            )
        for local_index, vertex in enumerate(facet.node_ids):
            previous = facet.node_ids[local_index - 1]
            following = facet.node_ids[(local_index + 1) % len(facet.node_ids)]
            facets_by_vertex[vertex].append((previous, following, facet_index))

    bad_counts = tuple(
        (edge, len(directions))
        for edge, directions in sorted(incidences.items())
        if len(directions) != 2
    )
    if bad_counts:
        preview = ", ".join(
            f"{edge}:{count}" for edge, count in bad_counts[:6]
        )
        raise HybridBulkError(
            "boundary shell is open or non-manifold: every undirected edge "
            f"must have incidence 2 ({preview})"
        )

    bad_orientation = tuple(
        edge
        for edge, owners in sorted(incidences.items())
        if (owners[0][1], owners[0][2])
        != (owners[1][2], owners[1][1])
    )
    if bad_orientation:
        preview = ", ".join(str(edge) for edge in bad_orientation[:6])
        raise HybridBulkError(
            "boundary facet orientations are inconsistent across shared edges "
            f"({preview})"
        )

    # Edge incidence alone permits several closed shells in one call.  With a
    # shared kernel those independent star fills necessarily overlap or meet
    # only at the kernel, so reject them before any volume elements are made.
    facet_adjacency: list[set[int]] = [set() for _facet in facets]
    for owners in incidences.values():
        first_facet = owners[0][0]
        second_facet = owners[1][0]
        facet_adjacency[first_facet].add(second_facet)
        facet_adjacency[second_facet].add(first_facet)
    remaining = set(range(len(facets)))
    component_count = 0
    while remaining:
        component_count += 1
        pending = [remaining.pop()]
        while pending:
            current = pending.pop()
            newly_reached = facet_adjacency[current] & remaining
            remaining.difference_update(newly_reached)
            pending.extend(newly_reached)
    if component_count != 1:
        raise HybridBulkError(
            "boundary shell must contain exactly one edge-connected facet "
            f"component, got {component_count}"
        )

    # At a manifold vertex, intersecting the surface with a sufficiently small
    # sphere produces one cycle.  Edge incidence two is not enough: pinching
    # two otherwise valid surface patches into one node produces two disjoint
    # cycles and would make the star-fill complex non-manifold at that node.
    for vertex, corners in sorted(facets_by_vertex.items()):
        link_adjacency: dict[int, list[int]] = defaultdict(list)
        for previous, following, _facet_index in corners:
            link_adjacency[previous].append(following)
            link_adjacency[following].append(previous)
        bad_link_degrees = tuple(
            (neighbor, len(adjacent))
            for neighbor, adjacent in sorted(link_adjacency.items())
            if len(adjacent) != 2
        )
        if bad_link_degrees:
            preview = ", ".join(
                f"{neighbor}:{degree}"
                for neighbor, degree in bad_link_degrees[:6]
            )
            raise HybridBulkError(
                f"boundary vertex {vertex} link must be a single cycle; "
                f"invalid degrees ({preview})"
            )
        link_nodes = set(link_adjacency)
        visited: set[int] = set()
        pending = [next(iter(link_nodes))]
        while pending:
            current = pending.pop()
            if current in visited:
                continue
            visited.add(current)
            pending.extend(
                neighbor
                for neighbor in link_adjacency[current]
                if neighbor not in visited
            )
        if visited != link_nodes:
            raise HybridBulkError(
                f"boundary vertex {vertex} link must be a single cycle; "
                "multiple link components were found"
            )


def _geometry_tolerances(
    points: Sequence[Point3D],
    *,
    relative_tolerance: float,
) -> tuple[float, float, float]:
    minima = tuple(min(point[axis] for point in points) for axis in range(3))
    maxima = tuple(max(point[axis] for point in points) for axis in range(3))
    spans = tuple(maxima[axis] - minima[axis] for axis in range(3))
    scale = max(spans)
    if not math.isfinite(scale) or scale <= 0.0:
        raise HybridBulkError("boundary shell has zero spatial extent")
    coordinate_scale = max(abs(value) for point in points for value in point)
    # Do not impose an ulp(1.0) floor: the API is unit-agnostic and a relative
    # tolerance must behave the same for geometrically similar shells near the
    # origin.  ``scale`` also keeps the roundoff reference non-zero when a
    # shell straddles zero with small absolute coordinates.
    roundoff_scale = max(coordinate_scale, scale)
    roundoff = 64.0 * math.ulp(roundoff_scale)
    length_tolerance = max(relative_tolerance * scale, roundoff)
    area_tolerance = length_tolerance * scale
    volume_tolerance = length_tolerance * scale * scale
    return length_tolerance, area_tolerance, volume_tolerance


def _validate_facet_geometry(
    facet: BoundaryFacet,
    coordinates: Mapping[int, Point3D],
    kernel: Point3D,
    *,
    length_tolerance: float,
    area_tolerance: float,
) -> None:
    points = tuple(coordinates[node_id] for node_id in facet.node_ids)
    first, second, third = points[:3]
    normal = _cross(_subtract(second, first), _subtract(third, first))
    normal_length = _norm(normal)
    if normal_length <= area_tolerance:
        raise HybridBulkError(
            f"{facet.kind.value} facet {facet.node_ids} is degenerate"
        )
    unit_normal = tuple(value / normal_length for value in normal)

    if facet.kind is BoundaryFacetKind.QUAD4:
        fourth = points[3]
        plane_distance = abs(_dot(unit_normal, _subtract(fourth, first)))
        if plane_distance > length_tolerance:
            raise HybridBulkError(
                f"QUAD4 facet {facet.node_ids} is not planar"
            )
        # All consecutive turns must agree with the first triangle normal.
        # This rejects bow-ties, collinear corners, and concave bases before a
        # pyramid with an invalid isoparametric mapping can be emitted.
        for index in range(4):
            previous = points[(index - 1) % 4]
            current = points[index]
            following = points[(index + 1) % 4]
            turn = _cross(
                _subtract(current, previous),
                _subtract(following, current),
            )
            if _dot(turn, unit_normal) <= area_tolerance:
                raise HybridBulkError(
                    f"QUAD4 facet {facet.node_ids} must be strictly convex "
                    "and cyclically ordered"
                )

    signed_kernel_distance = _dot(unit_normal, _subtract(kernel, first))
    if signed_kernel_distance >= -length_tolerance:
        raise HybridBulkError(
            "kernel point must lie strictly inside every outward-oriented "
            f"boundary facet; failed at {facet.kind.value} {facet.node_ids}"
        )


def _shell_signed_volume(
    facets: Sequence[BoundaryFacet],
    coordinates: Mapping[int, Point3D],
) -> float:
    """Divergence-theorem volume with a stable translated origin."""

    used_points = tuple(coordinates[node_id] for node_id in sorted(coordinates))
    reference_values = tuple(
        0.5
        * (
            min(point[axis] for point in used_points)
            + max(point[axis] for point in used_points)
        )
        for axis in range(3)
    )
    reference: Point3D = reference_values  # type: ignore[assignment]
    contributions: list[float] = []
    for facet in facets:
        for first_id, second_id, third_id in _triangles(facet):
            first = _subtract(coordinates[first_id], reference)
            second = _subtract(coordinates[second_id], reference)
            third = _subtract(coordinates[third_id], reference)
            contributions.append(_dot(first, _cross(second, third)) / 6.0)
    return math.fsum(contributions)


def _make_element(facet: BoundaryFacet, kernel_node_id: int) -> StarElement:
    outward = facet.node_ids
    # The shell normal points outwards.  Reverse only the base cycle so the
    # final kernel/apex node lies on its positive-volume side.
    inward = (outward[0],) + tuple(reversed(outward[1:]))
    kind = (
        StarElementKind.TET4
        if facet.kind is BoundaryFacetKind.TRI3
        else StarElementKind.PYRAMID5
    )
    return StarElement(
        kind=kind,
        node_ids=inward + (kernel_node_id,),
        source_facet_node_ids=outward,
        source_facet_locked=facet.locked,
    )


def _element_signed_volume(
    element: StarElement,
    coordinates: Mapping[int, Point3D],
) -> float:
    points = tuple(coordinates[node_id] for node_id in element.node_ids)
    if element.kind is StarElementKind.TET4:
        return _signed_tetra_volume(*points)  # type: ignore[arg-type]
    return _signed_tetra_volume(
        points[0], points[1], points[2], points[4]
    ) + _signed_tetra_volume(
        points[0], points[2], points[3], points[4]
    )


def fill_hybrid_bulk(
    node_coordinates: Mapping[int, Sequence[float]],
    boundary_facets: Sequence[BoundaryFacet],
    kernel_point: Sequence[float],
    *,
    kernel_node_id: int | None = None,
    relative_tolerance: float = 1.0e-10,
) -> HybridBulkMesh:
    """Fill a validated TRI3/QUAD4 shell by connecting it to one kernel.

    The shell is checked as one closed, consistently oriented combinatorial
    2-manifold: every edge has incidence two and every vertex link is one
    cycle.  The kernel must lie strictly behind every facet plane, all quads
    must be planar and strictly convex, every generated cell must have positive
    volume, and the cell-volume sum must match the oriented shell volume.

    General intersection testing between non-adjacent facets is outside this
    local kernel.  The caller must therefore certify that the supplied shell
    is embedded (non-self-intersecting); the volume-sum equality does not prove
    that property.

    Facet input order and cyclic start nodes do not affect the returned
    connectivity order.  Reversing a facet is *not* normalised because doing
    so would hide an invalid shell orientation.
    """

    if not isinstance(node_coordinates, Mapping) or not node_coordinates:
        raise HybridBulkError("node_coordinates must be a non-empty mapping")
    if isinstance(relative_tolerance, bool):
        raise HybridBulkError("relative_tolerance must be finite and between 0 and 1")
    try:
        parsed_relative_tolerance = float(relative_tolerance)
    except (TypeError, ValueError, OverflowError) as exc:
        raise HybridBulkError(
            "relative_tolerance must be finite and between 0 and 1"
        ) from exc
    if not math.isfinite(parsed_relative_tolerance) or not (
        0.0 < parsed_relative_tolerance < 1.0
    ):
        raise HybridBulkError("relative_tolerance must be finite and between 0 and 1")
    relative_tolerance = parsed_relative_tolerance
    if isinstance(boundary_facets, (str, bytes, bytearray)):
        raise HybridBulkError("boundary_facets must be a sequence of BoundaryFacet")
    try:
        canonical_facets = tuple(boundary_facets)
    except TypeError as exc:
        raise HybridBulkError(
            "boundary_facets must be a sequence of BoundaryFacet"
        ) from exc
    if not canonical_facets:
        raise HybridBulkError("boundary_facets must not be empty")
    if any(not isinstance(facet, BoundaryFacet) for facet in canonical_facets):
        raise HybridBulkError("every boundary facet must be a BoundaryFacet")
    boundary_facets = canonical_facets

    referenced_ids = {
        node_id for facet in boundary_facets for node_id in facet.node_ids
    }
    missing_ids = tuple(sorted(referenced_ids.difference(node_coordinates)))
    if missing_ids:
        raise HybridBulkError(f"boundary facets reference missing nodes: {missing_ids}")

    coordinates: dict[int, Point3D] = {}
    for node_id in sorted(referenced_ids):
        if isinstance(node_id, bool) or not isinstance(node_id, int):
            raise HybridBulkError("node ids must be integers")
        coordinates[node_id] = _canonical_point(
            node_coordinates[node_id], label=f"node {node_id}"
        )
    coordinate_owners: dict[Point3D, int] = {}
    for node_id, point in coordinates.items():
        previous = coordinate_owners.setdefault(point, node_id)
        if previous != node_id:
            raise HybridBulkError(
                f"nodes {previous} and {node_id} have duplicate coordinates"
            )

    kernel = _canonical_point(kernel_point, label="kernel point")
    if kernel_node_id is None:
        kernel_node_id = max(referenced_ids) + 1
        while kernel_node_id in node_coordinates:
            kernel_node_id += 1
    if (
        isinstance(kernel_node_id, bool)
        or not isinstance(kernel_node_id, int)
    ):
        raise HybridBulkError("kernel_node_id must be an integer")
    if kernel_node_id in node_coordinates:
        raise HybridBulkError(f"kernel_node_id {kernel_node_id} already exists")
    if kernel in coordinate_owners:
        raise HybridBulkError("kernel point coincides with a boundary node")

    normalized_facets = tuple(
        sorted(
            (
                BoundaryFacet(
                    facet.kind,
                    _canonical_cycle(facet.node_ids),
                    locked=facet.locked,
                )
                for facet in boundary_facets
            ),
            key=_facet_sort_key,
        )
    )
    facet_keys = tuple(tuple(sorted(facet.node_ids)) for facet in normalized_facets)
    if len(facet_keys) != len(set(facet_keys)):
        raise HybridBulkError("boundary shell contains duplicate facets")

    _validate_shell_topology(normalized_facets)
    all_points = tuple(coordinates.values()) + (kernel,)
    length_tolerance, area_tolerance, volume_tolerance = _geometry_tolerances(
        all_points,
        relative_tolerance=relative_tolerance,
    )
    for facet in normalized_facets:
        _validate_facet_geometry(
            facet,
            coordinates,
            kernel,
            length_tolerance=length_tolerance,
            area_tolerance=area_tolerance,
        )

    shell_volume = _shell_signed_volume(normalized_facets, coordinates)
    if shell_volume <= volume_tolerance:
        raise HybridBulkError(
            "boundary normals and oriented shell volume are inconsistent or "
            f"degenerate: signed volume={shell_volume:.17g}"
        )

    complete_coordinates = dict(coordinates)
    complete_coordinates[kernel_node_id] = kernel
    elements = tuple(
        _make_element(facet, kernel_node_id) for facet in normalized_facets
    )
    element_volumes = tuple(
        _element_signed_volume(element, complete_coordinates)
        for element in elements
    )
    non_positive = tuple(
        (element.kind.value, element.source_facet_node_ids, volume)
        for element, volume in zip(elements, element_volumes)
        if volume <= volume_tolerance
    )
    if non_positive:
        kind, facet_nodes, volume = non_positive[0]
        raise HybridBulkError(
            f"generated {kind} from facet {facet_nodes} has non-positive "
            f"volume {volume:.17g}"
        )

    element_volume_sum = math.fsum(element_volumes)
    match_tolerance = max(
        volume_tolerance,
        relative_tolerance * max(shell_volume, element_volume_sum),
        64.0
        * math.ulp(max(shell_volume, element_volume_sum))
        * len(elements),
    )
    if not math.isclose(
        element_volume_sum,
        shell_volume,
        rel_tol=0.0,
        abs_tol=match_tolerance,
    ):
        raise HybridBulkError(
            "generated element-volume sum does not match boundary shell volume: "
            f"elements={element_volume_sum:.17g}, shell={shell_volume:.17g}, "
            f"tolerance={match_tolerance:.17g}"
        )

    return HybridBulkMesh(
        node_coordinates=MappingProxyType(dict(sorted(complete_coordinates.items()))),
        kernel_node_id=kernel_node_id,
        boundary_facets=normalized_facets,
        elements=elements,
        shell_volume=shell_volume,
        element_volume_sum=element_volume_sum,
        minimum_element_volume=min(element_volumes),
        length_tolerance=length_tolerance,
        volume_tolerance=volume_tolerance,
    )


__all__ = [
    "BoundaryFacet",
    "BoundaryFacetKind",
    "HybridBulkError",
    "HybridBulkMesh",
    "Point3D",
    "StarElement",
    "StarElementKind",
    "fill_hybrid_bulk",
]
