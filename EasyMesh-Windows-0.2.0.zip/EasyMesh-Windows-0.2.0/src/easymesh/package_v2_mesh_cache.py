"""Bounded process cache of immutable mesh copies, keyed by file identity/content."""
from collections import OrderedDict
from dataclasses import dataclass, field
from pathlib import Path
from threading import RLock
import tempfile


@dataclass
class MeshFileEntry:
    path: Path
    signature: tuple[int, ...]
    temporary: object
    capture: object
    parsed_mesh: object = None
    parsed_limits: object = None
    counts: tuple[int, int, int] | None = None
    geometry_data: object = None
    geometry_memory: int = 0
    lock: object = field(default_factory=RLock)

    @property
    def private_path(self):
        return Path(self.temporary.name) / "mesh.msh"

    def __del__(self):
        self.temporary.cleanup()


_entries = OrderedDict()
_lock = RLock()
_MAX_CACHED_FILES = 4
_MAX_CACHED_BYTES = 512 * 1024 * 1024
_MAX_CACHED_MESH_MEMORY = 512 * 1024 * 1024


def mesh_file_entry(path, *, maximum_mesh_bytes=512 * 1024 * 1024, cancelled=lambda: False):
    # Lazy imports avoid a cycle with the public Frozen loader.
    from .package_v2_frozen import _regular_lstat, _stat_signature, _capture_regular_file, FrozenSourceError

    path = Path(path).absolute()
    with _lock:
        signature = _stat_signature(_regular_lstat(path, role="mesh"))
        if signature[2] > maximum_mesh_bytes:
            raise FrozenSourceError(f"frozen mesh artifact exceeds the {maximum_mesh_bytes}-byte limit")
        previous = _entries.get(path)
        if previous is not None and previous.signature == signature:
            _entries.move_to_end(path)
            return previous
        temporary = tempfile.TemporaryDirectory(prefix="easymesh-mesh-cache-")
        try:
            capture = _capture_regular_file(path, role="mesh",
                maximum_size=maximum_mesh_bytes, snapshot_copy_path=Path(temporary.name) / "mesh.msh",
                cancelled=cancelled)
            if _stat_signature(_regular_lstat(path, role="mesh")) != signature:
                raise FrozenSourceError("网格文件在读取期间发生变化，请重试。")
        except BaseException:
            temporary.cleanup()
            raise
        entry = MeshFileEntry(path, signature, temporary, capture)
        if (previous is not None and previous.capture.snapshot.sha256 == capture.snapshot.sha256
                and previous.lock.acquire(blocking=False)):
            try:
                entry.parsed_mesh, entry.parsed_limits, entry.counts = (
                    previous.parsed_mesh, previous.parsed_limits, previous.counts)
                entry.geometry_data = previous.geometry_data
                entry.geometry_memory = previous.geometry_memory
            finally:
                previous.lock.release()
        _entries[path] = entry
        _entries.move_to_end(path)
        while len(_entries) > 1 and (len(_entries) > _MAX_CACHED_FILES or
                sum(e.capture.snapshot.size_bytes for e in _entries.values()) > _MAX_CACHED_BYTES):
            _entries.popitem(last=False)
        return entry


def verify_mesh_entry(entry):
    from .package_v2_frozen import _regular_lstat, _stat_signature, FrozenSourceError
    if _stat_signature(_regular_lstat(entry.path, role="mesh")) != entry.signature:
        raise FrozenSourceError("frozen mesh artifact changed while the source was loaded")


def trim_parsed_meshes(keep):
    with _lock:
        def memory(entry):
            return ((entry.counts[2] if entry.parsed_mesh is not None and entry.counts else 0)
                    + (entry.geometry_memory if entry.geometry_data is not None else 0))

        total = sum(memory(e) for e in _entries.values())
        for entry in _entries.values():
            if total <= _MAX_CACHED_MESH_MEMORY:
                break
            if entry is not keep and memory(entry) and entry.lock.acquire(blocking=False):
                try:
                    total -= memory(entry)
                    entry.parsed_mesh = entry.parsed_limits = entry.counts = None
                    entry.geometry_data = None
                    entry.geometry_memory = 0
                finally:
                    entry.lock.release()
        if total > _MAX_CACHED_MESH_MEMORY and keep.lock.acquire(blocking=False):
            try:
                keep.parsed_mesh = keep.parsed_limits = keep.counts = None
                keep.geometry_data = None
                keep.geometry_memory = 0
            finally:
                keep.lock.release()


def clear_mesh_file_cache():
    """Release cache ownership; in-flight readers retain their own entry."""
    with _lock:
        _entries.clear()
