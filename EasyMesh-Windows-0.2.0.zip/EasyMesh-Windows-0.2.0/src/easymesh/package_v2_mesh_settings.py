"""Global, reproducible Package V2 mesh-policy settings.

These values describe interface geometry predicates shared by every endpoint
in one Package.  They are deliberately not Component-local sizing controls and
must never be used as a general node-merging or mesh-quality tolerance.
"""

from __future__ import annotations

import math
import re


DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_SOURCE = "0.01um"
DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM = 1.0e-5
_ABSOLUTE_LENGTH_LITERAL = re.compile(
    r"^(?P<number>[+-]?(?:(?:[0-9]+(?:\.[0-9]*)?)|(?:\.[0-9]+))"
    r"(?:[eE][+-]?[0-9]+)?)\s*"
    r"(?P<unit>mm|um|\N{MICRO SIGN}m|\N{GREEK SMALL LETTER MU}m)$"
)


def validate_interface_geometry_tolerance_mm(value: object) -> float:
    """Return one safe absolute interface tolerance in millimetres."""

    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(
            "interface_geometry_tolerance_mm must be a finite positive number"
        )
    tolerance = float(value)
    if not math.isfinite(tolerance) or tolerance <= 0.0:
        raise ValueError(
            "interface_geometry_tolerance_mm must be a finite positive number"
        )
    return tolerance


def parse_interface_geometry_tolerance_literal_mm(value: object) -> float:
    """Resolve one positive unit-bearing absolute literal to millimetres."""

    if not isinstance(value, str) or not value.strip():
        raise ValueError(
            "interface_geometry_tolerance must be one positive absolute "
            "length literal in mm or um"
        )
    matched = _ABSOLUTE_LENGTH_LITERAL.fullmatch(value.strip())
    if matched is None:
        raise ValueError(
            "interface_geometry_tolerance must be one positive absolute "
            "length literal in mm or um"
        )
    number = float(matched.group("number"))
    scale_mm = 1.0 if matched.group("unit") == "mm" else 1.0e-3
    return validate_interface_geometry_tolerance_mm(number * scale_mm)


__all__ = [
    "DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM",
    "DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_SOURCE",
    "parse_interface_geometry_tolerance_literal_mm",
    "validate_interface_geometry_tolerance_mm",
]
