"""Orthogonal instance transforms and orientation-preserving mesh placement."""
from __future__ import annotations

import math
from functools import lru_cache
from itertools import product


IDENTITY = ((1., 0., 0.), (0., 1., 0.), (0., 0., 1.))
MIRROR_X = ((-1., 0., 0.), (0., 1., 0.), (0., 0., 1.))


def multiply(a, b):
    return tuple(tuple(sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)) for i in range(3))


def matvec(matrix, vector):
    return tuple(sum(row[j] * vector[j] for j in range(3)) for row in matrix)


def determinant(matrix):
    a, b, c = matrix
    return a[0] * (b[1]*c[2] - b[2]*c[1]) - a[1] * (b[0]*c[2] - b[2]*c[0]) + a[2] * (b[0]*c[1] - b[1]*c[0])


def rotation_matrix(angles):
    result = IDENTITY
    for axis, angle in enumerate(angles):
        cosine, sine = math.cos(math.radians(angle)), math.sin(math.radians(angle))
        if abs(cosine) < 1e-14:
            cosine = 0.
        if abs(sine) < 1e-14:
            sine = 0.
        matrices = (((1., 0., 0.), (0., cosine, -sine), (0., sine, cosine)),
                    ((cosine, 0., sine), (0., 1., 0.), (-sine, 0., cosine)),
                    ((cosine, -sine, 0.), (sine, cosine, 0.), (0., 0., 1.)))
        result = multiply(matrices[axis], result)
    return result


def discrete_matrix(rotations, mirrors):
    if len(rotations) != 3 or any(type(value) is not int or value not in (0, 90, 180, 270) for value in rotations):
        raise ValueError("每轴旋转必须是 0、90、180 或 270 度。")
    if len(mirrors) != 3 or any(type(value) is not bool for value in mirrors):
        raise ValueError("镜像必须包含 X/Y/Z 三个开关。")
    reflection = tuple(tuple((-1. if mirrors[i] else 1.) if i == j else 0. for j in range(3)) for i in range(3))
    return multiply(rotation_matrix(rotations), reflection)


def euler_angles(matrix):
    """Recover Rx then Ry then Rz angles, including gimbal-lock cases."""
    y = math.asin(max(-1., min(1., -matrix[2][0])))
    if abs(math.cos(y)) > 1e-12:
        x, z = math.atan2(matrix[2][1], matrix[2][2]), math.atan2(matrix[1][0], matrix[0][0])
    else:
        x, z = 0., math.atan2(-matrix[0][1], matrix[1][1])
    return tuple(0. if abs(value) < 1e-12 else value for value in map(math.degrees, (x, y, z)))


def compose_placement(matrix, source_matrix, source_translation, translation, pivot):
    placed = matvec(matrix, tuple(source_translation[i] - pivot[i] for i in range(3)))
    return multiply(matrix, source_matrix), tuple(translation[i] + pivot[i] + placed[i] for i in range(3))


def placed_connectivity(gmsh_type, node_tags, matrix):
    """Reference-cell reflection compensates a mirrored coordinate frame.

    Original artifact connectivity remains unchanged. Only the placed copy is
    permuted, retaining exactly the same cell, nodes and Physical Groups.
    """
    if determinant(matrix) >= 0.:
        return node_tags
    permutations = {4: (1, 0, 2, 3), 5: (1, 0, 3, 2, 5, 4, 7, 6),
                    6: (1, 0, 2, 4, 3, 5), 7: (1, 0, 3, 2, 4)}
    return tuple(node_tags[index] for index in permutations[gmsh_type])


def placed_face_index(gmsh_type, source_face_index, matrix):
    """Map an original face index to the positive-orientation placed cell."""
    from .volume_mesh import ELEMENT_SPECS

    _, node_count, faces = ELEMENT_SPECS[gmsh_type]
    connectivity = placed_connectivity(gmsh_type, tuple(range(node_count)), matrix)
    source_face = set(faces[source_face_index])
    return next(index for index, face in enumerate(faces)
                if {connectivity[node] for node in face} == source_face)


@lru_cache(maxsize=1)
def _discrete_orientations():
    result = {}
    for rotations in product((0, 90, 180, 270), repeat=3):
        for mirrors in product((False, True), repeat=3):
            matrix = discrete_matrix(rotations, mirrors)
            cost = sum(bool(value) for value in rotations) + sum(mirrors)
            if matrix not in result or cost < result[matrix][0]:
                result[matrix] = (cost, rotations, mirrors)
    return result


def decompose_discrete_transform(matrix):
    """Return one equivalent set of controls, or None for an arbitrary pose."""
    rounded = tuple(tuple(round(value) for value in row) for row in matrix)
    if any(abs(matrix[i][j] - rounded[i][j]) > 1e-9 for i in range(3) for j in range(3)):
        return None
    record = _discrete_orientations().get(rounded)
    return record[1:] if record is not None else None


def frozen_placement_controls(placement):
    """Keep authored choices: several rotation/mirror combinations share a matrix."""
    if "rotation" not in placement and "mirrors" not in placement:
        return decompose_discrete_transform(placement["rotation_matrix"])
    if not isinstance(placement.get("rotation"), list) or not isinstance(placement.get("mirrors"), list):
        raise ValueError("网格实例的 rotation 和 mirrors 必须同时提供三个轴的设置。")
    rotations, mirrors = tuple(placement["rotation"]), tuple(placement["mirrors"])
    matrix = discrete_matrix(rotations, mirrors)
    if any(abs(matrix[i][j] - placement["rotation_matrix"][i][j]) > 1e-9
           for i in range(3) for j in range(3)):
        raise ValueError("网格实例的旋转 / 镜像设置与 rotation_matrix 不一致。")
    return rotations, mirrors


def describe_orientation(controls):
    if controls is None:
        return "自定义姿态（已保留）"
    rotations, mirrors = controls
    parts = [f"镜像 {axis}" for axis, enabled in zip("XYZ", mirrors) if enabled]
    parts += [f"{axis} {angle}°" for axis, angle in zip("XYZ", rotations) if angle]
    return "；".join(parts) or "无旋转 / 镜像"


def describe_transform(matrix):
    return describe_orientation(decompose_discrete_transform(matrix))
