"""Interactive XY view of the exact projected topology used by Layer meshing."""

import math
from PySide6.QtCore import QPointF, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen, QPolygonF

from .section_preview import SectionPreview
from .mesh_controls import ControlAxis
from .topology import TopologyPlan
from .preview_style import component_pen, mesh_pen


class PlanarMeshPreview(SectionPreview):
    """Share the section view's zoom/pan navigation, rendering real mesh edges."""

    r_interval_activated = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._topology: TopologyPlan | None = None
        self._radius_um = 0.
        self._face_paths = {}
        self._edge_path = QPainterPath()
        self._edge_count = 0
        self._boundary_path = QPainterPath()
        self._slice_plan = None
        self._slice_height_um = None
        self._slice_label = ""
        self._material_palette = {}
        self._visible_face_identities = {}
        self._visible_counts = {3: 0, 4: 0}
        self._slice_radius_um = 0.
        self._xy_projection = None
        self._hover_buckets = {}
        self._hover_bucket_size = 1.
        self._selected_r_key = None
        self._region_boundary_paths = {}
        self._message = "有效的 Layer 和网格参数设置后显示 XY 网格"
        self.setToolTip("单击网格定位对应 R 区间；显示选中高度的实际 XY 网格，材料颜色与左侧截面一致。深粗线为 component 边界，浅细线为内部网格。滚轮缩放、拖拽平移，双击适配窗口。")

    def sizeHint(self):
        return QSize(460, 470)

    def reset_view(self, *, update=True):
        self._xy_projection = None
        super().reset_view(update=update)

    def _mesh_hover_enabled(self):
        return self._topology is not None

    def _cell_metrics_at(self, position):
        if self._xy_projection is None or not self._view_boxes()[1].contains(position):
            return None
        cx, cy, scale = self._xy_projection
        point = QPointF((position.x() - cx) / scale, (cy - position.y()) / scale)
        key = (math.floor(point.x() / self._hover_bucket_size),
               math.floor(point.y() / self._hover_bucket_size))
        for polygon, bounds, thickness, region, chords, arcs in self._hover_buckets.get(key, ()):
            if bounds.contains(point) and polygon.containsPoint(point, Qt.FillRule.OddEvenFill):
                return thickness, region, chords, arcs
        return None

    def _radial_cell_at(self, position):
        hit = self._cell_metrics_at(position)
        return hit[:2] if hit is not None else None

    def cell_thickness_at(self, position):
        """Actual radial span of the visible polygon, including center triangles."""
        hit = self._radial_cell_at(position)
        return hit[0] if hit is not None else None

    def cell_tooltip_at(self, position):
        hit = self._cell_metrics_at(position)
        if hit is None:
            return None
        thickness, region, chords, arcs = hit
        radial = [i for i in self._control_intervals if i.axis is ControlAxis.RADIAL]
        identifier = radial[region].identifier if region < len(radial) else f"R{region + 1:02d}"
        def span(values):
            lower, upper = min(values), max(values)
            return f"{lower:.6g}" if math.isclose(lower, upper) else f"{lower:.6g}–{upper:.6g}"
        text = f"{identifier} · R 方向尺寸：{thickness:.6g} µm"
        if chords:
            text += f"\n环向边长：{span(chords)} µm"
        targets = self._topology.angular_target_sizes_um
        if targets and arcs:
            target = targets[region]
            deviations = tuple((value / target - 1) * 100 for value in arcs)
            text += f"\n环向弧长目标：{target:.6g} µm；实际：{span(arcs)} µm"
            text += f"\n弧长偏差：{min(deviations):+.1f}%～{max(deviations):+.1f}%"
        return text

    def _activate_interval_at(self, position):
        hit = self._radial_cell_at(position)
        radial = [i for i in self._control_intervals if i.axis is ControlAxis.RADIAL]
        if hit is None or hit[1] >= len(radial):
            return False
        self.r_interval_activated.emit(radial[hit[1]].key)
        return True

    def _selected_r_boundary(self):
        radial = [i for i in self._control_intervals if i.axis is ControlAxis.RADIAL]
        region = next((index for index, interval in enumerate(radial)
                       if interval.key == self._selected_r_key), None)
        return self._region_boundary_paths.get(region)

    def set_selected_r_interval(self, key, *, ensure_visible=False):
        self._selected_r_key = key
        boundary = self._selected_r_boundary()
        if ensure_visible and boundary is not None and self._xy_projection is not None:
            cx, cy, scale = self._xy_projection
            bounds = boundary.boundingRect()
            visible = QRectF(cx + bounds.left() * scale, cy - bounds.bottom() * scale,
                             bounds.width() * scale, bounds.height() * scale)
            if not self._view_boxes()[1].adjusted(-1, -1, 1, 1).contains(visible):
                self.reset_view(update=False)
        self.update()

    def _view_boxes(self):
        outer = QRectF(self.rect()).adjusted(10., 12., -10., -12.)
        _items, legend_height = self._legend_layout(max(1., outer.width() - 24.))
        return outer, outer.adjusted(26., 62., -26., -(64. + legend_height)), outer.width() < 400

    @property
    def legend_entries(self):
        return tuple((material, self._material_palette.get(self._material_key(material), QColor("#d6dbe1")))
                     for material in self._face_paths if material)

    def _legend_layout(self, width):
        """Wrap the current slice's material swatches inside the view width."""
        entries = []
        x = y = 0.
        for material, color in self.legend_entries:
            label = self.fontMetrics().elidedText(material, Qt.TextElideMode.ElideRight, max(1, int(width - 24)))
            item_width = min(width, 24. + self.fontMetrics().horizontalAdvance(label))
            if x and x + item_width > width:
                x, y = 0., y + 22.
            entries.append((label, color, QRectF(x, y, item_width, 20.)))
            x += item_width + 12.
        return entries, y + 22. if entries else 0.

    @property
    def topology(self):
        return self._topology

    @property
    def edge_count(self):
        return self._edge_count

    def set_topology(self, topology: TopologyPlan | None, message=""):
        message = message or "有效的 Layer 和网格参数设置后显示 XY 网格"
        if topology is self._topology and message == self._message:
            return
        radius = topology.rings[-1].radius_um if topology is not None else 0.
        if radius != self._radius_um:
            self.reset_view(update=False)
        self._radius_um = radius
        self._topology = topology
        self._plan = topology  # Enables the shared pointer-centered navigation.
        self._message = message
        self._slice_plan = None
        self._slice_height_um = None
        self._slice_label = ""
        self._rebuild_paths()

    @property
    def slice_height_um(self):
        return self._slice_height_um

    @property
    def visible_face_identities(self):
        return dict(self._visible_face_identities)

    def set_height_slice(self, section_plan, height_um, label, material_palette):
        if (section_plan is self._slice_plan and height_um == self._slice_height_um
                and label == self._slice_label and material_palette == self._material_palette):
            return
        if height_um != self._slice_height_um:
            self.reset_view(update=False)
        self._slice_plan = section_plan
        self._slice_height_um = height_um
        self._slice_label = label
        self._material_palette = dict(material_palette)
        self._rebuild_paths()

    def _rebuild_paths(self):
        self._hide_mesh_tooltip()
        self._xy_projection = None
        self._hover_buckets = {}
        self._region_boundary_paths = {}
        self._region_size_ranges = {}
        self._face_paths = {}
        self._edge_path = QPainterPath()
        self._boundary_path = QPainterPath()
        self._visible_face_identities = {}
        self._visible_counts = {3: 0, 4: 0}
        self._slice_radius_um = 0.
        topology = self._topology
        edges = {}
        if topology is not None:
            points = tuple(QPointF(x * 1000, y * 1000) for x, y in topology.coordinates_mm)
            # Use exact ring radii, not chord lengths or the configured seed.
            node_radii = {node: ring.radius_um for ring in topology.rings for node in ring.node_ids}
            self._hover_bucket_size = 2 * self._radius_um / max(1., math.sqrt(len(topology.faces)))
            identities = {}
            if self._slice_plan is not None:
                # Face.region uses the same inner-to-outer material columns as
                # the volume mesher. Do not infer identity from polygon centers.
                for region, column in enumerate(self._slice_plan.columns):
                    identities[region] = next(
                        ((span.component, span.material) for span in column.spans
                         if span.z_bottom_um <= self._slice_height_um < span.z_top_um), None)
            for index, face in enumerate(topology.faces):
                identity = identities.get(face.region) if self._slice_plan is not None else ("", "")
                if identity is None:
                    continue
                self._visible_face_identities[index] = identity
                polygon = QPolygonF([points[node] for node in face.node_ids])
                bounds = polygon.boundingRect()
                radii = [node_radii.get(node, 0.) for node in face.node_ids]
                chords, arcs = [], []
                for a, b in zip(face.node_ids, face.node_ids[1:] + face.node_ids[:1]):
                    radius = node_radii.get(a, 0.)
                    if radius and radius == node_radii.get(b, 0.):
                        chord = math.hypot(points[a].x() - points[b].x(), points[a].y() - points[b].y())
                        chords.append(chord)
                        arcs.append(2 * radius * math.asin(min(1., chord / (2 * radius))))
                thickness = max(radii) - min(radii)
                cell = (polygon, bounds, thickness, face.region, tuple(chords), tuple(arcs))
                ranges = self._region_size_ranges.setdefault(face.region, [thickness, thickness, float("inf"), 0.])
                ranges[0], ranges[1] = min(ranges[0], thickness), max(ranges[1], thickness)
                if arcs:
                    ranges[2], ranges[3] = min(ranges[2], *arcs), max(ranges[3], *arcs)
                # A small spatial index avoids scanning every face on mouse move.
                step = self._hover_bucket_size
                for bx in range(math.floor(bounds.left() / step), math.floor(bounds.right() / step) + 1):
                    for by in range(math.floor(bounds.top() / step), math.floor(bounds.bottom() / step) + 1):
                        self._hover_buckets.setdefault((bx, by), []).append(cell)
                self._slice_radius_um = max(self._slice_radius_um, *(math.hypot(points[node].x(), points[node].y()) for node in face.node_ids))
                self._visible_counts[len(face.node_ids)] += 1
                path = self._face_paths.setdefault(identity[1], QPainterPath())
                path.moveTo(points[face.node_ids[0]])
                for node in face.node_ids[1:]:
                    path.lineTo(points[node])
                path.closeSubpath()
                for a, b in zip(face.node_ids, face.node_ids[1:] + face.node_ids[:1]):
                    edges.setdefault((min(a, b), max(a, b)), []).append((identity, face.region))
            for (a, b), owners in sorted(edges.items()):
                self._edge_path.moveTo(points[a])
                self._edge_path.lineTo(points[b])
                if len(owners) == 1 or len({owner[0] for owner in owners}) > 1:
                    self._boundary_path.moveTo(points[a])
                    self._boundary_path.lineTo(points[b])
                regions = {owner[1] for owner in owners}
                if len(owners) == 1 or len(regions) > 1:
                    for region in regions:
                        path = self._region_boundary_paths.setdefault(region, QPainterPath())
                        path.moveTo(points[a])
                        path.lineTo(points[b])
        self._edge_count = len(edges)
        self.update()

    def paintEvent(self, event):  # noqa: N802
        del event
        self._xy_projection = None
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), self.palette().color(self.backgroundRole()))
        outer, plot, _compact = self._view_boxes()
        foreground = self.palette().color(self.foregroundRole())
        border = QColor(foreground)
        border.setAlpha(55)
        painter.setPen(QPen(border, 1))
        painter.drawRoundedRect(outer, 8, 8)
        painter.setPen(foreground)
        font = painter.font()
        font.setBold(True)
        painter.setFont(font)
        painter.drawText(outer.adjusted(8, 7, -8, 0), Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop, "XY 平面网格")
        font.setBold(False)
        painter.setFont(font)
        if self._topology is None:
            self._last_visible_geometry_box = QRectF()
            painter.drawText(plot, Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, self._message)
            return
        topology = self._topology
        painter.drawText(QRectF(outer.left(), outer.top() + 32, outer.width(), 22), Qt.AlignmentFlag.AlignCenter,
                         (f"{self._slice_label} · z={self._slice_height_um:g} µm"
                          if self._slice_height_um is not None else "XY 投影网格"))
        if plot.width() <= 0 or plot.height() <= 0:
            return
        scale = min(plot.width(), plot.height()) / (2 * self._radius_um) * self._zoom_factor
        center = plot.center() + self._bounded_pan(plot, self._zoom_factor, self._pan_offset_px.x(), self._pan_offset_px.y())
        self._xy_projection = (center.x(), center.y(), scale)
        radius_px = self._radius_um * scale
        self._last_visible_geometry_box = QRectF(center.x() - radius_px, center.y() - radius_px,
                                                 2 * radius_px, 2 * radius_px).intersected(plot)
        painter.save()
        painter.setClipRect(plot)
        painter.translate(center)
        painter.scale(scale, -scale)
        for material, path in self._face_paths.items():
            color = self._material_palette.get(self._material_key(material), QColor("#d6dbe1"))
            painter.fillPath(path, color)
        painter.setPen(mesh_pen())
        painter.drawPath(self._edge_path)
        painter.setPen(component_pen())
        painter.drawPath(self._boundary_path)
        selected_boundary = self._selected_r_boundary()
        if selected_boundary is not None:
            pen = QPen(QColor("#2563eb"), 2.5, Qt.PenStyle.DashLine)
            pen.setCosmetic(True)
            painter.setPen(pen)
            painter.drawPath(selected_boundary)
        painter.restore()
        painter.setPen(foreground)
        painter.drawText(QRectF(plot.center().x() - 15, plot.top() + 1, 30, 20), Qt.AlignmentFlag.AlignCenter, "+Y")
        painter.drawText(QRectF(plot.right(), plot.center().y() - 10, 25, 20), Qt.AlignmentFlag.AlignCenter, "+X")
        legend, legend_height = self._legend_layout(max(1., outer.width() - 24.))
        footer = QRectF(outer.left() + 8, outer.bottom() - 54 - legend_height, outer.width() - 16, 48)
        painter.drawText(footer, Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap,
                         f"d={2 * self._slice_radius_um:g} µm · {self._zoom_factor:g}×\n"
                         f"四边形 {self._visible_counts[4]:,} · 三角形 {self._visible_counts[3]:,}\n"
                         + ("此高度无实体" if not self._visible_face_identities else "材料图例"))
        for label, color, box in legend:
            box = box.translated(outer.left() + 12., outer.bottom() - legend_height - 4.)
            painter.fillRect(QRectF(box.left(), box.top() + 4., 12., 12.), color)
            painter.drawText(box.adjusted(18., 0., 0., 0.), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, label)
