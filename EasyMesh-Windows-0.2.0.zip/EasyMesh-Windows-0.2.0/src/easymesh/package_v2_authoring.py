"""Materialize an immutable Package V2 Job from one portable Source file.

This is the only mutable authoring step used by the GUI and demo script.  It
compiles the exact Source, freshly audits every declared Frozen bundle, binds
the installed Worker/Gmsh runtime and an absolute mesh output, then publishes
the resulting Job atomically.  Execution still consumes only the immutable Job.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import stat

from .output_artifacts import atomic_output_path, paths_refer_to_same_file
from .package_v2_compile import compile_package_v2
from .package_v2_frozen import load_compiled_frozen_source
from .package_v2_job import (
    PackageV2JobRequest,
    PackageV2RuntimeProfile,
    build_package_v2_job_request,
    parse_package_v2_job_request,
)
from .package_v2_source import MAX_SOURCE_BYTES


def _read_bounded_regular_source(path: Path) -> bytes:
    flags = os.O_RDONLY
    for name in ("O_BINARY", "O_CLOEXEC", "O_NONBLOCK"):
        flags |= getattr(os, name, 0)
    descriptor = os.open(path, flags)
    try:
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            raise ValueError("Package V2 Source must be a regular file")
        with os.fdopen(descriptor, "rb", closefd=True) as stream:
            descriptor = -1
            value = stream.read(MAX_SOURCE_BYTES + 1)
    finally:
        if descriptor >= 0:
            os.close(descriptor)
    if len(value) > MAX_SOURCE_BYTES:
        raise ValueError(
            f"Package V2 Source exceeds the {MAX_SOURCE_BYTES}-byte limit"
        )
    return value


def _canonical_job_bytes(request: PackageV2JobRequest) -> bytes:
    return (
        json.dumps(
            request.to_jsonable(),
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        + "\n"
    ).encode("utf-8")


def materialize_package_v2_job(
    source_path: str | os.PathLike[str],
    job_path: str | os.PathLike[str],
    output_mesh_path: str | os.PathLike[str],
    *,
    job_id: str,
    runtime_profile: PackageV2RuntimeProfile | None = None,
) -> PackageV2JobRequest:
    """Build and atomically publish one locally bound immutable Job."""

    source = Path(source_path).expanduser().resolve()
    job = Path(job_path).expanduser().resolve()
    output = Path(output_mesh_path).expanduser().resolve()
    if job.suffix != ".json":
        raise ValueError("Package V2 Job path must end in .json")
    if paths_refer_to_same_file(source, job):
        raise ValueError("Package V2 Job must not overwrite its Source")
    if paths_refer_to_same_file(source, output):
        raise ValueError("Package V2 mesh output must not overwrite its Source")
    if paths_refer_to_same_file(job, output):
        raise ValueError("Package V2 Job and mesh output paths must differ")

    source_bytes = _read_bounded_regular_source(source)
    compiled = compile_package_v2(
        source_bytes,
        source_name=source.name,
        source_root=source.parent,
    )
    snapshots = tuple(
        load_compiled_frozen_source(value) for value in compiled.frozen_sources
    )
    if runtime_profile is None:
        from .package_v2_worker import current_package_v2_runtime_profile

        runtime_profile = current_package_v2_runtime_profile()
    request = build_package_v2_job_request(
        compiled,
        snapshots,
        job_id=job_id,
        output_mesh_path=output,
        source_root=source.parent,
        runtime_profile=runtime_profile,
    )
    for dependency in request.runtime_dependencies:
        if paths_refer_to_same_file(job, dependency.runtime_path):
            raise ValueError("Package V2 Job must not overwrite a Frozen artifact")

    encoded = _canonical_job_bytes(request)
    job.parent.mkdir(parents=True, exist_ok=True)
    with atomic_output_path(job) as temporary:
        with temporary.open("wb") as stream:
            os.chmod(temporary, 0o600)
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
    replayed = parse_package_v2_job_request(job.read_bytes())
    if replayed != request:
        raise RuntimeError("published Package V2 Job failed exact replay")
    return request


__all__ = ["materialize_package_v2_job"]
