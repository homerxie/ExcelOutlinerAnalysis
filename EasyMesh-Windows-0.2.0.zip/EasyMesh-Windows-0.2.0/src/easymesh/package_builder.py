"""Assemble a package mesh around one immutable connected-bump MSH asset.

The package builder sits deliberately between layout generation and CDB
conversion.  It keeps the connected bump connectivity unchanged, applies the
requested rigid placement, and builds the surrounding package volumes against
explicit interface nodes.  The first implementation targets the component
vocabulary used by :mod:`examples/package.pack`: ``cube``, ``cube_ring`` and
``UF_fillet``.

The protected die-corner mesh is not inferred from a bounding box.  It is read
from the connected layout's ``structured_regions`` sidecar and validated as a
complete Cartesian HEX8 lattice before any package cell is created.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from collections.abc import Iterable, Mapping, Sequence
from array import array
from dataclasses import asdict, dataclass, field, fields
import hashlib
import json
import math
from pathlib import Path
from typing import Any

from .component_interface import (
    ComponentMeshRequirement,
    NegotiatedComponentInterface,
)
from .generated_interface_continuity import (
    GeneratedInterfaceContinuityError,
    GeneratedSurfaceEquivalenceGroup,
    plan_generated_interface_continuity,
)
from .generated_surface_execution import (
    GeneratedSurfaceExecutionError,
    GeneratedSurfaceExecutionPlan,
    plan_generated_interface_surface_execution,
)
from .occ_locked_hybrid import (
    ConstrainedHybridError,
    generate_locked_box_hybrid,
)
from .occ_rectangular_frame_conformal import (
    RectangularFrameGeometry,
    generate_rectangular_frame_conformal_hybrid,
)
from .occ_uf_conformal import (
    GmshUfConformalVolume,
    generate_rectangular_uf_conformal_hybrid,
)
from .gmsh_runtime import isolated_gmsh_model
from .hybrid_bulk import StarElementKind
from .hybrid_prism import (
    HybridPrismError,
    LockedPrismFace,
    PlanarCell,
    fill_extruded_planar_prism,
)
from .output_artifacts import (
    atomic_output_path,
    atomic_write_text,
    exclusive_artifact_lock,
    file_artifact,
    normalized_mesh_output,
    paths_refer_to_same_file,
)
from .package_spec import (
    BooleanOperation,
    EvaluatedComponent,
    EvaluatedRotationSweep,
    EvaluatedSweepFeature,
    EvaluatedTranslationSweep,
    GeneratedPart,
    MeshPlacement,
    PackageBundle,
    PackageTransform,
    load_package_bundle,
)
from .planar_transition import TransitionRing, generate_planar_transition_mesh
from .uf_skin import CartesianCell, RectangularUfEnvelope, UfCellClass
from .volume_mesh import (
    ELEMENT_SPECS,
    ElementKind,
    MeshNode,
    VolumeMesh,
    load_volume_mesh,
)


_COORDINATE_TOLERANCE_MM = 1.0e-10
_COORDINATE_DIGITS = 12
_MATERIAL_PREFIX = "MATERIAL_"
_PART_PREFIX = "PART_"
_ALL_SOLIDS = "ALL_SOLID_VOLUMES"
_TEMPLATE_SOLIDS = "TEMPLATE_SOLID_VOLUMES"
_TRANSITION_SOLIDS = "TRANSITION_SOLID_VOLUMES"
_TEMPLATE_ORIGIN = "TEMPLATE"
_TRANSITION_ORIGIN = "TRANSITION"
_ELEMENT_GENERATION_PROVENANCE = {
    "frozen_source",
    "selected_volume_backend",
}
_REBUILT_SOURCE_PHYSICAL_NAMES = {
    _ALL_SOLIDS,
    _TEMPLATE_SOLIDS,
    _TRANSITION_SOLIDS,
}
_SUPPORTED_COMPONENTS = {"cube", "cube_ring", "UF_fillet"}
PACKAGE_BULK_MESH_MODES = ("sweep", "hybrid")
COMPONENT_VOLUME_TOPOLOGIES = (
    "structured_sweep",
    "orthogonal_hex",
    "conformal_hybrid",
)
PACKAGE_COMPONENT_MESH_ROLES = (
    "substrate",
    "added_si",
    "ring_lower",
    "ring_upper",
    "underfill_corner_core",
    "underfill_fillet",
)
PACKAGE_INTERFACE_MATCH_ROLES = (
    "substrate",
    "added_si",
    "ring_lower",
    "ring_upper",
    "underfill_corner_core",
)
PACKAGE_INTERFACE_MATCH_MODES = (
    "preserve_interface_trace",
)
UNDERFILL_CORE_MESH_MODES = (
    "target_mesh_control",
)
UNDERFILL_CORE_VOLUME_TOPOLOGIES = (
    *COMPONENT_VOLUME_TOPOLOGIES,
)
_HYBRID_DEMO_MIN_QUALITY = 0.03
_MAXIMUM_UF_TRACE_SWEEP_ELEMENT_COUNT = 500_000
_MAXIMUM_UF_TRACE_SWEEP_POTENTIAL_COUNT = 2_000_000
_CANONICAL_COMPONENT_PARAMETERS = {
    "cube": ("w", "l", "h"),
    "cube_ring": ("w_o", "l_o", "w_i", "l_i", "h"),
    "UF_fillet": ("w", "l", "h_uf", "w_uf"),
}
_CANONICAL_COMPONENT_PROBES = {
    "cube": (0.73, 0.91, 0.17),
    "cube_ring": (1.13, 1.37, 0.61, 0.47, 0.08),
    "UF_fillet": (0.53, 0.67, 0.11, 0.19),
}


class PackageBuildError(ValueError):
    """Raised when a package cannot be assembled without an ambiguous mesh."""


@dataclass(frozen=True, slots=True)
class _ComponentMeshPolicy:
    """One normalized Component-owned backend selection.

    Volume topology is deliberately independent from the immutable interface
    trace: the selected strategy always owns every generated volume element.
    """

    volume_topology: str
    target_edge_mm: float
    transition_distance_mm: float

    def to_dict(self) -> dict[str, object]:
        return {
            "volume_topology": self.volume_topology,
            "target_edge_mm": self.target_edge_mm,
            "transition_distance_mm": self.transition_distance_mm,
        }


@dataclass(frozen=True, slots=True)
class _InterfaceMatchPolicy:
    """One immutable interface-trace policy, separate from volume meshing."""

    mode: str

    def to_dict(self) -> dict[str, object]:
        return {"mode": self.mode}


@dataclass(frozen=True, slots=True)
class PackageInterfaceAudit:
    """Canonical, immutable exact-face counts produced by interface auditing.

    The names are the stable audit identities already serialized under
    ``exact_interface_face_counts``.  Keeping the canonical representation as
    a tuple prevents a caller from mutating evidence after a plan has passed
    its topology audit, while :meth:`to_dict` provides a fresh JSON-ready copy
    for workers and reports.
    """

    face_counts: tuple[tuple[str, int], ...]

    def __post_init__(self) -> None:
        if type(self.face_counts) not in (tuple, list):
            raise PackageBuildError(
                "interface audit face counts must be a tuple or list"
            )
        normalized: list[tuple[str, int]] = []
        seen: set[str] = set()
        for item in self.face_counts:
            if type(item) not in (tuple, list) or len(item) != 2:
                raise PackageBuildError(
                    "interface audit entries must be (name, face_count) pairs"
                )
            name, count = item
            if not isinstance(name, str) or not name.strip():
                raise PackageBuildError(
                    "interface audit names must be non-empty strings"
                )
            canonical_name = name.strip()
            if canonical_name in seen:
                raise PackageBuildError(
                    f"duplicate interface audit name: {canonical_name!r}"
                )
            if isinstance(count, bool) or not isinstance(count, int) or count < 0:
                raise PackageBuildError(
                    "interface audit face counts must be non-negative integers"
                )
            seen.add(canonical_name)
            normalized.append((canonical_name, count))
        object.__setattr__(
            self,
            "face_counts",
            tuple(sorted(normalized, key=lambda item: item[0])),
        )

    @classmethod
    def from_mapping(cls, value: Mapping[str, int]) -> "PackageInterfaceAudit":
        if not isinstance(value, Mapping):
            raise PackageBuildError("interface audit evidence must be a mapping")
        return cls(tuple(value.items()))

    def to_dict(self) -> dict[str, int]:
        """Return a fresh, deterministically ordered JSON-ready mapping."""

        return dict(self.face_counts)


def normalize_package_bulk_mesh_mode(value: object) -> str:
    """Return the stable package bulk-mode token used in replay metadata."""

    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in PACKAGE_BULK_MESH_MODES:
            return normalized
    supported = ", ".join(PACKAGE_BULK_MESH_MODES)
    raise PackageBuildError(f"package bulk mesh mode must be one of: {supported}")


def normalize_underfill_core_mesh_mode(value: object) -> str:
    """Return the stable lower-UF ownership policy token."""

    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in UNDERFILL_CORE_MESH_MODES:
            return normalized
    supported = ", ".join(UNDERFILL_CORE_MESH_MODES)
    raise PackageBuildError(
        f"underfill core mesh mode must be one of: {supported}"
    )


def normalize_underfill_core_volume_topology(value: object) -> str:
    """Return the explicit generated lower-UF volume-topology policy."""

    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in UNDERFILL_CORE_VOLUME_TOPOLOGIES:
            return normalized
    supported = ", ".join(UNDERFILL_CORE_VOLUME_TOPOLOGIES)
    raise PackageBuildError(
        f"underfill core volume topology must be one of: {supported}"
    )


def _normalize_ring_volume_topologies(
    values: object,
) -> tuple[str, str]:
    """Return the two explicit ring topology selections in stack order."""

    if isinstance(values, (str, bytes, bytearray)):
        raw_values: tuple[object, ...] = ()
    else:
        try:
            raw_values = tuple(values)  # type: ignore[arg-type]
        except TypeError:
            raw_values = ()
    if len(raw_values) != 2:
        raise PackageBuildError(
            "ring_volume_topologies must contain exactly two values"
        )
    supported = set(COMPONENT_VOLUME_TOPOLOGIES)
    normalized: list[str] = []
    for index, value in enumerate(raw_values, start=1):
        if not isinstance(value, str) or value.strip().lower() not in supported:
            raise PackageBuildError(
                f"ring {index} volume topology must be one of: "
                + ", ".join(COMPONENT_VOLUME_TOPOLOGIES)
            )
        normalized.append(value.strip().lower())
    return normalized[0], normalized[1]


def _resolve_underfill_core_volume_topology(
    mode: str,
    requested: object,
) -> tuple[str, str, bool]:
    """Resolve the explicitly selected lower-UF strategy."""

    normalize_underfill_core_mesh_mode(mode)
    if requested is None:
        raise PackageBuildError(
            "target_mesh_control requires an explicit "
            "underfill_core_volume_topology"
        )
    normalized = normalize_underfill_core_volume_topology(requested)
    return normalized, normalized, False


def _positive_policy_length(value: object, *, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise PackageBuildError(f"{field_name} must be a positive finite number")
    result = float(value)
    if not math.isfinite(result) or result <= 0.0:
        raise PackageBuildError(f"{field_name} must be a positive finite number")
    return result


def _normalize_component_mesh_policies(
    value: object,
) -> dict[str, _ComponentMeshPolicy]:
    """Require the complete six-Component meshing contract.

    There is intentionally no role-derived default and no legacy topology
    alias.  A Package V2 job is replayable only when every generated body owns
    one of the three public backends explicitly.
    """

    if not isinstance(value, Mapping):
        raise PackageBuildError("component_mesh_policies must be a mapping")
    if set(value) != set(PACKAGE_COMPONENT_MESH_ROLES):
        missing = sorted(set(PACKAGE_COMPONENT_MESH_ROLES) - set(value))
        extra = sorted(set(value) - set(PACKAGE_COMPONENT_MESH_ROLES))
        raise PackageBuildError(
            "component_mesh_policies must contain exactly the six generated "
            f"roles; missing={missing}, extra={extra}"
        )
    result: dict[str, _ComponentMeshPolicy] = {}
    for role in PACKAGE_COMPONENT_MESH_ROLES:
        raw = value[role]
        if not isinstance(raw, Mapping) or set(raw) != {
            "volume_topology",
            "target_edge_mm",
            "transition_distance_mm",
        }:
            raise PackageBuildError(
                f"component_mesh_policies[{role!r}] must contain exactly "
                "volume_topology, target_edge_mm and transition_distance_mm"
            )
        topology = raw["volume_topology"]
        if not isinstance(topology, str):
            raise PackageBuildError(
                f"component_mesh_policies[{role!r}].volume_topology must be a string"
            )
        normalized_topology = topology.strip().lower()
        if normalized_topology not in COMPONENT_VOLUME_TOPOLOGIES:
            raise PackageBuildError(
                f"component_mesh_policies[{role!r}].volume_topology must be one "
                f"of: {', '.join(COMPONENT_VOLUME_TOPOLOGIES)}"
            )
        result[role] = _ComponentMeshPolicy(
            normalized_topology,
            _positive_policy_length(
                raw["target_edge_mm"],
                field_name=f"component_mesh_policies[{role!r}].target_edge_mm",
            ),
            _positive_policy_length(
                raw["transition_distance_mm"],
                field_name=(
                    f"component_mesh_policies[{role!r}]"
                    ".transition_distance_mm"
                ),
            ),
        )
    return result


def _normalize_interface_match_policies(
    value: object,
) -> dict[str, _InterfaceMatchPolicy]:
    """Require five independent interface contracts without topology coupling."""

    if not isinstance(value, Mapping):
        raise PackageBuildError("interface_match_policies must be a mapping")
    if set(value) != set(PACKAGE_INTERFACE_MATCH_ROLES):
        missing = sorted(set(PACKAGE_INTERFACE_MATCH_ROLES) - set(value))
        extra = sorted(set(value) - set(PACKAGE_INTERFACE_MATCH_ROLES))
        raise PackageBuildError(
            "interface_match_policies must contain exactly the five matched "
            f"roles; missing={missing}, extra={extra}"
        )
    result: dict[str, _InterfaceMatchPolicy] = {}
    for role in PACKAGE_INTERFACE_MATCH_ROLES:
        raw = value[role]
        if not isinstance(raw, Mapping) or set(raw) != {"mode"}:
            raise PackageBuildError(
                f"interface_match_policies[{role!r}] must contain exactly mode"
            )
        mode_value = raw["mode"]
        if not isinstance(mode_value, str):
            raise PackageBuildError(
                f"interface_match_policies[{role!r}].mode must be a string"
            )
        mode = mode_value.strip().lower()
        if mode not in PACKAGE_INTERFACE_MATCH_MODES:
            raise PackageBuildError(
                f"interface_match_policies[{role!r}].mode must be one of: "
                f"{', '.join(PACKAGE_INTERFACE_MATCH_MODES)}"
            )
        result[role] = _InterfaceMatchPolicy(mode)
    return result


def _normalize_generated_interface_policies(
    value: object,
    *,
    component_role_bindings: object,
    component_policies: Mapping[str, _ComponentMeshPolicy],
) -> tuple[
    tuple[NegotiatedComponentInterface, ...],
    dict[str, str],
]:
    """Validate the geometry-derived common-surface decisions.

    ``component_role_bindings`` is only an adapter from canonical Component
    IDs to this narrow package executor's slots.  It cannot select or alter a
    surface policy.  Every policy is rechecked from the two Component-owned
    topology/size requests before any volume backend runs.
    """

    if not isinstance(component_role_bindings, Mapping):
        raise PackageBuildError(
            "generated_component_role_bindings must be a mapping"
        )
    bindings: dict[str, str] = {}
    for component_id, role in component_role_bindings.items():
        if (
            not isinstance(component_id, str)
            or not component_id.strip()
            or not isinstance(role, str)
            or role not in PACKAGE_COMPONENT_MESH_ROLES
        ):
            raise PackageBuildError(
                "generated_component_role_bindings contains an invalid entry"
            )
        bindings[component_id.strip()] = role
    if (
        set(bindings.values()) != set(PACKAGE_COMPONENT_MESH_ROLES)
        or len(bindings) != len(PACKAGE_COMPONENT_MESH_ROLES)
    ):
        raise PackageBuildError(
            "generated_component_role_bindings must map six unique canonical "
            "Component IDs onto the six executor slots"
        )
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise PackageBuildError(
            "generated_interface_policies must be a sequence"
        )
    policies = tuple(value)
    if any(type(item) is not NegotiatedComponentInterface for item in policies):
        raise PackageBuildError(
            "generated_interface_policies must contain negotiated interfaces"
        )
    if tuple(sorted(policies, key=lambda item: item.interface_id)) != policies:
        raise PackageBuildError(
            "generated_interface_policies must be stably ordered by interface_id"
        )
    if len({item.interface_id for item in policies}) != len(policies) or len(
        {frozenset(item.component_ids) for item in policies}
    ) != len(policies):
        raise PackageBuildError(
            "generated_interface_policies contains duplicate interfaces"
        )

    volume_kinds = {
        "structured_sweep": ("HEX8", "WEDGE6"),
        "orthogonal_hex": ("HEX8",),
        "conformal_hybrid": ("TET4", "PYRAMID5", "WEDGE6"),
    }
    for interface in policies:
        if any(component_id not in bindings for component_id in interface.component_ids):
            raise PackageBuildError(
                f"generated interface {interface.interface_id!r} names an unknown "
                "canonical Component"
            )
        first_id, second_id = interface.component_ids
        first = component_policies[bindings[first_id]]
        second = component_policies[bindings[second_id]]
        ordered = ((first_id, first), (second_id, second))
        orthogonal = tuple(
            component_id
            for component_id, policy in ordered
            if policy.volume_topology == "orthogonal_hex"
        )
        sweep = tuple(
            component_id
            for component_id, policy in ordered
            if policy.volume_topology == "structured_sweep"
        )
        if orthogonal:
            expected_policy = "shared_cartesian_quad"
            expected_surface_kinds = ("QUAD4",)
        elif sweep:
            expected_policy = "shared_inherited_sweep_surface"
            expected_surface_kinds = ("TRI3", "QUAD4")
        else:
            expected_policy = "shared_gmsh_conformal_surface"
            expected_surface_kinds = ("TRI3", "QUAD4")
        expected_target = min(first.target_edge_mm, second.target_edge_mm)
        expected_transitions = {
            first_id: first.transition_distance_mm,
            second_id: second.transition_distance_mm,
        }
        actual_transitions = {
            first_id: interface.first_transition_distance_mm,
            second_id: interface.second_transition_distance_mm,
        }
        if (
            interface.surface_policy != expected_policy
            or interface.permitted_surface_element_kinds
            != expected_surface_kinds
            or not _close(interface.interface_target_edge_mm, expected_target)
            or any(
                not _close(actual_transitions[key], expected_transitions[key])
                for key in expected_transitions
            )
            or interface.first_permitted_volume_element_kinds
            != volume_kinds[first.volume_topology]
            or interface.second_permitted_volume_element_kinds
            != volume_kinds[second.volume_topology]
            or not interface.shared_nodes_required
            or not interface.independent_boundary_deletion_forbidden
        ):
            raise PackageBuildError(
                f"generated interface {interface.interface_id!r} does not match "
                "its adjacent Component topology/size policies"
            )
    return policies, bindings


def _normalize_generated_interface_continuity_groups(
    value: object,
    *,
    interfaces: Sequence[NegotiatedComponentInterface],
    component_role_bindings: Mapping[str, str],
    component_policies: Mapping[str, _ComponentMeshPolicy],
    sweep_direction_xyz_by_component: Mapping[
        str, tuple[float, float, float]
    ] | None = None,
) -> tuple[GeneratedSurfaceEquivalenceGroup, ...]:
    """Audit, without replacing, the geometry-derived continuity decision.

    The lowering layer owns this decision.  The package builder only verifies
    that the supplied groups are the deterministic result of the negotiated
    real faces and the adjacent Component requirements, then consumes the
    exact supplied objects.  Component roles and material names are not inputs
    to the continuity planner.
    """

    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise PackageBuildError(
            "generated_interface_continuity_groups must be a sequence"
        )
    groups = tuple(value)
    if any(type(item) is not GeneratedSurfaceEquivalenceGroup for item in groups):
        raise PackageBuildError(
            "generated_interface_continuity_groups must contain generated "
            "surface equivalence groups"
        )
    requirements = {
        component_id: ComponentMeshRequirement(
            component_id=component_id,
            volume_topology=component_policies[role].volume_topology,
            target_edge_mm=component_policies[role].target_edge_mm,
            transition_distance_mm=(
                component_policies[role].transition_distance_mm
            ),
        )
        for component_id, role in component_role_bindings.items()
    }
    try:
        expected = plan_generated_interface_continuity(
            tuple(interfaces),
            requirements,
            sweep_direction_xyz_by_component=(
                sweep_direction_xyz_by_component
            ),
        ).groups
    except GeneratedInterfaceContinuityError as error:
        raise PackageBuildError(
            "generated-interface continuity lacks an executable explicit "
            f"Sweep direction: {error}"
        ) from error
    if groups != expected:
        raise PackageBuildError(
            "generated-interface continuity groups are stale or were rewritten; "
            "they must derive only from real adjacency, topology, size and "
            "geometric transport evidence"
        )
    return groups


def _normalize_generated_surface_execution_plan(
    value: object,
    *,
    interfaces: Sequence[NegotiatedComponentInterface],
    continuity_groups: Sequence[GeneratedSurfaceEquivalenceGroup],
    component_role_bindings: Mapping[str, str],
    component_policies: Mapping[str, _ComponentMeshPolicy],
) -> GeneratedSurfaceExecutionPlan:
    """Validate and preserve the lowering-owned neutral surface DAG.

    This adapter never selects a producer from a package role.  It rebuilds
    only the generic Component requirements needed by the role-free planner,
    verifies the immutable plan and returns the exact supplied object.
    """

    if type(value) is not GeneratedSurfaceExecutionPlan:
        raise PackageBuildError(
            "generated_surface_execution_plan must be a neutral surface plan"
        )
    requirements = {
        component_id: ComponentMeshRequirement(
            component_id=component_id,
            volume_topology=component_policies[role].volume_topology,
            target_edge_mm=component_policies[role].target_edge_mm,
            transition_distance_mm=(
                component_policies[role].transition_distance_mm
            ),
        )
        for component_id, role in component_role_bindings.items()
    }
    try:
        expected = plan_generated_interface_surface_execution(
            tuple(interfaces),
            tuple(continuity_groups),
            value.transport_links,
            requirements,
            sweep_direction_xyz_by_component=(
                value.sweep_direction_xyz_by_component
            ),
        )
    except GeneratedSurfaceExecutionError as error:
        raise PackageBuildError(
            "generated surface execution plan failed generic validation: "
            f"{error}"
        ) from error
    if value != expected:
        raise PackageBuildError(
            "generated surface execution plan is stale or was rewritten"
        )
    return value


def _sweep_directions_from_surface_execution_plan(
    value: object,
) -> Mapping[str, tuple[float, float, float]] | None:
    """Return persisted direction evidence without reconstructing it from geometry."""

    if value is None:
        return None
    if type(value) is not GeneratedSurfaceExecutionPlan:
        raise PackageBuildError(
            "generated_surface_execution_plan must be a neutral surface plan"
        )
    return value.sweep_direction_xyz_by_component


def _validate_underfill_core_topology_evidence(
    *,
    mode: str,
    requested: str | None,
    applied: str,
    implicit_selection: bool,
    generated_element_count: int,
    hex8_count: int,
    pyramid5_count: int,
    tet4_count: int,
    fallback_hex8_count: int,
    star_converted_hex8_count: int,
    free_surface_tri3_count: int,
    free_surface_quad_fallback_count: int,
    non_hex_exterior_face_count: int,
    exterior_quad_owned_by_non_hex_count: int,
    orthogonal_hex_verified: bool,
) -> None:
    """Reject topology evidence that does not match the emitted lower UF."""

    normalized_requested = (
        None
        if requested is None
        else normalize_underfill_core_volume_topology(requested)
    )
    applied = normalize_underfill_core_volume_topology(applied)
    if not isinstance(implicit_selection, bool):
        raise PackageBuildError(
            "underfill core implicit topology selection evidence must be boolean"
        )
    if not isinstance(orthogonal_hex_verified, bool):
        raise PackageBuildError(
            "underfill core orthogonal-HEX verification evidence must be boolean"
        )
    counts = (
        generated_element_count,
        hex8_count,
        pyramid5_count,
        tet4_count,
        fallback_hex8_count,
        star_converted_hex8_count,
        free_surface_tri3_count,
        free_surface_quad_fallback_count,
        non_hex_exterior_face_count,
        exterior_quad_owned_by_non_hex_count,
    )
    if any(
        isinstance(value, bool) or not isinstance(value, int) or value < 0
        for value in counts
    ):
        raise PackageBuildError(
            "underfill core topology counts must be non-negative integers"
        )
    normalize_underfill_core_mesh_mode(mode)
    if (
        normalized_requested is None
        or implicit_selection
        or normalized_requested != applied
    ):
        raise PackageBuildError(
            "underfill core topology must be explicitly requested and applied unchanged"
        )
    if generated_element_count != hex8_count + pyramid5_count + tet4_count:
        raise PackageBuildError(
            "underfill core HEX8/PYRAMID5/TET4 counts do not sum to generated elements"
        )
    if normalized_requested == "orthogonal_hex":
        if (
            hex8_count != generated_element_count
            or pyramid5_count
            or tet4_count
            or fallback_hex8_count
            or star_converted_hex8_count
            or free_surface_tri3_count
            or free_surface_quad_fallback_count
            or non_hex_exterior_face_count
            or exterior_quad_owned_by_non_hex_count
            or not orthogonal_hex_verified
        ):
            raise PackageBuildError(
                "orthogonal-HEX lower-UF topology evidence is inconsistent"
            )
    elif normalized_requested == "conformal_hybrid":
        if (
            fallback_hex8_count > hex8_count
            or orthogonal_hex_verified
        ):
            raise PackageBuildError(
                "conformal-hybrid lower-UF topology evidence is inconsistent"
            )
    elif normalized_requested == "structured_sweep":
        if (
            hex8_count != generated_element_count
            or pyramid5_count
            or tet4_count
            or fallback_hex8_count
            or star_converted_hex8_count
            or orthogonal_hex_verified
        ):
            raise PackageBuildError(
                "structured-sweep lower-UF topology evidence is inconsistent"
            )


def _validated_zone_element_kind_counts(
    value: Mapping[str, Mapping[str, int]],
    *,
    zone_element_counts: Mapping[str, int],
    element_kind_counts: Mapping[str, int],
) -> dict[str, dict[str, int]]:
    """Return summary-ready zone/kind evidence after cross-auditing it."""

    if not isinstance(value, Mapping):
        raise PackageBuildError("zone element-kind counts must be a mapping")
    if not isinstance(zone_element_counts, Mapping):
        raise PackageBuildError("zone element counts must be a mapping")
    if not isinstance(element_kind_counts, Mapping):
        raise PackageBuildError("element-kind counts must be a mapping")

    valid_kinds = {kind.value for kind in ElementKind}

    def validated_totals(
        counts: Mapping[str, int],
        *,
        label: str,
        allowed_keys: set[str] | None = None,
    ) -> dict[str, int]:
        normalized: dict[str, int] = {}
        for key, count in counts.items():
            if not isinstance(key, str) or not key:
                raise PackageBuildError(f"{label} keys must be non-empty strings")
            if allowed_keys is not None and key not in allowed_keys:
                raise PackageBuildError(
                    f"{label} contains unknown element kind {key!r}"
                )
            if isinstance(count, bool) or not isinstance(count, int) or count <= 0:
                raise PackageBuildError(
                    f"{label} values must be positive integers"
                )
            normalized[key] = count
        return dict(sorted(normalized.items()))

    zone_totals = validated_totals(
        zone_element_counts,
        label="zone element counts",
    )
    kind_totals = validated_totals(
        element_kind_counts,
        label="element-kind counts",
        allowed_keys=valid_kinds,
    )
    if set(value) != set(zone_totals):
        raise PackageBuildError(
            "zone element-kind counts must contain exactly the audited zones"
        )

    normalized: dict[str, dict[str, int]] = {}
    accumulated: Counter[str] = Counter()
    for zone in sorted(zone_totals):
        kind_counts = value[zone]
        if not isinstance(kind_counts, Mapping) or not kind_counts:
            raise PackageBuildError(
                f"zone element-kind counts for {zone!r} must be a non-empty mapping"
            )
        validated = validated_totals(
            kind_counts,
            label=f"zone element-kind counts for {zone!r}",
            allowed_keys=valid_kinds,
        )
        if sum(validated.values()) != zone_totals[zone]:
            raise PackageBuildError(
                f"zone element-kind counts for {zone!r} do not sum to its total"
            )
        normalized[zone] = validated
        accumulated.update(validated)
    if dict(sorted(accumulated.items())) != kind_totals:
        raise PackageBuildError(
            "zone element-kind counts do not reproduce global element-kind counts"
        )
    return normalized


def _validate_underfill_core_evidence(
    *,
    mode: str,
    requested_target: float | None,
    requested_transition: float | None,
    effective_target: float | None,
    effective_transition: float | None,
    locked_z_level_count: int,
    minimum_determinant: float | None,
    minimum_scaled_jacobian: float | None,
    minimum_sicn: float | None,
    minimum_sige: float | None,
    locked_face_count: int,
    generated_element_count: int,
) -> None:
    """Reject incomplete or self-contradictory fresh lower-UF evidence."""

    normalize_underfill_core_mesh_mode(mode)
    numeric = {
        "requested target": requested_target,
        "requested transition": requested_transition,
        "effective target": effective_target,
        "effective transition": effective_transition,
        "minimum determinant": minimum_determinant,
        "minimum scaled Jacobian": minimum_scaled_jacobian,
        "minimum SICN": minimum_sicn,
        "minimum SIGE": minimum_sige,
    }
    if any(
        value is None
        or isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
        or value <= 0.0
        for value in numeric.values()
    ):
        raise PackageBuildError(
            "target-controlled underfill core has incomplete finite quality/control evidence"
        )
    assert requested_target is not None
    assert requested_transition is not None
    assert effective_target is not None
    assert effective_transition is not None
    assert minimum_scaled_jacobian is not None
    assert minimum_sicn is not None
    assert minimum_sige is not None
    if effective_target > requested_target + _COORDINATE_TOLERANCE_MM:
        raise PackageBuildError(
            "target-controlled underfill core effective edge exceeds its request"
        )
    if not _close(effective_transition, requested_transition):
        raise PackageBuildError(
            "target-controlled underfill core changed the requested transition distance"
        )
    if min(minimum_scaled_jacobian, minimum_sicn, minimum_sige) < (
        _HYBRID_DEMO_MIN_QUALITY
    ):
        raise PackageBuildError(
            "target-controlled underfill core quality evidence is below 0.03"
        )
    if (
        not isinstance(locked_z_level_count, int)
        or isinstance(locked_z_level_count, bool)
        or locked_z_level_count < 2
        or not isinstance(locked_face_count, int)
        or isinstance(locked_face_count, bool)
        or locked_face_count < 1
        or not isinstance(generated_element_count, int)
        or isinstance(generated_element_count, bool)
        or generated_element_count < 1
    ):
        raise PackageBuildError(
            "target-controlled underfill core count evidence is incomplete"
        )


def _finite(value: object, *, field_name: str) -> float:
    if isinstance(value, bool):
        raise PackageBuildError(f"{field_name} must be finite")
    try:
        parsed = float(value)
    except (TypeError, ValueError) as error:
        raise PackageBuildError(f"{field_name} must be finite") from error
    if not math.isfinite(parsed):
        raise PackageBuildError(f"{field_name} must be finite")
    return parsed


def _coordinate_key(x: float, y: float, z: float) -> tuple[float, float, float]:
    return (round(x, _COORDINATE_DIGITS), round(y, _COORDINATE_DIGITS), round(z, _COORDINATE_DIGITS))


def _xy_key(x: float, y: float) -> tuple[float, float]:
    return (round(x, _COORDINATE_DIGITS), round(y, _COORDINATE_DIGITS))


def _close(first: float, second: float) -> bool:
    return math.isclose(
        first,
        second,
        rel_tol=0.0,
        abs_tol=_COORDINATE_TOLERANCE_MM,
    )


def _matching_index(values: Sequence[float], target: float, *, field_name: str) -> int:
    """Resolve one sidecar coordinate without requiring bit-identical JSON/MSH floats."""

    matches = [index for index, value in enumerate(values) if _close(value, target)]
    if len(matches) != 1:
        raise PackageBuildError(
            f"{field_name} does not match exactly one declared coordinate surface"
        )
    return matches[0]


def _token(value: str) -> str:
    rendered = "".join(
        character.upper() if character.isalnum() else "_" for character in value
    ).strip("_")
    if not rendered:
        raise PackageBuildError(f"cannot create a physical-group token from {value!r}")
    if rendered[0].isdigit():
        rendered = f"M_{rendered}"
    return rendered


@dataclass(frozen=True, slots=True)
class PackageElement:
    """One package element with material, selection and origin ownership.

    Imported connected-bump elements retain their raw material and unified
    ``TEMPLATE_<alias>_<component>`` selection names in
    ``preserved_physical_names``.  System origin sets and ``HM_*`` owners are
    deliberately represented by ``origin``/``owner_component`` instead: the
    package writer rebuilds those groups over the complete assembly so stale
    source aggregates cannot collide with the generated package volumes.
    """

    tag: int
    gmsh_type: int
    node_tags: tuple[int, ...]
    material: str
    component: str
    zone: str
    origin: str = _TRANSITION_ORIGIN
    owner_component: str | None = None
    preserved_physical_names: tuple[str, ...] = ()
    generation_provenance: str = "selected_volume_backend"

    def __post_init__(self) -> None:
        if self.tag < 1:
            raise PackageBuildError("package element tags must be positive")
        specification = ELEMENT_SPECS.get(self.gmsh_type)
        if specification is None:
            raise PackageBuildError(
                f"unsupported package element Gmsh type: {self.gmsh_type}"
            )
        expected = specification[1]
        if len(self.node_tags) != expected or len(set(self.node_tags)) != expected:
            raise PackageBuildError(
                f"Gmsh type {self.gmsh_type} requires {expected} distinct nodes"
            )
        if not self.material or not self.component or not self.zone:
            raise PackageBuildError("package element ownership must not be empty")
        if self.origin not in {_TEMPLATE_ORIGIN, _TRANSITION_ORIGIN}:
            raise PackageBuildError(
                "package element origin must be TEMPLATE or TRANSITION"
            )
        if self.owner_component is not None and not self.owner_component.strip():
            raise PackageBuildError("package element owner component must not be empty")
        if self.generation_provenance not in _ELEMENT_GENERATION_PROVENANCE:
            raise PackageBuildError(
                "package element generation provenance is invalid"
            )
        cleaned_names = tuple(name.strip() for name in self.preserved_physical_names)
        if any(not name for name in cleaned_names):
            raise PackageBuildError("preserved Physical Group names must not be empty")
        if len({name.upper() for name in cleaned_names}) != len(cleaned_names):
            raise PackageBuildError(
                "preserved Physical Group names must be unique ignoring case"
            )
        forbidden = tuple(
            name
            for name in cleaned_names
            if name.upper() in _REBUILT_SOURCE_PHYSICAL_NAMES
            or name.upper().startswith("HM_")
        )
        if forbidden:
            raise PackageBuildError(
                "ALL/TEMPLATE/TRANSITION aggregate and HM_* groups must be "
                f"rebuilt, not preserved: {forbidden!r}"
            )
        object.__setattr__(
            self,
            "preserved_physical_names",
            tuple(sorted(cleaned_names, key=lambda name: name.upper())),
        )

    @property
    def kind(self) -> ElementKind:
        return ELEMENT_SPECS[self.gmsh_type][0]

    @property
    def owner_token(self) -> str:
        return _token(self.owner_component or self.component)

    @property
    def hm_physical_name(self) -> str:
        return f"HM_{self.owner_token}_{self.origin}"


@dataclass(frozen=True, slots=True)
class CornerPort:
    """One validated connected-bump Cartesian corner region after placement."""

    source_index: int
    final_corner: str
    x_min_mm: float
    x_max_mm: float
    y_min_mm: float
    y_max_mm: float
    size_x_mm: float
    size_y_mm: float
    source_z_levels_mm: tuple[float, ...]
    final_z_levels_mm: tuple[float, ...]
    element_tags: tuple[int, ...]

    @property
    def inward_x_mm(self) -> float:
        return self.x_max_mm - self.x_min_mm

    @property
    def inward_y_mm(self) -> float:
        return self.y_max_mm - self.y_min_mm


@dataclass(frozen=True, slots=True)
class ResolvedPackageStack:
    """Resolved geometry for the current package component vocabulary."""

    substrate_material: str
    substrate_width_mm: float
    substrate_length_mm: float
    substrate_bottom_mm: float
    substrate_top_mm: float
    bump_source_path: Path
    bump_loc_xy_mm: tuple[float, float]
    bump_bottom_mm: float
    bump_top_mm: float
    die_material: str
    die_width_mm: float
    die_length_mm: float
    die_bottom_mm: float
    die_top_mm: float
    ring_parts: tuple[tuple[str, float, float, float], ...]
    uf_component: str
    uf_die_width_mm: float
    uf_die_length_mm: float
    uf_base_mm: float
    uf_height_mm: float
    uf_width_mm: float

    @property
    def outer_bounds_xy_mm(self) -> tuple[float, float, float, float]:
        return (
            -0.5 * self.substrate_width_mm,
            0.5 * self.substrate_width_mm,
            -0.5 * self.substrate_length_mm,
            0.5 * self.substrate_length_mm,
        )

    @property
    def die_bounds_xy_mm(self) -> tuple[float, float, float, float]:
        return (
            -0.5 * self.die_width_mm,
            0.5 * self.die_width_mm,
            -0.5 * self.die_length_mm,
            0.5 * self.die_length_mm,
        )

    @property
    def uf_top_mm(self) -> float:
        return self.uf_base_mm + self.uf_height_mm


@dataclass(frozen=True, slots=True)
class PackageMeshPlan:
    bundle: PackageBundle
    stack: ResolvedPackageStack
    source_mesh: VolumeMesh
    nodes: tuple[MeshNode, ...]
    elements: tuple[PackageElement, ...]
    corner_ports: tuple[CornerPort, ...]
    source_sha256: str
    source_connectivity_preserved: bool
    uf_surface_skin_generated: bool
    uf_cut_cell_count: int
    interface_face_count: int
    exterior_face_count: int
    bulk_mesh_mode: str = "sweep"
    hybrid_scope: str = "NONE"
    hybrid_transition_z_levels_mm: tuple[float, ...] = ()
    hybrid_regions: tuple["PackageHybridRegion", ...] = ()
    uf_above_bump_target_z_mm: float | None = None
    far_field_size_mm: float = 0.080
    transition_distance_mm: float = 0.120
    interface_audit_face_counts: tuple[tuple[str, int], ...] = ()
    generated_materials_authoritative: bool = False
    component_mesh_policies: Mapping[str, Mapping[str, object]] = field(
        default_factory=dict
    )
    interface_match_policies: Mapping[str, Mapping[str, object]] = field(
        default_factory=dict
    )
    component_mesh_policy_evidence: Mapping[str, Mapping[str, object]] = field(
        default_factory=dict
    )
    interface_match_policy_evidence: Mapping[str, Mapping[str, object]] = field(
        default_factory=dict
    )
    generated_component_role_bindings: Mapping[str, str] = field(
        default_factory=dict
    )
    generated_interface_policies: tuple[NegotiatedComponentInterface, ...] = ()
    generated_interface_continuity_groups: tuple[
        GeneratedSurfaceEquivalenceGroup, ...
    ] = ()
    generated_surface_execution_plan: GeneratedSurfaceExecutionPlan | None = None
    generated_interface_policy_evidence: tuple[Mapping[str, object], ...] = ()
    ring_volume_topologies: tuple[str, str] = (
        "structured_sweep",
        "structured_sweep",
    )
    underfill_core_mesh_mode: str = "target_mesh_control"
    underfill_core_target_edge_mm: float | None = None
    underfill_core_transition_distance_mm: float | None = None
    underfill_core_effective_target_edge_mm: float | None = None
    underfill_core_effective_transition_distance_mm: float | None = None
    underfill_core_locked_z_level_count: int = 0
    underfill_core_minimum_determinant: float | None = None
    underfill_core_minimum_scaled_jacobian: float | None = None
    underfill_core_minimum_sicn: float | None = None
    underfill_core_minimum_sige: float | None = None
    underfill_core_locked_interface_face_count: int = 0
    underfill_core_generated_element_count: int = 0
    underfill_core_requested_volume_topology: str | None = None
    underfill_core_applied_volume_topology: str = "structured_sweep"
    underfill_core_implicit_topology_selection: bool = False
    underfill_core_generated_hex8_count: int = 0
    underfill_core_generated_pyramid5_count: int = 0
    underfill_core_generated_tet4_count: int = 0
    underfill_core_quality_fallback_hex8_count: int = 0
    underfill_core_star_converted_hex8_count: int = 0
    underfill_core_free_surface_tri3_count: int = 0
    underfill_core_free_surface_quad_fallback_count: int = 0
    underfill_core_non_hex_exterior_face_count: int = 0
    underfill_core_exterior_quad_owned_by_non_hex_count: int = 0
    underfill_core_orthogonal_hex_verified: bool = False

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "bulk_mesh_mode",
            normalize_package_bulk_mesh_mode(self.bulk_mesh_mode),
        )
        object.__setattr__(
            self,
            "underfill_core_mesh_mode",
            normalize_underfill_core_mesh_mode(self.underfill_core_mesh_mode),
        )
        if not isinstance(self.generated_materials_authoritative, bool):
            raise PackageBuildError(
                "generated_materials_authoritative must be a boolean"
            )
        if self.component_mesh_policies or self.interface_match_policies:
            normalized_component_policies = _normalize_component_mesh_policies(
                self.component_mesh_policies
            )
            normalized_interface_policies = _normalize_interface_match_policies(
                self.interface_match_policies
            )
            object.__setattr__(
                self,
                "component_mesh_policies",
                {
                    role: normalized_component_policies[role].to_dict()
                    for role in PACKAGE_COMPONENT_MESH_ROLES
                },
            )
            object.__setattr__(
                self,
                "interface_match_policies",
                {
                    role: normalized_interface_policies[role].to_dict()
                    for role in PACKAGE_INTERFACE_MATCH_ROLES
                },
            )
            negotiated, bindings = _normalize_generated_interface_policies(
                self.generated_interface_policies,
                component_role_bindings=self.generated_component_role_bindings,
                component_policies=normalized_component_policies,
            )
            object.__setattr__(self, "generated_interface_policies", negotiated)
            object.__setattr__(
                self,
                "generated_component_role_bindings",
                bindings,
            )
            object.__setattr__(
                self,
                "generated_interface_continuity_groups",
                _normalize_generated_interface_continuity_groups(
                    self.generated_interface_continuity_groups,
                    interfaces=negotiated,
                    component_role_bindings=bindings,
                    component_policies=normalized_component_policies,
                    sweep_direction_xyz_by_component=(
                        _sweep_directions_from_surface_execution_plan(
                            self.generated_surface_execution_plan
                        )
                    ),
                ),
            )
            if self.generated_surface_execution_plan is not None:
                object.__setattr__(
                    self,
                    "generated_surface_execution_plan",
                    _normalize_generated_surface_execution_plan(
                        self.generated_surface_execution_plan,
                        interfaces=negotiated,
                        continuity_groups=(
                            self.generated_interface_continuity_groups
                        ),
                        component_role_bindings=bindings,
                        component_policies=normalized_component_policies,
                    ),
                )
        elif self.component_mesh_policy_evidence or self.interface_match_policy_evidence:
            raise PackageBuildError(
                "component/interface policy evidence requires explicit policies"
            )
        elif (
            self.generated_interface_continuity_groups
            or self.generated_surface_execution_plan is not None
        ):
            raise PackageBuildError(
                "generated-interface planning requires explicit policies"
            )
        object.__setattr__(
            self,
            "ring_volume_topologies",
            _normalize_ring_volume_topologies(self.ring_volume_topologies),
        )
        _validate_underfill_core_evidence(
            mode=self.underfill_core_mesh_mode,
            requested_target=self.underfill_core_target_edge_mm,
            requested_transition=self.underfill_core_transition_distance_mm,
            effective_target=self.underfill_core_effective_target_edge_mm,
            effective_transition=(
                self.underfill_core_effective_transition_distance_mm
            ),
            locked_z_level_count=self.underfill_core_locked_z_level_count,
            minimum_determinant=self.underfill_core_minimum_determinant,
            minimum_scaled_jacobian=(
                self.underfill_core_minimum_scaled_jacobian
            ),
            minimum_sicn=self.underfill_core_minimum_sicn,
            minimum_sige=self.underfill_core_minimum_sige,
            locked_face_count=self.underfill_core_locked_interface_face_count,
            generated_element_count=self.underfill_core_generated_element_count,
        )
        if self.underfill_core_requested_volume_topology is not None:
            object.__setattr__(
                self,
                "underfill_core_requested_volume_topology",
                normalize_underfill_core_volume_topology(
                    self.underfill_core_requested_volume_topology
                ),
            )
        object.__setattr__(
            self,
            "underfill_core_applied_volume_topology",
            normalize_underfill_core_volume_topology(
                self.underfill_core_applied_volume_topology
            ),
        )
        _validate_underfill_core_topology_evidence(
            mode=self.underfill_core_mesh_mode,
            requested=self.underfill_core_requested_volume_topology,
            applied=self.underfill_core_applied_volume_topology,
            implicit_selection=self.underfill_core_implicit_topology_selection,
            generated_element_count=self.underfill_core_generated_element_count,
            hex8_count=self.underfill_core_generated_hex8_count,
            pyramid5_count=self.underfill_core_generated_pyramid5_count,
            tet4_count=self.underfill_core_generated_tet4_count,
            fallback_hex8_count=(
                self.underfill_core_quality_fallback_hex8_count
            ),
            star_converted_hex8_count=(
                self.underfill_core_star_converted_hex8_count
            ),
            free_surface_tri3_count=(
                self.underfill_core_free_surface_tri3_count
            ),
            free_surface_quad_fallback_count=(
                self.underfill_core_free_surface_quad_fallback_count
            ),
            non_hex_exterior_face_count=(
                self.underfill_core_non_hex_exterior_face_count
            ),
            exterior_quad_owned_by_non_hex_count=(
                self.underfill_core_exterior_quad_owned_by_non_hex_count
            ),
            orthogonal_hex_verified=(
                self.underfill_core_orthogonal_hex_verified
            ),
        )
        audit = PackageInterfaceAudit(self.interface_audit_face_counts)
        object.__setattr__(
            self,
            "interface_audit_face_counts",
            audit.face_counts,
        )

    @property
    def node_count(self) -> int:
        return len(self.nodes)

    @property
    def element_count(self) -> int:
        return len(self.elements)

    @property
    def element_kind_counts(self) -> dict[str, int]:
        counts = Counter(element.kind.value for element in self.elements)
        return dict(sorted(counts.items()))

    @property
    def material_element_counts(self) -> dict[str, int]:
        counts = Counter(element.material for element in self.elements)
        return dict(sorted(counts.items()))

    @property
    def component_element_counts(self) -> dict[str, int]:
        counts = Counter(element.component for element in self.elements)
        return dict(sorted(counts.items()))

    @property
    def component_element_kind_counts(self) -> dict[str, dict[str, int]]:
        counts: dict[str, Counter[str]] = defaultdict(Counter)
        for element in self.elements:
            counts[element.component][element.kind.value] += 1
        return {
            component: dict(sorted(kind_counts.items()))
            for component, kind_counts in sorted(counts.items())
        }

    @property
    def zone_element_counts(self) -> dict[str, int]:
        counts = Counter(element.zone for element in self.elements)
        return dict(sorted(counts.items()))

    @property
    def zone_element_kind_counts(self) -> dict[str, dict[str, int]]:
        counts: dict[str, Counter[str]] = defaultdict(Counter)
        for element in self.elements:
            counts[element.zone][element.kind.value] += 1
        return {
            zone: dict(sorted(kind_counts.items()))
            for zone, kind_counts in sorted(counts.items())
        }

    @property
    def exact_interface_face_counts(self) -> dict[str, int]:
        return self.interface_audit.to_dict()

    @property
    def interface_audit(self) -> PackageInterfaceAudit:
        """Return immutable, revalidated evidence for worker consumption."""

        return PackageInterfaceAudit(self.interface_audit_face_counts)


@dataclass(frozen=True, slots=True)
class PackageHybridRegion:
    """One true XYZ-coarsening TET/PYR bulk in the package plan."""

    zone: str
    interface_z_mm: float
    far_z_mm: float
    maximum_size_mm: float
    near_size_mm: float
    locked_face_count: int
    locked_bottom_face_count: int
    locked_side_face_count: int
    far_face_count: int
    node_count: int
    element_count: int
    tet4_count: int
    pyramid5_count: int
    near_median_edge_mm: float
    far_median_edge_mm: float
    growth_ratio_x: float
    growth_ratio_y: float
    growth_ratio_z: float
    minimum_sicn: float
    minimum_sige: float
    generated_node_count: int = 0
    random_seed: int = 0
    minimum_scaled_jacobian: float = 0.0
    adapter_cap_z_mm: float | None = None
    adapter_top_face_count: int = 0
    remainder_tet4_count: int = 0
    adapter_bottom_median_edge_mm: float = 0.0
    adapter_top_median_edge_mm: float = 0.0
    bottom_base_aspect_median: float = 0.0
    bottom_base_aspect_p90: float = 0.0
    bottom_base_aspect_maximum: float = 0.0
    growth_measurement_available: bool = True

    @property
    def edge_growth_ratio(self) -> float:
        return self.far_median_edge_mm / self.near_median_edge_mm

    @property
    def adapter_xy_edge_growth_ratio(self) -> float:
        if self.adapter_bottom_median_edge_mm <= 0.0:
            return 0.0
        return (
            self.adapter_top_median_edge_mm
            / self.adapter_bottom_median_edge_mm
        )

    @property
    def adapter_surface_face_reduction_ratio(self) -> float:
        if self.adapter_top_face_count <= 0:
            return 0.0
        return 2.0 * self.locked_bottom_face_count / self.adapter_top_face_count


@dataclass(frozen=True, slots=True)
class PackageBuildSummary:
    mesh_path: str
    report_path: str
    parameters_path: str
    package_path: str
    source_mesh_path: str
    source_sha256: str
    bulk_mesh_mode: str
    hybrid_scope: str
    hybrid_quality_metrics: Mapping[str, float | int]
    node_count: int
    element_count: int
    element_kind_counts: Mapping[str, int]
    material_element_counts: Mapping[str, int]
    component_element_counts: Mapping[str, int]
    zone_element_counts: Mapping[str, int]
    zone_element_kind_counts: Mapping[str, Mapping[str, int]]
    corner_port_count: int
    corner_inward_um: float
    corner_pitch_um: float
    interface_face_count: int
    exterior_face_count: int
    duplicate_node_count: int
    minimum_jacobian_determinant: float
    source_connectivity_preserved: bool
    uf_surface_skin_generated: bool
    uf_cut_cell_count: int
    written_mesh_reopened_verified: bool
    mesh_artifact: Mapping[str, str | int]
    generated_materials_authoritative: bool = False
    component_mesh_policies: Mapping[str, Mapping[str, object]] = field(
        default_factory=dict
    )
    interface_match_policies: Mapping[str, Mapping[str, object]] = field(
        default_factory=dict
    )
    component_mesh_policy_evidence: Mapping[str, Mapping[str, object]] = field(
        default_factory=dict
    )
    interface_match_policy_evidence: Mapping[str, Mapping[str, object]] = field(
        default_factory=dict
    )
    generated_component_role_bindings: Mapping[str, str] = field(
        default_factory=dict
    )
    generated_interface_policies: tuple[NegotiatedComponentInterface, ...] = ()
    generated_interface_continuity_groups: tuple[
        GeneratedSurfaceEquivalenceGroup, ...
    ] = ()
    generated_surface_execution_plan: GeneratedSurfaceExecutionPlan | None = None
    generated_interface_policy_evidence: tuple[Mapping[str, object], ...] = ()
    ring_volume_topologies: tuple[str, str] = (
        "structured_sweep",
        "structured_sweep",
    )
    exact_interface_face_counts: Mapping[str, int] = field(default_factory=dict)
    underfill_core_mesh_mode: str = "target_mesh_control"
    underfill_core_target_edge_mm: float | None = None
    underfill_core_transition_distance_mm: float | None = None
    underfill_core_effective_target_edge_mm: float | None = None
    underfill_core_effective_transition_distance_mm: float | None = None
    underfill_core_locked_z_level_count: int = 0
    underfill_core_minimum_determinant: float | None = None
    underfill_core_minimum_scaled_jacobian: float | None = None
    underfill_core_minimum_sicn: float | None = None
    underfill_core_minimum_sige: float | None = None
    underfill_core_locked_interface_face_count: int = 0
    underfill_core_generated_element_count: int = 0
    underfill_core_requested_volume_topology: str | None = None
    underfill_core_applied_volume_topology: str = "structured_sweep"
    underfill_core_implicit_topology_selection: bool = False
    underfill_core_generated_hex8_count: int = 0
    underfill_core_generated_pyramid5_count: int = 0
    underfill_core_generated_tet4_count: int = 0
    underfill_core_quality_fallback_hex8_count: int = 0
    underfill_core_star_converted_hex8_count: int = 0
    underfill_core_free_surface_tri3_count: int = 0
    underfill_core_free_surface_quad_fallback_count: int = 0
    underfill_core_non_hex_exterior_face_count: int = 0
    underfill_core_exterior_quad_owned_by_non_hex_count: int = 0
    underfill_core_orthogonal_hex_verified: bool = False
    component_element_kind_counts: Mapping[str, Mapping[str, int]] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        if not isinstance(self.generated_materials_authoritative, bool):
            raise PackageBuildError(
                "generated_materials_authoritative must be a boolean"
            )
        if self.component_mesh_policies or self.interface_match_policies:
            normalized_component_policies = _normalize_component_mesh_policies(
                self.component_mesh_policies
            )
            normalized_interface_policies = _normalize_interface_match_policies(
                self.interface_match_policies
            )
            object.__setattr__(
                self,
                "component_mesh_policies",
                {
                    role: normalized_component_policies[role].to_dict()
                    for role in PACKAGE_COMPONENT_MESH_ROLES
                },
            )
            object.__setattr__(
                self,
                "interface_match_policies",
                {
                    role: normalized_interface_policies[role].to_dict()
                    for role in PACKAGE_INTERFACE_MATCH_ROLES
                },
            )
            negotiated, bindings = _normalize_generated_interface_policies(
                self.generated_interface_policies,
                component_role_bindings=self.generated_component_role_bindings,
                component_policies=normalized_component_policies,
            )
            object.__setattr__(self, "generated_interface_policies", negotiated)
            object.__setattr__(
                self,
                "generated_component_role_bindings",
                bindings,
            )
            object.__setattr__(
                self,
                "generated_interface_continuity_groups",
                _normalize_generated_interface_continuity_groups(
                    self.generated_interface_continuity_groups,
                    interfaces=negotiated,
                    component_role_bindings=bindings,
                    component_policies=normalized_component_policies,
                    sweep_direction_xyz_by_component=(
                        _sweep_directions_from_surface_execution_plan(
                            self.generated_surface_execution_plan
                        )
                    ),
                ),
            )
            if self.generated_surface_execution_plan is not None:
                object.__setattr__(
                    self,
                    "generated_surface_execution_plan",
                    _normalize_generated_surface_execution_plan(
                        self.generated_surface_execution_plan,
                        interfaces=negotiated,
                        continuity_groups=(
                            self.generated_interface_continuity_groups
                        ),
                        component_role_bindings=bindings,
                        component_policies=normalized_component_policies,
                    ),
                )
        elif self.component_mesh_policy_evidence or self.interface_match_policy_evidence:
            raise PackageBuildError(
                "component/interface policy evidence requires explicit policies"
            )
        elif (
            self.generated_interface_continuity_groups
            or self.generated_surface_execution_plan is not None
        ):
            raise PackageBuildError(
                "generated-interface planning requires explicit policies"
            )
        object.__setattr__(
            self,
            "ring_volume_topologies",
            _normalize_ring_volume_topologies(self.ring_volume_topologies),
        )
        audit = PackageInterfaceAudit.from_mapping(
            self.exact_interface_face_counts
        )
        object.__setattr__(
            self,
            "underfill_core_mesh_mode",
            normalize_underfill_core_mesh_mode(self.underfill_core_mesh_mode),
        )
        _validate_underfill_core_evidence(
            mode=self.underfill_core_mesh_mode,
            requested_target=self.underfill_core_target_edge_mm,
            requested_transition=self.underfill_core_transition_distance_mm,
            effective_target=self.underfill_core_effective_target_edge_mm,
            effective_transition=(
                self.underfill_core_effective_transition_distance_mm
            ),
            locked_z_level_count=self.underfill_core_locked_z_level_count,
            minimum_determinant=self.underfill_core_minimum_determinant,
            minimum_scaled_jacobian=(
                self.underfill_core_minimum_scaled_jacobian
            ),
            minimum_sicn=self.underfill_core_minimum_sicn,
            minimum_sige=self.underfill_core_minimum_sige,
            locked_face_count=self.underfill_core_locked_interface_face_count,
            generated_element_count=self.underfill_core_generated_element_count,
        )
        if self.underfill_core_requested_volume_topology is not None:
            object.__setattr__(
                self,
                "underfill_core_requested_volume_topology",
                normalize_underfill_core_volume_topology(
                    self.underfill_core_requested_volume_topology
                ),
            )
        object.__setattr__(
            self,
            "underfill_core_applied_volume_topology",
            normalize_underfill_core_volume_topology(
                self.underfill_core_applied_volume_topology
            ),
        )
        _validate_underfill_core_topology_evidence(
            mode=self.underfill_core_mesh_mode,
            requested=self.underfill_core_requested_volume_topology,
            applied=self.underfill_core_applied_volume_topology,
            implicit_selection=self.underfill_core_implicit_topology_selection,
            generated_element_count=self.underfill_core_generated_element_count,
            hex8_count=self.underfill_core_generated_hex8_count,
            pyramid5_count=self.underfill_core_generated_pyramid5_count,
            tet4_count=self.underfill_core_generated_tet4_count,
            fallback_hex8_count=(
                self.underfill_core_quality_fallback_hex8_count
            ),
            star_converted_hex8_count=(
                self.underfill_core_star_converted_hex8_count
            ),
            free_surface_tri3_count=(
                self.underfill_core_free_surface_tri3_count
            ),
            free_surface_quad_fallback_count=(
                self.underfill_core_free_surface_quad_fallback_count
            ),
            non_hex_exterior_face_count=(
                self.underfill_core_non_hex_exterior_face_count
            ),
            exterior_quad_owned_by_non_hex_count=(
                self.underfill_core_exterior_quad_owned_by_non_hex_count
            ),
            orthogonal_hex_verified=(
                self.underfill_core_orthogonal_hex_verified
            ),
        )
        object.__setattr__(
            self,
            "exact_interface_face_counts",
            audit.to_dict(),
        )
        zone_kind_counts = _validated_zone_element_kind_counts(
            self.zone_element_kind_counts,
            zone_element_counts=self.zone_element_counts,
            element_kind_counts=self.element_kind_counts,
        )
        if (
            isinstance(self.element_count, bool)
            or not isinstance(self.element_count, int)
            or self.element_count < 0
            or sum(
                count
                for kind_counts in zone_kind_counts.values()
                for count in kind_counts.values()
            )
            != self.element_count
        ):
            raise PackageBuildError(
                "zone element-kind counts do not sum to the summary element count"
            )
        object.__setattr__(
            self,
            "zone_element_kind_counts",
            zone_kind_counts,
        )
        object.__setattr__(
            self,
            "zone_element_counts",
            dict(sorted(self.zone_element_counts.items())),
        )
        object.__setattr__(
            self,
            "element_kind_counts",
            dict(sorted(self.element_kind_counts.items())),
        )

    def to_dict(self) -> dict[str, object]:
        # A continuity group intentionally carries read-only MappingProxy
        # evidence.  Build the JSON payload shallowly and serialize the two
        # domain dataclasses explicitly rather than asking ``asdict`` to
        # deepcopy immutable mapping proxies.
        payload = {
            definition.name: getattr(self, definition.name)
            for definition in fields(self)
        }
        payload["generated_interface_policies"] = [
            value.to_dict() for value in self.generated_interface_policies
        ]
        payload["generated_interface_continuity_groups"] = [
            value.to_dict()
            for value in self.generated_interface_continuity_groups
        ]
        payload["generated_surface_execution_plan"] = (
            None
            if self.generated_surface_execution_plan is None
            else self.generated_surface_execution_plan.to_dict()
        )
        payload["element_kind_counts"] = dict(self.element_kind_counts)
        payload["material_element_counts"] = dict(self.material_element_counts)
        payload["component_element_counts"] = dict(self.component_element_counts)
        payload["component_element_kind_counts"] = {
            component: dict(kind_counts)
            for component, kind_counts in self.component_element_kind_counts.items()
        }
        payload["zone_element_counts"] = dict(self.zone_element_counts)
        payload["zone_element_kind_counts"] = {
            zone: dict(kind_counts)
            for zone, kind_counts in self.zone_element_kind_counts.items()
        }
        payload["hybrid_quality_metrics"] = dict(self.hybrid_quality_metrics)
        payload["exact_interface_face_counts"] = dict(
            self.exact_interface_face_counts
        )
        payload["mesh_artifact"] = dict(self.mesh_artifact)
        return payload


@dataclass(frozen=True, slots=True)
class _ConnectedBumpSnapshot:
    source_mesh: VolumeMesh
    parameters: Mapping[str, object]
    report: Mapping[str, object]
    sha256: str
    size_bytes: int


class _NodeRegistry:
    def __init__(self) -> None:
        self.nodes_by_tag: dict[int, MeshNode] = {}
        self.tag_by_coordinate: dict[tuple[float, float, float], int] = {}
        self.next_tag = 1

    def add(
        self,
        x: float,
        y: float,
        z: float,
        *,
        preferred_tag: int | None = None,
    ) -> int:
        coordinates = (
            _finite(x, field_name="node x"),
            _finite(y, field_name="node y"),
            _finite(z, field_name="node z"),
        )
        key = _coordinate_key(*coordinates)
        existing = self.tag_by_coordinate.get(key)
        if existing is not None:
            node = self.nodes_by_tag[existing]
            if any(
                not _close(first, second)
                for first, second in zip(node.coordinates, coordinates)
            ):
                raise PackageBuildError("rounded coordinate key is ambiguous")
            return existing
        if preferred_tag is not None:
            if preferred_tag < 1 or preferred_tag in self.nodes_by_tag:
                raise PackageBuildError(
                    f"preferred package node tag is unavailable: {preferred_tag}"
                )
            tag = preferred_tag
        else:
            while self.next_tag in self.nodes_by_tag:
                self.next_tag += 1
            tag = self.next_tag
        self.nodes_by_tag[tag] = MeshNode(tag, *coordinates)
        self.tag_by_coordinate[key] = tag
        self.next_tag = max(self.next_tag, tag + 1)
        return tag

    def tag_at(self, x: float, y: float, z: float) -> int | None:
        return self.tag_by_coordinate.get(_coordinate_key(x, y, z))

    def nodes(self) -> tuple[MeshNode, ...]:
        return tuple(self.nodes_by_tag[tag] for tag in sorted(self.nodes_by_tag))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_layout_sidecar(mesh_path: Path) -> dict[str, object]:
    sidecar = mesh_path.with_suffix(".parameters.json")
    if not sidecar.is_file():
        raise PackageBuildError(
            "connected-bump package input requires its .parameters.json sidecar: "
            f"{sidecar}"
        )
    try:
        payload = json.loads(sidecar.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise PackageBuildError(f"cannot read layout sidecar: {sidecar}") from error
    if payload.get("schema") != "easymesh-bump-layout-v4":
        raise PackageBuildError(
            "package assembly requires an easymesh-bump-layout-v4 sidecar"
        )
    return payload


def _source_sidecar_paths(mesh_path: Path) -> tuple[Path, Path]:
    return (
        mesh_path.with_suffix(".parameters.json"),
        mesh_path.with_suffix(".report.json"),
    )


def _load_json_object(path: Path, *, label: str) -> dict[str, object]:
    if not path.is_file():
        raise PackageBuildError(f"connected-bump {label} is required: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise PackageBuildError(
            f"cannot read connected-bump {label}: {path}"
        ) from error
    if not isinstance(payload, dict):
        raise PackageBuildError(
            f"connected-bump {label} must contain a JSON object: {path}"
        )
    return payload


def _validate_source_report(
    mesh_path: Path,
    parameters: Mapping[str, object],
    report: Mapping[str, object],
    *,
    mesh_sha256: str,
    mesh_size_bytes: int,
) -> None:
    report_path = mesh_path.with_suffix(".report.json")
    if report.get("parameters") != parameters:
        raise PackageBuildError(
            "connected-bump report.parameters differs from its parameters sidecar: "
            f"{report_path}"
        )
    artifact = report.get("mesh_artifact")
    if not isinstance(artifact, dict):
        raise PackageBuildError(
            f"connected-bump report lacks mesh_artifact: {report_path}"
        )
    artifact_path = artifact.get("path")
    if not isinstance(artifact_path, str) or not artifact_path.strip():
        raise PackageBuildError(
            f"connected-bump report mesh_artifact.path is invalid: {report_path}"
        )
    if not paths_refer_to_same_file(mesh_path, artifact_path):
        raise PackageBuildError(
            "connected-bump report mesh_artifact.path does not identify the source MSH: "
            f"{report_path}"
        )
    artifact_size = artifact.get("size_bytes")
    if (
        not isinstance(artifact_size, int)
        or isinstance(artifact_size, bool)
        or artifact_size != mesh_size_bytes
    ):
        raise PackageBuildError(
            "connected-bump report mesh_artifact.size_bytes differs from the "
            f"source MSH: {report_path}"
        )
    artifact_sha256 = artifact.get("sha256")
    if (
        not isinstance(artifact_sha256, str)
        or len(artifact_sha256) != 64
        or artifact_sha256.lower() != mesh_sha256
    ):
        raise PackageBuildError(
            "connected-bump report mesh_artifact SHA-256 differs from the "
            f"source MSH: {report_path}"
        )


def _load_connected_bump_snapshot(mesh_path: Path) -> _ConnectedBumpSnapshot:
    """Read one MSH and its two sidecars as a byte-bound snapshot."""

    source = mesh_path.expanduser().resolve()
    parameter_path, report_path = _source_sidecar_paths(source)
    try:
        size_before = source.stat().st_size
        sha_before = _sha256(source)
    except OSError as error:
        raise PackageBuildError(f"cannot fingerprint connected-bump source: {source}") from error
    parameters = _load_json_object(parameter_path, label="parameters sidecar")
    if parameters.get("schema") != "easymesh-bump-layout-v4":
        raise PackageBuildError(
            "package assembly requires an easymesh-bump-layout-v4 sidecar"
        )
    report = _load_json_object(report_path, label="report sidecar")
    _validate_source_report(
        source,
        parameters,
        report,
        mesh_sha256=sha_before,
        mesh_size_bytes=size_before,
    )
    try:
        source_mesh = load_volume_mesh(source)
        size_after = source.stat().st_size
        sha_after = _sha256(source)
    except OSError as error:
        raise PackageBuildError(f"cannot read connected-bump source: {source}") from error
    if size_before != size_after or sha_before != sha_after:
        raise PackageBuildError(
            "connected-bump source MSH changed while its snapshot was being read"
        )
    return _ConnectedBumpSnapshot(
        source_mesh=source_mesh,
        parameters=parameters,
        report=report,
        sha256=sha_before,
        size_bytes=size_before,
    )


def _translation_feature(
    region_name: str,
    polygon: Sequence[Sequence[float]],
    vector: Sequence[float],
    *,
    operation: BooleanOperation = BooleanOperation.ADD,
) -> EvaluatedSweepFeature:
    return EvaluatedSweepFeature(
        operation=operation,
        region_name=region_name,
        polygon_mm=tuple(tuple(float(value) for value in point) for point in polygon),  # type: ignore[arg-type]
        sweep=EvaluatedTranslationSweep(
            vector_mm=tuple(float(value) for value in vector),  # type: ignore[arg-type]
        ),
    )


def _rotation_feature(
    region_name: str,
    polygon: Sequence[Sequence[float]],
    angles: Sequence[float],
    pivot: Sequence[float],
    *,
    operation: BooleanOperation = BooleanOperation.ADD,
) -> EvaluatedSweepFeature:
    return EvaluatedSweepFeature(
        operation=operation,
        region_name=region_name,
        polygon_mm=tuple(tuple(float(value) for value in point) for point in polygon),  # type: ignore[arg-type]
        sweep=EvaluatedRotationSweep(
            angles_deg=tuple(float(value) for value in angles),  # type: ignore[arg-type]
            pivot_mm=tuple(float(value) for value in pivot),  # type: ignore[arg-type]
        ),
    )


def _canonical_component_instance(
    component_name: str,
    arguments_mm: Sequence[float],
) -> EvaluatedComponent:
    """Return the geometry contract consumed by the phase-one package builder.

    The mesher currently implements these three components directly.  Keeping
    the complete evaluated contract here prevents a parsed-but-ignored change
    to polygon ordering, Boolean ordering, sweep direction, or UF pivots.
    """

    arguments = tuple(float(value) for value in arguments_mm)
    parameters = _CANONICAL_COMPONENT_PARAMETERS.get(component_name)
    if parameters is None or len(arguments) != len(parameters):
        raise PackageBuildError(
            f"unsupported canonical component instance: {component_name!r}"
        )
    bound = dict(zip(parameters, arguments))
    features: tuple[EvaluatedSweepFeature, ...]
    if component_name == "cube":
        width, length, height = arguments
        features = (
            _translation_feature(
                "cube",
                (
                    (-width / 2.0, -length / 2.0, 0.0),
                    (width / 2.0, -length / 2.0, 0.0),
                    (width / 2.0, length / 2.0, 0.0),
                    (-width / 2.0, length / 2.0, 0.0),
                ),
                (0.0, 0.0, height),
            ),
        )
    elif component_name == "cube_ring":
        outer_width, outer_length, inner_width, inner_length, height = arguments

        def rectangle(width: float, length: float) -> tuple[tuple[float, float, float], ...]:
            return (
                (-width / 2.0, -length / 2.0, 0.0),
                (width / 2.0, -length / 2.0, 0.0),
                (width / 2.0, length / 2.0, 0.0),
                (-width / 2.0, length / 2.0, 0.0),
            )

        features = (
            _translation_feature(
                "cube",
                rectangle(outer_width, outer_length),
                (0.0, 0.0, height),
            ),
            _translation_feature(
                "cube",
                rectangle(inner_width, inner_length),
                (0.0, 0.0, height),
                operation=BooleanOperation.SUBTRACT,
            ),
        )
    else:
        width, length, height, toe_width = arguments
        x_min, x_max = -width / 2.0, width / 2.0
        y_min, y_max = -length / 2.0, length / 2.0
        features = (
            _translation_feature(
                "UF_left",
                ((x_min, y_min, 0.0), (x_min, y_min, height), (x_min - toe_width, y_min, 0.0)),
                (0.0, length, 0.0),
            ),
            _rotation_feature(
                "UF_bottomleft",
                ((x_min, y_min, 0.0), (x_min, y_min, height), (x_min - toe_width, y_min, 0.0)),
                (0.0, 0.0, 90.0),
                (x_min, y_min, 0.0),
            ),
            _translation_feature(
                "UF_bottom",
                ((x_min, y_min, 0.0), (x_min, y_min, height), (x_min, y_min - toe_width, 0.0)),
                (width, 0.0, 0.0),
            ),
            _rotation_feature(
                "UF_bottomright",
                ((x_max, y_min, 0.0), (x_max, y_min, height), (x_max, y_min - toe_width, 0.0)),
                (0.0, 0.0, 90.0),
                (x_max, y_min, 0.0),
            ),
            _translation_feature(
                "UF_right",
                ((x_max, y_min, 0.0), (x_max, y_min, height), (x_max + toe_width, y_min, 0.0)),
                (0.0, length, 0.0),
            ),
            _rotation_feature(
                "UF_topright",
                ((x_max, y_max, 0.0), (x_max, y_max, height), (x_max + toe_width, y_max, 0.0)),
                (0.0, 0.0, 90.0),
                (x_max, y_max, 0.0),
            ),
            _translation_feature(
                "UF_top",
                ((x_max, y_max, 0.0), (x_max, y_max, height), (x_max, y_max + toe_width, 0.0)),
                (-width, 0.0, 0.0),
            ),
            _rotation_feature(
                "UF_topleft",
                ((x_min, y_max, 0.0), (x_min, y_max, height), (x_min, y_max + toe_width, 0.0)),
                (0.0, 0.0, 90.0),
                (x_min, y_max, 0.0),
            ),
        )
    return EvaluatedComponent(
        name=component_name,
        parameters_mm=bound,
        features=features,
    )


def _vectors_match(
    actual: Sequence[float],
    expected: Sequence[float],
) -> bool:
    return len(actual) == len(expected) and all(
        _close(first, second) for first, second in zip(actual, expected)
    )


def _component_instances_match(
    actual: EvaluatedComponent,
    expected: EvaluatedComponent,
) -> bool:
    if actual.name != expected.name or len(actual.features) != len(expected.features):
        return False
    for actual_feature, expected_feature in zip(actual.features, expected.features):
        if (
            actual_feature.operation is not expected_feature.operation
            or actual_feature.region_name != expected_feature.region_name
            or len(actual_feature.polygon_mm) != len(expected_feature.polygon_mm)
            or any(
                not _vectors_match(actual_point, expected_point)
                for actual_point, expected_point in zip(
                    actual_feature.polygon_mm,
                    expected_feature.polygon_mm,
                )
            )
            or type(actual_feature.sweep) is not type(expected_feature.sweep)
        ):
            return False
        if isinstance(actual_feature.sweep, EvaluatedTranslationSweep):
            assert isinstance(expected_feature.sweep, EvaluatedTranslationSweep)
            if not _vectors_match(
                actual_feature.sweep.vector_mm,
                expected_feature.sweep.vector_mm,
            ):
                return False
        else:
            assert isinstance(actual_feature.sweep, EvaluatedRotationSweep)
            assert isinstance(expected_feature.sweep, EvaluatedRotationSweep)
            if not (
                _vectors_match(
                    actual_feature.sweep.angles_deg,
                    expected_feature.sweep.angles_deg,
                )
                and _vectors_match(
                    actual_feature.sweep.pivot_mm,
                    expected_feature.sweep.pivot_mm,
                )
            ):
                return False
    return True


def _validate_component_semantics(bundle: PackageBundle) -> None:
    """Fail closed unless every generated component matches its mesh contract."""

    for component_name in sorted(_SUPPORTED_COMPONENTS):
        component = bundle.components.get(component_name)
        if component is None:
            if any(
                part.component_name == component_name
                for part in bundle.package.generated_parts
            ):
                raise PackageBuildError(
                    f"missing canonical component {component_name!r}"
                )
            continue
        expected_parameters = _CANONICAL_COMPONENT_PARAMETERS[component_name]
        if component.name != component_name or component.parameters != expected_parameters:
            raise PackageBuildError(
                f"component {component_name!r} does not match canonical parameter semantics"
            )
        probe_arguments = _CANONICAL_COMPONENT_PROBES[component_name]
        try:
            probe = component.instantiate(probe_arguments)
        except ValueError as error:
            raise PackageBuildError(
                f"component {component_name!r} cannot instantiate its canonical probe"
            ) from error
        if not _component_instances_match(
            probe,
            _canonical_component_instance(component_name, probe_arguments),
        ):
            raise PackageBuildError(
                f"component {component_name!r} does not match canonical polygon/sweep semantics"
            )

    for part in bundle.package.generated_parts:
        component = bundle.components.get(part.component_name)
        if component is None:
            raise PackageBuildError(
                f"line {part.line_number}: missing component {part.component_name!r}"
            )
        try:
            actual = component.instantiate(part.arguments_mm)
        except ValueError as error:
            raise PackageBuildError(
                f"line {part.line_number}: cannot instantiate component "
                f"{part.component_name!r}"
            ) from error
        expected = _canonical_component_instance(
            part.component_name,
            part.arguments_mm,
        )
        if not _component_instances_match(actual, expected):
            raise PackageBuildError(
                f"line {part.line_number}: component {part.component_name!r} "
                "does not match canonical polygon/sweep semantics"
            )


def resolve_package_stack(
    bundle: PackageBundle,
    source_mesh: VolumeMesh,
) -> ResolvedPackageStack:
    """Resolve the support-based Z placement used by the current example."""

    unknown = {
        part.component_name
        for part in bundle.package.generated_parts
        if part.component_name not in _SUPPORTED_COMPONENTS
    }
    if unknown:
        raise PackageBuildError(
            f"unsupported package component: {sorted(unknown)[0]!r}"
        )
    placements = bundle.package.placements
    if len(placements) != 6:
        raise PackageBuildError(
            "current package profile requires substrate, bump, die, two rings, and UF"
        )
    if not isinstance(placements[0], GeneratedPart) or placements[0].component_name != "cube":
        raise PackageBuildError("first package placement must be the substrate cube")
    if not isinstance(placements[1], MeshPlacement):
        raise PackageBuildError("second package placement must be the bump mesh")
    if placements[1].transform is not PackageTransform.RX180:
        raise PackageBuildError("connected bump placement must use RX180")
    if not isinstance(placements[2], GeneratedPart) or placements[2].component_name != "cube":
        raise PackageBuildError("third package placement must be the added-Si cube")
    if any(
        not isinstance(placements[index], GeneratedPart)
        or placements[index].component_name != "cube_ring"
        for index in (3, 4)
    ):
        raise PackageBuildError("fourth and fifth package placements must be rings")
    if not isinstance(placements[5], GeneratedPart) or placements[5].component_name != "UF_fillet":
        raise PackageBuildError("last package placement must be UF_fillet")

    substrate = placements[0]
    bump = placements[1]
    die = placements[2]
    first_ring = placements[3]
    second_ring = placements[4]
    uf = placements[5]
    assert isinstance(substrate, GeneratedPart)
    assert isinstance(bump, MeshPlacement)
    assert isinstance(die, GeneratedPart)
    assert isinstance(first_ring, GeneratedPart)
    assert isinstance(second_ring, GeneratedPart)
    assert isinstance(uf, GeneratedPart)

    substrate_width, substrate_length, substrate_height = substrate.arguments_mm
    die_width, die_length, die_height = die.arguments_mm
    ring_parts: list[tuple[str, float, float, float]] = []
    ring_bottom = substrate_height
    for ring in (first_ring, second_ring):
        outer_width, outer_length, inner_width, inner_length, height = ring.arguments_mm
        if not (
            _close(outer_width, substrate_width)
            and _close(outer_length, substrate_length)
            and _close(inner_width, die_width)
            and _close(inner_length, die_length)
        ):
            raise PackageBuildError(
                "ring dimensions must match the substrate outer and die inner bounds"
            )
        ring_parts.append((ring.material_name, ring_bottom, ring_bottom + height, height))
        ring_bottom += height

    source_by_alias = bundle.package.mesh_source_by_alias
    source = source_by_alias.get(bump.source_alias)
    if source is None:
        raise PackageBuildError(f"unknown bump source alias: {bump.source_alias!r}")
    source_z = tuple(node.z for node in source_mesh.nodes)
    source_height = max(source_z) - min(source_z)
    bump_bottom = substrate_height
    bump_top = bump_bottom + source_height
    source_x_min = min(node.x for node in source_mesh.nodes)
    source_x_max = max(node.x for node in source_mesh.nodes)
    source_y_min = min(node.y for node in source_mesh.nodes)
    source_y_max = max(node.y for node in source_mesh.nodes)
    if not (
        _close(die_width, source_x_max - source_x_min)
        and _close(die_length, source_y_max - source_y_min)
    ):
        raise PackageBuildError("added Si footprint must match the connected bump bounds")
    placed_bump_center = (
        0.5 * (source_x_min + source_x_max) + bump.loc_xy_mm[0],
        -0.5 * (source_y_min + source_y_max) + bump.loc_xy_mm[1],
    )
    if not all(
        _close(bump_center, die_center)
        for bump_center, die_center in zip(placed_bump_center, die.loc_xy_mm)
    ):
        raise PackageBuildError(
            "connected bump center after RX180 and loc must match the added-Si center"
        )
    uf_die_width, uf_die_length, uf_height, uf_width = uf.arguments_mm
    if not (_close(uf_die_width, die_width) and _close(uf_die_length, die_length)):
        raise PackageBuildError("UF die footprint must match the added-Si footprint")
    if ring_bottom + uf_height > bump_top + die_height + _COORDINATE_TOLERANCE_MM:
        raise PackageBuildError("UF wetting height exceeds the complete die sidewall")

    return ResolvedPackageStack(
        substrate_material=substrate.material_name,
        substrate_width_mm=substrate_width,
        substrate_length_mm=substrate_length,
        substrate_bottom_mm=0.0,
        substrate_top_mm=substrate_height,
        bump_source_path=source.mesh_path,
        bump_loc_xy_mm=bump.loc_xy_mm,
        bump_bottom_mm=bump_bottom,
        bump_top_mm=bump_top,
        die_material=die.material_name,
        die_width_mm=die_width,
        die_length_mm=die_length,
        die_bottom_mm=bump_top,
        die_top_mm=bump_top + die_height,
        ring_parts=tuple(ring_parts),
        uf_component=uf.material_name,
        uf_die_width_mm=uf_die_width,
        uf_die_length_mm=uf_die_length,
        uf_base_mm=ring_bottom,
        uf_height_mm=uf_height,
        uf_width_mm=uf_width,
    )


def _source_material(element: object) -> str:
    physical_names = tuple(getattr(element, "physical_names"))
    system_names = {
        "ALL_SOLID_VOLUMES",
        "TEMPLATE_SOLID_VOLUMES",
        "TRANSITION_SOLID_VOLUMES",
    }
    candidates = tuple(
        name
        for name in physical_names
        if name.upper() not in system_names
        and not name.upper().startswith(
            ("HM_", "TEMPLATE_", "TRANSITION_", "BUMP_", "COMPONENT_")
        )
    )
    if len(candidates) != 1:
        raise PackageBuildError(
            "each connected-bump element must have one unambiguous material group: "
            f"element {getattr(element, 'tag')} has {candidates!r}"
        )
    return candidates[0]


def _hm_identity(name: str) -> tuple[str, str] | None:
    """Return ``(origin, component)`` for canonical or legacy HM names."""

    normalized = name.strip().upper()
    if not normalized.startswith("HM_"):
        return None
    body = normalized[len("HM_") :]
    for origin in (_TEMPLATE_ORIGIN, _TRANSITION_ORIGIN):
        suffix = f"_{origin}"
        if body.endswith(suffix) and len(body) > len(suffix):
            return (origin, body[: -len(suffix)])
        prefix = f"{origin}_"
        if body.startswith(prefix) and len(body) > len(prefix):
            return (origin, body[len(prefix) :])
    raise PackageBuildError(
        "connected-bump HM group must be named "
        f"HM_<component>_TEMPLATE/TRANSITION: {name!r}"
    )


def _source_provenance(
    element: object,
) -> tuple[str, str, tuple[str, ...]]:
    """Resolve one imported EID's exclusive origin and retained selections."""

    physical_names = tuple(
        str(name).strip() for name in getattr(element, "physical_names")
    )
    hm_identities = tuple(
        identity
        for name in physical_names
        if (identity := _hm_identity(name)) is not None
    )
    if len(hm_identities) != 1:
        raise PackageBuildError(
            "each connected-bump element must belong to exactly one HM owner: "
            f"element {getattr(element, 'tag')} has {hm_identities!r}"
        )
    origin, owner_component = hm_identities[0]
    template_selections = tuple(
        name
        for name in physical_names
        if name.upper().startswith("TEMPLATE_")
        and name.upper() != _TEMPLATE_SOLIDS
    )
    has_transition_aggregate = any(
        name.upper() == _TRANSITION_SOLIDS for name in physical_names
    )
    if origin == _TEMPLATE_ORIGIN:
        if len(template_selections) != 1 or has_transition_aggregate:
            raise PackageBuildError(
                "a TEMPLATE connected-bump element must have exactly one "
                "TEMPLATE_<alias>_<component> selection and no transition set: "
                f"element {getattr(element, 'tag')}"
            )
    elif template_selections or not has_transition_aggregate:
        raise PackageBuildError(
            "a TRANSITION connected-bump element must have the transition set "
            "and no TEMPLATE selection: "
            f"element {getattr(element, 'tag')}"
        )

    preserved = tuple(
        name
        for name in physical_names
        if name.upper() not in _REBUILT_SOURCE_PHYSICAL_NAMES
        and not name.upper().startswith("HM_")
    )
    return origin, owner_component, preserved


def _component_material_map(sidecar: Mapping[str, object]) -> dict[str, str]:
    raw_components = sidecar.get("transition_slab_components")
    raw_materials = sidecar.get("transition_slab_materials")
    if not isinstance(raw_components, list) or not isinstance(raw_materials, list):
        raise PackageBuildError("layout sidecar lacks transition component/material data")
    if len(raw_components) != len(raw_materials):
        raise PackageBuildError("layout component/material sidecar arrays disagree")
    materials_by_component: dict[str, set[str]] = defaultdict(set)
    for component, material in zip(raw_components, raw_materials):
        if not isinstance(component, str) or not isinstance(material, str):
            raise PackageBuildError("layout component/material entries must be strings")
        materials_by_component[component.strip().upper()].add(material.strip())
    ambiguous = {
        component: values
        for component, values in materials_by_component.items()
        if len(values) != 1
    }
    if ambiguous:
        raise PackageBuildError(
            f"layout component/material mapping is ambiguous: {ambiguous}"
        )
    return {
        component: next(iter(values))
        for component, values in materials_by_component.items()
    }


def _generated_material_alias_map(
    sidecar: Mapping[str, object],
    *,
    generated_materials_authoritative: bool,
) -> dict[str, str]:
    """Return only the alias authority selected for generated Components."""

    if not isinstance(generated_materials_authoritative, bool):
        raise PackageBuildError(
            "generated_materials_authoritative must be a boolean"
        )
    if generated_materials_authoritative:
        return {}
    return _component_material_map(sidecar)


def _package_material(
    component_or_material: str,
    mapping: Mapping[str, str],
    *,
    generated_materials_authoritative: bool = False,
) -> str:
    """Resolve one generated material under an explicit provenance policy.

    Legacy package files use component aliases such as ``SR`` and ``UF`` and
    intentionally resolve them through the Frozen layout sidecar.  A V2
    strategy has already resolved each generated ``Component.material``;
    authoritative mode therefore returns that token verbatim and must not let
    a Frozen-source alias table reinterpret it.
    """

    if not isinstance(generated_materials_authoritative, bool):
        raise PackageBuildError(
            "generated_materials_authoritative must be a boolean"
        )
    if generated_materials_authoritative:
        return component_or_material
    return mapping.get(component_or_material.strip().upper(), component_or_material)


def _transform_source_coordinate(
    node: MeshNode,
    *,
    stack: ResolvedPackageStack,
    source_z_max: float,
) -> tuple[float, float, float]:
    """Apply the proper RX180 placement and support alignment."""

    return (
        node.x + stack.bump_loc_xy_mm[0],
        -node.y + stack.bump_loc_xy_mm[1],
        stack.bump_bottom_mm + source_z_max - node.z,
    )


def _copy_connected_bump(
    source_mesh: VolumeMesh,
    stack: ResolvedPackageStack,
    registry: _NodeRegistry,
) -> tuple[list[PackageElement], dict[int, int]]:
    source_z_max = max(node.z for node in source_mesh.nodes)
    transformed_tag_by_source: dict[int, int] = {}
    for node in source_mesh.nodes:
        x, y, z = _transform_source_coordinate(
            node,
            stack=stack,
            source_z_max=source_z_max,
        )
        transformed_tag_by_source[node.tag] = registry.add(
            x,
            y,
            z,
            preferred_tag=node.tag,
        )
    elements: list[PackageElement] = []
    for element in source_mesh.elements:
        origin, owner_component, preserved_names = _source_provenance(element)
        elements.append(
            PackageElement(
                tag=element.tag,
                gmsh_type=element.gmsh_type,
                node_tags=tuple(
                    transformed_tag_by_source[tag] for tag in element.node_tags
                ),
                material=_source_material(element),
                component="CONNECTED_BUMP",
                zone="IMPORTED_C4",
                origin=origin,
                owner_component=owner_component,
                preserved_physical_names=preserved_names,
                generation_provenance="frozen_source",
            )
        )
    return elements, transformed_tag_by_source


def _region_float(region: Mapping[str, object], name: str) -> float:
    if name not in region:
        raise PackageBuildError(f"structured region is missing {name!r}")
    return _finite(region[name], field_name=f"structured region {name}")


def _extract_corner_ports(
    source_mesh: VolumeMesh,
    transformed_tag_by_source: Mapping[int, int],
    registry: _NodeRegistry,
    sidecar: Mapping[str, object],
    stack: ResolvedPackageStack,
) -> tuple[CornerPort, ...]:
    raw_regions = sidecar.get("structured_regions")
    raw_z_levels = sidecar.get("z_levels")
    if not isinstance(raw_regions, list) or len(raw_regions) != 4:
        raise PackageBuildError(
            "package assembly requires exactly four connected-bump corner regions"
        )
    if not isinstance(raw_z_levels, list) or len(raw_z_levels) < 2:
        raise PackageBuildError("layout sidecar lacks the source Z surfaces")
    source_z_levels = tuple(
        _finite(value, field_name="layout z level") for value in raw_z_levels
    )
    if any(second <= first for first, second in zip(source_z_levels, source_z_levels[1:])):
        raise PackageBuildError("layout z levels must be strictly ordered")
    source_z_max = source_z_levels[-1]
    final_z_levels = tuple(
        stack.bump_bottom_mm + source_z_max - value
        for value in reversed(source_z_levels)
    )
    source_nodes = source_mesh.node_map()
    ports: list[CornerPort] = []
    final_corner_names: set[str] = set()

    for fallback_index, raw_region in enumerate(raw_regions):
        if not isinstance(raw_region, dict):
            raise PackageBuildError("structured-region sidecar entries must be objects")
        source_index = int(raw_region.get("index", fallback_index))
        x0 = _region_float(raw_region, "x_min")
        x1 = _region_float(raw_region, "x_max")
        y0 = _region_float(raw_region, "y_min")
        y1 = _region_float(raw_region, "y_max")
        dx = _region_float(raw_region, "size_x")
        dy = _region_float(raw_region, "size_y")
        if x1 <= x0 or y1 <= y0 or dx <= 0.0 or dy <= 0.0:
            raise PackageBuildError(
                "corner structured-region extents and pitches must be positive"
            )
        x_count = round((x1 - x0) / dx)
        y_count = round((y1 - y0) / dy)
        if (
            x_count < 1
            or y_count < 1
            or not _close(x1, x0 + x_count * dx)
            or not _close(y1, y0 + y_count * dy)
        ):
            raise PackageBuildError(
                "corner structured-region bounds must be exact integer multiples "
                "of size_x/size_y"
            )
        final_x = sorted(
            (x0 + stack.bump_loc_xy_mm[0], x1 + stack.bump_loc_xy_mm[0])
        )
        final_y = sorted(
            (-y0 + stack.bump_loc_xy_mm[1], -y1 + stack.bump_loc_xy_mm[1])
        )
        corner = (
            ("N" if 0.5 * (final_y[0] + final_y[1]) > stack.bump_loc_xy_mm[1] else "S")
            + ("E" if 0.5 * (final_x[0] + final_x[1]) > stack.bump_loc_xy_mm[0] else "W")
        )
        if corner in final_corner_names:
            raise PackageBuildError(f"duplicate final corner port: {corner}")
        final_corner_names.add(corner)

        element_tags: list[int] = []
        node_tag_by_lattice: dict[tuple[int, int, int], int] = {}
        element_tag_by_cell: dict[tuple[int, int, int], int] = {}
        for element in source_mesh.elements:
            if element.kind is not ElementKind.HEX8:
                continue
            coordinates = [source_nodes[tag].coordinates for tag in element.node_tags]
            if not all(
                x0 - _COORDINATE_TOLERANCE_MM <= x <= x1 + _COORDINATE_TOLERANCE_MM
                and y0 - _COORDINATE_TOLERANCE_MM <= y <= y1 + _COORDINATE_TOLERANCE_MM
                for x, y, _z in coordinates
            ):
                continue
            element_tags.append(element.tag)
            element_lattice: list[tuple[int, int, int]] = []
            for tag in element.node_tags:
                node = source_nodes[tag]
                i = round((node.x - x0) / dx)
                j = round((node.y - y0) / dy)
                if (
                    not 0 <= i <= x_count
                    or not 0 <= j <= y_count
                    or not _close(node.x, x0 + i * dx)
                    or not _close(node.y, y0 + j * dy)
                ):
                    raise PackageBuildError(
                        f"corner {corner} node {tag} is not on the declared "
                        "Cartesian XY lattice"
                    )
                k = _matching_index(
                    source_z_levels,
                    node.z,
                    field_name="corner node Z coordinate",
                )
                lattice = (i, j, k)
                previous_tag = node_tag_by_lattice.setdefault(lattice, tag)
                if previous_tag != tag:
                    raise PackageBuildError(
                        f"corner {corner} logical node {lattice} is represented by "
                        f"multiple source nodes ({previous_tag}, {tag})"
                    )
                element_lattice.append(lattice)
                transformed = registry.nodes_by_tag[transformed_tag_by_source[tag]]
                expected = _transform_source_coordinate(
                    node,
                    stack=stack,
                    source_z_max=source_z_max,
                )
                if any(
                    not _close(value, reference)
                    for value, reference in zip(transformed.coordinates, expected)
                ):
                    raise PackageBuildError("corner transform does not preserve nodes")
            unique_lattice = set(element_lattice)
            if len(unique_lattice) != 8:
                raise PackageBuildError(
                    f"corner {corner} HEX8 {element.tag} does not contain eight "
                    "unique Cartesian lattice corners"
                )
            i_values = {index[0] for index in unique_lattice}
            j_values = {index[1] for index in unique_lattice}
            k_values = {index[2] for index in unique_lattice}
            if (
                len(i_values) != 2
                or len(j_values) != 2
                or len(k_values) != 2
                or max(i_values) - min(i_values) != 1
                or max(j_values) - min(j_values) != 1
                or max(k_values) - min(k_values) != 1
            ):
                raise PackageBuildError(
                    f"corner {corner} HEX8 {element.tag} does not occupy exactly "
                    "one Cartesian (i,j,k) cell"
                )
            expected_corners = {
                (i, j, k)
                for i in i_values
                for j in j_values
                for k in k_values
            }
            if unique_lattice != expected_corners:
                raise PackageBuildError(
                    f"corner {corner} HEX8 {element.tag} does not contain the "
                    "complete Cartesian cell corner set"
                )
            cell = (min(i_values), min(j_values), min(k_values))
            previous_element = element_tag_by_cell.setdefault(cell, element.tag)
            if previous_element != element.tag:
                raise PackageBuildError(
                    f"corner {corner} Cartesian cell {cell} is occupied by multiple "
                    f"HEX8 elements ({previous_element}, {element.tag})"
                )
        expected_element_count = x_count * y_count * (len(source_z_levels) - 1)
        expected_node_count = (x_count + 1) * (y_count + 1) * len(source_z_levels)
        if len(element_tags) != expected_element_count:
            raise PackageBuildError(
                f"corner {corner} contains {len(element_tags)} HEX8, expected "
                f"{expected_element_count}"
            )
        expected_nodes = {
            (i, j, k)
            for i in range(x_count + 1)
            for j in range(y_count + 1)
            for k in range(len(source_z_levels))
        }
        if set(node_tag_by_lattice) != expected_nodes:
            raise PackageBuildError(
                f"corner {corner} lattice contains {len(node_tag_by_lattice)} nodes, "
                f"expected {expected_node_count}"
            )
        expected_cells = {
            (i, j, k)
            for i in range(x_count)
            for j in range(y_count)
            for k in range(len(source_z_levels) - 1)
        }
        if set(element_tag_by_cell) != expected_cells:
            raise PackageBuildError(
                f"corner {corner} Cartesian cells are incomplete: "
                f"actual={len(element_tag_by_cell)}, expected={len(expected_cells)}"
            )
        ports.append(
            CornerPort(
                source_index=source_index,
                final_corner=corner,
                x_min_mm=final_x[0],
                x_max_mm=final_x[1],
                y_min_mm=final_y[0],
                y_max_mm=final_y[1],
                size_x_mm=dx,
                size_y_mm=dy,
                source_z_levels_mm=source_z_levels,
                final_z_levels_mm=final_z_levels,
                element_tags=tuple(sorted(element_tags)),
            )
        )
    return tuple(sorted(ports, key=lambda port: port.final_corner))


def _face_incidence(
    elements: Sequence[PackageElement],
) -> dict[tuple[int, ...], list[tuple[PackageElement, tuple[int, ...]]]]:
    incidences: dict[
        tuple[int, ...], list[tuple[PackageElement, tuple[int, ...]]]
    ] = defaultdict(list)
    for element in elements:
        for local_face in ELEMENT_SPECS[element.gmsh_type][2]:
            face = tuple(element.node_tags[index] for index in local_face)
            incidences[tuple(sorted(face))].append((element, face))
    return incidences


def _boundary_faces(
    elements: Sequence[PackageElement],
) -> tuple[tuple[int, ...], ...]:
    return tuple(
        owners[0][1]
        for owners in _face_incidence(elements).values()
        if len(owners) == 1
    )


def _horizontal_boundary_facets(
    elements: Sequence[PackageElement],
    registry: _NodeRegistry,
    z_value: float,
) -> tuple[tuple[int, ...], ...]:
    """Return deterministic, node-exact boundary facets on one Z plane."""

    facets = tuple(
        face
        for face in _boundary_faces(elements)
        if all(
            _close(registry.nodes_by_tag[tag].z, z_value)
            for tag in face
        )
    )
    return tuple(sorted(facets, key=lambda face: (tuple(sorted(face)), face)))


def _signed_xy_area(
    node_tags: Sequence[int],
    nodes_by_tag: Mapping[int, MeshNode],
) -> float:
    return 0.5 * sum(
        nodes_by_tag[node_tags[index]].x
        * nodes_by_tag[node_tags[(index + 1) % len(node_tags)]].y
        - nodes_by_tag[node_tags[(index + 1) % len(node_tags)]].x
        * nodes_by_tag[node_tags[index]].y
        for index in range(len(node_tags))
    )


def _horizontal_surface_cells(
    elements: Sequence[PackageElement],
    registry: _NodeRegistry,
    z_value: float,
) -> tuple[tuple[tuple[float, float], ...], ...]:
    cells: list[tuple[tuple[float, float], ...]] = []
    for face in _boundary_faces(elements):
        nodes = [registry.nodes_by_tag[tag] for tag in face]
        if not all(_close(node.z, z_value) for node in nodes):
            continue
        ordered = face if _signed_xy_area(face, registry.nodes_by_tag) > 0.0 else tuple(reversed(face))
        cells.append(tuple((registry.nodes_by_tag[tag].x, registry.nodes_by_tag[tag].y) for tag in ordered))
    if not cells:
        raise PackageBuildError(f"connected bump has no horizontal skin at z={z_value}")
    return tuple(cells)


def _cell_boundary_edges(
    cells: Sequence[Sequence[tuple[float, float]]],
) -> tuple[tuple[tuple[float, float], tuple[float, float]], ...]:
    occurrences: dict[
        tuple[tuple[float, float], tuple[float, float]],
        list[tuple[tuple[float, float], tuple[float, float]]],
    ] = defaultdict(list)
    for cell in cells:
        for index, first in enumerate(cell):
            second = cell[(index + 1) % len(cell)]
            first_key = _xy_key(*first)
            second_key = _xy_key(*second)
            key = tuple(sorted((first_key, second_key)))  # type: ignore[assignment]
            occurrences[key].append((first_key, second_key))
    nonmanifold = [key for key, values in occurrences.items() if len(values) > 2]
    if nonmanifold:
        raise PackageBuildError("planar cell union contains a non-manifold edge")
    return tuple(values[0] for values in occurrences.values() if len(values) == 1)


def _trace_single_boundary_loop(
    edges: Sequence[tuple[tuple[float, float], tuple[float, float]]],
) -> tuple[tuple[float, float], ...]:
    if not edges:
        raise PackageBuildError("cannot trace an empty planar boundary")
    next_points: dict[tuple[float, float], list[tuple[float, float]]] = defaultdict(list)
    for first, second in edges:
        next_points[first].append(second)
    if any(len(values) != 1 for values in next_points.values()):
        raise PackageBuildError("planar boundary is not one consistently oriented loop")
    start = min(next_points)
    loop = [start]
    current = start
    for _ in range(len(edges)):
        current = next_points[current][0]
        if current == start:
            break
        if current in loop:
            raise PackageBuildError("planar boundary closes on the wrong vertex")
        loop.append(current)
    if current != start or len(loop) != len(edges):
        raise PackageBuildError("planar cell union has multiple exterior loops")
    twice_area = sum(
        loop[index][0] * loop[(index + 1) % len(loop)][1]
        - loop[(index + 1) % len(loop)][0] * loop[index][1]
        for index in range(len(loop))
    )
    if twice_area < 0.0:
        loop.reverse()
    return tuple(loop)


def _axis_lines(start: float, end: float, spacing: float) -> tuple[float, ...]:
    count = round((end - start) / spacing)
    if count < 1 or not _close(start + count * spacing, end):
        raise PackageBuildError("structured package extent is not divisible by pitch")
    return tuple(start + index * spacing for index in range(count + 1))


def _uf_target_radial_offsets(
    width_mm: float,
    native_edge_mm: float,
    target_edge_mm: float,
    transition_distance_mm: float,
) -> tuple[float, ...]:
    """Grade one generated outward UF axis while retaining exact endpoints.

    The transition control is a physical distance, not a growth-factor hint.
    At an accumulated outward distance ``r`` the proposed next interval is
    linearly graded from the immutable-wall native size to the far target::

        h(r) = native + (target - native) * min(r / transition, 1)

    Thus a target-sized interval can only start at or beyond the requested
    transition distance.  The finite toe width may end before a full target
    interval is needed.
    """

    width = _finite(width_mm, field_name="UF radial width")
    native = _finite(native_edge_mm, field_name="UF locked-boundary edge size")
    target = _finite(target_edge_mm, field_name="UF radial target edge")
    transition = _finite(
        transition_distance_mm,
        field_name="UF radial transition distance",
    )
    if min(width, native, target, transition) <= 0.0:
        raise PackageBuildError("UF radial grading controls must be positive")
    first_size = min(native, target)
    if _close(first_size, target):
        layer_count = max(1, math.ceil(width / target))
        return tuple(width * index / layer_count for index in range(layer_count + 1))

    offsets = [0.0]
    while width - offsets[-1] > _COORDINATE_TOLERANCE_MM:
        distance = offsets[-1]
        fraction = min(distance / transition, 1.0)
        next_size = first_size + (target - first_size) * fraction
        if not math.isfinite(next_size) or next_size <= 0.0:
            raise PackageBuildError("UF radial grading produced an invalid interval")
        remaining = width - distance
        step = min(next_size, remaining)
        offsets.append(offsets[-1] + step)
        if len(offsets) > 10_000:
            raise PackageBuildError("UF radial grading exceeded its layer ceiling")
    offsets[-1] = width
    if len(offsets) >= 3:
        last = offsets[-1] - offsets[-2]
        previous = offsets[-2] - offsets[-3]
        # Equalize only wholly far-field tail cells.  Rebalancing inside the
        # transition would violate the cumulative-distance size law above.
        if last < 0.5 * previous and offsets[-3] >= transition:
            combined = offsets[-1] - offsets[-3]
            half = 0.5 * combined
            if half <= target + _COORDINATE_TOLERANCE_MM:
                offsets[-2] = offsets[-3] + half
    if any(
        upper <= lower
        for lower, upper in zip(offsets, offsets[1:])
    ):
        raise PackageBuildError("UF radial grading produced non-increasing offsets")
    return tuple(offsets)


def _corner_macro_cells(
    stack: ResolvedPackageStack,
    ports: Sequence[CornerPort],
    *,
    radial_offsets_mm: Sequence[float] | None = None,
) -> tuple[tuple[tuple[float, float], ...], ...]:
    x_inner_min, x_inner_max, y_inner_min, y_inner_max = stack.die_bounds_xy_mm
    cells: list[tuple[tuple[float, float], ...]] = []
    seen: set[tuple[tuple[float, float], ...]] = set()
    for port in ports:
        sx = 1.0 if "E" in port.final_corner else -1.0
        sy = 1.0 if "N" in port.final_corner else -1.0
        corner_x = x_inner_max if sx > 0.0 else x_inner_min
        corner_y = y_inner_max if sy > 0.0 else y_inner_min
        inward_x = port.x_max_mm - port.x_min_mm
        inward_y = port.y_max_mm - port.y_min_mm
        x_start, x_end = sorted(
            (corner_x - sx * inward_x, corner_x + sx * stack.uf_width_mm)
        )
        y_start, y_end = sorted(
            (corner_y - sy * inward_y, corner_y + sy * stack.uf_width_mm)
        )
        if radial_offsets_mm is None:
            x_lines = _axis_lines(x_start, x_end, port.size_x_mm)
            y_lines = _axis_lines(y_start, y_end, port.size_y_mm)
        else:
            offsets = tuple(radial_offsets_mm)
            if (
                len(offsets) < 2
                or not _close(offsets[0], 0.0)
                or not _close(offsets[-1], stack.uf_width_mm)
                or any(upper <= lower for lower, upper in zip(offsets, offsets[1:]))
            ):
                raise PackageBuildError("UF radial offsets are invalid")
            x_inward = _axis_lines(
                min(corner_x - sx * inward_x, corner_x),
                max(corner_x - sx * inward_x, corner_x),
                port.size_x_mm,
            )
            y_inward = _axis_lines(
                min(corner_y - sy * inward_y, corner_y),
                max(corner_y - sy * inward_y, corner_y),
                port.size_y_mm,
            )
            x_lines = tuple(
                sorted(
                    {
                        *x_inward,
                        *(corner_x + sx * offset for offset in offsets),
                    }
                )
            )
            y_lines = tuple(
                sorted(
                    {
                        *y_inward,
                        *(corner_y + sy * offset for offset in offsets),
                    }
                )
            )
        for x0, x1 in zip(x_lines, x_lines[1:]):
            for y0, y1 in zip(y_lines, y_lines[1:]):
                center_x = 0.5 * (x0 + x1)
                center_y = 0.5 * (y0 + y1)
                inside_die = (
                    x_inner_min < center_x < x_inner_max
                    and y_inner_min < center_y < y_inner_max
                )
                if inside_die:
                    continue
                cell = (
                    _xy_key(x0, y0),
                    _xy_key(x1, y0),
                    _xy_key(x1, y1),
                    _xy_key(x0, y1),
                )
                canonical = tuple(sorted(cell))
                if canonical in seen:
                    raise PackageBuildError("corner macro cells overlap")
                seen.add(canonical)
                cells.append(cell)
    return tuple(cells)


@dataclass(frozen=True, slots=True)
class _Bounds:
    x_min_mm: float
    x_max_mm: float
    y_min_mm: float
    y_max_mm: float


@dataclass(frozen=True, slots=True)
class _PackagePlanarDomain:
    central_cells: tuple[tuple[tuple[float, float], ...], ...]
    corner_cells: tuple[tuple[tuple[float, float], ...], ...]
    straight_uf_cells: tuple[tuple[tuple[float, float], ...], ...]
    residual_cells: tuple[tuple[tuple[float, float], ...], ...]
    protected_boundary: tuple[tuple[float, float], ...]

    @property
    def uf_control_cells(self) -> tuple[tuple[tuple[float, float], ...], ...]:
        """Planar cells shared exactly by the rings and the UF staircase."""

        return self.corner_cells + self.straight_uf_cells

    @property
    def exterior_cells(self) -> tuple[tuple[tuple[float, float], ...], ...]:
        return self.uf_control_cells + self.residual_cells

    @property
    def all_cells(self) -> tuple[tuple[tuple[float, float], ...], ...]:
        return self.central_cells + self.exterior_cells


def _build_package_planar_domain(
    stack: ResolvedPackageStack,
    ports: Sequence[CornerPort],
    central_cells: Sequence[tuple[tuple[float, float], ...]],
    *,
    far_field_size_mm: float,
    transition_distance_mm: float,
    uf_radial_offsets_mm: Sequence[float] | None = None,
    verbose: bool,
) -> _PackagePlanarDomain:
    corner_cells = _corner_macro_cells(
        stack,
        ports,
        radial_offsets_mm=uf_radial_offsets_mm,
    )
    straight_uf_cells = _straight_uf_cells(
        stack,
        ports,
        central_cells,
        radial_offsets_mm=uf_radial_offsets_mm,
    )
    uf_control_cells = corner_cells + straight_uf_cells
    canonical_control_cells = [
        tuple(sorted(_xy_key(*point) for point in cell))
        for cell in uf_control_cells
    ]
    if len(canonical_control_cells) != len(set(canonical_control_cells)):
        raise PackageBuildError("corner and straight UF control cells overlap")

    # Protect the complete UF background footprint before asking the planar
    # transition mesher for the far field.  These exact QUAD4 cells are reused
    # by substrate, both support rings and the UF builder.  Consequently no
    # residual TRI3 can lie underneath a UF base face.
    protected_cells = tuple(central_cells) + uf_control_cells
    boundary = _trace_single_boundary_loop(_cell_boundary_edges(protected_cells))
    x_min, x_max, y_min, y_max = stack.outer_bounds_xy_mm
    target_size = min(
        min(port.size_x_mm, port.size_y_mm) for port in ports
    )
    residual = generate_planar_transition_mesh(
        _Bounds(x_min, x_max, y_min, y_max),
        (TransitionRing(0, boundary, target_size),),
        far_field_size_mm=far_field_size_mm,
        transition_distance_mm=transition_distance_mm,
        verbose=verbose,
    )
    residual_cells: list[tuple[tuple[float, float], ...]] = []
    for connectivity in residual.triangles:
        cell = tuple(residual.coordinates_mm[index] for index in connectivity)
        area = sum(
            cell[index][0] * cell[(index + 1) % len(cell)][1]
            - cell[(index + 1) % len(cell)][0] * cell[index][1]
            for index in range(len(cell))
        )
        residual_cells.append(cell if area > 0.0 else tuple(reversed(cell)))
    if residual.quads:
        raise PackageBuildError("package residual transition must contain only TRI3")

    expected_area = stack.substrate_width_mm * stack.substrate_length_mm
    actual_area = sum(
        abs(
            0.5
            * sum(
                cell[index][0] * cell[(index + 1) % len(cell)][1]
                - cell[(index + 1) % len(cell)][0] * cell[index][1]
                for index in range(len(cell))
            )
        )
        for cell in (*protected_cells, *residual_cells)
    )
    if not math.isclose(actual_area, expected_area, rel_tol=1.0e-8, abs_tol=1.0e-10):
        raise PackageBuildError(
            f"package planar domain area mismatch: {actual_area} != {expected_area}"
        )
    return _PackagePlanarDomain(
        central_cells=tuple(central_cells),
        corner_cells=corner_cells,
        straight_uf_cells=straight_uf_cells,
        residual_cells=tuple(residual_cells),
        protected_boundary=boundary,
    )


def _axis_aligned_cell_bounds(
    cell: Sequence[tuple[float, float]],
    *,
    label: str,
) -> tuple[float, float, float, float]:
    if len(cell) != 4:
        raise PackageBuildError(f"{label} must contain QUAD4 cells")
    x_values = {point[0] for point in cell}
    y_values = {point[1] for point in cell}
    if len(x_values) != 2 or len(y_values) != 2:
        raise PackageBuildError(f"{label} must be axis-aligned Cartesian QUAD4")
    x_min, x_max = min(x_values), max(x_values)
    y_min, y_max = min(y_values), max(y_values)
    expected = {
        _xy_key(x_min, y_min),
        _xy_key(x_max, y_min),
        _xy_key(x_max, y_max),
        _xy_key(x_min, y_max),
    }
    if {_xy_key(*point) for point in cell} != expected:
        raise PackageBuildError(f"{label} does not contain four rectangle corners")
    return x_min, x_max, y_min, y_max


def _refined_axis_coordinates(
    coordinates: Sequence[float],
    protected_intervals: Sequence[tuple[float, float]],
    target_edge_mm: float,
) -> tuple[float, ...]:
    """Refine only where a new global line cannot split a locked face."""

    target = _positive_policy_length(
        target_edge_mm,
        field_name="orthogonal planar target edge",
    )
    values = sorted({_coordinate_key(value, 0.0)[0] for value in coordinates})
    added: list[float] = []
    for lower, upper in zip(values, values[1:]):
        count = max(1, math.ceil((upper - lower) / target))
        for index in range(1, count):
            candidate = lower + (upper - lower) * index / count
            if any(
                interval_lower + _COORDINATE_TOLERANCE_MM
                < candidate
                < interval_upper - _COORDINATE_TOLERANCE_MM
                for interval_lower, interval_upper in protected_intervals
            ):
                continue
            added.append(candidate)
    return tuple(sorted({_xy_key(value, 0.0)[0] for value in (*values, *added)}))


def _build_orthogonal_package_planar_domain(
    stack: ResolvedPackageStack,
    ports: Sequence[CornerPort],
    central_cells: Sequence[tuple[tuple[float, float], ...]],
    *,
    target_edge_mm: float,
    protected_domain: _PackagePlanarDomain | None = None,
) -> _PackagePlanarDomain:
    """Build one shared Cartesian QUAD partition for every adjacent owner.

    The exact protected Component/Frozen faces are installed first.  Residual
    cells are then filled from a tensor grid without inserting a line through
    any protected face.  This is the orthogonal surface-owner branch selected
    by generic adjacency negotiation; it is not an underfill-specific repair.
    """

    corner_cells = (
        _corner_macro_cells(stack, ports)
        if protected_domain is None
        else protected_domain.corner_cells
    )
    straight_uf_cells = (
        _straight_uf_cells(stack, ports, central_cells)
        if protected_domain is None
        else protected_domain.straight_uf_cells
    )
    protected_cells = tuple(central_cells) + corner_cells + straight_uf_cells
    protected_bounds = tuple(
        _axis_aligned_cell_bounds(cell, label="orthogonal protected planar mesh")
        for cell in protected_cells
    )
    protected_keys = {
        tuple(sorted(_xy_key(*point) for point in cell))
        for cell in protected_cells
    }
    if len(protected_keys) != len(protected_cells):
        raise PackageBuildError("orthogonal protected planar cells overlap")
    x_min, x_max, y_min, y_max = stack.outer_bounds_xy_mm
    x_coordinates = _refined_axis_coordinates(
        (x_min, x_max, *(point[0] for cell in protected_cells for point in cell)),
        tuple((bounds[0], bounds[1]) for bounds in protected_bounds),
        target_edge_mm,
    )
    y_coordinates = _refined_axis_coordinates(
        (y_min, y_max, *(point[1] for cell in protected_cells for point in cell)),
        tuple((bounds[2], bounds[3]) for bounds in protected_bounds),
        target_edge_mm,
    )
    residual: list[tuple[tuple[float, float], ...]] = []
    for x0, x1 in zip(x_coordinates, x_coordinates[1:]):
        for y0, y1 in zip(y_coordinates, y_coordinates[1:]):
            cell = (
                _xy_key(x0, y0),
                _xy_key(x1, y0),
                _xy_key(x1, y1),
                _xy_key(x0, y1),
            )
            key = tuple(sorted(cell))
            if key in protected_keys:
                continue
            overlap_area = 0.0
            for px0, px1, py0, py1 in protected_bounds:
                overlap_area += max(0.0, min(x1, px1) - max(x0, px0)) * max(
                    0.0,
                    min(y1, py1) - max(y0, py0),
                )
            if overlap_area > _COORDINATE_TOLERANCE_MM**2:
                raise PackageBuildError(
                    "orthogonal tensor grid would split a protected interface "
                    "face; the requested Cartesian topology is incompatible with "
                    "this locked partition"
                )
            residual.append(cell)
    actual_area = math.fsum(
        (max(point[0] for point in cell) - min(point[0] for point in cell))
        * (max(point[1] for point in cell) - min(point[1] for point in cell))
        for cell in (*protected_cells, *residual)
    )
    expected_area = stack.substrate_width_mm * stack.substrate_length_mm
    if not math.isclose(
        actual_area,
        expected_area,
        rel_tol=1.0e-10,
        abs_tol=1.0e-10,
    ):
        raise PackageBuildError(
            "orthogonal shared planar partition does not cover the package box"
        )
    boundary = _trace_single_boundary_loop(_cell_boundary_edges(protected_cells))
    return _PackagePlanarDomain(
        central_cells=tuple(central_cells),
        corner_cells=corner_cells,
        straight_uf_cells=straight_uf_cells,
        residual_cells=tuple(residual),
        protected_boundary=boundary,
    )


class _PlanBuilder:
    def __init__(self, registry: _NodeRegistry, imported: Sequence[PackageElement]) -> None:
        self.registry = registry
        self.elements: list[PackageElement] = list(imported)
        self.next_element_tag = max((element.tag for element in imported), default=0) + 1

    def add_element(
        self,
        gmsh_type: int,
        node_tags: Sequence[int],
        *,
        material: str,
        component: str,
        zone: str,
        generation_provenance: str = "selected_volume_backend",
    ) -> None:
        self.elements.append(
            PackageElement(
                tag=self.next_element_tag,
                gmsh_type=gmsh_type,
                node_tags=tuple(node_tags),
                material=material,
                component=component,
                zone=zone,
                origin=_TRANSITION_ORIGIN,
                owner_component=component,
                generation_provenance=generation_provenance,
            )
        )
        self.next_element_tag += 1

    def extrude_cells(
        self,
        cells: Sequence[Sequence[tuple[float, float]]],
        z_levels_mm: Sequence[float],
        *,
        material: str,
        component: str,
        zone: str,
    ) -> None:
        levels = tuple(z_levels_mm)
        if len(levels) < 2 or any(
            second <= first for first, second in zip(levels, levels[1:])
        ):
            raise PackageBuildError(f"invalid extrusion Z schedule for {zone}")
        tags_by_level: list[list[tuple[int, ...]]] = []
        for z_value in levels:
            level_cells: list[tuple[int, ...]] = []
            for cell in cells:
                level_cells.append(
                    tuple(self.registry.add(x, y, z_value) for x, y in cell)
                )
            tags_by_level.append(level_cells)
        for lower_cells, upper_cells in zip(tags_by_level, tags_by_level[1:]):
            for lower, upper in zip(lower_cells, upper_cells):
                if len(lower) == 3:
                    self.add_element(
                        6,
                        (*lower, *upper),
                        material=material,
                        component=component,
                        zone=zone,
                    )
                elif len(lower) == 4:
                    self.add_element(
                        5,
                        (*lower, *upper),
                        material=material,
                        component=component,
                        zone=zone,
                    )
                else:
                    raise PackageBuildError("only TRI3/QUAD4 planar cells can extrude")


@dataclass(frozen=True, slots=True)
class _HybridPrismStats:
    slab_count: int
    planar_cell_count: int
    tet4_count: int
    pyramid5_count: int


def _graded_interval_levels(
    start: float,
    end: float,
    *,
    first_size: float,
    growth: float,
    minimum_layers: int = 1,
) -> tuple[float, ...]:
    """Return an exact interval whose layer thicknesses grow geometrically."""

    start_value = _finite(start, field_name="graded interval start")
    end_value = _finite(end, field_name="graded interval end")
    first = _finite(first_size, field_name="graded interval first size")
    ratio = _finite(growth, field_name="graded interval growth")
    if (
        end_value <= start_value
        or first <= 0.0
        or ratio <= 1.0
        or isinstance(minimum_layers, bool)
        or not isinstance(minimum_layers, int)
        or minimum_layers < 1
    ):
        raise PackageBuildError(
            "graded interval requires positive extent/first size, growth > 1, "
            "and a positive integer minimum layer count"
        )
    extent = end_value - start_value
    weights = [min(first, extent)]
    while (
        len(weights) < minimum_layers
        or math.fsum(weights) + weights[-1] * ratio
        <= extent * (1.0 + 1.0e-12)
    ):
        weights.append(weights[-1] * ratio)
    scale = extent / math.fsum(weights)
    levels = [start_value]
    cumulative = start_value
    for weight in weights[:-1]:
        cumulative += weight * scale
        levels.append(cumulative)
    levels.append(end_value)
    if any(second <= first_value for first_value, second in zip(levels, levels[1:])):
        raise PackageBuildError("graded interval produced a non-positive layer")
    return tuple(levels)


def _hybrid_planar_cell(
    cell: Sequence[tuple[float, float]],
) -> tuple[dict[int, tuple[float, float]], PlanarCell]:
    coordinates = {
        index: _xy_key(*point) for index, point in enumerate(cell, start=1)
    }
    node_ids = tuple(coordinates)
    if len(node_ids) == 3:
        planar_cell = PlanarCell.tri3(node_ids)
    elif len(node_ids) == 4:
        planar_cell = PlanarCell.quad4(node_ids)
    else:
        raise PackageBuildError("hybrid prism supports only TRI3/QUAD4 footprints")
    return coordinates, planar_cell


def _add_hybrid_prism_layers(
    builder: _PlanBuilder,
    cells: Sequence[Sequence[tuple[float, float]]],
    z_levels_mm: Sequence[float],
    *,
    material: str,
    component: str,
    zone: str,
) -> _HybridPrismStats:
    """Fill each XY footprint and graded Z slab with checked PYR5/TET4 cells.

    Per-footprint kernels deliberately avoid the single, very-high-valence
    die-centre node produced by one whole-die star fill.  All horizontal and
    vertical QUAD4 shell facets are locked, so adjacent prisms share the same
    complete face instead of independently selecting a diagonal.
    """

    levels = tuple(
        _finite(value, field_name="hybrid transition Z level")
        for value in z_levels_mm
    )
    if len(levels) < 2 or any(
        second <= first for first, second in zip(levels, levels[1:])
    ):
        raise PackageBuildError("hybrid transition requires increasing Z levels")
    planar_cells = tuple(tuple(_xy_key(*point) for point in cell) for cell in cells)
    if not planar_cells:
        raise PackageBuildError("hybrid transition requires planar cells")

    tet4_count = 0
    pyramid5_count = 0
    for z_bottom, z_top in zip(levels, levels[1:]):
        for cell in planar_cells:
            coordinates, planar_cell = _hybrid_planar_cell(cell)
            bottom_ids = {
                planar_id: builder.registry.add(x, y, z_bottom)
                for planar_id, (x, y) in coordinates.items()
            }
            top_ids = {
                planar_id: builder.registry.add(x, y, z_top)
                for planar_id, (x, y) in coordinates.items()
            }
            kernel_xy = (
                math.fsum(point[0] for point in cell) / len(cell),
                math.fsum(point[1] for point in cell) / len(cell),
            )
            kernel_tag = builder.registry.add(
                kernel_xy[0],
                kernel_xy[1],
                0.5 * (z_bottom + z_top),
            )
            locked_faces = [
                LockedPrismFace.side(
                    (
                        planar_cell.node_ids[index],
                        planar_cell.node_ids[(index + 1) % len(planar_cell.node_ids)],
                    )
                )
                for index in range(len(planar_cell.node_ids))
            ]
            if len(planar_cell.node_ids) == 4:
                locked_faces.extend(
                    (
                        LockedPrismFace.bottom(planar_cell.node_ids),
                        LockedPrismFace.top(planar_cell.node_ids),
                    )
                )
            try:
                prism = fill_extruded_planar_prism(
                    coordinates,
                    (planar_cell,),
                    z_bottom,
                    z_top,
                    bottom_node_ids=bottom_ids,
                    top_node_ids=top_ids,
                    kernel_xy=kernel_xy,
                    kernel_node_id=kernel_tag,
                    locked_faces=locked_faces,
                )
            except HybridPrismError as error:
                raise PackageBuildError(
                    "hybrid thickness transition failed for "
                    f"{component} cell at z=[{z_bottom:.12g}, {z_top:.12g}]: "
                    f"{error}"
                ) from error
            for node_tag, coordinates_3d in prism.node_coordinates.items():
                registered = builder.registry.nodes_by_tag.get(node_tag)
                if registered is None or any(
                    not _close(first, second)
                    for first, second in zip(
                        registered.coordinates,
                        coordinates_3d,
                    )
                ):
                    raise PackageBuildError(
                        "hybrid prism changed an allocated boundary/kernel node"
                    )
            for element in prism.elements:
                if element.kind is StarElementKind.TET4:
                    gmsh_type = 4
                    tet4_count += 1
                elif element.kind is StarElementKind.PYRAMID5:
                    gmsh_type = 7
                    pyramid5_count += 1
                else:  # pragma: no cover - hybrid_bulk owns this enum
                    raise PackageBuildError(
                        f"unsupported hybrid element kind: {element.kind}"
                    )
                builder.add_element(
                    gmsh_type,
                    element.node_ids,
                    material=material,
                    component=component,
                    zone=zone,
                )
    return _HybridPrismStats(
        slab_count=len(levels) - 1,
        planar_cell_count=len(planar_cells),
        tet4_count=tet4_count,
        pyramid5_count=pyramid5_count,
    )


def _oriented_tri_base_towards_apex(
    face: Sequence[tuple[float, float, float]],
    apex: tuple[float, float, float],
) -> tuple[tuple[float, float, float], ...]:
    values = tuple(face)
    if len(values) != 3 or len({_coordinate_key(*point) for point in values}) != 3:
        raise PackageBuildError("conformal-hybrid ring TET4 base is invalid")
    first, second, third = values
    ab = tuple(second[axis] - first[axis] for axis in range(3))
    ac = tuple(third[axis] - first[axis] for axis in range(3))
    normal = (
        ab[1] * ac[2] - ab[2] * ac[1],
        ab[2] * ac[0] - ab[0] * ac[2],
        ab[0] * ac[1] - ab[1] * ac[0],
    )
    if math.fsum(
        normal[axis] * (apex[axis] - first[axis])
        for axis in range(3)
    ) < 0.0:
        values = tuple(reversed(values))
    return values


def _ring_sweep_element_coordinates(
    cells: Sequence[Sequence[tuple[float, float]]],
    z_levels_mm: Sequence[float],
) -> tuple[tuple[int, tuple[tuple[float, float, float], ...]], ...]:
    levels = tuple(
        _finite(value, field_name="ring conformal-hybrid Z level")
        for value in z_levels_mm
    )
    if len(levels) < 2 or any(
        upper <= lower for lower, upper in zip(levels, levels[1:])
    ):
        raise PackageBuildError(
            "conformal-hybrid ring requires increasing Z levels"
        )
    output: list[
        tuple[int, tuple[tuple[float, float, float], ...]]
    ] = []
    for raw_cell in cells:
        cell = tuple(_xy_key(*point) for point in raw_cell)
        if len(cell) not in {3, 4} or len(set(cell)) != len(cell):
            raise PackageBuildError(
                "conformal-hybrid ring accepts only distinct TRI3/QUAD4 cells"
            )
        gmsh_type = 6 if len(cell) == 3 else 5
        for lower_z, upper_z in zip(levels, levels[1:]):
            lower = tuple((x, y, lower_z) for x, y in cell)
            upper = tuple((x, y, upper_z) for x, y in cell)
            output.append((gmsh_type, (*lower, *upper)))
    if not output:
        raise PackageBuildError("conformal-hybrid ring sweep scaffold is empty")
    return tuple(output)


def _ring_candidate_quality_values(
    elements: Sequence[
        tuple[int, Sequence[tuple[float, float, float]]]
    ],
) -> dict[str, tuple[float, ...]]:
    """Return per-element metrics for mixed TET4/PYRAMID5 candidates."""

    candidates = tuple((gmsh_type, tuple(points)) for gmsh_type, points in elements)
    if not candidates or any(
        gmsh_type not in {4, 7}
        or len(points) != ELEMENT_SPECS[gmsh_type][1]
        for gmsh_type, points in candidates
    ):
        raise PackageBuildError(
            "conformal-hybrid ring quality candidates must be TET4/PYRAMID5"
        )
    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:  # pragma: no cover - dependency failure
        raise RuntimeError(
            "Gmsh is required to audit conformal-hybrid ring candidates"
        ) from error
    node_tag_by_key: dict[tuple[float, float, float], int] = {}
    coordinates_by_tag: dict[int, tuple[float, float, float]] = {}
    records_by_type: dict[int, list[tuple[int, tuple[int, ...]]]] = defaultdict(list)
    for element_tag, (gmsh_type, points) in enumerate(candidates, start=1):
        connectivity: list[int] = []
        for raw_point in points:
            point = tuple(float(value) for value in raw_point)
            if len(point) != 3 or any(not math.isfinite(value) for value in point):
                raise PackageBuildError(
                    "conformal-hybrid ring candidate contains a non-finite node"
                )
            key = _coordinate_key(*point)
            node_tag = node_tag_by_key.get(key)
            if node_tag is None:
                node_tag = len(node_tag_by_key) + 1
                node_tag_by_key[key] = node_tag
                coordinates_by_tag[node_tag] = point
            connectivity.append(node_tag)
        if len(connectivity) != len(set(connectivity)):
            raise PackageBuildError(
                "conformal-hybrid ring candidate contains a collapsed element"
            )
        records_by_type[gmsh_type].append((element_tag, tuple(connectivity)))

    with isolated_gmsh_model(
        gmsh,
        "__easymesh_ring_conformal_candidates",
        number_options={"General.Terminal": 0.0, "Mesh.ElementOrder": 1.0},
    ):
        entity = gmsh.model.addDiscreteEntity(3)
        node_tags = tuple(sorted(coordinates_by_tag))
        gmsh.model.mesh.addNodes(
            3,
            entity,
            list(node_tags),
            [
                value
                for tag in node_tags
                for value in coordinates_by_tag[tag]
            ],
        )
        for gmsh_type in sorted(records_by_type):
            records = records_by_type[gmsh_type]
            gmsh.model.mesh.addElementsByType(
                entity,
                gmsh_type,
                [tag for tag, _connectivity in records],
                [
                    node
                    for _tag, connectivity in records
                    for node in connectivity
                ],
            )
        ordered_tags = list(range(1, len(candidates) + 1))
        metrics: dict[str, tuple[float, ...]] = {}
        for name in ("minDetJac", "minSJ", "minSICN", "minSIGE"):
            values = tuple(
                float(value)
                for value in gmsh.model.mesh.getElementQualities(
                    ordered_tags,
                    name,
                )
            )
            if len(values) != len(candidates):
                raise PackageBuildError(
                    f"conformal-hybrid ring {name} evidence is incomplete"
                )
            metrics[name] = values
    return metrics


def _coordinate_volume_boundary_face_keys(
    elements: Sequence[
        tuple[int, Sequence[tuple[float, float, float]]]
    ],
) -> set[tuple[tuple[float, float, float], ...]]:
    """Return coordinate-keyed boundary faces and reject non-manifold input."""

    incidence: Counter[tuple[tuple[float, float, float], ...]] = Counter()
    for gmsh_type, raw_coordinates in elements:
        if gmsh_type not in ELEMENT_SPECS:
            raise PackageBuildError("coordinate boundary audit has unknown element type")
        coordinates = tuple(raw_coordinates)
        expected_nodes = ELEMENT_SPECS[gmsh_type][1]
        if len(coordinates) != expected_nodes:
            raise PackageBuildError(
                "coordinate boundary audit has invalid element connectivity"
            )
        for local_face in ELEMENT_SPECS[gmsh_type][2]:
            key = tuple(
                sorted(
                    _coordinate_key(*coordinates[index])
                    for index in local_face
                )
            )
            if len(key) not in {3, 4} or len(set(key)) != len(key):
                raise PackageBuildError(
                    "coordinate boundary audit found a collapsed face"
                )
            incidence[key] += 1
    if any(owner_count > 2 for owner_count in incidence.values()):
        raise PackageBuildError(
            "coordinate boundary audit found a non-manifold volume face"
        )
    return {key for key, owner_count in incidence.items() if owner_count == 1}


def _ring_conformal_hybrid_coordinates(
    scaffold_elements: Sequence[
        tuple[int, Sequence[tuple[float, float, float]]]
    ],
) -> tuple[
    tuple[tuple[int, tuple[tuple[float, float, float], ...]], ...],
    dict[str, int],
]:
    """Quality-select a face-preserving star fill for each ring prism."""

    scaffold = tuple(
        (gmsh_type, tuple(coordinates))
        for gmsh_type, coordinates in scaffold_elements
    )
    if not scaffold or any(
        gmsh_type not in {5, 6}
        or len(coordinates) != ELEMENT_SPECS[gmsh_type][1]
        for gmsh_type, coordinates in scaffold
    ):
        raise PackageBuildError(
            "conformal-hybrid ring requires a HEX8/WEDGE6 sweep scaffold"
        )
    candidates: list[
        tuple[int, tuple[tuple[float, float, float], ...]]
    ] = []
    ranges: list[tuple[int, int]] = []
    for gmsh_type, coordinates in scaffold:
        apex = tuple(
            math.fsum(point[axis] for point in coordinates) / len(coordinates)
            for axis in range(3)
        )
        start = len(candidates)
        for local_face in ELEMENT_SPECS[gmsh_type][2]:
            face = tuple(coordinates[index] for index in local_face)
            if len(face) == 3:
                base = _oriented_tri_base_towards_apex(face, apex)
                candidates.append((4, (*base, apex)))
            else:
                base = _uf_oriented_pyramid_base(face, apex)
                candidates.append((7, (*base, apex)))
        ranges.append((start, len(candidates)))
    metrics = _ring_candidate_quality_values(candidates)
    output: list[
        tuple[int, tuple[tuple[float, float, float], ...]]
    ] = []
    converted_hex8 = 0
    converted_wedge6 = 0
    fallback_hex8 = 0
    fallback_wedge6 = 0
    generated_tet4 = 0
    generated_pyramid5 = 0
    for scaffold_element, (start, end) in zip(scaffold, ranges):
        accepted = (
            all(
                math.isfinite(metrics[name][index])
                for name in ("minDetJac", "minSJ", "minSICN", "minSIGE")
                for index in range(start, end)
            )
            and all(
                metrics["minDetJac"][index] > 0.0
                for index in range(start, end)
            )
            and all(
                metrics[name][index] >= _HYBRID_DEMO_MIN_QUALITY
                for name in ("minSJ", "minSICN", "minSIGE")
                for index in range(start, end)
            )
        )
        source_type = scaffold_element[0]
        if accepted:
            selected = candidates[start:end]
            output.extend(selected)
            generated_tet4 += sum(value[0] == 4 for value in selected)
            generated_pyramid5 += sum(value[0] == 7 for value in selected)
            if source_type == 5:
                converted_hex8 += 1
            else:
                converted_wedge6 += 1
        else:
            output.append(scaffold_element)
            if source_type == 5:
                fallback_hex8 += 1
            else:
                fallback_wedge6 += 1
    if generated_tet4 + generated_pyramid5 <= 0:
        raise PackageBuildError(
            "conformal-hybrid ring could not convert any prism above the 0.03 floor"
        )
    scaffold_boundary = _coordinate_volume_boundary_face_keys(scaffold)
    output_boundary = _coordinate_volume_boundary_face_keys(output)
    if output_boundary != scaffold_boundary:
        raise PackageBuildError(
            "conformal-hybrid ring changed its scaffold boundary or created a cavity"
        )
    scaffold_hex8 = sum(gmsh_type == 5 for gmsh_type, _coordinates in scaffold)
    scaffold_wedge6 = len(scaffold) - scaffold_hex8
    if (
        scaffold_hex8 != converted_hex8 + fallback_hex8
        or scaffold_wedge6 != converted_wedge6 + fallback_wedge6
        or generated_tet4 != 2 * converted_wedge6
        or generated_pyramid5 != 6 * converted_hex8 + 3 * converted_wedge6
    ):
        raise PackageBuildError(
            "conformal-hybrid ring mother-prism conservation audit failed"
        )
    return tuple(output), {
        "scaffold_hex8_count": scaffold_hex8,
        "scaffold_wedge6_count": scaffold_wedge6,
        "converted_hex8_count": converted_hex8,
        "converted_wedge6_count": converted_wedge6,
        "quality_fallback_hex8_count": fallback_hex8,
        "quality_fallback_wedge6_count": fallback_wedge6,
        "generated_tet4_count": generated_tet4,
        "generated_pyramid5_count": generated_pyramid5,
    }


def _add_ring_conformal_hybrid(
    builder: _PlanBuilder,
    cells: Sequence[Sequence[tuple[float, float]]],
    z_levels_mm: Sequence[float],
    *,
    bounds_xy_mm: Sequence[float],
    opening_bounds_xy_mm: Sequence[float],
    target_edge_mm: float,
    transition_distance_mm: float,
    material: str,
    component: str,
    zone: str,
    verbose: bool,
) -> dict[str, int]:
    """Append a rectangular frame whose 3-D connectivity is owned by Gmsh.

    The caller supplies the already-negotiated bottom/top surface partition.
    EasyMesh installs those exact facets on the analytic frame and never
    constructs a sweep scaffold or star-fill candidate for this branch.
    """

    levels = tuple(
        _finite(value, field_name="direct frame Z level")
        for value in z_levels_mm
    )
    if len(levels) < 2 or any(
        upper <= lower for lower, upper in zip(levels, levels[1:])
    ):
        raise PackageBuildError(
            "direct conformal frame requires increasing Z levels"
        )
    try:
        outer_x_min, outer_x_max, outer_y_min, outer_y_max = tuple(
            float(value) for value in bounds_xy_mm
        )
        inner_x_min, inner_x_max, inner_y_min, inner_y_max = tuple(
            float(value) for value in opening_bounds_xy_mm
        )
    except (TypeError, ValueError) as error:
        raise PackageBuildError(
            "direct conformal frame bounds must contain four finite values"
        ) from error
    geometry = RectangularFrameGeometry(
        outer_x_min,
        outer_x_max,
        outer_y_min,
        outer_y_max,
        inner_x_min,
        inner_x_max,
        inner_y_min,
        inner_y_max,
    )
    bottom_coordinates, bottom_facets = _registered_planar_facets(
        builder.registry,
        cells,
        levels[0],
    )
    top_coordinates, top_facets = _registered_planar_facets(
        builder.registry,
        cells,
        levels[-1],
    )
    locked_coordinates = {**bottom_coordinates, **top_coordinates}
    try:
        volume = generate_rectangular_frame_conformal_hybrid(
            locked_coordinates,
            {
                "bottom": bottom_facets,
                "top": top_facets,
            },
            geometry,
            levels[0],
            levels[-1],
            target_size_mm=target_edge_mm,
            transition_distance_mm=transition_distance_mm,
            minimum_quality=_HYBRID_DEMO_MIN_QUALITY,
            verbose=verbose,
        )
    except ConstrainedHybridError as error:
        raise PackageBuildError(
            f"direct OCC/Gmsh conformal frame failed for {component}: {error}"
        ) from error

    global_tag_by_local: dict[int, int] = {}
    for local_tag, coordinates in volume.node_coordinates.items():
        source_tag = volume.source_node_id_by_local_id.get(local_tag)
        if source_tag is not None:
            source_node = builder.registry.nodes_by_tag.get(source_tag)
            if source_node is None or any(
                not _close(actual, expected)
                for actual, expected in zip(
                    source_node.coordinates,
                    coordinates,
                )
            ):
                raise PackageBuildError(
                    "direct conformal frame changed a negotiated surface node"
                )
            global_tag_by_local[local_tag] = source_tag
        else:
            global_tag_by_local[local_tag] = builder.registry.add(*coordinates)
    for element in volume.elements:
        builder.add_element(
            element.gmsh_type,
            tuple(global_tag_by_local[tag] for tag in element.node_ids),
            material=material,
            component=component,
            zone=zone,
        )
    return {
        "gmsh_owned_connectivity": 1,
        "locked_bottom_face_count": len(bottom_facets),
        "locked_top_face_count": len(top_facets),
        "generated_tet4_count": volume.tet4_count,
        "generated_wedge6_count": volume.wedge6_count,
        "generated_pyramid5_count": volume.pyramid5_count,
        "minimum_sicn_ppm": round(volume.minimum_sicn * 1_000_000),
        "minimum_sige_ppm": round(volume.minimum_sige * 1_000_000),
        "minimum_scaled_jacobian_ppm": round(
            volume.minimum_scaled_jacobian * 1_000_000
        ),
    }


def _registered_planar_facets(
    registry: _NodeRegistry,
    cells: Sequence[Sequence[tuple[float, float]]],
    z_value: float,
) -> tuple[dict[int, tuple[float, float, float]], tuple[tuple[int, ...], ...]]:
    """Resolve one generated planar partition to its exact package node tags."""

    coordinates: dict[int, tuple[float, float, float]] = {}
    facets: list[tuple[int, ...]] = []
    for cell in cells:
        if len(cell) not in {3, 4}:
            raise PackageBuildError("hybrid docking accepts only TRI3/QUAD4 cells")
        facet = tuple(registry.add(x, y, z_value) for x, y in cell)
        if len(set(facet)) != len(facet):
            raise PackageBuildError("hybrid docking facet contains a repeated node")
        for tag in facet:
            coordinates[tag] = registry.nodes_by_tag[tag].coordinates
        facets.append(facet)
    if len({tuple(sorted(facet)) for facet in facets}) != len(facets):
        raise PackageBuildError("hybrid docking facets are not unique")
    return coordinates, tuple(facets)


def _append_constrained_hybrid_volume(
    builder: _PlanBuilder,
    cells: Sequence[Sequence[tuple[float, float]]],
    bounds_xy_mm: Sequence[float],
    interface_z_mm: float,
    far_z_mm: float,
    *,
    maximum_size_mm: float,
    near_size_mm: float,
    transition_distance_mm: float,
    material: str,
    component: str,
    zone: str,
    verbose: bool,
    locked_side_node_coordinates: Mapping[int, Sequence[float]] | None = None,
    locked_side_facets: Sequence[Sequence[int]] = (),
) -> PackageHybridRegion:
    """Generate and append one exact-boundary, genuinely XYZ-graded bulk."""

    docking_coordinates, docking_facets = _registered_planar_facets(
        builder.registry,
        cells,
        interface_z_mm,
    )
    side_coordinates = dict(locked_side_node_coordinates or {})
    side_facets = tuple(tuple(facet) for facet in locked_side_facets)
    if bool(side_coordinates) != bool(side_facets):
        raise PackageBuildError(
            "hybrid locked-side coordinates and facets must both be empty or non-empty"
        )
    if side_facets:
        side_node_ids = {tag for facet in side_facets for tag in facet}
        missing_coordinates = side_node_ids - (
            set(docking_coordinates) | set(side_coordinates)
        )
        if missing_coordinates:
            raise PackageBuildError(
                "hybrid locked-side facets reference nodes without coordinates"
            )
        if set(side_coordinates) - side_node_ids:
            raise PackageBuildError(
                "hybrid locked-side coordinates contain unused nodes"
            )
        if any(len(facet) not in {3, 4} for facet in side_facets):
            raise PackageBuildError(
                "hybrid locked-side accepts only TRI3/QUAD4 facets"
            )
        if any(len(set(facet)) != len(facet) for facet in side_facets):
            raise PackageBuildError(
                "hybrid locked-side facet contains a repeated node"
            )
        if len({tuple(sorted(facet)) for facet in side_facets}) != len(side_facets):
            raise PackageBuildError("hybrid locked-side facets are not unique")
        for tag, raw_point in side_coordinates.items():
            registered = builder.registry.nodes_by_tag.get(tag)
            if registered is None:
                raise PackageBuildError(
                    "hybrid locked-side coordinate references an unregistered node"
                )
            point = tuple(raw_point)
            if len(point) != 3 or any(
                not _close(actual, expected)
                for actual, expected in zip(registered.coordinates, point)
            ):
                raise PackageBuildError(
                    "hybrid locked-side coordinate differs from its package node"
                )
    try:
        volume = generate_locked_box_hybrid(
            docking_coordinates,
            docking_facets,
            bounds_xy_mm,
            interface_z_mm,
            far_z_mm,
            maximum_size_mm=maximum_size_mm,
            near_size_mm=near_size_mm,
            transition_distance_mm=transition_distance_mm,
            locked_side_node_coordinates=side_coordinates or None,
            locked_side_facets=side_facets,
            verbose=verbose,
        )
    except ConstrainedHybridError as error:
        raise PackageBuildError(
            f"constrained XYZ hybrid meshing failed for {component}: {error}"
        ) from error

    global_by_local: dict[int, int] = {}
    for local_id in sorted(volume.node_coordinates):
        point = volume.node_coordinates[local_id]
        source_id = volume.source_node_id_by_local_id.get(local_id)
        if source_id is not None:
            registered = builder.registry.nodes_by_tag.get(source_id)
            if registered is None or any(
                not _close(first, second)
                for first, second in zip(registered.coordinates, point)
            ):
                raise PackageBuildError(
                    f"hybrid {component} changed a locked docking node"
                )
            global_by_local[local_id] = source_id
            continue
        existing = builder.registry.tag_at(*point)
        if existing is not None:
            raise PackageBuildError(
                f"hybrid {component} generated an undeclared coincident node"
            )
        global_by_local[local_id] = builder.registry.add(*point)

    for element in volume.elements:
        builder.add_element(
            element.gmsh_type,
            tuple(global_by_local[node_id] for node_id in element.node_ids),
            material=material,
            component=component,
            zone=zone,
        )

    locked_bottom_face_count = volume.locked_bottom_face_count
    locked_side_face_count = volume.locked_side_face_count
    if locked_bottom_face_count != len(docking_facets):
        raise PackageBuildError(
            f"hybrid {component} changed the locked bottom-face count"
        )
    if locked_side_face_count != len(side_facets):
        raise PackageBuildError(
            f"hybrid {component} changed the locked side-face count"
        )
    if volume.locked_face_count != locked_bottom_face_count + locked_side_face_count:
        raise PackageBuildError(
            f"hybrid {component} reports inconsistent locked-face counts"
        )
    return PackageHybridRegion(
        zone=zone,
        interface_z_mm=interface_z_mm,
        far_z_mm=far_z_mm,
        maximum_size_mm=maximum_size_mm,
        near_size_mm=near_size_mm,
        locked_face_count=volume.locked_face_count,
        locked_bottom_face_count=locked_bottom_face_count,
        locked_side_face_count=locked_side_face_count,
        far_face_count=volume.far_face_count,
        node_count=len(volume.node_coordinates),
        element_count=len(volume.elements),
        tet4_count=volume.tet4_count,
        pyramid5_count=volume.pyramid5_count,
        near_median_edge_mm=volume.near_median_edge_mm,
        far_median_edge_mm=volume.far_median_edge_mm,
        growth_ratio_x=volume.growth_by_axis["x"].ratio,
        growth_ratio_y=volume.growth_by_axis["y"].ratio,
        growth_ratio_z=volume.growth_by_axis["z"].ratio,
        minimum_sicn=volume.minimum_sicn,
        minimum_sige=volume.minimum_sige,
        minimum_scaled_jacobian=volume.minimum_scaled_jacobian,
        generated_node_count=(
            len(volume.node_coordinates) - len(volume.source_node_id_by_local_id)
        ),
        random_seed=volume.random_seed,
    )


def _frozen_uf_inner_wall_facets(
    imported: Sequence[PackageElement],
    registry: _NodeRegistry,
    stack: ResolvedPackageStack,
) -> tuple[tuple[int, ...], ...]:
    """Extract only the immutable C4 wall trace touched by the lower UF."""

    incidence = _face_incidence(imported)
    boundary = tuple(
        owners[0][1]
        for owners in incidence.values()
        if len(owners) == 1
    )
    facets = tuple(
        face
        for face in boundary
        if _is_die_inner_wall_face(
            face,
            registry,
            stack,
            stack.uf_base_mm,
            stack.bump_top_mm,
        )
    )
    if not facets:
        raise PackageBuildError("Frozen UF inner-wall trace is empty")
    if any(len(facet) not in {3, 4} for facet in facets):
        raise PackageBuildError(
            "Frozen UF inner-wall trace contains a non-TRI3/QUAD4 facet"
        )
    if len({tuple(sorted(facet)) for facet in facets}) != len(facets):
        raise PackageBuildError("Frozen UF inner-wall trace contains duplicate facets")
    return tuple(sorted(facets, key=lambda face: tuple(sorted(face))))


def _uf_trace_z_levels_from_locked_side_surface(
    locked_side_facets: Sequence[Sequence[int]],
    registry: _NodeRegistry,
    stack: ResolvedPackageStack,
) -> tuple[float, ...]:
    """Recover the lower-UF sweep schedule from the exact Frozen wall only.

    A conformal HEX8 sweep requires the side surface to be a tensor
    product of one closed XY trace and one shared Z schedule.  Proving that
    property here prevents any fallback to ``CornerPort.source_z_levels_mm``
    or to Frozen volume connectivity as a generated-volume template.
    """

    facets = tuple(tuple(facet) for facet in locked_side_facets)
    if not facets:
        raise PackageBuildError("trace-only UF side surface is empty")
    if any(len(facet) != 4 for facet in facets):
        raise PackageBuildError(
            "trace-only UF fresh sweep requires a QUAD4 locked side surface"
        )
    canonical_facets = tuple(tuple(sorted(facet)) for facet in facets)
    if len(set(canonical_facets)) != len(canonical_facets):
        raise PackageBuildError("trace-only UF side surface contains duplicate faces")

    z_by_key: dict[float, float] = {}
    for facet in facets:
        if not _is_die_inner_wall_face(
            facet,
            registry,
            stack,
            stack.uf_base_mm,
            stack.bump_top_mm,
        ):
            raise PackageBuildError(
                "trace-only UF locked side face escapes the declared die wall"
            )
        for tag in facet:
            node = registry.nodes_by_tag.get(tag)
            if node is None:
                raise PackageBuildError(
                    "trace-only UF side surface references an unknown node"
                )
            z_key = round(node.z, _COORDINATE_DIGITS)
            existing = z_by_key.setdefault(z_key, node.z)
            if not _close(existing, node.z):
                raise PackageBuildError(
                    "trace-only UF side surface has ambiguous Z coordinates"
                )
    ordered_z_keys = tuple(sorted(z_by_key))
    levels = tuple(z_by_key[key] for key in ordered_z_keys)
    if (
        len(levels) < 2
        or not _close(levels[0], stack.uf_base_mm)
        or not _close(levels[-1], stack.bump_top_mm)
        or any(upper <= lower for lower, upper in zip(levels, levels[1:]))
    ):
        raise PackageBuildError(
            "trace-only UF side surface does not span one strict base-to-top Z schedule"
        )
    z_index = {key: index for index, key in enumerate(ordered_z_keys)}
    edges_by_interval: dict[
        int,
        set[tuple[tuple[float, float], tuple[float, float]]],
    ] = defaultdict(set)
    for facet in facets:
        nodes_by_z: dict[float, list[MeshNode]] = defaultdict(list)
        for tag in facet:
            node = registry.nodes_by_tag[tag]
            nodes_by_z[round(node.z, _COORDINATE_DIGITS)].append(node)
        if len(nodes_by_z) != 2 or any(
            len(nodes) != 2 for nodes in nodes_by_z.values()
        ):
            raise PackageBuildError(
                "trace-only UF side QUAD does not connect exactly two Z levels"
            )
        lower_key, upper_key = sorted(nodes_by_z)
        lower_index = z_index[lower_key]
        if z_index[upper_key] != lower_index + 1:
            raise PackageBuildError(
                "trace-only UF side QUAD skips a locked surface Z level"
            )
        lower_xy = tuple(sorted(_xy_key(node.x, node.y) for node in nodes_by_z[lower_key]))
        upper_xy = tuple(sorted(_xy_key(node.x, node.y) for node in nodes_by_z[upper_key]))
        if lower_xy != upper_xy or lower_xy[0] == lower_xy[1]:
            raise PackageBuildError(
                "trace-only UF side QUAD is not a vertical extrusion of one XY edge"
            )
        edge = (lower_xy[0], lower_xy[1])
        if edge in edges_by_interval[lower_index]:
            raise PackageBuildError(
                "trace-only UF side surface repeats an XY edge in one Z interval"
            )
        edges_by_interval[lower_index].add(edge)
    if set(edges_by_interval) != set(range(len(levels) - 1)):
        raise PackageBuildError(
            "trace-only UF side surface leaves an uncovered Z interval"
        )
    reference_edges = edges_by_interval[0]
    if not reference_edges or any(
        edges != reference_edges for edges in edges_by_interval.values()
    ):
        raise PackageBuildError(
            "trace-only UF side surface changes XY topology between Z intervals"
        )
    adjacency: dict[tuple[float, float], set[tuple[float, float]]] = defaultdict(set)
    for first, second in reference_edges:
        adjacency[first].add(second)
        adjacency[second].add(first)
    if any(len(neighbors) != 2 for neighbors in adjacency.values()):
        raise PackageBuildError(
            "trace-only UF side surface XY trace is not a closed two-manifold loop"
        )
    visited: set[tuple[float, float]] = set()
    pending = [min(adjacency)]
    while pending:
        point = pending.pop()
        if point in visited:
            continue
        visited.add(point)
        pending.extend(adjacency[point] - visited)
    if visited != set(adjacency):
        raise PackageBuildError(
            "trace-only UF side surface XY trace contains multiple loops"
        )
    return levels


def _uf_locked_side_xy_edge_keys(
    locked_side_facets: Sequence[Sequence[int]],
    registry: _NodeRegistry,
) -> set[tuple[tuple[float, float], tuple[float, float]]]:
    """Return the immutable XY edge trace underlying all locked wall QUADs."""

    edges: set[tuple[tuple[float, float], tuple[float, float]]] = set()
    for facet in locked_side_facets:
        xy = tuple(
            sorted(
                {
                    _xy_key(
                        registry.nodes_by_tag[tag].x,
                        registry.nodes_by_tag[tag].y,
                    )
                    for tag in facet
                }
            )
        )
        if len(xy) != 2:
            raise PackageBuildError(
                "trace-only UF locked wall face does not reduce to one XY edge"
            )
        edges.add((xy[0], xy[1]))
    if not edges:
        raise PackageBuildError("trace-only UF locked wall XY trace is empty")
    return edges


def _append_direct_gmsh_uf_volume(
    builder: _PlanBuilder,
    envelope: RectangularUfEnvelope,
    z_min_mm: float,
    z_max_mm: float,
    locked_facets_by_side: Mapping[str, Sequence[Sequence[int]]],
    *,
    target_size_mm: float,
    near_size_mm: float,
    transition_distance_mm: float,
    material: str,
    component: str,
    zone: str,
    verbose: bool,
) -> tuple[
    GmshUfConformalVolume,
    Mapping[str, tuple[tuple[int, ...], ...]],
    tuple[PackageElement, ...],
]:
    """Install named boundary locks and append only Gmsh-owned UF elements."""

    normalized_locks = {
        side: tuple(tuple(int(node) for node in facet) for facet in facets)
        for side, facets in locked_facets_by_side.items()
        if facets
    }
    referenced = {
        node
        for facets in normalized_locks.values()
        for facet in facets
        for node in facet
    }
    locked_coordinates: dict[int, tuple[float, float, float]] = {}
    for node in referenced:
        registered = builder.registry.nodes_by_tag.get(node)
        if registered is None:
            raise PackageBuildError(
                "direct UF lock references an unknown package node"
            )
        locked_coordinates[node] = registered.coordinates
    try:
        volume = generate_rectangular_uf_conformal_hybrid(
            locked_coordinates,
            normalized_locks,
            envelope,
            z_min_mm,
            z_max_mm,
            target_size_mm=target_size_mm,
            near_size_mm=near_size_mm,
            transition_distance_mm=transition_distance_mm,
            minimum_quality=_HYBRID_DEMO_MIN_QUALITY,
            random_seeds=tuple(range(1, 13)),
            verbose=verbose,
        )
    except ConstrainedHybridError as error:
        raise PackageBuildError(
            f"direct OCC/Gmsh conformal volume failed for {component}: {error}"
        ) from error

    global_by_local: dict[int, int] = {}
    for local_id in sorted(volume.node_coordinates):
        point = volume.node_coordinates[local_id]
        source_id = volume.source_node_id_by_local_id.get(local_id)
        if source_id is not None:
            registered = builder.registry.nodes_by_tag.get(source_id)
            if registered is None or any(
                not _close(first, second)
                for first, second in zip(registered.coordinates, point)
            ):
                raise PackageBuildError(
                    "direct UF backend changed a negotiated surface node"
                )
            global_by_local[local_id] = source_id
            continue
        existing = builder.registry.tag_at(*point)
        if existing is not None:
            raise PackageBuildError(
                "direct UF backend generated an undeclared coincident node"
            )
        global_by_local[local_id] = builder.registry.add(*point)

    start = len(builder.elements)
    for element in volume.elements:
        builder.add_element(
            element.gmsh_type,
            tuple(global_by_local[node] for node in element.node_ids),
            material=material,
            component=component,
            zone=zone,
        )
    appended = tuple(builder.elements[start:])
    mapped_boundaries = {
        "base": tuple(
            tuple(global_by_local[node] for node in facet)
            for facet in volume.base_facets
        ),
        "cap": tuple(
            tuple(global_by_local[node] for node in facet)
            for facet in volume.cap_facets
        ),
        "die_wall": tuple(
            tuple(global_by_local[node] for node in facet)
            for facet in volume.die_wall_facets
        ),
        "free_surface": tuple(
            tuple(global_by_local[node] for node in facet)
            for facet in volume.free_surface_facets
        ),
    }
    return volume, mapped_boundaries, appended


def _group_uf_die_wall_facets_by_side(
    facets: Sequence[Sequence[int]],
    registry: _NodeRegistry,
    envelope: RectangularUfEnvelope,
) -> dict[str, tuple[tuple[int, ...], ...]]:
    """Classify exact wall facets by geometry, without component-role names."""

    planes = {
        "die_x_min": (0, envelope.center_x - envelope.half_die_width),
        "die_x_max": (0, envelope.center_x + envelope.half_die_width),
        "die_y_min": (1, envelope.center_y - envelope.half_die_length),
        "die_y_max": (1, envelope.center_y + envelope.half_die_length),
    }
    grouped: dict[str, list[tuple[int, ...]]] = {
        side: [] for side in planes
    }
    for raw_facet in facets:
        facet = tuple(int(node) for node in raw_facet)
        if len(facet) not in {3, 4} or len(set(facet)) != len(facet):
            raise PackageBuildError(
                "direct UF wall lock must contain TRI3/QUAD4 facets"
            )
        points: list[tuple[float, float, float]] = []
        for node in facet:
            registered = registry.nodes_by_tag.get(node)
            if registered is None:
                raise PackageBuildError(
                    "direct UF wall lock references an unknown node"
                )
            points.append(registered.coordinates)
        matches = tuple(
            side
            for side, (axis, plane) in planes.items()
            if all(_close(point[axis], plane) for point in points)
        )
        if len(matches) != 1:
            raise PackageBuildError(
                "direct UF wall facet does not lie on exactly one analytic die side"
            )
        grouped[matches[0]].append(facet)
    return {
        side: tuple(values)
        for side, values in grouped.items()
        if values
    }


def _append_uf_upper_hybrid_volume(
    builder: _PlanBuilder,
    docking_facets: Sequence[Sequence[int]],
    stack: ResolvedPackageStack,
    cap_z_mm: float,
    *,
    maximum_size_mm: float,
    near_size_mm: float,
    transition_distance_mm: float,
    material: str,
    verbose: bool,
) -> tuple[PackageHybridRegion, tuple[tuple[int, ...], ...], tuple[PackageElement, ...]]:
    """Append a tapered UF slice whose 3-D connectivity is owned by Gmsh."""

    facets = tuple(tuple(facet) for facet in docking_facets)
    if not facets or any(len(facet) != 4 for facet in facets):
        raise PackageBuildError(
            "upper-UF hybrid requires a non-empty QUAD4 docking annulus"
        )
    if len({tuple(sorted(facet)) for facet in facets}) != len(facets):
        raise PackageBuildError("upper-UF docking facets are not unique")
    envelope = RectangularUfEnvelope(
        die_width=stack.uf_die_width_mm,
        die_length=stack.uf_die_length_mm,
        base_z=stack.uf_base_mm,
        height=stack.uf_height_mm,
        fillet_width=stack.uf_width_mm,
    )
    volume, boundaries, appended = _append_direct_gmsh_uf_volume(
        builder,
        envelope,
        stack.bump_top_mm,
        cap_z_mm,
        {"base": facets},
        target_size_mm=maximum_size_mm,
        near_size_mm=near_size_mm,
        transition_distance_mm=transition_distance_mm,
        material=material,
        component="UF_FILLET",
        zone="UF_XYZ_HYBRID_BULK",
        verbose=verbose,
    )
    die_wall_facets = boundaries["die_wall"]
    locked_base_facets = volume.locked_facets_by_side.get("base", ())
    if len(locked_base_facets) != len(facets):
        raise PackageBuildError("upper-UF hybrid changed the docking-face count")
    if not die_wall_facets:
        raise PackageBuildError("upper-UF hybrid exposes no Si contact wall")
    nominal_growth = maximum_size_mm / near_size_mm
    return (
        PackageHybridRegion(
            zone="UF_XYZ_HYBRID_BULK",
            interface_z_mm=stack.bump_top_mm,
            far_z_mm=cap_z_mm,
            maximum_size_mm=maximum_size_mm,
            near_size_mm=near_size_mm,
            locked_face_count=volume.locked_face_count,
            locked_bottom_face_count=len(locked_base_facets),
            locked_side_face_count=0,
            far_face_count=len(volume.cap_facets),
            node_count=volume.node_count,
            element_count=volume.element_count,
            tet4_count=volume.tet4_count,
            pyramid5_count=volume.pyramid5_count,
            near_median_edge_mm=near_size_mm,
            far_median_edge_mm=maximum_size_mm,
            growth_ratio_x=nominal_growth,
            growth_ratio_y=nominal_growth,
            growth_ratio_z=nominal_growth,
            minimum_sicn=volume.minimum_sicn,
            minimum_sige=volume.minimum_sige,
            minimum_scaled_jacobian=volume.minimum_scaled_jacobian,
            generated_node_count=(
                volume.node_count - len(volume.source_node_id_by_local_id)
            ),
            random_seed=volume.random_seed,
            adapter_cap_z_mm=cap_z_mm,
            adapter_top_face_count=len(volume.cap_facets),
            remainder_tet4_count=volume.tet4_count,
            growth_measurement_available=False,
        ),
        die_wall_facets,
        appended,
    )


def _ordered_horizontal_facet_points(
    facet: Sequence[int],
    registry: _NodeRegistry,
    z_value: float,
) -> tuple[tuple[float, float, float], ...]:
    points = tuple(registry.nodes_by_tag[tag].coordinates for tag in facet)
    if len(points) not in {3, 4} or any(
        abs(point[2] - z_value) > _COORDINATE_TOLERANCE_MM
        for point in points
    ):
        raise PackageBuildError(
            "shared sweep surface must contain horizontal TRI3/QUAD4 facets"
        )
    center_x = math.fsum(point[0] for point in points) / len(points)
    center_y = math.fsum(point[1] for point in points) / len(points)
    ordered = tuple(
        sorted(
            points,
            key=lambda point: math.atan2(
                point[1] - center_y,
                point[0] - center_x,
            ),
        )
    )
    area = math.fsum(
        ordered[index][0] * ordered[(index + 1) % len(ordered)][1]
        - ordered[(index + 1) % len(ordered)][0] * ordered[index][1]
        for index in range(len(ordered))
    )
    if area <= _COORDINATE_TOLERANCE_MM**2:
        raise PackageBuildError("shared sweep surface facet is degenerate")
    return ordered


def _append_uf_structured_sweep_from_facets(
    builder: _PlanBuilder,
    docking_facets: Sequence[Sequence[int]],
    stack: ResolvedPackageStack,
    z_levels_mm: Sequence[float],
    *,
    material: str,
    zone: str,
) -> tuple[PackageElement, ...]:
    """Extrude inherited TRI/QUAD facets through the UF section-width law."""

    levels = tuple(z_levels_mm)
    if len(levels) < 2 or any(
        upper <= lower for lower, upper in zip(levels, levels[1:])
    ):
        raise PackageBuildError("structured UF sweep requires increasing levels")
    reference_width = _uf_width_at_z(stack, levels[0])
    if reference_width <= _COORDINATE_TOLERANCE_MM:
        raise PackageBuildError("structured UF sweep reference width is zero")
    base_facets = tuple(
        _ordered_horizontal_facet_points(facet, builder.registry, levels[0])
        for facet in docking_facets
    )
    if not base_facets:
        raise PackageBuildError("structured UF sweep has no inherited facets")
    mapped_levels: list[tuple[tuple[tuple[float, float, float], ...], ...]] = []
    for z_value in levels:
        width = _uf_width_at_z(stack, z_value)
        if width <= _COORDINATE_TOLERANCE_MM:
            raise PackageBuildError(
                "structured UF sweep must stop before the zero-width apex"
            )
        mapped_levels.append(
            tuple(
                tuple(
                    (
                        *_map_uf_section_xy(
                            stack,
                            (point[0], point[1]),
                            reference_width_mm=reference_width,
                            target_width_mm=width,
                        ),
                        z_value,
                    )
                    for point in facet
                )
                for facet in base_facets
            )
        )
    start = len(builder.elements)
    for lower_level, upper_level in zip(mapped_levels, mapped_levels[1:]):
        for lower, upper in zip(lower_level, upper_level):
            gmsh_type = 6 if len(lower) == 3 else 5
            builder.add_element(
                gmsh_type,
                tuple(
                    builder.registry.add(*point)
                    for point in (*lower, *upper)
                ),
                material=material,
                component="UF_FILLET",
                zone=zone,
            )
    appended = tuple(builder.elements[start:])
    if not appended:
        raise PackageBuildError("structured UF sweep generated no elements")
    return appended


def _die_wall_boundary_facets(
    elements: Sequence[PackageElement],
    registry: _NodeRegistry,
    stack: ResolvedPackageStack,
    z_min: float,
    z_max: float,
) -> tuple[tuple[int, ...], ...]:
    incidence = _face_incidence(elements)
    facets = tuple(
        owners[0][1]
        for owners in incidence.values()
        if len(owners) == 1
        and _is_die_inner_wall_face(
            owners[0][1],
            registry,
            stack,
            z_min,
            z_max,
        )
    )
    if z_max > z_min + _COORDINATE_TOLERANCE_MM and not facets:
        raise PackageBuildError("generated UF exposes no die-wall interface facets")
    return tuple(sorted(facets, key=lambda face: tuple(sorted(face))))


def _append_selected_uf_upper_volume(
    builder: _PlanBuilder,
    docking_facets: Sequence[Sequence[int]],
    stack: ResolvedPackageStack,
    ports: Sequence[CornerPort],
    cap_z_mm: float,
    *,
    topology: str,
    target_edge_mm: float,
    transition_distance_mm: float,
    near_size_mm: float,
    material: str,
    verbose: bool,
) -> tuple[
    PackageHybridRegion | None,
    tuple[tuple[int, ...], ...],
    tuple[PackageElement, ...],
]:
    """Fill one adjacent fillet body from its negotiated docking surface."""

    resolved_topology = normalize_underfill_core_volume_topology(topology)
    facets = tuple(tuple(facet) for facet in docking_facets)
    if not facets:
        raise PackageBuildError("upper generated body has no shared docking surface")
    if resolved_topology == "conformal_hybrid":
        height = cap_z_mm - stack.bump_top_mm
        maximum_size = max(
            near_size_mm,
            min(
                target_edge_mm,
                max(3.0 * near_size_mm, 0.5 * height),
            ),
        )
        region, die_facets, elements = _append_uf_upper_hybrid_volume(
            builder,
            facets,
            stack,
            cap_z_mm,
            maximum_size_mm=maximum_size,
            near_size_mm=near_size_mm,
            transition_distance_mm=transition_distance_mm,
            material=material,
            verbose=verbose,
        )
        return region, die_facets, elements

    levels = _levels_between(
        _uf_z_levels(
            stack,
            ports,
            above_bump_target_mm=target_edge_mm,
        ),
        stack.bump_top_mm,
        cap_z_mm,
    )
    if resolved_topology == "structured_sweep":
        elements = _append_uf_structured_sweep_from_facets(
            builder,
            facets,
            stack,
            levels,
            material=material,
            zone="UF_UPPER_STRUCTURED_SWEEP",
        )
    elif resolved_topology == "orthogonal_hex":
        if any(len(facet) != 4 for facet in facets):
            raise PackageBuildError(
                "orthogonal_hex requires a negotiated QUAD4 docking surface"
            )
        base_cells = tuple(
            tuple((point[0], point[1]) for point in _ordered_horizontal_facet_points(
                facet,
                builder.registry,
                stack.bump_top_mm,
            ))
            for facet in facets
        )
        start = len(builder.elements)
        _add_uf_hex_staircase(
            builder,
            stack,
            ports,
            base_cells,
            material=material,
            z_levels_mm=levels,
            zone="UF_UPPER_ORTHOGONAL_HEX",
        )
        elements = tuple(builder.elements[start:])
        if not elements:
            raise PackageBuildError("orthogonal upper volume generated no HEX8")
        _audit_orthogonal_hex_coordinates(
            tuple(
                (
                    element.gmsh_type,
                    tuple(
                        builder.registry.nodes_by_tag[tag].coordinates
                        for tag in element.node_tags
                    ),
                )
                for element in elements
            )
        )
    else:  # pragma: no cover - normalized above
        raise AssertionError(f"unsupported upper topology: {resolved_topology}")
    die_facets = _die_wall_boundary_facets(
        elements,
        builder.registry,
        stack,
        stack.bump_top_mm,
        cap_z_mm,
    )
    return None, die_facets, elements


def _subdivide_interval(start: float, end: float, target_size: float) -> tuple[float, ...]:
    if end <= start or target_size <= 0.0:
        raise PackageBuildError("interval subdivision requires positive extent and size")
    ratio = (end - start) / target_size
    count = max(1, math.ceil(ratio - 1.0e-12))
    return tuple(start + (end - start) * index / count for index in range(count + 1))


def _merge_levels(*groups: Iterable[float]) -> tuple[float, ...]:
    unique: dict[float, float] = {}
    for group in groups:
        for value in group:
            parsed = _finite(value, field_name="Z level")
            unique.setdefault(round(parsed, _COORDINATE_DIGITS), parsed)
    return tuple(sorted(unique.values()))


def _levels_between(
    levels: Sequence[float],
    start: float,
    end: float,
) -> tuple[float, ...]:
    selected = tuple(
        value
        for value in levels
        if start - _COORDINATE_TOLERANCE_MM
        <= value
        <= end + _COORDINATE_TOLERANCE_MM
    )
    return _merge_levels((start,), selected, (end,))


def _substrate_z_levels(stack: ResolvedPackageStack) -> tuple[float, ...]:
    height = stack.substrate_top_mm - stack.substrate_bottom_mm
    fractions = (0.0, 0.20, 0.45, 0.70, 0.88, 1.0)
    return tuple(stack.substrate_bottom_mm + height * value for value in fractions)


def _die_z_levels(
    stack: ResolvedPackageStack,
    ports: Sequence[CornerPort],
) -> tuple[float, ...]:
    source_levels = ports[0].source_z_levels_mm
    inherited_dz = source_levels[1] - source_levels[0]
    return _merge_levels(
        _subdivide_interval(stack.die_bottom_mm, stack.uf_top_mm, inherited_dz),
        _subdivide_interval(stack.uf_top_mm, stack.die_top_mm, inherited_dz),
    )


def _placed_source_z_levels(
    stack: ResolvedPackageStack,
    ports: Sequence[CornerPort],
) -> tuple[float, ...]:
    source = ports[0].source_z_levels_mm
    source_max = source[-1]
    return tuple(
        stack.bump_bottom_mm + source_max - value for value in reversed(source)
    )


def _uf_lower_z_levels(
    stack: ResolvedPackageStack,
    ports: Sequence[CornerPort],
) -> tuple[float, ...]:
    """Return the protected UF schedule no higher than the C4 top.

    This is deliberately independent from the upper-UF meshing policy.  The
    hybrid path uses these levels for the immutable HEX core and hands its
    complete horizontal boundary to the separate upper-UF volume mesher.
    """

    return _levels_between(
        _placed_source_z_levels(stack, ports),
        stack.uf_base_mm,
        min(stack.bump_top_mm, stack.uf_top_mm),
    )


def _uf_safe_cap_z(
    stack: ResolvedPackageStack,
    ports: Sequence[CornerPort],
) -> float:
    """Highest positive-width conservative UF section for hybrid meshing."""

    if stack.uf_top_mm <= stack.bump_top_mm + _COORDINATE_TOLERANCE_MM:
        return min(stack.uf_top_mm, stack.bump_top_mm)
    corner_pitch = min(
        min(port.size_x_mm, port.size_y_mm) for port in ports
    )
    return stack.uf_top_mm - stack.uf_height_mm * min(
        1.0,
        math.sqrt(2.0) * corner_pitch / stack.uf_width_mm,
    )


def _uf_hybrid_cap_z(
    stack: ResolvedPackageStack,
    ports: Sequence[CornerPort],
) -> float:
    """Regularize only the zero-width analytic tip of the hybrid UF.

    Unlike a Cartesian FULL_HEX cap, the TET/PYR loft does not need one full
    diagonal cell of radial width. Retaining half one docking pitch gives the
    locked pyramids useful height while still avoiding a zero-area top wire.
    """

    if stack.uf_top_mm <= stack.bump_top_mm + _COORDINATE_TOLERANCE_MM:
        return min(stack.uf_top_mm, stack.bump_top_mm)
    corner_pitch = min(
        min(port.size_x_mm, port.size_y_mm) for port in ports
    )
    bottom_radius = stack.uf_width_mm * (
        stack.uf_top_mm - stack.bump_top_mm
    ) / stack.uf_height_mm
    # A fixed sub-pitch tip works for the short demo, but becomes an extreme
    # 100:1 loft when UF reaches most of the added-Si height. Retain at least
    # 8% of the transition radius (and 0.35 pitch) so both low and high UF end
    # on a small, positive-area regularized cap instead of a zero-width line.
    tip_radius = max(0.35 * corner_pitch, 0.08 * bottom_radius)
    return stack.uf_top_mm - stack.uf_height_mm * min(
        1.0,
        tip_radius / stack.uf_width_mm,
    )


def _uf_z_levels(
    stack: ResolvedPackageStack,
    ports: Sequence[CornerPort],
    *,
    above_bump_target_mm: float | None = None,
) -> tuple[float, ...]:
    below_bump_levels = _uf_lower_z_levels(stack, ports)
    if stack.uf_top_mm <= stack.bump_top_mm + _COORDINATE_TOLERANCE_MM:
        return below_bump_levels
    inherited_dz = ports[0].source_z_levels_mm[1] - ports[0].source_z_levels_mm[0]
    above_bump_dz = (
        inherited_dz
        if above_bump_target_mm is None
        else _finite(
            above_bump_target_mm,
            field_name="UF above-bump target Z size",
        )
    )
    if above_bump_dz <= 0.0:
        raise PackageBuildError("UF above-bump target Z size must be positive")
    if above_bump_target_mm is None:
        above_bump_levels = _subdivide_interval(
            stack.bump_top_mm,
            stack.uf_top_mm,
            above_bump_dz,
        )
    else:
        # The analytic fillet reaches its maximum only on the zero-width die
        # wall.  At the first finite radial cell, the conservative FULL_HEX
        # ceiling is lower. Insert that exact safe ceiling so the retained UF
        # side reaches the highest resolvable staircase level; the final cap
        # remains an explicitly skipped CUT interval.
        safe_top = _uf_safe_cap_z(stack, ports)
        if safe_top > stack.bump_top_mm + _COORDINATE_TOLERANCE_MM:
            full_core_levels = _subdivide_interval(
                stack.bump_top_mm,
                safe_top,
                above_bump_dz,
            )
        else:
            full_core_levels = (stack.bump_top_mm,)
        above_bump_levels = _merge_levels(
            full_core_levels,
            (stack.uf_top_mm,),
        )
    return _merge_levels(
        below_bump_levels,
        above_bump_levels,
    )


def _ring_z_levels(
    stack: ResolvedPackageStack,
    ports: Sequence[CornerPort],
    bottom: float,
    top: float,
) -> tuple[float, ...]:
    return _levels_between(_placed_source_z_levels(stack, ports), bottom, top)


def _straight_uf_cells(
    stack: ResolvedPackageStack,
    ports: Sequence[CornerPort],
    central_cells: Sequence[Sequence[tuple[float, float]]],
    *,
    radial_offsets_mm: Sequence[float] | None = None,
) -> tuple[tuple[tuple[float, float], ...], ...]:
    x_min, x_max, y_min, y_max = stack.die_bounds_xy_mm
    inward = ports[0].inward_x_mm
    pitch = ports[0].size_x_mm
    if any(
        not _close(port.inward_x_mm, inward)
        or not _close(port.inward_y_mm, inward)
        or not _close(port.size_x_mm, pitch)
        or not _close(port.size_y_mm, pitch)
        for port in ports
    ):
        raise PackageBuildError("all corner ports must use one square XY lattice")
    # The inner UF wall must use the exact connected-mesh perimeter nodes.
    # A newly graded schedule would be geometrically coincident but not
    # topologically conformal to the imported side wall.
    central_boundary = _trace_single_boundary_loop(
        _cell_boundary_edges(central_cells)
    )
    def x_tangent(y_side: float) -> tuple[float, ...]:
        return tuple(
            sorted(
                {
                    x_min + inward,
                    x_max - inward,
                    *(
                        x
                        for x, y in central_boundary
                        if _close(y, y_side)
                        and x_min + inward - _COORDINATE_TOLERANCE_MM
                        <= x
                        <= x_max - inward + _COORDINATE_TOLERANCE_MM
                    ),
                }
            )
        )

    def y_tangent(x_side: float) -> tuple[float, ...]:
        return tuple(
            sorted(
                {
                    y_min + inward,
                    y_max - inward,
                    *(
                        y
                        for x, y in central_boundary
                        if _close(x, x_side)
                        and y_min + inward - _COORDINATE_TOLERANCE_MM
                        <= y
                        <= y_max - inward + _COORDINATE_TOLERANCE_MM
                    ),
                }
            )
        )

    x_tangent_bottom = x_tangent(y_min)
    x_tangent_top = x_tangent(y_max)
    y_tangent_left = y_tangent(x_min)
    y_tangent_right = y_tangent(x_max)
    if any(
        len(lines) < 2
        for lines in (
            x_tangent_bottom,
            x_tangent_top,
            y_tangent_left,
            y_tangent_right,
        )
    ):
        raise PackageBuildError("cannot recover connected-bump UF wall ports")
    if radial_offsets_mm is None:
        x_radial_left = _axis_lines(x_min - stack.uf_width_mm, x_min, pitch)
        x_radial_right = _axis_lines(x_max, x_max + stack.uf_width_mm, pitch)
        y_radial_bottom = _axis_lines(y_min - stack.uf_width_mm, y_min, pitch)
        y_radial_top = _axis_lines(y_max, y_max + stack.uf_width_mm, pitch)
    else:
        offsets = tuple(radial_offsets_mm)
        if (
            len(offsets) < 2
            or not _close(offsets[0], 0.0)
            or not _close(offsets[-1], stack.uf_width_mm)
            or any(upper <= lower for lower, upper in zip(offsets, offsets[1:]))
        ):
            raise PackageBuildError("UF radial offsets are invalid")
        x_radial_left = tuple(sorted(x_min - offset for offset in offsets))
        x_radial_right = tuple(x_max + offset for offset in offsets)
        y_radial_bottom = tuple(sorted(y_min - offset for offset in offsets))
        y_radial_top = tuple(y_max + offset for offset in offsets)

    cells: list[tuple[tuple[float, float], ...]] = []

    def add_grid(x_lines: Sequence[float], y_lines: Sequence[float]) -> None:
        for x0, x1 in zip(x_lines, x_lines[1:]):
            for y0, y1 in zip(y_lines, y_lines[1:]):
                cells.append(
                    (
                        _xy_key(x0, y0),
                        _xy_key(x1, y0),
                        _xy_key(x1, y1),
                        _xy_key(x0, y1),
                    )
                )

    # Opposite connected-bump sides are allowed to have different transition
    # schedules.  Preserve each side independently; taking their union would
    # introduce hanging nodes where a coordinate from one side is absent on
    # the opposite side.
    add_grid(x_tangent_bottom, y_radial_bottom)
    add_grid(x_tangent_top, y_radial_top)
    add_grid(x_radial_left, y_tangent_left)
    add_grid(x_radial_right, y_tangent_right)
    return tuple(cells)


def _uf_top_height(
    x: float,
    y: float,
    stack: ResolvedPackageStack,
) -> float:
    half_x = 0.5 * stack.uf_die_width_mm
    half_y = 0.5 * stack.uf_die_length_mm
    dx = max(abs(x) - half_x, 0.0)
    dy = max(abs(y) - half_y, 0.0)
    distance = math.hypot(dx, dy)
    if distance > stack.uf_width_mm + _COORDINATE_TOLERANCE_MM:
        return stack.uf_base_mm
    return stack.uf_base_mm + stack.uf_height_mm * (
        1.0 - distance / stack.uf_width_mm
    )


@dataclass(frozen=True, slots=True)
class _UfMeshStats:
    full_hex_count: int
    cut_cell_count: int
    outside_cell_count: int


@dataclass(frozen=True, slots=True)
class _UfTraceSweepStats:
    element_count: int
    hex8_count: int
    cut_cell_count: int
    outside_cell_count: int


@dataclass(frozen=True, slots=True)
class _UfTraceAppliedTopologyStats:
    element_count: int
    hex8_count: int
    pyramid5_count: int
    tet4_count: int
    quality_fallback_hex8_count: int
    star_converted_hex8_count: int
    free_surface_tri3_count: int
    free_surface_quad_fallback_count: int


@dataclass(frozen=True, slots=True)
class _UfTraceSurfaceAuditStats:
    free_surface_tri3_count: int
    free_surface_quad_fallback_count: int
    exterior_quad_owned_by_non_hex_count: int


@dataclass(frozen=True, slots=True)
class _UfTraceSweepQuality:
    minimum_determinant: float
    minimum_scaled_jacobian: float
    minimum_sicn: float
    minimum_sige: float

    @property
    def passes(self) -> bool:
        return (
            self.minimum_determinant > 0.0
            and self.minimum_scaled_jacobian >= _HYBRID_DEMO_MIN_QUALITY
            and self.minimum_sicn >= _HYBRID_DEMO_MIN_QUALITY
            and self.minimum_sige >= _HYBRID_DEMO_MIN_QUALITY
        )


@dataclass(frozen=True, slots=True)
class _UfTracePlanarCandidate:
    domain: _PackagePlanarDomain
    effective_target_edge_mm: float
    effective_transition_distance_mm: float
    quality: _UfTraceSweepQuality
    stats: _UfTraceSweepStats


def _uf_trace_sweep_element_coordinates(
    stack: ResolvedPackageStack,
    control_cells: Sequence[Sequence[tuple[float, float]]],
    z_levels_mm: Sequence[float],
) -> tuple[
    tuple[tuple[int, tuple[tuple[float, float, float], ...]], ...],
    _UfTraceSweepStats,
]:
    """Return fresh lower-UF sweep connectivity in coordinate form."""

    levels = tuple(
        _finite(value, field_name="trace-only UF locked Z level")
        for value in z_levels_mm
    )
    if (
        len(levels) < 2
        or any(upper <= lower for lower, upper in zip(levels, levels[1:]))
        or not _close(levels[0], stack.uf_base_mm)
        or not _close(levels[-1], stack.bump_top_mm)
    ):
        raise PackageBuildError(
            "trace-only UF sweep requires strict locked base-to-top Z levels"
        )
    envelope = RectangularUfEnvelope(
        die_width=stack.uf_die_width_mm,
        die_length=stack.uf_die_length_mm,
        base_z=stack.uf_base_mm,
        height=stack.uf_height_mm,
        fillet_width=stack.uf_width_mm,
    )
    estimated_node_ceiling = len(
        {
            _xy_key(x, y)
            for candidate_cell in control_cells
            for x, y in candidate_cell
        }
    ) * len(levels)
    potential_element_count = len(control_cells) * (len(levels) - 1)
    if potential_element_count > _MAXIMUM_UF_TRACE_SWEEP_POTENTIAL_COUNT:
        estimated_bytes = (
            potential_element_count * 8 * 8
            + estimated_node_ceiling * 3 * 8
        )
        raise PackageBuildError(
            "trace-only UF fresh sweep exceeds the preflight resource ceiling: "
            f"potential_elements={potential_element_count}, "
            f"limit={_MAXIMUM_UF_TRACE_SWEEP_POTENTIAL_COUNT}, "
            f"estimated_nodes<={estimated_node_ceiling}, "
            f"packed_connectivity_coordinate_bytes>={estimated_bytes}"
        )
    elements: list[tuple[int, tuple[tuple[float, float, float], ...]]] = []
    hex8_count = 0
    cut_cell_count = 0
    outside_cell_count = 0
    for raw_cell in control_cells:
        cell = tuple((_xy_key(x, y)) for x, y in raw_cell)
        if len(cell) != 4 or len(set(cell)) != len(cell):
            raise PackageBuildError(
                "trace-only UF planar controls must be distinct QUAD4 cells"
            )
        signed_twice_area = sum(
            cell[index][0] * cell[(index + 1) % len(cell)][1]
            - cell[(index + 1) % len(cell)][0] * cell[index][1]
            for index in range(len(cell))
        )
        if signed_twice_area <= _COORDINATE_TOLERANCE_MM**2:
            raise PackageBuildError(
                "trace-only UF planar control cell must be counter-clockwise"
            )
        for lower_z, upper_z in zip(levels, levels[1:]):
            lower_inside = tuple(
                envelope.contains(x, y, lower_z) for x, y in cell
            )
            upper_inside = tuple(
                envelope.contains(x, y, upper_z) for x, y in cell
            )
            if all(upper_inside):
                lower = tuple((x, y, lower_z) for x, y in cell)
                upper = tuple((x, y, upper_z) for x, y in cell)
                elements.append((5, (*lower, *upper)))
                if len(elements) > _MAXIMUM_UF_TRACE_SWEEP_ELEMENT_COUNT:
                    estimated_bytes = (
                        len(elements) * 8 * 8 + estimated_node_ceiling * 3 * 8
                    )
                    raise PackageBuildError(
                        "trace-only UF fresh sweep exceeds the resource ceiling: "
                        f"elements>{_MAXIMUM_UF_TRACE_SWEEP_ELEMENT_COUNT}, "
                        f"estimated_nodes<={estimated_node_ceiling}, "
                        f"packed_connectivity_coordinate_bytes>={estimated_bytes}"
                    )
                hex8_count += 1
            elif any(lower_inside) or any(upper_inside):
                cut_cell_count += 1
            else:
                outside_cell_count += 1
    stats = _UfTraceSweepStats(
        element_count=len(elements),
        hex8_count=hex8_count,
        cut_cell_count=cut_cell_count,
        outside_cell_count=outside_cell_count,
    )
    if not elements or stats.element_count != stats.hex8_count:
        raise PackageBuildError("trace-only UF fresh sweep generated no volume")
    return tuple(elements), stats


def _uf_width_at_z(stack: ResolvedPackageStack, z_value: float) -> float:
    if not (
        stack.uf_base_mm - _COORDINATE_TOLERANCE_MM
        <= z_value
        <= stack.uf_top_mm + _COORDINATE_TOLERANCE_MM
    ):
        raise PackageBuildError("UF section Z escapes the analytic fillet")
    return max(
        0.0,
        stack.uf_width_mm
        * (stack.uf_top_mm - z_value)
        / stack.uf_height_mm,
    )


def _map_uf_section_xy(
    stack: ResolvedPackageStack,
    point: tuple[float, float],
    *,
    reference_width_mm: float,
    target_width_mm: float,
) -> tuple[float, float]:
    """Map one inherited annular-section node without deleting its cell."""

    x, y = point
    x_min, x_max, y_min, y_max = stack.die_bounds_xy_mm
    nearest_x = min(x_max, max(x_min, x))
    nearest_y = min(y_max, max(y_min, y))
    dx = x - nearest_x
    dy = y - nearest_y
    distance = math.hypot(dx, dy)
    if distance <= _COORDINATE_TOLERANCE_MM:
        on_wall = (
            abs(x - x_min) <= _COORDINATE_TOLERANCE_MM
            or abs(x - x_max) <= _COORDINATE_TOLERANCE_MM
            or abs(y - y_min) <= _COORDINATE_TOLERANCE_MM
            or abs(y - y_max) <= _COORDINATE_TOLERANCE_MM
        )
        if not on_wall:
            raise PackageBuildError(
                "structured UF section contains a node inside the die opening"
            )
        return _xy_key(x, y)
    if distance > reference_width_mm + 10.0 * _COORDINATE_TOLERANCE_MM:
        raise PackageBuildError(
            "structured UF section node escapes its inherited reference width"
        )
    scale = target_width_mm / reference_width_mm
    return _xy_key(nearest_x + scale * dx, nearest_y + scale * dy)


def _uf_structured_section_sweep_coordinates(
    stack: ResolvedPackageStack,
    control_cells: Sequence[Sequence[tuple[float, float]]],
    z_levels_mm: Sequence[float],
) -> tuple[
    tuple[tuple[int, tuple[tuple[float, float, float], ...]], ...],
    _UfTraceSweepStats,
]:
    """Sweep one inherited annular section through the analytic width law.

    Every input face persists through every interval.  Coordinates move along
    the local outward ray of the die rectangle, so the free surface can slope;
    no CUT cell is classified, removed, or replaced by a staircase policy.
    """

    levels = tuple(
        _finite(value, field_name="structured UF section Z level")
        for value in z_levels_mm
    )
    if len(levels) < 2 or any(
        upper <= lower for lower, upper in zip(levels, levels[1:])
    ):
        raise PackageBuildError("structured UF section levels must increase")
    reference_width = _uf_width_at_z(stack, levels[0])
    if reference_width <= _COORDINATE_TOLERANCE_MM:
        raise PackageBuildError("structured UF reference section has zero width")
    cells: list[tuple[tuple[float, float], ...]] = []
    for raw_cell in control_cells:
        cell = tuple(_xy_key(*point) for point in raw_cell)
        if len(cell) != 4 or len(set(cell)) != 4:
            raise PackageBuildError(
                "structured UF section requires distinct QUAD4 input faces"
            )
        signed_twice_area = math.fsum(
            cell[index][0] * cell[(index + 1) % 4][1]
            - cell[(index + 1) % 4][0] * cell[index][1]
            for index in range(4)
        )
        if signed_twice_area <= _COORDINATE_TOLERANCE_MM**2:
            raise PackageBuildError(
                "structured UF section faces must be counter-clockwise"
            )
        cells.append(cell)
    mapped_by_level: list[tuple[tuple[tuple[float, float, float], ...], ...]] = []
    for z_value in levels:
        width = _uf_width_at_z(stack, z_value)
        if width <= _COORDINATE_TOLERANCE_MM:
            raise PackageBuildError(
                "structured UF sweep must stop before the zero-width apex"
            )
        mapped_by_level.append(
            tuple(
                tuple(
                    (
                        *_map_uf_section_xy(
                            stack,
                            point,
                            reference_width_mm=reference_width,
                            target_width_mm=width,
                        ),
                        z_value,
                    )
                    for point in cell
                )
                for cell in cells
            )
        )
    elements = tuple(
        (5, (*lower, *upper))
        for lower_level, upper_level in zip(
            mapped_by_level,
            mapped_by_level[1:],
        )
        for lower, upper in zip(lower_level, upper_level)
    )
    if not elements:
        raise PackageBuildError("structured UF section sweep generated no volume")
    stats = _UfTraceSweepStats(
        element_count=len(elements),
        hex8_count=len(elements),
        cut_cell_count=0,
        outside_cell_count=0,
    )
    return elements, stats


def _uf_trace_sweep_quality(
    elements: Sequence[
        tuple[int, Sequence[tuple[float, float, float]]]
    ],
) -> _UfTraceSweepQuality:
    """Evaluate every generated HEX8 before a candidate is accepted."""

    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:  # pragma: no cover - dependency failure
        raise RuntimeError("Gmsh is required to audit the trace-only UF sweep") from error
    node_tag_by_key: dict[tuple[float, float, float], int] = {}
    coordinates_by_tag: dict[int, tuple[float, float, float]] = {}
    connectivities_by_type: dict[int, list[tuple[int, ...]]] = defaultdict(list)
    for gmsh_type, element_coordinates in elements:
        if gmsh_type != 5:
            raise PackageBuildError(
                "trace-only UF quality audit accepts only HEX8"
            )
        connectivity: list[int] = []
        for coordinates in element_coordinates:
            if len(coordinates) != 3 or any(
                not math.isfinite(value) for value in coordinates
            ):
                raise PackageBuildError(
                    "trace-only UF sweep contains a non-finite node"
                )
            key = _coordinate_key(*coordinates)
            tag = node_tag_by_key.get(key)
            if tag is None:
                tag = len(node_tag_by_key) + 1
                node_tag_by_key[key] = tag
                coordinates_by_tag[tag] = tuple(float(value) for value in coordinates)
            connectivity.append(tag)
        if len(set(connectivity)) != len(connectivity):
            raise PackageBuildError(
                "trace-only UF sweep contains a collapsed volume element"
            )
        connectivities_by_type[gmsh_type].append(tuple(connectivity))

    with isolated_gmsh_model(
        gmsh,
        "__easymesh_uf_trace_sweep_quality",
        number_options={"General.Terminal": 0.0, "Mesh.ElementOrder": 1.0},
    ):
        entity = gmsh.model.addDiscreteEntity(3)
        node_tags = tuple(sorted(coordinates_by_tag))
        gmsh.model.mesh.addNodes(
            3,
            entity,
            list(node_tags),
            [
                value
                for tag in node_tags
                for value in coordinates_by_tag[tag]
            ],
        )
        element_tags: list[int] = []
        next_element_tag = 1
        for gmsh_type in sorted(connectivities_by_type):
            connectivities = connectivities_by_type[gmsh_type]
            tags = list(range(next_element_tag, next_element_tag + len(connectivities)))
            next_element_tag += len(connectivities)
            gmsh.model.mesh.addElementsByType(
                entity,
                gmsh_type,
                tags,
                [node for connectivity in connectivities for node in connectivity],
            )
            element_tags.extend(tags)
        metrics: dict[str, tuple[float, ...]] = {}
        for name in ("minDetJac", "minSJ", "minSICN", "minSIGE"):
            values = tuple(
                float(value)
                for value in gmsh.model.mesh.getElementQualities(element_tags, name)
            )
            if len(values) != len(element_tags) or any(
                not math.isfinite(value) for value in values
            ):
                raise PackageBuildError(
                    f"trace-only UF {name} quality evidence is incomplete"
                )
            metrics[name] = values
    return _UfTraceSweepQuality(
        minimum_determinant=min(metrics["minDetJac"]),
        minimum_scaled_jacobian=min(metrics["minSJ"]),
        minimum_sicn=min(metrics["minSICN"]),
        minimum_sige=min(metrics["minSIGE"]),
    )


def _uf_trace_hybrid_quality_values(
    elements: Sequence[
        tuple[int, Sequence[tuple[float, float, float]]]
    ],
) -> dict[str, tuple[float, ...]]:
    """Return mixed TET4/PYRAMID5 metrics in deterministic caller order."""

    if not elements or any(
        gmsh_type not in {4, 7}
        for gmsh_type, _coordinates in elements
    ):
        raise PackageBuildError(
            "conformal-hybrid UF quality candidates must be TET4/PYRAMID5"
        )
    return _ring_candidate_quality_values(elements)


def _uf_oriented_pyramid_base(
    face: Sequence[tuple[float, float, float]],
    apex: tuple[float, float, float],
) -> tuple[tuple[float, float, float], ...]:
    """Orient one QUAD so its normal points from the base towards the apex."""

    values = tuple(face)
    if len(values) != 4 or len({_coordinate_key(*point) for point in values}) != 4:
        raise PackageBuildError("conformal-hybrid UF pyramid base is invalid")
    first, second, third = values[:3]
    ab = tuple(second[axis] - first[axis] for axis in range(3))
    ac = tuple(third[axis] - first[axis] for axis in range(3))
    normal = (
        ab[1] * ac[2] - ab[2] * ac[1],
        ab[2] * ac[0] - ab[0] * ac[2],
        ab[0] * ac[1] - ab[1] * ac[0],
    )
    centroid = tuple(
        math.fsum(point[axis] for point in values) / 4.0
        for axis in range(3)
    )
    if math.fsum(
        normal[axis] * (apex[axis] - centroid[axis])
        for axis in range(3)
    ) < 0.0:
        values = tuple(reversed(values))
    return values


def _coordinate_face_key(
    face: Sequence[Sequence[float]],
) -> tuple[tuple[float, float, float], ...]:
    """Return one orientation-independent face key in coordinate space."""

    points = tuple(_coordinate_key(*point) for point in face)
    if len(points) not in {3, 4} or len(set(points)) != len(points):
        raise PackageBuildError("conformal-hybrid UF face key is invalid")
    return tuple(sorted(points))


def _stable_quad_triangles(
    face: Sequence[tuple[float, float, float]],
) -> tuple[
    tuple[tuple[float, float, float], ...],
    tuple[tuple[float, float, float], ...],
]:
    """Split one cyclic QUAD with a coordinate-stable diagonal."""

    values = tuple(tuple(float(value) for value in point) for point in face)
    if len(values) != 4 or len({_coordinate_key(*point) for point in values}) != 4:
        raise PackageBuildError("conformal-hybrid UF free QUAD is invalid")
    diagonal_02 = tuple(
        sorted((_coordinate_key(*values[0]), _coordinate_key(*values[2])))
    )
    diagonal_13 = tuple(
        sorted((_coordinate_key(*values[1]), _coordinate_key(*values[3])))
    )
    if diagonal_02 <= diagonal_13:
        return (
            (values[0], values[1], values[2]),
            (values[0], values[2], values[3]),
        )
    return (
        (values[1], values[2], values[3]),
        (values[1], values[3], values[0]),
    )


def _uf_scaffold_boundary_faces(
    scaffold_elements: Sequence[
        tuple[int, Sequence[tuple[float, float, float]]]
    ],
) -> dict[
    tuple[tuple[float, float, float], ...],
    tuple[tuple[float, float, float], ...],
]:
    """Return every single-owner QUAD of a valid HEX8 scaffold."""

    owners: dict[
        tuple[tuple[float, float, float], ...],
        list[tuple[tuple[float, float, float], ...]],
    ] = defaultdict(list)
    for gmsh_type, raw_coordinates in scaffold_elements:
        coordinates = tuple(tuple(float(value) for value in point) for point in raw_coordinates)
        if gmsh_type != 5 or len(coordinates) != 8:
            raise PackageBuildError(
                "conformal-hybrid UF boundary audit requires HEX8 scaffold"
            )
        for local_face in ELEMENT_SPECS[5][2]:
            face = tuple(coordinates[index] for index in local_face)
            owners[_coordinate_face_key(face)].append(face)
    if any(len(face_owners) > 2 for face_owners in owners.values()):
        raise PackageBuildError(
            "conformal-hybrid UF scaffold contains a non-manifold face"
        )
    return {
        key: face_owners[0]
        for key, face_owners in owners.items()
        if len(face_owners) == 1
    }


def _uf_conformal_hybrid_coordinates(
    scaffold_elements: Sequence[
        tuple[int, Sequence[tuple[float, float, float]]]
    ],
    *,
    protected_exterior_face_keys: Iterable[
        tuple[tuple[float, float, float], ...]
    ] = (),
    protected_horizontal_z_values: Sequence[float] = (),
) -> tuple[
    tuple[tuple[int, tuple[tuple[float, float, float], ...]], ...],
    _UfTraceAppliedTopologyStats,
    _UfTraceSweepQuality,
]:
    """Triangulate quality-safe free skin while preserving every locked QUAD.

    Only mother HEX8 cells touching the unprotected exterior are candidates.
    Each free QUAD becomes two TET4 bases on a stable diagonal, while the
    mother's other faces remain complete PYRAMID5 bases.  The whole mother is
    converted or retained as one HEX8; individual child rejection can never
    create a hole.
    """

    scaffold = tuple(
        (gmsh_type, tuple(coordinates))
        for gmsh_type, coordinates in scaffold_elements
    )
    if not scaffold or any(
        gmsh_type != 5
        or len(coordinates) != 8
        or len({_coordinate_key(*point) for point in coordinates}) != 8
        for gmsh_type, coordinates in scaffold
    ):
        raise PackageBuildError(
            "conformal-hybrid UF requires a non-empty fresh HEX8 scaffold"
        )
    boundary_faces = _uf_scaffold_boundary_faces(scaffold)
    explicit_protected_keys = {
        tuple(sorted(tuple(_coordinate_key(*point) for point in key)))
        for key in protected_exterior_face_keys
    }
    if not explicit_protected_keys <= set(boundary_faces):
        raise PackageBuildError(
            "conformal-hybrid UF protected face is absent from the scaffold boundary"
        )
    protected_z = {
        round(
            _finite(value, field_name="conformal-hybrid UF protected Z"),
            _COORDINATE_DIGITS,
        )
        for value in protected_horizontal_z_values
    }
    protected_keys = set(explicit_protected_keys)
    for key, face in boundary_faces.items():
        z_values = {
            round(point[2], _COORDINATE_DIGITS)
            for point in face
        }
        if len(z_values) == 1 and next(iter(z_values)) in protected_z:
            protected_keys.add(key)
    free_face_keys = set(boundary_faces) - protected_keys
    if not free_face_keys:
        raise PackageBuildError(
            "conformal-hybrid UF has no free exterior QUAD to triangulate"
        )

    candidates: list[
        tuple[int, tuple[tuple[float, float, float], ...]]
    ] = []
    candidate_ranges: dict[int, tuple[int, int, int]] = {}
    for scaffold_index, (_gmsh_type, coordinates) in enumerate(scaffold):
        apex = tuple(
            math.fsum(point[axis] for point in coordinates) / 8.0
            for axis in range(3)
        )
        if _coordinate_key(*apex) in {
            _coordinate_key(*point) for point in coordinates
        }:
            raise PackageBuildError(
                "conformal-hybrid UF HEX8 has a coincident cell centre"
            )
        start = len(candidates)
        free_face_count = 0
        for local_face in ELEMENT_SPECS[5][2]:
            face = tuple(coordinates[index] for index in local_face)
            if _coordinate_face_key(face) in free_face_keys:
                free_face_count += 1
                for triangle in _stable_quad_triangles(face):
                    base = _oriented_tri_base_towards_apex(triangle, apex)
                    candidates.append((4, (*base, apex)))
            else:
                base = _uf_oriented_pyramid_base(face, apex)
                candidates.append((7, (*base, apex)))
        if free_face_count:
            candidate_ranges[scaffold_index] = (
                start,
                len(candidates),
                free_face_count,
            )
        elif len(candidates) != start:
            del candidates[start:]
    metrics = _uf_trace_hybrid_quality_values(candidates)
    output: list[tuple[int, tuple[tuple[float, float, float], ...]]] = []
    accepted_candidate_indices: list[int] = []
    retained_hex8: list[
        tuple[int, tuple[tuple[float, float, float], ...]]
    ] = []
    fallback_count = 0
    converted_count = 0
    free_surface_quad_fallback_count = 0
    for scaffold_index, element in enumerate(scaffold):
        candidate_range = candidate_ranges.get(scaffold_index)
        if candidate_range is None:
            output.append(element)
            retained_hex8.append(element)
            continue
        start, end, free_face_count = candidate_range
        indices = tuple(range(start, end))
        accepted = (
            all(
                math.isfinite(metrics[name][index])
                for name in ("minDetJac", "minSJ", "minSICN", "minSIGE")
                for index in indices
            )
            and all(metrics["minDetJac"][index] > 0.0 for index in indices)
            and all(
                metrics[name][index] >= _HYBRID_DEMO_MIN_QUALITY
                for name in ("minSJ", "minSICN", "minSIGE")
                for index in indices
            )
        )
        if accepted:
            output.extend(candidates[index] for index in indices)
            accepted_candidate_indices.extend(indices)
            converted_count += 1
        else:
            output.append(element)
            retained_hex8.append(element)
            fallback_count += 1
            free_surface_quad_fallback_count += free_face_count
    if not accepted_candidate_indices:
        raise PackageBuildError(
            "conformal-hybrid UF could not triangulate any free-surface HEX8 "
            "above the 0.03 floor"
        )
    if len(output) > _MAXIMUM_UF_TRACE_SWEEP_ELEMENT_COUNT:
        raise PackageBuildError(
            "conformal-hybrid UF exceeds the generated-element resource ceiling: "
            f"elements={len(output)}, limit={_MAXIMUM_UF_TRACE_SWEEP_ELEMENT_COUNT}"
        )
    minima = {
        name: min(metrics[name][index] for index in accepted_candidate_indices)
        for name in metrics
    }
    if retained_hex8:
        fallback_quality = _uf_trace_sweep_quality(retained_hex8)
        minima["minDetJac"] = min(
            minima["minDetJac"],
            fallback_quality.minimum_determinant,
        )
        minima["minSJ"] = min(
            minima["minSJ"],
            fallback_quality.minimum_scaled_jacobian,
        )
        minima["minSICN"] = min(
            minima["minSICN"],
            fallback_quality.minimum_sicn,
        )
        minima["minSIGE"] = min(
            minima["minSIGE"],
            fallback_quality.minimum_sige,
        )
    quality = _UfTraceSweepQuality(
        minimum_determinant=minima["minDetJac"],
        minimum_scaled_jacobian=minima["minSJ"],
        minimum_sicn=minima["minSICN"],
        minimum_sige=minima["minSIGE"],
    )
    if not quality.passes:
        raise PackageBuildError(
            "conformal-hybrid UF output failed the fixed 0.03 quality floor"
        )
    tet4_count = sum(
        candidates[index][0] == 4
        for index in accepted_candidate_indices
    )
    pyramid5_count = len(accepted_candidate_indices) - tet4_count
    stats = _UfTraceAppliedTopologyStats(
        element_count=len(output),
        hex8_count=len(retained_hex8),
        pyramid5_count=pyramid5_count,
        tet4_count=tet4_count,
        quality_fallback_hex8_count=fallback_count,
        star_converted_hex8_count=converted_count,
        free_surface_tri3_count=tet4_count,
        free_surface_quad_fallback_count=free_surface_quad_fallback_count,
    )
    return tuple(output), stats, quality


def _audit_orthogonal_hex_coordinates(
    elements: Sequence[
        tuple[int, Sequence[tuple[float, float, float]]]
    ],
) -> None:
    """Prove that every element is an axis-aligned orthogonal HEX8 brick.

    ``orthogonal_hex`` deliberately includes its staircase boundary policy:
    only complete Cartesian cells are retained and every cut cell is omitted.
    Merely counting HEX8 elements is insufficient because a skewed swept HEX8
    would have the same element kind.
    """

    if not elements:
        raise PackageBuildError("orthogonal-HEX lower UF is empty")
    for gmsh_type, raw_coordinates in elements:
        coordinates = tuple(_coordinate_key(*point) for point in raw_coordinates)
        if gmsh_type != 5 or len(coordinates) != 8 or len(set(coordinates)) != 8:
            raise PackageBuildError(
                "orthogonal-HEX lower UF must contain only distinct HEX8 nodes"
            )
        axis_values = tuple(
            tuple(sorted({point[axis] for point in coordinates}))
            for axis in range(3)
        )
        if any(
            len(values) != 2
            or values[1] - values[0] <= _COORDINATE_TOLERANCE_MM
            for values in axis_values
        ):
            raise PackageBuildError(
                "orthogonal-HEX lower UF contains a non-Cartesian HEX8"
            )
        expected = {
            (x, y, z)
            for x in axis_values[0]
            for y in axis_values[1]
            for z in axis_values[2]
        }
        if set(coordinates) != expected:
            raise PackageBuildError(
                "orthogonal-HEX lower UF contains a skewed or non-axis-aligned HEX8"
            )


def _select_uf_trace_planar_candidate(
    stack: ResolvedPackageStack,
    ports: Sequence[CornerPort],
    central_cells: Sequence[tuple[tuple[float, float], ...]],
    z_levels_mm: Sequence[float],
    locked_trace_edges: set[
        tuple[tuple[float, float], tuple[float, float]]
    ],
    *,
    requested_target_edge_mm: float,
    requested_transition_distance_mm: float,
    package_far_field_size_mm: float,
    package_transition_distance_mm: float,
    verbose: bool,
) -> _UfTracePlanarCandidate:
    """Choose one graded QUAD partition whose fresh HEX sweep passes quality."""

    native_edge = min(min(port.size_x_mm, port.size_y_mm) for port in ports)
    failures: list[str] = []
    seen: set[tuple[float, float]] = set()
    for scale in (1.0, 0.75, 0.5, 0.375, 0.25, 0.1875, 0.125, 0.09375, 0.0625):
        effective_target = max(native_edge, requested_target_edge_mm * scale)
        effective_transition = requested_transition_distance_mm
        key = (
            round(effective_target, _COORDINATE_DIGITS),
            round(effective_transition, _COORDINATE_DIGITS),
        )
        if key in seen:
            continue
        seen.add(key)
        radial_offsets = _uf_target_radial_offsets(
            stack.uf_width_mm,
            native_edge,
            effective_target,
            effective_transition,
        )
        domain = _build_package_planar_domain(
            stack,
            ports,
            central_cells,
            far_field_size_mm=package_far_field_size_mm,
            transition_distance_mm=package_transition_distance_mm,
            uf_radial_offsets_mm=radial_offsets,
            verbose=verbose,
        )
        base_cells = _uf_trace_base_cells(stack, domain.uf_control_cells)
        x_min, x_max, y_min, y_max = stack.die_bounds_xy_mm
        generated_inner_edges = {
            tuple(sorted((_xy_key(*first), _xy_key(*second))))
            for first, second in _cell_boundary_edges(base_cells)
            if (
                (
                    (
                        (_close(first[0], x_min) and _close(second[0], x_min))
                        or (_close(first[0], x_max) and _close(second[0], x_max))
                    )
                    and y_min - _COORDINATE_TOLERANCE_MM
                    <= first[1]
                    <= y_max + _COORDINATE_TOLERANCE_MM
                    and y_min - _COORDINATE_TOLERANCE_MM
                    <= second[1]
                    <= y_max + _COORDINATE_TOLERANCE_MM
                )
                or (
                    (
                        (_close(first[1], y_min) and _close(second[1], y_min))
                        or (_close(first[1], y_max) and _close(second[1], y_max))
                    )
                    and x_min - _COORDINATE_TOLERANCE_MM
                    <= first[0]
                    <= x_max + _COORDINATE_TOLERANCE_MM
                    and x_min - _COORDINATE_TOLERANCE_MM
                    <= second[0]
                    <= x_max + _COORDINATE_TOLERANCE_MM
                )
            )
        }
        if generated_inner_edges != locked_trace_edges:
            raise PackageBuildError(
                "trace-only target QUAD partition differs from the exact locked "
                f"wall trace: generated={len(generated_inner_edges)}, "
                f"locked={len(locked_trace_edges)}, "
                f"missing={len(locked_trace_edges - generated_inner_edges)}, "
                f"extra={len(generated_inner_edges - locked_trace_edges)}"
            )
        elements, stats = _uf_trace_sweep_element_coordinates(
            stack,
            base_cells,
            z_levels_mm,
        )
        if stats.hex8_count != stats.element_count:
            raise PackageBuildError(
                "trace-only generated planar partition did not sweep exclusively "
                "from QUAD4 to fresh HEX8"
            )
        quality = _uf_trace_sweep_quality(elements)
        if quality.passes:
            return _UfTracePlanarCandidate(
                domain=domain,
                effective_target_edge_mm=effective_target,
                effective_transition_distance_mm=effective_transition,
                quality=quality,
                stats=stats,
            )
        failures.append(
            f"target={effective_target:.8g}, transition={effective_transition:.8g}, "
            f"minDetJac={quality.minimum_determinant:.8g}, "
            f"minSJ={quality.minimum_scaled_jacobian:.8g}, "
            f"minSICN={quality.minimum_sicn:.8g}, "
            f"minSIGE={quality.minimum_sige:.8g}"
        )
    raise PackageBuildError(
        "trace-only UF target candidates fail the fixed 0.03 quality floor: "
        + "; ".join(failures)
    )


def _uf_trace_base_cells(
    stack: ResolvedPackageStack,
    control_cells: Sequence[Sequence[tuple[float, float]]],
) -> tuple[tuple[tuple[float, float], ...], ...]:
    """Return the closed ring/UF base partition for trace-only meshing.

    The cells are package-generated interface faces, not Frozen volume cells.
    Their inner loop reuses the connected-bump trace while the envelope test
    removes the square background cells that lie outside the rounded toe.
    """

    envelope = RectangularUfEnvelope(
        die_width=stack.uf_die_width_mm,
        die_length=stack.uf_die_length_mm,
        base_z=stack.uf_base_mm,
        height=stack.uf_height_mm,
        fillet_width=stack.uf_width_mm,
    )
    cells = tuple(
        tuple(cell)
        for cell in control_cells
        if all(
            envelope.contains(x, y, stack.uf_base_mm)
            for x, y in cell
        )
    )
    if not cells:
        raise PackageBuildError("trace-only UF base annulus is empty")
    canonical = tuple(
        tuple(sorted(_xy_key(*point) for point in cell)) for cell in cells
    )
    if len(set(canonical)) != len(canonical):
        raise PackageBuildError("trace-only UF base annulus contains duplicate cells")
    boundary = _cell_boundary_edges(cells)
    if not boundary:
        raise PackageBuildError("trace-only UF base annulus has no boundary")
    adjacency: dict[tuple[float, float], set[tuple[float, float]]] = defaultdict(set)
    for first, second in boundary:
        adjacency[first].add(second)
        adjacency[second].add(first)
    if any(len(neighbors) != 2 for neighbors in adjacency.values()):
        raise PackageBuildError(
            "trace-only UF base annulus boundary is not a pair of closed loops"
        )
    unvisited = set(adjacency)
    loop_count = 0
    while unvisited:
        loop_count += 1
        start = min(unvisited)
        current = start
        previous: tuple[float, float] | None = None
        while True:
            unvisited.discard(current)
            candidates = adjacency[current] - ({previous} if previous is not None else set())
            following = min(candidates) if candidates else start
            previous, current = current, following
            if current == start:
                break
    if loop_count != 2:
        raise PackageBuildError(
            "trace-only UF base annulus must have exactly inner and outer loops"
        )
    return cells


def _add_uf_hex_staircase(
    builder: _PlanBuilder,
    stack: ResolvedPackageStack,
    ports: Sequence[CornerPort],
    control_cells: Sequence[Sequence[tuple[float, float]]],
    *,
    material: str,
    above_bump_target_mm: float | None = None,
    z_levels_mm: Sequence[float] | None = None,
    component: str = "UF_FILLET",
    zone: str = "UF_HEX_CORE",
    generation_provenance: str = "selected_volume_backend",
) -> _UfMeshStats:
    # ``control_cells`` comes from _build_package_planar_domain and is also
    # consumed by the two ring sweeps.  Do not reconstruct an equivalent grid
    # here: coordinate coincidence is insufficient when exact face keys are
    # required at the RING_2/UF interface.
    cells = tuple(control_cells)
    canonical_cells = [tuple(sorted(_xy_key(*point) for point in cell)) for cell in cells]
    if len(canonical_cells) != len(set(canonical_cells)):
        raise PackageBuildError("corner and straight UF control cells overlap")
    if z_levels_mm is None:
        levels = _uf_z_levels(
            stack,
            ports,
            above_bump_target_mm=above_bump_target_mm,
        )
    else:
        if above_bump_target_mm is not None:
            raise PackageBuildError(
                "explicit UF Z levels and above-bump target are mutually exclusive"
            )
        levels = tuple(
            _finite(value, field_name="UF explicit Z level")
            for value in z_levels_mm
        )
        if len(levels) < 2 or any(
            upper <= lower for lower, upper in zip(levels, levels[1:])
        ):
            raise PackageBuildError("explicit UF Z levels must be strictly increasing")
        if (
            levels[0] < stack.uf_base_mm - _COORDINATE_TOLERANCE_MM
            or levels[-1] > stack.uf_top_mm + _COORDINATE_TOLERANCE_MM
        ):
            raise PackageBuildError("explicit UF Z levels escape the analytic envelope")
    envelope = RectangularUfEnvelope(
        die_width=stack.uf_die_width_mm,
        die_length=stack.uf_die_length_mm,
        base_z=stack.uf_base_mm,
        height=stack.uf_height_mm,
        fillet_width=stack.uf_width_mm,
    )
    full_hex_count = 0
    cut_cell_count = 0
    outside_cell_count = 0
    for cell in cells:
        x_values = tuple(point[0] for point in cell)
        y_values = tuple(point[1] for point in cell)
        x_min, x_max = min(x_values), max(x_values)
        y_min, y_max = min(y_values), max(y_values)
        if len(set(x_values)) != 2 or len(set(y_values)) != 2:
            raise PackageBuildError("UF background cells must be axis-aligned quads")
        for z0, z1 in zip(levels, levels[1:]):
            background = CartesianCell(x_min, x_max, y_min, y_max, z0, z1)
            classification = envelope.classify_cell(background)
            if classification.kind is UfCellClass.OUTSIDE:
                outside_cell_count += 1
                continue
            if classification.kind is UfCellClass.FULL_HEX:
                full_hex_count += 1
                lower = tuple(builder.registry.add(x, y, z0) for x, y in cell)
                upper = tuple(builder.registry.add(x, y, z1) for x, y in cell)
                builder.add_element(
                    5,
                    (*lower, *upper),
                    material=material,
                    component=component,
                    zone=zone,
                    generation_provenance=generation_provenance,
                )
                continue

            cut_cell_count += 1
            # Production fallback: retain a conservative, fully HEX
            # staircase core. Partial skin coverage would leave cracks, so
            # every CUT cell is skipped as one explicit policy. The separate
            # uf_cut_cell module remains an experimental development kernel.
            continue
    return _UfMeshStats(
        full_hex_count=full_hex_count,
        cut_cell_count=cut_cell_count,
        outside_cell_count=outside_cell_count,
    )


def _add_uf_trace_surface_sweep(
    builder: _PlanBuilder,
    stack: ResolvedPackageStack,
    control_cells: Sequence[Sequence[tuple[float, float]]],
    z_levels_mm: Sequence[float],
    *,
    material: str,
    volume_topology: str,
    locked_side_facets: Sequence[Sequence[int]] = (),
    target_edge_mm: float | None = None,
    transition_distance_mm: float | None = None,
    near_size_mm: float | None = None,
    verbose: bool = False,
) -> tuple[
    _UfTraceSweepStats,
    _UfTraceAppliedTopologyStats,
    _UfTraceSweepQuality | None,
    tuple[PackageElement, ...],
    tuple[tuple[int, tuple[tuple[float, float, float], ...]], ...],
]:
    """Append the explicitly selected fresh lower-UF volume topology."""

    topology = normalize_underfill_core_volume_topology(volume_topology)
    if topology == "structured_sweep":
        scaffold_elements, stats = _uf_structured_section_sweep_coordinates(
            stack,
            control_cells,
            z_levels_mm,
        )
    else:
        scaffold_elements, stats = _uf_trace_sweep_element_coordinates(
            stack,
            control_cells,
            z_levels_mm,
        )
    if stats.hex8_count != stats.element_count:
        raise PackageBuildError(
            "trace-only lower UF must be generated exclusively as HEX8"
        )
    if topology == "conformal_hybrid":
        if (
            target_edge_mm is None
            or transition_distance_mm is None
            or near_size_mm is None
        ):
            raise PackageBuildError(
                "direct conformal UF requires target, near and transition sizes"
            )
        base_coordinates, base_facets = _registered_planar_facets(
            builder.registry,
            control_cells,
            stack.uf_base_mm,
        )
        del base_coordinates
        envelope = RectangularUfEnvelope(
            die_width=stack.uf_die_width_mm,
            die_length=stack.uf_die_length_mm,
            base_z=stack.uf_base_mm,
            height=stack.uf_height_mm,
            fillet_width=stack.uf_width_mm,
        )
        wall_locks = _group_uf_die_wall_facets_by_side(
            locked_side_facets,
            builder.registry,
            envelope,
        )
        volume, boundaries, appended = _append_direct_gmsh_uf_volume(
            builder,
            envelope,
            stack.uf_base_mm,
            stack.bump_top_mm,
            {"base": base_facets, **wall_locks},
            target_size_mm=target_edge_mm,
            near_size_mm=near_size_mm,
            transition_distance_mm=transition_distance_mm,
            material=material,
            component="UF_CORNER_CORE",
            zone="UF_TRACE_CORE_FRESH_CONFORMAL_HYBRID",
            verbose=verbose,
        )
        if volume.wedge6_count:
            raise PackageBuildError(
                "direct UF returned WEDGE6 but the narrow legacy summary has no "
                "WEDGE6 field; use the clean Package V2 component evidence path"
            )
        applied_stats = _UfTraceAppliedTopologyStats(
            element_count=volume.element_count,
            hex8_count=0,
            pyramid5_count=volume.pyramid5_count,
            tet4_count=volume.tet4_count,
            quality_fallback_hex8_count=0,
            star_converted_hex8_count=0,
            free_surface_tri3_count=sum(
                len(facet) == 3 for facet in boundaries["free_surface"]
            ),
            free_surface_quad_fallback_count=sum(
                len(facet) == 4 for facet in boundaries["free_surface"]
            ),
        )
        applied_quality = _UfTraceSweepQuality(
            minimum_determinant=volume.minimum_determinant,
            minimum_scaled_jacobian=volume.minimum_scaled_jacobian,
            minimum_sicn=volume.minimum_sicn,
            minimum_sige=volume.minimum_sige,
        )
        return stats, applied_stats, applied_quality, appended, ()
    elif topology == "orthogonal_hex":
        _audit_orthogonal_hex_coordinates(scaffold_elements)
        coordinate_elements = scaffold_elements
        applied_stats = _UfTraceAppliedTopologyStats(
            element_count=stats.element_count,
            hex8_count=stats.hex8_count,
            pyramid5_count=0,
            tet4_count=0,
            quality_fallback_hex8_count=0,
            star_converted_hex8_count=0,
            free_surface_tri3_count=0,
            free_surface_quad_fallback_count=0,
        )
        applied_quality = None
        zone = "UF_TRACE_CORE_FRESH_ORTHOGONAL_HEX"
    elif topology == "structured_sweep":
        coordinate_elements = scaffold_elements
        applied_stats = _UfTraceAppliedTopologyStats(
            element_count=stats.element_count,
            hex8_count=stats.hex8_count,
            pyramid5_count=0,
            tet4_count=0,
            quality_fallback_hex8_count=0,
            star_converted_hex8_count=0,
            free_surface_tri3_count=0,
            free_surface_quad_fallback_count=0,
        )
        applied_quality = None
        zone = "UF_TRACE_CORE_STRUCTURED_SWEEP"
    else:
        raise AssertionError(f"unsupported lower-UF topology: {topology}")
    start = len(builder.elements)
    for gmsh_type, coordinates in coordinate_elements:
        builder.add_element(
            gmsh_type,
            tuple(builder.registry.add(*point) for point in coordinates),
            material=material,
            component="UF_CORNER_CORE",
            zone=zone,
        )
    appended = tuple(builder.elements[start:])
    if len(appended) != applied_stats.element_count:
        raise PackageBuildError(
            "trace-only UF generated element count differs from its applied topology"
        )
    return stats, applied_stats, applied_quality, appended, scaffold_elements


def _audit_uf_trace_surface_sweep(
    generated_elements: Sequence[PackageElement],
    source_elements: Sequence[PackageElement],
    ring_elements: Sequence[PackageElement],
    control_cells: Sequence[Sequence[tuple[float, float]]],
    locked_side_facets: Sequence[Sequence[int]],
    z_levels_mm: Sequence[float],
    registry: _NodeRegistry,
    stack: ResolvedPackageStack,
    scaffold_elements: Sequence[
        tuple[int, Sequence[tuple[float, float, float]]]
    ],
    expected_stats: _UfTraceSweepStats,
    applied_stats: _UfTraceAppliedTopologyStats,
    applied_topology: str,
) -> tuple[tuple[tuple[int, ...], ...], _UfTraceSurfaceAuditStats]:
    """Prove exact side/base/top ownership for the fresh lower-UF sweep."""

    topology = normalize_underfill_core_volume_topology(applied_topology)
    elements = tuple(generated_elements)
    if not elements or any(
        element.gmsh_type not in {4, 5, 6, 7} for element in elements
    ):
        raise PackageBuildError(
            "trace-only lower UF contains an unsupported generated element"
        )
    if topology == "orthogonal_hex":
        _audit_orthogonal_hex_coordinates(
            tuple(
                (
                    element.gmsh_type,
                    tuple(
                        registry.nodes_by_tag[tag].coordinates
                        for tag in element.node_tags
                    ),
                )
                for element in elements
            )
        )
    elif topology not in {"conformal_hybrid", "structured_sweep"}:
        raise PackageBuildError(
            "trace-only generated lower UF has an unsupported applied topology"
        )
    actual_kind_counts = Counter(element.gmsh_type for element in elements)
    if (
        len(elements) != applied_stats.element_count
        or actual_kind_counts[5] != applied_stats.hex8_count
        or actual_kind_counts[7] != applied_stats.pyramid5_count
        or actual_kind_counts[4] != applied_stats.tet4_count
        or (
            topology == "conformal_hybrid"
            and (
                actual_kind_counts[6]
                or applied_stats.hex8_count
                or applied_stats.tet4_count < 1
                or applied_stats.star_converted_hex8_count
                or applied_stats.quality_fallback_hex8_count
            )
        )
        or (
            topology == "orthogonal_hex"
            and (
                applied_stats.hex8_count != expected_stats.element_count
                or applied_stats.pyramid5_count
                or applied_stats.tet4_count
                or applied_stats.star_converted_hex8_count
                or applied_stats.quality_fallback_hex8_count
                or applied_stats.free_surface_tri3_count
                or applied_stats.free_surface_quad_fallback_count
            )
        )
        or (
            topology == "structured_sweep"
            and (
                applied_stats.hex8_count != expected_stats.element_count
                or applied_stats.pyramid5_count
                or applied_stats.tet4_count
                or applied_stats.star_converted_hex8_count
                or applied_stats.quality_fallback_hex8_count
                or applied_stats.free_surface_tri3_count
                or applied_stats.free_surface_quad_fallback_count
            )
        )
    ):
        raise PackageBuildError(
            "trace-only lower UF applied-topology count audit failed"
        )
    connectivity = tuple((element.gmsh_type, element.node_tags) for element in elements)
    if len(set(connectivity)) != len(connectivity):
        raise PackageBuildError(
            "trace-only lower UF contains duplicate generated connectivity"
        )
    source_connectivity = {
        (element.gmsh_type, tuple(sorted(element.node_tags)))
        for element in source_elements
    }
    generated_connectivity = {
        (element.gmsh_type, tuple(sorted(element.node_tags)))
        for element in elements
    }
    if source_connectivity & generated_connectivity:
        raise PackageBuildError(
            "trace-only lower UF duplicated Frozen volume connectivity"
        )
    locked_nodes = {tag for facet in locked_side_facets for tag in facet}
    source_nodes = {tag for element in source_elements for tag in element.node_tags}
    generated_nodes = {tag for element in elements for tag in element.node_tags}
    if generated_nodes & source_nodes != locked_nodes:
        raise PackageBuildError(
            "trace-only lower UF/source shared-node set differs from the locked wall"
        )
    level_keys = tuple(round(value, _COORDINATE_DIGITS) for value in z_levels_mm)
    level_index = {value: index for index, value in enumerate(level_keys)}
    if not applied_stats.pyramid5_count:
        generated_level_keys: set[float] = set()
        for element in elements:
            z_counts = Counter(
                round(registry.nodes_by_tag[tag].z, _COORDINATE_DIGITS)
                for tag in element.node_tags
            )
            if (
                len(z_counts) != 2
                or sorted(z_counts.values()) != [4, 4]
                or any(value not in level_index for value in z_counts)
            ):
                raise PackageBuildError(
                    "trace-only lower UF HEX8 does not use two locked facet levels"
                )
            lower, upper = sorted(z_counts)
            if level_index[upper] != level_index[lower] + 1:
                raise PackageBuildError(
                    "trace-only lower UF HEX8 skips a locked facet Z level"
                )
            generated_level_keys.update(z_counts)
        if generated_level_keys != set(level_keys):
            raise PackageBuildError(
                "trace-only lower UF Z set differs from locked side facet levels"
            )
    incidence = _face_incidence(elements)
    if any(len(owners) not in {1, 2} for owners in incidence.values()):
        raise PackageBuildError(
            "trace-only lower UF contains a non-manifold generated face"
        )

    locked_keys = {tuple(sorted(facet)) for facet in locked_side_facets}
    generated_side_keys = {
        key
        for key, owners in incidence.items()
        if len(owners) == 1
        and _is_die_inner_wall_face(
            owners[0][1],
            registry,
            stack,
            stack.uf_base_mm,
            stack.bump_top_mm,
        )
    }
    if generated_side_keys != locked_keys:
        raise PackageBuildError(
            "trace-only lower UF does not reproduce every exact locked side face key: "
            f"generated={len(generated_side_keys)}, locked={len(locked_keys)}, "
            f"missing={len(locked_keys - generated_side_keys)}, "
            f"extra={len(generated_side_keys - locked_keys)}"
        )
    if any(
        len(incidence.get(key, ())) != 1
        or incidence[key][0][0].gmsh_type not in {5, 7}
        for key in locked_keys
    ):
        raise PackageBuildError(
            "trace-only lower UF locked side face lacks one conformal owner"
        )

    allowed_base_keys: set[tuple[int, ...]] = set()
    for cell in control_cells:
        tags: list[int] = []
        for x, y in cell:
            tag = registry.tag_at(x, y, stack.uf_base_mm)
            if tag is None:
                raise PackageBuildError(
                    "trace-only UF base control references an unregistered node"
                )
            tags.append(tag)
        allowed_base_keys.add(tuple(sorted(tags)))
    base_facets = _horizontal_boundary_facets(
        elements,
        registry,
        stack.uf_base_mm,
    )
    base_keys = {tuple(sorted(facet)) for facet in base_facets}
    if (
        not base_keys
        or any(len(facet) != 4 for facet in base_facets)
        or not base_keys <= allowed_base_keys
        or any(len(incidence[key]) != 1 for key in base_keys)
    ):
        raise PackageBuildError(
            "trace-only lower UF base seam is not an exact generated QUAD4 subset"
        )
    ring_incidence = _face_incidence(tuple(ring_elements))
    if any(
        len(ring_incidence.get(key, ())) != 1
        for key in base_keys
    ):
        raise PackageBuildError(
            "trace-only lower UF base seam lacks one exact RING_2 owner per face"
        )

    top_facets = _horizontal_boundary_facets(
        elements,
        registry,
        stack.bump_top_mm,
    )
    top_keys = {tuple(sorted(facet)) for facet in top_facets}
    if (
        not top_keys
        or len(top_keys) != len(top_facets)
        or (
            topology != "conformal_hybrid"
            and any(len(facet) != 4 for facet in top_facets)
        )
        or any(len(facet) not in {3, 4} for facet in top_facets)
        or any(len(incidence[key]) != 1 for key in top_keys)
        or base_keys & top_keys
    ):
        raise PackageBuildError(
            "trace-only lower UF top seam is not a unique single-owner QUAD4 surface"
        )
    exterior_keys = {
        key
        for key, owners in incidence.items()
        if len(owners) == 1
        and key not in locked_keys
        and key not in base_keys
        and key not in top_keys
    }
    if any(len(incidence[key][0][1]) not in {3, 4} for key in exterior_keys):
        raise PackageBuildError(
            "trace-only lower UF free surface contains a non-TRI/QUAD face"
        )

    if topology == "conformal_hybrid":
        free_surface_tri3_count = sum(
            len(incidence[key][0][1]) == 3 for key in exterior_keys
        )
        free_surface_quad_count = sum(
            len(incidence[key][0][1]) == 4 for key in exterior_keys
        )
        exterior_quad_owned_by_non_hex_count = sum(
            len(incidence[key][0][1]) == 4
            and incidence[key][0][0].gmsh_type != 5
            for key in exterior_keys
        )
        surface_stats = _UfTraceSurfaceAuditStats(
            free_surface_tri3_count=free_surface_tri3_count,
            free_surface_quad_fallback_count=free_surface_quad_count,
            exterior_quad_owned_by_non_hex_count=(
                exterior_quad_owned_by_non_hex_count
            ),
        )
        if (
            free_surface_tri3_count < 1
            or free_surface_tri3_count
            != applied_stats.free_surface_tri3_count
            or free_surface_quad_count
            != applied_stats.free_surface_quad_fallback_count
        ):
            raise PackageBuildError(
                "direct Gmsh UF free-surface recount differs from backend evidence"
            )
        return top_facets, surface_stats

    original_boundary_faces = _uf_scaffold_boundary_faces(scaffold_elements)
    locked_coordinate_keys = {
        _coordinate_face_key(
            tuple(registry.nodes_by_tag[tag].coordinates for tag in facet)
        )
        for facet in locked_side_facets
    }
    original_base_coordinate_keys = {
        key
        for key, face in original_boundary_faces.items()
        if all(_close(point[2], stack.uf_base_mm) for point in face)
    }
    original_top_coordinate_keys = {
        key
        for key, face in original_boundary_faces.items()
        if all(_close(point[2], stack.bump_top_mm) for point in face)
    }
    if not (
        locked_coordinate_keys <= set(original_boundary_faces)
        and original_base_coordinate_keys
        and original_top_coordinate_keys
    ):
        raise PackageBuildError(
            "trace-only lower UF scaffold lacks a protected wall/base/top face"
        )

    def coordinate_keys_for_tag_faces(
        faces: Iterable[Sequence[int]],
    ) -> set[tuple[tuple[float, float, float], ...]]:
        return {
            _coordinate_face_key(
                tuple(registry.nodes_by_tag[tag].coordinates for tag in face)
            )
            for face in faces
        }

    if (
        coordinate_keys_for_tag_faces(base_facets)
        != original_base_coordinate_keys
        or coordinate_keys_for_tag_faces(top_facets)
        != original_top_coordinate_keys
    ):
        raise PackageBuildError(
            "trace-only lower UF changed a protected base/top QUAD"
        )
    expected_free_faces = {
        key: face
        for key, face in original_boundary_faces.items()
        if key not in locked_coordinate_keys
        and key not in original_base_coordinate_keys
        and key not in original_top_coordinate_keys
    }
    if not expected_free_faces:
        raise PackageBuildError("trace-only lower UF has no audited free surface")

    def tag_face_key(
        face: Sequence[tuple[float, float, float]],
    ) -> tuple[int, ...]:
        tags: list[int] = []
        for point in face:
            tag = registry.tag_at(*point)
            if tag is None:
                raise PackageBuildError(
                    "trace-only lower UF surface references an unregistered node"
                )
            tags.append(tag)
        return tuple(sorted(tags))

    accounted_exterior_keys: set[tuple[int, ...]] = set()
    free_surface_tri3_count = 0
    free_surface_quad_fallback_count = 0
    for face in expected_free_faces.values():
        quad_key = tag_face_key(face)
        triangle_keys = {
            tag_face_key(triangle)
            for triangle in _stable_quad_triangles(face)
        }
        if quad_key in exterior_keys:
            if triangle_keys & exterior_keys:
                raise PackageBuildError(
                    "trace-only lower UF free QUAD is both retained and triangulated"
                )
            owner, owner_face = incidence[quad_key][0]
            if owner.gmsh_type != 5 or len(owner_face) != 4:
                raise PackageBuildError(
                    "trace-only lower UF fallback QUAD is not owned by one HEX8"
                )
            accounted_exterior_keys.add(quad_key)
            free_surface_quad_fallback_count += 1
        else:
            present_triangle_keys = triangle_keys & exterior_keys
            if present_triangle_keys != triangle_keys or any(
                incidence[key][0][0].gmsh_type != 4
                or len(incidence[key][0][1]) != 3
                for key in triangle_keys
            ):
                raise PackageBuildError(
                    "trace-only lower UF free QUAD is not covered by its stable TRI pair"
                )
            accounted_exterior_keys.update(triangle_keys)
            free_surface_tri3_count += 2
    if accounted_exterior_keys != exterior_keys:
        raise PackageBuildError(
            "trace-only lower UF free surface contains an extra or missing face"
        )

    exterior_quad_owned_by_non_hex_count = sum(
        len(owner_face) == 4 and owner.gmsh_type != 5
        for owners in incidence.values()
        if len(owners) == 1
        for owner, owner_face in owners
    )
    if topology == "orthogonal_hex":
        if free_surface_tri3_count:
            raise PackageBuildError(
                "orthogonal-HEX lower UF unexpectedly triangulated its free surface"
            )
        surface_stats = _UfTraceSurfaceAuditStats(0, 0, 0)
    else:
        surface_stats = _UfTraceSurfaceAuditStats(
            free_surface_tri3_count=free_surface_tri3_count,
            free_surface_quad_fallback_count=(
                free_surface_quad_fallback_count
            ),
            exterior_quad_owned_by_non_hex_count=(
                exterior_quad_owned_by_non_hex_count
            ),
        )
        if (
            surface_stats.free_surface_tri3_count < 1
            or surface_stats.free_surface_tri3_count
            != applied_stats.free_surface_tri3_count
            or surface_stats.free_surface_quad_fallback_count
            != applied_stats.free_surface_quad_fallback_count
        ):
            raise PackageBuildError(
                "conformal-hybrid UF free-surface recount differs from conversion evidence"
            )
    return top_facets, surface_stats


def _component_boundary_skins(
    elements: Sequence[PackageElement],
) -> dict[str, dict[tuple[int, ...], tuple[int, ...]]]:
    """Return the exact node-keyed boundary skin of every package component."""

    elements_by_component: dict[str, list[PackageElement]] = defaultdict(list)
    for element in elements:
        elements_by_component[element.component].append(element)

    skins: dict[str, dict[tuple[int, ...], tuple[int, ...]]] = {}
    for component, component_elements in sorted(elements_by_component.items()):
        incidence = _face_incidence(component_elements)
        nonmanifold = [key for key, owners in incidence.items() if len(owners) > 2]
        if nonmanifold:
            raise PackageBuildError(
                f"component {component!r} contains a non-manifold volume face"
            )
        skins[component] = {
            key: owners[0][1]
            for key, owners in incidence.items()
            if len(owners) == 1
        }
    return skins


def _require_component_skin_on_box_boundary(
    component: str,
    skin: Mapping[tuple[int, ...], tuple[int, ...]],
    registry: _NodeRegistry,
    bounds_xy_mm: tuple[float, float, float, float],
    z_min_mm: float,
    z_max_mm: float,
) -> None:
    """Reject unmatched component faces that lie inside an expected box.

    A component-local face incidence audit alone accepts a crack: both sides
    of an unshared internal interface simply appear as boundary faces.  For a
    component whose intended support is one axis-aligned box, every legitimate
    boundary face must instead lie wholly on one of the six outer planes.
    This remains valid when an outer plane is partitioned into TRI3/QUAD4
    facets, so it also covers the hybrid added-Si transition.
    """

    if not skin:
        raise PackageBuildError(f"component {component!r} has an empty boundary skin")
    x_min, x_max, y_min, y_max = bounds_xy_mm
    if x_max <= x_min or y_max <= y_min or z_max_mm <= z_min_mm:
        raise PackageBuildError(
            f"component {component!r} has invalid expected box bounds"
        )
    box_bounds = (
        ("x", x_min, x_max),
        ("y", y_min, y_max),
        ("z", z_min_mm, z_max_mm),
    )
    interior_faces: list[tuple[int, ...]] = []
    for face in skin.values():
        try:
            nodes = tuple(registry.nodes_by_tag[tag] for tag in face)
        except KeyError as error:
            raise PackageBuildError(
                f"component {component!r} skin references an unknown node"
            ) from error
        for axis, lower, upper in box_bounds:
            coordinates = tuple(getattr(node, axis) for node in nodes)
            if any(
                value < lower - _COORDINATE_TOLERANCE_MM
                or value > upper + _COORDINATE_TOLERANCE_MM
                for value in coordinates
            ):
                raise PackageBuildError(
                    f"component {component!r} boundary escapes its expected box"
                )
        on_outer_plane = any(
            all(_close(getattr(node, axis), plane) for node in nodes)
            for axis, lower, upper in box_bounds
            for plane in (lower, upper)
        )
        if not on_outer_plane:
            interior_faces.append(face)
    if interior_faces:
        raise PackageBuildError(
            f"component {component!r} contains {len(interior_faces)} internal "
            "boundary faces (crack or cavity)"
        )


def _component_boundary_topology_from_skins(
    skins: Mapping[str, Mapping[tuple[int, ...], tuple[int, ...]]],
) -> tuple[int, int]:
    owners_by_skin_face: Counter[tuple[int, ...]] = Counter()
    for skin in skins.values():
        owners_by_skin_face.update(skin.keys())

    multiply_owned = [
        key for key, owner_count in owners_by_skin_face.items() if owner_count > 2
    ]
    if multiply_owned:
        raise PackageBuildError("more than two package components share one face")
    return (
        sum(owner_count == 2 for owner_count in owners_by_skin_face.values()),
        sum(owner_count == 1 for owner_count in owners_by_skin_face.values()),
    )


def _component_boundary_topology(
    elements: Sequence[PackageElement],
) -> tuple[int, int]:
    """Count component interfaces and exterior facets without one global face map.

    Building a dictionary for every face of the complete package would defeat
    the mesh-size controls this assembler is intended to provide.  Component
    skins are much smaller, so each union is reduced independently and only
    those skins are compared across the assembly.
    """

    return _component_boundary_topology_from_skins(
        _component_boundary_skins(elements)
    )


def _horizontal_skin_face_keys(
    skin: Mapping[tuple[int, ...], tuple[int, ...]],
    registry: _NodeRegistry,
    z_value: float,
) -> set[tuple[int, ...]]:
    return {
        key
        for key, face in skin.items()
        if all(_close(registry.nodes_by_tag[tag].z, z_value) for tag in face)
    }


def _require_exact_interface(
    name: str,
    first: set[tuple[int, ...]],
    second: set[tuple[int, ...]],
    *,
    first_must_be_subset: bool = False,
) -> int:
    if not first:
        raise PackageBuildError(f"required package interface {name} is empty")
    missing_from_second = first - second
    unmatched_in_second = set() if first_must_be_subset else second - first
    if missing_from_second or unmatched_in_second:
        relation = "subset" if first_must_be_subset else "equality"
        raise PackageBuildError(
            f"package interface {name} fails exact face-key {relation}: "
            f"first={len(first)}, second={len(second)}, "
            f"missing_from_second={len(missing_from_second)}, "
            f"unmatched_in_second={len(unmatched_in_second)}"
        )
    return len(first)


def _require_exact_uf_split_interface(
    lower_elements: Sequence[PackageElement],
    upper_elements: Sequence[PackageElement],
    registry: _NodeRegistry,
    z_value: float,
    *,
    required_face_size: int = 4,
) -> int:
    """Prove that lower/upper UF meet on one full exact seam.

    Equality is intentional: accepting a subset would silently turn omitted
    lower faces into a horizontal UF shelf.  Both the legacy lower HEX core
    and the fresh trace-controlled HEX sweep expose QUAD4 seams.  The
    half-space checks also make positive-volume overlap across the seam
    impossible.
    """

    if not lower_elements or not upper_elements:
        raise PackageBuildError("split UF interface requires lower and upper elements")
    if any(
        registry.nodes_by_tag[tag].z > z_value + _COORDINATE_TOLERANCE_MM
        for element in lower_elements
        for tag in element.node_tags
    ):
        raise PackageBuildError("lower UF crosses above its split interface")
    if any(
        registry.nodes_by_tag[tag].z < z_value - _COORDINATE_TOLERANCE_MM
        for element in upper_elements
        for tag in element.node_tags
    ):
        raise PackageBuildError("upper UF crosses below its split interface")

    lower_boundary = {
        tuple(sorted(face)) for face in _boundary_faces(lower_elements)
    }
    upper_boundary = {
        tuple(sorted(face)) for face in _boundary_faces(upper_elements)
    }
    lower_top = {
        tuple(sorted(face))
        for face in _horizontal_boundary_facets(
            lower_elements,
            registry,
            z_value,
        )
    }
    upper_bottom = {
        tuple(sorted(face))
        for face in _horizontal_boundary_facets(
            upper_elements,
            registry,
            z_value,
        )
    }
    if required_face_size not in {3, 4}:
        raise PackageBuildError("UF split interface face size must be TRI3 or QUAD4")
    if any(len(face) != required_face_size for face in lower_top):
        label = "TRI3" if required_face_size == 3 else "QUAD4"
        raise PackageBuildError(f"lower UF split surface must contain only {label} faces")
    if any(len(face) != required_face_size for face in upper_bottom):
        label = "TRI3" if required_face_size == 3 else "QUAD4"
        raise PackageBuildError(f"upper UF split surface must contain only {label} faces")
    count = _require_exact_interface(
        "lower-UF/upper-UF split",
        lower_top,
        upper_bottom,
    )
    shared_boundary = lower_boundary & upper_boundary
    if shared_boundary != lower_top:
        raise PackageBuildError(
            "lower and upper UF share faces outside their declared split interface"
        )
    return count


def _is_die_inner_wall_face(
    face: Sequence[int],
    registry: _NodeRegistry,
    stack: ResolvedPackageStack,
    z_min: float,
    z_max: float,
) -> bool:
    nodes = tuple(registry.nodes_by_tag[tag] for tag in face)
    if not all(
        z_min - _COORDINATE_TOLERANCE_MM
        <= node.z
        <= z_max + _COORDINATE_TOLERANCE_MM
        for node in nodes
    ):
        return False
    x_min, x_max, y_min, y_max = stack.die_bounds_xy_mm
    on_x_wall = (
        all(_close(node.x, x_min) for node in nodes)
        or all(_close(node.x, x_max) for node in nodes)
    ) and all(
        y_min - _COORDINATE_TOLERANCE_MM
        <= node.y
        <= y_max + _COORDINATE_TOLERANCE_MM
        for node in nodes
    )
    on_y_wall = (
        all(_close(node.y, y_min) for node in nodes)
        or all(_close(node.y, y_max) for node in nodes)
    ) and all(
        x_min - _COORDINATE_TOLERANCE_MM
        <= node.x
        <= x_max + _COORDINATE_TOLERANCE_MM
        for node in nodes
    )
    return on_x_wall or on_y_wall


def _die_inner_wall_face_keys(
    skin: Mapping[tuple[int, ...], tuple[int, ...]],
    registry: _NodeRegistry,
    stack: ResolvedPackageStack,
    z_min: float,
    z_max: float,
) -> set[tuple[int, ...]]:
    return {
        key
        for key, face in skin.items()
        if _is_die_inner_wall_face(face, registry, stack, z_min, z_max)
    }


def _is_uf_inner_wall_face(
    face: Sequence[int],
    registry: _NodeRegistry,
    stack: ResolvedPackageStack,
) -> bool:
    return _is_die_inner_wall_face(
        face,
        registry,
        stack,
        stack.uf_base_mm,
        stack.uf_top_mm,
    )


def _audit_package_interfaces(
    skins: Mapping[str, Mapping[tuple[int, ...], tuple[int, ...]]],
    registry: _NodeRegistry,
    stack: ResolvedPackageStack,
) -> dict[str, int]:
    """Fail closed unless all mandatory package contacts are face-conformal.

    Coordinates are intentionally not used as a fallback.  A contact passes
    only when both components own the same complete first-order face node key.
    """

    required_components = {
        "CONNECTED_BUMP",
        "SUBSTRATE",
        "ADDED_SI",
        "RING_1",
        "RING_2",
        "UF_FILLET",
    }
    missing_components = sorted(required_components - set(skins))
    if missing_components:
        raise PackageBuildError(
            "cannot audit package interfaces; missing components: "
            + ", ".join(missing_components)
        )

    def horizontal(component: str, z_value: float) -> set[tuple[int, ...]]:
        return _horizontal_skin_face_keys(skins[component], registry, z_value)

    bump_bottom = horizontal("CONNECTED_BUMP", stack.bump_bottom_mm)
    substrate_top = horizontal("SUBSTRATE", stack.substrate_top_mm)
    ring_1_bottom = horizontal("RING_1", stack.ring_parts[0][1])
    overlap = bump_bottom & ring_1_bottom
    if overlap:
        raise PackageBuildError(
            "CONNECTED_BUMP and RING_1 overlap on the substrate top: "
            f"{len(overlap)} exact faces"
        )

    lower_uf_component = (
        "UF_CORNER_CORE" if "UF_CORNER_CORE" in skins else "UF_FILLET"
    )
    counts = {
        "bump_bottom_substrate": _require_exact_interface(
            "CONNECTED_BUMP/SUBSTRATE",
            bump_bottom,
            substrate_top,
            first_must_be_subset=True,
        ),
        "ring_1_bottom_substrate": _require_exact_interface(
            "RING_1/SUBSTRATE",
            ring_1_bottom,
            substrate_top,
            first_must_be_subset=True,
        ),
        "substrate_top_partition": _require_exact_interface(
            "(CONNECTED_BUMP + RING_1)/SUBSTRATE partition",
            bump_bottom | ring_1_bottom,
            substrate_top,
        ),
        "bump_top_added_si": _require_exact_interface(
            "CONNECTED_BUMP/ADDED_SI",
            horizontal("CONNECTED_BUMP", stack.bump_top_mm),
            horizontal("ADDED_SI", stack.die_bottom_mm),
        ),
        "ring_1_ring_2": _require_exact_interface(
            "RING_1/RING_2",
            horizontal("RING_1", stack.ring_parts[0][2]),
            horizontal("RING_2", stack.ring_parts[1][1]),
        ),
        "uf_base_ring_2": _require_exact_interface(
            f"{lower_uf_component}/RING_2 base",
            horizontal(lower_uf_component, stack.uf_base_mm),
            horizontal("RING_2", stack.ring_parts[1][2]),
            first_must_be_subset=True,
        ),
    }

    bump_skin = skins["CONNECTED_BUMP"]
    for ring_number, (_material, bottom, top, _height) in enumerate(
        stack.ring_parts,
        start=1,
    ):
        ring_component = f"RING_{ring_number}"
        ring_inner_wall = _die_inner_wall_face_keys(
            skins[ring_component],
            registry,
            stack,
            bottom,
            top,
        )
        bump_inner_wall = _die_inner_wall_face_keys(
            bump_skin,
            registry,
            stack,
            bottom,
            top,
        )
        counts[f"ring_{ring_number}_inner_wall_bump"] = _require_exact_interface(
            f"{ring_component}/CONNECTED_BUMP inner wall",
            ring_inner_wall,
            bump_inner_wall,
        )

    uf_added_si_top = min(stack.uf_top_mm, stack.die_top_mm)
    uf_inner_wall_bump = _die_inner_wall_face_keys(
        skins[lower_uf_component],
        registry,
        stack,
        stack.uf_base_mm,
        stack.bump_top_mm,
    )
    uf_inner_wall_added_si = _die_inner_wall_face_keys(
        skins["UF_FILLET"],
        registry,
        stack,
        stack.die_bottom_mm,
        uf_added_si_top,
    )
    uf_inner_wall = uf_inner_wall_bump | uf_inner_wall_added_si
    if uf_inner_wall_bump & uf_inner_wall_added_si:
        raise PackageBuildError("UF inner-wall ownership ranges overlap")
    if uf_inner_wall_bump | uf_inner_wall_added_si != uf_inner_wall:
        raise PackageBuildError(
            "UF inner wall is not fully partitioned between bump and added Si"
        )
    counts["uf_inner_wall_bump"] = _require_exact_interface(
        "UF_FILLET/CONNECTED_BUMP inner wall",
        uf_inner_wall_bump,
        _die_inner_wall_face_keys(
            skins["CONNECTED_BUMP"],
            registry,
            stack,
            stack.uf_base_mm,
            stack.bump_top_mm,
        ),
        first_must_be_subset=True,
    )
    added_si_inner_wall = _die_inner_wall_face_keys(
        skins["ADDED_SI"],
        registry,
        stack,
        stack.die_bottom_mm,
        uf_added_si_top,
    )
    if uf_added_si_top <= stack.die_bottom_mm + _COORDINATE_TOLERANCE_MM:
        if uf_inner_wall_added_si or added_si_inner_wall:
            raise PackageBuildError(
                "zero-height UF/added-Si contact unexpectedly contains faces"
            )
        counts["uf_inner_wall_added_si"] = 0
    else:
        counts["uf_inner_wall_added_si"] = _require_exact_interface(
            "UF_FILLET/ADDED_SI inner wall",
            uf_inner_wall_added_si,
            added_si_inner_wall,
            first_must_be_subset=True,
        )
    die_side_skin = set(skins["CONNECTED_BUMP"]) | set(skins["ADDED_SI"])
    counts["uf_inner_wall_die"] = _require_exact_interface(
        "UF_FILLET/die inner wall",
        uf_inner_wall,
        die_side_skin,
        first_must_be_subset=True,
    )
    return counts


def _validate_generated_locations(bundle: PackageBundle) -> None:
    for placement in bundle.package.placements:
        if placement.operation is not BooleanOperation.ADD:
            raise PackageBuildError(
                "the first package profile supports additive (+) placements only"
            )
        if any(not _close(value, 0.0) for value in placement.loc_xy_mm):
            raise PackageBuildError(
                "the first package profile currently requires loc=(0,0) for all parts"
            )


def _package_input_artifacts(
    bundle: PackageBundle,
) -> tuple[tuple[str, Path], ...]:
    inputs: list[tuple[str, Path]] = []
    if bundle.package.source_path is not None:
        inputs.append(("package", bundle.package.source_path))
    for component_name, component in bundle.components.items():
        if component.source_path is not None:
            inputs.append((f"component {component_name!r}", component.source_path))
    for source in bundle.package.mesh_sources:
        inputs.append((f"mesh source {source.alias!r}", source.mesh_path))
        parameter_path, report_path = _source_sidecar_paths(source.mesh_path)
        inputs.extend(
            (
                (f"mesh source {source.alias!r} parameters sidecar", parameter_path),
                (f"mesh source {source.alias!r} report sidecar", report_path),
            )
        )
    return tuple(inputs)


def _validate_package_output_paths(
    bundle: PackageBundle,
    output: Path,
) -> tuple[Path, Path]:
    """Reject every output/input or output/output filesystem alias."""

    report_path = output.with_suffix(".report.json")
    parameters_path = output.with_suffix(".parameters.json")
    outputs = (
        ("mesh output", output),
        ("report output", report_path),
        ("parameters output", parameters_path),
    )
    for index, (left_label, left_path) in enumerate(outputs):
        for right_label, right_path in outputs[index + 1 :]:
            if paths_refer_to_same_file(left_path, right_path):
                raise PackageBuildError(
                    f"{left_label} and {right_label} identify the same file"
                )
    for output_label, output_candidate in outputs:
        for input_label, input_path in _package_input_artifacts(bundle):
            if paths_refer_to_same_file(output_candidate, input_path):
                raise PackageBuildError(
                    f"{output_label} must not overwrite or alias {input_label}: "
                    f"{output_candidate}"
                )
    return report_path, parameters_path


def _kind_counts_for_elements(
    elements: Sequence[PackageElement],
) -> dict[str, int]:
    return dict(
        sorted(
            Counter(
                ELEMENT_SPECS[element.gmsh_type][0].value
                for element in elements
            ).items()
        )
    )


def _component_policy_elements(
    elements: Sequence[PackageElement],
    role: str,
) -> tuple[PackageElement, ...]:
    executor_component = {
        "substrate": "SUBSTRATE",
        "added_si": "ADDED_SI",
        "ring_lower": "RING_1",
        "ring_upper": "RING_2",
        "underfill_corner_core": "UF_CORNER_CORE",
        "underfill_fillet": "UF_FILLET",
    }[role]
    return tuple(
        value for value in elements if value.component == executor_component
    )


def _build_component_policy_evidence(
    elements: Sequence[PackageElement],
    component_policies: Mapping[str, _ComponentMeshPolicy],
) -> dict[str, dict[str, object]]:
    evidence: dict[str, dict[str, object]] = {}
    for role in PACKAGE_COMPONENT_MESH_ROLES:
        selected = _component_policy_elements(elements, role)
        backend = tuple(
            value
            for value in selected
            if value.generation_provenance == "selected_volume_backend"
        )
        if len(backend) != len(selected):
            raise PackageBuildError(
                f"generated Component {role!r} contains invalid element provenance"
            )
        policy = component_policies[role]
        evidence[role] = {
            "requested_volume_topology": policy.volume_topology,
            "applied_volume_topology": policy.volume_topology,
            "implicit_topology_selection": False,
            "target_edge_mm": policy.target_edge_mm,
            "transition_distance_mm": policy.transition_distance_mm,
            "zones": sorted({value.zone for value in backend}),
            "backend_generated_element_kind_counts": _kind_counts_for_elements(backend),
            "backend_generated_volume_element_count": len(backend),
        }
    return evidence


def _build_interface_policy_evidence(
    interface_policies: Mapping[str, _InterfaceMatchPolicy],
    interface_audit: Mapping[str, int],
) -> dict[str, dict[str, object]]:
    audit_name = {
        "substrate": "bump_bottom_substrate",
        "added_si": "bump_top_added_si",
        "ring_lower": "ring_1_inner_wall_bump",
        "ring_upper": "ring_2_inner_wall_bump",
        "underfill_corner_core": "uf_inner_wall_bump",
    }
    evidence: dict[str, dict[str, object]] = {}
    for role in PACKAGE_INTERFACE_MATCH_ROLES:
        policy = interface_policies[role]
        evidence[role] = {
            "requested_mode": policy.mode,
            "applied_mode": policy.mode,
            "resolved_face_count": int(interface_audit[audit_name[role]]),
            "shared_nodes_verified": True,
        }
    return evidence


def _build_generated_interface_policy_evidence(
    interfaces: Sequence[NegotiatedComponentInterface],
    component_role_bindings: Mapping[str, str],
    component_skins: Mapping[
        str,
        Mapping[tuple[int, ...], tuple[int, ...]],
    ],
    applied_surface_backends: Mapping[frozenset[str], str],
) -> tuple[dict[str, object], ...]:
    """Audit each geometry-derived shared surface against the emitted mesh.

    The backend marker is written at the point where the surface is actually
    created.  It is deliberately not inferred from a requested topology or
    from the eventual element kinds, which prevents a Cartesian surface from
    being reported as Gmsh-generated merely because its neighboring volumes
    contain TET4/PYRAMID5.
    """

    executor_component = {
        "substrate": "SUBSTRATE",
        "added_si": "ADDED_SI",
        "ring_lower": "RING_1",
        "ring_upper": "RING_2",
        "underfill_corner_core": "UF_CORNER_CORE",
        "underfill_fillet": "UF_FILLET",
    }
    expected_backend = {
        "shared_cartesian_quad": "orthogonal_hex",
        "shared_inherited_sweep_surface": "structured_sweep",
        "shared_gmsh_conformal_surface": "gmsh",
    }
    evidence: list[dict[str, object]] = []
    for interface in interfaces:
        roles = tuple(
            component_role_bindings[component_id]
            for component_id in interface.component_ids
        )
        role_pair = frozenset(roles)
        backend = applied_surface_backends.get(role_pair)
        required_backend = expected_backend[interface.surface_policy]
        if backend != required_backend:
            raise PackageBuildError(
                f"generated interface {interface.interface_id!r} requested "
                f"{interface.surface_policy!r} but no audited {required_backend!r} "
                "surface producer owns the common face"
            )
        first_component, second_component = (
            executor_component[role] for role in roles
        )
        if (
            first_component not in component_skins
            or second_component not in component_skins
        ):
            raise PackageBuildError(
                f"generated interface {interface.interface_id!r} lacks one emitted "
                "Component skin"
            )
        common_keys = set(component_skins[first_component]) & set(
            component_skins[second_component]
        )
        if not common_keys:
            raise PackageBuildError(
                f"generated interface {interface.interface_id!r} has no exact "
                "shared face keys"
            )
        kind_counts = Counter(
            "TRI3" if len(component_skins[first_component][key]) == 3 else "QUAD4"
            if len(component_skins[first_component][key]) == 4
            else "UNSUPPORTED"
            for key in common_keys
        )
        if "UNSUPPORTED" in kind_counts or not set(kind_counts) <= set(
            interface.permitted_surface_element_kinds
        ):
            raise PackageBuildError(
                f"generated interface {interface.interface_id!r} emitted surface "
                "element kinds outside its negotiated contract"
            )
        evidence.append(
            {
                "negotiated_policy": interface.to_dict(),
                "executor_component_roles": list(roles),
                "surface_generation_backend": backend,
                "resolved_common_face_count": len(common_keys),
                "actual_surface_element_kind_counts": dict(
                    sorted(kind_counts.items())
                ),
                "exact_face_keys_verified": True,
                "shared_nodes_verified": True,
                "independent_boundary_deletion_count": 0,
            }
        )
    return tuple(evidence)


def plan_package_mesh(
    package: str | Path | PackageBundle,
    *,
    component_mesh_policies: Mapping[str, Mapping[str, object]] | None = None,
    interface_match_policies: Mapping[str, Mapping[str, object]] | None = None,
    generated_component_role_bindings: Mapping[str, str] | None = None,
    generated_interface_policies: Sequence[NegotiatedComponentInterface]
    | None = None,
    generated_interface_continuity_groups: Sequence[
        GeneratedSurfaceEquivalenceGroup
    ]
    | None = None,
    generated_surface_execution_plan: GeneratedSurfaceExecutionPlan
    | None = None,
    bulk_mesh_mode: str = "sweep",
    far_field_size_mm: float = 0.080,
    transition_distance_mm: float = 0.120,
    ring_volume_topologies: Sequence[str] = (
        "structured_sweep",
        "structured_sweep",
    ),
    underfill_core_mesh_mode: str = "target_mesh_control",
    underfill_core_volume_topology: str | None = "orthogonal_hex",
    underfill_core_target_edge_mm: float | None = 0.080,
    underfill_core_transition_distance_mm: float | None = 0.120,
    generated_materials_authoritative: bool = False,
    verbose: bool = False,
) -> PackageMeshPlan:
    """Compile the current package DSL into one immutable conformal mesh plan."""

    if (component_mesh_policies is None) != (interface_match_policies is None):
        raise PackageBuildError(
            "component_mesh_policies and interface_match_policies must be "
            "provided together"
        )
    resolved_component_policies = (
        None
        if component_mesh_policies is None
        else _normalize_component_mesh_policies(component_mesh_policies)
    )
    resolved_interface_policies = (
        None
        if interface_match_policies is None
        else _normalize_interface_match_policies(interface_match_policies)
    )
    if resolved_component_policies is None:
        if (
            generated_component_role_bindings is not None
            or generated_interface_policies is not None
            or generated_interface_continuity_groups is not None
            or generated_surface_execution_plan is not None
        ):
            raise PackageBuildError(
                "generated interface negotiation requires explicit Component policies"
            )
        resolved_generated_interfaces: tuple[
            NegotiatedComponentInterface, ...
        ] = ()
        resolved_generated_continuity_groups: tuple[
            GeneratedSurfaceEquivalenceGroup, ...
        ] = ()
        resolved_generated_surface_execution = None
        resolved_component_role_bindings: dict[str, str] = {}
        # The package-spec CLI remains a separate V1 entry point.  Package V2
        # high-UF execution always supplies the complete mappings above and
        # never enters this branch.
        resolved_bulk_mesh_mode = normalize_package_bulk_mesh_mode(bulk_mesh_mode)
        resolved_ring_topologies = _normalize_ring_volume_topologies(
            ring_volume_topologies
        )
        resolved_underfill_core_mode = normalize_underfill_core_mesh_mode(
            underfill_core_mesh_mode
        )
        (
            requested_underfill_core_topology,
            resolved_underfill_core_topology,
            implicit_underfill_core_topology,
        ) = _resolve_underfill_core_volume_topology(
            resolved_underfill_core_mode,
            underfill_core_volume_topology,
        )
    else:
        assert resolved_interface_policies is not None
        if (
            generated_component_role_bindings is None
            or generated_interface_policies is None
            or generated_interface_continuity_groups is None
        ):
            raise PackageBuildError(
                "explicit Component policies require geometry-derived generated "
                "interface negotiation"
            )
        (
            resolved_generated_interfaces,
            resolved_component_role_bindings,
        ) = _normalize_generated_interface_policies(
            generated_interface_policies,
            component_role_bindings=generated_component_role_bindings,
            component_policies=resolved_component_policies,
        )
        resolved_generated_continuity_groups = (
            _normalize_generated_interface_continuity_groups(
                generated_interface_continuity_groups,
                interfaces=resolved_generated_interfaces,
                component_role_bindings=resolved_component_role_bindings,
                component_policies=resolved_component_policies,
                sweep_direction_xyz_by_component=(
                    _sweep_directions_from_surface_execution_plan(
                        generated_surface_execution_plan
                    )
                ),
            )
        )
        resolved_generated_surface_execution = (
            None
            if generated_surface_execution_plan is None
            else _normalize_generated_surface_execution_plan(
                generated_surface_execution_plan,
                interfaces=resolved_generated_interfaces,
                continuity_groups=resolved_generated_continuity_groups,
                component_role_bindings=resolved_component_role_bindings,
                component_policies=resolved_component_policies,
            )
        )
        adjacency_role_pairs = {
            frozenset(
                resolved_component_role_bindings[component_id]
                for component_id in interface.component_ids
            )
            for interface in resolved_generated_interfaces
        }
        executor_geometry_pairs = {
            frozenset(pair)
            for pair in (
                ("substrate", "ring_lower"),
                ("ring_lower", "ring_upper"),
                ("ring_upper", "underfill_corner_core"),
                ("underfill_corner_core", "underfill_fillet"),
                ("underfill_fillet", "added_si"),
            )
        }
        if adjacency_role_pairs != executor_geometry_pairs:
            raise PackageBuildError(
                "geometry-derived adjacency graph does not match this narrow "
                "package executor's five physical contacts"
            )
        resolved_ring_topologies = (
            resolved_component_policies["ring_lower"].volume_topology,
            resolved_component_policies["ring_upper"].volume_topology,
        )
        resolved_underfill_core_mode = "target_mesh_control"
        resolved_underfill_core_topology = resolved_component_policies[
            "underfill_corner_core"
        ].volume_topology
        requested_underfill_core_topology = resolved_underfill_core_topology
        implicit_underfill_core_topology = False
        resolved_bulk_mesh_mode = (
            "hybrid"
            if any(
                policy.volume_topology == "conformal_hybrid"
                for policy in resolved_component_policies.values()
            )
            else "sweep"
        )

    role_by_component_id = resolved_component_role_bindings

    def generated_interface_for_roles(
        first_role: str,
        second_role: str,
    ) -> NegotiatedComponentInterface | None:
        if not resolved_generated_interfaces:
            return None
        requested = frozenset((first_role, second_role))
        matches = tuple(
            interface
            for interface in resolved_generated_interfaces
            if frozenset(
                role_by_component_id[component_id]
                for component_id in interface.component_ids
            )
            == requested
        )
        if len(matches) != 1:
            raise PackageBuildError(
                "geometry-derived adjacency does not resolve exactly one shared "
                f"surface for {first_role!r}/{second_role!r}"
            )
        return matches[0]

    def surface_backend_for_topology(topology: str) -> str:
        return {
            "orthogonal_hex": "orthogonal_hex",
            "structured_sweep": "structured_sweep",
            "conformal_hybrid": "gmsh",
        }[topology]

    def interface_seed_role(
        interface: NegotiatedComponentInterface,
    ) -> str:
        if resolved_component_policies is None:
            raise PackageBuildError(
                "generated interface seed requires explicit Component policies"
            )
        candidates = tuple(
            component_id
            for component_id in interface.component_ids
            if (
                interface.surface_policy == "shared_gmsh_conformal_surface"
                or resolved_component_policies[
                    role_by_component_id[component_id]
                ].volume_topology
                == (
                    "orthogonal_hex"
                    if interface.surface_policy == "shared_cartesian_quad"
                    else "structured_sweep"
                )
            )
        )
        if not candidates:
            raise PackageBuildError(
                "generated interface policy has no compatible legacy surface seed"
            )
        component_id = min(
            candidates,
            key=lambda value: (
                resolved_component_policies[
                    role_by_component_id[value]
                ].target_edge_mm,
                resolved_component_policies[
                    role_by_component_id[value]
                ].transition_distance_mm,
                value,
            ),
        )
        return role_by_component_id[component_id]
    if not isinstance(generated_materials_authoritative, bool):
        raise PackageBuildError(
            "generated_materials_authoritative must be a boolean"
        )
    bundle = (
        package
        if isinstance(package, PackageBundle)
        else load_package_bundle(Path(package).expanduser().resolve())
    )
    _validate_component_semantics(bundle)
    _validate_generated_locations(bundle)
    if len(bundle.package.mesh_sources) != 1:
        raise PackageBuildError("the current package profile requires one mesh source")
    source_path = bundle.package.mesh_sources[0].mesh_path
    if not source_path.is_file():
        raise PackageBuildError(f"connected-bump source does not exist: {source_path}")

    snapshot = _load_connected_bump_snapshot(source_path)
    source_mesh = snapshot.source_mesh
    sidecar = snapshot.parameters
    stack = resolve_package_stack(bundle, source_mesh)
    # V1 package tokens intentionally depend on the connected-bump alias
    # table. A V2 strategy supplies final generated Component.material names,
    # so even parsing that Frozen-source alias table would make unrelated
    # source metadata authoritative over generated ownership.
    component_materials = _generated_material_alias_map(
        sidecar,
        generated_materials_authoritative=(
            generated_materials_authoritative
        ),
    )

    registry = _NodeRegistry()
    imported, transformed_tag_by_source = _copy_connected_bump(
        source_mesh,
        stack,
        registry,
    )
    ports = _extract_corner_ports(
        source_mesh,
        transformed_tag_by_source,
        registry,
        sidecar,
        stack,
    )
    bottom_cells = _horizontal_surface_cells(imported, registry, stack.bump_bottom_mm)
    top_cells = _horizontal_surface_cells(imported, registry, stack.bump_top_mm)
    if {
        tuple(sorted(_xy_key(*point) for point in cell)) for cell in bottom_cells
    } != {
        tuple(sorted(_xy_key(*point) for point in cell)) for cell in top_cells
    }:
        raise PackageBuildError(
            "connected-bump top and bottom docking surfaces have different XY topology"
        )

    resolved_far_field_size = _finite(
        far_field_size_mm,
        field_name="package far-field size",
    )
    resolved_transition_distance = _finite(
        transition_distance_mm,
        field_name="package transition distance",
    )
    requested_core_target = (
        underfill_core_target_edge_mm
        if resolved_component_policies is None
        else resolved_component_policies[
            "underfill_corner_core"
        ].target_edge_mm
    )
    requested_core_transition = (
        underfill_core_transition_distance_mm
        if resolved_component_policies is None
        else resolved_component_policies[
            "underfill_corner_core"
        ].transition_distance_mm
    )
    if requested_core_target is None:
        raise PackageBuildError("underfill core requires target_edge_mm")
    if requested_core_transition is None:
        raise PackageBuildError(
            "underfill core requires transition_distance_mm"
        )
    resolved_core_target_edge = _finite(
        requested_core_target,
        field_name="underfill core target edge",
    )
    resolved_core_transition = _finite(
        requested_core_transition,
        field_name="underfill core transition distance",
    )
    if resolved_core_target_edge <= 0.0 or resolved_core_transition <= 0.0:
        raise PackageBuildError("underfill core controls must be positive")
    frozen_side_facets: tuple[tuple[int, ...], ...] = ()
    trace_z_levels: tuple[float, ...] = ()
    trace_planar_candidate: _UfTracePlanarCandidate | None = None
    applied_generated_interface_surface_backends: dict[
        frozenset[str],
        str,
    ] = {}
    planar_shared_interfaces = tuple(
        interface
        for interface in (
            generated_interface_for_roles("substrate", "ring_lower"),
            generated_interface_for_roles("ring_lower", "ring_upper"),
            generated_interface_for_roles(
                "ring_upper",
                "underfill_corner_core",
            ),
        )
        if interface is not None
    )
    core_fillet_interface = generated_interface_for_roles(
        "underfill_corner_core",
        "underfill_fillet",
    )
    fillet_added_interface = generated_interface_for_roles(
        "underfill_fillet",
        "added_si",
    )
    orthogonal_planar_interfaces = tuple(
        interface
        for interface in planar_shared_interfaces
        if interface.surface_policy == "shared_cartesian_quad"
    )
    orthogonal_surface_requested = bool(orthogonal_planar_interfaces)
    orthogonal_surface_target = (
        min(
            interface.interface_target_edge_mm
            for interface in orthogonal_planar_interfaces
        )
        if orthogonal_surface_requested
        else resolved_far_field_size
    )
    frozen_side_facets = _frozen_uf_inner_wall_facets(
        imported,
        registry,
        stack,
    )
    trace_z_levels = _uf_trace_z_levels_from_locked_side_surface(
        frozen_side_facets,
        registry,
        stack,
    )
    trace_planar_candidate = _select_uf_trace_planar_candidate(
        stack,
        ports,
        bottom_cells,
        trace_z_levels,
        _uf_locked_side_xy_edge_keys(frozen_side_facets, registry),
        requested_target_edge_mm=resolved_core_target_edge,
        requested_transition_distance_mm=resolved_core_transition,
        package_far_field_size_mm=resolved_far_field_size,
        package_transition_distance_mm=resolved_transition_distance,
        verbose=verbose,
    )
    planar = (
        _build_orthogonal_package_planar_domain(
            stack,
            ports,
            bottom_cells,
            target_edge_mm=orthogonal_surface_target,
            protected_domain=trace_planar_candidate.domain,
        )
        if orthogonal_surface_requested
        else trace_planar_candidate.domain
    )
    for interface in planar_shared_interfaces:
        role_pair = frozenset(
            role_by_component_id[component_id]
            for component_id in interface.component_ids
        )
        if interface.surface_policy == "shared_cartesian_quad":
            applied_generated_interface_surface_backends[role_pair] = (
                "orthogonal_hex"
            )
        elif interface.surface_policy == "shared_inherited_sweep_surface":
            applied_generated_interface_surface_backends[role_pair] = (
                "structured_sweep"
            )
    builder = _PlanBuilder(registry, imported)

    substrate_material = _package_material(
        stack.substrate_material,
        component_materials,
        generated_materials_authoritative=generated_materials_authoritative,
    )
    die_material = _package_material(
        stack.die_material,
        component_materials,
        generated_materials_authoritative=generated_materials_authoritative,
    )
    hybrid_scope = "NONE"
    hybrid_transition_z_levels: tuple[float, ...] = ()
    hybrid_regions: list[PackageHybridRegion] = []
    corner_pitch = min(
        min(port.size_x_mm, port.size_y_mm) for port in ports
    )
    hybrid_near_size = 2.0 * corner_pitch
    upper_uf_near_size = 1.6 * corner_pitch
    # Retained in the schema for backwards-compatible sidecars. The current
    # upper-UF path is not a Z-only level schedule, so this legacy field must
    # remain empty instead of advertising an unused target thickness.
    hybrid_uf_above_bump_target = None
    substrate_topology = (
        (
            "conformal_hybrid"
            if resolved_bulk_mesh_mode == "hybrid"
            else "structured_sweep"
        )
        if resolved_component_policies is None
        else resolved_component_policies["substrate"].volume_topology
    )
    substrate_target = (
        resolved_far_field_size
        if resolved_component_policies is None
        else resolved_component_policies["substrate"].target_edge_mm
    )
    substrate_transition = (
        resolved_transition_distance
        if resolved_component_policies is None
        else resolved_component_policies["substrate"].transition_distance_mm
    )
    if substrate_topology == "structured_sweep":
        builder.extrude_cells(
            planar.all_cells,
            _substrate_z_levels(stack),
            material=substrate_material,
            component="SUBSTRATE",
            zone="SUBSTRATE_SWEEP",
        )
    elif substrate_topology == "orthogonal_hex":
        if any(len(cell) != 4 for cell in planar.all_cells):
            raise PackageBuildError(
                "orthogonal substrate requires the negotiated Cartesian QUAD surface"
            )
        builder.extrude_cells(
            planar.all_cells,
            _substrate_z_levels(stack),
            material=substrate_material,
            component="SUBSTRATE",
            zone="SUBSTRATE_ORTHOGONAL_HEX",
        )
    elif substrate_topology == "conformal_hybrid":
        # Start the unstructured substrate directly at the exact C4/ring
        # underside.  Locked TRI faces are owned by TET4 and locked QUAD faces
        # by complete PYRAMID5 bases, so no full-area Z-drag collar is needed.
        # The die branch below follows the same policy while additionally
        # locking the partial-height UF wall.
        hybrid_regions.append(
            _append_constrained_hybrid_volume(
                builder,
                planar.all_cells,
                stack.outer_bounds_xy_mm,
                stack.substrate_top_mm,
                stack.substrate_bottom_mm,
                maximum_size_mm=max(
                    hybrid_near_size,
                    substrate_target,
                ),
                near_size_mm=hybrid_near_size,
                transition_distance_mm=substrate_transition,
                material=substrate_material,
                component="SUBSTRATE",
                zone="SUBSTRATE_XYZ_HYBRID_BULK",
                verbose=verbose,
            )
        )
    else:  # pragma: no cover - normalized above
        raise AssertionError(f"unsupported substrate topology: {substrate_topology}")

    uf_material = _package_material(
        stack.uf_component,
        component_materials,
        generated_materials_authoritative=generated_materials_authoritative,
    )

    def add_rings() -> None:
        for ring_index, (raw_material, bottom, top, _height) in enumerate(
            stack.ring_parts,
            start=1,
        ):
            topology = resolved_ring_topologies[ring_index - 1]
            ring_role = "ring_lower" if ring_index == 1 else "ring_upper"
            ring_target = (
                resolved_far_field_size
                if resolved_component_policies is None
                else resolved_component_policies[ring_role].target_edge_mm
            )
            ring_transition = (
                resolved_transition_distance
                if resolved_component_policies is None
                else resolved_component_policies[
                    ring_role
                ].transition_distance_mm
            )
            material = _package_material(
                raw_material,
                component_materials,
                generated_materials_authoritative=(
                    generated_materials_authoritative
                ),
            )
            levels = _ring_z_levels(stack, ports, bottom, top)
            if topology == "structured_sweep":
                builder.extrude_cells(
                    planar.exterior_cells,
                    levels,
                    material=material,
                    component=f"RING_{ring_index}",
                    zone=f"RING_{ring_index}_SWEEP",
                )
            elif topology == "orthogonal_hex":
                if any(len(cell) != 4 for cell in planar.exterior_cells):
                    raise PackageBuildError(
                        f"ring {ring_index} orthogonal_hex requires the negotiated "
                        "Cartesian QUAD surface"
                    )
                builder.extrude_cells(
                    planar.exterior_cells,
                    levels,
                    material=material,
                    component=f"RING_{ring_index}",
                    zone=f"RING_{ring_index}_ORTHOGONAL_HEX",
                )
            elif topology == "conformal_hybrid":
                stats = _add_ring_conformal_hybrid(
                    builder,
                    planar.exterior_cells,
                    levels,
                    bounds_xy_mm=stack.outer_bounds_xy_mm,
                    opening_bounds_xy_mm=stack.die_bounds_xy_mm,
                    target_edge_mm=ring_target,
                    transition_distance_mm=ring_transition,
                    material=material,
                    component=f"RING_{ring_index}",
                    zone=f"RING_{ring_index}_CONFORMAL_HYBRID",
                    verbose=verbose,
                )
                if (
                    stats["generated_tet4_count"]
                    + stats["generated_pyramid5_count"]
                    <= 0
                ):
                    raise PackageBuildError(
                        f"ring {ring_index} conformal_hybrid did not emit "
                        "TET4/PYRAMID5"
                    )
            else:  # pragma: no cover - normalized above
                raise AssertionError(f"unsupported ring topology: {topology}")

    uf_split_face_count = 0
    upper_uf_generated = False
    underfill_core_locked_faces = 0
    underfill_core_generated_elements = 0
    underfill_core_non_hex_exterior_faces = 0
    underfill_core_exterior_quad_owned_by_non_hex = 0
    underfill_core_orthogonal_hex_verified = False
    trace_applied_stats = _UfTraceAppliedTopologyStats(
        element_count=0,
        hex8_count=0,
        pyramid5_count=0,
        tet4_count=0,
        quality_fallback_hex8_count=0,
        star_converted_hex8_count=0,
        free_surface_tri3_count=0,
        free_surface_quad_fallback_count=0,
    )
    trace_applied_quality: _UfTraceSweepQuality | None = None
    upper_uf_topology = (
        "conformal_hybrid"
        if resolved_component_policies is None
        else resolved_component_policies["underfill_fillet"].volume_topology
    )
    upper_uf_target = (
        resolved_far_field_size
        if resolved_component_policies is None
        else resolved_component_policies["underfill_fillet"].target_edge_mm
    )
    upper_uf_transition = (
        resolved_transition_distance
        if resolved_component_policies is None
        else resolved_component_policies[
            "underfill_fillet"
        ].transition_distance_mm
    )

    if resolved_component_policies is None and resolved_bulk_mesh_mode == "sweep":
        # Keep the production sweep element order unchanged: substrate, die,
        # rings, then UF.  This is part of the stable mesh fingerprint.
        builder.extrude_cells(
            top_cells,
            _die_z_levels(stack, ports),
            material=die_material,
            component="ADDED_SI",
            zone="DIE_CAPTURE_SWEEP",
        )
        add_rings()
        uf_element_start = len(builder.elements)
        uf_stats = _add_uf_hex_staircase(
            builder,
            stack,
            ports,
            planar.uf_control_cells,
            material=uf_material,
        )
        _uf_elements = tuple(builder.elements[uf_element_start:])
        staircase_coordinates = tuple(
            (
                element.gmsh_type,
                tuple(
                    registry.nodes_by_tag[tag].coordinates
                    for tag in element.node_tags
                ),
            )
            for element in _uf_elements
        )
        _audit_orthogonal_hex_coordinates(staircase_coordinates)
        trace_applied_quality = _uf_trace_sweep_quality(staircase_coordinates)
        trace_applied_stats = _UfTraceAppliedTopologyStats(
            element_count=len(_uf_elements),
            hex8_count=len(_uf_elements),
            pyramid5_count=0,
            tet4_count=0,
            quality_fallback_hex8_count=0,
            star_converted_hex8_count=0,
            free_surface_tri3_count=0,
            free_surface_quad_fallback_count=0,
        )
        underfill_core_locked_faces = len(frozen_side_facets)
        underfill_core_generated_elements = len(_uf_elements)
        underfill_core_orthogonal_hex_verified = True
    else:
        # The protected UF stops exactly at the connected-bump top. Its whole
        # annular QUAD boundary is then owned by one PYRAMID5 layer and a
        # tapered TET4 bulk; no fine XY partition is dragged into the upper UF.
        add_rings()
        locked_side_facets: tuple[tuple[int, ...], ...] = ()
        cap_z = _uf_hybrid_cap_z(stack, ports)
        if resolved_underfill_core_mode == "target_mesh_control":
            assert resolved_core_target_edge is not None
            assert resolved_core_transition is not None
            assert trace_planar_candidate is not None
            assert trace_z_levels
            assert frozen_side_facets
            lower_base_cells = _uf_trace_base_cells(stack, planar.uf_control_cells)
            (
                trace_stats,
                trace_applied_stats,
                trace_applied_quality,
                lower_uf_elements,
                lower_uf_scaffold_elements,
            ) = _add_uf_trace_surface_sweep(
                builder,
                stack,
                lower_base_cells,
                trace_z_levels,
                material=uf_material,
                volume_topology=resolved_underfill_core_topology,
                locked_side_facets=frozen_side_facets,
                target_edge_mm=resolved_core_target_edge,
                transition_distance_mm=resolved_core_transition,
                near_size_mm=min(
                    resolved_core_target_edge,
                    hybrid_near_size,
                ),
                verbose=verbose,
            )
            if (
                resolved_underfill_core_topology != "structured_sweep"
                and trace_stats != trace_planar_candidate.stats
            ):
                raise PackageBuildError(
                    "trace-only UF accepted candidate changed during final generation"
                )
            (
                trace_core_top_facets,
                trace_surface_audit,
            ) = _audit_uf_trace_surface_sweep(
                lower_uf_elements,
                imported,
                tuple(
                    element
                    for element in builder.elements
                    if element.component == "RING_2"
                ),
                lower_base_cells,
                frozen_side_facets,
                trace_z_levels,
                registry,
                stack,
                lower_uf_scaffold_elements,
                trace_stats,
                trace_applied_stats,
                resolved_underfill_core_topology,
            )
            underfill_core_exterior_quad_owned_by_non_hex = (
                trace_surface_audit.exterior_quad_owned_by_non_hex_count
            )
            # Compatibility alias.  It is no longer used as proof that the
            # free exterior changed topology; free_surface_tri3_count is.
            underfill_core_non_hex_exterior_faces = (
                underfill_core_exterior_quad_owned_by_non_hex
            )
            underfill_core_orthogonal_hex_verified = (
                resolved_underfill_core_topology == "orthogonal_hex"
            )
            # The lower locked wall belongs to CONNECTED_BUMP below the added-Si
            # box.  It is audited above but must not be passed as an added-Si
            # side constraint; only the upper UF/added-Si contact belongs there.
            locked_side_facets = ()
            underfill_core_locked_faces = len(frozen_side_facets)
            underfill_core_generated_elements = len(lower_uf_elements)
            if (
                core_fillet_interface is not None
                and interface_seed_role(core_fillet_interface)
                == "underfill_corner_core"
                and resolved_underfill_core_topology
                in {"structured_sweep", "orthogonal_hex"}
            ):
                applied_generated_interface_surface_backends[
                    frozenset(
                        ("underfill_corner_core", "underfill_fillet")
                    )
                ] = surface_backend_for_topology(
                    resolved_underfill_core_topology
                )
            uf_stats = _UfMeshStats(
                full_hex_count=0,
                cut_cell_count=trace_stats.cut_cell_count,
                outside_cell_count=trace_stats.outside_cell_count,
            )
            if cap_z > stack.bump_top_mm + _COORDINATE_TOLERANCE_MM:
                upper_region, upper_die_facets, upper_uf_elements = (
                    _append_selected_uf_upper_volume(
                        builder,
                        trace_core_top_facets,
                        stack,
                        ports,
                        cap_z,
                        topology=upper_uf_topology,
                        target_edge_mm=upper_uf_target,
                        transition_distance_mm=upper_uf_transition,
                        near_size_mm=upper_uf_near_size,
                        material=uf_material,
                        verbose=verbose,
                    )
                )
                if upper_region is not None:
                    hybrid_regions.append(upper_region)
                locked_side_facets = upper_die_facets
                uf_split_face_count = _require_exact_uf_split_interface(
                    lower_uf_elements,
                    upper_uf_elements,
                    registry,
                    stack.bump_top_mm,
                )
                upper_uf_generated = True
            elif stack.uf_top_mm > stack.bump_top_mm + _COORDINATE_TOLERANCE_MM:
                raise PackageBuildError(
                    "UF rises above the connected bump but has no positive-width "
                    "trace-only cap section"
                )
        # Build the die after the upper UF and install the *actual* coarsened
        # UF inner-wall triangles as locked side facets.  The two materials
        # consequently share node IDs and complete faces despite independent
        # volume meshes.
        locked_side_node_coordinates = {
            tag: registry.nodes_by_tag[tag].coordinates
            for face in locked_side_facets
            for tag in face
        }
        added_si_topology = (
            "conformal_hybrid"
            if resolved_component_policies is None
            else resolved_component_policies["added_si"].volume_topology
        )
        added_si_target = (
            resolved_far_field_size
            if resolved_component_policies is None
            else resolved_component_policies["added_si"].target_edge_mm
        )
        added_si_transition = (
            resolved_transition_distance
            if resolved_component_policies is None
            else resolved_component_policies["added_si"].transition_distance_mm
        )
        die_transition_height = stack.die_top_mm - stack.die_bottom_mm
        die_maximum_size = max(
            hybrid_near_size,
            min(
                added_si_target,
                0.5 * die_transition_height,
            ),
        )
        if added_si_topology in {"structured_sweep", "orthogonal_hex"}:
            if added_si_topology == "orthogonal_hex" and any(
                len(cell) != 4 for cell in top_cells
            ):
                raise PackageBuildError(
                    "orthogonal added-Si requires a Cartesian QUAD docking surface"
                )
            locked_side_levels = tuple(
                registry.nodes_by_tag[tag].z
                for facet in locked_side_facets
                for tag in facet
            )
            levels = _merge_levels(
                _die_z_levels(stack, ports),
                locked_side_levels,
            )
            builder.extrude_cells(
                top_cells,
                levels,
                material=die_material,
                component="ADDED_SI",
                zone=(
                    "DIE_ORTHOGONAL_HEX"
                    if added_si_topology == "orthogonal_hex"
                    else "DIE_CAPTURE_SWEEP"
                ),
            )
        elif added_si_topology == "conformal_hybrid":
            hybrid_regions.append(_append_constrained_hybrid_volume(
                builder,
                top_cells,
                stack.die_bounds_xy_mm,
                stack.die_bottom_mm,
                stack.die_top_mm,
                maximum_size_mm=die_maximum_size,
                near_size_mm=hybrid_near_size,
                transition_distance_mm=added_si_transition,
                material=die_material,
                component="ADDED_SI",
                zone="DIE_XYZ_HYBRID_BULK",
                verbose=verbose,
                locked_side_node_coordinates=locked_side_node_coordinates,
                locked_side_facets=locked_side_facets,
            ))
        else:  # pragma: no cover - normalized above
            raise AssertionError(f"unsupported added-Si topology: {added_si_topology}")
        if (
            fillet_added_interface is not None
            and interface_seed_role(fillet_added_interface)
            == "underfill_fillet"
            and upper_uf_generated
        ):
            applied_generated_interface_surface_backends[
                frozenset(("underfill_fillet", "added_si"))
            ] = surface_backend_for_topology(upper_uf_topology)
        hybrid_scope = (
            "DIE_SUBSTRATE_AND_TRACE_ONLY_UF_CONFORMAL_HYBRID"
            if resolved_underfill_core_topology == "conformal_hybrid"
            else "DIE_SUBSTRATE_AND_TRACE_ONLY_UF_FRESH_HEX_HYBRID"
        )

    elements = tuple(builder.elements)
    component_skins = _component_boundary_skins(elements)
    _require_component_skin_on_box_boundary(
        "ADDED_SI",
        component_skins["ADDED_SI"],
        registry,
        stack.die_bounds_xy_mm,
        stack.die_bottom_mm,
        stack.die_top_mm,
    )
    _require_component_skin_on_box_boundary(
        "SUBSTRATE",
        component_skins["SUBSTRATE"],
        registry,
        stack.outer_bounds_xy_mm,
        stack.substrate_bottom_mm,
        stack.substrate_top_mm,
    )
    interface_audit = _audit_package_interfaces(component_skins, registry, stack)
    if uf_split_face_count:
        interface_audit["uf_lower_upper_split"] = uf_split_face_count
    component_policy_evidence: dict[str, dict[str, object]] = {}
    interface_policy_evidence: dict[str, dict[str, object]] = {}
    generated_interface_policy_evidence: tuple[dict[str, object], ...] = ()
    if resolved_component_policies is not None:
        assert resolved_interface_policies is not None
        component_policy_evidence = _build_component_policy_evidence(
            elements,
            resolved_component_policies,
        )
        interface_policy_evidence = _build_interface_policy_evidence(
            resolved_interface_policies,
            interface_audit,
        )
        generated_interface_policy_evidence = (
            _build_generated_interface_policy_evidence(
                resolved_generated_interfaces,
                resolved_component_role_bindings,
                component_skins,
                applied_generated_interface_surface_backends,
            )
        )
    interfaces, exterior = _component_boundary_topology_from_skins(component_skins)
    source_connectivity_preserved = all(
        package_element.node_tags == source_element.node_tags
        and package_element.gmsh_type == source_element.gmsh_type
        for package_element, source_element in zip(imported, source_mesh.elements)
    )
    if not source_connectivity_preserved:
        raise PackageBuildError("RX180 changed imported element connectivity")
    return PackageMeshPlan(
        bundle=bundle,
        stack=stack,
        source_mesh=source_mesh,
        nodes=registry.nodes(),
        elements=elements,
        corner_ports=ports,
        source_sha256=snapshot.sha256,
        source_connectivity_preserved=True,
        uf_surface_skin_generated=upper_uf_generated,
        uf_cut_cell_count=uf_stats.cut_cell_count,
        interface_face_count=interfaces,
        exterior_face_count=exterior,
        bulk_mesh_mode=resolved_bulk_mesh_mode,
        hybrid_scope=hybrid_scope,
        hybrid_transition_z_levels_mm=hybrid_transition_z_levels,
        hybrid_regions=tuple(hybrid_regions),
        uf_above_bump_target_z_mm=hybrid_uf_above_bump_target,
        far_field_size_mm=resolved_far_field_size,
        transition_distance_mm=resolved_transition_distance,
        interface_audit_face_counts=tuple(sorted(interface_audit.items())),
        generated_materials_authoritative=(
            generated_materials_authoritative
        ),
        component_mesh_policies=(
            {}
            if resolved_component_policies is None
            else {
                role: resolved_component_policies[role].to_dict()
                for role in PACKAGE_COMPONENT_MESH_ROLES
            }
        ),
        interface_match_policies=(
            {}
            if resolved_interface_policies is None
            else {
                role: resolved_interface_policies[role].to_dict()
                for role in PACKAGE_INTERFACE_MATCH_ROLES
            }
        ),
        component_mesh_policy_evidence=component_policy_evidence,
        interface_match_policy_evidence=interface_policy_evidence,
        generated_component_role_bindings=(
            resolved_component_role_bindings
        ),
        generated_interface_policies=resolved_generated_interfaces,
        generated_interface_continuity_groups=(
            resolved_generated_continuity_groups
        ),
        generated_surface_execution_plan=(
            resolved_generated_surface_execution
        ),
        generated_interface_policy_evidence=(
            generated_interface_policy_evidence
        ),
        ring_volume_topologies=resolved_ring_topologies,
        underfill_core_mesh_mode=resolved_underfill_core_mode,
        underfill_core_target_edge_mm=resolved_core_target_edge,
        underfill_core_transition_distance_mm=resolved_core_transition,
        underfill_core_effective_target_edge_mm=(
            trace_planar_candidate.effective_target_edge_mm
            if trace_planar_candidate is not None else None
        ),
        underfill_core_effective_transition_distance_mm=(
            trace_planar_candidate.effective_transition_distance_mm
            if trace_planar_candidate is not None else None
        ),
        underfill_core_locked_z_level_count=len(trace_z_levels),
        underfill_core_minimum_determinant=(
            (
                trace_applied_quality or trace_planar_candidate.quality
            ).minimum_determinant
            if trace_planar_candidate is not None
            else None
        ),
        underfill_core_minimum_scaled_jacobian=(
            (
                trace_applied_quality or trace_planar_candidate.quality
            ).minimum_scaled_jacobian
            if trace_planar_candidate is not None
            else None
        ),
        underfill_core_minimum_sicn=(
            (
                trace_applied_quality or trace_planar_candidate.quality
            ).minimum_sicn
            if trace_planar_candidate is not None
            else None
        ),
        underfill_core_minimum_sige=(
            (
                trace_applied_quality or trace_planar_candidate.quality
            ).minimum_sige
            if trace_planar_candidate is not None
            else None
        ),
        underfill_core_locked_interface_face_count=underfill_core_locked_faces,
        underfill_core_generated_element_count=underfill_core_generated_elements,
        underfill_core_requested_volume_topology=(
            requested_underfill_core_topology
        ),
        underfill_core_applied_volume_topology=(
            resolved_underfill_core_topology
        ),
        underfill_core_implicit_topology_selection=(
            implicit_underfill_core_topology
        ),
        underfill_core_generated_hex8_count=trace_applied_stats.hex8_count,
        underfill_core_generated_pyramid5_count=(
            trace_applied_stats.pyramid5_count
        ),
        underfill_core_generated_tet4_count=(
            trace_applied_stats.tet4_count
        ),
        underfill_core_quality_fallback_hex8_count=(
            trace_applied_stats.quality_fallback_hex8_count
        ),
        underfill_core_star_converted_hex8_count=(
            trace_applied_stats.star_converted_hex8_count
        ),
        underfill_core_free_surface_tri3_count=(
            trace_applied_stats.free_surface_tri3_count
        ),
        underfill_core_free_surface_quad_fallback_count=(
            trace_applied_stats.free_surface_quad_fallback_count
        ),
        underfill_core_non_hex_exterior_face_count=(
            underfill_core_non_hex_exterior_faces
        ),
        underfill_core_exterior_quad_owned_by_non_hex_count=(
            underfill_core_exterior_quad_owned_by_non_hex
        ),
        underfill_core_orthogonal_hex_verified=(
            underfill_core_orthogonal_hex_verified
        ),
    )


def _physical_material_name(material: str) -> str:
    return f"{_MATERIAL_PREFIX}{_token(material)}"


def _physical_part_name(component: str) -> str:
    return f"{_PART_PREFIX}{_token(component)}"


def _physical_zone_name(zone: str) -> str:
    return f"ZONE_{_token(zone)}"


def _normalized_physical_names(
    values: Iterable[str],
    *,
    category: str,
    name_factory: Any,
) -> dict[str, str]:
    names_by_value: dict[str, str] = {}
    value_by_name: dict[str, str] = {}
    for value in sorted(values):
        name = name_factory(value)
        previous = value_by_name.setdefault(name, value)
        if previous != value:
            raise PackageBuildError(
                f"package {category} names collide after normalization: "
                f"{previous!r}, {value!r}"
            )
        names_by_value[value] = name
    return names_by_value


def _validated_physical_names(
    plan: PackageMeshPlan,
) -> tuple[dict[str, str], dict[str, str], dict[str, str]]:
    material_names = _normalized_physical_names(
        plan.material_element_counts,
        category="material",
        name_factory=_physical_material_name,
    )
    part_names = _normalized_physical_names(
        plan.component_element_counts,
        category="part",
        name_factory=_physical_part_name,
    )
    zone_names = _normalized_physical_names(
        plan.zone_element_counts,
        category="zone",
        name_factory=_physical_zone_name,
    )

    owner_by_name: dict[str, tuple[str, str]] = {}

    def register(name: str, owner: tuple[str, str]) -> None:
        normalized = name.strip().upper()
        previous = owner_by_name.setdefault(normalized, owner)
        if previous != owner:
            raise PackageBuildError(
                "package physical-group names collide across namespaces: "
                f"{previous!r}, {owner!r} -> {name!r}"
            )

    for name in (_ALL_SOLIDS, _TEMPLATE_SOLIDS, _TRANSITION_SOLIDS):
        register(name, ("reserved", name))
    for category, names in (
        ("material", material_names),
        ("part", part_names),
        ("zone", zone_names),
    ):
        for value, name in names.items():
            register(name, (category, value))

    material_by_hm_name: dict[str, str] = {}
    for element in plan.elements:
        hm_name = element.hm_physical_name
        register(hm_name, ("hm-owner", hm_name.upper()))
        previous_material = material_by_hm_name.setdefault(
            hm_name.upper(), element.material
        )
        if previous_material != element.material:
            raise PackageBuildError(
                f"package HM owner {hm_name!r} spans multiple materials: "
                f"{previous_material!r}, {element.material!r}"
            )
        for preserved_name in element.preserved_physical_names:
            register(
                preserved_name,
                ("preserved-source", preserved_name.upper()),
            )
    return material_names, part_names, zone_names


def _element_entity_key(
    element: PackageElement,
) -> tuple[str, str, str, str, str, tuple[str, ...]]:
    """Return the complete per-entity membership signature for one EID."""

    return (
        element.component,
        element.material,
        element.zone,
        element.origin,
        element.owner_token,
        element.preserved_physical_names,
    )


def _element_physical_names(
    element: PackageElement,
    material_names: Mapping[str, str],
    part_names: Mapping[str, str],
    zone_names: Mapping[str, str],
) -> tuple[str, ...]:
    names = (
        material_names[element.material],
        part_names[element.component],
        zone_names[element.zone],
        _ALL_SOLIDS,
        (
            _TEMPLATE_SOLIDS
            if element.origin == _TEMPLATE_ORIGIN
            else _TRANSITION_SOLIDS
        ),
        element.hm_physical_name,
        *element.preserved_physical_names,
    )
    if len({name.upper() for name in names}) != len(names):
        raise PackageBuildError(
            f"element {element.tag} has colliding Physical Group memberships"
        )
    return names


def _add_package_discrete_mesh(
    gmsh: Any,
    plan: PackageMeshPlan,
) -> dict[str, int]:
    material_names, part_names, zone_names = _validated_physical_names(plan)
    entity_keys: list[tuple[str, str, str, str, str, tuple[str, ...]]] = []
    entity_index: dict[
        tuple[str, str, str, str, str, tuple[str, ...]], int
    ] = {}
    for element in plan.elements:
        key = _element_entity_key(element)
        if key not in entity_index:
            entity_index[key] = len(entity_keys)
            entity_keys.append(key)
    if not entity_keys:
        raise PackageBuildError("cannot write an empty package mesh")
    entity_by_key = {
        key: gmsh.model.addDiscreteEntity(3, index + 1)
        for index, key in enumerate(entity_keys)
    }

    maximum_node_tag = max(node.tag for node in plan.nodes)
    if maximum_node_tag > max(10_000_000, 4 * plan.node_count):
        raise PackageBuildError(
            "package node tags are too sparse for deterministic entity ownership"
        )
    owner_index = array("I", [0]) * (maximum_node_tag + 1)
    for element in plan.elements:
        owner = entity_index[_element_entity_key(element)] + 1
        for node_tag in element.node_tags:
            if owner_index[node_tag] == 0:
                owner_index[node_tag] = owner
    owned_nodes: list[list[MeshNode]] = [[] for _ in entity_keys]
    for node in plan.nodes:
        owner = owner_index[node.tag]
        if owner == 0:
            raise PackageBuildError(f"package node {node.tag} is not used by any element")
        owned_nodes[owner - 1].append(node)
    for key, nodes in zip(entity_keys, owned_nodes):
        gmsh.model.mesh.addNodes(
            3,
            entity_by_key[key],
            [node.tag for node in nodes],
            [value for node in nodes for value in node.coordinates],
        )

    element_blocks: dict[tuple[int, int], list[PackageElement]] = defaultdict(list)
    for element in plan.elements:
        key = _element_entity_key(element)
        element_blocks[(entity_index[key], element.gmsh_type)].append(element)
    for entity_rank, key in enumerate(entity_keys):
        for gmsh_type in sorted(ELEMENT_SPECS):
            block = element_blocks.get((entity_rank, gmsh_type), ())
            if not block:
                continue
            gmsh.model.mesh.addElementsByType(
                entity_by_key[key],
                gmsh_type,
                [element.tag for element in block],
                [node for element in block for node in element.node_tags],
            )

    entity_members_by_physical_name: dict[
        str, set[tuple[str, str, str, str, str, tuple[str, ...]]]
    ] = defaultdict(set)
    expected_counts: Counter[str] = Counter()
    for element in plan.elements:
        key = _element_entity_key(element)
        for name in _element_physical_names(
            element,
            material_names,
            part_names,
            zone_names,
        ):
            entity_members_by_physical_name[name].add(key)
            expected_counts[name] += 1

    for name in sorted(
        entity_members_by_physical_name,
        key=lambda value: value.upper(),
    ):
        keys = entity_members_by_physical_name[name]
        tag = gmsh.model.addPhysicalGroup(
            3,
            [entity_by_key[key] for key in entity_keys if key in keys],
        )
        gmsh.model.setPhysicalName(3, tag, name)

    palette = (
        (226, 93, 93),
        (244, 162, 97),
        (233, 196, 106),
        (42, 157, 143),
        (69, 123, 157),
        (106, 76, 147),
    )
    for index, material in enumerate(sorted(plan.material_element_counts)):
        keys = [key for key in entity_keys if key[1] == material]
        gmsh.model.setColor(
            [(3, entity_by_key[key]) for key in keys],
            *palette[index % len(palette)],
            255,
        )
    return dict(expected_counts)


def _record_fingerprint(records: Iterable[bytes]) -> tuple[int, int, int]:
    accumulator = _FingerprintAccumulator()
    for record in records:
        accumulator.add(record)
    return accumulator.value


class _FingerprintAccumulator:
    __slots__ = ("count", "xor_value", "sum_value")

    def __init__(self) -> None:
        self.count = 0
        self.xor_value = 0
        self.sum_value = 0

    def add(self, record: bytes) -> None:
        digest = int.from_bytes(
            hashlib.blake2b(record, digest_size=16).digest(),
            "big",
        )
        self.count += 1
        self.xor_value ^= digest
        self.sum_value = (self.sum_value + digest) % (1 << 128)

    @property
    def value(self) -> tuple[int, int, int]:
        return self.count, self.xor_value, self.sum_value


def _node_record(tag: int, x: float, y: float, z: float) -> bytes:
    # ASCII MSH 4.1 round-tripping may move a coordinate by one ULP.  A 1 nm
    # audit quantum is still orders of magnitude below the smallest package
    # edge here while remaining stable across that serialization boundary.
    key = (round(x, 9), round(y, 9), round(z, 9))
    return f"{tag}|{key[0]:.9f}|{key[1]:.9f}|{key[2]:.9f}".encode("ascii")


def _element_record(tag: int, gmsh_type: int, node_tags: Sequence[int]) -> bytes:
    return (
        f"{tag}|{gmsh_type}|" + ",".join(str(value) for value in node_tags)
    ).encode("ascii")


def _expected_plan_fingerprints(
    plan: PackageMeshPlan,
) -> tuple[tuple[int, int, int], tuple[int, int, int]]:
    return (
        _record_fingerprint(
            _node_record(node.tag, node.x, node.y, node.z) for node in plan.nodes
        ),
        _record_fingerprint(
            _element_record(element.tag, element.gmsh_type, element.node_tags)
            for element in plan.elements
        ),
    )


def _hybrid_quality_metrics(
    gmsh: Any,
    plan: PackageMeshPlan,
) -> dict[str, float | int]:
    conformal_ring_zones = tuple(
        f"RING_{index}_CONFORMAL_HYBRID"
        for index, topology in enumerate(
            plan.ring_volume_topologies,
            start=1,
        )
        if topology == "conformal_hybrid"
    )
    conformal_core_zones = (
        ("UF_TRACE_CORE_FRESH_CONFORMAL_HYBRID",)
        if plan.underfill_core_applied_volume_topology == "conformal_hybrid"
        else ()
    )
    if (
        plan.bulk_mesh_mode != "hybrid"
        and not conformal_ring_zones
        and not conformal_core_zones
    ):
        return {}
    region_zones = (
        tuple(region.zone for region in plan.hybrid_regions)
        + conformal_ring_zones
        + conformal_core_zones
    )
    if not region_zones:
        raise PackageBuildError("hybrid output does not declare any XYZ bulk region")
    physical_tag_by_zone: dict[str, int] = {}
    for dimension, tag in gmsh.model.getPhysicalGroups(3):
        name = gmsh.model.getPhysicalName(int(dimension), int(tag))
        if int(dimension) != 3 or not name.startswith("ZONE_"):
            continue
        for zone in region_zones:
            if name == _physical_zone_name(zone):
                if zone in physical_tag_by_zone:
                    raise PackageBuildError(
                        f"hybrid zone {zone!r} has multiple Physical Groups"
                    )
                physical_tag_by_zone[zone] = int(tag)
    if set(physical_tag_by_zone) != set(region_zones):
        raise PackageBuildError("hybrid XYZ bulk Physical Groups are incomplete")

    element_tags: list[int] = []
    result: dict[str, float | int] = {"zone_count": len(region_zones)}
    for zone in region_zones:
        zone_tags: list[int] = []
        allowed_types = (
            {4, 5, 6, 7}
            if zone in conformal_ring_zones
            else {4, 5, 7}
            if zone in conformal_core_zones
            else {4, 7}
        )
        for entity in gmsh.model.getEntitiesForPhysicalGroup(
            3, physical_tag_by_zone[zone]
        ):
            element_types, tag_blocks, _ = gmsh.model.mesh.getElements(3, entity)
            for element_type, tags in zip(element_types, tag_blocks):
                if int(element_type) not in allowed_types:
                    raise PackageBuildError(
                        f"hybrid zone {zone!r} contains an element kind outside "
                        "its explicit topology/fallback policy"
                    )
                zone_tags.extend(int(tag) for tag in tags)
        expected_count = plan.zone_element_counts.get(zone, 0)
        if not zone_tags or len(zone_tags) != expected_count:
            raise PackageBuildError(
                f"hybrid zone {zone!r} membership differs from the plan"
            )
        token = _token(zone).lower()
        result[f"{token}_element_count"] = len(zone_tags)
        element_tags.extend(zone_tags)
    if len(element_tags) != len(set(element_tags)):
        raise PackageBuildError("hybrid XYZ bulk regions overlap")
    result["element_count"] = len(element_tags)
    metric_names = {
        "minSJ": "minimum_scaled_jacobian",
        "minSICN": "minimum_sicn",
        "minSIGE": "minimum_sige",
    }
    for gmsh_name, report_name in metric_names.items():
        values = sorted(
            float(value)
            for value in gmsh.model.mesh.getElementQualities(
                element_tags,
                gmsh_name,
            )
        )
        if len(values) != len(element_tags) or any(
            not math.isfinite(value) for value in values
        ):
            raise PackageBuildError(
                f"hybrid {gmsh_name} quality evaluation is incomplete"
            )
        minimum = values[0]
        if minimum < _HYBRID_DEMO_MIN_QUALITY:
            raise PackageBuildError(
                f"hybrid {gmsh_name}={minimum:.6g} is below the demo "
                f"threshold {_HYBRID_DEMO_MIN_QUALITY:.2f}"
            )
        result[report_name] = minimum
        result[f"p01_{report_name.removeprefix('minimum_')}"] = values[
            int(0.01 * (len(values) - 1))
        ]
    return result


def _validate_gmsh_package_model(
    gmsh: Any,
    plan: PackageMeshPlan,
    expected_physical_counts: Mapping[str, int],
    expected_fingerprints: tuple[tuple[int, int, int], tuple[int, int, int]],
) -> tuple[float, int, dict[str, float | int]]:
    surface_entities = tuple(gmsh.model.getEntities(2))
    _, surface_blocks, _ = gmsh.model.mesh.getElements(2)
    if surface_entities or sum(len(tags) for tags in surface_blocks):
        raise PackageBuildError("package output must contain only volume elements")

    raw_node_tags, raw_coordinates, _ = gmsh.model.mesh.getNodes()
    actual_node_fingerprint = _record_fingerprint(
        _node_record(
            int(tag),
            float(raw_coordinates[3 * index]),
            float(raw_coordinates[3 * index + 1]),
            float(raw_coordinates[3 * index + 2]),
        )
        for index, tag in enumerate(raw_node_tags)
    )
    if actual_node_fingerprint != expected_fingerprints[0]:
        raise PackageBuildError("written package node fingerprint differs from the plan")

    actual_element_fingerprint = _FingerprintAccumulator()
    minimum_determinant = math.inf
    entity_element_counts: dict[int, int] = {}
    for _dimension, entity_tag_value in gmsh.model.getEntities(3):
        entity_tag = int(entity_tag_value)
        element_types, tag_blocks, node_blocks = gmsh.model.mesh.getElements(
            3,
            entity_tag,
        )
        entity_count = 0
        for element_type_value, tags, flat_nodes in zip(
            element_types,
            tag_blocks,
            node_blocks,
        ):
            gmsh_type = int(element_type_value)
            specification = ELEMENT_SPECS.get(gmsh_type)
            if specification is None:
                raise PackageBuildError(
                    f"written package contains unsupported Gmsh type {gmsh_type}"
                )
            node_count = specification[1]
            entity_count += len(tags)
            for index, tag in enumerate(tags):
                actual_element_fingerprint.add(
                    _element_record(
                        int(tag),
                        gmsh_type,
                        tuple(
                            int(value)
                            for value in flat_nodes[
                                index * node_count : (index + 1) * node_count
                            ]
                        ),
                    )
                )
            determinants = tuple(
                float(value)
                for value in gmsh.model.mesh.getElementQualities(tags, "minDetJac")
            )
            if len(determinants) != len(tags):
                raise PackageBuildError(
                    "written package Jacobian evidence is incomplete"
                )
            if determinants:
                if any(
                    not math.isfinite(value) or value <= 0.0
                    for value in determinants
                ):
                    raise PackageBuildError(
                        "written package contains a non-positive Jacobian"
                    )
                block_minimum = min(determinants)
                minimum_determinant = min(minimum_determinant, block_minimum)
        entity_element_counts[entity_tag] = entity_count
    if actual_element_fingerprint.value != expected_fingerprints[1]:
        raise PackageBuildError(
            "written package element connectivity differs from the plan"
        )
    if not math.isfinite(minimum_determinant):
        raise PackageBuildError("written package contains no volume elements")

    actual_physical_counts: dict[str, int] = {}
    for dimension, physical_tag_value in gmsh.model.getPhysicalGroups(3):
        if int(dimension) != 3:
            continue
        physical_tag = int(physical_tag_value)
        name = str(gmsh.model.getPhysicalName(3, physical_tag))
        actual_physical_counts[name] = sum(
            entity_element_counts[int(entity)]
            for entity in gmsh.model.getEntitiesForPhysicalGroup(3, physical_tag)
        )
    if actual_physical_counts != dict(expected_physical_counts):
        raise PackageBuildError("written package Physical Groups differ from the plan")
    duplicate_node_count = len(gmsh.model.mesh.getDuplicateNodes())
    if duplicate_node_count:
        raise PackageBuildError(
            f"written package contains {duplicate_node_count} duplicate nodes"
        )
    return (
        minimum_determinant,
        duplicate_node_count,
        _hybrid_quality_metrics(gmsh, plan),
    )


def _source_definition_artifact(
    *,
    label: str,
    path: Path | None,
    size_bytes: int | None,
    sha256: str | None,
) -> dict[str, object]:
    if (
        path is None
        or size_bytes is None
        or size_bytes < 0
        or not isinstance(sha256, str)
        or len(sha256) != 64
    ):
        raise PackageBuildError(
            f"{label} lacks the content snapshot required for package replay"
        )
    return {
        "path": str(path),
        "size_bytes": size_bytes,
        "sha256": sha256.lower(),
    }


def _resolved_component_material(
    plan: PackageMeshPlan,
    component: str,
) -> str:
    materials = {
        element.material
        for element in plan.elements
        if element.component == component
    }
    if len(materials) != 1:
        raise PackageBuildError(
            f"package component {component!r} does not have one resolved material"
        )
    return next(iter(materials))


def _package_parameters_payload(plan: PackageMeshPlan) -> dict[str, object]:
    stack = plan.stack
    package = plan.bundle.package
    component_sources = [
        {
            "name": name,
            **_source_definition_artifact(
                label=f"component {name!r}",
                path=component.source_path,
                size_bytes=component.source_size_bytes,
                sha256=component.source_sha256,
            ),
        }
        for name, component in sorted(plan.bundle.components.items())
    ]
    material_resolution = {
        "policy": (
            "generated_component_authoritative"
            if plan.generated_materials_authoritative
            else "frozen_sidecar_aliases"
        ),
        "generated_materials_authoritative": (
            plan.generated_materials_authoritative
        ),
        "substrate": {
            "raw_component_token": stack.substrate_material,
            "resolved_material": _resolved_component_material(plan, "SUBSTRATE"),
        },
        "added_si": {
            "raw_component_token": stack.die_material,
            "resolved_material": _resolved_component_material(plan, "ADDED_SI"),
        },
        "rings": [
            {
                "index": index,
                "raw_component_token": raw_token,
                "resolved_material": _resolved_component_material(
                    plan,
                    f"RING_{index}",
                ),
            }
            for index, (raw_token, _bottom, _top, _height) in enumerate(
                stack.ring_parts,
                start=1,
            )
        ],
        "uf": (
            {
                "corner_core": {
                    "raw_component_token": stack.uf_component,
                    "resolved_material": _resolved_component_material(
                        plan,
                        "UF_CORNER_CORE",
                    ),
                },
                "fillet": {
                    "raw_component_token": stack.uf_component,
                    "resolved_material": _resolved_component_material(
                        plan,
                        "UF_FILLET",
                    ),
                },
            }
            if plan.component_mesh_policies
            else {
                "raw_component_token": stack.uf_component,
                "resolved_material": _resolved_component_material(
                    plan,
                    "UF_FILLET",
                ),
            }
        ),
    }
    upper_uf_region = max(
        (
            region
            for region in plan.hybrid_regions
            if region.zone == "UF_XYZ_HYBRID_BULK"
        ),
        key=lambda region: region.far_z_mm,
        default=None,
    )
    generated_uf_cap_z = (
        upper_uf_region.far_z_mm if upper_uf_region is not None else None
    )
    omitted_uf_tip_height = (
        max(0.0, stack.uf_top_mm - generated_uf_cap_z)
        if generated_uf_cap_z is not None
        else None
    )

    def hybrid_region_payload(region: PackageHybridRegion) -> dict[str, object]:
        payload = asdict(region)
        payload["edge_growth_ratio"] = (
            region.edge_growth_ratio
            if region.growth_measurement_available else None
        )
        payload["adapter_xy_edge_growth_ratio"] = (
            region.adapter_xy_edge_growth_ratio
        )
        payload["adapter_surface_face_reduction_ratio"] = (
            region.adapter_surface_face_reduction_ratio
        )
        if not region.growth_measurement_available:
            payload.update(
                {
                    "growth_ratio_x": None,
                    "growth_ratio_y": None,
                    "growth_ratio_z": None,
                }
            )
        return payload

    def ring_topology_payload(index: int, topology: str) -> dict[str, object]:
        zone = (
            f"RING_{index}_CONFORMAL_HYBRID"
            if topology == "conformal_hybrid"
            else f"RING_{index}_SWEEP"
        )
        counts = dict(plan.zone_element_kind_counts.get(zone, {}))
        payload: dict[str, object] = {
            "index": index,
            "requested_volume_topology": topology,
            "applied_volume_topology": topology,
            "implicit_topology_selection": False,
            "zone": zone,
            "generated_element_kind_counts": counts,
        }
        if topology == "conformal_hybrid":
            tet4_count = counts.get("TET4", 0)
            pyramid5_count = counts.get("PYRAMID5", 0)
            converted_wedge6 = tet4_count // 2
            pyramid_remainder = pyramid5_count - 3 * converted_wedge6
            if (
                tet4_count % 2
                or pyramid_remainder < 0
                or pyramid_remainder % 6
                or converted_wedge6 + pyramid_remainder // 6 <= 0
            ):
                raise PackageBuildError(
                    f"ring {index} conformal-hybrid conversion evidence is inconsistent"
                )
            payload.update(
                {
                    "converted_source_element_kind_counts": {
                        "HEX8": pyramid_remainder // 6,
                        "WEDGE6": converted_wedge6,
                    },
                    "quality_fallback_element_kind_counts": {
                        "HEX8": counts.get("HEX8", 0),
                        "WEDGE6": counts.get("WEDGE6", 0),
                    },
                    "generated_conformal_element_kind_counts": {
                        "TET4": tet4_count,
                        "PYRAMID5": pyramid5_count,
                    },
                }
            )
        return payload

    def explicit_component_mesh_policy_payload() -> dict[str, object]:
        """Serialize only the decisions that drive the Package V2 backends.

        Generated-component topology, Frozen-interface inheritance and
        generated/generated common-surface negotiation are separate contracts.
        The report must not reconstruct any of them from a Component role or
        from an aggregate ``bulk_mesh_mode`` label.
        """

        if set(plan.component_mesh_policy_evidence) != set(
            PACKAGE_COMPONENT_MESH_ROLES
        ):
            raise PackageBuildError(
                "explicit Package V2 plan lacks complete component topology evidence"
            )
        if set(plan.interface_match_policy_evidence) != set(
            PACKAGE_INTERFACE_MATCH_ROLES
        ):
            raise PackageBuildError(
                "explicit Package V2 plan lacks complete Frozen-interface evidence"
            )
        return {
            "schema": "easymesh-component-mesh-policy-v1",
            "component_mesh_policies": {
                role: dict(plan.component_mesh_policies[role])
                for role in PACKAGE_COMPONENT_MESH_ROLES
            },
            "interface_match_policies": {
                role: dict(plan.interface_match_policies[role])
                for role in PACKAGE_INTERFACE_MATCH_ROLES
            },
            "component_mesh_policy_evidence": {
                role: dict(plan.component_mesh_policy_evidence[role])
                for role in PACKAGE_COMPONENT_MESH_ROLES
            },
            "interface_match_policy_evidence": {
                role: dict(plan.interface_match_policy_evidence[role])
                for role in PACKAGE_INTERFACE_MATCH_ROLES
            },
            "generated_component_role_bindings": dict(
                plan.generated_component_role_bindings
            ),
            "generated_interface_policies": [
                value.to_dict() for value in plan.generated_interface_policies
            ],
            "generated_interface_continuity_groups": [
                value.to_dict()
                for value in plan.generated_interface_continuity_groups
            ],
            "generated_surface_execution_plan": (
                None
                if plan.generated_surface_execution_plan is None
                else plan.generated_surface_execution_plan.to_dict()
            ),
            "generated_interface_policy_evidence": [
                dict(value)
                for value in plan.generated_interface_policy_evidence
            ],
            "backend_contracts": {
                "structured_sweep": (
                    "inherit one complete shared surface or section and let the "
                    "sweep generate every downstream volume element"
                ),
                "orthogonal_hex": (
                    "generate only axis-aligned HEX8; the stair-step boundary is "
                    "the explicit topology result"
                ),
                "conformal_hybrid": (
                    "Gmsh owns all 3D connectivity; unlocked volume is TET4 and "
                    "locked TRI3/QUAD4 surfaces may require WEDGE6/PYRAMID5 transitions"
                ),
            },
            "interface_contract": (
                "discover positive-area common faces from canonical solids; resolve "
                "one shared surface from both topology/target/transition policies; "
                "both volume backends consume the same nodes and complete facets"
            ),
            "independent_boundary_deletion_forbidden": True,
            "minimum_sj_sicn_sige": _HYBRID_DEMO_MIN_QUALITY,
            "failure_policy": (
                "fail closed on unsupported topology pairs, interface drift, "
                "boundary deletion, non-manifold faces, duplicate connectivity, "
                "low quality or volume mismatch"
            ),
            "hybrid_regions": [
                hybrid_region_payload(region)
                for region in plan.hybrid_regions
            ],
        }

    return {
        "schema": (
            "easymesh-package-v2-mesh-parameters-v1"
            if plan.component_mesh_policies
            else "easymesh-package-v1"
        ),
        "package_path": str(package.source_path or ""),
        "bulk_mesh_mode": plan.bulk_mesh_mode,
        "assembly_sources": {
            "package": _source_definition_artifact(
                label="package definition",
                path=package.source_path,
                size_bytes=package.source_size_bytes,
                sha256=package.source_sha256,
            ),
            "components": component_sources,
        },
        "source_mesh": {
            "path": str(stack.bump_source_path),
            "sha256": plan.source_sha256,
            "transform": "RX180",
            "translation_rule": "(x,y,z)->(x,-y,bump_bottom+source_z_max-z)",
        },
        "mesh_controls_mm": {
            "far_field_size": plan.far_field_size_mm,
            "transition_distance": plan.transition_distance_mm,
        },
        "material_resolution": material_resolution,
        "stack_mm": {
            "substrate": [stack.substrate_bottom_mm, stack.substrate_top_mm],
            "connected_bump": [stack.bump_bottom_mm, stack.bump_top_mm],
            "added_si": [stack.die_bottom_mm, stack.die_top_mm],
            "rings": [
                {
                    "material": _resolved_component_material(
                        plan,
                        f"RING_{index}",
                    ),
                    "raw_component_token": raw_token,
                    "bottom": bottom,
                    "top": top,
                }
                for index, (raw_token, bottom, top, _height) in enumerate(
                    stack.ring_parts,
                    start=1,
                )
            ],
            "uf": {
                "base": stack.uf_base_mm,
                "top_at_wall": stack.uf_top_mm,
                "analytic_top_at_wall": stack.uf_top_mm,
                "generated_mesh_cap": generated_uf_cap_z,
                "omitted_regularized_tip_height": omitted_uf_tip_height,
                "toe_width": stack.uf_width_mm,
                "material": _resolved_component_material(plan, "UF_FILLET"),
                "raw_component_token": stack.uf_component,
            },
        },
        "corner_ports": [
            {
                "source_index": port.source_index,
                "final_corner": port.final_corner,
                "bounds_xy_mm": [
                    port.x_min_mm,
                    port.x_max_mm,
                    port.y_min_mm,
                    port.y_max_mm,
                ],
                "pitch_xy_mm": [port.size_x_mm, port.size_y_mm],
                "hex8_count": len(port.element_tags),
                "z_levels_mm": list(port.final_z_levels_mm),
            }
            for port in plan.corner_ports
        ],
        "exact_interface_face_counts": plan.exact_interface_face_counts,
        "component_element_kind_counts": plan.component_element_kind_counts,
        "zone_element_kind_counts": plan.zone_element_kind_counts,
        "mesh_policy": (
            explicit_component_mesh_policy_payload()
            if plan.component_mesh_policies
            else {
            "bulk_mesh_mode": plan.bulk_mesh_mode,
            "ring_volume_topologies": list(plan.ring_volume_topologies),
            "ring_volume_topology_evidence": [
                ring_topology_payload(index, topology)
                for index, topology in enumerate(
                    plan.ring_volume_topologies,
                    start=1,
                )
            ],
            "hybrid_scope": plan.hybrid_scope,
            "hybrid_transition_z_levels_mm": list(
                plan.hybrid_transition_z_levels_mm
            ),
            "uf_above_bump_target_z_mm": plan.uf_above_bump_target_z_mm,
            "underfill_core": {
                "mesh_mode": plan.underfill_core_mesh_mode,
                "requested_volume_topology": (
                    plan.underfill_core_requested_volume_topology
                ),
                "applied_volume_topology": (
                    plan.underfill_core_applied_volume_topology
                ),
                "implicit_topology_selection": (
                    plan.underfill_core_implicit_topology_selection
                ),
                "target_edge_mm": plan.underfill_core_target_edge_mm,
                "transition_distance_mm": plan.underfill_core_transition_distance_mm,
                "effective_target_edge_mm": (
                    plan.underfill_core_effective_target_edge_mm
                ),
                "effective_transition_distance_mm": (
                    plan.underfill_core_effective_transition_distance_mm
                ),
                "quality_triggered_refinement": (
                    plan.underfill_core_mesh_mode == "target_mesh_control"
                    and plan.underfill_core_effective_target_edge_mm is not None
                    and plan.underfill_core_target_edge_mm is not None
                    and plan.underfill_core_effective_target_edge_mm
                    < plan.underfill_core_target_edge_mm
                    - _COORDINATE_TOLERANCE_MM
                ),
                "generation_method": (
                    "surface_trace_free_skin_tri_star_quality_hybrid"
                    if plan.underfill_core_applied_volume_topology
                    == "conformal_hybrid"
                    else "surface_trace_orthogonal_hex8_staircase"
                ),
                "target_scope": "shared_uf_ring_substrate_radial_xy_partition_locked_edges_exempt",
                "z_authority": (
                    "locked_surface_facet_levels_with_stable_free_face_diagonals"
                    if plan.underfill_core_applied_volume_topology
                    == "conformal_hybrid"
                    else "locked_surface_facet_levels"
                ),
                "locked_z_level_count": plan.underfill_core_locked_z_level_count,
                "minimum_determinant": (
                    plan.underfill_core_minimum_determinant
                ),
                "minimum_scaled_jacobian": (
                    plan.underfill_core_minimum_scaled_jacobian
                ),
                "minimum_sicn": plan.underfill_core_minimum_sicn,
                "minimum_sige": plan.underfill_core_minimum_sige,
                "locked_interface_face_count": plan.underfill_core_locked_interface_face_count,
                "generated_element_count": plan.underfill_core_generated_element_count,
                "generated_hex8_count": plan.underfill_core_generated_hex8_count,
                "generated_pyramid5_count": (
                    plan.underfill_core_generated_pyramid5_count
                ),
                "generated_tet4_count": (
                    plan.underfill_core_generated_tet4_count
                ),
                "quality_fallback_hex8_count": (
                    plan.underfill_core_quality_fallback_hex8_count
                ),
                "star_converted_hex8_count": (
                    plan.underfill_core_star_converted_hex8_count
                ),
                "free_surface_tri3_count": (
                    plan.underfill_core_free_surface_tri3_count
                ),
                "free_surface_quad_fallback_count": (
                    plan.underfill_core_free_surface_quad_fallback_count
                ),
                "exterior_quad_owned_by_non_hex_count": (
                    plan.underfill_core_exterior_quad_owned_by_non_hex_count
                ),
                "non_hex_exterior_face_count": (
                    plan.underfill_core_non_hex_exterior_face_count
                ),
                "non_hex_exterior_face_count_deprecated": True,
                "orthogonal_hex_verified": (
                    plan.underfill_core_orthogonal_hex_verified
                ),
                "cross_section_policy": (
                    "axis_aligned_quad4_cartesian_cells"
                    if plan.underfill_core_applied_volume_topology
                    == "orthogonal_hex"
                    else None
                ),
                "boundary_cut_policy": (
                    "retain_complete_cells_discard_cut_cells"
                    if plan.underfill_core_applied_volume_topology
                    == "orthogonal_hex"
                    else None
                ),
            },
            "hybrid_regions": [
                hybrid_region_payload(region)
                for region in plan.hybrid_regions
            ],
            "protected_corner_core": (
                "Frozen connected-bump topology is retained; lower UF locks exact "
                "wall surface faces and generates fresh target-controlled "
                + (
                    "quality-selected TET4/PYRAMID5 with whole-HEX8 fallback"
                    if plan.underfill_core_applied_volume_topology
                    == "conformal_hybrid"
                    else "HEX8 connectivity"
                )
                + " volume elements"
            ),
            "uf_geometry": (
                "trace-only locked-interface lower core with target-controlled "
                + (
                    "fresh free-skin TET4/PYRAMID5/quality-fallback-HEX8 volume"
                    if plan.underfill_core_applied_volume_topology
                    == "conformal_hybrid"
                    else "fresh HEX8 staircase/sweep"
                )
                + " and upper PYRAMID5/TET4 hybrid cap"
            ),
            "uf_surface_skin": (
                "stable TRI3 free skin generated for the lower conformal core; "
                "locked wall/base/top remain exact QUAD4"
                if plan.underfill_core_applied_volume_topology
                == "conformal_hybrid"
                else "faceted body-fitted TRI3 skin generated for upper UF"
                if plan.uf_surface_skin_generated
                else "not generated"
            ),
            "uf_cut_cells_skipped": plan.uf_cut_cell_count,
            "uf_cut_cells_skipped_scope": "fresh lower-UF scaffold against the analytic fillet envelope",
            "substrate": (
                "locked-interface XYZ-graded TET4/PYRAMID5 bulk"
                if plan.bulk_mesh_mode == "hybrid"
                else "graded conformal sweep"
            ),
            "rings": (
                "independently selected structured sweep or conformal "
                "TET4/PYRAMID5 prism fill"
            ),
            "uf": (
                "locked lower wall trace with an independent target-controlled "
                + (
                    "fresh free-skin TET4/PYRAMID5/HEX8-fallback volume"
                    if plan.underfill_core_applied_volume_topology
                    == "conformal_hybrid"
                    else "fresh HEX8 sweep"
                )
                + " and PYRAMID5/TET4 cap"
            ),
            "bulk_transition": plan.bulk_mesh_mode,
            "optimization": (
                {
                    "generated_hybrid_regions": (
                        "EasyMesh generates and audits the target-controlled shared "
                        "UF/ring radial QUAD4 partition and explicit lower topology; "
                        "Gmsh generates the separately locked upper hybrid volume"
                    ),
                    "preserved_regions": (
                        "connected bump exact interface traces and ring sweeps "
                        "are not topology-optimized; the lower UF is independently "
                        "generated from those locked traces"
                    ),
                    "minimum_sj_sicn_sige": _HYBRID_DEMO_MIN_QUALITY,
                    "failure_policy": (
                        "fail closed on low quality, duplicate nodes/elements, "
                        "non-manifold faces, interface drift or volume mismatch"
                    ),
                }
                if plan.bulk_mesh_mode == "hybrid"
                else {
                    "generated_hybrid_regions": "not applicable",
                    "preserved_regions": "exact conformal sweep",
                }
            ),
            "bulk_transition_strategy": (
                "die and substrate start XYZ-graded TET4/PYRAMID5 volumes at "
                "their locked C4 interfaces; lower UF applies the explicitly selected "
                "topology to the shared target-controlled QUAD4 partition while "
                "retaining locked wall-facet Z levels "
                "and its exact QUAD4 seam continues through the upper hybrid"
            ),
            }
        ),
    }


def build_package_mesh(
    package_path: str | Path,
    output_path: str | Path,
    *,
    component_mesh_policies: Mapping[str, Mapping[str, object]] | None = None,
    interface_match_policies: Mapping[str, Mapping[str, object]] | None = None,
    generated_component_role_bindings: Mapping[str, str] | None = None,
    generated_interface_policies: Sequence[NegotiatedComponentInterface]
    | None = None,
    generated_interface_continuity_groups: Sequence[
        GeneratedSurfaceEquivalenceGroup
    ]
    | None = None,
    generated_surface_execution_plan: GeneratedSurfaceExecutionPlan
    | None = None,
    bulk_mesh_mode: str = "sweep",
    far_field_size_mm: float = 0.080,
    transition_distance_mm: float = 0.120,
    ring_volume_topologies: Sequence[str] = (
        "structured_sweep",
        "structured_sweep",
    ),
    underfill_core_mesh_mode: str = "target_mesh_control",
    underfill_core_volume_topology: str | None = "orthogonal_hex",
    underfill_core_target_edge_mm: float | None = 0.080,
    underfill_core_transition_distance_mm: float | None = 0.120,
    generated_materials_authoritative: bool = False,
    verbose: bool = False,
    job_id: str | None = None,
) -> PackageBuildSummary:
    """Build, audit, and atomically publish one package MSH 4.1 artifact."""

    if (component_mesh_policies is None) != (interface_match_policies is None):
        raise PackageBuildError(
            "component_mesh_policies and interface_match_policies must be "
            "provided together"
    )
    if component_mesh_policies is not None:
        normalized_component_policies = _normalize_component_mesh_policies(
            component_mesh_policies
        )
        _normalize_interface_match_policies(interface_match_policies)
        if (
            generated_component_role_bindings is None
            or generated_interface_policies is None
            or generated_interface_continuity_groups is None
        ):
            raise PackageBuildError(
                "explicit Component policies require geometry-derived generated "
                "interface negotiation"
            )
        normalized_interfaces, normalized_bindings = (
            _normalize_generated_interface_policies(
                generated_interface_policies,
                component_role_bindings=generated_component_role_bindings,
                component_policies=normalized_component_policies,
            )
        )
        normalized_continuity_groups = _normalize_generated_interface_continuity_groups(
            generated_interface_continuity_groups,
            interfaces=normalized_interfaces,
            component_role_bindings=normalized_bindings,
            component_policies=normalized_component_policies,
            sweep_direction_xyz_by_component=(
                _sweep_directions_from_surface_execution_plan(
                    generated_surface_execution_plan
                )
            ),
        )
        if generated_surface_execution_plan is not None:
            _normalize_generated_surface_execution_plan(
                generated_surface_execution_plan,
                interfaces=normalized_interfaces,
                continuity_groups=normalized_continuity_groups,
                component_role_bindings=normalized_bindings,
                component_policies=normalized_component_policies,
            )
    else:
        if (
            generated_component_role_bindings is not None
            or generated_interface_policies is not None
            or generated_interface_continuity_groups is not None
            or generated_surface_execution_plan is not None
        ):
            raise PackageBuildError(
                "generated interface negotiation requires explicit Component policies"
            )
        resolved_underfill_core_mode = normalize_underfill_core_mesh_mode(
            underfill_core_mesh_mode
        )
        _normalize_ring_volume_topologies(ring_volume_topologies)
        _resolve_underfill_core_volume_topology(
            resolved_underfill_core_mode,
            underfill_core_volume_topology,
        )
    resolved_package = Path(package_path).expanduser().resolve()
    output = normalized_mesh_output(output_path)
    bundle = load_package_bundle(resolved_package)
    report_path, parameters_path = _validate_package_output_paths(bundle, output)
    if len(bundle.package.mesh_sources) != 1:
        raise PackageBuildError("the current package profile requires one mesh source")
    source_path = bundle.package.mesh_sources[0].mesh_path
    with exclusive_artifact_lock(output):
        with exclusive_artifact_lock(source_path):
            plan = plan_package_mesh(
                bundle,
                component_mesh_policies=component_mesh_policies,
                interface_match_policies=interface_match_policies,
                generated_component_role_bindings=(
                    generated_component_role_bindings
                ),
                generated_interface_policies=generated_interface_policies,
                generated_interface_continuity_groups=(
                    generated_interface_continuity_groups
                ),
                generated_surface_execution_plan=(
                    generated_surface_execution_plan
                ),
                bulk_mesh_mode=bulk_mesh_mode,
                far_field_size_mm=far_field_size_mm,
                transition_distance_mm=transition_distance_mm,
                ring_volume_topologies=ring_volume_topologies,
                underfill_core_mesh_mode=underfill_core_mesh_mode,
                underfill_core_volume_topology=underfill_core_volume_topology,
                underfill_core_target_edge_mm=underfill_core_target_edge_mm,
                underfill_core_transition_distance_mm=(
                    underfill_core_transition_distance_mm
                ),
                generated_materials_authoritative=(
                    generated_materials_authoritative
                ),
                verbose=verbose,
            )

            try:
                import gmsh  # type: ignore
            except ModuleNotFoundError as error:  # pragma: no cover - dependency failure
                raise RuntimeError("Gmsh is required to write the package mesh") from error

            options = {
                "General.Terminal": 1.0 if verbose else 0.0,
                "Mesh.MshFileVersion": 4.1,
                "Mesh.Binary": 0.0,
                "Mesh.ElementOrder": 1.0,
                "Mesh.SaveAll": 1.0,
            }
            expected_fingerprints = _expected_plan_fingerprints(plan)
            with isolated_gmsh_model(
                gmsh,
                "__easymesh_package",
                number_options=options,
            ):
                physical_counts = _add_package_discrete_mesh(gmsh, plan)
                (
                    minimum_determinant,
                    duplicate_count,
                    hybrid_quality_metrics,
                ) = _validate_gmsh_package_model(
                    gmsh,
                    plan,
                    physical_counts,
                    expected_fingerprints,
                )
                with atomic_output_path(output) as temporary_mesh:
                    gmsh.write(str(temporary_mesh))
                    with isolated_gmsh_model(
                        gmsh,
                        "__easymesh_package_reopen",
                        number_options={"General.Terminal": 0.0},
                    ):
                        gmsh.merge(str(temporary_mesh))
                        (
                            reopened_minimum,
                            reopened_duplicates,
                            reopened_hybrid_quality_metrics,
                        ) = _validate_gmsh_package_model(
                            gmsh,
                            plan,
                            physical_counts,
                            expected_fingerprints,
                        )
                    minimum_determinant = min(
                        minimum_determinant,
                        reopened_minimum,
                    )
                    duplicate_count = max(duplicate_count, reopened_duplicates)
                    if hybrid_quality_metrics.keys() != (
                        reopened_hybrid_quality_metrics.keys()
                    ):
                        raise PackageBuildError(
                            "reopened hybrid quality metrics differ from the "
                            "written model"
                        )
                    hybrid_quality_metrics = {
                        name: (
                            min(
                                float(value),
                                float(reopened_hybrid_quality_metrics[name]),
                            )
                            if not name.endswith("_count")
                            else int(value)
                        )
                        for name, value in hybrid_quality_metrics.items()
                    }
                    mesh_artifact = file_artifact(
                        temporary_mesh,
                        published_path=output,
                    )

        summary = PackageBuildSummary(
            mesh_path=str(output),
            report_path=str(report_path),
            parameters_path=str(parameters_path),
            package_path=str(resolved_package),
            source_mesh_path=str(plan.stack.bump_source_path),
            source_sha256=plan.source_sha256,
            bulk_mesh_mode=plan.bulk_mesh_mode,
            hybrid_scope=plan.hybrid_scope,
            hybrid_quality_metrics=hybrid_quality_metrics,
            node_count=plan.node_count,
            element_count=plan.element_count,
            element_kind_counts=plan.element_kind_counts,
            material_element_counts=plan.material_element_counts,
            component_element_counts=plan.component_element_counts,
            zone_element_counts=plan.zone_element_counts,
            zone_element_kind_counts=plan.zone_element_kind_counts,
            corner_port_count=len(plan.corner_ports),
            corner_inward_um=plan.corner_ports[0].inward_x_mm * 1000.0,
            corner_pitch_um=plan.corner_ports[0].size_x_mm * 1000.0,
            interface_face_count=plan.interface_face_count,
            exterior_face_count=plan.exterior_face_count,
            duplicate_node_count=duplicate_count,
            minimum_jacobian_determinant=minimum_determinant,
            source_connectivity_preserved=plan.source_connectivity_preserved,
            uf_surface_skin_generated=plan.uf_surface_skin_generated,
            uf_cut_cell_count=plan.uf_cut_cell_count,
            written_mesh_reopened_verified=True,
            generated_materials_authoritative=(
                plan.generated_materials_authoritative
            ),
            component_mesh_policies=plan.component_mesh_policies,
            interface_match_policies=plan.interface_match_policies,
            component_mesh_policy_evidence=(
                plan.component_mesh_policy_evidence
            ),
            interface_match_policy_evidence=(
                plan.interface_match_policy_evidence
            ),
            generated_component_role_bindings=(
                plan.generated_component_role_bindings
            ),
            generated_interface_policies=plan.generated_interface_policies,
            generated_interface_continuity_groups=(
                plan.generated_interface_continuity_groups
            ),
            generated_surface_execution_plan=(
                plan.generated_surface_execution_plan
            ),
            generated_interface_policy_evidence=(
                plan.generated_interface_policy_evidence
            ),
            ring_volume_topologies=plan.ring_volume_topologies,
            exact_interface_face_counts=plan.exact_interface_face_counts,
            underfill_core_mesh_mode=plan.underfill_core_mesh_mode,
            underfill_core_target_edge_mm=plan.underfill_core_target_edge_mm,
            underfill_core_transition_distance_mm=(
                plan.underfill_core_transition_distance_mm
            ),
            underfill_core_effective_target_edge_mm=(
                plan.underfill_core_effective_target_edge_mm
            ),
            underfill_core_effective_transition_distance_mm=(
                plan.underfill_core_effective_transition_distance_mm
            ),
            underfill_core_locked_z_level_count=(
                plan.underfill_core_locked_z_level_count
            ),
            underfill_core_minimum_determinant=(
                plan.underfill_core_minimum_determinant
            ),
            underfill_core_minimum_scaled_jacobian=(
                plan.underfill_core_minimum_scaled_jacobian
            ),
            underfill_core_minimum_sicn=plan.underfill_core_minimum_sicn,
            underfill_core_minimum_sige=plan.underfill_core_minimum_sige,
            underfill_core_locked_interface_face_count=(
                plan.underfill_core_locked_interface_face_count
            ),
            underfill_core_generated_element_count=(
                plan.underfill_core_generated_element_count
            ),
            underfill_core_requested_volume_topology=(
                plan.underfill_core_requested_volume_topology
            ),
            underfill_core_applied_volume_topology=(
                plan.underfill_core_applied_volume_topology
            ),
            underfill_core_implicit_topology_selection=(
                plan.underfill_core_implicit_topology_selection
            ),
            underfill_core_generated_hex8_count=(
                plan.underfill_core_generated_hex8_count
            ),
            underfill_core_generated_pyramid5_count=(
                plan.underfill_core_generated_pyramid5_count
            ),
            underfill_core_generated_tet4_count=(
                plan.underfill_core_generated_tet4_count
            ),
            underfill_core_quality_fallback_hex8_count=(
                plan.underfill_core_quality_fallback_hex8_count
            ),
            underfill_core_star_converted_hex8_count=(
                plan.underfill_core_star_converted_hex8_count
            ),
            underfill_core_free_surface_tri3_count=(
                plan.underfill_core_free_surface_tri3_count
            ),
            underfill_core_free_surface_quad_fallback_count=(
                plan.underfill_core_free_surface_quad_fallback_count
            ),
            underfill_core_non_hex_exterior_face_count=(
                plan.underfill_core_non_hex_exterior_face_count
            ),
            underfill_core_exterior_quad_owned_by_non_hex_count=(
                plan.underfill_core_exterior_quad_owned_by_non_hex_count
            ),
            underfill_core_orthogonal_hex_verified=(
                plan.underfill_core_orthogonal_hex_verified
            ),
            component_element_kind_counts=plan.component_element_kind_counts,
            mesh_artifact=mesh_artifact,
        )
        parameter_payload = _package_parameters_payload(plan)
        atomic_write_text(
            parameters_path,
            json.dumps(parameter_payload, indent=2, ensure_ascii=False),
        )
        report_payload: dict[str, object] = {
            "schema": (
                "easymesh-package-v2-mesh-report-v1"
                if plan.component_mesh_policies
                else "easymesh-package-report-v1"
            ),
            "bulk_mesh_mode": plan.bulk_mesh_mode,
            "parameters": parameter_payload,
            "quality": summary.to_dict(),
            "mesh_artifact": dict(mesh_artifact),
        }
        if job_id is not None:
            report_payload["job_id"] = job_id
        atomic_write_text(
            report_path,
            json.dumps(report_payload, indent=2, ensure_ascii=False),
        )
        return summary


__all__ = [
    "PACKAGE_BULK_MESH_MODES",
    "UNDERFILL_CORE_VOLUME_TOPOLOGIES",
    "CornerPort",
    "PackageBuildError",
    "PackageBuildSummary",
    "PackageElement",
    "PackageHybridRegion",
    "PackageInterfaceAudit",
    "PackageMeshPlan",
    "ResolvedPackageStack",
    "build_package_mesh",
    "normalize_package_bulk_mesh_mode",
    "normalize_underfill_core_volume_topology",
    "plan_package_mesh",
    "resolve_package_stack",
]
