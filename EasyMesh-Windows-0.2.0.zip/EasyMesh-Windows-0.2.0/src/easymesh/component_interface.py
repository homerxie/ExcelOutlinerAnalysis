"""Topology-driven surface contracts between adjacent generated Components.

The resolver in this module deliberately knows nothing about underfill, rings,
dies, substrates, material names, or stack order.  It receives one geometric
common-face capability plus the two Component-owned mesh policies and chooses
which side owns the one shared surface mesh.  Volume meshers consume that
surface afterwards; they are never allowed to delete boundary cells to repair
an independently generated mismatch.
"""

from __future__ import annotations

from dataclasses import dataclass
import math


VOLUME_TOPOLOGIES = (
    "structured_sweep",
    "orthogonal_hex",
    "conformal_hybrid",
)


class ComponentInterfaceError(ValueError):
    """Raised when two requested backends cannot share the geometric face."""


def _name(value: object, *, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ComponentInterfaceError(f"{field_name} must be a non-empty string")
    return value.strip()


def _positive(value: object, *, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ComponentInterfaceError(f"{field_name} must be positive and finite")
    result = float(value)
    if not math.isfinite(result) or result <= 0.0:
        raise ComponentInterfaceError(f"{field_name} must be positive and finite")
    return result


def _point3(
    value: object,
    *,
    field_name: str,
) -> tuple[float, float, float]:
    try:
        raw = tuple(value)  # type: ignore[arg-type]
    except TypeError as error:
        raise ComponentInterfaceError(f"{field_name} must be a 3-D vector") from error
    if len(raw) != 3:
        raise ComponentInterfaceError(f"{field_name} must be a 3-D vector")
    output: list[float] = []
    for component in raw:
        if isinstance(component, bool) or not isinstance(component, (int, float)):
            raise ComponentInterfaceError(f"{field_name} must be finite")
        number = float(component)
        if not math.isfinite(number):
            raise ComponentInterfaceError(f"{field_name} must be finite")
        output.append(number)
    return tuple(output)  # type: ignore[return-value]


@dataclass(frozen=True, slots=True)
class PlanarTransportEvidence:
    """Geometry proof used only for cross-body surface continuity.

    ``section_signature`` is produced by the canonical-geometry adjacency
    extractor and is invariant under translation along ``unit_normal_xyz``.
    Equal signatures, parallel normals and collinear centroids prove that two
    distinct common faces are corresponding sweep sections.  A missing proof
    never means "probably compatible"; continuity planning fails closed when
    it needs that comparison.
    """

    unit_normal_xyz: tuple[float, float, float]
    centroid_xyz_mm: tuple[float, float, float]
    section_signature: str

    def __post_init__(self) -> None:
        normal = _point3(self.unit_normal_xyz, field_name="unit_normal_xyz")
        length = math.sqrt(math.fsum(value * value for value in normal))
        if not math.isclose(length, 1.0, rel_tol=1.0e-9, abs_tol=1.0e-9):
            raise ComponentInterfaceError("unit_normal_xyz must be a unit vector")
        object.__setattr__(self, "unit_normal_xyz", normal)
        object.__setattr__(
            self,
            "centroid_xyz_mm",
            _point3(self.centroid_xyz_mm, field_name="centroid_xyz_mm"),
        )
        object.__setattr__(
            self,
            "section_signature",
            _name(self.section_signature, field_name="section_signature"),
        )


@dataclass(frozen=True, slots=True)
class ComponentMeshRequirement:
    component_id: str
    volume_topology: str
    target_edge_mm: float
    transition_distance_mm: float

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "component_id",
            _name(self.component_id, field_name="component_id"),
        )
        if self.volume_topology not in VOLUME_TOPOLOGIES:
            raise ComponentInterfaceError(
                "volume_topology must be one of: " + ", ".join(VOLUME_TOPOLOGIES)
            )
        object.__setattr__(
            self,
            "target_edge_mm",
            _positive(self.target_edge_mm, field_name="target_edge_mm"),
        )
        object.__setattr__(
            self,
            "transition_distance_mm",
            _positive(
                self.transition_distance_mm,
                field_name="transition_distance_mm",
            ),
        )


@dataclass(frozen=True, slots=True)
class CommonFaceCapability:
    """Geometry-only facts about one exact shared face.

    ``axis_aligned_planar`` means a Cartesian QUAD partition can lie on the
    face. ``sweep_section_compatible`` means the face can be the inherited
    section/end surface of a sweep.  Neither flag selects a mesh algorithm.
    """

    interface_id: str
    first_component_id: str
    second_component_id: str
    axis_aligned_planar: bool
    sweep_section_compatible: bool
    transport_evidence: PlanarTransportEvidence | None = None

    def __post_init__(self) -> None:
        for field_name in (
            "interface_id",
            "first_component_id",
            "second_component_id",
        ):
            object.__setattr__(
                self,
                field_name,
                _name(getattr(self, field_name), field_name=field_name),
            )
        if self.first_component_id == self.second_component_id:
            raise ComponentInterfaceError(
                "a generated interface requires two distinct Components"
            )
        if not isinstance(self.axis_aligned_planar, bool) or not isinstance(
            self.sweep_section_compatible, bool
        ):
            raise ComponentInterfaceError(
                "common-face capability flags must be booleans"
            )
        if self.transport_evidence is not None and type(
            self.transport_evidence
        ) is not PlanarTransportEvidence:
            raise ComponentInterfaceError(
                "transport_evidence must be PlanarTransportEvidence or None"
            )
        if self.transport_evidence is not None and not self.sweep_section_compatible:
            raise ComponentInterfaceError(
                "transport evidence requires a sweep-compatible planar face"
            )


@dataclass(frozen=True, slots=True)
class NegotiatedComponentInterface:
    interface_id: str
    component_ids: tuple[str, str]
    surface_policy: str
    interface_target_edge_mm: float
    first_transition_distance_mm: float
    second_transition_distance_mm: float
    permitted_surface_element_kinds: tuple[str, ...]
    first_permitted_volume_element_kinds: tuple[str, ...]
    second_permitted_volume_element_kinds: tuple[str, ...]
    shared_nodes_required: bool = True
    independent_boundary_deletion_forbidden: bool = True
    transport_evidence: PlanarTransportEvidence | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "interface_id": self.interface_id,
            "component_ids": list(self.component_ids),
            "surface_policy": self.surface_policy,
            "interface_target_edge_mm": self.interface_target_edge_mm,
            "transition_distance_mm_by_component": {
                self.component_ids[0]: self.first_transition_distance_mm,
                self.component_ids[1]: self.second_transition_distance_mm,
            },
            "permitted_surface_element_kinds": list(
                self.permitted_surface_element_kinds
            ),
            "permitted_volume_element_kinds_by_component": {
                self.component_ids[0]: list(
                    self.first_permitted_volume_element_kinds
                ),
                self.component_ids[1]: list(
                    self.second_permitted_volume_element_kinds
                ),
            },
            "shared_nodes_required": self.shared_nodes_required,
            "independent_boundary_deletion_forbidden": (
                self.independent_boundary_deletion_forbidden
            ),
            "transport_evidence": (
                None
                if self.transport_evidence is None
                else {
                    "unit_normal_xyz": list(
                        self.transport_evidence.unit_normal_xyz
                    ),
                    "centroid_xyz_mm": list(
                        self.transport_evidence.centroid_xyz_mm
                    ),
                    "section_signature": (
                        self.transport_evidence.section_signature
                    ),
                }
            ),
        }


_VOLUME_KINDS = {
    "orthogonal_hex": ("HEX8",),
    "structured_sweep": ("HEX8", "WEDGE6"),
    # Hybrid describes the admissible family set, not a requirement that every
    # family (or specifically TET4) appear in every component.  A Gmsh-owned
    # structured subregion may therefore remain HEX8 when that is the only
    # quality-safe way to retain an immutable QUAD interface.
    "conformal_hybrid": ("TET4", "HEX8", "PYRAMID5", "WEDGE6"),
}


def negotiate_component_interface(
    geometry: CommonFaceCapability,
    first: ComponentMeshRequirement,
    second: ComponentMeshRequirement,
) -> NegotiatedComponentInterface:
    """Resolve one common surface from geometry, topology, and mesh sizes.

    The operation is symmetric: swapping ``first`` and ``second`` preserves
    the chosen policy.  This DTO does not choose a producer; physical surface
    authority is planned exactly once later from actual canonical sides by
    :func:`plan_neutral_surface_authorities`.
    """

    expected = {geometry.first_component_id, geometry.second_component_id}
    actual = {first.component_id, second.component_id}
    if expected != actual:
        raise ComponentInterfaceError(
            "mesh requirements do not identify the common-face Components"
        )
    ordered = tuple(sorted((first, second), key=lambda value: value.component_id))
    left, right = ordered
    topologies = {left.volume_topology, right.volume_topology}

    if "orthogonal_hex" in topologies:
        if not geometry.axis_aligned_planar:
            raise ComponentInterfaceError(
                f"interface {geometry.interface_id!r} is not axis-aligned planar, "
                "so orthogonal_hex cannot own its shared surface"
            )
        surface_policy = "shared_cartesian_quad"
        surface_kinds = ("QUAD4",)
    elif "structured_sweep" in topologies:
        if not geometry.sweep_section_compatible:
            raise ComponentInterfaceError(
                f"interface {geometry.interface_id!r} is not a compatible sweep "
                "section or inherited surface"
            )
        surface_policy = "shared_inherited_sweep_surface"
        surface_kinds = ("TRI3", "QUAD4")
    else:
        surface_policy = "shared_gmsh_conformal_surface"
        surface_kinds = ("TRI3", "QUAD4")

    return NegotiatedComponentInterface(
        interface_id=geometry.interface_id,
        component_ids=(left.component_id, right.component_id),
        surface_policy=surface_policy,
        interface_target_edge_mm=min(
            left.target_edge_mm,
            right.target_edge_mm,
        ),
        first_transition_distance_mm=left.transition_distance_mm,
        second_transition_distance_mm=right.transition_distance_mm,
        permitted_surface_element_kinds=surface_kinds,
        first_permitted_volume_element_kinds=_VOLUME_KINDS[left.volume_topology],
        second_permitted_volume_element_kinds=_VOLUME_KINDS[right.volume_topology],
        transport_evidence=geometry.transport_evidence,
    )


__all__ = [
    "CommonFaceCapability",
    "ComponentInterfaceError",
    "ComponentMeshRequirement",
    "NegotiatedComponentInterface",
    "PlanarTransportEvidence",
    "VOLUME_TOPOLOGIES",
    "negotiate_component_interface",
]
