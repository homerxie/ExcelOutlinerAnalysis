"""Advanced seed options shared by Layer Z and radial interval editors."""

from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox,
    QFormLayout, QLabel, QVBoxLayout,
)

from .layer_sweep import LayerSweepPolicy, RadialSeedPolicy


class LayerSweepDialog(QDialog):
    def __init__(self, interval, inherited, override=None, parent=None):
        super().__init__(parent)
        radial = interval.axis.value == "radial"
        self.policy_type = RadialSeedPolicy if radial else LayerSweepPolicy
        policy = override or inherited
        self.setWindowTitle(f"{interval.identifier} 高级网格选项 · {interval.display_position} µm")
        root = QVBoxLayout(self)
        note = QLabel(
            "尺寸按半径方向的实际间距计算；表中 d 为直径。材料圆环边界固定，环向尺寸由全局 XY 控制。"
            if radial else "在此 Z 区间内布种，材料高度边界固定，局部 Z 尺寸优先。", self
        )
        note.setWordWrap(True)
        root.addWidget(note)
        self.inherit_checkbox = QCheckBox("使用默认径向策略（弱约束）" if radial else "继承全局 Z sweep 策略", self)
        self.inherit_checkbox.setChecked(override is None)
        root.addWidget(self.inherit_checkbox)
        form = QFormLayout()
        root.addLayout(form)
        self.constraint_combo = QComboBox(self)
        self.constraint_combo.addItem("弱约束：允许调整步长", "soft")
        self.constraint_combo.addItem("强约束：固定 seed，余量收尾", "hard")
        self.constraint_combo.setCurrentIndex(self.constraint_combo.findData(policy.constraint))
        form.addRow("约束强度", self.constraint_combo)
        self.direction_combo = QComboBox(self)
        directions = (
            (("由内向外", "inner"), ("由外向内", "outer"), ("内外两端 → 中间", "both_r"))
            if radial else
            (("−Z 面 → +Z（从下往上）", "negative_z"), ("+Z 面 → −Z（从上往下）", "positive_z"), ("−Z / +Z 两面 → 中间", "both_z"))
        )
        for label, value in directions:
            self.direction_combo.addItem(label, value)
        self.direction_combo.setCurrentIndex(self.direction_combo.findData(policy.direction))
        form.addRow("Seed 方向", self.direction_combo)
        self.merge_spin = QDoubleSpinBox(self)
        self.center_spin = QDoubleSpinBox(self)
        for spin, value in ((self.merge_spin, policy.remainder_ratio), (self.center_spin, policy.center_merge_ratio)):
            spin.setDecimals(3)
            spin.setRange(.001, 1.)
            spin.setSingleStep(.05)
            spin.setValue(value)
        self.center_spin.setMinimum(self.merge_spin.value())
        self.merge_spin.valueChanged.connect(self.center_spin.setMinimum)
        form.addRow("Merge 边界比例", self.merge_spin)
        form.addRow("中心合并比例", self.center_spin)
        help_text = QLabel(
            "比例 = 剩余单元尺寸 / 当前 seed 尺寸。\n"
            "单向：低于 Merge 边界比例，合并到前一单元。\n"
            "双向：低于 Merge 边界比例，各自合并到本侧前一单元；"
            "否则不超过中心合并比例时合成一个中心单元，超过时保留两个。\n"
            "没有前一单元时保留区间边界。默认比例为 0.25 / 0.5。", self
        )
        help_text.setWordWrap(True)
        root.addWidget(help_text)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, self)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)
        self.inherit_checkbox.toggled.connect(self._update_fields)
        self.constraint_combo.currentIndexChanged.connect(self._update_fields)
        self.direction_combo.currentIndexChanged.connect(self._update_fields)
        self._update_fields()
        self.resize(480, self.sizeHint().height())

    def _update_fields(self, *_args):
        custom = not self.inherit_checkbox.isChecked()
        hard = custom and self.constraint_combo.currentData() == "hard"
        self.constraint_combo.setEnabled(custom)
        self.direction_combo.setEnabled(hard)
        self.merge_spin.setEnabled(hard)
        self.center_spin.setEnabled(hard and self.direction_combo.currentData() in {"both_z", "both_r"})

    def policy(self):
        if self.inherit_checkbox.isChecked():
            return None
        return self.policy_type(self.constraint_combo.currentData(), self.direction_combo.currentData(),
                                self.merge_spin.value(), self.center_spin.value())
