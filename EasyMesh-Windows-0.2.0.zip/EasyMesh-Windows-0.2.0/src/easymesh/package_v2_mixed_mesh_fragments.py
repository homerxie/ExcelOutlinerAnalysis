"""Role-free DTO adapters for final mixed-volume assembly.

The adapters in this module only translate public mesh records.  Component
keys, material names, element provenance and node semantic tokens are supplied
by the caller; no geometry role or material string selects an implementation.
Element connectivity is copied in its original order.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import replace
from collections.abc import Mapping, Sequence
import math
from types import MappingProxyType
from typing import TypeAlias

from .gmsh_closed_shell_remainder import GmshClosedShellRemainder
from .package_v2_compile import CanonicalFrozenPlacement
from .package_v2_instance_transform import placed_connectivity
from .package_v2_frozen import FrozenSourceSnapshot
from .package_v2_mixed_mesh_assembly import (
    ComponentLocalMeshFragment,
    ComponentMeshElement,
    ComponentMeshNode,
    DeclaredSharedSeam,
    FragmentFaceReference,
)
from .package_v2_orthogonal_fillet import (
    OrthogonalFilletMesh,
    OrthogonalMultiblockFilletMesh,
)
from .volume_mesh import ELEMENT_SPECS, MeshNode, VolumeMesh


Point3D: TypeAlias = tuple[float, float, float]

ORTHOGONAL_HEX_CONTINUATION_PROVENANCE = (
    "gmsh_locked_orth_quad_hex_continuation"
)
CONFORMAL_HYBRID_TRANSITION_PROVENANCE = (
    "gmsh_conformal_hybrid_locked_base_quadtri_tet_remainder"
)


class MixedMeshFragmentError(ValueError):
    """A public mesh DTO cannot be translated without inventing identity."""


def _canonical_text(value: object, *, field_name: str) -> str:
    if (
        not isinstance(value, str)
        or not value
        or value != value.strip()
        or any(ord(character) < 32 for character in value)
    ):
        raise MixedMeshFragmentError(f"{field_name} must be a canonical string")
    return value


def _positive_tolerance(value: object) -> float:
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(float(value))
        or float(value) <= 0.0
    ):
        raise MixedMeshFragmentError("coordinate_tolerance_mm must be positive")
    return float(value)


def _semantic_tokens(
    value: Mapping[int, str] | None,
    *,
    node_ids: set[int],
) -> Mapping[int, str]:
    if value is None:
        return MappingProxyType({})
    if not isinstance(value, Mapping):
        raise MixedMeshFragmentError(
            "semantic_tokens_by_node_id must be a mapping"
        )
    tokens: dict[int, str] = {}
    for raw_node, raw_token in value.items():
        if (
            isinstance(raw_node, bool)
            or not isinstance(raw_node, int)
            or raw_node < 1
            or raw_node not in node_ids
        ):
            raise MixedMeshFragmentError(
                "semantic token mapping references an unknown node"
            )
        tokens[raw_node] = _canonical_text(
            raw_token, field_name="node semantic token"
        )
    if len(set(tokens.values())) != len(tokens):
        raise MixedMeshFragmentError(
            "one fragment cannot assign one semantic token to multiple nodes"
        )
    return MappingProxyType(dict(sorted(tokens.items())))


def _build_fragment(
    *,
    fragment_key: str,
    component_key: str,
    material_name: str,
    provenance: str,
    provenance_by_element_id: Mapping[int, str] | None,
    node_rows: Sequence[tuple[int, Point3D]],
    element_rows: Sequence[tuple[int, int, tuple[int, ...]]],
    semantic_tokens_by_node_id: Mapping[int, str] | None,
) -> ComponentLocalMeshFragment:
    resolved_nodes = tuple(node_rows)
    resolved_elements = tuple(element_rows)
    node_ids = {row[0] for row in resolved_nodes}
    if len(node_ids) != len(resolved_nodes):
        raise MixedMeshFragmentError("source DTO repeats a node ID")
    tokens = _semantic_tokens(
        semantic_tokens_by_node_id,
        node_ids=node_ids,
    )
    if provenance_by_element_id is None:
        element_provenance = MappingProxyType({})
    else:
        if not isinstance(provenance_by_element_id, Mapping):
            raise MixedMeshFragmentError(
                "provenance_by_element_id must be a mapping"
            )
        known_element_ids = {row[0] for row in resolved_elements}
        element_provenance = MappingProxyType(
            {
                element_id: _canonical_text(
                    value,
                    field_name="element provenance override",
                )
                for element_id, value in provenance_by_element_id.items()
                if element_id in known_element_ids
            }
        )
        if set(provenance_by_element_id) != set(element_provenance):
            raise MixedMeshFragmentError(
                "element provenance override references an unknown element"
            )
    try:
        return ComponentLocalMeshFragment(
            fragment_key,
            component_key,
            material_name,
            tuple(
                ComponentMeshNode(node_id, coordinates, tokens.get(node_id))
                for node_id, coordinates in resolved_nodes
            ),
            tuple(
                ComponentMeshElement(
                    element_id,
                    gmsh_type,
                    node_ids_in_original_order,
                    element_provenance.get(element_id, provenance),
                )
                for element_id, gmsh_type, node_ids_in_original_order in resolved_elements
            ),
        )
    except (TypeError, ValueError) as error:
        if isinstance(error, MixedMeshFragmentError):
            raise
        raise MixedMeshFragmentError(
            f"source DTO cannot form a component-local fragment: {error}"
        ) from error


def fragment_from_closed_shell_remainder(
    remainder: GmshClosedShellRemainder,
    *,
    fragment_key: str,
    component_key: str,
    material_name: str,
    provenance: str,
    provenance_by_element_id: Mapping[int, str] | None = None,
    semantic_tokens_by_node_id: Mapping[int, str] | None = None,
) -> ComponentLocalMeshFragment:
    """Translate a Gmsh-owned remainder without reordering connectivity."""

    if not isinstance(remainder, GmshClosedShellRemainder):
        raise MixedMeshFragmentError(
            "remainder must be a GmshClosedShellRemainder"
        )
    return _build_fragment(
        fragment_key=fragment_key,
        component_key=component_key,
        material_name=material_name,
        provenance=provenance,
        provenance_by_element_id=provenance_by_element_id,
        node_rows=tuple(sorted(remainder.node_coordinates.items())),
        element_rows=tuple(
            (index, element.gmsh_type, tuple(element.node_ids))
            for index, element in enumerate(remainder.elements, start=1)
        ),
        semantic_tokens_by_node_id=semantic_tokens_by_node_id,
    )


def fragment_from_orthogonal_fillet_mesh(
    mesh: OrthogonalFilletMesh | OrthogonalMultiblockFilletMesh,
    *,
    fragment_key: str,
    component_key: str,
    material_name: str,
    provenance: str,
    semantic_tokens_by_node_id: Mapping[int, str] | None = None,
) -> ComponentLocalMeshFragment:
    """Translate package-frame orthogonal HEX records unchanged."""

    if type(mesh) not in {
        OrthogonalFilletMesh,
        OrthogonalMultiblockFilletMesh,
    }:
        raise MixedMeshFragmentError(
            "mesh must be an orthogonal fillet mesh DTO"
        )
    fragment = _build_fragment(
        fragment_key=fragment_key,
        component_key=component_key,
        material_name=material_name,
        provenance=provenance,
        provenance_by_element_id=None,
        node_rows=tuple(
            (node.node_index, tuple(node.package_coordinates_mm))
            for node in mesh.nodes
        ),
        element_rows=tuple(
            (
                element.element_index,
                element.gmsh_type,
                tuple(element.node_indices),
            )
            for element in mesh.elements
        ),
        semantic_tokens_by_node_id=semantic_tokens_by_node_id,
    )

    warning_ids = {i for warning in mesh.audit.mesh_warnings for i in warning.get("element_ids", ())}
    return replace(fragment, elements=tuple(
        replace(element, element_set_names=("ORTH_MESH_WARNINGS",))
        if element.local_element_id in warning_ids else element
        for element in fragment.elements
    ))


def _explicit_boundary_facets(
    fragment: ComponentLocalMeshFragment,
    facets: Sequence[Sequence[int]],
    *,
    side_name: str,
) -> tuple[FragmentFaceReference, ...]:
    if isinstance(facets, (str, bytes)):
        raise MixedMeshFragmentError(f"{side_name} facets must be a sequence")
    try:
        raw_facets = tuple(facets)
    except TypeError as error:
        raise MixedMeshFragmentError(
            f"{side_name} facets must be a sequence"
        ) from error
    face_owner_counts: Counter[tuple[int, ...]] = Counter()
    for element in fragment.elements:
        for local_face in ELEMENT_SPECS[element.gmsh_type][2]:
            face_owner_counts[
                tuple(sorted(element.node_ids[index] for index in local_face))
            ] += 1
    result: list[FragmentFaceReference] = []
    seen: set[tuple[int, ...]] = set()
    for raw_facet in raw_facets:
        try:
            reference = FragmentFaceReference(
                fragment.fragment_key,
                tuple(raw_facet),
            )
        except (TypeError, ValueError) as error:
            raise MixedMeshFragmentError(
                f"{side_name} contains an invalid TRI/QUAD facet"
            ) from error
        key = tuple(sorted(reference.node_ids))
        if key in seen:
            raise MixedMeshFragmentError(
                f"{side_name} contains a duplicate facet"
            )
        seen.add(key)
        if face_owner_counts[key] != 1:
            raise MixedMeshFragmentError(
                f"{side_name} facet must be one explicit boundary element face"
            )
        result.append(reference)
    if not result:
        raise MixedMeshFragmentError("shared facet declarations cannot be empty")
    return tuple(result)


def declared_shared_seams_from_facets(
    first_fragment: ComponentLocalMeshFragment,
    first_facets: Sequence[Sequence[int]],
    second_fragment: ComponentLocalMeshFragment,
    second_facets: Sequence[Sequence[int]],
    *,
    seam_key_prefix: str,
    sizing_contract_id: str | None = None,
    target_edge_mm: float | None = None,
    coordinate_tolerance_mm: float = 1.0e-10,
) -> tuple[DeclaredSharedSeam, ...]:
    """Match two explicit facet sets by semantic token and coordinate.

    Every facet and node must participate in one complete bijection.  The
    returned seam declarations preserve the caller's facet cycles.
    """

    if (
        not isinstance(first_fragment, ComponentLocalMeshFragment)
        or not isinstance(second_fragment, ComponentLocalMeshFragment)
        or first_fragment.fragment_key == second_fragment.fragment_key
    ):
        raise MixedMeshFragmentError(
            "shared facets require two distinct component-local fragments"
        )
    prefix = _canonical_text(seam_key_prefix, field_name="seam_key_prefix")
    tolerance = _positive_tolerance(coordinate_tolerance_mm)
    first = _explicit_boundary_facets(
        first_fragment, first_facets, side_name="first"
    )
    second = _explicit_boundary_facets(
        second_fragment, second_facets, side_name="second"
    )
    if len(first) != len(second):
        raise MixedMeshFragmentError(
            "shared facet collections must have the same cardinality"
        )
    if Counter(len(face.node_ids) for face in first) != Counter(
        len(face.node_ids) for face in second
    ):
        raise MixedMeshFragmentError(
            "shared facet collections must pair TRI3 with TRI3 and QUAD4 with QUAD4"
        )

    first_nodes = {node.local_node_id: node for node in first_fragment.nodes}
    second_nodes = {node.local_node_id: node for node in second_fragment.nodes}
    second_node_by_token = {
        node.semantic_token: node
        for node in second_fragment.nodes
        if node.semantic_token is not None
    }

    def token_signature(
        face: FragmentFaceReference,
        nodes: Mapping[int, ComponentMeshNode],
        *,
        side_name: str,
    ) -> frozenset[str]:
        tokens = tuple(nodes[node_id].semantic_token for node_id in face.node_ids)
        if any(token is None for token in tokens):
            raise MixedMeshFragmentError(
                f"{side_name} shared facet node lacks a semantic token"
            )
        return frozenset(token for token in tokens if token is not None)

    second_by_signature: dict[
        frozenset[str], FragmentFaceReference
    ] = {}
    for face in second:
        signature = token_signature(face, second_nodes, side_name="second")
        if signature in second_by_signature:
            raise MixedMeshFragmentError(
                "second shared facets do not have unique semantic signatures"
            )
        second_by_signature[signature] = face

    matched: list[
        tuple[frozenset[str], FragmentFaceReference, FragmentFaceReference]
    ] = []
    used_second: set[tuple[int, ...]] = set()
    for first_face in first:
        signature = token_signature(first_face, first_nodes, side_name="first")
        second_face = second_by_signature.get(signature)
        if second_face is None:
            raise MixedMeshFragmentError(
                "shared facet semantic tokens do not form a complete bijection"
            )
        if len(first_face.node_ids) != len(second_face.node_ids):
            raise MixedMeshFragmentError(
                "matched shared facets must both be TRI3 or both be QUAD4"
            )
        for first_node_id in first_face.node_ids:
            first_node = first_nodes[first_node_id]
            token = first_node.semantic_token
            if token is None or token not in second_node_by_token:
                raise MixedMeshFragmentError(
                    "shared node semantic token is missing on the opposite fragment"
                )
            second_node = second_node_by_token[token]
            if math.dist(
                first_node.coordinates_mm,
                second_node.coordinates_mm,
            ) > tolerance:
                raise MixedMeshFragmentError(
                    "shared node semantic token resolves to inconsistent coordinates"
                )
            if second_node.local_node_id not in second_face.node_ids:
                raise MixedMeshFragmentError(
                    "shared facet semantic tokens are not a node-level bijection"
                )
        second_key = tuple(sorted(second_face.node_ids))
        if second_key in used_second:
            raise MixedMeshFragmentError(
                "one second facet cannot satisfy multiple first facets"
            )
        used_second.add(second_key)
        matched.append((signature, first_face, second_face))
    if len(used_second) != len(second):
        raise MixedMeshFragmentError(
            "shared facet semantic tokens do not form a complete bijection"
        )

    matched.sort(key=lambda value: (len(value[0]), tuple(sorted(value[0]))))
    return tuple(
        DeclaredSharedSeam(
            f"{prefix}:{index:06d}",
            (first_face, second_face),
            sizing_contract_id,
            target_edge_mm,
        )
        for index, (_signature, first_face, second_face) in enumerate(
            matched, start=1
        )
    )


def placed_frozen_volume_mesh(snapshot: FrozenSourceSnapshot) -> VolumeMesh:
    """Apply one snapshot's orthogonal placement exactly once.

    Mirrors also permute reference-cell ordering to retain positive Jacobians.
    Node/element membership, tags, entities and Physical Groups are preserved;
    the original artifact is unchanged.
    """

    if type(snapshot) is not FrozenSourceSnapshot:
        raise MixedMeshFragmentError(
            "snapshot must be an exact FrozenSourceSnapshot"
        )
    if type(snapshot.mesh) is not VolumeMesh:
        raise MixedMeshFragmentError("snapshot mesh must be an exact VolumeMesh")
    placement = snapshot.placement
    if type(placement) is not CanonicalFrozenPlacement:
        raise MixedMeshFragmentError(
            "snapshot placement must be an exact CanonicalFrozenPlacement"
        )
    try:
        replayed = CanonicalFrozenPlacement(
            placement.translation_xyz_mm,
            placement.rotation_matrix,
        )
    except (TypeError, ValueError) as error:
        raise MixedMeshFragmentError("snapshot placement is invalid") from error
    if replayed != placement:
        raise MixedMeshFragmentError("snapshot placement is non-canonical")

    translation = placement.translation_xyz_mm
    rotation = placement.rotation_matrix
    transformed_nodes = tuple(
        MeshNode(
            node.tag,
            *tuple(
                0.0
                if (coordinate := (
                    sum(
                        rotation[axis][source_axis]
                        * node.coordinates[source_axis]
                        for source_axis in range(3)
                    )
                    + translation[axis]
                )) == 0.0
                else coordinate
                for axis in range(3)
            ),
        )
        for node in snapshot.mesh.nodes
    )
    if any(
        not math.isfinite(coordinate)
        for node in transformed_nodes
        for coordinate in node.coordinates
    ):
        raise MixedMeshFragmentError(
            "Frozen placement produced a non-finite coordinate"
        )
    return VolumeMesh(
        snapshot.mesh.source_path,
        transformed_nodes,
        tuple(replace(element, node_tags=placed_connectivity(element.gmsh_type, element.node_tags, rotation))
              for element in snapshot.mesh.elements),
        snapshot.mesh.entity_physical_groups,
        snapshot.mesh.dimensional_element_counts,
        snapshot.mesh.min_jacobian_determinant,
    )


__all__ = [
    "CONFORMAL_HYBRID_TRANSITION_PROVENANCE",
    "MixedMeshFragmentError",
    "ORTHOGONAL_HEX_CONTINUATION_PROVENANCE",
    "declared_shared_seams_from_facets",
    "fragment_from_closed_shell_remainder",
    "fragment_from_orthogonal_fillet_mesh",
    "placed_frozen_volume_mesh",
]
