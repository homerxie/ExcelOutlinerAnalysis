"""Generate the conformal XY transition mesh around placed bump templates.

Each template is a straight extrusion with its own native outer ring. Its only
internal interface with the surrounding layout is therefore the side wall. Meshing
the rectangle-with-holes in two dimensions and extruding it on the template's
unchanged Z levels is both more robust and more faithful to the layer geometry
than running an unconstrained three-dimensional smoother near the bump.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Iterable, Sequence

from .gmsh_runtime import isolated_gmsh_model


_COORDINATE_TOLERANCE_MM = 1.0e-10


def _positive(value: object, *, field_name: str) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{field_name} must be a positive finite number") from error
    if not math.isfinite(parsed) or parsed <= 0.0:
        raise ValueError(f"{field_name} must be a positive finite number")
    return parsed


def _signed_twice_area(
    points: tuple[tuple[float, float], ...],
    connectivity: tuple[int, int, int],
) -> float:
    (ax, ay), (bx, by), (cx, cy) = (points[index] for index in connectivity)
    return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)


def _signed_polygon_area(
    points: Sequence[tuple[float, float]],
    connectivity: Sequence[int],
) -> float:
    return 0.5 * sum(
        points[connectivity[index]][0]
        * points[connectivity[(index + 1) % len(connectivity)]][1]
        - points[connectivity[(index + 1) % len(connectivity)]][0]
        * points[connectivity[index]][1]
        for index in range(len(connectivity))
    )


@dataclass(frozen=True, slots=True)
class _StructuredRegion:
    x_min_mm: float
    x_max_mm: float
    y_min_mm: float
    y_max_mm: float
    size_x_mm: float
    size_y_mm: float
    x_cell_count: int
    y_cell_count: int


def _region_value(region: object, name: str) -> float:
    try:
        value = float(getattr(region, name))
    except (AttributeError, TypeError, ValueError) as error:
        raise ValueError(
            "structured regions must expose finite x_min_mm, x_max_mm, "
            "y_min_mm, y_max_mm, size_x_mm, and size_y_mm values"
        ) from error
    if not math.isfinite(value):
        raise ValueError(f"structured region {name} must be finite")
    return value


def _region_size_value(region: object, axis: str) -> float:
    directional_name = f"size_{axis}_mm"
    if hasattr(region, directional_name):
        return _region_value(region, directional_name)
    # Isotropic parser models may expose one shared size while retaining the
    # same structural interface for bounds.
    if hasattr(region, "size_mm"):
        return _region_value(region, "size_mm")
    raise ValueError(
        "structured regions must expose size_x_mm and size_y_mm, or one "
        "isotropic size_mm value"
    )


def _resolve_structured_regions(
    regions: Iterable[object],
    *,
    x_min: float,
    x_max: float,
    y_min: float,
    y_max: float,
) -> tuple[_StructuredRegion, ...]:
    resolved: list[_StructuredRegion] = []
    for index, region in enumerate(regions):
        region_x_min = _region_value(region, "x_min_mm")
        region_x_max = _region_value(region, "x_max_mm")
        region_y_min = _region_value(region, "y_min_mm")
        region_y_max = _region_value(region, "y_max_mm")
        size_x = _positive(
            _region_size_value(region, "x"),
            field_name=f"structured region {index} x size",
        )
        size_y = _positive(
            _region_size_value(region, "y"),
            field_name=f"structured region {index} y size",
        )
        width = region_x_max - region_x_min
        height = region_y_max - region_y_min
        if width <= 0.0 or height <= 0.0:
            raise ValueError(f"structured region {index} must have positive area")
        if (
            region_x_min < x_min - _COORDINATE_TOLERANCE_MM
            or region_x_max > x_max + _COORDINATE_TOLERANCE_MM
            or region_y_min < y_min - _COORDINATE_TOLERANCE_MM
            or region_y_max > y_max + _COORDINATE_TOLERANCE_MM
        ):
            raise ValueError(f"structured region {index} lies outside layout bounds")
        x_count = round(width / size_x)
        y_count = round(height / size_y)
        if x_count < 1 or not math.isclose(
            width,
            x_count * size_x,
            rel_tol=1.0e-10,
            abs_tol=_COORDINATE_TOLERANCE_MM,
        ):
            raise ValueError(
                f"structured region {index} width is not an integer multiple "
                "of its x size"
            )
        if y_count < 1 or not math.isclose(
            height,
            y_count * size_y,
            rel_tol=1.0e-10,
            abs_tol=_COORDINATE_TOLERANCE_MM,
        ):
            raise ValueError(
                f"structured region {index} height is not an integer multiple "
                "of its y size"
            )
        resolved.append(
            _StructuredRegion(
                region_x_min,
                region_x_max,
                region_y_min,
                region_y_max,
                size_x,
                size_y,
                x_count,
                y_count,
            )
        )

    for first_index, first in enumerate(resolved):
        for second_index, second in enumerate(
            resolved[first_index + 1 :], first_index + 1
        ):
            overlap_x = min(first.x_max_mm, second.x_max_mm) - max(
                first.x_min_mm, second.x_min_mm
            )
            overlap_y = min(first.y_max_mm, second.y_max_mm) - max(
                first.y_min_mm, second.y_min_mm
            )
            if (
                overlap_x >= -_COORDINATE_TOLERANCE_MM
                and overlap_y >= -_COORDINATE_TOLERANCE_MM
            ):
                raise ValueError(
                    f"structured regions {first_index} and {second_index} "
                    "touch or overlap"
                )
    return tuple(resolved)


def _orientation(
    first: tuple[float, float],
    second: tuple[float, float],
    third: tuple[float, float],
) -> float:
    return (
        (second[0] - first[0]) * (third[1] - first[1])
        - (second[1] - first[1]) * (third[0] - first[0])
    )


def _point_on_segment(
    point: tuple[float, float],
    first: tuple[float, float],
    second: tuple[float, float],
) -> bool:
    return (
        abs(_orientation(first, second, point)) <= _COORDINATE_TOLERANCE_MM**2
        and min(first[0], second[0]) - _COORDINATE_TOLERANCE_MM
        <= point[0]
        <= max(first[0], second[0]) + _COORDINATE_TOLERANCE_MM
        and min(first[1], second[1]) - _COORDINATE_TOLERANCE_MM
        <= point[1]
        <= max(first[1], second[1]) + _COORDINATE_TOLERANCE_MM
    )


def _segments_intersect_or_touch(
    first_start: tuple[float, float],
    first_end: tuple[float, float],
    second_start: tuple[float, float],
    second_end: tuple[float, float],
) -> bool:
    orientations = (
        _orientation(first_start, first_end, second_start),
        _orientation(first_start, first_end, second_end),
        _orientation(second_start, second_end, first_start),
        _orientation(second_start, second_end, first_end),
    )
    tolerance = _COORDINATE_TOLERANCE_MM**2
    if (
        orientations[0] * orientations[1] < -tolerance
        and orientations[2] * orientations[3] < -tolerance
    ):
        return True
    return any(
        abs(orientation) <= tolerance and _point_on_segment(point, start, end)
        for orientation, point, start, end in (
            (orientations[0], second_start, first_start, first_end),
            (orientations[1], second_end, first_start, first_end),
            (orientations[2], first_start, second_start, second_end),
            (orientations[3], first_end, second_start, second_end),
        )
    )


def _point_in_or_on_polygon(
    point: tuple[float, float],
    polygon: Sequence[tuple[float, float]],
) -> bool:
    inside = False
    for index, first in enumerate(polygon):
        second = polygon[(index + 1) % len(polygon)]
        if _point_on_segment(point, first, second):
            return True
        if (first[1] > point[1]) != (second[1] > point[1]):
            crossing_x = first[0] + (point[1] - first[1]) * (
                second[0] - first[0]
            ) / (second[1] - first[1])
            if crossing_x >= point[0] - _COORDINATE_TOLERANCE_MM:
                inside = not inside
    return inside


def _validate_regions_do_not_touch_rings(
    regions: Sequence[_StructuredRegion],
    rings: Sequence["TransitionRing"],
) -> None:
    """Reject structured patches that would overwrite an immutable bump hole."""

    for region_index, region in enumerate(regions):
        rectangle = (
            (region.x_min_mm, region.y_min_mm),
            (region.x_max_mm, region.y_min_mm),
            (region.x_max_mm, region.y_max_mm),
            (region.x_min_mm, region.y_max_mm),
        )
        for ring in rings:
            polygon = ring.coordinates_mm
            intersects = any(
                _segments_intersect_or_touch(
                    rectangle[rectangle_index],
                    rectangle[(rectangle_index + 1) % 4],
                    polygon[ring_index],
                    polygon[(ring_index + 1) % len(polygon)],
                )
                for rectangle_index in range(4)
                for ring_index in range(len(polygon))
            )
            contains = any(
                _point_in_or_on_polygon(point, polygon) for point in rectangle
            ) or any(
                region.x_min_mm - _COORDINATE_TOLERANCE_MM
                <= x
                <= region.x_max_mm + _COORDINATE_TOLERANCE_MM
                and region.y_min_mm - _COORDINATE_TOLERANCE_MM
                <= y
                <= region.y_max_mm + _COORDINATE_TOLERANCE_MM
                for x, y in polygon
            )
            if intersects or contains:
                raise ValueError(
                    f"structured region {region_index} touches or overlaps bump "
                    f"ring {ring.placement_index}"
                )


@dataclass(frozen=True, slots=True)
class TransitionRing:
    """One immutable, counter-clockwise polygonal bump-side interface."""

    placement_index: int
    coordinates_mm: tuple[tuple[float, float], ...]
    target_size_mm: float

    def __post_init__(self) -> None:
        if isinstance(self.placement_index, bool) or self.placement_index < 0:
            raise ValueError("placement_index must be a non-negative integer")
        coordinates = tuple(
            (float(point[0]), float(point[1])) for point in self.coordinates_mm
        )
        if len(coordinates) < 8:
            raise ValueError("a transition ring must contain at least 8 points")
        if any(
            not math.isfinite(value)
            for point in coordinates
            for value in point
        ):
            raise ValueError("transition-ring coordinates must be finite")
        if len({(round(x, 13), round(y, 13)) for x, y in coordinates}) != len(
            coordinates
        ):
            raise ValueError("a transition ring must not repeat a point")
        twice_area = sum(
            coordinates[index][0] * coordinates[(index + 1) % len(coordinates)][1]
            - coordinates[(index + 1) % len(coordinates)][0]
            * coordinates[index][1]
            for index in range(len(coordinates))
        )
        if twice_area <= 0.0:
            raise ValueError("transition-ring coordinates must be counter-clockwise")
        object.__setattr__(self, "coordinates_mm", coordinates)
        object.__setattr__(
            self,
            "target_size_mm",
            _positive(self.target_size_mm, field_name="ring target size"),
        )


@dataclass(frozen=True, slots=True)
class PlanarTransitionMesh:
    """Pure data extracted from the temporary Gmsh two-dimensional model."""

    coordinates_mm: tuple[tuple[float, float], ...]
    triangles: tuple[tuple[int, int, int], ...]
    quads: tuple[tuple[int, int, int, int], ...]
    ring_node_indices: tuple[tuple[int, ...], ...]
    quad_region_indices: tuple[tuple[int, ...], ...]
    triangle_sicn: tuple[float, ...]
    triangle_sige: tuple[float, ...]
    quad_sicn: tuple[float, ...]
    quad_sige: tuple[float, ...]
    minimum_sicn: float
    minimum_sige: float
    minimum_edge_mm: float
    maximum_edge_mm: float
    area_mm2: float

    @property
    def node_count(self) -> int:
        return len(self.coordinates_mm)

    @property
    def triangle_count(self) -> int:
        return len(self.triangles)

    @property
    def quad_count(self) -> int:
        return len(self.quads)

    @property
    def structured_region_count(self) -> int:
        return len(self.quad_region_indices)


def _load_gmsh() -> Any:
    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:
        raise RuntimeError("Gmsh is required to generate the transition mesh") from error
    return gmsh


def _edge_statistics(
    coordinates: tuple[tuple[float, float], ...],
    triangles: tuple[tuple[int, int, int], ...],
    quads: tuple[tuple[int, int, int, int], ...] = (),
) -> tuple[float, float]:
    edges: set[tuple[int, int]] = set()
    for cell in (*triangles, *quads):
        for index, first in enumerate(cell):
            second = cell[(index + 1) % len(cell)]
            edges.add((first, second) if first < second else (second, first))
    lengths = [
        math.hypot(
            coordinates[first][0] - coordinates[second][0],
            coordinates[first][1] - coordinates[second][1],
        )
        for first, second in edges
    ]
    return min(lengths), max(lengths)


@dataclass(frozen=True, slots=True)
class _GeometryEntities:
    exterior_surfaces: tuple[int, ...]
    region_surfaces: tuple[int, ...]
    ring_point_tags: tuple[tuple[int, ...], ...]
    ring_curve_tags: tuple[tuple[int, ...], ...]
    region_curve_tags: tuple[tuple[int, ...], ...]


def _build_geo_geometry(
    gmsh: Any,
    *,
    x_min: float,
    x_max: float,
    y_min: float,
    y_max: float,
    far_size: float,
    rings: tuple[TransitionRing, ...],
) -> _GeometryEntities:
    outer_points = (
        gmsh.model.geo.addPoint(x_min, y_min, 0.0, far_size),
        gmsh.model.geo.addPoint(x_max, y_min, 0.0, far_size),
        gmsh.model.geo.addPoint(x_max, y_max, 0.0, far_size),
        gmsh.model.geo.addPoint(x_min, y_max, 0.0, far_size),
    )
    outer_curves = tuple(
        gmsh.model.geo.addLine(
            outer_points[index], outer_points[(index + 1) % 4]
        )
        for index in range(4)
    )
    outer_loop = gmsh.model.geo.addCurveLoop(list(outer_curves))

    ring_point_tags: list[tuple[int, ...]] = []
    ring_curve_tags: list[tuple[int, ...]] = []
    hole_loops: list[int] = []
    for ring in rings:
        point_tags = tuple(
            gmsh.model.geo.addPoint(x, y, 0.0, ring.target_size_mm)
            for x, y in ring.coordinates_mm
        )
        curve_tags = tuple(
            gmsh.model.geo.addLine(
                point_tags[index], point_tags[(index + 1) % len(point_tags)]
            )
            for index in range(len(point_tags))
        )
        # The polygon coordinates are CCW; reverse them for an inner loop.
        hole_loops.append(
            gmsh.model.geo.addCurveLoop([-tag for tag in reversed(curve_tags)])
        )
        ring_point_tags.append(point_tags)
        ring_curve_tags.append(curve_tags)

    surface = gmsh.model.geo.addPlaneSurface([outer_loop, *hole_loops])
    gmsh.model.geo.synchronize()
    return _GeometryEntities(
        exterior_surfaces=(surface,),
        region_surfaces=(),
        ring_point_tags=tuple(ring_point_tags),
        ring_curve_tags=tuple(ring_curve_tags),
        region_curve_tags=(),
    )


def _build_occ_geometry(
    gmsh: Any,
    *,
    x_min: float,
    x_max: float,
    y_min: float,
    y_max: float,
    rings: tuple[TransitionRing, ...],
    regions: tuple[_StructuredRegion, ...],
) -> _GeometryEntities:
    """Partition exact structured patches from the exterior transition face."""

    occ = gmsh.model.occ
    outer_surface = occ.addRectangle(
        x_min, y_min, 0.0, x_max - x_min, y_max - y_min
    )
    input_region_surfaces = tuple(
        occ.addRectangle(
            region.x_min_mm,
            region.y_min_mm,
            0.0,
            region.x_max_mm - region.x_min_mm,
            region.y_max_mm - region.y_min_mm,
        )
        for region in regions
    )
    _fragmented, fragment_map = occ.fragment(
        [(2, outer_surface)],
        [(2, tag) for tag in input_region_surfaces],
    )
    if len(fragment_map) != len(regions) + 1:
        raise RuntimeError("Gmsh returned an incomplete structured-region fragment map")

    region_surfaces: list[int] = []
    for index, mapping in enumerate(fragment_map[1:]):
        mapped_surfaces = tuple(tag for dimension, tag in mapping if dimension == 2)
        if len(mapped_surfaces) != 1:
            raise RuntimeError(
                f"structured region {index} did not produce one exact Gmsh surface"
            )
        region_surfaces.append(mapped_surfaces[0])
    region_surface_set = set(region_surfaces)
    exterior_objects = tuple(
        (dimension, tag)
        for dimension, tag in fragment_map[0]
        if dimension == 2 and tag not in region_surface_set
    )
    if not exterior_objects:
        raise RuntimeError("structured regions consume the complete transition domain")

    ring_point_tags: list[tuple[int, ...]] = []
    ring_curve_tags: list[tuple[int, ...]] = []
    ring_faces: list[tuple[int, int]] = []
    for ring in rings:
        point_tags = tuple(
            occ.addPoint(x, y, 0.0) for x, y in ring.coordinates_mm
        )
        curve_tags = tuple(
            occ.addLine(
                point_tags[index], point_tags[(index + 1) % len(point_tags)]
            )
            for index in range(len(point_tags))
        )
        wire = occ.addWire(list(curve_tags), checkClosed=True)
        ring_faces.append((2, occ.addPlaneSurface([wire])))
        ring_point_tags.append(point_tags)
        ring_curve_tags.append(curve_tags)

    cut_surfaces, _cut_map = occ.cut(
        list(exterior_objects),
        ring_faces,
        removeObject=True,
        removeTool=True,
    )
    occ.synchronize()
    exterior_surfaces = tuple(
        tag for dimension, tag in cut_surfaces if dimension == 2
    )
    if not exterior_surfaces:
        raise RuntimeError("Gmsh did not preserve an exterior transition surface")

    region_curve_tags: list[tuple[int, ...]] = []
    for index, (region, surface_tag) in enumerate(zip(regions, region_surfaces)):
        curves = tuple(
            tag
            for dimension, tag in gmsh.model.getBoundary(
                [(2, surface_tag)], oriented=False, recursive=False
            )
            if dimension == 1
        )
        if len(curves) != 4:
            raise RuntimeError(
                f"structured region {index} is not an unfragmented four-sided surface"
            )
        horizontal_count = 0
        vertical_count = 0
        for curve_tag in curves:
            x0, y0, _z0, x1, y1, _z1 = gmsh.model.getBoundingBox(1, curve_tag)
            if (x1 - x0) > (y1 - y0):
                gmsh.model.mesh.setTransfiniteCurve(
                    curve_tag, region.x_cell_count + 1
                )
                horizontal_count += 1
            else:
                gmsh.model.mesh.setTransfiniteCurve(
                    curve_tag, region.y_cell_count + 1
                )
                vertical_count += 1
        if horizontal_count != 2 or vertical_count != 2:
            raise RuntimeError(
                f"structured region {index} does not have two x and two y edges"
            )
        gmsh.model.mesh.setTransfiniteSurface(surface_tag)
        gmsh.model.mesh.setRecombine(2, surface_tag)
        region_curve_tags.append(curves)

    return _GeometryEntities(
        exterior_surfaces=exterior_surfaces,
        region_surfaces=tuple(region_surfaces),
        ring_point_tags=tuple(ring_point_tags),
        ring_curve_tags=tuple(ring_curve_tags),
        region_curve_tags=tuple(region_curve_tags),
    )


def generate_planar_transition_mesh(
    bounds: object,
    rings: Iterable[TransitionRing],
    *,
    structured_regions: Iterable[object] = (),
    far_field_size_mm: float = 0.040,
    transition_distance_mm: float = 0.120,
    verbose: bool = False,
) -> PlanarTransitionMesh:
    """Mesh an XY rectangle with exact polygonal holes for all bump side walls.

    ``bounds`` intentionally uses structural typing and must expose
    ``x_min_mm``, ``x_max_mm``, ``y_min_mm`` and ``y_max_mm``.  Hole vertices
    become Gmsh point entities and every polygon edge is constrained to exactly
    one mesh edge, so the returned ring nodes reproduce the template skin
    without inserting, deleting or relocating an interface node.
    """

    ring_tuple = tuple(rings)
    if not ring_tuple:
        raise ValueError("at least one transition ring is required")
    if len({ring.placement_index for ring in ring_tuple}) != len(ring_tuple):
        raise ValueError("transition-ring placement indices must be unique")
    far_size = _positive(far_field_size_mm, field_name="far-field size")
    transition_distance = _positive(
        transition_distance_mm, field_name="transition distance"
    )
    x_min = float(getattr(bounds, "x_min_mm"))
    x_max = float(getattr(bounds, "x_max_mm"))
    y_min = float(getattr(bounds, "y_min_mm"))
    y_max = float(getattr(bounds, "y_max_mm"))
    if not all(math.isfinite(value) for value in (x_min, x_max, y_min, y_max)):
        raise ValueError("transition bounds must be finite")
    if x_max <= x_min or y_max <= y_min:
        raise ValueError("transition bounds must have positive area")
    region_tuple = _resolve_structured_regions(
        structured_regions,
        x_min=x_min,
        x_max=x_max,
        y_min=y_min,
        y_max=y_max,
    )
    _validate_regions_do_not_touch_rings(region_tuple, ring_tuple)
    minimum_target_size = min(
        [
            *(ring.target_size_mm for ring in ring_tuple),
            *(region.size_x_mm for region in region_tuple),
            *(region.size_y_mm for region in region_tuple),
        ]
    )

    gmsh = _load_gmsh()
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_layout_xy_transition",
        number_options={
            "General.Terminal": 1.0 if verbose else 0.0,
            "Mesh.ElementOrder": 1.0,
            "Mesh.Algorithm": 6.0,  # Frontal-Delaunay
            "Mesh.MeshSizeFromPoints": 0.0,
            "Mesh.MeshSizeFromCurvature": 0.0,
            "Mesh.MeshSizeExtendFromBoundary": 0.0,
            "Mesh.MeshSizeMin": minimum_target_size * 0.80,
            "Mesh.MeshSizeMax": far_size,
        },
    ):

        if region_tuple:
            geometry = _build_occ_geometry(
                gmsh,
                x_min=x_min,
                x_max=x_max,
                y_min=y_min,
                y_max=y_max,
                rings=ring_tuple,
                regions=region_tuple,
            )
        else:
            geometry = _build_geo_geometry(
                gmsh,
                x_min=x_min,
                x_max=x_max,
                y_min=y_min,
                y_max=y_max,
                far_size=far_size,
                rings=ring_tuple,
            )

        for curve_tags in geometry.ring_curve_tags:
            for curve_tag in curve_tags:
                gmsh.model.mesh.setTransfiniteCurve(curve_tag, 2)

        field_tags: list[int] = []
        for ring, curve_tags in zip(ring_tuple, geometry.ring_curve_tags):
            distance = gmsh.model.mesh.field.add("Distance")
            gmsh.model.mesh.field.setNumbers(distance, "CurvesList", list(curve_tags))
            gmsh.model.mesh.field.setNumber(distance, "Sampling", 5)
            threshold = gmsh.model.mesh.field.add("Threshold")
            gmsh.model.mesh.field.setNumber(threshold, "InField", distance)
            gmsh.model.mesh.field.setNumber(
                threshold, "SizeMin", ring.target_size_mm
            )
            gmsh.model.mesh.field.setNumber(threshold, "SizeMax", far_size)
            gmsh.model.mesh.field.setNumber(threshold, "DistMin", 0.0)
            gmsh.model.mesh.field.setNumber(
                threshold, "DistMax", transition_distance
            )
            field_tags.append(threshold)
        for region, curve_tags in zip(region_tuple, geometry.region_curve_tags):
            distance = gmsh.model.mesh.field.add("Distance")
            gmsh.model.mesh.field.setNumbers(distance, "CurvesList", list(curve_tags))
            gmsh.model.mesh.field.setNumber(distance, "Sampling", 20)
            threshold = gmsh.model.mesh.field.add("Threshold")
            gmsh.model.mesh.field.setNumber(threshold, "InField", distance)
            gmsh.model.mesh.field.setNumber(
                threshold,
                "SizeMin",
                min(region.size_x_mm, region.size_y_mm),
            )
            gmsh.model.mesh.field.setNumber(threshold, "SizeMax", far_size)
            gmsh.model.mesh.field.setNumber(threshold, "DistMin", 0.0)
            gmsh.model.mesh.field.setNumber(
                threshold, "DistMax", transition_distance
            )
            field_tags.append(threshold)
        constant = gmsh.model.mesh.field.add("MathEval")
        gmsh.model.mesh.field.setString(constant, "F", f"{far_size:.17g}")
        field_tags.append(constant)
        minimum = gmsh.model.mesh.field.add("Min")
        gmsh.model.mesh.field.setNumbers(minimum, "FieldsList", field_tags)
        gmsh.model.mesh.field.setAsBackgroundMesh(minimum)

        gmsh.model.mesh.generate(2)
        gmsh.model.mesh.optimize(
            "Relocate2D",
            False,
            5,
            [(2, surface) for surface in geometry.exterior_surfaces],
        )

        node_tags, raw_coordinates, _ = gmsh.model.mesh.getNodes()
        tag_to_index = {int(tag): index for index, tag in enumerate(node_tags)}
        coordinates = tuple(
            (float(raw_coordinates[3 * index]), float(raw_coordinates[3 * index + 1]))
            for index in range(len(node_tags))
        )

        triangles_raw: list[tuple[int, int, int]] = []
        triangle_tags: list[int] = []
        for exterior_surface in geometry.exterior_surfaces:
            element_types, element_tags, element_nodes = (
                gmsh.model.mesh.getElements(2, exterior_surface)
            )
            for element_type, tags, nodes in zip(
                element_types, element_tags, element_nodes
            ):
                name, dimension, order, node_count, _, _ = (
                    gmsh.model.mesh.getElementProperties(int(element_type))
                )
                if dimension != 2 or order != 1 or node_count != 3:
                    raise RuntimeError(
                        f"unexpected exterior transition element type: {name}"
                    )
                for offset, tag in enumerate(tags):
                    connectivity = tuple(
                        tag_to_index[int(value)]
                        for value in nodes[3 * offset : 3 * offset + 3]
                    )
                    if _signed_twice_area(coordinates, connectivity) < 0.0:
                        connectivity = (
                            connectivity[0], connectivity[2], connectivity[1]
                        )
                    if _signed_twice_area(coordinates, connectivity) <= 0.0:
                        raise RuntimeError(
                            "planar transition contains a degenerate triangle"
                        )
                    triangles_raw.append(connectivity)
                    triangle_tags.append(int(tag))
        triangles = tuple(triangles_raw)
        if not triangles:
            raise RuntimeError("Gmsh did not generate planar transition triangles")

        quads_raw: list[tuple[int, int, int, int]] = []
        quad_tags: list[int] = []
        quad_region_indices: list[tuple[int, ...]] = []
        for region_index, (region, surface_tag) in enumerate(
            zip(region_tuple, geometry.region_surfaces)
        ):
            region_quad_indices: list[int] = []
            element_types, element_tags, element_nodes = (
                gmsh.model.mesh.getElements(2, surface_tag)
            )
            for element_type, tags, nodes in zip(
                element_types, element_tags, element_nodes
            ):
                name, dimension, order, node_count, _, _ = (
                    gmsh.model.mesh.getElementProperties(int(element_type))
                )
                if dimension != 2 or order != 1 or node_count != 4:
                    raise RuntimeError(
                        f"unexpected structured-region element type: {name}"
                    )
                for offset, tag in enumerate(tags):
                    connectivity = tuple(
                        tag_to_index[int(value)]
                        for value in nodes[4 * offset : 4 * offset + 4]
                    )
                    if _signed_polygon_area(coordinates, connectivity) < 0.0:
                        connectivity = (
                            connectivity[0],
                            connectivity[3],
                            connectivity[2],
                            connectivity[1],
                        )
                    if _signed_polygon_area(coordinates, connectivity) <= 0.0:
                        raise RuntimeError(
                            "structured region contains a degenerate quadrilateral"
                        )
                    region_quad_indices.append(len(quads_raw))
                    quads_raw.append(connectivity)
                    quad_tags.append(int(tag))
            expected_count = region.x_cell_count * region.y_cell_count
            if len(region_quad_indices) != expected_count:
                raise RuntimeError(
                    f"structured region {region_index} generated "
                    f"{len(region_quad_indices)} quads instead of {expected_count}"
                )
            quad_region_indices.append(tuple(region_quad_indices))
        quads = tuple(quads_raw)
        for region_index, (region, indices) in enumerate(
            zip(region_tuple, quad_region_indices)
        ):
            region_node_indices: set[int] = set()
            for quad_index in indices:
                quad = quads[quad_index]
                region_node_indices.update(quad)
                horizontal_edges = 0
                vertical_edges = 0
                for local_index, first in enumerate(quad):
                    second = quad[(local_index + 1) % 4]
                    dx = abs(
                        coordinates[second][0] - coordinates[first][0]
                    )
                    dy = abs(
                        coordinates[second][1] - coordinates[first][1]
                    )
                    if dy <= _COORDINATE_TOLERANCE_MM and math.isclose(
                        dx,
                        region.size_x_mm,
                        rel_tol=1.0e-9,
                        abs_tol=_COORDINATE_TOLERANCE_MM,
                    ):
                        horizontal_edges += 1
                    elif dx <= _COORDINATE_TOLERANCE_MM and math.isclose(
                        dy,
                        region.size_y_mm,
                        rel_tol=1.0e-9,
                        abs_tol=_COORDINATE_TOLERANCE_MM,
                    ):
                        vertical_edges += 1
                    else:
                        raise RuntimeError(
                            f"structured region {region_index} did not preserve "
                            "its exact orthogonal x/y cell sizes"
                        )
                if horizontal_edges != 2 or vertical_edges != 2:
                    raise RuntimeError(
                        f"structured region {region_index} contains a non-rectangular quad"
                    )
                if not math.isclose(
                    _signed_polygon_area(coordinates, quad),
                    region.size_x_mm * region.size_y_mm,
                    rel_tol=1.0e-9,
                    abs_tol=_COORDINATE_TOLERANCE_MM**2,
                ):
                    raise RuntimeError(
                        f"structured region {region_index} quad area is not exact"
                    )
            region_coordinates = tuple(
                coordinates[index] for index in region_node_indices
            )
            actual_bounds = (
                min(x for x, _y in region_coordinates),
                max(x for x, _y in region_coordinates),
                min(y for _x, y in region_coordinates),
                max(y for _x, y in region_coordinates),
            )
            expected_bounds = (
                region.x_min_mm,
                region.x_max_mm,
                region.y_min_mm,
                region.y_max_mm,
            )
            if any(
                not math.isclose(
                    actual,
                    expected,
                    rel_tol=1.0e-10,
                    abs_tol=_COORDINATE_TOLERANCE_MM,
                )
                for actual, expected in zip(actual_bounds, expected_bounds)
            ):
                raise RuntimeError(
                    f"structured region {region_index} did not preserve its bounds"
                )

        ring_indices: list[tuple[int, ...]] = []
        for point_tags in geometry.ring_point_tags:
            indices: list[int] = []
            for point_tag in point_tags:
                point_nodes, _, _ = gmsh.model.mesh.getNodes(0, point_tag)
                if len(point_nodes) != 1:
                    raise RuntimeError("a constrained ring point has no unique mesh node")
                indices.append(tag_to_index[int(point_nodes[0])])
            ring_indices.append(tuple(indices))

        edge_counts: dict[tuple[int, int], int] = {}
        for cell in (*triangles, *quads):
            for local_index, first in enumerate(cell):
                second = cell[(local_index + 1) % len(cell)]
                key = (first, second) if first < second else (second, first)
                edge_counts[key] = edge_counts.get(key, 0) + 1
        if any(count not in (1, 2) for count in edge_counts.values()):
            raise RuntimeError("planar transition is not a mixed 2-manifold mesh")
        ring_edge_keys: set[tuple[int, int]] = set()
        for indices in ring_indices:
            for index, first in enumerate(indices):
                second = indices[(index + 1) % len(indices)]
                key = (first, second) if first < second else (second, first)
                ring_edge_keys.add(key)
                if edge_counts.get(key) != 1:
                    raise RuntimeError(
                        "a template-interface edge is not represented exactly once "
                        "on the transition boundary"
                    )
        for (first, second), count in edge_counts.items():
            if count != 1 or (first, second) in ring_edge_keys:
                continue
            first_xy = coordinates[first]
            second_xy = coordinates[second]
            on_outer_rectangle = any(
                abs(first_xy[axis] - bound) <= _COORDINATE_TOLERANCE_MM
                and abs(second_xy[axis] - bound) <= _COORDINATE_TOLERANCE_MM
                for axis, bounds_for_axis in (
                    (0, (x_min, x_max)),
                    (1, (y_min, y_max)),
                )
                for bound in bounds_for_axis
            )
            if not on_outer_rectangle:
                raise RuntimeError(
                    "planar transition contains an unexpected internal free edge"
                )

        triangle_sicn = tuple(
            float(value)
            for value in gmsh.model.mesh.getElementQualities(
                triangle_tags, "minSICN"
            )
        )
        triangle_sige = tuple(
            float(value)
            for value in gmsh.model.mesh.getElementQualities(
                triangle_tags, "minSIGE"
            )
        )
        quad_sicn = tuple(
            float(value)
            for value in gmsh.model.mesh.getElementQualities(
                quad_tags, "minSICN"
            )
        )
        quad_sige = tuple(
            float(value)
            for value in gmsh.model.mesh.getElementQualities(
                quad_tags, "minSIGE"
            )
        )
        minimum_edge, maximum_edge = _edge_statistics(
            coordinates, triangles, quads
        )
        triangle_area = 0.5 * sum(
            _signed_twice_area(coordinates, triangle) for triangle in triangles
        )
        quad_area = sum(
            _signed_polygon_area(coordinates, quad) for quad in quads
        )
        area = triangle_area + quad_area
        expected_area = (x_max - x_min) * (y_max - y_min) - sum(
            0.5
            * sum(
                ring.coordinates_mm[index][0]
                * ring.coordinates_mm[(index + 1) % len(ring.coordinates_mm)][1]
                - ring.coordinates_mm[(index + 1) % len(ring.coordinates_mm)][0]
                * ring.coordinates_mm[index][1]
                for index in range(len(ring.coordinates_mm))
            )
            for ring in ring_tuple
        )
        if not math.isclose(
            area,
            expected_area,
            rel_tol=1.0e-8,
            abs_tol=_COORDINATE_TOLERANCE_MM,
        ):
            raise RuntimeError(
                "planar transition area does not equal the rectangle minus bump holes"
            )

        return PlanarTransitionMesh(
            coordinates_mm=coordinates,
            triangles=triangles,
            quads=quads,
            ring_node_indices=tuple(ring_indices),
            quad_region_indices=tuple(quad_region_indices),
            triangle_sicn=triangle_sicn,
            triangle_sige=triangle_sige,
            quad_sicn=quad_sicn,
            quad_sige=quad_sige,
            minimum_sicn=min((*triangle_sicn, *quad_sicn)),
            minimum_sige=min((*triangle_sige, *quad_sige)),
            minimum_edge_mm=minimum_edge,
            maximum_edge_mm=maximum_edge,
            area_mm2=area,
        )


__all__ = [
    "PlanarTransitionMesh",
    "TransitionRing",
    "generate_planar_transition_mesh",
]
