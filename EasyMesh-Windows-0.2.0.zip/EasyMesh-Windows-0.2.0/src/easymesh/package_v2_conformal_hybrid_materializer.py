"""Geometry-driven materialization of one ``conformal_hybrid`` component.

The component boundary is generated first as one complete locked TRI/QUAD
shell.  That immutable shell is then passed to a Gmsh-owned volume backend;
EasyMesh never manufactures, splits, deletes, or repairs a three-dimensional
element. Hybrid prefers a TET interior that can coarsen away from interfaces;
HEX8, WEDGE6 and PYRAMID5 remain permitted transition families. A structured
volume is a last resort after the applicable TET routes fail their audits.

Geometry-side names are the only boundary selectors.  Locked coordinates are
expressed in the canonical fragment-local frame.  The returned
``ComponentLocalMeshFragment`` is expressed in package coordinates after the
fragment's one rigid placement has been applied.
"""

from __future__ import annotations

from collections import Counter
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
import math
from types import MappingProxyType
from typing import TypeAlias

from .component_interface import ComponentMeshRequirement
from .gmsh_closed_shell_remainder import (
    GmshClosedShellElement,
    GmshClosedShellRemainder,
    generate_closed_shell_conformal_remainder,
)
from .gmsh_rectangular_uf_structured_fill import (
    RectangularUfStructuredFill,
    RectangularUfStructuredFillError,
    generate_rectangular_uf_locked_quad_structured_fill,
)
from .gmsh_rectangular_uf_locked_base_quadtri_fill import (
    RectangularUfLockedBaseQuadTriFill,
    RectangularUfLockedBaseQuadTriFillError,
    generate_rectangular_uf_locked_base_quadtri_fill,
    rectangular_uf_locked_base_quadtri_ineligibility,
)
from .occ_box_frame_surface_shell import (
    GmshBoxFrameSurfaceShell,
    generate_box_frame_surface_shell,
)
from .occ_locked_hybrid import ConstrainedHybridError
from .package_v2_locked_box_tet import generate_box_tet
from .occ_uf_surface_shell import (
    GmshUfSurfaceShell,
    generate_rectangular_uf_surface_shell,
)
from .occ_uf_conformal import (
    GmshUfConformalVolume,
    generate_rectangular_uf_conformal_hybrid,
)
from .package_v2_geometry import (
    CanonicalBox,
    CanonicalGeometryFragment,
    CanonicalRectangularFrameExtrusion,
    CanonicalRectangularUnderfillFillet,
    CanonicalRigidPlacement,
)
from .package_v2_mixed_mesh_assembly import ComponentLocalMeshFragment
from .package_v2_mixed_mesh_fragments import (
    CONFORMAL_HYBRID_TRANSITION_PROVENANCE,
    ORTHOGONAL_HEX_CONTINUATION_PROVENANCE,
    fragment_from_closed_shell_remainder,
)
from .package_v2_mesh_settings import (
    DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM,
    validate_interface_geometry_tolerance_mm,
)
from .uf_skin import RectangularUfEnvelope


Point3D: TypeAlias = tuple[float, float, float]
SurfaceShell: TypeAlias = GmshBoxFrameSurfaceShell | GmshUfSurfaceShell

_MINIMUM_ACCEPTED_QUALITY = 0.03
_ELEMENT_KIND_ORDER = ("TET4", "HEX8", "WEDGE6", "PYRAMID5")


class ConformalHybridMaterializationError(ValueError):
    """One component cannot satisfy the explicit conformal contract."""


def _canonical_text(value: object, *, field_name: str) -> str:
    if (
        not isinstance(value, str)
        or not value
        or value != value.strip()
        or any(ord(character) < 32 for character in value)
    ):
        raise ConformalHybridMaterializationError(
            f"{field_name} must be a canonical non-empty string"
        )
    return value


def _finite_quality(value: object) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ConformalHybridMaterializationError(
            "minimum_quality must be finite and at least 0.03"
        )
    result = float(value)
    if (
        not math.isfinite(result)
        or result < _MINIMUM_ACCEPTED_QUALITY
        or result >= 1.0
    ):
        raise ConformalHybridMaterializationError(
            "minimum_quality must be finite, at least 0.03, and less than 1"
        )
    return result


def _finite_positive_size(value: object, *, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ConformalHybridMaterializationError(
            f"{field_name} must be finite and positive"
        )
    result = float(value)
    if not math.isfinite(result) or result <= 0.0:
        raise ConformalHybridMaterializationError(
            f"{field_name} must be finite and positive"
        )
    return result


def _matrix_product(
    left: Sequence[Sequence[float]],
    right: Sequence[Sequence[float]],
) -> tuple[tuple[float, float, float], ...]:
    return tuple(
        tuple(
            math.fsum(
                left[row][inner] * right[inner][column]
                for inner in range(3)
            )
            for column in range(3)
        )
        for row in range(3)
    )


def _rotation_matrix(
    placement: CanonicalRigidPlacement,
) -> tuple[tuple[float, float, float], ...]:
    x_value, y_value, z_value = (
        math.radians(value) for value in placement.rotation_deg_xyz
    )
    rotate_x = (
        (1.0, 0.0, 0.0),
        (0.0, math.cos(x_value), -math.sin(x_value)),
        (0.0, math.sin(x_value), math.cos(x_value)),
    )
    rotate_y = (
        (math.cos(y_value), 0.0, math.sin(y_value)),
        (0.0, 1.0, 0.0),
        (-math.sin(y_value), 0.0, math.cos(y_value)),
    )
    rotate_z = (
        (math.cos(z_value), -math.sin(z_value), 0.0),
        (math.sin(z_value), math.cos(z_value), 0.0),
        (0.0, 0.0, 1.0),
    )
    return _matrix_product(rotate_z, _matrix_product(rotate_y, rotate_x))


def _to_package(
    point: Sequence[float],
    placement: CanonicalRigidPlacement,
    rotation: Sequence[Sequence[float]],
) -> Point3D:
    pivot = placement.pivot_xyz_mm
    relative = tuple(float(point[index]) - pivot[index] for index in range(3))
    rotated = tuple(
        math.fsum(rotation[row][column] * relative[column] for column in range(3))
        for row in range(3)
    )
    return tuple(
        rotated[index]
        + pivot[index]
        + placement.translation_xyz_mm[index]
        for index in range(3)
    )  # type: ignore[return-value]


def _fillet_envelope(
    root: CanonicalRectangularUnderfillFillet,
) -> RectangularUfEnvelope:
    """Represent the canonical toe/top radii as one linear envelope slice."""

    die_x, die_y = root.die_origin_xy_mm
    die_width, die_length = root.die_size_xy_mm
    extrapolated_height = (
        root.wall_height_mm
        * root.toe_width_mm
        / (root.toe_width_mm - root.top_width_mm)
    )
    return RectangularUfEnvelope(
        die_width=die_width,
        die_length=die_length,
        base_z=root.base_z_mm,
        height=extrapolated_height,
        fillet_width=root.toe_width_mm,
        center_x=die_x + 0.5 * die_width,
        center_y=die_y + 0.5 * die_length,
    )


def _surface_shell(
    fragment: CanonicalGeometryFragment,
    locked_node_coordinates: Mapping[int, Sequence[float]],
    locked_boundary_facets: Mapping[str, Sequence[Sequence[int]]],
    requirement: ComponentMeshRequirement,
    *,
    surface_target_size_mm: float | None,
    near_size_mm: float | None,
    forced_partial_locked_sides: Sequence[str],
    contact_partition_loops,
    verbose: bool,
) -> SurfaceShell:
    root = fragment.root
    surface_target_size = (
        requirement.target_edge_mm
        if surface_target_size_mm is None
        else min(requirement.target_edge_mm, surface_target_size_mm)
    )
    arguments = {
        "target_size_mm": surface_target_size,
        "transition_distance_mm": requirement.transition_distance_mm,
        # The producer shell itself must honor the negotiated surface target.
        # ``near_size_mm`` belongs to an inherited/locked patch within that
        # shell and therefore cannot be coarser than the shell-wide ceiling.
        "near_size_mm": (
            None
            if near_size_mm is None
            else min(surface_target_size, near_size_mm)
        ),
        "verbose": verbose,
    }
    if type(root) in {CanonicalBox, CanonicalRectangularFrameExtrusion}:
        if forced_partial_locked_sides:
            raise ConformalHybridMaterializationError(
                "forced partial locked sides are supported only for a "
                "rectangular underfill fillet"
            )
        return generate_box_frame_surface_shell(
            locked_node_coordinates,
            locked_boundary_facets,
            fragment,
            contact_partition_loops=contact_partition_loops,
            **arguments,
        )
    if type(root) is CanonicalRectangularUnderfillFillet:
        if root.uses_elliptical_sweep:
            from .package_v2_swept_fillet import surface_shell
            return surface_shell(root, locked_node_coordinates, locked_boundary_facets,
                force_partial_locked_sides=forced_partial_locked_sides,
                contact_partition_loops=contact_partition_loops, **arguments)
        envelope = _fillet_envelope(root)
        return generate_rectangular_uf_surface_shell(
            locked_node_coordinates,
            locked_boundary_facets,
            envelope,
            root.base_z_mm,
            root.base_z_mm + root.wall_height_mm,
            force_partial_locked_sides=forced_partial_locked_sides,
            contact_partition_loops=contact_partition_loops,
            **arguments,
        )
    raise ConformalHybridMaterializationError(
        "conformal_hybrid materialization supports canonical Box, "
        "RectangularFrameExtrusion, and RectangularUnderfillFillet fragments"
    )


def _flatten_locked_facets(
    shell: SurfaceShell,
) -> tuple[tuple[int, ...], ...]:
    return tuple(
        facet
        for facets in shell.locked_facets_by_side.values()
        for facet in facets
    )


def _package_remainder(
    remainder: GmshClosedShellRemainder,
    placement: CanonicalRigidPlacement,
) -> GmshClosedShellRemainder:
    rotation = _rotation_matrix(placement)
    return replace(
        remainder,
        node_coordinates=MappingProxyType(
            {
                node_id: _to_package(point, placement, rotation)
                for node_id, point in remainder.node_coordinates.items()
            }
        ),
    )


def _remap_shell_facets(
    facets_by_side: Mapping[str, Sequence[Sequence[int]]],
    remainder: GmshClosedShellRemainder,
) -> Mapping[str, tuple[tuple[int, ...], ...]]:
    remainder_by_shell = {
        shell_node: remainder_node
        for remainder_node, shell_node in remainder.source_node_id_by_local_id.items()
    }
    try:
        return MappingProxyType(
            {
                side: tuple(
                    tuple(remainder_by_shell[node] for node in facet)
                    for facet in facets
                )
                for side, facets in facets_by_side.items()
            }
        )
    except KeyError as error:  # pragma: no cover - audited by the fill backend
        raise ConformalHybridMaterializationError(
            "Gmsh did not retain a surface-shell node"
        ) from error


def _direct_uf_remainder(
    volume: GmshUfConformalVolume,
) -> GmshClosedShellRemainder:
    """Adapt an already audited direct OCC/Gmsh UF volume for assembly."""

    boundary = (
        *volume.base_facets,
        *volume.cap_facets,
        *volume.die_wall_facets,
        *volume.free_surface_facets,
    )
    docking = tuple(
        facet
        for facets in volume.locked_facets_by_side.values()
        for facet in facets
    )
    return GmshClosedShellRemainder(
        node_coordinates=volume.node_coordinates,
        source_node_id_by_local_id=volume.source_node_id_by_local_id,
        elements=tuple(
            GmshClosedShellElement(element.gmsh_type, element.node_ids)
            for element in volume.elements
        ),
        boundary_facets=boundary,
        docking_facets=docking,
        tet4_count=volume.tet4_count,
        hex8_count=0,
        wedge6_count=volume.wedge6_count,
        pyramid5_count=volume.pyramid5_count,
        locked_triangle_count=volume.locked_triangle_count,
        locked_quad_count=volume.locked_quad_count,
        target_size_mm=volume.target_size_mm,
        near_size_mm=volume.near_size_mm,
        transition_distance_mm=volume.transition_distance_mm,
        background_field_kind=volume.background_field_kind,
        minimum_sicn=volume.minimum_sicn,
        minimum_sige=volume.minimum_sige,
        minimum_scaled_jacobian=volume.minimum_scaled_jacobian,
        minimum_determinant=volume.minimum_determinant,
        duplicate_node_count=volume.duplicate_node_count,
        duplicate_element_count=volume.duplicate_element_count,
        shell_volume_mm3=volume.cad_volume_mm3,
        element_volume_mm3=volume.element_volume_mm3,
        relative_volume_error=volume.element_relative_volume_error,
        random_seed=volume.random_seed,
    )


def _direct_uf_boundary_facets_by_side(
    volume: GmshUfConformalVolume,
    root: CanonicalRectangularUnderfillFillet,
) -> Mapping[str, tuple[tuple[int, ...], ...]]:
    """Recover the four exact die-wall names from a direct UF result."""

    x_min, y_min = root.die_origin_xy_mm
    x_max = x_min + root.die_size_xy_mm[0]
    y_max = y_min + root.die_size_xy_mm[1]
    tolerance = 1.0e-7
    grouped: dict[str, list[tuple[int, ...]]] = {
        "die_x_min": [],
        "die_x_max": [],
        "die_y_min": [],
        "die_y_max": [],
    }
    for facet in volume.die_wall_facets:
        points = tuple(volume.node_coordinates[node] for node in facet)
        matches = tuple(
            side
            for side, axis, coordinate, tangent_axis, tangent_bounds in (
                ("die_x_min", 0, x_min, 1, (y_min, y_max)),
                ("die_x_max", 0, x_max, 1, (y_min, y_max)),
                ("die_y_min", 1, y_min, 0, (x_min, x_max)),
                ("die_y_max", 1, y_max, 0, (x_min, x_max)),
            )
            if all(
                abs(point[axis] - coordinate) <= tolerance
                and tangent_bounds[0] - tolerance
                <= point[tangent_axis]
                <= tangent_bounds[1] + tolerance
                and root.base_z_mm - tolerance
                <= point[2]
                <= root.base_z_mm + root.wall_height_mm + tolerance
                for point in points
            )
        )
        if len(matches) != 1:
            raise ConformalHybridMaterializationError(
                "direct OCC/Gmsh UF produced an ambiguous die-wall facet"
            )
        grouped[matches[0]].append(facet)
    return MappingProxyType(
        {
            "base": tuple(volume.base_facets),
            "cap": tuple(volume.cap_facets),
            **{side: tuple(facets) for side, facets in grouped.items()},
            "outer_free": tuple(volume.free_surface_facets),
        }
    )


@dataclass(frozen=True, slots=True)
class ConformalHybridComponentMesh:
    """Audited Gmsh-owned volume plus its assembly-ready representation."""

    canonical_fragment: CanonicalGeometryFragment
    requirement: ComponentMeshRequirement
    surface_shell: SurfaceShell
    remainder: GmshClosedShellRemainder
    component_fragment: ComponentLocalMeshFragment
    locked_facets_by_geometric_side: Mapping[
        str, tuple[tuple[int, ...], ...]
    ]
    boundary_facets_by_geometric_side: Mapping[
        str, tuple[tuple[int, ...], ...]
    ]
    source_locked_node_id_by_local_id: Mapping[int, int]
    semantic_tokens_by_local_id: Mapping[int, str]
    element_counts: Mapping[str, int]
    element_kinds: tuple[str, ...]
    minimum_sicn: float
    minimum_sige: float
    minimum_scaled_jacobian: float
    backend_evidence: Mapping[str, object]
    required_quality: float = _MINIMUM_ACCEPTED_QUALITY
    orthogonal_hex_continuation_element_ids: tuple[int, ...] = ()
    orthogonal_hex_continuation_minimum_sicn: float | None = None
    orthogonal_hex_continuation_minimum_sige: float | None = None
    orthogonal_hex_continuation_minimum_scaled_jacobian: float | None = None
    orthogonal_hex_continuation_sicn_aspect_quality_exempted: bool = False
    non_continuation_minimum_sicn: float | None = None
    non_continuation_minimum_sige: float | None = None
    non_continuation_minimum_scaled_jacobian: float | None = None
    applied_volume_path: str = "gmsh_delaunay_closed_shell"
    structured_radial_layer_count: int = 0
    structured_angular_layer_count: int = 0
    structured_cross_block_shared_facet_count: int = 0
    structured_geometry_volume_relative_error: float = 0.0
    gmsh_owns_all_volume_connectivity: bool = True

    def __post_init__(self) -> None:
        for field_name in (
            "locked_facets_by_geometric_side",
            "boundary_facets_by_geometric_side",
            "source_locked_node_id_by_local_id",
            "semantic_tokens_by_local_id",
            "element_counts",
        ):
            object.__setattr__(
                self,
                field_name,
                MappingProxyType(dict(getattr(self, field_name))),
            )
        object.__setattr__(
            self,
            "backend_evidence",
            MappingProxyType(dict(self.backend_evidence)),
        )
        if self.requirement.volume_topology != "conformal_hybrid":
            raise ConformalHybridMaterializationError(
                "component mesh result requires conformal_hybrid topology"
            )
        if not self.gmsh_owns_all_volume_connectivity:
            raise ConformalHybridMaterializationError(
                "conformal_hybrid volume connectivity must be Gmsh-owned"
            )
        required_quality = _finite_quality(self.required_quality)
        if self.applied_volume_path not in {
            "gmsh_delaunay_closed_shell",
            "gmsh_delaunay_closed_shell_pyramid_untangler",
            "gmsh_direct_occ_locked_uf",
            "gmsh_direct_occ_elliptical_pointed_fillet",
            "gmsh_direct_occ_four_side_fillet",
            "gmsh_direct_occ_locked_box_tet",
            "gmsh_locked_quad_boundary_layer_and_corner_revolve",
            "gmsh_locked_quad_elliptical_corner_sweep",
            "gmsh_locked_base_ruled_staircase_quadtri_and_tet_remainder",
        }:
            raise ConformalHybridMaterializationError(
                "conformal_hybrid applied volume path is unknown"
            )
        if not self.element_kinds or set(self.element_kinds).difference(
            _ELEMENT_KIND_ORDER
        ):
            raise ConformalHybridMaterializationError(
                "conformal_hybrid must contain a non-empty permitted family subset"
            )
        if self.applied_volume_path in {
            "gmsh_locked_quad_boundary_layer_and_corner_revolve",
            "gmsh_locked_quad_elliptical_corner_sweep",
        }:
            if (
                self.structured_radial_layer_count < 1
                or self.structured_angular_layer_count < 1
                or self.structured_cross_block_shared_facet_count < 1
                or not math.isfinite(
                    self.structured_geometry_volume_relative_error
                )
                or self.structured_geometry_volume_relative_error < 0.0
            ):
                raise ConformalHybridMaterializationError(
                    "conformal_hybrid structured path evidence is incomplete"
                )
        mapped_path = self.applied_volume_path == (
            "gmsh_locked_base_ruled_staircase_quadtri_and_tet_remainder"
        )
        continuation_ids = tuple(
            self.orthogonal_hex_continuation_element_ids
        )
        object.__setattr__(
            self,
            "orthogonal_hex_continuation_element_ids",
            continuation_ids,
        )
        continuation_values = (
            self.orthogonal_hex_continuation_minimum_sicn,
            self.orthogonal_hex_continuation_minimum_sige,
            self.orthogonal_hex_continuation_minimum_scaled_jacobian,
        )
        non_continuation_values = (
            self.non_continuation_minimum_sicn,
            self.non_continuation_minimum_sige,
            self.non_continuation_minimum_scaled_jacobian,
        )
        if not mapped_path or not continuation_ids:
            if (
                continuation_ids
                or any(value is not None for value in continuation_values)
                or any(value is not None for value in non_continuation_values)
                or self.orthogonal_hex_continuation_sicn_aspect_quality_exempted
            ):
                raise ConformalHybridMaterializationError(
                    "Orth-origin HEX evidence is valid only for the mapped "
                    "locked-base Gmsh path with an actual Orth producer"
                )
            if min(
                self.minimum_sicn,
                self.minimum_sige,
                self.minimum_scaled_jacobian,
            ) < required_quality:
                raise ConformalHybridMaterializationError(
                    "conformal_hybrid quality evidence is below the required "
                    "floor"
                )
            return

        if (
            not continuation_ids
            or len(set(continuation_ids)) != len(continuation_ids)
            or any(value is None for value in continuation_values)
            or any(value is None for value in non_continuation_values)
        ):
            raise ConformalHybridMaterializationError(
                "mapped locked-base path lacks per-family quality evidence"
            )
        element_by_id = {
            element.local_element_id: element
            for element in self.component_fragment.elements
        }
        if any(
            element_id not in element_by_id
            or element_by_id[element_id].gmsh_type != 5
            or element_by_id[element_id].provenance
            != ORTHOGONAL_HEX_CONTINUATION_PROVENANCE
            for element_id in continuation_ids
        ) or any(
            element.provenance == ORTHOGONAL_HEX_CONTINUATION_PROVENANCE
            and element.local_element_id not in continuation_ids
            for element in self.component_fragment.elements
        ):
            raise ConformalHybridMaterializationError(
                "mapped locked-base Orth-origin HEX provenance is inconsistent"
            )
        resolved_continuation = tuple(float(value) for value in continuation_values)
        resolved_non_continuation = tuple(
            float(value) for value in non_continuation_values
        )
        if any(
            not math.isfinite(value)
            for value in (*resolved_continuation, *resolved_non_continuation)
        ):
            raise ConformalHybridMaterializationError(
                "mapped locked-base per-family quality is non-finite"
            )
        if self.orthogonal_hex_continuation_sicn_aspect_quality_exempted != (
            resolved_continuation[0] < required_quality
        ):
            raise ConformalHybridMaterializationError(
                "mapped locked-base SICN exemption flag is inconsistent"
            )
        if min(
            self.minimum_sige,
            self.minimum_scaled_jacobian,
            resolved_continuation[1],
            resolved_continuation[2],
            *resolved_non_continuation,
        ) < required_quality:
            raise ConformalHybridMaterializationError(
                "mapped locked-base strategy-aware quality is below the "
                "required floor"
            )
        if resolved_continuation[0] <= 0.0:
            raise ConformalHybridMaterializationError(
                "mapped locked-base continuation SICN must remain positive"
            )

    @property
    def node_count(self) -> int:
        return self.remainder.node_count

    @property
    def element_count(self) -> int:
        return self.remainder.element_count

    @property
    def has_locked_quads(self) -> bool:
        return any(
            len(facet) == 4
            for facets in self.locked_facets_by_geometric_side.values()
            for facet in facets
        )


def materialize_conformal_hybrid_component(
    canonical_fragment: CanonicalGeometryFragment,
    locked_node_coordinates: Mapping[int, Sequence[float]],
    locked_boundary_facets: Mapping[str, Sequence[Sequence[int]]],
    requirement: ComponentMeshRequirement,
    *,
    material_name: str,
    fragment_key: str | None = None,
    provenance: str = "gmsh_conformal_hybrid",
    semantic_tokens_by_locked_node_id: Mapping[int, str] | None = None,
    surface_target_size_mm: float | None = None,
    near_size_mm: float | None = None,
    forced_partial_locked_sides: Sequence[str] = (),
    contact_partition_loops=(),
    minimum_quality: float = _MINIMUM_ACCEPTED_QUALITY,
    random_seeds: Sequence[int] = (1, 2, 3),
    optimization_rounds: int = 2,
    orthogonal_hex_locked_base: bool = False,
    interface_geometry_tolerance_mm: float = (
        DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM
    ),
    verbose: bool = False,
) -> ConformalHybridComponentMesh:
    """Materialize one canonical body without custom 3D connectivity.

    ``locked_boundary_facets`` is keyed only by the geometric side vocabulary
    accepted by the selected canonical geometry.  Semantic tokens use the
    caller's locked-node IDs and are transferred to the final component-local
    node IDs exactly once.
    """

    if type(canonical_fragment) is not CanonicalGeometryFragment:
        raise ConformalHybridMaterializationError(
            "canonical_fragment must be a CanonicalGeometryFragment"
        )
    if type(requirement) is not ComponentMeshRequirement:
        raise ConformalHybridMaterializationError(
            "requirement must be a ComponentMeshRequirement"
        )
    if requirement.volume_topology != "conformal_hybrid":
        raise ConformalHybridMaterializationError(
            "materializer requires volume_topology 'conformal_hybrid'"
        )
    if not isinstance(locked_node_coordinates, Mapping) or not isinstance(
        locked_boundary_facets, Mapping
    ):
        raise ConformalHybridMaterializationError(
            "locked coordinates and facets must be mappings"
        )
    if not isinstance(verbose, bool):
        raise ConformalHybridMaterializationError("verbose must be boolean")
    if not isinstance(orthogonal_hex_locked_base, bool):
        raise ConformalHybridMaterializationError(
            "orthogonal_hex_locked_base must be boolean"
        )
    try:
        geometry_tolerance = validate_interface_geometry_tolerance_mm(
            interface_geometry_tolerance_mm
        )
    except ValueError as error:
        raise ConformalHybridMaterializationError(str(error)) from error
    try:
        resolved_forced_partial_sides = tuple(forced_partial_locked_sides)
    except TypeError as error:
        raise ConformalHybridMaterializationError(
            "forced_partial_locked_sides must be a sequence"
        ) from error
    if (
        len(set(resolved_forced_partial_sides))
        != len(resolved_forced_partial_sides)
        or any(side not in {"base", "cap"} for side in resolved_forced_partial_sides)
    ):
        raise ConformalHybridMaterializationError(
            "forced_partial_locked_sides may contain base and cap once each"
        )
    resolved_quality = _finite_quality(minimum_quality)
    resolved_fragment_key = _canonical_text(
        canonical_fragment.fragment_id if fragment_key is None else fragment_key,
        field_name="fragment_key",
    )
    resolved_material = _canonical_text(material_name, field_name="material_name")
    resolved_provenance = _canonical_text(provenance, field_name="provenance")

    raw_tokens = (
        {} if semantic_tokens_by_locked_node_id is None
        else semantic_tokens_by_locked_node_id
    )
    if not isinstance(raw_tokens, Mapping):
        raise ConformalHybridMaterializationError(
            "semantic_tokens_by_locked_node_id must be a mapping"
        )
    unknown_token_nodes = set(raw_tokens).difference(locked_node_coordinates)
    if unknown_token_nodes:
        raise ConformalHybridMaterializationError(
            "semantic token mapping references an unknown locked node"
        )

    resolved_surface_target = (
        None
        if surface_target_size_mm is None
        else min(
            requirement.target_edge_mm,
            _finite_positive_size(
                surface_target_size_mm,
                field_name="surface_target_size_mm",
            ),
        )
    )
    resolved_explicit_near = (
        None
        if near_size_mm is None
        else min(
            requirement.target_edge_mm,
            _finite_positive_size(near_size_mm, field_name="near_size_mm"),
        )
    )
    shell = _surface_shell(
        canonical_fragment,
        locked_node_coordinates,
        locked_boundary_facets,
        requirement,
        surface_target_size_mm=resolved_surface_target,
        near_size_mm=resolved_explicit_near,
        forced_partial_locked_sides=resolved_forced_partial_sides,
        contact_partition_loops=contact_partition_loops,
        verbose=verbose,
    )
    # The surface generator can negotiate a finer effective near size from
    # immutable docking edges.  Pass that *resolved* value into the volume
    # fill instead of reconstructing it from the caller's shell-wide target.
    # An explicit near size remains an independent ceiling, so neither source
    # can be accidentally relaxed here.
    resolved_remainder_near = (
        shell.near_size_mm
        if resolved_explicit_near is None
        else min(shell.near_size_mm, resolved_explicit_near)
    )
    docking_facets = _flatten_locked_facets(shell)
    structured_fill: RectangularUfStructuredFill | None = None
    quadtri_fill: RectangularUfLockedBaseQuadTriFill | None = None
    direct_fill: GmshUfConformalVolume | None = None
    direct_box = None
    direct_box_failure = None
    if type(canonical_fragment.root) is CanonicalBox and docking_facets:
        try:
            if resolved_surface_target is not None and resolved_surface_target < requirement.target_edge_mm:
                raise ConstrainedHybridError(
                    "direct Box TET requires the closed-shell route for a finer outgoing surface target"
                )
            direct_box = generate_box_tet(
                canonical_fragment.root, locked_node_coordinates, locked_boundary_facets,
                target_size_mm=requirement.target_edge_mm,
                near_size_mm=resolved_remainder_near,
                transition_distance_mm=requirement.transition_distance_mm,
                minimum_quality=resolved_quality, random_seeds=random_seeds,
                contact_partition_loops=contact_partition_loops, verbose=verbose,
            )
        except ConstrainedHybridError as error:
            direct_box_failure = str(error)
    quadtri_failure: RectangularUfLockedBaseQuadTriFillError | None = None
    quadtri_eligible = (
        type(canonical_fragment.root)
        is CanonicalRectangularUnderfillFillet
        and not canonical_fragment.root.uses_elliptical_sweep
        and rectangular_uf_locked_base_quadtri_ineligibility(
            shell,
            canonical_fragment.root,
            forced_partial_locked_sides=resolved_forced_partial_sides,
            interface_geometry_tolerance_mm=geometry_tolerance,
        )
        is None
    )
    if quadtri_eligible:
        try:
            quadtri_fill = generate_rectangular_uf_locked_base_quadtri_fill(
                shell,
                canonical_fragment.root,  # type: ignore[arg-type]
                target_size_mm=requirement.target_edge_mm,
                transition_distance_mm=requirement.transition_distance_mm,
                near_size_mm=resolved_remainder_near,
                forced_partial_locked_sides=resolved_forced_partial_sides,
                minimum_quality=resolved_quality,
                random_seeds=random_seeds,
                optimization_rounds=optimization_rounds,
                allow_source_hex_sicn_aspect_exemption=(
                    orthogonal_hex_locked_base
                ),
                interface_geometry_tolerance_mm=geometry_tolerance,
                verbose=verbose,
            )
        except RectangularUfLockedBaseQuadTriFillError as error:
            quadtri_failure = error

    native_error: ConstrainedHybridError | None = None
    if direct_box is not None:
        local_remainder = direct_box[0]
    elif quadtri_fill is None:
        try:
            local_remainder = generate_closed_shell_conformal_remainder(
                shell.node_coordinates,
                shell.boundary_facets,
                docking_facets,
                target_size_mm=requirement.target_edge_mm,
                transition_distance_mm=requirement.transition_distance_mm,
                near_size_mm=resolved_remainder_near,
                minimum_quality=resolved_quality,
                random_seeds=random_seeds,
                optimization_rounds=optimization_rounds,
                verbose=verbose,
            )
        except ConstrainedHybridError as error:
            native_error = error

    if quadtri_fill is not None:
        local_remainder = quadtri_fill.remainder
    elif native_error is not None and type(canonical_fragment.root) is CanonicalRectangularUnderfillFillet and canonical_fragment.root.uses_elliptical_sweep:
        from .package_v2_swept_fillet import direct_swept_fill, locked_wall_fill, pointed_wall_fill, widths_at
        try:
            if canonical_fragment.root.top_widths_mm is not None:
                direct_fill = direct_swept_fill(canonical_fragment.root, locked_node_coordinates, locked_boundary_facets,
                    target_size_mm=requirement.target_edge_mm, transition_distance_mm=requirement.transition_distance_mm,
                    near_size_mm=resolved_remainder_near, minimum_quality=resolved_quality, random_seeds=random_seeds,
                    optimization_rounds=optimization_rounds, interface_geometry_tolerance_mm=geometry_tolerance, verbose=verbose)
                local_remainder = _direct_uf_remainder(direct_fill)
            elif max(widths_at(canonical_fragment.root, 1.)) == 0:
                direct_fill = pointed_wall_fill(canonical_fragment.root, locked_node_coordinates, locked_boundary_facets,
                    target_size_mm=requirement.target_edge_mm, transition_distance_mm=requirement.transition_distance_mm,
                    near_size_mm=resolved_remainder_near, minimum_quality=resolved_quality, random_seeds=random_seeds,
                    optimization_rounds=optimization_rounds, interface_geometry_tolerance_mm=geometry_tolerance, verbose=verbose)
                local_remainder = _direct_uf_remainder(direct_fill)
            else:
                structured_fill = locked_wall_fill(shell, canonical_fragment.root, target_size_mm=requirement.target_edge_mm,
                    transition_distance_mm=requirement.transition_distance_mm, near_size_mm=resolved_remainder_near,
                    minimum_quality=resolved_quality, verbose=verbose)
                local_remainder = structured_fill.remainder
        except ValueError as error:
            raise ConstrainedHybridError(f"{native_error}; elliptical fillet fallback: {error}") from error
    elif native_error is not None:
        diagnostic = str(native_error)
        is_quality_failure = any(
            marker in diagnostic
            for marker in (
                "quality floor was not met",
                "contains a non-positive element",
                "quality is non-finite",
                "folds across internal faces",
            )
        )
        if (
            not is_quality_failure
            or type(canonical_fragment.root)
            is not CanonicalRectangularUnderfillFillet
            or canonical_fragment.root.uses_elliptical_sweep
            or resolved_forced_partial_sides
        ):
            if quadtri_failure is not None:
                raise ConstrainedHybridError(
                    "mapped Gmsh QuadTri path was not executable: "
                    f"{quadtri_failure}; native Gmsh closed-shell path was "
                    f"not executable: {native_error}"
                ) from native_error
            if direct_box_failure is not None:
                raise ConstrainedHybridError(f"{direct_box_failure}; {native_error}") from native_error
            raise native_error
        fallback_failures: list[str] = []
        if quadtri_failure is not None:
            fallback_failures.append(
                "mapped Gmsh QuadTri path was not executable: "
                f"{quadtri_failure}"
            )
        try:
            direct_fill = generate_rectangular_uf_conformal_hybrid(
                locked_node_coordinates,
                locked_boundary_facets,
                _fillet_envelope(canonical_fragment.root),
                canonical_fragment.root.base_z_mm,
                canonical_fragment.root.base_z_mm
                + canonical_fragment.root.wall_height_mm,
                target_size_mm=requirement.target_edge_mm,
                transition_distance_mm=(
                    requirement.transition_distance_mm
                ),
                near_size_mm=resolved_remainder_near,
                minimum_quality=resolved_quality,
                random_seeds=random_seeds,
                optimization_rounds=optimization_rounds,
                interface_geometry_tolerance_mm=geometry_tolerance,
                verbose=verbose,
            )
        except ConstrainedHybridError as direct_error:
            fallback_failures.append(
                "direct OCC/Gmsh UF path was not executable: "
                f"{direct_error}"
            )

        if direct_fill is None:
            try:
                structured_fill = (
                    generate_rectangular_uf_locked_quad_structured_fill(
                        shell,
                        canonical_fragment.root,
                        target_size_mm=requirement.target_edge_mm,
                        transition_distance_mm=(
                            requirement.transition_distance_mm
                        ),
                        near_size_mm=resolved_remainder_near,
                        minimum_quality=resolved_quality,
                        verbose=verbose,
                    )
                )
            except RectangularUfStructuredFillError as structured_error:
                fallback_failures.append(
                    "restricted Gmsh structured protection path was not "
                    f"executable: {structured_error}"
                )
                raise ConstrainedHybridError(
                    f"{native_error}; " + "; ".join(fallback_failures)
                ) from native_error
        if structured_fill is not None:
            local_remainder = structured_fill.remainder
        elif direct_fill is not None:
            local_remainder = _direct_uf_remainder(direct_fill)
        else:  # pragma: no cover - both fallback calls either return or raise
            raise AssertionError("conformal Hybrid fallback produced no result")

    if direct_box is not None:
        locked_by_side, boundary_by_side = direct_box[1:3]
    elif direct_fill is not None:
        locked_by_side = direct_fill.locked_facets_by_side
        boundary_by_side = _direct_uf_boundary_facets_by_side(
            direct_fill,
            canonical_fragment.root,  # type: ignore[arg-type]
        )
    elif quadtri_fill is not None:
        locked_by_side = quadtri_fill.locked_facets_by_side
        boundary_by_side = quadtri_fill.boundary_facets_by_side
    elif structured_fill is None:
        locked_by_side = _remap_shell_facets(
            shell.locked_facets_by_side,
            local_remainder,
        )
        boundary_by_side = _remap_shell_facets(
            shell.facets_by_geometric_side,
            local_remainder,
        )
    else:
        locked_by_side = structured_fill.locked_facets_by_side
        boundary_by_side = structured_fill.boundary_facets_by_side
    if direct_box is not None:
        final_by_source = {
            source_node: final_node for final_node, source_node
            in local_remainder.source_node_id_by_local_id.items()
        }
    elif direct_fill is not None:
        final_by_source = {
            source_node: final_node
            for final_node, source_node in
            direct_fill.source_node_id_by_local_id.items()
        }
    else:
        remainder_by_shell = {
            shell_node: remainder_node
            for remainder_node, shell_node in
            local_remainder.source_node_id_by_local_id.items()
        }
        shell_by_source = {
            source_node: shell_node
            for shell_node, source_node in
            shell.source_node_id_by_local_id.items()
        }
        try:
            final_by_source = {
                source_node: remainder_by_shell[shell_node]
                for source_node, shell_node in shell_by_source.items()
            }
        except KeyError as error:  # pragma: no cover - audited by the fill backend
            raise ConformalHybridMaterializationError(
                "Gmsh did not retain a locked source node"
            ) from error
    semantic_tokens = {
        final_by_source[int(source_node)]: token
        for source_node, token in raw_tokens.items()
    }
    source_by_final = {
        final_node: source_node
        for source_node, final_node in final_by_source.items()
    }

    package_remainder = _package_remainder(
        local_remainder,
        canonical_fragment.placement,
    )
    component_fragment = fragment_from_closed_shell_remainder(
        package_remainder,
        fragment_key=resolved_fragment_key,
        component_key=requirement.component_id,
        material_name=resolved_material,
        provenance=(
            CONFORMAL_HYBRID_TRANSITION_PROVENANCE
            if quadtri_fill is not None
            else resolved_provenance
        ),
        provenance_by_element_id=(
            {
                element_id: ORTHOGONAL_HEX_CONTINUATION_PROVENANCE
                for element_id in quadtri_fill.source_hex_element_ids
            }
            if quadtri_fill is not None and orthogonal_hex_locked_base
            else None
        ),
        semantic_tokens_by_node_id=semantic_tokens,
    )
    counts = Counter(element.kind.value for element in component_fragment.elements)
    element_counts = MappingProxyType(
        {kind: counts[kind] for kind in _ELEMENT_KIND_ORDER}
    )
    element_kinds = tuple(kind for kind in _ELEMENT_KIND_ORDER if counts[kind])
    if direct_box is not None:
        applied_volume_path = "gmsh_direct_occ_locked_box_tet"
    elif quadtri_fill is not None:
        applied_volume_path = quadtri_fill.applied_path
    elif structured_fill is not None:
        applied_volume_path = structured_fill.applied_path
    elif direct_fill is not None:
        applied_volume_path = ("gmsh_direct_occ_four_side_fillet" if canonical_fragment.root.top_widths_mm is not None else
            "gmsh_direct_occ_elliptical_pointed_fillet"
            if canonical_fragment.root.uses_elliptical_sweep else "gmsh_direct_occ_locked_uf")
    elif package_remainder.pyramid_untangler_used:
        applied_volume_path = "gmsh_delaunay_closed_shell_pyramid_untangler"
    else:
        applied_volume_path = "gmsh_delaunay_closed_shell"
    backend_evidence: dict[str, object] = {
        "applied_volume_path": applied_volume_path,
        "gmsh_owns_all_volume_connectivity": True,
        "tet_preferred": True,
        "tet4_count": counts["TET4"],
    }
    if direct_box is not None:
        backend_evidence.update(direct_box[3])
    elif direct_box_failure is not None:
        backend_evidence["direct_box_tet_rejection"] = direct_box_failure
    if not counts["TET4"]:
        backend_evidence["strategy_warnings"] = [{
            "code": "hybrid_tet_unavailable", "severity": "warning", "export_allowed": True,
            "message": "Hybrid 的 TET 路径未通过检查，已使用其他单元生成；当前结果未实现 TET 内部加粗，请检查网格尺寸与接口约束。",
            "applied_volume_path": applied_volume_path,
            "tet_candidate_rejection": str(native_error),
        }]
    if quadtri_fill is not None:
        backend_evidence.update(
            {
                "adapter_height_mm": quadtri_fill.adapter_height_mm,
                "geometry_recovery_height_mm": (
                    quadtri_fill.geometry_recovery_height_mm
                ),
                "adapter_first_layer_fraction": (
                    quadtri_fill.adapter_first_layer_fraction
                ),
                "adapter_method": quadtri_fill.adapter_method,
                "remainder_algorithm_3d": (
                    quadtri_fill.remainder_algorithm_3d
                ),
                "source_quad_count": quadtri_fill.source_quad_count,
                "source_quad_hex_owner_count": (
                    quadtri_fill.source_quad_hex_owner_count
                ),
                "adapter_hex8_count": quadtri_fill.adapter_hex8_count,
                "adapter_pyramid5_count": (
                    quadtri_fill.adapter_pyramid5_count
                ),
                "adapter_wedge6_count": quadtri_fill.adapter_wedge6_count,
                "adapter_tet4_count": quadtri_fill.adapter_tet4_count,
                "remainder_tet4_count": quadtri_fill.remainder_tet4_count,
                "interface_triangle_count": (
                    quadtri_fill.interface_triangle_count
                ),
                "interface_quad_count": quadtri_fill.interface_quad_count,
                "interface_two_owner_count": (
                    quadtri_fill.interface_two_owner_count
                ),
                "canonical_volume_relative_error": (
                    quadtri_fill.canonical_volume_relative_error
                ),
                "recovery_section_area_relative_error": (
                    quadtri_fill.recovery_section_area_relative_error
                ),
                "recovery_maximum_radial_deviation_mm": (
                    quadtri_fill.recovery_maximum_radial_deviation_mm
                ),
                "recovery_minimum_signed_radial_deviation_mm": (
                    quadtri_fill.recovery_minimum_signed_radial_deviation_mm
                ),
                "recovery_maximum_signed_radial_deviation_mm": (
                    quadtri_fill.recovery_maximum_signed_radial_deviation_mm
                ),
                "recovery_allowed_radial_deviation_mm": (
                    quadtri_fill.recovery_allowed_radial_deviation_mm
                ),
                "source_hex_minimum_sicn": (
                    quadtri_fill.source_hex_minimum_sicn
                ),
                "source_hex_minimum_sige": (
                    quadtri_fill.source_hex_minimum_sige
                ),
                "source_hex_minimum_scaled_jacobian": (
                    quadtri_fill.source_hex_minimum_scaled_jacobian
                ),
                "source_hex_sicn_aspect_quality_exempted": (
                    quadtri_fill.source_hex_sicn_aspect_quality_exempted
                ),
                "non_source_minimum_sicn": (
                    quadtri_fill.non_source_minimum_sicn
                ),
                "non_source_minimum_sige": (
                    quadtri_fill.non_source_minimum_sige
                ),
                "non_source_minimum_scaled_jacobian": (
                    quadtri_fill.non_source_minimum_scaled_jacobian
                ),
                "candidate_attempts": quadtri_fill.candidate_attempts,
            }
        )
    elif structured_fill is not None:
        backend_evidence.update(
            {
                "structured_radial_layer_count": (
                    structured_fill.radial_layer_count
                ),
                "structured_angular_layer_count": (
                    structured_fill.angular_layer_count
                ),
                "structured_cross_block_shared_facet_count": (
                    structured_fill.cross_block_shared_facet_count
                ),
                "structured_geometry_volume_relative_error": (
                    structured_fill.geometry_volume_relative_error
                ),
            }
        )

    return ConformalHybridComponentMesh(
        canonical_fragment=canonical_fragment,
        requirement=requirement,
        surface_shell=shell,
        remainder=package_remainder,
        component_fragment=component_fragment,
        locked_facets_by_geometric_side=locked_by_side,
        boundary_facets_by_geometric_side=boundary_by_side,
        source_locked_node_id_by_local_id=MappingProxyType(source_by_final),
        semantic_tokens_by_local_id=MappingProxyType(semantic_tokens),
        element_counts=element_counts,
        element_kinds=element_kinds,
        minimum_sicn=package_remainder.minimum_sicn,
        minimum_sige=package_remainder.minimum_sige,
        minimum_scaled_jacobian=(
            package_remainder.minimum_scaled_jacobian
        ),
        backend_evidence=backend_evidence,
        required_quality=resolved_quality,
        orthogonal_hex_continuation_element_ids=(
            ()
            if quadtri_fill is None or not orthogonal_hex_locked_base
            else quadtri_fill.source_hex_element_ids
        ),
        orthogonal_hex_continuation_minimum_sicn=(
            None
            if quadtri_fill is None or not orthogonal_hex_locked_base
            else quadtri_fill.source_hex_minimum_sicn
        ),
        orthogonal_hex_continuation_minimum_sige=(
            None
            if quadtri_fill is None or not orthogonal_hex_locked_base
            else quadtri_fill.source_hex_minimum_sige
        ),
        orthogonal_hex_continuation_minimum_scaled_jacobian=(
            None
            if quadtri_fill is None or not orthogonal_hex_locked_base
            else quadtri_fill.source_hex_minimum_scaled_jacobian
        ),
        orthogonal_hex_continuation_sicn_aspect_quality_exempted=(
            False
            if quadtri_fill is None or not orthogonal_hex_locked_base
            else quadtri_fill.source_hex_sicn_aspect_quality_exempted
        ),
        non_continuation_minimum_sicn=(
            None
            if quadtri_fill is None or not orthogonal_hex_locked_base
            else quadtri_fill.non_source_minimum_sicn
        ),
        non_continuation_minimum_sige=(
            None
            if quadtri_fill is None or not orthogonal_hex_locked_base
            else quadtri_fill.non_source_minimum_sige
        ),
        non_continuation_minimum_scaled_jacobian=(
            None
            if quadtri_fill is None or not orthogonal_hex_locked_base
            else quadtri_fill.non_source_minimum_scaled_jacobian
        ),
        applied_volume_path=applied_volume_path,
        structured_radial_layer_count=(
            0 if structured_fill is None else structured_fill.radial_layer_count
        ),
        structured_angular_layer_count=(
            0 if structured_fill is None else structured_fill.angular_layer_count
        ),
        structured_cross_block_shared_facet_count=(
            0
            if structured_fill is None
            else structured_fill.cross_block_shared_facet_count
        ),
        structured_geometry_volume_relative_error=(
            0.0
            if structured_fill is None
            else structured_fill.geometry_volume_relative_error
        ),
    )


__all__ = [
    "ConformalHybridComponentMesh",
    "ConformalHybridMaterializationError",
    "materialize_conformal_hybrid_component",
]
