"""Role-free Cartesian HEX8 backend for a rectangular fillet volume.

This module is the one backend that is allowed to turn the analytic free
surface of :class:`CanonicalRectangularUnderfillFillet` into a staircase.  It
does not inspect material, stack position, Component role, or any alternative
volume topology.  A candidate Cartesian cell is handled by one explicit rule:

* analytic FULL cells are retained;
* analytic CUT cells are retained when their centre lies in the analytic target;
* every other CUT cell and every OUTSIDE cell is rejected.

Interface constraints fix candidate coordinates and connectivity, never cell
occupancy. Only surviving cells contribute boundary facets. The result reports
the volume error and located topology warnings without repairing occupancy.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from enum import Enum
import hashlib
from itertools import product
import json
import math
from statistics import median
from typing import Iterable, Mapping, Sequence

from .package_v2_mesh_sizing import (
    MeshSeedPolicy,
    geometry_origin,
    interval_levels,
    ray_levels,
)

from .package_assembly import (
    ComponentLocalDirection,
    OrthogonalHexMeshStrategy,
)
from .package_v2_geometry import (
    CanonicalGeometryFragment,
    CanonicalRectangularUnderfillFillet,
    CanonicalRigidPlacement,
)


_SCHEMA = "easymesh-package-v2-orthogonal-fillet-v3"
_MULTIBLOCK_SCHEMA = "easymesh-package-v2-orthogonal-fillet-multiblock-v4"
_CUT_RULE = "retain_center_inside"
_HEX_FACES = (
    (0, 1, 2, 3),
    (4, 5, 6, 7),
    (0, 1, 5, 4),
    (1, 2, 6, 5),
    (2, 3, 7, 6),
    (3, 0, 4, 7),
)


class OrthogonalFilletError(ValueError):
    """Raised when a Cartesian fillet mesh cannot preserve its contract."""


class OrthogonalCellClass(str, Enum):
    FULL = "full"
    CUT = "cut"
    OUTSIDE = "outside"


class OrthogonalRetentionReason(str, Enum):
    ANALYTIC_FULL = "analytic_full"
    CUT_CENTER_INSIDE = "cut_center_inside"


class OrthogonalBoundarySide(str, Enum):
    BASE = "base"
    CAP = "cap"
    DIE_X_MIN = "die_x_min"
    DIE_X_MAX = "die_x_max"
    DIE_Y_MIN = "die_y_min"
    DIE_Y_MAX = "die_y_max"
    STAIRCASE_X_MIN = "staircase_x_min"
    STAIRCASE_X_MAX = "staircase_x_max"
    STAIRCASE_Y_MIN = "staircase_y_min"
    STAIRCASE_Y_MAX = "staircase_y_max"
    STAIRCASE_Z_MIN = "staircase_z_min"
    STAIRCASE_Z_MAX = "staircase_z_max"


@dataclass(frozen=True, slots=True)
class LockedCartesianQuad:
    """An immutable candidate QUAD partition; cell ownership is independent."""

    seam_id: str
    target_local_points_mm: tuple[
        tuple[float, float, float],
        tuple[float, float, float],
        tuple[float, float, float],
        tuple[float, float, float],
    ]

    def __post_init__(self) -> None:
        if not isinstance(self.seam_id, str) or not self.seam_id:
            raise OrthogonalFilletError("locked QUAD seam_id is invalid")
        points = tuple(
            _point3(point, field_name="locked QUAD point")
            for point in self.target_local_points_mm
        )
        if len(points) != 4 or len(set(points)) != 4:
            raise OrthogonalFilletError(
                "locked QUAD must contain four distinct target-local points"
            )
        object.__setattr__(self, "target_local_points_mm", points)


@dataclass(frozen=True, slots=True)
class LockedCartesianBoundaryChain:
    """One exact inner-perimeter chain for a Cartesian multiblock face.

    The chain identifies geometry only.  It does not select a Component,
    material, stack direction or volume backend.  Consecutive source segments
    are immutable: a multiblock partition may refine away from the chain but
    cannot insert a T-junction into one of its edges.
    """

    chain_id: str
    die_wall_side: OrthogonalBoundarySide
    target_local_points_mm: tuple[tuple[float, float, float], ...]

    def __post_init__(self) -> None:
        if not isinstance(self.chain_id, str) or not self.chain_id:
            raise OrthogonalFilletError("locked boundary chain_id is invalid")
        if not isinstance(
            self.die_wall_side,
            OrthogonalBoundarySide,
        ) or self.die_wall_side not in {
            OrthogonalBoundarySide.DIE_X_MIN,
            OrthogonalBoundarySide.DIE_X_MAX,
            OrthogonalBoundarySide.DIE_Y_MIN,
            OrthogonalBoundarySide.DIE_Y_MAX,
        }:
            raise OrthogonalFilletError(
                "locked boundary chain must identify one die-wall side"
            )
        points = tuple(
            _point3(point, field_name="locked boundary-chain point")
            for point in self.target_local_points_mm
        )
        if len(points) < 2 or len(set(points)) != len(points):
            raise OrthogonalFilletError(
                "locked boundary chain requires distinct ordered points"
            )
        object.__setattr__(self, "target_local_points_mm", points)


@dataclass(frozen=True, slots=True)
class OrthogonalHexNode:
    node_index: int
    target_local_coordinates_mm: tuple[float, float, float]
    package_coordinates_mm: tuple[float, float, float]


@dataclass(frozen=True, slots=True)
class OrthogonalHexElement:
    element_index: int
    node_indices: tuple[int, int, int, int, int, int, int, int]
    cell_ijk: tuple[int, int, int]
    bounds_xyz_mm: tuple[
        tuple[float, float],
        tuple[float, float],
        tuple[float, float],
    ]
    analytic_class: OrthogonalCellClass
    retention_reason: OrthogonalRetentionReason
    locked_seam_ids: tuple[str, ...]
    volume_mm3: float
    gmsh_type: int = 5


@dataclass(frozen=True, slots=True)
class OrthogonalBoundaryFacet:
    side: OrthogonalBoundarySide
    node_indices: tuple[int, int, int, int]
    owner_element_index: int
    owner_local_face_index: int
    locked_seam_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class OrthogonalFilletAudit:
    cut_cell_rule: str
    target_edge_mm: float
    x_levels_mm: tuple[float, ...]
    y_levels_mm: tuple[float, ...]
    z_levels_mm: tuple[float, ...]
    candidate_cell_count: int
    analytic_full_cell_count: int
    analytic_cut_cell_count: int
    analytic_outside_cell_count: int
    accepted_full_cell_count: int
    accepted_cut_cell_count: int
    rejected_cut_cell_count: int
    locked_seam_count: int
    locked_seam_cell_count: int
    locked_cut_override_count: int
    required_boundary_point_count: int
    required_boundary_points_sha256: str
    approximated_volume_mm3: float
    analytic_volume_mm3: float
    signed_volume_error_mm3: float
    absolute_volume_error_mm3: float
    relative_volume_error: float
    maximum_generated_edge_mm: float
    target_geometry_sha256: str
    mesh_sha256: str
    mesh_warnings: tuple[dict[str, object], ...] = ()
    evidence_sha256: str = field(init=False)

    def __post_init__(self) -> None:
        if (
            isinstance(self.required_boundary_point_count, bool)
            or not isinstance(self.required_boundary_point_count, int)
            or self.required_boundary_point_count < 0
        ):
            raise OrthogonalFilletError(
                "required boundary point count is invalid"
            )
        if (
            not isinstance(self.required_boundary_points_sha256, str)
            or len(self.required_boundary_points_sha256) != 64
            or any(
                character not in "0123456789abcdef"
                for character in self.required_boundary_points_sha256
            )
        ):
            raise OrthogonalFilletError(
                "required boundary point digest is invalid"
            )
        payload = {
            "schema": _SCHEMA,
            "cut_cell_rule": self.cut_cell_rule,
            "target_edge_mm": self.target_edge_mm,
            "x_levels_mm": self.x_levels_mm,
            "y_levels_mm": self.y_levels_mm,
            "z_levels_mm": self.z_levels_mm,
            "candidate_cell_count": self.candidate_cell_count,
            "analytic_full_cell_count": self.analytic_full_cell_count,
            "analytic_cut_cell_count": self.analytic_cut_cell_count,
            "analytic_outside_cell_count": self.analytic_outside_cell_count,
            "accepted_full_cell_count": self.accepted_full_cell_count,
            "accepted_cut_cell_count": self.accepted_cut_cell_count,
            "rejected_cut_cell_count": self.rejected_cut_cell_count,
            "locked_seam_count": self.locked_seam_count,
            "locked_seam_cell_count": self.locked_seam_cell_count,
            "locked_cut_override_count": self.locked_cut_override_count,
            "required_boundary_point_count": self.required_boundary_point_count,
            "required_boundary_points_sha256": (
                self.required_boundary_points_sha256
            ),
            "approximated_volume_mm3": self.approximated_volume_mm3,
            "analytic_volume_mm3": self.analytic_volume_mm3,
            "signed_volume_error_mm3": self.signed_volume_error_mm3,
            "absolute_volume_error_mm3": self.absolute_volume_error_mm3,
            "relative_volume_error": self.relative_volume_error,
            "maximum_generated_edge_mm": self.maximum_generated_edge_mm,
            "target_geometry_sha256": self.target_geometry_sha256,
            "mesh_sha256": self.mesh_sha256,
            "mesh_warnings": self.mesh_warnings,
        }
        object.__setattr__(self, "evidence_sha256", _digest(payload))


@dataclass(frozen=True, slots=True)
class OrthogonalFilletMesh:
    nodes: tuple[OrthogonalHexNode, ...]
    elements: tuple[OrthogonalHexElement, ...]
    boundary_facets: tuple[OrthogonalBoundaryFacet, ...]
    audit: OrthogonalFilletAudit
    candidate_xy_cells_mm: tuple[tuple[tuple[float, float], tuple[float, float]], ...] = ()

    @property
    def locked_boundary_facets(self) -> tuple[OrthogonalBoundaryFacet, ...]:
        return tuple(
            facet for facet in self.boundary_facets if facet.locked_seam_ids
        )

    def boundary_facets_for_side(
        self,
        side: OrthogonalBoundarySide,
    ) -> tuple[OrthogonalBoundaryFacet, ...]:
        if not isinstance(side, OrthogonalBoundarySide):
            raise OrthogonalFilletError("boundary side is invalid")
        return tuple(facet for facet in self.boundary_facets if facet.side is side)


@dataclass(frozen=True, slots=True)
class OrthogonalMultiblockFilletAudit:
    """Evidence for the chain-preserving eight-block Cartesian backend."""

    cut_cell_rule: str
    target_edge_mm: float
    near_edge_mm: float
    shared_surface_id: str | None
    side_tangential_levels_mm: tuple[tuple[str, tuple[float, ...]], ...]
    radial_offsets_mm: tuple[float, ...]
    z_levels_mm: tuple[float, ...]
    block_count: int
    chain_count: int
    chain_segment_count: int
    matched_chain_segment_count: int
    chain_sha256: str
    candidate_cell_count: int
    analytic_full_cell_count: int
    analytic_cut_cell_count: int
    analytic_outside_cell_count: int
    accepted_full_cell_count: int
    accepted_cut_cell_count: int
    rejected_cut_cell_count: int
    base_shared_quad_count: int
    locked_cut_override_count: int
    boundary_facet_count: int
    boundary_edge_count: int
    boundary_edge_owner_min: int
    boundary_edge_owner_max: int
    connected_element_component_count: int
    approximated_volume_mm3: float
    analytic_volume_mm3: float
    signed_volume_error_mm3: float
    absolute_volume_error_mm3: float
    relative_volume_error: float
    maximum_generated_edge_mm: float
    target_geometry_sha256: str
    mesh_sha256: str
    side_normal_offsets_mm: tuple[tuple[str, tuple[float, ...]], ...] = ()
    immutable_target_edge_override_count: int = 0
    immutable_maximum_edge_mm: float = 0.0
    authoritative_base_override_count: int = 0
    active_xy_cell_count_by_layer: tuple[int, ...] = ()
    active_xy_sets_nested: bool = True
    actual_maximum_z_mm: float = 0.0
    mesh_warnings: tuple[dict[str, object], ...] = ()
    evidence_sha256: str = field(init=False)

    def __post_init__(self) -> None:
        if self.block_count != 8:
            raise OrthogonalFilletError("multiblock fillet must contain eight blocks")
        if self.chain_count != 4:
            raise OrthogonalFilletError(
                "multiblock fillet must contain four boundary chains"
            )
        # Centre sampling may remove candidate chain segments or yield a
        # non-manifold boundary. Located warnings describe these outcomes.
        if not self.active_xy_sets_nested:
            raise OrthogonalFilletError(
                "multiblock active XY cells are not nested along the taper"
            )
        if any(
            next_count > current_count
            for current_count, next_count in zip(
                self.active_xy_cell_count_by_layer,
                self.active_xy_cell_count_by_layer[1:],
            )
        ):
            raise OrthogonalFilletError(
                "multiblock active XY cell count grows along a narrowing taper"
            )
        payload = {
            "schema": _MULTIBLOCK_SCHEMA,
            "cut_cell_rule": self.cut_cell_rule,
            "target_edge_mm": self.target_edge_mm,
            "near_edge_mm": self.near_edge_mm,
            "shared_surface_id": self.shared_surface_id,
            "side_tangential_levels_mm": self.side_tangential_levels_mm,
            "radial_offsets_mm": self.radial_offsets_mm,
            "z_levels_mm": self.z_levels_mm,
            "block_count": self.block_count,
            "chain_count": self.chain_count,
            "chain_segment_count": self.chain_segment_count,
            "matched_chain_segment_count": self.matched_chain_segment_count,
            "chain_sha256": self.chain_sha256,
            "candidate_cell_count": self.candidate_cell_count,
            "analytic_full_cell_count": self.analytic_full_cell_count,
            "analytic_cut_cell_count": self.analytic_cut_cell_count,
            "analytic_outside_cell_count": self.analytic_outside_cell_count,
            "accepted_full_cell_count": self.accepted_full_cell_count,
            "accepted_cut_cell_count": self.accepted_cut_cell_count,
            "rejected_cut_cell_count": self.rejected_cut_cell_count,
            "base_shared_quad_count": self.base_shared_quad_count,
            "locked_cut_override_count": self.locked_cut_override_count,
            "boundary_facet_count": self.boundary_facet_count,
            "boundary_edge_count": self.boundary_edge_count,
            "boundary_edge_owner_min": self.boundary_edge_owner_min,
            "boundary_edge_owner_max": self.boundary_edge_owner_max,
            "connected_element_component_count": (
                self.connected_element_component_count
            ),
            "approximated_volume_mm3": self.approximated_volume_mm3,
            "analytic_volume_mm3": self.analytic_volume_mm3,
            "signed_volume_error_mm3": self.signed_volume_error_mm3,
            "absolute_volume_error_mm3": self.absolute_volume_error_mm3,
            "relative_volume_error": self.relative_volume_error,
            "maximum_generated_edge_mm": self.maximum_generated_edge_mm,
            "target_geometry_sha256": self.target_geometry_sha256,
            "mesh_sha256": self.mesh_sha256,
            "side_normal_offsets_mm": self.side_normal_offsets_mm,
            "immutable_target_edge_override_count": (
                self.immutable_target_edge_override_count
            ),
            "immutable_maximum_edge_mm": self.immutable_maximum_edge_mm,
            "authoritative_base_override_count": (
                self.authoritative_base_override_count
            ),
            "active_xy_cell_count_by_layer": (
                self.active_xy_cell_count_by_layer
            ),
            "active_xy_sets_nested": self.active_xy_sets_nested,
            "actual_maximum_z_mm": self.actual_maximum_z_mm,
            "mesh_warnings": self.mesh_warnings,
        }
        object.__setattr__(self, "evidence_sha256", _digest(payload))


@dataclass(frozen=True, slots=True)
class OrthogonalMultiblockFilletMesh:
    """Pure HEX8 fillet whose four die-edge chains remain unsplit."""

    nodes: tuple[OrthogonalHexNode, ...]
    elements: tuple[OrthogonalHexElement, ...]
    boundary_facets: tuple[OrthogonalBoundaryFacet, ...]
    audit: OrthogonalMultiblockFilletAudit
    candidate_xy_cells_mm: tuple[tuple[tuple[float, float], tuple[float, float]], ...] = ()

    @property
    def locked_boundary_facets(self) -> tuple[OrthogonalBoundaryFacet, ...]:
        return tuple(
            facet for facet in self.boundary_facets if facet.locked_seam_ids
        )

    def boundary_facets_for_side(
        self,
        side: OrthogonalBoundarySide,
    ) -> tuple[OrthogonalBoundaryFacet, ...]:
        if not isinstance(side, OrthogonalBoundarySide):
            raise OrthogonalFilletError("boundary side is invalid")
        return tuple(facet for facet in self.boundary_facets if facet.side is side)


@dataclass(frozen=True, slots=True)
class _ValidatedQuad:
    seam_id: str
    kind: str
    side: OrthogonalBoundarySide
    points: tuple[tuple[float, float, float], ...]
    constant_axis: int
    spans: tuple[tuple[int, tuple[float, float]], ...]


@dataclass(frozen=True, slots=True)
class _ValidatedBoundaryChain:
    chain_id: str
    side: OrthogonalBoundarySide
    points: tuple[tuple[float, float, float], ...]
    tangent_axis: int
    tangential_levels_mm: tuple[float, ...]
    segment_keys: tuple[
        tuple[
            tuple[float, float, float],
            tuple[float, float, float],
        ],
        ...,
    ]


@dataclass(frozen=True, slots=True)
class _ValidatedWallPartitions:
    """Four complete side-local Cartesian partitions and their common edges."""

    chains: tuple[_ValidatedBoundaryChain, ...]
    z_levels_mm: tuple[float, ...]
    locked_seam_ids_by_face: Mapping[
        tuple[tuple[float, float, float], ...], tuple[str, ...]
    ]
    target_override_edge_count: int
    maximum_locked_edge_mm: float


@dataclass(frozen=True, slots=True)
class _ValidatedBasePartition:
    """One complete two-cycle, eight-block Cartesian endpoint complex."""

    chains: tuple[_ValidatedBoundaryChain, ...]
    planar_cells: tuple[
        tuple[
            int,
            int,
            tuple[tuple[float, float], tuple[float, float]],
        ],
        ...,
    ]
    normal_offsets_by_side: Mapping[
        OrthogonalBoundarySide, tuple[float, ...]
    ]
    locked_seam_ids_by_face: Mapping[
        tuple[tuple[float, float, float], ...], tuple[str, ...]
    ]
    locked_seam_ids_by_bounds: Mapping[
        tuple[tuple[float, float], tuple[float, float]], tuple[str, ...]
    ]
    target_override_edge_count: int
    maximum_locked_edge_mm: float


def _finite(value: object, *, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise OrthogonalFilletError(f"{field_name} must be numeric")
    result = float(value)
    if not math.isfinite(result):
        raise OrthogonalFilletError(f"{field_name} must be finite")
    return result


def _positive(value: object, *, field_name: str) -> float:
    result = _finite(value, field_name=field_name)
    if result <= 0.0:
        raise OrthogonalFilletError(f"{field_name} must be positive")
    return result


def _point3(value: object, *, field_name: str) -> tuple[float, float, float]:
    if isinstance(value, (str, bytes)):
        raise OrthogonalFilletError(f"{field_name} must contain three numbers")
    try:
        raw = tuple(value)  # type: ignore[arg-type]
    except TypeError as error:
        raise OrthogonalFilletError(
            f"{field_name} must contain three numbers"
        ) from error
    if len(raw) != 3:
        raise OrthogonalFilletError(f"{field_name} must contain three numbers")
    return tuple(
        _finite(item, field_name=f"{field_name}[{index}]")
        for index, item in enumerate(raw)
    )  # type: ignore[return-value]


def _digest(value: object) -> str:
    encoded = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _key(value: float) -> float:
    return round(float(value), 12)


def _point_key(point: Sequence[float]) -> tuple[float, float, float]:
    return tuple(_key(value) for value in point)  # type: ignore[return-value]


def _face_key(
    points: Iterable[Sequence[float]],
) -> tuple[tuple[float, float, float], ...]:
    return tuple(sorted(_point_key(point) for point in points))


def _close(first: float, second: float, tolerance: float) -> bool:
    return math.isclose(first, second, rel_tol=0.0, abs_tol=tolerance)


def _width_at_z(
    root: CanonicalRectangularUnderfillFillet,
    z_value: float,
) -> float:
    fraction = (z_value - root.base_z_mm) / root.wall_height_mm
    return root.toe_width_mm + fraction * (
        root.top_width_mm - root.toe_width_mm
    )


def _outside_distance(
    root: CanonicalRectangularUnderfillFillet,
    x_value: float,
    y_value: float,
) -> float:
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    dx = max(x0 - x_value, 0.0, x_value - x1)
    dy = max(y0 - y_value, 0.0, y_value - y1)
    return math.hypot(dx, dy)


def _outside_open_die(
    root: CanonicalRectangularUnderfillFillet,
    x_value: float,
    y_value: float,
    tolerance: float,
) -> bool:
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    return (
        x_value <= x0 + tolerance
        or x_value >= x1 - tolerance
        or y_value <= y0 + tolerance
        or y_value >= y1 - tolerance
    )


def _contains_point(
    root: CanonicalRectangularUnderfillFillet,
    point: Sequence[float],
    tolerance: float,
) -> bool:
    x_value, y_value, z_value = point
    z0 = root.base_z_mm
    z1 = z0 + root.wall_height_mm
    return (
        z0 - tolerance <= z_value <= z1 + tolerance
        and _outside_open_die(root, x_value, y_value, tolerance)
        and _outside_distance(root, x_value, y_value)
        <= _width_at_z(root, min(max(z_value, z0), z1)) + tolerance
    )


def _analytic_boundary_names(
    root: CanonicalRectangularUnderfillFillet,
    point: Sequence[float],
    tolerance: float,
) -> frozenset[str]:
    x_value, y_value, z_value = point
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    z0 = root.base_z_mm
    z1 = z0 + root.wall_height_mm
    if z_value < z0 - tolerance or z_value > z1 + tolerance:
        return frozenset()
    clamped_z = min(max(z_value, z0), z1)
    width = _width_at_z(root, clamped_z)
    outside_die = _outside_open_die(
        root,
        x_value,
        y_value,
        tolerance,
    )
    distance = _outside_distance(root, x_value, y_value)
    in_cross_section = outside_die and distance <= width + tolerance
    names: set[str] = set()
    if _close(z_value, z0, tolerance) and in_cross_section:
        names.add("base")
    if _close(z_value, z1, tolerance) and in_cross_section:
        names.add("cap")
    wall_specs = (
        ("die_x_min", 0, x0, 1, (y0, y1)),
        ("die_x_max", 0, x1, 1, (y0, y1)),
        ("die_y_min", 1, y0, 0, (x0, x1)),
        ("die_y_max", 1, y1, 0, (x0, x1)),
    )
    for name, axis, coordinate, tangent, tangent_bounds in wall_specs:
        if (
            _close(point[axis], coordinate, tolerance)
            and tangent_bounds[0] - tolerance
            <= point[tangent]
            <= tangent_bounds[1] + tolerance
        ):
            names.add(name)
    if outside_die and _close(distance, width, tolerance):
        names.add("analytic_free_surface")
    return frozenset(names)


def _validate_required_boundary_points(
    root: CanonicalRectangularUnderfillFillet,
    values: Sequence[Sequence[float]],
    tolerance: float,
) -> tuple[tuple[float, float, float], ...]:
    if isinstance(values, (str, bytes)):
        raise OrthogonalFilletError(
            "required_boundary_points must be a sequence of target-local points"
        )
    try:
        raw_points = tuple(values)
    except TypeError as error:
        raise OrthogonalFilletError(
            "required_boundary_points must be a sequence of target-local points"
        ) from error
    canonical: list[tuple[float, float, float]] = []
    seen: set[tuple[float, float, float]] = set()
    for index, raw_point in enumerate(raw_points):
        point = _point3(
            raw_point,
            field_name=f"required_boundary_points[{index}]",
        )
        key = _point_key(point)
        if key in seen:
            raise OrthogonalFilletError(
                "required_boundary_points contains a duplicate coordinate"
            )
        seen.add(key)
        if not _analytic_boundary_names(root, key, tolerance):
            raise OrthogonalFilletError(
                f"required boundary point {key!r} is not on the analytic fillet "
                "boundary"
            )
        canonical.append(key)
    return tuple(sorted(canonical))


def _validate_required_cartesian_points(
    root: CanonicalRectangularUnderfillFillet,
    values: Sequence[Sequence[float]],
    tolerance: float,
) -> tuple[tuple[float, float, float], ...]:
    """Validate grid anchors that may lie inside the retained-cell union.

    These points are deliberately weaker than ``required_boundary_points``:
    they contribute Cartesian levels but do not assert surface ownership or
    alter the CUT rule.  The preserved-orthogonal materializer uses them to
    make an already accepted Cartesian HEX8 pattern a subset of this
    backend's grid without splitting or replacing that pattern.
    """

    if isinstance(values, (str, bytes)):
        raise OrthogonalFilletError(
            "required_cartesian_points must be a sequence of target-local points"
        )
    try:
        raw_points = tuple(values)
    except TypeError as error:
        raise OrthogonalFilletError(
            "required_cartesian_points must be a sequence of target-local points"
        ) from error
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    lower = (x0 - root.toe_width_mm, y0 - root.toe_width_mm, root.base_z_mm)
    upper = (
        x1 + root.toe_width_mm,
        y1 + root.toe_width_mm,
        root.base_z_mm + root.wall_height_mm,
    )
    canonical: list[tuple[float, float, float]] = []
    seen: set[tuple[float, float, float]] = set()
    for index, raw_point in enumerate(raw_points):
        point = _point3(
            raw_point,
            field_name=f"required_cartesian_points[{index}]",
        )
        key = _point_key(point)
        if key in seen:
            raise OrthogonalFilletError(
                "required_cartesian_points contains a duplicate coordinate"
            )
        seen.add(key)
        if any(
            key[axis] < lower[axis] - tolerance
            or key[axis] > upper[axis] + tolerance
            for axis in range(3)
        ):
            raise OrthogonalFilletError(
                f"required Cartesian point {key!r} is outside the fillet "
                "Cartesian envelope"
            )
        canonical.append(key)
    return tuple(sorted(canonical))


def _cell_vertices(
    bounds: Sequence[tuple[float, float]],
) -> tuple[tuple[float, float, float], ...]:
    x_bounds, y_bounds, z_bounds = bounds
    return (
        (x_bounds[0], y_bounds[0], z_bounds[0]),
        (x_bounds[1], y_bounds[0], z_bounds[0]),
        (x_bounds[1], y_bounds[1], z_bounds[0]),
        (x_bounds[0], y_bounds[1], z_bounds[0]),
        (x_bounds[0], y_bounds[0], z_bounds[1]),
        (x_bounds[1], y_bounds[0], z_bounds[1]),
        (x_bounds[1], y_bounds[1], z_bounds[1]),
        (x_bounds[0], y_bounds[1], z_bounds[1]),
    )


def _cell_overlaps_open_die(
    root: CanonicalRectangularUnderfillFillet,
    bounds: Sequence[tuple[float, float]],
    tolerance: float,
) -> bool:
    x_bounds, y_bounds, _z_bounds = bounds
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    return (
        x_bounds[1] > x0 + tolerance
        and x_bounds[0] < x1 - tolerance
        and y_bounds[1] > y0 + tolerance
        and y_bounds[0] < y1 - tolerance
    )


def _cell_has_external_xy_volume(
    root: CanonicalRectangularUnderfillFillet,
    bounds: Sequence[tuple[float, float]],
    tolerance: float,
) -> bool:
    x_bounds, y_bounds, _z_bounds = bounds
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    return (
        x_bounds[0] < x0 - tolerance
        or x_bounds[1] > x1 + tolerance
        or y_bounds[0] < y0 - tolerance
        or y_bounds[1] > y1 + tolerance
    )


def _minimum_cell_distance(
    root: CanonicalRectangularUnderfillFillet,
    bounds: Sequence[tuple[float, float]],
) -> float:
    x_bounds, y_bounds, _z_bounds = bounds
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    dx = max(x0 - x_bounds[1], x_bounds[0] - x1, 0.0)
    dy = max(y0 - y_bounds[1], y_bounds[0] - y1, 0.0)
    return math.hypot(dx, dy)


def _classify_cell(
    root: CanonicalRectangularUnderfillFillet,
    bounds: Sequence[tuple[float, float]],
    tolerance: float,
) -> OrthogonalCellClass:
    vertices = _cell_vertices(bounds)
    if all(_contains_point(root, point, tolerance) for point in vertices) and (
        not _cell_overlaps_open_die(root, bounds, tolerance)
    ):
        return OrthogonalCellClass.FULL
    if not _cell_has_external_xy_volume(root, bounds, tolerance):
        return OrthogonalCellClass.OUTSIDE
    minimum_distance = _minimum_cell_distance(root, bounds)
    maximum_width = _width_at_z(root, bounds[2][0])
    if minimum_distance < maximum_width - tolerance:
        return OrthogonalCellClass.CUT
    return OrthogonalCellClass.OUTSIDE


def _cell_center_inside(
    root: CanonicalRectangularUnderfillFillet,
    bounds: Sequence[tuple[float, float]],
    tolerance: float,
) -> bool:
    center = tuple(0.5 * (lower + upper) for lower, upper in bounds)
    return _contains_point(root, center, tolerance)


def _analytic_volume(root: CanonicalRectangularUnderfillFillet) -> float:
    perimeter = 2.0 * (root.die_size_xy_mm[0] + root.die_size_xy_mm[1])
    toe = root.toe_width_mm
    top = root.top_width_mm
    return root.wall_height_mm * (
        0.5 * perimeter * (toe + top)
        + math.pi * (toe * toe + toe * top + top * top) / 3.0
    )


def _quad_rectangle(
    quad: LockedCartesianQuad,
    *,
    tolerance: float,
) -> tuple[int, tuple[tuple[int, tuple[float, float]], ...]]:
    points = quad.target_local_points_mm
    unique_by_axis = tuple(
        tuple(sorted({_key(point[axis]) for point in points}))
        for axis in range(3)
    )
    constant_axes = tuple(
        axis for axis, values in enumerate(unique_by_axis) if len(values) == 1
    )
    varying_axes = tuple(
        axis for axis, values in enumerate(unique_by_axis) if len(values) == 2
    )
    if len(constant_axes) != 1 or len(varying_axes) != 2:
        raise OrthogonalFilletError(
            f"locked QUAD {quad.seam_id!r} is not axis-aligned"
        )
    constant_axis = constant_axes[0]
    expected = {
        tuple(coordinates)  # type: ignore[arg-type]
        for coordinates in product(*unique_by_axis)
    }
    if {_point_key(point) for point in points} != expected:
        raise OrthogonalFilletError(
            f"locked QUAD {quad.seam_id!r} is not a complete rectangle"
        )
    spans = tuple(
        (axis, (values[0], values[1]))
        for axis, values in enumerate(unique_by_axis)
        if axis != constant_axis
    )
    if any(upper - lower <= tolerance for _axis, (lower, upper) in spans):
        raise OrthogonalFilletError(
            f"locked QUAD {quad.seam_id!r} has zero area"
        )
    return constant_axis, spans


def _quad_has_positive_cross_section_overlap(
    root: CanonicalRectangularUnderfillFillet,
    points: Sequence[Sequence[float]],
    width: float,
    tolerance: float,
) -> bool:
    x_bounds = (
        min(point[0] for point in points),
        max(point[0] for point in points),
    )
    y_bounds = (
        min(point[1] for point in points),
        max(point[1] for point in points),
    )
    dummy = (x_bounds, y_bounds, (root.base_z_mm, root.base_z_mm))
    return (
        width > tolerance
        and _cell_has_external_xy_volume(root, dummy, tolerance)
        and not _cell_overlaps_open_die(root, dummy, tolerance)
        and _minimum_cell_distance(root, dummy) < width - tolerance
    )


def _validate_locked_quads(
    root: CanonicalRectangularUnderfillFillet,
    target_edge: float,
    base_quads: Sequence[LockedCartesianQuad],
    cap_quads: Sequence[LockedCartesianQuad],
    die_wall_quads: Sequence[LockedCartesianQuad],
    tolerance: float,
) -> tuple[_ValidatedQuad, ...]:
    groups = (
        ("base", OrthogonalBoundarySide.BASE, tuple(base_quads)),
        ("cap", OrthogonalBoundarySide.CAP, tuple(cap_quads)),
        ("die_wall", None, tuple(die_wall_quads)),
    )
    seen_ids: set[str] = set()
    output: list[_ValidatedQuad] = []
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    z0 = root.base_z_mm
    z1 = z0 + root.wall_height_mm
    for kind, fixed_side, values in groups:
        for quad in values:
            if type(quad) is not LockedCartesianQuad:
                raise OrthogonalFilletError(
                    "locked seam entries must be exact LockedCartesianQuad"
                )
            if quad.seam_id in seen_ids:
                raise OrthogonalFilletError(
                    f"locked QUAD seam_id {quad.seam_id!r} is duplicated"
                )
            seen_ids.add(quad.seam_id)
            constant_axis, spans = _quad_rectangle(quad, tolerance=tolerance)
            points = quad.target_local_points_mm
            side = fixed_side
            if kind == "base":
                if constant_axis != 2 or not all(
                    _close(point[2], z0, tolerance) for point in points
                ):
                    raise OrthogonalFilletError(
                        f"locked base QUAD {quad.seam_id!r} is not on base_z"
                    )
                if not _quad_has_positive_cross_section_overlap(
                    root, points, root.toe_width_mm, tolerance
                ):
                    raise OrthogonalFilletError(
                        f"locked base QUAD {quad.seam_id!r} has no positive "
                        "analytic interface overlap"
                    )
            elif kind == "cap":
                if constant_axis != 2 or not all(
                    _close(point[2], z1, tolerance) for point in points
                ):
                    raise OrthogonalFilletError(
                        f"locked cap QUAD {quad.seam_id!r} is not on the cap"
                    )
                if not _quad_has_positive_cross_section_overlap(
                    root, points, root.top_width_mm, tolerance
                ):
                    raise OrthogonalFilletError(
                        f"locked cap QUAD {quad.seam_id!r} has no positive "
                        "analytic interface overlap"
                    )
            else:
                specifications = (
                    (OrthogonalBoundarySide.DIE_X_MIN, 0, x0, 1, (y0, y1)),
                    (OrthogonalBoundarySide.DIE_X_MAX, 0, x1, 1, (y0, y1)),
                    (OrthogonalBoundarySide.DIE_Y_MIN, 1, y0, 0, (x0, x1)),
                    (OrthogonalBoundarySide.DIE_Y_MAX, 1, y1, 0, (x0, x1)),
                )
                side = None
                for candidate, axis, coordinate, tangent, tangent_bounds in specifications:
                    if constant_axis != axis or not all(
                        _close(point[axis], coordinate, tolerance)
                        for point in points
                    ):
                        continue
                    tangent_values = tuple(point[tangent] for point in points)
                    z_values = tuple(point[2] for point in points)
                    if (
                        min(tangent_values) >= tangent_bounds[0] - tolerance
                        and max(tangent_values) <= tangent_bounds[1] + tolerance
                        and min(z_values) >= z0 - tolerance
                        and max(z_values) <= z1 + tolerance
                    ):
                        side = candidate
                        break
                if side is None:
                    raise OrthogonalFilletError(
                        f"locked die-wall QUAD {quad.seam_id!r} is not on one "
                        "analytic die wall"
                    )
            assert side is not None
            output.append(
                _ValidatedQuad(
                    quad.seam_id,
                    kind,
                    side,
                    tuple(points),
                    constant_axis,
                    spans,
                )
            )
    return tuple(output)


def _axis_levels(
    anchors: Iterable[float],
    protected_spans: Iterable[tuple[float, float]],
    target_edge: float,
    tolerance: float,
    *,
    axis_name: str,
    origin: float | None = None,
    negative_size: float | None = None,
    positive_size: float | None = None,
    sizing: MeshSeedPolicy = MeshSeedPolicy(),
) -> tuple[float, ...]:
    canonical_anchors = tuple(sorted({_key(value) for value in anchors}))
    protected = {
        (_key(lower), _key(upper))
        for lower, upper in protected_spans
    }
    if (origin is not None and canonical_anchors[0] < origin < canonical_anchors[-1]
            and not any(a+tolerance < origin < b-tolerance for a,b in protected)):
        canonical_anchors = tuple(sorted({*canonical_anchors, _key(origin)}))
    for lower, upper in protected:
        interior = tuple(
            value
            for value in canonical_anchors
            if lower + tolerance < value < upper - tolerance
        )
        if interior:
            raise OrthogonalFilletError(
                f"locked QUAD grid has a T-junction on {axis_name}: protected "
                f"span {(lower, upper)!r} contains anchors {interior!r}"
            )
    levels = [canonical_anchors[0]]
    for lower, upper in zip(canonical_anchors, canonical_anchors[1:]):
        distance = upper - lower
        if distance <= tolerance:
            continue
        is_protected = (lower, upper) in protected
        if is_protected:
            levels.append(upper)
        else:
            levels.extend(interval_levels(lower,upper,negative_size or target_edge,
                positive_size or target_edge,lower if origin is None else origin,sizing)[1:])
    return tuple(levels)


def _coordinate_index(levels: Sequence[float], value: float) -> int:
    key = _key(value)
    for index, candidate in enumerate(levels):
        if _key(candidate) == key:
            return index
    raise OrthogonalFilletError("locked seam coordinate is absent from grid")


def _locked_cell_index(
    quad: _ValidatedQuad,
    x_levels: Sequence[float],
    y_levels: Sequence[float],
    z_levels: Sequence[float],
) -> tuple[int, int, int]:
    levels = (x_levels, y_levels, z_levels)
    bounds_by_axis = {
        axis: span for axis, span in quad.spans
    }
    lower_indices = {
        axis: _coordinate_index(levels[axis], span[0])
        for axis, span in bounds_by_axis.items()
    }
    if quad.kind == "base":
        return lower_indices[0], lower_indices[1], 0
    if quad.kind == "cap":
        return lower_indices[0], lower_indices[1], len(z_levels) - 2
    if quad.side is OrthogonalBoundarySide.DIE_X_MIN:
        return (
            _coordinate_index(x_levels, quad.points[0][0]) - 1,
            lower_indices[1],
            lower_indices[2],
        )
    if quad.side is OrthogonalBoundarySide.DIE_X_MAX:
        return (
            _coordinate_index(x_levels, quad.points[0][0]),
            lower_indices[1],
            lower_indices[2],
        )
    if quad.side is OrthogonalBoundarySide.DIE_Y_MIN:
        return (
            lower_indices[0],
            _coordinate_index(y_levels, quad.points[0][1]) - 1,
            lower_indices[2],
        )
    return (
        lower_indices[0],
        _coordinate_index(y_levels, quad.points[0][1]),
        lower_indices[2],
    )


def _rotation_matrix(
    placement: CanonicalRigidPlacement,
) -> tuple[tuple[float, float, float], ...]:
    rx, ry, rz = (math.radians(value) for value in placement.rotation_deg_xyz)
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    matrix_x = ((1.0, 0.0, 0.0), (0.0, cx, -sx), (0.0, sx, cx))
    matrix_y = ((cy, 0.0, sy), (0.0, 1.0, 0.0), (-sy, 0.0, cy))
    matrix_z = ((cz, -sz, 0.0), (sz, cz, 0.0), (0.0, 0.0, 1.0))

    def multiply(first: Sequence[Sequence[float]], second: Sequence[Sequence[float]]):
        return tuple(
            tuple(
                math.fsum(first[row][item] * second[item][column] for item in range(3))
                for column in range(3)
            )
            for row in range(3)
        )

    return multiply(matrix_z, multiply(matrix_y, matrix_x))


def _to_package(
    point: Sequence[float],
    placement: CanonicalRigidPlacement,
    rotation: Sequence[Sequence[float]],
) -> tuple[float, float, float]:
    pivot = placement.pivot_xyz_mm
    relative = tuple(point[index] - pivot[index] for index in range(3))
    rotated = tuple(
        math.fsum(rotation[row][column] * relative[column] for column in range(3))
        for row in range(3)
    )
    return tuple(
        placement.translation_xyz_mm[index] + pivot[index] + rotated[index]
        for index in range(3)
    )  # type: ignore[return-value]


def _quad_fully_inside_cross_section(
    root: CanonicalRectangularUnderfillFillet,
    points: Sequence[Sequence[float]],
    z_value: float,
    tolerance: float,
) -> bool:
    return all(
        _outside_open_die(root, point[0], point[1], tolerance)
        and _outside_distance(root, point[0], point[1])
        <= _width_at_z(root, z_value) + tolerance
        for point in points
    )


def _boundary_side(
    root: CanonicalRectangularUnderfillFillet,
    points: Sequence[Sequence[float]],
    tolerance: float,
    locked_side: OrthogonalBoundarySide | None,
) -> OrthogonalBoundarySide:
    if locked_side is not None:
        return locked_side
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    z0 = root.base_z_mm
    z1 = z0 + root.wall_height_mm
    if all(_close(point[2], z0, tolerance) for point in points):
        return OrthogonalBoundarySide.BASE
    if all(_close(point[2], z1, tolerance) for point in points):
        if _quad_fully_inside_cross_section(root, points, z1, tolerance):
            return OrthogonalBoundarySide.CAP
        return OrthogonalBoundarySide.STAIRCASE_Z_MAX
    wall_specs = (
        (OrthogonalBoundarySide.DIE_X_MIN, 0, x0, 1, (y0, y1)),
        (OrthogonalBoundarySide.DIE_X_MAX, 0, x1, 1, (y0, y1)),
        (OrthogonalBoundarySide.DIE_Y_MIN, 1, y0, 0, (x0, x1)),
        (OrthogonalBoundarySide.DIE_Y_MAX, 1, y1, 0, (x0, x1)),
    )
    for side, axis, coordinate, tangent, tangent_bounds in wall_specs:
        if all(
            _close(point[axis], coordinate, tolerance)
            and tangent_bounds[0] - tolerance
            <= point[tangent]
            <= tangent_bounds[1] + tolerance
            for point in points
        ):
            return side
    constant_axis = next(
        axis
        for axis in range(3)
        if len({_key(point[axis]) for point in points}) == 1
    )
    coordinate = points[0][constant_axis]
    center = (
        x0 + 0.5 * root.die_size_xy_mm[0],
        y0 + 0.5 * root.die_size_xy_mm[1],
        z0 + 0.5 * root.wall_height_mm,
    )
    negative = coordinate < center[constant_axis]
    return {
        (0, True): OrthogonalBoundarySide.STAIRCASE_X_MIN,
        (0, False): OrthogonalBoundarySide.STAIRCASE_X_MAX,
        (1, True): OrthogonalBoundarySide.STAIRCASE_Y_MIN,
        (1, False): OrthogonalBoundarySide.STAIRCASE_Y_MAX,
        (2, True): OrthogonalBoundarySide.STAIRCASE_Z_MIN,
        (2, False): OrthogonalBoundarySide.STAIRCASE_Z_MAX,
    }[(constant_axis, negative)]


def mesh_rectangular_fillet_orthogonal_hex(
    target_fragment: CanonicalGeometryFragment,
    target_edge_mm: float,
    *,
    base_quads: Sequence[LockedCartesianQuad] = (),
    cap_quads: Sequence[LockedCartesianQuad] = (),
    die_wall_quads: Sequence[LockedCartesianQuad] = (),
    required_boundary_points: Sequence[Sequence[float]] = (),
    required_cartesian_points: Sequence[Sequence[float]] = (),
    orthogonal_strategy: OrthogonalHexMeshStrategy | None = None,
) -> OrthogonalFilletMesh:
    """Generate a pure Cartesian HEX8 staircase for one canonical fillet.

    ``target_edge_mm`` is a maximum interval size, not a demand for cubic
    cells.  Each geometry span is divided by ``ceil(span / target_edge)``.
    Consequently a 0.05-mm band with a 0.08-mm target has one exact 0.05-mm
    Z layer; a 0.057-mm toe span likewise has one exact 0.057-mm XY interval.
    Locked QUAD spans remain single intervals and must already be no coarser
    than the target.

    ``required_boundary_points`` contributes only Cartesian X/Y/Z levels for
    target-local boundary-node compatibility.  It neither creates a locked
    face nor changes the FULL/CUT/OUTSIDE retention decision for any cell.

    ``required_cartesian_points`` has the same grid-anchor effect but may lie
    inside the retained-cell union.  It is intended for an already validated
    package-Cartesian HEX8 propagation pattern.  It does not lock a face,
    retain a CUT cell, or authorize changing inherited connectivity.
    """

    if type(target_fragment) is not CanonicalGeometryFragment or type(
        target_fragment.root
    ) is not CanonicalRectangularUnderfillFillet:
        raise OrthogonalFilletError(
            "orthogonal fillet backend requires one canonical rectangular "
            "underfill fillet fragment"
        )
    target_edge = _positive(target_edge_mm, field_name="target_edge_mm")
    root = target_fragment.root
    scale = max(
        1.0,
        *(
            abs(value)
            for value in (
                *root.die_origin_xy_mm,
                *root.die_size_xy_mm,
                root.base_z_mm,
                root.wall_height_mm,
                root.toe_width_mm,
                root.top_width_mm,
                target_edge,
            )
        ),
    )
    tolerance = 1.0e-10 * scale
    required_points = _validate_required_boundary_points(
        root,
        required_boundary_points,
        tolerance,
    )
    required_grid_points = _validate_required_cartesian_points(
        root,
        required_cartesian_points,
        tolerance,
    )
    locked = _validate_locked_quads(
        root,
        target_edge,
        base_quads,
        cap_quads,
        die_wall_quads,
        tolerance,
    )
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    z0 = root.base_z_mm
    z1 = z0 + root.wall_height_mm
    anchors = [
        {x0 - root.toe_width_mm, x0, x1, x1 + root.toe_width_mm},
        {y0 - root.toe_width_mm, y0, y1, y1 + root.toe_width_mm},
        {z0, z1},
    ]
    for point in (*required_points, *required_grid_points):
        for axis in range(3):
            anchors[axis].add(point[axis])
    protected: list[set[tuple[float, float]]] = [set(), set(), set()]
    for quad in locked:
        for point in quad.points:
            for axis in range(3):
                anchors[axis].add(point[axis])
        for axis, span in quad.spans:
            protected[axis].add(span)
    policy = MeshSeedPolicy() if orthogonal_strategy is None else orthogonal_strategy.sizing
    origin = None if orthogonal_strategy is None else geometry_origin(root,policy,orthogonal_strategy.partition_origin_mm)
    def axis_options(axis):
        if orthogonal_strategy is None:
            return {}
        sizes = orthogonal_strategy.directional_near_edge_mm
        return dict(origin=None if origin is None else origin[axis], sizing=policy,
            negative_size=sizes[ComponentLocalDirection("negative_"+"xyz"[axis])],
            positive_size=sizes[ComponentLocalDirection("positive_"+"xyz"[axis])])
    x_levels = _axis_levels(
        anchors[0], protected[0], target_edge, tolerance, axis_name="x", **axis_options(0)
    )
    y_levels = _axis_levels(
        anchors[1], protected[1], target_edge, tolerance, axis_name="y", **axis_options(1)
    )
    z_levels = _axis_levels(
        anchors[2], protected[2], target_edge, tolerance, axis_name="z", **axis_options(2)
    )
    levels = (x_levels, y_levels, z_levels)
    seam_ids_by_cell: dict[tuple[int, int, int], list[str]] = defaultdict(list)
    seam_ids_by_face: dict[
        tuple[tuple[float, float, float], ...],
        list[str],
    ] = defaultdict(list)
    seam_side_by_face: dict[
        tuple[tuple[float, float, float], ...],
        OrthogonalBoundarySide,
    ] = {}
    for quad in locked:
        cell_index = _locked_cell_index(quad, x_levels, y_levels, z_levels)
        if any(
            value < 0 or value >= len(levels[axis]) - 1
            for axis, value in enumerate(cell_index)
        ):
            raise OrthogonalFilletError(
                f"locked QUAD {quad.seam_id!r} has no target-side cell"
            )
        seam_ids_by_cell[cell_index].append(quad.seam_id)
        face_key = _face_key(quad.points)
        seam_ids_by_face[face_key].append(quad.seam_id)
        previous_side = seam_side_by_face.setdefault(face_key, quad.side)
        if previous_side is not quad.side:
            raise OrthogonalFilletError(
                "coincident locked QUADs disagree on geometric side"
            )

    classifications = CounterLike()
    retained: list[
        tuple[
            tuple[int, int, int],
            tuple[tuple[float, float], ...],
            OrthogonalCellClass,
            OrthogonalRetentionReason,
            tuple[str, ...],
        ]
    ] = []
    locked_cut_override_count = 0
    for k in range(len(z_levels) - 1):
        for j in range(len(y_levels) - 1):
            for i in range(len(x_levels) - 1):
                cell = (i, j, k)
                bounds = (
                    (x_levels[i], x_levels[i + 1]),
                    (y_levels[j], y_levels[j + 1]),
                    (z_levels[k], z_levels[k + 1]),
                )
                classification = _classify_cell(root, bounds, tolerance)
                classifications.add(classification)
                locked_ids = tuple(sorted(seam_ids_by_cell.get(cell, ())))
                if classification is OrthogonalCellClass.FULL:
                    retained.append(
                        (
                            cell,
                            bounds,
                            classification,
                            OrthogonalRetentionReason.ANALYTIC_FULL,
                            locked_ids,
                        )
                    )
                    continue
                if classification is OrthogonalCellClass.CUT:
                    center_inside = _cell_center_inside(root, bounds, tolerance)
                    if center_inside:
                        retained.append(
                            (
                                cell,
                                bounds,
                                classification,
                                OrthogonalRetentionReason.CUT_CENTER_INSIDE,
                                locked_ids,
                            )
                        )
                    continue
    if not retained:
        raise OrthogonalFilletError(
            "orthogonal CUT rule retained no positive-volume HEX8"
        )

    rotation = _rotation_matrix(target_fragment.placement)
    node_by_key: dict[tuple[float, float, float], OrthogonalHexNode] = {}

    def node_for(point: tuple[float, float, float]) -> OrthogonalHexNode:
        key = _point_key(point)
        node = node_by_key.get(key)
        if node is None:
            node = OrthogonalHexNode(
                len(node_by_key) + 1,
                point,
                _to_package(point, target_fragment.placement, rotation),
            )
            node_by_key[key] = node
        return node

    elements: list[OrthogonalHexElement] = []
    for cell, bounds, classification, reason, locked_ids in retained:
        vertices = _cell_vertices(bounds)
        nodes_for_element = tuple(node_for(point) for point in vertices)
        volume = math.prod(upper - lower for lower, upper in bounds)
        elements.append(
            OrthogonalHexElement(
                len(elements) + 1,
                tuple(  # type: ignore[arg-type]
                    node.node_index for node in nodes_for_element
                ),
                cell,
                bounds,  # type: ignore[arg-type]
                classification,
                reason,
                locked_ids,
                volume,
            )
        )
    nodes = tuple(sorted(node_by_key.values(), key=lambda value: value.node_index))
    node_by_index = {node.node_index: node for node in nodes}
    face_owners: dict[
        tuple[tuple[float, float, float], ...],
        list[tuple[OrthogonalHexElement, int, tuple[int, int, int, int]]],
    ] = defaultdict(list)
    for element in elements:
        for face_index, face in enumerate(_HEX_FACES):
            node_indices = tuple(element.node_indices[index] for index in face)
            points = tuple(
                node_by_index[index].target_local_coordinates_mm
                for index in node_indices
            )
            face_owners[_face_key(points)].append(
                (element, face_index, node_indices)  # type: ignore[arg-type]
            )
    if any(len(owners) > 2 for owners in face_owners.values()):
        raise OrthogonalFilletError(
            "orthogonal retained-cell union contains a non-manifold face"
        )
    boundary_facets: list[OrthogonalBoundaryFacet] = []
    resolved_locked_faces: set[tuple[tuple[float, float, float], ...]] = set()
    for key in sorted(face_owners):
        owners = face_owners[key]
        if len(owners) != 1:
            continue
        element, local_face_index, node_indices = owners[0]
        points = tuple(
            node_by_index[index].target_local_coordinates_mm
            for index in node_indices
        )
        locked_ids = tuple(sorted(seam_ids_by_face.get(key, ())))
        locked_side = seam_side_by_face.get(key)
        if locked_ids:
            resolved_locked_faces.add(key)
        boundary_facets.append(
            OrthogonalBoundaryFacet(
                _boundary_side(root, points, tolerance, locked_side),
                node_indices,
                element.element_index,
                local_face_index,
                locked_ids,
            )
        )
    # Anchors constrain candidate coordinates. Their incident cells may all
    # be unassigned after centre sampling, so final nodes need not contain them.

    approximated_volume = math.fsum(element.volume_mm3 for element in elements)
    analytic_volume = _analytic_volume(root)
    signed_error = approximated_volume - analytic_volume
    maximum_edge = max(
        upper - lower
        for axis_levels in levels
        for lower, upper in zip(axis_levels, axis_levels[1:])
    )
    target_geometry_payload = {
        "fragment_id": target_fragment.fragment_id,
        "die_origin_xy_mm": root.die_origin_xy_mm,
        "die_size_xy_mm": root.die_size_xy_mm,
        "base_z_mm": root.base_z_mm,
        "wall_height_mm": root.wall_height_mm,
        "toe_width_mm": root.toe_width_mm,
        "top_width_mm": root.top_width_mm,
        "placement": {
            "translation_xyz_mm": target_fragment.placement.translation_xyz_mm,
            "rotation_deg_xyz": target_fragment.placement.rotation_deg_xyz,
            "pivot_xyz_mm": target_fragment.placement.pivot_xyz_mm,
        },
    }
    mesh_payload = {
        "nodes": [
            (node.node_index, node.target_local_coordinates_mm)
            for node in nodes
        ],
        "elements": [
            (
                element.element_index,
                element.node_indices,
                element.analytic_class.value,
                element.retention_reason.value,
                element.locked_seam_ids,
            )
            for element in elements
        ],
        "boundary_facets": [
            (
                facet.side.value,
                facet.node_indices,
                facet.owner_element_index,
                facet.owner_local_face_index,
                facet.locked_seam_ids,
            )
            for facet in boundary_facets
        ],
    }
    accepted_full_count = sum(
        element.analytic_class is OrthogonalCellClass.FULL
        for element in elements
    )
    accepted_cut_count = sum(
        element.analytic_class is OrthogonalCellClass.CUT
        for element in elements
    )
    audit = OrthogonalFilletAudit(
        _CUT_RULE,
        target_edge,
        x_levels,
        y_levels,
        z_levels,
        classifications.total,
        classifications[OrthogonalCellClass.FULL],
        classifications[OrthogonalCellClass.CUT],
        classifications[OrthogonalCellClass.OUTSIDE],
        accepted_full_count,
        accepted_cut_count,
        classifications[OrthogonalCellClass.CUT] - accepted_cut_count,
        len(locked),
        len(seam_ids_by_cell),
        locked_cut_override_count,
        len(required_points),
        _digest(required_points),
        approximated_volume,
        analytic_volume,
        signed_error,
        abs(signed_error),
        abs(signed_error) / analytic_volume,
        maximum_edge,
        _digest(target_geometry_payload),
        _digest(mesh_payload),
        mesh_warnings=_mesh_topology_warnings(target_fragment, nodes, elements, face_owners),
    )
    return OrthogonalFilletMesh(
        nodes,
        tuple(elements),
        tuple(boundary_facets),
        audit,
        tuple(
            ((xl, xu), (yl, yu))
            for xl, xu in zip(x_levels, x_levels[1:])
            for yl, yu in zip(y_levels, y_levels[1:])
            if not _cell_overlaps_open_die(root, ((xl, xu), (yl, yu), (z0, z1)), tolerance)
        ),
    )


def _edge_key(
    first: Sequence[float],
    second: Sequence[float],
) -> tuple[tuple[float, float, float], tuple[float, float, float]]:
    endpoints = sorted((_point_key(first), _point_key(second)))
    return endpoints[0], endpoints[1]


def _validate_boundary_chains(
    root: CanonicalRectangularUnderfillFillet,
    boundary_chains: Sequence[LockedCartesianBoundaryChain],
    target_edge: float,
    tolerance: float,
) -> tuple[_ValidatedBoundaryChain, ...]:
    if isinstance(boundary_chains, (str, bytes)):
        raise OrthogonalFilletError(
            "base_boundary_chains must contain four exact boundary chains"
        )
    try:
        values = tuple(boundary_chains)
    except TypeError as error:
        raise OrthogonalFilletError(
            "base_boundary_chains must contain four exact boundary chains"
        ) from error
    if len(values) != 4:
        raise OrthogonalFilletError(
            "multiblock shared base requires exactly four boundary chains"
        )

    x0, y0 = (_key(value) for value in root.die_origin_xy_mm)
    x1 = _key(x0 + root.die_size_xy_mm[0])
    y1 = _key(y0 + root.die_size_xy_mm[1])
    z0 = _key(root.base_z_mm)
    specifications = {
        OrthogonalBoundarySide.DIE_X_MIN: (0, x0, 1, (y0, y1)),
        OrthogonalBoundarySide.DIE_X_MAX: (0, x1, 1, (y0, y1)),
        OrthogonalBoundarySide.DIE_Y_MIN: (1, y0, 0, (x0, x1)),
        OrthogonalBoundarySide.DIE_Y_MAX: (1, y1, 0, (x0, x1)),
    }
    seen_ids: set[str] = set()
    seen_sides: set[OrthogonalBoundarySide] = set()
    validated: list[_ValidatedBoundaryChain] = []
    for value in values:
        if type(value) is not LockedCartesianBoundaryChain:
            raise OrthogonalFilletError(
                "base boundary entries must be exact LockedCartesianBoundaryChain"
            )
        if value.chain_id in seen_ids:
            raise OrthogonalFilletError(
                f"boundary chain_id {value.chain_id!r} is duplicated"
            )
        if value.die_wall_side in seen_sides:
            raise OrthogonalFilletError(
                f"boundary side {value.die_wall_side.value!r} is duplicated"
            )
        seen_ids.add(value.chain_id)
        seen_sides.add(value.die_wall_side)
        constant_axis, coordinate, tangent_axis, tangent_bounds = specifications[
            value.die_wall_side
        ]
        points = tuple(_point_key(point) for point in value.target_local_points_mm)
        for point in points:
            if point[constant_axis] != coordinate:
                raise OrthogonalFilletError(
                    f"boundary chain {value.chain_id!r} is not on its declared "
                    "die-wall side"
                )
            if point[2] != z0:
                raise OrthogonalFilletError(
                    f"boundary chain {value.chain_id!r} is not on fillet base_z"
                )
            tangent = point[tangent_axis]
            if not (
                tangent_bounds[0] - tolerance
                <= tangent
                <= tangent_bounds[1] + tolerance
            ):
                raise OrthogonalFilletError(
                    f"boundary chain {value.chain_id!r} exceeds its die edge"
                )
        tangent_values = tuple(point[tangent_axis] for point in points)
        deltas = tuple(
            second - first
            for first, second in zip(tangent_values, tangent_values[1:])
        )
        if all(delta > tolerance for delta in deltas):
            pass
        elif all(delta < -tolerance for delta in deltas):
            points = tuple(reversed(points))
            tangent_values = tuple(reversed(tangent_values))
            deltas = tuple(-delta for delta in reversed(deltas))
        else:
            raise OrthogonalFilletError(
                f"boundary chain {value.chain_id!r} is not strictly monotone"
            )
        if not (
            tangent_values[0] == tangent_bounds[0]
            and tangent_values[-1] == tangent_bounds[1]
        ):
            raise OrthogonalFilletError(
                f"boundary chain {value.chain_id!r} does not cover the complete "
                "die edge"
            )
        segment_keys = tuple(
            _edge_key(first, second)
            for first, second in zip(points, points[1:])
        )
        validated.append(
            _ValidatedBoundaryChain(
                value.chain_id,
                value.die_wall_side,
                points,
                tangent_axis,
                tuple(_key(item) for item in tangent_values),
                segment_keys,
            )
        )
    missing = set(specifications) - seen_sides
    if missing:
        raise OrthogonalFilletError(
            "multiblock shared base is missing die-wall sides: "
            f"{tuple(sorted(side.value for side in missing))!r}"
        )
    order = {
        OrthogonalBoundarySide.DIE_X_MIN: 0,
        OrthogonalBoundarySide.DIE_X_MAX: 1,
        OrthogonalBoundarySide.DIE_Y_MIN: 2,
        OrthogonalBoundarySide.DIE_Y_MAX: 3,
    }
    return tuple(sorted(validated, key=lambda item: order[item.side]))


def _validated_wall_partitions(
    root: CanonicalRectangularUnderfillFillet,
    quads: Sequence[_ValidatedQuad],
    target_edge: float,
    tolerance: float,
) -> _ValidatedWallPartitions:
    """Prove four independent, complete side tensors with one edge trace.

    Tangential coordinates stay local to their owning side.  Only the Z
    coordinates on the four physical die-corner edges are required to agree.
    This is the exact compatibility needed by the four side strips and four
    Cartesian corner blocks; an opposite side's interior levels never cut a
    locked facet.
    """

    required_sides = (
        OrthogonalBoundarySide.DIE_X_MIN,
        OrthogonalBoundarySide.DIE_X_MAX,
        OrthogonalBoundarySide.DIE_Y_MIN,
        OrthogonalBoundarySide.DIE_Y_MAX,
    )
    grouped: dict[OrthogonalBoundarySide, list[_ValidatedQuad]] = defaultdict(list)
    for quad in quads:
        if quad.kind != "die_wall" or quad.side not in required_sides:
            raise OrthogonalFilletError(
                "per-side Orth partition accepts die-wall QUAD4 facets only"
            )
        grouped[quad.side].append(quad)
    if set(grouped) != set(required_sides):
        missing = tuple(
            side.value for side in required_sides if side not in grouped
        )
        raise OrthogonalFilletError(
            "per-side Orth fillet requires four complete die-wall partitions; "
            f"missing={missing!r}"
        )

    x0, y0 = (_key(value) for value in root.die_origin_xy_mm)
    x1 = _key(x0 + root.die_size_xy_mm[0])
    y1 = _key(y0 + root.die_size_xy_mm[1])
    z0 = _key(root.base_z_mm)
    z1 = _key(root.base_z_mm + root.wall_height_mm)
    side_specs = {
        OrthogonalBoundarySide.DIE_X_MIN: (1, y0, y1),
        OrthogonalBoundarySide.DIE_X_MAX: (1, y0, y1),
        OrthogonalBoundarySide.DIE_Y_MIN: (0, x0, x1),
        OrthogonalBoundarySide.DIE_Y_MAX: (0, x0, x1),
    }
    chains: list[_ValidatedBoundaryChain] = []
    common_z_levels: tuple[float, ...] | None = None
    seam_ids_by_face: dict[
        tuple[tuple[float, float, float], ...], tuple[str, ...]
    ] = {}
    locked_edges: set[
        tuple[tuple[float, float, float], tuple[float, float, float]]
    ] = set()

    for side in required_sides:
        tangent_axis, tangent_lower, tangent_upper = side_specs[side]
        values = tuple(grouped[side])
        tangent_levels = tuple(
            sorted(
                {
                    _key(point[tangent_axis])
                    for quad in values
                    for point in quad.points
                }
            )
        )
        z_levels = tuple(
            sorted({_key(point[2]) for quad in values for point in quad.points})
        )
        if (
            len(tangent_levels) < 2
            or tangent_levels[0] != tangent_lower
            or tangent_levels[-1] != tangent_upper
            or len(z_levels) < 2
            or z_levels[0] != z0
            or z_levels[-1] != z1
        ):
            raise OrthogonalFilletError(
                f"per-side Orth partition {side.value!r} is partial"
            )
        if common_z_levels is None:
            common_z_levels = z_levels
        elif common_z_levels != z_levels:
            raise OrthogonalFilletError(
                "adjacent per-side Orth partitions disagree on their shared "
                "physical Z-edge authority"
            )

        tangent_index = {value: index for index, value in enumerate(tangent_levels)}
        z_index = {value: index for index, value in enumerate(z_levels)}
        cells: dict[tuple[int, int], _ValidatedQuad] = {}
        for quad in values:
            spans = dict(quad.spans)
            tangent_span = tuple(_key(value) for value in spans[tangent_axis])
            z_span = tuple(_key(value) for value in spans[2])
            ti = tangent_index[tangent_span[0]]
            zi = z_index[z_span[0]]
            if (
                ti + 1 >= len(tangent_levels)
                or tangent_levels[ti + 1] != tangent_span[1]
                or zi + 1 >= len(z_levels)
                or z_levels[zi + 1] != z_span[1]
            ):
                raise OrthogonalFilletError(
                    f"per-side Orth partition {side.value!r} contains a "
                    "partial-edge T-junction"
                )
            cell = (ti, zi)
            if cell in cells:
                raise OrthogonalFilletError(
                    f"per-side Orth partition {side.value!r} contains "
                    "overlapping duplicate QUAD4 facets"
                )
            cells[cell] = quad
            face_key = _face_key(quad.points)
            if face_key in seam_ids_by_face:
                raise OrthogonalFilletError(
                    "per-side Orth partitions duplicate one physical face"
                )
            seam_ids_by_face[face_key] = (quad.seam_id,)
            for first, second in zip(
                quad.points,
                (*quad.points[1:], quad.points[0]),
            ):
                locked_edges.add(_edge_key(first, second))
        expected_cells = {
            (ti, zi)
            for ti in range(len(tangent_levels) - 1)
            for zi in range(len(z_levels) - 1)
        }
        if set(cells) != expected_cells:
            raise OrthogonalFilletError(
                f"per-side Orth partition {side.value!r} is partial or has a hole"
            )
        points = tuple(
            (
                x0 if side is OrthogonalBoundarySide.DIE_X_MIN else
                x1 if side is OrthogonalBoundarySide.DIE_X_MAX else value,
                y0 if side is OrthogonalBoundarySide.DIE_Y_MIN else
                y1 if side is OrthogonalBoundarySide.DIE_Y_MAX else value,
                z0,
            )
            for value in tangent_levels
        )
        segment_keys = tuple(
            _edge_key(first, second)
            for first, second in zip(points, points[1:])
        )
        chains.append(
            _ValidatedBoundaryChain(
                f"per-side:{side.value}",
                side,
                points,
                tangent_axis,
                tangent_levels,
                segment_keys,
            )
        )

    assert common_z_levels is not None
    edge_lengths = tuple(math.dist(*edge) for edge in locked_edges)
    return _ValidatedWallPartitions(
        tuple(chains),
        common_z_levels,
        seam_ids_by_face,
        sum(
            length > target_edge + tolerance
            for length in edge_lengths
        ),
        max(edge_lengths, default=0.0),
    )


def _validate_authoritative_base_quads(
    root: CanonicalRectangularUnderfillFillet,
    values: Sequence[LockedCartesianQuad],
    tolerance: float,
) -> tuple[_ValidatedQuad, ...]:
    """Validate topology-neutral BASE facets without analytic clipping.

    An Orth producer passes its complete candidate partition, including cells
    outside either component. The consumer samples its own geometry for cell
    ownership; accepting a candidate QUAD does not force an incident HEX. The
    complete annulus and same-die proof is performed by
    :func:`_validated_base_partition` immediately afterwards.
    """

    seen_ids: set[str] = set()
    output: list[_ValidatedQuad] = []
    z0 = root.base_z_mm
    for value in values:
        if type(value) is not LockedCartesianQuad:
            raise OrthogonalFilletError(
                "authoritative BASE entries must be exact LockedCartesianQuad"
            )
        if value.seam_id in seen_ids:
            raise OrthogonalFilletError(
                f"authoritative BASE seam_id {value.seam_id!r} is duplicated"
            )
        seen_ids.add(value.seam_id)
        constant_axis, spans = _quad_rectangle(value, tolerance=tolerance)
        if constant_axis != 2 or not all(
            _close(point[2], z0, tolerance)
            for point in value.target_local_points_mm
        ):
            raise OrthogonalFilletError(
                f"authoritative BASE QUAD {value.seam_id!r} is not on base_z"
            )
        output.append(
            _ValidatedQuad(
                value.seam_id,
                "base",
                OrthogonalBoundarySide.BASE,
                tuple(value.target_local_points_mm),
                constant_axis,
                spans,
            )
        )
    return tuple(output)


def _validated_base_partition(
    root: CanonicalRectangularUnderfillFillet,
    quads: Sequence[_ValidatedQuad],
    target_edge: float,
    tolerance: float,
) -> _ValidatedBasePartition:
    """Prove an incoming BASE is one complete per-side Orth complex.

    Coordinates are deliberately compared only on their actual support lines.
    In particular, an X coordinate owned by ``die_y_max`` is never projected
    into the tensor of ``die_y_min``.  This is the distinction between the
    eight-block representation and the legacy global X/Y tensor.
    """

    if not quads or any(value.kind != "base" for value in quads):
        raise OrthogonalFilletError(
            "complete multiblock BASE requires locked base QUAD4 facets"
        )
    x0, y0 = (_key(value) for value in root.die_origin_xy_mm)
    x1 = _key(x0 + root.die_size_xy_mm[0])
    y1 = _key(y0 + root.die_size_xy_mm[1])
    z0 = _key(root.base_z_mm)

    # Block order is the public eight-block order used by the generator below.
    def block_for(
        bounds: tuple[tuple[float, float], tuple[float, float]],
    ) -> int:
        (xl, xu), (yl, yu) = bounds
        left = xu <= x0 + tolerance
        right = xl >= x1 - tolerance
        below = yu <= y0 + tolerance
        above = yl >= y1 - tolerance
        within_x = xl >= x0 - tolerance and xu <= x1 + tolerance
        within_y = yl >= y0 - tolerance and yu <= y1 + tolerance
        if left and below:
            return 4
        if left and above:
            return 5
        if right and below:
            return 6
        if right and above:
            return 7
        if left and within_y:
            return 0
        if right and within_y:
            return 1
        if below and within_x:
            return 2
        if above and within_x:
            return 3
        raise OrthogonalFilletError(
            "complete multiblock BASE contains a QUAD that crosses an "
            "eight-block die boundary"
        )

    bounds_by_quad: list[
        tuple[_ValidatedQuad, int, tuple[tuple[float, float], tuple[float, float]]]
    ] = []
    face_by_bounds: dict[
        tuple[tuple[float, float], tuple[float, float]],
        tuple[tuple[float, float, float], ...],
    ] = {}
    seam_ids_by_face: dict[
        tuple[tuple[float, float, float], ...], tuple[str, ...]
    ] = {}
    seam_ids_by_bounds: dict[
        tuple[tuple[float, float], tuple[float, float]], tuple[str, ...]
    ] = {}
    for quad in quads:
        spans = dict(quad.spans)
        if set(spans) != {0, 1}:
            raise OrthogonalFilletError(
                "complete multiblock BASE accepts planar XY QUAD4 facets only"
            )
        bounds = (
            tuple(_key(value) for value in spans[0]),
            tuple(_key(value) for value in spans[1]),
        )
        if bounds in face_by_bounds:
            raise OrthogonalFilletError(
                "complete multiblock BASE contains overlapping duplicate QUAD4 "
                "facets"
            )
        face_key = _face_key(quad.points)
        face_by_bounds[bounds] = face_key
        seam_ids_by_face[face_key] = (quad.seam_id,)
        seam_ids_by_bounds[bounds] = (quad.seam_id,)
        bounds_by_quad.append((quad, block_for(bounds), bounds))

    # Positive-area overlap is forbidden even when neither rectangle is an
    # exact duplicate.  A sweep on X avoids a quadratic scan for the ordinary
    # fine-grid case while remaining exact for this axis-aligned complex.
    active: list[
        tuple[_ValidatedQuad, int, tuple[tuple[float, float], tuple[float, float]]]
    ] = []
    for current in sorted(
        bounds_by_quad,
        key=lambda value: (value[2][0][0], value[2][0][1], value[2][1]),
    ):
        current_x, current_y = current[2]
        active = [
            value
            for value in active
            if value[2][0][1] > current_x[0] + tolerance
        ]
        for previous in active:
            previous_y = previous[2][1]
            if (
                min(previous_y[1], current_y[1])
                - max(previous_y[0], current_y[0])
                > tolerance
            ):
                raise OrthogonalFilletError(
                    "complete multiblock BASE contains positive-area "
                    "overlapping QUAD4 facets"
                )
        active.append(current)

    edge_owners: dict[
        tuple[tuple[float, float, float], tuple[float, float, float]],
        list[int],
    ] = defaultdict(list)
    segments_by_support_line: dict[
        tuple[int, float, float],
        list[
            tuple[
                float,
                float,
                tuple[tuple[float, float, float], tuple[float, float, float]],
            ]
        ],
    ] = defaultdict(list)
    for cell_index, (quad, _block_index, _bounds) in enumerate(bounds_by_quad):
        points = tuple(_point_key(point) for point in quad.points)
        for first, second in zip(points, (*points[1:], points[0])):
            edge = _edge_key(first, second)
            edge_owners[edge].append(cell_index)
            if _close(first[1], second[1], tolerance):
                axis = 0
                support = (axis, _key(first[1]), z0)
            elif _close(first[0], second[0], tolerance):
                axis = 1
                support = (axis, _key(first[0]), z0)
            else:  # pragma: no cover - _quad_rectangle already proves this
                raise OrthogonalFilletError(
                    "complete multiblock BASE contains a non-Cartesian edge"
                )
            lower, upper = sorted((first[axis], second[axis]))
            segments_by_support_line[support].append((lower, upper, edge))

    if any(len(owners) > 2 for owners in edge_owners.values()):
        raise OrthogonalFilletError(
            "complete multiblock BASE contains a non-manifold edge"
        )
    # Compare spans only on the same physical line.  This catches one-long to
    # two-short partial edges without importing anchors from an opposite side.
    for segments in segments_by_support_line.values():
        ordered = sorted(segments, key=lambda value: (value[0], value[1]))
        line_active: list[
            tuple[
                float,
                float,
                tuple[tuple[float, float, float], tuple[float, float, float]],
            ]
        ] = []
        for current in ordered:
            line_active = [
                value
                for value in line_active
                if value[1] > current[0] + tolerance
            ]
            for previous in line_active:
                overlap = min(previous[1], current[1]) - max(
                    previous[0], current[0]
                )
                if overlap > tolerance and previous[2] != current[2]:
                    raise OrthogonalFilletError(
                        "complete multiblock BASE has a partial-edge "
                        "T-junction on one physical support line"
                    )
            line_active.append(current)

    adjacency: dict[int, set[int]] = {
        index: set() for index in range(len(bounds_by_quad))
    }
    for owners in edge_owners.values():
        if len(owners) == 2:
            first, second = owners
            adjacency[first].add(second)
            adjacency[second].add(first)
    remaining = set(adjacency)
    component_count = 0
    while remaining:
        component_count += 1
        pending = [remaining.pop()]
        while pending:
            current = pending.pop()
            unseen = adjacency[current].intersection(remaining)
            remaining.difference_update(unseen)
            pending.extend(unseen)
    if component_count != 1:
        raise OrthogonalFilletError(
            "complete multiblock BASE is not edge-connected"
        )

    boundary_edges = {
        edge for edge, owners in edge_owners.items() if len(owners) == 1
    }
    boundary_adjacency: dict[
        tuple[float, float, float], set[tuple[float, float, float]]
    ] = defaultdict(set)
    for first, second in boundary_edges:
        boundary_adjacency[first].add(second)
        boundary_adjacency[second].add(first)
    if not boundary_adjacency or any(
        len(neighbours) != 2 for neighbours in boundary_adjacency.values()
    ):
        raise OrthogonalFilletError(
            "complete multiblock BASE boundary is open or has a T-junction"
        )
    remaining_vertices = set(boundary_adjacency)
    boundary_components: list[set[tuple[float, float, float]]] = []
    while remaining_vertices:
        component = {remaining_vertices.pop()}
        pending = list(component)
        while pending:
            current = pending.pop()
            unseen = boundary_adjacency[current].intersection(remaining_vertices)
            remaining_vertices.difference_update(unseen)
            component.update(unseen)
            pending.extend(unseen)
        boundary_components.append(component)
    if len(boundary_components) != 2:
        raise OrthogonalFilletError(
            "complete multiblock BASE must have exactly one die-perimeter "
            "cycle and one outer staircase cycle"
        )

    required_sides = (
        OrthogonalBoundarySide.DIE_X_MIN,
        OrthogonalBoundarySide.DIE_X_MAX,
        OrthogonalBoundarySide.DIE_Y_MIN,
        OrthogonalBoundarySide.DIE_Y_MAX,
    )
    inner_by_side: dict[
        OrthogonalBoundarySide,
        set[tuple[tuple[float, float, float], tuple[float, float, float]]],
    ] = defaultdict(set)
    for edge in boundary_edges:
        side = _inner_perimeter_side_for_edge(
            root, edge[0], edge[1], tolerance
        )
        if side is not None:
            inner_by_side[side].add(edge)
    if set(inner_by_side) != set(required_sides):
        raise OrthogonalFilletError(
            "complete multiblock BASE does not expose all four die-perimeter "
            "sides"
        )
    chains: list[_ValidatedBoundaryChain] = []
    all_inner_edges: set[
        tuple[tuple[float, float, float], tuple[float, float, float]]
    ] = set()
    for side in required_sides:
        edges = inner_by_side[side]
        tangent_axis = 1 if side in {
            OrthogonalBoundarySide.DIE_X_MIN,
            OrthogonalBoundarySide.DIE_X_MAX,
        } else 0
        tangent_bounds = (y0, y1) if tangent_axis == 1 else (x0, x1)
        points = tuple(
            sorted(
                {point for edge in edges for point in edge},
                key=lambda point: point[tangent_axis],
            )
        )
        if (
            not points
            or points[0][tangent_axis] != tangent_bounds[0]
            or points[-1][tangent_axis] != tangent_bounds[1]
        ):
            raise OrthogonalFilletError(
                f"complete multiblock BASE die edge {side.value!r} is partial"
            )
        expected_edges = {
            _edge_key(first, second)
            for first, second in zip(points, points[1:])
        }
        if edges != expected_edges:
            raise OrthogonalFilletError(
                f"complete multiblock BASE die edge {side.value!r} contains "
                "a gap or partial T-junction"
            )
        all_inner_edges.update(edges)
        chains.append(
            _ValidatedBoundaryChain(
                f"complete_base:{side.value}",
                side,
                points,
                tangent_axis,
                tuple(point[tangent_axis] for point in points),
                tuple(sorted(edges)),
            )
        )
    inner_vertices = {point for edge in all_inner_edges for point in edge}
    inner_component = tuple(
        component
        for component in boundary_components
        if inner_vertices.intersection(component)
    )
    if len(inner_component) != 1 or inner_component[0] != inner_vertices:
        raise OrthogonalFilletError(
            "complete multiblock BASE inner boundary is not exactly the die "
            "perimeter cycle"
        )

    grouped: dict[
        int,
        list[tuple[tuple[float, float], tuple[float, float]]],
    ] = defaultdict(list)
    for _quad, block_index, bounds in bounds_by_quad:
        grouped[block_index].append(bounds)
    if set(grouped) != set(range(8)):
        missing = tuple(index for index in range(8) if index not in grouped)
        raise OrthogonalFilletError(
            "complete multiblock BASE does not contain all eight Cartesian "
            f"regions; missing={missing!r}"
        )
    chain_by_side = {chain.side: chain for chain in chains}

    def coordinates_for_blocks(axis: int, block_indices: set[int]) -> tuple[float, ...]:
        return tuple(
            sorted(
                {
                    value
                    for block_index in block_indices
                    for bounds in grouped[block_index]
                    for value in bounds[axis]
                }
            )
        )

    negative_x = coordinates_for_blocks(0, {0, 4, 5})
    positive_x = coordinates_for_blocks(0, {1, 6, 7})
    negative_y = coordinates_for_blocks(1, {2, 4, 6})
    positive_y = coordinates_for_blocks(1, {3, 5, 7})
    normal_coordinates = {
        OrthogonalBoundarySide.DIE_X_MIN: negative_x,
        OrthogonalBoundarySide.DIE_X_MAX: positive_x,
        OrthogonalBoundarySide.DIE_Y_MIN: negative_y,
        OrthogonalBoundarySide.DIE_Y_MAX: positive_y,
    }
    if (
        not negative_x or negative_x[-1] != x0
        or not positive_x or positive_x[0] != x1
        or not negative_y or negative_y[-1] != y0
        or not positive_y or positive_y[0] != y1
    ):
        raise OrthogonalFilletError(
            "complete multiblock BASE does not terminate on the same die "
            "rectangle"
        )

    block_levels = {
        0: (
            negative_x,
            chain_by_side[
                OrthogonalBoundarySide.DIE_X_MIN
            ].tangential_levels_mm,
        ),
        1: (
            positive_x,
            chain_by_side[
                OrthogonalBoundarySide.DIE_X_MAX
            ].tangential_levels_mm,
        ),
        2: (
            chain_by_side[
                OrthogonalBoundarySide.DIE_Y_MIN
            ].tangential_levels_mm,
            negative_y,
        ),
        3: (
            chain_by_side[
                OrthogonalBoundarySide.DIE_Y_MAX
            ].tangential_levels_mm,
            positive_y,
        ),
        4: (negative_x, negative_y),
        5: (negative_x, positive_y),
        6: (positive_x, negative_y),
        7: (positive_x, positive_y),
    }
    for block_index, cells in grouped.items():
        x_levels, y_levels = block_levels[block_index]
        x_index = {value: index for index, value in enumerate(x_levels)}
        y_index = {value: index for index, value in enumerate(y_levels)}
        for x_bounds, y_bounds in cells:
            i = x_index.get(x_bounds[0], -1)
            j = y_index.get(y_bounds[0], -1)
            if (
                i < 0
                or i + 1 >= len(x_levels)
                or x_levels[i + 1] != x_bounds[1]
                or j < 0
                or j + 1 >= len(y_levels)
                or y_levels[j + 1] != y_bounds[1]
            ):
                raise OrthogonalFilletError(
                    "complete multiblock BASE has a non-consecutive cell in "
                    "one side-local Cartesian partition"
                )
        if block_index < 4:
            expected = {
                ((xl, xu), (yl, yu))
                for xl, xu in zip(x_levels, x_levels[1:])
                for yl, yu in zip(y_levels, y_levels[1:])
            }
            if set(cells) != expected:
                raise OrthogonalFilletError(
                    "complete multiblock BASE side strip is partial or has a "
                    "hole"
                )

    normal_offsets = {
        OrthogonalBoundarySide.DIE_X_MIN: tuple(
            sorted(_key(x0 - value) for value in negative_x)
        ),
        OrthogonalBoundarySide.DIE_X_MAX: tuple(
            sorted(_key(value - x1) for value in positive_x)
        ),
        OrthogonalBoundarySide.DIE_Y_MIN: tuple(
            sorted(_key(y0 - value) for value in negative_y)
        ),
        OrthogonalBoundarySide.DIE_Y_MAX: tuple(
            sorted(_key(value - y1) for value in positive_y)
        ),
    }
    if any(
        len(values) < 2 or values[0] != 0.0 or values[-1] <= tolerance
        for values in normal_offsets.values()
    ):
        raise OrthogonalFilletError(
            "complete multiblock BASE has no positive annular width on one "
            "die side"
        )

    unique_edges = tuple(edge_owners)
    edge_lengths = tuple(math.dist(*edge) for edge in unique_edges)
    planar_cells = tuple(
        (block_index, local_index, bounds)
        for block_index in range(8)
        for local_index, bounds in enumerate(sorted(grouped[block_index]))
    )
    return _ValidatedBasePartition(
        tuple(chains),
        planar_cells,
        normal_offsets,
        seam_ids_by_face,
        seam_ids_by_bounds,
        sum(length > target_edge + tolerance for length in edge_lengths),
        max(edge_lengths, default=0.0),
    )


def _uniform_levels(
    lower: float,
    upper: float,
    maximum_edge: float,
) -> tuple[float, ...]:
    distance = upper - lower
    ratio = distance / maximum_edge
    nearest = round(ratio)
    # Decimal spans such as (0.6 - 0.2) / 0.1 must give four layers,
    # not five because of floating-point subtraction noise.
    divisions = max(1, nearest if math.isclose(ratio, nearest, rel_tol=1.e-12, abs_tol=1.e-12) else math.ceil(ratio))
    return tuple(
        _key(lower + distance * index / divisions)
        for index in range(divisions + 1)
    )


def _inner_perimeter_side_for_edge(
    root: CanonicalRectangularUnderfillFillet,
    first: Sequence[float],
    second: Sequence[float],
    tolerance: float,
) -> OrthogonalBoundarySide | None:
    if not (
        _close(first[2], root.base_z_mm, tolerance)
        and _close(second[2], root.base_z_mm, tolerance)
    ):
        return None
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    specifications = (
        (OrthogonalBoundarySide.DIE_X_MIN, 0, x0, 1, (y0, y1)),
        (OrthogonalBoundarySide.DIE_X_MAX, 0, x1, 1, (y0, y1)),
        (OrthogonalBoundarySide.DIE_Y_MIN, 1, y0, 0, (x0, x1)),
        (OrthogonalBoundarySide.DIE_Y_MAX, 1, y1, 0, (x0, x1)),
    )
    for side, axis, coordinate, tangent, tangent_bounds in specifications:
        if (
            _close(first[axis], coordinate, tolerance)
            and _close(second[axis], coordinate, tolerance)
            and tangent_bounds[0] - tolerance
            <= first[tangent]
            <= tangent_bounds[1] + tolerance
            and tangent_bounds[0] - tolerance
            <= second[tangent]
            <= tangent_bounds[1] + tolerance
            and abs(first[tangent] - second[tangent]) > tolerance
        ):
            return side
    return None


def _connected_element_component_count(
    elements: Sequence[OrthogonalHexElement],
    face_owners: Mapping[
        tuple[tuple[float, float, float], ...],
        Sequence[tuple[OrthogonalHexElement, int, tuple[int, int, int, int]]],
    ],
) -> int:
    adjacency: dict[int, set[int]] = {
        element.element_index: set() for element in elements
    }
    for owners in face_owners.values():
        if len(owners) != 2:
            continue
        first = owners[0][0].element_index
        second = owners[1][0].element_index
        adjacency[first].add(second)
        adjacency[second].add(first)
    remaining = set(adjacency)
    component_count = 0
    while remaining:
        component_count += 1
        pending = [remaining.pop()]
        while pending:
            current = pending.pop()
            unseen = adjacency[current].intersection(remaining)
            remaining.difference_update(unseen)
            pending.extend(unseen)
    return component_count


def _mesh_topology_warnings(fragment, nodes, elements, face_owners):
    """Diagnose centre sampling without moving nodes or retaining extra cells.

    A vertex's incident cells must connect through faces containing that
    vertex. This catches both edge-only and point-only contacts, including
    pinches in a mesh that is face-connected elsewhere. Details are bounded.
    """
    by_id = {element.element_index: element for element in elements}
    nodes_by_id = {node.node_index: node for node in nodes}
    incident = defaultdict(set)
    adjacency = {element.element_index: set() for element in elements}
    for element in elements:
        for node in element.node_indices:
            incident[node].add(element.element_index)
    for owners in face_owners.values():
        if len(owners) == 2:
            a, b = (owner[0].element_index for owner in owners)
            adjacency[a].add(b)
            adjacency[b].add(a)

    def groups(values):
        remaining = set(values)
        output = []
        while remaining:
            start = min(remaining)
            remaining.remove(start)
            group = {start}
            pending = [start]
            while pending:
                unseen = adjacency[pending.pop()].intersection(remaining)
                remaining.difference_update(unseen)
                group.update(unseen)
                pending.extend(unseen)
            output.append(group)
        return output

    def cell_location(element_id):
        element = by_id[element_id]
        return {
            "element_id": element_id,
            "cell_indices": element.cell_ijk,
            "bounds_local_mm": element.bounds_xyz_mm,
        }

    messages = []
    pinched = []
    for node, owners in incident.items():
        if len(owners) > 1 and len(groups(owners)) > 1:
            pinched.append(node)
    if pinched:
        messages.append({
            "code": "orthogonal_edge_or_point_contact",
            "severity": "warning",
            "fragment_id": fragment.fragment_id,
            "message": "中心筛选后存在仅靠边或点连接的单元；请细化该处网格尺寸或简化几何。",
            "affected_node_count": len(pinched),
            "element_ids": tuple(sorted({i for node in pinched for i in incident[node]})),
            "locations": tuple({
                "coordinates_package_mm": nodes_by_id[node].package_coordinates_mm,
                "coordinates_local_mm": nodes_by_id[node].target_local_coordinates_mm,
                "cells": tuple(cell_location(i) for i in sorted(incident[node])),
            } for node in sorted(pinched)[:20]),
            "locations_truncated": len(pinched) > 20,
        })
    components = groups(by_id)
    if len(components) > 1:
        messages.append({
            "code": "orthogonal_disconnected_cells",
            "severity": "warning",
            "fragment_id": fragment.fragment_id,
            "message": "中心筛选后的体单元未通过面连成一个整体；请检查局部网格尺寸或简化几何。",
            "connected_component_count": len(components),
            "element_ids": tuple(sorted(by_id)),
            "locations": tuple({
                **cell_location(min(group)), "element_count": len(group),
            } for group in components[:20]),
            "locations_truncated": len(components) > 20,
        })
    top = fragment.root.base_z_mm + fragment.root.wall_height_mm
    actual_top = max(element.bounds_xyz_mm[2][1] for element in elements)
    if actual_top < top - 1.0e-10:
        messages.append({
            "code": "orthogonal_tip_truncated",
            "severity": "warning",
            "fragment_id": fragment.fragment_id,
            "message": "顶部没有候选单元中心落入几何，网格顶端被截短；需要保留该细节时请细化网格。",
            "element_ids": tuple(e.element_index for e in elements if abs(e.bounds_xyz_mm[2][1] - actual_top) <= 1.0e-10),
            "analytic_top_local_z_mm": top,
            "actual_top_local_z_mm": actual_top,
        })
    # Different inherited normal spacings can truncate only one arm of the
    # ring. A global maximum alone hides this loss when another arm reaches
    # the analytic top. Diagnose each die-wall side independently; occupancy
    # and interface partition authority must remain unchanged.
    x0, y0 = fragment.root.die_origin_xy_mm
    x1 = x0 + fragment.root.die_size_xy_mm[0]
    y1 = y0 + fragment.root.die_size_xy_mm[1]
    for side, axis, endpoint, coordinate, tangent, bounds in (
        ("die_x_min", 0, 1, x0, 1, (y0, y1)),
        ("die_x_max", 0, 0, x1, 1, (y0, y1)),
        ("die_y_min", 1, 1, y0, 0, (x0, x1)),
        ("die_y_max", 1, 0, y1, 0, (x0, x1)),
    ):
        wall_cells = tuple(e for e in elements
                           if abs(e.bounds_xyz_mm[axis][endpoint] - coordinate) <= 1.0e-10
                           and e.bounds_xyz_mm[tangent][0] >= bounds[0] - 1.0e-10
                           and e.bounds_xyz_mm[tangent][1] <= bounds[1] + 1.0e-10)
        wall_top = max((e.bounds_xyz_mm[2][1] for e in wall_cells),
                       default=fragment.root.base_z_mm)
        if wall_top >= min(top, actual_top) - 1.0e-10:
            continue
        affected = tuple(e.element_index for e in wall_cells
                         if abs(e.bounds_xyz_mm[2][1] - wall_top) <= 1.0e-10)
        messages.append({
            "code": "orthogonal_side_tip_truncated", "severity": "warning",
            "fragment_id": fragment.fragment_id, "geometric_side": side,
            "message": (
                f"{side} 侧中心筛选后的网格止于 Z={wall_top * 1000:.6g} µm，"
                f"原几何延伸至 {top * 1000:.6g} µm；该区没有 Orth 体单元，"
                "邻接部件在此不再有共享 QUAD。需要保留接触时请细化法向网格或简化几何。"
            ),
            "export_allowed": True, "element_ids": affected,
            "locations": tuple(cell_location(i) for i in affected[:20]),
            "locations_truncated": len(affected) > 20,
            "missing_z_interval_local_mm": (wall_top, top),
            "analytic_top_local_z_mm": top, "actual_top_local_z_mm": wall_top,
        })
    return tuple(messages)


def mesh_rectangular_fillet_orthogonal_hex_multiblock(
    target_fragment: CanonicalGeometryFragment,
    target_edge_mm: float,
    *,
    base_boundary_chains: Sequence[LockedCartesianBoundaryChain] = (),
    base_quads: Sequence[LockedCartesianQuad] = (),
    die_wall_quads: Sequence[LockedCartesianQuad] = (),
    shared_surface_id: str | None = None,
    orthogonal_strategy: OrthogonalHexMeshStrategy | None = None,
) -> OrthogonalMultiblockFilletMesh:
    """Generate a per-side, eight-block Cartesian fillet mesh.

    Each die-wall side strip uses only its own chain's tangential levels.  The
    four corner blocks combine the two adjacent normal schedules with their
    one common physical-edge trace, so an opposite side's coordinates can
    never cut through the whole tensor. Die-wall and BASE QUAD partitions
    constrain candidate coordinates only. An incoming ``base_quads``
    complex is the planar decomposition itself; it is never projected into a
    global X/Y tensor.  When ``shared_surface_id`` is present, the generated
    surviving target-base facets are emitted for actual contact matching.
    """

    if type(target_fragment) is not CanonicalGeometryFragment or type(
        target_fragment.root
    ) is not CanonicalRectangularUnderfillFillet:
        raise OrthogonalFilletError(
            "orthogonal multiblock backend requires one canonical rectangular "
            "underfill fillet fragment"
        )
    target_edge = _positive(target_edge_mm, field_name="target_edge_mm")
    if shared_surface_id is not None and (
        not isinstance(shared_surface_id, str) or not shared_surface_id
    ):
        raise OrthogonalFilletError("shared_surface_id is invalid")
    if orthogonal_strategy is not None and type(
        orthogonal_strategy
    ) is not OrthogonalHexMeshStrategy:
        raise OrthogonalFilletError(
            "orthogonal_strategy must be an exact OrthogonalHexMeshStrategy"
        )
    root = target_fragment.root
    sizing = MeshSeedPolicy() if orthogonal_strategy is None else orthogonal_strategy.sizing
    origin = (None if orthogonal_strategy is None else geometry_origin(
        root, sizing, orthogonal_strategy.partition_origin_mm))
    def free_levels(lower, upper, axis):
        sizes = (
            None
            if orthogonal_strategy is None
            else orthogonal_strategy.directional_near_edge_mm
        )
        negative = (
            target_edge
            if sizes is None
            else sizes[ComponentLocalDirection("negative_" + "xyz"[axis])]
        )
        positive = (
            target_edge
            if sizes is None
            else sizes[ComponentLocalDirection("positive_" + "xyz"[axis])]
        )
        if axis < 2:
            # Both ends of a free straight die-wall span are 3D reentrant
            # corners. Preserve both first cells even without an Origin preset.
            from .package_v2_orthogonal_domain_planning import (
                orthogonal_corner_sizes,
                orthogonal_meeting_levels,
            )

            left_size, right_size = orthogonal_corner_sizes(
                lower,
                upper,
                negative,
                positive,
                None if origin is None else origin[axis],
            )
            values = orthogonal_meeting_levels(
                lower, upper, left_size, right_size, sizing.remainder_ratio
            )
        elif origin is None:
            values = _uniform_levels(lower, upper, target_edge)
        else:
            values = interval_levels(lower, upper, negative, positive, origin[axis], sizing)
        return tuple(_key(v) for v in values)

    scale = max(
        1.0,
        *(
            abs(value)
            for value in (
                *root.die_origin_xy_mm,
                *root.die_size_xy_mm,
                root.base_z_mm,
                root.wall_height_mm,
                root.toe_width_mm,
                root.top_width_mm,
                target_edge,
            )
        ),
    )
    tolerance = 1.0e-10 * scale
    validated_base = _validate_authoritative_base_quads(
        root,
        base_quads,
        tolerance,
    )
    if validated_base and (
        base_boundary_chains or die_wall_quads or shared_surface_id is not None
    ):
        raise OrthogonalFilletError(
            "complete incoming multiblock BASE cannot be combined with "
            "boundary chains, die-wall locks, or a generated shared surface"
        )
    validated_walls = _validate_locked_quads(
        root,
        target_edge,
        (),
        (),
        die_wall_quads,
        tolerance,
    )
    wall_partitions = (
        _validated_wall_partitions(
            root,
            validated_walls,
            target_edge,
            tolerance,
        )
        if validated_walls
        else None
    )
    base_partition = (
        _validated_base_partition(
            root,
            validated_base,
            target_edge,
            tolerance,
        )
        if validated_base
        else None
    )
    if base_partition is not None:
        chains = base_partition.chains
    elif base_boundary_chains:
        chains = _validate_boundary_chains(
            root,
            base_boundary_chains,
            target_edge,
            tolerance,
        )
        if wall_partitions is not None and tuple(
            (value.side, value.tangential_levels_mm) for value in chains
        ) != tuple(
            (value.side, value.tangential_levels_mm)
            for value in wall_partitions.chains
        ):
            raise OrthogonalFilletError(
                "base boundary chains disagree with the complete per-side "
                "die-wall partitions"
            )
    elif wall_partitions is not None:
        chains = wall_partitions.chains
    else:
        # The rectangular opening seeds a free per-side partition. Each
        # side's normal spacing remains independent of the opposite side.
        x0, y0 = root.die_origin_xy_mm
        x1, y1 = x0 + root.die_size_xy_mm[0], y0 + root.die_size_xy_mm[1]
        chains = _validate_boundary_chains(
            root,
            tuple(LockedCartesianBoundaryChain(
                f"free:{side.value}", side,
                tuple((constant, t, root.base_z_mm) if axis == 0 else (t, constant, root.base_z_mm)
                      for t in free_levels(lower, upper, 1-axis)),
            ) for side, axis, constant, lower, upper in (
                (OrthogonalBoundarySide.DIE_X_MIN, 0, x0, y0, y1),
                (OrthogonalBoundarySide.DIE_X_MAX, 0, x1, y0, y1),
                (OrthogonalBoundarySide.DIE_Y_MIN, 1, y0, x0, x1),
                (OrthogonalBoundarySide.DIE_Y_MAX, 1, y1, x0, x1),
            )),
            target_edge, tolerance,
        )
    chain_by_side = {chain.side: chain for chain in chains}
    segment_lengths = tuple(
        second - first
        for chain in chains
        for first, second in zip(
            chain.tangential_levels_mm,
            chain.tangential_levels_mm[1:],
        )
    )
    chain_target_override_count = sum(
        length > target_edge + tolerance for length in segment_lengths
    )
    maximum_chain_edge = max(segment_lengths, default=0.0)
    near_edge = _key(min(target_edge, median(segment_lengths)))
    directional_sizes = (
        None
        if orthogonal_strategy is None
        else orthogonal_strategy.directional_near_edge_mm
    )
    side_directions = {
        OrthogonalBoundarySide.DIE_X_MIN: ComponentLocalDirection.NEGATIVE_X,
        OrthogonalBoundarySide.DIE_X_MAX: ComponentLocalDirection.POSITIVE_X,
        OrthogonalBoundarySide.DIE_Y_MIN: ComponentLocalDirection.NEGATIVE_Y,
        OrthogonalBoundarySide.DIE_Y_MAX: ComponentLocalDirection.POSITIVE_Y,
    }
    normal_size_by_side = {
        side: (
            near_edge
            if directional_sizes is None
            else directional_sizes[direction]
        )
        for side, direction in side_directions.items()
    }
    def normal_levels(side, size):
        if origin is None:
            return tuple(_key(v) for v in ray_levels(0., root.toe_width_mm, size, sizing))
        direction = side_directions[side]
        axis = 0 if direction.value.endswith("x") else 1
        positive = direction.value.startswith("positive")
        inner = root.die_origin_xy_mm[axis] + (root.die_size_xy_mm[axis] if positive else 0.)
        offset = (origin[axis]-inner) * (1 if positive else -1)
        opposite = ComponentLocalDirection(("negative_" if positive else "positive_") + "xy"[axis])
        reverse_size = directional_sizes[opposite]
        return tuple(_key(v) for v in interval_levels(0., root.toe_width_mm, reverse_size, size, offset, sizing))
    normal_offsets_by_side = (
        dict(base_partition.normal_offsets_by_side)
        if base_partition is not None
        else {
            side: normal_levels(side, size)
            for side, size in normal_size_by_side.items()
        }
    )
    z_maximum_edge = (
        near_edge
        if directional_sizes is None
        else directional_sizes[ComponentLocalDirection.POSITIVE_Z]
    )
    z_levels = (
        wall_partitions.z_levels_mm
        if wall_partitions is not None
        else (free_levels(root.base_z_mm, root.base_z_mm + root.wall_height_mm, 2)
              if origin is not None else tuple(_key(v) for v in ray_levels(
                  root.base_z_mm, root.base_z_mm + root.wall_height_mm, z_maximum_edge, sizing)))
    )

    x0, y0 = (_key(value) for value in root.die_origin_xy_mm)
    x1 = _key(x0 + root.die_size_xy_mm[0])
    y1 = _key(y0 + root.die_size_xy_mm[1])
    negative_x = tuple(
        sorted(
            _key(x0 - offset)
            for offset in normal_offsets_by_side[
                OrthogonalBoundarySide.DIE_X_MIN
            ]
        )
    )
    positive_x = tuple(
        sorted(
            _key(x1 + offset)
            for offset in normal_offsets_by_side[
                OrthogonalBoundarySide.DIE_X_MAX
            ]
        )
    )
    negative_y = tuple(
        sorted(
            _key(y0 - offset)
            for offset in normal_offsets_by_side[
                OrthogonalBoundarySide.DIE_Y_MIN
            ]
        )
    )
    positive_y = tuple(
        sorted(
            _key(y1 + offset)
            for offset in normal_offsets_by_side[
                OrthogonalBoundarySide.DIE_Y_MAX
            ]
        )
    )
    x_min_tangent = chain_by_side[
        OrthogonalBoundarySide.DIE_X_MIN
    ].tangential_levels_mm
    x_max_tangent = chain_by_side[
        OrthogonalBoundarySide.DIE_X_MAX
    ].tangential_levels_mm
    y_min_tangent = chain_by_side[
        OrthogonalBoundarySide.DIE_Y_MIN
    ].tangential_levels_mm
    y_max_tangent = chain_by_side[
        OrthogonalBoundarySide.DIE_Y_MAX
    ].tangential_levels_mm
    blocks = (
        ("side_x_min", OrthogonalBoundarySide.DIE_X_MIN, negative_x, x_min_tangent),
        ("side_x_max", OrthogonalBoundarySide.DIE_X_MAX, positive_x, x_max_tangent),
        ("side_y_min", OrthogonalBoundarySide.DIE_Y_MIN, y_min_tangent, negative_y),
        ("side_y_max", OrthogonalBoundarySide.DIE_Y_MAX, y_max_tangent, positive_y),
        ("corner_x_min_y_min", None, negative_x, negative_y),
        ("corner_x_min_y_max", None, negative_x, positive_y),
        ("corner_x_max_y_min", None, positive_x, negative_y),
        ("corner_x_max_y_max", None, positive_x, positive_y),
    )
    planar_cells: list[
        tuple[
            int,
            int,
            tuple[tuple[float, float], tuple[float, float]],
        ]
    ] = []
    if base_partition is not None:
        planar_cells.extend(base_partition.planar_cells)
    else:
        planar_keys: set[
            tuple[tuple[float, float], tuple[float, float]]
        ] = set()
        for block_index, (_name, _side, x_levels, y_levels) in enumerate(blocks):
            local_index = 0
            for y_lower, y_upper in zip(y_levels, y_levels[1:]):
                for x_lower, x_upper in zip(x_levels, x_levels[1:]):
                    bounds_xy = (
                        (_key(x_lower), _key(x_upper)),
                        (_key(y_lower), _key(y_upper)),
                    )
                    if bounds_xy in planar_keys:
                        raise OrthogonalFilletError(
                            "multiblock planar decomposition contains duplicate "
                            "cells"
                        )
                    planar_keys.add(bounds_xy)
                    planar_cells.append((block_index, local_index, bounds_xy))
                    local_index += 1

    z0 = _key(root.base_z_mm)
    base_cell_keys = (
        {bounds for _block, _local, bounds in base_partition.planar_cells}
        if base_partition is not None
        else {
            bounds_xy
            for _block_index, _local_index, bounds_xy in planar_cells
            if _contains_point(
                root,
                (
                    0.5 * (bounds_xy[0][0] + bounds_xy[0][1]),
                    0.5 * (bounds_xy[1][0] + bounds_xy[1][1]),
                    z0,
                ),
                tolerance,
            )
        }
    )
    if not base_cell_keys:
        raise OrthogonalFilletError(
            "multiblock base cell-centre rule retained no shared QUAD"
        )

    locked_wall_ids_by_face = (
        {}
        if wall_partitions is None
        else dict(wall_partitions.locked_seam_ids_by_face)
    )
    locked_base_ids_by_face = (
        {}
        if base_partition is None
        else dict(base_partition.locked_seam_ids_by_face)
    )
    locked_base_ids_by_bounds = (
        {}
        if base_partition is None
        else dict(base_partition.locked_seam_ids_by_bounds)
    )

    def wall_face_key_for_cell(
        block_index: int,
        bounds: tuple[tuple[float, float], ...],
    ) -> tuple[tuple[float, float, float], ...] | None:
        side = blocks[block_index][1]
        x_bounds, y_bounds, z_bounds = bounds
        if side is OrthogonalBoundarySide.DIE_X_MIN and x_bounds[1] == x0:
            x_value = x0
            return _face_key(
                (
                    (x_value, y_bounds[0], z_bounds[0]),
                    (x_value, y_bounds[1], z_bounds[0]),
                    (x_value, y_bounds[1], z_bounds[1]),
                    (x_value, y_bounds[0], z_bounds[1]),
                )
            )
        if side is OrthogonalBoundarySide.DIE_X_MAX and x_bounds[0] == x1:
            x_value = x1
            return _face_key(
                (
                    (x_value, y_bounds[0], z_bounds[0]),
                    (x_value, y_bounds[1], z_bounds[0]),
                    (x_value, y_bounds[1], z_bounds[1]),
                    (x_value, y_bounds[0], z_bounds[1]),
                )
            )
        if side is OrthogonalBoundarySide.DIE_Y_MIN and y_bounds[1] == y0:
            y_value = y0
            return _face_key(
                (
                    (x_bounds[0], y_value, z_bounds[0]),
                    (x_bounds[1], y_value, z_bounds[0]),
                    (x_bounds[1], y_value, z_bounds[1]),
                    (x_bounds[0], y_value, z_bounds[1]),
                )
            )
        if side is OrthogonalBoundarySide.DIE_Y_MAX and y_bounds[0] == y1:
            y_value = y1
            return _face_key(
                (
                    (x_bounds[0], y_value, z_bounds[0]),
                    (x_bounds[1], y_value, z_bounds[0]),
                    (x_bounds[1], y_value, z_bounds[1]),
                    (x_bounds[0], y_value, z_bounds[1]),
                )
            )
        return None

    classifications = CounterLike()
    retained: list[
        tuple[
            tuple[int, int, int],
            tuple[tuple[float, float], ...],
            OrthogonalCellClass,
            OrthogonalRetentionReason,
            tuple[str, ...],
        ]
    ] = []
    locked_cut_override_count = 0
    authoritative_base_override_count = 0
    active_xy_by_layer: list[
        set[tuple[tuple[float, float], tuple[float, float]]]
    ] = []
    for k, (z_lower, z_upper) in enumerate(zip(z_levels, z_levels[1:])):
        active_xy: set[
            tuple[tuple[float, float], tuple[float, float]]
        ] = set()
        for block_index, local_index, bounds_xy in planar_cells:
            bounds = (bounds_xy[0], bounds_xy[1], (z_lower, z_upper))
            classification = _classify_cell(root, bounds, tolerance)
            classifications.add(classification)
            owns_base = (
                k == 0
                and bounds_xy in base_cell_keys
                and (
                    shared_surface_id is not None
                    or bounds_xy in locked_base_ids_by_bounds
                )
            )
            wall_face_key = wall_face_key_for_cell(block_index, bounds)
            wall_locked_ids = (
                ()
                if wall_face_key is None
                else locked_wall_ids_by_face.get(wall_face_key, ())
            )
            locked_ids = (
                *(
                    locked_base_ids_by_bounds.get(bounds_xy, ())
                    if owns_base and base_partition is not None
                    else (
                        (shared_surface_id,)
                        if owns_base and shared_surface_id is not None
                        else ()
                    )
                ),
                *wall_locked_ids,
            )
            if classification is OrthogonalCellClass.FULL:
                active_xy.add(bounds_xy)
                retained.append(
                    (
                        (block_index, local_index, k),
                        bounds,
                        classification,
                        OrthogonalRetentionReason.ANALYTIC_FULL,
                        locked_ids,
                    )
                )
                continue
            if classification is OrthogonalCellClass.CUT:
                if _cell_center_inside(root, bounds, tolerance):
                    active_xy.add(bounds_xy)
                    retained.append(
                        (
                            (block_index, local_index, k),
                            bounds,
                            classification,
                            OrthogonalRetentionReason.CUT_CENTER_INSIDE,
                            locked_ids,
                        )
                    )
                continue
        active_xy_by_layer.append(active_xy)
    active_xy_sets_nested = all(
        next_values.issubset(current_values)
        for current_values, next_values in zip(
            active_xy_by_layer,
            active_xy_by_layer[1:],
        )
    )
    if not active_xy_sets_nested:
        raise OrthogonalFilletError(
            "orthogonal multiblock active XY cells are not nested along the "
            "narrowing taper"
        )
    if not retained:
        raise OrthogonalFilletError(
            "orthogonal multiblock CUT rule retained no positive-volume HEX8"
        )

    rotation = _rotation_matrix(target_fragment.placement)
    node_by_key: dict[tuple[float, float, float], OrthogonalHexNode] = {}

    def node_for(point: tuple[float, float, float]) -> OrthogonalHexNode:
        key = _point_key(point)
        node = node_by_key.get(key)
        if node is None:
            node = OrthogonalHexNode(
                len(node_by_key) + 1,
                key,
                _to_package(key, target_fragment.placement, rotation),
            )
            node_by_key[key] = node
        return node

    elements: list[OrthogonalHexElement] = []
    for cell, bounds, classification, reason, locked_ids in retained:
        nodes_for_element = tuple(node_for(point) for point in _cell_vertices(bounds))
        volume = math.prod(upper - lower for lower, upper in bounds)
        elements.append(
            OrthogonalHexElement(
                len(elements) + 1,
                tuple(  # type: ignore[arg-type]
                    node.node_index for node in nodes_for_element
                ),
                cell,
                bounds,  # type: ignore[arg-type]
                classification,
                reason,
                locked_ids,
                volume,
            )
        )
    nodes = tuple(sorted(node_by_key.values(), key=lambda item: item.node_index))
    node_by_index = {node.node_index: node for node in nodes}
    face_owners: dict[
        tuple[tuple[float, float, float], ...],
        list[tuple[OrthogonalHexElement, int, tuple[int, int, int, int]]],
    ] = defaultdict(list)
    for element in elements:
        for face_index, face in enumerate(_HEX_FACES):
            node_indices = tuple(element.node_indices[index] for index in face)
            points = tuple(
                node_by_index[index].target_local_coordinates_mm
                for index in node_indices
            )
            face_owners[_face_key(points)].append(
                (element, face_index, node_indices)  # type: ignore[arg-type]
            )
    non_manifold_faces = tuple(
        key for key, owners in face_owners.items() if len(owners) > 2
    )
    if non_manifold_faces:
        raise OrthogonalFilletError(
            "orthogonal multiblock retained-cell union contains a non-manifold face"
        )

    base_face_keys = {
        _face_key(
            (
                (bounds_xy[0][0], bounds_xy[1][0], z0),
                (bounds_xy[0][1], bounds_xy[1][0], z0),
                (bounds_xy[0][1], bounds_xy[1][1], z0),
                (bounds_xy[0][0], bounds_xy[1][1], z0),
            )
        )
        for bounds_xy in base_cell_keys
    }
    boundary_facets: list[OrthogonalBoundaryFacet] = []
    resolved_base_faces: set[tuple[tuple[float, float, float], ...]] = set()
    resolved_base_seam_ids: set[str] = set()
    for key in sorted(face_owners):
        owners = face_owners[key]
        if len(owners) != 1:
            continue
        element, local_face_index, node_indices = owners[0]
        points = tuple(
            node_by_index[index].target_local_coordinates_mm
            for index in node_indices
        )
        incoming_base_ids = locked_base_ids_by_face.get(key, ())
        is_locked_base = (
            key in base_face_keys
            and (shared_surface_id is not None or bool(incoming_base_ids))
        )
        if is_locked_base:
            resolved_base_faces.add(key)
            resolved_base_seam_ids.update(incoming_base_ids)
        wall_locked_ids = locked_wall_ids_by_face.get(key, ())
        boundary_facets.append(
            OrthogonalBoundaryFacet(
                _boundary_side(
                    root,
                    points,
                    tolerance,
                    OrthogonalBoundarySide.BASE if is_locked_base else None,
                ),
                node_indices,
                element.element_index,
                local_face_index,
                (
                    *incoming_base_ids,
                    *(
                        (shared_surface_id,)
                        if is_locked_base and shared_surface_id is not None
                        else ()
                    ),
                    *wall_locked_ids,
                ),
            )
        )
    boundary_edge_owners: Counter[
        tuple[tuple[float, float, float], tuple[float, float, float]]
    ] = Counter()
    actual_inner_segments: Counter[
        tuple[tuple[float, float, float], tuple[float, float, float]]
    ] = Counter()
    for facet in boundary_facets:
        points = tuple(
            node_by_index[index].target_local_coordinates_mm
            for index in facet.node_indices
        )
        for first, second in zip(points, points[1:] + points[:1]):
            edge = _edge_key(first, second)
            boundary_edge_owners[edge] += 1
            if (
                facet.side is OrthogonalBoundarySide.BASE
                and _inner_perimeter_side_for_edge(
                    root,
                    first,
                    second,
                    tolerance,
                )
                is not None
            ):
                actual_inner_segments[edge] += 1
    connected_components = _connected_element_component_count(
        elements,
        face_owners,
    )
    if any(element.gmsh_type != 5 for element in elements):
        raise OrthogonalFilletError("orthogonal multiblock emitted a non-HEX8")

    approximated_volume = math.fsum(element.volume_mm3 for element in elements)
    analytic_volume = _analytic_volume(root)
    signed_error = approximated_volume - analytic_volume
    maximum_edge = max(
        upper - lower
        for element in elements
        for lower, upper in element.bounds_xyz_mm
    )
    maximum_requested_generated_edge = max(
        target_edge,
        z_maximum_edge,
        *normal_size_by_side.values(),
    )
    maximum_locked_edge = max(
        maximum_chain_edge,
        (
            0.0
            if wall_partitions is None
            else wall_partitions.maximum_locked_edge_mm
        ),
        (
            0.0
            if base_partition is None
            else base_partition.maximum_locked_edge_mm
        ),
    )
    if maximum_edge > max(
        maximum_requested_generated_edge,
        maximum_locked_edge,
    ) + tolerance:
        raise OrthogonalFilletError(
            "orthogonal multiblock generated an edge larger than every "
            "directional request and immutable edge"
        )
    chain_payload = tuple(
        (chain.chain_id, chain.side.value, chain.points) for chain in chains
    )
    target_geometry_payload = {
        "fragment_id": target_fragment.fragment_id,
        "die_origin_xy_mm": root.die_origin_xy_mm,
        "die_size_xy_mm": root.die_size_xy_mm,
        "base_z_mm": root.base_z_mm,
        "wall_height_mm": root.wall_height_mm,
        "toe_width_mm": root.toe_width_mm,
        "top_width_mm": root.top_width_mm,
        "placement": {
            "translation_xyz_mm": target_fragment.placement.translation_xyz_mm,
            "rotation_deg_xyz": target_fragment.placement.rotation_deg_xyz,
            "pivot_xyz_mm": target_fragment.placement.pivot_xyz_mm,
        },
    }
    mesh_payload = {
        "nodes": tuple(
            (node.node_index, node.target_local_coordinates_mm) for node in nodes
        ),
        "elements": tuple(
            (
                element.element_index,
                element.node_indices,
                element.cell_ijk,
                element.analytic_class.value,
                element.retention_reason.value,
                element.locked_seam_ids,
            )
            for element in elements
        ),
        "boundary_facets": tuple(
            (
                facet.side.value,
                facet.node_indices,
                facet.owner_element_index,
                facet.owner_local_face_index,
                facet.locked_seam_ids,
            )
            for facet in boundary_facets
        ),
    }
    accepted_full_count = sum(
        element.analytic_class is OrthogonalCellClass.FULL
        for element in elements
    )
    accepted_cut_count = sum(
        element.analytic_class is OrthogonalCellClass.CUT
        for element in elements
    )
    side_tangential_levels = tuple(
        (chain.side.value, chain.tangential_levels_mm) for chain in chains
    )
    side_normal_offsets = tuple(
        (side.value, tuple(normal_offsets_by_side[side]))
        for side in (
            OrthogonalBoundarySide.DIE_X_MIN,
            OrthogonalBoundarySide.DIE_X_MAX,
            OrthogonalBoundarySide.DIE_Y_MIN,
            OrthogonalBoundarySide.DIE_Y_MAX,
        )
    )
    radial_offsets = tuple(
        normal_offsets_by_side[OrthogonalBoundarySide.DIE_X_MIN]
    )
    audit = OrthogonalMultiblockFilletAudit(
        _CUT_RULE,
        target_edge,
        near_edge,
        shared_surface_id,
        side_tangential_levels,
        radial_offsets,
        z_levels,
        len(blocks),
        len(chains),
        sum(len(chain.segment_keys) for chain in chains),
        sum(actual_inner_segments.values()),
        _digest(chain_payload),
        classifications.total,
        classifications[OrthogonalCellClass.FULL],
        classifications[OrthogonalCellClass.CUT],
        classifications[OrthogonalCellClass.OUTSIDE],
        accepted_full_count,
        accepted_cut_count,
        classifications[OrthogonalCellClass.CUT] - accepted_cut_count,
        (
            len(resolved_base_faces)
            if shared_surface_id is not None or base_partition is not None
            else 0
        ),
        locked_cut_override_count,
        len(boundary_facets),
        len(boundary_edge_owners),
        min(boundary_edge_owners.values()),
        max(boundary_edge_owners.values()),
        connected_components,
        approximated_volume,
        analytic_volume,
        signed_error,
        abs(signed_error),
        abs(signed_error) / analytic_volume,
        maximum_edge,
        _digest(target_geometry_payload),
        _digest(mesh_payload),
        side_normal_offsets,
        (
            chain_target_override_count
            + (
                0
                if wall_partitions is None
                else wall_partitions.target_override_edge_count
            )
            + (
                0
                if base_partition is None
                else base_partition.target_override_edge_count
            )
        ),
        maximum_locked_edge,
        authoritative_base_override_count,
        tuple(len(values) for values in active_xy_by_layer),
        active_xy_sets_nested,
        max(element.bounds_xyz_mm[2][1] for element in elements),
        mesh_warnings=_mesh_topology_warnings(target_fragment, nodes, elements, face_owners),
    )
    return OrthogonalMultiblockFilletMesh(
        nodes,
        tuple(elements),
        tuple(boundary_facets),
        audit,
        tuple(bounds for _block, _local, bounds in planar_cells),
    )


class CounterLike:
    """Tiny enum counter kept private to avoid exposing policy vocabulary."""

    def __init__(self) -> None:
        self._values = {value: 0 for value in OrthogonalCellClass}

    def add(self, value: OrthogonalCellClass) -> None:
        self._values[value] += 1

    def __getitem__(self, value: OrthogonalCellClass) -> int:
        return self._values[value]

    @property
    def total(self) -> int:
        return sum(self._values.values())


__all__ = [
    "LockedCartesianBoundaryChain",
    "LockedCartesianQuad",
    "OrthogonalBoundaryFacet",
    "OrthogonalBoundarySide",
    "OrthogonalCellClass",
    "OrthogonalFilletAudit",
    "OrthogonalFilletError",
    "OrthogonalFilletMesh",
    "OrthogonalHexElement",
    "OrthogonalHexNode",
    "OrthogonalMultiblockFilletAudit",
    "OrthogonalMultiblockFilletMesh",
    "OrthogonalRetentionReason",
    "mesh_rectangular_fillet_orthogonal_hex",
    "mesh_rectangular_fillet_orthogonal_hex_multiblock",
]
