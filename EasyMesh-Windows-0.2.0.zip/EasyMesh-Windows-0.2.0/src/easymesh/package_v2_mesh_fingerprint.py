"""Background mesh fingerprints; saving a pose never accepts new file contents."""
from dataclasses import dataclass
from pathlib import Path
from threading import Event

from PySide6.QtCore import QObject, QRunnable, QThreadPool, QTimer, Signal, Qt
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QWidget

from .package_v2_mesh_groups import mesh_file_signature
from .package_v2_mesh_cache import mesh_file_entry, verify_mesh_entry


@dataclass(frozen=True)
class MeshFingerprint:
    sha256: str
    signature: tuple[int, ...]


def fingerprint_mesh_file(path, *, cancelled=lambda: False):
    path = Path(path)
    entry = mesh_file_entry(path, cancelled=cancelled)
    verify_mesh_entry(entry)
    return MeshFingerprint(entry.capture.snapshot.sha256, entry.signature)


class _FingerprintSignals(QObject):
    finished = Signal(int, object, str)


class _FingerprintTask(QRunnable):
    def __init__(self, generation, path):
        super().__init__()
        self.generation, self.path = generation, path
        self.cancelled = Event()
        self.signals = _FingerprintSignals()

    def run(self):
        try:
            result = fingerprint_mesh_file(self.path, cancelled=self.cancelled.is_set)
        except (OSError, ValueError, RuntimeError) as error:
            result, message = None, str(error)
        else:
            message = ""
        if not self.cancelled.is_set():
            self.signals.finished.emit(self.generation, result, message)


class MeshFingerprintWidget(QWidget):
    updateRequested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.path = None
        self.sha256 = None
        self.fingerprint = None
        self.loading = False
        self.error = "请先选择网格文件。"
        self._generation, self._task = 0, None
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.status = QLabel(self.error)
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        self.status.setWordWrap(True)
        layout.addWidget(self.status, 1)
        self.update_button = QPushButton("更新网格引用")
        self.update_button.setToolTip("确认使用文件当前内容，重新计算并记录网格指纹；保存实例后生效。")
        self.update_button.clicked.connect(self._update)
        layout.addWidget(self.update_button)
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(180)
        self.timer.timeout.connect(self._start)

    def cancel(self):
        self.timer.stop()
        self._generation += 1
        if self._task is not None:
            self._task.cancelled.set()
            self._task = None
        self.loading = False

    def set_mesh(self, path, *, sha256=None, immediate=False):
        self.cancel()
        self.path, self.sha256 = path, sha256
        self.fingerprint = None
        self.update_button.setEnabled(bool(path))
        self.error = "请先选择网格文件。" if not path else ""
        if sha256:
            self.status.setText("已记录网格指纹，运行前会核对文件内容。")
        elif path:
            self.loading = True
            self.status.setText("正在后台计算网格指纹…")
            self._start() if immediate else self.timer.start()
        else:
            self.status.setText(self.error)

    def _update(self):
        self.updateRequested.emit()
        self.set_mesh(self.path, immediate=True)

    def _start(self):
        if not self.path:
            return
        task = _FingerprintTask(self._generation, self.path)
        task.signals.finished.connect(self._loaded)
        self._task = task
        QThreadPool.globalInstance().start(task)

    def _loaded(self, generation, fingerprint, error):
        if generation != self._generation:
            return
        self._task, self.loading = None, False
        self.fingerprint, self.error = fingerprint, error
        self.sha256 = fingerprint.sha256 if fingerprint else None
        self.status.setText("已计算网格指纹，保存实例后生效。" if fingerprint else error)

    def selected_sha256(self, *, allow_offline=False):
        if self.loading:
            raise ValueError("正在后台计算网格指纹，请稍候。")
        if self.fingerprint is not None:
            try:
                signature = mesh_file_signature(self.path)
            except OSError as error:
                raise ValueError(f"无法访问网格文件：{error}") from error
            if signature != self.fingerprint.signature:
                raise ValueError("网格在计算指纹后发生变化，请核对后点击“更新网格引用”。")
        if self.sha256 is None and not allow_offline:
            raise ValueError(self.error or "请先计算网格指纹。")
        return self.sha256
