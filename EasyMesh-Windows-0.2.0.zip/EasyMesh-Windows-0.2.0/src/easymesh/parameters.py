from __future__ import annotations

import json
import math
import re
from dataclasses import asdict, dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Iterable


UM_TO_MM = 1.0e-3
# Kept as a compatibility constant for callers which mean the historical
# 45-degree-sector mode.  New meshing code should read ``parameters.sector_count``.
SECTOR_COUNT = 8
MIN_NUMERICAL_SEPARATION_UM = 1.0e-5
MAX_NUMERICAL_LENGTH_UM = 1.0e9
MAX_DEMO_REGION_COUNT = 128
MAX_DEMO_ESTIMATED_PROJECTED_ELEMENTS = 50_000
MAX_DEMO_THICKNESS_LAYERS = 10_000
MAX_DEMO_ESTIMATED_ELEMENTS = 5_000_000


class SymmetryMode(str, Enum):
    """Reflection axes retained by the projected mesh topology.

    ``XY_45`` is the historical mode: the mesh is symmetric about x, y and
    both 45-degree diagonal axes.  ``XY`` retains only x/y reflection
    symmetry, allowing a planner to use 90-degree sectors without also
    constraining the diagonals.
    """

    XY_45 = "xy_45"
    XY = "xy"

    @property
    def sector_count(self) -> int:
        return 8 if self is SymmetryMode.XY_45 else 4

    @property
    def symmetry_axes_deg(self) -> tuple[int, ...]:
        if self is SymmetryMode.XY_45:
            return (0, 45, 90, 135)
        return (0, 90)


def normalize_symmetry_mode(value: object) -> SymmetryMode:
    """Return the persisted symmetry mode, rejecting unstable aliases."""

    if isinstance(value, SymmetryMode):
        return value
    cause: ValueError | None = None
    if isinstance(value, str):
        try:
            return SymmetryMode(value.strip().lower())
        except ValueError as error:
            cause = error
    supported = ", ".join(mode.value for mode in SymmetryMode)
    raise ValueError(f"symmetry_mode must be one of: {supported}") from cause


def parse_diameters(text: str) -> tuple[float, ...]:
    """Parse comma-, semicolon-, or whitespace-separated diameters in micrometres."""
    tokens = [token for token in re.split(r"[,;\s]+", text.strip()) if token]
    if not tokens:
        raise ValueError("至少需要一个同心圆直径。")
    try:
        values = tuple(float(token) for token in tokens)
    except ValueError as exc:
        raise ValueError("直径必须是用空格或逗号分隔的数字。") from exc
    if any(not math.isfinite(value) or value <= 0 for value in values):
        raise ValueError("所有直径必须是有限的正数。")
    if len(set(values)) != len(values):
        raise ValueError("同心圆直径不能重复。")
    return tuple(sorted(values, reverse=True))


@dataclass(frozen=True)
class MeshParameters:
    diameters_um: tuple[float, ...] = (80.0, 70.0, 66.0, 50.0, 40.0)
    thickness_um: float = 2.7
    target_xy_um: float = 4.0
    target_z_um: float = 1.35
    model_name: str = "concentric_ring_demo"
    symmetry_mode: SymmetryMode = SymmetryMode.XY_45

    def __post_init__(self) -> None:
        normalized = tuple(sorted((float(value) for value in self.diameters_um), reverse=True))
        object.__setattr__(self, "diameters_um", normalized)
        object.__setattr__(
            self,
            "symmetry_mode",
            normalize_symmetry_mode(self.symmetry_mode),
        )
        self.validate()

    def validate(self) -> None:
        if not self.diameters_um:
            raise ValueError("至少需要一个同心圆直径。")
        if len(set(self.diameters_um)) != len(self.diameters_um):
            raise ValueError("同心圆直径不能重复。")
        if len(self.diameters_um) > MAX_DEMO_REGION_COUNT:
            raise ValueError(
                "同心圆数量超过当前 demo 的安全上限 "
                f"{MAX_DEMO_REGION_COUNT}。"
            )
        if any(not math.isfinite(value) or value <= 0 for value in self.diameters_um):
            raise ValueError("所有直径必须是有限的正数。")
        for name, value in (
            ("厚度", self.thickness_um),
            ("平面网格尺寸", self.target_xy_um),
            ("厚度方向网格尺寸", self.target_z_um),
        ):
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name}必须是有限的正数。")
        if not self.model_name.strip():
            raise ValueError("模型名称不能为空。")
        if any(
            value > MAX_NUMERICAL_LENGTH_UM
            for value in (
                *self.diameters_um,
                self.thickness_um,
                self.target_xy_um,
                self.target_z_um,
            )
        ):
            raise ValueError(
                f"输入尺寸超过数值建模上限 {MAX_NUMERICAL_LENGTH_UM:g} µm。"
            )
        if self.thickness_um < MIN_NUMERICAL_SEPARATION_UM:
            raise ValueError(
                f"厚度小于数值建模下限 {MIN_NUMERICAL_SEPARATION_UM:g} µm。"
            )
        for label, value in (
            ("平面网格尺寸", self.target_xy_um),
            ("厚度方向网格尺寸", self.target_z_um),
            ("最小圆半径", min(self.diameters_um) * 0.5),
        ):
            if value < MIN_NUMERICAL_SEPARATION_UM:
                raise ValueError(
                    f"{label}小于数值建模下限 {MIN_NUMERICAL_SEPARATION_UM:g} µm。"
                )
        ascending_radii = sorted(value * 0.5 for value in self.diameters_um)
        if any(
            outer - inner < MIN_NUMERICAL_SEPARATION_UM
            for inner, outer in zip(ascending_radii, ascending_radii[1:])
        ):
            raise ValueError(
                "相邻同心圆的半径差小于数值建模下限 "
                f"{MIN_NUMERICAL_SEPARATION_UM:g} µm。"
            )
        layer_ratio = self.thickness_um / self.target_z_um
        if not math.isfinite(layer_ratio) or math.ceil(layer_ratio) > MAX_DEMO_THICKNESS_LAYERS:
            raise ValueError(
                "厚度方向层数超过当前 demo 的安全上限 "
                f"{MAX_DEMO_THICKNESS_LAYERS:,}。"
            )
        outer_radius_um = max(self.diameters_um) * 0.5
        radius_ratio = outer_radius_um / self.target_xy_um
        area_estimate = math.pi * radius_ratio * radius_ratio
        mandatory_ring_estimate = sum(
            self.sector_count
            * max(
                1,
                math.ceil(
                    2.0
                    * math.pi
                    * radius
                    / (self.sector_count * self.target_xy_um)
                ),
            )
            for radius in ascending_radii
        )
        projected_estimate = max(area_estimate, mandatory_ring_estimate)
        if projected_estimate > MAX_DEMO_ESTIMATED_PROJECTED_ELEMENTS:
            raise ValueError(
                "预计二维投影单元数超过当前 demo 的交互上限 "
                f"{MAX_DEMO_ESTIMATED_PROJECTED_ELEMENTS:,}；请增大平面网格尺寸。"
            )
        total_estimate = projected_estimate * max(1, math.ceil(layer_ratio))
        if not math.isfinite(total_estimate) or total_estimate > MAX_DEMO_ESTIMATED_ELEMENTS:
            raise ValueError(
                "预计三维单元数超过当前 demo 的安全上限 "
                f"{MAX_DEMO_ESTIMATED_ELEMENTS:,}；请增大网格尺寸。"
            )

    @property
    def diameters_mm(self) -> tuple[float, ...]:
        return tuple(value * UM_TO_MM for value in self.diameters_um)

    @property
    def radii_mm_ascending(self) -> tuple[float, ...]:
        return tuple(sorted(value * 0.5 for value in self.diameters_mm))

    @property
    def thickness_mm(self) -> float:
        return self.thickness_um * UM_TO_MM

    @property
    def target_xy_mm(self) -> float:
        return self.target_xy_um * UM_TO_MM

    @property
    def target_z_mm(self) -> float:
        return self.target_z_um * UM_TO_MM

    @property
    def sector_count(self) -> int:
        return self.symmetry_mode.sector_count

    @property
    def symmetry_axes_deg(self) -> tuple[int, ...]:
        return self.symmetry_mode.symmetry_axes_deg

    @property
    def angular_elements_per_sector(self) -> int:
        outer_radius = self.radii_mm_ascending[-1]
        approximate = (
            2.0
            * math.pi
            * outer_radius
            / (self.sector_count * self.target_xy_mm)
        )
        candidates = {
            max(1, math.floor(approximate)),
            max(1, math.ceil(approximate)),
        }
        return min(
            candidates,
            key=lambda count: abs(
                math.log(
                    2.0
                    * outer_radius
                    * math.sin(math.pi / (self.sector_count * count))
                    / self.target_xy_mm
                )
            ),
        )

    @property
    def thickness_layers(self) -> int:
        return max(1, math.ceil(self.thickness_mm / self.target_z_mm))

    @property
    def estimated_hex_count(self) -> int:
        from .topology import build_topology

        return build_topology(self).quadrilateral_count * self.thickness_layers

    @property
    def estimated_wedge_count(self) -> int:
        from .topology import build_topology

        return build_topology(self).triangle_count * self.thickness_layers

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["diameters_um"] = list(self.diameters_um)
        # ``SymmetryMode`` subclasses str for json compatibility, but emitting
        # its value explicitly also keeps this mapping stable for non-json
        # consumers and across Python enum implementations.
        data["symmetry_mode"] = self.symmetry_mode.value
        return data

    def derived_dict(self) -> dict[str, Any]:
        from .topology import build_topology

        topology = build_topology(self)
        return {
            "length_unit": "mm",
            "symmetry_mode": self.symmetry_mode.value,
            "sector_count": self.sector_count,
            "sector_angle_deg": 360.0 / self.sector_count,
            "symmetry_axes_deg": list(self.symmetry_axes_deg),
            "optimization_priority": [
                "projected_edge_length",
                "quadrilateral_projected_area_within_edge_tolerance",
            ],
            "outer_angular_elements_per_sector": topology.rings[-1].elements_per_sector,
            "ring_radii_um": [ring.radius_um for ring in topology.rings],
            "ring_elements_per_sector": [
                ring.elements_per_sector for ring in topology.rings
            ],
            "center_count_path": list(topology.center_count_path),
            "outer_radial_layers": list(topology.outer_radial_layers),
            "thickness_layers": self.thickness_layers,
            "estimated_hex_count": topology.quadrilateral_count * self.thickness_layers,
            "estimated_wedge_count": topology.triangle_count * self.thickness_layers,
            "target_projected_edge_length_um": self.target_xy_um,
            "projected_edge_length": topology.edge_length.to_dict(),
            "projected_edge_length_by_region": {
                str(region): statistics.to_dict()
                for region, statistics in topology.edge_length_by_region.items()
            },
            "secondary_target_quadrilateral_area_um2": topology.target_quad_area_um2,
            "quadrilateral_projected_area": topology.quad_area.to_dict(),
            "triangle_projected_area_excluded_from_uniformity": topology.triangle_area.to_dict(),
        }

    def save_json(self, path: str | Path) -> Path:
        output = Path(path)
        output.parent.mkdir(parents=True, exist_ok=True)
        payload = {"parameters": self.to_dict(), "derived": self.derived_dict()}
        output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        return output

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MeshParameters":
        if "parameters" in data:
            data = data["parameters"]
        return cls(
            diameters_um=tuple(float(value) for value in data["diameters_um"]),
            thickness_um=float(data.get("thickness_um", 2.7)),
            target_xy_um=float(data.get("target_xy_um", 4.0)),
            target_z_um=float(data.get("target_z_um", 1.35)),
            model_name=str(data.get("model_name", "concentric_ring_demo")),
            symmetry_mode=data.get("symmetry_mode", SymmetryMode.XY_45.value),
        )

    @classmethod
    def load_json(cls, path: str | Path) -> "MeshParameters":
        data = json.loads(Path(path).read_text(encoding="utf-8-sig"))
        return cls.from_dict(data)


def format_diameters(values: Iterable[float]) -> str:
    return ", ".join(f"{value:g}" for value in values)
