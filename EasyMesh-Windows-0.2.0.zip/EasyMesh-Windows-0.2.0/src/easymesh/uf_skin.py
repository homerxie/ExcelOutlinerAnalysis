"""Analytic underfill envelope and Cartesian surface-band classification.

The package mesher needs a small, deterministic geometry kernel before it can
decide how to replace the stair-stepped free surface with WEDGE/PYRAMID/TET
cells.  This module deliberately stops before connectivity generation.  It
describes the external fillet around a rectangular die, classifies background
Cartesian cells, and audits a proposed one- or two-cell-thick surface band.

All coordinates use one caller-selected unit (the package builder uses mm).
Mixing units is therefore a caller error; no conversion is performed here.
"""

from __future__ import annotations

from collections import Counter, deque
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from enum import Enum
import math
from typing import TypeAlias


CellIndex: TypeAlias = tuple[int, int, int]
Point3D: TypeAlias = tuple[float, float, float]


class UfSkinError(ValueError):
    """Raised when a UF envelope or surface-band contract is invalid."""


class UfCellClass(str, Enum):
    """Relationship between one Cartesian cell and the analytic UF solid."""

    OUTSIDE = "outside"
    FULL_HEX = "full_hex"
    CUT = "cut"


def _finite(value: object, *, field_name: str) -> float:
    if isinstance(value, bool):
        raise UfSkinError(f"{field_name} must be finite")
    try:
        result = float(value)
    except (TypeError, ValueError) as error:
        raise UfSkinError(f"{field_name} must be finite") from error
    if not math.isfinite(result):
        raise UfSkinError(f"{field_name} must be finite")
    return result


def _positive(value: object, *, field_name: str) -> float:
    result = _finite(value, field_name=field_name)
    if result <= 0.0:
        raise UfSkinError(f"{field_name} must be positive")
    return result


@dataclass(frozen=True, slots=True)
class CartesianCell:
    """Closed axis-aligned background cell.

    Classification concerns positive cell volume.  Merely touching the UF at
    one face, edge, or vertex does not turn an otherwise exterior cell into a
    cut cell.
    """

    x_min: float
    x_max: float
    y_min: float
    y_max: float
    z_min: float
    z_max: float

    def __post_init__(self) -> None:
        for minimum_name, maximum_name in (
            ("x_min", "x_max"),
            ("y_min", "y_max"),
            ("z_min", "z_max"),
        ):
            minimum = _finite(getattr(self, minimum_name), field_name=minimum_name)
            maximum = _finite(getattr(self, maximum_name), field_name=maximum_name)
            if maximum <= minimum:
                raise UfSkinError(f"{maximum_name} must be greater than {minimum_name}")
            object.__setattr__(self, minimum_name, minimum)
            object.__setattr__(self, maximum_name, maximum)

    @property
    def vertices(self) -> tuple[Point3D, ...]:
        """The eight vertices in deterministic bottom-then-top order."""

        return tuple(
            (x, y, z)
            for z in (self.z_min, self.z_max)
            for y in (self.y_min, self.y_max)
            for x in (self.x_min, self.x_max)
        )


@dataclass(frozen=True, slots=True)
class RectangularUfEnvelope:
    """Linear fillet envelope outside a rectangular die.

    For a die centred at ``(center_x, center_y)``, the outward plan-view
    distance is

    ``d = hypot(max(abs(x-cx)-die_width/2, 0),
                 max(abs(y-cy)-die_length/2, 0))``.

    The free surface is ``base_z + height * (1 - d / fillet_width)``.  The UF
    solid excludes the open die interior, ends at ``d == fillet_width``, and is
    bounded below by ``base_z``.
    """

    die_width: float
    die_length: float
    base_z: float
    height: float
    fillet_width: float
    center_x: float = 0.0
    center_y: float = 0.0

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "die_width",
            _positive(self.die_width, field_name="die_width"),
        )
        object.__setattr__(
            self,
            "die_length",
            _positive(self.die_length, field_name="die_length"),
        )
        object.__setattr__(
            self,
            "height",
            _positive(self.height, field_name="height"),
        )
        object.__setattr__(
            self,
            "fillet_width",
            _positive(self.fillet_width, field_name="fillet_width"),
        )
        for field_name in ("base_z", "center_x", "center_y"):
            object.__setattr__(
                self,
                field_name,
                _finite(getattr(self, field_name), field_name=field_name),
            )

    @property
    def half_die_width(self) -> float:
        return 0.5 * self.die_width

    @property
    def half_die_length(self) -> float:
        return 0.5 * self.die_length

    @property
    def apex_z(self) -> float:
        """Free-surface height at a die side or corner."""

        return self.base_z + self.height

    @property
    def toe_z(self) -> float:
        return self.base_z

    def outside_distance(self, x: float, y: float) -> float:
        """Shortest plan-view distance from ``(x, y)`` to the die rectangle."""

        x_value = _finite(x, field_name="x")
        y_value = _finite(y, field_name="y")
        dx = max(abs(x_value - self.center_x) - self.half_die_width, 0.0)
        dy = max(abs(y_value - self.center_y) - self.half_die_length, 0.0)
        return math.hypot(dx, dy)

    def top_height(self, x: float, y: float) -> float:
        """Analytic free-surface height, including its continuation past the toe.

        Call :meth:`contains_xy` when footprint membership also matters.  The
        un-clamped continuation makes monotonicity explicit and prevents points
        beyond the toe from being mistaken for zero-thickness UF.
        """

        distance = self.outside_distance(x, y)
        return self.base_z + self.height * (1.0 - distance / self.fillet_width)

    def is_outside_die(self, x: float, y: float) -> bool:
        """Whether a point is outside the open die interior.

        The die boundary is included because it is the UF/die interface.
        """

        x_value = _finite(x, field_name="x")
        y_value = _finite(y, field_name="y")
        return (
            abs(x_value - self.center_x) >= self.half_die_width
            or abs(y_value - self.center_y) >= self.half_die_length
        )

    def contains_xy(self, x: float, y: float) -> bool:
        """Closed plan-view UF footprint membership."""

        return self.is_outside_die(x, y) and self.outside_distance(
            x, y
        ) <= self.fillet_width

    def contains(self, x: float, y: float, z: float) -> bool:
        """Closed-point membership in the analytic UF solid."""

        z_value = _finite(z, field_name="z")
        return (
            self.contains_xy(x, y)
            and self.base_z <= z_value <= self.top_height(x, y)
        )

    def _cell_has_external_xy_volume(self, cell: CartesianCell) -> bool:
        left = self.center_x - self.half_die_width
        right = self.center_x + self.half_die_width
        bottom = self.center_y - self.half_die_length
        top = self.center_y + self.half_die_length
        return (
            cell.x_min < left
            or cell.x_max > right
            or cell.y_min < bottom
            or cell.y_max > top
        )

    def _cell_overlaps_open_die_interior(self, cell: CartesianCell) -> bool:
        left = self.center_x - self.half_die_width
        right = self.center_x + self.half_die_width
        bottom = self.center_y - self.half_die_length
        top = self.center_y + self.half_die_length
        return (
            cell.x_min < right
            and cell.x_max > left
            and cell.y_min < top
            and cell.y_max > bottom
        )

    def _minimum_cell_distance(self, cell: CartesianCell) -> float:
        left = self.center_x - self.half_die_width
        right = self.center_x + self.half_die_width
        bottom = self.center_y - self.half_die_length
        top = self.center_y + self.half_die_length
        dx = max(left - cell.x_max, cell.x_min - right, 0.0)
        dy = max(bottom - cell.y_max, cell.y_min - top, 0.0)
        return math.hypot(dx, dy)

    def classify_cell(self, cell: CartesianCell) -> "UfCellClassification":
        """Classify one background cell without constructing mixed elements.

        ``FULL_HEX`` is intentionally conservative: all eight vertices must be
        inside and the cell may not cross the die's open interior.  A cell with
        positive-volume intersection that fails this rule is ``CUT``.  The
        analytic AABB intersection check also catches curved-surface cuts for
        which none of the eight vertices happens to lie inside.
        """

        if not isinstance(cell, CartesianCell):
            raise TypeError("cell must be a CartesianCell")
        vertex_membership = tuple(self.contains(*point) for point in cell.vertices)
        inside_vertex_count = sum(vertex_membership)
        minimum_distance = self._minimum_cell_distance(cell)
        maximum_top = self.base_z + self.height * (
            1.0 - minimum_distance / self.fillet_width
        )

        if (
            inside_vertex_count == 8
            and not self._cell_overlaps_open_die_interior(cell)
        ):
            kind = UfCellClass.FULL_HEX
        else:
            # A cell that only touches the toe or free surface has no UF volume.
            # Leave a scale-aware margin so harmless round-off in expressions
            # such as ``1 - 90/200`` cannot manufacture a zero-volume CUT cell.
            intersection_tolerance = 1.0e-12 * max(
                1.0,
                abs(cell.x_min),
                abs(cell.x_max),
                abs(cell.y_min),
                abs(cell.y_max),
                abs(cell.z_min),
                abs(cell.z_max),
                abs(self.base_z),
                self.die_width,
                self.die_length,
                self.height,
                self.fillet_width,
            )
            has_positive_intersection = (
                self._cell_has_external_xy_volume(cell)
                and minimum_distance < self.fillet_width - intersection_tolerance
                and cell.z_max > self.base_z + intersection_tolerance
                and cell.z_min < maximum_top - intersection_tolerance
            )
            kind = UfCellClass.CUT if has_positive_intersection else UfCellClass.OUTSIDE

        return UfCellClassification(
            kind=kind,
            inside_vertex_count=inside_vertex_count,
            minimum_outside_distance=minimum_distance,
            maximum_top_height=maximum_top,
        )


@dataclass(frozen=True, slots=True)
class UfCellClassification:
    """Auditable result of classifying one Cartesian cell."""

    kind: UfCellClass
    inside_vertex_count: int
    minimum_outside_distance: float
    maximum_top_height: float

    @property
    def intersects(self) -> bool:
        return self.kind is not UfCellClass.OUTSIDE


def classify_cartesian_cell(
    envelope: RectangularUfEnvelope,
    cell: CartesianCell,
) -> UfCellClassification:
    """Functional wrapper around :meth:`RectangularUfEnvelope.classify_cell`."""

    if not isinstance(envelope, RectangularUfEnvelope):
        raise TypeError("envelope must be a RectangularUfEnvelope")
    return envelope.classify_cell(cell)


def _validate_cell_index(index: object) -> CellIndex:
    if (
        not isinstance(index, tuple)
        or len(index) != 3
        or any(isinstance(value, bool) or not isinstance(value, int) for value in index)
    ):
        raise UfSkinError("Cartesian cell indices must be (i, j, k) integer tuples")
    return index


def classify_cartesian_cells(
    envelope: RectangularUfEnvelope,
    cells: Mapping[CellIndex, CartesianCell],
) -> dict[CellIndex, UfCellClassification]:
    """Classify a sparse or complete indexed Cartesian cell collection."""

    if not isinstance(envelope, RectangularUfEnvelope):
        raise TypeError("envelope must be a RectangularUfEnvelope")
    result: dict[CellIndex, UfCellClassification] = {}
    for raw_index, cell in cells.items():
        index = _validate_cell_index(raw_index)
        result[index] = envelope.classify_cell(cell)
    return result


def _classification_kind(value: object) -> UfCellClass:
    if isinstance(value, UfCellClassification):
        return value.kind
    if isinstance(value, UfCellClass):
        return value
    if isinstance(value, str):
        try:
            return UfCellClass(value)
        except ValueError as error:
            raise UfSkinError(f"unknown UF cell classification: {value!r}") from error
    raise UfSkinError("classification values must be UfCellClass or UfCellClassification")


def _face_neighbours(index: CellIndex) -> tuple[CellIndex, ...]:
    i, j, k = index
    return (
        (i - 1, j, k),
        (i + 1, j, k),
        (i, j - 1, k),
        (i, j + 1, k),
        (i, j, k - 1),
        (i, j, k + 1),
    )


@dataclass(frozen=True, slots=True)
class SurfaceBandStatistics:
    """Classification totals and graph-depth audit for a proposed skin band.

    Analytic ``CUT`` cells are graph depth 1.  Any adjacent ``FULL_HEX`` cell
    deliberately consumed by the surface transition is depth 2, and so on.
    Depth is computed only through face-adjacent cells included in
    ``band_cells``.
    """

    outside_count: int
    full_hex_count: int
    cut_count: int
    band_cell_count: int
    depth_counts: tuple[tuple[int, int], ...]
    maximum_depth: int
    maximum_allowed_depth: int
    missing_cut_cells: tuple[CellIndex, ...]
    unknown_band_cells: tuple[CellIndex, ...]
    outside_band_cells: tuple[CellIndex, ...]
    unreachable_band_cells: tuple[CellIndex, ...]
    too_deep_cells: tuple[CellIndex, ...]

    @property
    def is_valid(self) -> bool:
        return not (
            self.missing_cut_cells
            or self.unknown_band_cells
            or self.outside_band_cells
            or self.unreachable_band_cells
            or self.too_deep_cells
        )

    @property
    def classification_counts(self) -> dict[str, int]:
        return {
            UfCellClass.OUTSIDE.value: self.outside_count,
            UfCellClass.FULL_HEX.value: self.full_hex_count,
            UfCellClass.CUT.value: self.cut_count,
        }

    @property
    def graph_depth_counts(self) -> dict[int, int]:
        return dict(self.depth_counts)

    def to_dict(self) -> dict[str, object]:
        return {
            "classification_counts": self.classification_counts,
            "band_cell_count": self.band_cell_count,
            "depth_counts": self.graph_depth_counts,
            "maximum_depth": self.maximum_depth,
            "maximum_allowed_depth": self.maximum_allowed_depth,
            "is_valid": self.is_valid,
            "missing_cut_cells": list(self.missing_cut_cells),
            "unknown_band_cells": list(self.unknown_band_cells),
            "outside_band_cells": list(self.outside_band_cells),
            "unreachable_band_cells": list(self.unreachable_band_cells),
            "too_deep_cells": list(self.too_deep_cells),
        }


def analyze_surface_band(
    classifications: Mapping[CellIndex, UfCellClass | UfCellClassification | str],
    band_cells: Iterable[CellIndex] | None = None,
    *,
    maximum_depth: int = 2,
) -> SurfaceBandStatistics:
    """Audit whether a proposed non-HEX band stays within graph depth 1 or 2.

    When ``band_cells`` is omitted, the analytic ``CUT`` cells themselves form
    the proposed one-layer band.  A supplied band must include every ``CUT``
    cell and may additionally consume face-adjacent ``FULL_HEX`` cells.
    """

    if isinstance(maximum_depth, bool) or not isinstance(maximum_depth, int):
        raise UfSkinError("maximum_depth must be a positive integer")
    if maximum_depth < 1:
        raise UfSkinError("maximum_depth must be a positive integer")

    kinds: dict[CellIndex, UfCellClass] = {}
    for raw_index, raw_kind in classifications.items():
        index = _validate_cell_index(raw_index)
        kinds[index] = _classification_kind(raw_kind)

    cut_cells = {index for index, kind in kinds.items() if kind is UfCellClass.CUT}
    if band_cells is None:
        band = set(cut_cells)
    else:
        band = {_validate_cell_index(index) for index in band_cells}

    unknown = tuple(sorted(band.difference(kinds)))
    known_band = band.intersection(kinds)
    outside = tuple(
        sorted(index for index in known_band if kinds[index] is UfCellClass.OUTSIDE)
    )
    missing_cut = tuple(sorted(cut_cells.difference(band)))

    traversable = {
        index for index in known_band if kinds[index] is not UfCellClass.OUTSIDE
    }
    seeds = sorted(cut_cells.intersection(traversable))
    depths: dict[CellIndex, int] = {index: 1 for index in seeds}
    queue: deque[CellIndex] = deque(seeds)
    while queue:
        current = queue.popleft()
        next_depth = depths[current] + 1
        for neighbour in _face_neighbours(current):
            if neighbour not in traversable or neighbour in depths:
                continue
            depths[neighbour] = next_depth
            queue.append(neighbour)

    unreachable = tuple(sorted(traversable.difference(depths)))
    too_deep = tuple(
        sorted(index for index, depth in depths.items() if depth > maximum_depth)
    )
    depth_counts = tuple(sorted(Counter(depths.values()).items()))
    maximum_seen = max(depths.values(), default=0)
    counts = Counter(kinds.values())
    return SurfaceBandStatistics(
        outside_count=counts[UfCellClass.OUTSIDE],
        full_hex_count=counts[UfCellClass.FULL_HEX],
        cut_count=counts[UfCellClass.CUT],
        band_cell_count=len(band),
        depth_counts=depth_counts,
        maximum_depth=maximum_seen,
        maximum_allowed_depth=maximum_depth,
        missing_cut_cells=missing_cut,
        unknown_band_cells=unknown,
        outside_band_cells=outside,
        unreachable_band_cells=unreachable,
        too_deep_cells=too_deep,
    )


def validate_surface_band(
    classifications: Mapping[CellIndex, UfCellClass | UfCellClassification | str],
    band_cells: Iterable[CellIndex] | None = None,
    *,
    maximum_depth: int = 2,
) -> SurfaceBandStatistics:
    """Return statistics for a valid band, otherwise raise :class:`UfSkinError`."""

    statistics = analyze_surface_band(
        classifications,
        band_cells,
        maximum_depth=maximum_depth,
    )
    if statistics.is_valid:
        return statistics

    reasons: list[str] = []
    for label, cells in (
        ("missing CUT", statistics.missing_cut_cells),
        ("unknown", statistics.unknown_band_cells),
        ("outside", statistics.outside_band_cells),
        ("unreachable", statistics.unreachable_band_cells),
        ("too deep", statistics.too_deep_cells),
    ):
        if cells:
            reasons.append(f"{label}={len(cells)}")
    raise UfSkinError("invalid UF surface band: " + ", ".join(reasons))


__all__ = [
    "CartesianCell",
    "CellIndex",
    "Point3D",
    "RectangularUfEnvelope",
    "SurfaceBandStatistics",
    "UfCellClass",
    "UfCellClassification",
    "UfSkinError",
    "analyze_surface_band",
    "classify_cartesian_cell",
    "classify_cartesian_cells",
    "validate_surface_band",
]
