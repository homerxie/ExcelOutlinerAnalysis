"""Gmsh-owned zero-tip fill behind one immutable Cartesian QUAD annulus.

This is a deliberately narrow geometry/topology backend.  It recognizes only
an exact zero-tip rectangular fillet whose sole lock is one complete planar
Cartesian QUAD annulus on ``base``.  The locked staircase is the negotiated
geometry authority only on that contact.  A short mapped adapter performs a
bounded, volume-conserving recovery toward the analytic rounded-rectangle
section before the free Hybrid boundary continues to the zero-width tip.

Gmsh creates both pieces of the volume.  A two-layer mapped boundary-layer
extrusion leaves one HEX8 behind every immutable QUAD and uses QuadTri for an
all-TRI interface.  The existing direct OCC/Gmsh backend then fills that exact
TRI annulus to the zero-width tip with TET/PYR/WEDGE elements.  EasyMesh only
maps the shared node identities and audits the two Gmsh connectivities.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import math
from statistics import median
from types import MappingProxyType
from typing import TypeAlias

from .gmsh_closed_shell_remainder import (
    GmshClosedShellElement,
    GmshClosedShellRemainder,
    _folded_internal_face_count,
    _orient_closed_shell,
)
from .gmsh_runtime import isolated_gmsh_model
from .gmsh_candidate_runtime import bounded_candidate_search, check_candidate_budget
from .occ_locked_hybrid import ConstrainedHybridError, _load_gmsh
from .occ_quadtri_adapter import (
    GmshQuadTriAdapter,
    generate_gmsh_mapped_quadtri_adapter,
)
from .occ_uf_conformal import (
    GmshUfConformalVolume,
    generate_rectangular_uf_conformal_hybrid,
)
from .occ_uf_surface_shell import GmshUfSurfaceShell
from .package_v2_geometry import CanonicalRectangularUnderfillFillet
from .package_v2_mesh_settings import validate_interface_geometry_tolerance_mm
from .uf_skin import RectangularUfEnvelope
from .volume_mesh import ELEMENT_SPECS


Point3D: TypeAlias = tuple[float, float, float]
FaceKey: TypeAlias = tuple[int, ...]

_TRI3 = 2
_QUAD4 = 3
_TET4 = 4
_HEX8 = 5
_WEDGE6 = 6
_PYRAMID5 = 7
_COORDINATE_TOLERANCE_MM = 1.0e-10
_QUALITY_FLOOR = 0.03
_CANONICAL_VOLUME_RELATIVE_TOLERANCE = 0.02
_QUADTRI_APPLIED_PATH = (
    "gmsh_locked_base_ruled_staircase_quadtri_and_tet_remainder"
)
_APPLIED_PATHS = frozenset({_QUADTRI_APPLIED_PATH})


class RectangularUfLockedBaseQuadTriFillError(ValueError):
    """The narrow locked-base Gmsh fill is ineligible or failed its audits."""


@dataclass(frozen=True, slots=True)
class RectangularUfLockedBaseQuadTriFill:
    """Audited combined mapped-QuadTri adapter and zero-tip remainder."""

    remainder: GmshClosedShellRemainder
    locked_facets_by_side: Mapping[str, tuple[tuple[int, ...], ...]]
    boundary_facets_by_side: Mapping[str, tuple[tuple[int, ...], ...]]
    adapter_height_mm: float
    geometry_recovery_height_mm: float
    adapter_first_layer_fraction: float
    adapter_method: str
    remainder_algorithm_3d: int
    source_quad_count: int
    source_quad_hex_owner_count: int
    source_hex_element_ids: tuple[int, ...]
    source_hex_minimum_sicn: float
    source_hex_minimum_sige: float
    source_hex_minimum_scaled_jacobian: float
    source_hex_sicn_aspect_quality_exempted: bool
    non_source_element_count: int
    non_source_minimum_sicn: float
    non_source_minimum_sige: float
    non_source_minimum_scaled_jacobian: float
    interface_triangle_count: int
    interface_quad_count: int
    interface_two_owner_count: int
    adapter_hex8_count: int
    adapter_pyramid5_count: int
    adapter_wedge6_count: int
    adapter_tet4_count: int
    remainder_tet4_count: int
    ruled_staircase_shell_volume_mm3: float
    ruled_staircase_element_volume_mm3: float
    ruled_staircase_volume_relative_error: float
    canonical_analytic_volume_mm3: float
    canonical_volume_relative_error: float
    recovery_section_analytic_area_mm2: float
    recovery_section_polygon_area_mm2: float
    recovery_section_area_relative_error: float
    recovery_minimum_signed_radial_deviation_mm: float
    recovery_maximum_signed_radial_deviation_mm: float
    recovery_maximum_radial_deviation_mm: float
    recovery_allowed_radial_deviation_mm: float
    required_quality: float
    candidate_attempts: tuple[str, ...]
    geometry_authority: str = (
        "exact_orth_staircase_base_with_bounded_analytic_recovery"
    )
    applied_path: str = _QUADTRI_APPLIED_PATH
    gmsh_owns_all_volume_connectivity: bool = True

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "locked_facets_by_side",
            MappingProxyType(dict(self.locked_facets_by_side)),
        )
        object.__setattr__(
            self,
            "boundary_facets_by_side",
            MappingProxyType(dict(self.boundary_facets_by_side)),
        )
        if self.applied_path not in _APPLIED_PATHS:
            raise RectangularUfLockedBaseQuadTriFillError(
                "mapped locked-base applied path is invalid"
            )
        if not self.gmsh_owns_all_volume_connectivity:
            raise RectangularUfLockedBaseQuadTriFillError(
                "mapped QuadTri fill must retain Gmsh-owned connectivity"
            )
        if (
            self.source_quad_count < 1
            or self.source_quad_hex_owner_count != self.source_quad_count
            or len(self.source_hex_element_ids) != self.source_quad_count
            or len(set(self.source_hex_element_ids))
            != len(self.source_hex_element_ids)
            or any(
                element_id < 1 or element_id > self.remainder.element_count
                for element_id in self.source_hex_element_ids
            )
            or any(
                self.remainder.elements[element_id - 1].gmsh_type != _HEX8
                for element_id in self.source_hex_element_ids
            )
            or self.non_source_element_count
            != self.remainder.element_count - len(self.source_hex_element_ids)
            or self.non_source_element_count < 1
            or self.interface_triangle_count < 0
            or self.interface_quad_count < 0
            or self.interface_triangle_count + self.interface_quad_count < 1
            or self.interface_two_owner_count
            != self.interface_triangle_count + self.interface_quad_count
        ):
            raise RectangularUfLockedBaseQuadTriFillError(
                "mapped QuadTri ownership evidence is incomplete"
            )
        if any(
            not math.isfinite(value)
            for value in (
                self.source_hex_minimum_sicn,
                self.source_hex_minimum_sige,
                self.source_hex_minimum_scaled_jacobian,
                self.non_source_minimum_sicn,
                self.non_source_minimum_sige,
                self.non_source_minimum_scaled_jacobian,
            )
        ):
            raise RectangularUfLockedBaseQuadTriFillError(
                "mapped QuadTri combined quality evidence is non-finite"
            )
        if (
            not math.isfinite(self.required_quality)
            or not _QUALITY_FLOOR <= self.required_quality < 1.0
        ):
            raise RectangularUfLockedBaseQuadTriFillError(
                "mapped QuadTri required quality is invalid"
            )
        if (
            self.source_hex_sicn_aspect_quality_exempted
            != (self.source_hex_minimum_sicn < self.required_quality)
        ):
            raise RectangularUfLockedBaseQuadTriFillError(
                "mapped QuadTri source-HEX SICN exemption evidence is inconsistent"
            )
        if min(
            self.source_hex_minimum_sige,
            self.source_hex_minimum_scaled_jacobian,
            self.non_source_minimum_sicn,
            self.non_source_minimum_sige,
            self.non_source_minimum_scaled_jacobian,
        ) < self.required_quality:
            raise RectangularUfLockedBaseQuadTriFillError(
                "mapped QuadTri strategy-aware quality evidence is below the "
                "required floor"
            )
        if self.source_hex_minimum_sicn <= 0.0:
            raise RectangularUfLockedBaseQuadTriFillError(
                "mapped QuadTri source-HEX SICN must remain positive"
            )
        if (
            self.canonical_volume_relative_error
            > _CANONICAL_VOLUME_RELATIVE_TOLERANCE
        ):
            raise RectangularUfLockedBaseQuadTriFillError(
                "ruled-staircase volume differs from the canonical fillet by more than 2%"
            )
        if (
            not math.isfinite(self.adapter_height_mm)
            or self.adapter_height_mm <= 0.0
            or not math.isfinite(self.geometry_recovery_height_mm)
            or self.geometry_recovery_height_mm <= 0.0
        ):
            raise RectangularUfLockedBaseQuadTriFillError(
                "mapped QuadTri geometry recovery height is invalid"
            )
        if (
            not math.isfinite(self.recovery_maximum_radial_deviation_mm)
            or not math.isfinite(
                self.recovery_minimum_signed_radial_deviation_mm
            )
            or not math.isfinite(
                self.recovery_maximum_signed_radial_deviation_mm
            )
            or not math.isfinite(self.recovery_allowed_radial_deviation_mm)
            or self.recovery_maximum_radial_deviation_mm < 0.0
            or self.recovery_allowed_radial_deviation_mm <= 0.0
            or self.recovery_maximum_radial_deviation_mm
            > self.recovery_allowed_radial_deviation_mm + _COORDINATE_TOLERANCE_MM
        ):
            raise RectangularUfLockedBaseQuadTriFillError(
                "mapped QuadTri local geometry coverage evidence is invalid"
            )


@dataclass(frozen=True, slots=True)
class _LockedBaseProof:
    coordinates: Mapping[int, Point3D]
    facets: tuple[tuple[int, int, int, int], ...]
    outer_loop: tuple[int, ...]
    inner_loop: tuple[int, ...]
    minimum_edge_mm: float
    median_edge_mm: float
    maximum_edge_mm: float
    maximum_edge_ratio: float


@dataclass(frozen=True, slots=True)
class _AnalyticRecoveryTargets:
    coordinates: Mapping[int, Point3D]
    geometry_recovery_height_mm: float
    analytic_section_area_mm2: float
    polygon_section_area_mm2: float
    section_area_relative_error: float
    minimum_signed_radial_deviation_mm: float
    maximum_signed_radial_deviation_mm: float
    maximum_radial_deviation_mm: float
    allowed_radial_deviation_mm: float


def _face_key(nodes: Sequence[int]) -> FaceKey:
    return tuple(sorted(int(node) for node in nodes))


def _edge_key(first: int, second: int) -> tuple[int, int]:
    return (first, second) if first < second else (second, first)


def _coordinate_key(point: Sequence[float]) -> tuple[float, float, float]:
    return tuple(round(float(value), 12) for value in point)  # type: ignore[return-value]


def _loop_area(loop: Sequence[int], coordinates: Mapping[int, Point3D]) -> float:
    return 0.5 * math.fsum(
        coordinates[first][0] * coordinates[second][1]
        - coordinates[second][0] * coordinates[first][1]
        for first, second in zip(loop, (*loop[1:], loop[0]))
    )


def _boundary_loops(
    facets: Sequence[Sequence[int]],
) -> tuple[tuple[int, ...], ...]:
    owners: dict[tuple[int, int], int] = Counter(
        _edge_key(first, second)
        for facet in facets
        for first, second in zip(facet, (*facet[1:], facet[0]))
    )
    if any(count not in {1, 2} for count in owners.values()):
        raise RectangularUfLockedBaseQuadTriFillError(
            "locked base QUAD annulus is topologically non-manifold"
        )
    adjacency: dict[int, set[int]] = defaultdict(set)
    for (first, second), count in owners.items():
        if count == 1:
            adjacency[first].add(second)
            adjacency[second].add(first)
    if not adjacency or any(len(values) != 2 for values in adjacency.values()):
        raise RectangularUfLockedBaseQuadTriFillError(
            "locked base QUAD annulus boundary does not form closed loops"
        )
    loops: list[tuple[int, ...]] = []
    remaining = set(adjacency)
    while remaining:
        start = min(remaining)
        loop = [start]
        previous: int | None = None
        current = start
        while True:
            options = sorted(adjacency[current].difference({previous}))
            if not options:
                raise RectangularUfLockedBaseQuadTriFillError(
                    "locked base QUAD annulus boundary loop is open"
                )
            following = options[0]
            if following == start:
                break
            if following in loop:
                raise RectangularUfLockedBaseQuadTriFillError(
                    "locked base QUAD annulus boundary loop self-intersects"
                )
            loop.append(following)
            previous, current = current, following
        remaining.difference_update(loop)
        loops.append(tuple(loop))
    return tuple(loops)


def _projected_cycle_edges(
    loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
    root: CanonicalRectangularUnderfillFillet,
) -> tuple[tuple[Point3D, Point3D], ...]:
    x_min, y_min = root.die_origin_xy_mm
    x_max = x_min + root.die_size_xy_mm[0]
    y_max = y_min + root.die_size_xy_mm[1]
    projected: list[tuple[float, float, float]] = []
    for node in loop:
        point = coordinates[node]
        value = _coordinate_key(
            (
                min(max(point[0], x_min), x_max),
                min(max(point[1], y_min), y_max),
                root.base_z_mm + root.wall_height_mm,
            )
        )
        if not projected or value != projected[-1]:
            projected.append(value)
    if len(projected) > 1 and projected[0] == projected[-1]:
        projected.pop()
    if len(projected) < 4:
        raise RectangularUfLockedBaseQuadTriFillError(
            "locked base outer staircase projection is degenerate"
        )
    return tuple(
        (first, second)
        for first, second in zip(projected, (*projected[1:], projected[0]))
    )


def _inner_cycle_edges(
    loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
    root: CanonicalRectangularUnderfillFillet,
) -> tuple[tuple[Point3D, Point3D], ...]:
    points = tuple(
        _coordinate_key(
            (
                coordinates[node][0],
                coordinates[node][1],
                root.base_z_mm + root.wall_height_mm,
            )
        )
        for node in loop
    )
    return tuple(
        (first, second)
        for first, second in zip(points, (*points[1:], points[0]))
    )


def _edge_cycles_match(
    first: Sequence[tuple[Point3D, Point3D]],
    second: Sequence[tuple[Point3D, Point3D]],
    tolerance_mm: float,
) -> bool:
    """Match two unoriented geometric edge cycles with an absolute tolerance."""

    if len(first) != len(second):
        return False
    unmatched = list(second)
    for first_start, first_end in first:
        match_index = next(
            (
                index
                for index, (second_start, second_end) in enumerate(unmatched)
                if (
                    math.dist(first_start, second_start) <= tolerance_mm
                    and math.dist(first_end, second_end) <= tolerance_mm
                )
                or (
                    math.dist(first_start, second_end) <= tolerance_mm
                    and math.dist(first_end, second_start) <= tolerance_mm
                )
            ),
            None,
        )
        if match_index is None:
            return False
        unmatched.pop(match_index)
    return not unmatched


def _prove_no_cartesian_t_junctions(
    coordinates: Mapping[int, Point3D],
    facets: Sequence[Sequence[int]],
    tolerance_mm: float,
) -> None:
    tolerance = tolerance_mm
    horizontal: list[tuple[float, float, float]] = []
    vertical: list[tuple[float, float, float]] = []

    def levels(values: Sequence[float]) -> tuple[float, ...]:
        ordered = sorted(values)
        groups: list[list[float]] = []
        for value in ordered:
            if not groups or value - groups[-1][-1] > tolerance:
                groups.append([value])
            else:
                groups[-1].append(value)
        return tuple(math.fsum(group) / len(group) for group in groups)

    for facet in facets:
        xs = levels(tuple(coordinates[node][0] for node in facet))
        ys = levels(tuple(coordinates[node][1] for node in facet))
        if len(xs) != 2 or len(ys) != 2:
            raise RectangularUfLockedBaseQuadTriFillError(
                "locked base QUAD is not one Cartesian rectangle"
            )
        expected_corners = {(x_index, y_index) for x_index in range(2) for y_index in range(2)}
        actual_corners = set()
        for node in facet:
            point = coordinates[node]
            x_candidates = tuple(
                index
                for index, value in enumerate(xs)
                if abs(point[0] - value) <= tolerance
            )
            y_candidates = tuple(
                index
                for index, value in enumerate(ys)
                if abs(point[1] - value) <= tolerance
            )
            if len(x_candidates) != 1 or len(y_candidates) != 1:
                raise RectangularUfLockedBaseQuadTriFillError(
                    "locked base QUAD has an ambiguous Cartesian corner"
                )
            actual_corners.add((x_candidates[0], y_candidates[0]))
        if actual_corners != expected_corners:
            raise RectangularUfLockedBaseQuadTriFillError(
                "locked base QUAD does not use four Cartesian rectangle corners"
            )
        for first, second in zip(facet, (*facet[1:], facet[0])):
            first_point = coordinates[first]
            second_point = coordinates[second]
            if abs(first_point[1] - second_point[1]) <= tolerance:
                horizontal.append(
                    (
                        0.5 * (first_point[1] + second_point[1]),
                        *tuple(sorted((first_point[0], second_point[0]))),
                    )
                )
            elif abs(first_point[0] - second_point[0]) <= tolerance:
                vertical.append(
                    (
                        0.5 * (first_point[0] + second_point[0]),
                        *tuple(sorted((first_point[1], second_point[1]))),
                    )
                )
            else:
                raise RectangularUfLockedBaseQuadTriFillError(
                    "locked base QUAD contains a non-Cartesian edge"
                )
    for fixed, lower, upper in horizontal:
        if any(
            abs(point[1] - fixed) <= tolerance
            and lower + tolerance < point[0] < upper - tolerance
            for point in coordinates.values()
        ):
            raise RectangularUfLockedBaseQuadTriFillError(
                "locked base Cartesian QUAD grid has an x-edge T-junction"
            )
    for fixed, lower, upper in vertical:
        if any(
            abs(point[0] - fixed) <= tolerance
            and lower + tolerance < point[1] < upper - tolerance
            for point in coordinates.values()
        ):
            raise RectangularUfLockedBaseQuadTriFillError(
                "locked base Cartesian QUAD grid has a y-edge T-junction"
            )


def _prove_locked_base(
    shell: GmshUfSurfaceShell,
    root: CanonicalRectangularUnderfillFillet,
    *,
    forced_partial_locked_sides: Sequence[str],
    interface_geometry_tolerance_mm: float,
) -> _LockedBaseProof:
    if type(shell) is not GmshUfSurfaceShell:
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped QuadTri path requires an exact Gmsh UF surface shell"
        )
    if type(root) is not CanonicalRectangularUnderfillFillet:
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped QuadTri path requires an exact rectangular fillet geometry"
        )
    tolerance = interface_geometry_tolerance_mm
    if abs(root.top_width_mm) > tolerance:
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped QuadTri path requires a zero-width tip"
        )
    if tuple(forced_partial_locked_sides):
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped QuadTri path does not accept forced-partial locks"
        )
    nonempty_sides = tuple(
        side for side, facets in shell.locked_facets_by_side.items() if facets
    )
    if nonempty_sides != ("base",):
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped QuadTri path requires base to be the sole locked side; "
            f"got {nonempty_sides!r}"
        )
    raw_facets = tuple(shell.locked_facets_by_side["base"])
    if not raw_facets or any(len(facet) != 4 for facet in raw_facets):
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped QuadTri path requires a non-empty all-QUAD base"
        )
    locked_keys = {_face_key(facet) for facet in raw_facets}
    if len(locked_keys) != len(raw_facets):
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped QuadTri locked base repeats a QUAD"
        )
    complete_base = tuple(shell.facets_by_geometric_side.get("base", ()))
    if (
        len(complete_base) != len(raw_facets)
        or {_face_key(facet) for facet in complete_base} != locked_keys
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped QuadTri locked base is not the complete shell base"
        )
    referenced = {node for facet in raw_facets for node in facet}
    coordinates = {
        node: tuple(float(value) for value in shell.node_coordinates[node])
        for node in sorted(referenced)
    }
    if any(
        abs(point[2] - root.base_z_mm) > tolerance
        for point in coordinates.values()
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped QuadTri locked base is not planar at the geometry base"
        )
    facets = tuple(tuple(int(node) for node in facet) for facet in raw_facets)
    _prove_no_cartesian_t_junctions(coordinates, facets, tolerance)
    edge_owners: dict[tuple[int, int], list[int]] = defaultdict(list)
    for facet_index, facet in enumerate(facets):
        for first, second in zip(facet, (*facet[1:], facet[0])):
            edge_owners[_edge_key(first, second)].append(facet_index)
    facet_adjacency: dict[int, set[int]] = defaultdict(set)
    for values in edge_owners.values():
        if len(values) == 2:
            facet_adjacency[values[0]].add(values[1])
            facet_adjacency[values[1]].add(values[0])
    seen_facets: set[int] = set()
    pending_facets = deque((0,))
    while pending_facets:
        current = pending_facets.popleft()
        if current in seen_facets:
            continue
        seen_facets.add(current)
        pending_facets.extend(facet_adjacency[current].difference(seen_facets))
    if len(seen_facets) != len(facets):
        raise RectangularUfLockedBaseQuadTriFillError(
            "locked base QUAD facet graph is not edge-connected"
        )
    loops = _boundary_loops(facets)
    if len(loops) != 2:
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped QuadTri locked base must be one two-loop annulus"
        )
    outer_loop, inner_loop = sorted(
        loops,
        key=lambda loop: abs(_loop_area(loop, coordinates)),
        reverse=True,
    )
    if abs(_loop_area(outer_loop, coordinates)) <= abs(
        _loop_area(inner_loop, coordinates)
    ) + tolerance**2:
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped QuadTri locked base annulus has invalid loop areas"
        )
    mesh_area = math.fsum(
        (
            max(coordinates[node][0] for node in facet)
            - min(coordinates[node][0] for node in facet)
        )
        * (
            max(coordinates[node][1] for node in facet)
            - min(coordinates[node][1] for node in facet)
        )
        for facet in facets
    )
    loop_area = abs(_loop_area(outer_loop, coordinates)) - abs(
        _loop_area(inner_loop, coordinates)
    )
    if not math.isclose(
        mesh_area,
        loop_area,
        rel_tol=1.0e-10,
        abs_tol=1.0e-14,
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "locked base Cartesian QUADs overlap or do not cover their annulus exactly: "
            f"mesh_area={mesh_area:.12g}, loop_area={loop_area:.12g}"
        )
    x_min, y_min = root.die_origin_xy_mm
    x_max = x_min + root.die_size_xy_mm[0]
    y_max = y_min + root.die_size_xy_mm[1]
    inner_sides: set[str] = set()
    for first, second in zip(inner_loop, (*inner_loop[1:], inner_loop[0])):
        first_point = coordinates[first]
        second_point = coordinates[second]
        matches = tuple(
            side
            for side, axis, value, tangent, lower, upper in (
                ("x_min", 0, x_min, 1, y_min, y_max),
                ("x_max", 0, x_max, 1, y_min, y_max),
                ("y_min", 1, y_min, 0, x_min, x_max),
                ("y_max", 1, y_max, 0, x_min, x_max),
            )
            if abs(first_point[axis] - value) <= tolerance
            and abs(second_point[axis] - value) <= tolerance
            and lower - tolerance
            <= first_point[tangent]
            <= upper + tolerance
            and lower - tolerance
            <= second_point[tangent]
            <= upper + tolerance
        )
        if len(matches) != 1:
            raise RectangularUfLockedBaseQuadTriFillError(
                "mapped QuadTri inner loop does not follow the die perimeter"
            )
        inner_sides.add(matches[0])
    if inner_sides != {"x_min", "x_max", "y_min", "y_max"}:
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped QuadTri inner loop does not cover all four die sides"
        )
    if not _edge_cycles_match(
        _projected_cycle_edges(outer_loop, coordinates, root),
        _inner_cycle_edges(inner_loop, coordinates, root),
        tolerance,
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped QuadTri outer staircase projection partition does not "
            "match the die-inner loop"
        )

    edge_lengths = tuple(
        math.dist(coordinates[first], coordinates[second])
        for first, second in {
            _edge_key(first, second)
            for facet in facets
            for first, second in zip(facet, (*facet[1:], facet[0]))
        }
    )
    if min(edge_lengths) <= tolerance:
        raise RectangularUfLockedBaseQuadTriFillError(
            "locked base QUAD grid contains an edge at or below the configured "
            "interface geometry tolerance"
        )
    quad_ratios = []
    for facet in facets:
        lengths = tuple(
            math.dist(coordinates[first], coordinates[second])
            for first, second in zip(facet, (*facet[1:], facet[0]))
        )
        quad_ratios.append(max(lengths) / min(lengths))
    return _LockedBaseProof(
        MappingProxyType(coordinates),
        facets,  # type: ignore[arg-type]
        tuple(outer_loop),
        tuple(inner_loop),
        min(edge_lengths),
        median(edge_lengths),
        max(edge_lengths),
        max(quad_ratios),
    )


def rectangular_uf_locked_base_quadtri_ineligibility(
    shell: GmshUfSurfaceShell,
    root: CanonicalRectangularUnderfillFillet,
    *,
    forced_partial_locked_sides: Sequence[str] = (),
    interface_geometry_tolerance_mm: float = 1.0e-5,
) -> str | None:
    """Return a geometry-only ineligibility reason without invoking Gmsh 3D."""

    try:
        tolerance = validate_interface_geometry_tolerance_mm(
            interface_geometry_tolerance_mm
        )
        _prove_locked_base(
            shell,
            root,
            forced_partial_locked_sides=forced_partial_locked_sides,
            interface_geometry_tolerance_mm=tolerance,
        )
    except (RectangularUfLockedBaseQuadTriFillError, ValueError) as error:
        return str(error)
    return None


def _candidate_parameters(
    proof: _LockedBaseProof,
    total_height_mm: float,
) -> tuple[tuple[float, float], ...]:
    median_edge = proof.median_edge_mm
    maximum_edge = proof.maximum_edge_mm
    raw_heights = (
        max(1.5 * median_edge, 0.10 * maximum_edge),
        max(1.0 * median_edge, 0.075 * maximum_edge),
        max(2.0 * median_edge, 0.15 * maximum_edge),
        max(3.0 * median_edge, 0.20 * maximum_edge),
    )
    candidates: list[tuple[float, float]] = []
    for raw_height in raw_heights:
        height = min(raw_height, 0.45 * total_height_mm)
        if (
            height <= _COORDINATE_TOLERANCE_MM
            or height >= total_height_mm - _COORDINATE_TOLERANCE_MM
        ):
            continue
        fraction = min(0.60, max(0.25, 0.60 * median_edge / height))
        candidate = (height, fraction)
        if candidate not in candidates:
            candidates.append(candidate)
    if not candidates:
        raise RectangularUfLockedBaseQuadTriFillError(
            "locked base edge lengths leave no positive mapped adapter height"
        )
    return tuple(candidates)


def _volume_conserving_adapter_heights(
    total_height_mm: float,
    near_size_mm: float,
    target_size_mm: float,
    transition_distance_mm: float,
) -> tuple[float, ...]:
    """Choose near-size-aligned adapter heights around a balanced split.

    The candidate order is derived only from the requested size field.  The
    residual keeps at least one near-size layer, while the adapter is bounded
    by both the target size and the transition distance.  Trying the balanced
    layer count first avoids a geometry-specific fixed height.
    """

    upper = min(
        total_height_mm - near_size_mm,
        target_size_mm,
        transition_distance_mm,
    )
    maximum_layers = int(
        math.floor((upper + _COORDINATE_TOLERANCE_MM) / near_size_mm)
    )
    if maximum_layers < 2:
        return ()
    preferred_height = min(
        0.5 * total_height_mm,
        0.5 * target_size_mm,
        0.5 * transition_distance_mm,
    )
    preferred_layers = min(
        maximum_layers,
        max(2, int(round(preferred_height / near_size_mm))),
    )
    layer_counts = tuple(
        sorted(
            range(2, maximum_layers + 1),
            key=lambda count: (abs(count - preferred_layers), count),
        )
    )
    return tuple(count * near_size_mm for count in layer_counts)


def _first_layer_fraction_candidates(
    adapter_height_mm: float,
    near_size_mm: float,
) -> tuple[float, ...]:
    """Return balanced two-stage thickness splits on the near-size lattice."""

    layer_count = max(2, int(round(adapter_height_mm / near_size_mm)))
    candidates = tuple(index / layer_count for index in range(1, layer_count))
    return tuple(sorted(candidates, key=lambda value: (abs(value - 0.5), value)))


def _signed_xy_area(
    nodes: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> float:
    return 0.5 * math.fsum(
        coordinates[first][0] * coordinates[second][1]
        - coordinates[second][0] * coordinates[first][1]
        for first, second in zip(nodes, (*nodes[1:], nodes[0]))
    )


def _interpolated_coordinates(
    first: Mapping[int, Point3D],
    second: Mapping[int, Point3D],
    fraction: float,
) -> Mapping[int, Point3D]:
    return MappingProxyType(
        {
            node: tuple(
                first[node][axis]
                + fraction * (second[node][axis] - first[node][axis])
                for axis in range(3)
            )
            for node in first
        }
    )


def _patch_xy_area(
    proof: _LockedBaseProof,
    coordinates: Mapping[int, Point3D],
) -> float:
    return math.fsum(
        abs(_signed_xy_area(facet, coordinates)) for facet in proof.facets
    )


def _radial_recovery_coordinates(
    proof: _LockedBaseProof,
    root: CanonicalRectangularUnderfillFillet,
    adapter_height_mm: float,
    recovery_height_mm: float,
) -> Mapping[int, Point3D]:
    x_min, y_min = root.die_origin_xy_mm
    x_max = x_min + root.die_size_xy_mm[0]
    y_max = y_min + root.die_size_xy_mm[1]
    scale = 1.0 - recovery_height_mm / root.wall_height_mm
    target_z = root.base_z_mm + adapter_height_mm
    return MappingProxyType(
        {
            node: (
                (anchor_x := min(max(point[0], x_min), x_max))
                + scale * (point[0] - anchor_x),
                (anchor_y := min(max(point[1], y_min), y_max))
                + scale * (point[1] - anchor_y),
                target_z,
            )
            for node, point in proof.coordinates.items()
        }
    )


def _zero_tip_coordinates(
    proof: _LockedBaseProof,
    root: CanonicalRectangularUnderfillFillet,
    recovery_coordinates: Mapping[int, Point3D],
) -> Mapping[int, Point3D]:
    x_min, y_min = root.die_origin_xy_mm
    x_max = x_min + root.die_size_xy_mm[0]
    y_max = y_min + root.die_size_xy_mm[1]
    target_z = root.base_z_mm + root.wall_height_mm
    output = {
        node: (
            min(max(point[0], x_min), x_max),
            min(max(point[1], y_min), y_max),
            target_z,
        )
        for node, point in recovery_coordinates.items()
    }
    for facet_index, facet in enumerate(proof.facets):
        collapsed = {
            _coordinate_key(output[node]) for node in facet
        }
        if len(collapsed) not in {1, 2}:
            raise RectangularUfLockedBaseQuadTriFillError(
                "volume-conserving recovery cannot form a zero-tip edge/point "
                f"collapse: facet_index={facet_index},target_count={len(collapsed)}"
            )
    return MappingProxyType(output)


def _simpson_ruled_volume_mm3(
    proof: _LockedBaseProof,
    first: Mapping[int, Point3D],
    second: Mapping[int, Point3D],
    height_mm: float,
) -> float:
    """Integrate the linearly ruled patch exactly in the sweep coordinate."""

    midpoint = _interpolated_coordinates(first, second, 0.5)
    return height_mm * (
        _patch_xy_area(proof, first)
        + 4.0 * _patch_xy_area(proof, midpoint)
        + _patch_xy_area(proof, second)
    ) / 6.0


def _canonical_volume_mm3(
    root: CanonicalRectangularUnderfillFillet,
) -> float:
    return root.wall_height_mm * (
        (root.die_size_xy_mm[0] + root.die_size_xy_mm[1])
        * root.toe_width_mm
        + math.pi * root.toe_width_mm * root.toe_width_mm / 3.0
    )


def _predicted_ruled_volume_mm3(
    proof: _LockedBaseProof,
    root: CanonicalRectangularUnderfillFillet,
    adapter_height_mm: float,
    recovery_height_mm: float,
) -> float:
    recovery = _radial_recovery_coordinates(
        proof,
        root,
        adapter_height_mm,
        recovery_height_mm,
    )
    apex = _zero_tip_coordinates(proof, root, recovery)
    return _simpson_ruled_volume_mm3(
        proof,
        proof.coordinates,
        recovery,
        adapter_height_mm,
    ) + _simpson_ruled_volume_mm3(
        proof,
        recovery,
        apex,
        root.wall_height_mm - adapter_height_mm,
    )


def _solve_volume_conserving_recovery_height(
    proof: _LockedBaseProof,
    root: CanonicalRectangularUnderfillFillet,
    adapter_height_mm: float,
    *,
    interface_geometry_tolerance_mm: float,
) -> float:
    """Solve the volume-conserving radial recovery before invoking Gmsh."""

    total_height = root.wall_height_mm
    minimum_scale = interface_geometry_tolerance_mm / proof.minimum_edge_mm
    if minimum_scale >= 1.0:
        raise RectangularUfLockedBaseQuadTriFillError(
            "interface geometry tolerance leaves no distinct recovery section"
        )
    lower = 0.0
    upper = math.nextafter(total_height * (1.0 - minimum_scale), 0.0)
    canonical = _canonical_volume_mm3(root)
    lower_volume = _predicted_ruled_volume_mm3(
        proof, root, adapter_height_mm, lower
    )
    upper_volume = _predicted_ruled_volume_mm3(
        proof, root, adapter_height_mm, upper
    )
    if not upper_volume <= canonical <= lower_volume:
        raise RectangularUfLockedBaseQuadTriFillError(
            "canonical fillet volume is outside the geometry-derived recovery "
            "bracket: "
            f"low_relative={(lower_volume - canonical) / canonical:.12g},"
            f"high_relative={(upper_volume - canonical) / canonical:.12g}"
        )
    high_volume_coordinate = lower
    low_volume_coordinate = upper
    for _iteration in range(64):
        midpoint = 0.5 * (high_volume_coordinate + low_volume_coordinate)
        volume = _predicted_ruled_volume_mm3(
            proof, root, adapter_height_mm, midpoint
        )
        if volume > canonical:
            high_volume_coordinate = midpoint
        else:
            low_volume_coordinate = midpoint
    recovery = 0.5 * (high_volume_coordinate + low_volume_coordinate)
    final_volume = _predicted_ruled_volume_mm3(
        proof, root, adapter_height_mm, recovery
    )
    if abs(final_volume - canonical) / canonical > 1.0e-10:
        raise RectangularUfLockedBaseQuadTriFillError(
            "volume recovery solver did not converge"
        )
    # The rest of this backend identifies coordinates at 12 decimal places.
    # Normalize the scalar to the same lattice before Gmsh sees it; otherwise
    # insignificant solver-tail bits can flip a Delaunay diagonal in a
    # symmetric co-spherical point set.
    normalized = round(recovery, 12)
    normalized_volume = _predicted_ruled_volume_mm3(
        proof, root, adapter_height_mm, normalized
    )
    if (
        not 0.0 < normalized < total_height
        or abs(normalized_volume - canonical) / canonical
        > _CANONICAL_VOLUME_RELATIVE_TOLERANCE
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "coordinate-normalized recovery leaves the canonical volume band"
        )
    return normalized


def _clockwise_feature_chains(
    proof: _LockedBaseProof,
    root: CanonicalRectangularUnderfillFillet,
) -> tuple[tuple[int, ...], ...]:
    """Split the staircase outer loop at the eight rounded-rectangle tangencies."""

    loop = proof.outer_loop
    if _signed_xy_area(loop, proof.coordinates) > 0.0:
        loop = tuple(reversed(loop))
    x_min, y_min = root.die_origin_xy_mm
    x_max = x_min + root.die_size_xy_mm[0]
    y_max = y_min + root.die_size_xy_mm[1]
    tolerance = _COORDINATE_TOLERANCE_MM

    def select(
        predicate: object,
        key: object,
        label: str,
    ) -> int:
        candidates = tuple(
            node
            for node in loop
            if predicate(proof.coordinates[node])  # type: ignore[operator]
        )
        if not candidates:
            raise RectangularUfLockedBaseQuadTriFillError(
                "locked staircase outer loop has no canonical "
                f"{label} tangency node"
            )
        return min(candidates, key=key)  # type: ignore[arg-type, return-value]

    anchors = (
        select(
            lambda point: abs(point[1] - y_min) <= tolerance
            and point[0] < x_min - tolerance,
            lambda node: (proof.coordinates[node][0], node),
            "left-bottom",
        ),
        select(
            lambda point: abs(point[1] - y_max) <= tolerance
            and point[0] < x_min - tolerance,
            lambda node: (proof.coordinates[node][0], node),
            "left-top",
        ),
        select(
            lambda point: abs(point[0] - x_min) <= tolerance
            and point[1] > y_max + tolerance,
            lambda node: (-proof.coordinates[node][1], node),
            "top-left",
        ),
        select(
            lambda point: abs(point[0] - x_max) <= tolerance
            and point[1] > y_max + tolerance,
            lambda node: (-proof.coordinates[node][1], node),
            "top-right",
        ),
        select(
            lambda point: abs(point[1] - y_max) <= tolerance
            and point[0] > x_max + tolerance,
            lambda node: (-proof.coordinates[node][0], node),
            "right-top",
        ),
        select(
            lambda point: abs(point[1] - y_min) <= tolerance
            and point[0] > x_max + tolerance,
            lambda node: (-proof.coordinates[node][0], node),
            "right-bottom",
        ),
        select(
            lambda point: abs(point[0] - x_max) <= tolerance
            and point[1] < y_min - tolerance,
            lambda node: (proof.coordinates[node][1], node),
            "bottom-right",
        ),
        select(
            lambda point: abs(point[0] - x_min) <= tolerance
            and point[1] < y_min - tolerance,
            lambda node: (proof.coordinates[node][1], node),
            "bottom-left",
        ),
    )
    if len(set(anchors)) != len(anchors):
        raise RectangularUfLockedBaseQuadTriFillError(
            "locked staircase outer-loop tangency anchors are not distinct"
        )
    start = loop.index(anchors[0])
    loop = loop[start:] + loop[:start]
    indices = tuple(loop.index(node) for node in anchors)
    if indices[0] != 0 or tuple(sorted(indices)) != indices:
        raise RectangularUfLockedBaseQuadTriFillError(
            "locked staircase outer-loop tangencies are not in rounded-rectangle order"
        )
    cyclic = (*indices, len(loop))
    return tuple(
        tuple(loop[index] for index in range(cyclic[offset], cyclic[offset + 1] + 1))
        if offset < len(indices) - 1
        else (*loop[indices[-1] :], loop[0])
        for offset in range(len(indices))
    )


def _segments_intersect(
    first: tuple[float, float],
    second: tuple[float, float],
    third: tuple[float, float],
    fourth: tuple[float, float],
) -> bool:
    tolerance = _COORDINATE_TOLERANCE_MM**2

    def cross(
        origin: tuple[float, float],
        left: tuple[float, float],
        right: tuple[float, float],
    ) -> float:
        return (left[0] - origin[0]) * (right[1] - origin[1]) - (
            left[1] - origin[1]
        ) * (right[0] - origin[0])

    def side(value: float) -> int:
        return 1 if value > tolerance else -1 if value < -tolerance else 0

    values = (
        side(cross(first, second, third)),
        side(cross(first, second, fourth)),
        side(cross(third, fourth, first)),
        side(cross(third, fourth, second)),
    )
    if values[0] * values[1] < 0 and values[2] * values[3] < 0:
        return True
    if 0 not in values:
        return False

    def within(
        point: tuple[float, float],
        lower: tuple[float, float],
        upper: tuple[float, float],
    ) -> bool:
        tolerance_length = _COORDINATE_TOLERANCE_MM
        return (
            min(lower[0], upper[0]) - tolerance_length
            <= point[0]
            <= max(lower[0], upper[0]) + tolerance_length
            and min(lower[1], upper[1]) - tolerance_length
            <= point[1]
            <= max(lower[1], upper[1]) + tolerance_length
        )

    return (
        (values[0] == 0 and within(third, first, second))
        or (values[1] == 0 and within(fourth, first, second))
        or (values[2] == 0 and within(first, third, fourth))
        or (values[3] == 0 and within(second, third, fourth))
    )


def _prove_simple_loop(
    loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
    *,
    label: str,
) -> None:
    points = tuple(
        (coordinates[node][0], coordinates[node][1]) for node in loop
    )
    count = len(points)
    for first_index in range(count):
        first_edge = (points[first_index], points[(first_index + 1) % count])
        for second_index in range(first_index + 1, count):
            if (
                second_index == first_index
                or second_index == (first_index + 1) % count
                or first_index == (second_index + 1) % count
            ):
                continue
            second_edge = (
                points[second_index],
                points[(second_index + 1) % count],
            )
            if _segments_intersect(*first_edge, *second_edge):
                raise RectangularUfLockedBaseQuadTriFillError(
                    f"analytic recovery {label} loop self-intersects"
                )


def _distance_to_rectangle(
    point: tuple[float, float],
    bounds: tuple[float, float, float, float],
) -> float:
    x_min, x_max, y_min, y_max = bounds
    x_value, y_value = point
    dx = max(x_min - x_value, 0.0, x_value - x_max)
    dy = max(y_min - y_value, 0.0, y_value - y_max)
    return math.hypot(dx, dy)


def _segment_rectangle_distance_extrema(
    first: tuple[float, float],
    second: tuple[float, float],
    bounds: tuple[float, float, float, float],
) -> tuple[float, float]:
    """Return exact min/max point-to-rectangle distance along one segment."""

    x_min, x_max, y_min, y_max = bounds
    delta_x = second[0] - first[0]
    delta_y = second[1] - first[1]
    breakpoints = {0.0, 1.0}
    for origin, delta, lower, upper in (
        (first[0], delta_x, x_min, x_max),
        (first[1], delta_y, y_min, y_max),
    ):
        if abs(delta) <= _COORDINATE_TOLERANCE_MM:
            continue
        for boundary in (lower, upper):
            value = (boundary - origin) / delta
            if 0.0 < value < 1.0:
                breakpoints.add(value)
    ordered = sorted(breakpoints)
    candidates = set(ordered)
    for lower_t, upper_t in zip(ordered, ordered[1:]):
        midpoint = 0.5 * (lower_t + upper_t)
        midpoint_x = first[0] + midpoint * delta_x
        midpoint_y = first[1] + midpoint * delta_y
        if midpoint_x < x_min:
            x_origin, x_delta = first[0] - x_min, delta_x
        elif midpoint_x > x_max:
            x_origin, x_delta = first[0] - x_max, delta_x
        else:
            x_origin, x_delta = 0.0, 0.0
        if midpoint_y < y_min:
            y_origin, y_delta = first[1] - y_min, delta_y
        elif midpoint_y > y_max:
            y_origin, y_delta = first[1] - y_max, delta_y
        else:
            y_origin, y_delta = 0.0, 0.0
        denominator = x_delta * x_delta + y_delta * y_delta
        if denominator <= _COORDINATE_TOLERANCE_MM**2:
            continue
        stationary = -(
            x_origin * x_delta + y_origin * y_delta
        ) / denominator
        if lower_t < stationary < upper_t:
            candidates.add(stationary)
    distances = tuple(
        _distance_to_rectangle(
            (
                first[0] + value * delta_x,
                first[1] + value * delta_y,
            ),
            bounds,
        )
        for value in candidates
    )
    return min(distances), max(distances)


def _audit_recovery_targets(
    proof: _LockedBaseProof,
    root: CanonicalRectangularUnderfillFillet,
    coordinates: Mapping[int, Point3D],
    adapter_height_mm: float,
    *,
    geometry_recovery_height_mm: float | None = None,
    require_exact_analytic_outer: bool = True,
    allowed_radial_deviation_mm: float | None = None,
) -> _AnalyticRecoveryTargets:
    recovery_height = (
        adapter_height_mm
        if geometry_recovery_height_mm is None
        else geometry_recovery_height_mm
    )
    scale = 1.0 - recovery_height / root.wall_height_mm
    radius = root.toe_width_mm * scale
    canonical_radius = root.toe_width_mm * (
        1.0 - adapter_height_mm / root.wall_height_mm
    )
    x_min, y_min = root.die_origin_xy_mm
    x_max = x_min + root.die_size_xy_mm[0]
    y_max = y_min + root.die_size_xy_mm[1]
    distance_extrema = tuple(
        _segment_rectangle_distance_extrema(
            coordinates[first][:2],
            coordinates[second][:2],
            (x_min, x_max, y_min, y_max),
        )
        for first, second in zip(
            proof.outer_loop,
            (*proof.outer_loop[1:], proof.outer_loop[0]),
        )
    )
    minimum_signed_radial_deviation = (
        min(value[0] for value in distance_extrema) - canonical_radius
    )
    maximum_signed_radial_deviation = (
        max(value[1] for value in distance_extrema) - canonical_radius
    )
    maximum_radial_deviation = max(
        abs(minimum_signed_radial_deviation),
        abs(maximum_signed_radial_deviation),
    )
    allowed_radial_deviation = (
        max(_COORDINATE_TOLERANCE_MM, maximum_radial_deviation)
        if allowed_radial_deviation_mm is None
        else float(allowed_radial_deviation_mm)
    )
    if (
        not math.isfinite(allowed_radial_deviation)
        or allowed_radial_deviation <= 0.0
        or maximum_radial_deviation
        > allowed_radial_deviation + _COORDINATE_TOLERANCE_MM
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "volume-conserving recovery exceeds its local size-field coverage "
            f"budget: maximum_radial_deviation_mm="
            f"{maximum_radial_deviation:.12g},allowed_mm="
            f"{allowed_radial_deviation:.12g}"
        )
    target_z = root.base_z_mm + adapter_height_mm
    if set(coordinates) != set(proof.coordinates):
        raise RectangularUfLockedBaseQuadTriFillError(
            "analytic recovery targets do not cover every locked node"
        )
    if len({_coordinate_key(point) for point in coordinates.values()}) != len(
        coordinates
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "analytic recovery targets contain coincident nodes"
        )
    if any(
        abs(point[2] - target_z) > _COORDINATE_TOLERANCE_MM
        for point in coordinates.values()
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "analytic recovery targets are not on one section plane"
        )
    if require_exact_analytic_outer:
        for node in proof.outer_loop:
            x_value, y_value, _z_value = coordinates[node]
            anchor_x = min(max(x_value, x_min), x_max)
            anchor_y = min(max(y_value, y_min), y_max)
            if not math.isclose(
                math.hypot(x_value - anchor_x, y_value - anchor_y),
                radius,
                rel_tol=0.0,
                abs_tol=5.0e-10,
            ):
                raise RectangularUfLockedBaseQuadTriFillError(
                    "analytic recovery outer target escaped its rounded offset"
                )
    for node in proof.inner_loop:
        source = proof.coordinates[node]
        target = coordinates[node]
        if (
            abs(source[0] - target[0]) > _COORDINATE_TOLERANCE_MM
            or abs(source[1] - target[1]) > _COORDINATE_TOLERANCE_MM
        ):
            raise RectangularUfLockedBaseQuadTriFillError(
                "analytic recovery changed a die-perimeter target"
            )

    source_signs: set[int] = set()
    polygon_area = 0.0
    for facet_index, facet in enumerate(proof.facets):
        source_area = _signed_xy_area(facet, proof.coordinates)
        target_area = _signed_xy_area(facet, coordinates)
        if abs(target_area) <= _COORDINATE_TOLERANCE_MM**2 or (
            source_area * target_area <= 0.0
        ):
            raise RectangularUfLockedBaseQuadTriFillError(
                "analytic recovery target QUAD is inverted or degenerate: "
                f"facet_index={facet_index},source_area={source_area:.12g},"
                f"target_area={target_area:.12g}"
            )
        source_signs.add(1 if source_area > 0.0 else -1)
        points = tuple(coordinates[node] for node in facet)
        corners = tuple(
            (points[(index + 1) % 4][0] - points[index][0])
            * (points[(index + 2) % 4][1] - points[(index + 1) % 4][1])
            - (points[(index + 1) % 4][1] - points[index][1])
            * (points[(index + 2) % 4][0] - points[(index + 1) % 4][0])
            for index in range(4)
        )
        if min(abs(value) for value in corners) <= (
            _COORDINATE_TOLERANCE_MM**2
        ) or len({1 if value > 0.0 else -1 for value in corners}) != 1:
            raise RectangularUfLockedBaseQuadTriFillError(
                "analytic recovery target QUAD is not strictly convex: "
                f"facet_index={facet_index}"
            )
        polygon_area += abs(target_area)
    if len(source_signs) != 1:
        raise RectangularUfLockedBaseQuadTriFillError(
            "locked source QUAD cycles do not have one planar orientation"
        )

    _prove_simple_loop(proof.outer_loop, coordinates, label="outer")
    _prove_simple_loop(proof.inner_loop, coordinates, label="inner")
    for first, second in zip(
        proof.outer_loop,
        (*proof.outer_loop[1:], proof.outer_loop[0]),
    ):
        first_xy = coordinates[first][:2]
        second_xy = coordinates[second][:2]
        for third, fourth in zip(
            proof.inner_loop,
            (*proof.inner_loop[1:], proof.inner_loop[0]),
        ):
            if _segments_intersect(
                first_xy,
                second_xy,
                coordinates[third][:2],
                coordinates[fourth][:2],
            ):
                raise RectangularUfLockedBaseQuadTriFillError(
                    "analytic recovery outer and inner loops intersect"
                )
    loop_area = abs(_signed_xy_area(proof.outer_loop, coordinates)) - abs(
        _signed_xy_area(proof.inner_loop, coordinates)
    )
    if not math.isclose(
        polygon_area,
        loop_area,
        rel_tol=1.0e-9,
        abs_tol=1.0e-13,
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "analytic recovery QUAD union has an overlap or hole: "
            f"quad_area={polygon_area:.12g},loop_area={loop_area:.12g}"
        )
    analytic_area = (
        2.0
        * (root.die_size_xy_mm[0] + root.die_size_xy_mm[1])
        * radius
        + math.pi * radius * radius
    )
    section_error = abs(polygon_area - analytic_area) / analytic_area
    if require_exact_analytic_outer and (
        polygon_area > analytic_area * (1.0 + 1.0e-8)
        or section_error > 0.02
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "analytic recovery section coverage is outside its rounded fillet: "
            f"relative_error={section_error:.8g},maximum=0.02"
        )
    return _AnalyticRecoveryTargets(
        coordinates=MappingProxyType(dict(coordinates)),
        geometry_recovery_height_mm=recovery_height,
        analytic_section_area_mm2=analytic_area,
        polygon_section_area_mm2=polygon_area,
        section_area_relative_error=section_error,
        minimum_signed_radial_deviation_mm=(
            minimum_signed_radial_deviation
        ),
        maximum_signed_radial_deviation_mm=(
            maximum_signed_radial_deviation
        ),
        maximum_radial_deviation_mm=maximum_radial_deviation,
        allowed_radial_deviation_mm=allowed_radial_deviation,
    )


def _gmsh_relax_recovery_targets(
    proof: _LockedBaseProof,
    initial_coordinates: Mapping[int, Point3D],
) -> Mapping[int, Point3D]:
    """Let Gmsh redistribute only the planar interior of the target QUAD patch."""

    boundary_nodes = set(proof.outer_loop).union(proof.inner_loop)
    interior_nodes = set(proof.coordinates).difference(boundary_nodes)
    if not interior_nodes:
        return MappingProxyType(dict(initial_coordinates))
    gmsh = _load_gmsh()
    try:
        with isolated_gmsh_model(
            gmsh,
            "__easymesh_uf_analytic_recovery_surface",
            number_options={
                "General.Terminal": 0.0,
                "General.NumThreads": 1.0,
                "Mesh.MaxNumThreads1D": 1.0,
                "Mesh.MaxNumThreads2D": 1.0,
            },
        ):
            point_tag_by_node = {
                node: int(gmsh.model.geo.addPoint(*initial_coordinates[node]))
                for node in sorted(boundary_nodes)
            }
            curve_tags_by_loop: list[tuple[int, ...]] = []
            for loop in (proof.outer_loop, proof.inner_loop):
                curve_tags_by_loop.append(
                    tuple(
                        int(
                            gmsh.model.geo.addLine(
                                point_tag_by_node[first],
                                point_tag_by_node[second],
                            )
                        )
                        for first, second in zip(
                            loop,
                            (*loop[1:], loop[0]),
                        )
                    )
                )
            curve_loops = tuple(
                int(gmsh.model.geo.addCurveLoop(curves))
                for curves in curve_tags_by_loop
            )
            surface_tag = int(gmsh.model.geo.addPlaneSurface(curve_loops))
            gmsh.model.geo.synchronize()

            gmsh_tag_by_source = {
                source: index
                for index, source in enumerate(
                    sorted(
                        initial_coordinates,
                        key=lambda node: (
                            _coordinate_key(initial_coordinates[node]),
                            node,
                        ),
                    ),
                    start=1,
                )
            }
            for source in sorted(boundary_nodes):
                point_tag = point_tag_by_node[source]
                gmsh_tag = gmsh_tag_by_source[source]
                gmsh.model.mesh.addNodes(
                    0,
                    point_tag,
                    [gmsh_tag],
                    list(initial_coordinates[source]),
                )
                gmsh.model.mesh.addElementsByType(
                    point_tag,
                    15,
                    [],
                    [gmsh_tag],
                )
            for loop, curve_tags in zip(
                (proof.outer_loop, proof.inner_loop),
                curve_tags_by_loop,
            ):
                for first, second, curve_tag in zip(
                    loop,
                    (*loop[1:], loop[0]),
                    curve_tags,
                ):
                    gmsh.model.mesh.addElementsByType(
                        curve_tag,
                        1,
                        [],
                        [
                            gmsh_tag_by_source[first],
                            gmsh_tag_by_source[second],
                        ],
                    )
            ordered_interior = tuple(
                sorted(interior_nodes, key=gmsh_tag_by_source.__getitem__)
            )
            gmsh.model.mesh.addNodes(
                2,
                surface_tag,
                [gmsh_tag_by_source[node] for node in ordered_interior],
                [
                    value
                    for node in ordered_interior
                    for value in initial_coordinates[node]
                ],
            )
            gmsh.model.mesh.addElementsByType(
                surface_tag,
                _QUAD4,
                [],
                [
                    gmsh_tag_by_source[node]
                    for facet in proof.facets
                    for node in facet
                ],
            )
            gmsh.model.mesh.renumberNodes()
            raw_tags, raw_coordinates, _parameters = gmsh.model.mesh.getNodes()
            tags = tuple(int(value) for value in raw_tags)
            before_by_tag = {
                tag: tuple(
                    float(value)
                    for value in raw_coordinates[3 * index : 3 * index + 3]
                )
                for index, tag in enumerate(tags)
            }
            tag_by_coordinate = {
                _coordinate_key(point): tag for tag, point in before_by_tag.items()
            }
            if len(tag_by_coordinate) != len(before_by_tag):
                raise RectangularUfLockedBaseQuadTriFillError(
                    "Gmsh recovery surface contains duplicate nodes before smoothing"
                )
            tag_by_source = {
                source: tag_by_coordinate[_coordinate_key(point)]
                for source, point in initial_coordinates.items()
            }
            gmsh.model.mesh.optimize(
                "Laplace2D",
                force=False,
                niter=100,
            )
            raw_tags, raw_coordinates, _parameters = gmsh.model.mesh.getNodes()
            after_by_tag = {
                int(tag): tuple(
                    float(value)
                    for value in raw_coordinates[3 * index : 3 * index + 3]
                )
                for index, tag in enumerate(raw_tags)
            }
            if set(after_by_tag) != set(before_by_tag):
                raise RectangularUfLockedBaseQuadTriFillError(
                    "Gmsh recovery surface changed its node identity set"
                )
            output = {
                source: after_by_tag[tag]
                for source, tag in tag_by_source.items()
            }
            if any(
                math.dist(output[node], initial_coordinates[node])
                > _COORDINATE_TOLERANCE_MM
                for node in boundary_nodes
            ):
                raise RectangularUfLockedBaseQuadTriFillError(
                    "Gmsh recovery relaxation moved an analytic boundary node"
                )
            return MappingProxyType(output)
    except RectangularUfLockedBaseQuadTriFillError:
        raise
    except Exception as error:
        raise RectangularUfLockedBaseQuadTriFillError(
            f"Gmsh could not relax the analytic recovery target patch: {error}"
        ) from error


def _targets(
    proof: _LockedBaseProof,
    root: CanonicalRectangularUnderfillFillet,
    adapter_height_mm: float,
) -> _AnalyticRecoveryTargets:
    """Map one staircase annulus bijectively onto an analytic offset section."""

    x_min, y_min = root.die_origin_xy_mm
    x_max = x_min + root.die_size_xy_mm[0]
    y_max = y_min + root.die_size_xy_mm[1]
    scale = 1.0 - adapter_height_mm / root.wall_height_mm
    radius = root.toe_width_mm * scale
    target_z = root.base_z_mm + adapter_height_mm
    output: dict[int, Point3D] = {}
    for node, point in proof.coordinates.items():
        anchor_x = min(max(point[0], x_min), x_max)
        anchor_y = min(max(point[1], y_min), y_max)
        output[node] = (
            anchor_x + scale * (point[0] - anchor_x),
            anchor_y + scale * (point[1] - anchor_y),
            target_z,
        )

    feature_maps = (
        lambda value: (x_min - radius, y_min + value * (y_max - y_min)),
        lambda value: (
            x_min + radius * math.cos(math.pi - value * math.pi / 2.0),
            y_max + radius * math.sin(math.pi - value * math.pi / 2.0),
        ),
        lambda value: (x_min + value * (x_max - x_min), y_max + radius),
        lambda value: (
            x_max + radius * math.cos(math.pi / 2.0 - value * math.pi / 2.0),
            y_max + radius * math.sin(math.pi / 2.0 - value * math.pi / 2.0),
        ),
        lambda value: (x_max + radius, y_max - value * (y_max - y_min)),
        lambda value: (
            x_max + radius * math.cos(-value * math.pi / 2.0),
            y_min + radius * math.sin(-value * math.pi / 2.0),
        ),
        lambda value: (x_max - value * (x_max - x_min), y_min - radius),
        lambda value: (
            x_min + radius * math.cos(-math.pi / 2.0 - value * math.pi / 2.0),
            y_min + radius * math.sin(-math.pi / 2.0 - value * math.pi / 2.0),
        ),
    )
    assigned: dict[int, Point3D] = {}
    for chain, feature_map in zip(
        _clockwise_feature_chains(proof, root),
        feature_maps,
    ):
        lengths = tuple(
            math.dist(proof.coordinates[first], proof.coordinates[second])
            for first, second in zip(chain, chain[1:])
        )
        total = math.fsum(lengths)
        if total <= _COORDINATE_TOLERANCE_MM:
            raise RectangularUfLockedBaseQuadTriFillError(
                "locked staircase rounded-rectangle feature chain is degenerate"
            )
        cumulative = 0.0
        for index, node in enumerate(chain):
            if index:
                cumulative += lengths[index - 1]
            x_value, y_value = feature_map(cumulative / total)
            target = (x_value, y_value, target_z)
            previous = assigned.setdefault(node, target)
            if math.dist(previous, target) > _COORDINATE_TOLERANCE_MM:
                raise RectangularUfLockedBaseQuadTriFillError(
                    "analytic recovery feature-chain endpoints disagree"
                )
            output[node] = target
    if set(assigned) != set(proof.outer_loop):
        raise RectangularUfLockedBaseQuadTriFillError(
            "analytic recovery feature chains do not cover the outer loop exactly"
        )
    relaxed = _gmsh_relax_recovery_targets(proof, output)
    return _audit_recovery_targets(
        proof,
        root,
        relaxed,
        adapter_height_mm,
    )


def _mapped_hex_targets(
    proof: _LockedBaseProof,
    root: CanonicalRectangularUnderfillFillet,
    adapter_height_mm: float,
    recovery_height_mm: float,
    *,
    target_size_mm: float,
    near_size_mm: float,
    transition_distance_mm: float,
    interface_geometry_tolerance_mm: float,
) -> _AnalyticRecoveryTargets:
    """Create one volume-conserving radial target for Gmsh QuadTri."""

    if not (
        0.0 < recovery_height_mm < root.wall_height_mm
        and 0.0 < adapter_height_mm < root.wall_height_mm
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped recovery heights must lie strictly inside the fillet wall"
        )
    x_min, y_min = root.die_origin_xy_mm
    x_max = x_min + root.die_size_xy_mm[0]
    y_max = y_min + root.die_size_xy_mm[1]
    target_z = root.base_z_mm + adapter_height_mm
    output = dict(
        _radial_recovery_coordinates(
            proof,
            root,
            adapter_height_mm,
            recovery_height_mm,
        )
    )

    # Nodes on the die-inner loop are a geometric interface, not free
    # smoothing points.  Canonicalize only coordinates already within the
    # user-selected same-plane tolerance; this avoids turning roundoff on the
    # interior side of the plane into a false die penetration.
    tolerance = interface_geometry_tolerance_mm
    for node in proof.inner_loop:
        x_value, y_value, _z_value = output[node]
        if abs(x_value - x_min) <= tolerance:
            x_value = x_min
        elif abs(x_value - x_max) <= tolerance:
            x_value = x_max
        if abs(y_value - y_min) <= tolerance:
            y_value = y_min
        elif abs(y_value - y_max) <= tolerance:
            y_value = y_max
        output[node] = (x_value, y_value, target_z)

    distance_fraction = min(
        1.0,
        adapter_height_mm / transition_distance_mm,
    )
    allowed_deviation = near_size_mm + (
        target_size_mm - near_size_mm
    ) * distance_fraction

    return _audit_recovery_targets(
        proof,
        root,
        MappingProxyType(output),
        adapter_height_mm,
        geometry_recovery_height_mm=recovery_height_mm,
        require_exact_analytic_outer=False,
        allowed_radial_deviation_mm=allowed_deviation,
    )


def _envelope(root: CanonicalRectangularUnderfillFillet) -> RectangularUfEnvelope:
    return RectangularUfEnvelope(
        die_width=root.die_size_xy_mm[0],
        die_length=root.die_size_xy_mm[1],
        base_z=root.base_z_mm,
        height=root.wall_height_mm,
        fillet_width=root.toe_width_mm,
        center_x=root.die_origin_xy_mm[0] + 0.5 * root.die_size_xy_mm[0],
        center_y=root.die_origin_xy_mm[1] + 0.5 * root.die_size_xy_mm[1],
    )


def _classify_die_or_free(
    facet: Sequence[int],
    coordinates: Mapping[int, Point3D],
    root: CanonicalRectangularUnderfillFillet,
) -> str:
    points = tuple(coordinates[node] for node in facet)
    x_min, y_min = root.die_origin_xy_mm
    x_max = x_min + root.die_size_xy_mm[0]
    y_max = y_min + root.die_size_xy_mm[1]
    tolerance = 1.0e-8
    matches = tuple(
        side
        for side, axis, value, tangent, lower, upper in (
            ("die_x_min", 0, x_min, 1, y_min, y_max),
            ("die_x_max", 0, x_max, 1, y_min, y_max),
            ("die_y_min", 1, y_min, 0, x_min, x_max),
            ("die_y_max", 1, y_max, 0, x_min, x_max),
        )
        if all(
            abs(point[axis] - value) <= tolerance
            and lower - tolerance <= point[tangent] <= upper + tolerance
            for point in points
        )
    )
    if len(matches) > 1:
        raise RectangularUfLockedBaseQuadTriFillError(
            "ruled-staircase lateral facet has ambiguous die-wall ownership"
        )
    return matches[0] if matches else "outer_free"


def _combine(
    adapter: GmshQuadTriAdapter,
    residual: GmshUfConformalVolume,
    root: CanonicalRectangularUnderfillFillet,
    *,
    target_size_mm: float,
    near_size_mm: float,
    transition_distance_mm: float,
) -> tuple[
    GmshClosedShellRemainder,
    Mapping[str, tuple[tuple[int, ...], ...]],
    Mapping[str, tuple[tuple[int, ...], ...]],
    int,
    float,
    float,
    float,
    float,
    float,
]:
    coordinates: dict[int, Point3D] = dict(adapter.node_coordinates)
    coordinate_owner = {
        _coordinate_key(point): node for node, point in coordinates.items()
    }
    adapter_interface_nodes = {
        node for facet in adapter.interface_facets for node in facet
    }
    residual_by_source = {
        source: local
        for local, source in residual.source_node_id_by_local_id.items()
    }
    if set(residual_by_source) != adapter_interface_nodes:
        raise RectangularUfLockedBaseQuadTriFillError(
            "TET remainder source-node identity differs from the mapped TRI interface"
        )
    combined_by_residual: dict[int, int] = {}
    for residual_node, point in residual.node_coordinates.items():
        source = residual.source_node_id_by_local_id.get(residual_node)
        if source is not None:
            if source not in adapter_interface_nodes or math.dist(
                point, adapter.node_coordinates[source]
            ) > _COORDINATE_TOLERANCE_MM:
                raise RectangularUfLockedBaseQuadTriFillError(
                    "TET remainder changed a mapped TRI interface node"
                )
            combined_by_residual[residual_node] = source
            continue
        key = _coordinate_key(point)
        if key in coordinate_owner:
            raise RectangularUfLockedBaseQuadTriFillError(
                "adapter and TET remainder contain a non-interface coincident node"
            )
        combined_node = len(coordinates) + 1
        coordinates[combined_node] = point
        coordinate_owner[key] = combined_node
        combined_by_residual[residual_node] = combined_node
    if len(coordinate_owner) != len(coordinates):
        raise RectangularUfLockedBaseQuadTriFillError(
            "combined ruled-staircase fill contains duplicate nodes"
        )

    adapter_elements = tuple(
        GmshClosedShellElement(element.gmsh_type, element.node_ids)
        for element in adapter.elements
    )
    residual_elements = tuple(
        GmshClosedShellElement(
            element.gmsh_type,
            tuple(combined_by_residual[node] for node in element.node_ids),
        )
        for element in residual.elements
    )
    elements = (*adapter_elements, *residual_elements)
    if len(elements) != len(
        {(element.gmsh_type, tuple(sorted(element.node_ids))) for element in elements}
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "combined ruled-staircase fill contains duplicate elements"
        )

    seam_keys = {_face_key(facet) for facet in adapter.interface_facets}
    mapped_residual_base = tuple(
        tuple(combined_by_residual[node] for node in facet)
        for facet in residual.base_facets
    )
    residual_seam_keys = {_face_key(facet) for facet in mapped_residual_base}
    if len(residual_seam_keys) != len(mapped_residual_base) or residual_seam_keys != seam_keys:
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped adapter top TRI set and TET remainder base TRI set differ"
        )

    owners: dict[FaceKey, list[tuple[str, int, int, tuple[int, ...]]]] = defaultdict(list)
    for origin, origin_elements in (
        ("adapter", adapter_elements),
        ("remainder", residual_elements),
    ):
        for index, element in enumerate(origin_elements):
            for local_face in ELEMENT_SPECS[element.gmsh_type][2]:
                cycle = tuple(element.node_ids[value] for value in local_face)
                owners[_face_key(cycle)].append(
                    (origin, index, element.gmsh_type, cycle)
                )
    if any(len(values) not in {1, 2} for values in owners.values()):
        counts = Counter(len(values) for values in owners.values())
        raise RectangularUfLockedBaseQuadTriFillError(
            "combined ruled-staircase face ownership is non-manifold: "
            f"owner_counts={dict(sorted(counts.items()))!r}"
        )
    shared_between_stages = {
        key
        for key, values in owners.items()
        if {value[0] for value in values} == {"adapter", "remainder"}
    }
    if shared_between_stages != seam_keys:
        raise RectangularUfLockedBaseQuadTriFillError(
            "combined stages share a face outside the exact mapped TRI seam"
        )
    if any(
        len(owners[key]) != 2
        or {owner[0] for owner in owners[key]} != {"adapter", "remainder"}
        for key in seam_keys
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped TRI seam does not have exactly one owner from each Gmsh stage"
        )
    source_keys = {_face_key(facet) for facet in adapter.source_facets}
    if any(
        len(owners[key]) != 1 or owners[key][0][2] != _HEX8
        for key in source_keys
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "immutable source QUAD does not have exactly one HEX8 owner"
        )

    adjacency: dict[int, set[int]] = defaultdict(set)
    element_offset = len(adapter_elements)
    for values in owners.values():
        if len(values) != 2:
            continue
        indices = tuple(
            value[1] + (0 if value[0] == "adapter" else element_offset)
            for value in values
        )
        adjacency[indices[0]].add(indices[1])
        adjacency[indices[1]].add(indices[0])
    seen: set[int] = set()
    pending = deque((0,))
    while pending:
        current = pending.popleft()
        if current in seen:
            continue
        seen.add(current)
        pending.extend(adjacency[current].difference(seen))
    if len(seen) != len(elements):
        raise RectangularUfLockedBaseQuadTriFillError(
            "combined Gmsh elements are not one face-connected volume"
        )
    folded = _folded_internal_face_count(
        tuple(
            (element.gmsh_type, index, element.node_ids)
            for index, element in enumerate(elements, start=1)
        ),
        coordinates,
    )
    if folded:
        raise RectangularUfLockedBaseQuadTriFillError(
            "combined ruled-staircase connectivity folds across internal faces: "
            f"folded_internal_face_count={folded}"
        )

    seam_z = root.base_z_mm + adapter.extrusion_vector[2]
    tolerance = 1.0e-9
    if any(
        point[2] < root.base_z_mm - tolerance or point[2] > seam_z + tolerance
        for point in adapter.node_coordinates.values()
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "mapped adapter nodes escape their lower Z domain"
        )
    if any(
        point[2] < seam_z - tolerance
        or point[2] > root.base_z_mm + root.wall_height_mm + tolerance
        for point in residual.node_coordinates.values()
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "TET remainder nodes escape their upper Z domain"
        )

    label_by_key: dict[FaceKey, str] = {}

    def label(facets: Sequence[Sequence[int]], value: str) -> None:
        for facet in facets:
            key = _face_key(facet)
            previous = label_by_key.setdefault(key, value)
            if previous != value:
                raise RectangularUfLockedBaseQuadTriFillError(
                    "combined boundary face received conflicting side labels"
                )

    label(adapter.source_facets, "base")
    for facet in adapter.lateral_facets:
        label((facet,), _classify_die_or_free(facet, coordinates, root))
    for facets, side in (
        (residual.cap_facets, "cap"),
        (residual.free_surface_facets, "outer_free"),
    ):
        label(
            tuple(
                tuple(combined_by_residual[node] for node in facet)
                for facet in facets
            ),
            side,
        )
    for facet in residual.die_wall_facets:
        mapped = tuple(combined_by_residual[node] for node in facet)
        label((mapped,), _classify_die_or_free(mapped, coordinates, root))

    boundary_by_owner = {
        key: values[0][3] for key, values in owners.items() if len(values) == 1
    }
    if set(label_by_key) != set(boundary_by_owner):
        missing = len(set(boundary_by_owner).difference(label_by_key))
        extra = len(set(label_by_key).difference(boundary_by_owner))
        raise RectangularUfLockedBaseQuadTriFillError(
            "combined boundary classification is not exact: "
            f"missing={missing}, extra={extra}"
        )
    oriented_boundary, shell_volume = _orient_closed_shell(
        tuple(boundary_by_owner.values()),
        coordinates,
    )
    oriented_by_key = {_face_key(facet): facet for facet in oriented_boundary}
    boundary_by_side = MappingProxyType(
        {
            side: tuple(
                oriented_by_key[key]
                for key in sorted(label_by_key)
                if label_by_key[key] == side
            )
            for side in (
                "base",
                "cap",
                "die_x_min",
                "die_x_max",
                "die_y_min",
                "die_y_max",
                "outer_free",
            )
        }
    )
    element_volume = adapter.element_volume_mm3 + residual.element_volume_mm3
    relative_volume_error = abs(element_volume - shell_volume) / shell_volume
    if relative_volume_error > 1.0e-8:
        raise RectangularUfLockedBaseQuadTriFillError(
            "combined Gmsh element volume differs from ruled-staircase shell: "
            f"relative_error={relative_volume_error:.8g}"
        )
    analytic_volume = root.wall_height_mm * (
        (root.die_size_xy_mm[0] + root.die_size_xy_mm[1]) * root.toe_width_mm
        + math.pi * root.toe_width_mm * root.toe_width_mm / 3.0
    )
    canonical_volume_error = abs(shell_volume - analytic_volume) / analytic_volume
    if canonical_volume_error > 0.02:
        raise RectangularUfLockedBaseQuadTriFillError(
            "negotiated ruled-staircase volume differs from the canonical "
            f"zero-tip fillet by {canonical_volume_error:.8g}; maximum=0.02"
        )
    counts = Counter(element.gmsh_type for element in elements)
    minimum_sicn = min(adapter.minimum_sicn, residual.minimum_sicn)
    minimum_sige = min(adapter.minimum_sige, residual.minimum_sige)
    minimum_sj = min(
        adapter.minimum_scaled_jacobian,
        residual.minimum_scaled_jacobian,
    )
    non_source_minimum_sicn = min(
        adapter.transition_minimum_sicn,
        residual.minimum_sicn,
    )
    if min(
        minimum_sige,
        minimum_sj,
        non_source_minimum_sicn,
    ) < _QUALITY_FLOOR:
        raise RectangularUfLockedBaseQuadTriFillError(
            "combined ruled-staircase fill falls below its strategy-aware "
            "quality floor 0.03"
        )
    locked_by_side = MappingProxyType(
        {
            "base": boundary_by_side["base"],
            "cap": (),
            "die_x_min": (),
            "die_x_max": (),
            "die_y_min": (),
            "die_y_max": (),
        }
    )
    result = GmshClosedShellRemainder(
        node_coordinates=MappingProxyType(coordinates),
        source_node_id_by_local_id=adapter.source_node_id_by_local_id,
        elements=tuple(elements),
        boundary_facets=oriented_boundary,
        docking_facets=boundary_by_side["base"],
        tet4_count=counts[_TET4],
        hex8_count=counts[_HEX8],
        wedge6_count=counts[_WEDGE6],
        pyramid5_count=counts[_PYRAMID5],
        locked_triangle_count=0,
        locked_quad_count=len(adapter.source_facets),
        target_size_mm=target_size_mm,
        near_size_mm=near_size_mm,
        transition_distance_mm=transition_distance_mm,
        background_field_kind=(
            "MappedBoundaryLayer+QuadTri/" + residual.background_field_kind
        ),
        minimum_sicn=minimum_sicn,
        minimum_sige=minimum_sige,
        minimum_scaled_jacobian=minimum_sj,
        minimum_determinant=min(
            adapter.minimum_determinant,
            residual.minimum_determinant,
        ),
        duplicate_node_count=0,
        duplicate_element_count=0,
        shell_volume_mm3=shell_volume,
        element_volume_mm3=element_volume,
        relative_volume_error=relative_volume_error,
        random_seed=residual.random_seed,
        pyramid_untangler_used=False,
    )
    return (
        result,
        locked_by_side,
        boundary_by_side,
        len(seam_keys),
        shell_volume,
        element_volume,
        relative_volume_error,
        analytic_volume,
        canonical_volume_error,
    )


@bounded_candidate_search
def generate_rectangular_uf_locked_base_quadtri_fill(
    shell: GmshUfSurfaceShell,
    root: CanonicalRectangularUnderfillFillet,
    *,
    target_size_mm: float,
    transition_distance_mm: float,
    near_size_mm: float,
    forced_partial_locked_sides: Sequence[str] = (),
    minimum_quality: float = _QUALITY_FLOOR,
    random_seeds: Sequence[int] = (1, 2, 3),
    optimization_rounds: int = 2,
    allow_source_hex_sicn_aspect_exemption: bool = False,
    interface_geometry_tolerance_mm: float = 1.0e-5,
    verbose: bool = False,
) -> RectangularUfLockedBaseQuadTriFill:
    """Fill the narrowly proved zero-tip ruled staircase with Gmsh only."""

    try:
        geometry_tolerance = validate_interface_geometry_tolerance_mm(
            interface_geometry_tolerance_mm
        )
    except ValueError as error:
        raise RectangularUfLockedBaseQuadTriFillError(str(error)) from error
    proof = _prove_locked_base(
        shell,
        root,
        forced_partial_locked_sides=forced_partial_locked_sides,
        interface_geometry_tolerance_mm=geometry_tolerance,
    )
    values = {
        "target_size_mm": target_size_mm,
        "transition_distance_mm": transition_distance_mm,
        "near_size_mm": near_size_mm,
        "minimum_quality": minimum_quality,
    }
    for name, raw_value in values.items():
        if isinstance(raw_value, bool) or not isinstance(raw_value, (int, float)):
            raise RectangularUfLockedBaseQuadTriFillError(
                f"{name} must be finite and positive"
            )
        value = float(raw_value)
        if not math.isfinite(value) or value <= 0.0:
            raise RectangularUfLockedBaseQuadTriFillError(
                f"{name} must be finite and positive"
            )
    quality = float(minimum_quality)
    if quality < _QUALITY_FLOOR or quality >= 1.0:
        raise RectangularUfLockedBaseQuadTriFillError(
            "minimum_quality must be at least 0.03 and less than 1"
        )
    if float(near_size_mm) > float(target_size_mm):
        raise RectangularUfLockedBaseQuadTriFillError(
            "near_size_mm must not exceed target_size_mm"
        )
    try:
        seeds = tuple(dict.fromkeys(random_seeds))
    except TypeError as error:
        raise RectangularUfLockedBaseQuadTriFillError(
            "random_seeds must be a sequence"
        ) from error
    if not seeds or any(
        isinstance(seed, bool) or not isinstance(seed, int) or seed < 1
        for seed in seeds
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "random_seeds must contain positive integers"
        )
    if (
        isinstance(optimization_rounds, bool)
        or not isinstance(optimization_rounds, int)
        or optimization_rounds < 0
        or optimization_rounds > 4
    ):
        raise RectangularUfLockedBaseQuadTriFillError(
            "optimization_rounds must be an integer in 0..4"
        )
    if not isinstance(verbose, bool):
        raise RectangularUfLockedBaseQuadTriFillError("verbose must be boolean")
    if not isinstance(allow_source_hex_sicn_aspect_exemption, bool):
        raise RectangularUfLockedBaseQuadTriFillError(
            "source-HEX SICN exemption flag must be boolean"
        )
    attempts: list[str] = []

    def finish_adapter(
        adapter: GmshQuadTriAdapter,
        target_proof: _AnalyticRecoveryTargets,
        *,
        adapter_height: float,
        first_fraction: float,
        applied_path: str,
        prefix: str,
    ) -> RectangularUfLockedBaseQuadTriFill | None:
        def accept_residual(
            residual: GmshUfConformalVolume,
            attempt_prefix: str,
        ) -> RectangularUfLockedBaseQuadTriFill | None:
            try:
                (
                    remainder,
                    locked_by_side,
                    boundary_by_side,
                    seam_count,
                    shell_volume,
                    element_volume,
                    volume_error,
                    analytic_volume,
                    canonical_volume_error,
                ) = _combine(
                    adapter,
                    residual,
                    root,
                    target_size_mm=float(target_size_mm),
                    near_size_mm=float(near_size_mm),
                    transition_distance_mm=float(transition_distance_mm),
                )
            except (
                RectangularUfLockedBaseQuadTriFillError,
                ConstrainedHybridError,
            ) as error:
                attempts.append(
                    f"{attempt_prefix},stage=combined_audit,failed={error}"
                )
                return None
            attempts.append(
                f"{attempt_prefix},stage=accepted,"
                f"seed={residual.random_seed},"
                f"minSICN={remainder.minimum_sicn:.12g},"
                f"minSIGE={remainder.minimum_sige:.12g},"
                f"minSJ={remainder.minimum_scaled_jacobian:.12g}"
            )
            return RectangularUfLockedBaseQuadTriFill(
                remainder=remainder,
                locked_facets_by_side=locked_by_side,
                boundary_facets_by_side=boundary_by_side,
                adapter_height_mm=adapter_height,
                geometry_recovery_height_mm=(
                    target_proof.geometry_recovery_height_mm
                ),
                adapter_first_layer_fraction=first_fraction,
                adapter_method=adapter.method,
                remainder_algorithm_3d=residual.algorithm_3d,
                source_quad_count=len(proof.facets),
                source_quad_hex_owner_count=adapter.source_quad_hex_owner_count,
                source_hex_element_ids=adapter.source_hex_element_ids,
                source_hex_minimum_sicn=adapter.source_hex_minimum_sicn,
                source_hex_minimum_sige=adapter.source_hex_minimum_sige,
                source_hex_minimum_scaled_jacobian=(
                    adapter.source_hex_minimum_scaled_jacobian
                ),
                source_hex_sicn_aspect_quality_exempted=(
                    adapter.source_hex_sicn_aspect_quality_exempted
                ),
                non_source_element_count=(
                    adapter.transition_element_count + residual.element_count
                ),
                non_source_minimum_sicn=min(
                    adapter.transition_minimum_sicn,
                    residual.minimum_sicn,
                ),
                non_source_minimum_sige=min(
                    adapter.transition_minimum_sige,
                    residual.minimum_sige,
                ),
                non_source_minimum_scaled_jacobian=min(
                    adapter.transition_minimum_scaled_jacobian,
                    residual.minimum_scaled_jacobian,
                ),
                interface_triangle_count=sum(
                    len(facet) == 3 for facet in adapter.interface_facets
                ),
                interface_quad_count=sum(
                    len(facet) == 4 for facet in adapter.interface_facets
                ),
                interface_two_owner_count=seam_count,
                adapter_hex8_count=adapter.hex8_count,
                adapter_pyramid5_count=adapter.pyramid5_count,
                adapter_wedge6_count=adapter.wedge6_count,
                adapter_tet4_count=adapter.tet4_count,
                remainder_tet4_count=residual.tet4_count,
                ruled_staircase_shell_volume_mm3=shell_volume,
                ruled_staircase_element_volume_mm3=element_volume,
                ruled_staircase_volume_relative_error=volume_error,
                canonical_analytic_volume_mm3=analytic_volume,
                canonical_volume_relative_error=canonical_volume_error,
                recovery_section_analytic_area_mm2=(
                    target_proof.analytic_section_area_mm2
                ),
                recovery_section_polygon_area_mm2=(
                    target_proof.polygon_section_area_mm2
                ),
                recovery_section_area_relative_error=(
                    target_proof.section_area_relative_error
                ),
                recovery_minimum_signed_radial_deviation_mm=(
                    target_proof.minimum_signed_radial_deviation_mm
                ),
                recovery_maximum_signed_radial_deviation_mm=(
                    target_proof.maximum_signed_radial_deviation_mm
                ),
                recovery_maximum_radial_deviation_mm=(
                    target_proof.maximum_radial_deviation_mm
                ),
                recovery_allowed_radial_deviation_mm=(
                    target_proof.allowed_radial_deviation_mm
                ),
                required_quality=quality,
                candidate_attempts=tuple(attempts),
                applied_path=applied_path,
            )

        interface_nodes = {
            node for facet in adapter.interface_facets for node in facet
        }
        accepted_result = []

        def validate_combined(residual):
            algorithm_prefix = f"{prefix},algorithm_3d={residual.algorithm_3d}"
            accepted = accept_residual(residual, algorithm_prefix)
            if accepted is None:
                raise RectangularUfLockedBaseQuadTriFillError(
                    "combined adapter/remainder audit rejected candidate"
                )
            accepted_result.append(accepted)

        check_candidate_budget()
        try:
            generate_rectangular_uf_conformal_hybrid(
                {
                    node: adapter.node_coordinates[node]
                    for node in sorted(interface_nodes)
                },
                {"base": adapter.interface_facets},
                _envelope(root),
                root.base_z_mm + adapter_height,
                root.base_z_mm + root.wall_height_mm,
                target_size_mm=float(target_size_mm),
                transition_distance_mm=float(transition_distance_mm),
                near_size_mm=float(near_size_mm),
                minimum_quality=quality,
                random_seeds=seeds,
                optimization_rounds=optimization_rounds,
                candidate_validator=validate_combined,
                interface_geometry_tolerance_mm=geometry_tolerance,
                verbose=verbose,
            )
        except ConstrainedHybridError as error:
            attempts.append(f"{prefix},stage=remainder,failed={error}")
            return None
        if accepted_result:
            return accepted_result[-1]
        return None

    # Protect the complete Orth trace with exactly one Gmsh-owned HEX behind
    # every immutable QUAD, then let Gmsh's official QuadTri transition expose
    # an all-TRI interface for the Gmsh TET remainder.  The in-plane recovery
    # coordinate is solved from the existing canonical-volume policy; it is
    # not tied to a package role or a fixed fillet dimension.
    for adapter_height in _volume_conserving_adapter_heights(
        root.wall_height_mm,
        float(near_size_mm),
        float(target_size_mm),
        float(transition_distance_mm),
    ):
        try:
            recovery_height = _solve_volume_conserving_recovery_height(
                proof,
                root,
                adapter_height,
                interface_geometry_tolerance_mm=geometry_tolerance,
            )
            target_proof = _mapped_hex_targets(
                proof,
                root,
                adapter_height,
                recovery_height,
                target_size_mm=float(target_size_mm),
                near_size_mm=float(near_size_mm),
                transition_distance_mm=float(transition_distance_mm),
                interface_geometry_tolerance_mm=geometry_tolerance,
            )
        except RectangularUfLockedBaseQuadTriFillError as error:
            attempts.append(
                f"path=volume_conserving_quadtri,"
                f"height_mm={adapter_height:.12g},"
                f"stage=target,failed={error}"
            )
            continue
        geometry_prefix = (
            "path=volume_conserving_quadtri,"
            f"height_mm={adapter_height:.12g},"
            f"recovery_height_mm={recovery_height:.12g},"
            "recovery_section_area_relative_error="
            f"{target_proof.section_area_relative_error:.12g},"
            "recovery_maximum_radial_deviation_mm="
            f"{target_proof.maximum_radial_deviation_mm:.12g},"
            "recovery_allowed_radial_deviation_mm="
            f"{target_proof.allowed_radial_deviation_mm:.12g}"
        )
        for first_fraction in _first_layer_fraction_candidates(
            adapter_height,
            float(near_size_mm),
        ):
            check_candidate_budget()
            prefix = (
                f"{geometry_prefix},"
                f"first_layer_fraction={first_fraction:.12g},"
                "method=add_vertices,node_ordering=xyz"
            )
            try:
                adapter = generate_gmsh_mapped_quadtri_adapter(
                    proof.coordinates,
                    proof.facets,
                    target_proof.coordinates,
                    first_layer_fraction=first_fraction,
                    minimum_quality=quality,
                    allow_source_hex_sicn_aspect_exemption=(
                        allow_source_hex_sicn_aspect_exemption
                    ),
                    interface_geometry_tolerance_mm=geometry_tolerance,
                    methods=("add_vertices",),
                    node_ordering="xyz",
                    verbose=verbose,
                )
            except ConstrainedHybridError as error:
                attempts.append(f"{prefix},stage=adapter,failed={error}")
                continue
            accepted = finish_adapter(
                adapter,
                target_proof,
                adapter_height=adapter_height,
                first_fraction=first_fraction,
                applied_path=_QUADTRI_APPLIED_PATH,
                prefix=prefix,
            )
            if accepted is not None:
                return accepted

    # Retain exact same-height analytic recovery as an independently audited
    # fallback for locked surfaces whose staircase already meets the canonical
    # volume policy without an earlier/later radial recovery coordinate.
    for adapter_height, first_fraction in _candidate_parameters(
        proof, root.wall_height_mm
    ):
        check_candidate_budget()
        target_proof = _targets(proof, root, adapter_height)
        geometry_prefix = (
            f"path=quadtri,height_mm={adapter_height:.12g},"
            f"first_layer_fraction={first_fraction:.12g},"
            "recovery_section_area_relative_error="
            f"{target_proof.section_area_relative_error:.12g}"
        )
        for method, node_ordering in (
            ("add_vertices", "xyz"),
            ("no_new_vertices", "xyz"),
        ):
            prefix = (
                f"{geometry_prefix},method={method},"
                f"node_ordering={node_ordering}"
            )
            try:
                adapter = generate_gmsh_mapped_quadtri_adapter(
                    proof.coordinates,
                    proof.facets,
                    target_proof.coordinates,
                    first_layer_fraction=first_fraction,
                    minimum_quality=quality,
                    allow_source_hex_sicn_aspect_exemption=(
                        allow_source_hex_sicn_aspect_exemption
                    ),
                    interface_geometry_tolerance_mm=geometry_tolerance,
                    methods=(method,),
                    node_ordering=node_ordering,
                    verbose=verbose,
                )
            except ConstrainedHybridError as error:
                attempts.append(f"{prefix},stage=adapter,failed={error}")
                continue
            accepted = finish_adapter(
                adapter,
                target_proof,
                adapter_height=adapter_height,
                first_fraction=first_fraction,
                applied_path=_QUADTRI_APPLIED_PATH,
                prefix=prefix,
            )
            if accepted is not None:
                return accepted
    raise RectangularUfLockedBaseQuadTriFillError(
        "all geometry-derived mapped QuadTri fill candidates failed; "
        f"source_quads={len(proof.facets)},"
        f"min_edge_mm={proof.minimum_edge_mm:.12g},"
        f"median_edge_mm={proof.median_edge_mm:.12g},"
        f"max_edge_mm={proof.maximum_edge_mm:.12g},"
        f"max_quad_edge_ratio={proof.maximum_edge_ratio:.12g}; "
        + " | ".join(attempts)
    )


__all__ = [
    "RectangularUfLockedBaseQuadTriFill",
    "RectangularUfLockedBaseQuadTriFillError",
    "generate_rectangular_uf_locked_base_quadtri_fill",
    "rectangular_uf_locked_base_quadtri_ineligibility",
]
