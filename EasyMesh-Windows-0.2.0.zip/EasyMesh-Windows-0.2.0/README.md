# EasyMesh Layer 轴对称材料网格 Demo

这是一个可运行的参数化原型：在 PySide6 页面中编辑 Layer、预览轴对称结构的过圆心截面，并通过独立子进程调用 Gmsh Python API 生成三维材料网格。平面拓扑以 HEX8 为主，中心增边位置使用少量 WEDGE6；结果可直接在 Gmsh 原生窗口中检查。

`.layer` 是单个轴对称 bump 模板的几何输入。程序从截面的全部真实径向、竖直边界自动建立平面区域与厚度层，不再维护另一份手工直径或总厚度列表。默认示例派生直径为 `90、80、70、62、60、50、30 µm`，其中 `62 µm` 来自 PSV2 的 `1 µm` 侧壁包边；派生总高度为 `125.7 µm`。多个已经生成的模板通过 `.loc` 布局组合，模板体网格不会被重新生成。

## 安装与启动

需要 Python 3.10 或更高版本。从源码目录做可编辑安装后，GUI 与后台 worker 都通过已安装的 `easymesh` 包启动，不依赖当前工作目录或硬编码的虚拟环境路径。

### Windows PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e .
easymesh-gui
```

如果 PowerShell 策略不允许激活脚本，可以不激活环境，直接执行 `.\.venv\Scripts\python.exe -m pip install -e .` 和 `.\.venv\Scripts\easymesh-gui.exe`。

Windows GUI 从 `pythonw.exe` 启动时，后台接触检测和网格任务会使用同一 Python
环境内的 `python.exe`，确保 UTF-8 管道和日志可用；网格任务仍隐藏控制台窗口。
请保留虚拟环境中的两个解释器，不要单独复制 `pythonw.exe`。

#### Windows 3D 预览验收

Qt Quick 3D 默认通过 Direct3D 11 渲染；`QT_QUICK_BACKEND=software` 或
`QT_QPA_PLATFORM=offscreen` 不能验证实际 3D 效果。正常使用无需设置这些变量。
旋转、平移和缩放只更新相机参数，复用已经上传的面/线缓冲和坐标轴模型。

安装后可在源码目录运行原生测速（窗口保持可见，约 16 秒）：

```powershell
$env:QT_QPA_PLATFORM = "windows"
$env:QSG_RHI_BACKEND = "d3d11"
Remove-Item Env:QT_QUICK_BACKEND -ErrorAction SilentlyContinue
.\.venv\Scripts\python.exe scripts/benchmark_preview_3d.py --expect-backend Direct3D11 --min-fps 30 --output preview-performance.json
```

脚本在 1280×800 窗口中持续旋转、缩放和平移，分别预热不透明和半透明模式，
记录 Qt 每秒实际渲染帧数、最大帧耗时、缩放比例、场景大小和图形后端。
`--min-fps 30` 要求两个模式的采样中位数均达到 30 FPS；需要 60 FPS 时改为 60。
使用 `--source <工程.source.json>` 可测自己的工程；默认场景是仓库内 High-UF 示例。
这是当前机器、场景和分辨率的验收数据，不能作为所有 Windows 显卡的性能保证。

CI 覆盖 Windows Python 3.10/3.12、中文及空格路径下的 `pythonw` worker 管道，
并运行 D3D11 遮挡/透明/缩放图像回归及测速，将报告保存为构建附件。
托管 Windows runner 可能使用软件 D3D 适配器，所以 CI 只要求实际渲染有帧输出；
30/60 FPS 的流畅度门槛应在目标 Windows 电脑运行上面的命令验收。
帧率字段采用 [Qt RenderStats](https://doc.qt.io/qt-6/qml-qtquick3d-renderstats.html)
的统计定义，后端要求见 [Qt Quick 3D 图形要求](https://doc.qt.io/qt-6/qtquick3d-requirements.html)。

### macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e .
easymesh-gui
```

`easymesh-gui` 是不带命令行窗口的 GUI 入口；需要脚本化生成时使用 `easymesh-demo`。

### 用户工作目录

GUI 将默认输入指向 `<EasyMesh 工作目录>/examples`，将网格、报告和日志写入 `<EasyMesh 工作目录>/output`：

- 在源码 checkout 中运行时，默认是当前 EasyMesh 仓库根目录；
- wheel / 可编辑安装环境默认使用系统“文稿”目录下的 `EasyMesh`，Windows 通常为 `C:\Users\<用户>\Documents\EasyMesh`，macOS 通常为 `~/Documents/EasyMesh`；
- 在启动前设置 `EASYMESH_HOME` 可以在所有平台显式覆写该位置，请指向当前用户可写的目录。

安装版首次启动会创建这两个目录，并把可编辑的 `bumpcell.layer` 示例复制到 `examples`；不会覆盖用户已经修改过的同名文件。多 Bump 模板属于用户工程数据，安装包不会假设或重建用户的 fine / medium / coarse MSH，因此布局页会等待用户选择自己的 `.loc`。源码 checkout 则继续直接使用仓库内完整的示例布局和模板。当前跨平台承诺覆盖 Windows/macOS 的 Python wheel 与可编辑安装；仓库尚未发布经过签名和真实机器验证的独立 `.exe` / `.app` 安装器。

PowerShell 示例：

```powershell
$env:EASYMESH_HOME = "D:\EasyMeshData"
easymesh-gui
```

macOS 示例：

```bash
export EASYMESH_HOME="$HOME/EasyMeshData"
easymesh-gui
```

如果自定义工作目录，可在其 `examples` 子目录中放置 `.layer` / `.loc` 及引用的模板，也可在 GUI 中直接选择其他位置的输入文件。
GUI 中手工输入的相对 Layer、LOC 和输出路径统一相对于这个 EasyMesh 工作目录解析；`.loc` 文件内部的模板相对路径仍相对于该 `.loc` 自身所在目录。命令行参数保持常规 CLI 语义，相对于命令行当前目录解析。

GUI 分为四个 tab：

- “Layer 单模板”编辑 `.layer`、局部 R/Z 尺寸并生成单个轴对称模板；
- “Bump 布局连接”选择 `.loc`、设置远场尺寸与过渡距离，并在页面中查看每个实例的原生 ring、模板的全部 Z surfaces、只读模板边缘材料、可编辑外部材料映射及最近一次质量报告。
- “MSH → CDB”将已验证的 Gmsh 体网格转换为 ANSYS CDB；
- “Package V2”可在关系表中事务式编辑 portable Source、生成本机绑定的 immutable Job，也可检查并执行已有 Job；右侧提供轻量 3D 几何预览与结果报告，不提供绕过 Job 的执行参数覆盖。

页面点击对应 tab 中的“生成并在 Gmsh 中预览”后会：

1. Layer 页为每次 worker 建立独立且自动清理的输入快照；布局页直接把已校验的原 `.loc` 交给 worker；成功后都会写出可重放的 parameters JSON；
2. 在独立 worker 中生成并验证网格；
3. 打开 Gmsh 原生 FLTK 预览。关闭预览不会关闭参数 GUI。

也可以直接从 Layer 文件生成：

```text
easymesh-demo --layer examples/bumpcell.layer --xy-size 4.0 --z-size 1.35 --symmetry-mode xy_45 --output output/bumpcell.msh
```

增加 `--preview` 即可在生成后打开 Gmsh。`--config` 可以读取页面保存的轴对称参数 JSON，并自动识别 Layer 新格式或旧平板格式。
`--symmetry-mode xy` 对应页面中的“仅保留 X/Y 轴对称”，不再强制 45°/135° 镜像；默认 `xy_45` 保持原行为。

Package V2 的 Mesh 表格末尾提供“高级…”与设置摘要：Orth 可设六方向尺寸、强/弱约束、布种 Origin 和余量保留比例（默认 1/4）；Sweep 独立设置层厚与面内目标尺寸：目标留空时在继承边尺寸之间自动过渡，填写目标后可指定面内过渡距离，空间不足时不强求达到目标；Hybrid 可设置自由表面目标尺寸。所有尺寸都是无接口约束部分的默认值，低优先级继承高优先级的实际网格。Origin 按方向生效，因此 XY 接口不会取消 Z 布种起点。高级设置会随 Source/工程保存。

## Package V2 三拓扑混搭示例

Package V2 只接受当前 Revision 8 Source 和当前运行时 Job；Revision 1–7 的 Source
及其 Job 不迁移、不复用。每个 Generated Component 必须通过唯一 wire authority
`mesh_control.strategy.kind` 显式选择且只能选择：

- `orthogonal_hex`（Orth）：只生成 package-axis-aligned `HEX8`；候选单元中心在原始
  几何内才归属该组件，接触分割不强制保留单元，实际共享面取两侧保留面的交集；
- `structured_sweep`（Sweep）：必须显式提供 Component-local `direction`，再证明该方向上的
  平移不变截面并执行 `TRI3 -> WEDGE6`、`QUAD4 -> HEX8`；end 与 lateral locks 都必须继承
  同一截面，tapered fillet 不可扫；
- `conformal_hybrid`（Hybrid）：精确继承已有 authority seam，其余边界使用 body-fitted
  网格，合法结果是 `HEX8/WEDGE6/PYRAMID5/TET4` 的任意非空子集。经审计的
  Gmsh structured adapter 可以得到全 `HEX8/WEDGE6`。Hybrid 不自行生成 Orth
  staircase；从 immutable staircase 恢复 fillet 时可使用受局部尺寸场约束的几何近似，
  其偏差和体积证据必须写入 report。

Gmsh 拥有 generated connectivity。Source 中不存在第二个 topology 字段；interface、
Component/material 名称、family、堆叠位置、`UF` 字样和 union-find/component role 都不能
选择策略或特殊 executor。

Sweep strategy 必须写成 `{"kind":"structured_sweep","direction":"positive_z"}` 这样的
闭合对象。`direction` 只能是 Component-local 的 `positive_x`、`negative_x`、`positive_y`、
`negative_y`、`positive_z`、`negative_z`，并同时决定 axis、source end 和符号；程序不从
lock 或上下层关系推断。正方向从该轴 `min` end 扫到 `max` end，负方向反之。Box 支持
六向，当前 rectangular frame 只支持 `positive_z`/
`negative_z`，fillet 不支持 Sweep。方向不匹配 geometry 或 immutable contact/priority
约束时在网格生成前直接报错。

Orth 可在 `strategy.directional_near_edge` 中分别设置 Component-local
`positive_x/negative_x/positive_y/negative_y/positive_z/negative_z` 六个近边尺寸；缺省
方向回退本 Component 的 `target_edge`。可选 `strategy.partition_origin` 只为缺少 executable
boundary anchor 的分区提供局部锚点。每个 directional 值是相应 side 的法向要求，
不是对整个面或 seam 全部切向边的统一尺寸。各 side 独立划分，只共享公共 edge
authority；Frozen 继承 trace 的切向边即使更粗也不会被分割。

单实体 Box 和多 Solid Component 的六方向尺寸均可独立。fillet 使用局部八块矩形环候选域；
Z 按尺寸等分或继承既有接触分层，不为角部问题自动增加层数。中心筛选后若出现
边/点连接、不连通或顶端截短，报告明确警告和位置，仍允许导出；受影响单元归入
`ORTH_MESH_WARNINGS`，MSH 和 CDB 均保留此集合。
外围未归属候选的 XY/Z 分割、放置及归属掩码保存于 report 的
`execution.orthogonal_candidate_grids`，供未来 molding 等互补部件重新分类复用。

Frozen 在声明 placement 后保持节点和单元成员、facets、element kinds 和 ownership
不可变。镜像仅调整摆放副本的单元节点顺序和接口面绕向以保持正体积，原始文件不变。
唯一显式 Frozen/Generated interface mode 是 `preserve_interface_trace`，只锁定
完整实际接触 trace；当前模型不继承 Frozen volume，也没有任何体 propagation。

Generated/Generated seam 只由真实正面积 adjacency、双方 priority、显式 strategy、
Component-local sizes 和可执行边界约束确定。共享 surface 只生成一次，各 owner 复用同一组
semantic node tokens/facets；禁止先独立建网再按距离合点。union-find 只能合并已经证明的
identity，不能发现 seam 或赋予 Component 角色。

`mesh_settings.interface_geometry_tolerance` 的默认值和当前示例值均为 `0.01um`
(`1e-5 mm`)。它只用于同点、同平面、同边界和已声明 trace 的几何谓词，不会移动 Frozen、
合并一般近邻节点、跨越真实 gap 或放宽质量审计。

当前 high-UF Revision 8 测试夹具是一个混搭集成输入：两个 ring 使用 Sweep，corner core
及 upper fillet 使用 Orth，substrate、added Si 使用 Hybrid；五个 Frozen match 全部是
`preserve_interface_trace`。历史 `worker-3.0.0` Revision 6 运行曾写后重开得到
306,407 nodes、422,660 elements，
即 `182456 HEX8 + 219536 WEDGE6 + 1536 PYRAMID5 + 19132 TET4`；canonical numbered mesh
SHA-256 为 `9f617c23932aab1b193820c74741659bef3b88eddd37e5da29d237b7ba61b4df`。
实际质量为 `minDetJac=4.405258987e-10`、`minSJ=0.605876292`、
`minSICN=0.028631302`、`minSIGE=0.091772989`。raw 三指标比较因 23,712 个已逐单元证明为
Cartesian HEX8 的 Orth corner-core 低 SICN 而为 false，但结构化豁免存在，
`strategy_aware_floor_met=true` 且 `floor_met=true`。这些数字仅是历史证据。当前执行语义为
`worker-3.22.0 / role-free-mixed-v29`，worker report schema 为
`easymesh-package-v2-worker-report-v7`，role-free execution schema 为
`easymesh-package-v2-role-free-mixed-execution-v6`。Orth→Orth 保留 per-side partition；
Orth→Hybrid 在几何、完整锁面和实际 Orth producer topology 都符合时使用 Gmsh
QuadTri。当前 Source 的 +X/+Y 为 `5um`，其他方向为 `80um`，表示侧面的法向要求；Frozen 切向边
可大于 5 um，所以不宣称全 seam 都是 5 um，也不再将 1,996 个 QUAD 写成当前
golden。旧 worker Job 和不匹配 Source/plan/runtime/output hash 的 artifact 都必须重建。

v25 支持 Sweep 的局部侧面 QUAD 锁定：所有接触面沿指定 Sweep 方向共享同一组层位，
每个 QUAD 必须只跨相邻层，且截面边不能跳过其他锁定边的分区；未接触区域可继续延伸。
没有继承端面时，也可由兼容的侧面约束生成完整截面。局部外框接触 Orth 时，仅该接触
外框要求正交 QUAD，内部允许保持混合截面。原有组件策略、Frozen 网格和质量门槛保持不变。

任何 CDB 只有在 source mesh hash 与已验收 MSH 匹配时才是有效派生证据。all-Hybrid
变体尚未用 v14 路径重新验收；早期失败只作为历史记录，本轮 Orth→Hybrid 能力
不等于 all-Hybrid 已修复。

v23 起 Hybrid 优先生成能向内部加粗的 TET，接口允许 PYRAMID/HEX/WEDGE 过渡。
完整混合端面和矩形侧面锁定的 Box 优先使用直接 OCC 路径，六个局部法向均可用；
报告记录实际单元类型、近远尺寸及质量。只有适用的 TET 路径失败后才尝试整体 Sweep，
并在报告和界面明确警告，仍允许导出。TET 加粗不保证比 HEX/WEDGE Sweep 的单元总数少。

v24 对 Orth 的四个 die-wall 侧分别检查顶部截短，避免其他侧达到顶部时掩盖局部细节消失。
中心筛选删掉的区域不再是实际接触面，邻接 Hybrid 可生成自由 TRI；保留的接触 QUAD
仍必须共享全部节点。局部截短明确警告，并把剩余下缘单元加入 `ORTH_MESH_WARNINGS`。

GUI 的“结果报告 → 网格警告”逐项显示部件、问题位置（µm）、原因、处理建议、
标记单元集与导出状态；原始 JSON 保留为技术详情。重新检查已有 Job 也会加载这些说明，
无需重新划分网格。切换 Job 或修改 Source 后清除旧警告，避免误认为当前结果。

v14 起的最终回退支持完整继承端面加局部侧面锁定的 Hybrid Box/Frame：逐个证明 QUAD 是同一
截面周界的平移产物，且层界不会切开任何锁面，然后由 Gmsh 生成 HEX/WEDGE。
不拆几何、不移动 Frozen、不降低质量门槛；显式 Sweep 的默认限制不变。

v15 将不变的底面边界范围及 Orth 锁面 ID 集合改为单次计算。直接 OCC 残余体候选
在独立进程执行，默认每候选 60 秒、同一 QuadTri/直接体搜索共用 240 秒预算；超时
丢弃未验收候选，预算耗尽明确失败。生成、优化、质量和审计阶段写入进度与报告。
预算集中在 `gmsh_candidate_runtime.CandidateExecutionPolicy`；不是各组件写死的规则，
目前不增加 GUI 字段，也不修改网格尺寸、质量门槛或 Gmsh 线程数。

v16 根据实测，仅将直接 OCC 候选的 HXT(10) 配置为 4 线程；Delaunay(1) 与
Frontal(4) 明确为 1 线程，其他网格路径保持原设置。实际线程选项写入候选事件，
算法与线程数的对应关系记录在 parameters 的 `fixed_policy`。算法顺序、优化轮数、
质量门槛和 Frozen 约束不变。升级后须重启 EasyMesh，再从 Source 创建新 Job。

v17：全 TRI（或无锁面）的直接体候选默认 HXT（4 线程）→ Delaunay（1 线程），
不再自动尝试 Frontal。HXT 最多占用进入该算法时剩余搜索预算的一半，为回退保留时间。
“高级网格设置”中可勾选“并行尝试 HXT（4 线程）与 Delaunay（1 线程）”，
对应 Source 的可选布尔字段 `mesh_settings.parallel_tet_candidates`（默认 false）。
每个 seed 同时最多运行两个独立候选，先通过完整候选及组合审计者胜出，然后回收另一个；
不合格候选不能抢先胜出。直接承接 QUAD 的候选仍使用 Delaunay，不受该开关影响。
并行增加 CPU/内存占用，胜出算法和内部网格可能随负载变化；实际算法、种子和线程
写入候选事件。该选项随 Source/Job 固化，改变后必须重建 Job。

v18：Package V2 结果报告前增加质量迭代表，显示组件、候选算法/seed、轮次、
`minDetJac / minSJ / minSICN / minSIGE`、单元数及验收状态。直接 OCC 和 closed-shell
候选在生成后（第 0 轮）及每轮外层优化后记录数值，失败候选也保留；这不是 Gmsh
优化器内部每一步的轨迹。最终重开审计另列组件和整包行，Orth 长宽比豁免明确标注。
历史日志未记录的数值显示“—”，不拿最终网格倒填候选。几何偏差独立提示，
质量通过不等于原始曲面精确符合。此次仅增加观测/展示，不改变几何和质量门槛；
升级后重启界面并从 Source 创建 v18 Job，才会记录新的逐轮数据。

v19：Frozen 接口按实际外表面与 Generated 几何的正面积接触自动建立；不再要求
手工维护接触名单。Source 中已有接口记录不能制造或阻止实际接触，新增组件
不再复制参考组件的接口。Frozen 始终不可修改、优先级最高；部分面片、重复归属
和不兼容策略仍明确报错。执行和报告复用一次接触检查；实际接口及面片数写入
parameters/report 的 `frozen_contact_discovery`。升级后重启并从 Source 重建 v19 Job。

v20：界面的“实际接触（自动检测）”表及下方派生 JSON 在 Source 打开、有效编辑、
Job 快照切换、Frozen 三件套变化后后台刷新，过期结果丢弃；检测失败不是零接触。
Source/immutable Job 内的旧 `interface_matches` 不被偷偷改写，也不作为实际接口显示。
Generated 接触不要求任一侧覆盖整个几何面：出面前用 Gmsh 落实局部接触边界，
只把重叠区域的确切面片与节点传给相邻组件，非接触边界和完整体积保留。
这不放宽 Frozen 不可拆分、Sweep 方向/截面兼容、Orth 格点兼容和质量约束。
已验证实际 ring_upper 的 1.44 mm² 局部出面及小型混搭装配；不是任意几何/组合
或用户整包完整生成成功的声明。升级后重启界面，从 Source 重建 v20 Job。

v21 / Source Revision 7：彻底移除手工 `interface_matches` 字段（空数组也拒绝），
并移除 Source 编辑器的接口配对模型、复制参数及旧控件。JSON 统一在 JSON 页展示，
明确区分模型定义和自动检测结果；实际接触页不再重复放 JSON。
新的当前模型入口为 [`package_v2_high_uf_clean.source.json`](output/package_v2_high_uf_clean.source.json)。
它保留 7 个组件的几何、优先级、策略、尺寸以及 connected_bump Frozen 定义。
需要重启并从新 Source 创建 v21 Job。旧 Job 不改写；Frozen 引用的
`bumps_connected.parameters.json` 和 `bumps_connected.report.json` 是必要资产，不能当旧 Job 删除。

compatible planar mixed TRI/QUAD partial Sweep end 已有 Gmsh-owned 补全路径；任意其他
partial topology 仍 fail closed。multiply-locked Hybrid 只证明了严格受限的 axis-aligned
Box `Mesh.OptimizePyramids=1` 重试；真实 `added_si` 定向测试得到 `16878 TET4 + 1392
PYRAMID5`、`fold=0`、体积相对误差 `2.64e-15`、`minSICN=0.05759`。这不是任意复杂 shell
已受支持的声明。

v28 / worker-3.18.0：质量表按实际执行顺序记录每个 Generated 组件的开始、完成或失败，
Orth/Sweep 完成后测量原始连接关系，后续 Hybrid 失败时仍保留前面组件的记录。
生成完成标记为“待整包审计”，不能当作最终验收。Hybrid 每轮原生优化单独记录；
产生倒置或折叠的节点平滑先回退，已有折叠的初始候选直接拒绝。
对于未达到质量门槛的内部 TET/PYRAMID，仅移动内部节点并检查全部相邻单元。
Box Hybrid 的请求尺寸过渡失败后，可重试尺寸梯度不超过 0.5 的较细内部网格；
请求与实际采用的过渡距离都写入报告，接口锁定及 0.03 质量门槛保持不变。
升级后重启界面，从 Source 创建新 Job；旧 Job 的运行版本不会自动改写。

v29 / worker-3.19.0：Orth 支持同一 Component 多个 Solid，以及相接 Orth Component 的共同规划。大 Box 上的局部小接口会提前进入分块，六方向尺寸、三维内角播种及可配置 0.25 收尾规则共同生效。材料和 Solid 归属保留；固定非 Orth/Frozen 接口不兼容时直接显示红色错误，不生成过渡网格。

可打开 [多 Solid 与跨 Component 示例](examples/package_v2/orth_connected.source.json)。正交 `union`/`difference` 也可写入 Source；孔洞和开口在预览及网格中按实际边界处理。多个独立 Solid 的正体积重叠需显式写成 Union。[兼容/冲突示例说明](examples/package_v2/ORTH_CONNECTED.md)提供可运行的固定接口案例。升级后需重新从 Source 创建 Job。

先确保 connected-bump 的 MSH/parameters/report 三件套存在，再创建绑定当前 Source、
Frozen artifacts、checkout 和 Gmsh/Worker runtime 的新 immutable Job：

```text
python scripts/create_package_v2_demo_job.py
easymesh-demo --package-v2-job output/package_v2_high_uf.job.json
```

GUI 用户在 “Package V2” 页点击“从 Source 创建 Job…”，选择
`output/package_v2_high_uf.source.json` 和输出 MSH，然后执行自动选中的 Job。
不要把 `.source.json` 直接填入 immutable Job 输入框。Mesh 表把三值策略写回
`strategy.kind`；Sweep 还显示必填六值 `direction`，只有 Orth 显示六方向 near-edge 与
optional partition origin。Interfaces 只提供 trace preservation。“高级接口几何设置”编辑
带 `mm`/`um` 单位的绝对容差。
任何 Source 编辑都会完整重编译并使旧 Job/report 失效。

Source revision 8 / worker-3.22.0 统一使用 **Template → Instance**：工程里的所有生成几何
都是实例。点击“新建 Source…”可从空工程开始，内置两种 Box 模板：`box_zmin_center`
以 Zmin 面中心为原点，`box_min_corner` 以 Xmin/Ymin/Zmin 角点为原点。
二者都只公开 `x_size`、`y_size`、`z_size`，内部映射到六个边界表达式。

“创建实例…”选择模板，为所有公开参数绑定 Global variable、表达式或带单位数值，
并设置模板原点在全局坐标中的 Origin X/Y/Z、旋转和镜像。实例可以
加入已有 Component，也可以新建 Component；材料和网格由 Component 统一维护。
网格优先级、策略与尺寸统一在 Mesh 页维护；新 Component 自动获得默认设置。
包含 fillet 的新 Component 默认使用 `conformal_hybrid`；不等宽或外扩 fillet 当前使用此策略。
“复制实例…”继续引用同一个模板并复制绑定；“编辑实例…”只修改选中实例。
复制到新 Component 时继承原网格设置并自动分配独立优先级；加入已有 Component 则继承该组设置。
“删除实例”只移除选中实例；“删除 Component”移除整组实例。两者都保留模板。
未打开或新建 Source 时不显示创建实例或模板的入口。Geometry 页的树按 Component → 实例 → 参数展开，
只显示顶层公开参数和 Origin，
内部公式及递归子实例不会展开到工程表中。Variables 表只显示 Global variables，
支持增删和未引用高亮；被绑定或被其他全局公式使用的变量不能删除。

“创建模板…”定义新的局部几何；“编辑模板…”修改共享定义。编辑器包含公开
Local variables、内部变量/公式、基本图形，以及已有模板的子 Instances。
公开参数和内部变量均显示引用情况；未被本模板的图形、公式或子实例使用的项以黄色标记，
悬停可查看引用位置。编辑表达式、重命名变量或增删图形和子实例时，引用状态自动更新。
局部原点固定为 `(0, 0, 0)`；模板定义不接受 `origin` 字段。
子实例的 Origin 使用父模板坐标。每个子参数必须显式
绑定到父模板局部变量、公式或常量。模板不能读取工程 Globals，同名局部变量可在不同模板中复用。
模板编辑影响引用它的全部实例；参数重命名保留原绑定，新增公开参数以默认值补齐现有绑定。

基本图形提供 `solid`、`fillet`、`ring`。solid 使用六个局部边界坐标；ring 和 fillet 使用
外框与内框的 xmin/xmax/ymin/ymax，共用 zmin/zmax。fillet 的外框表示底部轮廓边界，
底部四侧间距由内外框坐标确定；顶部 X−、X＋、Y−、Y＋宽度分别设置，每项均允许为零，
可绑定 Local variable。直边截面沿高度过渡，四角按相邻两侧的底部和顶部宽度扫掠并与直边相切。
模板使用四项 `top_widths`，不再读取单一 `top_width`。
扩展图形通过 `BasicShapeDefinition` 注册，必须明确局部 X、Y、Z 坐标字段；字段可表示
中心、起点或其他基准点，不要求使用 min/max 命名。详见 [基本图形与 Component](docs/basic-shapes-and-components.md)。
这些操作均整体验证后写入草稿，取消或校验失败不产生部分修改。

“Export template…”导出 `.template.json`，包含根模板及所需的递归子模板，不携带 Globals。
“Import template…”读取这种独立文件。同名同内容模板复用，
同名不同内容拒绝覆盖。实例绑定错误、单位错误、模板循环和过深嵌套都会明确报错。
示例 `examples/local_template_lid.source.json` 含两个共享 lid 模板的实例；lid 内部组合 Frame
和基础 Box 子实例，只公开 cavity、thickness、footprint_width。

仅支持当前 Source revision 8 和当前运行时 Job。旧 Source、旧 `.geometry.json` 预设、
旧模板坐标写法与内嵌旧 Source 的 Job 会明确报错，不再自动迁移或转换。
Job 请求格式仍为 `easymesh-package-v2-job-request-v1`，这是当前格式；运行时身份校验保持严格。
删除前的功能对应核对与验证见 [当前格式清理记录](docs/current-format-only.md)。
Orthogonal Hex 支持每个实例多个 Solid；相接 Solid 与跨实例的 Orth 接触共同规划，共用完整 QUAD 接口。

Frozen 页提供“添加网格实例…”、“编辑网格实例…”和“删除网格实例”。添加时只需选择 `.msh`，
填写唯一实例名称，从程序读取的体分组（Physical Volume）列表中勾选需要使用的部分，
以及位置、镜像和直角旋转。也可选择“复用网格实例”，带入已有文件及摆放值后创建新实例。
文件须位于 Source 所在目录或其子目录。首次添加时，程序在后台计算 SHA-256，
保存到 Source 的 `artifacts.sha256`。执行前会检查网格是否被修改或同名替换；
确认使用新内容时，在编辑窗口点击“更新网格引用”并保存。修改摆放不会自动接受内容变化。
Frozen 不再依赖或读取输入网格的 Parameters、Report；生成任务自身的质量报告仍正常输出。
删除会移除该网格实例的所有 Component 引用，保留原始文件。添加、编辑、删除均只修改
有效草稿，点击“保存 Source”后落盘；运行任务、存在暂存修改或查看只读 Job 快照时不可操作。

分组列表在后台仅读取 MSH 4.1 ASCII 文件头部的 PhysicalNames 和 Entities，读到这两段后立即停止，
不扫描节点和单元。若前部没有这些信息或头部超过 2 MB，则停止并提示；已有实例保留原分组，
仍可编辑摆放。分组可按名称筛选，允许只选部分网格，但所选分组不能重复覆盖同一体实体。
网格分组保留原名，允许 `302`、含空格、符号或中文的名称；它们不受变量命名规则限制。
程序为分组生成独立的安全内部标识；重名、空分组仍会提示错误。
实际执行时仅使用勾选分组的体单元及其节点，原始网格文件不变。头部范围只是所选网格的外接范围，
用于轻量预览和定位；任意形状的真实节点、单元、孔洞及外表面保持原样，用于实际接触检测与装配。
头部、网格指纹、解析结果和外表面使用有界的进程缓存。文件身份、大小、mtime/ctime 未变时不重读；
检测到变化才重算指纹，内容相同则复用解析结果。新进程或缓存淘汰后会重新读取和验证。
当前 Frozen import 版本为 `frozen-mesh-sha256-v4`，Job 只绑定输入网格文件的指纹。

编辑窗口带入当前网格实例的文件、位置、旋转和镜像。位置 X/Y/Z 是网格局部原点在全局坐标中的
位置，保存时替换当前摆放，不累加。每轴可选择 0/90/180/270° 旋转及镜像开关；镜像 X/Y/Z
分别关于网格局部 YZ/XZ/XY 平面，顺序为镜像 → 绕 X、Y、Z 旋转 → 放到指定位置。
Source placement 保留 `rotation_matrix`，并可附带经一致性校验的 `rotation` 和 `mirrors`，
用于准确恢复用户选择的组合。只有矩阵时带入等效直角组合；已有非直角姿态明确显示并保留，
用户可修改位置或选择替换为直角姿态。旋转使用右手规则；表格与弹窗显示同一组旋转/镜像设置。
多个 Frozen 实例可编辑、预览和保存，但当前 Job 执行器仍只支持一个 Frozen Source 与生成几何
联合划网格。

Package V2 的内嵌 3D 预览直接读取纯编译器输出的 canonical geometry，把 Box、Frame、
Underfill 等 primitive 的实际外形交给 Qt Quick 3D/RHI 渲染，不启动 Gmsh。实体遮挡使用
Qt 的真实深度缓冲；可旋转、缩放和平移，并支持材料
着色、Component 显隐、表格选中联动，以及由 Weighted Blended OIT 处理的可选半透明模式。
预览固定使用适合 CAD 和微米级尺寸检查的正交相机，最高支持 100,000 倍指针锚定缩放；
X/Y/Z 按钮可从对应正轴快速查看 YZ、XZ、XY 平面，“恢复视图”返回等轴观察角。
全局原点显示红 X、绿 Y、蓝 Z 坐标轴，方向随视角旋转；轴标记叠加在模型上方，
缩放或调整窗口大小时保持固定屏幕尺寸，平移时仍跟随真实原点。
在左侧 Geometry 树选中实例时，同时显示它的局部原点、小写 x/y/z 轴和实例名；
选中 Component 时显示其各实例的局部坐标，嵌套子实例的内部坐标不展开。局部轴随实例旋转和镜像变化。
Geometry 模板、实例（含子实例）的创建和编辑窗口右侧复用同一 3D 预览组件，左右区域可拖动调整。
弹窗显示当前对象的 Local origin 与局部小写 x/y/z 轴；实例的轴随其位置、旋转和镜像变化。
模板按公开参数默认值预览，实例按当前绑定预览，子实例使用父模板草稿中的局部变量。
停止输入约 200 ms 后更新；输入不完整或几何无效时提示原因并保留上次有效预览，取消不修改 Source。
应用内 Tab 用于填入当前补全候选；没有候选时保持焦点，Shift+Tab 也不再切换输入框或表格单元格。
Enter 仍用于提交，Ctrl+Tab 等组合键保留原有行为。
内部三角只构成有上限的 GPU 面缓冲，不参与描边；线缓冲只包含实际外轮廓和折边。Frozen
默认显示经过深度测试的 bounds/placement 线框和接口关系：bounds 只会从有大小上限的
parameters/report JSON 元数据读取；元数据缺失时显示“范围未知”的代理框，始终不会为预览
读取大型 MSH。只有完整编译成功后才替换场景，非法 Source 编辑会继续保留上一帧合法几何。
同一份场景通过 Qt RHI 在 Windows 使用 Direct3D、在 macOS 使用 Metal，不包含 OpenGL
专用渲染代码或自定义 shader。

正式结果只有在写出 MSH 后重开审计通过才成立。审计从实际 connectivity 重算每个
Component 的 actual element-kind counts、strategy-family compatibility、semantic seam face
keys、Cartesian HEX 证据、Frozen trace、ownership、体积、重复节点/单元、fold、
non-manifold faces，以及策略感知质量门槛。所有单元要求正 Jacobian、正 `minSICN`、
`minSJ >= 0.03` 和 `minSIGE >= 0.03`；Frozen、Sweep、普通 Hybrid 单元还要求
`minSICN >= 0.03`。Generated Orth Component 只有在全部单元逐一证明为 package-axis
Cartesian HEX8 后，才允许把低但为正的 SICN 记录为各向异性长宽比证据。Hybrid 中只有
紧邻真实 Orth authority seam、拥有唯一 contracted shared QUAD 且自身也证明为 Cartesian
的首层 HEX8，可使用同一例外；continuation provenance 本身并不构成证明。扭曲/剪切/
非正交、零/负 SICN、不合格 Jacobian/SJ/SIGE 仍是硬失败。原始最小值与豁免组件必须继续写入 report。Orth 的
analytic sloped coverage 只作
诊断证据，不是删除 perimeter 的 gate。Source 字段、旧 report 或渲染外观都不能替代这份
证据。report 中 `quality.minimum_sicn` 始终保留全网格 raw 最小值；
`raw_all_metrics_floor_met` 只表示未应用策略语义的直接数值比较，
`strategy_aware_floor_met`（以及同义汇总字段 `floor_met`）才表示上述最终合同是否通过；发生
Orth 例外时还必须列出 `orthogonal_sicn_aspect_ratio_exemption_count` 和对应组件证据。

同目录的 `generated_box.source.json` 和 `generated_frame.source.json` 也已是 Revision 7，
分别提供小型 Hybrid Box 与 Sweep Frame 冒烟输入。完整说明见
[`examples/package_v2`](examples/package_v2/README.md)，规范见
[`Package V2 Revision 7 mixed-topology contract`](docs/PACKAGE_V2_MIXED_TOPOLOGY_CONTRACT.md)。

## 多 bump 模板连接

一般不需要使用命令行：启动 GUI 后切换到“Bump 布局连接”，选择或重新载入 `.loc` 即可。页面先校验 bounds、模板引用和坐标格式，再从各模板读取真实外径、原生外圈及保持原高度的边缘 slab；不预设最大 bump 直径或最小中心 pitch。模板边缘 component/material 始终只读；外部材料按 Layer 的 material 原名映射，目标留空表示继承，输入 `UF` 后材料名就是 `UF`，不会增加前缀。例如 `ILD/USG` 与 `PSV2/USG` 都属于材料组 `USG`，一次 `USG → UF` 会同时覆盖两段外缘，但逐层 component 仍分别是 `ILD` 与 `PSV2`。生成在独立 worker 中执行，完成后直接显示节点/单元数、component/material 衔接、接口质量、各向异性提示和硬约束复核。相同输出路径在已有任务运行时会被跨进程锁定；GUI 还会核对 `.loc`/模板的新旧状态、外部 component/material stack，并用报告中的文件大小和 SHA-256 绑定实际 `.msh`，因此 preview 不会误读遗留或错配的 report。

`.loc` 同时定义矩形 XY 范围、模板别名和每个 bump 的中心位置，例如：

```text
Xsize,0um,10000um
Ysize,0um,5000um
fine,../output/concentric_fine.msh
medium,../output/concentric_medium.msh
coarse,../output/concentric_coarse.msh
110um,110um,fine
110um,220um,medium
220um,220um,coarse
220um,110um,medium

# 可复用长度表达式，以及一个 50×50 µm、XY 步长 5 µm 的结构化角块
define, corner = 50um
mesh,HEX,size,[(0um,0um),(corner,0um),(corner,corner),(0um,corner)],x,5um
mesh,HEX,size,[(0um,0um),(corner,0um),(corner,corner),(0um,corner)],y,5um
```

模板路径相对 `.loc` 所在目录解析；坐标支持 `um`、`µm`、`μm` 和 `mm`。`define` 只支持带单位长度、已定义变量及 `+/-`，不会执行任意表达式。相同矩形的 `x`、`y` 两条 `mesh,HEX,size` 记录组成一个硬约束：四点必须是轴对齐矩形，两方向尺寸可独立设置，分别必须为正数且整除对应边长，结构化矩形之间不能相接或重叠。指定区域在 XY 中生成精确矩形 QUAD4，并沿模板 Layer 的全部原始 Z surfaces 挤出为正交 HEX8；这里的“立方体”指结构化六面体拓扑，Z 厚度继承 Layer，不会为了强求三边等长而移动材料界面。

`.loc` 不假定模板直径，也不设置中心 pitch 下限；读取模板后使用各自真实外缘建立过渡域。只要模板 footprint 之间及其与 XY 边界之间仍有正净空，就交给 Gmsh 生成并由质量门槛判断是否可用；重叠、相切、越界、结构化区域与 bump 相交，以及重复坐标都会明确拒绝。

从布局生成连接网格：

```text
easymesh-demo --layout examples/bumps.loc --far-field-size 80 --transition-distance 120 --transition-material CU=UF --output output/bumps_connected.msh
```

`--loc` 是 `--layout` 的同义参数。两个尺寸选项的单位均为 µm；它们控制未被 `.loc` 结构化区域覆盖的 XY 过渡网格，不改变模板、结构化区域的硬尺寸或任何 Z 高度。`--transition-material SOURCE=TARGET` 可重复使用；GUI 只会把非继承映射作为规范化参数传给 worker。

材料映射对当前布局中该源材料对应的全部 Z slabs 生效。当前每个 Z slab 的背景区域使用一个统一外部材料；如果将来需要同一高度下不同 bump 周围使用不同材料，则还需要增加 XY 材料分区。

连接采用原生外圈分层挤出，而不是给所有模板添加统一接口壳：

- 每种模板各自保留原生外圈节点数，不互相重采样，也不要求直径一致；
- 模板的全部节点、HEX8/WEDGE6 类型及 connectivity 只做 XY 平移和全局 retag；
- Gmsh 在同一 XY 分区内生成共形混合网格：`.loc` 指定矩形为精确 QUAD4，其余矩形减去各自 polygon hole 的区域为 TRI3；两者共享公共边节点，再沿模板原始的全部 Z levels 分别挤出为 HEX8/WEDGE6；
- 每个外缘 Z interval 的新单元默认继承接触该边缘的 component/material，也可由用户按源材料映射为另一外部材料。当前默认模板边缘依次为 `0–7 µm → Si/Si`、`7–14 µm → ILD/USG`、`14–15.9 µm → PSV2/USG`、`15.9–23.7 µm → PI/PI`、`23.7–85.7 µm → UF/302`、`85.7–105.7 µm → SR/SR1`、`105.7–125.7 µm → SBT/SBT`；例如 `SR1=UF` 同时改变外部 WEDGE6/HEX8 的材料，模板中的 `SR/SR1` 单元不变；
- 每个模板侧壁 QUAD4 必须恰好邻接一个原模板体单元和一个新 WEDGE6，双方复用同一组 global node tags 且面朝向相反；材料不同时，该共形面就是明确的材料界面；
- 最终 MSH 只写三维体单元。写出后会在空 Gmsh model 中重新打开，复核节点坐标、element connectivity、Physical Volumes 和重复节点。

`minSICN` 会因 `0.95 µm` 薄层相对远场 XY 尺寸很小而下降，不能单独解释为模板或过渡网格扭曲。新过渡区以正 Jacobian 为硬门槛，并要求 `minSJ`、`minSIGE >= 0.30`；二维过渡同时要求 `minSICN`、`minSIGE >= 0.30`。

节点、单元、接口数量及最窄几何净空会随 `.loc`、模板直径、原生 ring 分辨率和尺寸场变化；GUI 与 `.report.json` 会显示本次生成的实际统计和质量结果。

## FCBGA 封装装配（legacy Phase 1）

`.pack` 在已生成的 connected-bump MSH 外继续装配基板、附加 Si、SBT/SR 环和 UF。本节是 legacy Phase 1 CLI builder 的独立对照工作流，不是上文不兼容的 Package V2 Revision 6；本节的 1.37M high-UF 数据仅作 legacy `.pack` 对照，不能转换为或证明任何 Revision 6 artifact。工作流先生成 `bumps_connected.msh` 及其 parameters/report sidecar，再生成 package MSH，最后单独转换 CDB：

```text
easymesh-demo --layout examples/bumps.loc --output output/bumps_connected.msh
easymesh-demo --package examples/package.pack --package-bulk-mode sweep --output output/package.msh
easymesh-demo --convert-msh output/package.msh --output output/package.cdb --cdb-element-type 185
```

厚度方向直接拖拽和渐粗混合网格使用同一 `.pack` 输入，可以分别输出后并排比较：

```text
easymesh-demo --package examples/package.pack --package-bulk-mode sweep  --output output/package_sweep.msh
easymesh-demo --package examples/package.pack --package-bulk-mode hybrid --output output/package_hybrid.msh
easymesh-demo --package examples/package_high_uf.pack --package-bulk-mode hybrid --output output/package_high_uf_hybrid.msh
```

`sweep` 是默认模式，对附加 Si 和 substrate 沿固定 XY 拓扑做厚度拖拽，UF 也沿继承的细 Z 层生成保守 staircase。`hybrid` 是三向 bulk 对照 demo：die/Si 从 connected-bump 的精确顶面、substrate 从 C4/ring 的精确底面立即进入 XYZ 渐粗的 TET4/PYRAMID5；锁定 TRI 面由 TET4 承接，锁定 QUAD 面由完整 PYRAMID5 底面承接。UF 在 bump 顶以下仍保持受保护的 HEX8 staircase；一旦越过 bump 顶面，完整 QUAD annulus 只经过一次有界的 PYRAMID5/TET4 转换段，转换段顶面已经缩成较粗 TRI partition，剩余高度用纯 TET4 继续放大 X/Y/Z，不再复制细 XY 面。适配段采用不超过 region `maximum_size` 的一次性 3×近场平面目标；构建还要求 TRI 等效面数确实下降、平面边长中位数至少增长 1.25×，否则即使体单元质量合格也会 fail closed。该实际 UF 内壁随后作为 added-Si 的精确 side lock，所以高 UF 也不会迫使整块 Si 保持细网格。connected-bump connectivity、50×50 µm corner ports、bump 高度内的 UF 分层和 SBT/SR rings 均保持不变；无法形成正面积体单元的解析尖端仍只截去一个很小的 regularized cap，parameters/report 会同时记录解析顶面、实际网格 cap 和省略高度。模式、`hybrid_scope`、两段 UF 的 adapter cap/face 数、锁面数、平面粗化比、近远端边长、三向 span、随机种子和三项质量指标都会写入 parameters/report。

以默认 `package.pack` 为例，`sweep → hybrid` 为 `1,248,212 → 992,313` nodes（-20.5%）及 `1,405,104 → 1,203,769` volume elements（-14.3%）。更能暴露高度拖拽问题的 `package_high_uf.pack` 把 UF 顶设在 added-Si 高度的 90%：`sweep → hybrid` 为 `1,528,236 → 1,141,147` nodes（-25.3%）及 `1,680,124 → 1,371,013` elements（-18.4%）。其中 ADDED_SI 从 `254,040` 降到 `19,966`（-92.1%）；UF 从 `611,964` 降到 `506,930`，其 bump 顶以上区域只含 `4,032 PYRAMID5 + 26,470 TET4 = 30,502` 个单元。适配层把 4,032 个 QUAD（等效 8,064 个 TRI）降为 192 个粗 TRI，随后纯 TET continuation 不再携带原平面分区；近/远中位边长约 `6.5 → 38.5 µm`。connected-bump 和两个 rings 完全不变。substrate 单区则从 87,520 个粗 sweep HEX/WEDGE 增为 117,517 个 TET/PYR：四面体化的主要收益是节点/自由度与三向远场分辨率，不保证每个 component 的一阶体单元数都下降。

含 TET4/PYRAMID5 的 `output/package_hybrid.msh` 转换 CDB 时只支持 `SOLID185`；`SOLID186` 仍只接受 HEX8/WEDGE6。例如：

```text
easymesh-demo --convert-msh output/package_hybrid.msh --output output/package_hybrid.cdb --cdb-element-type 185
```

省略 Package 命令的 `--output` 时默认写入 `output/package.msh`。`--far-field-size` 和 `--transition-distance` 对 Package 同样生效，单位仍为 µm；前者控制 package 平面远场，并作为 hybrid substrate、die 和上段 UF 的远端目标上限（薄体仍受可用高度约束）；后者控制从 locked interface 向远端的三维尺寸增长距离。它们不改变 connected-bump、四个 corner ports 或解析材料界面。Package 构建失败会在 stderr 给出一条简洁错误并返回状态码 `2`，不会输出 Python traceback。

当前 [`examples/package.pack`](examples/package.pack) 的内容为：

```text
bumpRegion, "../output/bumps_connected.msh"

+,SBT,(0um,0um),cube,1000um,1200um,300um
+,bumpRegion,(0um,0um),RX180
+,Si,(0um,0um),cube,500um,500um,100um
+,SBT,(0um,0um),cube_ring,1000um,1200um,500um,500um,20um
+,SR,(0um,0um),cube_ring,1000um,1200um,500um,500um,20um
+,UF,(0um,0um),UF_fillet,500um,500um,100um,200um
```

第一条记录声明预网格资产别名；相对 mesh 路径以 `.pack` 文件所在目录为基准解析。后续 `+` 记录严格保序，当前 profile 要求依次为底部 substrate cube、connected-bump mesh、附加 Si cube、两个 `cube_ring`、最后 `UF_fillet`。Z 位置由这个支承顺序和各自高度求解，不在 `loc` 中另填 Z 锚点。connected-bump 必须保留生成时同路径的 `.msh`、`.parameters.json` 和 `.report.json`；Package 会核对 report 中绑定的绝对 artifact path、字节数、SHA-256 和两份 parameters。普通复制、移动或改名这三件文件后，旧 report 不会自动重定位，必须在目标位置重新生成 connected-bump（同一 inode 的受控链接除外）。

当前 profile 的位置和单位约定如下：

- 所有 placement 目前都必须使用 `loc=(0,0)`；它表示以全局 XY 原点对齐的中心放置。非零平移和任意锚点属于后续扩展；
- `RX180` 只用于 connected-bump 预网格：保持 X，翻转 Y/Z，再把翻转后的底面贴到 substrate 顶面。这样 bump 下方结构朝上，并在其背面继续增加 Si；
- 长度支持 `um`、`µm`、`μm` 和 `mm`，解析边界统一转换为 mm；组件表达式只允许参数、数字、括号及 `+ - * /`。旋转向量中的 `90` 是角度值（degree），不加长度单位；
- `cube.component`、`cube_ring.component` 和 `UF_fillet.component` 从 `.pack` 同目录按组件名载入。Phase 1 production builder 把它们作为 canonical validation contract：会实例化并严格校验 polygon、sweep、pivot 和 `+/-` 顺序，但实际网格仍由当前专用的 cube/ring/解析 UF staircase 实现生成；它们暂时不是可自由修改后自动驱动任意几何的通用组件接口，语义变化会 fail closed；
- `.pack` 第二列保留用户写入的 raw component/material token。若它与 connected-bump sidecar 中的 transition component 同名，Package 会解析成对应的实际材料；当前示例因此是 `UF → 302`、`SR → SR1`。Package parameters/report 同时记录 raw token 和 resolved material，求解材料以 `MATERIAL_*` 完备分区及报告中的 resolved material 为准。

当前 [`examples/bumps.loc`](examples/bumps.loc) 在 connected-bump 四个角各定义一个真实的 `50 × 50 µm` 结构化区域；其 XY pitch 是 `0.005 mm = 5 µm`，所以每个角为 `10 × 10` 个平面方格，并沿 connected-bump 的原始 Z surfaces 形成 HEX8。这里不要把“50 µm 控制区”误读成“50 µm 网格尺寸”，也不是 10 µm pitch。Package 会识别这四个 corner ports，并让 die-corner/UF 核心继承其格点和厚度分层。

`sweep` 的 production UF 仍是 `FULL_HEX` staircase：受保护角区保持正交 HEX8，只写入完全落在解析 fillet 包络内的背景格；与包络相交的 `CUT` 格整批跳过，因此它是保守内接阶梯，而不是解析曲面 skin。`hybrid` 只在 bump 顶以下沿用这套 HEX/CUT 判据；上段改用 faceted body-fitted TRI skin、完整 QUAD→PYRAMID5 接口以及 TET4 bulk，并对解析零宽尖端做小尺度 regularization。报告中的 `uf_cut_cells_skipped` 明确只统计 lower staircase，另由 upper-UF region 记录 adapter cap、底面 aspect、PYR/TET 数和最终 top cap。

Phase 2a 的 `hybrid_bulk`/`hybrid_prism` 仍保留为确定性小壳拓扑内核。Package `hybrid` 使用受约束三维 Delaunay：die 锁定 C4 顶面与实际粗化后的 UF 内壁，substrate 锁定 C4/ring 底面；上段 UF 先用一个短 Delaunay hybrid adapter 完成 QUAD→PYRAMID/TET 与第一次 XY/Z 粗化，再以该 adapter 的粗 TRI cap 锁定纯 TET continuation。生成区启用 tetra flips、`OptimizePyramids` 和 `Relocate3D`，并尝试确定性 seeds；最终必须同时通过正 Jacobian、`minSJ/minSICN/minSIGE ≥ 0.03`、无 duplicate/non-manifold、接口逐面相等和体积闭合。connected-bump、corner HEX 和 rings 不做拓扑优化，因为它们本身就是必须保留的网格合同。

原有直径/恒厚命令行仍作为兼容路径保留：

```text
easymesh-demo --diameters "80,70,66,50,40" --thickness 2.7 --xy-size 4.0 --z-size 1.35 --output output/concentric_demo.msh
```

## XY 平面的中心与圆环拓扑

- 不再使用方形核心。
- 全局 XY 尺寸既是环向弦长目标，也是未覆写径向区间的默认目标。
- 规划器把所有唯一投影边（包括三角形边和四边形边）与目标尺寸比较，首先最小化边长的 RMS 对数误差。
- 每个物理圆可使用不同的周向边数；相邻圆环按需用三角形增边，不再要求所有圆都沿用外圈最细的周向划分。
- 投影四边形挤出为 HEX8，增边三角形挤出为 WEDGE6；三角形数量不是硬限制，但不会在不能改善边长时无意义增加。
- 增边单元的手性按圆周位置交替，节点和完整单元拓扑都检查 `0°、45°、90°、135°` 镜像对称。
- 只有在边长目标相差不超过 `0.5%` 的候选半径之间，才使用四边形投影面积 CV 作为第二级目标。

半径为 `r`、每 45° 有 `k` 条边时，周向弦长为：

```text
c(r, k) = 2 r sin(π / 8k)
```

规划器先按全局 XY 目标弦长确定各圈的 `k`，并按每个径向区间的有效 R 尺寸确定径向层数。局部 R 覆写不会被误用为环向弦长目标；没有覆写的区间保持全局 XY 尺寸对应的原有划分。程序不会跨过或删除任何 Layer 派生的物理圆。

页面提供两种平面对称约束：

- 默认模式使用 8 个 45° 镜像扇区，强制 `0°、45°、90°、135°` 四条镜像轴；
- “仅保留 X/Y 轴对称”使用 4 个 90° 镜像扇区，只强制 `0°、90°`，允许单元连接不再关于两条对角轴镜像。

取消 45° 约束提供了更多周向计数候选，但不保证质量一定提高。默认 `bumpcell.layer` 仍包含 PSV2 侧壁产生的 `r=30–31 µm` 窄区间，因此较低的 `minSICN` 可能来自真实高长宽比，不能单独解释成形状扭曲。应结合本次报告中的 `minSJ`、`minSIGE` 和 Jacobian 判断，并以 GUI 或报告给出的实际数值比较两种对称模式。

兼容的旧命令行默认参数实测结果：

- `1,059` 个节点；
- `576` 个 HEX8；
- `128` 个 WEDGE6；
- 唯一投影边长 `2.000–5.423 µm`，平均 `4.061 µm`，CV 约 `17.1%`；
- `78.6%` 的投影边位于目标 `4 µm` 的 `±25%` 范围内；
- 四边形投影面积 `8.294–19.683 µm²`，全局 CV 约 `23.7%`（面积是二级目标）；
- `minSICN > 0.52`，`minSIGE > 0.74`，Jacobian 全部为正；
- 无重复节点，四条要求的镜像轴均通过。

## Layer 截面与厚度方向

页面默认载入 `examples/bumpcell.layer`。所有记录都必须恰好包含八个字段；air gap 也使用同样的八字段格式，但将 `component` 和 `material` 两列同时留空：

```text
+,component,material,height,outer_diameter,inner_diameter,water,top
+,component,material,height,outer_diameter,inner_diameter,water,bottom
+,component,material,thickness,outer_diameter,inner_diameter,tape,sidewall_thickness
+,,,height,outer_diameter,inner_diameter,water,top|bottom
```

- `component` 是组件名，`material` 是材料名；不同组件可以使用同一种材料。轴对称模板网格同时生成互斥的 `COMPONENT_*` 组件体组，以及直接采用 Layer `material` 原名、可聚合多个组件的材料体组。
- `water,top`：目标水位等于指定圆环覆盖区内的当前最高表面加上 `height`；`water,bottom` 则使用当前最低表面。`height` 可以为正、负或零。
- `water` 只填充各径向柱从当前表面到目标水位之间的空体积，不会覆盖已有材料；局部表面已经达到或高于目标水位时，该柱保持不变。`top`/`bottom` 必须显式填写。
- `tape`：正厚度材料沿已有水平表面等厚添加；遇到已有台阶时，按最后一列给出的正水平宽度包覆台阶低侧，并让包边顶面与高侧新增 `tape` 顶面齐平。包边处的竖向厚度不受名义厚度约束。
- `+,,,height,...,water,top|bottom` 的记录将 `component` 和 `material` 同时留空，用于保留一段 air gap。旧的 `+,,height,...` 七字段形式不兼容，会被拒绝。
- air gap 按与 `water` 相同的 `top`/`bottom` 目标水位计算，但保留的体积不生成 component/material 体组或体单元。它是持久 keepout：后续 `water` 和 `tape` 只能从 keepout 顶面继续，不会回填其内部。
- air gap 实际占据模板最外缘径向柱时，`.loc` 布局在对应高度区间也不生成周边 transition 网格。仅仅是指令的直径接触外缘、但目标水位没有实际产生 keepout 时，不会误删 transition 网格。
- `.loc` 若要恢复 terminal 或底部 air gap，必须保留同名的 `.msh`、`.parameters.json` 与 `.report.json` 三件产物包；读取时会核对 parameters/report 完全一致，并用 MSH 的路径、字节数和 SHA-256 绑定实际网格。只要任一旁车仍声明 air gap，缺失或错配就会明确拒绝；若两份旁车都丢失，单靠不含该空腔体单元的 MSH 无法恢复 terminal gap，因此不要拆散这三件产物。
- 只包含 air gap、没有任何实体材料的 Layer 文件不能生成单模板网格。
- 预览显示 `x ∈ [-R, R]` 的完整直径截面；它绕中心轴扫掠 `180°` 后覆盖完整轴对称三维结构。

Z 方向不会再把整个模型当作一个恒厚体。程序保留 Layer 产生的每个真实高度边界，对每个相邻 Z 区间分别按其有效尺寸均匀细分，因此材料界面不会被厚度划分跨过。只为截面中实际存在的材料体积生成单元，空区不生成实体或单元。

### 局部目标尺寸定义

控制项表示相邻几何边界之间的区间，而不是单个边界点。默认示例的径向区间为 `R01: r=0–15 µm` 到 `R07: r=40–45 µm`，竖直区间为 `Z01: z=0–7 µm` 到 `Z11: z=105.7–125.7 µm`。预览保留全部边界投影刻度，并用括号和位于区间中部的编号表示控制范围：

- 竖直方向的 `Z` 尺寸表位于截面图左侧；
- 径向的 `R` 尺寸表位于截面图下方；`R` 只覆盖半径方向的尺寸，暂不支持环向局部尺寸；
- 局部尺寸留空时继承全局 XY 或 Z 目标尺寸，填写正数后覆盖该区间的全局值并高亮整个投影括号；
- Layer 改动时，起止边界仍完全相同的区间会保留覆写，已经消失或被拆分的区间会被移除。

R、Z 局部覆写都会随参数传给 Gmsh worker。R 覆写仅改变对应区间的径向层数，环向始终使用全局 XY 尺寸；Z 覆写仅改变对应真实高度区间的厚度层数。未覆写区间继续继承各自的全局尺寸。

## 组件/材料 Physical Volumes 与默认结果

默认 `bumpcell.layer` 生成 11 个组件实体，并分别写入：

```text
COMPONENT_SI       COMPONENT_ILD       COMPONENT_AL
COMPONENT_PSV2     COMPONENT_PI        COMPONENT_CUPILLAR
COMPONENT_SN       COMPONENT_UF        COMPONENT_SR
COMPONENT_CUPAD    COMPONENT_SBT
```

同材料组件再聚合为 9 个材料 Physical Groups：

```text
Si
USG
Al
PI
Cu
Sn
302
SR1
SBT
```

材料 Physical Group 使用解析后的 Layer `material` 原名：保留大小写、内部空格、连字符、Unicode 和纯数字；多个 component 使用完全相同的材料名时会聚合到同一个组。为保证 ASCII MSH 4.1 写出后能无损重开，材料名必须由可打印字符组成，不能包含双引号或首尾空白。`ALL_SOLID_VOLUMES` 以及 `COMPONENT_`、`TEMPLATE_`、`TRANSITION_`、`HM_`、`BUMP_`、`MATERIAL_`、`REGION_` 前缀（不区分大小写）属于保留命名空间，不能作为 Layer 材料名。

另外包含汇总体组 `ALL_SOLID_VOLUMES`。单模板、布局 MSH 与 CDB 导出都以这些原名材料组作为互斥完备材料分区；兼容的旧直径/恒厚命令行仍使用 `REGION_*` 径向体组。

多 Bump 布局输出还会直接写出与 CDB 相同的两层 component 分类：`TEMPLATE_<模板别名>_<component>` 表示可重叠查询的 Set，`HM_<component>_TEMPLATE` / `HM_<component>_TRANSITION` 表示每个 element 唯一归属的来源 Component 分区。材料组同时聚合模板与过渡单元；只另设总过渡组 `TRANSITION_SOLID_VOLUMES`，不生成逐材料的 `TRANSITION_<材料>` 子组。布局 MSH 不再包含按实例编号的 `BUMP_####_*` Physical Groups。

## ANSYS CDB 导出

GUI 的第三个 `MSH → CDB` 页可直接选择输入/输出文件，切换
`SOLID185`/`SOLID186`、坐标比例和 `/UNITS` 标签。转换在独立后台
worker 中执行；完成后页面会显示节点提升、HEX/WEDGE/TET/PYRAMID、HyperMesh
Component、共享 MAT、重叠 CMBLOCK 统计，复核本次 CDB 的文件大小，
并显示 worker 生成的 SHA-256 摘要。

安装项目后可把当前 EasyMesh MSH 4.1 体网格转换为 blocked CDB。默认写线性 `SOLID185`：

```text
easymesh-msh-to-cdb output/concentric_coarse.msh --output output/concentric_coarse.cdb --element-type 185
```

切换为二次 `SOLID186`：

```text
easymesh-msh-to-cdb output/concentric_coarse.msh --output output/concentric_coarse_186.cdb --element-type 186
```

也可从 Python 调用：

```python
from easymesh.cdb_exporter import CdbExportOptions, export_msh_to_cdb

summary = export_msh_to_cdb(
    "output/concentric_coarse.msh",
    "output/concentric_coarse.cdb",
    options=CdbExportOptions(element_type=186),
)
```

当前转换 profile 与 EasyMesh 输出契约一致：只接受 ASCII Gmsh MSH 4.1、一阶 HEX8/WEDGE6/TET4/PYRAMID5 和纯三维体单元，原始坐标单位为 mm。`--coordinate-scale` 可显式缩放坐标；`/UNITS,MPA` 只是 ANSYS 单位系统标记，本身不会换算数值。

- `SOLID185` 保留源 node/EID；WEDGE6、TET4、PYRAMID5 分别按受测的 8 槽退化 connectivity 写出；
- `SOLID186` 只接受 HEX8/WEDGE6：保留源角点和 EID，从 `max(source node ID)+1` 开始生成边中节点，并按全局无向边复用，所以相邻单元保持二次共形；WEDGE6 按 ANSYS 20 槽退化 prism 写出。含 TET4/PYRAMID5 的混合网格会明确要求改用 `SOLID185`；
- 布局 MSH 与 CDB 使用同一套分类。Set 直接按 `.loc` 模板别名 × component 写成 `TEMPLATE_<别名>_<component>`，例如 `TEMPLATE_FINE_UF`、`TEMPLATE_MEDIUM_PSV2`；相同模板和 component 的所有 bump 实例合并。布局中的原名材料组、`TRANSITION_SOLID_VOLUMES` 和 `ALL_SOLID_VOLUMES` 作为独立 Sets；同一 EID 可以出现在多个 Set 中，EBLOCK 中仍只定义一次 element；
- 对普通 Layer/布局 MSH，`Si`、`USG`、`302` 等原名材料组构成互斥完备主分区。Package MSH 则以 `MATERIAL_<规范化材料名>` 构成覆盖完整封装的互斥主分区，并映射为每个 element 唯一的 `MAT` 号；从 connected-bump 保留下来的原名材料组只是在 imported selection 上的兼容查询 Set，不覆盖附加 Si、substrate、rings 或 UF fillet，不能当作 Package 的完整材料分区。其他 `PART_*`、`ZONE_*` 和模板选择组也只是可重叠 Sets；
- MSH 同时直接写出 HyperMesh 的单归属 Component 分区：模板区为 `HM_<component>_TEMPLATE`，过渡区为 `HM_<component>_TRANSITION`；模板别名的细分只放在上述 Sets 中。CDB exporter 会复核这套互斥完备分区并生成同名 Component。只有非空 Component 组合会写出，生成的 Set/Component 名限制为 legacy HyperMesh 兼容的 32 个字符；旧版 `BUMP_####_*` 布局 MSH 不再兼容，需要用当前 EasyMesh 重新生成；
- 本地 `TYPE=1` 表示模板、`TYPE=2` 表示过渡，两者都映射到当前选择的 `SOLID185` 或 `SOLID186`。同材料的不同 component 共享同一个 `MAT_<材料>`，`REAL=0`、`SECNUM=0`，因此不会制造虚假的实常数或截面；
- 输出按来源与 component 的互斥组合分别写 `!!HMNAME COMP`、`EBLOCK` 和 `CM`，与 HyperMesh 导出的旧式 ANSYS 组织兼容；所有 EID 在这些 EBLOCK 中仍恰好定义一次；
- 不生成 HyperMesh Part；当前只写 MAT 编号，不写 `MP`/`MPDATA` 材料本构。输出旁同时生成 `<name>.cdb.report.json`，记录节点提升、Set 映射、重叠数量、坐标比例，并分别用 path、字节数和 SHA-256 绑定输入 MSH 与输出 CDB；转换期间 source MSH 也持有与生成器相同的 artifact lock，并复核读取前后指纹不变。

ANSYS/APDL Component 与 HyperMesh/HyperView 的 Component collector 不是同一概念：CDB 的 CMBLOCK 允许重叠；HyperMesh/HyperView 的可视 Component 要求 element 唯一归属。导出器因此按“来源 × component”生成互斥 Component，同时让多个 component 复用同一原名材料对应的 MAT，并保留可重叠 Element Sets；不会复制 element 来伪造多归属。

默认 Layer 的几何高度为 `125.7 µm`，包含 `7` 个径向控制区间、`11` 个物理 Z 区间和 `9` 种材料。最终节点数、HEX8/WEDGE6 数量、细分后的 Z 层数及质量指标由当前 XY/Z 尺寸和局部覆写决定，以 GUI 和 `.report.json` 的本次结果为准。生成结果不包含独立二维实体或二维单元。

Gmsh 中可见的外表面只是 HEX8/WEDGE6 体单元的边界面，不是 TRI3/QUAD4 单元。

## 保存与恢复工程

Layer 路径右侧的“保存 Layer”按钮会把编辑器文本原子写回当前 `.layer` 文件。编辑后按钮启用且编辑框标题显示“未保存”，成功写入后恢复为“已保存”；重新载入或切换文件前会提示处理尚未保存的 Layer。若磁盘文件在载入后被其他程序修改，EasyMesh 会在覆盖前警告。

GUI 的“工程”菜单可以打开、保存或另存当前工程（`*.easymesh.json`）。工程文件保存三个页面的全部可编辑输入：Layer 原文与 R/Z 局部尺寸、布局路径与外部材料映射，以及 CDB 输入输出和转换选项；报告内容、模板缓存和后台任务等运行态不会写入。编辑中的无效文本也会原样保存，重新打开后仍由页面上的正常校验给出提示。

读取旧工程时，布局材料映射中的历史前缀写法会迁移到当前原名，并按大小写不敏感方式重新绑定到模板材料；新工程只保存 `USG`、`302`、`UF` 这类无前缀名称。

每次从 GUI 生成 MSH 或导出 CDB 时，产物与本次任务报告通过复核后，还会在输出旁原子写入该次启动设置的工程快照。快照保留完整产物名以避免碰撞，例如 `foo.msh.easymesh.json` 和 `foo.cdb.easymesh.json`，都可以从“工程 → 打开工程…”恢复。自动快照不会改变当前手动工程的保存路径，也不会把导出误当成用户已经保存了后续页面修改。

## 输出与验证

每次生成会产生：

- `.msh`：ASCII Gmsh MSH 4.1，坐标单位 mm；当前 Layer、布局和 Phase 1 Package production 输出使用三维 HEX8/WEDGE6，混合网格 IR 与 CDB 链路另支持 TET4/PYRAMID5；
- `.parameters.json`：可重放的网格参数；Layer 输出包含原始文本、全局 XY/Z 尺寸和 R/Z 区间覆写，布局输出包含 bounds、模板、实例、过渡尺寸，以及模板/外部的 component 与 material stacks；Package 输出另外记录 far-field/transition 控制、pack/component 内容 SHA-256、source mesh SHA-256，以及 raw component token 到 resolved material 的映射。`job_id` 这类任务元数据只写 report 顶层，不属于重放契约；
- `.report.json`：参数快照，以及节点/单元数、材料单元数、Physical Volumes、Z 层级、有效径向尺寸、质量和镜像检查；布局报告还记录最终 `.msh` 的字节数和 SHA-256；
- `<完整输出名>.easymesh.json`：GUI 三页设置快照，例如 `foo.msh.easymesh.json` 或 `foo.cdb.easymesh.json`，可直接重新打开恢复对应设置；
- `.log`：由 GUI 启动时的 worker 日志。

Layer、旧参数模式和 Bump 布局生成器共用规范化的小写 `.msh` 路径及同一套跨进程 artifact-bundle 锁，避免不同入口同时发布同名 MSH、parameters 和 report。

重复节点、缺失材料边界和数值上不可分辨的半径/高度会直接终止生成。任一 signed 质量指标 `<= 0` 表示单元退化或倒置，也作为错误终止，而不是普通警告。原型还限制区域数、二维交互规模、厚度层数和预计三维单元数，避免误输入极小尺寸后卡住 GUI 或耗尽内存。

### 质量提示的解释

程序按下面的优先级解释 Gmsh 质量指标：

- `minSJ <= 0`、`minSIGE <= 0`、`minSICN <= 0` 或非正 Jacobian：单元退化或倒置，生成失败，必须处理；
- `minSJ < 0.30` 或 `minSIGE < 0.30`：报告“明显形状扭曲”警告，建议检查夹角、剪切、压扁和突变的尺寸过渡；
- `minSJ`、`minSIGE >= 0.30`，但 `minSICN < 0.30`：仅报告“高长宽比”提示。`SICN` 同时也受剪切和扭曲影响，并不是纯长宽比指标；不过在另外两个形状指标良好时，低 `SICN` 更可能由各向异性主导，不应直接判为不合格网格。这是一条工程诊断规则，不是 `SICN` 的纯长宽比定义。

例如一个完全正交、没有角度扭曲的单元，其局部 Jacobian 为

```text
J = diag(hx, hy, hz)
```

此时 `SJ=1`，与三个方向的尺寸比例无关；而 `SICN` 会随长宽比增大而降低：

```text
SICN = 3 / (sqrt(hx² + hy² + hz²) * sqrt(hx⁻² + hy⁻² + hz⁻²))
```

因此 `10×1×1` 的理想正交单元可以同时具有 `SJ=1` 和较低的 `SICN`。在薄膜问题中，如果短边沿厚度或另一关键场梯度方向、该方向已经充分细分、长边方向的解变化缓慢且单元保持正交，这种各向异性网格可能是合理而高效的。它仍可能漏掉长边方向的快速变化，并使方程组条件数变差。

出现仅 `SICN` 较低的提示时，建议沿物理场变化快的关键方向细化，而不是机械地把三个方向都改成相同尺寸；最终应将相关方向的尺寸减半，比较目标结果的变化，完成网格收敛验证。质量提示和对称模式对比都是辅助判断，不能替代收敛性分析。

## 为什么保留独立 PySide6 页面

当前交互方式适合原型，也适合作为后续程序的骨架：PySide6 页面只负责编辑、校验、截面与转换报告展示，独立 worker 负责 `config → mesh → report` 或 `MSH → CDB → report`，Gmsh 作为成熟的网格检查器。这样不会把 Qt 与 Gmsh FLTK 两套事件循环混在一起，也便于以后增加按 XY 区域细分的外部材料和 bump position 编辑；同一 CDB 转换能力同时由 GUI、CLI 和 Python API 复用。

## Qt Designer GUI 工作流

主窗口的布局、标签和基础控件以 `ui/main_window.ui` 为设计源；`src/easymesh/ui_main_window.py` 是使用 PySide6 `pyside6-uic` 生成并提交到 Git 的 Python binding，不应手工编辑。自定义截面绘制控件保留在 `src/easymesh/section_preview.py`，并在 Designer 文件中作为 promoted widget 引用。

目前并非所有弹窗都来自 `.ui`：Template / Instance 弹窗在 `package_v2_template_dialogs.py` 中构建，公开参数和基本图形字段随模板动态生成；Variable、Frozen 等编辑弹窗位于 `gui.py`。所有表单显式使用 `AllNonFixedFieldsGrow`，输入框随可用宽度伸展，避免 macOS 样式默认把字段限制在较短宽度。

修改主窗口 GUI 时：

1. 在 Qt Designer 中只编辑 `ui/main_window.ui`；
2. 在已安装项目依赖的虚拟环境中运行 `python scripts/generate_ui.py`；
3. 使用 `python scripts/generate_ui.py --check` 确认提交的 Python binding 与 `.ui` 完全一致；
4. 同时提交 `.ui` 和重新生成的 `ui_main_window.py`。

`scripts/generate_ui.py` 会在当前 Python 旁边查找 `pyside6-uic`（Windows 为 `pyside6-uic.exe`），因此命令本身不包含 macOS/Linux 专用的 `.venv/bin` 路径。CI 会在 Windows、macOS 和 Ubuntu 上执行同一个 `--check`。

## 测试

```text
python scripts/generate_ui.py --check
python -m unittest discover -s tests -v
```
