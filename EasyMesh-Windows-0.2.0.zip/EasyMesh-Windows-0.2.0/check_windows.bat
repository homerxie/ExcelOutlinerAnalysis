@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
if not exist ".venv\Scripts\python.exe" (
    echo Run install_windows.bat first.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" -m pip check
if errorlevel 1 goto failed
".venv\Scripts\python.exe" scripts\check_windows_runtime.py
if errorlevel 1 goto failed
echo.
echo Environment checks passed. See README_WINDOWS.md for the native 3D benchmark.
pause
exit /b 0
:failed
echo Environment check failed. Keep the error above for troubleshooting.
pause
exit /b 1
