@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
if exist ".venv\Scripts\python.exe" goto install
py -3.10 -c "import sys" >nul 2>&1
if not errorlevel 1 goto python310
py -3.12 -c "import sys" >nul 2>&1
if not errorlevel 1 goto python312
python -c "import sys; assert sys.version_info >= (3, 10)" >nul 2>&1
if errorlevel 1 goto missing_python
python -m venv .venv
goto venv_ready
:python310
py -3.10 -m venv .venv
goto venv_ready
:python312
py -3.12 -m venv .venv
:venv_ready
if errorlevel 1 goto failed
if not exist ".venv\Scripts\python.exe" goto failed
:install
".venv\Scripts\python.exe" -c "import sys, struct; assert sys.version_info >= (3, 10), 'Python 3.10+ required'; assert struct.calcsize('P') == 8, '64-bit Python required'"
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install --only-binary=:all: -r requirements.txt
if errorlevel 1 goto failed
set "APP_WHEEL="
for %%W in ("wheels\easymesh_gmsh_demo-*.whl") do set "APP_WHEEL=%%~fW"
if not exist "%APP_WHEEL%" goto failed
".venv\Scripts\python.exe" -m pip install --no-deps --force-reinstall "%APP_WHEEL%"
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip check
if errorlevel 1 goto failed
echo.
echo Installation complete. Double-click run_windows.bat to start EasyMesh.
echo Optional: run check_windows.bat to verify dependencies and native meshing.
pause
exit /b 0
:missing_python
echo Install 64-bit Python 3.10 or 3.12, including the Python launcher or PATH option.
echo Then run this installer again. See README_WINDOWS.md.
pause
exit /b 1
:failed
echo.
echo Installation failed. See the error above and README_WINDOWS.md.
pause
exit /b 1
