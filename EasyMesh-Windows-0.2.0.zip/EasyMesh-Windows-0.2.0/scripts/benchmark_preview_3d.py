"""Measure the real embedded preview on a native desktop (Windows or macOS).

Run after installing EasyMesh: python scripts/benchmark_preview_3d.py
Qt's completed-frame FPS is sampled during continuous camera motion. Do not
use QT_QPA_PLATFORM=offscreen or compare VM software rendering with GPU results.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import platform
import statistics
import sys
import time

from PySide6.QtCore import QObject, QTimer, Qt, qVersion
from PySide6.QtQml import QQmlProperty
from PySide6.QtWidgets import QApplication

from easymesh.package_v2_compile import compile_package_v2
from easymesh.package_v2_preview_3d import PackageV2Preview3D


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path(__file__).resolve().parents[1]
                        / "tests/fixtures/package_v2_high_uf_gui.source.json")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--expect-backend", help="e.g. Direct3D11 or Metal")
    parser.add_argument("--min-fps", type=float, default=0,
                        help="optional minimum median FPS for EACH display mode")
    args = parser.parse_args()
    if not math.isfinite(args.min_fps) or args.min_fps < 0:
        parser.error("--min-fps must be finite and nonnegative")
    source = args.source.resolve()
    compiled = compile_package_v2(source.read_bytes(), source_root=source.parent,
                                  source_name=source.name)
    app = QApplication([])
    preview = PackageV2Preview3D()
    preview.resize(1280, 800)
    start = time.perf_counter()
    preview.set_compiled_geometry(compiled)
    scene_build_ms = (time.perf_counter() - start) * 1000
    preview.show()
    app.processEvents()
    canvas = preview.canvas
    backend = preview.render_backend
    if (not preview.render_status.startswith("ready:")
            or (args.expect_backend and backend != args.expect_backend)):
        print(f"Native renderer required: {preview.render_status}; expected {args.expect_backend}",
              file=sys.stderr)
        preview.close()
        return 1
    view = canvas.rootObject().findChild(QObject, "sceneView")
    stats = QQmlProperty.read(view, "renderStats")
    report = {
        "platform": platform.platform(), "python": platform.python_version(),
        "qt": qVersion(), "backend": backend, "source": str(source),
        "viewport_logical_pixels": [canvas.width(), canvas.height()],
        "device_pixel_ratio": canvas.devicePixelRatioF(),
        "components": len(preview.scene.components),
        "triangles": sum(len(c.triangles) for c in preview.scene.components),
        "scene_build_ms": round(scene_build_ms, 3), "modes": {},
    }
    phase = 0
    phase_start = time.perf_counter()
    samples: list[dict] = []
    # Warm up shader/pipeline caches and FPS counters for 2.5 seconds per mode.
    next_sample = phase_start + 3.5

    def tick() -> None:
        nonlocal phase, phase_start, next_sample, samples
        now = time.perf_counter()
        elapsed = now - phase_start
        # Match the production camera update path without cursor automation or
        # framebuffer readback (which would stall the GPU and skew the result).
        canvas._yaw_deg = -38 + elapsed * 35
        canvas._pitch_deg = -24 + 15 * math.sin(elapsed)
        canvas._zoom = 1.0 + 0.2 * math.sin(elapsed * 0.7)
        canvas._pan_x = canvas._scene_radius * 0.1 * math.sin(elapsed * 0.5)
        canvas._apply_camera_properties()
        if now < next_sample:
            return
        samples.append({"fps": stats.property("fps"),
                        "max_frame_ms": stats.property("maxFrameTime")})
        next_sample = now + 1.05
        if len(samples) < 5:
            return
        name = "opaque" if phase == 0 else "translucent"
        report["modes"][name] = {
            "samples": samples,
            "median_fps": statistics.median(sample["fps"] for sample in samples),
            "lowest_sample_fps": min(sample["fps"] for sample in samples),
        }
        if phase == 0:
            phase = 1
            preview.set_translucent(True)
            phase_start = time.perf_counter()
            next_sample = phase_start + 3.5
            samples = []
        else:
            timer.stop()
            app.quit()

    timer = QTimer()
    timer.setTimerType(Qt.TimerType.PreciseTimer)
    timer.timeout.connect(tick)
    timer.start(16)
    # A user closing the window leaves an incomplete report and a failed exit.
    app.exec()
    preview.close()
    report["passed"] = len(report["modes"]) == 2 and all(
        mode["lowest_sample_fps"] > 0 and mode["median_fps"] >= args.min_fps
        for mode in report["modes"].values()
    )
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
