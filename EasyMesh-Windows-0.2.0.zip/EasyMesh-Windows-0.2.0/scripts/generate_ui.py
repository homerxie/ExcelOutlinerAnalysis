"""Generate the committed PySide6 binding from Qt Designer sources."""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
UI_SOURCE = Path("ui/main_window.ui")
GENERATED_MODULE = Path("src/easymesh/ui_main_window.py")


def _uic_executable() -> Path:
    executable_name = "pyside6-uic.exe" if os.name == "nt" else "pyside6-uic"
    adjacent = Path(sys.executable).with_name(executable_name)
    if adjacent.is_file():
        return adjacent
    discovered = shutil.which("pyside6-uic")
    if discovered:
        return Path(discovered)
    raise RuntimeError(
        "pyside6-uic was not found next to the active Python or on PATH; "
        "install the project's PySide6 dependency first"
    )


def _generate(output: Path) -> None:
    subprocess.run(
        [
            str(_uic_executable()),
            str(UI_SOURCE),
            "-o",
            str(output),
        ],
        cwd=PROJECT_ROOT,
        check=True,
    )
    # Keep the committed binding byte-for-byte stable when generated on
    # Windows (CRLF) or macOS/Linux (LF).
    generated = output.read_text(encoding="utf-8").rstrip() + "\n"
    with output.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write(generated)


def _portable_source_text(path: Path) -> str:
    """Read generated source with universal newline normalization."""

    with path.open("r", encoding="utf-8", newline=None) as stream:
        return stream.read()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Generate src/easymesh/ui_main_window.py from ui/main_window.ui"
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="fail when the committed generated module is not up to date",
    )
    args = parser.parse_args(argv)

    target = PROJECT_ROOT / GENERATED_MODULE
    if not args.check:
        _generate(target)
        print(f"generated {GENERATED_MODULE} from {UI_SOURCE}")
        return 0

    with tempfile.TemporaryDirectory() as directory:
        candidate = Path(directory) / GENERATED_MODULE.name
        _generate(candidate)
        if not target.is_file() or _portable_source_text(
            candidate
        ) != _portable_source_text(target):
            print(
                "generated UI module is stale; run: "
                f"{sys.executable} scripts/generate_ui.py",
                file=sys.stderr,
            )
            return 1
    print("generated UI module is up to date")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
