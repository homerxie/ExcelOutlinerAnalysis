"""Create a locally bound immutable Job for the Package V2 demo Source."""

from __future__ import annotations

import argparse
from pathlib import Path

from easymesh.package_v2_authoring import materialize_package_v2_job


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE = PROJECT_ROOT / "examples/package_v2/generated_box.source.json"
DEFAULT_JOB = PROJECT_ROOT / "output/package_v2_generated_box.job.json"
DEFAULT_OUTPUT = PROJECT_ROOT / "output/package_v2_generated_box.msh"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Create an immutable Job for a Package V2 demo Source"
    )
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--job", type=Path, default=DEFAULT_JOB)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--job-id", default="package-v2-generated-box-demo")
    args = parser.parse_args(argv)

    source_path = args.source.expanduser().resolve()
    job_path = args.job.expanduser().resolve()
    output_path = args.output.expanduser().resolve()
    request = materialize_package_v2_job(
        source_path,
        job_path,
        output_path,
        job_id=args.job_id,
    )

    print(f"wrote immutable Package V2 Job: {job_path}")
    print(f"bound mesh output: {request.output_mesh_path}")
    print(f"run: easymesh-demo --package-v2-job {job_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
