"""Portable dependency, worker and Gmsh smoke check for the Windows share ZIP."""
from __future__ import annotations

from pathlib import Path
import platform
import struct
import subprocess
import sys
import tempfile

import gmsh
import numpy
from PySide6.QtCore import qVersion
from PySide6.QtQuick3D import QQuick3DGeometry

from easymesh.app_runtime import worker_command_prefix, worker_environment
from easymesh.package_v2_compile import compile_package_v2


def main() -> None:
    assert sys.version_info >= (3, 10), "Python 3.10+ required"
    assert struct.calcsize("P") == 8, "64-bit Python required"
    print(f"Python {platform.python_version()} ({platform.machine()})")
    print(f"Gmsh {gmsh.__version__}; NumPy {numpy.__version__}; Qt {qVersion()}")
    print(f"Qt Quick 3D: {QQuick3DGeometry.__name__}")
    root = Path(__file__).resolve().parents[1]
    sources = [*sorted((root / "examples/package_v2").glob("*.source.json")),
               root / "examples/local_template_lid.source.json"]
    for source in sources:
        compile_package_v2(source.read_bytes(), source_root=source.parent, source_name=source.name)
        print(f"Source compiled: {source.name}")
    completed = subprocess.run(
        [*worker_command_prefix(), "--help"], env=worker_environment(),
        capture_output=True, text=True, encoding="utf-8", timeout=30, check=True,
    )
    assert "--package-v2-job" in completed.stdout, completed.stdout
    with tempfile.TemporaryDirectory(prefix="EasyMesh 中文 ") as directory:
        mesh = Path(directory) / "检查 mesh.msh"
        gmsh.initialize()
        try:
            gmsh.option.setNumber("General.Terminal", 0)
            gmsh.model.add("smoke")
            gmsh.model.occ.addBox(0, 0, 0, 1, 1, 1)
            gmsh.model.occ.synchronize()
            gmsh.option.setNumber("Mesh.MeshSizeMin", 0.5)
            gmsh.option.setNumber("Mesh.MeshSizeMax", 0.5)
            gmsh.model.mesh.generate(3)
            gmsh.write(str(mesh))
            assert mesh.stat().st_size > 0
            gmsh.clear()
            gmsh.open(str(mesh))
            element_count = sum(len(tags) for tags in gmsh.model.mesh.getElements(3)[1])
            assert element_count > 0, "No volume elements after reopening MSH"
            print(f"Native meshing and Unicode path round-trip: {element_count} volume elements")
        finally:
            gmsh.finalize()
    print("PASS: dependencies, source compilation, worker and native meshing")


if __name__ == "__main__":
    main()
