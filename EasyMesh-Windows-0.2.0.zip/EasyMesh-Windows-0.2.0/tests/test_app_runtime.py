from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from easymesh.app_runtime import (
    prepare_runtime_workspace,
    runtime_workspace_root,
    source_project_root,
    worker_command_prefix,
    worker_environment,
    worker_popen_options,
)


ROOT = Path(__file__).resolve().parents[1]


class AppRuntimeTests(unittest.TestCase):
    def test_bundled_layer_example_matches_source_and_documents_air_gap(self) -> None:
        example = (ROOT / "examples" / "bumpcell.layer").read_text(encoding="utf-8")
        bundled = (
            ROOT / "src" / "easymesh" / "resources" / "bumpcell.layer"
        ).read_text(encoding="utf-8")

        self.assertEqual(bundled, example)
        self.assertIn(
            "# +,,,height,outer_diameter,inner_diameter,water,top|bottom",
            example,
        )
        self.assertIn("Legacy seven-field records, including +,,height,...", example)
        self.assertIn("persistent keepout", example)
        self.assertIn("no surrounding .loc transition mesh", example)

    def test_source_checkout_is_detected_without_using_the_working_directory(self) -> None:
        with patch("pathlib.Path.cwd", return_value=Path("/unrelated")):
            self.assertEqual(source_project_root(), ROOT)

    def test_workspace_honors_explicit_override_before_source_checkout(self) -> None:
        configured = runtime_workspace_root(
            documents_location="/ignored",
            environment={"EASYMESH_HOME": "~/portable-easymesh"},
        )
        self.assertEqual(configured, (Path.home() / "portable-easymesh").resolve())

    def test_relative_workspace_override_is_stable_from_the_user_home(self) -> None:
        configured = runtime_workspace_root(
            documents_location="/ignored",
            environment={"EASYMESH_HOME": "portable/easymesh"},
        )
        self.assertEqual(
            configured,
            (Path.home() / "portable" / "easymesh").resolve(),
        )

    def test_installed_workspace_uses_the_platform_documents_location(self) -> None:
        documents = Path.cwd() / "platform-documents"
        with patch("easymesh.app_runtime.source_project_root", return_value=None):
            workspace = runtime_workspace_root(
                documents_location=documents,
                environment={},
            )
        self.assertEqual(workspace, (documents / "EasyMesh").resolve())

    def test_installed_workspace_seeds_editable_layer_without_overwriting_it(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            workspace = prepare_runtime_workspace(Path(directory) / "EasyMesh")
            layer = workspace / "examples" / "bumpcell.layer"
            self.assertTrue((workspace / "output").is_dir())
            self.assertIn("+,Al,Al,2.8um", layer.read_text(encoding="utf-8"))

            layer.write_text(
                "+,Custom,Custom,1um,10um,0um,water,top\n",
                encoding="utf-8",
            )
            prepare_runtime_workspace(workspace)
            self.assertEqual(
                layer.read_text(encoding="utf-8"),
                "+,Custom,Custom,1um,10um,0um,water,top\n",
            )

    def test_installed_and_frozen_worker_commands_use_the_active_executable(self) -> None:
        with patch.object(sys, "frozen", False, create=True):
            self.assertEqual(
                worker_command_prefix(),
                [sys.executable, "-m", "easymesh", "--worker"],
            )
        with patch.object(sys, "frozen", True, create=True):
            self.assertEqual(
                worker_command_prefix(),
                [sys.executable, "--worker"],
            )

    def test_worker_environment_is_utf8_and_preserves_existing_pythonpath(self) -> None:
        existing = os.pathsep.join(("/one", "/two"))
        environment = worker_environment({"PYTHONPATH": existing, "KEEP": "yes"})

        self.assertEqual(environment["PYTHONUTF8"], "1")
        self.assertEqual(environment["PYTHONIOENCODING"], "utf-8")
        self.assertEqual(environment["KEEP"], "yes")
        self.assertEqual(
            environment["PYTHONPATH"].split(os.pathsep),
            [str(ROOT / "src"), "/one", "/two"],
        )

    def test_pythonw_worker_uses_sibling_console_interpreter(self) -> None:
        with tempfile.TemporaryDirectory(prefix="EasyMesh 空格 ") as directory:
            executable = Path(directory) / "python.exe"
            executable.touch()
            with patch.object(sys, "platform", "win32"), patch.object(
                sys, "executable", str(executable.with_name("pythonw.exe"))
            ), patch.object(sys, "frozen", False, create=True):
                self.assertEqual(worker_command_prefix(), [
                    str(executable), "-m", "easymesh", "--worker",
                ])
                executable.unlink()
                with self.assertRaisesRegex(RuntimeError, "python.exe"):
                    worker_command_prefix()

    @unittest.skipUnless(sys.platform == "win32", "requires Windows pythonw")
    def test_pythonw_launch_roundtrips_contact_service_over_utf8_pipes(self) -> None:
        import json

        pythonw = Path(sys.executable).with_name("pythonw.exe")
        self.assertTrue(pythonw.is_file())
        with tempfile.TemporaryDirectory(prefix="EasyMesh 空格 ") as directory:
            # pythonw itself writes its evidence to disk because its stdout
            # is not a reliable transport, even when invoked with pipes.
            report = Path(directory) / "result.json"
            code = '''
import json, subprocess, sys
from pathlib import Path
from easymesh.app_runtime import worker_command_prefix, worker_environment
command = [*worker_command_prefix(), "--package-v2-contact-preview"]
result = subprocess.run(command, input=json.dumps({"source_text": "{}", "source_root": sys.argv[2], "generation": "中文管道"}), capture_output=True, text=True, encoding="utf-8", env=worker_environment(), creationflags=subprocess.CREATE_NO_WINDOW, timeout=30)
Path(sys.argv[1]).write_text(json.dumps({"command": command, "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}), encoding="utf-8")
'''
            subprocess.run(
                [str(pythonw), "-c", code, str(report), directory],
                env=worker_environment(), check=True, timeout=45,
            )
            evidence = json.loads(report.read_text(encoding="utf-8"))
            self.assertEqual(Path(evidence["command"][0]).name.lower(), "python.exe")
            self.assertEqual(evidence["returncode"], 1, evidence)
            payload = json.loads(evidence["stdout"])
            self.assertEqual(payload["generation"], "中文管道")
            self.assertFalse(payload["geometry_contacts_complete"])
            self.assertTrue(payload["error"])

    def test_windows_workers_hide_the_console_without_affecting_other_platforms(self) -> None:
        with patch.object(sys, "platform", "win32"), patch.object(
            subprocess,
            "CREATE_NO_WINDOW",
            0x08000000,
            create=True,
        ):
            windows_options = worker_popen_options()
        self.assertEqual(windows_options["creationflags"], 0x08000000)
        self.assertEqual(windows_options["stdin"], subprocess.DEVNULL)

        with patch.object(sys, "platform", "darwin"):
            mac_options = worker_popen_options()
        self.assertNotIn("creationflags", mac_options)


if __name__ == "__main__":
    unittest.main()
