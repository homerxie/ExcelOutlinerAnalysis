"""Current-format test sources and explicit coordinate-shape constructors."""
from pathlib import Path
import json


def load_source(name):
    return json.loads((Path(__file__).parent / 'fixtures' / 'current' / (name + '.source.json')).read_text())


def box(origin, size, *, name='body'):
    return {'id': name, 'kind': 'bounds_box', 'bounds': {
        key: str(origin[i]) if key.endswith('min') else f'({origin[i]}) + ({size[i]})'
        for i, axis in enumerate('xyz') for key in (axis+'min', axis+'max')}}


def source(components, *, package_id='test_package', family='custom'):
    """Each entry declares one instance's id, material, shapes and mesh control."""
    result = {'schema': 'easymesh-package-v2', 'schema_revision': 8,
              'package': {'id': package_id, 'family': family},
              'globals': {'parameters': [], 'derived': []}, 'templates': [], 'instances': [],
              'frozen_sources': [], 'mesh_settings': {'interface_geometry_tolerance': '0.01um'}}
    for name, material, solids, control in components:
        result['templates'].append({'id': name+'_template', 'parameters': [], 'derived': [],
                                    'solids': solids, 'instances': []})
        result['instances'].append({'id': name, 'template': name+'_template', 'bindings': {},
                                    'origin': ['0mm']*3, 'material': material, 'mesh_control': control})
    return result


def mesh_control(priority=1, kind='conformal_hybrid'):
    strategy={'kind':kind}
    if kind=='structured_sweep':strategy['direction']='positive_z'
    return {'mesh_priority':priority, 'target_edge':'0.25mm', 'transition_distance':'0.45mm', 'strategy':strategy}


def coordinates(geometry):
    """Express a numerical meshing fixture in the current template coordinates.

    Tests share numerical primitive samples with the geometry engine; these are
    shapes, not Source documents. Runtime Source readers accept only bounds.
    """
    from copy import deepcopy
    g=deepcopy(geometry)
    kind=g['kind']; name=g.get('id','body')
    if kind.startswith('bounds_'):return g
    if kind=='box':return box(g['origin'],g['size'],name=name)
    if kind=='union':return dict(g,children=[coordinates(c) for c in g['children']])
    if kind=='difference':return dict(g,base=coordinates(g['base']),cutters=[coordinates(c) for c in g['cutters']])
    if kind=='rectangular_frame_extrusion':
        result=box(g['outer_origin'],[*g['outer_size'],g['height']],name=name)
        result['kind']='bounds_ring'
        lo=[f"({g['outer_origin'][i]}) + ({g['opening_offset'][i]})" for i in range(2)]
        result['inner_bounds']={key:lo[i] if key.endswith('min') else f"({lo[i]}) + ({g['opening_size'][i]})"
                                for i,axis in enumerate('xy') for key in (axis+'min',axis+'max')}
        return result
    if kind=='rectangular_underfill_fillet':
        result=box([*g['die_origin'],g['base_z']],[*g['die_size'],g['wall_height']],name=name)
        result['kind']='bounds_fillet'
        result['inner_bounds']={key:result['bounds'][key] for key in ('xmin','xmax','ymin','ymax')}
        widths=g.get('side_widths',[g['toe_width']]*4)
        tops=g.get('top_widths',[g.get('top_width','0mm')]*4)
        result['top_widths']=dict(zip(('xmin','xmax','ymin','ymax'),tops))
        for i,key in enumerate(('xmin','xmax','ymin','ymax')):
            sign='-' if key.endswith('min') else '+'
            result['bounds'][key]=f"({result['bounds'][key]}) {sign} ({widths[i]})"
        return result
    raise ValueError(kind)
