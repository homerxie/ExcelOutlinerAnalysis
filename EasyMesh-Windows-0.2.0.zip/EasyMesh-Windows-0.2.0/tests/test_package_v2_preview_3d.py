from __future__ import annotations

import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

RUN_QUICK3D_RENDER_TESTS = (
    os.environ.get("EASYMESH_RUN_QUICK3D_RENDER_TESTS") == "1"
)
if not RUN_QUICK3D_RENDER_TESTS:
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import (
    QLibraryInfo,
    QObject,
    QPoint,
    QPointF,
    Qt,
    qInstallMessageHandler,
)
from PySide6.QtGui import QColor, QWheelEvent
from PySide6.QtQuick3D import QQuick3DGeometry
from PySide6.QtQuickWidgets import QQuickWidget
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

from easymesh.package_v2_compile import compile_package_v2
from easymesh.package_v2_geometry import CanonicalBox, CanonicalRigidPlacement
from easymesh.package_v2_preview_3d import (
    PackageV2Preview3D,
    _positive_oriented_box_overlap_mm,
    _preview_oriented_box,
    build_preview_scene,
    feature_edges,
    frozen_component_key,
    generated_component_key,
    material_color,
    transform_frozen_point,
    transform_generated_point,
    visible_feature_edges,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]
HIGH_UF_SOURCE = PROJECT_ROOT / "tests/fixtures/package_v2_high_uf_gui.source.json"
PREVIEW_SOURCE = PROJECT_ROOT / "src/easymesh/package_v2_preview_3d.py"
PREVIEW_QML = PROJECT_ROOT / "src/easymesh/resources/package_v2_preview_3d.qml"
GENERATED_KEYS = (
    "generated/substrate/substrate",
    "generated/added_si/added_si",
    "generated/ring_lower/ring_lower",
    "generated/ring_upper/ring_upper",
    "generated/underfill_corner_core/underfill_corner_core",
    "generated/underfill_fillet/underfill_fillet",
)
FROZEN_KEY = "frozen/connected_bump/ALL_SOLID_VOLUMES"


def _compile_high_uf(path: Path = HIGH_UF_SOURCE):
    return compile_package_v2(
        path.read_bytes(),
        source_name=path.name,
        source_root=path.parent,
    )


def _temporary_high_uf(root: Path):
    source = root / HIGH_UF_SOURCE.name
    source.write_bytes(HIGH_UF_SOURCE.read_bytes())
    return _compile_high_uf(source)


def _two_box_document(*, second_origin_x, same_component=False):
    from tests.package_v2_current_sources import source,box,mesh_control
    first=box(["0mm"]*3,["1mm"]*3,name="first_box")
    second=box([second_origin_x,"0mm","0mm"],["1mm"]*3,name="second_box")
    components=[("first","A",[first,second] if same_component else [first],mesh_control())]
    if not same_component:components.append(("second","B",[second],mesh_control(2)))
    return source(components,package_id="preview_boxes")


def _frame_and_box_document(*, box_origin_x):
    from tests.package_v2_current_sources import source,box,mesh_control
    frame={"id":"frame_geometry","kind":"bounds_ring","bounds":{
        "xmin":"0mm","xmax":"3mm","ymin":"0mm","ymax":"3mm","zmin":"0mm","zmax":"1mm"},
        "inner_bounds":{"xmin":"1mm","xmax":"2mm","ymin":"1mm","ymax":"2mm"}}
    return source([("frame","A",[frame],mesh_control()),("box","B",[box([box_origin_x,"1.25mm","0mm"],["0.5mm","0.5mm","1mm"],name="box_geometry")],mesh_control(2))],package_id="preview_frame")


def _underfill_and_box_document(*, box_origin, box_size=("0.5mm","0.2mm","0.15mm")):
    from tests.package_v2_current_sources import source,box,mesh_control
    fillet={"id":"underfill_geometry","kind":"bounds_fillet","bounds":{
        "xmin":"-1mm","xmax":"3mm","ymin":"-1mm","ymax":"3mm","zmin":"0mm","zmax":"1mm"},
        "inner_bounds":{"xmin":"0mm","xmax":"2mm","ymin":"0mm","ymax":"2mm"},
        "top_widths":{k:"0mm" for k in ("xmin","xmax","ymin","ymax")}}
    return source([("underfill","A",[fillet],mesh_control()),("box","B",[box(box_origin,box_size,name="box_geometry")],mesh_control(2))],package_id="preview_underfill")


def _compile_preview_document(document: object):
    if isinstance(document, dict):
        document.setdefault(
            "mesh_settings",
            {"interface_geometry_tolerance": "0.01um"},
        )
    return compile_package_v2(
        json.dumps(document).encode("utf-8"),
        source_name="preview.source.json",
        source_root="/virtual/project",
    )


def _pixel_delta(first: object, second: object) -> int:
    return max(
        abs(first.red() - second.red()),  # type: ignore[attr-defined]
        abs(first.green() - second.green()),  # type: ignore[attr-defined]
        abs(first.blue() - second.blue()),  # type: ignore[attr-defined]
    )


class PackageV2Quick3DResourceContractTests(unittest.TestCase):
    def test_qml_and_python_use_only_portable_quick3d_contracts(self) -> None:
        source = PREVIEW_SOURCE.read_text(encoding="utf-8")
        qml = PREVIEW_QML.read_text(encoding="utf-8")

        self.assertIn("QQuickWidget", source)
        self.assertIn("QQuick3DGeometry.PrimitiveType.Triangles", source)
        self.assertIn("QQuick3DGeometry.PrimitiveType.Lines", source)
        self.assertNotIn("QPainter", source)
        self.assertNotIn("paintEvent", source)
        self.assertNotIn("QOpenGL", source)
        self.assertNotIn("CustomMaterial", source + qml)
        self.assertNotIn("Shader", source + qml)
        self.assertNotIn("_rasterize", source)

        self.assertIn("import QtQuick3D", qml)
        self.assertIn("View3D", qml)
        self.assertIn('objectName: "sceneView"', qml)
        self.assertIn("renderMode: View3D.Offscreen", qml)
        self.assertIn("depthTestEnabled: true", qml)
        self.assertNotIn("PerspectiveCamera", qml)
        self.assertNotIn("perspectiveMode", qml)
        self.assertIn("OrthographicCamera", qml)
        self.assertIn('objectName: "orthographicCamera"', qml)
        self.assertIn("camera: orthographicCamera", qml)
        self.assertIn("horizontalMagnification:", qml)
        self.assertIn("verticalMagnification: horizontalMagnification", qml)
        self.assertIn('objectName: "cameraOrbit"', qml)
        self.assertIn('objectName: "cameraKeyLight"', qml)
        self.assertIn('objectName: "cameraFillLight"', qml)
        self.assertIn("eulerRotation.x: 0", qml)
        self.assertIn("eulerRotation.y: 0", qml)
        camera_orbit_start = qml.index('objectName: "cameraOrbit"')
        scene_node_start = qml.index("Node {\n            position: root.sceneOffset")
        self.assertGreater(qml.index('objectName: "cameraKeyLight"'), camera_orbit_start)
        self.assertLess(qml.index('objectName: "cameraKeyLight"'), scene_node_start)
        self.assertGreater(qml.index('objectName: "cameraFillLight"'), camera_orbit_start)
        self.assertLess(qml.index('objectName: "cameraFillLight"'), scene_node_start)
        self.assertIn("property bool translucentMode: false", qml)
        self.assertIn("oitMethod: root.translucentMode", qml)
        self.assertIn("? SceneEnvironment.OITWeightedBlended", qml)
        self.assertIn(": SceneEnvironment.OITNone", qml)
        self.assertIn("PrincipledMaterial", qml)
        self.assertIn("blendMode: PrincipledMaterial.SourceOver", qml)
        self.assertIn("lineWidth: 1.0", qml)
        self.assertIn("Material.BackFaceCulling", qml)
        self.assertIn("required property bool depthWrite", qml)
        self.assertIn("? Material.AlwaysDepthDraw", qml)
        self.assertIn(": Material.NeverDepthDraw", qml)
        self.assertNotIn("DefaultMaterial", qml)

    def test_qml_is_in_package_data_and_passes_qmllint_when_available(self) -> None:
        pyproject = (PROJECT_ROOT / "pyproject.toml").read_text(encoding="utf-8")
        self.assertIn('"resources/*.qml"', pyproject)
        self.assertTrue(PREVIEW_QML.is_file())

        executable = shutil.which("pyside6-qmllint")
        if executable is None:
            sibling = Path(sys.executable).with_name("pyside6-qmllint")
            executable = str(sibling) if sibling.is_file() else None
        if executable is None:
            self.skipTest("pyside6-qmllint is not installed in this environment")
        qml_import_path = QLibraryInfo.path(
            QLibraryInfo.LibraryPath.QmlImportsPath
        )
        completed = subprocess.run(
            [executable, "-I", qml_import_path, str(PREVIEW_QML)],
            capture_output=True,
            check=False,
            text=True,
            timeout=30,
        )
        self.assertEqual(
            completed.returncode,
            0,
            completed.stdout + completed.stderr,
        )


class PackageV2PreviewSceneTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.compiled = _compile_high_uf()

    def test_high_uf_scene_is_small_and_preserves_component_relations(self) -> None:
        scene = build_preview_scene(self.compiled)

        self.assertEqual(scene.generated_count, 6)
        self.assertEqual(scene.frozen_count, 1)
        self.assertEqual(scene.component_keys, GENERATED_KEYS + (FROZEN_KEY,))
        self.assertEqual(scene.interfaces, ())

        # This is intentionally independent of the 1.37-million-cell output
        # mesh.  Keep the first low-poly implementation within its stated
        # approximately-500-triangle resource budget.
        self.assertEqual(
            tuple(len(component.triangles) for component in scene.components),
            (12, 12, 32, 32, 160, 88, 0),
        )
        # Painting follows canonical semantic faces. The triangles above are
        # retained only for a bounded topology/occlusion cache.
        self.assertEqual(
            tuple(len(component.fill_faces) for component in scene.components),
            (6, 6, 16, 16, 112, 76, 0),
        )
        self.assertTrue(
            all(
                len(face) == 4
                for component in scene.components[:4]
                for face in component.fill_faces
            )
        )
        self.assertEqual(
            {len(face) for face in scene.components[4].fill_faces},
            {3, 4},
        )
        self.assertEqual(scene.fill_face_count, 232)
        self.assertEqual(
            tuple(len(component.surface_edges) for component in scene.components),
            (12, 12, 24, 24, 84, 48, 0),
        )
        self.assertEqual(scene.triangle_count, 336)
        self.assertLessEqual(scene.triangle_count, 500)
        self.assertEqual(scene.plan_digest, self.compiled.plan_digest)

    def test_legal_high_uf_geometry_has_no_overlap_warning(self) -> None:
        scene = build_preview_scene(self.compiled)

        self.assertEqual(scene.geometry_warnings, ())
        self.assertFalse(
            any("正体积重叠" in warning for warning in scene.warnings)
        )

    def test_overlapping_box_components_emit_one_structured_warning(self) -> None:
        scene = build_preview_scene(
            _compile_preview_document(
                _two_box_document(second_origin_x="0.5mm")
            )
        )

        self.assertEqual(len(scene.geometry_warnings), 1)
        warning = scene.geometry_warnings[0]
        self.assertEqual(
            warning.code,
            "generated_component_positive_volume_overlap",
        )
        self.assertEqual(
            warning.component_keys,
            (
                "generated/first/first",
                "generated/second/second",
            ),
        )
        self.assertEqual(
            warning.component_labels,
            ("first / first", "second / second"),
        )
        self.assertAlmostEqual(warning.minimum_axis_overlap_mm, 0.5)
        self.assertTrue(warning.exact)
        self.assertIn("正体积重叠", warning.message)
        self.assertIn("可继续修改草稿", warning.message)
        self.assertIn(warning.message, scene.warnings)

    def test_overlap_diagnostics_are_bounded_for_interactive_edits(self) -> None:
        document = _two_box_document(second_origin_x="0mm")
        from copy import deepcopy
        prototype = document["instances"][0]
        document["instances"] = []
        for index in range(102):
            instance = deepcopy(prototype)
            instance["id"] = f"body_{index}"
            instance["mesh_control"]["mesh_priority"] = index + 1
            document["instances"].append(instance)

        scene = build_preview_scene(_compile_preview_document(document))

        self.assertEqual(len(scene.geometry_warnings), 100)
        self.assertTrue(scene.geometry_warning_scan_truncated)
        self.assertTrue(
            any("诊断已达到" in warning for warning in scene.warnings)
        )

    def test_touching_boxes_and_same_component_union_do_not_warn(self) -> None:
        touching = build_preview_scene(
            _compile_preview_document(
                _two_box_document(second_origin_x="1mm")
            )
        )
        same_component = build_preview_scene(
            _compile_preview_document(
                _two_box_document(
                    second_origin_x="0.5mm",
                    same_component=True,
                )
            )
        )

        self.assertEqual(touching.geometry_warnings, ())
        self.assertFalse(
            any("正体积重叠" in warning for warning in touching.warnings)
        )
        self.assertEqual(same_component.geometry_warnings, ())

    def test_frame_opening_is_not_treated_as_solid_but_rails_are(self) -> None:
        inside_opening = build_preview_scene(
            _compile_preview_document(
                _frame_and_box_document(box_origin_x="1.25mm")
            )
        )
        crossing_left_rail = build_preview_scene(
            _compile_preview_document(
                _frame_and_box_document(box_origin_x="0.75mm")
            )
        )

        self.assertEqual(inside_opening.geometry_warnings, ())
        self.assertEqual(len(crossing_left_rail.geometry_warnings), 1)
        warning = crossing_left_rail.geometry_warnings[0]
        self.assertEqual(
            warning.component_keys,
            (
                "generated/box/box",
                "generated/frame/frame",
            ),
        )
        self.assertAlmostEqual(warning.minimum_axis_overlap_mm, 0.25)
        self.assertTrue(warning.exact)

    def test_underfill_straight_side_overlap_emits_nonexact_advisory(self) -> None:
        scene = build_preview_scene(
            _compile_preview_document(
                _underfill_and_box_document(
                    box_origin=("0.5mm", "-0.65mm", "0.05mm"),
                )
            )
        )

        self.assertEqual(len(scene.geometry_warnings), 1)
        warning = scene.geometry_warnings[0]
        self.assertEqual(
            warning.code,
            "generated_underfill_possible_volume_overlap",
        )
        self.assertEqual(
            warning.component_keys,
            (
                "generated/box/box",
                "generated/underfill/underfill",
            ),
        )
        self.assertFalse(warning.exact)
        self.assertGreater(warning.minimum_axis_overlap_mm, 0.0)
        self.assertIn("Underfill 保守检查", warning.message)
        self.assertIn("不会阻止继续编辑", warning.message)
        self.assertIn(warning.message, scene.warnings)

    def test_underfill_hollow_touch_and_rounded_outer_bound_do_not_warn(self) -> None:
        inside_die = build_preview_scene(
            _compile_preview_document(
                _underfill_and_box_document(
                    box_origin=("0.5mm", "0.5mm", "0.05mm"),
                )
            )
        )
        touching_inner_wall = build_preview_scene(
            _compile_preview_document(
                _underfill_and_box_document(
                    box_origin=("0.5mm", "0mm", "0.05mm"),
                )
            )
        )
        rounded_corner_outer_bound = build_preview_scene(
            _compile_preview_document(
                _underfill_and_box_document(
                    box_origin=("-0.9mm", "-0.9mm", "0.05mm"),
                    box_size=("0.1mm", "0.1mm", "0.1mm"),
                )
            )
        )

        self.assertEqual(inside_die.geometry_warnings, ())
        self.assertEqual(touching_inner_wall.geometry_warnings, ())
        self.assertEqual(rounded_corner_outer_bound.geometry_warnings, ())

    def test_rotated_boxes_across_instances_use_exact_obb_overlap(self) -> None:
        document = _two_box_document(
            second_origin_x="2mm",
            same_component=True,
        )
        from copy import deepcopy
        document["templates"][0]["solids"].pop()
        rotated = deepcopy(document["instances"][0])
        # Rotate around the former box center, expressed as a local-origin placement.
        rotated.update(id="rotated", origin=["0.95mm", f"{0.5 - math.sqrt(0.5)}mm", "0mm"], rotation=[0, 0, 45])
        rotated["mesh_control"]["mesh_priority"] = 2
        document["instances"].append(rotated)

        scene = build_preview_scene(_compile_preview_document(document))

        self.assertEqual(len(scene.geometry_warnings), 1)
        self.assertEqual(
            scene.geometry_warnings[0].component_keys,
            (
                "generated/first/first",
                "generated/rotated/rotated",
            ),
        )
        self.assertTrue(scene.geometry_warnings[0].exact)

        touching_document = json.loads(json.dumps(document))
        touching_document["instances"][1]["origin"][0] = (
            "1.7071067811865475mm"
        )
        touching_scene = build_preview_scene(
            _compile_preview_document(touching_document)
        )
        self.assertEqual(touching_scene.geometry_warnings, ())

    def test_nearly_parallel_long_boxes_keep_the_cross_separating_axis(
        self,
    ) -> None:
        angle_rad = 1.0e-11
        angle_deg = math.degrees(angle_rad)
        cross_direction = (0.0, math.sin(angle_rad), math.sin(angle_rad))
        cross_length = math.hypot(*cross_direction)
        translation = tuple(
            3.1 * value / cross_length for value in cross_direction
        )
        box = CanonicalBox(
            (-1.0e12, -1.0, -1.0),
            (2.0e12, 2.0, 2.0),
        )
        first = _preview_oriented_box(
            box,
            CanonicalRigidPlacement((0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)),
            component_key="first",
            component_label="first",
        )
        second = _preview_oriented_box(
            box,
            CanonicalRigidPlacement(
                translation,  # type: ignore[arg-type]
                (0.0, angle_deg, angle_deg),
                (0.0, 0.0, 0.0),
            ),
            component_key="second",
            component_label="second",
        )

        self.assertIsNone(_positive_oriented_box_overlap_mm(first, second))

    def test_frozen_source_bounds_group_multiple_component_visibility_keys(self) -> None:
        document = json.loads(HIGH_UF_SOURCE.read_text(encoding="utf-8"))
        document["frozen_sources"][0]["components"].append("SECOND_SOLID_VOLUME")
        compiled = compile_package_v2(
            json.dumps(document).encode("utf-8"),
            source_name=HIGH_UF_SOURCE.name,
            source_root=HIGH_UF_SOURCE.parent,
        )
        scene = build_preview_scene(compiled)
        first_key = FROZEN_KEY
        second_key = frozen_component_key(
            "connected_bump",
            "SECOND_SOLID_VOLUME",
        )

        self.assertEqual(
            tuple(scene.frozen_components_by_source),
            ("connected_bump",),
        )
        self.assertEqual(
            tuple(
                component.key
                for component in scene.frozen_components_by_source[
                    "connected_bump"
                ]
            ),
            (first_key, second_key),
        )
        self.assertEqual(
            tuple(
                component.key
                for component in scene.visible_frozen_components_by_source(
                    (second_key,)
                )["connected_bump"]
            ),
            (second_key,),
        )
        self.assertEqual(
            scene.visible_frozen_components_by_source(()),
            {},
        )
        self.assertEqual(
            scene.highlighted_frozen_sources((second_key,)),
            frozenset(("connected_bump",)),
        )
        self.assertTrue(
            all(
                "shared source" in component.label
                for component in scene.frozen_components_by_source[
                    "connected_bump"
                ]
            )
        )

    def test_keys_colors_and_rigid_transforms_are_deterministic(self) -> None:
        self.assertEqual(
            generated_component_key("instance-a", "body"),
            "generated/instance-a/body",
        )
        self.assertEqual(
            frozen_component_key("source-a", "ALL_SOLID_VOLUMES"),
            "frozen/source-a/ALL_SOLID_VOLUMES",
        )
        self.assertEqual(material_color("SBT").name(), "#4f9d69")
        self.assertEqual(material_color("sbt"), material_color("SBT"))
        self.assertEqual(material_color("mystery resin").name(), "#578bcb")
        self.assertEqual(
            build_preview_scene(self.compiled).component_keys,
            build_preview_scene(self.compiled).component_keys,
        )

        generated_placement = CanonicalRigidPlacement(
            (10.0, -2.0, 3.0),
            (0.0, 0.0, 90.0),
            (1.0, 1.0, 0.0),
        )
        transformed = transform_generated_point(
            (2.0, 1.0, 4.0),
            generated_placement,
        )
        for actual, expected in zip(transformed, (11.0, 0.0, 7.0)):
            self.assertAlmostEqual(actual, expected)

        frozen_placement = self.compiled.frozen_sources[0].placement
        self.assertEqual(
            transform_frozen_point((-0.25, -0.25, 0.0), frozen_placement),
            (-0.25, 0.25, 0.4257),
        )

    def test_feature_edges_hide_coplanar_diagonals_but_keep_real_creases(self) -> None:
        first = ((0.0, 0.0, 0.0), (1.0, 0.0, 0.0), (1.0, 1.0, 0.0))
        coplanar = ((0.0, 0.0, 0.0), (1.0, 1.0, 0.0), (0.0, 1.0, 0.0))
        edges = feature_edges((first, coplanar))

        self.assertEqual(len(edges), 4)
        diagonal = {
            (0.0, 0.0, 0.0),
            (1.0, 1.0, 0.0),
        }
        self.assertNotIn(
            diagonal,
            ({first_point, second_point} for first_point, second_point in edges),
        )

        folded = ((0.0, 0.0, 0.0), (1.0, 1.0, 0.0), (0.0, 0.0, 1.0))
        crease_edges = feature_edges((first, folded))
        self.assertIn(
            diagonal,
            (
                {first_point, second_point}
                for first_point, second_point in crease_edges
            ),
        )

    def test_primitive_edges_are_cached_and_back_faces_are_hidden(self) -> None:
        scene = build_preview_scene(self.compiled)
        generated = scene.components[:6]

        # Box, frame and Underfill retain their canonical primitive edges;
        # triangle diagonals and rounded-arc tessellation seams are not lines.
        self.assertEqual(
            tuple(len(component.edge_adjacency) for component in generated),
            (18, 18, 48, 48, 240, 132),
        )
        self.assertEqual(
            tuple(len(component.surface_edges) for component in generated),
            (12, 12, 24, 24, 84, 48),
        )
        underfill = generated[-1]
        self.assertTrue(
            any(
                0.0 < edge.maximum_dihedral_angle_deg < 20.0
                for edge in underfill.edge_adjacency
            )
        )
        self.assertTrue(
            all(
                edge.maximum_dihedral_angle_deg >= 20.0
                for edge in underfill.edge_adjacency
                if edge.edge in underfill.surface_edges
            )
        )
        self.assertTrue(
            all(
                edge.semantic_face_indices
                for component in generated
                for edge in component.edge_adjacency
                if edge.edge in component.surface_edges
            )
        )

        # No edge is drawn when all incident faces point away. Conversely,
        # viewing every face retains exactly the semantic primitive edges.
        for component in generated:
            all_back = (False,) * len(component.triangles)
            self.assertEqual(
                visible_feature_edges(component.edge_adjacency, all_back),
                (),
            )
            all_front = (True,) * len(component.triangles)
            self.assertEqual(
                visible_feature_edges(component.edge_adjacency, all_front),
                component.surface_edges,
            )

    def test_frozen_uses_only_bounded_msh_header_without_loading_nodes_or_gmsh(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            compiled = _temporary_high_uf(root)
            mesh = root / "bumps_connected.msh"
            mesh.write_bytes(
                b'$MeshFormat\n4.1 0 8\n$EndMeshFormat\n'
                b'$PhysicalNames\n1\n3 1 "ALL_SOLID_VOLUMES"\n$EndPhysicalNames\n'
                b'$Entities\n0 0 0 1\n1 -.25 -.2 .01 .25 .2 .125 1 1 0\n$EndEntities\n'
                b'$Nodes\ninvalid body: preview must not parse this\n'
            )
            opened = []
            original_open = Path.open

            def guarded_open(path, *args, **kwargs):
                opened.append(path)
                self.assertEqual(path, mesh)
                return original_open(path, *args, **kwargs)

            with patch.object(Path, "open", guarded_open), \
                    patch("easymesh.sample_mesh.load_sample_mesh", side_effect=AssertionError("mesh loader invoked")), \
                    patch("easymesh.gmsh_runtime._load_gmsh", side_effect=AssertionError("Gmsh invoked")):
                scene = build_preview_scene(compiled)
                build_preview_scene(compiled)
            self.assertEqual(opened, [mesh])
            frozen = scene.component_by_key[FROZEN_KEY]
            self.assertTrue(frozen.bounds_known)
            self.assertEqual(len(frozen.wire_corners), 8)
            self.assertEqual({round(p[0], 7) for p in frozen.wire_corners}, {-.25, .25})
            self.assertEqual({round(p[1], 7) for p in frozen.wire_corners}, {-.2, .2})
            self.assertEqual({round(p[2], 7) for p in frozen.wire_corners}, {.3007, .4157})
            self.assertIn("metadata bounds", frozen.label)

    def test_missing_mesh_uses_placement_proxy_without_searching_for_json(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            compiled = _temporary_high_uf(root)
            with patch.object(Path, "open", side_effect=AssertionError("no companion file should be opened")):
                scene = build_preview_scene(compiled)
            frozen = scene.component_by_key[FROZEN_KEY]
            self.assertFalse(frozen.bounds_known)
            self.assertEqual(frozen.center, (0., 0., .4257))
            self.assertEqual(len(frozen.wire_corners), 8)
            self.assertEqual(frozen.triangles, ())
            self.assertIn("范围未知", frozen.label)
            self.assertTrue(any("未读取 MSH" in warning for warning in scene.warnings))


class PackageV2PreviewWidgetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.application = QApplication.instance() or QApplication([])
        cls.compiled = _compile_high_uf()

    def setUp(self) -> None:
        self.preview = PackageV2Preview3D()
        self.preview.resize(720, 540)
        self.preview.set_compiled_geometry(self.compiled)
        self.preview.show()
        QApplication.processEvents()

    def tearDown(self) -> None:
        self.preview.close()
        self.preview.deleteLater()
        QApplication.processEvents()

    def _wheel(self, delta: int, anchor: QPointF | None = None) -> None:
        anchor = anchor or QPointF(self.preview.canvas.rect().center())
        event = QWheelEvent(
            anchor,
            anchor,
            QPoint(),
            QPoint(0, delta),
            Qt.MouseButton.NoButton,
            Qt.KeyboardModifier.NoModifier,
            Qt.ScrollPhase.ScrollUpdate,
            False,
        )
        QApplication.sendEvent(self.preview.canvas, event)
        QApplication.processEvents()

    def test_quick3d_canvas_scene_model_and_buffers_are_bounded(self) -> None:
        canvas = self.preview.canvas
        self.assertIsInstance(canvas, QQuickWidget)
        self.assertEqual(canvas.status(), QQuickWidget.Status.Ready)
        root = canvas.rootObject()
        self.assertIsNotNone(root)
        repeater = root.findChild(QObject, "sceneRepeater")
        self.assertIsNotNone(repeater)

        entries = canvas._scene_model.entries
        self.assertEqual(len(entries), 16)
        self.assertEqual(repeater.property("count"), len(entries))
        primitive_types = tuple(
            entry.geometry.primitiveType() for entry in entries
        )
        self.assertEqual(
            primitive_types.count(QQuick3DGeometry.PrimitiveType.Triangles),
            6,
        )
        self.assertEqual(
            primitive_types.count(QQuick3DGeometry.PrimitiveType.Lines),
            10,
        )
        self.assertEqual(
            set(primitive_types),
            {
                QQuick3DGeometry.PrimitiveType.Triangles,
                QQuick3DGeometry.PrimitiveType.Lines,
            },
        )
        self.assertEqual(
            sum(
                len(entry.geometry.vertexData())
                + len(entry.geometry.indexData())
                for entry in entries
            ),
            30_048,
        )
        self.assertTrue(
            all(
                entry.geometry.vertexData()
                and entry.geometry.indexData()
                and entry.geometry.boundsMin() != entry.geometry.boundsMax()
                for entry in entries
            )
        )

        triangle_entries = tuple(
            entry
            for entry in entries
            if entry.geometry.primitiveType()
            == QQuick3DGeometry.PrimitiveType.Triangles
        )
        self.assertEqual(
            tuple(entry.keys for entry in triangle_entries),
            tuple((key,) for key in GENERATED_KEYS),
        )
        self.assertTrue(
            all(
                entry.opacity == 1.0
                and not entry.unlit
                and not entry.no_culling
                for entry in triangle_entries
            )
        )

        underfill = self.preview.scene.component_by_key[GENERATED_KEYS[4]]
        underfill_base = min(point[2] for point in underfill.points)
        bottom_faces = tuple(
            face
            for face in underfill.fill_faces
            if all(abs(point[2] - underfill_base) <= 1.0e-12 for point in face)
        )
        self.assertTrue(bottom_faces)
        # These bottom faces remain in the closed solid buffer; the QML
        # BackFaceCulling contract, not a painter-order heuristic, hides them
        # from the default above-camera view.
        self.assertFalse(
            next(
                entry for entry in triangle_entries
                if entry.keys == (GENERATED_KEYS[4],)
            ).no_culling
        )

    def test_offscreen_backend_is_reported_as_non_rendering_capability(self) -> None:
        if QApplication.platformName() != "offscreen":
            self.skipTest("this capability assertion targets QT_QPA_PLATFORM=offscreen")
        self.assertEqual(self.preview.canvas.status(), QQuickWidget.Status.Ready)
        self.assertIsNotNone(self.preview.canvas.rootObject())
        self.assertEqual(self.preview.render_backend, "Software")
        self.assertEqual(
            self.preview.render_status,
            "unsupported-backend: Software",
        )

    def test_visibility_and_highlight_state_follow_component_keys(self) -> None:
        all_keys = frozenset(self.preview.scene.component_keys)
        self.assertEqual(self.preview.visible_components, all_keys)
        self.assertEqual(set(self.preview.visibility_actions), all_keys)

        hidden = GENERATED_KEYS[0]
        self.preview.set_component_visible(hidden, False)
        self.assertNotIn(hidden, self.preview.visible_components)
        self.assertFalse(self.preview.visibility_actions[hidden].isChecked())
        self.assertIn("隐藏 1", self.preview.summary_label.text())
        self.assertTrue(
            all(
                not entry.visible
                for entry in self.preview.canvas._scene_model.entries
                if hidden in entry.keys
            )
        )

        self.preview.visibility_actions[hidden].trigger()
        self.assertIn(hidden, self.preview.visible_components)
        self.assertTrue(self.preview.visibility_actions[hidden].isChecked())
        self.assertTrue(
            all(
                entry.visible
                for entry in self.preview.canvas._scene_model.entries
                if hidden in entry.keys
            )
        )

        self.preview.set_highlighted_components(
            (GENERATED_KEYS[1], FROZEN_KEY, "not/a/component")
        )
        self.assertEqual(
            self.preview.highlighted_components,
            frozenset((GENERATED_KEYS[1], FROZEN_KEY)),
        )
        highlighted_entries = tuple(
            entry
            for entry in self.preview.canvas._scene_model.entries
            if any(key in {GENERATED_KEYS[1], FROZEN_KEY} for key in entry.keys)
        )
        self.assertTrue(highlighted_entries)
        self.assertTrue(all(entry.highlighted for entry in highlighted_entries))
        self.assertTrue(
            any(entry.display_color != entry.base_color for entry in highlighted_entries)
        )
        self.assertIn("高亮 2", self.preview.summary_label.text())
        self.assertFalse(self.preview.canvas.rootObject().property("translucentMode"))

        entries = self.preview.canvas._scene_model.entries
        selected_face = next(
            entry
            for entry in entries
            if entry.keys == (GENERATED_KEYS[1],)
            and entry.geometry.primitiveType()
            == QQuick3DGeometry.PrimitiveType.Triangles
        )
        self.assertTrue(selected_face.highlighted)
        self.assertFalse(selected_face.focus_faded)
        self.assertEqual(selected_face.display_color, selected_face.base_color)
        self.assertTrue(selected_face.display_unlit)
        self.assertEqual(selected_face.display_opacity, 1.0)
        self.assertFalse(selected_face.transparent_mode)
        self.assertTrue(selected_face.depth_write)

        selected_edges = tuple(
            entry
            for entry in entries
            if entry.keys == (GENERATED_KEYS[1],)
            and entry.geometry.primitiveType()
            == QQuick3DGeometry.PrimitiveType.Lines
        )
        self.assertTrue(selected_edges)
        self.assertTrue(
            all(entry.display_color == QColor("#ffea00") for entry in selected_edges)
        )

        background_faces = tuple(
            entry
            for entry in entries
            if not entry.highlighted and entry.translucent_capable
        )
        self.assertTrue(background_faces)
        self.assertTrue(all(not entry.visible for entry in background_faces))
        self.assertTrue(
            all(not entry.transparent_mode for entry in background_faces)
        )
        background_lines = tuple(
            entry
            for entry in entries
            if not entry.highlighted and not entry.translucent_capable
        )
        self.assertTrue(background_lines)
        self.assertTrue(all(entry.visible for entry in background_lines))
        self.assertTrue(all(entry.focus_context for entry in background_lines))
        self.assertTrue(
            all(entry.display_color == QColor("#65717b") for entry in background_lines)
        )
        self.assertTrue(
            all(
                not entry.transparent_mode and entry.display_opacity == 1.0
                for entry in background_lines
            )
        )

        # Selection must not override the user's transparency switch.
        self.preview.translucent_button.click()
        self.assertEqual(selected_face.display_opacity, 0.42)
        self.assertTrue(selected_face.transparent_mode)
        self.assertFalse(selected_face.depth_write)
        self.assertTrue(selected_face.highlighted)
        self.assertTrue(all(not entry.visible for entry in background_faces))
        self.assertTrue(all(entry.display_opacity == 1.0 for entry in selected_edges))
        self.preview.set_highlighted_components(())
        self.assertNotIn("高亮", self.preview.summary_label.text())
        self.assertTrue(selected_face.translucent)
        self.assertEqual(selected_face.display_opacity, 0.42)
        self.assertTrue(selected_face.transparent_mode)
        self.preview.set_translucent(False)
        self.assertFalse(self.preview.canvas.rootObject().property("translucentMode"))
        self.assertTrue(
            all(
                not entry.focus_faded
                and entry.display_opacity == 1.0
                and not entry.transparent_mode
                for entry in entries
            )
        )

    def test_translucency_only_changes_generated_fill_entries(self) -> None:
        entries = self.preview.canvas._scene_model.entries
        triangle_entries = tuple(
            entry
            for entry in entries
            if entry.geometry.primitiveType()
            == QQuick3DGeometry.PrimitiveType.Triangles
        )
        line_entries = tuple(
            entry
            for entry in entries
            if entry.geometry.primitiveType()
            == QQuick3DGeometry.PrimitiveType.Lines
        )
        self.assertFalse(self.preview.translucent)
        self.assertFalse(self.preview.translucent_button.isChecked())
        self.assertFalse(
            self.preview.canvas.rootObject().property("translucentMode")
        )
        self.assertTrue(
            all(
                entry.display_opacity == 1.0
                and not entry.translucent
                and entry.depth_write
                for entry in entries
            )
        )

        self.preview.translucent_button.click()
        QApplication.processEvents()
        self.assertTrue(self.preview.translucent)
        self.assertTrue(
            self.preview.canvas.rootObject().property("translucentMode")
        )
        self.assertIn("半透明", self.preview.summary_label.text())
        self.assertTrue(
            all(
                entry.translucent_capable
                and entry.translucent
                and entry.display_opacity == 0.42
                and not entry.depth_write
                for entry in triangle_entries
            )
        )
        self.assertTrue(
            all(
                not entry.translucent_capable
                and not entry.translucent
                and entry.display_opacity == 1.0
                and entry.depth_write
                for entry in line_entries
            )
        )
        model = self.preview.canvas._scene_model
        for row, entry in enumerate(entries):
            index = model.index(row, 0)
            self.assertEqual(
                model.data(index, model.TransparentRole),
                entry.geometry.primitiveType()
                == QQuick3DGeometry.PrimitiveType.Triangles,
            )
            self.assertEqual(
                model.data(index, model.DepthWriteRole),
                entry.geometry.primitiveType()
                != QQuick3DGeometry.PrimitiveType.Triangles,
            )

        self.preview.translucent_button.click()
        QApplication.processEvents()
        self.assertFalse(self.preview.translucent)
        self.assertFalse(
            self.preview.canvas.rootObject().property("translucentMode")
        )
        self.assertTrue(
            all(
                entry.display_opacity == 1.0
                and not entry.translucent
                and entry.depth_write
                for entry in entries
            )
        )

    def test_camera_controls_reset_without_claiming_offscreen_3d_render(self) -> None:
        initial = (-38.0, -24.0, 1.0, 0.0, 0.0)
        self.assertEqual(self.preview.camera_state, initial)

        self._wheel(240)
        self.assertGreater(self.preview.camera_state[2], 1.0)
        start = self.preview.canvas.rect().center()
        end = start + QPoint(45, 20)
        QTest.mousePress(
            self.preview.canvas,
            Qt.MouseButton.LeftButton,
            pos=start,
        )
        QTest.mouseMove(self.preview.canvas, end)
        QTest.mouseRelease(
            self.preview.canvas,
            Qt.MouseButton.LeftButton,
            pos=end,
        )
        QApplication.processEvents()
        self.assertNotEqual(self.preview.camera_state[:2], initial[:2])

        self.preview.set_highlighted_components((GENERATED_KEYS[4], FROZEN_KEY))
        self.preview.reset_button.click()
        QApplication.processEvents()
        self.assertEqual(self.preview.camera_state, initial)

    def test_orthographic_zoom_spans_100mm_to_1um_around_pointer(self) -> None:
        canvas = self.preview.canvas
        root = canvas.rootObject()
        initial_distance = float(root.property("cameraDistance"))
        radius = float(root.property("sceneRadius"))
        anchor = QPointF(canvas.width() * 0.78, canvas.height() * 0.31)
        offset_x = anchor.x() - canvas.width() * 0.5
        offset_y = anchor.y() - canvas.height() * 0.5
        viewport_span = float(min(canvas.width(), canvas.height()))
        initial_world_per_pixel = radius * 2.4 / viewport_span
        anchored_before = (
            offset_x * initial_world_per_pixel,
            -offset_y * initial_world_per_pixel,
        )

        # One large synthetic wheel gesture exercises the logarithmic clamp;
        # ordinary hardware reaches the same value through repeated notches.
        self._wheel(12_000, anchor)

        yaw, pitch, zoom, pan_x, pan_y = self.preview.camera_state
        self.assertEqual((yaw, pitch), (-38.0, -24.0))
        self.assertAlmostEqual(zoom, 100_000.0)
        self.assertAlmostEqual(float(root.property("zoomFactor")), 100_000.0)
        self.assertAlmostEqual(float(root.property("cameraDistance")), initial_distance)
        magnified_world_per_pixel = radius * 2.4 / zoom / viewport_span
        anchored_after = (
            pan_x + offset_x * magnified_world_per_pixel,
            pan_y - offset_y * magnified_world_per_pixel,
        )
        self.assertAlmostEqual(anchored_after[0], anchored_before[0], places=10)
        self.assertAlmostEqual(anchored_after[1], anchored_before[1], places=10)

    def test_horizontal_drag_orbits_in_the_expected_direction(self) -> None:
        initial_yaw = self.preview.camera_state[0]
        center = self.preview.canvas.rect().center()
        right = center + QPoint(42, 0)
        QTest.mousePress(
            self.preview.canvas,
            Qt.MouseButton.LeftButton,
            pos=center,
        )
        QTest.mouseMove(self.preview.canvas, right)
        QTest.mouseRelease(
            self.preview.canvas,
            Qt.MouseButton.LeftButton,
            pos=right,
        )
        QApplication.processEvents()
        self.assertLess(self.preview.camera_state[0], initial_yaw)

        self.preview.reset_view()
        QApplication.processEvents()
        left = center - QPoint(42, 0)
        QTest.mousePress(
            self.preview.canvas,
            Qt.MouseButton.LeftButton,
            pos=center,
        )
        QTest.mouseMove(self.preview.canvas, left)
        QTest.mouseRelease(
            self.preview.canvas,
            Qt.MouseButton.LeftButton,
            pos=left,
        )
        QApplication.processEvents()
        self.assertGreater(self.preview.camera_state[0], initial_yaw)

    def test_pointer_motion_does_not_republish_scene_or_coordinate_models(self) -> None:
        canvas = self.preview.canvas
        root = canvas.rootObject()
        entries = canvas._scene_model.entries
        axis = root.findChild(QObject, "globalAxisX")
        before = self.preview.camera_state
        # Native scene initialization may request a full synchronization once;
        # pointer events themselves must only touch the camera.
        with patch.object(canvas, "_apply_root_properties") as scene_update, patch.object(
            canvas, "_build_scene_entries", wraps=canvas._build_scene_entries
        ) as build:
            center = canvas.rect().center()
            QTest.mousePress(canvas, Qt.MouseButton.LeftButton, pos=center)
            QTest.mouseMove(canvas, center + QPoint(30, 15))
            QTest.mouseRelease(canvas, Qt.MouseButton.LeftButton, pos=center + QPoint(30, 15))
            self._wheel(120)
            self.assertNotEqual(before[:3], self.preview.camera_state[:3])
            scene_update.assert_not_called()
            build.assert_not_called()
        self.assertIs(root.findChild(QObject, "globalAxisX"), axis)
        self.assertIs(canvas._scene_model.entries, entries)
        self.assertEqual(root.property("orbitYaw"), self.preview.camera_state[0])
        self.assertEqual(root.property("zoomFactor"), self.preview.camera_state[2])

    def test_preview_uses_only_the_orthographic_camera(self) -> None:
        root = self.preview.canvas.rootObject()
        scene_view = root.findChild(QObject, "sceneView")
        camera_orbit = root.findChild(QObject, "cameraOrbit")
        orthographic_camera = root.findChild(QObject, "orthographicCamera")
        camera_key_light = root.findChild(QObject, "cameraKeyLight")
        camera_fill_light = root.findChild(QObject, "cameraFillLight")
        self.assertIsNotNone(scene_view)
        self.assertIsNotNone(camera_orbit)
        self.assertIsNotNone(orthographic_camera)
        self.assertIsNotNone(camera_key_light)
        self.assertIsNotNone(camera_fill_light)
        self.assertIn(
            "OrthographicCamera",
            orthographic_camera.metaObject().className(),
        )
        self.assertIsNone(root.findChild(QObject, "perspectiveCamera"))
        self.assertIs(camera_key_light.parent(), camera_orbit)
        self.assertIs(camera_fill_light.parent(), camera_orbit)
        self.assertFalse(hasattr(self.preview, "perspective_button"))
        self.assertFalse(hasattr(self.preview, "set_perspective"))

    def test_axis_view_buttons_preserve_zoom_and_render_modes(self) -> None:
        self.assertEqual(self.preview.x_view_button.text(), "X")
        self.assertEqual(self.preview.y_view_button.text(), "Y")
        self.assertEqual(self.preview.z_view_button.text(), "Z")

        self._wheel(120)
        zoom = self.preview.camera_state[2]
        self.preview.set_translucent(True)
        expected_views = (
            (self.preview.x_view_button, (90.0, 0.0)),
            (self.preview.y_view_button, (-180.0, 0.0)),
            (self.preview.z_view_button, (0.0, -90.0)),
        )
        center = self.preview.canvas.rect().center()

        for button, expected_angles in expected_views:
            QTest.mousePress(
                self.preview.canvas,
                Qt.MouseButton.RightButton,
                pos=center,
            )
            QTest.mouseMove(self.preview.canvas, center + QPoint(34, 19))
            QTest.mouseRelease(
                self.preview.canvas,
                Qt.MouseButton.RightButton,
                pos=center + QPoint(34, 19),
            )
            QApplication.processEvents()
            self.assertNotEqual(self.preview.camera_state[3:], (0.0, 0.0))

            button.click()
            QApplication.processEvents()
            self.assertEqual(self.preview.camera_state[:2], expected_angles)
            self.assertEqual(self.preview.camera_state[2], zoom)
            self.assertEqual(self.preview.camera_state[3:], (0.0, 0.0))
            self.assertTrue(self.preview.translucent)

        z_view_state = self.preview.camera_state
        horizontal = center + QPoint(36, 0)
        QTest.mousePress(
            self.preview.canvas,
            Qt.MouseButton.LeftButton,
            pos=center,
        )
        QTest.mouseMove(self.preview.canvas, horizontal)
        QTest.mouseRelease(
            self.preview.canvas,
            Qt.MouseButton.LeftButton,
            pos=horizontal,
        )
        QApplication.processEvents()
        self.assertNotEqual(self.preview.camera_state[0], z_view_state[0])
        self.assertEqual(self.preview.camera_state[1], -90.0)

        before_invalid = self.preview.camera_state
        with self.assertRaisesRegex(ValueError, "x, y, z"):
            self.preview.set_axis_view("xy")
        self.assertEqual(self.preview.camera_state, before_invalid)
        self.assertTrue(self.preview.translucent)

    def test_global_axes_follow_canonical_views_at_constant_screen_scale(self) -> None:
        root = self.preview.canvas.rootObject()
        overlay = root.findChild(QObject, "globalAxes")
        axes = {
            item.objectName()[-1]: item
            for item in overlay.childItems()
            if item.objectName().startswith("globalAxis")
        }
        self.assertEqual(set(axes), set("XYZ"))
        length = float(overlay.property("axisLength"))
        expected = {
            "x": {"X": (0, 0), "Y": (length, 0), "Z": (0, -length)},
            "y": {"X": (-length, 0), "Y": (0, 0), "Z": (0, -length)},
            "z": {"X": (length, 0), "Y": (0, -length), "Z": (0, 0)},
        }
        for view, directions in expected.items():
            self.preview.set_axis_view(view)
            QApplication.processEvents()
            for label, (dx, dy) in directions.items():
                self.assertAlmostEqual(axes[label].property("dx"), dx, places=4)
                self.assertAlmostEqual(axes[label].property("dy"), dy, places=4)

        # Exercise the same camera updates used by drag, zoom and resize.
        self.preview.reset_view()
        QApplication.processEvents()
        before = [(item.property("dx"), item.property("dy")) for item in axes.values()]
        self.assertNotAlmostEqual(before[0][1], 0, places=3)
        for delta in (1200, 12000, -24000):
            self._wheel(delta)
            self.assertEqual(
                [(item.property("dx"), item.property("dy")) for item in axes.values()],
                before,
            )
        self.preview.resize(980, 680)
        QApplication.processEvents()
        self.assertEqual(
            [(item.property("dx"), item.property("dy")) for item in axes.values()],
            before,
        )

    def test_global_axes_anchor_tracks_true_origin_and_pan(self) -> None:
        self.preview.set_compiled_geometry(_compile_preview_document(
            _two_box_document(second_origin_x="4mm")
        ))
        self.preview.set_axis_view("z")
        QApplication.processEvents()
        canvas = self.preview.canvas
        root = canvas.rootObject()
        overlay = root.findChild(QObject, "globalAxes")
        camera = root.findChild(QObject, "orthographicCamera")

        def check_origin() -> None:
            magnification = camera.property("horizontalMagnification")
            # Bounds [0,5] x [0,1] put the global origin away from the fit center.
            self.assertAlmostEqual(
                overlay.property("originX"),
                canvas.width() / 2 - (2.5 + root.property("panX")) * magnification,
                places=3,
            )
            self.assertAlmostEqual(
                overlay.property("originY"),
                canvas.height() / 2 + (0.5 + root.property("panY")) * magnification,
                places=3,
            )

        check_origin()
        self._wheel(240)
        check_origin()
        center = canvas.rect().center()
        QTest.mousePress(canvas, Qt.MouseButton.RightButton, pos=center)
        QTest.mouseMove(canvas, center + QPoint(36, 24))
        QTest.mouseRelease(canvas, Qt.MouseButton.RightButton, pos=center + QPoint(36, 24))
        QApplication.processEvents()
        self.assertNotEqual(self.preview.camera_state[3:], (0, 0))
        check_origin()
        self.preview.resize(980, 680)
        QApplication.processEvents()
        check_origin()
        self.preview.set_visible_components(())
        QApplication.processEvents()
        self.assertFalse(overlay.isVisible())

    def test_native_quick3d_high_uf_depth_regression(self) -> None:
        if not RUN_QUICK3D_RENDER_TESTS:
            self.skipTest(
                "requires EASYMESH_RUN_QUICK3D_RENDER_TESTS=1 on a native "
                "Metal/D3D11/D3D12/Vulkan/OpenGL GUI runner"
            )
        self.assertIn(
            self.preview.render_backend,
            {"Metal", "Direct3D11", "Direct3D12", "Vulkan", "OpenGL"},
        )
        self.assertEqual(
            self.preview.render_status,
            f"ready: {self.preview.render_backend}",
        )

        all_keys = GENERATED_KEYS + (FROZEN_KEY,)

        def frame_for(hidden: frozenset[str]):
            self.preview.set_visible_components(
                key for key in all_keys if key not in hidden
            )
            QTest.qWait(180)
            frame = self.preview.canvas.grabFramebuffer()
            self.assertFalse(frame.isNull())
            return frame

        z_frame = None
        try:
            both = frame_for(frozenset())
            without_upper = frame_for(frozenset((GENERATED_KEYS[3],)))
            without_underfill = frame_for(frozenset((GENERATED_KEYS[4],)))
            without_both = frame_for(
                frozenset((GENERATED_KEYS[3], GENERATED_KEYS[4]))
            )
            self.preview.set_axis_view("z")
            z_frame = frame_for(frozenset())
        finally:
            self.preview.set_visible_components(all_keys)
            self.preview.reset_view()

        self.assertEqual(
            {
                frame.size()
                for frame in (
                    both,
                    without_upper,
                    without_underfill,
                    without_both,
                )
            },
            {both.size()},
        )
        width, height = both.width(), both.height()
        witnesses = 0
        stable_witnesses = 0
        offsets = ((0, 0), (-2, 0), (2, 0), (0, -2), (0, 2))
        for y in range(3, height - 3, 2):
            for x in range(3, width - 3, 2):
                # This mask selects pixels where UF changes the image and,
                # after UF is hidden, upper-ring changes the same ray.
                if not all(
                    _pixel_delta(
                        both.pixelColor(x + dx, y + dy),
                        without_underfill.pixelColor(x + dx, y + dy),
                    )
                    >= 14
                    and _pixel_delta(
                        without_underfill.pixelColor(x + dx, y + dy),
                        without_both.pixelColor(x + dx, y + dy),
                    )
                    >= 14
                    for dx, dy in offsets
                ):
                    continue
                witnesses += 1
                if _pixel_delta(
                    both.pixelColor(x, y),
                    without_upper.pixelColor(x, y),
                ) <= 4:
                    stable_witnesses += 1

        self.assertGreaterEqual(witnesses, 20)
        self.assertGreaterEqual(stable_witnesses / witnesses, 0.97)

        self.assertIsNotNone(z_frame)
        background = z_frame.pixelColor(0, 0)
        foreground_points = tuple(
            (x, y)
            for y in range(0, z_frame.height(), 2)
            for x in range(0, z_frame.width(), 2)
            if _pixel_delta(z_frame.pixelColor(x, y), background) >= 6
        )
        self.assertGreaterEqual(len(foreground_points), 100)
        left = min(x for x, _y in foreground_points)
        right = max(x for x, _y in foreground_points)
        top = min(y for _x, y in foreground_points)
        bottom = max(y for _x, y in foreground_points)
        box_width = right - left + 1
        box_height = bottom - top + 1
        self.assertGreater(box_width, z_frame.width() * 0.10)
        self.assertLess(box_width, z_frame.width() * 0.90)
        self.assertGreater(box_height, z_frame.height() * 0.10)
        self.assertLess(box_height, z_frame.height() * 0.90)
        self.assertLess(abs((left + right) / 2 - z_frame.width() / 2), 12)
        self.assertLess(abs((top + bottom) / 2 - z_frame.height() / 2), 12)
        self.assertGreater(box_width / box_height, 0.55)
        self.assertLess(box_width / box_height, 1.80)

    def test_native_quick3d_orthographic_microscope_zoom(self) -> None:
        if not RUN_QUICK3D_RENDER_TESTS:
            self.skipTest(
                "requires EASYMESH_RUN_QUICK3D_RENDER_TESTS=1 on a native "
                "Metal/D3D11/D3D12/Vulkan/OpenGL GUI runner"
            )
        self.assertIn(
            self.preview.render_backend,
            {"Metal", "Direct3D11", "Direct3D12", "Vulkan", "OpenGL"},
        )
        self.preview.set_axis_view("z")
        QTest.qWait(180)
        before = self.preview.canvas.grabFramebuffer()
        self.assertFalse(before.isNull())
        root = self.preview.canvas.rootObject()
        initial_distance = float(root.property("cameraDistance"))

        center = QPointF(self.preview.canvas.rect().center())
        self._wheel(12_000, center)
        QTest.qWait(180)
        after = self.preview.canvas.grabFramebuffer()
        self.assertFalse(after.isNull())
        self.assertEqual(after.size(), before.size())
        self.assertAlmostEqual(self.preview.camera_state[2], 100_000.0)
        self.assertAlmostEqual(
            float(root.property("cameraDistance")),
            initial_distance,
        )

        sample_positions = (
            (0.20, 0.20),
            (0.80, 0.20),
            (0.20, 0.80),
            (0.80, 0.80),
        )
        before_colors = tuple(
            before.pixelColor(int(before.width() * x), int(before.height() * y))
            for x, y in sample_positions
        )
        after_colors = tuple(
            after.pixelColor(int(after.width() * x), int(after.height() * y))
            for x, y in sample_positions
        )
        self.assertGreaterEqual(
            sum(
                _pixel_delta(old, new) >= 12
                for old, new in zip(before_colors, after_colors)
            ),
            3,
        )
        self.assertLessEqual(
            max(
                _pixel_delta(after_colors[0], color)
                for color in after_colors[1:]
            ),
            8,
        )

    def test_native_quick3d_axis_views_follow_hypermesh_headlight(self) -> None:
        if not RUN_QUICK3D_RENDER_TESTS:
            self.skipTest(
                "requires EASYMESH_RUN_QUICK3D_RENDER_TESTS=1 on a native "
                "Metal/D3D11/D3D12/Vulkan/OpenGL GUI runner"
            )
        self.assertIn(
            self.preview.render_backend,
            {"Metal", "Direct3D11", "Direct3D12", "Vulkan", "OpenGL"},
        )

        view_luminance: list[tuple[float, float]] = []
        for axis in "xyz":
            self.preview.set_axis_view(axis)
            QTest.qWait(180)
            frame = self.preview.canvas.grabFramebuffer()
            self.assertFalse(frame.isNull())
            background = frame.pixelColor(0, 0)
            samples: list[float] = []
            for y in range(0, frame.height(), 3):
                for x in range(0, frame.width(), 3):
                    color = frame.pixelColor(x, y)
                    if _pixel_delta(color, background) < 10:
                        continue
                    samples.append(
                        0.2126 * color.red()
                        + 0.7152 * color.green()
                        + 0.0722 * color.blue()
                    )
            self.assertGreaterEqual(len(samples), 100)
            samples.sort()
            view_luminance.append(
                (samples[len(samples) // 10], samples[len(samples) // 2])
            )

        # A screen-normal headlight keeps all canonical orthographic views
        # readable and prevents one axis from becoming much darker than the
        # others. Thresholds allow normal Metal/D3D/Vulkan color variation.
        self.assertGreater(min(low for low, _median in view_luminance), 70.0)
        medians = tuple(median for _low, median in view_luminance)
        self.assertLess(max(medians) - min(medians), 35.0)

    def test_native_quick3d_component_focus_is_visually_distinct(self) -> None:
        if not RUN_QUICK3D_RENDER_TESTS:
            self.skipTest(
                "requires EASYMESH_RUN_QUICK3D_RENDER_TESTS=1 on a native "
                "Metal/D3D11/D3D12/Vulkan/OpenGL GUI runner"
            )
        self.assertIn(
            self.preview.render_backend,
            {"Metal", "Direct3D11", "Direct3D12", "Vulkan", "OpenGL"},
        )

        QTest.qWait(180)
        normal = self.preview.canvas.grabFramebuffer()
        self.assertFalse(normal.isNull())
        focus_key = next(
            component.key
            for component in reversed(self.preview.scene.components)
            if not component.frozen
        )
        self.preview.set_highlighted_components((focus_key,))
        QTest.qWait(180)
        focused = self.preview.canvas.grabFramebuffer()
        self.assertFalse(focused.isNull())
        self.preview.set_highlighted_components(())
        QTest.qWait(180)
        restored = self.preview.canvas.grabFramebuffer()
        self.assertFalse(restored.isNull())
        self.assertEqual({normal.size(), focused.size(), restored.size()}, {normal.size()})

        sampled = tuple(
            (x, y)
            for y in range(0, normal.height(), 3)
            for x in range(0, normal.width(), 3)
        )
        focus_changed = sum(
            _pixel_delta(normal.pixelColor(x, y), focused.pixelColor(x, y)) >= 10
            for x, y in sampled
        )
        restore_changed = sum(
            _pixel_delta(normal.pixelColor(x, y), restored.pixelColor(x, y)) >= 5
            for x, y in sampled
        )
        self.assertGreater(focus_changed / len(sampled), 0.03)
        self.assertLess(restore_changed / len(sampled), 0.01)

    def test_native_quick3d_translucent_button_changes_selected_component(self) -> None:
        if not RUN_QUICK3D_RENDER_TESTS:
            self.skipTest("requires a native Qt Quick 3D GUI runner")
        self.preview.set_highlighted_components(
            (GENERATED_KEYS[0],), show_local_frames=True, instance_id="substrate",
        )
        camera = self.preview.camera_state
        frames = self.preview.local_coordinate_frames
        self.assertTrue(frames)

        def grab():
            QTest.qWait(180)
            frame = self.preview.canvas.grabFramebuffer()
            self.assertFalse(frame.isNull())
            return frame

        opaque = grab()
        self.preview.translucent_button.click()
        translucent = grab()
        self.assertTrue(self.preview.canvas.rootObject().property("translucentMode"))
        self.preview.translucent_button.click()
        restored = grab()
        self.assertFalse(self.preview.canvas.rootObject().property("translucentMode"))
        self.assertEqual(self.preview.camera_state, camera)
        self.assertEqual(self.preview.local_coordinate_frames, frames)
        self.assertEqual(opaque.size(), translucent.size())
        sampled = [(x, y) for y in range(2, opaque.height() - 2, 4)
                   for x in range(2, opaque.width() - 2, 4)]
        changed = sum(_pixel_delta(opaque.pixelColor(x, y), translucent.pixelColor(x, y)) >= 8
                      for x, y in sampled)
        restore_changed = sum(_pixel_delta(opaque.pixelColor(x, y), restored.pixelColor(x, y)) >= 8
                              for x, y in sampled)
        self.assertGreater(changed / len(sampled), 0.02)
        self.assertLess(restore_changed / len(sampled), 0.01)

    def test_native_quick3d_translucent_layers_use_oit(self) -> None:
        if not RUN_QUICK3D_RENDER_TESTS:
            self.skipTest(
                "requires EASYMESH_RUN_QUICK3D_RENDER_TESTS=1 on a native "
                "Metal/D3D11/D3D12/Vulkan/OpenGL GUI runner"
            )
        self.assertIn(
            self.preview.render_backend,
            {"Metal", "Direct3D11", "Direct3D12", "Vulkan", "OpenGL"},
        )
        self.assertEqual(
            self.preview.render_status,
            f"ready: {self.preview.render_backend}",
        )

        all_keys = GENERATED_KEYS + (FROZEN_KEY,)
        messages: list[str] = []

        def capture_message(_kind: object, _context: object, message: str) -> None:
            messages.append(message)

        previous_handler = qInstallMessageHandler(capture_message)

        def frame_for(hidden: frozenset[str]):
            self.preview.set_visible_components(
                key for key in all_keys if key not in hidden
            )
            QTest.qWait(180)
            frame = self.preview.canvas.grabFramebuffer()
            self.assertFalse(frame.isNull())
            return frame

        try:
            self.preview.set_translucent(False)
            opaque = frame_for(frozenset())
            self.preview.set_translucent(True)
            self.assertTrue(
                self.preview.canvas.rootObject().property("translucentMode")
            )
            both = frame_for(frozenset())
            without_upper = frame_for(frozenset((GENERATED_KEYS[3],)))
            without_underfill = frame_for(frozenset((GENERATED_KEYS[4],)))
            without_both = frame_for(
                frozenset((GENERATED_KEYS[3], GENERATED_KEYS[4]))
            )
        finally:
            self.preview.set_translucent(False)
            self.preview.set_visible_components(all_keys)
            qInstallMessageHandler(previous_handler)

        self.assertFalse(
            any(
                "Order Independent Transparency" in message
                and "disabled" in message
                for message in messages
            ),
            "\n".join(messages),
        )
        self.assertEqual(
            {
                frame.size()
                for frame in (
                    opaque,
                    both,
                    without_upper,
                    without_underfill,
                    without_both,
                )
            },
            {opaque.size()},
        )

        changed_by_translucency = 0
        overlap_witnesses = 0
        width, height = both.width(), both.height()
        for y in range(2, height - 2, 2):
            for x in range(2, width - 2, 2):
                if _pixel_delta(opaque.pixelColor(x, y), both.pixelColor(x, y)) >= 8:
                    changed_by_translucency += 1
                # At these rays both generated solids independently
                # contribute to the transparent result. This exercises the
                # actual high-UF buffers and multiple translucent layers,
                # without relying on a platform-specific expected RGB value.
                if (
                    _pixel_delta(
                        both.pixelColor(x, y),
                        without_upper.pixelColor(x, y),
                    )
                    >= 6
                    and _pixel_delta(
                        both.pixelColor(x, y),
                        without_underfill.pixelColor(x, y),
                    )
                    >= 6
                    and _pixel_delta(
                        without_upper.pixelColor(x, y),
                        without_both.pixelColor(x, y),
                    )
                    >= 6
                    and _pixel_delta(
                        without_underfill.pixelColor(x, y),
                        without_both.pixelColor(x, y),
                    )
                    >= 6
                ):
                    overlap_witnesses += 1

        self.assertGreaterEqual(changed_by_translucency, 100)
        self.assertGreaterEqual(overlap_witnesses, 20)

    def test_failed_scene_extraction_is_atomic_at_the_widget_boundary(self) -> None:
        prior_scene = self.preview.scene
        prior_revision = self.preview.scene_revision
        prior_digest = self.preview.scene_digest

        with self.assertRaises(TypeError):
            self.preview.set_compiled_geometry(object())

        self.assertIs(self.preview.scene, prior_scene)
        self.assertEqual(self.preview.scene_revision, prior_revision)
        self.assertEqual(self.preview.scene_digest, prior_digest)


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
