# EasyMesh Windows 分享版

## 三步启动

1. 安装 **64 位 x86-64 Python 3.10 或 3.12**。3.10 可以使用，不强制升级。
   安装时启用 Python Launcher（`py`）或勾选 Add Python to PATH。
2. 将 ZIP **完整解压**到当前用户可写的目录，例如 `D:\EasyMesh`，双击
   `install_windows.bat`，等待出现 `Installation complete`。
3. 双击 `run_windows.bat`。生成结果位于包内 `output` 目录。

这是 Python 应用分享包，包含源码和应用 wheel，不是免 Python 的独立 EXE。
首次安装需要联网下载依赖，不需要管理员权限或激活 PowerShell 脚本。
不要直接在压缩软件里运行，不要放进 Program Files 等只读目录。
启动时会保留一个命令行窗口用于显示错误；使用 GUI 期间不要关闭它。
更换解压位置或收到新版本时，应重新运行安装脚本。

## 依赖清单

标准文件为 `requirements.txt`，同时提供 `requirement.txt` 作为兼容入口。
二者都可以用于 `pip install -r`：

```text
gmsh==4.15.2
numpy>=1.24,<3
PySide6==6.11.2
```

pip 会自动安装 PySide6 的 Essentials、Addons、shiboken6 等间接依赖。
包内应用 wheel 是 `py3-none-any`，第三方依赖由 pip 下载对应的 Windows wheel；
包内不包含 macOS 虚拟环境。32 位 Python 不支持本分享包。

手动安装（命令提示符，在解压目录）：

```bat
py -3.10 -m venv .venv
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install --only-binary=:all: -r requirements.txt
.venv\Scripts\python.exe -m pip install --no-deps wheels\easymesh_gmsh_demo-0.2.0-py3-none-any.whl
run_windows.bat
```

自动脚本会优先使用 Python 3.10，其次 3.12，再尝试 PATH 中的 Python。
若下载失败，先检查网络、代理和 pip 源是否提供以上固定版本，再重试安装。

## 示例和工程迁移

- Layer 页默认打开 `examples/bumpcell.layer`。
- Package V2 页可以打开 `examples/package_v2/generated_box.source.json`、
  `generated_frame.source.json`、`orth_connected.source.json`，以及
  `examples/local_template_lid.source.json`。这些示例不依赖外部 Frozen MSH。
- 布局页首次使用时需选择自己的 `.loc` 及其引用的模板 MSH。
- 转移自己的工程时，连同 Source 所引用的 MSH 一起分享，并保持相对目录结构。
  在目标电脑上重新生成 Job；不要复用绑定到原电脑绝对路径的 Job。

分享包不附带开发机的既有输出、大型网格、私人工程、缓存或 `.git`。

## 环境检查和 3D 流畅度

双击 `check_windows.bat`：检查依赖、示例编译、后台 CLI，并通过中文/空格
临时路径写入和重新读取小型 Gmsh 体网格。检查过程不会覆盖用户输出。

3D 使用 Qt Quick 3D 的原生图形后端。安装后在 PowerShell 运行：

```powershell
$env:QT_QPA_PLATFORM = "windows"
$env:QSG_RHI_BACKEND = "d3d11"
Remove-Item Env:QT_QUICK_BACKEND -ErrorAction SilentlyContinue
.\.venv\Scripts\python.exe scripts/benchmark_preview_3d.py --expect-backend Direct3D11 --min-fps 30 --output preview-performance.json
```

测速窗口保持可见，约 16 秒完成。分别检查不透明和半透明模式，30 可改为 60；
使用 `--source <你的工程.source.json>` 测试实际工程。默认 High-UF 场景中的
Frozen 部件仅显示代理线框，不包含对应 MSH。

macOS 打包机的测试不能代替 Windows 实机验收。远程桌面、虚拟机、软件图形
适配器及显卡驱动会影响结果。更多已知问题见 `docs/windows-compatibility.md`。
