# Package V2 Revision 7 examples

These examples use the clean, incompatible Package V2 revision-7 contract.
Revision 1–6 Sources, Jobs, plans, reports, and output bundles are not accepted
or migrated. Create a new immutable Job from a revision-7 Source whenever the
Source, Frozen artifacts, checkout, Worker, or Gmsh runtime changes.

The normative contract is
[`../../docs/PACKAGE_V2_MIXED_TOPOLOGY_CONTRACT.md`](../../docs/PACKAGE_V2_MIXED_TOPOLOGY_CONTRACT.md).

## Strategy wire format

Every Generated Component selects exactly one strategy. The sole topology wire
authority is `mesh_control.strategy.kind`:

```json
"mesh_control": {
  "target_edge": "80um",
  "transition_distance": "120um",
  "mesh_priority": 1,
  "strategy": {
    "kind": "orthogonal_hex"
  }
}
```

The three and only three strategy values are:

- `orthogonal_hex` (Orth): package-axis-aligned `HEX8` only. Retain a candidate
  cell exactly when its centre is inside the original geometry. Interfaces
  constrain partitions, never ownership; only surviving common faces are shared.
- `structured_sweep` (Sweep): a proven translation-invariant section, with
  `TRI3 -> WEDGE6` and `QUAD4 -> HEX8`. End and lateral locks must inherit the
  same section. Its Component-local `direction` is required, and tapered
  fillets are rejected.
- `conformal_hybrid` (Hybrid): exact reuse of every authority seam and a
  body-fitted free skin, with any nonempty subset of `HEX8`, `WEDGE6`,
  `PYRAMID5`, and `TET4`. A Gmsh structured adapter may validly return only
  `HEX8/WEDGE6`. Hybrid does not create an Orth staircase. A bounded recovery
  away from an immutable staircase is permitted only within the local size
  budget and canonical-volume tolerance, and its deviation and volume evidence
  must be reported; it is not an exact canonical free surface.

Gmsh owns generated connectivity. Strategy selection never comes from a
Component or material name, package family, stack position, `UF` substring, or
union-find/component role.

A Sweep strategy has exactly this shape:

```json
"strategy": {
  "kind": "structured_sweep",
  "direction": "positive_z"
}
```

`direction` is one of `positive_x`, `negative_x`, `positive_y`, `negative_y`,
`positive_z`, or `negative_z` in the Component-local frame. It fixes the axis,
source end, and transport sign: a positive direction transports from that
axis's `min` end to its `max` end, and a negative direction does the reverse.
It is never inferred from locks, priority, stack position, or names.
`CanonicalBox` currently supports all six values,
`rectangular_frame_extrusion` supports only positive/negative Z, and a tapered
fillet supports none. A wrong direction or contradictory immutable
contact/priority constraint is rejected during preflight.

Orth alone may add `strategy.directional_near_edge` values for any of the six
Component-local directions (`positive_x`, `negative_x`, `positive_y`,
`negative_y`, `positive_z`, `negative_z`). Omitted directions use that
Component's `target_edge`. Orth may also provide a three-coordinate local
`strategy.partition_origin` when boundary constraints do not already seed the
partition. Side partitions remain independent and share only their common
edge authority. Each directional value controls spacing normal to the named
side; it is not a promise that all tangential edges on that side or seam have
the same length. An immutable Frozen trace may therefore retain coarser
tangential edges.

A Box and a multi-Solid Component may use six independent signed sizes. Fillet uses
an eight-block rectangular annulus and size-based or inherited Z levels, with
no automatic topology-driven layer changes. Edge/point-only contacts,
disconnected cells and truncated tips warn without blocking export; affected
cells belong to `ORTH_MESH_WARNINGS` in MSH and CDB. The execution report saves
the complete candidate partition and assignment mask in
`orthogonal_candidate_grids`, including unassigned cells for future
complementary geometry reuse.

See [connected Orth examples](ORTH_CONNECTED.md) for a multi-Solid Source and
reproducible compatible/conflicting immutable ports (v29 / worker-3.19.1).

## Included Sources

### `generated_box.source.json`

A small generated-only Hybrid Box for fast Source/compile/Job/Worker smoke
testing. Its Source revision is 6 and its strategy is selected only by:

```json
"strategy": {"kind": "conformal_hybrid"}
```

### `generated_frame.source.json`

A parameterized generated-only rectangular frame with derived opening sizes
and instance overrides. It uses `structured_sweep` with `direction=positive_z`,
so its section must remain translation invariant along local +Z and its
complete end/lateral boundary partitions must be compatible.

### `../../output/package_v2_high_uf.source.json`

This is the larger revision-6 mixed-strategy integration input. It imports
`output/bumps_connected.msh` plus its parameters/report sidecars as one audited
Frozen source, then declares six Generated Components:

| Component | Priority | Strategy | Direction |
| --- | ---: | --- | --- |
| `underfill_corner_core` | 1 | `orthogonal_hex` | — |
| `underfill_fillet` | 2 | `conformal_hybrid` | — |
| `ring_upper` | 3 | `structured_sweep` | `negative_z` |
| `ring_lower` | 4 | `structured_sweep` | `negative_z` |
| `substrate` | 5 | `conformal_hybrid` | — |
| `added_si` | 6 | `conformal_hybrid` | — |

All six currently use `target_edge=80um` and
`transition_distance=120um`. The Orth corner core additionally sets
`positive_x`, `negative_x`, `positive_y`, and `negative_y` to `5um`. These are
the four side-normal requirements, not a request to split every inherited
Frozen tangential edge to 5 um. All five explicit Frozen/Generated matches use
the sole interface mode `preserve_interface_trace`. Frozen nodes, facets,
volume connectivity, element kinds, and ownership remain immutable; only the
complete matched interface trace is reused. No Frozen volume elements or axis
propagation exist in revision 6.

The Source's advanced interface tolerance is `0.01um` (`1e-5 mm`). It is used
only for same-point/same-plane/same-boundary and declared-trace predicates. It
does not merge arbitrary nearby nodes, move Frozen nodes, bridge a gap, or
relax quality.

The following counts are historical revision-6 evidence from one
`worker-3.0.0` run. Reopening that mesh produced 306,407 nodes and 422,660
elements: `182456 HEX8 + 219536 WEDGE6 +
1536 PYRAMID5 + 19132 TET4`. Its canonical numbered-mesh SHA-256 is
`9f617c23932aab1b193820c74741659bef3b88eddd37e5da29d237b7ba61b4df`.
The actual minima are `minDetJac=4.405258987e-10`, `minSJ=0.605876292`,
`minSICN=0.028631302`, and `minSIGE=0.091772989`. The raw all-metrics result is
false only because all 23,712 cells of the Orth corner core are verified
Cartesian HEX8 with an aspect-ratio SICN exemption; the strategy-aware and
summary floor results are both true.

The current execution identity is `worker-3.14.0 / role-free-mixed-v24`, with
worker report schema `easymesh-package-v2-worker-report-v7` and role-free
execution schema `easymesh-package-v2-role-free-mixed-execution-v6`. Orth-to-
Orth retains independent per-side partitions. Orth-to-Hybrid uses the locked-
base Gmsh QuadTri route only when canonical geometry, a complete Cartesian
QUAD base lock, and the actual Orth producer topology all prove eligibility.
Component names, materials, and stack roles are not inputs to that decision.

The four 5 um values do not imply an all-5-um seam. Frozen may impose a coarser
tangential partition, which remains immutable. Consequently the historical
1,996-QUAD endpoint is not a current golden count, and maximum seam-edge length
is not by itself the four-direction acceptance test. Any v11/v12 Job or output
whose Source, plan, runtime identity, or artifact hash differs must be rebuilt.

Any CDB remains an independent derived artifact and is valid only when its
source-mesh hash matches the accepted MSH. An all-Hybrid high-UF variant has
not been revalidated with v13 and is not an accepted result. Earlier failures
are historical observations; the Orth-to-Hybrid route must not be described as
an all-Hybrid fix.

The locked-base route preserves every authority base node and QUAD exactly,
asks Gmsh for one first-layer HEX owner per QUAD, applies its official QuadTri
transition, and uses Gmsh for the residual volume. Its report must include the
applied method, adapter and recovery heights, maximum and allowed radial
deviation, canonical/materialized volume error, interface ownership, family
counts, and quality minima.

Compatible planar mixed-TRI/QUAD partial Sweep ends now use a Gmsh-owned
completion path; unsupported or ambiguous partial topology still fails closed.
Multiply-locked Hybrid currently has only a narrowly audited axis-aligned Box retry using
Gmsh's `Mesh.OptimizePyramids=1`. The real `added_si` focused case produced
`16878 TET4 + 1392 PYRAMID5`, zero folds, relative volume error `2.64e-15`, and
`minSICN=0.05759`; that evidence does not generalize to arbitrary complex
shells.

## Running an example

Create a locally bound immutable Job for the high-UF Source:

```bash
python scripts/create_package_v2_demo_job.py
```

Then run that Job:

```bash
easymesh-demo --package-v2-job output/package_v2_high_uf.job.json
```

Generate a Job for a smaller Source by passing explicit paths:

```bash
python scripts/create_package_v2_demo_job.py \
  --source examples/package_v2/generated_box.source.json \
  --job output/generated_box.job.json \
  --output output/generated_box.msh \
  --job-id generated-box-r6
```

The default high-UF Job must be recreated against the v13 runtime and the
current four-direction Source before it is current. A Job can fail closed if its Source,
Frozen bundle, checkout, worker, or Gmsh identity changes, or if a requested
mesh cannot satisfy its quality contract. Such a failure is not permission to
change strategy, override Orth centre ownership, approximate Hybrid geometry with a
staircase, partially sweep an inherited section, lower quality thresholds, or
reuse an older artifact.

## GUI authoring

Open a `.source.json` in the **Package V2** tab. The Mesh editor writes the
three-way strategy selection into `strategy.kind`; Sweep also requires its
six-value direction selector, while only Orth exposes six directional
near-edge overrides and an optional partition origin. The Interfaces editor
exposes only `preserve_interface_trace`, and the advanced geometry panel edits
the Package-global absolute interface tolerance.

Every accepted edit recompiles the complete Source and invalidates its old Job
and report. Do not put a `.source.json` in the immutable Job input field; create
a new Job from the Source first.

## Acceptance evidence

The Worker must reopen the written MSH in an empty model and recompute actual
connectivity evidence. A successful report must prove:

- element kinds allowed by each selected strategy;
- exact shared node/facet keys and complete declared contact;
- immutable Frozen traces;
- no cracks, overlaps, duplicate cells, unintended duplicate nodes, folds,
  non-positive volumes, or non-manifold faces;
- complete Component/material ownership and volume closure, including both
  materialized and canonical-volume evidence for a bounded-recovery Hybrid;
- positive Jacobian and positive `minSICN`, plus `minSJ >= 0.03` and
  `minSIGE >= 0.03`, for every cell; and
- `minSICN >= 0.03` for Frozen, Sweep, ordinary Hybrid cells, and all other
  unproved cells. Generated Orth may report a lower but positive raw SICN only
  when every cell is geometrically verified as package-axis Cartesian HEX8.
  A Hybrid first-layer HEX may use the same exception only when it owns exactly
  one contracted shared QUAD opposite a real Cartesian Orth producer and is
  itself geometrically Cartesian. Continuation provenance alone is not
  sufficient. Sheared, twisted, folded, non-Cartesian, zero-SICN, or
  negative-SICN cells are never covered.

The report always retains the whole-mesh raw `quality.minimum_sicn`.
`quality.raw_all_metrics_floor_met` is only the literal three-metric comparison
and may be false for an accepted Cartesian Orth aspect-ratio case;
`quality.strategy_aware_floor_met` and its `quality.floor_met` summary alias
carry the actual acceptance result. The Orth exemption
entries identify the Component and include its minimum SICN, element count,
required floor, and Cartesian proof.

For Orth, analytic sloped coverage is diagnostic evidence rather than a gate;
the surviving physical staircase is authoritative. A requested strategy token,
preview image, pre-reopen count, or historical report is never a substitute for
these audits.
