# Orth 多 Solid 与共同接口

打开 [orth_connected.source.json](orth_connected.source.json)，从 Source 创建新 Job 后生成。`main` 包含两个相接 Box；`side_pad` 使用另一材料，其小接触面跨两个 Box。结果是严格正交 HEX8，接口共享完整 QUAD，每个体单元只属于一个 Component/material。

几何树继续支持 Component 折叠、展开子 Solid、添加、删除和归属/材料编辑。Component 的六方向尺寸及 Origin 由全部子 Solid 共用；编辑后创建新 Job。断开的 Solid 不跨空气继承 seed，只有点/边接触不当作面接口。

在 Source 中，正交并集可写为 `{"id":"body","kind":"union","children":[Box或Frame,...]}`；差集使用 `{"id":"body","kind":"difference","base":Box或Frame,"cutters":[Box或Frame,...]}`。每个嵌套几何仍包含自己的 `id` 和完整参数。只支持 Box/Frame 构成的正交布尔几何；Fillet 保持独立 Solid 的中心筛选语义。独立追加且正体积重叠的 Solid 会报错，应改用 Union 表达合法并集。

要生成可复现的冲突 Source 和固定网格资产，在仓库根目录运行：

```sh
PYTHONPATH=src .venv/bin/python scripts/create_orth_conflict_example.py /tmp/orth-conflict
```

然后打开生成的 `/tmp/orth-conflict/conflict.source.json` 并创建新 Job。Orth Box 的前后两个非 Orth 固定接口分别在 X=0.5 mm 和 X=0.4 mm 分段；两者不能成为同一套严格正交网格。错误会包含 `front`、`back`、X 方向和冲突坐标，明确提示生成中止、没有可导出的新完整网格。此前已验收的文件不被覆盖。

使用另一目录生成成功的对照案例：

```sh
PYTHONPATH=src .venv/bin/python scripts/create_orth_conflict_example.py /tmp/orth-compatible --compatible
```

此时两个固定接口都在 X=0.5 mm 分段，可以完成写出与重开审计。生成器把 Frozen 资产绑定到当前目录；移动目录后重新运行生成器并创建 Job。

新 Orth 双前锋规则：总长 2.2、两侧目标 1 保留 `1 + 0.2 + 1`；总长 1.5 得到 `0.75 + 0.75`；总长 0.8、目标 0.4/0.6 得到 `0.32 + 0.48`。真实几何断点和固定接口始终不动。Fillet 仍是阶梯近似；顶部细节/断连警告与固定接口冲突错误分开显示。
