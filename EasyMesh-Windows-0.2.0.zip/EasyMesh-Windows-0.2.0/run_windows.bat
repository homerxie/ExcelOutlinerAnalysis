@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
if not exist ".venv\Scripts\python.exe" (
    echo Run install_windows.bat first.
    pause
    exit /b 1
)
set "EASYMESH_HOME=%CD%"
".venv\Scripts\python.exe" run_demo.py
if errorlevel 1 (
    echo EasyMesh stopped with an error. Keep the message above for troubleshooting.
    pause
    exit /b 1
)
