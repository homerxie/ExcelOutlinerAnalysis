# Windows 兼容性检查（2026-09-15）

## 结论与修复

程序已有基于 pathlib 的路径处理、UTF-8 worker 环境、Windows 文件锁、spawn
子进程和 Qt Quick 3D/RHI 渲染。此次检查补充了以下修复与验收手段：

- Windows GUI 使用 `pythonw.exe` 时，后台任务改用相邻 `python.exe`，确保接触
  服务输入输出管道和网格日志可用；缺失解释器时明确报错。网格 worker 使用
  `CREATE_NO_WINDOW` 和 `DEVNULL` 输入，避免依赖 GUI 进程的控制台句柄。
- 旋转、平移、缩放仅更新五个相机属性，不再逐次刷新坐标轴、局部坐标列表、
  调色板和场景状态；相机操作不重建几何缓冲。
- Gmsh 测速脚本不再无条件导入 Windows 不存在的 `resource`；不支持的内存
  指标返回 null，并将 Linux 的 KiB 转为 bytes。
- Windows CI 增加 Python 3.12，以及从真实 `pythonw` 发起中文/空格路径管道
  交互的测试。原生 D3D11 图像回归之后运行可下载的帧率测量；前面测试失败
  时也继续提供图形诊断。

Python 文档明确指出无控制台 GUI / pythonw 的标准流可能为 None：
[Python 标准流说明](https://docs.python.org/3.12/library/sys.html#sys.stdin)。
Qt 默认后端和 3D 条件见 [Qt Quick 3D 图形要求](https://doc.qt.io/qt-6/qtquick3d-requirements.html)。

## 已完成的本地验证

测试环境为 macOS 26.6.2 / ARM64、Python 3.10.11、Qt 6.11.2。

| 检查 | 结果 |
| --- | --- |
| runtime、preview、local-frame、输出文件、CLI、spawn candidate | 109 项，102 通过、7 跳过 |
| 原生 Metal preview widget 回归（含图像检查） | 19 项，18 通过、1 跳过 |
| GUI、V2 editor、contact-preview 扩展回归 | 129 项，126 通过、3 失败，见下节 |
| Designer 生成代码一致性 | 通过 |
| offscreen 运行原生测速 | 正确拒绝 Software 后端，返回失败 |
| Gmsh 测速脚本 CLI 导入 | 通过 |

原生测速：High-UF 示例，7 个 Component、336 个三角面；1280×800 窗口，
实际 canvas 1264×722 逻辑像素，设备像素比 2。相机持续旋转、平移、缩放，
每种模式预热后采样 5 次。场景构建 15.5 ms；不透明模式中位数 62 FPS，
半透明模式 63 FPS，两者最低采样均为 62 FPS。
数据来自 [Qt RenderStats](https://doc.qt.io/qt-6/qml-qtquick3d-renderstats.html)
每秒帧数，不能当作显示器刷新率或纯 GPU 计时。

这只证明本机及此场景可流畅预览；此次未执行 Windows 机器或 Windows CI，
也未测试全部网格生成组合。不能据此承诺目标 Windows 机器已经通过验收。

## 扩展回归中现存的三个失败

在内存中恢复此次修改之前的 worker 和相机行为后，三项仍全部失败；验证过程
未覆盖或回退工作区原有修改。具体失败为：

- `test_layer_workspace_keeps_a_full_height_preview_at_common_sizes`：1024×720
  切换到布局页后，生成按钮的 visibleRegion 为空。
- `test_layout_source_lists_normalized_structured_hex_regions`：示例区域尺寸
  实际为 25，测试固定预期为 5。
- `test_v4_layout_report_renders_and_enforces_structured_hex_contract`：报告
  实际 XY QUAD/层为 112，测试固定预期为 400。

这些问题未在本次 Windows worker / 3D 修复中改动；因此不能报告全套 GUI
测试通过。后两项涉及现有示例与固定断言不一致，第一项仍需单独核查小窗口布局。

## Windows 实机验收

按 README 安装后，在源码目录 PowerShell 运行：

```powershell
$env:QT_QPA_PLATFORM = "windows"
$env:QSG_RHI_BACKEND = "d3d11"
Remove-Item Env:QT_QUICK_BACKEND -ErrorAction SilentlyContinue
.\.venv\Scripts\python.exe scripts/benchmark_preview_3d.py --expect-backend Direct3D11 --min-fps 30 --output preview-performance.json
```

窗口保持可见且不要最小化。将 30 改为 60 可采用更高目标；使用
`--source <工程.source.json>` 验证实际大型工程。托管 CI 可能使用 D3D 软件适配器，
只检查有实际帧输出并保留报告，性能阈值应在目标电脑验证。
