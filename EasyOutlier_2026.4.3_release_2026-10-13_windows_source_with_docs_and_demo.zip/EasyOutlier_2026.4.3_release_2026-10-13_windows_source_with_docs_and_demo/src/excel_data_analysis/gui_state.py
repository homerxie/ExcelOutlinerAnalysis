from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile
from typing import Any
import zlib

from .analysis_snapshot_storage import cleanup_after_commit, persist_reference, resolve_reference
from .tsk_result_state import TSK_DISPLAY_FORMAT, decode_tsk_result, encode_tsk_result
from .tsk_run_history import _without_history, decode_history, encode_history


GUI_STATE_FILENAME = ".excel_data_analysis_gui_state.json"
TSK_HISTORY_RESULT_REFERENCE_FORMAT = "tsk-history-result-ref-v1"


def _history_entry(history, key):
    if (not isinstance(history, dict) or not isinstance(history.get("entries"), list)
            or not isinstance(key, str) or not key):
        return None
    return next((entry for entry in history["entries"]
                 if isinstance(entry, dict) and entry.get("key") == key
                 and isinstance(entry.get("result"), dict)), None)


def gui_state_path(storage_path: str | Path) -> Path:
    return Path(storage_path) / GUI_STATE_FILENAME


def save_gui_state(
    storage_path: str | Path,
    payload: dict[str, Any],
) -> Path:
    analysis_reference = None
    results = payload.get("current_results")
    if isinstance(results, dict):
        results = dict(results)
        if results.get("analysis_snapshot") is not None:
            analysis_reference = persist_reference(
                storage_path, results["analysis_snapshot"], results.get("outlier_export_result_id")
            )
            results["analysis_snapshot"] = analysis_reference
        history = results.get("tsk_history")
        original_active = _history_entry(history, history.get("active_key")) if isinstance(history, dict) else None
        encoded_active = None
        if "tsk_history" in results:
            results["tsk_history"] = encode_history(history)
            encoded_active = _history_entry(results["tsk_history"], results["tsk_history"].get("active_key"))
        for key in ("tsk_result", "tsk_live_result"):
            current = results.get(key)
            if not isinstance(current, dict):
                continue
            # Completed runs normally share this exact object with history.
            # Reuse its encoding before allocating another compact tree/JSON.
            same_source = (encoded_active is not None and original_active is not None
                           and current is original_active["result"]
                           and _without_history(current) is current)
            encoded = (encoded_active["result"] if same_source else
                       encode_tsk_result(current, include_fit_context=True))
            if encoded_active is not None and encoded == encoded_active["result"]:
                results[key] = {"format": TSK_HISTORY_RESULT_REFERENCE_FORMAT,
                                "key": encoded_active["key"]}
            else:
                results[key] = encoded
        payload = {**payload, "current_results": results}
    target = gui_state_path(storage_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=target.parent,
                                         prefix=".gui-state-", suffix=".tmp", delete=False) as handle:
            temporary = Path(handle.name)
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    cleanup_after_commit(storage_path, analysis_reference)
    return target


def load_gui_state(
    storage_path: str | Path,
) -> dict[str, Any] | None:
    target = gui_state_path(storage_path)
    if not target.exists():
        return None
    payload = json.loads(target.read_text(encoding="utf-8"))
    results = payload.get("current_results")
    if isinstance(results, dict) and results.get("analysis_snapshot") is not None:
        try:
            results["analysis_snapshot"] = resolve_reference(
                storage_path, results["analysis_snapshot"], result_id=results.get("outlier_export_result_id")
            )
            results.pop("analysis_snapshot_restore_error", None)
        except (ValueError, OSError, TypeError) as exc:
            results["analysis_snapshot"] = None
            results["analysis_snapshot_restore_error"] = {
                "code": getattr(exc, "code", "snapshot_unavailable"), "message": str(exc),
            }
    active_encoded = active_decoded = None
    if isinstance(results, dict) and "tsk_history" in results:
        history = results["tsk_history"]
        active_entry = _history_entry(history, history.get("active_key")) if isinstance(history, dict) else None
        active_encoded = active_entry["result"] if active_entry is not None else None

        def restore_history_result(encoded, *, include_fit_context):
            nonlocal active_decoded
            # Different runs remain independent, even if their contents match.
            result = decode_tsk_result(encoded, include_fit_context=include_fit_context)
            if encoded is active_encoded:
                active_decoded = result
            return result

        results["tsk_history"], errors = decode_history(history, decode_result=restore_history_result)
        if errors:
            results["tsk_history_restore_errors"] = errors
    if isinstance(results, dict):
        for key in ("tsk_result", "tsk_live_result"):
            if not isinstance(results.get(key), dict):
                continue
            try:
                encoded = results[key]
                if encoded.get("format") == TSK_HISTORY_RESULT_REFERENCE_FORMAT:
                    if set(encoded) != {"format", "key"}:
                        raise ValueError("Invalid saved TSK history result reference")
                    entry = _history_entry(results.get("tsk_history"), encoded.get("key"))
                    if entry is None:
                        raise ValueError("Saved TSK history result reference is unavailable")
                    results[key] = entry["result"]
                elif (active_decoded is not None and encoded.get("format") == TSK_DISPLAY_FORMAT
                      and encoded == active_encoded):
                    # Legacy files saved the same active result twice. Preserve
                    # any export-only variants that history itself strips off.
                    results[key] = active_decoded
                else:
                    results[key] = decode_tsk_result(encoded, include_fit_context=True)
            except (ValueError, OSError, EOFError, KeyError, TypeError, zlib.error) as exc:
                # A damaged result must not prevent opening the database itself.
                results[key] = None
                results[key + "_restore_error"] = str(exc)
    return payload
