"""Stable all-instance label reservations, independent of the visible viewport."""
from __future__ import annotations

import math
from statistics import median

from PySide6.QtCore import QPointF, QRectF


class RectIndex:
    def __init__(self, cell_size=64.):
        self.cell_size = cell_size
        self.buckets = {}

    def cells(self, rect):
        for x in range(math.floor(rect.left() / self.cell_size), math.floor(rect.right() / self.cell_size) + 1):
            for y in range(math.floor(rect.top() / self.cell_size), math.floor(rect.bottom() / self.cell_size) + 1):
                yield x, y

    def add(self, rect, owner=None):
        for cell in self.cells(rect):
            self.buckets.setdefault(cell, []).append((rect, owner))

    def intersects(self, rect, ignore=None):
        return any((ignore is None or owner != ignore) and rect.intersects(other)
                   for cell in self.cells(rect) for other, owner in self.buckets.get(cell, ()))


def _spiral(x, y):
    """Infinite empty-slot search; each coincident anchor shares its cursor."""
    yield x, y
    radius = 1
    while True:
        for dx in range(-radius, radius + 1):
            yield x + dx, y - radius
            yield x + dx, y + radius
        for dy in range(-radius + 1, radius):
            yield x - radius, y + dy
            yield x + radius, y + dy
        radius += 1


def compact_label_scale(anchors, sizes, maximum=.65, *, vertical=False):
    """Estimate text size from typical spacing, not the closest pair globally.

    An isolated crowded pair must not make the entire map microscopic. Use
    median nearest-neighbor distance in label-sized cells; the packer handles
    local conflicts and coincident coordinates without hiding any labels.
    """
    from scipy.spatial import cKDTree

    width = max((width for width, height in sizes if height), default=1.)
    height = max((height for width, height in sizes if height), default=1.)
    width = max(width + 6, width / 2 + 15) if vertical else width + 32
    height = height + 32 if vertical else max(height + 6, height / 2 + 15)
    points = sorted({(point.x() / width, point.y() / height) for point in anchors})
    if len(points) < 2:
        return maximum
    distances, _ = cKDTree(points).query(points, k=2, p=math.inf)
    return min(maximum, float(median(distances[:, 1])))


def pack_label_rectangles(anchors, sizes, *, overlay=False, spacing_scale=1., preferred_axis="horizontal",
                          point_radius=12.):
    """Retain every nonempty label, reserving disjoint padded rectangles.

    Try nearby positions first. A shared grid of vacant slots provides a
    guaranteed fallback, without repeatedly searching from zero for hundreds
    of coincident instances. Overlay ignores only the label's own point.
    """
    cell_size = max(64., point_radius * 2, max((max(size) for size in sizes), default=1.))
    occupied, point_boxes = RectIndex(cell_size), RectIndex(cell_size)
    padding, radius = 3 * spacing_scale, point_radius
    gap = radius + 4 * spacing_scale
    point_owners = {}
    for index, point in enumerate(anchors):
        key = point.x(), point.y()
        point_owners[key] = None if key in point_owners else index
    # Duplicate coordinates share one obstacle. Otherwise every nearby query
    # scans thousands of identical point boxes before reaching a placed label.
    for (x, y), owner in point_owners.items():
        point_boxes.add(QRectF(x - radius, y - radius, radius * 2, radius * 2), owner)
    # Tiny text beside a large coordinate-sized point must not search millions
    # of microscopic grid slots just to get past the point's obstacle.
    cell_width = max(radius, max((width for width, height in sizes if height), default=1.) + 4 * padding)
    cell_height = max(radius, max((height for width, height in sizes if height), default=1.) + 4 * padding)
    cursors, blocked_cells, result = {}, set(), []
    for index, (point, (width, height)) in enumerate(zip(anchors, sizes)):
        if not height:
            result.append(None)
            continue
        horizontal = [(gap, -height / 2), (-width - gap, -height / 2)]
        vertical = [(-width / 2, -height - gap), (-width / 2, gap)]
        # Stay on the point's row or column; use the roomier axis first.
        candidates = vertical + horizontal if preferred_axis == "vertical" else horizontal + vertical
        if overlay:
            candidates.insert(0, (-width / 2, -height / 2))
        region = None
        for dx, dy in candidates:
            candidate = QRectF(point.x() + dx, point.y() + dy, width, height)
            padded = candidate.adjusted(-padding, -padding, padding, padding)
            if not occupied.intersects(padded) and not point_boxes.intersects(padded, ignore=index if overlay else None):
                region = candidate
                break
        if region is None:
            origin = (round(point.x() / cell_width), round(point.y() / cell_height))
            cursor = cursors.setdefault(origin, _spiral(*origin))
            for cell in cursor:
                if cell in blocked_cells:
                    continue
                blocked_cells.add(cell)
                center = QPointF(cell[0] * cell_width, cell[1] * cell_height)
                # Test the full slot so rejection can be shared across labels.
                slot = QRectF(center.x() - (cell_width - 2 * padding) / 2,
                              center.y() - (cell_height - 2 * padding) / 2,
                              cell_width - 2 * padding, cell_height - 2 * padding)
                if not occupied.intersects(slot) and not point_boxes.intersects(slot):
                    region = QRectF(center.x() - width / 2, center.y() - height / 2, width, height)
                    break
        occupied.add(region.adjusted(-padding, -padding, padding, padding))
        result.append(region)
    return result
