# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_coordinate_window.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog,
    QDoubleSpinBox, QGridLayout, QHBoxLayout, QLabel,
    QPushButton, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)

from excel_data_analysis.gui.coordinate_size_spinbox import CoordinateSizeSpinBox
from excel_data_analysis.gui.tsk_coordinate_plot import TskCoordinatePlot

class Ui_TskCoordinateWindowForm(object):
    def setupUi(self, TskCoordinateWindowForm):
        if not TskCoordinateWindowForm.objectName():
            TskCoordinateWindowForm.setObjectName(u"TskCoordinateWindowForm")
        TskCoordinateWindowForm.resize(1120, 800)
        TskCoordinateWindowForm.setMinimumSize(QSize(760, 640))
        TskCoordinateWindowForm.setModal(False)
        self.windowLayout = QVBoxLayout(TskCoordinateWindowForm)
        self.windowLayout.setSpacing(8)
        self.windowLayout.setObjectName(u"windowLayout")
        self.windowLayout.setContentsMargins(12, 12, 12, 12)
        self.contextLayout = QHBoxLayout()
        self.contextLayout.setObjectName(u"contextLayout")
        self.groupLabel = QLabel(TskCoordinateWindowForm)
        self.groupLabel.setObjectName(u"groupLabel")

        self.contextLayout.addWidget(self.groupLabel)

        self.groupComboBox = QComboBox(TskCoordinateWindowForm)
        self.groupComboBox.setObjectName(u"groupComboBox")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.groupComboBox.sizePolicy().hasHeightForWidth())
        self.groupComboBox.setSizePolicy(sizePolicy)
        self.groupComboBox.setMinimumContentsLength(10)
        self.groupComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)

        self.contextLayout.addWidget(self.groupComboBox)

        self.contextLabel = QLabel(TskCoordinateWindowForm)
        self.contextLabel.setObjectName(u"contextLabel")
        self.contextLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.contextLabel.setWordWrap(False)

        self.contextLayout.addWidget(self.contextLabel)


        self.windowLayout.addLayout(self.contextLayout)

        self.selectionLayout = QHBoxLayout()
        self.selectionLayout.setObjectName(u"selectionLayout")
        self.chainLabel = QLabel(TskCoordinateWindowForm)
        self.chainLabel.setObjectName(u"chainLabel")

        self.selectionLayout.addWidget(self.chainLabel)

        self.chainComboBox = QComboBox(TskCoordinateWindowForm)
        self.chainComboBox.setObjectName(u"chainComboBox")
        sizePolicy.setHeightForWidth(self.chainComboBox.sizePolicy().hasHeightForWidth())
        self.chainComboBox.setSizePolicy(sizePolicy)
        self.chainComboBox.setMinimumContentsLength(10)
        self.chainComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)

        self.selectionLayout.addWidget(self.chainComboBox)

        self.followCheckBox = QCheckBox(TskCoordinateWindowForm)
        self.followCheckBox.setObjectName(u"followCheckBox")
        self.followCheckBox.setChecked(True)

        self.selectionLayout.addWidget(self.followCheckBox)

        self.focusButton = QPushButton(TskCoordinateWindowForm)
        self.focusButton.setObjectName(u"focusButton")
        self.focusButton.setEnabled(False)

        self.selectionLayout.addWidget(self.focusButton)


        self.windowLayout.addLayout(self.selectionLayout)

        self.viewLayout = QHBoxLayout()
        self.viewLayout.setObjectName(u"viewLayout")
        self.outlineLabel = QLabel(TskCoordinateWindowForm)
        self.outlineLabel.setObjectName(u"outlineLabel")

        self.viewLayout.addWidget(self.outlineLabel)

        self.outlineComboBox = QComboBox(TskCoordinateWindowForm)
        self.outlineComboBox.addItem("")
        self.outlineComboBox.addItem("")
        self.outlineComboBox.addItem("")
        self.outlineComboBox.setObjectName(u"outlineComboBox")

        self.viewLayout.addWidget(self.outlineComboBox)

        self.labelsCheckBox = QCheckBox(TskCoordinateWindowForm)
        self.labelsCheckBox.setObjectName(u"labelsCheckBox")
        self.labelsCheckBox.setChecked(True)

        self.viewLayout.addWidget(self.labelsCheckBox)

        self.labelLayoutButton = QPushButton(TskCoordinateWindowForm)
        self.labelLayoutButton.setObjectName(u"labelLayoutButton")

        self.viewLayout.addWidget(self.labelLayoutButton)

        self.toolbarSpacer = QSpacerItem(16, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.viewLayout.addItem(self.toolbarSpacer)

        self.zoomOutButton = QPushButton(TskCoordinateWindowForm)
        self.zoomOutButton.setObjectName(u"zoomOutButton")
        self.zoomOutButton.setEnabled(False)

        self.viewLayout.addWidget(self.zoomOutButton)

        self.zoomInButton = QPushButton(TskCoordinateWindowForm)
        self.zoomInButton.setObjectName(u"zoomInButton")
        self.zoomInButton.setEnabled(False)

        self.viewLayout.addWidget(self.zoomInButton)

        self.resetButton = QPushButton(TskCoordinateWindowForm)
        self.resetButton.setObjectName(u"resetButton")

        self.viewLayout.addWidget(self.resetButton)


        self.windowLayout.addLayout(self.viewLayout)

        self.labelOptionsLayout = QHBoxLayout()
        self.labelOptionsLayout.setSpacing(8)
        self.labelOptionsLayout.setObjectName(u"labelOptionsLayout")
        self.labelModeLabel = QLabel(TskCoordinateWindowForm)
        self.labelModeLabel.setObjectName(u"labelModeLabel")

        self.labelOptionsLayout.addWidget(self.labelModeLabel)

        self.labelModeComboBox = QComboBox(TskCoordinateWindowForm)
        self.labelModeComboBox.addItem("")
        self.labelModeComboBox.addItem("")
        self.labelModeComboBox.setObjectName(u"labelModeComboBox")

        self.labelOptionsLayout.addWidget(self.labelModeComboBox)

        self.labelPositionLabel = QLabel(TskCoordinateWindowForm)
        self.labelPositionLabel.setObjectName(u"labelPositionLabel")
        self.labelPositionLabel.setEnabled(False)

        self.labelOptionsLayout.addWidget(self.labelPositionLabel)

        self.labelPositionComboBox = QComboBox(TskCoordinateWindowForm)
        self.labelPositionComboBox.addItem("")
        self.labelPositionComboBox.addItem("")
        self.labelPositionComboBox.setObjectName(u"labelPositionComboBox")
        self.labelPositionComboBox.setEnabled(False)

        self.labelOptionsLayout.addWidget(self.labelPositionComboBox)

        self.labelOptionsSpacer = QSpacerItem(0, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.labelOptionsLayout.addItem(self.labelOptionsSpacer)


        self.windowLayout.addLayout(self.labelOptionsLayout)

        self.labelSizeLayout = QHBoxLayout()
        self.labelSizeLayout.setSpacing(8)
        self.labelSizeLayout.setObjectName(u"labelSizeLayout")
        self.initialLabelSizeLabel = QLabel(TskCoordinateWindowForm)
        self.initialLabelSizeLabel.setObjectName(u"initialLabelSizeLabel")
        self.initialLabelSizeLabel.setEnabled(False)

        self.labelSizeLayout.addWidget(self.initialLabelSizeLabel)

        self.initialLabelSizeSpinBox = CoordinateSizeSpinBox(TskCoordinateWindowForm)
        self.initialLabelSizeSpinBox.setObjectName(u"initialLabelSizeSpinBox")
        self.initialLabelSizeSpinBox.setEnabled(False)
        self.initialLabelSizeSpinBox.setMinimumSize(QSize(120, 0))
        self.initialLabelSizeSpinBox.setMaximumSize(QSize(120, 16777215))
        self.initialLabelSizeSpinBox.setKeyboardTracking(False)
        self.initialLabelSizeSpinBox.setDecimals(20)
        self.initialLabelSizeSpinBox.setProperty(u"minimumText", u"1e-20")
        self.initialLabelSizeSpinBox.setMaximum(1000000000000.000000000000000)
        self.initialLabelSizeSpinBox.setSingleStep(0.001000000000000)
        self.initialLabelSizeSpinBox.setValue(0.010416666666667)

        self.labelSizeLayout.addWidget(self.initialLabelSizeSpinBox)

        self.maximumLabelSizeLabel = QLabel(TskCoordinateWindowForm)
        self.maximumLabelSizeLabel.setObjectName(u"maximumLabelSizeLabel")
        self.maximumLabelSizeLabel.setEnabled(False)

        self.labelSizeLayout.addWidget(self.maximumLabelSizeLabel)

        self.maximumLabelSizeSpinBox = QDoubleSpinBox(TskCoordinateWindowForm)
        self.maximumLabelSizeSpinBox.setObjectName(u"maximumLabelSizeSpinBox")
        self.maximumLabelSizeSpinBox.setEnabled(False)
        self.maximumLabelSizeSpinBox.setKeyboardTracking(False)
        self.maximumLabelSizeSpinBox.setDecimals(1)
        self.maximumLabelSizeSpinBox.setMinimum(0.100000000000000)
        self.maximumLabelSizeSpinBox.setMaximum(48.000000000000000)
        self.maximumLabelSizeSpinBox.setSingleStep(0.100000000000000)
        self.maximumLabelSizeSpinBox.setValue(18.000000000000000)

        self.labelSizeLayout.addWidget(self.maximumLabelSizeSpinBox)

        self.zoomRangeLabel = QLabel(TskCoordinateWindowForm)
        self.zoomRangeLabel.setObjectName(u"zoomRangeLabel")

        self.labelSizeLayout.addWidget(self.zoomRangeLabel)

        self.labelSizeSpacer = QSpacerItem(0, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.labelSizeLayout.addItem(self.labelSizeSpacer)


        self.windowLayout.addLayout(self.labelSizeLayout)

        self.pointSizeLayout = QHBoxLayout()
        self.pointSizeLayout.setSpacing(8)
        self.pointSizeLayout.setObjectName(u"pointSizeLayout")
        self.pointWorldDiameterLabel = QLabel(TskCoordinateWindowForm)
        self.pointWorldDiameterLabel.setObjectName(u"pointWorldDiameterLabel")

        self.pointSizeLayout.addWidget(self.pointWorldDiameterLabel)

        self.pointWorldDiameterSpinBox = CoordinateSizeSpinBox(TskCoordinateWindowForm)
        self.pointWorldDiameterSpinBox.setObjectName(u"pointWorldDiameterSpinBox")
        self.pointWorldDiameterSpinBox.setMinimumSize(QSize(120, 0))
        self.pointWorldDiameterSpinBox.setMaximumSize(QSize(120, 16777215))
        self.pointWorldDiameterSpinBox.setKeyboardTracking(False)
        self.pointWorldDiameterSpinBox.setDecimals(20)
        self.pointWorldDiameterSpinBox.setProperty(u"minimumText", u"1e-20")
        self.pointWorldDiameterSpinBox.setMaximum(1000000000000.000000000000000)
        self.pointWorldDiameterSpinBox.setSingleStep(0.001000000000000)
        self.pointWorldDiameterSpinBox.setValue(0.020833333333333)

        self.pointSizeLayout.addWidget(self.pointWorldDiameterSpinBox)

        self.maximumPointDiameterLabel = QLabel(TskCoordinateWindowForm)
        self.maximumPointDiameterLabel.setObjectName(u"maximumPointDiameterLabel")

        self.pointSizeLayout.addWidget(self.maximumPointDiameterLabel)

        self.maximumPointDiameterSpinBox = QDoubleSpinBox(TskCoordinateWindowForm)
        self.maximumPointDiameterSpinBox.setObjectName(u"maximumPointDiameterSpinBox")
        self.maximumPointDiameterSpinBox.setKeyboardTracking(False)
        self.maximumPointDiameterSpinBox.setDecimals(1)
        self.maximumPointDiameterSpinBox.setMinimum(0.100000000000000)
        self.maximumPointDiameterSpinBox.setMaximum(64.000000000000000)
        self.maximumPointDiameterSpinBox.setSingleStep(0.100000000000000)
        self.maximumPointDiameterSpinBox.setValue(8.000000000000000)

        self.pointSizeLayout.addWidget(self.maximumPointDiameterSpinBox)

        self.pointSizeSpacer = QSpacerItem(0, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.pointSizeLayout.addItem(self.pointSizeSpacer)


        self.windowLayout.addLayout(self.pointSizeLayout)

        self.selectionLabel = QLabel(TskCoordinateWindowForm)
        self.selectionLabel.setObjectName(u"selectionLabel")
        self.selectionLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.selectionLabel.setWordWrap(True)

        self.windowLayout.addWidget(self.selectionLabel)

        self.legendWidget = QWidget(TskCoordinateWindowForm)
        self.legendWidget.setObjectName(u"legendWidget")
        self.legendLayout = QGridLayout(self.legendWidget)
        self.legendLayout.setObjectName(u"legendLayout")
        self.legendLayout.setHorizontalSpacing(8)
        self.legendLayout.setContentsMargins(0, 0, 0, 0)
        self.pointLegendTitle = QLabel(self.legendWidget)
        self.pointLegendTitle.setObjectName(u"pointLegendTitle")

        self.legendLayout.addWidget(self.pointLegendTitle, 0, 0, 1, 1)

        self.pointGradient = QLabel(self.legendWidget)
        self.pointGradient.setObjectName(u"pointGradient")
        self.pointGradient.setMinimumSize(QSize(90, 10))
        self.pointGradient.setMaximumSize(QSize(90, 10))

        self.legendLayout.addWidget(self.pointGradient, 0, 1, 1, 1)

        self.pointLegendLabel = QLabel(self.legendWidget)
        self.pointLegendLabel.setObjectName(u"pointLegendLabel")

        self.legendLayout.addWidget(self.pointLegendLabel, 0, 2, 1, 1)

        self.selectionLegend = QLabel(self.legendWidget)
        self.selectionLegend.setObjectName(u"selectionLegend")

        self.legendLayout.addWidget(self.selectionLegend, 0, 3, 1, 1)

        self.ringLegendTitle = QLabel(self.legendWidget)
        self.ringLegendTitle.setObjectName(u"ringLegendTitle")

        self.legendLayout.addWidget(self.ringLegendTitle, 1, 0, 1, 1)

        self.ringGradient = QLabel(self.legendWidget)
        self.ringGradient.setObjectName(u"ringGradient")
        self.ringGradient.setMinimumSize(QSize(90, 10))
        self.ringGradient.setMaximumSize(QSize(90, 10))

        self.legendLayout.addWidget(self.ringGradient, 1, 1, 1, 1)

        self.ringLegendLabel = QLabel(self.legendWidget)
        self.ringLegendLabel.setObjectName(u"ringLegendLabel")

        self.legendLayout.addWidget(self.ringLegendLabel, 1, 2, 1, 1)

        self.missingLegend = QLabel(self.legendWidget)
        self.missingLegend.setObjectName(u"missingLegend")

        self.legendLayout.addWidget(self.missingLegend, 1, 3, 1, 1)

        self.interactionHint = QLabel(self.legendWidget)
        self.interactionHint.setObjectName(u"interactionHint")
        self.interactionHint.setWordWrap(True)

        self.legendLayout.addWidget(self.interactionHint, 2, 0, 1, 4)


        self.windowLayout.addWidget(self.legendWidget)

        self.coordinatePlot = TskCoordinatePlot(TskCoordinateWindowForm)
        self.coordinatePlot.setObjectName(u"coordinatePlot")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(1)
        sizePolicy1.setHeightForWidth(self.coordinatePlot.sizePolicy().hasHeightForWidth())
        self.coordinatePlot.setSizePolicy(sizePolicy1)
        self.coordinatePlot.setMinimumSize(QSize(320, 220))
        font = QFont()
        font.setPointSize(10)
        self.coordinatePlot.setFont(font)
        self.coordinatePlot.setMouseTracking(True)
        self.coordinatePlot.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.coordinatePlot.setProperty(u"plotBackgroundRole", u"Base")
        self.coordinatePlot.setProperty(u"labelZoomThreshold", 1.500000000000000)
        self.coordinatePlot.setProperty(u"maximumCanvasZoom", 64.000000000000000)
        self.coordinatePlot.setProperty(u"canvasPaddingFraction", 0.060000000000000)
        self.coordinatePlot.setProperty(u"canvasBorderWidth", 1.000000000000000)
        self.coordinatePlot.setProperty(u"referenceLabelPointSize", 10.000000000000000)
        self.coordinatePlot.setProperty(u"overlayLabelBackgroundOpacity", 0.400000000000000)
        self.coordinatePlot.setProperty(u"labelWorldHeight", 0.010416666666667)
        self.coordinatePlot.setProperty(u"pointWorldDiameter", 0.020833333333333)
        self.coordinatePlot.setProperty(u"defaultLabelHeightFraction", 0.010416666666667)
        self.coordinatePlot.setProperty(u"defaultPointDiameterFraction", 0.020833333333333)
        self.coordinatePlot.setProperty(u"referenceCoordinateSpan", 512.000000000000000)
        self.coordinatePlot.setProperty(u"maximumLabelPixelHeight", 18.000000000000000)
        self.coordinatePlot.setProperty(u"maximumPointPixelDiameter", 8.000000000000000)
        self.coordinatePlot.setProperty(u"leaderLineWidth", 1.000000000000000)
        self.coordinatePlot.setProperty(u"maximumLabelWidth", 260)

        self.windowLayout.addWidget(self.coordinatePlot)

        self.statusLabel = QLabel(TskCoordinateWindowForm)
        self.statusLabel.setObjectName(u"statusLabel")
        self.statusLabel.setWordWrap(True)

        self.windowLayout.addWidget(self.statusLabel)

        self.windowLayout.setStretch(8, 1)
#if QT_CONFIG(shortcut)
        self.groupLabel.setBuddy(self.groupComboBox)
        self.chainLabel.setBuddy(self.chainComboBox)
        self.outlineLabel.setBuddy(self.outlineComboBox)
        self.labelModeLabel.setBuddy(self.labelModeComboBox)
        self.labelPositionLabel.setBuddy(self.labelPositionComboBox)
        self.initialLabelSizeLabel.setBuddy(self.initialLabelSizeSpinBox)
        self.maximumLabelSizeLabel.setBuddy(self.maximumLabelSizeSpinBox)
        self.pointWorldDiameterLabel.setBuddy(self.pointWorldDiameterSpinBox)
        self.maximumPointDiameterLabel.setBuddy(self.maximumPointDiameterSpinBox)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(TskCoordinateWindowForm)

        self.labelModeComboBox.setCurrentIndex(0)
        self.labelPositionComboBox.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(TskCoordinateWindowForm)
    # setupUi

    def retranslateUi(self, TskCoordinateWindowForm):
        TskCoordinateWindowForm.setWindowTitle(QCoreApplication.translate("TskCoordinateWindowForm", u"TSK \u5750\u6807\u56fe", None))
        TskCoordinateWindowForm.setProperty(u"contextFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"{mode} \u00b7 \u5750\u6807\u5355\u4f4d\uff1a{unit}", None))
        TskCoordinateWindowForm.setProperty(u"layoutModeText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u6a21\u677f\u5e03\u5c40\uff08\u6682\u65e0 Analyze \u89c2\u6d4b\uff09", None))
        TskCoordinateWindowForm.setProperty(u"observedModeText", QCoreApplication.translate("TskCoordinateWindowForm", u"Analyze \u89c2\u6d4b\uff08\u5c1a\u672a\u62df\u5408 TSK\uff09", None))
        TskCoordinateWindowForm.setProperty(u"fittedModeText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5df2\u4fdd\u5b58 TSK \u5206\u6790", None))
        TskCoordinateWindowForm.setProperty(u"emptyGroupText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5c1a\u65e0\u5206\u6790\u7ed3\u679c", None))
        TskCoordinateWindowForm.setProperty(u"unknownUnitText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u672a\u6307\u5b9a", None))
        TskCoordinateWindowForm.setProperty(u"allChainsText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5168\u90e8\u94fe\u8def\uff08\u6e05\u9664\u9ad8\u4eae\uff09", None))
        TskCoordinateWindowForm.setProperty(u"selectionFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"Chain {chain} \u00b7 \u5df2\u5b9a\u4f4d {shown}/{total} \u4e2a\u5b9e\u4f8b \u00b7 \u89c2\u6d4b {observed} \u00b7 \u9884\u6d4b {predicted}", None))
        TskCoordinateWindowForm.setProperty(u"noSelectionText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u70b9\u51fb\u5206\u6790\u4e2d\u7684 Chain \u540d\u79f0\u6216\u56fe\u4e2d\u7684\u70b9\u53ef\u9ad8\u4eae\u6574\u6761\u94fe\u3002", None))
        TskCoordinateWindowForm.setProperty(u"legendFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"{low} \u2192 {high}", None))
        TskCoordinateWindowForm.setProperty(u"unavailableText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u6682\u65e0\u6709\u6548\u98ce\u9669", None))
        TskCoordinateWindowForm.setProperty(u"zoomRangeFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5168\u56fe 1\u00d7 \u2014 \u6700\u5927 {maximum}\u00d7", None))
        TskCoordinateWindowForm.setProperty(u"statusFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5df2\u7ed8\u5236 {shown}/{total} \u4e2a\u5b9e\u4f8b \u00b7 \u7f3a\u5c11\u6709\u6548 XY\uff1a{missing} \u00b7 \u540c\u5750\u6807\u989d\u5916\u5b9e\u4f8b\uff1a{coincident} \u00b7 \u7f29\u653e {zoom}\u00d7 \u00b7 \u89c6\u91ce\u5185\u6587\u5b57 {labels} \u00b7 \u70b9 {visible}", None))
        self.groupLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u8282\u70b9 / \u6279\u6b21", None))
        self.contextLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5c1a\u65e0\u5206\u6790\u7ed3\u679c", None))
        self.chainLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"Chain", None))
#if QT_CONFIG(tooltip)
        self.chainComboBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u9009\u62e9\u94fe\u8def\uff0c\u9ad8\u4eae\u5b83\u5728\u5e03\u5c40\u4e2d\u7684\u6240\u6709\u5b9e\u4f8b\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.followCheckBox.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u9009\u62e9\u65f6\u81ea\u52a8\u5b9a\u4f4d", None))
        self.focusButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5b9a\u4f4d\u9009\u4e2d\u94fe", None))
        self.outlineLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5916\u5708", None))
        self.outlineComboBox.setItemText(0, QCoreApplication.translate("TskCoordinateWindowForm", u"\u94fe\u8def\u89c2\u6d4b\u5931\u6548\u7387", None))
        self.outlineComboBox.setItemText(1, QCoreApplication.translate("TskCoordinateWindowForm", u"\u94fe\u8def\u9884\u6d4b\u5931\u6548\u7387", None))
        self.outlineComboBox.setItemText(2, QCoreApplication.translate("TskCoordinateWindowForm", u"\u4e0d\u663e\u793a", None))

        self.labelsCheckBox.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u663e\u793a\u6587\u5b57", None))
        self.labelLayoutButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6807\u7b7e\u6392\u7248", None))
#if QT_CONFIG(tooltip)
        self.labelLayoutButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u62d6\u52a8\u5b57\u6bb5\u6807\u7b7e\uff0c\u5b89\u6392\u663e\u793a\u884c\u3001\u540c\u884c\u987a\u5e8f\u6216\u9690\u85cf\u5b57\u6bb5\u3002\u4fee\u6539\u4f1a\u7acb\u5373\u66f4\u65b0\u5750\u6807\u56fe\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.zoomOutButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u2212", None))
#if QT_CONFIG(tooltip)
        self.zoomOutButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u7f29\u5c0f\uff0c\u6700\u5c0f\u4e3a\u5b8c\u6574\u753b\u5e03\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.zoomInButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\uff0b", None))
#if QT_CONFIG(tooltip)
        self.zoomInButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u653e\u5927\uff0c\u4e0a\u9650\u4ee5\u5f53\u524d\u663e\u793a\u7684\u7f29\u653e\u8303\u56f4\u4e3a\u51c6\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.resetButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u663e\u793a\u5168\u90e8", None))
        self.labelModeLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6587\u5b57\u6a21\u5f0f", None))
        self.labelModeComboBox.setItemText(0, QCoreApplication.translate("TskCoordinateWindowForm", u"\u81ea\u52a8\u907f\u8ba9", None))
        self.labelModeComboBox.setItemText(1, QCoreApplication.translate("TskCoordinateWindowForm", u"\u59cb\u7ec8\u663e\u793a\u5168\u90e8", None))

#if QT_CONFIG(tooltip)
        self.labelModeComboBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u81ea\u52a8\u907f\u8ba9\uff1a\u653e\u5927\u540e\u663e\u793a\u80fd\u653e\u4e0b\u7684\u6587\u5b57\u3002\u59cb\u7ec8\u663e\u793a\u5168\u90e8\uff1a\u5b57\u9ad8\u4f7f\u7528\u5750\u6807\u5355\u4f4d\uff0c\u968f\u5730\u56fe\u7b49\u6bd4\u4f8b\u7f29\u653e\uff0c\u8fbe\u5230\u6700\u5927\u5c4f\u5e55\u5b57\u9ad8\u540e\u5e73\u6ed1\u505c\u6b62\u53d8\u5927\u3002\u6587\u5b57\u5c3d\u91cf\u8d34\u8fd1\u5bf9\u5e94 TSK \u5e76\u907f\u514d\u91cd\u53e0\uff1b\u65e0\u6cd5\u5c31\u8fd1\u5bb9\u7eb3\u65f6\u79fb\u5f00\uff0c\u5e76\u7528\u5f15\u7ebf\u5bf9\u5e94\u539f\u70b9\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.labelPositionLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u4f4d\u7f6e", None))
        self.labelPositionComboBox.setItemText(0, QCoreApplication.translate("TskCoordinateWindowForm", u"\u70b9\u65c1", None))
        self.labelPositionComboBox.setItemText(1, QCoreApplication.translate("TskCoordinateWindowForm", u"\u534a\u900f\u660e\u60ac\u6d6e", None))

#if QT_CONFIG(tooltip)
        self.labelPositionComboBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u70b9\u65c1\uff1a\u81ea\u52a8\u9009\u62e9\u5bf9\u5e94 TSK \u4e0a\u3001\u4e0b\u3001\u5de6\u3001\u53f3\u66f4\u5bbd\u655e\u7684\u7a7a\u9699\uff0c\u8d34\u8fd1\u653e\u7f6e\u6587\u5b57\u3002\u534a\u900f\u660e\u60ac\u6d6e\uff1a\u6587\u5b57\u6d6e\u5728\u81ea\u8eab\u70b9\u4e0a\u65b9\uff0c\u80cc\u666f\u534a\u900f\u660e\uff0c\u4fdd\u6301\u4e0b\u65b9\u7684\u70b9\u53ef\u89c1\u3002\u5c3d\u91cf\u4e0d\u8de8\u8d8a\u76f8\u90bb\u884c\u5217\uff1b\u540c\u5750\u6807\u7b49\u65e0\u6cd5\u907f\u514d\u7684\u51b2\u7a81\u518d\u79fb\u52a8\u6587\u5b57\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.initialLabelSizeLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5b57\u9ad8\uff08\u5750\u6807\uff09", None))
#if QT_CONFIG(tooltip)
        self.initialLabelSizeSpinBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5355\u884c\u6587\u5b57\u9ad8\u5ea6\uff0c\u4ee5\u5750\u6807\u8f74\u5355\u4f4d\u8868\u793a\uff0c\u4e0e\u5f53\u524d\u500d\u7387\u65e0\u5173\u3002\u663e\u793a\u9ad8\u5ea6\uff1d\u5750\u6807\u5b57\u9ad8\u00d7\u7f29\u653e\u6bd4\u4f8b\uff0c\u8fbe\u5230\u6700\u5927\u5c4f\u5e55\u5b57\u9ad8\u540e\u4e0d\u518d\u53d8\u5927\u3002\u652f\u6301\u5c0f\u6570\u6216\u79d1\u5b66\u8ba1\u6570\u6cd5\uff0c\u4f8b\u5982 1e-8\uff1b\u9996\u6b21\u6309\u6570\u636e\u8303\u56f4\u8bbe\u7f6e\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.maximumLabelSizeLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6700\u5927\u5b57\u9ad8", None))
#if QT_CONFIG(tooltip)
        self.maximumLabelSizeSpinBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6587\u5b57\u5355\u884c\u9ad8\u5ea6\u7684\u5c4f\u5e55\u4e0a\u9650\uff0c\u5355\u4f4d\u4e3a\u903b\u8f91\u50cf\u7d20 px\u3002\u6587\u5b57\u968f\u5730\u56fe\u7b49\u6bd4\u4f8b\u653e\u5927\u81f3\u8be5\u9ad8\u5ea6\u540e\u4fdd\u6301\u4e0d\u53d8\uff0c\u7f29\u5c0f\u65f6\u8fde\u7eed\u6062\u590d\u3002\u8303\u56f4 0.1 \u81f3 48.0 px\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.maximumLabelSizeSpinBox.setSuffix(QCoreApplication.translate("TskCoordinateWindowForm", u" px", None))
        self.zoomRangeLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5168\u56fe 1\u00d7 \u2014 \u6700\u5927 64\u00d7", None))
#if QT_CONFIG(tooltip)
        self.zoomRangeLabel.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u8fb9\u6846\u5305\u542b\u5b9e\u4f8b\u70b9\u53ca\u6587\u5b57\uff0c\u62d6\u52a8\u5728\u753b\u5e03\u8fb9\u754c\u5185\u505c\u6b62\u3002\u8c03\u6574\u5927\u5c0f\u65f6\u4fdd\u6301\u5f53\u524d\u89c6\u56fe\uff0c\u5e76\u6309\u9700\u6269\u5c55\u753b\u5e03\uff1b\u7f29\u653e\u4e0a\u9650\u4ee5\u6b64\u5904\u663e\u793a\u4e3a\u51c6\u3002\u70b9\u51fb\u663e\u793a\u5168\u90e8\u53ef\u91cd\u65b0\u8d34\u5408\u5185\u5bb9\u5e76\u6062\u590d\u5168\u56fe 1 \u81f3 64 \u500d\u7684\u8303\u56f4\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.pointWorldDiameterLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5706\u70b9\u76f4\u5f84\uff08\u5750\u6807\uff09", None))
#if QT_CONFIG(tooltip)
        self.pointWorldDiameterSpinBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5b9e\u5fc3\u5706\u70b9\u76f4\u5f84\uff0c\u4ee5\u5750\u6807\u8f74\u5355\u4f4d\u8868\u793a\uff0c\u4e0e\u6587\u5b57\u5927\u5c0f\u53ca\u5f53\u524d\u500d\u7387\u65e0\u5173\u3002\u4e24\u79cd\u6587\u5b57\u6a21\u5f0f\u4e0b\u5747\u968f\u5730\u56fe\u7b49\u6bd4\u4f8b\u7f29\u653e\uff0c\u5230\u6700\u5927\u5c4f\u5e55\u76f4\u5f84\u540e\u4fdd\u6301\u4e0d\u53d8\u3002\u652f\u6301\u5c0f\u6570\u6216\u79d1\u5b66\u8ba1\u6570\u6cd5\uff0c\u4f8b\u5982 1e-8\uff1b\u9996\u6b21\u6309\u6570\u636e\u8303\u56f4\u8bbe\u7f6e\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.maximumPointDiameterLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6700\u5927\u76f4\u5f84", None))
#if QT_CONFIG(tooltip)
        self.maximumPointDiameterSpinBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5b9e\u5fc3\u5706\u70b9\u76f4\u5f84\u7684\u5c4f\u5e55\u4e0a\u9650\uff0c\u5355\u4f4d\u4e3a\u903b\u8f91\u50cf\u7d20 px\u3002\u5706\u70b9\u968f\u5730\u56fe\u7b49\u6bd4\u4f8b\u653e\u5927\u81f3\u8be5\u76f4\u5f84\u540e\u4fdd\u6301\u4e0d\u53d8\uff0c\u7f29\u5c0f\u65f6\u8fde\u7eed\u6062\u590d\u3002\u8303\u56f4 0.1 \u81f3 64.0 px\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.maximumPointDiameterSpinBox.setSuffix(QCoreApplication.translate("TskCoordinateWindowForm", u" px", None))
        self.selectionLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u70b9\u51fb\u5206\u6790\u4e2d\u7684 Chain \u540d\u79f0\u6216\u56fe\u4e2d\u7684\u70b9\u53ef\u9ad8\u4eae\u6574\u6761\u94fe\u3002", None))
        self.pointLegendTitle.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u70b9\u8272 \u00b7 \u5b9e\u4f8b\u9884\u4f30\u5931\u6548\u7387", None))
        self.pointGradient.setStyleSheet(QCoreApplication.translate("TskCoordinateWindowForm", u"background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #23a5a0, stop:0.5 #edc65a, stop:1 #d1495b); border-radius: 3px;", None))
        self.pointLegendLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6682\u65e0\u6709\u6548\u98ce\u9669", None))
        self.selectionLegend.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u84dd\u8272\u5149\u5708\uff1a\u9009\u4e2d\u94fe\u8def", None))
        self.ringLegendTitle.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5916\u5708 \u00b7 \u94fe\u8def\u89c2\u6d4b\u5931\u6548\u7387", None))
        self.ringLegendTitle.setProperty(u"formatText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5916\u5708 \u00b7 {metric}", None))
        self.ringGradient.setStyleSheet(QCoreApplication.translate("TskCoordinateWindowForm", u"background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #23a5a0, stop:0.5 #edc65a, stop:1 #d1495b); border-radius: 3px;", None))
        self.ringLegendLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6682\u65e0\u6709\u6548\u98ce\u9669", None))
        self.missingLegend.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u7070\u8272\uff1a\u65e0\u6709\u6548\u4f30\u8ba1 / \u6d4b\u8bd5", None))
        self.interactionHint.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6eda\u8f6e\u7f29\u653e \u00b7 \u62d6\u52a8\u5e73\u79fb \u00b7 \u53cc\u51fb\u663e\u793a\u5168\u90e8 \u00b7 \u60ac\u505c\u67e5\u770b\u5b8c\u6574\u5c5e\u6027\u3002\u59cb\u7ec8\u663e\u793a\u5168\u90e8\u65f6\uff0c\u6587\u5b57\u6309\u5750\u6807\u5b57\u9ad8\u968f\u56fe\u7f29\u653e\uff0c\u8fbe\u5230\u6700\u5927\u5c4f\u5e55\u5b57\u9ad8\u540e\u505c\u6b62\u53d8\u5927\uff1b\u5706\u70b9\u76f4\u5f84\u4e5f\u6309\u5750\u6807\u7f29\u653e\u5e76\u53d7\u5c4f\u5e55\u4e0a\u9650\u9650\u5236\uff1b\u663e\u793a\u5168\u90e8\u4f1a\u628a\u6587\u5b57\u7eb3\u5165\u89c6\u91ce\u3002\u540c\u5750\u6807\u70b9\u53ef\u91cd\u590d\u70b9\u51fb\u5207\u6362\u94fe\u8def\u3002\u4e24\u79cd\u8272\u9636\u5206\u522b\u6309\u5f53\u524d\u7ec4\u6709\u6548\u503c\u7ebf\u6027\u7f29\u653e\u3002", None))
        self.coordinatePlot.setProperty(u"emptyText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u6ca1\u6709\u53ef\u7ed8\u5236\u7684\u6709\u6548 XY \u5750\u6807\u3002\u8bf7\u5728\u6a21\u677f\u4e2d\u63d0\u4f9b\u5b9e\u4f8b\u5750\u6807\u540e\u91cd\u65b0\u5206\u6790\u3002", None))
        self.coordinatePlot.setProperty(u"labelMode", QCoreApplication.translate("TskCoordinateWindowForm", u"auto", None))
        self.coordinatePlot.setProperty(u"labelPosition", QCoreApplication.translate("TskCoordinateWindowForm", u"side", None))
        self.coordinatePlot.setProperty(u"leaderLineDarkColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#a4abb6", None))
        self.coordinatePlot.setProperty(u"leaderLineLightColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#858d98", None))
        self.coordinatePlot.setProperty(u"labelValueSeparator", QCoreApplication.translate("TskCoordinateWindowForm", u" \u00b7 ", None))
        self.coordinatePlot.setProperty(u"lowColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#23a5a0", None))
        self.coordinatePlot.setProperty(u"middleColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#edc65a", None))
        self.coordinatePlot.setProperty(u"highColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#d1495b", None))
        self.coordinatePlot.setProperty(u"missingColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#8c939e", None))
        self.coordinatePlot.setProperty(u"selectionColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#4285ff", None))
        self.coordinatePlot.setProperty(u"identityFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"TSK {tsk} \u00b7 {instance}", None))
        self.coordinatePlot.setProperty(u"chainFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"Chain {chain}", None))
        self.coordinatePlot.setProperty(u"attributeFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"{name}\uff1a{value}", None))
        self.coordinatePlot.setProperty(u"riskFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u9884\u4f30\u5931\u6548\uff1a{risk}", None))
        self.coordinatePlot.setProperty(u"observedFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u94fe\u8def\u89c2\u6d4b\uff1a{risk}", None))
        self.coordinatePlot.setProperty(u"predictedFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u94fe\u8def\u9884\u6d4b\uff1a{risk}", None))
        self.coordinatePlot.setProperty(u"overlapFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u6b64\u5904\u5171 {count} \u4e2a\u5b9e\u4f8b\uff1b\u91cd\u590d\u70b9\u51fb\u53ef\u5207\u6362\u94fe\u8def\u3002", None))
        self.coordinatePlot.setProperty(u"moreFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u53e6\u6709 {count} \u4e2a\u5b9e\u4f8b\uff1b\u9009\u62e9 Chain \u53ef\u5b9a\u4f4d\u3002", None))
        self.statusLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5c1a\u65e0\u5750\u6807\u6570\u636e", None))
    # retranslateUi

