"""Coordinate-space TSK instances with screen-space labels and saved risks."""
from __future__ import annotations

from dataclasses import dataclass
from html import escape
import math

from PySide6.QtCore import QEvent, QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetricsF, QPainter, QPalette, QPen
from PySide6.QtWidgets import QApplication, QToolTip, QWidget

from .tsk_risk_display import percentage, risk_available, valid_probability
from .tsk_coordinate_labels import available_field_keys, default_label_rows, normalize_label_rows, render_label_lines
from .tsk_coordinate_label_geometry import compact_label_scale, pack_label_rectangles


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def chain_probability(chain, metric):
    value = chain.get(metric)
    tested = chain.get("n_tested")
    return value if finite(tested) and tested > 0 and valid_probability(value) else None


@dataclass(frozen=True)
class CoordinateInstance:
    chain_id: str
    instance_id: str
    tsk_id: str
    x: float
    y: float
    features: dict
    probability: float | None
    observed: float | None
    predicted: float | None
    reason: str


def coordinate_instances(payload, group):
    """Join by chain, type and instance, never substitute reference-model risk."""
    chains = {str(row.get("chain_id")): row for row in group.get("chains", [])}
    members = {}
    for chain_id, chain in chains.items():
        for member in chain.get("members") or group.get("chain_members", {}).get(chain_id, []):
            for instance_id in member.get("instance_ids", []):
                members[(chain_id, str(member.get("tsk_id")), str(instance_id))] = member
    topology = payload.get("topology") or (group.get("prediction_context") or {}).get("topology", [])
    points = []
    for row in topology:
        if not (finite(row.get("x")) and finite(row.get("y"))):
            continue
        chain_id, tsk_id = str(row.get("chain_id", "")), str(row.get("tsk_id", ""))
        instance_id = str(row.get("tsk_instance_id", row.get("instance_id", "")))
        chain = chains.get(chain_id, {})
        member = members.get((chain_id, tsk_id, instance_id), {})
        tested = chain.get("n_tested")
        probability = (member.get("probability") if finite(tested) and tested > 0 and risk_available(member)
                       and member.get("status") not in {"fit_not_converged", "unavailable", "not_identifiable"} else None)
        points.append(CoordinateInstance(chain_id, instance_id, tsk_id, float(row["x"]), float(row["y"]),
            dict(row.get("features") or {}), probability,
            chain_probability(chain, "observed_probability"), chain_probability(chain, "predicted_probability"),
            str(member.get("reason") or "")))
    return points, topology


def probability_range(values):
    values = [value for value in values if valid_probability(value)]
    return (min(values), max(values)) if values else None


class _RectIndex:
    """Small screen-space buckets keep decluttering independent of label count."""
    def __init__(self):
        self.buckets = {}

    @staticmethod
    def cells(rect):
        for x in range(math.floor(rect.left() / 64), math.floor(rect.right() / 64) + 1):
            for y in range(math.floor(rect.top() / 64), math.floor(rect.bottom() / 64) + 1):
                yield x, y

    def add(self, rect):
        for key in self.cells(rect):
            self.buckets.setdefault(key, []).append(rect)

    def intersects(self, rect):
        return any(rect.intersects(other) for key in self.cells(rect) for other in self.buckets.get(key, ()))


class TskCoordinatePlot(QWidget):
    chain_selected = Signal(str)
    view_changed = Signal(int, int, float)
    world_sizes_changed = Signal(float, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.points = []
        self.selected_chain = None
        self.outline_metric = "observed"
        self.labels_enabled = True
        self.point_range = None
        self.ring_range = None
        self._center = QPointF()
        self._zoom = 1.
        self._bounds = QRectF(-.5, -.5, 1., 1.)
        self._screen_points = []
        self._label_regions = []
        self._label_cache = {}
        self._layout_dirty = True
        self._press = None
        self._dragged = False
        self._last_stats = None
        self.label_rows = None
        self._default_label_rows = []
        self._label_field_keys = []
        self._global_labels = None
        self._capped_labels = None
        self._all_label_regions = []
        self._reference_scale = 1.
        self._reference_center = QPointF()
        self._label_height_custom = False
        self._point_diameter_custom = False
        self._text_scale = 1.
        self._compact_scale = 1.
        self._canvas_cache = None
        self._canvas_envelope = None
        self._maximum_zoom_limit = None
        self._last_minimum_zoom = None

    def _text(self, key, **values):
        return str(self.property(key) or "").format(**values)

    def set_points(self, points):
        self.points = list(points)
        features = list(dict.fromkeys(name for point in self.points for name in point.features))
        self._label_field_keys = available_field_keys(features)
        self._default_label_rows = default_label_rows(features)
        self.selected_chain = None
        self.point_range = probability_range(point.probability for point in self.points)
        self.set_outline_metric(self.outline_metric)
        self._label_cache.clear()
        self._global_labels = None
        self._canvas_cache = None
        self._last_stats = None
        self._bounds = self._point_bounds(self.points)
        if self.points:
            span = max(self._bounds.width(), self._bounds.height())
            if not self._label_height_custom:
                self.setProperty("labelWorldHeight", span * float(self.property("defaultLabelHeightFraction") or 1 / 96))
            if not self._point_diameter_custom:
                self.setProperty("pointWorldDiameter", span * float(self.property("defaultPointDiameterFraction") or 1 / 48))
            self.world_sizes_changed.emit(self._label_world_height(), self._point_world_diameter())
        self.reset_view()

    @staticmethod
    def _point_bounds(points):
        if not points:
            return QRectF(-.5, -.5, 1., 1.)
        xs, ys = [p.x for p in points], [p.y for p in points]
        x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
        # Preserve equal X/Y scale even when all coordinates lie on one axis.
        span = max(x1 - x0, y1 - y0) or 1.
        return QRectF(x0 - (span if x0 == x1 else 0) / 2,
                      y0 - (span if y0 == y1 else 0) / 2,
                      x1 - x0 or span, y1 - y0 or span)

    def plot_rect(self):
        return QRectF(self.rect()).adjusted(62, 20, -22, -42)

    def _base_scale(self):
        rect = self.plot_rect()
        return max(1e-12, min(rect.width() / self._bounds.width(), rect.height() / self._bounds.height()) * .8)

    def world_to_screen(self, x, y):
        scale, center = self._base_scale() * self._zoom, self.plot_rect().center()
        return QPointF(center.x() + (x - self._center.x()) * scale,
                       center.y() - (y - self._center.y()) * scale)

    def screen_to_world(self, point):
        scale, center = self._base_scale() * self._zoom, self.plot_rect().center()
        return QPointF(self._center.x() + (point.x() - center.x()) / scale,
                       self._center.y() - (point.y() - center.y()) / scale)

    def _invalidate(self):
        self._layout_dirty = True
        self.update()

    def canvas_bounds(self):
        """Finite world-space page shared by drawing, fitting and navigation."""
        if self._canvas_cache is None:
            bounds = QRectF(self._bounds)
            # A shared page keeps the camera and marker sizes unchanged when
            # labels are hidden or their visibility mode is switched.
            if self.points:
                self._ensure_global_labels()
                for rect, _, _ in self._global_labels:
                    bounds = bounds.united(QRectF(self._reference_to_world(rect.bottomLeft()),
                                                  self._reference_to_world(rect.topRight())))
                # Allow capped labels to choose another side of an edge point
                # without spilling past the finite page.
                width = max((rect.width() for rect, _, _ in self._global_labels), default=12.) / self._reference_scale
                height = max((rect.height() for rect, _, _ in self._global_labels), default=12.) / self._reference_scale
                width = max(width, self._point_world_diameter() * 1.5)
                height = max(height, self._point_world_diameter() * 1.5)
            else:
                width = height = 12 / self._base_scale()
            fraction = float(self.property("canvasPaddingFraction") or .06)
            dx, dy = max(bounds.width() * fraction, width), max(bounds.height() * fraction, height)
            canvas = bounds.adjusted(-dx, -dy, dx, dy)
            if self._canvas_envelope is not None:
                # Editing sizes or label rows must not shrink the page or
                # shift its center and thereby refit the user's camera.
                center = self._canvas_envelope.center()
                canvas = canvas.united(self._canvas_envelope)
                half_width = max(center.x() - canvas.left(), canvas.right() - center.x())
                half_height = max(center.y() - canvas.top(), canvas.bottom() - center.y())
                canvas = QRectF(center.x() - half_width, center.y() - half_height,
                                half_width * 2, half_height * 2)
            self._canvas_cache = canvas
            self._canvas_envelope = QRectF(canvas)
        return QRectF(self._canvas_cache)

    def zoom_limits(self):
        bounds, area = self.canvas_bounds(), self.plot_rect()
        minimum = .96 * min(area.width() / bounds.width(), area.height() / bounds.height()) / self._base_scale()
        if self._maximum_zoom_limit is None:
            self._maximum_zoom_limit = minimum * float(self.property("maximumCanvasZoom") or 64.)
        return minimum, max(minimum, self._maximum_zoom_limit)

    def relative_zoom(self):
        return self._zoom / self.zoom_limits()[0]

    def _constrain_view(self):
        minimum, maximum = self.zoom_limits()
        self._zoom = max(minimum, min(maximum, self._zoom))
        self._last_minimum_zoom = minimum
        bounds, area = self.canvas_bounds(), self.plot_rect()
        scale = self._base_scale() * self._zoom
        half_width, half_height = area.width() / scale / 2, area.height() / scale / 2

        def coordinate(value, low, high, half):
            if half * 2 >= high - low:
                return (low + high) / 2
            return max(low + half, min(high - half, value))

        self._center = QPointF(coordinate(self._center.x(), bounds.left(), bounds.right(), half_width),
                               coordinate(self._center.y(), bounds.top(), bounds.bottom(), half_height))

    def _canvas_screen_rect(self):
        bounds = self.canvas_bounds()
        return QRectF(self.world_to_screen(bounds.left(), bounds.bottom()),
                      self.world_to_screen(bounds.right(), bounds.top()))

    def reset_view(self):
        # Only an explicit fit (or loading data) tightens the page and renews
        # its zoom range. Ordinary size edits preserve the current scale.
        self._canvas_cache = None
        self._canvas_envelope = None
        self._maximum_zoom_limit = None
        self._center = self.canvas_bounds().center()
        self._zoom = self.zoom_limits()[0]
        self._constrain_view()
        self._invalidate()

    def zoom(self, factor, anchor=None):
        if not math.isfinite(factor) or factor <= 0:
            return
        self._constrain_view()
        anchor = anchor if anchor is not None else self.plot_rect().center()
        before = self.screen_to_world(anchor)
        minimum, maximum = self.zoom_limits()
        self._zoom = max(minimum, min(maximum, self._zoom * factor))
        self._center += before - self.screen_to_world(anchor)
        self._constrain_view()
        self._invalidate()

    def focus_selection(self):
        selected = [p for p in self.points if p.chain_id == self.selected_chain]
        if not selected:
            return
        if self._always_labels():
            self._fit_label_bounds(self.selected_chain)
            self._constrain_view()
            self._invalidate()
            return
        bounds, rect = self._point_bounds(selected), self.plot_rect()
        self._center = bounds.center()
        if all(p.x == selected[0].x and p.y == selected[0].y for p in selected):
            self._zoom = max(3., self._zoom)
        else:
            scale = min(rect.width() / bounds.width(), rect.height() / bounds.height()) * .65
            self._zoom = scale / self._base_scale()
        self._constrain_view()
        self._invalidate()

    def set_selected_chain(self, chain_id, *, focus=False):
        self.selected_chain = str(chain_id) if chain_id is not None else None
        if focus:
            self.focus_selection()
        self._invalidate()

    def set_outline_metric(self, metric):
        self.outline_metric = metric
        self.ring_range = probability_range(getattr(p, metric) for p in self.points) if metric else None
        self._invalidate()

    def set_labels_enabled(self, enabled):
        if self.labels_enabled != enabled:
            self._canvas_cache = None
        self.labels_enabled = enabled
        self._constrain_view()
        self._invalidate()

    def _always_labels(self):
        return self.labels_enabled and self.property("labelMode") == "always"

    def set_label_mode(self, mode):
        if mode not in ("auto", "always"):
            raise ValueError(mode)
        self.setProperty("labelMode", mode)
        self._constrain_view()
        self._invalidate()

    def set_label_position(self, position):
        if position not in ("side", "overlay"):
            raise ValueError(position)
        if position != self.property("labelPosition"):
            self.setProperty("labelPosition", position)
            self._global_labels = None
            self._canvas_cache = None
        self._constrain_view()
        self._invalidate()

    def set_maximum_label_pixel_height(self, size):
        self.setProperty("maximumLabelPixelHeight", max(.1, float(size)))
        self._invalidate()

    def _label_world_height(self):
        return float(self.property("labelWorldHeight") or 1 / 96)

    def _point_world_diameter(self):
        return float(self.property("pointWorldDiameter") or 1 / 48)

    def set_label_world_height(self, height):
        if not math.isfinite(height) or height <= 0:
            return
        self._label_height_custom = True
        self.setProperty("labelWorldHeight", float(height))
        self._invalidate_size_geometry()

    def set_point_world_diameter(self, diameter):
        if not math.isfinite(diameter) or diameter <= 0:
            return
        self._point_diameter_custom = True
        self.setProperty("pointWorldDiameter", float(diameter))
        self._invalidate_size_geometry()

    def set_maximum_point_pixel_diameter(self, diameter):
        self.setProperty("maximumPointPixelDiameter", max(.1, float(diameter)))
        self._invalidate()

    def _invalidate_size_geometry(self):
        self._global_labels = None
        self._canvas_cache = None
        self._constrain_view()
        self._invalidate()

    def _maximum_text_scale(self):
        return float(self.property("maximumLabelPixelHeight") or 18.) / QFontMetricsF(self._reference_font()).height()

    def _reference_font(self):
        font = QFont(self.font())
        font.setPointSizeF(float(self.property("referenceLabelPointSize") or font.pointSizeF()))
        return font

    def _ensure_global_labels(self):
        if self._global_labels is not None:
            return
        # Normalize geometry using only data coordinates, never the current
        # camera, window size or the moment a control was edited.
        self._reference_scale = float(self.property("referenceCoordinateSpan") or 512.) / max(self._bounds.width(), self._bounds.height())
        self._reference_center = self._bounds.center()
        metrics = QFontMetricsF(self._reference_font())
        anchors, texts, sizes = [], [], []
        for point in self.points:
            anchors.append(QPointF((point.x - self._reference_center.x()) * self._reference_scale,
                                   (self._reference_center.y() - point.y) * self._reference_scale))
            lines = self.label_lines(point)
            texts.append(lines)
            # All-text mode never elides values. Scale the complete glyph bounds.
            width = max((metrics.horizontalAdvance(line) for line in lines), default=0.) + 12
            sizes.append((width, len(lines) * metrics.height() + 10 if lines else 0.))
        horizontal = compact_label_scale(anchors, sizes, math.inf)
        vertical = compact_label_scale(anchors, sizes, math.inf, vertical=True)
        self._label_axis = "vertical" if vertical > horizontal else "horizontal"
        self._compact_scale = self._label_world_height() * self._reference_scale / metrics.height()
        sizes = [(width * self._compact_scale, height * self._compact_scale) for width, height in sizes]
        self._reference_point_radius = self._point_world_diameter() * self._reference_scale * 1.5
        rects = pack_label_rectangles(anchors, sizes, overlay=self.property("labelPosition") == "overlay",
                                     spacing_scale=self._compact_scale, preferred_axis=self._label_axis,
                                     point_radius=self._reference_point_radius)
        self._global_labels = [(rect, index, texts[index]) for index, rect in enumerate(rects) if rect is not None]
        self._label_anchors, self._label_sizes, self._label_texts = anchors, sizes, texts
        self._capped_labels = None

    def _reference_to_world(self, point):
        return QPointF(self._reference_center.x() + point.x() / self._reference_scale,
                       self._reference_center.y() - point.y() / self._reference_scale)

    def _fit_label_bounds(self, chain_id=None):
        self._ensure_global_labels()
        selected = [point for point in self.points if chain_id is None or point.chain_id == chain_id]
        if not selected:
            return
        # Fit actual coordinates, without the one-unit fallback used for empty
        # axes. That fallback would zoom far out for a single micrometer-scale point.
        padding = self._point_world_diameter() * 1.5
        xs, ys = [point.x for point in selected], [point.y for point in selected]
        bounds = QRectF(min(xs) - padding, min(ys) - padding,
                        max(xs) - min(xs) + 2 * padding, max(ys) - min(ys) + 2 * padding)
        for rect, index, _ in self._global_labels:
            if chain_id is None or self.points[index].chain_id == chain_id:
                bounds = bounds.united(QRectF(self._reference_to_world(rect.bottomLeft()),
                                              self._reference_to_world(rect.topRight())))
        area = self.plot_rect()
        self._center = bounds.center()
        self._zoom = .8 * min(area.width() / bounds.width(), area.height() / bounds.height()) / self._base_scale()
        # Capped text is packed closer to anchors. Verify the actual layout
        # after fitting; its displaced labels can differ from reservations.
        for _ in range(6):
            self._layout_all_labels(area)
            regions = [rect for rect, index, _ in self._all_label_regions
                       if chain_id is None or self.points[index].chain_id == chain_id]
            for point in selected:
                pos = self.world_to_screen(point.x, point.y)
                radius = 12 * self._marker_scale()
                regions.append(QRectF(pos.x() - radius, pos.y() - radius, 2 * radius, 2 * radius))
            visible_bounds = regions[0]
            for region in regions[1:]:
                visible_bounds = visible_bounds.united(region)
            target = area.adjusted(area.width() * .08, area.height() * .08,
                                   -area.width() * .08, -area.height() * .08)
            if target.contains(visible_bounds):
                return
            self._center = self.screen_to_world(visible_bounds.center())
            factor = min(1., target.width() / visible_bounds.width(), target.height() / visible_bounds.height())
            self._zoom *= factor * .95
        # Guaranteed fallback to the unchanged uncapped reservations.
        self._center = bounds.center()
        cap = self._maximum_text_scale()
        self._zoom = min(.8 * min(area.width() / bounds.width(), area.height() / bounds.height()) / self._base_scale(),
                         cap * self._reference_scale / (self._compact_scale * self._base_scale()))

    def _layout_all_labels(self, area):
        self._ensure_global_labels()
        world_scale = self._base_scale() * self._zoom / self._reference_scale
        maximum = self._maximum_text_scale()
        self._text_scale = min(world_scale * self._compact_scale, maximum)
        spacing = world_scale * self._compact_scale / self._text_scale
        point_radius = 12 * self._marker_scale() * self._compact_scale / self._text_scale
        labels = self._global_labels
        if spacing > 1. + 1e-12 or point_radius < self._reference_point_radius * (1 - 1e-12):
            # Once text stops growing, keep it near its point. Pack against all
            # expanded anchors, rather than leaving a capped label far away in
            # a growing reservation. Panning and selection reuse this layout.
            cache_key = spacing, point_radius
            if self._capped_labels is None or self._capped_labels[0] != cache_key:
                anchors = [point * spacing for point in self._label_anchors]
                rects = pack_label_rectangles(anchors, self._label_sizes,
                                              overlay=self.property("labelPosition") == "overlay",
                                              spacing_scale=self._compact_scale, preferred_axis=self._label_axis,
                                              point_radius=point_radius)
                labels = [(rect, index, self._label_texts[index])
                          for index, rect in enumerate(rects) if rect is not None]
                self._capped_labels = cache_key, labels
            labels = self._capped_labels[1]
        self._all_label_regions = []
        for reference, index, lines in labels:
            world = self._reference_to_world(reference.center() / spacing)
            center = self.world_to_screen(world.x(), world.y())
            box_scale = self._text_scale / self._compact_scale
            width, height = reference.width() * box_scale, reference.height() * box_scale
            region = QRectF(center.x() - width / 2, center.y() - height / 2, width, height)
            self._all_label_regions.append((region, index, lines))
        self._label_regions = [entry for entry in self._all_label_regions if area.intersects(entry[0])]

    def _color(self, value, bounds):
        if not valid_probability(value) or bounds is None:
            return QColor(self.property("missingColor"))
        low, high = bounds
        fraction = (value - low) / (high - low) if high > low else 0.
        first, second = ("lowColor", "middleColor") if fraction <= .5 else ("middleColor", "highColor")
        a, b = QColor(self.property(first)), QColor(self.property(second))
        t = fraction * 2 if fraction <= .5 else (fraction - .5) * 2
        return QColor.fromRgbF(*(a.getRgbF()[i] * (1 - t) + b.getRgbF()[i] * t for i in range(3)))

    @staticmethod
    def _value(value):
        if value is None:
            return "—"
        # Each attribute stays on one line; tooltips retain the full value.
        return str(value).replace("\n", " ↵ ").replace("\r", " ").replace("\t", " ")

    def label_lines(self, point):
        rows = self._default_label_rows if self.label_rows is None else self.label_rows
        return render_label_lines(point, rows, str(self.property("labelValueSeparator") or " · "))

    def set_label_rows(self, rows, feature_names=None):
        available = self._label_field_keys if feature_names is None else available_field_keys(feature_names)
        self.label_rows = normalize_label_rows(rows, available)
        self._label_cache.clear()
        self._global_labels = None
        self._canvas_cache = None
        self._constrain_view()
        self._invalidate()

    def _detail_lines(self, point):
        """Hover retains named, complete attributes regardless of hidden labels."""
        return [self._text("identityFormat", tsk=self._value(point.tsk_id), instance=self._value(point.instance_id)),
                *[self._text("attributeFormat", name=self._value(name), value=self._value(value))
                  for name, value in point.features.items()],
                self._text("riskFormat", risk=percentage(point.probability))]

    def _label_geometry(self, index, metrics):
        if index not in self._label_cache:
            lines = [metrics.elidedText(line, Qt.ElideRight, int(self.property("maximumLabelWidth")))
                     for line in self.label_lines(self.points[index])]
            width = max((metrics.horizontalAdvance(line) for line in lines), default=0) + 12
            self._label_cache[index] = lines, width, len(lines) * metrics.height() + 10
        return self._label_cache[index]

    def _layout(self):
        if not self._layout_dirty:
            return
        self._layout_dirty = False
        self._constrain_view()
        area = self.plot_rect()
        self._screen_points = [(index, self.world_to_screen(point.x, point.y))
                               for index, point in enumerate(self.points)]
        self._screen_points = [(index, pos) for index, pos in self._screen_points if area.contains(pos)]
        self._label_regions = []
        self._all_label_regions = []
        if self._always_labels():
            self._layout_all_labels(area)
            return
        if not self.labels_enabled or self._zoom < float(self.property("labelZoomThreshold")):
            return
        metrics, occupied = QFontMetricsF(self.font()), _RectIndex()
        label_area = area.intersected(self._canvas_screen_rect())
        point_radius = 12 * self._marker_scale()
        for _, pos in self._screen_points:
            occupied.add(QRectF(pos.x() - point_radius, pos.y() - point_radius, 2 * point_radius, 2 * point_radius))
        ordered = sorted(self._screen_points, key=lambda item: self.points[item[0]].chain_id != self.selected_chain)
        for index, pos in ordered:
            lines, width, height = self._label_geometry(index, metrics)
            if not lines:
                continue
            gap = point_radius + 4
            candidates = [(gap, -height / 2), (-width - gap, -height / 2),
                          (gap, gap), (-width - gap, gap), (gap, -height - gap),
                          (-width - gap, -height - gap), (-width / 2, -height - gap), (-width / 2, gap)]
            for dx, dy in candidates:
                region = QRectF(pos.x() + dx, pos.y() + dy, width, height)
                padded = region.adjusted(-3, -3, 3, 3)
                if label_area.contains(padded) and not occupied.intersects(padded):
                    self._label_regions.append((region, index, lines))
                    occupied.add(padded)
                    break

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        palette = self.palette()
        background_role = getattr(QPalette.ColorRole, self.property("plotBackgroundRole") or "Base")
        painter.fillRect(self.rect(), palette.color(background_role))
        area = self.plot_rect()
        self._layout()
        if not self.points:
            painter.setPen(palette.color(QPalette.Text))
            painter.drawText(area, Qt.AlignCenter | Qt.TextWordWrap, self._text("emptyText"))
        else:
            canvas = self._canvas_screen_rect()
            painter.save()
            painter.setClipRect(area)
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(palette.color(QPalette.Mid), float(self.property("canvasBorderWidth") or 1.)))
            painter.drawRect(canvas)
            painter.restore()
            self._draw_axes(painter, area, canvas.intersected(area))
            painter.save()
            painter.setClipRect(canvas.intersected(area))
            selected_color = QColor(self.property("selectionColor"))
            overlay = self._always_labels() and self.property("labelPosition") == "overlay"
            if not overlay:
                self._draw_labels(painter, selected_color)
            marker_scale = self._marker_scale()
            # Draw selected points last, so coincident instances remain findable.
            for index, pos in sorted(self._screen_points, key=lambda item: self.points[item[0]].chain_id == self.selected_chain):
                painter.save()
                painter.translate(pos)
                painter.scale(marker_scale, marker_scale)
                pos = QPointF()
                point = self.points[index]
                selected = point.chain_id == self.selected_chain
                painter.setOpacity(.28 if self.selected_chain is not None and not selected else 1.)
                if selected:
                    halo = QColor(selected_color)
                    halo.setAlpha(55)
                    painter.setBrush(halo)
                    painter.setPen(QPen(selected_color, 2.5))
                    painter.drawEllipse(pos, 11, 11)
                if self.outline_metric:
                    painter.setBrush(Qt.NoBrush)
                    painter.setPen(QPen(self._color(getattr(point, self.outline_metric), self.ring_range), 2.5))
                    painter.drawEllipse(pos, 7, 7)
                painter.setPen(QPen(palette.color(QPalette.Base), 1))
                painter.setBrush(self._color(point.probability, self.point_range))
                painter.drawEllipse(pos, 4, 4)
                painter.restore()
            if overlay:
                self._draw_labels(painter, selected_color)
            painter.restore()
        painter.end()
        stats = (len(self._label_regions), len(self._screen_points), self.relative_zoom())
        if stats != self._last_stats:
            self._last_stats = stats
            self.view_changed.emit(*stats)

    def _marker_scale(self):
        diameter = self._point_world_diameter() * self._base_scale() * self._zoom
        return min(diameter, float(self.property("maximumPointPixelDiameter") or 8.)) / 8.

    def _draw_labels(self, painter, selected_color):
        palette = self.palette()
        scale = self._text_scale if self._always_labels() else 1.
        font = self._reference_font() if self._always_labels() else self.font()
        metrics = QFontMetricsF(font)
        leader_color = QColor(self.property("leaderLineDarkColor" if palette.color(QPalette.Base).lightness() < 128
                                          else "leaderLineLightColor") or palette.color(QPalette.Mid))
        leader_width = float(self.property("leaderLineWidth") or 1.)
        # Draw leaders first so no leader can cross over another label's text.
        for region, index, _ in self._label_regions:
            point = self.points[index]
            pos = self.world_to_screen(point.x, point.y)
            selected = point.chain_id == self.selected_chain
            painter.setPen(QPen(selected_color if selected else leader_color, leader_width))
            end = QPointF(max(region.left(), min(region.right(), pos.x())),
                          max(region.top(), min(region.bottom(), pos.y())))
            painter.drawLine(pos, end)
        for region, index, lines in self._label_regions:
            selected = self.points[index].chain_id == self.selected_chain
            painter.save()
            painter.translate(region.topLeft())
            painter.scale(scale, scale)
            painter.setFont(font)
            painter.setPen(QPen(selected_color if selected else palette.color(QPalette.Mid), 1))
            background = palette.color(QPalette.Base)
            if self._always_labels() and self.property("labelPosition") == "overlay":
                background.setAlphaF(float(self.property("overlayLabelBackgroundOpacity")))
            painter.setBrush(background)
            painter.drawRoundedRect(QRectF(0, 0, region.width() / scale, region.height() / scale), 4, 4)
            painter.setPen(palette.color(QPalette.Text))
            for number, line in enumerate(lines):
                painter.drawText(QPointF(6, 5 + metrics.ascent() + number * metrics.height()), line)
            painter.restore()

    def _draw_axes(self, painter, area, grid_area):
        palette, metrics = self.palette(), QFontMetricsF(self.font())
        grid = QColor(palette.color(QPalette.Mid))
        grid.setAlpha(80)
        for step in range(6):
            x, y = area.left() + step * area.width() / 5, area.bottom() - step * area.height() / 5
            painter.setPen(QPen(grid, 1))
            if grid_area.left() <= x <= grid_area.right():
                painter.drawLine(QPointF(x, grid_area.top()), QPointF(x, grid_area.bottom()))
            if grid_area.top() <= y <= grid_area.bottom():
                painter.drawLine(QPointF(grid_area.left(), y), QPointF(grid_area.right(), y))
            world = self.screen_to_world(QPointF(x, y))
            painter.setPen(palette.color(QPalette.Text))
            xt, yt = f"{world.x():.4g}", f"{world.y():.4g}"
            painter.drawText(QPointF(x - metrics.horizontalAdvance(xt) / 2, area.bottom() + metrics.height() + 3), xt)
            painter.drawText(QRectF(0, y - metrics.height() / 2, area.left() - 6, metrics.height()), Qt.AlignRight | Qt.AlignVCenter, yt)
        painter.drawText(QPointF(area.center().x(), area.bottom() + 36), "X")
        painter.drawText(QPointF(area.left() - 15, area.top() - 5), "Y")

    def _hits(self, pos):
        self._layout()
        if not self._canvas_screen_rect().intersected(self.plot_rect()).contains(pos):
            return []
        if self._always_labels():
            # A displaced or overlaid label belongs to exactly one instance.
            labels = [index for rect, index, _ in self._label_regions if rect.contains(pos)]
            if labels:
                return labels
        hits = [(index, (point - pos).manhattanLength()) for index, point in self._screen_points
                if (point - pos).manhattanLength() <= 14]
        if hits:
            return [index for index, _ in sorted(hits, key=lambda pair: pair[1])]
        return [index for rect, index, _ in self._label_regions if rect.contains(pos)]

    def tooltip_text(self, indexes):
        blocks = []
        if len(indexes) > 1:
            blocks.append(self._text("overlapFormat", count=len(indexes)))
        # Bound dense hover documents while retaining access through Chain selection.
        for index in indexes[:12]:
            p = self.points[index]
            blocks.append("\n".join([self._text("chainFormat", chain=p.chain_id), *self._detail_lines(p),
                f"X: {p.x:g}", f"Y: {p.y:g}", self._text("observedFormat", risk=percentage(p.observed)),
                self._text("predictedFormat", risk=percentage(p.predicted)), *([p.reason] if p.reason else [])]))
        if len(indexes) > 12:
            blocks.append(self._text("moreFormat", count=len(indexes) - 12))
        return "<qt>" + "<br/><br/>".join(escape(block).replace("\n", "<br/>") for block in blocks) + "</qt>"

    def event(self, event):
        if event.type() == QEvent.ToolTip:
            hits = self._hits(QPointF(event.pos()))
            if hits:
                hits.sort(key=lambda i: self.points[i].chain_id != self.selected_chain)
                QToolTip.showText(event.globalPos(), self.tooltip_text(hits), self)
            else:
                QToolTip.hideText()
            return True
        if event.type() in (QEvent.FontChange, QEvent.StyleChange) and hasattr(self, "_label_cache"):
            self._label_cache.clear()
            self._global_labels = None
            self._canvas_cache = None
            self._invalidate()
        return super().event(event)

    def resizeEvent(self, event):
        at_minimum = self._last_minimum_zoom is not None and math.isclose(self._zoom, self._last_minimum_zoom)
        if at_minimum:
            self._zoom = self.zoom_limits()[0]
        self._constrain_view()
        self._invalidate()
        super().resizeEvent(event)

    def wheelEvent(self, event):
        delta = event.angleDelta().y() or event.pixelDelta().y()
        if delta:
            self.zoom(1.25 ** max(-8., min(8., delta / 120)), event.position())
            event.accept()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._press = event.position()
            self._press_center = QPointF(self._center)
            self._dragged = False
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._press is not None:
            delta = event.position() - self._press
            if delta.manhattanLength() >= QApplication.startDragDistance():
                self._dragged = True
            if self._dragged:
                scale = self._base_scale() * self._zoom
                self._center = self._press_center + QPointF(-delta.x() / scale, delta.y() / scale)
                self._constrain_view()
                self.setCursor(Qt.ClosedHandCursor)
                QToolTip.hideText()
                self._invalidate()
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self._press is not None:
            if not self._dragged:
                hits = self._hits(event.position())
                if hits:
                    chains = list(dict.fromkeys(self.points[i].chain_id for i in hits))
                    index = (chains.index(self.selected_chain) + 1) % len(chains) if self.selected_chain in chains else 0
                    self.set_selected_chain(chains[index])
                    self.chain_selected.emit(chains[index])
            self._press = None
            self.unsetCursor()
            event.accept()
        else:
            super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._press = None
            self.reset_view()
            event.accept()
        else:
            super().mouseDoubleClickEvent(event)
