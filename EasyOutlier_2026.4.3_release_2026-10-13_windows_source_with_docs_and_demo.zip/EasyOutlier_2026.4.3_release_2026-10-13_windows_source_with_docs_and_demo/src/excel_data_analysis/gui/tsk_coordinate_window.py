"""Non-modal coordinate view synchronized with the active TSK result group."""
from PySide6.QtCore import QSignalBlocker, Signal
from PySide6.QtWidgets import QDialog

from ..tsk_sorting import natural_sort_key
from .tsk_coordinate_plot import chain_probability, coordinate_instances
from .tsk_risk_display import percentage
from .tsk_coordinate_labels import default_label_rows
from .ui_tsk_coordinate_window import Ui_TskCoordinateWindowForm


class TskCoordinateWindow(QDialog):
    chain_selected = Signal(str)
    group_selected = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskCoordinateWindowForm()
        self.ui.setupUi(self)
        self._topology = []
        self._chains = {}
        self._coincident = 0
        self._label_layout_dialog = None
        self._label_layouts = {}
        self._label_features = []
        self._label_schema = ()
        self.ui.coordinatePlot.chain_selected.connect(self._point_selected)
        self.ui.coordinatePlot.view_changed.connect(self._update_status)
        self.ui.coordinatePlot.world_sizes_changed.connect(self._world_sizes_changed)
        self.ui.chainComboBox.activated.connect(self._chain_selected)
        self.ui.groupComboBox.activated.connect(self.group_selected.emit)
        self.ui.outlineComboBox.currentIndexChanged.connect(self._outline_changed)
        self.ui.labelsCheckBox.toggled.connect(self._labels_enabled_changed)
        self.ui.labelModeComboBox.currentIndexChanged.connect(self._label_options_changed)
        self.ui.labelPositionComboBox.currentIndexChanged.connect(self._label_options_changed)
        self.ui.initialLabelSizeSpinBox.valueChanged.connect(self.ui.coordinatePlot.set_label_world_height)
        self.ui.maximumLabelSizeSpinBox.valueChanged.connect(self.ui.coordinatePlot.set_maximum_label_pixel_height)
        self.ui.pointWorldDiameterSpinBox.valueChanged.connect(self.ui.coordinatePlot.set_point_world_diameter)
        self.ui.maximumPointDiameterSpinBox.valueChanged.connect(self.ui.coordinatePlot.set_maximum_point_pixel_diameter)
        self.ui.labelLayoutButton.clicked.connect(self._open_label_layout)
        self.ui.zoomInButton.clicked.connect(lambda: self.ui.coordinatePlot.zoom(1.5))
        self.ui.zoomOutButton.clicked.connect(lambda: self.ui.coordinatePlot.zoom(1 / 1.5))
        self.ui.resetButton.clicked.connect(self.ui.coordinatePlot.reset_view)
        self.ui.focusButton.clicked.connect(self.ui.coordinatePlot.focus_selection)
        self._labels_enabled_changed(self.ui.labelsCheckBox.isChecked())
        self._update_status(0, 0, 1.)

    def _text(self, name, **values):
        return str(self.property(name) or "").format(**values)

    def _world_sizes_changed(self, label_height, point_diameter):
        with QSignalBlocker(self.ui.initialLabelSizeSpinBox), QSignalBlocker(self.ui.pointWorldDiameterSpinBox):
            self.ui.initialLabelSizeSpinBox.setValue(label_height)
            self.ui.pointWorldDiameterSpinBox.setValue(point_diameter)

    def set_payload_group(self, payload, group):
        points, self._topology = coordinate_instances(payload, group)
        self._chains = {str(row.get("chain_id")): row for row in group.get("chains", [])}
        self._coincident = len(points) - len({(p.x, p.y) for p in points})
        with QSignalBlocker(self.ui.groupComboBox):
            self.ui.groupComboBox.clear()
            for index, entry in enumerate(payload.get("groups", [])):
                self.ui.groupComboBox.addItem(str(entry.get("label") or entry.get("node") or index + 1))
                if entry is group:
                    self.ui.groupComboBox.setCurrentIndex(index)
        self.ui.groupComboBox.setEnabled(self.ui.groupComboBox.count() > 1)
        config = payload.get("provenance", {}).get("template_snapshot", {}).get("tsk_analysis", {})
        self.ui.contextLabel.setText(self._text("contextFormat", mode=self._text(payload.get("coordinate_view_mode", "fitted") + "ModeText"),
                                              unit=config.get("coordinate_unit") or self._text("unknownUnitText")))
        with QSignalBlocker(self.ui.chainComboBox):
            self.ui.chainComboBox.clear()
            self.ui.chainComboBox.addItem(self._text("allChainsText"), None)
            for chain in sorted({str(row.get("chain_id", "")) for row in self._topology} | set(self._chains), key=natural_sort_key):
                self.ui.chainComboBox.addItem(chain, chain)
        self.ui.coordinatePlot.set_points(points)
        self._label_features = list(dict.fromkeys(name for row in self._topology for name in (row.get("features") or {})))
        self._label_schema = tuple(sorted(self._label_features))
        rows = self._label_layouts.get(self._label_schema, default_label_rows(self._label_features))
        self.ui.coordinatePlot.set_label_rows(rows, self._label_features)
        # Group changes already reset the camera; include the current schema's
        # complete labels after binding its saved field arrangement.
        if self.ui.labelModeComboBox.currentIndex() == 1 and self.ui.labelsCheckBox.isChecked():
            self.ui.coordinatePlot.reset_view()
        if self._label_layout_dialog is not None:
            self._bind_label_layout(rows)
        self.ui.pointLegendLabel.setText(self._range_text(self.ui.coordinatePlot.point_range))
        self._outline_changed()
        self.set_selected_chain(None)
        self._update_status(0, len(points), 1.)

    def _range_text(self, bounds):
        return (self._text("legendFormat", low=percentage(bounds[0]), high=percentage(bounds[1]))
                if bounds is not None else self._text("unavailableText"))

    def _preview_point(self):
        plot = self.ui.coordinatePlot
        return next((point for point in plot.points if point.chain_id == plot.selected_chain),
                    next(iter(plot.points), None))

    def _bind_label_layout(self, rows):
        self._label_layout_dialog.set_context(self._label_features, rows, self._preview_point(),
                                             str(self.ui.coordinatePlot.property("labelValueSeparator")))

    def _open_label_layout(self):
        if self._label_layout_dialog is None:
            from .tsk_label_layout_dialog import TskLabelLayoutDialog
            self._label_layout_dialog = TskLabelLayoutDialog(self)
            self._label_layout_dialog.layout_changed.connect(self._label_layout_changed)
            rows = self.ui.coordinatePlot.label_rows
            self._bind_label_layout(rows if rows is not None else default_label_rows(self._label_features))
        self._label_layout_dialog.show()
        self._label_layout_dialog.raise_()
        self._label_layout_dialog.activateWindow()

    def _label_layout_changed(self, rows):
        self._label_layouts[self._label_schema] = [list(row) for row in rows]
        self.ui.coordinatePlot.set_label_rows(rows, self._label_features)

    def _labels_enabled_changed(self, enabled):
        self.ui.coordinatePlot.set_labels_enabled(enabled)
        self._label_options_changed()

    def _label_options_changed(self, *_):
        enabled = self.ui.labelsCheckBox.isChecked()
        always = self.ui.labelModeComboBox.currentIndex() == 1
        self.ui.labelModeLabel.setEnabled(enabled)
        self.ui.labelModeComboBox.setEnabled(enabled)
        for widget in (self.ui.labelPositionLabel, self.ui.labelPositionComboBox,
                       self.ui.initialLabelSizeLabel, self.ui.initialLabelSizeSpinBox,
                       self.ui.maximumLabelSizeLabel, self.ui.maximumLabelSizeSpinBox):
            widget.setEnabled(enabled and always)
        plot = self.ui.coordinatePlot
        plot.set_label_mode("always" if always else "auto")
        plot.set_label_position(("side", "overlay")[self.ui.labelPositionComboBox.currentIndex()])

    def _outline_changed(self, *_):
        plot = self.ui.coordinatePlot
        plot.set_outline_metric(("observed", "predicted", None)[self.ui.outlineComboBox.currentIndex()])
        self.ui.ringLegendTitle.setText(self.ui.ringLegendTitle.property("formatText").format(metric=self.ui.outlineComboBox.currentText()))
        self.ui.ringLegendLabel.setText(self._range_text(plot.ring_range))
        self.ui.ringGradient.setVisible(plot.outline_metric is not None)
        self.ui.ringLegendLabel.setVisible(plot.outline_metric is not None)

    def set_selected_chain(self, chain_id, *, focus=None):
        plot = self.ui.coordinatePlot
        changed = plot.selected_chain != chain_id
        plot.set_selected_chain(chain_id, focus=changed and (self.ui.followCheckBox.isChecked() if focus is None else focus))
        with QSignalBlocker(self.ui.chainComboBox):
            self.ui.chainComboBox.setCurrentIndex(max(0, self.ui.chainComboBox.findData(chain_id)))
        selected = [point for point in plot.points if point.chain_id == chain_id]
        self.ui.focusButton.setEnabled(bool(selected))
        if self._label_layout_dialog is not None:
            self._label_layout_dialog.set_preview_point(self._preview_point())
        if chain_id is None:
            self.ui.selectionLabel.setText(self._text("noSelectionText"))
        else:
            chain = self._chains.get(chain_id, {})
            self.ui.selectionLabel.setText(self._text("selectionFormat", chain=chain_id, shown=len(selected),
                total=sum(str(row.get("chain_id", "")) == chain_id for row in self._topology),
                observed=percentage(chain_probability(chain, "observed_probability")),
                predicted=percentage(chain_probability(chain, "predicted_probability"))))

    def _chain_selected(self):
        chain_id = self.ui.chainComboBox.currentData()
        self.set_selected_chain(chain_id)
        if chain_id is not None:
            self.chain_selected.emit(chain_id)

    def _point_selected(self, chain_id):
        # Keep the clicked point under the cursor, including coincident chains.
        self.set_selected_chain(chain_id, focus=False)
        self.chain_selected.emit(chain_id)

    def _update_status(self, labels, visible, zoom):
        plot = self.ui.coordinatePlot
        shown, total = len(plot.points), len(self._topology)
        minimum, maximum = plot.zoom_limits()
        relative_zoom = plot.relative_zoom()
        maximum_relative_zoom = maximum / minimum
        self.ui.zoomRangeLabel.setText(self._text("zoomRangeFormat", maximum=f"{maximum_relative_zoom:g}"))
        self.ui.zoomOutButton.setEnabled(bool(shown) and relative_zoom > 1. + 1e-9)
        self.ui.zoomInButton.setEnabled(bool(shown) and relative_zoom < maximum_relative_zoom - 1e-9)
        self.ui.statusLabel.setText(self._text("statusFormat", shown=shown, total=total, missing=total - shown,
            coincident=self._coincident, zoom=f"{relative_zoom:.2g}", labels=labels, visible=visible))
