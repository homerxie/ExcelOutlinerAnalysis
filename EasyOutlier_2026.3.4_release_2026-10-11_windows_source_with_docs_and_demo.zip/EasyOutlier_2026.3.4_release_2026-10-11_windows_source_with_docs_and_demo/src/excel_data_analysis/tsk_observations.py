"""Adapt completed Analyze states to TSK counts without repeating classification."""
from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
from pathlib import Path
import pickle

from .merge_config import chain_level, column_levels
from .reporting import _sample_key_display, _sample_key_from_dimensions
from .tsk_sorting import natural_sort_key


def read_analysis_snapshot(path):
    """Read an application-owned Analyze snapshot, never a user-supplied pickle."""
    if not path or not Path(path).is_file():
        raise ValueError("请先在 Analyze 完成分析，再运行 TSK；TSK 必须基于已完成的 Analyze 结果。")
    with Path(path).open("rb") as stream:
        snapshot = pickle.load(stream)
    if not all(name in snapshot for name in ("template", "rows", "columns", "summary_artifacts")):
        raise ValueError("Analyze 结果不完整，请重新运行 Analyze。")
    return snapshot


def template_for_snapshot(snapshot):
    """Exclude topology branches absent from the actual Analyze column scope."""
    template = deepcopy(snapshot["template"])
    prefix = column_levels(template).index(chain_level(template)) + 1
    chains = {tuple(column.header_values[:prefix]) for column in snapshot["columns"]}
    template.tsk_analysis.instances = [item for item in template.tsk_analysis.instances
                                       if tuple(item.chain_key) in chains]
    if not template.tsk_analysis.instances:
        raise ValueError("Analyze 结果中没有可用于 TSK 的链路；请检查 Analyze 的排除范围及 Chain–TSK 对应表。")
    template.report.outlier_fail_method = snapshot.get("fail_mode", template.report.outlier_fail_method)
    return template


def selected_snapshot_rows(snapshot, options):
    template = snapshot["template"]
    nodes = set(options.get("nodes") or [])
    if options.get("node_mode") == "combined_new":
        available = {row.dimensions.get(template.report.reliability_node_dimension) for row in snapshot["rows"]}
        unknown = nodes - available
        if unknown:
            raise ValueError("组合节点不在 Analyze 结果中：" + "、".join(sorted(unknown)))
    samples = set(options.get("sample_ids") or [])
    rows = []
    for row in snapshot["rows"]:
        sample = _sample_key_from_dimensions(row.dimensions, template.report.sample_dimension_names)
        if nodes and row.dimensions.get(template.report.reliability_node_dimension) not in nodes:
            continue
        if samples and _sample_key_display(sample) not in samples and (not sample or sample[-1] not in samples):
            continue
        rows.append(row)
    if not rows:
        raise ValueError("所选范围在 Analyze 结果中没有样品数据。")
    return rows


def validate_node_mode(node_mode):
    if node_mode not in {"separate", "combined_new"}:
        raise ValueError(f"不支持的 TSK 节点分析方式：{node_mode}")
    return node_mode


def observations_from_snapshot(snapshot, template, rows, batch, warnings=(), *, node_mode="separate"):
    """Count Analyze's final Pass/Fail states; absence of a retained state is Missing."""
    from .tsk_service import _batch_value, _pool_batch_groups

    node_name = template.report.reliability_node_dimension
    combined = validate_node_mode(node_mode) == "combined_new"
    nodes = sorted({row.dimensions[node_name] for row in rows}, key=natural_sort_key)
    if combined and len(nodes) < 2:
        raise ValueError("组合新增分析需要至少两个有样品数据的可靠性节点，请检查 Nodes 和 Sample IDs。")
    dimension = batch["batch_dimension"]
    chain_keys = {tuple(item.chain_key): item.chain_id for item in template.tsk_analysis.instances}
    identities = defaultdict(set)
    for row in rows:
        sample = _sample_key_from_dimensions(row.dimensions, template.report.sample_dimension_names)
        node = row.dimensions[node_name]
        source_batch = _batch_value(row.dimensions, dimension) if dimension is not None else ""
        identities[(sample, node)].add(source_batch)
    if any(len(batches) > 1 for batches in identities.values()):
        raise ValueError("Analyze 的同一样品/节点跨越多个原批次；请将批次加入 Analyze 的唯一 Sample ID 字段后重新分析。")
    source_batches = {next(iter(values)) for values in identities.values()}
    if batch["batch_mode"] == "parent":
        missing = sorted(source for source in source_batches if not batch["batch_mapping"].get(source))
        if missing:
            raise ValueError("请为所有所选原批次填写母批编号：" + ", ".join(missing))

    grouped = defaultdict(dict)
    for (sample, node), batches in identities.items():
        outcomes = grouped[(node, next(iter(batches)))]
        for chain in chain_keys.values():
            outcomes[(sample, chain)] = "Missing"
    seen = set()
    for record in snapshot["summary_artifacts"]["final_status_rows"]:
        identity = (tuple(record["sample_key"]), record["node"])
        chain = chain_keys.get(tuple(record["test_group_key"]))
        if identity not in identities or chain is None:
            continue
        key = (*identity, chain)
        if key in seen:
            raise ValueError("Analyze 结果中一个样品/节点/Chain 存在多个状态，请检查唯一 Sample ID。")
        seen.add(key)
        batch_id = next(iter(identities[identity]))
        if combined and record["is_fail"] and record.get("status") not in {"New", "Existed"}:
            raise ValueError("Analyze 结果缺少新增 / 已有异常标记，请重新运行 Analyze 后再组合节点。")
        failed = record["is_fail"] and (not combined or record["status"] == "New")
        grouped[(identity[1], batch_id)][(identity[0], chain)] = "Fail" if failed else "Pass"

    members = {}
    if combined:
        # One observation per original batch, unique sample and Chain. New wins
        # over non-new; any retained state wins over Missing. Never add exposures
        # across repeated nodes or average their already-fitted probabilities.
        pooled = defaultdict(dict)
        node_label = " + ".join(nodes)
        priority = {"Missing": 0, "Pass": 1, "Fail": 2}
        for (node, source_batch), outcomes in grouped.items():
            target = pooled[(node_label, source_batch)]
            for key, status in outcomes.items():
                if priority[status] >= priority.get(target.get(key), -1):
                    target[key] = status
                detail = members.setdefault((source_batch, *key), {"observed_nodes": [], "new_nodes": []})
                if status != "Missing":
                    detail["observed_nodes"].append(node)
                if status == "Fail":
                    detail["new_nodes"].append(node)
        grouped = pooled

    output = []
    for (node, source_batch), outcomes in sorted(grouped.items()):
        counts = {chain: dict(chain_id=chain, n_tested=0, n_failed=0, n_passed=0, n_missing=0)
                  for chain in chain_keys.values()}
        paired = []
        for (sample, chain), status in sorted(outcomes.items(), key=lambda item: (
                tuple(natural_sort_key(value) for value in item[0][0]), natural_sort_key(item[0][1]))):
            count = counts[chain]
            count[{"Missing": "n_missing", "Fail": "n_failed", "Pass": "n_passed"}[status]] += 1
            count["n_tested"] += int(status != "Missing")
            paired.append({"sample_key": list(sample), "chain_id": chain, "status": status,
                           **({name: sorted(values, key=natural_sort_key) for name, values in
                               members[(source_batch, sample, chain)].items()} if combined else {})})
        output.append({"label": f"{node_name}{' 新增组合' if combined else ''}={node}", "node": node, "stratum": {},
                       **({"node_mode": node_mode, "source_nodes": nodes} if combined else {}),
                       "counts": sorted(counts.values(), key=lambda row: natural_sort_key(row["chain_id"])),
                       "sample_outcomes": paired, "classification_warnings": list(warnings),
                       **({"source_batch": source_batch} if dimension is not None else {})})
    return _pool_batch_groups(output, batch) if dimension is not None else output
