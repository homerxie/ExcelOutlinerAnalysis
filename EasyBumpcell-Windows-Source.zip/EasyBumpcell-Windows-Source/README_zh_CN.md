# EasyBumpcell

[English](README.md) | **简体中文**

EasyBumpcell v1.2 是一款基于 PySide6 的跨平台桌面程序，用于生成多 Layer 同心的 Round 或 Oval sample GDS、匹配的 Al Pad LEF abstract，以及全英文 PDF 验证报告。

- 新用户：请阅读中文 [5 分钟快速入门教程](docs/QUICKSTART_zh_CN.md)。
- 产品需求：[PRODUCT_SPECIFICATION.md](PRODUCT_SPECIFICATION.md)
- 开发计划：[DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md)

![已完成 Round 示例配置的 EasyBumpcell](docs/images/quickstart-ready.png)

## 生成内容

| 导出选择 | GDS 文件 | LEF 文件 | PDF 报告 |
|---|---:|---:|---:|
| Round | 1 | 1 | 1 份 Round 报告 |
| Oval | 4（`0D`、`45D`、`90D`、`135D`） | 4 | 1 份 Oval 报告 |
| Round + Oval | 5 | 5 | 1 份合并报告 |

每个 GDS 都包含所有已配置 Layer 的 Polygon。每个对应的 LEF 包含一个使用用户所选 Al Pad Drawing Layer 的 Macro。报告记录生成的名称、校验和、几何、坐标约定和验证结果。

## 标准使用流程

1. 应用经过审核的工艺模板，或手动输入工艺数据。
2. 输入必填的文件 Version，并选择 Round 或 Oval 进行实时预览。
3. 完成每个 Layer 的 Layer Name、Layer Number、Datatype 和形状尺寸。
4. 标记 Tapeout Layer，并通过拖动将各行排列成正确的工艺顺序。
5. 选择并验证 LEF 实际使用的 Al Pad Drawing Layer。
6. 确认 Tapeout 工艺顺序。
7. 检查符合 DBU 网格要求的 GDS 预览和从 LEF 文本解析出的 LEF 预览。
8. 点击“导出”，选择一个或两个尺寸完整的 Shape，并选择输出目录。
9. 逐项勾选“导出前必须确认”中的所有内容，然后写入文件。

程序无法自行检查外部 techfile、layermap 或 design rule 文档。用户仍需负责确认这些工艺定义。

## 当前默认设置

- 界面语言：首次启动使用 English；可以在运行时切换 English 和简体中文，所选语言会被保存。
- Shape Type：`Round`。
- Process DBU：`0.0005 µm`；另一个支持值是 `0.001 µm`。
- Al Pad Layer：默认不选择，必须由用户明确指定。
- Origin：默认与所选 Al Pad Layer 同步，并放在该 Layer 最终量化后 Bounding Box 的左下角。
- 预览控制：`显示节点`和`吸附到节点`默认都已开启。
- Layer Number 和尺寸默认为空；Datatype 默认为 `0`。

默认 Layer 表如下：

| 顺序 | Layer Name | Tapeout？ |
|---:|---|:---:|
| 1 | AP | 是 |
| 2 | ALPAD | 否 |
| 3 | CB2 | 是 |
| 4 | PIO | 是 |
| 5 | UBM | 是 |
| 6 | UBM_CU | 否 |

`Tapeout?` 决定哪些 Layer 参与输出文件名、自动 Cell Name 和已确认的工艺顺序文本。非 Tapeout Layer 仍会保留在 GDS 几何中；经过明确确认后，也可以选择非 Tapeout Layer 作为 LEF Al Pad Layer。

## 几何与坐标保证

### Round

- 每个 Layer 使用一个规则 64 边形。
- 第一个点是最右侧的垂直中点。
- 所有点按逆时针排列，并包含四个坐标轴极值点。

### Oval

- 每个 Layer 使用一个 66 边的 elongated-circle Polygon：两端半圆各 33 个点，并由上下两条直边连接。
- 分别生成 `0D`、`45D`、`90D` 和 `135D` 四个独立 Layout。
- 在 `0D` 时，第一个点位于长轴正方向端点。第一个点随几何一起旋转，所有 Polygon 始终保持逆时针方向。
- 默认零度长轴沿 X 轴，默认正角度方向为逆时针。两项都可以在“高级设置”中修改。

### DBU 与 Origin

- 所有输入尺寸都是正数 µm，且最多保留一位小数。
- Oval 必须满足 `Major Axis > Minor Axis > 0`。
- 几何先旋转，再量化到整数 Process DBU 坐标。
- GDS 和 LEF 复用完全相同且顺序一致的 Al Pad 量化 Polygon 坐标，包括第一个点。
- 默认 Origin 跟随所选 Al Pad Layer。“高级设置”可以关闭同步、选择其他参考 Layer，或使用共同中心。
- LEF `FOREIGN` 记录从 GDS Origin 到 Macro 左下角的向量；`ORIGIN` 记录从该左下角返回 Macro Origin 的反向向量。

## Layer、LEF 与命名

- Layer Number 必须是 `0` 到 `65535` 的整数。
- Datatype 必须是 `0` 到 `255` 的整数。
- Layer Number/Datatype 组合以及 Layer Name 都不能重复。
- Technology Name 仅接受 ASCII 字母和数字。
- Bump Type 和 Layer Name 接受 ASCII 字母、数字和下划线。
- Version 接受 ASCII 字母和数字；点号或连字符只能位于字母数字组之间，例如 `V1`、`1.0` 或 `V1.2-rc1`。
- Version 会附加到每个 GDS、LEF 和 PDF 文件名中，但不会加入内部 GDS Cell Name 或 LEF Macro Name。
- 输出文件名包含每个 Tapeout Layer 及其四舍五入后的尺寸标记。
- 自动生成的内部 Cell Name 默认使用 Bump Type 加上首个和末个 Tapeout Layer。“高级设置”可以增加其他 Tapeout Layer，或手动覆盖名称。
- Cell Name 硬上限为 127 个字符；输出文件名硬上限为 255 个字符。可选的严格旧版兼容模式会在 Cell Name 超过历史上的 32 字符限制时发出警告。

每个 LEF 使用版本 `5.8`，并包含一个 `CLASS COVER BUMP` Macro。LEF Macro Name 与对应的 GDS Cell Name 完全一致。其 PIN Polygon 直接复制所选 Al Pad Layer 的最终 GDS Polygon，不进行轮廓转换或坐标平移。

实时 LEF 预览不会根据 GDS Shape 另行重建。EasyBumpcell 会先序列化完整 LEF 定义，再从同一份文本中解析 PIN、LABEL 和由 `ORIGIN`/`SIZE` 定义的 BOUNDARY。PDF 报告解析的是已经过验证的暂存 LEF 文件原文。

## 工艺模板

工艺模板是 JSON 文件，存放在源码目录或打包程序旁的 `template` 文件夹中。

schema v3 模板包含：

- Technology Name 和可选的 Bump Type
- 一个或两个尺寸完整的 Shape Type
- Process DBU
- 完整且有序的 Layer 列表
- Layer Number、Datatype、Round/Oval 尺寸、颜色、预览纹理和 Tapeout 状态
- 已选择的 Al Pad Layer
- 高级设置中的全部选项：原点同步、参考 Layer 与原点定义，Oval 轴向与旋转约定，参与 Cell Name 的 Layer、手动 Cell Name，以及严格旧版 GDSII 兼容模式

Version 被有意排除在模板之外。应用模板时会保留当前 Version，并且一定会重置 Process Order 确认，要求用户重新人工检查。

只能保存尺寸完整的 Shape Type。同时选择两种 Shape 会生成包含 `Round_Oval` 的模板名称。用户可以在主窗口中保存、导入、导出、覆盖和删除模板。程序仍兼容读取 schema v1 和 schema v2 模板；由于旧模板尚未保存高级设置，应用旧模板时会保留当前高级设置。

源码仓库包含供快速入门教程使用的 `template/C1x_CuBOT_Round_Oval_V2.json`。它只是演示数据，不能用于真实 Tapeout。Windows 打包脚本会在发布包中创建一个初始为空、可写入的 `template` 文件夹。

## 预览与报告

主窗口提供独立的 GDS 和 LEF 预览页。

- GDS 预览显示所有最终量化后的 Layer Polygon。
- LEF 预览显示所选 Al Pad 的 PIN Polygon、LABEL Anchor 和已经验证的 BOUNDARY。
- 颜色与透明矢量纹理组合使用，使完全重合的 Layer 仍可区分。
- 自适应 µm 坐标轴、数值刻度、鼠标十字线和实时坐标都使用最终 GDS 坐标系。
- `显示节点`显示真实的量化 Polygon 顶点。
- `吸附到节点`会在 UI 阈值范围内将十字线吸附到最近的真实顶点。
- 预览标题显示真实 Polygon 节点数和最终 Bumpcell Center。
- 输出摘要显示 Cell Base Name、Polygon 节点数、DBU/Origin 设置和校验状态。
- 节点显示和吸附只影响实时 UI，不会修改 GDS、LEF、模板或 PDF 输出。

全英文 PDF 使用横向 A4 页面，标题为 `Sample GDS report`。Technology Name、Bump Type、Version 和 Shape Type 位于报告开头的身份信息区域，随后 Round、Oval 和合并报告都使用以下章节顺序：

1. LEF PIN Layer and Process DBU
2. Layer Number/Datatype Mapping（包含 Tapeout 状态）
3. GDS Preview - Common Scale
4. LEF Preview - Common Scale
5. Generated GDS, LEF, Cell, and Macro Names
6. POSIX Checksums
7. Nominal Dimensions vs Actual Quantized Axis Dimensions
8. Coordinate and Validation Summary

Oval 行还会记录零度轴和正角度旋转方向。联合导出会共用一组表格和统一比例的预览，不会为每个 Shape 重复生成独立报告章节。

## 验证与导出安全

在启用“导出”之前，必须至少有一个尺寸完整的 Shape 通过项目验证、明确选择 Al Pad Layer，并确认 Tapeout 工艺顺序。

“导出前必须确认”要求用户核对：

- Process DBU 是否与所选工艺的 techfile（`*.tf`）一致
- 所有 GDS Layer Number 和 Datatype 是否与当前 Bump design rule 一致
- 所选 Al Drawing Layer 的 Layer Name、Layer Number 和 Datatype 是否与工艺 layermap（`*.map` / `*.layermap`）一致
- 所选 Layer 是否为实际使用的 Al Drawing Layer，而不是 Marking Layer 或 Dummy Layer
- Tapeout Layer 及其工艺顺序
- 每一条运行时量化警告和已有文件覆盖提示

每一项都必须单独勾选。Checklist 文本会在打开对话框时从 `src/easybumpcell/export_checklist.json` 读取。

导出采用暂存并一次性提交的流程：

1. 在临时目录中生成所有请求的 GDS。
2. 回读每个 GDS，并验证 Library、Cell、Layer 映射、坐标、节点顺序和边界。
3. 生成并验证每个对应的 LEF。
4. 为每个 GDS 和 LEF 计算 POSIX/Linux `cksum` CRC 和字节数。
5. 使用已验证的暂存文件生成 PDF。
6. 将完整输出集移动到目标目录；如果最终提交失败，则恢复原有文件。

生成或验证失败时，不会在正式输出目录中留下不完整的文件集。

## 源码环境配置

从源码运行需要 Python 3.10 或更高版本。

### Windows PowerShell

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip setuptools wheel
python -m pip install -e ".[dev]"
python scripts\generate_ui.py
python scripts\generate_translations.py
python -m pytest
python -m easybumpcell.app
```

如果 PowerShell 阻止执行激活脚本，可以直接调用虚拟环境中的程序：

```powershell
.\.venv\Scripts\python.exe scripts\generate_ui.py
.\.venv\Scripts\python.exe scripts\generate_translations.py
.\.venv\Scripts\python.exe -m pytest
.\.venv\Scripts\python.exe -m easybumpcell.app
```

### macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -e '.[dev]'
python scripts/generate_ui.py
python scripts/generate_translations.py
python -m pytest
python -m easybumpcell.app
```

### Linux

请先安装 Python、venv 支持以及 Qt 所需的桌面库。在 Debian/Ubuntu 上，可以从以下命令开始：

```bash
sudo apt-get install python3 python3-venv libegl1 libgl1
```

然后执行：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -e '.[dev]'
python scripts/generate_ui.py
python scripts/generate_translations.py
python -m pytest
python -m easybumpcell.app
```

安装完成后，也可以使用控制台命令 `easybumpcell` 启动程序。

源码包含 `.vscode/launch.json`。使用 VS Code 打开含有 `pyproject.toml` 的目录，选择虚拟环境中的 Python，选择 `Debug EasyBumpcell`，然后按 F5。

## 开发流程

### 仓库结构

```text
src/easybumpcell/domain/       项目和 Layer 数据模型
src/easybumpcell/geometry/     Round/Oval 构造、旋转和量化
src/easybumpcell/services/     命名、验证以及 GDS/LEF/PDF 导出与校验
src/easybumpcell/ui/           手写的 Qt Controller 和自定义 Widget
src/easybumpcell/ui_generated/ 由 pyside6-uic 生成的模块
ui/                            Qt Designer 源文件
tests/                         核心、UI、i18n、资源和模板测试
template/                      源码环境使用的工艺模板
demo/                          示例输出文件
```

运行完整测试：

```bash
python -m pytest
```

手动验证 POSIX checksum 兼容性：

```bash
cksum path/to/generated.gds
```

十进制 CRC 和字节数必须与 PDF 报告中的数值一致。

### Qt Designer 与 Qt Linguist

`ui/` 下的 `.ui` 文件是所有静态窗口和对话框布局的唯一源文件：

```text
ui/main_window.ui
ui/advanced_dialog.ui
ui/export_dialog.ui
ui/export_shape_dialog.ui
ui/template_save_dialog.ui
```

修改 `.ui` 文件后，重新生成 Python 模块：

```bash
python scripts/generate_ui.py
```

不要手动编辑 `src/easybumpcell/ui_generated/ui_*.py`。信号连接、Model、验证和自定义绘制应放在 `src/easybumpcell/ui/` 中。

English 是 UI 源语言。简体中文翻译维护在 `src/easybumpcell/translations/easybumpcell_zh_CN.ts` 中。修改可见 UI 文本后执行：

```bash
python scripts/generate_translations.py
pyside6-linguist src/easybumpcell/translations/easybumpcell_zh_CN.ts
python scripts/generate_translations.py
```

导出 Checklist 是例外：它的中英文文本直接来自 `src/easybumpcell/export_checklist.json`，不使用 Qt Linguist。修改时必须保留对应字符串所使用的占位符，包括 `{DBU}`、`{technology_name}`、`{process_order}`、`{all_layers}`、`{Al_layername}`、`{Al_layernumb_datatype}`、`{layer_number}`、`{datatype}`、`{message}` 和 `{count}`。

### 帮助图片

Process DBU 和 Layer 与工艺顺序旁的圆形 `?` 按钮会显示以下图片 Tooltip：

```text
src/easybumpcell/help_images/process_dbu_help.png
src/easybumpcell/help_images/layer_mapping_help.png
```

PyInstaller 会将这些文件作为 package data 收集。打包后的程序可以使用可执行文件旁的 `help_images` 文件夹覆盖它们。图片保持宽高比且不会被放大；只有超过 `720 × 480` 逻辑像素的 Tooltip 限制或当前屏幕可用区域的 90% 时才会平滑缩小。

## 打包

本仓库不直接交付预构建应用。必须在与目标平台相同的操作系统上构建。打包前请重新生成 UI 和翻译，并运行测试：

```bash
python scripts/generate_ui.py
python scripts/generate_translations.py
python -m pytest
```

### Windows

PyInstaller 不能在 macOS 或 Linux 上交叉编译 Windows 程序。请在 Windows 上运行：

```powershell
python scripts\package_windows_release.py
```

脚本会重新生成 UI/翻译、运行测试、构建 PyInstaller one-directory 应用，并创建 `dist\EasyBumpcell-Windows.zip`。使用 `EasyBumpcell\EasyBumpcell.exe` 启动打包后的程序。

只有在同一份源码中测试已经通过时，才应使用 `python scripts\package_windows_release.py --skip-tests`。可执行文件嵌入 `Icon/NeonDoubleRingIcon.ico`，完整运行时图标集复制到 `EasyBumpcell\internal\Icon\`。

### macOS

请在目标 CPU 架构上原生运行：

```bash
python -m PyInstaller --noconfirm --clean --windowed \
  --contents-directory internal \
  --name EasyBumpcell \
  --paths src \
  --collect-data easybumpcell \
  --add-data Icon:Icon \
  --icon Icon/NeonDoubleRingIcon.icns \
  src/easybumpcell/app.py
```

输出为 `dist/EasyBumpcell.app`。除非已经准备并测试通用 Python 环境和通用依赖，否则应分别为 Apple Silicon 和 Intel 构建。

### Linux

请在需要支持的最旧 Linux/glibc 环境中构建：

```bash
python -m PyInstaller --noconfirm --clean --windowed \
  --contents-directory internal \
  --name EasyBumpcell \
  --paths src \
  --collect-data easybumpcell \
  --add-data Icon:Icon \
  src/easybumpcell/app.py
```

输出位于 `dist/EasyBumpcell/`。它可以直接作为目录压缩包发布，也可以作为 AppImage 工作流的输入。

## 输出命名示例

Round：

```text
TechName_LF_Round_80AP_40CB2_30PIO_60UBM_V1.gds
TechName_LF_Round_80AP_40CB2_30PIO_60UBM_V1.lef
TechName_LF_Round_80AP_40CB2_30PIO_60UBM_Report_V1.pdf
```

以上示例默认对应的内部 Round Cell/LEF Macro Name 为：

```text
LF_AP80_UBM60
```

Oval：

```text
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_0D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_0D_V1.lef
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_45D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_45D_V1.lef
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_90D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_90D_V1.lef
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_135D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_135D_V1.lef
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_Report_V1.pdf
```

同时导出两个 Shape 时使用相同的五组 GDS/LEF，并生成一个合并报告：

```text
TechName_LF_Round_Oval_Report_V1.pdf
```
