from __future__ import annotations

import re
from pathlib import Path

from PySide6.QtCore import (
    QCoreApplication,
    QLibraryInfo,
    QObject,
    QSettings,
    QTranslator,
    Signal,
)


ENGLISH = "en"
SIMPLIFIED_CHINESE = "zh_CN"
SUPPORTED_LANGUAGES = (ENGLISH, SIMPLIFIED_CHINESE)
LANGUAGE_SETTINGS_KEY = "interface/language"


def _translate(context: str, source: str) -> str:
    return QCoreApplication.translate(context, source)


def translate_enum(value: str) -> str:
    translations = {
        "Round": _translate("Enums", "Round"),
        "Oval": _translate("Enums", "Oval"),
        "Reference Layer Bounding Box Lower-left": _translate(
            "Enums",
            "Reference Layer Bounding Box Lower-left",
        ),
        "Common Center": _translate("Enums", "Common Center"),
        "X Axis": _translate("Enums", "X Axis"),
        "Y Axis": _translate("Enums", "Y Axis"),
        "Counterclockwise": _translate("Enums", "Counterclockwise"),
        "Clockwise": _translate("Enums", "Clockwise"),
    }
    return translations.get(value, value)


def translate_preview_pattern(value: str) -> str:
    translations = {
        "Forward Diagonal": _translate("PreviewPatterns", "Forward Diagonal"),
        "Backward Diagonal": _translate("PreviewPatterns", "Backward Diagonal"),
        "Diagonal Crosshatch": _translate(
            "PreviewPatterns",
            "Diagonal Crosshatch",
        ),
        "Dots": _translate("PreviewPatterns", "Dots"),
        "Horizontal Lines": _translate("PreviewPatterns", "Horizontal Lines"),
        "Vertical Lines": _translate("PreviewPatterns", "Vertical Lines"),
        "Grid": _translate("PreviewPatterns", "Grid"),
        "Dense Dots": _translate("PreviewPatterns", "Dense Dots"),
    }
    return translations.get(value, value)


def _translated_field_name(value: str) -> str:
    suffixes = (
        (" Minor Axis", _translate("Validation", "Minor Axis")),
        (" Major Axis", _translate("Validation", "Major Axis")),
        (" Diameter", _translate("Validation", "Diameter")),
    )
    for suffix, translated_suffix in suffixes:
        if value.endswith(suffix):
            return f"{value.removesuffix(suffix)} {translated_suffix}"
    translations = {
        "Technology Name": _translate("Validation", "Technology Name"),
        "Layer Name": _translate("Validation", "Layer Name"),
        "Layer Number": _translate("Validation", "Layer Number"),
        "Datatype": _translate("Validation", "Datatype"),
        "Version": _translate("Validation", "Version"),
        "Bump Type": _translate("Validation", "Bump Type"),
        "Dimension": _translate("Validation", "Dimension"),
        "Diameter": _translate("Validation", "Diameter"),
        "Minor Axis": _translate("Validation", "Minor Axis"),
        "Major Axis": _translate("Validation", "Major Axis"),
    }
    return translations.get(value, value)


def translate_validation_message(message: str) -> str:
    exact_messages = {
        "At least one layer is required": _translate(
            "Validation",
            "At least one layer is required",
        ),
        "At least one Tapeout layer is required": _translate(
            "Validation",
            "At least one Tapeout layer is required",
        ),
        "Process DBU must be a positive finite value": _translate(
            "Validation",
            "Process DBU must be a positive finite value",
        ),
        "The origin reference layer does not exist": _translate(
            "Validation",
            "The origin reference layer does not exist",
        ),
        "Origin reference layer does not exist": _translate(
            "Validation",
            "Origin reference layer does not exist",
        ),
        "Select the Al Pad Layer for LEF output": _translate(
            "Validation",
            "Select the Al Pad Layer for LEF output",
        ),
        "Select the Al Pad Layer below the Layer table before export": _translate(
            "Validation",
            "Select the Al Pad Layer below the Layer table before export",
        ),
        "Confirm the layer process order before export": _translate(
            "Validation",
            "Confirm the layer process order before export",
        ),
        "Cell Name dimension selection contains deleted layers": _translate(
            "Validation",
            "Cell Name dimension selection contains deleted layers",
        ),
        "Select at least one layer for the Cell Name": _translate(
            "Validation",
            "Select at least one layer for the Cell Name",
        ),
        "Select at least one Tapeout layer for the Cell Name": _translate(
            "Validation",
            "Select at least one Tapeout layer for the Cell Name",
        ),
        "Layer Name may contain ASCII letters, digits and underscores only": _translate(
            "Validation",
            "Layer Name may contain ASCII letters, digits and underscores only",
        ),
        "Manual Cell Name may contain ASCII letters, digits and underscores only": _translate(
            "Validation",
            "Manual Cell Name may contain ASCII letters, digits and underscores only",
        ),
        "Version must begin with V and may otherwise contain ASCII letters, digits, periods and hyphens, with separators only between alphanumeric groups": _translate(
            "Validation",
            "Version must begin with V and may otherwise contain ASCII letters, digits, periods and hyphens, with separators only between alphanumeric groups",
        ),
        "Bump Type may contain ASCII letters, digits and underscores only": _translate(
            "Validation",
            "Bump Type may contain ASCII letters, digits and underscores only",
        ),
        "Unable to quantize polygon vertex inside the nominal polygon": _translate(
            "Validation",
            "Unable to quantize polygon vertex inside the nominal polygon",
        ),
        "A centrally symmetric polygon must have an even vertex count": _translate(
            "Validation",
            "A centrally symmetric polygon must have an even vertex count",
        ),
        "Polygon is not centrally symmetric": _translate(
            "Validation",
            "Polygon is not centrally symmetric",
        ),
        "All layer polygons in one generated layout must use the same node count": _translate(
            "Validation",
            "All layer polygons in one generated layout must use the same node count",
        ),
    }
    translated = exact_messages.get(message)
    if translated is not None:
        return translated

    match = re.fullmatch(r"(.+) is required", message)
    if match:
        return _translate("Validation", "{field} is required").format(
            field=_translated_field_name(match.group(1)),
        )
    match = re.fullmatch(
        r"(.+) may contain ASCII letters and digits only",
        message,
    )
    if match:
        return _translate(
            "Validation",
            "{field} may contain ASCII letters and digits only",
        ).format(field=_translated_field_name(match.group(1)))
    match = re.fullmatch(
        r"(.+) must be a positive number with at most one decimal place",
        message,
    )
    if match:
        return _translate(
            "Validation",
            "{field} must be a positive number with at most one decimal place",
        ).format(field=_translated_field_name(match.group(1)))
    match = re.fullmatch(r"Duplicate Layer Name: (.+)", message)
    if match:
        return _translate("Validation", "Duplicate Layer Name: {name}").format(
            name=match.group(1),
        )
    match = re.fullmatch(
        r"(.+): (Major Axis|major axis) must be greater than (Minor Axis|minor axis)",
        message,
    )
    if match:
        return _translate(
            "Validation",
            "{name}: Major Axis must be greater than Minor Axis",
        ).format(name=match.group(1))
    match = re.fullmatch(
        r"(.+): Layer Number must be an integer from 0 to 65535",
        message,
    )
    if match:
        return _translate(
            "Validation",
            "{name}: Layer Number must be an integer from 0 to 65535",
        ).format(name=match.group(1))
    match = re.fullmatch(
        r"(.+): Datatype must be an integer from 0 to 255",
        message,
    )
    if match:
        return _translate(
            "Validation",
            "{name}: Datatype must be an integer from 0 to 255",
        ).format(name=match.group(1))
    match = re.fullmatch(r"Duplicate Layer Number/Datatype: (.+)", message)
    if match:
        return _translate(
            "Validation",
            "Duplicate Layer Number/Datatype: {pair}",
        ).format(pair=match.group(1))
    match = re.fullmatch(
        r"(.+): unsupported preview pattern (.+)",
        message,
    )
    if match:
        return _translate(
            "Validation",
            "{name}: unsupported preview pattern {pattern}",
        ).format(name=match.group(1), pattern=match.group(2))
    match = re.fullmatch(
        r"(.+) (Diameter|Minor Axis|Major Axis) endpoints fall on half-grid positions for Process DBU (.+) µm\. DBU will not be changed\.",
        message,
    )
    if match:
        return _translate(
            "Validation",
            "{name} {dimension} endpoints fall on half-grid positions for Process DBU {dbu} µm. DBU will not be changed.",
        ).format(
            name=match.group(1),
            dimension=_translated_field_name(match.group(2)),
            dbu=match.group(3),
        )
    match = re.fullmatch(
        r"(\d+) existing output file\(s\) will be replaced\.",
        message,
    )
    if match:
        return _translate(
            "Validation",
            "{count} existing output file(s) will be replaced.",
        ).format(count=match.group(1))
    match = re.fullmatch(
        r"(\d+) generated Cell name\(s\) exceed the (\d+)-character limit \(maximum (\d+)\)",
        message,
    )
    if match:
        return _translate(
            "Validation",
            "{count} generated Cell name(s) exceed the {limit}-character limit (maximum {maximum})",
        ).format(
            count=match.group(1),
            limit=match.group(2),
            maximum=match.group(3),
        )
    match = re.fullmatch(
        r"(\d+) generated Cell name\(s\) exceed 32 characters \(maximum (\d+)\); some legacy GDS tools may reject them",
        message,
    )
    if match:
        return _translate(
            "Validation",
            "{count} generated Cell name(s) exceed 32 characters (maximum {maximum}); some legacy GDS tools may reject them",
        ).format(count=match.group(1), maximum=match.group(2))
    match = re.fullmatch(
        r"(\d+) output file name\(s\) exceed the (\d+)-character limit \(maximum (\d+)\)",
        message,
    )
    if match:
        return _translate(
            "Validation",
            "{count} output file name(s) exceed the {limit}-character limit (maximum {maximum})",
        ).format(
            count=match.group(1),
            limit=match.group(2),
            maximum=match.group(3),
        )
    return message


class LanguageManager(QObject):
    languageChanged = Signal(str)

    def __init__(
        self,
        parent: QObject | None = None,
        settings: QSettings | None = None,
    ) -> None:
        super().__init__(parent)
        self._settings = settings
        self._language = ENGLISH
        self._application_translator = QTranslator(self)
        self._qt_translator = QTranslator(self)
        if self._settings is not None:
            stored_language = str(
                self._settings.value(
                    LANGUAGE_SETTINGS_KEY,
                    ENGLISH,
                )
            )
            if stored_language not in SUPPORTED_LANGUAGES:
                stored_language = ENGLISH
            self.set_language(stored_language)

    @property
    def language(self) -> str:
        return self._language

    def set_language(self, language: str) -> bool:
        if language not in SUPPORTED_LANGUAGES:
            raise ValueError(f"Unsupported interface language: {language}")
        if language == self._language:
            self._save_language(language)
            return False

        application = QCoreApplication.instance()
        if application is None:
            raise RuntimeError("A QCoreApplication is required before changing language")
        application.removeTranslator(self._application_translator)
        application.removeTranslator(self._qt_translator)

        if language == SIMPLIFIED_CHINESE:
            translation_path = (
                Path(__file__).resolve().parent
                / "translations"
                / "easybumpcell_zh_CN.qm"
            )
            if not self._application_translator.load(str(translation_path)):
                raise RuntimeError(
                    f"Unable to load interface translation: {translation_path}"
                )
            application.installTranslator(self._application_translator)

            qt_translation_path = Path(
                QLibraryInfo.path(QLibraryInfo.LibraryPath.TranslationsPath)
            )
            if self._qt_translator.load(
                "qtbase_zh_CN",
                str(qt_translation_path),
            ):
                application.installTranslator(self._qt_translator)

        self._language = language
        self._save_language(language)
        self.languageChanged.emit(language)
        return True

    def _save_language(self, language: str) -> None:
        if self._settings is None:
            return
        self._settings.setValue(LANGUAGE_SETTINGS_KEY, language)
        self._settings.sync()
