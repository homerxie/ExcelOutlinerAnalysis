<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>AdvancedDialog</name>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="6"/>
        <source>Advanced Settings</source>
        <translation>高级设置</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="18"/>
        <source>Coordinate Settings</source>
        <translation>坐标设置</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="24"/>
        <source>Sync Origin Reference to LEF Al Pad Layer</source>
        <translation>原点默认同步 LEF Al Pad Layer</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="34"/>
        <source>Origin Reference Layer</source>
        <translation>原点 Reference Layer</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="44"/>
        <source>Origin Definition</source>
        <translation>原点定义</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="57"/>
        <source>Oval Angle Convention</source>
        <translation>椭圆角度约定</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="63"/>
        <source>Zero-Degree Axis</source>
        <translation>零度轴</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="73"/>
        <source>Positive Rotation</source>
        <translation>正向旋转</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="86"/>
        <source>Cell Name Settings</source>
        <translation>Cell Name 设置</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="92"/>
        <source>Dimensions Included in Cell Name</source>
        <translation>Cell Name 包含的尺寸</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="102"/>
        <source>Reset to First and Last Layers</source>
        <translation>重置为首层和末层</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="109"/>
        <source>Strict Legacy GDSII Compatibility</source>
        <translation>严格兼容旧版 GDSII</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="112"/>
        <source>Checked: the legacy GDSII Cell Name compatibility limit is 32 characters; longer names show a warning but can still be exported. Unchecked: the Cell Name hard limit is 127 characters; longer names cannot be exported.</source>
        <translation>勾选：旧版 GDSII 的 Cell Name 兼容限制为 32 个字符；超过 32 个字符会显示警告，但仍可导出。不勾选：Cell Name 硬上限为 127 个字符；超过 127 个字符将无法导出。</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="119"/>
        <source>Override automatically generated base name</source>
        <translation>覆盖自动生成的基础名称</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="129"/>
        <source>ASCII letters, digits and underscores only</source>
        <translation>仅限 ASCII 字母、数字和下划线</translation>
    </message>
</context>
<context>
    <name>AdvancedSettingsDialog</name>
    <message>
        <location filename="../ui/advanced_dialog.py" line="76"/>
        <source>{name} — Layer Number {layer} / Datatype {datatype}</source>
        <translation>{name} — Layer Number {layer} / Datatype {datatype}</translation>
    </message>
</context>
<context>
    <name>CheckableComboBox</name>
    <message>
        <location filename="../ui/checkable_combo_box.py" line="16"/>
        <source>Select at least one layer</source>
        <translation>请至少选择一层</translation>
    </message>
</context>
<context>
    <name>Enums</name>
    <message>
        <location filename="../i18n.py" line="28"/>
        <source>Round</source>
        <translation>圆形</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="29"/>
        <source>Oval</source>
        <translation>椭圆</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="30"/>
        <source>Reference Layer Bounding Box Lower-left</source>
        <translation>Reference Layer Bounding Box 左下角</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="34"/>
        <source>Common Center</source>
        <translation>公共中心</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="35"/>
        <source>X Axis</source>
        <translation>X 轴</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="36"/>
        <source>Y Axis</source>
        <translation>Y 轴</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="37"/>
        <source>Counterclockwise</source>
        <translation>逆时针</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="38"/>
        <source>Clockwise</source>
        <translation>顺时针</translation>
    </message>
</context>
<context>
    <name>ExportConfirmationDialog</name>
    <message>
        <location filename="../ui/export_dialog.py" line="97"/>
        <source>  [WILL BE REPLACED]</source>
        <translation>  [将被替换]</translation>
    </message>
    <message>
        <location filename="../ui/export_dialog.py" line="154"/>
        <source>Export</source>
        <translation>导出</translation>
    </message>
</context>
<context>
    <name>ExportDialog</name>
    <message>
        <location filename="../../../ui/export_dialog.ui" line="6"/>
        <source>Confirm Export</source>
        <translation>确认导出</translation>
    </message>
    <message>
        <location filename="../../../ui/export_dialog.ui" line="18"/>
        <source>The following files will be generated:</source>
        <translation>将生成以下文件：</translation>
    </message>
</context>
<context>
    <name>ExportShapeDialog</name>
    <message>
        <location filename="../../../ui/export_shape_dialog.ui" line="6"/>
        <source>Select Export Shapes</source>
        <translation>选择导出形状</translation>
    </message>
    <message>
        <location filename="../../../ui/export_shape_dialog.ui" line="18"/>
        <source>Select at least one shape to export. Selecting both creates one combined report.</source>
        <translation>请至少选择一种要导出的形状。同时选择两种形状时，将生成一份合并报告。</translation>
    </message>
    <message>
        <location filename="../../../ui/export_shape_dialog.ui" line="28"/>
        <source>Round</source>
        <translation>圆形</translation>
    </message>
    <message>
        <location filename="../../../ui/export_shape_dialog.ui" line="35"/>
        <source>Oval</source>
        <translation>椭圆</translation>
    </message>
    <message>
        <location filename="../ui/export_shape_dialog.py" line="43"/>
        <source>Missing complete dimensions: {shapes}</source>
        <translation>缺少完整尺寸：{shapes}</translation>
    </message>
    <message>
        <location filename="../ui/export_shape_dialog.py" line="47"/>
        <source>Complete dimensions are available for both shapes.</source>
        <translation>两种形状均有完整尺寸。</translation>
    </message>
</context>
<context>
    <name>LayerNameDelegate</name>
    <message>
        <location filename="../ui/layer_table_model.py" line="76"/>
        <source>Letters, digits and underscores only</source>
        <translation>仅限字母、数字和下划线</translation>
    </message>
</context>
<context>
    <name>LayerTableModel</name>
    <message>
        <location filename="../ui/layer_table_model.py" line="93"/>
        <source>Tapeout?</source>
        <translation>Tapeout？</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="94"/>
        <source>Layer Name</source>
        <translation>Layer Name</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="95"/>
        <source>Layer Number</source>
        <translation>Layer Number</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="96"/>
        <source>Datatype</source>
        <translation>Datatype</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="99"/>
        <source>Diameter (µm)</source>
        <translation>直径（µm）</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="101"/>
        <source>Minor Axis (µm)</source>
        <translation>短轴（µm）</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="102"/>
        <source>Major Axis (µm)</source>
        <translation>长轴（µm）</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="107"/>
        <source>Only tapeout layers participate in GDS and Cell naming.</source>
        <translation>只有 Tapeout 的 Layer 参与 GDS 和 Cell 命名。</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="182"/>
        <source>Preview style: {color} / {pattern}</source>
        <translation>预览样式：{color} / {pattern}</translation>
    </message>
</context>
<context>
    <name>LayoutPreviewWidget</name>
    <message>
        <location filename="../ui/preview_widget.py" line="331"/>
        <source>Round</source>
        <translation>圆形</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="151"/>
        <source>Complete the project data to preview the grid-compliant GDS.</source>
        <translation>请补全项目数据，以预览符合格点要求的 GDS。</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="147"/>
        <source>Select the Al Pad Layer and complete the project data to preview the LEF PIN, label and boundary.</source>
        <translation>请选择 Al Pad Layer 并补全项目数据，以预览 LEF PIN、LABEL 和 BOUNDARY。</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="336"/>
        <source>{shape} - LEF {count}-gon PIN</source>
        <translation>{shape} - LEF {count}边形 PIN</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="341"/>
        <source>{shape} - {count}-gon</source>
        <translation>{shape} - {count}边形</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="358"/>
        <source>Center</source>
        <translation>中心</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="362"/>
        <source>Label {label} anchor</source>
        <translation>LABEL {label} 锚点</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="365"/>
        <source> · first LEF point</source>
        <translation> · 首个 LEF 点</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="701"/>
        <source>    NODE</source>
        <translation>    节点</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../ui/main_window.ui" line="20"/>
        <source>EasyBumpcell</source>
        <translation>EasyBumpcell</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="79"/>
        <source>Process Templates</source>
        <translation>工艺模板</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="104"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="111"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="118"/>
        <source>Import</source>
        <translation>导入</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="125"/>
        <source>Export</source>
        <translation>导出</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="153"/>
        <source>Technology Name *</source>
        <translation>Technology Name *</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="160"/>
        <source>e.g. TechName</source>
        <translation>例如 TechName</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="167"/>
        <source>Bump Type</source>
        <translation>Bump Type</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="174"/>
        <source>Optional, e.g. LF</source>
        <translation>可选，例如 LF</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="181"/>
        <source>Version *</source>
        <translation>版本 *</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="188"/>
        <source>Required file version. It is appended to output file names but not to the internal GDS Cell name.</source>
        <translation>必填的文件版本。该版本会附加到输出文件名，但不会加入内部 GDS Cell Name。</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="198"/>
        <source>Shape Type</source>
        <translation>形状类型</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="206"/>
        <source>Round</source>
        <translation>圆形</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="211"/>
        <source>Oval</source>
        <translation>椭圆</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="219"/>
        <source>Process DBU (µm) *</source>
        <translation>Process DBU（µm）*</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="227"/>
        <source>0.001 µm</source>
        <translation>0.001 µm</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="232"/>
        <source>0.0005 µm</source>
        <translation>0.0005 µm</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="539"/>
        <source>Polygon</source>
        <translation>多边形</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="738"/>
        <source>Grid-compliant GDS Preview</source>
        <translation>符合格点要求的 GDS 预览</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="399"/>
        <source>Al Pad drawing *</source>
        <translation>Al Pad drawing *</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="906"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="300"/>
        <source>Layers and Process Order</source>
        <translation>Layer 与工艺顺序</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="141"/>
        <source>Process</source>
        <translation>工艺</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="191"/>
        <source>e.g. 1 or 1.0</source>
        <translation>例如 1 或 1.0</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="426"/>
        <source>Add Layer</source>
        <translation>添加 Layer</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="433"/>
        <location filename="../ui/main_window.py" line="866"/>
        <source>Delete Layer</source>
        <translation>删除 Layer</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="440"/>
        <source>Restore Defaults</source>
        <translation>恢复默认值</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="460"/>
        <location filename="../ui/main_window.py" line="900"/>
        <location filename="../ui/main_window.py" line="1158"/>
        <source>Confirm Process Order</source>
        <translation>确认工艺顺序</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="478"/>
        <source>Output Summary</source>
        <translation>输出摘要</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="504"/>
        <source>Cell Base Name</source>
        <translation>Cell Base Name</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="523"/>
        <location filename="../../../ui/main_window.ui" line="558"/>
        <location filename="../../../ui/main_window.ui" line="587"/>
        <source>—</source>
        <translation>—</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="568"/>
        <source>DBU / Origin</source>
        <translation>DBU / Origin</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="600"/>
        <source>Validation</source>
        <translation>校验</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="638"/>
        <source>Enter project data.</source>
        <translation>请输入项目数据。</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="902"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="938"/>
        <source>Advanced Settings</source>
        <translation>高级设置</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="665"/>
        <source>Export GDS + LEF + PDF</source>
        <translation>导出 GDS + LEF + PDF</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="700"/>
        <source>GDS Preview</source>
        <translation>GDS 预览</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="779"/>
        <source>Show the actual quantized polygon vertices in both the GDS and LEF live previews. Exported GDS, LEF and PDF files are unchanged.</source>
        <translation>在 GDS 和 LEF 实时预览中显示实际量化多边形顶点。导出的 GDS、LEF 和 PDF 文件不受影响。</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="782"/>
        <source>Show Nodes</source>
        <translation>显示节点</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="792"/>
        <source>Snap the crosshair and coordinate readout in both the GDS and LEF live previews to the nearest quantized polygon vertex. Exported GDS, LEF and PDF files are unchanged.</source>
        <translation>在 GDS 和 LEF 实时预览中，将十字准线和坐标读数吸附到最近的量化多边形顶点。导出的 GDS、LEF 和 PDF 文件不受影响。</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="795"/>
        <source>Snap to Nodes</source>
        <translation>吸附到节点</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="826"/>
        <source>LEF Preview</source>
        <translation>LEF 预览</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="307"/>
        <source>Show detailed confirmation guide</source>
        <translation>显示详细确认教程</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="384"/>
        <source>Help image not found at relative path {path}.</source>
        <translation>未找到相对路径 {path} 下的教程图片。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="393"/>
        <source>Unable to display help image: {path}</source>
        <translation>无法显示教程图片：{path}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="482"/>
        <source>Select a template…</source>
        <translation>选择模板…</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="502"/>
        <source>Default template folder: {path}</source>
        <translation>默认模板文件夹：{path}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="630"/>
        <source>Template Saved</source>
        <translation>模板已保存</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="631"/>
        <source>Template &quot;{name}&quot; was saved in:
{path}</source>
        <translation>模板“{name}”已保存到：
{path}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="677"/>
        <source>Import Process Template</source>
        <translation>导入工艺模板</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="679"/>
        <location filename="../ui/main_window.py" line="738"/>
        <source>JSON Files (*.json)</source>
        <translation>JSON 文件 (*.json)</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="541"/>
        <source>Apply Process Template</source>
        <translation>应用工艺模板</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="543"/>
        <source>Please carefully check that the content is correct.

Applying this template will replace all current content.</source>
        <translation>用户需仔细检查内容正确。

应用该模版将替换当前所有内容。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="645"/>
        <source>Delete Process Template</source>
        <translation>删除工艺模板</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="647"/>
        <source>Delete template &quot;{name}&quot;?

This action cannot be undone.</source>
        <translation>是否删除模板“{name}”？

此操作无法撤销。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="668"/>
        <source>Template Deleted</source>
        <translation>模板已删除</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="669"/>
        <source>Template &quot;{name}&quot; was deleted.</source>
        <translation>模板“{name}”已删除。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="723"/>
        <source>No Template Selected</source>
        <translation>未选择模板</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="724"/>
        <source>Select a stored template to export.</source>
        <translation>请选择要导出的已保存模板。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="736"/>
        <source>Export Process Template</source>
        <translation>导出工艺模板</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="767"/>
        <source>Template Exported</source>
        <translation>模板已导出</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="768"/>
        <source>Template &quot;{name}&quot; was exported to:
{path}</source>
        <translation>模板“{name}”已导出到：
{path}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="780"/>
        <source>Template Already Exists</source>
        <translation>模板已存在</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="781"/>
        <source>Replace the stored template &quot;{name}&quot;?</source>
        <translation>是否覆盖已保存的模板“{name}”？</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="795"/>
        <source>File Already Exists</source>
        <translation>文件已存在</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="796"/>
        <source>Replace the existing file &quot;{name}&quot;?</source>
        <translation>是否覆盖现有文件“{name}”？</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="810"/>
        <source>Template Error</source>
        <translation>模板错误</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="867"/>
        <source>At least one layer is required.</source>
        <translation>至少需要一层。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="873"/>
        <source>Restore Default Layers</source>
        <translation>恢复默认 Layer</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="875"/>
        <source>Replace the current layer table with AP, ALPAD, CB2, PIO, UBM and UBM_CU?</source>
        <translation>是否用 AP、ALPAD、CB2、PIO、UBM 和 UBM_CU 替换当前 Layer 表？</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="884"/>
        <location filename="../ui/main_window.py" line="935"/>
        <location filename="../ui/main_window.py" line="961"/>
        <location filename="../ui/main_window.py" line="962"/>
        <source>(unnamed)</source>
        <translation>（未命名）</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="901"/>
        <source>Confirm this process order?

{order}</source>
        <translation>确认以下工艺顺序？

{order}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="924"/>
        <source>Select Al Pad Layer…</source>
        <translation>选择 Al Pad Layer…</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="932"/>
        <source>{name} — GDS Layer Number {layer} / Datatype {datatype}</source>
        <translation>{name} — GDS Layer Number {layer} / Datatype {datatype}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="955"/>
        <source>Al Drawing Layer Name Updated</source>
        <translation>Al Drawing Layer 名称已更新</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="957"/>
        <source>The selected Al Drawing Layer has been renamed.

Before: {before}
After: {after}</source>
        <translation>当前选择的 Al Drawing Layer 已被重命名。

修改前：{before}
修改后：{after}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="984"/>
        <source>Confirm Non-Tapeout Al Pad Layer</source>
        <translation>确认非 Tapeout Al Pad Layer</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="986"/>
        <source>Layer &quot;{name}&quot; is not marked for Tapeout.

Please confirm that it is the correct Al drawing layer.</source>
        <translation>Layer “{name}” 未标记为 Tapeout。

请确认它是否为正确的 Al Drawing Layer。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1021"/>
        <source>Please confirm again: {Al_layername} {Al_layernumb_datatype} is the actual Al Drawing Layer in use (not a Marking Layer or Dummy Layer).</source>
        <translation>请再次确认：{Al_layername} {Al_layernumb_datatype} 是实际使用的 Al Drawing Layer（而不是 Marking Layer 或 Dummy Layer）。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1056"/>
        <source>Common Center</source>
        <translation>公共中心</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1058"/>
        <source>{name} Lower-left</source>
        <translation>{name} 左下角</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1062"/>
        <source>Missing</source>
        <translation>缺失</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1065"/>
        <source>DBU {dbu} µm · Origin {origin}</source>
        <translation>DBU {dbu} µm · Origin {origin}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1097"/>
        <source>{count}-gon</source>
        <translation>{count}边形</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1111"/>
        <source>ERROR: {message}</source>
        <translation>错误：{message}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1117"/>
        <location filename="../ui/main_window.py" line="1129"/>
        <source>WARNING: {message}</source>
        <translation>警告：{message}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1140"/>
        <source>Confirm the process order before export.</source>
        <translation>请在导出前确认工艺顺序。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1147"/>
        <source>PASS</source>
        <translation>通过</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1152"/>
        <source>Order Confirmed</source>
        <translation>顺序已确认</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1154"/>
        <source>The current process order has been confirmed.</source>
        <translation>当前工艺顺序已经确认。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1162"/>
        <source>Review and confirm the layer process order before export.</source>
        <translation>请在导出前检查并确认 Layer 工艺顺序。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1186"/>
        <source>Please confirm that the Process DBU exactly matches the DBU definition in the {technology_name} Process techfile (*.tf).</source>
        <translation>请确认 Process DBU 与 {technology_name} 工艺 techfile (*.tf) 中的 DBU 定义完全一致。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1193"/>
        <source>Please confirm:
1. The following GDS Layers and their Layer Number/Datatype match the design rule for the current Bump type of {technology_name} Process. This will affect the accuracy of GDS generation.
2. The mapping between the Al drawing layer&apos;s Layer Name and its Layer Number/Datatype matches the definition in the layermap (*.map / *.layermap) of {technology_name} Process. This will affect the accuracy of LEF generation.</source>
        <translation>请确认：
1. 以下 GDS Layer 及其 Layer Number、Datatype 与 {technology_name} 工艺当前 Bump 类型的design rule 一致。这将影响GDS文件的准确生成。
2. Al drawing layer的Layer Name与Layer Number、Datatype的对应关系与{technology_name} 工艺的layermap (*.map / *.layermap) 文件中的定义一致。这将影响LEF文件的准确生成。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1211"/>
        <location filename="../ui/main_window.py" line="1245"/>
        <location filename="../ui/main_window.py" line="1283"/>
        <source>Cannot Export</source>
        <translation>无法导出</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1213"/>
        <source>No complete Round or Oval dimensions are available.</source>
        <translation>没有可用的完整圆形或椭圆尺寸。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1234"/>
        <source>{shape}: {message}</source>
        <translation>{shape}：{message}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1251"/>
        <source>Select Output Directory</source>
        <translation>选择输出目录</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1285"/>
        <source>Select and verify the Al Pad Layer below the Layer table.</source>
        <translation>请在 Layer 表格下方选择并确认 Al Pad Layer。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1313"/>
        <source>Export Failed</source>
        <translation>导出失败</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1323"/>
        <source>Export Complete</source>
        <translation>导出完成</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="1324"/>
        <source>Generated and verified:

{files}</source>
        <translation>已生成并验证：

{files}</translation>
    </message>
</context>
<context>
    <name>PreviewPatterns</name>
    <message>
        <location filename="../i18n.py" line="45"/>
        <source>Forward Diagonal</source>
        <translation>正斜线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="46"/>
        <source>Backward Diagonal</source>
        <translation>反斜线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="47"/>
        <source>Diagonal Crosshatch</source>
        <translation>斜向交叉线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="51"/>
        <source>Dots</source>
        <translation>点状</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="52"/>
        <source>Horizontal Lines</source>
        <translation>水平线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="53"/>
        <source>Vertical Lines</source>
        <translation>垂直线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="54"/>
        <source>Grid</source>
        <translation>网格</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="55"/>
        <source>Dense Dots</source>
        <translation>密集点状</translation>
    </message>
</context>
<context>
    <name>TemplateSaveDialog</name>
    <message>
        <location filename="../../../ui/template_save_dialog.ui" line="6"/>
        <source>Save Process Template</source>
        <translation>保存工艺模板</translation>
    </message>
    <message>
        <location filename="../../../ui/template_save_dialog.ui" line="20"/>
        <source>File name preview</source>
        <translation>文件名预览</translation>
    </message>
    <message>
        <location filename="../../../ui/template_save_dialog.ui" line="43"/>
        <source>Custom suffix</source>
        <translation>自定义后缀</translation>
    </message>
    <message>
        <location filename="../../../ui/template_save_dialog.ui" line="50"/>
        <source>Optional</source>
        <translation>可选</translation>
    </message>
    <message>
        <location filename="../../../ui/template_save_dialog.ui" line="61"/>
        <source>Shapes to save</source>
        <translation>要保存的形状</translation>
    </message>
    <message>
        <location filename="../../../ui/template_save_dialog.ui" line="68"/>
        <source>Round</source>
        <translation>圆形</translation>
    </message>
    <message>
        <location filename="../../../ui/template_save_dialog.ui" line="75"/>
        <source>Oval</source>
        <translation>椭圆</translation>
    </message>
    <message>
        <location filename="../../../ui/template_save_dialog.ui" line="113"/>
        <source>Use ASCII letters, digits, periods, hyphens and underscores. Separators must be between alphanumeric groups.</source>
        <translation>可使用 ASCII 字母、数字、句点、连字符和下划线；分隔符必须位于字母或数字组之间。</translation>
    </message>
    <message>
        <location filename="../ui/template_save_dialog.py" line="69"/>
        <source>Both Round and Oval dimensions will be saved.</source>
        <translation>将同时保存圆形和椭圆尺寸。</translation>
    </message>
    <message>
        <location filename="../ui/template_save_dialog.py" line="73"/>
        <source>Only {shape} dimensions will be saved.</source>
        <translation>只保存{shape}尺寸。</translation>
    </message>
    <message>
        <location filename="../ui/template_save_dialog.py" line="77"/>
        <source>Select at least one shape to save.</source>
        <translation>请至少选择一种要保存的形状。</translation>
    </message>
</context>
<context>
    <name>Validation</name>
    <message>
        <location filename="../i18n.py" line="62"/>
        <location filename="../i18n.py" line="78"/>
        <source>Minor Axis</source>
        <translation>短轴</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="63"/>
        <location filename="../i18n.py" line="79"/>
        <source>Major Axis</source>
        <translation>长轴</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="64"/>
        <location filename="../i18n.py" line="77"/>
        <source>Diameter</source>
        <translation>直径</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="70"/>
        <source>Technology Name</source>
        <translation>Technology Name</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="71"/>
        <source>Layer Name</source>
        <translation>Layer Name</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="72"/>
        <source>Layer Number</source>
        <translation>Layer Number</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="73"/>
        <source>Datatype</source>
        <translation>Datatype</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="74"/>
        <source>Version</source>
        <translation>版本</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="75"/>
        <source>Bump Type</source>
        <translation>Bump Type</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="76"/>
        <source>Dimension</source>
        <translation>尺寸</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="86"/>
        <source>At least one layer is required</source>
        <translation>至少需要一层</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="90"/>
        <source>At least one Tapeout layer is required</source>
        <translation>至少需要勾选一个 Tapeout Layer</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="94"/>
        <source>Process DBU must be a positive finite value</source>
        <translation>Process DBU 必须是正有限值</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="98"/>
        <source>The origin reference layer does not exist</source>
        <translation>原点 Reference Layer 不存在</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="102"/>
        <source>Origin reference layer does not exist</source>
        <translation>原点 Reference Layer 不存在</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="106"/>
        <source>Select the Al Pad Layer for LEF output</source>
        <translation>请选择用于 LEF 输出的 Al Pad Layer</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="110"/>
        <source>Select the Al Pad Layer below the Layer table before export</source>
        <translation>请在导出前于 Layer 表格下方选择 Al Pad Layer</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="114"/>
        <source>Confirm the layer process order before export</source>
        <translation>请在导出前确认 Layer 工艺顺序</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="118"/>
        <source>Cell Name dimension selection contains deleted layers</source>
        <translation>Cell Name 尺寸选择中包含已删除的 Layer</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="122"/>
        <source>Select at least one layer for the Cell Name</source>
        <translation>请至少为 Cell Name 选择一个 Layer</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="126"/>
        <source>Select at least one Tapeout layer for the Cell Name</source>
        <translation>请至少选择一个 Tapeout Layer 用于 Cell Name</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="130"/>
        <source>Layer Name may contain ASCII letters, digits and underscores only</source>
        <translation>Layer Name 仅可包含 ASCII 字母、数字和下划线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="134"/>
        <source>Manual Cell Name may contain ASCII letters, digits and underscores only</source>
        <translation>手动 Cell Name 仅可包含 ASCII 字母、数字和下划线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="138"/>
        <source>Version must begin with V and may otherwise contain ASCII letters, digits, periods and hyphens, with separators only between alphanumeric groups</source>
        <translation>Version 必须以 V 开头，其余部分仅可包含 ASCII 字母、数字、句点和连字符，且分隔符只能位于字母数字组之间</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="142"/>
        <source>Bump Type may contain ASCII letters, digits and underscores only</source>
        <translation>Bump 类型仅可包含 ASCII 字母、数字和下划线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="146"/>
        <source>Unable to quantize polygon vertex inside the nominal polygon</source>
        <translation>无法在标称多边形内部量化多边形顶点</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="150"/>
        <source>A centrally symmetric polygon must have an even vertex count</source>
        <translation>中心对称多边形必须具有偶数个顶点</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="154"/>
        <source>Polygon is not centrally symmetric</source>
        <translation>多边形不是中心对称图形</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="158"/>
        <source>All layer polygons in one generated layout must use the same node count</source>
        <translation>同一生成布局中的所有 Layer 多边形必须使用相同的节点数</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="169"/>
        <source>{field} is required</source>
        <translation>{field}为必填项</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="177"/>
        <source>{field} may contain ASCII letters and digits only</source>
        <translation>{field}仅可包含 ASCII 字母和数字</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="186"/>
        <source>{field} must be a positive number with at most one decimal place</source>
        <translation>{field}必须是最多一位小数的正数</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="192"/>
        <source>Duplicate Layer Name: {name}</source>
        <translation>Layer Name 重复：{name}</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="200"/>
        <source>{name}: Major Axis must be greater than Minor Axis</source>
        <translation>{name}：长轴必须大于短轴</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="209"/>
        <source>{name}: Layer Number must be an integer from 0 to 65535</source>
        <translation>{name}：Layer Number 必须是 0 到 65535 之间的整数</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="218"/>
        <source>{name}: Datatype must be an integer from 0 to 255</source>
        <translation>{name}：Datatype 必须是 0 到 255 之间的整数</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="224"/>
        <source>Duplicate Layer Number/Datatype: {pair}</source>
        <translation>Layer Number/Datatype 重复：{pair}</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="233"/>
        <source>{name}: unsupported preview pattern {pattern}</source>
        <translation>{name}：不支持的预览纹理 {pattern}</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="242"/>
        <source>{name} {dimension} endpoints fall on half-grid positions for Process DBU {dbu} µm. DBU will not be changed.</source>
        <translation>{name} 的{dimension}端点位于 Process DBU {dbu} µm 的半网格位置。DBU 不会被更改。</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="255"/>
        <source>{count} existing output file(s) will be replaced.</source>
        <translation>将替换 {count} 个已存在的输出文件。</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="264"/>
        <source>{count} generated Cell name(s) exceed the {limit}-character limit (maximum {maximum})</source>
        <translation>{count} 个生成的 Cell Name 超过 {limit} 字符限制（最大 {maximum}）</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="277"/>
        <source>{count} generated Cell name(s) exceed 32 characters (maximum {maximum}); some legacy GDS tools may reject them</source>
        <translation>{count} 个生成的 Cell Name 超过 32 个字符（最大 {maximum}）；某些旧版 GDS 工具可能会拒绝它们</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="286"/>
        <source>{count} output file name(s) exceed the {limit}-character limit (maximum {maximum})</source>
        <translation>{count} 个输出文件名超过 {limit} 字符限制（最大 {maximum}）</translation>
    </message>
</context>
</TS>
