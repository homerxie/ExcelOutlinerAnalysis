from __future__ import annotations

from pathlib import Path
import sys

from PySide6.QtCore import QSize
from PySide6.QtGui import QIcon


ICON_RELATIVE_DIRECTORY = Path("Icon")
WINDOWS_ICON_NAME = "NeonDoubleRingIcon.ico"
MACOS_ICON_NAME = "NeonDoubleRingIcon.icns"
PNG_ICON_SIZES = (16, 24, 32, 48, 64, 128, 256, 512, 1024)


def icon_directory_candidates() -> tuple[Path, ...]:
    candidates: list[Path] = []
    pyinstaller_root = getattr(sys, "_MEIPASS", None)
    if pyinstaller_root:
        candidates.append(
            Path(pyinstaller_root).resolve() / ICON_RELATIVE_DIRECTORY
        )

    if getattr(sys, "frozen", False):
        executable_directory = Path(sys.executable).resolve().parent
        candidates.extend(
            (
                executable_directory
                / "internal"
                / ICON_RELATIVE_DIRECTORY,
                executable_directory
                / "_internal"
                / ICON_RELATIVE_DIRECTORY,
                executable_directory / ICON_RELATIVE_DIRECTORY,
            )
        )
        if (
            sys.platform == "darwin"
            and executable_directory.name == "MacOS"
        ):
            candidates.append(
                executable_directory.parent
                / "Resources"
                / ICON_RELATIVE_DIRECTORY
            )

    candidates.extend(
        (
            Path(__file__).resolve().parents[2]
            / ICON_RELATIVE_DIRECTORY,
            Path.cwd().resolve() / ICON_RELATIVE_DIRECTORY,
        )
    )

    unique_candidates: list[Path] = []
    for candidate in candidates:
        if candidate not in unique_candidates:
            unique_candidates.append(candidate)
    return tuple(unique_candidates)


def find_icon_directory() -> Path | None:
    return next(
        (
            directory
            for directory in icon_directory_candidates()
            if directory.is_dir()
        ),
        None,
    )


def load_application_icon() -> QIcon:
    icon_directory = find_icon_directory()
    if icon_directory is None:
        return QIcon()

    native_icon_name = (
        WINDOWS_ICON_NAME
        if sys.platform == "win32"
        else MACOS_ICON_NAME
        if sys.platform == "darwin"
        else None
    )
    native_icon_path = (
        icon_directory / native_icon_name
        if native_icon_name is not None
        else None
    )
    icon = (
        QIcon(str(native_icon_path))
        if native_icon_path is not None and native_icon_path.is_file()
        else QIcon()
    )

    # The macOS ICNS has platform-specific transparent safe margins. Adding
    # the shared PNG files would reintroduce the full-size artwork for some
    # Dock/window icon sizes, so keep the ICNS as the sole macOS source.
    if sys.platform == "darwin" and not icon.isNull():
        return icon

    for size in PNG_ICON_SIZES:
        path = icon_directory / f"icon_{size}x{size}.png"
        if path.is_file():
            icon.addFile(
                str(path),
                QSize(size, size),
                QIcon.Mode.Normal,
                QIcon.State.Off,
            )
    return icon
