from __future__ import annotations

import math
from dataclasses import dataclass
from decimal import Decimal

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPen, QPixmap, QPolygonF, QRegion
from PySide6.QtWidgets import QWidget

from easybumpcell.coordinate_format import (
    dbu_decimal_places,
    format_coordinate_um,
)
from easybumpcell.domain.enums import ShapeType
from easybumpcell.domain.models import ProjectConfig
from easybumpcell.geometry.layout import GeneratedLayout
from easybumpcell.services.lef_export import (
    LEFPreviewElements,
    lef_preview_elements,
)
from easybumpcell.ui.preview_style import draw_preview_pattern


def _nice_tick_spacing(desired_um: float) -> float:
    if not math.isfinite(desired_um) or desired_um <= 0:
        return 1.0
    exponent = math.floor(math.log10(desired_um))
    magnitude = 10.0 ** exponent
    fraction = desired_um / magnitude
    if fraction <= 1:
        nice_fraction = 1.0
    elif fraction <= 2:
        nice_fraction = 2.0
    elif fraction <= 5:
        nice_fraction = 5.0
    else:
        nice_fraction = 10.0
    return nice_fraction * magnitude


def _tick_values(minimum: float, maximum: float, spacing: float) -> list[float]:
    first = math.ceil((minimum - spacing * 1e-9) / spacing) * spacing
    values = []
    value = first
    while value <= maximum + spacing * 1e-9 and len(values) < 100:
        values.append(0.0 if abs(value) < spacing * 1e-9 else value)
        value += spacing
    return values


def _format_tick(value: float, spacing: float) -> str:
    if abs(value) < spacing * 1e-9:
        return "0"
    decimals = max(0, min(6, -math.floor(math.log10(spacing))))
    text = f"{value:.{decimals}f}"
    return text.rstrip("0").rstrip(".") if decimals else text


@dataclass(frozen=True)
class _PanelView:
    index: int
    panel: QRectF
    plot: QRectF
    scale: float
    offset_x: float
    offset_y: float
    dbu_um: float
    tick_spacing_um: float

    def map_point(self, x_dbu: float, y_dbu: float) -> QPointF:
        return QPointF(
            self.offset_x + x_dbu * self.scale,
            self.offset_y - y_dbu * self.scale,
        )

    def screen_to_um(self, point: QPointF) -> tuple[float, float]:
        return (
            (point.x() - self.offset_x) / self.scale * self.dbu_um,
            (self.offset_y - point.y()) / self.scale * self.dbu_um,
        )

    def visible_um_bounds(self) -> tuple[float, float, float, float]:
        min_x, min_y = self.screen_to_um(
            QPointF(self.plot.left(), self.plot.bottom())
        )
        max_x, max_y = self.screen_to_um(
            QPointF(self.plot.right(), self.plot.top())
        )
        return min_x, min_y, max_x, max_y


@dataclass(frozen=True)
class _PreviewNode:
    position: QPointF
    x_dbu: int
    y_dbu: int
    layer_uid: str
    color: str


class LayoutPreviewWidget(QWidget):
    NODE_RADIUS_PX = 1.5
    SELECTED_NODE_RADIUS_PX = 2.0
    SNAP_RADIUS_PX = 8.0

    def __init__(
        self,
        parent=None,
        *,
        lef_mode: bool = False,
        empty_message: str | None = None,
    ) -> None:
        super().__init__(parent)
        self.lef_mode = lef_mode
        self.empty_message = empty_message
        self.config: ProjectConfig | None = None
        self.layouts: list[GeneratedLayout] = []
        self.selected_layer_uid: str | None = None
        self.show_nodes = True
        self.snap_to_nodes = True
        self._panel_views: list[_PanelView] = []
        self._panel_nodes: dict[int, tuple[_PreviewNode, ...]] = {}
        self._hover_panel_index: int | None = None
        self._pointer_position: QPointF | None = None
        self._hover_position: QPointF | None = None
        self._snapped_node: _PreviewNode | None = None
        self.hover_coordinate_um: tuple[float, float] | None = None
        self._static_cache: QPixmap | None = None
        self._static_cache_size = self.size()
        self._static_cache_dpr = 0.0
        self._static_cache_build_count = 0
        self.setMinimumSize(400, 420)
        self.setAutoFillBackground(False)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self.setMouseTracking(True)

    def retranslate(self) -> None:
        self._invalidate_static_cache()
        self.update()

    def _empty_message(self) -> str:
        if self.empty_message is not None:
            return self.tr(self.empty_message)
        if self.lef_mode:
            return self.tr(
                "Select the Al Pad Layer and complete the project data "
                "to preview the LEF PIN, label and boundary."
            )
        return self.tr(
            "Complete the project data to preview the grid-compliant GDS."
        )

    def set_layouts(self, config: ProjectConfig, layouts: list[GeneratedLayout]) -> None:
        self.config = config
        self.layouts = layouts
        self._clear_hover()
        self._invalidate_static_cache()
        self.update()

    def clear_layouts(self) -> None:
        self.layouts = []
        self._clear_hover()
        self._invalidate_static_cache()
        self.update()

    def set_selected_layer(self, uid: str | None) -> None:
        self.selected_layer_uid = uid
        self._invalidate_static_cache()
        self.update()

    def set_show_nodes(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if self.show_nodes == enabled:
            return
        self.show_nodes = enabled
        self._invalidate_static_cache()
        self.update()

    def set_snap_to_nodes(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if self.snap_to_nodes == enabled:
            return
        old_panel_index = self._hover_panel_index
        old_position = (
            QPointF(self._hover_position)
            if self._hover_position is not None
            else None
        )
        self.snap_to_nodes = enabled
        if self._pointer_position is not None:
            self._update_hover_from_pointer(self._pointer_position)
        self._update_hover_regions(
            old_panel_index,
            old_position,
            self._hover_panel_index,
            self._hover_position,
        )

    def _global_bounds(self) -> tuple[int, int, int, int]:
        if self.lef_mode and self.config is not None:
            elements = [
                lef_preview_elements(self.config, layout)
                for layout in self.layouts
            ]
            boxes = [
                box
                for item in elements
                for box in (item.pin_geometry.bbox_dbu, item.boundary_dbu)
            ]
        else:
            boxes = [
                layer.bbox_dbu
                for layout in self.layouts
                for layer in layout.layers
            ]
        min_x = min(min(box.min_x for box in boxes), 0)
        min_y = min(min(box.min_y for box in boxes), 0)
        max_x = max(max(box.max_x for box in boxes), 0)
        max_y = max(max(box.max_y for box in boxes), 0)
        if self.lef_mode:
            width = max_x - min_x
            height = max_y - min_y
            pad_x = max(1, math.ceil(width * 0.14))
            pad_y = max(1, math.ceil(height * 0.14))
            min_x -= pad_x
            min_y -= pad_y
            max_x += pad_x
            max_y += pad_y
        if min_x == max_x:
            max_x += 1
        if min_y == max_y:
            max_y += 1
        return min_x, min_y, max_x, max_y

    def paintEvent(self, event) -> None:
        current_dpr = self.devicePixelRatioF()
        if (
            self._static_cache is None
            or self._static_cache_size != self.size()
            or not math.isclose(self._static_cache_dpr, current_dpr)
        ):
            self._rebuild_static_cache()
        painter = QPainter(self)
        if self._static_cache is not None:
            painter.drawPixmap(0, 0, self._static_cache)
        if self._hover_panel_index is not None:
            view = next(
                (
                    item
                    for item in self._panel_views
                    if item.index == self._hover_panel_index
                ),
                None,
            )
            if view is not None:
                self._draw_hover(painter, view)

    def _rebuild_static_cache(self) -> None:
        dpr = self.devicePixelRatioF()
        width = max(1, round(self.width() * dpr))
        height = max(1, round(self.height() * dpr))
        cache = QPixmap(width, height)
        cache.setDevicePixelRatio(dpr)
        cache.fill(Qt.GlobalColor.transparent)
        painter = QPainter(cache)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.fillRect(self.rect(), QColor("#F1F4F6"))
        if not self.layouts or self.config is None:
            painter.setPen(QColor("#6D7882"))
            painter.drawText(
                self.rect(),
                Qt.AlignmentFlag.AlignCenter,
                self._empty_message(),
            )
            painter.end()
            self._panel_views = []
            self._panel_nodes = {}
            self._static_cache = cache
            self._static_cache_size = self.size()
            self._static_cache_dpr = dpr
            self._static_cache_build_count += 1
            return

        count = len(self.layouts)
        columns, rows = (1, 1) if count == 1 else (2, 2)
        outer = 10
        gap = 10
        available_w = self.width() - 2 * outer - gap * (columns - 1)
        available_h = self.height() - 2 * outer - gap * (rows - 1)
        panel_w = available_w / columns
        panel_h = available_h / rows
        bounds = self._global_bounds()
        self._panel_views = []
        self._panel_nodes = {}

        for index, layout in enumerate(self.layouts):
            column = index % columns
            row = index // columns
            panel = QRectF(
                outer + column * (panel_w + gap),
                outer + row * (panel_h + gap),
                panel_w,
                panel_h,
            )
            self._draw_panel(painter, panel, layout, bounds, index)
        painter.end()
        self._static_cache = cache
        self._static_cache_size = self.size()
        self._static_cache_dpr = dpr
        self._static_cache_build_count += 1

    def _draw_panel(
        self,
        painter: QPainter,
        panel: QRectF,
        layout: GeneratedLayout,
        bounds: tuple[int, int, int, int],
        panel_index: int,
    ) -> None:
        lef_elements = (
            lef_preview_elements(self.config, layout)
            if self.lef_mode
            else None
        )
        painter.save()
        painter.setPen(QPen(QColor("#CAD2D9"), 1))
        painter.setBrush(QColor("#FFFFFF"))
        painter.drawRoundedRect(panel, 5, 5)
        shape_title = (
            self.tr("Round")
            if self.config.shape_type is ShapeType.ROUND
            else f"{layout.logical_angle}°"
        )
        title = (
            self.tr("{shape} - LEF {count}-gon PIN").format(
                shape=shape_title,
                count=layout.nodes_per_polygon,
            )
            if lef_elements is not None
            else self.tr("{shape} - {count}-gon").format(
                shape=shape_title,
                count=layout.nodes_per_polygon,
            )
        )
        painter.setFont(QFont(painter.font().family(), 11, QFont.Weight.DemiBold))
        painter.setPen(QColor("#1F2D3D"))
        painter.drawText(QRectF(panel.left(), panel.top() + 5, panel.width(), 22), Qt.AlignmentFlag.AlignCenter, title)
        painter.setFont(QFont(painter.font().family(), 7))
        painter.setPen(QColor("#61707D"))
        painter.drawText(
            QRectF(panel.left() + 6, panel.top() + 24, panel.width() - 12, 12),
            Qt.AlignmentFlag.AlignCenter,
            layout.cell_name,
        )
        if lef_elements is None:
            summary_x_dbu, summary_y_dbu = layout.common_center_dbu
            summary_prefix = self.tr("Center")
            summary_suffix = ""
        else:
            summary_x_dbu, summary_y_dbu = lef_elements.label_anchor_dbu
            summary_prefix = self.tr("Label {label} anchor").format(
                label=lef_elements.label_text,
            )
            summary_suffix = self.tr(" · first LEF point")
        summary_x_um = Decimal(summary_x_dbu) * self.config.dbu_um
        summary_y_um = Decimal(summary_y_dbu) * self.config.dbu_um
        painter.drawText(
            QRectF(panel.left() + 6, panel.top() + 36, panel.width() - 12, 12),
            Qt.AlignmentFlag.AlignCenter,
            (
                f"{summary_prefix}: "
                f"X {format_coordinate_um(summary_x_um, self.config.dbu_um)} µm, "
                f"Y {format_coordinate_um(summary_y_um, self.config.dbu_um)} µm"
                f"{summary_suffix}"
            ),
        )
        header_bottom = 52
        if lef_elements is not None:
            self._draw_lef_legend(painter, panel, lef_elements)
            header_bottom = 69

        plot = panel.adjusted(20, header_bottom, -20, -18)
        min_x, min_y, max_x, max_y = bounds
        world_w = max_x - min_x
        world_h = max_y - min_y
        scale = min(plot.width() / world_w, plot.height() / world_h)
        offset_x = plot.left() + (plot.width() - world_w * scale) / 2 - min_x * scale
        offset_y = plot.bottom() - (plot.height() - world_h * scale) / 2 + min_y * scale
        dbu_um = float(self.config.dbu_um)
        pixels_per_um = scale / dbu_um
        tick_spacing_um = _nice_tick_spacing(65.0 / pixels_per_um)
        view = _PanelView(
            panel_index,
            QRectF(panel),
            QRectF(plot),
            scale,
            offset_x,
            offset_y,
            dbu_um,
            tick_spacing_um,
        )
        self._panel_views.append(view)

        def map_point(x: int, y: int) -> QPointF:
            return view.map_point(x, y)

        display_layers = (
            (lef_elements.pin_geometry,)
            if lef_elements is not None
            else layout.layers
        )
        ordered_layers = sorted(
            display_layers,
            key=lambda layer: layer.bbox_dbu.width * layer.bbox_dbu.height,
            reverse=True,
        )
        for layer in ordered_layers:
            color = QColor(layer.definition.color)
            selected = layer.definition.uid == self.selected_layer_uid
            polygon = QPolygonF([map_point(x, y) for x, y in layer.points_dbu])
            draw_preview_pattern(
                painter,
                polygon,
                color,
                layer.definition.preview_pattern,
            )
            painter.setPen(QPen(color, 3 if selected else 1.4))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawPolygon(polygon)
        if lef_elements is not None:
            self._draw_lef_boundary(painter, view, lef_elements)

        nodes = tuple(
            _PreviewNode(
                map_point(x, y),
                x,
                y,
                layer.definition.uid,
                layer.definition.color,
            )
            for layer in display_layers
            for x, y in layer.points_dbu
        )
        self._panel_nodes[panel_index] = nodes
        self._draw_axes(painter, view)
        origin = view.map_point(0, 0)
        painter.setPen(QPen(QColor("#111111"), 1.4))
        painter.drawLine(QPointF(origin.x() - 5, origin.y()), QPointF(origin.x() + 5, origin.y()))
        painter.drawLine(QPointF(origin.x(), origin.y() - 5), QPointF(origin.x(), origin.y() + 5))
        if self.show_nodes:
            self._draw_nodes(painter, nodes)
        if lef_elements is not None:
            self._draw_lef_label(painter, view, lef_elements)
        painter.restore()

    def _draw_lef_legend(
        self,
        painter: QPainter,
        panel: QRectF,
        elements: LEFPreviewElements,
    ) -> None:
        painter.save()
        painter.setFont(QFont(painter.font().family(), 7, QFont.Weight.DemiBold))
        metrics = painter.fontMetrics()
        labels = (
            elements.pin_layer_name,
            elements.label_layer_name,
            elements.boundary_layer_name,
        )
        widths = [metrics.horizontalAdvance(label) + 24 for label in labels]
        total_width = sum(widths) + 12
        x = panel.center().x() - total_width / 2
        y = panel.top() + 54

        pin_color = QColor(elements.definition.color)
        painter.setPen(QPen(pin_color, 2))
        painter.drawLine(QPointF(x, y + 4), QPointF(x + 12, y + 4))
        painter.setPen(QColor("#34434F"))
        painter.drawText(QPointF(x + 16, y + 7), labels[0])
        x += widths[0] + 6

        label_color = QColor("#7B1FA2")
        painter.setPen(QPen(label_color, 1.2))
        painter.setBrush(QColor("#FFFFFF"))
        painter.drawEllipse(QPointF(x + 6, y + 4), 3, 3)
        painter.setPen(QColor("#34434F"))
        painter.drawText(QPointF(x + 16, y + 7), labels[1])
        x += widths[1] + 6

        painter.setPen(QPen(QColor("#455A64"), 1.2, Qt.PenStyle.DashLine))
        painter.drawLine(QPointF(x, y + 4), QPointF(x + 12, y + 4))
        painter.setPen(QColor("#34434F"))
        painter.drawText(QPointF(x + 16, y + 7), labels[2])
        painter.restore()

    def _draw_lef_boundary(
        self,
        painter: QPainter,
        view: _PanelView,
        elements: LEFPreviewElements,
    ) -> None:
        boundary = elements.boundary_dbu
        top_left = view.map_point(boundary.min_x, boundary.max_y)
        bottom_right = view.map_point(boundary.max_x, boundary.min_y)
        painter.save()
        painter.setPen(
            QPen(QColor("#455A64"), 1.35, Qt.PenStyle.DashLine)
        )
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(QRectF(top_left, bottom_right).normalized())
        painter.restore()

    def _draw_lef_label(
        self,
        painter: QPainter,
        view: _PanelView,
        elements: LEFPreviewElements,
    ) -> None:
        anchor = view.map_point(*elements.label_anchor_dbu)
        label_color = QColor("#7B1FA2")
        painter.save()
        painter.setPen(QPen(label_color, 1.25))
        painter.setBrush(QColor("#FFFFFF"))
        painter.drawEllipse(anchor, 3.6, 3.6)
        painter.drawLine(
            QPointF(anchor.x() - 5.5, anchor.y()),
            QPointF(anchor.x() + 5.5, anchor.y()),
        )
        painter.drawLine(
            QPointF(anchor.x(), anchor.y() - 5.5),
            QPointF(anchor.x(), anchor.y() + 5.5),
        )

        painter.setFont(QFont(painter.font().family(), 8, QFont.Weight.Bold))
        metrics = painter.fontMetrics()
        text_width = metrics.horizontalAdvance(elements.label_text) + 10
        text_height = metrics.height() + 4
        text_x = anchor.x() + 7
        if text_x + text_width > view.plot.right():
            text_x = anchor.x() - text_width - 7
        text_y = anchor.y() - text_height - 5
        if text_y < view.plot.top():
            text_y = anchor.y() + 5
        badge = QRectF(text_x, text_y, text_width, text_height)
        painter.setPen(QPen(label_color, 0.8))
        painter.setBrush(QColor(255, 255, 255, 235))
        painter.drawRoundedRect(badge, 3, 3)
        painter.setPen(label_color)
        painter.drawText(
            badge,
            Qt.AlignmentFlag.AlignCenter,
            elements.label_text,
        )
        painter.restore()

    def _draw_nodes(
        self,
        painter: QPainter,
        nodes: tuple[_PreviewNode, ...],
    ) -> None:
        ordered_nodes = sorted(
            nodes,
            key=lambda node: node.layer_uid == self.selected_layer_uid,
        )
        for node in ordered_nodes:
            selected = node.layer_uid == self.selected_layer_uid
            radius = (
                self.SELECTED_NODE_RADIUS_PX
                if selected
                else self.NODE_RADIUS_PX
            )
            color = QColor(node.color)
            fill = QColor(color)
            fill.setAlpha(235)
            node_border = color.darker(145)
            painter.setPen(QPen(node_border, 0.7))
            painter.setBrush(fill)
            painter.drawEllipse(node.position, radius, radius)

    def _draw_axes(self, painter: QPainter, view: _PanelView) -> None:
        origin = view.map_point(0, 0)
        min_x, min_y, max_x, max_y = view.visible_um_bounds()
        x_ticks = _tick_values(min_x, max_x, view.tick_spacing_um)
        y_ticks = _tick_values(min_y, max_y, view.tick_spacing_um)

        axis_color = QColor("#607D8B")
        axis_color.setAlpha(185)
        painter.setPen(QPen(axis_color, 0.9))
        painter.drawLine(
            QPointF(view.plot.left(), origin.y()),
            QPointF(view.plot.right(), origin.y()),
        )
        painter.drawLine(
            QPointF(origin.x(), view.plot.top()),
            QPointF(origin.x(), view.plot.bottom()),
        )

        painter.setFont(QFont(painter.font().family(), 7))
        painter.setPen(QColor("#52636F"))
        x_labels_below = origin.y() + 18 <= view.panel.bottom() - 2
        x_label_top = origin.y() + 5 if x_labels_below else origin.y() - 18
        for value_um in x_ticks:
            point = view.map_point(value_um / view.dbu_um, 0)
            painter.drawLine(
                QPointF(point.x(), origin.y() - 3),
                QPointF(point.x(), origin.y() + 3),
            )
            painter.drawText(
                QRectF(point.x() - 25, x_label_top, 50, 13),
                Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop,
                _format_tick(value_um, view.tick_spacing_um),
            )

        y_labels_right = origin.x() - 48 < view.panel.left() + 2
        y_label_left = origin.x() + 5 if y_labels_right else origin.x() - 48
        y_label_alignment = (
            Qt.AlignmentFlag.AlignLeft
            if y_labels_right
            else Qt.AlignmentFlag.AlignRight
        )
        for value_um in y_ticks:
            point = view.map_point(0, value_um / view.dbu_um)
            painter.drawLine(
                QPointF(origin.x() - 3, point.y()),
                QPointF(origin.x() + 3, point.y()),
            )
            if abs(value_um) < view.tick_spacing_um * 1e-9:
                continue
            painter.drawText(
                QRectF(y_label_left, point.y() - 7, 43, 14),
                y_label_alignment | Qt.AlignmentFlag.AlignVCenter,
                _format_tick(value_um, view.tick_spacing_um),
            )

        painter.setFont(QFont(painter.font().family(), 7, QFont.Weight.DemiBold))
        x_title_top = origin.y() - 17 if x_labels_below else origin.y() + 4
        painter.drawText(
            QRectF(view.plot.right() - 45, x_title_top, 45, 14),
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
            "X (µm)",
        )
        painter.drawText(
            QRectF(origin.x() + 5, view.plot.top() + 14, 45, 14),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop,
            "Y (µm)",
        )

    def _coordinate_decimals(self) -> int:
        if self.config is None:
            return 3
        return dbu_decimal_places(self.config.dbu_um)

    def _draw_hover(self, painter: QPainter, view: _PanelView) -> None:
        if (
            self._hover_panel_index != view.index
            or self._hover_position is None
            or not view.plot.contains(self._hover_position)
        ):
            return
        position = self._hover_position
        crosshair_color = QColor(
            "#00796B" if self._snapped_node is not None else "#263238"
        )
        crosshair_color.setAlpha(185 if self._snapped_node is not None else 150)
        crosshair_pen = QPen(crosshair_color, 0.8, Qt.PenStyle.DashLine)
        painter.save()
        painter.setClipRect(view.plot)
        painter.setPen(crosshair_pen)
        painter.drawLine(
            QPointF(view.plot.left(), position.y()),
            QPointF(view.plot.right(), position.y()),
        )
        painter.drawLine(
            QPointF(position.x(), view.plot.top()),
            QPointF(position.x(), view.plot.bottom()),
        )
        painter.restore()

        if self._snapped_node is not None:
            painter.setPen(QPen(QColor("#00796B"), 1.2))
            painter.setBrush(QColor(255, 255, 255, 225))
            painter.drawEllipse(position, 3.6, 3.6)
            node_color = QColor(self._snapped_node.color)
            node_color.setAlpha(245)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(node_color)
            painter.drawEllipse(position, 1.5, 1.5)

        x_um, y_um = (
            self.hover_coordinate_um
            if self.hover_coordinate_um is not None
            else view.screen_to_um(position)
        )
        decimals = self._coordinate_decimals()
        text = (
            f"X: {x_um:.{decimals}f} µm    "
            f"Y: {y_um:.{decimals}f} µm"
        )
        if self._snapped_node is not None:
            text += self.tr("    NODE")
        painter.setFont(QFont(painter.font().family(), 8, QFont.Weight.DemiBold))
        metrics = painter.fontMetrics()
        badge_width = metrics.horizontalAdvance(text) + 14
        badge_height = metrics.height() + 8
        badge = QRectF(
            view.plot.right() - badge_width - 4,
            view.plot.top() + 4,
            badge_width,
            badge_height,
        )
        badge_border = QColor(
            "#00796B" if self._snapped_node is not None else "#78909C"
        )
        painter.setPen(QPen(badge_border, 0.8))
        painter.setBrush(QColor(255, 255, 255, 235))
        painter.drawRoundedRect(badge, 3, 3)
        painter.setPen(QColor("#263238"))
        painter.drawText(
            badge.adjusted(7, 3, -7, -3),
            Qt.AlignmentFlag.AlignCenter,
            text,
        )

    def _nearest_node(
        self,
        view: _PanelView,
        position: QPointF,
    ) -> _PreviewNode | None:
        radius_squared = self.SNAP_RADIUS_PX ** 2
        nearest: _PreviewNode | None = None
        nearest_key: tuple[float, bool] | None = None
        for node in self._panel_nodes.get(view.index, ()):
            dx = node.position.x() - position.x()
            dy = node.position.y() - position.y()
            distance_squared = dx * dx + dy * dy
            if distance_squared > radius_squared:
                continue
            key = (
                distance_squared,
                node.layer_uid != self.selected_layer_uid,
            )
            if nearest_key is None or key < nearest_key:
                nearest = node
                nearest_key = key
        return nearest

    def _update_hover_from_pointer(self, position: QPointF) -> None:
        self._pointer_position = QPointF(position)
        view = next(
            (item for item in self._panel_views if item.plot.contains(position)),
            None,
        )
        if view is None:
            self._clear_hover()
            return

        snapped_node = (
            self._nearest_node(view, position)
            if self.snap_to_nodes
            else None
        )
        self._hover_panel_index = view.index
        self._snapped_node = snapped_node
        if snapped_node is None:
            self._hover_position = QPointF(position)
            self.hover_coordinate_um = view.screen_to_um(position)
        else:
            self._hover_position = QPointF(snapped_node.position)
            dbu_um = float(self.config.dbu_um) if self.config is not None else 1.0
            self.hover_coordinate_um = (
                snapped_node.x_dbu * dbu_um,
                snapped_node.y_dbu * dbu_um,
            )

    def mouseMoveEvent(self, event) -> None:
        position = event.position()
        old_panel_index = self._hover_panel_index
        old_position = (
            QPointF(self._hover_position)
            if self._hover_position is not None
            else None
        )
        self._update_hover_from_pointer(position)
        if old_panel_index is None and self._hover_panel_index is not None:
            self.setCursor(Qt.CursorShape.CrossCursor)
        elif old_panel_index is not None and self._hover_panel_index is None:
            self.unsetCursor()
        self._update_hover_regions(
            old_panel_index,
            old_position,
            self._hover_panel_index,
            self._hover_position,
        )
        super().mouseMoveEvent(event)

    def leaveEvent(self, event) -> None:
        old_panel_index = self._hover_panel_index
        old_position = (
            QPointF(self._hover_position)
            if self._hover_position is not None
            else None
        )
        self._clear_hover()
        self.unsetCursor()
        self._update_hover_regions(old_panel_index, old_position, None, None)
        super().leaveEvent(event)

    def _clear_hover(self) -> None:
        self._hover_panel_index = None
        self._pointer_position = None
        self._hover_position = None
        self._snapped_node = None
        self.hover_coordinate_um = None

    def _invalidate_static_cache(self) -> None:
        self._static_cache = None
        self._panel_views = []
        self._panel_nodes = {}

    def _update_hover_regions(
        self,
        old_panel_index: int | None,
        old_position: QPointF | None,
        new_panel_index: int | None,
        new_position: QPointF | None,
    ) -> None:
        positions: dict[int, list[QPointF]] = {}
        if old_panel_index is not None and old_position is not None:
            positions.setdefault(old_panel_index, []).append(old_position)
        if new_panel_index is not None and new_position is not None:
            positions.setdefault(new_panel_index, []).append(new_position)

        for view in self._panel_views:
            hover_positions = positions.get(view.index)
            if not hover_positions:
                continue
            dirty_region = QRegion()
            for position in hover_positions:
                if not view.plot.contains(position):
                    continue
                horizontal = QRectF(
                    view.plot.left() - 2,
                    position.y() - 3,
                    view.plot.width() + 4,
                    6,
                )
                vertical = QRectF(
                    position.x() - 3,
                    view.plot.top() - 2,
                    6,
                    view.plot.height() + 4,
                )
                dirty_region |= QRegion(horizontal.toAlignedRect())
                dirty_region |= QRegion(vertical.toAlignedRect())

            badge_width = min(300.0, view.plot.width())
            badge_region = QRectF(
                view.plot.right() - badge_width,
                view.plot.top(),
                badge_width,
                40,
            )
            dirty_region |= QRegion(badge_region.toAlignedRect())
            if not dirty_region.isEmpty():
                self.update(dirty_region)

    def resizeEvent(self, event) -> None:
        self._invalidate_static_cache()
        self.update()
        super().resizeEvent(event)
