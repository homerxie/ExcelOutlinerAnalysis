from __future__ import annotations

from dataclasses import replace
from decimal import Decimal
from pathlib import Path
import sys

from PySide6.QtCore import (
    QEvent,
    QRegularExpression,
    QSignalBlocker,
    QSize,
    QTimer,
    Qt,
)
from PySide6.QtGui import (
    QAction,
    QActionGroup,
    QPixmap,
    QRegularExpressionValidator,
)
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QHeaderView,
    QLabel,
    QMainWindow,
    QMessageBox,
    QToolTip,
)

from easybumpcell.coordinate_format import format_coordinate_um
from easybumpcell.domain.enums import IssueLevel, OriginMode, ShapeType
from easybumpcell.domain.models import ProjectConfig
from easybumpcell.geometry import build_layouts
from easybumpcell.i18n import (
    ENGLISH,
    SIMPLIFIED_CHINESE,
    LanguageManager,
    translate_validation_message,
)
from easybumpcell.services.batch_export import export_project, intended_paths
from easybumpcell.services.lef_export import (
    LEF_BOUNDARY_LAYER_NAME,
    LEF_LABEL_LAYER_SUFFIX,
    LEF_PIN_LAYER_SUFFIX,
    LEF_PIN_NAME,
)
from easybumpcell.services.naming import base_name
from easybumpcell.services.validation import has_errors, validate_project
from easybumpcell.ui.advanced_dialog import AdvancedSettingsDialog
from easybumpcell.ui.export_dialog import ExportConfirmationDialog
from easybumpcell.ui.layer_table_model import (
    DimensionDelegate,
    IntegerDelegate,
    LayerNameDelegate,
    LayerTableModel,
)
from easybumpcell.ui.preview_widget import LayoutPreviewWidget
from easybumpcell.ui_generated.ui_main_window import Ui_MainWindow


HELP_IMAGE_DIRECTORY = Path("help_images")
PROCESS_DBU_HELP_IMAGE = HELP_IMAGE_DIRECTORY / "process_dbu_help.png"
LAYER_MAPPING_HELP_IMAGE = HELP_IMAGE_DIRECTORY / "layer_mapping_help.png"
HELP_TOOLTIP_MAXIMUM_SIZE = QSize(720, 480)
HELP_TOOLTIP_SCREEN_FRACTION = 0.9


class MainWindow(QMainWindow):
    def __init__(
        self,
        language_manager: LanguageManager | None = None,
    ) -> None:
        super().__init__()
        self.language_manager = language_manager or LanguageManager(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self._help_image_files = {
            self.ui.dbuHelpButton: PROCESS_DBU_HELP_IMAGE,
            self.ui.layerMappingHelpButton: LAYER_MAPPING_HELP_IMAGE,
        }
        for button in self._help_image_files:
            button.installEventFilter(self)
            button.clicked.connect(
                lambda _checked=False, target=button: self._show_help_image(
                    target
                )
            )
        self._image_help_tooltip = QLabel(
            self,
            Qt.WindowType.ToolTip,
        )
        self._image_help_tooltip.setObjectName("imageHelpTooltip")
        self._image_help_tooltip.setAttribute(
            Qt.WidgetAttribute.WA_TransparentForMouseEvents,
        )
        self._image_help_tooltip.setScaledContents(False)
        self._image_help_tooltip.setStyleSheet(
            "QLabel#imageHelpTooltip {"
            "background: #FFF6D8;"
            "border: 1px solid #E6C86E;"
            "padding: 0px;"
            "}"
        )
        self._image_help_tooltip.hide()
        self._help_tooltip_hide_timer = QTimer(self)
        self._help_tooltip_hide_timer.setSingleShot(True)
        self._help_tooltip_hide_timer.timeout.connect(
            self._image_help_tooltip.hide
        )
        self._retranslate_help_buttons()
        for index, shape_type in enumerate(ShapeType):
            self.ui.shapeCombo.setItemData(index, shape_type.value)
        self._language_action_group = QActionGroup(self)
        self._language_action_group.setExclusive(True)
        self._language_actions = {
            ENGLISH: self.ui.englishAction,
            SIMPLIFIED_CHINESE: self.ui.simplifiedChineseAction,
        }
        for language, action in self._language_actions.items():
            action.setData(language)
            self._language_action_group.addAction(action)
            action.setChecked(language == self.language_manager.language)
        self.ui.previewTabs.setCornerWidget(
            self.ui.nodeControlsWidget,
            Qt.Corner.TopRightCorner,
        )
        self.config = ProjectConfig()
        for index, dbu in enumerate(("0.001", "0.0005")):
            self.ui.dbuCombo.setItemData(index, dbu)
        self.ui.dbuCombo.setCurrentIndex(
            self.ui.dbuCombo.findData(str(self.config.dbu_um))
        )
        self.model = LayerTableModel(self.config, self)
        self.ui.layerTable.setModel(self.model)
        self.ui.layerTable.setItemDelegateForColumn(
            1,
            LayerNameDelegate(self.ui.layerTable),
        )
        for column in (2, 3):
            self.ui.layerTable.setItemDelegateForColumn(
                column, IntegerDelegate(self.ui.layerTable)
            )
        for column in (4, 5):
            self.ui.layerTable.setItemDelegateForColumn(
                column, DimensionDelegate(self.ui.layerTable)
            )
        self.ui.layerTable.verticalHeader().setVisible(False)
        self.ui.layerTable.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.ui.layerTable.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.ui.mainSplitter.setSizes([560, 820])

        self.preview = LayoutPreviewWidget(self.ui.previewContainer)
        self.ui.previewContainerLayout.addWidget(self.preview)
        self.lef_preview = LayoutPreviewWidget(
            self.ui.lefPreviewContainer,
            lef_mode=True,
        )
        self.ui.lefPreviewContainerLayout.addWidget(self.lef_preview)
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setSingleShot(True)
        self._refresh_timer.setInterval(100)
        self._refresh_timer.timeout.connect(self.refresh)

        token_validator = QRegularExpressionValidator(
            QRegularExpression("[A-Za-z0-9]*"), self
        )
        bump_type_validator = QRegularExpressionValidator(
            QRegularExpression("[A-Za-z0-9_]*"), self
        )
        version_validator = QRegularExpressionValidator(
            QRegularExpression("[A-Za-z0-9.-]*"),
            self,
        )
        self.ui.technologyEdit.setValidator(token_validator)
        self.ui.bumpTypeEdit.setValidator(bump_type_validator)
        self.ui.versionEdit.setValidator(version_validator)
        self._connect_signals()
        self.refresh()
        QTimer.singleShot(0, self._fit_project_group_height)

    def _connect_signals(self) -> None:
        self.ui.technologyEdit.textChanged.connect(self._project_text_changed)
        self.ui.bumpTypeEdit.textChanged.connect(self._project_text_changed)
        self.ui.versionEdit.textChanged.connect(self._project_text_changed)
        self.ui.shapeCombo.currentIndexChanged.connect(self._shape_changed)
        self.ui.dbuCombo.currentIndexChanged.connect(self._dbu_changed)
        self._language_action_group.triggered.connect(
            self._language_changed
        )
        self.language_manager.languageChanged.connect(
            self._retranslate_interface
        )
        self.model.contentChanged.connect(self.schedule_refresh)
        self.model.processOrderChanged.connect(self.schedule_refresh)
        self.ui.addLayerButton.clicked.connect(self.model.add_layer)
        self.ui.deleteLayerButton.clicked.connect(self._delete_selected_layer)
        self.ui.resetLayersButton.clicked.connect(self._restore_defaults)
        self.ui.confirmOrderButton.clicked.connect(self._confirm_order)
        self.ui.advancedSettingsAction.triggered.connect(
            self._show_advanced
        )
        self.ui.exportButton.clicked.connect(self._export)
        self.ui.showNodesCheck.toggled.connect(self.preview.set_show_nodes)
        self.ui.showNodesCheck.toggled.connect(self.lef_preview.set_show_nodes)
        self.ui.snapNodesCheck.toggled.connect(self.preview.set_snap_to_nodes)
        self.ui.snapNodesCheck.toggled.connect(self.lef_preview.set_snap_to_nodes)
        self.ui.alPadLayerCombo.currentIndexChanged.connect(
            self._al_pad_layer_changed
        )
        self.ui.layerTable.selectionModel().selectionChanged.connect(self._selection_changed)
        self.ui.mainSplitter.splitterMoved.connect(
            self._schedule_project_group_fit
        )

    def schedule_refresh(self) -> None:
        self._refresh_timer.start()

    def _schedule_project_group_fit(self, *_args) -> None:
        QTimer.singleShot(0, self._fit_project_group_height)

    def _fit_project_group_height(self) -> None:
        width = self.ui.projectGroup.width()
        if width <= 0:
            return
        target_height = self.ui.projectGroup.heightForWidth(width)
        if target_height > 0 and self.ui.projectGroup.height() != target_height:
            self.ui.projectGroup.setFixedHeight(target_height)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self._schedule_project_group_fit()

    def eventFilter(self, watched, event) -> bool:
        if watched in self._help_image_files:
            if event.type() == QEvent.Type.ToolTip:
                self._help_tooltip_hide_timer.stop()
                self._show_help_image(watched, event.globalPos())
                return True
            if event.type() == QEvent.Type.Leave:
                self._help_tooltip_hide_timer.start(500)
        return super().eventFilter(watched, event)

    def _retranslate_help_buttons(self) -> None:
        help_text = self.tr("Show detailed confirmation guide")
        for button in self._help_image_files:
            button.setToolTip(help_text)
            button.setAccessibleName(help_text)

    def _help_image_bases(self) -> tuple[Path, ...]:
        candidates: list[Path] = []
        if getattr(sys, "frozen", False):
            candidates.append(Path(sys.executable).resolve().parent)
        candidates.append(Path(__file__).resolve().parents[1])
        pyinstaller_root = getattr(sys, "_MEIPASS", None)
        if pyinstaller_root:
            candidates.extend(
                (
                    Path(pyinstaller_root).resolve() / "easybumpcell",
                    Path(pyinstaller_root).resolve(),
                )
            )
        candidates.append(Path.cwd().resolve())
        unique_bases: list[Path] = []
        for base in candidates:
            if base not in unique_bases:
                unique_bases.append(base)
        return tuple(unique_bases)

    def _find_help_image(
        self,
        relative_path: str | Path,
    ) -> Path | None:
        relative_path = Path(relative_path)
        for base in self._help_image_bases():
            path = base / relative_path
            if path.is_file():
                return path
        return None

    def _help_tooltip_logical_limit(self, screen=None) -> QSize:
        limit = QSize(HELP_TOOLTIP_MAXIMUM_SIZE)
        if screen is None:
            screen = self.screen()
        if screen is not None:
            available_size = screen.availableGeometry().size()
            limit.setWidth(
                min(
                    limit.width(),
                    max(
                        1,
                        round(
                            available_size.width()
                            * HELP_TOOLTIP_SCREEN_FRACTION
                        ),
                    ),
                )
            )
            limit.setHeight(
                min(
                    limit.height(),
                    max(
                        1,
                        round(
                            available_size.height()
                            * HELP_TOOLTIP_SCREEN_FRACTION
                        ),
                    ),
                )
            )
        return limit

    def _load_help_tooltip_pixmap(
        self,
        relative_path: str | Path,
        screen=None,
    ) -> tuple[QPixmap | None, str | None]:
        relative_path = Path(relative_path)
        path = self._find_help_image(relative_path)
        if path is None:
            message = self.tr(
                "Help image not found at relative path {path}."
            ).format(
                path=relative_path.as_posix(),
            )
            return None, message

        pixmap = QPixmap(str(path))
        if pixmap.isNull():
            message = self.tr(
                "Unable to display help image: {path}"
            ).format(path=relative_path.as_posix())
            return None, message

        if screen is None:
            screen = self.screen()
        device_pixel_ratio = (
            max(1.0, float(screen.devicePixelRatio()))
            if screen is not None
            else 1.0
        )
        logical_limit = self._help_tooltip_logical_limit(screen)
        physical_limit = QSize(
            max(1, round(logical_limit.width() * device_pixel_ratio)),
            max(1, round(logical_limit.height() * device_pixel_ratio)),
        )
        target_size = pixmap.size()
        if (
            target_size.width() > physical_limit.width()
            or target_size.height() > physical_limit.height()
        ):
            target_size.scale(
                physical_limit,
                Qt.AspectRatioMode.KeepAspectRatio,
            )
            pixmap = pixmap.scaled(
                target_size,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )

        # Never upscale a tutorial image. Setting DPR on the native or
        # smoothly downsampled pixmap lets QLabel use Qt's logical sizing
        # without asking Windows to resample it again.
        pixmap.setDevicePixelRatio(device_pixel_ratio)
        return pixmap, None

    def _show_help_image(self, button, global_position=None) -> None:
        relative_path = self._help_image_files[button]
        if global_position is None:
            global_position = button.mapToGlobal(button.rect().bottomLeft())
        screen = QApplication.screenAt(global_position) or button.screen()
        pixmap, error_message = self._load_help_tooltip_pixmap(
            relative_path,
            screen,
        )
        if pixmap is None:
            self._image_help_tooltip.hide()
            QToolTip.showText(
                global_position,
                error_message or "",
                button,
                button.rect(),
            )
            return

        QToolTip.hideText()
        self._image_help_tooltip.setPixmap(pixmap)
        self._image_help_tooltip.adjustSize()
        tooltip_size = self._image_help_tooltip.size()
        available = screen.availableGeometry()
        x_position = global_position.x() + 8
        y_position = global_position.y() + 8
        if x_position + tooltip_size.width() > available.right() + 1:
            x_position = max(
                available.left(),
                global_position.x() - tooltip_size.width() - 8,
            )
        if y_position + tooltip_size.height() > available.bottom() + 1:
            y_position = max(
                available.top(),
                global_position.y() - tooltip_size.height() - 8,
            )
        self._image_help_tooltip.move(x_position, y_position)
        self._image_help_tooltip.show()
        self._help_tooltip_hide_timer.start(15_000)

    def _project_text_changed(self) -> None:
        self.config.technology_name = self.ui.technologyEdit.text().strip()
        self.config.bump_type = self.ui.bumpTypeEdit.text().strip()
        self.config.version = self.ui.versionEdit.text().strip()
        self.schedule_refresh()

    def _shape_changed(self) -> None:
        shape_value = self.ui.shapeCombo.currentData()
        if shape_value is None:
            return
        self.model.set_shape_type(ShapeType(shape_value))
        self.schedule_refresh()

    def _dbu_changed(self, _index: int) -> None:
        value = self.ui.dbuCombo.currentData()
        if value is None:
            return
        self.config.dbu_um = Decimal(str(value))
        self.schedule_refresh()

    def _language_changed(self, action: QAction) -> None:
        language = action.data()
        if language is not None:
            self.language_manager.set_language(str(language))

    def _retranslate_interface(self) -> None:
        with QSignalBlocker(self.ui.shapeCombo):
            self.ui.retranslateUi(self)
        with QSignalBlocker(self._language_action_group):
            self._language_actions[
                self.language_manager.language
            ].setChecked(True)
        self.model.retranslate()
        self.preview.retranslate()
        self.lef_preview.retranslate()
        self._retranslate_help_buttons()
        self._schedule_project_group_fit()
        self.refresh()

    def _delete_selected_layer(self) -> None:
        index = self.ui.layerTable.currentIndex()
        if index.isValid():
            if not self.model.remove_row(index.row()):
                QMessageBox.information(
                    self,
                    self.tr("Delete Layer"),
                    self.tr("At least one layer is required."),
                )

    def _restore_defaults(self) -> None:
        answer = QMessageBox.question(
            self,
            self.tr("Restore Default Layers"),
            self.tr(
                "Replace the current layer table with AP, CB2, PIO and UBM?"
            ),
        )
        if answer == QMessageBox.StandardButton.Yes:
            self.model.restore_defaults()

    def _confirm_order(self) -> None:
        order = " → ".join(
            layer.meaning or self.tr("(unnamed)")
            for layer in self.config.layers
        )
        answer = QMessageBox.question(
            self,
            self.tr("Confirm Process Order"),
            self.tr("Confirm this process order?\n\n{order}").format(
                order=order,
            ),
        )
        if answer == QMessageBox.StandardButton.Yes:
            self.config.process_order_confirmed = True
            self.refresh()

    def _show_advanced(self) -> None:
        dialog = AdvancedSettingsDialog(self.config, self)
        if dialog.exec():
            dialog.apply_to_config()
            self.refresh()

    def _selection_changed(self) -> None:
        index = self.ui.layerTable.currentIndex()
        uid = self.config.layers[index.row()].uid if index.isValid() else None
        self.preview.set_selected_layer(uid)

    def _refresh_al_pad_layer_combo(self) -> None:
        with QSignalBlocker(self.ui.alPadLayerCombo):
            self.ui.alPadLayerCombo.clear()
            self.ui.alPadLayerCombo.addItem(
                self.tr("Select Al Pad Layer…"),
                None,
            )
            for layer in self.config.layers:
                layer_number = "—" if layer.layer is None else str(layer.layer)
                datatype = "—" if layer.datatype is None else str(layer.datatype)
                self.ui.alPadLayerCombo.addItem(
                    self.tr(
                        "{name} — GDS Layer Number {layer} / "
                        "Datatype {datatype}"
                    ).format(
                        name=layer.meaning or self.tr("(unnamed)"),
                        layer=layer_number,
                        datatype=datatype,
                    ),
                    layer.uid,
                )
            selected_index = self.ui.alPadLayerCombo.findData(
                self.config.al_pad_layer_uid
            )
            self.ui.alPadLayerCombo.setCurrentIndex(
                selected_index if selected_index >= 0 else 0
            )

    def _al_pad_layer_changed(self) -> None:
        uid = self.ui.alPadLayerCombo.currentData()
        self.config.al_pad_layer_uid = str(uid) if uid is not None else None
        self.refresh()

    def _update_lef_preview(self, layouts) -> None:
        definition = self.config.al_pad_layer()
        layer_number = (
            "—"
            if definition is None or definition.layer is None
            else str(definition.layer)
        )
        datatype = (
            "—"
            if definition is None or definition.datatype is None
            else str(definition.datatype)
        )
        layer_name = (
            "—"
            if definition is None or not definition.meaning
            else definition.meaning
        )
        self.ui.alPadHintLabel.setText(
            self.tr(
                "Please confirm again:\n"
                "1. The Layername.Datatype of the Al Pad Drawing layer "
                "(not the Marking or Dummy layer) is "
                "{layer_number}.{datatype}.\n"
                "2. The layer name defined for Layername.Datatype "
                "{layer_number}.{datatype} in the technology layermap "
                "(*.map) file is {layer_name}."
            ).format(
                layer_number=layer_number,
                datatype=datatype,
                layer_name=layer_name,
            )
        )
        if definition is None:
            self.ui.lefPinSummaryLabel.setText(
                f"PIN: — · LABEL ({LEF_PIN_NAME}): — · "
                f"{LEF_BOUNDARY_LAYER_NAME}"
            )
            self.ui.lefPinSummaryLabel.setToolTip("")
            self.lef_preview.clear_layouts()
            return

        summary = (
            f"{definition.meaning}{LEF_PIN_LAYER_SUFFIX} · "
            f"{definition.meaning}{LEF_LABEL_LAYER_SUFFIX} ({LEF_PIN_NAME}) · "
            f"{LEF_BOUNDARY_LAYER_NAME} · "
            f"GDS Layer Number {layer_number} / Datatype {datatype}"
        )
        self.ui.lefPinSummaryLabel.setText(summary)
        self.ui.lefPinSummaryLabel.setToolTip(summary)
        if not layouts:
            self.lef_preview.clear_layouts()
            return
        filtered_layouts = []
        for layout in layouts:
            layer = next(
                (
                    item
                    for item in layout.layers
                    if item.definition.uid == definition.uid
                ),
                None,
            )
            if layer is None:
                self.lef_preview.clear_layouts()
                return
            filtered_layouts.append(replace(layout, layers=(layer,)))
        self.lef_preview.set_selected_layer(definition.uid)
        self.lef_preview.set_layouts(self.config, filtered_layouts)

    def _format_settings_summary(self) -> str:
        reference = self.config.reference_layer()
        if self.config.origin_mode is OriginMode.CENTER:
            origin = self.tr("Common Center")
        else:
            origin = self.tr("{name} Lower-left").format(
                name=(
                    reference.meaning
                    if reference
                    else self.tr("Missing")
                ),
            )
        return self.tr("DBU {dbu} µm · Origin {origin}").format(
            dbu=self.config.dbu_um,
            origin=origin,
        )

    def _format_center_summary(self, layouts) -> str:
        if not layouts:
            return "—"
        rows = []
        for layout in layouts:
            x_um = layout.common_center_dbu[0] * self.config.dbu_um
            y_um = layout.common_center_dbu[1] * self.config.dbu_um
            coordinates = (
                f"X {format_coordinate_um(x_um, self.config.dbu_um)} µm · "
                f"Y {format_coordinate_um(y_um, self.config.dbu_um)} µm"
            )
            if len(layouts) == 1:
                return coordinates
            rows.append(f"{layout.logical_angle}D: {coordinates}")
        return "\n".join(rows)

    def _fit_summary_content_heights(
        self,
        center_summary: str,
        validation_text: str,
    ) -> None:
        center_lines = max(1, center_summary.count("\n") + 1)
        center_height = min(
            72,
            max(
                24,
                center_lines
                * self.ui.centerSummaryLabel.fontMetrics().lineSpacing()
                + 4,
            ),
        )
        self.ui.centerSummaryLabel.setFixedHeight(center_height)

        validation_lines = max(1, validation_text.count("\n") + 1)
        validation_height = min(
            96,
            max(
                24,
                validation_lines
                * self.ui.validationText.fontMetrics().lineSpacing()
                + 6,
            ),
        )
        self.ui.validationText.setFixedHeight(validation_height)

    def refresh(self) -> None:
        self._update_process_confirmation_hints()
        self._refresh_al_pad_layer_combo()
        issues = validate_project(self.config, for_export=False)
        errors = [issue.message for issue in issues if issue.level is IssueLevel.ERROR]
        warnings = [issue.message for issue in issues if issue.level is IssueLevel.WARNING]
        layouts = []
        if not errors:
            try:
                layouts = build_layouts(self.config)
                warnings.extend(sorted({risk.message for layout in layouts for risk in layout.risks}))
            except (ValueError, ArithmeticError) as exc:
                errors.append(str(exc))

        try:
            generated_base_name = base_name(self.config)
            self.ui.generatedNameLabel.setText(generated_base_name)
            self.ui.generatedNameLabel.setToolTip(generated_base_name)
        except ValueError:
            self.ui.generatedNameLabel.setText("—")
            self.ui.generatedNameLabel.setToolTip("")
        settings_summary = self._format_settings_summary()
        self.ui.settingsSummaryLabel.setText(settings_summary)
        self.ui.settingsSummaryLabel.setToolTip(settings_summary)
        node_counts = sorted({layout.nodes_per_polygon for layout in layouts})
        node_count_text = (
            self.tr("{count}-gon").format(
                count=node_counts[0],
            )
            if len(node_counts) == 1
            else "—"
        )
        self.ui.nodeCountLabel.setText(node_count_text)
        self.ui.nodeCountLabel.setToolTip(node_count_text)
        center_summary = self._format_center_summary(layouts)
        self.ui.centerSummaryLabel.setText(center_summary)
        self.ui.centerSummaryLabel.setToolTip(center_summary)
        if errors:
            self.ui.validationText.setStyleSheet(
                "QPlainTextEdit { color: #B3261E; border: none; "
                "background: transparent; padding: 0px; }"
            )
            validation_lines = [
                self.tr("ERROR: {message}").format(
                    message=translate_validation_message(message),
                )
                for message in errors
            ]
            validation_lines.extend(
                self.tr("WARNING: {message}").format(
                    message=translate_validation_message(message),
                )
                for message in warnings
            )
            validation_text = "\n".join(validation_lines)
        elif warnings:
            self.ui.validationText.setStyleSheet(
                "QPlainTextEdit { color: #8A5A00; border: none; "
                "background: transparent; padding: 0px; }"
            )
            validation_text = "\n".join(
                self.tr("WARNING: {message}").format(
                    message=translate_validation_message(message),
                )
                for message in warnings
            )
        elif not self.config.process_order_confirmed:
            self.ui.validationText.setStyleSheet(
                "QPlainTextEdit { color: #8A5A00; border: none; "
                "background: transparent; padding: 0px; }"
            )
            validation_text = self.tr(
                "Confirm the process order before export."
            )
        else:
            self.ui.validationText.setStyleSheet(
                "QPlainTextEdit { color: #1B7F3A; border: none; "
                "background: transparent; padding: 0px; }"
            )
            validation_text = self.tr("PASS")
        self.ui.validationText.setPlainText(validation_text)
        self.ui.validationText.setToolTip(validation_text)
        self._fit_summary_content_heights(
            center_summary,
            validation_text,
        )

        if self.config.process_order_confirmed:
            self.ui.confirmOrderButton.setText(self.tr("Order Confirmed"))
            self.ui.confirmOrderButton.setToolTip(
                self.tr("The current process order has been confirmed.")
            )
        else:
            self.ui.confirmOrderButton.setText(
                self.tr("Confirm Process Order")
            )
            self.ui.confirmOrderButton.setToolTip(
                self.tr(
                    "Review and confirm the layer process order before export."
                )
            )
        self.ui.exportButton.setEnabled(
            not errors
            and self.config.process_order_confirmed
            and self.config.al_pad_layer() is not None
        )
        if layouts:
            self.preview.set_layouts(self.config, layouts)
        else:
            self.preview.clear_layouts()
        self._update_lef_preview(layouts)

    def _update_process_confirmation_hints(self) -> None:
        technology_name = self.config.technology_name or "—"
        self.ui.dbuHintLabel.setText(
            self.tr(
                "Please confirm that the Process DBU exactly matches the "
                "DBU definition in the techfile (*.tf) of "
                "{technology_name} Process."
            ).format(technology_name=technology_name)
        )
        self.ui.processHintLabel.setText(
            self.tr(
                "Please confirm:\n"
                "1. The GDS Layer Number, Datatype are the correct layers "
                "used in the current package bump type of "
                "{technology_name} Process. This will affect the GDS "
                "generation.\n"
                "2. The GDS Layer Name exactly matches the GDS Layer "
                "Number/Datatype defined in the layermap (*.map) of "
                "{technology_name} Process. This will affect the LEF "
                "generation."
            ).format(technology_name=technology_name)
        )
        self._schedule_project_group_fit()

    def _export(self) -> None:
        issues = validate_project(self.config, for_export=True)
        if has_errors(issues):
            QMessageBox.critical(
                self,
                self.tr("Cannot Export"),
                "\n".join(
                    translate_validation_message(issue.message)
                    for issue in issues
                    if issue.level is IssueLevel.ERROR
                ),
            )
            return
        directory = QFileDialog.getExistingDirectory(
            self,
            self.tr("Select Output Directory"),
        )
        if not directory:
            return
        paths = intended_paths(self.config, directory)
        existing = [path for path in paths if path.exists()]
        layouts = build_layouts(self.config)
        warning_messages = [
            translate_validation_message(issue.message)
            for issue in issues
            if issue.level is IssueLevel.WARNING
        ]
        warning_messages.extend(
            sorted(
                {
                    translate_validation_message(risk.message)
                    for layout in layouts
                    for risk in layout.risks
                }
            )
        )
        al_pad_layer = self.config.al_pad_layer()
        if al_pad_layer is None:
            QMessageBox.critical(
                self,
                self.tr("Cannot Export"),
                self.tr(
                    "Select and verify the Al Pad Layer in LEF Preview."
                ),
            )
            return
        dialog = ExportConfirmationDialog(
            paths,
            warning_messages,
            existing,
            al_pad_layer,
            self,
            language=self.language_manager.language,
            technology_name=self.config.technology_name,
        )
        if not dialog.exec():
            return
        try:
            result = export_project(self.config, directory, overwrite=bool(existing))
        except Exception as exc:
            QMessageBox.critical(
                self,
                self.tr("Export Failed"),
                translate_validation_message(str(exc)),
            )
            return
        output_lines = []
        for gds_path, lef_path in zip(result.gds_paths, result.lef_paths):
            output_lines.extend((gds_path.name, lef_path.name))
        output_lines.append(result.report_path.name)
        QMessageBox.information(
            self,
            self.tr("Export Complete"),
            self.tr("Generated and verified:\n\n{files}").format(
                files="\n".join(output_lines),
            ),
        )
