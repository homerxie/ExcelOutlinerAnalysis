from __future__ import annotations

from PySide6.QtCore import QRegularExpression
from PySide6.QtGui import QRegularExpressionValidator
from PySide6.QtWidgets import QDialog, QDialogButtonBox

from easybumpcell.domain.enums import ShapeType
from easybumpcell.domain.models import ProjectConfig
from easybumpcell.services.process_templates import (
    ProcessTemplateError,
    TEMPLATE_SUFFIX_PATTERN,
    build_template_name,
)
from easybumpcell.services.shape_availability import (
    SHAPE_ORDER,
    available_shape_types,
)
from easybumpcell.ui_generated.ui_template_save_dialog import (
    Ui_TemplateSaveDialog,
)


class TemplateSaveDialog(QDialog):
    def __init__(
        self,
        config: ProjectConfig,
        *,
        initial_suffix: str = "",
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.config = config
        self.ui = Ui_TemplateSaveDialog()
        self.ui.setupUi(self)
        self._shape_checks = {
            ShapeType.ROUND: self.ui.roundCheck,
            ShapeType.OVAL: self.ui.ovalCheck,
        }
        available_shapes = set(available_shape_types(config))
        for shape_type, checkbox in self._shape_checks.items():
            checkbox.setEnabled(shape_type in available_shapes)
            checkbox.setChecked(shape_type in available_shapes)
            checkbox.toggled.connect(self._refresh_file_name)
        self._suffix_validator = QRegularExpressionValidator(
            QRegularExpression(TEMPLATE_SUFFIX_PATTERN)
        )
        self.ui.suffixEdit.setValidator(self._suffix_validator)
        self.ui.suffixEdit.setText(initial_suffix)
        self.ui.suffixEdit.textChanged.connect(self._refresh_file_name)
        self._refresh_file_name()

    def custom_suffix(self) -> str:
        return self.ui.suffixEdit.text().strip()

    def file_name(self) -> str:
        return self.ui.fileNamePreviewLabel.text()

    def selected_shape_types(self) -> tuple[ShapeType, ...]:
        return tuple(
            shape_type
            for shape_type in SHAPE_ORDER
            if self._shape_checks[shape_type].isChecked()
        )

    def _refresh_file_name(self) -> None:
        shape_types = self.selected_shape_types()
        if len(shape_types) == 2:
            shape_status = self.tr(
                "Both Round and Oval dimensions will be saved."
            )
        elif shape_types:
            shape_status = self.tr(
                "Only {shape} dimensions will be saved."
            ).format(shape=self.tr(shape_types[0].value))
        else:
            shape_status = self.tr(
                "Select at least one shape to save."
            )
        self.ui.shapeStatusLabel.setText(shape_status)
        try:
            if not shape_types:
                raise ProcessTemplateError(shape_status)
            template_name = build_template_name(
                self.config.technology_name,
                self.config.bump_type,
                shape_types,
                self.custom_suffix(),
            )
        except ProcessTemplateError as exc:
            self.ui.fileNamePreviewLabel.setText("—")
            self.ui.validationLabel.setText(str(exc))
            valid = False
        else:
            self.ui.fileNamePreviewLabel.setText(
                f"{template_name}.json"
            )
            self.ui.validationLabel.clear()
            valid = True
        save_button = self.ui.buttonBox.button(
            QDialogButtonBox.StandardButton.Save
        )
        if save_button is not None:
            save_button.setEnabled(valid)
