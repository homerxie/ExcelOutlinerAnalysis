from __future__ import annotations

from PySide6.QtWidgets import QDialog, QDialogButtonBox

from easybumpcell.domain.enums import ShapeType
from easybumpcell.services.shape_availability import SHAPE_ORDER
from easybumpcell.ui_generated.ui_export_shape_dialog import (
    Ui_ExportShapeDialog,
)


class ExportShapeDialog(QDialog):
    def __init__(
        self,
        available_shapes: tuple[ShapeType, ...],
        current_shape: ShapeType,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.ui = Ui_ExportShapeDialog()
        self.ui.setupUi(self)
        self._checks = {
            ShapeType.ROUND: self.ui.roundCheck,
            ShapeType.OVAL: self.ui.ovalCheck,
        }
        available_set = set(available_shapes)
        for shape_type, checkbox in self._checks.items():
            checkbox.setEnabled(shape_type in available_set)
            checkbox.setChecked(
                shape_type in available_set
                and (
                    shape_type is current_shape
                    or len(available_set) == 1
                )
            )
            checkbox.toggled.connect(self._update_ok_state)
        unavailable = [
            self.tr(shape.value)
            for shape in SHAPE_ORDER
            if shape not in available_set
        ]
        self.ui.availabilityLabel.setText(
            self.tr("Missing complete dimensions: {shapes}").format(
                shapes=", ".join(unavailable),
            )
            if unavailable
            else self.tr("Complete dimensions are available for both shapes.")
        )
        self._update_ok_state()

    def selected_shapes(self) -> tuple[ShapeType, ...]:
        return tuple(
            shape_type
            for shape_type in SHAPE_ORDER
            if self._checks[shape_type].isChecked()
        )

    def _update_ok_state(self) -> None:
        ok_button = self.ui.buttonBox.button(
            QDialogButtonBox.StandardButton.Ok
        )
        if ok_button is not None:
            ok_button.setEnabled(bool(self.selected_shapes()))
