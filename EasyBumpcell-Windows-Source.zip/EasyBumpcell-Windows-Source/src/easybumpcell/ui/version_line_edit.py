from __future__ import annotations

from PySide6.QtCore import QEvent, QSignalBlocker, Qt
from PySide6.QtGui import QPainter, QPalette
from PySide6.QtWidgets import QLineEdit, QStyle, QStyleOptionFrame


class VersionLineEdit(QLineEdit):
    """A line edit with a visible, non-editable ``V`` prefix."""

    FIXED_PREFIX = "V"
    PREFIX_LEFT_PADDING = 5
    PREFIX_TEXT_GAP = 4

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.textChanged.connect(self._remove_pasted_prefix)
        self._update_prefix_margin()

    def text(self) -> str:
        return f"{self.FIXED_PREFIX}{QLineEdit.text(self)}"

    def editable_text(self) -> str:
        return QLineEdit.text(self)

    def version(self) -> str:
        suffix = self.editable_text().strip()
        return f"{self.FIXED_PREFIX}{suffix}" if suffix else ""

    def setText(self, text: str) -> None:
        suffix = str(text or "")
        if suffix[:1].casefold() == self.FIXED_PREFIX.casefold():
            suffix = suffix[1:]
        QLineEdit.setText(self, suffix)

    def _remove_pasted_prefix(self, text: str) -> None:
        if text[:1].casefold() != self.FIXED_PREFIX.casefold():
            return
        cursor_position = self.cursorPosition()
        with QSignalBlocker(self):
            QLineEdit.setText(self, text[1:])
            self.setCursorPosition(max(0, cursor_position - 1))

    def _prefix_metrics(self) -> tuple[int, int]:
        metrics = self.fontMetrics()
        bounds = metrics.boundingRect(self.FIXED_PREFIX)
        origin_adjustment = -min(0, bounds.left())
        visual_right = origin_adjustment + max(
            metrics.horizontalAdvance(self.FIXED_PREFIX),
            bounds.right() + 1,
        )
        return origin_adjustment, visual_right

    def _update_prefix_margin(self) -> None:
        _origin_adjustment, visual_right = self._prefix_metrics()
        self.setTextMargins(
            self.PREFIX_LEFT_PADDING
            + visual_right
            + self.PREFIX_TEXT_GAP,
            0,
            0,
            0,
        )

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        option = QStyleOptionFrame()
        self.initStyleOption(option)
        contents = self.style().subElementRect(
            QStyle.SubElement.SE_LineEditContents,
            option,
            self,
        )
        metrics = self.fontMetrics()
        origin_adjustment, _visual_right = self._prefix_metrics()
        baseline = (
            contents.top()
            + (contents.height() - metrics.height()) // 2
            + metrics.ascent()
        )
        painter = QPainter(self)
        painter.setFont(self.font())
        color_group = (
            QPalette.ColorGroup.Active
            if self.isEnabled()
            else QPalette.ColorGroup.Disabled
        )
        painter.setPen(
            self.palette().color(color_group, QPalette.ColorRole.Text)
        )
        painter.drawText(
            contents.left()
            + self.PREFIX_LEFT_PADDING
            + origin_adjustment,
            baseline,
            self.FIXED_PREFIX,
        )

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self._update_prefix_margin()

    def changeEvent(self, event) -> None:
        super().changeEvent(event)
        if event.type() in (
            QEvent.Type.FontChange,
            QEvent.Type.StyleChange,
            QEvent.Type.PaletteChange,
        ):
            self._update_prefix_margin()
