from __future__ import annotations

from decimal import Decimal
from pathlib import Path

from PySide6.QtCore import QSize, QTimer, Qt
from PySide6.QtGui import (
    QKeySequence,
    QShortcut,
    QTextLayout,
)
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QListWidgetItem,
    QStyle,
)

from easybumpcell.domain.models import LayerDefinition
from easybumpcell.export_checklist import (
    format_export_checklist_text,
    load_export_checklist,
)
from easybumpcell.i18n import ENGLISH
from easybumpcell.ui_generated.ui_export_dialog import Ui_ExportDialog


class ExportConfirmationDialog(QDialog):
    CHECKLIST_TEXT_ROLE = Qt.ItemDataRole.UserRole

    def __init__(
        self,
        paths: list[Path],
        warnings: list[str],
        existing: list[Path],
        al_pad_layer: LayerDefinition,
        parent=None,
        *,
        language: str | None = None,
        checklist_path: Path | None = None,
        technology_name: str | None = None,
        dbu_um: Decimal | str | None = None,
        process_order: str | None = None,
        all_layers: str | None = None,
    ) -> None:
        super().__init__(parent)
        self.ui = Ui_ExportDialog()
        self.ui.setupUi(self)
        self._checklist_checkboxes: list[
            tuple[QListWidgetItem, QCheckBox]
        ] = []
        self._copy_checklist_shortcut = QShortcut(
            QKeySequence(QKeySequence.StandardKey.Copy),
            self.ui.exportChecklist,
        )
        self._copy_checklist_shortcut.setContext(
            Qt.ShortcutContext.WidgetWithChildrenShortcut
        )
        self._copy_checklist_shortcut.activated.connect(
            self._copy_selected_checklist_items
        )
        if language is None:
            language_manager = getattr(parent, "language_manager", None)
            language = getattr(language_manager, "language", ENGLISH)
        project_config = getattr(parent, "config", None)
        if technology_name is None:
            technology_name = getattr(
                project_config,
                "technology_name",
                "",
            )
        technology_name = technology_name or "—"
        if dbu_um is None:
            dbu_um = getattr(project_config, "dbu_um", None)
        dbu_value = "—" if dbu_um is None else str(dbu_um)
        if process_order is None and project_config is not None:
            process_order = " → ".join(
                layer.meaning or "(unnamed)"
                for layer in project_config.tapeout_layers()
            )
        process_order = process_order or "—"
        if all_layers is None and project_config is not None:
            all_layers = "\n".join(
                f"{layer.meaning or '(unnamed)'} "
                f"{'—' if layer.layer is None else layer.layer},"
                f"{'—' if layer.datatype is None else layer.datatype}"
                for layer in project_config.layers
            )
        all_layers = all_layers or "—"
        checklist_text = load_export_checklist(language, checklist_path)
        self.ui.exportChecklistGroup.setTitle(checklist_text.title)
        self.ui.checklistIntroLabel.setText(checklist_text.intro)
        for path in paths:
            suffix = (
                self.tr("  [WILL BE REPLACED]")
                if path in existing
                else ""
            )
            self.ui.fileList.addItem(path.name + suffix)
        layer_number = (
            "—" if al_pad_layer.layer is None else str(al_pad_layer.layer)
        )
        datatype = (
            "—" if al_pad_layer.datatype is None else str(al_pad_layer.datatype)
        )
        al_layername = al_pad_layer.meaning or "—"
        al_layernumb_datatype = f"{layer_number}.{datatype}"
        for confirmation in checklist_text.confirmations:
            confirmation_values = {
                "name": al_pad_layer.meaning,
                "technology_name": technology_name,
                "DBU": dbu_value,
                "process_order": process_order,
                "all_layers": all_layers,
                "Al_layernumb_datatype": al_layernumb_datatype,
                "Al_layername": al_layername,
                "layer_number": layer_number,
                "datatype": datatype,
            }
            self._add_checklist_item(
                format_export_checklist_text(
                    confirmation,
                    "confirmations",
                    **confirmation_values,
                )
            )

        for warning in warnings:
            self._add_checklist_item(
                format_export_checklist_text(
                    checklist_text.warning_template,
                    "warning_template",
                    message=warning,
                )
            )
        if existing:
            self._add_checklist_item(
                format_export_checklist_text(
                    checklist_text.replacement_template,
                    "replacement_template",
                    count=len(existing),
                )
            )

        self.ui.exportChecklist.setTextElideMode(
            Qt.TextElideMode.ElideNone
        )
        self.ui.exportChecklist.setSpacing(4)
        self._save_button = self.ui.buttonBox.button(
            QDialogButtonBox.StandardButton.Save
        )
        self._save_button.setText(self.tr("Export"))
        self._refresh_checklist_layout()
        self._update_save_state()

    def _add_checklist_item(self, text: str) -> None:
        # The QListWidgetItem is only the row/selection container.  Leaving
        # DisplayRole or CheckStateRole set here makes Qt paint a second label
        # or indicator underneath the native QCheckBox item widget.
        item = QListWidgetItem()
        item.setData(self.CHECKLIST_TEXT_ROLE, text)
        item.setFlags(
            (
                item.flags()
                | Qt.ItemFlag.ItemIsEnabled
                | Qt.ItemFlag.ItemIsSelectable
            )
            & ~Qt.ItemFlag.ItemIsUserCheckable
        )
        self.ui.exportChecklist.addItem(item)
        checkbox = QCheckBox(text, self.ui.exportChecklist)
        checkbox.pressed.connect(
            lambda target=item: self._select_checklist_item(target)
        )
        checkbox.toggled.connect(self._update_save_state)
        self.ui.exportChecklist.setItemWidget(item, checkbox)
        self._checklist_checkboxes.append((item, checkbox))

    def checklist_texts(self) -> list[str]:
        return [
            str(item.data(self.CHECKLIST_TEXT_ROLE) or "")
            for item, _checkbox in self._checklist_checkboxes
        ]

    @staticmethod
    def _wrap_checkbox_text(text: str, checkbox: QCheckBox, width: int) -> str:
        wrapped_lines: list[str] = []
        for paragraph in text.split("\n"):
            if not paragraph:
                wrapped_lines.append("")
                continue
            layout = QTextLayout(paragraph, checkbox.font())
            layout.beginLayout()
            while True:
                line = layout.createLine()
                if not line.isValid():
                    break
                line.setLineWidth(width)
                start = line.textStart()
                length = line.textLength()
                wrapped_lines.append(paragraph[start : start + length].strip())
            layout.endLayout()
        return "\n".join(wrapped_lines)

    def _refresh_checklist_layout(self) -> None:
        checklist = self.ui.exportChecklist
        for item, checkbox in self._checklist_checkboxes:
            indicator_width = checkbox.style().pixelMetric(
                QStyle.PixelMetric.PM_IndicatorWidth,
            )
            label_spacing = checkbox.style().pixelMetric(
                QStyle.PixelMetric.PM_CheckBoxLabelSpacing,
            )
            text_width = max(
                120,
                checklist.viewport().width()
                - indicator_width
                - label_spacing
                - 16,
            )
            checkbox.setText(
                self._wrap_checkbox_text(
                    str(item.data(self.CHECKLIST_TEXT_ROLE) or ""),
                    checkbox,
                    text_width,
                )
            )
            item.setSizeHint(QSize(0, checkbox.sizeHint().height()))

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if hasattr(self, "_checklist_checkboxes"):
            QTimer.singleShot(0, self._refresh_checklist_layout)

    def showEvent(self, event) -> None:
        super().showEvent(event)
        QTimer.singleShot(0, self._refresh_checklist_layout)

    def _select_checklist_item(self, item: QListWidgetItem) -> None:
        checklist = self.ui.exportChecklist
        keep_selection = QApplication.keyboardModifiers() & (
            Qt.KeyboardModifier.ControlModifier
            | Qt.KeyboardModifier.MetaModifier
            | Qt.KeyboardModifier.ShiftModifier
        )
        if not keep_selection:
            checklist.clearSelection()
        item.setSelected(True)
        checklist.setCurrentItem(item)

    def _copy_selected_checklist_items(self) -> None:
        checklist = self.ui.exportChecklist
        selected_items = sorted(
            checklist.selectedItems(),
            key=checklist.row,
        )
        if not selected_items:
            return
        QApplication.clipboard().setText(
            "\n".join(
                str(item.data(self.CHECKLIST_TEXT_ROLE) or "")
                for item in selected_items
            )
        )

    def _update_save_state(self, *_args) -> None:
        all_confirmed = bool(self._checklist_checkboxes) and all(
            checkbox.isChecked()
            for _item, checkbox in self._checklist_checkboxes
        )
        self._save_button.setEnabled(all_confirmed)
