# Warning help images

Place the two warning tutorial images in this directory before packaging:

```text
process_dbu_help.png
layer_mapping_help.png
```

The PyInstaller commands in the repository use `--collect-data easybumpcell`,
so these files are included automatically. A packaged application can also
override them with a `help_images` directory beside the executable.

Tooltip image sizes use Qt device-independent pixels and the active screen's
per-screen DPI scale. Images are smoothly downsampled but never enlarged,
stretched, or cropped. For a full-width 720-logical-pixel Tooltip, use a
source at least 900 px wide at 125% DPI, 1080 px at 150%, or 1440 px at 200%.
