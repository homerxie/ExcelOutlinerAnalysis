"""EasyBumpcell package."""

APPLICATION_NAME = "EasyBumpcell"
__version__ = "1.2"
APPLICATION_TITLE = f"{APPLICATION_NAME} v{__version__}"
