from __future__ import annotations

import math

from easybumpcell.domain.enums import RotationDirection, ZeroDegreeAxis

Point = tuple[float, float]
IntPoint = tuple[int, int]


def actual_rotation_degrees(
    logical_degrees: int,
    zero_axis: ZeroDegreeAxis,
    direction: RotationDirection,
) -> float:
    base = 0.0 if zero_axis is ZeroDegreeAxis.X else 90.0
    sign = 1.0 if direction is RotationDirection.COUNTERCLOCKWISE else -1.0
    return base + sign * logical_degrees


def rotate_points(points: list[Point], degrees: float) -> list[Point]:
    angle = math.radians(degrees)
    cosine = math.cos(angle)
    sine = math.sin(angle)
    return [
        (x * cosine - y * sine, x * sine + y * cosine)
        for x, y in points
    ]


def rotate_integer_points_quarter_turns(
    points: list[IntPoint],
    quarter_turns: int,
) -> list[IntPoint]:
    """Rotate integer coordinates counterclockwise without floating point."""
    turns = quarter_turns % 4
    if turns == 0:
        return list(points)
    if turns == 1:
        return [(-y, x) for x, y in points]
    if turns == 2:
        return [(-x, -y) for x, y in points]
    return [(y, -x) for x, y in points]
