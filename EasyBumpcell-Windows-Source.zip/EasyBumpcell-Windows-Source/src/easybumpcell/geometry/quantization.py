from __future__ import annotations

import math
from dataclasses import dataclass
from decimal import Decimal
from typing import Callable

Point = tuple[float, float]
IntPoint = tuple[int, int]
IntegerTransform = Callable[[IntPoint], IntPoint]


@dataclass(frozen=True)
class BoundingBox:
    min_x: int
    min_y: int
    max_x: int
    max_y: int

    @property
    def width(self) -> int:
        return self.max_x - self.min_x

    @property
    def height(self) -> int:
        return self.max_y - self.min_y


def bounding_box(points: list[IntPoint] | tuple[IntPoint, ...]) -> BoundingBox:
    xs = [point[0] for point in points]
    ys = [point[1] for point in points]
    return BoundingBox(min(xs), min(ys), max(xs), max(ys))


def _inside_convex(point: IntPoint, polygon: list[Point], tolerance: float = 1e-8) -> bool:
    x, y = point
    sign = 0
    for index, start in enumerate(polygon):
        end = polygon[(index + 1) % len(polygon)]
        cross = (end[0] - start[0]) * (y - start[1]) - (end[1] - start[1]) * (x - start[0])
        if abs(cross) <= tolerance:
            continue
        current = 1 if cross > 0 else -1
        if sign == 0:
            sign = current
        elif current != sign:
            return False
    return True


def _nearest_inside_integer(point: Point, polygon: list[Point]) -> IntPoint:
    x, y = point
    floor_x = math.floor(x)
    ceil_x = math.ceil(x)
    floor_y = math.floor(y)
    ceil_y = math.ceil(y)
    candidates: list[tuple[float, int, int]] = []
    for qx in range(floor_x - 1, ceil_x + 2):
        for qy in range(floor_y - 1, ceil_y + 2):
            if _inside_convex((qx, qy), polygon):
                distance = (qx - x) ** 2 + (qy - y) ** 2
                candidates.append((distance, qx, qy))
    if not candidates:
        # Moving toward the center is guaranteed to enter a convex polygon.
        scale = 0.999
        for _ in range(1000):
            qx = round(x * scale)
            qy = round(y * scale)
            if _inside_convex((qx, qy), polygon):
                return qx, qy
            scale *= 0.999
        raise ValueError("Unable to quantize polygon vertex inside the nominal polygon")
    _, qx, qy = min(candidates, key=lambda value: (value[0], -(value[1] ** 2 + value[2] ** 2), value[1], value[2]))
    return qx, qy


def _integer_axis_reflection(axis_degrees: float) -> IntegerTransform:
    rounded_degrees = round(axis_degrees)
    if not math.isclose(axis_degrees, rounded_degrees, abs_tol=1e-9):
        raise ValueError("Symmetry axis must be a multiple of 45 degrees")
    normalized = rounded_degrees % 180
    transforms: dict[int, IntegerTransform] = {
        0: lambda point: (point[0], -point[1]),
        45: lambda point: (point[1], point[0]),
        90: lambda point: (-point[0], point[1]),
        135: lambda point: (-point[1], -point[0]),
    }
    try:
        return transforms[normalized]
    except KeyError as exc:
        raise ValueError(
            "Symmetry axis must be a multiple of 45 degrees"
        ) from exc


def _symmetric_orbit(
    point: IntPoint,
    reflect_across_major_axis: IntegerTransform,
) -> tuple[IntPoint, ...]:
    reflected = reflect_across_major_axis(point)
    candidates = (
        point,
        reflected,
        (-point[0], -point[1]),
        (-reflected[0], -reflected[1]),
    )
    return tuple(dict.fromkeys(candidates))


def _nearest_inside_symmetric_integer(
    point: Point,
    polygon: list[Point],
    reflect_across_major_axis: IntegerTransform,
    required_orbit_size: int,
) -> IntPoint:
    x, y = point
    floor_x = math.floor(x)
    ceil_x = math.ceil(x)
    floor_y = math.floor(y)
    ceil_y = math.ceil(y)
    candidates: list[tuple[float, int, int]] = []
    for qx in range(floor_x - 2, ceil_x + 3):
        for qy in range(floor_y - 2, ceil_y + 3):
            quantized = (qx, qy)
            orbit = _symmetric_orbit(
                quantized,
                reflect_across_major_axis,
            )
            if len(orbit) != required_orbit_size:
                continue
            if all(
                _inside_convex(member, polygon, tolerance=1e-6)
                for member in orbit
            ):
                distance = (qx - x) ** 2 + (qy - y) ** 2
                candidates.append((distance, qx, qy))
    if not candidates:
        raise ValueError(
            "Unable to quantize polygon vertex as a complete symmetry orbit "
            "inside the nominal polygon"
        )
    _, qx, qy = min(
        candidates,
        key=lambda value: (
            value[0],
            -(value[1] ** 2 + value[2] ** 2),
            value[1],
            value[2],
        ),
    )
    return qx, qy


def quantize_centrally_symmetric_polygon(points_um: list[Point], dbu_um: Decimal) -> list[IntPoint]:
    if len(points_um) % 2:
        raise ValueError("A centrally symmetric polygon must have an even vertex count")
    dbu = float(dbu_um)
    if not math.isfinite(dbu) or dbu <= 0:
        raise ValueError("DBU must be positive")
    scaled = [(x / dbu, y / dbu) for x, y in points_um]
    half = len(scaled) // 2
    result: list[IntPoint | None] = [None] * len(scaled)
    for index in range(half):
        opposite = scaled[index + half]
        point = scaled[index]
        if abs(point[0] + opposite[0]) > 1e-6 or abs(point[1] + opposite[1]) > 1e-6:
            raise ValueError("Polygon is not centrally symmetric")
        quantized = _nearest_inside_integer(point, scaled)
        result[index] = quantized
        result[index + half] = (-quantized[0], -quantized[1])
    return [point for point in result if point is not None]


def quantize_biaxially_symmetric_polygon(
    points_um: list[Point],
    dbu_um: Decimal,
    major_axis_degrees: float,
) -> list[IntPoint]:
    """Quantize a 4k+2 polygon as exact integer symmetry orbits.

    The input order must start at the positive major-axis endpoint and proceed
    counterclockwise.  Index 0 and its opposite form the two-point endpoint
    orbit.  Every other vertex is assigned together with its major-axis
    reflection, central opposite, and minor-axis reflection.
    """
    if len(points_um) % 4 != 2:
        raise ValueError(
            "A biaxially symmetric endpoint polygon must have 4k+2 vertices"
        )
    dbu = float(dbu_um)
    if not math.isfinite(dbu) or dbu <= 0:
        raise ValueError("DBU must be positive")

    scaled = [(x / dbu, y / dbu) for x, y in points_um]
    count = len(scaled)
    half = count // 2
    quarter = (count - 2) // 4
    reflect = _integer_axis_reflection(major_axis_degrees)
    result: list[IntPoint | None] = [None] * count

    def close(first: Point, second: Point) -> bool:
        return (
            math.isclose(first[0], second[0], rel_tol=1e-12, abs_tol=1e-6)
            and math.isclose(
                first[1],
                second[1],
                rel_tol=1e-12,
                abs_tol=1e-6,
            )
        )

    reflected_endpoint = reflect(scaled[0])  # type: ignore[arg-type]
    if not (
        close(scaled[0], reflected_endpoint)
        and close(
            scaled[half],
            (-scaled[0][0], -scaled[0][1]),
        )
    ):
        raise ValueError("Polygon endpoints are not biaxially symmetric")

    positive_endpoint = _nearest_inside_symmetric_integer(
        scaled[0],
        scaled,
        reflect,
        required_orbit_size=2,
    )
    result[0] = positive_endpoint
    result[half] = (-positive_endpoint[0], -positive_endpoint[1])

    for index in range(1, quarter + 1):
        ideal = scaled[index]
        reflected_ideal = reflect(ideal)  # type: ignore[arg-type]
        if not (
            close(scaled[-index], reflected_ideal)
            and close(
                scaled[index + half],
                (-ideal[0], -ideal[1]),
            )
            and close(
                scaled[half - index],
                (-reflected_ideal[0], -reflected_ideal[1]),
            )
        ):
            raise ValueError("Polygon is not biaxially symmetric")
        quantized = _nearest_inside_symmetric_integer(
            scaled[index],
            scaled,
            reflect,
            required_orbit_size=4,
        )
        reflected = reflect(quantized)
        result[index] = quantized
        result[-index] = reflected
        result[index + half] = (-quantized[0], -quantized[1])
        result[half - index] = (-reflected[0], -reflected[1])

    if any(point is None for point in result):
        raise ValueError("Symmetry orbit quantization left unassigned vertices")
    return [point for point in result if point is not None]


def translate(points: list[IntPoint], dx: int, dy: int) -> list[IntPoint]:
    return [(x + dx, y + dy) for x, y in points]


def half_grid_risk(dimension_um, dbu_um: Decimal) -> bool:
    half_steps = Decimal(str(dimension_um)) / (Decimal(2) * dbu_um)
    return half_steps != half_steps.to_integral_value()
