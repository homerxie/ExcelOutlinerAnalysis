from __future__ import annotations

from copy import deepcopy
from decimal import Decimal, InvalidOperation

from easybumpcell.domain.enums import ShapeType
from easybumpcell.domain.models import LayerDefinition, ProjectConfig


SHAPE_ORDER = (ShapeType.ROUND, ShapeType.OVAL)


def available_shape_types(
    config: ProjectConfig,
) -> tuple[ShapeType, ...]:
    return available_shape_types_for_layers(config.layers)


def available_shape_types_for_layers(
    layers: list[LayerDefinition] | tuple[LayerDefinition, ...],
) -> tuple[ShapeType, ...]:
    if not layers:
        return ()
    available: list[ShapeType] = []
    if all(_positive_dimension(layer.diameter_um) for layer in layers):
        available.append(ShapeType.ROUND)
    if all(_valid_oval_dimensions(layer) for layer in layers):
        available.append(ShapeType.OVAL)
    return tuple(available)


def project_for_shape(
    config: ProjectConfig,
    shape_type: ShapeType,
) -> ProjectConfig:
    shape_type = ShapeType(shape_type)
    if shape_type not in available_shape_types(config):
        raise ValueError(
            f"Complete {shape_type.value} dimensions are not available."
        )
    shaped = deepcopy(config)
    shaped.shape_type = shape_type
    return shaped


def _positive_dimension(value) -> bool:
    try:
        decimal_value = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return False
    return decimal_value.is_finite() and decimal_value > 0


def _valid_oval_dimensions(layer: LayerDefinition) -> bool:
    if not _positive_dimension(layer.minor_axis_um):
        return False
    if not _positive_dimension(layer.major_axis_um):
        return False
    return Decimal(str(layer.major_axis_um)) > Decimal(
        str(layer.minor_axis_um)
    )
