from __future__ import annotations

import math
from dataclasses import dataclass
from decimal import Decimal
from html import escape
from pathlib import Path

from reportlab.graphics.shapes import Circle, Drawing, Line, Polygon, Rect, String
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.platypus import (
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from easybumpcell.coordinate_format import (
    format_coordinate_um,
    format_dimension_um,
)
from easybumpcell.domain.enums import IssueLevel, ShapeType
from easybumpcell.domain.models import LayerDefinition, ProjectConfig, ValidationIssue
from easybumpcell.geometry.layout import GeneratedLayout
from easybumpcell.preview_patterns import (
    BACKWARD_DIAGONAL,
    DENSE_DOTS,
    DIAGONAL_CROSS,
    DOTS,
    FORWARD_DIAGONAL,
    GRID,
    HORIZONTAL,
    VERTICAL,
)
from easybumpcell.services.lef_export import (
    LEFPreviewElements,
    lef_preview_elements,
)
from easybumpcell.services.naming import lef_file_name
from easybumpcell.services.posix_cksum import PosixChecksum


REPORT_TITLE = "Sample GDS report"
_UNDERSCORE_BREAK = '_<font size="0"> </font>'
_TABLE_HEADER_FONT_SIZE = 9
_TABLE_BODY_FONT_SIZE = 10
_PREVIEW_LEGEND_FONT_SIZE = 6.5
_PREVIEW_SHARED_LEGEND_HEIGHT = 9 * mm


@dataclass(frozen=True)
class ShapeReportData:
    config: ProjectConfig
    layouts: tuple[GeneratedLayout, ...]
    checksums: tuple[PosixChecksum, ...]
    issues: tuple[ValidationIssue, ...]
    lef_definitions: tuple[str, ...] = ()


def _underscore_break_markup(value: str) -> str:
    return escape(value).replace("_", _UNDERSCORE_BREAK)


def _underscore_wrapped_paragraph(
    value: str,
    style,
) -> Paragraph:
    return Paragraph(_underscore_break_markup(value), style)


def _table_text_style(font_size: int) -> ParagraphStyle:
    return ParagraphStyle(
        f"UnderscoreWrappedTableText{font_size}",
        fontName="Helvetica",
        fontSize=font_size,
        leading=font_size + 2,
        splitLongWords=True,
        spaceBefore=0,
        spaceAfter=0,
    )


def _split_text_to_width(
    value: str,
    max_width: float,
    font_name: str,
    font_size: float,
) -> list[str]:
    if not value:
        return [""]
    lines: list[str] = []
    remaining = value
    while remaining:
        fit = 0
        for index in range(1, len(remaining) + 1):
            if stringWidth(remaining[:index], font_name, font_size) > max_width:
                break
            fit = index
        if fit == 0:
            fit = 1
        lines.append(remaining[:fit])
        remaining = remaining[fit:]
    return lines


def _wrap_text_at_underscores(
    value: str,
    max_width: float,
    font_name: str,
    font_size: float,
) -> list[str]:
    parts = value.split("_")
    segments = [
        part + ("_" if index < len(parts) - 1 else "")
        for index, part in enumerate(parts)
    ]
    lines: list[str] = []
    current = ""
    for segment in segments:
        candidate = current + segment
        if stringWidth(candidate, font_name, font_size) <= max_width:
            current = candidate
            continue
        if current:
            lines.append(current)
        if stringWidth(segment, font_name, font_size) <= max_width:
            current = segment
            continue
        segment_lines = _split_text_to_width(
            segment,
            max_width,
            font_name,
            font_size,
        )
        lines.extend(segment_lines[:-1])
        current = segment_lines[-1]
    if current or not lines:
        lines.append(current)
    return lines


def _nice_tick_spacing(desired_um: float) -> float:
    if not math.isfinite(desired_um) or desired_um <= 0:
        return 1.0
    exponent = math.floor(math.log10(desired_um))
    magnitude = 10.0 ** exponent
    fraction = desired_um / magnitude
    if fraction <= 1:
        nice_fraction = 1.0
    elif fraction <= 2:
        nice_fraction = 2.0
    elif fraction <= 5:
        nice_fraction = 5.0
    else:
        nice_fraction = 10.0
    return nice_fraction * magnitude


def _tick_values(minimum: float, maximum: float, spacing: float) -> list[float]:
    first = math.ceil((minimum - spacing * 1e-9) / spacing) * spacing
    values = []
    value = first
    while value <= maximum + spacing * 1e-9 and len(values) < 100:
        values.append(0.0 if abs(value) < spacing * 1e-9 else value)
        value += spacing
    return values


def _format_axis_tick(value: float, spacing: float) -> str:
    if abs(value) < spacing * 1e-9:
        return "0"
    decimals = max(0, min(6, -math.floor(math.log10(spacing))))
    text = f"{value:.{decimals}f}"
    return text.rstrip("0").rstrip(".") if decimals else text


def _section(
    title: str,
    content,
    styles,
    *,
    keep_together: bool = False,
) -> list:
    section = [
        Paragraph(title, styles["Section"]),
        (
            content
            if not isinstance(content, str)
            else _underscore_wrapped_paragraph(
                content or "N/A",
                styles["BodyText"],
            )
        ),
        Spacer(1, 3 * mm),
    ]
    return (
        [KeepTogether(section)]
        if isinstance(content, str) or keep_together
        else section
    )


def _identity_grid(
    items: list[tuple[str, str]],
    styles,
    width: float,
) -> Table:
    if len(items) != 4:
        raise ValueError("The report identity grid requires exactly four items")
    label_style = ParagraphStyle(
        "IdentityLabel",
        parent=styles["Section"],
        fontSize=_TABLE_HEADER_FONT_SIZE,
        leading=_TABLE_HEADER_FONT_SIZE + 2,
        spaceBefore=0,
        spaceAfter=1 * mm,
        keepWithNext=True,
    )
    value_style = ParagraphStyle(
        "IdentityValue",
        parent=styles["BodyText"],
        fontSize=_TABLE_BODY_FONT_SIZE,
        leading=_TABLE_BODY_FONT_SIZE + 2,
        spaceBefore=0,
        spaceAfter=0,
    )
    cells = [
        [
            Paragraph(title, label_style),
            _underscore_wrapped_paragraph(value or "N/A", value_style),
        ]
        for title, value in items
    ]
    table = Table(
        [cells[:2], cells[2:]],
        colWidths=[width / 2, width / 2],
        hAlign="LEFT",
    )
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F2F5F7")),
                ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#AAB4BE")),
                ("INNERGRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#C6CED5")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    return table


def _styled_table(data: list[list[object]], widths=None) -> Table:
    header_style = ParagraphStyle(
        "PDFTableHeader",
        fontName="Helvetica-Bold",
        fontSize=_TABLE_HEADER_FONT_SIZE,
        leading=_TABLE_HEADER_FONT_SIZE + 2,
        textColor=colors.white,
        splitLongWords=True,
        spaceBefore=0,
        spaceAfter=0,
    )
    body_style = _table_text_style(_TABLE_BODY_FONT_SIZE)
    wrapped_data = [
        [
            (
                _underscore_wrapped_paragraph(
                    cell,
                    header_style if row_index == 0 else body_style,
                )
                if isinstance(cell, str)
                else cell
            )
            for cell in row
        ]
        for row_index, row in enumerate(data)
    ]
    table = Table(wrapped_data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#243447")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#AAB4BE")),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F2F5F7")]),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]
        )
    )
    return table


def _clipped_parallel_segments(
    polygon: list[tuple[float, float]],
    direction: tuple[float, float],
    spacing: float,
    phase: float = 0,
) -> list[tuple[tuple[float, float], tuple[float, float]]]:
    direction_length = math.hypot(*direction)
    unit_direction = (
        direction[0] / direction_length,
        direction[1] / direction_length,
    )
    normal = (-unit_direction[1], unit_direction[0])
    normal_positions = [
        point[0] * normal[0] + point[1] * normal[1]
        for point in polygon
    ]
    first_offset = (
        math.floor((min(normal_positions) - phase) / spacing) * spacing
        + phase
    )
    last_offset = (
        math.ceil((max(normal_positions) - phase) / spacing) * spacing
        + phase
    )
    segments = []
    offset = first_offset
    while offset <= last_offset + 1e-8:
        intersections: list[tuple[float, float]] = []
        for index, start in enumerate(polygon):
            end = polygon[(index + 1) % len(polygon)]
            start_distance = start[0] * normal[0] + start[1] * normal[1] - offset
            end_distance = end[0] * normal[0] + end[1] * normal[1] - offset
            if abs(start_distance) <= 1e-8:
                intersections.append(start)
            denominator = start_distance - end_distance
            if abs(denominator) > 1e-8:
                edge_fraction = start_distance / denominator
                if 1e-8 < edge_fraction < 1 - 1e-8:
                    intersections.append(
                        (
                            start[0] + edge_fraction * (end[0] - start[0]),
                            start[1] + edge_fraction * (end[1] - start[1]),
                        )
                    )
        unique: list[tuple[float, float]] = []
        for point in intersections:
            if not any(
                abs(point[0] - existing[0]) <= 1e-6
                and abs(point[1] - existing[1]) <= 1e-6
                for existing in unique
            ):
                unique.append(point)
        if len(unique) >= 2:
            ordered = sorted(
                unique,
                key=lambda point: (
                    point[0] * unit_direction[0]
                    + point[1] * unit_direction[1]
                ),
            )
            segments.append((ordered[0], ordered[-1]))
        offset += spacing
    return segments


def _point_inside_convex_polygon(
    point: tuple[float, float],
    polygon: list[tuple[float, float]],
) -> bool:
    sign = 0
    for index, start in enumerate(polygon):
        end = polygon[(index + 1) % len(polygon)]
        cross = (
            (end[0] - start[0]) * (point[1] - start[1])
            - (end[1] - start[1]) * (point[0] - start[0])
        )
        if abs(cross) <= 1e-8:
            continue
        current = 1 if cross > 0 else -1
        if sign == 0:
            sign = current
        elif current != sign:
            return False
    return True


def _add_vector_pattern(
    drawing: Drawing,
    polygon: list[tuple[float, float]],
    pattern: str,
    color,
    *,
    spacing: float = 6.0,
    stroke_width: float = 0.55,
) -> None:
    pattern_color = colors.Color(
        color.red,
        color.green,
        color.blue,
        alpha=0.82,
    )
    directions = {
        FORWARD_DIAGONAL: ((1.0, 1.0),),
        BACKWARD_DIAGONAL: ((1.0, -1.0),),
        DIAGONAL_CROSS: ((1.0, 1.0), (1.0, -1.0)),
        HORIZONTAL: ((1.0, 0.0),),
        VERTICAL: ((0.0, 1.0),),
        GRID: ((1.0, 0.0), (0.0, 1.0)),
    }
    if pattern in directions:
        effective_spacing = spacing * (
            1.35 if pattern in (DIAGONAL_CROSS, GRID) else 1.0
        )
        phase = (
            effective_spacing * 0.27
            if pattern in (DIAGONAL_CROSS, GRID)
            else 0
        )
        for direction in directions[pattern]:
            for start, end in _clipped_parallel_segments(
                polygon,
                direction,
                effective_spacing,
                phase,
            ):
                drawing.add(
                    Line(
                        start[0],
                        start[1],
                        end[0],
                        end[1],
                        strokeColor=pattern_color,
                        strokeWidth=stroke_width,
                    )
                )
        return

    if pattern not in (DOTS, DENSE_DOTS):
        raise ValueError(f"Unsupported preview pattern: {pattern}")
    dot_spacing = spacing * (1.18 if pattern == DOTS else 0.72)
    dot_radius = 0.75 if pattern == DOTS else 0.6
    min_x = min(point[0] for point in polygon)
    max_x = max(point[0] for point in polygon)
    min_y = min(point[1] for point in polygon)
    max_y = max(point[1] for point in polygon)
    x = math.floor(min_x / dot_spacing) * dot_spacing
    column = 0
    while x <= max_x + 1e-8:
        y_offset = dot_spacing / 2 if column % 2 else 0
        y = math.floor((min_y - y_offset) / dot_spacing) * dot_spacing + y_offset
        while y <= max_y + 1e-8:
            if _point_inside_convex_polygon((x, y), polygon):
                drawing.add(
                    Circle(
                        x,
                        y,
                        dot_radius,
                        fillColor=pattern_color,
                        strokeColor=None,
                    )
                )
            y += dot_spacing
        x += dot_spacing
        column += 1


def _compact_dimension(value: Decimal | int | float) -> str:
    return format(Decimal(str(value)).normalize(), "f")


def _matching_report_layer(
    reference: LayerDefinition,
    config: ProjectConfig,
) -> LayerDefinition | None:
    for layer in config.layers:
        if layer.uid == reference.uid:
            return layer
    reference_key = (
        reference.meaning,
        reference.layer,
        reference.datatype,
    )
    return next(
        (
            layer
            for layer in config.layers
            if (layer.meaning, layer.layer, layer.datatype) == reference_key
        ),
        None,
    )


def _mapping_dimension_text(
    reference: LayerDefinition,
    reports: list[ShapeReportData],
) -> str:
    dimensions: list[str] = []
    for report in reports:
        shape_type = report.config.shape_type
        layer = _matching_report_layer(reference, report.config)
        if layer is None:
            continue
        if shape_type is ShapeType.ROUND and layer.diameter_um is not None:
            dimensions.append(
                f"Round: {_compact_dimension(layer.diameter_um)} µm dia."
            )
        elif (
            shape_type is ShapeType.OVAL
            and layer.minor_axis_um is not None
            and layer.major_axis_um is not None
        ):
            dimensions.append(
                "Oval: "
                f"{_compact_dimension(layer.minor_axis_um)} x "
                f"{_compact_dimension(layer.major_axis_um)} µm"
            )
    return "; ".join(dimensions) or "N/A"


def _layer_mapping_table(
    config: ProjectConfig,
    reports: list[ShapeReportData] | None = None,
) -> Table:
    shape_reports = reports or [
        ShapeReportData(config, (), (), ())
    ]
    shape_types = {
        report.config.shape_type for report in shape_reports
    }
    if shape_types == {ShapeType.ROUND}:
        dimension_header = "Round Size (µm)"
    elif shape_types == {ShapeType.OVAL}:
        dimension_header = "Oval Size (µm)"
    else:
        dimension_header = "Round / Oval Size (µm)"
    rows = [[
        "Tapeout?",
        "Layer Name",
        "Layer Number",
        "Datatype",
        dimension_header,
    ]]
    rows.extend(
        [
            [
                "Yes" if layer.tapeout else "No",
                layer.meaning,
                str(layer.layer),
                str(layer.datatype),
                _mapping_dimension_text(layer, shape_reports),
            ]
            for layer in config.layers
        ]
    )
    return _styled_table(
        rows,
        [20 * mm, 43 * mm, 28 * mm, 28 * mm, 90 * mm],
    )


def _all_bounds(layouts: list[GeneratedLayout]) -> tuple[int, int, int, int]:
    boxes = [layer.bbox_dbu for layout in layouts for layer in layout.layers]
    min_x = min(min(box.min_x for box in boxes), 0)
    min_y = min(min(box.min_y for box in boxes), 0)
    max_x = max(max(box.max_x for box in boxes), 0)
    max_y = max(max(box.max_y for box in boxes), 0)
    if max_x == min_x:
        max_x += 1
    if max_y == min_y:
        max_y += 1
    return min_x, min_y, max_x, max_y


def _lef_all_bounds(
    elements: list[LEFPreviewElements],
) -> tuple[int, int, int, int]:
    boxes = [
        box
        for item in elements
        for box in (item.pin_geometry.bbox_dbu, item.boundary_dbu)
    ]
    min_x = min(min(box.min_x for box in boxes), 0)
    min_y = min(min(box.min_y for box in boxes), 0)
    max_x = max(max(box.max_x for box in boxes), 0)
    max_y = max(max(box.max_y for box in boxes), 0)
    width = max_x - min_x
    height = max_y - min_y
    pad_x = max(1, math.ceil(width * 0.14))
    pad_y = max(1, math.ceil(height * 0.14))
    return (
        min_x - pad_x,
        min_y - pad_y,
        max_x + pad_x,
        max_y + pad_y,
    )


def _add_gds_legend(
    drawing: Drawing,
    layers: list[LayerDefinition],
    center_x: float,
    legend_y: float,
) -> None:
    legend_widths = [
        stringWidth(
            layer.meaning,
            "Helvetica-Bold",
            _PREVIEW_LEGEND_FONT_SIZE,
        )
        + 12 * mm
        for layer in layers
    ]
    legend_x = center_x - sum(legend_widths) / 2
    for layer, item_width in zip(layers, legend_widths):
        icon_x = legend_x + 1.2 * mm
        icon_y = legend_y - 0.8 * mm
        icon_width = 5 * mm
        icon_height = 2.8 * mm
        color = colors.HexColor(layer.color)
        polygon = [
            (icon_x, icon_y),
            (icon_x + icon_width, icon_y),
            (icon_x + icon_width, icon_y + icon_height),
            (icon_x, icon_y + icon_height),
        ]
        drawing.add(
            Rect(
                icon_x,
                icon_y,
                icon_width,
                icon_height,
                fillColor=colors.Color(
                    color.red,
                    color.green,
                    color.blue,
                    alpha=0.08,
                ),
                strokeColor=None,
            )
        )
        _add_vector_pattern(
            drawing,
            polygon,
            layer.preview_pattern,
            color,
            spacing=3.2,
            stroke_width=0.5,
        )
        drawing.add(
            Rect(
                icon_x,
                icon_y,
                icon_width,
                icon_height,
                fillColor=None,
                strokeColor=color,
                strokeWidth=0.7,
            )
        )
        drawing.add(
            String(
                icon_x + 6.2 * mm,
                legend_y - 0.7 * mm,
                layer.meaning,
                fontName="Helvetica-Bold",
                fontSize=_PREVIEW_LEGEND_FONT_SIZE,
                fillColor=colors.HexColor("#34434F"),
            )
        )
        legend_x += item_width


def _add_lef_legend(
    drawing: Drawing,
    elements: LEFPreviewElements,
    center_x: float,
    legend_y: float,
) -> None:
    legend_items = (
        (elements.pin_layer_name, "pin"),
        (elements.label_layer_name, "label"),
        (elements.boundary_layer_name, "boundary"),
    )
    legend_widths = [
        stringWidth(
            name,
            "Helvetica-Bold",
            _PREVIEW_LEGEND_FONT_SIZE,
        )
        + 10 * mm
        for name, _ in legend_items
    ]
    legend_x = center_x - sum(legend_widths) / 2
    for (name, kind), item_width in zip(legend_items, legend_widths):
        icon_x = legend_x + 1.2 * mm
        icon_y = legend_y + 0.5 * mm
        if kind == "pin":
            drawing.add(
                Line(
                    icon_x,
                    icon_y,
                    icon_x + 4 * mm,
                    icon_y,
                    strokeColor=colors.HexColor(elements.definition.color),
                    strokeWidth=1.1,
                )
            )
        elif kind == "label":
            drawing.add(
                Circle(
                    icon_x + 2 * mm,
                    icon_y,
                    1.1 * mm,
                    fillColor=colors.white,
                    strokeColor=colors.HexColor("#7B1FA2"),
                    strokeWidth=0.8,
                )
            )
        else:
            drawing.add(
                Line(
                    icon_x,
                    icon_y,
                    icon_x + 4 * mm,
                    icon_y,
                    strokeColor=colors.HexColor("#455A64"),
                    strokeWidth=0.8,
                    strokeDashArray=[2, 1.5],
                )
            )
        drawing.add(
            String(
                icon_x + 5.4 * mm,
                legend_y - 0.7 * mm,
                name,
                fontName="Helvetica-Bold",
                fontSize=_PREVIEW_LEGEND_FONT_SIZE,
                fillColor=colors.HexColor("#34434F"),
            )
        )
        legend_x += item_width


def _preview_drawing(
    layouts: list[GeneratedLayout],
    config: ProjectConfig,
    *,
    lef_mode: bool = False,
    panel_configs: list[ProjectConfig] | None = None,
    panel_positions: list[tuple[int, int]] | None = None,
    columns: int | None = None,
    rows: int | None = None,
    show_cell_names: bool = True,
    show_centers: bool = True,
    shared_gds_legend: bool = False,
    shared_lef_legend: bool = False,
    lef_definitions: list[str | None] | None = None,
) -> Drawing:
    if not layouts:
        raise ValueError("A PDF preview requires at least one layout")
    configs = panel_configs or [config] * len(layouts)
    if len(configs) != len(layouts):
        raise ValueError("Each PDF preview layout requires one configuration")
    definitions = lef_definitions or [None] * len(layouts)
    if len(definitions) != len(layouts):
        raise ValueError("Each PDF LEF preview layout requires one LEF definition")
    if len({item.dbu_um for item in configs}) != 1:
        raise ValueError("Combined PDF previews require a common Process DBU")
    if columns is None or rows is None:
        if len(layouts) == 1:
            columns, rows = 1, 1
        else:
            columns, rows = 2, 2
    if columns * rows < len(layouts):
        raise ValueError("The PDF preview grid is too small for its layouts")
    positions = panel_positions or [
        (index % columns, index // columns)
        for index in range(len(layouts))
    ]
    if len(positions) != len(layouts):
        raise ValueError("Each PDF preview layout requires one grid position")
    if len(set(positions)) != len(positions):
        raise ValueError("PDF preview grid positions must be unique")
    if any(
        column < 0
        or column >= columns
        or row_from_top < 0
        or row_from_top >= rows
        for column, row_from_top in positions
    ):
        raise ValueError("A PDF preview grid position is outside the grid")
    width = 245 * mm
    height = (135 if len(layouts) == 1 else 155) * mm
    drawing = Drawing(width, height)
    gap = 5 * mm
    shared_legend_h = (
        _PREVIEW_SHARED_LEGEND_HEIGHT
        if shared_gds_legend or (lef_mode and shared_lef_legend)
        else 0
    )
    grid_height = height - shared_legend_h
    panel_w = (width - gap * (columns - 1)) / columns
    panel_h = (grid_height - gap * (rows - 1)) / rows
    cell_name_font = "Helvetica"
    cell_name_font_size = 5.5
    cell_name_max_width = panel_w - 8 * mm
    wrapped_cell_names = (
        [
            _wrap_text_at_underscores(
                layout.cell_name,
                cell_name_max_width,
                cell_name_font,
                cell_name_font_size,
            )
            for layout in layouts
        ]
        if show_cell_names
        else [[] for _ in layouts]
    )
    maximum_cell_name_lines = (
        max(map(len, wrapped_cell_names)) if show_cell_names else 0
    )
    cell_name_line_step = 2.4 * mm
    lef_elements = (
        [
            lef_preview_elements(
                panel_config,
                layout,
                lef_definition=lef_definition,
            )
            for panel_config, layout, lef_definition in zip(
                configs,
                layouts,
                definitions,
            )
        ]
        if lef_mode
        else []
    )
    gds_legend_layers: list[LayerDefinition] = []
    if shared_gds_legend:
        seen_layers: set[tuple[str, int | None, int | None, str, str]] = set()
        for layout in layouts:
            for layer in layout.layers:
                definition = layer.definition
                legend_key = (
                    definition.meaning,
                    definition.layer,
                    definition.datatype,
                    definition.color,
                    definition.preview_pattern,
                )
                if legend_key in seen_layers:
                    continue
                seen_layers.add(legend_key)
                gds_legend_layers.append(definition)
    min_x, min_y, max_x, max_y = (
        _lef_all_bounds(lef_elements)
        if lef_mode
        else _all_bounds(layouts)
    )
    world_w = max_x - min_x
    world_h = max_y - min_y
    compact_titles = not show_cell_names
    title_h = (
        (8 if lef_mode else 7) * mm
        if compact_titles
        else (
            (17 if lef_mode else 14) * mm
            + (maximum_cell_name_lines - 1) * cell_name_line_step
        )
    )
    left_margin = 15 * mm
    right_margin = 6 * mm
    bottom_margin = 9 * mm
    plot_w = panel_w - left_margin - right_margin
    plot_h = panel_h - title_h - bottom_margin
    scale = min(plot_w / world_w, plot_h / world_h)
    if shared_gds_legend:
        _add_gds_legend(
            drawing,
            gds_legend_layers,
            width / 2,
            height - 4.8 * mm,
        )
    if shared_lef_legend:
        _add_lef_legend(
            drawing,
            lef_elements[0],
            width / 2,
            height - 4.8 * mm,
        )
    for index, layout in enumerate(layouts):
        panel_config = configs[index]
        elements = lef_elements[index] if lef_mode else None
        column, row_from_top = positions[index]
        row = rows - 1 - row_from_top
        left = column * (panel_w + gap)
        bottom = row * (panel_h + gap)
        plot_left = left + left_margin
        plot_bottom = bottom + bottom_margin
        plot_right = plot_left + plot_w
        plot_top = plot_bottom + plot_h
        offset_x = plot_left + (plot_w - world_w * scale) / 2 - min_x * scale
        offset_y = plot_bottom + (plot_h - world_h * scale) / 2 - min_y * scale

        drawing.add(
            Polygon(
                [left, bottom, left + panel_w, bottom, left + panel_w, bottom + panel_h, left, bottom + panel_h],
                fillColor=colors.HexColor("#FAFBFC"),
                strokeColor=colors.HexColor("#CAD2D9"),
                strokeWidth=0.6,
            )
        )
        shape_title = (
            "Round"
            if panel_config.shape_type is ShapeType.ROUND
            else f"Oval {layout.logical_angle} Degree"
        )
        title = f"LEF - {shape_title}" if lef_mode else shape_title
        drawing.add(
            String(
                left + panel_w / 2,
                bottom + panel_h - 3.7 * mm,
                title,
                textAnchor="middle",
                fontName="Helvetica-Bold",
                fontSize=10,
                fillColor=colors.HexColor("#1F2D3D"),
            )
        )
        if show_cell_names:
            for line_index, line in enumerate(wrapped_cell_names[index]):
                drawing.add(
                    String(
                        left + panel_w / 2,
                        bottom
                        + panel_h
                        - 7.5 * mm
                        - line_index * cell_name_line_step,
                        line,
                        textAnchor="middle",
                        fontName=cell_name_font,
                        fontSize=cell_name_font_size,
                        fillColor=colors.HexColor("#536270"),
                    )
                )
        if elements is None and show_centers:
            summary_x_dbu, summary_y_dbu = layout.common_center_dbu
            summary_x_um = Decimal(summary_x_dbu) * panel_config.dbu_um
            summary_y_um = Decimal(summary_y_dbu) * panel_config.dbu_um
            drawing.add(
                String(
                    left + panel_w / 2,
                    bottom
                    + panel_h
                    - 11 * mm
                    - (maximum_cell_name_lines - 1) * cell_name_line_step,
                    (
                        "Center: "
                        f"X {format_coordinate_um(summary_x_um, panel_config.dbu_um)} µm, "
                        f"Y {format_coordinate_um(summary_y_um, panel_config.dbu_um)} µm"
                    ),
                    textAnchor="middle",
                    fontName="Helvetica",
                    fontSize=5.5,
                    fillColor=colors.HexColor("#536270"),
                )
            )
        if elements is not None and not shared_lef_legend:
            legend_y = (
                bottom
                + panel_h
                - 12.3 * mm
                - (maximum_cell_name_lines - 1) * cell_name_line_step
            )
            _add_lef_legend(
                drawing,
                elements,
                left + panel_w / 2,
                legend_y,
            )

        layers_to_draw = (
            [elements.pin_geometry]
            if elements is not None
            else list(layout.layers)
        )
        for layer in sorted(
            layers_to_draw,
            key=lambda item: item.bbox_dbu.width * item.bbox_dbu.height,
            reverse=True,
        ):
            coordinates: list[float] = []
            for x, y in layer.points_dbu:
                coordinates.extend((offset_x + x * scale, offset_y + y * scale))
            color = colors.HexColor(layer.definition.color)
            polygon_points = [
                (coordinates[index], coordinates[index + 1])
                for index in range(0, len(coordinates), 2)
            ]
            drawing.add(
                Polygon(
                    coordinates,
                    fillColor=colors.Color(color.red, color.green, color.blue, alpha=0.06),
                    strokeColor=None,
                )
            )
            _add_vector_pattern(
                drawing,
                polygon_points,
                layer.definition.preview_pattern,
                color,
            )
            drawing.add(
                Polygon(
                    coordinates,
                    fillColor=None,
                    strokeColor=color,
                    strokeWidth=0.65,
                )
            )
        if elements is not None:
            boundary = elements.boundary_dbu
            drawing.add(
                Rect(
                    offset_x + boundary.min_x * scale,
                    offset_y + boundary.min_y * scale,
                    boundary.width * scale,
                    boundary.height * scale,
                    fillColor=None,
                    strokeColor=colors.HexColor("#455A64"),
                    strokeWidth=0.85,
                    strokeDashArray=[3, 2],
                )
            )

        origin_x = offset_x
        origin_y = offset_y
        axis_color = colors.HexColor("#7C8993")
        label_color = colors.HexColor("#52636F")
        drawing.add(
            Line(
                plot_left,
                origin_y,
                plot_right,
                origin_y,
                strokeColor=axis_color,
                strokeWidth=0.45,
            )
        )
        drawing.add(
            Line(
                origin_x,
                plot_bottom,
                origin_x,
                plot_top,
                strokeColor=axis_color,
                strokeWidth=0.45,
            )
        )

        dbu_um = float(panel_config.dbu_um)
        points_per_um = scale / dbu_um
        tick_spacing_um = _nice_tick_spacing(32.0 / points_per_um)
        min_x_um = min_x * dbu_um
        max_x_um = max_x * dbu_um
        min_y_um = min_y * dbu_um
        max_y_um = max_y * dbu_um
        for value_um in _tick_values(min_x_um, max_x_um, tick_spacing_um):
            tick_x = offset_x + value_um / dbu_um * scale
            drawing.add(
                Line(
                    tick_x,
                    origin_y - 1.1 * mm,
                    tick_x,
                    origin_y + 1.1 * mm,
                    strokeColor=axis_color,
                    strokeWidth=0.45,
                )
            )
            drawing.add(
                String(
                    tick_x,
                    origin_y - 3.2 * mm,
                    _format_axis_tick(value_um, tick_spacing_um),
                    textAnchor="middle",
                    fontName="Helvetica",
                    fontSize=4.5,
                    fillColor=label_color,
                )
            )
        for value_um in _tick_values(min_y_um, max_y_um, tick_spacing_um):
            tick_y = offset_y + value_um / dbu_um * scale
            drawing.add(
                Line(
                    origin_x - 1.1 * mm,
                    tick_y,
                    origin_x + 1.1 * mm,
                    tick_y,
                    strokeColor=axis_color,
                    strokeWidth=0.45,
                )
            )
            if abs(value_um) < tick_spacing_um * 1e-9:
                continue
            drawing.add(
                String(
                    origin_x - 1.8 * mm,
                    tick_y - 1.3,
                    _format_axis_tick(value_um, tick_spacing_um),
                    textAnchor="end",
                    fontName="Helvetica",
                    fontSize=4.5,
                    fillColor=label_color,
                )
            )
        drawing.add(
            String(
                plot_right,
                origin_y + 1.8 * mm,
                "X (µm)",
                textAnchor="end",
                fontName="Helvetica-Bold",
                fontSize=4.8,
                fillColor=label_color,
            )
        )
        drawing.add(
            String(
                origin_x + 1.8 * mm,
                plot_top - 2.4 * mm,
                "Y (µm)",
                fontName="Helvetica-Bold",
                fontSize=4.8,
                fillColor=label_color,
            )
        )
        drawing.add(Line(origin_x - 2.5, origin_y, origin_x + 2.5, origin_y, strokeColor=colors.black, strokeWidth=0.8))
        drawing.add(Line(origin_x, origin_y - 2.5, origin_x, origin_y + 2.5, strokeColor=colors.black, strokeWidth=0.8))
        if elements is not None:
            anchor_x = offset_x + elements.label_anchor_dbu[0] * scale
            anchor_y = offset_y + elements.label_anchor_dbu[1] * scale
            anchor_color = colors.HexColor("#7B1FA2")
            drawing.add(
                Circle(
                    anchor_x,
                    anchor_y,
                    0.8 * mm,
                    fillColor=colors.white,
                    strokeColor=anchor_color,
                    strokeWidth=0.9,
                )
            )
            drawing.add(
                Line(
                    anchor_x - 1.9 * mm,
                    anchor_y,
                    anchor_x + 1.9 * mm,
                    anchor_y,
                    strokeColor=anchor_color,
                    strokeWidth=0.7,
                )
            )
            drawing.add(
                Line(
                    anchor_x,
                    anchor_y - 1.9 * mm,
                    anchor_x,
                    anchor_y + 1.9 * mm,
                    strokeColor=anchor_color,
                    strokeWidth=0.7,
                )
            )
            label_width = stringWidth(
                elements.label_text,
                "Helvetica-Bold",
                7,
            )
            label_x = anchor_x + 2.6 * mm
            text_anchor = "start"
            if label_x + label_width > plot_right:
                label_x = anchor_x - 2.6 * mm
                text_anchor = "end"
            label_y = anchor_y + 2.1 * mm
            if label_y + 7 > plot_top:
                label_y = anchor_y - 4.1 * mm
            drawing.add(
                String(
                    label_x,
                    label_y,
                    elements.label_text,
                    textAnchor=text_anchor,
                    fontName="Helvetica-Bold",
                    fontSize=7,
                    fillColor=anchor_color,
                )
            )
    return drawing


def _report_preview_drawing(
    reports: list[ShapeReportData],
    *,
    lef_mode: bool = False,
) -> Drawing:
    if not reports:
        raise ValueError("A PDF report requires at least one shape")
    panels: list[tuple[ProjectConfig, GeneratedLayout, str | None]] = []
    for report in reports:
        if report.lef_definitions and (
            len(report.lef_definitions) != len(report.layouts)
        ):
            raise ValueError(
                "Each PDF report layout requires one exported LEF definition"
            )
        definitions: tuple[str | None, ...] = (
            report.lef_definitions
            if report.lef_definitions
            else (None,) * len(report.layouts)
        )
        panels.extend(
            (report.config, layout, definition)
            for layout, definition in zip(report.layouts, definitions)
        )
    panels.sort(
        key=lambda panel: (
            0 if panel[0].shape_type is ShapeType.ROUND else 1,
            panel[1].logical_angle or 0,
        ),
    )
    layouts = [layout for _, layout, _ in panels]
    configs = [config for config, _, _ in panels]
    lef_definitions = [definition for _, _, definition in panels]
    shapes = [config.shape_type for config in configs]
    combined_shapes = [ShapeType.ROUND, *([ShapeType.OVAL] * 4)]
    if shapes == [ShapeType.ROUND]:
        columns, rows = 1, 1
        positions = [(0, 0)]
    elif shapes == [ShapeType.OVAL] * 4:
        columns, rows = 2, 2
        positions = [(0, 0), (1, 0), (0, 1), (1, 1)]
    elif shapes == combined_shapes:
        columns, rows = 3, 2
        positions = [
            (0, 0),
            (1, 0),
            (2, 0),
            (1, 1),
            (2, 1),
        ]
    else:
        raise ValueError(
            "A PDF report requires one Round layout, four Oval layouts, "
            "or both"
        )
    return _preview_drawing(
        layouts,
        configs[0],
        lef_mode=lef_mode,
        panel_configs=configs,
        panel_positions=positions,
        columns=columns,
        rows=rows,
        show_cell_names=False,
        show_centers=False,
        shared_gds_legend=not lef_mode,
        shared_lef_legend=lef_mode,
        lef_definitions=lef_definitions if lef_mode else None,
    )


def _combined_preview_drawing(
    reports: list[ShapeReportData],
    *,
    lef_mode: bool = False,
) -> Drawing:
    return _report_preview_drawing(reports, lef_mode=lef_mode)


def _dimension_table(
    config: ProjectConfig,
    layouts: list[GeneratedLayout],
) -> Table:
    if config.shape_type is ShapeType.ROUND:
        rows = [[
            "Layer Name",
            "Nominal Diameter (µm)",
            "Actual Width (µm)",
            "Actual Height (µm)",
        ]]
    else:
        rows = [[
            "Angle",
            "Layer Name",
            "Nominal Minor Axis (µm)",
            "Actual Minor Axis (µm)",
            "Nominal Major Axis (µm)",
            "Actual Major Axis (µm)",
        ]]
    for layout in layouts:
        actual_by_layer_and_dimension = {
            (deviation.layer_uid, deviation.axis): deviation.actual_um
            for deviation in layout.deviations
        }
        for layer in layout.layers:
            if config.shape_type is ShapeType.ROUND:
                rows.append([
                    layer.definition.meaning,
                    format_dimension_um(
                        layer.definition.diameter_um,
                        config.dbu_um,
                    ),
                    format_dimension_um(
                        actual_by_layer_and_dimension[
                            (layer.definition.uid, "Width (X)")
                        ],
                        config.dbu_um,
                    ),
                    format_dimension_um(
                        actual_by_layer_and_dimension[
                            (layer.definition.uid, "Height (Y)")
                        ],
                        config.dbu_um,
                    ),
                ])
            else:
                rows.append([
                    f"{layout.logical_angle}D",
                    layer.definition.meaning,
                    format_dimension_um(
                        layer.definition.minor_axis_um,
                        config.dbu_um,
                    ),
                    format_dimension_um(
                        actual_by_layer_and_dimension[
                            (layer.definition.uid, "Minor Axis")
                        ],
                        config.dbu_um,
                    ),
                    format_dimension_um(
                        layer.definition.major_axis_um,
                        config.dbu_um,
                    ),
                    format_dimension_um(
                        actual_by_layer_and_dimension[
                            (layer.definition.uid, "Major Axis")
                        ],
                        config.dbu_um,
                    ),
                ])
    return _styled_table(rows)


def _generated_names_table(
    config: ProjectConfig,
    layouts: list[GeneratedLayout],
) -> Table:
    rows = [[
        "GDS File Name",
        "GDS Cell Name",
        "LEF File Name",
        "LEF Macro Name",
        "Polygon",
    ]]
    rows.extend(
        [
            [
                layout.gds_file_name,
                layout.cell_name,
                lef_file_name(config, layout.logical_angle),
                layout.cell_name,
                f"{layout.nodes_per_polygon}-gon",
            ]
            for layout in layouts
        ]
    )
    return _styled_table(
        rows,
        [68 * mm, 52 * mm, 68 * mm, 52 * mm, 20 * mm],
    )


def _shape_angle_label(
    config: ProjectConfig,
    layout: GeneratedLayout,
) -> str:
    return (
        "Round"
        if config.shape_type is ShapeType.ROUND
        else f"Oval {layout.logical_angle}D"
    )


def _combined_generated_names_table(
    reports: list[ShapeReportData],
) -> Table:
    rows: list[list[object]] = [[
        "Shape / Angle",
        "GDS File Name",
        "GDS Cell Name",
        "LEF File Name",
        "LEF Macro Name",
        "Polygon",
    ]]
    rows.extend(
        [
            _shape_angle_label(report.config, layout),
            layout.gds_file_name,
            layout.cell_name,
            lef_file_name(report.config, layout.logical_angle),
            layout.cell_name,
            f"{layout.nodes_per_polygon}-gon",
        ]
        for report in reports
        for layout in report.layouts
    )
    return _styled_table(
        rows,
        [24 * mm, 59 * mm, 43 * mm, 59 * mm, 43 * mm, 16 * mm],
    )


def _combined_checksums_table(
    reports: list[ShapeReportData],
) -> Table:
    rows: list[list[object]] = [[
        "Shape",
        "POSIX CRC",
        "Byte Count",
        "File Name",
    ]]
    rows.extend(
        [
            report.config.shape_type.value,
            str(checksum.crc),
            str(checksum.byte_count),
            checksum.file_name,
        ]
        for report in reports
        for checksum in report.checksums
    )
    return _styled_table(
        rows,
        [24 * mm, 35 * mm, 32 * mm, 153 * mm],
    )


def _combined_dimension_table(
    reports: list[ShapeReportData],
) -> Table:
    rows: list[list[object]] = [[
        "Shape / Angle",
        "Layer",
        "Nominal X / Minor (µm)",
        "Actual X / Minor (µm)",
        "Nominal Y / Major (µm)",
        "Actual Y / Major (µm)",
    ]]
    for report in reports:
        config = report.config
        for layout in report.layouts:
            actual_by_layer_and_dimension = {
                (deviation.layer_uid, deviation.axis): deviation.actual_um
                for deviation in layout.deviations
            }
            for layer in layout.layers:
                if config.shape_type is ShapeType.ROUND:
                    nominal_x = layer.definition.diameter_um
                    nominal_y = layer.definition.diameter_um
                    actual_x = actual_by_layer_and_dimension[
                        (layer.definition.uid, "Width (X)")
                    ]
                    actual_y = actual_by_layer_and_dimension[
                        (layer.definition.uid, "Height (Y)")
                    ]
                else:
                    nominal_x = layer.definition.minor_axis_um
                    nominal_y = layer.definition.major_axis_um
                    actual_x = actual_by_layer_and_dimension[
                        (layer.definition.uid, "Minor Axis")
                    ]
                    actual_y = actual_by_layer_and_dimension[
                        (layer.definition.uid, "Major Axis")
                    ]
                rows.append([
                    _shape_angle_label(config, layout),
                    layer.definition.meaning,
                    format_dimension_um(nominal_x, config.dbu_um),
                    format_dimension_um(actual_x, config.dbu_um),
                    format_dimension_um(nominal_y, config.dbu_um),
                    format_dimension_um(actual_y, config.dbu_um),
                ])
    return _styled_table(
        rows,
        [25 * mm, 25 * mm, 46 * mm, 46 * mm, 46 * mm, 46 * mm],
    )


def _combined_validation_table(
    reports: list[ShapeReportData],
) -> Table:
    rows: list[list[object]] = [[
        "Shape",
        "Origin",
        "Oval Orientation",
        "Validation",
    ]]
    for report in reports:
        config = report.config
        layouts = list(report.layouts)
        reference = config.reference_layer()
        origin = (
            "Common Center"
            if config.origin_mode.value == "Common Center"
            else (
                f"{reference.meaning if reference else 'N/A'} "
                "Quantized Bounding Box Lower-left"
            )
        )
        orientation = (
            "N/A"
            if config.shape_type is ShapeType.ROUND
            else (
                f"Zero degree: {config.zero_degree_axis.value}; "
                f"positive rotation: {config.rotation_direction.value}"
            )
        )
        warnings = _report_warning_messages(list(report.issues))
        risks = sorted(
            {risk.message for layout in layouts for risk in layout.risks}
        )
        status = "WARNING" if warnings or risks else "PASS"
        validation = (
            status
            if not warnings and not risks
            else f"{status}: {'; '.join(warnings + risks)}"
        )
        rows.append([
            config.shape_type.value,
            origin,
            orientation,
            validation,
        ])
    return _styled_table(
        rows,
        [24 * mm, 66 * mm, 84 * mm, 70 * mm],
    )


def _report_warning_messages(issues: list[ValidationIssue]) -> list[str]:
    return [
        issue.message
        for issue in issues
        if issue.level is IssueLevel.WARNING and issue.code != "long_cell_name"
    ]


def _build_pdf_report(
    path: str | Path,
    reports: list[ShapeReportData],
) -> Path:
    if not reports:
        raise ValueError("A PDF report requires at least one shape")
    reports = sorted(
        reports,
        key=lambda report: (
            0 if report.config.shape_type is ShapeType.ROUND else 1
        ),
    )
    destination = Path(path)
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            "ReportTitle",
            parent=styles["Title"],
            fontName="Helvetica-Bold",
            fontSize=20,
            leading=24,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#142638"),
            spaceAfter=8 * mm,
        )
    )
    styles.add(
        ParagraphStyle(
            "Section",
            parent=styles["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=11,
            leading=14,
            textColor=colors.HexColor("#174A7E"),
            spaceAfter=2 * mm,
            keepWithNext=True,
        )
    )
    document = SimpleDocTemplate(
        str(destination),
        pagesize=landscape(A4),
        leftMargin=16 * mm,
        rightMargin=16 * mm,
        topMargin=14 * mm,
        bottomMargin=14 * mm,
        title=REPORT_TITLE,
        author="EasyBumpcell",
    )
    first_config = reports[0].config
    shape_names = " / ".join(
        report.config.shape_type.value for report in reports
    )
    story: list = [Paragraph(REPORT_TITLE, styles["ReportTitle"])]
    story.append(
        KeepTogether(
            [
                _identity_grid(
                    [
                        ("Technology Name", first_config.technology_name),
                        ("Bump Type", first_config.bump_type or "N/A"),
                        ("Version", first_config.version),
                        ("Shape Type", shape_names),
                    ],
                    styles,
                    document.width,
                ),
                Spacer(1, 4 * mm),
            ]
        )
    )
    pin_layer = first_config.al_pad_layer()
    if pin_layer is None:
        raise ValueError("Select the Al Pad Layer for LEF output")
    story += _section(
        "LEF PIN Layer and Process DBU",
        (
            f'LEF Layer Name "{pin_layer.meaning}" '
            f"(GDS Layer Number {pin_layer.layer} / "
            f"Datatype {pin_layer.datatype}); "
            f"Process DBU {first_config.dbu_um} µm."
        ),
        styles,
    )
    story += _section(
        "Layer Number/Datatype Mapping",
        _layer_mapping_table(first_config, reports),
        styles,
        keep_together=len(first_config.layers) <= 10,
    )

    story.append(PageBreak())
    story += _section(
        "GDS Preview - Common Scale",
        KeepTogether([_report_preview_drawing(reports)]),
        styles,
    )

    story.append(PageBreak())
    story += _section(
        "LEF Preview - Common Scale",
        KeepTogether([_report_preview_drawing(reports, lef_mode=True)]),
        styles,
    )

    story.append(PageBreak())
    story += _section(
        "Generated GDS, LEF, Cell and Macro Names",
        _combined_generated_names_table(reports),
        styles,
    )
    story += _section(
        "POSIX Checksums",
        _combined_checksums_table(reports),
        styles,
    )

    story.append(PageBreak())
    story += _section(
        "Nominal Dimensions vs Actual Quantized Axis Dimensions",
        _combined_dimension_table(reports),
        styles,
    )
    summary_section = _section(
        "Coordinate and Validation Summary",
        _combined_validation_table(reports),
        styles,
    )
    summary_section.pop()
    story += summary_section

    def draw_page_number(canvas, document_template) -> None:
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(colors.HexColor("#73808C"))
        canvas.drawCentredString(
            landscape(A4)[0] / 2,
            7 * mm,
            f"Page {document_template.page}",
        )
        canvas.restoreState()

    document.build(
        story,
        onFirstPage=draw_page_number,
        onLaterPages=draw_page_number,
    )
    return destination


def create_pdf_report(
    path: str | Path,
    config: ProjectConfig,
    layouts: list[GeneratedLayout],
    checksums: list[PosixChecksum],
    issues: list[ValidationIssue],
    lef_definitions: list[str] | None = None,
) -> Path:
    return _build_pdf_report(
        path,
        [
            ShapeReportData(
                config=config,
                layouts=tuple(layouts),
                checksums=tuple(checksums),
                issues=tuple(issues),
                lef_definitions=tuple(lef_definitions or ()),
            )
        ],
    )


def create_combined_pdf_report(
    path: str | Path,
    reports: list[ShapeReportData],
) -> Path:
    if len(reports) < 2:
        raise ValueError("A combined report requires at least two shapes")
    return _build_pdf_report(path, reports)
