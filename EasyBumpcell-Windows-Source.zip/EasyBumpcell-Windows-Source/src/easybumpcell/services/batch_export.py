from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass
from pathlib import Path

from easybumpcell.domain.enums import IssueLevel, ShapeType
from easybumpcell.domain.models import ProjectConfig, ValidationIssue
from easybumpcell.geometry import GeneratedLayout, build_layouts
from easybumpcell.services.gds_export import write_gds
from easybumpcell.services.gds_verify import verify_gds
from easybumpcell.services.lef_export import write_lef
from easybumpcell.services.lef_verify import verify_lef
from easybumpcell.services.naming import (
    combined_shape_report_name,
    lef_file_name,
    report_name,
)
from easybumpcell.services.pdf_report import (
    ShapeReportData,
    create_combined_pdf_report,
    create_pdf_report,
)
from easybumpcell.services.posix_cksum import PosixChecksum, posix_cksum
from easybumpcell.services.validation import validate_project
from easybumpcell.services.shape_availability import project_for_shape


@dataclass(frozen=True)
class ExportResult:
    gds_paths: tuple[Path, ...]
    lef_paths: tuple[Path, ...]
    report_path: Path
    checksums: tuple[PosixChecksum, ...]
    issues: tuple[ValidationIssue, ...]


def intended_paths(config: ProjectConfig, output_directory: str | Path) -> list[Path]:
    return intended_paths_for_shapes(
        config,
        (config.shape_type,),
        output_directory,
    )


def intended_paths_for_shapes(
    config: ProjectConfig,
    shape_types: tuple[ShapeType, ...],
    output_directory: str | Path,
) -> list[Path]:
    directory = Path(output_directory)
    paths: list[Path] = []
    shaped_configs = [
        project_for_shape(config, shape_type) for shape_type in shape_types
    ]
    for shaped_config in shaped_configs:
        for layout in build_layouts(shaped_config):
            paths.extend(
                (
                    directory / layout.gds_file_name,
                    directory
                    / lef_file_name(shaped_config, layout.logical_angle),
                )
            )
    report_file_name = (
        report_name(shaped_configs[0])
        if len(shaped_configs) == 1
        else combined_shape_report_name(config, shape_types)
    )
    return [*paths, directory / report_file_name]


def _commit_files(staged: list[Path], targets: list[Path]) -> None:
    backup_directory = staged[0].parent / "_backup"
    backup_directory.mkdir(exist_ok=True)
    backed_up: list[tuple[Path, Path]] = []
    committed: list[Path] = []
    try:
        for target in targets:
            if target.exists():
                backup = backup_directory / target.name
                os.replace(target, backup)
                backed_up.append((backup, target))
        for source, target in zip(staged, targets):
            os.replace(source, target)
            committed.append(target)
    except Exception:
        for target in committed:
            if target.exists():
                target.unlink()
        for backup, target in backed_up:
            if backup.exists():
                os.replace(backup, target)
        raise


def export_project(
    config: ProjectConfig,
    output_directory: str | Path,
    *,
    overwrite: bool = False,
) -> ExportResult:
    return export_project_shapes(
        config,
        (config.shape_type,),
        output_directory,
        overwrite=overwrite,
    )


def export_project_shapes(
    config: ProjectConfig,
    shape_types: tuple[ShapeType, ...],
    output_directory: str | Path,
    *,
    overwrite: bool = False,
) -> ExportResult:
    if not shape_types:
        raise ValueError("Select at least one shape to export")
    shaped_configs = [
        project_for_shape(config, shape_type) for shape_type in shape_types
    ]
    issues_by_shape = [
        validate_project(shaped_config, for_export=True)
        for shaped_config in shaped_configs
    ]
    errors = [
        f"{shaped_config.shape_type.value}: {issue.message}"
        for shaped_config, issues in zip(shaped_configs, issues_by_shape)
        for issue in issues
        if issue.level is IssueLevel.ERROR
    ]
    if errors:
        raise ValueError("; ".join(errors))
    all_issues = [issue for issues in issues_by_shape for issue in issues]

    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    layouts_by_shape: list[list[GeneratedLayout]] = [
        build_layouts(shaped_config) for shaped_config in shaped_configs
    ]
    gds_targets = [
        output / layout.gds_file_name
        for layouts in layouts_by_shape
        for layout in layouts
    ]
    lef_targets = [
        output / lef_file_name(shaped_config, layout.logical_angle)
        for shaped_config, layouts in zip(shaped_configs, layouts_by_shape)
        for layout in layouts
    ]
    report_file_name = (
        report_name(shaped_configs[0])
        if len(shaped_configs) == 1
        else combined_shape_report_name(config, shape_types)
    )
    report_target = output / report_file_name
    targets: list[Path] = []
    for gds_target, lef_target in zip(gds_targets, lef_targets):
        targets.extend((gds_target, lef_target))
    targets.append(report_target)
    existing = [path for path in targets if path.exists()]
    if existing and not overwrite:
        raise FileExistsError("Output files already exist: " + ", ".join(path.name for path in existing))

    with tempfile.TemporaryDirectory(prefix=".easybumpcell-", dir=output) as temporary:
        staging = Path(temporary)
        staged_outputs: list[Path] = []
        checksums: list[PosixChecksum] = []
        report_data: list[ShapeReportData] = []
        for shaped_config, layouts, issues in zip(
            shaped_configs,
            layouts_by_shape,
            issues_by_shape,
        ):
            shape_checksums: list[PosixChecksum] = []
            shape_lef_definitions: list[str] = []
            for layout in layouts:
                gds_path = write_gds(
                    staging / layout.gds_file_name,
                    shaped_config,
                    layout,
                )
                verify_gds(gds_path, shaped_config, layout)
                lef_path = write_lef(
                    staging
                    / lef_file_name(shaped_config, layout.logical_angle),
                    shaped_config,
                    layout,
                )
                verify_lef(lef_path, shaped_config, layout)
                shape_lef_definitions.append(
                    lef_path.read_text(encoding="ascii")
                )
                pair_checksums = (
                    posix_cksum(gds_path),
                    posix_cksum(lef_path),
                )
                shape_checksums.extend(pair_checksums)
                checksums.extend(pair_checksums)
                staged_outputs.extend((gds_path, lef_path))
            report_data.append(
                ShapeReportData(
                    config=shaped_config,
                    layouts=tuple(layouts),
                    checksums=tuple(shape_checksums),
                    issues=tuple(issues),
                    lef_definitions=tuple(shape_lef_definitions),
                )
            )

        report_path = (
            create_pdf_report(
                staging / report_file_name,
                shaped_configs[0],
                layouts_by_shape[0],
                checksums,
                issues_by_shape[0],
                lef_definitions=list(report_data[0].lef_definitions),
            )
            if len(shaped_configs) == 1
            else create_combined_pdf_report(
                staging / report_file_name,
                report_data,
            )
        )
        _commit_files([*staged_outputs, report_path], targets)

    return ExportResult(
        tuple(gds_targets),
        tuple(lef_targets),
        report_target,
        tuple(checksums),
        tuple(all_issues),
    )
