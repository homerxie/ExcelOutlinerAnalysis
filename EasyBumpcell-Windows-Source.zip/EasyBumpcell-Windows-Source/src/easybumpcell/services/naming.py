from __future__ import annotations

import re

from easybumpcell.dimensions import (
    dimension_decimal,
    format_cell_dimension,
)
from easybumpcell.domain.enums import ShapeType
from easybumpcell.domain.models import ProjectConfig

TOKEN_RE = re.compile(r"^[A-Za-z0-9]+$")
LAYER_NAME_RE = re.compile(r"^[A-Za-z0-9_]+$")
BUMP_TYPE_RE = re.compile(r"^[A-Za-z0-9_]+$")
VERSION_RE = re.compile(r"^V[A-Za-z0-9]+(?:[.-][A-Za-z0-9]+)*$")
MANUAL_NAME_RE = re.compile(r"^[A-Za-z0-9_]+$")
OVAL_ANGLES = (0, 45, 90, 135)
MAX_CELL_NAME_LENGTH = 127
MAX_FILE_NAME_LENGTH = 255


def validate_token(value: str, field_name: str, *, optional: bool = False) -> None:
    if not value:
        if optional:
            return
        raise ValueError(f"{field_name} is required")
    if not TOKEN_RE.fullmatch(value):
        raise ValueError(f"{field_name} may contain ASCII letters and digits only")


def validate_layer_name(value: str) -> None:
    if not value:
        raise ValueError("Layer Name is required")
    if not LAYER_NAME_RE.fullmatch(value):
        raise ValueError(
            "Layer Name may contain ASCII letters, digits and underscores only"
        )


def validate_version(value: str) -> None:
    if not value:
        raise ValueError("Version is required")
    if not VERSION_RE.fullmatch(value):
        raise ValueError(
            "Version must begin with V and may otherwise contain ASCII "
            "letters, digits, periods and hyphens, with separators only "
            "between alphanumeric groups"
        )


def validate_bump_type(value: str) -> None:
    if not value:
        return
    if not BUMP_TYPE_RE.fullmatch(value):
        raise ValueError(
            "Bump Type may contain ASCII letters, digits and underscores only"
        )


def _validate_layers(layers) -> None:
    for layer in layers:
        validate_layer_name(layer.meaning)


def _dimension_token(
    config: ProjectConfig,
    layer,
    *,
    meaning_first: bool,
) -> str:
    if config.shape_type is ShapeType.ROUND:
        diameter = dimension_decimal(
            layer.diameter_um,
            f"{layer.meaning} Diameter",
        )
        dimensions = format_cell_dimension(diameter)
    else:
        minor_axis = dimension_decimal(
            layer.minor_axis_um,
            f"{layer.meaning} Minor Axis",
        )
        major_axis = dimension_decimal(
            layer.major_axis_um,
            f"{layer.meaning} Major Axis",
        )
        if major_axis <= minor_axis:
            raise ValueError(f"{layer.meaning}: major axis must be greater than minor axis")
        dimensions = (
            f"{format_cell_dimension(minor_axis)}"
            f"{format_cell_dimension(major_axis)}"
        )
    naming_meaning = layer.meaning.replace("_", "")
    return (
        f"{naming_meaning}{dimensions}"
        if meaning_first
        else f"{dimensions}{naming_meaning}"
    )


def default_cell_name_layer_uids(config: ProjectConfig) -> list[str]:
    layers = config.tapeout_layers()
    if not layers:
        return []
    if len(layers) == 1:
        return [layers[0].uid]
    return [layers[0].uid, layers[-1].uid]


def cell_name_layers(config: ProjectConfig):
    selected_uids = (
        default_cell_name_layer_uids(config)
        if config.cell_name_layer_uids is None
        else config.cell_name_layer_uids
    )
    selected_set = set(selected_uids)
    missing = selected_set.difference(layer.uid for layer in config.layers)
    if missing:
        raise ValueError("Cell Name dimension selection contains deleted layers")
    selected = [
        layer
        for layer in config.layers
        if layer.tapeout and layer.uid in selected_set
    ]
    if not selected:
        raise ValueError("Select at least one Tapeout layer for the Cell Name")
    return selected


def automatic_base_name(config: ProjectConfig) -> str:
    validate_bump_type(config.bump_type)
    _validate_layers(config.tapeout_layers())
    tokens = [config.bump_type] if config.bump_type else []
    tokens.extend(
        _dimension_token(
            config,
            layer,
            meaning_first=True,
        )
        for layer in cell_name_layers(config)
    )
    return "_".join(tokens)


def file_base_name(config: ProjectConfig) -> str:
    validate_token(config.technology_name, "Technology Name")
    validate_bump_type(config.bump_type)
    tapeout_layers = config.tapeout_layers()
    if not tapeout_layers:
        raise ValueError("At least one Tapeout layer is required")
    _validate_layers(tapeout_layers)
    prefix = [config.technology_name]
    if config.bump_type:
        prefix.append(config.bump_type)
    prefix.append(config.shape_type.value)
    dimension_tokens: list[str] = []
    for layer in tapeout_layers:
        if config.shape_type is ShapeType.ROUND:
            dimension_tokens.append(
                _dimension_token(
                    config,
                    layer,
                    meaning_first=False,
                )
            )
        else:
            dimension_tokens.append(
                _dimension_token(
                    config,
                    layer,
                    meaning_first=False,
                )
            )
    return "_".join((*prefix, *dimension_tokens))


def base_name(config: ProjectConfig) -> str:
    if config.manual_cell_base_name:
        if not MANUAL_NAME_RE.fullmatch(config.manual_cell_base_name):
            raise ValueError("Manual Cell Name may contain ASCII letters, digits and underscores only")
        return config.manual_cell_base_name
    return automatic_base_name(config)


def generated_names(config: ProjectConfig) -> list[str]:
    base = base_name(config)
    if config.shape_type is ShapeType.ROUND:
        return [base]
    return [f"{base}_{angle}D" for angle in OVAL_ANGLES]


def gds_file_name(config: ProjectConfig, logical_angle: int) -> str:
    validate_version(config.version)
    base = file_base_name(config)
    angle = "" if config.shape_type is ShapeType.ROUND else f"_{logical_angle}D"
    return f"{base}{angle}_{config.version}.gds"


def lef_file_name(config: ProjectConfig, logical_angle: int) -> str:
    return gds_file_name(config, logical_angle).removesuffix(".gds") + ".lef"


def report_name(config: ProjectConfig) -> str:
    validate_version(config.version)
    return f"{file_base_name(config)}_Report_{config.version}.pdf"


def combined_shape_report_name(
    config: ProjectConfig,
    shape_types: tuple[ShapeType, ...],
) -> str:
    validate_token(config.technology_name, "Technology Name")
    validate_bump_type(config.bump_type)
    validate_version(config.version)
    if len(shape_types) < 2:
        raise ValueError("A combined report requires at least two shapes")
    prefix = [config.technology_name]
    if config.bump_type:
        prefix.append(config.bump_type)
    prefix.extend(shape_type.value for shape_type in shape_types)
    return "_".join((*prefix, "Report", config.version)) + ".pdf"
