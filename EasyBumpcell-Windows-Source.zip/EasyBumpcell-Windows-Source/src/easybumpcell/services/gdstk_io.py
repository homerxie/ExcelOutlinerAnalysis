from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path
from threading import RLock
from typing import Callable, TypeVar


_Result = TypeVar("_Result")
_GDS_CWD_LOCK = RLock()
_ASCII_TEMP_PREFIX = ".easybumpcell-gdstk-"


def _needs_ascii_bridge(path: Path) -> bool:
    """Return whether gdstk needs an ASCII-only path on this platform.

    Gdstk passes filesystem paths to C ``fopen`` as byte strings.  Windows
    therefore cannot reliably open paths containing characters outside the
    active ANSI code page, even though Python itself can open those paths.
    """
    return os.name == "nt" and not os.fspath(path).isascii()


def _absolute_path(path: Path) -> Path:
    return Path(os.path.abspath(os.fspath(path)))


def _call_from_parent(
    path: Path,
    operation: Callable[[Path], _Result],
) -> _Result:
    with _GDS_CWD_LOCK:
        previous_directory = Path.cwd()
        os.chdir(path.parent)
        try:
            return operation(Path(path.name))
        finally:
            os.chdir(previous_directory)


def _ascii_alias(path: Path) -> Path:
    suffix = path.suffix if path.suffix.isascii() else ".tmp"
    descriptor, alias = tempfile.mkstemp(
        prefix=_ASCII_TEMP_PREFIX,
        suffix=suffix,
        dir=path.parent,
    )
    os.close(descriptor)
    return Path(alias)


def write_gdstk_file(
    path: str | Path,
    writer: Callable[[Path], None],
) -> Path:
    """Write one gdstk file while preserving Unicode destination paths."""
    destination = Path(path)
    if not _needs_ascii_bridge(destination):
        writer(destination)
        return destination

    absolute_destination = _absolute_path(destination)
    if absolute_destination.name.isascii():
        _call_from_parent(absolute_destination, writer)
        return destination

    alias = _ascii_alias(absolute_destination)
    try:
        _call_from_parent(alias, writer)
        os.replace(alias, absolute_destination)
    finally:
        alias.unlink(missing_ok=True)
    return destination


def read_gdstk_file(
    path: str | Path,
    reader: Callable[[Path], _Result],
) -> _Result:
    """Read one gdstk file while preserving Unicode source paths."""
    source = Path(path)
    if not _needs_ascii_bridge(source):
        return reader(source)

    absolute_source = _absolute_path(source)
    if absolute_source.name.isascii():
        return _call_from_parent(absolute_source, reader)

    alias = _ascii_alias(absolute_source)
    try:
        shutil.copyfile(absolute_source, alias)
        return _call_from_parent(alias, reader)
    finally:
        alias.unlink(missing_ok=True)
