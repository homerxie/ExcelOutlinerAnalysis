from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
import json
import os
from pathlib import Path
import re
import sys
import tempfile
from typing import Any

from easybumpcell.domain.enums import ShapeType
from easybumpcell.domain.models import LayerDefinition, ProjectConfig
from easybumpcell.services.naming import MAX_FILE_NAME_LENGTH
from easybumpcell.services.shape_availability import (
    SHAPE_ORDER,
    available_shape_types,
    available_shape_types_for_layers,
)


TEMPLATE_FORMAT = "EasyBumpcell Process Template"
TEMPLATE_SCHEMA_VERSION = 2
SUPPORTED_PROCESS_DBUS = (Decimal("0.001"), Decimal("0.0005"))
TEMPLATE_SUFFIX_PATTERN = (
    r"(?:[A-Za-z0-9]+(?:[._-][A-Za-z0-9]+)*)?"
)
_TECHNOLOGY_PATTERN = re.compile(r"[A-Za-z0-9]*")
_TOKEN_PATTERN = re.compile(r"[A-Za-z0-9_]*")
_SUFFIX_PATTERN = re.compile(TEMPLATE_SUFFIX_PATTERN)


class ProcessTemplateError(ValueError):
    """Raised when a process template cannot be parsed or validated."""


@dataclass(frozen=True)
class ProcessTemplate:
    name: str
    custom_suffix: str
    technology_name: str
    bump_type: str
    shape_types: tuple[ShapeType, ...]
    dbu_um: Decimal
    layers: tuple[LayerDefinition, ...]
    al_pad_layer_uid: str | None


@dataclass(frozen=True)
class StoredProcessTemplate:
    path: Path
    template: ProcessTemplate


def default_template_directory() -> Path:
    """Return the writable template folder beside the source app or executable."""

    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent / "template"

    source_root = Path(__file__).resolve().parents[3]
    if (source_root / "pyproject.toml").is_file():
        return source_root / "template"
    return Path(sys.argv[0]).resolve().parent / "template"


def _normalize_shape_types(
    shape_types: ShapeType | tuple[ShapeType, ...] | list[ShapeType],
) -> tuple[ShapeType, ...]:
    values = (
        (shape_types,)
        if isinstance(shape_types, (str, ShapeType))
        else tuple(shape_types)
    )
    try:
        requested = {ShapeType(value) for value in values}
    except (TypeError, ValueError) as exc:
        raise ProcessTemplateError("Unsupported Shape Type.") from exc
    normalized = tuple(
        shape_type for shape_type in SHAPE_ORDER if shape_type in requested
    )
    if not normalized:
        raise ProcessTemplateError("At least one Shape Type is required.")
    return normalized


def build_template_name(
    technology_name: str,
    bump_type: str,
    shape_types: ShapeType | tuple[ShapeType, ...] | list[ShapeType],
    custom_suffix: str = "",
) -> str:
    technology_name = technology_name.strip()
    bump_type = bump_type.strip()
    custom_suffix = custom_suffix.strip()
    normalized_shapes = _normalize_shape_types(shape_types)

    if not technology_name:
        raise ProcessTemplateError(
            "Enter a Technology Name before saving a template."
        )
    if _TECHNOLOGY_PATTERN.fullmatch(technology_name) is None:
        raise ProcessTemplateError(
            "Technology Name may contain ASCII letters and digits only."
        )
    if _TOKEN_PATTERN.fullmatch(bump_type) is None:
        raise ProcessTemplateError(
            "Bump Type may contain ASCII letters, digits and underscores only."
        )
    if _SUFFIX_PATTERN.fullmatch(custom_suffix) is None:
        raise ProcessTemplateError(
            "Template suffix may contain ASCII letters, digits, periods, "
            "hyphens and underscores, with separators only between "
            "alphanumeric groups."
        )

    parts = [technology_name]
    if bump_type:
        parts.append(bump_type)
    parts.append("_".join(shape.value for shape in normalized_shapes))
    if custom_suffix:
        parts.append(custom_suffix)
    name = "_".join(parts)
    if len(f"{name}.json") > MAX_FILE_NAME_LENGTH:
        raise ProcessTemplateError(
            f"Template file name may not exceed {MAX_FILE_NAME_LENGTH} characters."
        )
    return name


def process_template_from_config(
    config: ProjectConfig,
    custom_suffix: str = "",
    *,
    shape_types: tuple[ShapeType, ...] | None = None,
) -> ProcessTemplate:
    available_shapes = available_shape_types(config)
    if not available_shapes:
        raise ProcessTemplateError(
            "No complete Round or Oval dimensions are available."
        )
    selected_shapes = (
        available_shapes
        if shape_types is None
        else _normalize_shape_types(shape_types)
    )
    if any(shape not in available_shapes for shape in selected_shapes):
        raise ProcessTemplateError(
            "Complete dimensions are not available for every selected Shape Type."
        )
    name = build_template_name(
        config.technology_name,
        config.bump_type,
        selected_shapes,
        custom_suffix,
    )
    dbu_um = Decimal(config.dbu_um)
    if dbu_um not in SUPPORTED_PROCESS_DBUS:
        raise ProcessTemplateError("Unsupported Process DBU.")
    layer_uids = [layer.uid for layer in config.layers]
    if len(layer_uids) != len(set(layer_uids)):
        raise ProcessTemplateError("Layer identifiers must be unique.")
    if (
        config.al_pad_layer_uid is not None
        and config.al_pad_layer_uid not in layer_uids
    ):
        raise ProcessTemplateError(
            "The selected Al Pad Layer does not exist in the template."
        )
    layers = [_clone_layer(layer) for layer in config.layers]
    if ShapeType.ROUND not in selected_shapes:
        for layer in layers:
            layer.diameter_um = None
    if ShapeType.OVAL not in selected_shapes:
        for layer in layers:
            layer.minor_axis_um = None
            layer.major_axis_um = None
    return ProcessTemplate(
        name=name,
        custom_suffix=custom_suffix.strip(),
        technology_name=config.technology_name.strip(),
        bump_type=config.bump_type.strip(),
        shape_types=selected_shapes,
        dbu_um=dbu_um,
        layers=tuple(layers),
        al_pad_layer_uid=config.al_pad_layer_uid,
    )


def apply_process_template(
    config: ProjectConfig,
    template: ProcessTemplate,
) -> None:
    """Apply template-owned fields while intentionally preserving Version."""

    selected_shape = (
        config.shape_type
        if config.shape_type in template.shape_types
        else template.shape_types[0]
    )
    config.technology_name = template.technology_name
    config.bump_type = template.bump_type
    config.shape_type = selected_shape
    config.dbu_um = template.dbu_um
    config.layers = [_clone_layer(layer) for layer in template.layers]
    layer_uids = {layer.uid for layer in config.layers}
    config.al_pad_layer_uid = (
        template.al_pad_layer_uid
        if template.al_pad_layer_uid in layer_uids
        else None
    )
    if config.sync_origin_to_al_pad:
        config.origin_reference_uid = config.al_pad_layer_uid
    elif config.origin_reference_uid not in layer_uids:
        config.origin_reference_uid = (
            config.layers[0].uid if config.layers else None
        )
    if config.cell_name_layer_uids is not None:
        retained_uids = [
            uid for uid in config.cell_name_layer_uids if uid in layer_uids
        ]
        config.cell_name_layer_uids = retained_uids or None
    config.process_order_confirmed = False


def template_path(directory: str | Path, template: ProcessTemplate) -> Path:
    return Path(directory) / f"{template.name}.json"


def save_process_template(
    template: ProcessTemplate,
    path: str | Path,
    *,
    overwrite: bool = False,
) -> Path:
    path = Path(path)
    if path.suffix.lower() != ".json":
        path = path.with_suffix(".json")
    if path.exists() and not overwrite:
        raise FileExistsError(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    document = _template_document(template)
    payload = json.dumps(document, ensure_ascii=False, indent=2) + "\n"
    temporary_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            encoding="utf-8",
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as temporary_file:
            temporary_file.write(payload)
            temporary_path = Path(temporary_file.name)
        os.replace(temporary_path, path)
    finally:
        if temporary_path is not None and temporary_path.exists():
            temporary_path.unlink()
    return path


def load_process_template(path: str | Path) -> ProcessTemplate:
    path = Path(path)
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ProcessTemplateError(
            f"Unable to read process template: {path.name}"
        ) from exc
    return process_template_from_document(document)


def list_process_templates(
    directory: str | Path,
) -> tuple[StoredProcessTemplate, ...]:
    directory = Path(directory)
    if not directory.is_dir():
        return ()
    stored: list[StoredProcessTemplate] = []
    for path in sorted(directory.glob("*.json"), key=lambda item: item.name.casefold()):
        try:
            template = load_process_template(path)
        except ProcessTemplateError:
            continue
        stored.append(StoredProcessTemplate(path=path, template=template))
    return tuple(
        sorted(stored, key=lambda item: item.template.name.casefold())
    )


def process_template_from_document(document: Any) -> ProcessTemplate:
    if not isinstance(document, dict):
        raise ProcessTemplateError("A process template must be a JSON object.")
    if document.get("format") != TEMPLATE_FORMAT:
        raise ProcessTemplateError("This is not an EasyBumpcell process template.")
    schema_version = document.get("schema_version")
    if schema_version not in (1, TEMPLATE_SCHEMA_VERSION):
        raise ProcessTemplateError("Unsupported process template schema version.")

    technology_name = _required_string(document, "technology_name").strip()
    bump_type = _required_string(document, "bump_type").strip()
    custom_suffix = _required_string(document, "custom_suffix").strip()
    if schema_version == 1:
        shape_types = _normalize_shape_types(
            _required_string(document, "shape_type")
        )
    else:
        shape_values = document.get("shape_types")
        if not isinstance(shape_values, list):
            raise ProcessTemplateError(
                "template.shape_types must be a list."
            )
        shape_types = _normalize_shape_types(shape_values)
    name = build_template_name(
        technology_name,
        bump_type,
        shape_types,
        custom_suffix,
    )
    if _required_string(document, "name") != name:
        raise ProcessTemplateError(
            "The template name does not match its process fields."
        )

    dbu_um = _decimal_value(document.get("dbu_um"), "dbu_um")
    if dbu_um not in SUPPORTED_PROCESS_DBUS:
        raise ProcessTemplateError("Unsupported Process DBU.")

    layer_documents = document.get("layers")
    if not isinstance(layer_documents, list) or not layer_documents:
        raise ProcessTemplateError("A process template requires at least one layer.")
    layers = tuple(
        _layer_from_document(layer_document, index)
        for index, layer_document in enumerate(layer_documents)
    )
    layer_uids = [layer.uid for layer in layers]
    if len(layer_uids) != len(set(layer_uids)):
        raise ProcessTemplateError("Layer identifiers must be unique.")
    process_order = document.get("process_order")
    if (
        not isinstance(process_order, list)
        or not process_order
        or any(not isinstance(uid, str) for uid in process_order)
    ):
        raise ProcessTemplateError(
            "process_order must be a non-empty list of layer identifiers."
        )
    if (
        len(process_order) != len(set(process_order))
        or set(process_order) != set(layer_uids)
    ):
        raise ProcessTemplateError(
            "process_order must contain every layer exactly once."
        )
    layers_by_uid = {layer.uid: layer for layer in layers}
    layers = tuple(layers_by_uid[uid] for uid in process_order)
    layer_uids = list(process_order)
    detected_shapes = available_shape_types_for_layers(layers)
    if (
        schema_version == TEMPLATE_SCHEMA_VERSION
        and any(shape not in detected_shapes for shape in shape_types)
    ):
        raise ProcessTemplateError(
            "The template is missing complete dimensions for a declared Shape Type."
        )

    al_pad_layer_uid = document.get("al_pad_layer_uid")
    if al_pad_layer_uid is not None and not isinstance(al_pad_layer_uid, str):
        raise ProcessTemplateError("al_pad_layer_uid must be a string or null.")
    if al_pad_layer_uid is not None and al_pad_layer_uid not in layer_uids:
        raise ProcessTemplateError(
            "The selected Al Pad Layer does not exist in the template."
        )

    return ProcessTemplate(
        name=name,
        custom_suffix=custom_suffix,
        technology_name=technology_name,
        bump_type=bump_type,
        shape_types=shape_types,
        dbu_um=dbu_um,
        layers=layers,
        al_pad_layer_uid=al_pad_layer_uid,
    )


def _template_document(template: ProcessTemplate) -> dict[str, Any]:
    return {
        "format": TEMPLATE_FORMAT,
        "schema_version": TEMPLATE_SCHEMA_VERSION,
        "name": template.name,
        "custom_suffix": template.custom_suffix,
        "technology_name": template.technology_name,
        "bump_type": template.bump_type,
        "shape_types": [shape.value for shape in template.shape_types],
        "dbu_um": str(template.dbu_um),
        "layers": [_layer_document(layer) for layer in template.layers],
        "process_order": [layer.uid for layer in template.layers],
        "al_pad_layer_uid": template.al_pad_layer_uid,
    }


def _layer_document(layer: LayerDefinition) -> dict[str, Any]:
    return {
        "uid": layer.uid,
        "meaning": layer.meaning,
        "layer": layer.layer,
        "datatype": layer.datatype,
        "diameter_um": _optional_decimal_text(layer.diameter_um),
        "minor_axis_um": _optional_decimal_text(layer.minor_axis_um),
        "major_axis_um": _optional_decimal_text(layer.major_axis_um),
        "color": layer.color,
        "preview_pattern": layer.preview_pattern,
        "tapeout": layer.tapeout,
    }


def _layer_from_document(document: Any, index: int) -> LayerDefinition:
    label = f"layers[{index}]"
    if not isinstance(document, dict):
        raise ProcessTemplateError(f"{label} must be a JSON object.")
    uid = _required_string(document, "uid", label=label)
    meaning = _required_string(document, "meaning", label=label)
    color = _required_string(document, "color", label=label)
    preview_pattern = _required_string(
        document,
        "preview_pattern",
        label=label,
    )
    if not uid:
        raise ProcessTemplateError(f"{label}.uid may not be empty.")
    if _TOKEN_PATTERN.fullmatch(meaning) is None:
        raise ProcessTemplateError(
            f"{label}.meaning contains unsupported characters."
        )
    tapeout = document.get("tapeout")
    if not isinstance(tapeout, bool):
        raise ProcessTemplateError(f"{label}.tapeout must be true or false.")
    return LayerDefinition(
        uid=uid,
        meaning=meaning,
        layer=_optional_integer(document.get("layer"), f"{label}.layer"),
        datatype=_optional_integer(
            document.get("datatype"),
            f"{label}.datatype",
        ),
        diameter_um=_optional_decimal(
            document.get("diameter_um"),
            f"{label}.diameter_um",
        ),
        minor_axis_um=_optional_decimal(
            document.get("minor_axis_um"),
            f"{label}.minor_axis_um",
        ),
        major_axis_um=_optional_decimal(
            document.get("major_axis_um"),
            f"{label}.major_axis_um",
        ),
        color=color,
        preview_pattern=preview_pattern,
        tapeout=tapeout,
    )


def _clone_layer(layer: LayerDefinition) -> LayerDefinition:
    return LayerDefinition(
        uid=layer.uid,
        meaning=layer.meaning,
        layer=layer.layer,
        datatype=layer.datatype,
        diameter_um=layer.diameter_um,
        minor_axis_um=layer.minor_axis_um,
        major_axis_um=layer.major_axis_um,
        color=layer.color,
        preview_pattern=layer.preview_pattern,
        tapeout=layer.tapeout,
    )


def _required_string(
    document: dict[str, Any],
    key: str,
    *,
    label: str | None = None,
) -> str:
    value = document.get(key)
    if not isinstance(value, str):
        prefix = label or "template"
        raise ProcessTemplateError(f"{prefix}.{key} must be a string.")
    return value


def _decimal_value(value: Any, label: str) -> Decimal:
    if isinstance(value, bool) or not isinstance(value, (str, int, float)):
        raise ProcessTemplateError(f"{label} must be a decimal value.")
    try:
        decimal_value = Decimal(str(value))
    except InvalidOperation as exc:
        raise ProcessTemplateError(f"{label} must be a decimal value.") from exc
    if not decimal_value.is_finite():
        raise ProcessTemplateError(f"{label} must be finite.")
    return decimal_value


def _optional_decimal(value: Any, label: str) -> Decimal | None:
    return None if value is None else _decimal_value(value, label)


def _optional_decimal_text(value: Any) -> str | None:
    return None if value is None else str(Decimal(str(value)))


def _optional_integer(value: Any, label: str) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise ProcessTemplateError(f"{label} must be an integer or null.")
    return value
