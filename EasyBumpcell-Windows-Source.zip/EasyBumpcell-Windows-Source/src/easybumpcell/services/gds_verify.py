from __future__ import annotations

import math
from decimal import Decimal
from pathlib import Path
from typing import Mapping, Sequence

import gdstk

from easybumpcell.domain.enums import ShapeType
from easybumpcell.domain.models import ProjectConfig
from easybumpcell.geometry.layout import GeneratedLayout
from easybumpcell.services.gds_export import GDS_LIBRARY_NAME
from easybumpcell.services.gdstk_io import read_gdstk_file

IntPoint = tuple[int, int]
LayerTag = tuple[int, int]
PolygonPoints = tuple[IntPoint, ...]
GdsReadback = dict[LayerTag, PolygonPoints]


class GdsVerificationError(RuntimeError):
    pass


def _fail(message: str) -> None:
    raise GdsVerificationError(message)


def _centered_points(
    points: PolygonPoints,
    center: IntPoint,
) -> tuple[IntPoint, ...]:
    center_x, center_y = center
    return tuple((x - center_x, y - center_y) for x, y in points)


def _reflect_across_axis(point: IntPoint, axis_degrees: float) -> IntPoint:
    rounded_angle = round(axis_degrees)
    if not math.isclose(axis_degrees, rounded_angle, abs_tol=1e-9):
        _fail("Oval symmetry axis is not a multiple of 45 degrees")
    x, y = point
    transforms = {
        0: (x, -y),
        45: (y, x),
        90: (-x, y),
        135: (-y, -x),
    }
    try:
        return transforms[rounded_angle % 180]
    except KeyError:
        _fail("Oval symmetry axis is not a multiple of 45 degrees")


def _verify_oval_polygon_symmetry(
    source: Path,
    tag: LayerTag,
    points: PolygonPoints,
    expected: GeneratedLayout,
) -> None:
    label = f"{source.name}: Layer/Datatype {tag[0]}/{tag[1]}"
    centered = _centered_points(points, expected.common_center_dbu)
    point_set = set(centered)
    if len(point_set) != 66:
        _fail(f"{label} does not have 66 unique vertices after GDS readback")

    central_opposites = {(-x, -y) for x, y in centered}
    if central_opposites != point_set:
        _fail(f"{label} is not centrally symmetric after GDS readback")

    major_reflections = {
        _reflect_across_axis(point, expected.actual_angle_degrees)
        for point in centered
    }
    if major_reflections != point_set:
        _fail(f"{label} is not major-axis symmetric after GDS readback")

    minor_reflections = {
        _reflect_across_axis(
            point,
            expected.actual_angle_degrees + 90,
        )
        for point in centered
    }
    if minor_reflections != point_set:
        _fail(f"{label} is not minor-axis symmetric after GDS readback")

    if (
        _reflect_across_axis(centered[0], expected.actual_angle_degrees)
        != centered[0]
    ):
        _fail(f"{label} first vertex is not on the major axis after GDS readback")


def verify_oval_gds_readback_reflections(
    readbacks_by_angle: Mapping[int, Mapping[LayerTag, PolygonPoints]],
    layouts: Sequence[GeneratedLayout],
) -> None:
    """Verify the decoded 45/135 GDS coordinates as global-axis mirrors."""
    layouts_by_angle = {layout.logical_angle: layout for layout in layouts}
    if 45 not in readbacks_by_angle or 135 not in readbacks_by_angle:
        _fail("Oval GDS readback is missing the 45 or 135 Degree layout")
    if 45 not in layouts_by_angle or 135 not in layouts_by_angle:
        _fail("Oval layout set is missing the 45 or 135 Degree layout")

    readback_45 = readbacks_by_angle[45]
    readback_135 = readbacks_by_angle[135]
    if set(readback_45) != set(readback_135):
        _fail("45 and 135 Degree GDS readbacks have different Layer/Datatype sets")

    layout_45 = layouts_by_angle[45]
    layout_135 = layouts_by_angle[135]
    for tag in readback_45:
        points_45 = set(
            _centered_points(
                readback_45[tag],
                layout_45.common_center_dbu,
            )
        )
        points_135 = set(
            _centered_points(
                readback_135[tag],
                layout_135.common_center_dbu,
            )
        )
        label = f"Layer/Datatype {tag[0]}/{tag[1]}"
        if {(x, -y) for x, y in points_45} != points_135:
            _fail(
                f"{label}: 45 and 135 Degree GDS readbacks are not "
                "X-axis reflections"
            )
        if {(-x, y) for x, y in points_45} != points_135:
            _fail(
                f"{label}: 45 and 135 Degree GDS readbacks are not "
                "Y-axis reflections"
            )


def verify_gds(
    path: str | Path,
    config: ProjectConfig,
    expected: GeneratedLayout,
) -> GdsReadback:
    source = Path(path)
    library = read_gdstk_file(source, gdstk.read_gds)
    expected_precision = float(config.dbu_um * Decimal("1e-6"))
    if library.name != GDS_LIBRARY_NAME:
        _fail(
            f"{source.name}: expected Library {GDS_LIBRARY_NAME}, "
            f"found {library.name}"
        )
    if not math.isclose(library.unit, 1e-6, rel_tol=0, abs_tol=1e-18):
        _fail(f"{source.name}: unexpected User Unit {library.unit}")
    if not math.isclose(library.precision, expected_precision, rel_tol=1e-12, abs_tol=1e-18):
        _fail(f"{source.name}: unexpected DBU {library.precision}")
    if len(library.cells) != 1:
        _fail(f"{source.name}: expected one Cell, found {len(library.cells)}")
    top_cells = library.top_level()
    if len(top_cells) != 1:
        _fail(f"{source.name}: expected one top-level Cell, found {len(top_cells)}")
    cell = library.cells[0]
    if cell.name != expected.cell_name:
        _fail(f"{source.name}: expected Cell {expected.cell_name}, found {cell.name}")
    if len(cell.polygons) != len(expected.layers):
        _fail(f"{source.name}: expected {len(expected.layers)} polygons, found {len(cell.polygons)}")

    expected_by_tag = {
        (layer.definition.layer, layer.definition.datatype): layer
        for layer in expected.layers
    }
    readback: GdsReadback = {}
    required_vertices = 64 if config.shape_type is ShapeType.ROUND else 66
    for polygon in cell.polygons:
        tag = (polygon.layer, polygon.datatype)
        if tag not in expected_by_tag:
            _fail(f"{source.name}: unexpected Layer/Datatype {tag[0]}/{tag[1]}")
        expected_layer = expected_by_tag[tag]
        if polygon.size != required_vertices:
            _fail(
                f"{source.name}: Layer/Datatype {tag[0]}/{tag[1]} has "
                f"{polygon.size} vertices, expected {required_vertices}"
            )
        actual_points = tuple(
            (
                round(float(point[0]) / float(config.dbu_um)),
                round(float(point[1]) / float(config.dbu_um)),
            )
            for point in polygon.points
        )
        expected_points = expected_layer.points_dbu
        if actual_points != expected_points:
            _fail(
                f"{source.name}: coordinate or point-order mismatch on "
                f"Layer/Datatype {tag[0]}/{tag[1]}"
            )
        readback[tag] = actual_points
        if config.shape_type is ShapeType.OVAL:
            _verify_oval_polygon_symmetry(
                source,
                tag,
                actual_points,
                expected,
            )
    return readback
