from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path

from easybumpcell.domain.enums import ShapeType
from easybumpcell.domain.models import LayerDefinition, ProjectConfig
from easybumpcell.geometry.layout import GeneratedLayout, QuantizedLayer
from easybumpcell.geometry.quantization import BoundingBox, IntPoint, bounding_box


LEF_VERSION = "5.8"
LEF_PIN_NAME = "BUMP"
LEF_PIN_LAYER_SUFFIX = ".PIN"
LEF_LABEL_LAYER_SUFFIX = ".LABEL"
LEF_BOUNDARY_LAYER_NAME = "BOUNDARY"

_LEF_NUMBER_TOKEN = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)"
_LEF_NUMBER_RE = re.compile(_LEF_NUMBER_TOKEN)


@dataclass(frozen=True)
class LEFPreviewElements:
    definition: LayerDefinition
    pin_geometry: QuantizedLayer
    pin_layer_name: str
    label_layer_name: str
    boundary_layer_name: str
    label_text: str
    label_anchor_dbu: IntPoint
    boundary_dbu: BoundingBox


def _coordinate_um(value_dbu: int, dbu_um: Decimal) -> Decimal:
    return Decimal(value_dbu) * dbu_um


def format_lef_decimal(value: Decimal) -> str:
    if not value:
        return "0"
    text = format(value, "f")
    return text.rstrip("0").rstrip(".") if "." in text else text


def format_lef_macro_decimal(value: Decimal) -> str:
    text = format(value, "f")
    integer, separator, fraction = text.partition(".")
    if not separator:
        return f"{integer}.000"
    fraction = fraction.rstrip("0")
    return f"{integer}.{fraction.ljust(3, '0')}"


def _lef_polygon_points_um(
    text: str,
) -> tuple[tuple[Decimal, Decimal], ...]:
    polygon_match = re.search(
        r"^\s*POLYGON\s*(.*?)\s*;",
        text,
        flags=re.MULTILINE | re.DOTALL,
    )
    if polygon_match is None:
        raise ValueError(
            "LEF boundary validation failed: missing or invalid PIN POLYGON"
        )
    numbers = [
        Decimal(value)
        for value in _LEF_NUMBER_RE.findall(polygon_match.group(1))
    ]
    if len(numbers) < 6 or len(numbers) % 2:
        raise ValueError(
            "LEF boundary validation failed: PIN POLYGON coordinates are incomplete"
        )
    return tuple(zip(numbers[0::2], numbers[1::2]))


def _lef_points_dbu(
    text: str,
    dbu_um: Decimal,
) -> tuple[IntPoint, ...]:
    dbu = Decimal(dbu_um)
    if dbu <= 0:
        raise ValueError(
            "LEF preview validation failed: Process DBU must be positive"
        )
    points_dbu: list[IntPoint] = []
    for x_um, y_um in _lef_polygon_points_um(text):
        x_dbu = x_um / dbu
        y_dbu = y_um / dbu
        if (
            x_dbu != x_dbu.to_integral_value()
            or y_dbu != y_dbu.to_integral_value()
        ):
            raise ValueError(
                "LEF preview validation failed: PIN POLYGON is not aligned "
                "to Process DBU"
            )
        points_dbu.append((int(x_dbu), int(y_dbu)))
    return tuple(points_dbu)


def lef_boundary_from_text(
    text: str,
    dbu_um: Decimal,
) -> BoundingBox:
    """Build the macro boundary from LEF ORIGIN and SIZE.

    LEF PIN coordinates are relative to the macro origin. ORIGIN locates that
    origin from the placement-boundary lower-left, so the boundary in PIN
    coordinates is (-origin_x, -origin_y) to
    (width - origin_x, height - origin_y).
    """
    origin_match = re.search(
        (
            rf"^\s*ORIGIN\s+({_LEF_NUMBER_TOKEN})\s+"
            rf"({_LEF_NUMBER_TOKEN})\s*;"
        ),
        text,
        flags=re.MULTILINE,
    )
    if origin_match is None:
        raise ValueError(
            "LEF boundary validation failed: missing or invalid ORIGIN statement"
        )
    origin_x_um = Decimal(origin_match.group(1))
    origin_y_um = Decimal(origin_match.group(2))

    size_match = re.search(
        (
            rf"^\s*SIZE\s+({_LEF_NUMBER_TOKEN})\s+BY\s+"
            rf"({_LEF_NUMBER_TOKEN})\s*;"
        ),
        text,
        flags=re.MULTILINE,
    )
    if size_match is None:
        raise ValueError(
            "LEF boundary validation failed: missing or invalid SIZE statement"
        )
    width_um = Decimal(size_match.group(1))
    height_um = Decimal(size_match.group(2))
    if width_um <= 0 or height_um <= 0:
        raise ValueError(
            "LEF boundary validation failed: SIZE dimensions must be positive"
        )

    points = _lef_polygon_points_um(text)
    polygon_bounds = (
        min(point[0] for point in points),
        min(point[1] for point in points),
        max(point[0] for point in points),
        max(point[1] for point in points),
    )
    expected_bounds = (
        -origin_x_um,
        -origin_y_um,
        width_um - origin_x_um,
        height_um - origin_y_um,
    )
    if polygon_bounds != expected_bounds:
        raise ValueError(
            "LEF boundary validation failed: "
            f"ORIGIN {origin_x_um} {origin_y_um} with "
            f"SIZE {width_um} BY {height_um} defines PIN POLYGON bounds "
            f"{expected_bounds}, but found {polygon_bounds}"
        )

    dbu = Decimal(dbu_um)
    if dbu <= 0:
        raise ValueError(
            "LEF boundary validation failed: Process DBU must be positive"
        )
    bounds_dbu = tuple(value / dbu for value in expected_bounds)
    if any(
        value != value.to_integral_value()
        for value in bounds_dbu
    ):
        raise ValueError(
            "LEF boundary validation failed: ORIGIN/SIZE boundary is not aligned "
            "to Process DBU"
        )
    return BoundingBox(
        *(int(value) for value in bounds_dbu),
    )


def al_pad_geometry(
    config: ProjectConfig,
    layout: GeneratedLayout,
) -> tuple[LayerDefinition, QuantizedLayer]:
    definition = config.al_pad_layer()
    if definition is None:
        raise ValueError("Select the Al Pad Layer for LEF output")
    geometry = next(
        (
            layer
            for layer in layout.layers
            if layer.definition.uid == definition.uid
        ),
        None,
    )
    if geometry is None:
        raise ValueError(
            f"Al Pad Layer {definition.meaning!r} is missing from {layout.cell_name}"
        )
    return definition, geometry


def lef_preview_elements(
    config: ProjectConfig,
    layout: GeneratedLayout,
    *,
    lef_definition: str | None = None,
) -> LEFPreviewElements:
    """Parse the three preview objects from one serialized LEF definition.

    Live preview serializes the current macro first. Export reports pass the
    exact LEF file contents. PIN, LABEL anchor and BOUNDARY therefore share one
    LEF source instead of independently recreating geometry from GDS rules.
    """
    definition, _ = al_pad_geometry(config, layout)
    source = (
        lef_definition
        if lef_definition is not None
        else lef_text(config, layout)
    )
    layer_match = re.search(
        r"^\s*LAYER\s+(\S+)\s*;",
        source,
        flags=re.MULTILINE,
    )
    if layer_match is None:
        raise ValueError("LEF preview validation failed: missing PIN LAYER")
    pin_match = re.search(
        r"^\s*PIN\s+(\S+)\s*$",
        source,
        flags=re.MULTILINE,
    )
    if pin_match is None:
        raise ValueError("LEF preview validation failed: missing PIN name")
    points_dbu = _lef_points_dbu(source, config.dbu_um)
    pin_geometry = QuantizedLayer(
        definition=definition,
        points_dbu=points_dbu,
        bbox_dbu=bounding_box(points_dbu),
    )
    boundary = lef_boundary_from_text(
        source,
        config.dbu_um,
    )
    layer_name = layer_match.group(1)
    pin_name = pin_match.group(1)
    return LEFPreviewElements(
        definition=definition,
        pin_geometry=pin_geometry,
        pin_layer_name=f"{layer_name}{LEF_PIN_LAYER_SUFFIX}",
        label_layer_name=f"{layer_name}{LEF_LABEL_LAYER_SUFFIX}",
        boundary_layer_name=LEF_BOUNDARY_LAYER_NAME,
        label_text=pin_name,
        label_anchor_dbu=points_dbu[0],
        boundary_dbu=boundary,
    )


def _symmetry_statement(
    config: ProjectConfig,
    layout: GeneratedLayout,
) -> str | None:
    if config.shape_type is ShapeType.ROUND:
        return "  SYMMETRY X Y R90 ;"
    normalized_angle = layout.actual_angle_degrees % 180
    if normalized_angle in (0, 90):
        return "  SYMMETRY X Y ;"
    return None


def lef_text(config: ProjectConfig, layout: GeneratedLayout) -> str:
    definition, geometry = al_pad_geometry(config, layout)
    bbox = geometry.bbox_dbu
    minimum_x = _coordinate_um(bbox.min_x, config.dbu_um)
    minimum_y = _coordinate_um(bbox.min_y, config.dbu_um)
    origin_x = -minimum_x
    origin_y = -minimum_y
    width = _coordinate_um(bbox.width, config.dbu_um)
    height = _coordinate_um(bbox.height, config.dbu_um)

    lines = [
        f"VERSION {LEF_VERSION} ;",
        'BUSBITCHARS "[]" ;',
        'DIVIDERCHAR "/" ;',
        "",
        f"MACRO {layout.cell_name}",
        "  CLASS COVER BUMP ;",
        (
            f"  FOREIGN {layout.cell_name} "
            f"{format_lef_macro_decimal(minimum_x)} "
            f"{format_lef_macro_decimal(minimum_y)} ;"
        ),
        (
            f"  ORIGIN {format_lef_macro_decimal(origin_x)} "
            f"{format_lef_macro_decimal(origin_y)} ;"
        ),
        "",
        (
            f"  SIZE {format_lef_macro_decimal(width)} BY "
            f"{format_lef_macro_decimal(height)} ;"
        ),
    ]
    symmetry = _symmetry_statement(config, layout)
    if symmetry is not None:
        lines.append(symmetry)
    lines.extend(
        [
            f"  PIN {LEF_PIN_NAME}",
            "    DIRECTION INOUT ;",
            "    USE SIGNAL ;",
            "    PORT",
            f"      LAYER {definition.meaning} ;",
        ]
    )

    polygon = " ".join(
        (
            f"{format_lef_decimal(_coordinate_um(x, config.dbu_um))} "
            f"{format_lef_decimal(_coordinate_um(y, config.dbu_um))}"
        )
        for x, y in geometry.points_dbu
    )
    lines.append(f"        POLYGON {polygon} ;")
    lines.extend(
        [
            "    END",
            f"  END {LEF_PIN_NAME}",
            f"END {layout.cell_name}",
            "",
            "END LIBRARY",
            "",
        ]
    )
    return "\n".join(lines)


def write_lef(
    path: str | Path,
    config: ProjectConfig,
    layout: GeneratedLayout,
) -> Path:
    destination = Path(path)
    destination.write_text(
        lef_text(config, layout),
        encoding="ascii",
        newline="\n",
    )
    return destination
