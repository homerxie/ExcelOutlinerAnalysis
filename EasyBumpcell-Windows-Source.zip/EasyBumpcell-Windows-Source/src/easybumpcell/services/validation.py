from __future__ import annotations

from decimal import Decimal, InvalidOperation

from easybumpcell.dimensions import dimension_decimal
from easybumpcell.domain.enums import IssueLevel, ShapeType
from easybumpcell.domain.models import (
    MAX_GDS_DATATYPE,
    MAX_GDS_LAYER_NUMBER,
    ProjectConfig,
    ValidationIssue,
)
from easybumpcell.services.naming import (
    MAX_CELL_NAME_LENGTH,
    MAX_FILE_NAME_LENGTH,
    OVAL_ANGLES,
    gds_file_name,
    generated_names,
    lef_file_name,
    report_name,
    validate_bump_type,
    validate_layer_name,
    validate_token,
    validate_version,
)
from easybumpcell.preview_patterns import PATTERN_LABELS


def _error(code: str, message: str, layer_uid: str | None = None) -> ValidationIssue:
    return ValidationIssue(IssueLevel.ERROR, code, message, layer_uid)


def _warning(code: str, message: str, layer_uid: str | None = None) -> ValidationIssue:
    return ValidationIssue(IssueLevel.WARNING, code, message, layer_uid)


def validate_project(config: ProjectConfig, *, for_export: bool = True) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    try:
        validate_token(config.technology_name, "Technology Name")
    except ValueError as exc:
        issues.append(_error("technology_name", str(exc)))
    try:
        validate_bump_type(config.bump_type)
    except ValueError as exc:
        issues.append(_error("bump_type", str(exc)))
    try:
        validate_version(config.version)
    except ValueError as exc:
        issues.append(_error("version", str(exc)))

    if not config.layers:
        issues.append(_error("layers_empty", "At least one layer is required"))
    if not config.tapeout_layers():
        issues.append(
            _error("tapeout_layers_empty", "At least one Tapeout layer is required")
        )

    meanings: set[str] = set()
    layer_pairs: set[tuple[int, int]] = set()
    for layer in config.layers:
        try:
            validate_layer_name(layer.meaning)
        except ValueError as exc:
            issues.append(_error("layer_meaning", str(exc), layer.uid))
        if layer.meaning in meanings:
            issues.append(
                _error(
                    "duplicate_meaning",
                    f"Duplicate Layer Name: {layer.meaning}",
                    layer.uid,
                )
            )
        meanings.add(layer.meaning)

        if layer.preview_pattern not in PATTERN_LABELS:
            issues.append(
                _error(
                    "preview_pattern",
                    f"{layer.meaning}: unsupported preview pattern {layer.preview_pattern!r}",
                    layer.uid,
                )
            )

        if (
            type(layer.layer) is not int
            or not 0 <= layer.layer <= MAX_GDS_LAYER_NUMBER
        ):
            issues.append(
                _error(
                    "layer_number",
                    f"{layer.meaning}: Layer Number must be an integer "
                    f"from 0 to {MAX_GDS_LAYER_NUMBER}",
                    layer.uid,
                )
            )
        if (
            type(layer.datatype) is not int
            or not 0 <= layer.datatype <= MAX_GDS_DATATYPE
        ):
            issues.append(
                _error(
                    "datatype",
                    f"{layer.meaning}: Datatype must be an integer "
                    f"from 0 to {MAX_GDS_DATATYPE}",
                    layer.uid,
                )
            )
        if type(layer.layer) is int and type(layer.datatype) is int:
            pair = (layer.layer, layer.datatype)
            if pair in layer_pairs:
                issues.append(_error("duplicate_layer_pair", f"Duplicate Layer Number/Datatype: {pair[0]}/{pair[1]}", layer.uid))
            layer_pairs.add(pair)

        if config.shape_type is ShapeType.ROUND:
            try:
                dimension_decimal(
                    layer.diameter_um,
                    f"{layer.meaning} Diameter",
                )
            except ValueError as exc:
                issues.append(_error("diameter", str(exc), layer.uid))
        else:
            minor_axis = None
            major_axis = None
            try:
                minor_axis = dimension_decimal(
                    layer.minor_axis_um,
                    f"{layer.meaning} Minor Axis",
                )
            except ValueError as exc:
                issues.append(_error("minor_axis", str(exc), layer.uid))
            try:
                major_axis = dimension_decimal(
                    layer.major_axis_um,
                    f"{layer.meaning} Major Axis",
                )
            except ValueError as exc:
                issues.append(_error("major_axis", str(exc), layer.uid))
            if (
                minor_axis is not None
                and major_axis is not None
                and major_axis <= minor_axis
            ):
                issues.append(_error("axis_order", f"{layer.meaning}: Major Axis must be greater than Minor Axis", layer.uid))

    try:
        dbu = Decimal(config.dbu_um)
        if not dbu.is_finite() or dbu <= 0:
            raise InvalidOperation
    except (InvalidOperation, ValueError, TypeError):
        issues.append(_error("dbu", "Process DBU must be a positive finite value"))

    if config.reference_layer() is None:
        issues.append(_error("origin_reference", "The origin reference layer does not exist"))
    if config.al_pad_layer() is None:
        issue = (
            _error(
                "al_pad_layer",
                "Select the Al Pad Layer for LEF output",
            )
            if for_export
            else _warning(
                "al_pad_layer",
                "Select the Al Pad Layer below the Layer table before export",
            )
        )
        issues.append(issue)
    if for_export and not config.process_order_confirmed:
        issues.append(_error("process_order", "Confirm the layer process order before export"))

    if not any(issue.level is IssueLevel.ERROR for issue in issues):
        try:
            cell_names = generated_names(config)
            over_limit = [
                name for name in cell_names if len(name) > MAX_CELL_NAME_LENGTH
            ]
            if over_limit:
                issues.append(
                    _error(
                        "cell_name_length",
                        (
                            f"{len(over_limit)} generated Cell name(s) exceed the "
                            f"{MAX_CELL_NAME_LENGTH}-character limit "
                            f"(maximum {max(map(len, over_limit))})"
                        ),
                    )
                )
            legacy_names = [name for name in cell_names if len(name) > 32]
            if config.strict_legacy_gdsii_compatibility and legacy_names:
                issues.append(
                    _warning(
                        "long_cell_name",
                        (
                            f"{len(legacy_names)} generated Cell name(s) exceed 32 characters "
                            f"(maximum {max(map(len, legacy_names))}); some legacy GDS tools may reject them"
                        ),
                    )
                )
            logical_angles = (
                (0,) if config.shape_type is ShapeType.ROUND else OVAL_ANGLES
            )
            file_names = [
                *(gds_file_name(config, angle) for angle in logical_angles),
                *(lef_file_name(config, angle) for angle in logical_angles),
                report_name(config),
            ]
            overlong_files = [
                name for name in file_names if len(name) > MAX_FILE_NAME_LENGTH
            ]
            if overlong_files:
                issues.append(
                    _error(
                        "file_name_length",
                        (
                            f"{len(overlong_files)} output file name(s) exceed the "
                            f"{MAX_FILE_NAME_LENGTH}-character limit "
                            f"(maximum {max(map(len, overlong_files))})"
                        ),
                    )
                )
        except ValueError as exc:
            issues.append(_error("naming", str(exc)))
    return issues


def has_errors(issues: list[ValidationIssue]) -> bool:
    return any(issue.level is IssueLevel.ERROR for issue in issues)
