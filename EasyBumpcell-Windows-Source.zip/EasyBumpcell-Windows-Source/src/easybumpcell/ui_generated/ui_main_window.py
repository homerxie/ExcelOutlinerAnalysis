# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_window.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox,
    QFormLayout, QFrame, QGridLayout, QGroupBox,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QMainWindow, QMenu, QMenuBar, QPlainTextEdit,
    QPushButton, QSizePolicy, QSpacerItem, QSplitter,
    QTabWidget, QTableView, QToolButton, QVBoxLayout,
    QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1380, 820)
        MainWindow.setMinimumSize(QSize(1280, 820))
        self.englishAction = QAction(MainWindow)
        self.englishAction.setObjectName(u"englishAction")
        self.englishAction.setCheckable(True)
        self.englishAction.setChecked(True)
        self.englishAction.setText(u"English")
        self.simplifiedChineseAction = QAction(MainWindow)
        self.simplifiedChineseAction.setObjectName(u"simplifiedChineseAction")
        self.simplifiedChineseAction.setCheckable(True)
        self.simplifiedChineseAction.setText(u"\u7b80\u4f53\u4e2d\u6587")
        self.advancedSettingsAction = QAction(MainWindow)
        self.advancedSettingsAction.setObjectName(u"advancedSettingsAction")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.mainLayout = QHBoxLayout(self.centralwidget)
        self.mainLayout.setSpacing(12)
        self.mainLayout.setObjectName(u"mainLayout")
        self.mainLayout.setContentsMargins(12, 12, 12, 12)
        self.mainSplitter = QSplitter(self.centralwidget)
        self.mainSplitter.setObjectName(u"mainSplitter")
        self.mainSplitter.setOrientation(Qt.Orientation.Horizontal)
        self.mainSplitter.setChildrenCollapsible(False)
        self.controlPanel = QWidget(self.mainSplitter)
        self.controlPanel.setObjectName(u"controlPanel")
        self.controlPanel.setMinimumSize(QSize(640, 0))
        self.controlLayout = QVBoxLayout(self.controlPanel)
        self.controlLayout.setSpacing(10)
        self.controlLayout.setObjectName(u"controlLayout")
        self.controlLayout.setContentsMargins(0, 0, 0, 0)
        self.templateGroup = QGroupBox(self.controlPanel)
        self.templateGroup.setObjectName(u"templateGroup")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.templateGroup.sizePolicy().hasHeightForWidth())
        self.templateGroup.setSizePolicy(sizePolicy)
        self.templateLayout = QHBoxLayout(self.templateGroup)
        self.templateLayout.setSpacing(6)
        self.templateLayout.setObjectName(u"templateLayout")
        self.templateCombo = QComboBox(self.templateGroup)
        self.templateCombo.setObjectName(u"templateCombo")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.templateCombo.sizePolicy().hasHeightForWidth())
        self.templateCombo.setSizePolicy(sizePolicy1)
        self.templateCombo.setMinimumSize(QSize(160, 0))

        self.templateLayout.addWidget(self.templateCombo)

        self.saveTemplateButton = QPushButton(self.templateGroup)
        self.saveTemplateButton.setObjectName(u"saveTemplateButton")

        self.templateLayout.addWidget(self.saveTemplateButton)

        self.deleteTemplateButton = QPushButton(self.templateGroup)
        self.deleteTemplateButton.setObjectName(u"deleteTemplateButton")

        self.templateLayout.addWidget(self.deleteTemplateButton)

        self.importTemplateButton = QPushButton(self.templateGroup)
        self.importTemplateButton.setObjectName(u"importTemplateButton")

        self.templateLayout.addWidget(self.importTemplateButton)

        self.exportTemplateButton = QPushButton(self.templateGroup)
        self.exportTemplateButton.setObjectName(u"exportTemplateButton")

        self.templateLayout.addWidget(self.exportTemplateButton)


        self.controlLayout.addWidget(self.templateGroup)

        self.projectGroup = QGroupBox(self.controlPanel)
        self.projectGroup.setObjectName(u"projectGroup")
        sizePolicy.setHeightForWidth(self.projectGroup.sizePolicy().hasHeightForWidth())
        self.projectGroup.setSizePolicy(sizePolicy)
        self.projectGrid = QGridLayout(self.projectGroup)
        self.projectGrid.setObjectName(u"projectGrid")
        self.projectGrid.setHorizontalSpacing(6)
        self.projectGrid.setVerticalSpacing(6)
        self.technologyLabel = QLabel(self.projectGroup)
        self.technologyLabel.setObjectName(u"technologyLabel")

        self.projectGrid.addWidget(self.technologyLabel, 0, 0, 1, 1)

        self.technologyEdit = QLineEdit(self.projectGroup)
        self.technologyEdit.setObjectName(u"technologyEdit")

        self.projectGrid.addWidget(self.technologyEdit, 0, 1, 1, 1)

        self.bumpTypeLabel = QLabel(self.projectGroup)
        self.bumpTypeLabel.setObjectName(u"bumpTypeLabel")

        self.projectGrid.addWidget(self.bumpTypeLabel, 0, 2, 1, 1)

        self.bumpTypeEdit = QLineEdit(self.projectGroup)
        self.bumpTypeEdit.setObjectName(u"bumpTypeEdit")

        self.projectGrid.addWidget(self.bumpTypeEdit, 0, 3, 1, 1)

        self.versionLabel = QLabel(self.projectGroup)
        self.versionLabel.setObjectName(u"versionLabel")

        self.projectGrid.addWidget(self.versionLabel, 1, 0, 1, 1)

        self.versionEdit = QLineEdit(self.projectGroup)
        self.versionEdit.setObjectName(u"versionEdit")

        self.projectGrid.addWidget(self.versionEdit, 1, 1, 1, 1)

        self.shapeLabel = QLabel(self.projectGroup)
        self.shapeLabel.setObjectName(u"shapeLabel")

        self.projectGrid.addWidget(self.shapeLabel, 1, 2, 1, 1)

        self.shapeCombo = QComboBox(self.projectGroup)
        self.shapeCombo.addItem("")
        self.shapeCombo.addItem("")
        self.shapeCombo.setObjectName(u"shapeCombo")

        self.projectGrid.addWidget(self.shapeCombo, 1, 3, 1, 1)

        self.dbuLabel = QLabel(self.projectGroup)
        self.dbuLabel.setObjectName(u"dbuLabel")

        self.projectGrid.addWidget(self.dbuLabel, 2, 0, 1, 1)

        self.dbuCombo = QComboBox(self.projectGroup)
        self.dbuCombo.addItem("")
        self.dbuCombo.addItem("")
        self.dbuCombo.setObjectName(u"dbuCombo")

        self.projectGrid.addWidget(self.dbuCombo, 2, 1, 1, 1)

        self.dbuWarningLayout = QHBoxLayout()
        self.dbuWarningLayout.setSpacing(6)
        self.dbuWarningLayout.setObjectName(u"dbuWarningLayout")
        self.dbuHelpButton = QToolButton(self.projectGroup)
        self.dbuHelpButton.setObjectName(u"dbuHelpButton")
        self.dbuHelpButton.setMinimumSize(QSize(24, 24))
        self.dbuHelpButton.setMaximumSize(QSize(24, 24))
        self.dbuHelpButton.setStyleSheet(u"QToolButton {\n"
"    color: #7A5200;\n"
"    background: #FFF6D8;\n"
"    border: 1px solid #E6C86E;\n"
"    border-radius: 11px;\n"
"    font-weight: bold;\n"
"}")
        self.dbuHelpButton.setText(u"?")

        self.dbuWarningLayout.addWidget(self.dbuHelpButton, 0, Qt.AlignmentFlag.AlignTop)

        self.dbuHintLabel = QLabel(self.projectGroup)
        self.dbuHintLabel.setObjectName(u"dbuHintLabel")
        self.dbuHintLabel.setStyleSheet(u"color: #7A5200; background: #FFF6D8; border: 1px solid #E6C86E; padding: 6px;")
        self.dbuHintLabel.setText(u"")
        self.dbuHintLabel.setWordWrap(True)
        self.dbuHintLabel.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByKeyboard|Qt.TextInteractionFlag.TextSelectableByMouse)

        self.dbuWarningLayout.addWidget(self.dbuHintLabel)


        self.projectGrid.addLayout(self.dbuWarningLayout, 3, 0, 1, 4)

        self.projectGrid.setColumnStretch(1, 1)
        self.projectGrid.setColumnStretch(3, 1)

        self.controlLayout.addWidget(self.projectGroup)

        self.layersGroup = QGroupBox(self.controlPanel)
        self.layersGroup.setObjectName(u"layersGroup")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(1)
        sizePolicy2.setHeightForWidth(self.layersGroup.sizePolicy().hasHeightForWidth())
        self.layersGroup.setSizePolicy(sizePolicy2)
        self.layersLayout = QVBoxLayout(self.layersGroup)
        self.layersLayout.setSpacing(6)
        self.layersLayout.setObjectName(u"layersLayout")
        self.processWarningLayout = QHBoxLayout()
        self.processWarningLayout.setSpacing(6)
        self.processWarningLayout.setObjectName(u"processWarningLayout")
        self.layerMappingHelpButton = QToolButton(self.layersGroup)
        self.layerMappingHelpButton.setObjectName(u"layerMappingHelpButton")
        self.layerMappingHelpButton.setMinimumSize(QSize(24, 24))
        self.layerMappingHelpButton.setMaximumSize(QSize(24, 24))
        self.layerMappingHelpButton.setStyleSheet(u"QToolButton {\n"
"    color: #7A5200;\n"
"    background: #FFF6D8;\n"
"    border: 1px solid #E6C86E;\n"
"    border-radius: 11px;\n"
"    font-weight: bold;\n"
"}")
        self.layerMappingHelpButton.setText(u"?")

        self.processWarningLayout.addWidget(self.layerMappingHelpButton, 0, Qt.AlignmentFlag.AlignTop)

        self.processHintLabel = QLabel(self.layersGroup)
        self.processHintLabel.setObjectName(u"processHintLabel")
        self.processHintLabel.setStyleSheet(u"color: #7A5200; background: #FFF6D8; border: 1px solid #E6C86E; padding: 6px;")
        self.processHintLabel.setText(u"")
        self.processHintLabel.setWordWrap(True)
        self.processHintLabel.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByKeyboard|Qt.TextInteractionFlag.TextSelectableByMouse)

        self.processWarningLayout.addWidget(self.processHintLabel)


        self.layersLayout.addLayout(self.processWarningLayout)

        self.layerTable = QTableView(self.layersGroup)
        self.layerTable.setObjectName(u"layerTable")
        self.layerTable.setAlternatingRowColors(True)
        self.layerTable.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.layerTable.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.layerTable.setDragEnabled(True)
        self.layerTable.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.layerTable.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.layerTable.setDropIndicatorShown(True)
        self.layerTable.setSortingEnabled(False)

        self.layersLayout.addWidget(self.layerTable)

        self.alPadSelectionLayout = QHBoxLayout()
        self.alPadSelectionLayout.setSpacing(8)
        self.alPadSelectionLayout.setObjectName(u"alPadSelectionLayout")
        self.alPadLayerLabel = QLabel(self.layersGroup)
        self.alPadLayerLabel.setObjectName(u"alPadLayerLabel")
        self.alPadLayerLabel.setMaximumSize(QSize(16777215, 30))

        self.alPadSelectionLayout.addWidget(self.alPadLayerLabel)

        self.alPadLayerCombo = QComboBox(self.layersGroup)
        self.alPadLayerCombo.setObjectName(u"alPadLayerCombo")
        sizePolicy1.setHeightForWidth(self.alPadLayerCombo.sizePolicy().hasHeightForWidth())
        self.alPadLayerCombo.setSizePolicy(sizePolicy1)
        self.alPadLayerCombo.setMinimumSize(QSize(220, 0))

        self.alPadSelectionLayout.addWidget(self.alPadLayerCombo)


        self.layersLayout.addLayout(self.alPadSelectionLayout)

        self.layerButtonLayout = QHBoxLayout()
        self.layerButtonLayout.setObjectName(u"layerButtonLayout")
        self.addLayerButton = QPushButton(self.layersGroup)
        self.addLayerButton.setObjectName(u"addLayerButton")

        self.layerButtonLayout.addWidget(self.addLayerButton)

        self.deleteLayerButton = QPushButton(self.layersGroup)
        self.deleteLayerButton.setObjectName(u"deleteLayerButton")

        self.layerButtonLayout.addWidget(self.deleteLayerButton)

        self.resetLayersButton = QPushButton(self.layersGroup)
        self.resetLayersButton.setObjectName(u"resetLayersButton")

        self.layerButtonLayout.addWidget(self.resetLayersButton)

        self.layerButtonSpacer = QSpacerItem(20, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.layerButtonLayout.addItem(self.layerButtonSpacer)

        self.confirmOrderButton = QPushButton(self.layersGroup)
        self.confirmOrderButton.setObjectName(u"confirmOrderButton")

        self.layerButtonLayout.addWidget(self.confirmOrderButton)


        self.layersLayout.addLayout(self.layerButtonLayout)


        self.controlLayout.addWidget(self.layersGroup)

        self.summaryGroup = QGroupBox(self.controlPanel)
        self.summaryGroup.setObjectName(u"summaryGroup")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.summaryGroup.sizePolicy().hasHeightForWidth())
        self.summaryGroup.setSizePolicy(sizePolicy3)
        self.summaryLayout = QVBoxLayout(self.summaryGroup)
        self.summaryLayout.setSpacing(0)
        self.summaryLayout.setObjectName(u"summaryLayout")
        self.summaryForm = QFormLayout()
        self.summaryForm.setObjectName(u"summaryForm")
        self.summaryForm.setVerticalSpacing(4)
        self.summaryForm.setHorizontalSpacing(10)
        self.summaryForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.summaryForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.summaryForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.generatedNameCaption = QLabel(self.summaryGroup)
        self.generatedNameCaption.setObjectName(u"generatedNameCaption")

        self.summaryForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.generatedNameCaption)

        self.generatedNameLabel = QLabel(self.summaryGroup)
        self.generatedNameLabel.setObjectName(u"generatedNameLabel")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        sizePolicy4.setHorizontalStretch(1)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.generatedNameLabel.sizePolicy().hasHeightForWidth())
        self.generatedNameLabel.setSizePolicy(sizePolicy4)
        self.generatedNameLabel.setMaximumSize(QSize(16777215, 24))
        self.generatedNameLabel.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.generatedNameLabel.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.generatedNameLabel.setWordWrap(False)

        self.summaryForm.setWidget(0, QFormLayout.ItemRole.FieldRole, self.generatedNameLabel)

        self.nodeCountCaption = QLabel(self.summaryGroup)
        self.nodeCountCaption.setObjectName(u"nodeCountCaption")

        self.summaryForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.nodeCountCaption)

        self.nodeCountLabel = QLabel(self.summaryGroup)
        self.nodeCountLabel.setObjectName(u"nodeCountLabel")
        sizePolicy1.setHeightForWidth(self.nodeCountLabel.sizePolicy().hasHeightForWidth())
        self.nodeCountLabel.setSizePolicy(sizePolicy1)
        self.nodeCountLabel.setMaximumSize(QSize(16777215, 24))
        self.nodeCountLabel.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)

        self.summaryForm.setWidget(1, QFormLayout.ItemRole.FieldRole, self.nodeCountLabel)

        self.settingsCaption = QLabel(self.summaryGroup)
        self.settingsCaption.setObjectName(u"settingsCaption")

        self.summaryForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.settingsCaption)

        self.settingsSummaryLabel = QLabel(self.summaryGroup)
        self.settingsSummaryLabel.setObjectName(u"settingsSummaryLabel")
        sizePolicy1.setHeightForWidth(self.settingsSummaryLabel.sizePolicy().hasHeightForWidth())
        self.settingsSummaryLabel.setSizePolicy(sizePolicy1)
        self.settingsSummaryLabel.setMaximumSize(QSize(16777215, 24))
        self.settingsSummaryLabel.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)

        self.summaryForm.setWidget(2, QFormLayout.ItemRole.FieldRole, self.settingsSummaryLabel)

        self.validationCaption = QLabel(self.summaryGroup)
        self.validationCaption.setObjectName(u"validationCaption")
        self.validationCaption.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)

        self.summaryForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.validationCaption)

        self.validationText = QPlainTextEdit(self.summaryGroup)
        self.validationText.setObjectName(u"validationText")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy5.setHorizontalStretch(1)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.validationText.sizePolicy().hasHeightForWidth())
        self.validationText.setSizePolicy(sizePolicy5)
        self.validationText.setMinimumSize(QSize(0, 54))
        self.validationText.setMaximumSize(QSize(16777215, 54))
        self.validationText.setStyleSheet(u"QPlainTextEdit {\n"
"    border: none;\n"
"    background: transparent;\n"
"    padding: 0px;\n"
"}")
        self.validationText.setFrameShape(QFrame.Shape.NoFrame)
        self.validationText.setReadOnly(True)

        self.summaryForm.setWidget(3, QFormLayout.ItemRole.FieldRole, self.validationText)


        self.summaryLayout.addLayout(self.summaryForm)


        self.controlLayout.addWidget(self.summaryGroup)

        self.actionLayout = QHBoxLayout()
        self.actionLayout.setObjectName(u"actionLayout")
        self.actionSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.actionLayout.addItem(self.actionSpacer)

        self.exportButton = QPushButton(self.controlPanel)
        self.exportButton.setObjectName(u"exportButton")

        self.actionLayout.addWidget(self.exportButton)


        self.controlLayout.addLayout(self.actionLayout)

        self.mainSplitter.addWidget(self.controlPanel)
        self.previewPanel = QWidget(self.mainSplitter)
        self.previewPanel.setObjectName(u"previewPanel")
        self.previewPanel.setMinimumSize(QSize(440, 0))
        self.previewPanelLayout = QVBoxLayout(self.previewPanel)
        self.previewPanelLayout.setObjectName(u"previewPanelLayout")
        self.previewPanelLayout.setContentsMargins(0, 0, 0, 0)
        self.previewTabs = QTabWidget(self.previewPanel)
        self.previewTabs.setObjectName(u"previewTabs")
        self.gdsPreviewTab = QWidget()
        self.gdsPreviewTab.setObjectName(u"gdsPreviewTab")
        self.gdsPreviewTabLayout = QVBoxLayout(self.gdsPreviewTab)
        self.gdsPreviewTabLayout.setObjectName(u"gdsPreviewTabLayout")
        self.gdsPreviewTabLayout.setContentsMargins(8, 8, 8, 8)
        self.previewHeaderLayout = QHBoxLayout()
        self.previewHeaderLayout.setSpacing(12)
        self.previewHeaderLayout.setObjectName(u"previewHeaderLayout")
        self.previewTitleLabel = QLabel(self.gdsPreviewTab)
        self.previewTitleLabel.setObjectName(u"previewTitleLabel")
        sizePolicy.setHeightForWidth(self.previewTitleLabel.sizePolicy().hasHeightForWidth())
        self.previewTitleLabel.setSizePolicy(sizePolicy)
        self.previewTitleLabel.setMaximumSize(QSize(16777215, 30))
        self.previewTitleLabel.setStyleSheet(u"font-size: 15px; font-weight: 600;")

        self.previewHeaderLayout.addWidget(self.previewTitleLabel)

        self.previewHeaderSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.previewHeaderLayout.addItem(self.previewHeaderSpacer)

        self.nodeControlsWidget = QWidget(self.gdsPreviewTab)
        self.nodeControlsWidget.setObjectName(u"nodeControlsWidget")
        self.nodeControlsLayout = QHBoxLayout(self.nodeControlsWidget)
        self.nodeControlsLayout.setSpacing(12)
        self.nodeControlsLayout.setObjectName(u"nodeControlsLayout")
        self.nodeControlsLayout.setContentsMargins(0, 0, 8, 0)
        self.showNodesCheck = QCheckBox(self.nodeControlsWidget)
        self.showNodesCheck.setObjectName(u"showNodesCheck")
        self.showNodesCheck.setChecked(True)

        self.nodeControlsLayout.addWidget(self.showNodesCheck)

        self.snapNodesCheck = QCheckBox(self.nodeControlsWidget)
        self.snapNodesCheck.setObjectName(u"snapNodesCheck")
        self.snapNodesCheck.setChecked(True)

        self.nodeControlsLayout.addWidget(self.snapNodesCheck)


        self.previewHeaderLayout.addWidget(self.nodeControlsWidget)


        self.gdsPreviewTabLayout.addLayout(self.previewHeaderLayout)

        self.previewContainer = QWidget(self.gdsPreviewTab)
        self.previewContainer.setObjectName(u"previewContainer")
        self.previewContainerLayout = QVBoxLayout(self.previewContainer)
        self.previewContainerLayout.setObjectName(u"previewContainerLayout")
        self.previewContainerLayout.setContentsMargins(0, 0, 0, 0)

        self.gdsPreviewTabLayout.addWidget(self.previewContainer)

        self.previewTabs.addTab(self.gdsPreviewTab, "")
        self.lefPreviewTab = QWidget()
        self.lefPreviewTab.setObjectName(u"lefPreviewTab")
        self.lefPreviewTabLayout = QVBoxLayout(self.lefPreviewTab)
        self.lefPreviewTabLayout.setObjectName(u"lefPreviewTabLayout")
        self.lefPreviewTabLayout.setContentsMargins(8, 8, 8, 8)
        self.alPadHintLabel = QLabel(self.lefPreviewTab)
        self.alPadHintLabel.setObjectName(u"alPadHintLabel")
        self.alPadHintLabel.setStyleSheet(u"color: #7A5200; background: #FFF6D8; border: 1px solid #E6C86E; padding: 6px;")
        self.alPadHintLabel.setText(u"")
        self.alPadHintLabel.setWordWrap(True)
        self.alPadHintLabel.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByKeyboard|Qt.TextInteractionFlag.TextSelectableByMouse)

        self.lefPreviewTabLayout.addWidget(self.alPadHintLabel)

        self.lefPreviewContainer = QWidget(self.lefPreviewTab)
        self.lefPreviewContainer.setObjectName(u"lefPreviewContainer")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy6.setHorizontalStretch(1)
        sizePolicy6.setVerticalStretch(1)
        sizePolicy6.setHeightForWidth(self.lefPreviewContainer.sizePolicy().hasHeightForWidth())
        self.lefPreviewContainer.setSizePolicy(sizePolicy6)
        self.lefPreviewContainerLayout = QVBoxLayout(self.lefPreviewContainer)
        self.lefPreviewContainerLayout.setObjectName(u"lefPreviewContainerLayout")
        self.lefPreviewContainerLayout.setContentsMargins(0, 0, 0, 0)

        self.lefPreviewTabLayout.addWidget(self.lefPreviewContainer)

        self.previewTabs.addTab(self.lefPreviewTab, "")

        self.previewPanelLayout.addWidget(self.previewTabs)

        self.mainSplitter.addWidget(self.previewPanel)

        self.mainLayout.addWidget(self.mainSplitter)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menuBar = QMenuBar(MainWindow)
        self.menuBar.setObjectName(u"menuBar")
        self.menuBar.setGeometry(QRect(0, 0, 1380, 24))
        self.settingsMenu = QMenu(self.menuBar)
        self.settingsMenu.setObjectName(u"settingsMenu")
        self.languageMenu = QMenu(self.settingsMenu)
        self.languageMenu.setObjectName(u"languageMenu")
        MainWindow.setMenuBar(self.menuBar)

        self.menuBar.addAction(self.settingsMenu.menuAction())
        self.settingsMenu.addAction(self.languageMenu.menuAction())
        self.settingsMenu.addSeparator()
        self.settingsMenu.addAction(self.advancedSettingsAction)
        self.languageMenu.addAction(self.englishAction)
        self.languageMenu.addAction(self.simplifiedChineseAction)

        self.retranslateUi(MainWindow)

        self.previewTabs.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"EasyBumpcell", None))
        self.advancedSettingsAction.setText(QCoreApplication.translate("MainWindow", u"Advanced Settings", None))
        self.templateGroup.setTitle(QCoreApplication.translate("MainWindow", u"Process Templates", None))
        self.saveTemplateButton.setText(QCoreApplication.translate("MainWindow", u"Save", None))
        self.deleteTemplateButton.setText(QCoreApplication.translate("MainWindow", u"Delete", None))
        self.importTemplateButton.setText(QCoreApplication.translate("MainWindow", u"Import", None))
        self.exportTemplateButton.setText(QCoreApplication.translate("MainWindow", u"Export", None))
        self.projectGroup.setTitle(QCoreApplication.translate("MainWindow", u"Process", None))
        self.technologyLabel.setText(QCoreApplication.translate("MainWindow", u"Technology Name *", None))
        self.technologyEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"e.g. TechName", None))
        self.bumpTypeLabel.setText(QCoreApplication.translate("MainWindow", u"Bump Type", None))
        self.bumpTypeEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Optional, e.g. LF", None))
        self.versionLabel.setText(QCoreApplication.translate("MainWindow", u"Version *", None))
#if QT_CONFIG(tooltip)
        self.versionEdit.setToolTip(QCoreApplication.translate("MainWindow", u"Required file version. It is appended to output file names but not to the internal GDS Cell name.", None))
#endif // QT_CONFIG(tooltip)
        self.versionEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"e.g. V1 or 1.0", None))
        self.shapeLabel.setText(QCoreApplication.translate("MainWindow", u"Shape Type", None))
        self.shapeCombo.setItemText(0, QCoreApplication.translate("MainWindow", u"Round", None))
        self.shapeCombo.setItemText(1, QCoreApplication.translate("MainWindow", u"Oval", None))

        self.dbuLabel.setText(QCoreApplication.translate("MainWindow", u"Process DBU (\u00b5m) *", None))
        self.dbuCombo.setItemText(0, QCoreApplication.translate("MainWindow", u"0.001 \u00b5m", None))
        self.dbuCombo.setItemText(1, QCoreApplication.translate("MainWindow", u"0.0005 \u00b5m", None))

        self.layersGroup.setTitle(QCoreApplication.translate("MainWindow", u"Layers and Process Order", None))
        self.alPadLayerLabel.setText(QCoreApplication.translate("MainWindow", u"Al Pad drawing *", None))
        self.addLayerButton.setText(QCoreApplication.translate("MainWindow", u"Add Layer", None))
        self.deleteLayerButton.setText(QCoreApplication.translate("MainWindow", u"Delete Layer", None))
        self.resetLayersButton.setText(QCoreApplication.translate("MainWindow", u"Restore Defaults", None))
        self.confirmOrderButton.setText(QCoreApplication.translate("MainWindow", u"Confirm Process Order", None))
        self.summaryGroup.setTitle(QCoreApplication.translate("MainWindow", u"Output Summary", None))
        self.generatedNameCaption.setText(QCoreApplication.translate("MainWindow", u"Cell Base Name", None))
        self.generatedNameLabel.setText(QCoreApplication.translate("MainWindow", u"\u2014", None))
        self.nodeCountCaption.setText(QCoreApplication.translate("MainWindow", u"Polygon", None))
        self.nodeCountLabel.setText(QCoreApplication.translate("MainWindow", u"\u2014", None))
        self.settingsCaption.setText(QCoreApplication.translate("MainWindow", u"DBU / Origin", None))
        self.settingsSummaryLabel.setText(QCoreApplication.translate("MainWindow", u"\u2014", None))
        self.validationCaption.setText(QCoreApplication.translate("MainWindow", u"Validation", None))
        self.validationText.setPlainText(QCoreApplication.translate("MainWindow", u"Enter project data.", None))
        self.exportButton.setText(QCoreApplication.translate("MainWindow", u"Export GDS + LEF + PDF", None))
        self.previewTitleLabel.setText(QCoreApplication.translate("MainWindow", u"Grid-compliant GDS Preview", None))
#if QT_CONFIG(tooltip)
        self.showNodesCheck.setToolTip(QCoreApplication.translate("MainWindow", u"Show the actual quantized polygon vertices in both the GDS and LEF live previews. Exported GDS, LEF and PDF files are unchanged.", None))
#endif // QT_CONFIG(tooltip)
        self.showNodesCheck.setText(QCoreApplication.translate("MainWindow", u"Show Nodes", None))
#if QT_CONFIG(tooltip)
        self.snapNodesCheck.setToolTip(QCoreApplication.translate("MainWindow", u"Snap the crosshair and coordinate readout in both the GDS and LEF live previews to the nearest quantized polygon vertex. Exported GDS, LEF and PDF files are unchanged.", None))
#endif // QT_CONFIG(tooltip)
        self.snapNodesCheck.setText(QCoreApplication.translate("MainWindow", u"Snap to Nodes", None))
        self.previewTabs.setTabText(self.previewTabs.indexOf(self.gdsPreviewTab), QCoreApplication.translate("MainWindow", u"GDS Preview", None))
        self.previewTabs.setTabText(self.previewTabs.indexOf(self.lefPreviewTab), QCoreApplication.translate("MainWindow", u"LEF Preview", None))
        self.settingsMenu.setTitle(QCoreApplication.translate("MainWindow", u"Settings", None))
        self.languageMenu.setTitle(QCoreApplication.translate("MainWindow", u"Language", None))
    # retranslateUi

