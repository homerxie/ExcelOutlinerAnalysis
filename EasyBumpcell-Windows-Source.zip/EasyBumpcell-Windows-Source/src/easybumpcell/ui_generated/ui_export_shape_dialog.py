# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'export_shape_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QCheckBox, QDialog,
    QDialogButtonBox, QLabel, QSizePolicy, QVBoxLayout,
    QWidget)

class Ui_ExportShapeDialog(object):
    def setupUi(self, ExportShapeDialog):
        if not ExportShapeDialog.objectName():
            ExportShapeDialog.setObjectName(u"ExportShapeDialog")
        ExportShapeDialog.setMinimumSize(QSize(420, 0))
        self.verticalLayout = QVBoxLayout(ExportShapeDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.instructionLabel = QLabel(ExportShapeDialog)
        self.instructionLabel.setObjectName(u"instructionLabel")
        self.instructionLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.instructionLabel)

        self.roundCheck = QCheckBox(ExportShapeDialog)
        self.roundCheck.setObjectName(u"roundCheck")

        self.verticalLayout.addWidget(self.roundCheck)

        self.ovalCheck = QCheckBox(ExportShapeDialog)
        self.ovalCheck.setObjectName(u"ovalCheck")

        self.verticalLayout.addWidget(self.ovalCheck)

        self.availabilityLabel = QLabel(ExportShapeDialog)
        self.availabilityLabel.setObjectName(u"availabilityLabel")
        self.availabilityLabel.setStyleSheet(u"color: #666666;")
        self.availabilityLabel.setText(u"")
        self.availabilityLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.availabilityLabel)

        self.buttonBox = QDialogButtonBox(ExportShapeDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(ExportShapeDialog)
        self.buttonBox.accepted.connect(ExportShapeDialog.accept)
        self.buttonBox.rejected.connect(ExportShapeDialog.reject)

        QMetaObject.connectSlotsByName(ExportShapeDialog)
    # setupUi

    def retranslateUi(self, ExportShapeDialog):
        ExportShapeDialog.setWindowTitle(QCoreApplication.translate("ExportShapeDialog", u"Select Export Shapes", None))
        self.instructionLabel.setText(QCoreApplication.translate("ExportShapeDialog", u"Select at least one shape to export. Selecting both creates one combined report.", None))
        self.roundCheck.setText(QCoreApplication.translate("ExportShapeDialog", u"Round", None))
        self.ovalCheck.setText(QCoreApplication.translate("ExportShapeDialog", u"Oval", None))
    # retranslateUi

