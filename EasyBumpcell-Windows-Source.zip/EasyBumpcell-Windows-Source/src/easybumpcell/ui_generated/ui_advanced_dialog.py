# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'advanced_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QCheckBox, QComboBox,
    QDialog, QDialogButtonBox, QFormLayout, QGroupBox,
    QLabel, QLineEdit, QPushButton, QSizePolicy,
    QVBoxLayout, QWidget)

from easybumpcell.ui.checkable_combo_box import CheckableComboBox

class Ui_AdvancedDialog(object):
    def setupUi(self, AdvancedDialog):
        if not AdvancedDialog.objectName():
            AdvancedDialog.setObjectName(u"AdvancedDialog")
        AdvancedDialog.setMinimumSize(QSize(520, 520))
        self.verticalLayout = QVBoxLayout(AdvancedDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.coordinateGroup = QGroupBox(AdvancedDialog)
        self.coordinateGroup.setObjectName(u"coordinateGroup")
        self.coordinateForm = QFormLayout(self.coordinateGroup)
        self.coordinateForm.setObjectName(u"coordinateForm")
        self.syncOriginToAlPadCheck = QCheckBox(self.coordinateGroup)
        self.syncOriginToAlPadCheck.setObjectName(u"syncOriginToAlPadCheck")
        self.syncOriginToAlPadCheck.setChecked(True)

        self.coordinateForm.setWidget(0, QFormLayout.ItemRole.SpanningRole, self.syncOriginToAlPadCheck)

        self.originReferenceLabel = QLabel(self.coordinateGroup)
        self.originReferenceLabel.setObjectName(u"originReferenceLabel")

        self.coordinateForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.originReferenceLabel)

        self.originReferenceCombo = QComboBox(self.coordinateGroup)
        self.originReferenceCombo.setObjectName(u"originReferenceCombo")

        self.coordinateForm.setWidget(1, QFormLayout.ItemRole.FieldRole, self.originReferenceCombo)

        self.originModeLabel = QLabel(self.coordinateGroup)
        self.originModeLabel.setObjectName(u"originModeLabel")

        self.coordinateForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.originModeLabel)

        self.originModeCombo = QComboBox(self.coordinateGroup)
        self.originModeCombo.setObjectName(u"originModeCombo")

        self.coordinateForm.setWidget(2, QFormLayout.ItemRole.FieldRole, self.originModeCombo)


        self.verticalLayout.addWidget(self.coordinateGroup)

        self.angleGroup = QGroupBox(AdvancedDialog)
        self.angleGroup.setObjectName(u"angleGroup")
        self.angleForm = QFormLayout(self.angleGroup)
        self.angleForm.setObjectName(u"angleForm")
        self.zeroAxisLabel = QLabel(self.angleGroup)
        self.zeroAxisLabel.setObjectName(u"zeroAxisLabel")

        self.angleForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.zeroAxisLabel)

        self.zeroAxisCombo = QComboBox(self.angleGroup)
        self.zeroAxisCombo.setObjectName(u"zeroAxisCombo")

        self.angleForm.setWidget(0, QFormLayout.ItemRole.FieldRole, self.zeroAxisCombo)

        self.rotationDirectionLabel = QLabel(self.angleGroup)
        self.rotationDirectionLabel.setObjectName(u"rotationDirectionLabel")

        self.angleForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.rotationDirectionLabel)

        self.rotationDirectionCombo = QComboBox(self.angleGroup)
        self.rotationDirectionCombo.setObjectName(u"rotationDirectionCombo")

        self.angleForm.setWidget(1, QFormLayout.ItemRole.FieldRole, self.rotationDirectionCombo)


        self.verticalLayout.addWidget(self.angleGroup)

        self.nameGroup = QGroupBox(AdvancedDialog)
        self.nameGroup.setObjectName(u"nameGroup")
        self.nameLayout = QVBoxLayout(self.nameGroup)
        self.nameLayout.setObjectName(u"nameLayout")
        self.cellNameLayersLabel = QLabel(self.nameGroup)
        self.cellNameLayersLabel.setObjectName(u"cellNameLayersLabel")

        self.nameLayout.addWidget(self.cellNameLayersLabel)

        self.cellNameLayersCombo = CheckableComboBox(self.nameGroup)
        self.cellNameLayersCombo.setObjectName(u"cellNameLayersCombo")

        self.nameLayout.addWidget(self.cellNameLayersCombo)

        self.resetCellNameLayersButton = QPushButton(self.nameGroup)
        self.resetCellNameLayersButton.setObjectName(u"resetCellNameLayersButton")

        self.nameLayout.addWidget(self.resetCellNameLayersButton)

        self.strictLegacyCheck = QCheckBox(self.nameGroup)
        self.strictLegacyCheck.setObjectName(u"strictLegacyCheck")

        self.nameLayout.addWidget(self.strictLegacyCheck)

        self.manualNameCheck = QCheckBox(self.nameGroup)
        self.manualNameCheck.setObjectName(u"manualNameCheck")

        self.nameLayout.addWidget(self.manualNameCheck)

        self.manualNameEdit = QLineEdit(self.nameGroup)
        self.manualNameEdit.setObjectName(u"manualNameEdit")
        self.manualNameEdit.setEnabled(False)
        self.manualNameEdit.setMaxLength(127)

        self.nameLayout.addWidget(self.manualNameEdit)


        self.verticalLayout.addWidget(self.nameGroup)

        self.buttonBox = QDialogButtonBox(AdvancedDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(AdvancedDialog)
        self.buttonBox.accepted.connect(AdvancedDialog.accept)
        self.buttonBox.rejected.connect(AdvancedDialog.reject)
        self.manualNameCheck.toggled.connect(self.manualNameEdit.setEnabled)

        QMetaObject.connectSlotsByName(AdvancedDialog)
    # setupUi

    def retranslateUi(self, AdvancedDialog):
        AdvancedDialog.setWindowTitle(QCoreApplication.translate("AdvancedDialog", u"Advanced Settings", None))
        self.coordinateGroup.setTitle(QCoreApplication.translate("AdvancedDialog", u"Coordinate Settings", None))
        self.syncOriginToAlPadCheck.setText(QCoreApplication.translate("AdvancedDialog", u"Sync Origin Reference to LEF Al Pad Layer", None))
        self.originReferenceLabel.setText(QCoreApplication.translate("AdvancedDialog", u"Origin Reference Layer", None))
        self.originModeLabel.setText(QCoreApplication.translate("AdvancedDialog", u"Origin Definition", None))
        self.angleGroup.setTitle(QCoreApplication.translate("AdvancedDialog", u"Oval Angle Convention", None))
        self.zeroAxisLabel.setText(QCoreApplication.translate("AdvancedDialog", u"Zero-Degree Axis", None))
        self.rotationDirectionLabel.setText(QCoreApplication.translate("AdvancedDialog", u"Positive Rotation", None))
        self.nameGroup.setTitle(QCoreApplication.translate("AdvancedDialog", u"Cell Name Settings", None))
        self.cellNameLayersLabel.setText(QCoreApplication.translate("AdvancedDialog", u"Dimensions Included in Cell Name", None))
        self.resetCellNameLayersButton.setText(QCoreApplication.translate("AdvancedDialog", u"Reset to First and Last Layers", None))
        self.strictLegacyCheck.setText(QCoreApplication.translate("AdvancedDialog", u"Strict Legacy GDSII Compatibility", None))
#if QT_CONFIG(tooltip)
        self.strictLegacyCheck.setToolTip(QCoreApplication.translate("AdvancedDialog", u"Warn when a generated Cell Name exceeds the legacy 32-character limit.", None))
#endif // QT_CONFIG(tooltip)
        self.manualNameCheck.setText(QCoreApplication.translate("AdvancedDialog", u"Override automatically generated base name", None))
        self.manualNameEdit.setPlaceholderText(QCoreApplication.translate("AdvancedDialog", u"ASCII letters, digits and underscores only", None))
    # retranslateUi

