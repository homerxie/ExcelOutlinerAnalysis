# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'template_save_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QCheckBox, QDialog,
    QDialogButtonBox, QFormLayout, QHBoxLayout, QLabel,
    QLineEdit, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)

class Ui_TemplateSaveDialog(object):
    def setupUi(self, TemplateSaveDialog):
        if not TemplateSaveDialog.objectName():
            TemplateSaveDialog.setObjectName(u"TemplateSaveDialog")
        TemplateSaveDialog.setMinimumSize(QSize(560, 0))
        self.verticalLayout = QVBoxLayout(TemplateSaveDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.templateForm = QFormLayout()
        self.templateForm.setObjectName(u"templateForm")
        self.fileNameCaption = QLabel(TemplateSaveDialog)
        self.fileNameCaption.setObjectName(u"fileNameCaption")

        self.templateForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.fileNameCaption)

        self.fileNamePreviewLabel = QLabel(TemplateSaveDialog)
        self.fileNamePreviewLabel.setObjectName(u"fileNamePreviewLabel")
        self.fileNamePreviewLabel.setStyleSheet(u"font-weight: bold;")
        self.fileNamePreviewLabel.setText(u"\u2014")
        self.fileNamePreviewLabel.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.fileNamePreviewLabel.setWordWrap(True)

        self.templateForm.setWidget(0, QFormLayout.ItemRole.FieldRole, self.fileNamePreviewLabel)

        self.suffixLabel = QLabel(TemplateSaveDialog)
        self.suffixLabel.setObjectName(u"suffixLabel")

        self.templateForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.suffixLabel)

        self.suffixEdit = QLineEdit(TemplateSaveDialog)
        self.suffixEdit.setObjectName(u"suffixEdit")

        self.templateForm.setWidget(1, QFormLayout.ItemRole.FieldRole, self.suffixEdit)


        self.verticalLayout.addLayout(self.templateForm)

        self.shapeSelectionLayout = QHBoxLayout()
        self.shapeSelectionLayout.setObjectName(u"shapeSelectionLayout")
        self.shapeSelectionLabel = QLabel(TemplateSaveDialog)
        self.shapeSelectionLabel.setObjectName(u"shapeSelectionLabel")

        self.shapeSelectionLayout.addWidget(self.shapeSelectionLabel)

        self.roundCheck = QCheckBox(TemplateSaveDialog)
        self.roundCheck.setObjectName(u"roundCheck")

        self.shapeSelectionLayout.addWidget(self.roundCheck)

        self.ovalCheck = QCheckBox(TemplateSaveDialog)
        self.ovalCheck.setObjectName(u"ovalCheck")

        self.shapeSelectionLayout.addWidget(self.ovalCheck)

        self.shapeSelectionSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.shapeSelectionLayout.addItem(self.shapeSelectionSpacer)


        self.verticalLayout.addLayout(self.shapeSelectionLayout)

        self.shapeStatusLabel = QLabel(TemplateSaveDialog)
        self.shapeStatusLabel.setObjectName(u"shapeStatusLabel")
        self.shapeStatusLabel.setStyleSheet(u"color: #174A7E; font-weight: bold;")
        self.shapeStatusLabel.setText(u"")
        self.shapeStatusLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.shapeStatusLabel)

        self.characterHintLabel = QLabel(TemplateSaveDialog)
        self.characterHintLabel.setObjectName(u"characterHintLabel")
        self.characterHintLabel.setStyleSheet(u"color: #666666;")
        self.characterHintLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.characterHintLabel)

        self.validationLabel = QLabel(TemplateSaveDialog)
        self.validationLabel.setObjectName(u"validationLabel")
        self.validationLabel.setStyleSheet(u"color: #B3261E;")
        self.validationLabel.setText(u"")
        self.validationLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.validationLabel)

        self.buttonBox = QDialogButtonBox(TemplateSaveDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setOrientation(Qt.Orientation.Horizontal)
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Save)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(TemplateSaveDialog)
        self.buttonBox.accepted.connect(TemplateSaveDialog.accept)
        self.buttonBox.rejected.connect(TemplateSaveDialog.reject)

        QMetaObject.connectSlotsByName(TemplateSaveDialog)
    # setupUi

    def retranslateUi(self, TemplateSaveDialog):
        TemplateSaveDialog.setWindowTitle(QCoreApplication.translate("TemplateSaveDialog", u"Save Process Template", None))
        self.fileNameCaption.setText(QCoreApplication.translate("TemplateSaveDialog", u"File name preview", None))
        self.suffixLabel.setText(QCoreApplication.translate("TemplateSaveDialog", u"Custom suffix", None))
        self.suffixEdit.setPlaceholderText(QCoreApplication.translate("TemplateSaveDialog", u"Optional", None))
        self.shapeSelectionLabel.setText(QCoreApplication.translate("TemplateSaveDialog", u"Shapes to save", None))
        self.roundCheck.setText(QCoreApplication.translate("TemplateSaveDialog", u"Round", None))
        self.ovalCheck.setText(QCoreApplication.translate("TemplateSaveDialog", u"Oval", None))
        self.characterHintLabel.setText(QCoreApplication.translate("TemplateSaveDialog", u"Use ASCII letters, digits, periods, hyphens and underscores. Separators must be between alphanumeric groups.", None))
    # retranslateUi

