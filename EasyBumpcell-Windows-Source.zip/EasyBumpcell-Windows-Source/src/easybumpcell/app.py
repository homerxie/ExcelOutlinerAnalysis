from __future__ import annotations

import sys

import qdarktheme
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication

from easybumpcell import APPLICATION_NAME, __version__
from easybumpcell.app_resources import load_application_icon
from easybumpcell.i18n import LanguageManager
from easybumpcell.ui.main_window import MainWindow


def main() -> int:
    application = QApplication(sys.argv)
    application.setApplicationName(APPLICATION_NAME)
    application.setApplicationVersion(__version__)
    application.setOrganizationName(APPLICATION_NAME)
    application_icon = load_application_icon()
    if not application_icon.isNull():
        application.setWindowIcon(application_icon)
    qdarktheme.setup_theme("dark")
    language_manager = LanguageManager(
        application,
        settings=QSettings(),
    )
    window = MainWindow(language_manager)
    window.show()
    return application.exec()


if __name__ == "__main__":
    raise SystemExit(main())
