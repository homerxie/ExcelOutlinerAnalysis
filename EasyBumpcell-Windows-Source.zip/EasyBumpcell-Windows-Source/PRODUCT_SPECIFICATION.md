# EasyBumpcell 产品需求与技术规格

## 1. 文档目的

本文档记录 EasyBumpcell 第一版的完整产品需求、几何定义、命名规则、GDS/LEF 输出规则、DBU 风险处理和英文 PDF 报告要求，作为后续开发、测试、验收和交接的基准。

如本文档与早期讨论记录冲突，以本文档为准。

## 2. 产品目标

EasyBumpcell 是一个兼容 Windows、macOS 和 Linux 的 Python 桌面程序，用于生成多 Layer、同心的 Round 或 Oval Bump sample GDS、对应的 Al Pad LEF abstract 和英文 PDF 报告。

普通用户只需要：

1. 输入 Technology Name。
2. 确认并输入与该项目 techfile 定义完全一致的 Process DBU。
3. 可选输入 Bump Type。
4. 输入文件 Version。
5. 选择 Round 或 Oval。
6. 填写各工艺层的 Layer、Datatype、含义和最多一位小数的微米尺寸。
7. 拖拽并确认图层的工艺顺序。
8. 查看最终量化几何的实时预览。
9. 明确选择 Al Pad Layer 并查看 LEF PIN 实时预览。
10. 一键原子导出 GDS、对应 LEF 文件和全英文 PDF 报告。

程序应尽可能防止无意修改关键工艺参数。Process DBU 位于主界面 Project 区域，并醒目提示用户确认其与项目 techfile 的 DBU 定义完全一致；原点、旋转定义和 Cell Name 覆盖等内容只能在高级设置中修改。

## 3. 目标平台

- 正式支持 Windows、macOS 和 Linux。
- Windows：Windows 10/11 64-bit。
- macOS：当前受支持的 macOS 版本；Apple Silicon 和 Intel 架构按发布目标分别构建或提供经过验证的通用包。
- Linux：主流 64-bit 桌面发行版，正式发布前确定最低 glibc 和图形环境要求。
- 开发语言：Python。
- 正式交付物是完整源代码，以及 Windows、macOS 和 Linux 的环境安装、源码运行和打包命令教程。
- 不要求项目开发者生成或交付预打包的 `.exe`、`.app`、`.dmg`、AppImage、安装程序或其他二进制发布包。
- 用户从源代码运行时需要安装受支持的 Python 和项目依赖。
- 用户如需独立应用，应按照教程在对应目标平台原生打包；不同平台的打包产物不能跨平台复用。
- 三个平台共享同一套业务、几何、命名、GDS、LEF、PDF 和 `cksum` 核心代码。
- 自动测试和发布验收必须覆盖 Windows、macOS 和 Linux。

## 4. 技术栈

- PySide6：桌面界面。
- gdstk：GDSII 文件生成和回读验证。
- ReportLab：英文矢量 PDF 报告。
- pytest：核心测试和集成测试。
- pytest-qt：Qt 界面测试。
- PyInstaller：提供 Windows、macOS 和 Linux 的原生打包配置、命令和教程，由用户在对应平台自行执行。
- 应用图标统一使用仓库根目录 `Icon/`：Windows executable 嵌入 `.ico`，macOS app bundle 使用 `.icns`，Linux 和 Qt runtime 使用多尺寸 PNG。PyInstaller onedir 的内容目录固定命名为 `internal`，完整图标目录通过相对资源映射放置在 `internal/Icon/`；运行时同时兼容旧版本 `_internal/Icon/` 和 macOS 原生 Resources 布局，不得依赖开发电脑绝对路径。

预览使用 Qt 原生绘图，不依赖 Matplotlib。PDF 中的版图预览直接绘制矢量 Polygon，不使用低分辨率截图。

### 4.1 Qt UI 文件规则

- 窗口和对话框布局优先使用 Qt Designer `.ui` 文件。
- `.ui` 是界面布局的源文件。
- 使用 PySide6 提供的 `pyside6-uic` 将 `.ui` 转换为 Python 模块后供程序导入。
- 生成的 `ui_*.py` 文件不得手工修改。
- 所有信号连接、业务逻辑、输入校验、数据绑定和状态控制放在独立的 Python Controller/Widget 类中。
- 图层表模型、Polygon 预览等自定义组件使用 Python 实现，并通过 `.ui` 中的占位 Widget、提升控件或运行时注入方式接入。
- 修改布局时必须先修改 `.ui`，再重新运行 UIC；不得直接修改生成文件。
- UIC 转换必须有统一脚本或构建命令，不能依赖开发者手工输入不同参数。

## 5. 主界面

### 5.1 基本信息

Process（中文界面显示“工艺”）区域使用四列 Grid 布局，每行放置两组“字段标签 + 输入控件”；DBU 确认提示横跨整行。调整窗口高度时，字段行高和行距不得变化。

- `Technology Name`：必填。
- `Bump Type`：可选，例如 `LF`。
- `Version`：必填。输入框内固定显示不可编辑、不可删除的 `V` 前缀，用户只输入后续内容，例如输入 `1`、`1.0` 或 `1.2-rc1`，项目中保存和导出的完整 Version 分别为 `V1`、`V1.0` 或 `V1.2-rc1`；后续内容允许 ASCII 字母、数字、点和连字符，分隔符只能位于字母数字组之间。
- `Shape Type`：`Round` 或 `Oval`，一次任务中的所有层使用同一种 Shape Type。
- `Process DBU`：固定提供 `0.001 µm` 和 `0.0005 µm` 两个选项，默认选择 `0.0005 µm`；用户必须确认所选值与该项目 `techfile` 中的 DBU 定义完全一致。

Technology Name、Bump Type 和图层含义标识必须适合用于 GDS/Cell 文件名。第一版仅允许 ASCII 字母和数字，不允许空格和小数点。Version 只参与输出文件名和报告，不参与内部 Cell 名。

Process DBU 警告与 Layers and Process Order 警告前分别提供圆形 `?` 按钮。图片固定使用相对路径 `help_images/process_dbu_help.png` 和 `help_images/layer_mapping_help.png`，不得保存开发电脑的绝对路径。源码运行时相对 easybumpcell package 查找；PyInstaller 打包时通过 package data 收集，并允许可执行文件旁同名相对目录覆盖。鼠标悬停时以图片 Tooltip 显示详细确认教程。图片最大显示区域为 720 × 480 个 Qt 设备无关像素，同时不得超过问号所在屏幕可用逻辑区域的 90%；Qt 按程序当前 per-screen DPR 统一转换为物理像素，必须兼容 125%、150%、200% 及跨屏 DPI。程序必须先以 `SmoothTransformation` 在物理像素尺寸完成高质量缩小，再设置 QPixmap DPR 并由专用 Tooltip QLabel 直接显示；不得使用 HTML 对原图进行二次缩放，也不得放大分辨率不足的源图。缩放必须保持原始宽高比，不得拉伸、裁切或重复应用 DPI scale。缺少图片时 Tooltip 仅提示所需相对路径。

### 5.2 图层表

默认提供以下四层：

1. AP
2. CB2
3. PIO
4. UBM

用户可以：

- 添加图层。
- 删除选中图层。
- 恢复默认四层。
- 通过拖拽整行改变工艺顺序。

Round 模式字段：

| 字段 | 说明 |
|---|---|
| Order | 当前工艺顺序 |
| Layer Name | AP、CB2、PIO、UBM 或用户定义图层名称 |
| Layer | GDS Layer Number |
| Datatype | GDS Datatype |
| Diameter (µm) | 正数微米直径，最多一位小数 |

Oval 模式字段：

| 字段 | 说明 |
|---|---|
| Order | 当前工艺顺序 |
| Layer Name | AP、CB2、PIO、UBM 或用户定义图层名称 |
| Layer | GDS Layer Number |
| Datatype | GDS Datatype |
| Minor Axis (µm) | 正数微米短轴，最多一位小数 |
| Major Axis (µm) | 正数微米长轴，最多一位小数 |

尺寸只允许正数 µm，最多一位小数：

- 输入控件固定显示一位小数，步进为 `0.1 µm`，最小值为 `0.1 µm`。
- 不接受两位或更多小数、0、负数、非数值或无穷值。
- Oval 必须满足 `Major Axis > Minor Axis > 0`。
- `Major Axis == Minor Axis` 时提示用户改用 Round。

### 5.3 工艺顺序确认

图层表上方固定显示：

> 请确认 GDS Layer Number、Datatype 和 GDS Layer Name 与该工艺 layermap 文件完全一致。

添加、删除或拖拽图层后：

- 状态变为“工艺顺序待确认”。
- 自动名称立即按照当前顺序预览。
- 正式导出前必须点击“确认工艺顺序”。

程序不能自行判断实际工艺顺序是否正确，只负责清晰显示并要求用户确认。

### 5.4 预览

右侧预览区包含 `GDS Preview` 和 `LEF Preview` 两个标签页。GDS Preview 保持多 Layer 最终量化几何预览；LEF Preview 必须先生成完整 LEF 文本，再从这一份文本解析 PIN Polygon、PIN 首点 LABEL 和由 `ORIGIN/SIZE` 定义的 BOUNDARY，禁止从 GDS bounding box 或形状规律另行重建。PDF 报告必须解析当前导出流程中已经写入并通过校验的 LEF 文件内容，不得为图示重新猜测或生成几何。

Al Pad Layer 选择器直接位于 LEF Preview，不放入高级设置。程序对 `ALPA`、`AP`、`ALPAD`、`AL` 进行忽略大小写的完整名称匹配并提供默认建议；这只是候选建议，不代表工艺映射已被验证。用户可以明确改选任意有效 Layer。

LEF Preview 必须显示所选 `Layer Name`、GDS `Layer Number`/`Datatype`。顶部警告只显示一条确认语句：`{Al_layername} {Al_layernumb_datatype}` 是实际使用的 Al Drawing Layer，而不是 Marking Layer 或 Dummy Layer。`Al Pad`、`drawing`、`Layer Name`、`Layer Number`、`Datatype`、`layermap` 等半导体术语在中文界面中保留原文，不直接翻译。

Round 模式显示一个预览窗口。

Oval 模式同时显示 2×2 四宫格：

- 0 Degree
- 45 Degree
- 90 Degree
- 135 Degree

所有预览必须：

- 使用相同缩放比例和相同刻度间距。
- 显示 X/Y 坐标轴、以 `µm` 为单位的自适应数值刻度和轴名称。
- 显示原点标记。
- 鼠标进入任一绘图区后显示十字准线，并实时显示该点相对于实际 GDS 原点的 X/Y 坐标。
- 鼠标坐标由当前面板的 GDS 坐标变换计算，不得使用窗口像素值或名义未量化几何。
- 鼠标移动只能恢复旧/新十字准线覆盖的窄条区域并更新坐标标签，不得重复绘制静态 Polygon、纹理、坐标轴或整个面板。
- Output Summary 以 `64-gon` 或 `66-gon`（中文界面为 `64边形` 或 `66边形`）显示最终 Polygon 类型，并显示最终 GDS 坐标系中的 Bumpcell Center；每个实时预览面板标题使用相同的多边形表述并显示中心坐标。
- Output Summary 的 `Cell Base Name` 固定单行显示并通过 Tooltip 提供完整名称；各摘要行使用统一紧凑间距，Bumpcell Center 和 Validation 只按实际行数占用高度。窗口增加的垂直空间由摘要最底部空白区吸收，不得拉大各字段之间的行距。
- 节点数量必须从最终量化 Polygon 的 `points_dbu` 读取；Round 当前为 64，Oval 当前为 66，不得只显示与实际数据脱离的固定说明文字。
- GDS/LEF 预览标签页右侧提供共享且默认开启的 `Show Nodes` 和 `Snap to Nodes` 两个独立开关；两个开关同时作用于 GDS Preview 和 LEF Preview。
- `Show Nodes` 以图层颜色显示最终量化 Polygon 的真实顶点；普通节点半径不大于 1.5 个逻辑像素，选中图层节点半径不大于 2 个逻辑像素，并随系统 DPI 正确缩放。
- `Snap to Nodes` 在鼠标距离最近顶点不超过 8 个逻辑像素时，将十字准线和坐标读数吸附到该顶点；同坐标候选优先采用当前选中图层。
- 吸附坐标必须直接由节点的整数 DBU 坐标换算，不得由屏幕像素反算近似值。
- 节点显示与节点吸附只属于实时 UI 预览状态，不写入项目工艺配置，不改变 GDS，并且不得出现在 PDF 报告预览中。
- Oval 显示长轴方向和对应角度。
- 显示对应 GDS/Cell 名称。
- 使用“颜色 + 透明矢量纹理”双重编码叠加图层；不得使用会遮住下层的实心不透明填充。
- 默认纹理至少包括正斜线、反斜线、交叉斜线、点阵、横线和竖线。
- 颜色和纹理均属于图层自身的预览样式；拖拽工艺顺序后必须继续跟随原图层。
- 完全同尺寸、完全重合的两个或多个图层必须能通过叠加纹理区分。
- 同步高亮图层表中选中的图层。
- 使用最终经过 DBU 量化的真实 Polygon 坐标。
- LEF Preview 中 Round 必须显示所选 Al Pad 的完整 64边形；Oval 的每个角度必须显示完整 66边形，不得转成 bounding-box、八边形、45° 轮廓或阶梯轮廓。

### 5.5 界面语言

- 主窗口菜单栏的 `Settings > Language` 提供 English 和简体中文两个互斥选项，可在运行时切换；语言设置不得占用主界面 Project 区域。
- 英文是界面源语言，简体中文使用 Qt Linguist 的 `.ts` 文件维护并编译为 `.qm` 运行时资源。
- 切换语言后，主窗口、图层表、预览文字、提示信息以及随后打开的高级设置和导出确认对话框必须使用所选语言；GDS、LEF 和 PDF 输出内容不受界面语言影响。
- 当前界面语言必须使用 `QSettings` 持久化；关闭并重新启动软件后恢复上次选择，首次启动或保存值无效时使用 English。
- `Advanced Settings` 仅从 `Settings` 菜单打开，不在主界面放置高级设置按钮。
- 主窗口标题显示 `EasyBumpcell v{系统版本}`；系统版本以 `easybumpcell.__version__` 为唯一来源，并同步用于 Qt 应用版本和 Python 打包元数据。

## 6. 高级设置

高级设置包括：

- 原点参考层，默认 AP。
- 原点位置：参考层外接矩形左下角或共同中心。
- Oval 0 Degree 基准方向。
- 正角度方向：Counterclockwise 或 Clockwise。
- 自动 Cell Name 覆盖及恢复。
- 长 Cell Name 兼容性设置。

程序不得自动修改 DBU，也不得为了消除半格点风险推荐或执行 DBU 切换。

默认角度定义：

- 0 Degree：长轴沿 X 轴。
- Positive Rotation：Counterclockwise。

## 7. 几何定义

### 7.1 Round

Round 是内接于目标直径圆的规则 64 边形。

对于直径 `D`：

```text
x[k] = D / 2 × cos(2πk / 64)
y[k] = D / 2 × sin(2πk / 64)
k = 0 ... 63
```

要求：

- 64 个唯一顶点。
- 起始角度为 0 Degree。
- 包含上下左右四个极值点。
- 不允许用户修改顶点数。

### 7.2 Oval

Oval 是长轴水平时由两个半圆端部和中间直线段形成的 elongated circle，最终直接表示为一个 66 边形。

设：

- 短轴为 `S`。
- 长轴为 `L`。
- 半径 `r = S / 2`。
- 半圆圆心偏移 `a = (L - S) / 2`。

构造：

- 右侧半圆取 33 个点。
- 左侧半圆取 33 个点。
- 两个半圆各形成 32 条弦边。
- 上下两条直边连接端部。
- 总计 66 个顶点和 66 条边。

不通过“两个半圆 + 一个矩形”的 Boolean Union 生成，避免接缝、重叠和多 Polygon。

### 7.3 Oval 旋转

标准 Oval 的本地长轴沿 X 轴。根据高级设置将逻辑角度映射为实际旋转角度，分别生成：

- 0 Degree
- 45 Degree
- 90 Degree
- 135 Degree

每个角度均生成一套独立、展开后的 Polygon，不使用 Cell Reference。

## 8. 原点规则

所有图层首先围绕共同中心生成。

默认：

- Reference Layer：AP。
- Origin：参考层旋转并量化后的实际外接矩形左下角。

高级设置可改为：

- 其他参考层。
- 共同中心。

每个 Oval 角度独立执行：

1. 生成同心 Polygon。
2. 应用目标旋转。
3. 执行 DBU 量化。
4. 计算参考层实际外接矩形。
5. 按原点规则整体平移。
6. 验证最终原点和同心关系。

因此四个独立 GDS 各自满足相同的原点定义。

## 9. DBU 和格点风险

### 9.1 固定工艺 DBU

- GDS User Unit 固定为 `1 µm`。
- Process DBU 仅允许选择 `0.001 µm` 或 `0.0005 µm`，默认 `0.0005 µm`。
- DBU 只能由用户在主界面 Project 区域明确选择。
- Project 区域必须提示用户确认 Process DBU 与该项目 techfile 中的 DBU 定义完全一致。
- 程序不得自动修改、建议切换或静默替换 DBU。

### 9.2 风险检测

程序重点检测：

- 名义尺寸端点是否落在半格点。
- 多层共同中心能否在当前 DBU 下保持。
- 多层尺寸奇偶性是否导致无法同时保持精确尺寸和同心。
- 原点平移是否产生半格点。
- 量化后的实际外接尺寸是否变化。

64/66 边形的普通非极值顶点不落在 DBU 网格上属于正常几何量化，不单独列为半格点工艺警告。

### 9.3 风险处理

存在半格点风险时：

- 主界面显示持续的黄色 WARNING。
- 导出前再次要求用户确认。
- 允许用户继续导出。
- 绝不自动修改 DBU。
- PDF 中记录受影响图层、轴、名义尺寸、实际尺寸和偏差。

默认量化优先级：

1. 优先保持共同中心。
2. 对称顶点成对量化。
3. 无法同时保持精确尺寸和同心时向内量化。
4. 量化后的 Polygon 不超过名义尺寸。
5. 文件名和 Cell 名均使用 `ROUND_HALF_UP` 四舍五入后的整数尺寸；几何和报告尺寸表始终使用真实输入尺寸。

## 10. 命名规则

### 10.1 Cell Name 与文件名分离

GDS 内部 `STRNAME` 和 LEF `MACRO` 使用同一个短 Cell Name；GDS/LEF/PDF 文件名继续使用完整描述名称。高级设置中的 Cell Name 图层选择和手动覆盖只改变 `STRNAME`/`MACRO`，不改变文件名、报告内容或几何。

自动 Cell Name 默认只包含：

1. 可选的 Bump Type。
2. 已确认工艺顺序中的第一个层。
3. 已确认工艺顺序中的最后一个层。
4. Oval 的角度后缀。

只有一个工艺层时只输出一次该层。Cell Name 不包含 Technology Name、`Round`/`Oval` 标记或 Version；潜在重名由用户通过更具描述性的 Bump Type 规避。

Bump Type 允许 ASCII 字母、数字和下划线。Cell Name 全部字段最终只能产生：

```text
A-Z a-z 0-9 _
```

不得包含空格、斜杠、中文或其他 Unicode 字符。

### 10.2 Round Cell Name

每个选中层使用 `LayerName + Diameter`：

```text
LF_AP80_UBM60
```

Bump Type 为空时：

```text
AP80_UBM60
```

### 10.3 Oval Cell Name

每个选中层使用 `LayerName + MinorAxis + MajorAxis`，短轴和长轴之间不增加 `x` 或其他分隔符：

```text
LF_AP4080_UBM3060_0D
LF_AP4080_UBM3060_45D
LF_AP4080_UBM3060_90D
LF_AP4080_UBM3060_135D
```

`D` 表示 Degree。Cell Name 和完整输出文件名中的尺寸均使用 `ROUND_HALF_UP` 四舍五入后的整数，例如 `40.4 → 40`、`40.5 → 41`；实际几何和报告尺寸表继续使用用户输入的真实尺寸。

### 10.4 高级 Cell Name 设置

- `Dimensions Included in Cell Name` 使用可勾选下拉列表。
- 默认勾选第一个和最后一个工艺层。
- 用户可以增加或取消任意层，但至少保留一个层。
- 下拉选项按已确认的工艺顺序显示；最终名称也始终按工艺顺序生成，不按点击顺序生成。
- 提供 `Reset to First and Last Layers`。
- 用户删除图层时同步清除失效选择；恢复默认图层时恢复自动首尾选择。
- 手动 Cell Name 覆盖仍位于高级设置，并遵守相同字符集和长度规则。

### 10.5 完整输出文件名

文件名保持完整描述规则。Round 示例：

```text
TechName_LF_Round_80AP_40CB2_30PIO_60UBM_V1.gds
TechName_LF_Round_80AP_40CB2_30PIO_60UBM_Report_V1.pdf
```

Oval 示例：

```text
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_0D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_45D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_90D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_135D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_Report_V1.pdf
```

每个最终 `.gds`、`.lef` 和 `.pdf` 文件名（包含角度、Version、报告后缀和扩展名）的硬上限为 255 个 ASCII 字符。

### 10.6 长度和 Legacy 兼容

- Cell Name 默认硬上限为 127 个字符，包含最终 Oval 角度后缀后检查。
- 超过 127 个字符为 ERROR，禁止导出；不截断、不哈希、不自动缩写。
- `Strict Legacy GDSII Compatibility` 位于高级设置且默认关闭。
- 仅在该设置打开时，超过 32 个字符显示兼容性 WARNING；该警告不禁止导出。
- 该设置的 Tooltip 必须明确对比两种状态：勾选时按旧版 GDSII 的 32 字符兼容限制检查，超过时警告但仍可导出；不勾选时 Cell Name 硬上限为 127 字符，超过时禁止导出。
- `LIBNAME` 固定为短名称 `Bumpcell`，有意义的短名称写入 `STRNAME`。
- 每个 GDS 只有一个 Cell，不包含其他辅助 Cell，也不使用 Cell Reference。


## 11. GDS、LEF 输出和验证

采用批量原子导出：

1. 完成输入和工艺顺序校验。
2. 生成最终量化几何。
3. 在临时目录写入所有 GDS 和对应 LEF。
4. 使用 gdstk 重新读取每个 GDS。
5. 验证结构、Cell、Layer、Datatype、顶点、DBU 和原点。
6. 回读每个 LEF，验证 Macro、PIN、Layer 和所有 Polygon 坐标与对应 GDS Al Pad 完全一致。
7. 为每个 GDS 计算 POSIX `cksum`。
8. 生成英文 PDF。
9. 全部成功后移动到用户选择的目标目录。
10. 任意步骤失败时，不留下不完整的正式输出。

导出对话框必须使用统一的 Required Export Checklist，替换分散的警告标签和总括式确认框。固定核对项包括：以下 GDS Layer 及其 Layer Number/Datatype 与用户输入的 `{Technology Name}` 工艺当前 Bump 类型的 design rule 一致，此项影响 GDS 文件的准确生成；Al drawing layer 的 Layer Name 与 Layer Number/Datatype 对应关系符合该工艺 `layermap (*.map / *.layermap)` 文件的定义，此项影响 LEF 文件的准确生成；Process DBU 与该工艺 `techfile (*.tf)` 中的 DBU 定义一致；Layer 工艺顺序正确；Al Pad Drawing 层（而不是 Marking 或 Dummy 层）的 `Layername.Datatype` 是 `{layer_number}.{datatype}`；该 `Layername.Datatype` 在工艺 `layermap (*.map)` 文件中的 layer name 定义是所选 Al Pad Layer Name。界面警告和导出 Checklist 必须将 `{Technology Name}`、`{layer_number}`、`{datatype}` 和 Al Pad Layer Name 替换为项目中用户实际输入或选择的值。每条运行时风险和覆盖已有文件也必须成为独立的可勾选条目。只有全部条目勾选后才能启用 Export。外层 Required Export Checklist GroupBox 使用普通界面配色；只有承载 checkbox 的 QListWidget frame、checkbox 条目文字和背景使用黄色警告配色。Checklist 每条直接使用与 Select Export Shapes 相同的原生 QCheckBox，不自绘 indicator，也不单独修改 checkbox 的字体或尺寸；全局主题负责字体、DPI 缩放和 hover 下划线，点击 checkbox 或该条文字均可切换勾选状态。Checklist 的标题、说明、固定条目、运行时警告模板和覆盖提示模板由 `src/easybumpcell/export_checklist.json` 统一定义，英文和中文均直接读取 JSON，不通过 Qt Linguist，允许修改 JSON 自定义。程序不得声称已自动验证外部 layermap 或 techfile。

### 11.1 Round 回读检查

- 正好一个顶层 Cell。
- 无其他 Cell。
- 每个有效工艺层正好一个 Polygon。
- Polygon 有 64 个唯一顶点。
- Layer/Datatype 正确。
- DBU、原点和外接尺寸正确。

### 11.2 Oval 回读检查

- 正好生成四个独立 GDS。
- 每个 GDS 正好一个顶层 Cell。
- 无其他 Cell。
- 每个有效工艺层正好一个 Polygon。
- Polygon 有 66 个唯一顶点。
- Cell 名、角度、Layer/Datatype、DBU 和原点正确。

### 11.3 LEF 输出规则

- 每个 GDS 配对输出一个同名 `.lef`。
- LEF `MACRO` 名与对应 GDS `STRNAME` 完全一致。
- Macro 使用 `CLASS COVER BUMP`。
- LEF 只包含用户所选 Al Pad Layer 的一个 PIN PORT，不包含其他工艺 Layer 或 OBS。
- `PIN` 名固定为 `BUMP`；`LAYER` 名逐字使用所选 Al Pad Layer Name，保留大小写，不做翻译、缩写或规范化。
- PIN 使用 `DIRECTION INOUT` 和 `USE SIGNAL`；PORT 不输出 `CLASS BUMP`。
- 不输出 `NAMESCASESENSITIVE` 或 `UNITS` 语句；目标流程负责通过 technology LEF 提供数据库精度。
- `FOREIGN` 使用对应 GDS 中所选 Al Pad Polygon 最终量化外接矩形左下角 `(Xmin, Ymin)`，表示 macro 左下角相对于 GDS foreign origin 的偏移。
- `FOREIGN` 后必须输出 `ORIGIN -Xmin -Ymin ;`，表示 macro origin 相对于 placement boundary 左下角的偏移；`FOREIGN` 与 `ORIGIN` 在 GDS origin 和 LEF macro origin 重合时必须互为相反数，并保持 `FOREIGN`、`ORIGIN`、`SIZE` 的标准顺序。
- `POLYGON` 必须直接复用对应 GDS 中 Al Pad Layer 最终量化后的全部节点坐标，首点和节点顺序完全一致，不得平移、重排或近似。
- Round LEF Polygon 为完整 64 边形；Oval 每个角度为对应的完整 66 节点轮廓。
- 不要求 LEF Polygon 边限制在 0°、45° 或 90°，不得对轮廓进行矩形化或其他近似。
- `SIZE` 必须等于所选 Al Pad 最终 bounding box 的宽和高。LEF BOUNDARY 在 macro-origin 坐标系中的四边界必须为 `(-ORIGIN_X, -ORIGIN_Y, SIZE_X-ORIGIN_X, SIZE_Y-ORIGIN_Y)`，并精确等于 LEF `POLYGON` 和 GDS Al Pad 的最终 bounding box。

## 12. POSIX cksum

报告使用 Linux/GNU 命令以下调用方式的默认算法：

```text
cksum filename.gds
```

这不是 SHA-256。默认算法是 POSIX 标准的 32-bit CRC，输出包括：

```text
CRC_DECIMAL  BYTE_COUNT  FILE_NAME
```

示意：

```text
1234567890 4567 Example.gds
```

程序使用纯 Python 实现同一 POSIX `cksum` 算法，不依赖 WSL、Git Bash、系统 `cksum` 命令或外部 GNU Coreutils。实现必须：

- 以二进制模式读取 GDS 和 LEF。
- 输出无符号十进制 CRC。
- 输出准确的文件字节数。
- 与 Linux/GNU `cksum file` 的默认输出一致。

测试必须将 Windows、macOS 和 Linux 版本生成的结果与 Linux/GNU `cksum` 交叉比对。

PDF 记录每个生成 GDS 和 LEF 文件的 `cksum`，但不记录 PDF 自身校验值，避免报告内容和自身校验值形成循环依赖。

## 13. 英文 PDF 报告

PDF 内容全部使用英文。

报告包含：

1. `Sample GDS report`
2. Technology Name
3. Bump Type
4. Version
5. Shape Type
6. Generated GDS and Cell Names
7. LEF PIN Layer Name
8. POSIX Checksums
9. Sample GDS Preview
10. Layer Number/Datatype Mapping
11. Nominal Dimensions vs Actual Quantized Axis Dimensions
12. LEF Preview
13. Origin Definition
14. Process DBU
15. Zero-Degree Axis（仅 Oval）
16. Positive Rotation Direction（仅 Oval）
17. Validation Status

报告不添加关于 Layer Name 或颜色仅供参考的额外页脚说明。

上述顺序是报告的固定章节顺序，其中角度约定两节只对 Oval 输出。Round 的尺寸表不显示 Angle 列，也不显示 `0D`、Zero-Degree Axis 或 Positive Rotation Direction。

Generated GDS and Cell Names 表必须同时输出 GDS File Name、GDS Cell Name、LEF File Name、LEF Macro Name 和 `Polygon`。`Polygon` 根据对应 GeneratedLayout 实际生成的节点数显示为 `64-gon` 或 `66-gon`。报告必须明确说明每对 GDS Cell Name 与 LEF Macro Name 完全一致。

LEF PIN Layer Name 只显示所选 LEF Layer Name 及对应的 GDS Layer Number/Datatype，不提示固定 PIN 名称。POSIX Checksums 必须覆盖每个生成的 GDS 和 LEF 文件。

Sample GDS Preview 必须绘制 Round 单图或 Oval 四宫格矢量预览。Bumpcell Center 必须由原点平移后的 `common_center_dbu` 换算，并直接写入每个对应面板，不建立独立表格。X/Y 坐标轴必须显示易读的 1/2/5 自适应刻度。

Layer Number/Datatype Mapping 必须紧接 Sample GDS Preview，并以表格行顺序体现已确认的工艺顺序；不再建立独立工艺顺序章节。Mapping 表只保留与预览一致的矢量颜色/纹理样本，不显示额外的 `Color / Pattern` 文字描述列。Nominal Dimensions vs Actual Quantized Axis Dimensions 必须位于 Mapping 之后、LEF Preview 之前。

LEF Preview 必须显示所选 Al Pad 的 `{Layer}.PIN`、`{Layer}.LABEL` 和 `BOUNDARY`，并在图内提供三者图例。这三个图示对象必须来自同一份序列化 LEF 定义：PIN 解析 `POLYGON`，LABEL 使用该 `POLYGON` 的首点，BOUNDARY 解析 `ORIGIN` 和 `SIZE width BY height ;`。绘制前必须确认同一 LEF `POLYGON` 的四边界精确等于 `(-ORIGIN_X, -ORIGIN_Y, SIZE_X-ORIGIN_X, SIZE_Y-ORIGIN_Y)`；只比较宽高不充分。不一致时必须报错且不得绘制。报告不输出重复的 LEF Preview Layers 表，也不显示 PIN LABEL 锚点坐标说明。

报告不再输出与尺寸对照表内容重叠的 `Quantization Deviations` 章节，也不显示 GDS User Unit 或 `long_cell_name` 兼容性警告；该警告仍保留在程序校验和导出确认中。报告包含用户输入的文件 Version，但不包含 Generation Time 或 Application Version。

Round 的实际量化尺寸按 X/Y 直径报告。Oval 的实际量化尺寸必须沿旋转后图形自身的短轴和长轴方向报告；不得用全局 X/Y 外接矩形尺寸代替长短轴尺寸。中心坐标、鼠标坐标等具体坐标读数固定使用 Process DBU 的小数位数；尺寸对照表中的直径、短轴和长轴固定比 Process DBU 多一位小数。坐标轴刻度为保证可读性不补齐 DBU 小数位。输入框固定一位小数；Cell Name 和 GDS/LEF/PDF 文件名中的所有尺寸均使用 `ROUND_HALF_UP` 四舍五入后的整数。

PDF 中的长 Technology/Bump Type、GDS/LEF 文件名、GDS Cell Name 和 LEF Macro Name 必须在可用宽度不足时优先于下划线之后自动换行；下划线本身保留在上一行。此规则同时应用于 Generated GDS and Cell Names、POSIX Checksums、Sample GDS Preview 和 LEF Preview 标题区域，不得让文字越过表格或预览面板边界。只有单个无下划线字段本身超过可用宽度时，才允许在字段内部继续拆分。

## 14. 配置持久化

可以使用 Qt `QSettings` 保存：

- 最近使用的 Technology Name。
- 最近使用的 Bump Type。
- 最近使用的图层表。
- 窗口大小和位置。
- 高级设置。

DBU 的恢复值必须在主界面摘要中明确显示。程序不得因为载入历史配置而隐藏当前 DBU。

## 15. 第一版验收标准

- 源代码可以在安装了受支持 Python 和项目依赖的 Windows、macOS 和 Linux 上运行。
- 提供三个目标平台各自的环境安装、源码运行、测试和 PyInstaller 打包命令教程。
- 项目交付不包含预构建安装包或二进制应用。
- 尺寸输入只能为正数 µm，最多一位小数。
- Round 输出一个 GDS，且 GDS 中只有一个同名 Cell。
- Oval 输出四个独立 GDS，每个 GDS 中只有一个同名 Cell。
- Round 输出一个对应 LEF；Oval 输出四个与角度 GDS 一一对应的 LEF。
- LEF PIN 固定为 `BUMP`，LAYER 名与用户确认的 Al Pad Layer Name 完全一致，且 LEF Polygon 节点与 GDS Al Pad 完全一致。
- 未确认 Al Pad Layer 和外部 layermap 命名时禁止导出。
- Round 固定 64 边，Oval 固定 66 边。
- 自动名称严格按照已确认的工艺顺序生成。
- Oval 同时显示四个角度的量化后预览。
- DBU 永不自动修改。
- 半格点风险在界面和英文 PDF 中可追溯。
- 每个角度独立满足所选原点定义。
- PDF 全英文，几何预览为矢量。
- PDF 中的校验值与 Linux 默认 `cksum` 一致。
- 所有正式 GDS 均经过自动回读验证。
- 所有正式 LEF 均经过自动回读验证。

## 16. 明确不在第一版范围内

- 输出 GDS Layer Name。
- 输出 `.lyp`。
- 输出 PNG 报告。
- 一个 Oval GDS 内包含四个角度 Cell。
- 两位或更多小数的微米尺寸。
- 自动切换 DBU。
- 自动推断正确工艺顺序。
- 自动修改超长 Cell Name。
- 预构建 Windows、macOS 或 Linux 安装包及二进制应用。
