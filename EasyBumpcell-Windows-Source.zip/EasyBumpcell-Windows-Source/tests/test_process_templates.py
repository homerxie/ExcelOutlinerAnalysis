from __future__ import annotations

from decimal import Decimal
import json
from pathlib import Path

import pytest

from easybumpcell.domain.enums import ShapeType
from easybumpcell.domain.models import LayerDefinition, ProjectConfig
from easybumpcell.services import process_templates
from easybumpcell.services.process_templates import (
    ProcessTemplateError,
    apply_process_template,
    build_template_name,
    default_template_directory,
    list_process_templates,
    load_process_template,
    process_template_from_config,
    save_process_template,
    template_path,
)


def _configured_project() -> ProjectConfig:
    layers = [
        LayerDefinition(
            uid="ubm-uid",
            meaning="UBM",
            layer=40,
            datatype=2,
            diameter_um=Decimal("80.5"),
            color="#123456",
            preview_pattern="grid",
            tapeout=True,
        ),
        LayerDefinition(
            uid="ap-uid",
            meaning="AP",
            layer=10,
            datatype=1,
            diameter_um=Decimal("55.5"),
            color="#ABCDEF",
            preview_pattern="dots",
            tapeout=False,
        ),
    ]
    return ProjectConfig(
        technology_name="N3Tech",
        bump_type="LF",
        version="V7",
        shape_type=ShapeType.ROUND,
        dbu_um=Decimal("0.001"),
        layers=layers,
        al_pad_layer_uid="ap-uid",
        process_order_confirmed=True,
    )


def test_template_name_uses_process_fields_and_custom_suffix() -> None:
    assert (
        build_template_name("N3Tech", "LF", ShapeType.OVAL, "Rev_A")
        == "N3Tech_LF_Oval_Rev_A"
    )
    assert (
        build_template_name("N3Tech", "", ShapeType.ROUND)
        == "N3Tech_Round"
    )
    assert (
        build_template_name("N3Tech", "LF", ShapeType.ROUND, "Rev-1.2")
        == "N3Tech_LF_Round_Rev-1.2"
    )
    with pytest.raises(ProcessTemplateError):
        build_template_name("N3Tech", "LF", ShapeType.ROUND, "bad suffix")
    with pytest.raises(ProcessTemplateError):
        build_template_name("N3Tech", "LF", ShapeType.ROUND, "_leading")
    with pytest.raises(ProcessTemplateError):
        build_template_name("T" * 250, "LF", ShapeType.ROUND)


def test_template_json_round_trip_excludes_version_and_preserves_layers(
    tmp_path: Path,
) -> None:
    config = _configured_project()
    template = process_template_from_config(config, "Rev_A")
    path = save_process_template(template, template_path(tmp_path, template))

    document = json.loads(path.read_text(encoding="utf-8"))
    assert "version" not in document
    assert document["name"] == "N3Tech_LF_Round_Rev_A"
    assert document["shape_types"] == ["Round"]
    assert "shape_type" not in document
    assert document["dbu_um"] == "0.001"
    assert [layer["meaning"] for layer in document["layers"]] == [
        "UBM",
        "AP",
    ]
    assert document["process_order"] == ["ubm-uid", "ap-uid"]
    assert document["layers"][0] == {
        "uid": "ubm-uid",
        "meaning": "UBM",
        "layer": 40,
        "datatype": 2,
        "diameter_um": "80.5",
        "minor_axis_um": None,
        "major_axis_um": None,
        "color": "#123456",
        "preview_pattern": "grid",
        "tapeout": True,
    }
    assert document["al_pad_layer_uid"] == "ap-uid"

    loaded = load_process_template(path)
    assert loaded == template
    assert loaded.shape_types == (ShapeType.ROUND,)
    assert list_process_templates(tmp_path)[0].template == template


def test_applying_template_preserves_version_and_requires_order_review() -> None:
    template = process_template_from_config(_configured_project(), "Rev_A")
    target = ProjectConfig(
        technology_name="OldTech",
        bump_type="Cu",
        version="V99",
        shape_type=ShapeType.OVAL,
        process_order_confirmed=True,
        cell_name_layer_uids=["deleted-layer"],
    )

    apply_process_template(target, template)

    assert target.technology_name == "N3Tech"
    assert target.bump_type == "LF"
    assert target.version == "V99"
    assert target.shape_type is ShapeType.ROUND
    assert target.dbu_um == Decimal("0.001")
    assert [layer.uid for layer in target.layers] == ["ubm-uid", "ap-uid"]
    assert target.layers[0] is not template.layers[0]
    assert target.al_pad_layer_uid == "ap-uid"
    assert target.origin_reference_uid == "ap-uid"
    assert target.cell_name_layer_uids is None
    assert not target.process_order_confirmed


def test_template_detects_and_names_both_complete_shape_definitions(
    tmp_path: Path,
) -> None:
    config = _configured_project()
    for index, layer in enumerate(config.layers):
        layer.minor_axis_um = Decimal(30 + index * 10)
        layer.major_axis_um = Decimal(60 + index * 10)

    template = process_template_from_config(config, "Dual")
    path = save_process_template(template, template_path(tmp_path, template))
    document = json.loads(path.read_text(encoding="utf-8"))

    assert template.shape_types == (ShapeType.ROUND, ShapeType.OVAL)
    assert template.name == "N3Tech_LF_Round_Oval_Dual"
    assert document["shape_types"] == ["Round", "Oval"]
    assert all(layer["diameter_um"] is not None for layer in document["layers"])
    assert all(layer["minor_axis_um"] is not None for layer in document["layers"])
    assert all(layer["major_axis_um"] is not None for layer in document["layers"])


def test_template_detects_oval_only_and_omits_round_dimensions() -> None:
    config = _configured_project()
    config.shape_type = ShapeType.OVAL
    for index, layer in enumerate(config.layers):
        layer.diameter_um = None
        layer.minor_axis_um = Decimal(30 + index * 10)
        layer.major_axis_um = Decimal(60 + index * 10)

    template = process_template_from_config(config)

    assert template.shape_types == (ShapeType.OVAL,)
    assert template.name == "N3Tech_LF_Oval"
    assert all(layer.diameter_um is None for layer in template.layers)
    assert all(layer.minor_axis_um is not None for layer in template.layers)
    assert all(layer.major_axis_um is not None for layer in template.layers)


def test_dual_shape_template_keeps_current_supported_shape_when_applied() -> None:
    config = _configured_project()
    for index, layer in enumerate(config.layers):
        layer.minor_axis_um = Decimal(30 + index * 10)
        layer.major_axis_um = Decimal(60 + index * 10)
    template = process_template_from_config(config)
    target = ProjectConfig(shape_type=ShapeType.OVAL, version="V22")

    apply_process_template(target, template)

    assert target.shape_type is ShapeType.OVAL
    assert target.version == "V22"


def test_dual_dimensions_can_be_saved_as_one_selected_shape() -> None:
    config = _configured_project()
    for index, layer in enumerate(config.layers):
        layer.minor_axis_um = Decimal(30 + index * 10)
        layer.major_axis_um = Decimal(60 + index * 10)

    template = process_template_from_config(
        config,
        shape_types=(ShapeType.OVAL,),
    )

    assert template.name == "N3Tech_LF_Oval"
    assert template.shape_types == (ShapeType.OVAL,)
    assert all(layer.diameter_um is None for layer in template.layers)
    assert all(layer.minor_axis_um is not None for layer in template.layers)


def test_template_requires_one_complete_shape_definition() -> None:
    config = _configured_project()
    config.layers[-1].diameter_um = None

    with pytest.raises(
        ProcessTemplateError,
        match="No complete Round or Oval dimensions",
    ):
        process_template_from_config(config)


def test_schema_one_template_remains_loadable(tmp_path: Path) -> None:
    template = process_template_from_config(_configured_project(), "Legacy")
    document = process_templates._template_document(template)
    document["schema_version"] = 1
    document["shape_type"] = document.pop("shape_types")[0]
    path = tmp_path / f"{template.name}.json"
    path.write_text(json.dumps(document), encoding="utf-8")

    loaded = load_process_template(path)

    assert loaded.shape_types == (ShapeType.ROUND,)
    assert loaded.name == template.name


def test_schema_one_template_without_dimensions_remains_loadable(
    tmp_path: Path,
) -> None:
    template = process_template_from_config(_configured_project(), "Legacy")
    document = process_templates._template_document(template)
    document["schema_version"] = 1
    document["shape_type"] = document.pop("shape_types")[0]
    for layer in document["layers"]:
        layer["diameter_um"] = None
    path = tmp_path / f"{template.name}.json"
    path.write_text(json.dumps(document), encoding="utf-8")

    loaded = load_process_template(path)

    assert loaded.shape_types == (ShapeType.ROUND,)
    assert all(layer.diameter_um is None for layer in loaded.layers)


def test_saving_requires_explicit_overwrite(tmp_path: Path) -> None:
    template = process_template_from_config(_configured_project())
    path = save_process_template(template, template_path(tmp_path, template))

    with pytest.raises(FileExistsError):
        save_process_template(template, path)
    assert save_process_template(template, path, overwrite=True) == path


def test_frozen_default_template_folder_is_beside_executable(
    monkeypatch,
    tmp_path: Path,
) -> None:
    executable = tmp_path / "EasyBumpcell" / "EasyBumpcell.exe"
    monkeypatch.setattr(process_templates.sys, "frozen", True, raising=False)
    monkeypatch.setattr(process_templates.sys, "executable", str(executable))

    assert default_template_directory() == executable.parent / "template"
