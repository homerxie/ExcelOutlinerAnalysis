from __future__ import annotations

from PySide6.QtCore import QCoreApplication, QSettings

from easybumpcell.i18n import (
    ENGLISH,
    LANGUAGE_SETTINGS_KEY,
    SIMPLIFIED_CHINESE,
    LanguageManager,
)


def _settings(path: str) -> QSettings:
    return QSettings(path, QSettings.Format.IniFormat)


def test_language_change_is_saved_immediately(qapp, tmp_path) -> None:
    settings_path = str(tmp_path / "settings.ini")
    manager = LanguageManager(settings=_settings(settings_path))

    assert manager.language == ENGLISH
    assert manager.set_language(SIMPLIFIED_CHINESE)

    persisted_settings = _settings(settings_path)
    assert (
        persisted_settings.value(LANGUAGE_SETTINGS_KEY)
        == SIMPLIFIED_CHINESE
    )

    manager.set_language(ENGLISH)


def test_language_is_restored_before_interface_creation(qapp, tmp_path) -> None:
    settings_path = str(tmp_path / "settings.ini")
    persisted_settings = _settings(settings_path)
    persisted_settings.setValue(
        LANGUAGE_SETTINGS_KEY,
        SIMPLIFIED_CHINESE,
    )
    persisted_settings.sync()

    manager = LanguageManager(settings=_settings(settings_path))

    assert manager.language == SIMPLIFIED_CHINESE
    assert QCoreApplication.translate("MainWindow", "Language") == "语言"

    manager.set_language(ENGLISH)
