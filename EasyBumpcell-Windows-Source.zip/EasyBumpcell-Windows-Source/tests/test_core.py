from __future__ import annotations

import math
import os
import re
from dataclasses import replace
from decimal import Decimal
from pathlib import Path

import gdstk
import pytest

from easybumpcell.coordinate_format import (
    dbu_decimal_places,
    format_coordinate_um,
    format_dimension_um,
)
from easybumpcell.domain.enums import (
    IssueLevel,
    OriginMode,
    RotationDirection,
    ShapeType,
    ZeroDegreeAxis,
)
from easybumpcell.domain.models import (
    DEFAULT_COLORS,
    LayerDefinition,
    MAX_GDS_LAYER_NUMBER,
    ProjectConfig,
    ValidationIssue,
)
from easybumpcell.geometry import build_layouts
from easybumpcell.geometry.oval import oval_polygon
from easybumpcell.geometry.round import round_polygon
from easybumpcell.preview_patterns import (
    DEFAULT_PREVIEW_PATTERNS,
)
from easybumpcell.services.lef_export import (
    lef_boundary_from_text,
    lef_preview_elements,
    lef_text,
)
from easybumpcell.services.gds_export import write_gds
from easybumpcell.services.gds_verify import (
    GdsVerificationError,
    verify_gds,
    verify_oval_gds_readback_reflections,
)
from easybumpcell.services.lef_verify import verify_lef
from easybumpcell.services.naming import (
    combined_shape_report_name,
    generated_names,
    lef_file_name,
    report_name,
)
from easybumpcell.services.posix_cksum import PosixChecksum, posix_cksum
from easybumpcell.services.pdf_report import (
    _PREVIEW_LEGEND_FONT_SIZE,
    REPORT_TITLE,
    ShapeReportData,
    _clipped_parallel_segments,
    _combined_checksums_table,
    _combined_dimension_table,
    _combined_generated_names_table,
    _combined_preview_drawing,
    _combined_validation_table,
    _dimension_table,
    _format_axis_tick,
    _generated_names_table,
    _layer_mapping_table,
    _preview_drawing,
    _report_warning_messages,
    _styled_table,
    _table_text_style,
    _underscore_break_markup,
    _underscore_wrapped_paragraph,
    _wrap_text_at_underscores,
)
from easybumpcell.services.validation import has_errors, validate_project
from easybumpcell.services.batch_export import (
    export_project,
    export_project_shapes,
    intended_paths,
    intended_paths_for_shapes,
)


def _lef_polygon_points(text: str) -> tuple[tuple[Decimal, Decimal], ...]:
    match = re.search(r"\bPOLYGON\s+(.*?)\s*;", text, flags=re.DOTALL)
    assert match is not None
    values = [
        Decimal(value)
        for value in re.findall(
            r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)",
            match.group(1),
        )
    ]
    assert len(values) % 2 == 0
    return tuple(zip(values[0::2], values[1::2]))


def _signed_double_area(points) -> float:
    return sum(
        start[0] * end[1] - end[0] * start[1]
        for start, end in zip(points, (*points[1:], points[0]))
    )


def _centered_points(layout, layer_index: int):
    center_x, center_y = layout.common_center_dbu
    return tuple(
        (x - center_x, y - center_y)
        for x, y in layout.layers[layer_index].points_dbu
    )


def _reflect_across_oval_major_axis(point, actual_angle: float):
    x, y = point
    normalized = round(actual_angle) % 180
    transforms = {
        0: (x, -y),
        45: (y, x),
        90: (-x, y),
        135: (-y, -x),
    }
    return transforms[normalized]


def _plain_table_cell(value):
    return value.getPlainText() if hasattr(value, "getPlainText") else value


def _gds_layer_points_dbu(path, config, definition) -> tuple[tuple[int, int], ...]:
    library = gdstk.read_gds(path)
    polygon = next(
        polygon
        for polygon in library.cells[0].polygons
        if (
            polygon.layer,
            polygon.datatype,
        )
        == (
            definition.layer,
            definition.datatype,
        )
    )
    return tuple(
        (
            round(float(point[0]) / float(config.dbu_um)),
            round(float(point[1]) / float(config.dbu_um)),
        )
        for point in polygon.points
    )


def _lef_polygon_points_dbu(
    text: str,
    dbu_um: Decimal,
) -> tuple[tuple[int, int], ...]:
    return tuple(
        (
            int(x / dbu_um),
            int(y / dbu_um),
        )
        for x, y in _lef_polygon_points(text)
    )


def sample_round() -> ProjectConfig:
    config = ProjectConfig(
        technology_name="TechName",
        bump_type="LF",
        version="V1",
        shape_type=ShapeType.ROUND,
        layers=[
            LayerDefinition("AP", 1, 0, diameter_um=80, color=DEFAULT_COLORS[0], preview_pattern=DEFAULT_PREVIEW_PATTERNS[0]),
            LayerDefinition("CB2", 2, 0, diameter_um=40, color=DEFAULT_COLORS[1], preview_pattern=DEFAULT_PREVIEW_PATTERNS[1]),
            LayerDefinition("PIO", 3, 0, diameter_um=30, color=DEFAULT_COLORS[2], preview_pattern=DEFAULT_PREVIEW_PATTERNS[2]),
            LayerDefinition("UBM", 4, 0, diameter_um=60, color=DEFAULT_COLORS[3], preview_pattern=DEFAULT_PREVIEW_PATTERNS[3]),
        ],
        process_order_confirmed=True,
    )
    config.set_al_pad_layer_uid(config.layers[0].uid)
    return config


def sample_oval() -> ProjectConfig:
    config = ProjectConfig(
        technology_name="TechName",
        bump_type="LF",
        version="V1",
        shape_type=ShapeType.OVAL,
        layers=[
            LayerDefinition("AP", 1, 0, minor_axis_um=40, major_axis_um=80, color=DEFAULT_COLORS[0], preview_pattern=DEFAULT_PREVIEW_PATTERNS[0]),
            LayerDefinition("CB2", 2, 0, minor_axis_um=20, major_axis_um=40, color=DEFAULT_COLORS[1], preview_pattern=DEFAULT_PREVIEW_PATTERNS[1]),
            LayerDefinition("PIO", 3, 0, minor_axis_um=10, major_axis_um=30, color=DEFAULT_COLORS[2], preview_pattern=DEFAULT_PREVIEW_PATTERNS[2]),
            LayerDefinition("UBM", 4, 0, minor_axis_um=30, major_axis_um=60, color=DEFAULT_COLORS[3], preview_pattern=DEFAULT_PREVIEW_PATTERNS[3]),
        ],
        process_order_confirmed=True,
    )
    config.set_al_pad_layer_uid(config.layers[0].uid)
    return config


def sample_round_and_oval() -> ProjectConfig:
    config = sample_round()
    oval = sample_oval()
    for layer, oval_layer in zip(config.layers, oval.layers):
        layer.minor_axis_um = oval_layer.minor_axis_um
        layer.major_axis_um = oval_layer.major_axis_um
    return config


def sample_combined_reports() -> list[ShapeReportData]:
    reports = []
    checksum_value = 1
    for config in (sample_round(), sample_oval()):
        layouts = build_layouts(config)
        checksums = []
        for layout in layouts:
            for file_name in (
                layout.gds_file_name,
                lef_file_name(config, layout.logical_angle),
            ):
                checksums.append(
                    PosixChecksum(checksum_value, 100, file_name)
                )
                checksum_value += 1
        reports.append(
            ShapeReportData(
                config,
                tuple(layouts),
                tuple(checksums),
                (),
            )
        )
    return reports


def test_round_has_64_vertices_and_exact_extents() -> None:
    points = round_polygon(80)
    assert len(points) == 64
    assert points[0] == pytest.approx((40, 0))
    assert max(x for x, _ in points) == pytest.approx(40)
    assert min(x for x, _ in points) == pytest.approx(-40)
    assert max(y for _, y in points) == pytest.approx(40)
    assert min(y for _, y in points) == pytest.approx(-40)
    assert _signed_double_area(points) > 0


def test_oval_has_66_vertices_and_exact_extents() -> None:
    points = oval_polygon(40, 80)
    assert len(points) == 66
    assert points[0] == pytest.approx((40, 0))
    assert max(x for x, _ in points) == pytest.approx(40)
    assert min(x for x, _ in points) == pytest.approx(-40)
    assert max(y for _, y in points) == pytest.approx(20)
    assert min(y for _, y in points) == pytest.approx(-20)
    assert _signed_double_area(points) > 0


def test_required_names() -> None:
    assert generated_names(sample_round()) == ["LF_AP80_UBM60"]
    assert generated_names(sample_oval()) == [
        "LF_AP4080_UBM3060_0D",
        "LF_AP4080_UBM3060_45D",
        "LF_AP4080_UBM3060_90D",
        "LF_AP4080_UBM3060_135D",
    ]
    round_layout = build_layouts(sample_round())[0]
    assert round_layout.gds_file_name == (
        "TechName_LF_Round_80AP_40CB2_30PIO_60UBM_V1.gds"
    )
    assert round_layout.cell_name == "LF_AP80_UBM60"
    assert report_name(sample_round()) == (
        "TechName_LF_Round_80AP_40CB2_30PIO_60UBM_Report_V1.pdf"
    )
    assert lef_file_name(sample_round(), 0) == (
        "TechName_LF_Round_80AP_40CB2_30PIO_60UBM_V1.lef"
    )


def test_al_pad_layer_is_unselected_until_explicitly_set() -> None:
    layers = [
        LayerDefinition("al", 4, 0, diameter_um=60),
        LayerDefinition("alpad", 3, 0, diameter_um=50),
        LayerDefinition("ap", 2, 0, diameter_um=40),
        LayerDefinition("alpa", 1, 0, diameter_um=30),
    ]
    config = ProjectConfig(layers=layers)
    assert config.al_pad_layer_uid is None
    assert config.origin_reference_uid is None

    config.set_al_pad_layer_uid(layers[2].uid)

    assert config.al_pad_layer_uid == layers[2].uid
    assert config.origin_reference_uid == layers[2].uid


def test_confirmed_non_tapeout_layer_can_be_used_for_lef() -> None:
    config = sample_round()
    config.layers[1].tapeout = False
    config.set_al_pad_layer_uid(config.layers[1].uid)

    assert config.al_pad_layer() is config.layers[1]
    assert config.reference_layer() is config.layers[1]
    assert "      LAYER CB2 ;" in lef_text(config, build_layouts(config)[0])


def test_al_pad_layer_is_required_only_for_formal_export() -> None:
    config = sample_round()
    config.al_pad_layer_uid = None
    preview_issues = validate_project(config, for_export=False)
    export_issues = validate_project(config, for_export=True)
    assert any(
        issue.code == "al_pad_layer" and issue.level is IssueLevel.WARNING
        for issue in preview_issues
    )
    assert any(
        issue.code == "al_pad_layer" and issue.level is IssueLevel.ERROR
        for issue in export_issues
    )


def test_modern_16_bit_gds_layer_number_range_is_supported(tmp_path) -> None:
    config = sample_round()
    config.layers[0].layer = MAX_GDS_LAYER_NUMBER

    assert not any(
        issue.code == "layer_number"
        for issue in validate_project(config, for_export=False)
    )
    result = export_project(config, tmp_path)
    assert (MAX_GDS_LAYER_NUMBER, 0) in gdstk.read_gds(
        result.gds_paths[0]
    ).layers_and_datatypes()

    config.layers[0].layer = MAX_GDS_LAYER_NUMBER + 1
    issues = validate_project(config, for_export=False)

    assert any(issue.code == "layer_number" for issue in issues)
    assert any("0 to 65535" in issue.message for issue in issues)


def test_cell_name_can_include_custom_layers_but_keeps_process_order() -> None:
    config = sample_round()
    config.cell_name_layer_uids = [
        config.layers[3].uid,
        config.layers[0].uid,
        config.layers[2].uid,
    ]
    assert generated_names(config) == ["LF_AP80_PIO30_UBM60"]


def test_non_tapeout_layers_are_excluded_from_all_names_but_kept_in_gds(
    tmp_path,
) -> None:
    config = sample_round()
    config.layers[1].tapeout = False
    config.layers[3].tapeout = False

    layout = build_layouts(config)[0]
    assert layout.cell_name == "LF_AP80_PIO30"
    assert layout.gds_file_name == "TechName_LF_Round_80AP_30PIO_V1.gds"
    assert lef_file_name(config, 0) == "TechName_LF_Round_80AP_30PIO_V1.lef"
    assert report_name(config) == "TechName_LF_Round_80AP_30PIO_Report_V1.pdf"
    assert [layer.definition.meaning for layer in layout.layers] == [
        "AP",
        "CB2",
        "PIO",
        "UBM",
    ]

    result = export_project(config, tmp_path)
    gds = gdstk.read_gds(result.gds_paths[0])
    assert {
        (polygon.layer, polygon.datatype)
        for polygon in gds.cells[0].polygons
    } == {(1, 0), (2, 0), (3, 0), (4, 0)}


def test_tapeout_filter_preserves_relative_process_order() -> None:
    config = sample_round()
    config.layers[1].tapeout = False
    config.cell_name_layer_uids = [layer.uid for layer in reversed(config.layers)]

    assert generated_names(config) == ["LF_AP80_PIO30_UBM60"]


def test_project_requires_at_least_one_tapeout_layer() -> None:
    config = sample_round()
    for layer in config.layers:
        layer.tapeout = False

    issues = validate_project(config)
    assert any(issue.code == "tapeout_layers_empty" for issue in issues)
    assert has_errors(issues)


def test_bump_type_allows_underscores_in_cell_name() -> None:
    config = sample_round()
    config.bump_type = "Flip_Chip_LF"
    assert generated_names(config) == ["Flip_Chip_LF_AP80_UBM60"]
    assert not any(issue.code == "bump_type" for issue in validate_project(config))


def test_layer_name_underscores_are_removed_without_stripping_lef_macro_separators() -> None:
    config = sample_round()
    config.bump_type = "Flip_Chip_LF"
    config.layers[-1].meaning = "UBM_CU"

    layout = build_layouts(config)[0]
    assert layout.cell_name == "Flip_Chip_LF_AP80_UBMCU60"
    assert layout.gds_file_name == (
        "TechName_Flip_Chip_LF_Round_80AP_40CB2_30PIO_60UBMCU_V1.gds"
    )
    assert lef_file_name(config, 0) == (
        "TechName_Flip_Chip_LF_Round_80AP_40CB2_30PIO_60UBMCU_V1.lef"
    )

    text = lef_text(config, layout)
    assert "MACRO Flip_Chip_LF_AP80_UBMCU60\n" in text
    assert "  FOREIGN Flip_Chip_LF_AP80_UBMCU60 " in text
    assert "END Flip_Chip_LF_AP80_UBMCU60\n" in text
    assert "MACRO FlipChipLFAP80UBMCU60" not in text


def test_cell_name_length_and_legacy_warning_rules() -> None:
    config = sample_round()
    config.bump_type = "LEGACY_COMPATIBILITY_BUMP"
    issues = validate_project(config)
    assert not any(issue.code == "long_cell_name" for issue in issues)

    config.strict_legacy_gdsii_compatibility = True
    issues = validate_project(config)
    assert any(issue.code == "long_cell_name" for issue in issues)
    assert not has_errors(issues)

    config.manual_cell_base_name = "A" * 128
    issues = validate_project(config)
    assert any(issue.code == "cell_name_length" for issue in issues)
    assert has_errors(issues)


def test_cell_name_rejects_non_ascii_characters() -> None:
    config = sample_round()
    config.manual_cell_base_name = "LF_AP80_中文"
    assert any(issue.code == "naming" for issue in validate_project(config))


def test_output_file_names_have_255_character_hard_limit() -> None:
    config = sample_round()
    config.technology_name = "T" * 240
    issues = validate_project(config)
    assert any(issue.code == "file_name_length" for issue in issues)
    assert has_errors(issues)


def test_validation_requires_a_safe_version() -> None:
    config = sample_round()
    config.version = ""
    assert any(issue.code == "version" for issue in validate_project(config))
    config.version = "V1_bad"
    assert any(issue.code == "version" for issue in validate_project(config))
    config.version = "1.2"
    assert any(issue.code == "version" for issue in validate_project(config))
    config.version = "V1.2-rc1"
    assert not any(issue.code == "version" for issue in validate_project(config))


def test_validation_accepts_one_decimal_and_rejects_more_precision() -> None:
    config = sample_round()
    config.layers[0].diameter_um = Decimal("80.5")
    assert not has_errors(validate_project(config))
    config.layers[0].diameter_um = Decimal("80.55")
    assert has_errors(validate_project(config))


def test_decimal_round_dimensions_use_real_geometry_and_rounded_cell_name() -> None:
    config = sample_round()
    config.layers[0].diameter_um = Decimal("80.5")
    config.layers[-1].diameter_um = Decimal("60.4")
    layout = build_layouts(config)[0]
    assert layout.cell_name == "LF_AP81_UBM60"
    assert layout.gds_file_name == (
        "TechName_LF_Round_81AP_40CB2_30PIO_60UBM_V1.gds"
    )
    ap = layout.layers[0]
    assert Decimal(ap.bbox_dbu.width) * config.dbu_um == Decimal("80.5")
    assert Decimal(ap.bbox_dbu.height) * config.dbu_um == Decimal("80.5")


def test_decimal_oval_dimensions_round_half_up_only_for_cell_name() -> None:
    config = sample_oval()
    config.layers[0].minor_axis_um = Decimal("40.5")
    config.layers[0].major_axis_um = Decimal("80.5")
    config.layers[-1].minor_axis_um = Decimal("30.4")
    config.layers[-1].major_axis_um = Decimal("60.5")
    layouts = build_layouts(config)
    assert layouts[0].cell_name == "LF_AP4181_UBM3061_0D"
    assert layouts[1].cell_name == "LF_AP4181_UBM3061_45D"
    assert layouts[0].gds_file_name == (
        "TechName_LF_Oval_4181AP_2040CB2_1030PIO_3061UBM_0D_V1.gds"
    )
    assert layouts[0].deviations[0].nominal_um == Decimal("40.5")


def test_validation_rejects_unknown_preview_pattern() -> None:
    config = sample_round()
    config.layers[0].preview_pattern = "unknown_pattern"
    issues = validate_project(config)
    assert any(issue.code == "preview_pattern" for issue in issues)


def test_round_layout_uses_ap_lower_left_origin() -> None:
    config = sample_round()
    layout = build_layouts(config)[0]
    ap = layout.layers[0]
    assert ap.bbox_dbu.min_x == 0
    assert ap.bbox_dbu.min_y == 0
    assert len(ap.points_dbu) == 64
    assert ap.points_dbu[0] == (
        ap.bbox_dbu.max_x,
        ap.bbox_dbu.max_y // 2,
    )
    assert _signed_double_area(ap.points_dbu) > 0


def test_oval_builds_four_independent_layouts() -> None:
    layouts = build_layouts(sample_oval())
    assert [layout.logical_angle for layout in layouts] == [0, 45, 90, 135]
    assert all(len(layer.points_dbu) == 66 for layout in layouts for layer in layout.layers)
    assert all(layout.layers[0].bbox_dbu.min_x == 0 for layout in layouts)
    assert all(layout.layers[0].bbox_dbu.min_y == 0 for layout in layouts)
    assert all(layout.nodes_per_polygon == 66 for layout in layouts)
    for layout in layouts:
        ap = layout.layers[0]
        angle = math.radians(layout.actual_angle_degrees)
        major_axis = (math.cos(angle), math.sin(angle))
        projections = [
            x * major_axis[0] + y * major_axis[1]
            for x, y in ap.points_dbu
        ]
        first_projection = (
            ap.points_dbu[0][0] * major_axis[0]
            + ap.points_dbu[0][1] * major_axis[1]
        )
        assert first_projection == pytest.approx(max(projections))
        assert _signed_double_area(ap.points_dbu) > 0


@pytest.mark.parametrize("dbu_um", [Decimal("0.001"), Decimal("0.0005")])
@pytest.mark.parametrize(
    ("zero_axis", "rotation_direction"),
    [
        (ZeroDegreeAxis.X, RotationDirection.COUNTERCLOCKWISE),
        (ZeroDegreeAxis.X, RotationDirection.CLOCKWISE),
        (ZeroDegreeAxis.Y, RotationDirection.COUNTERCLOCKWISE),
        (ZeroDegreeAxis.Y, RotationDirection.CLOCKWISE),
    ],
)
def test_quantized_ovals_are_exactly_symmetric_on_both_local_axes(
    dbu_um,
    zero_axis,
    rotation_direction,
) -> None:
    config = sample_oval()
    config.dbu_um = dbu_um
    config.zero_degree_axis = zero_axis
    config.rotation_direction = rotation_direction

    for layout in build_layouts(config):
        for layer_index in range(len(layout.layers)):
            points = _centered_points(layout, layer_index)
            point_set = set(points)
            major_reflection = {
                _reflect_across_oval_major_axis(
                    point,
                    layout.actual_angle_degrees,
                )
                for point in points
            }
            minor_reflection = {
                (-reflected_x, -reflected_y)
                for reflected_x, reflected_y in major_reflection
            }

            assert len(point_set) == 66
            assert major_reflection == point_set
            assert minor_reflection == point_set
            assert _reflect_across_oval_major_axis(
                points[0],
                layout.actual_angle_degrees,
            ) == points[0]


@pytest.mark.parametrize(
    ("zero_axis", "rotation_direction"),
    [
        (ZeroDegreeAxis.X, RotationDirection.COUNTERCLOCKWISE),
        (ZeroDegreeAxis.X, RotationDirection.CLOCKWISE),
        (ZeroDegreeAxis.Y, RotationDirection.COUNTERCLOCKWISE),
        (ZeroDegreeAxis.Y, RotationDirection.CLOCKWISE),
    ],
)
def test_45_and_135_ovals_are_exact_global_axis_reflections(
    zero_axis,
    rotation_direction,
) -> None:
    config = sample_oval()
    config.zero_degree_axis = zero_axis
    config.rotation_direction = rotation_direction
    layouts = {
        layout.logical_angle: layout
        for layout in build_layouts(config)
    }

    for layer_index in range(len(config.layers)):
        points_45 = set(_centered_points(layouts[45], layer_index))
        points_135 = set(_centered_points(layouts[135], layer_index))

        assert {(x, -y) for x, y in points_45} == points_135
        assert {(-x, y) for x, y in points_45} == points_135


def test_90_and_135_oval_sequences_are_integer_quarter_turns_of_masters() -> None:
    layouts = {
        layout.logical_angle: layout
        for layout in build_layouts(sample_oval())
    }

    for layer_index in range(len(layouts[0].layers)):
        points_0 = _centered_points(layouts[0], layer_index)
        points_45 = _centered_points(layouts[45], layer_index)
        points_90 = _centered_points(layouts[90], layer_index)
        points_135 = _centered_points(layouts[135], layer_index)

        assert tuple((-y, x) for x, y in points_0) == points_90
        assert tuple((-y, x) for x, y in points_45) == points_135


def test_report_node_count_uses_generated_polygon_vertices() -> None:
    round_config = sample_round()
    oval_config = sample_oval()
    round_layouts = build_layouts(round_config)
    oval_layouts = build_layouts(oval_config)
    assert round_layouts[0].nodes_per_polygon == 64
    assert [
        _plain_table_cell(cell)
        for cell in _generated_names_table(
            round_config,
            round_layouts,
        )._cellvalues[0]
    ] == [
        "GDS File Name",
        "GDS Cell Name",
        "LEF File Name",
        "LEF Macro Name",
        "Polygon",
    ]
    assert [
        _plain_table_cell(row[4])
        for row in _generated_names_table(
            round_config,
            round_layouts,
        )._cellvalues[1:]
    ] == ["64-gon"]
    assert [
        _plain_table_cell(row[4])
        for row in _generated_names_table(
            oval_config,
            oval_layouts,
        )._cellvalues[1:]
    ] == ["66-gon", "66-gon", "66-gon", "66-gon"]
    round_row = _generated_names_table(
        round_config,
        round_layouts,
    )._cellvalues[1]
    assert round_row[0].getPlainText().endswith(".gds")
    assert round_row[2].getPlainText().endswith(".lef")
    assert round_row[1].getPlainText() == round_row[3].getPlainText()


def test_rotated_oval_dimensions_are_reported_on_local_axes_not_world_bbox() -> None:
    config = sample_oval()
    layouts = build_layouts(config)
    assert _plain_table_cell(
        _dimension_table(config, layouts)._cellvalues[0][1]
    ) == "Layer Name"
    layout = next(item for item in layouts if item.logical_angle == 45)
    ap = layout.layers[0]
    actual = {
        deviation.axis: deviation.actual_um
        for deviation in layout.deviations
        if deviation.layer_uid == ap.definition.uid
    }
    world_width = Decimal(ap.bbox_dbu.width) * config.dbu_um
    world_height = Decimal(ap.bbox_dbu.height) * config.dbu_um

    assert set(actual) == {"Minor Axis", "Major Axis"}
    assert actual["Minor Axis"] == pytest.approx(Decimal("40"), abs=Decimal("0.002"))
    assert actual["Major Axis"] == pytest.approx(Decimal("80"), abs=Decimal("0.002"))
    assert Decimal("68") < world_width < Decimal("69")
    assert Decimal("68") < world_height < Decimal("69")
    assert world_width not in (actual["Minor Axis"], actual["Major Axis"])


def test_half_grid_risk_does_not_modify_dbu() -> None:
    config = sample_round()
    config.dbu_um = Decimal("0.4")
    original = config.dbu_um
    layouts = build_layouts(config)
    assert config.dbu_um == original
    assert layouts[0].risks


def test_posix_cksum_empty_file(tmp_path) -> None:
    path = tmp_path / "empty.bin"
    path.write_bytes(b"")
    result = posix_cksum(path)
    assert result.crc == 4294967295
    assert result.byte_count == 0


def test_posix_cksum_matches_posix_golden_value(tmp_path) -> None:
    path = tmp_path / "vector.bin"
    path.write_bytes(b"123456789")
    result = posix_cksum(path)
    assert result.crc == 930766865
    assert result.byte_count == 9


def test_report_mapping_uses_shape_dimensions_without_preview_column() -> None:
    reports = sample_combined_reports()
    table = _layer_mapping_table(reports[0].config, reports)
    assert [_plain_table_cell(cell) for cell in table._cellvalues[0]] == [
        "Tapeout?",
        "Layer Name",
        "Layer Number",
        "Datatype",
        "Round / Oval Size (µm)",
    ]
    assert _plain_table_cell(table._cellvalues[1][4]) == (
        "Round: 80 µm dia.; Oval: 40 x 80 µm"
    )
    assert all(len(row) == 5 for row in table._cellvalues)

    round_table = _layer_mapping_table(sample_round())
    assert _plain_table_cell(round_table._cellvalues[0][4]) == (
        "Round Size (µm)"
    )
    assert _plain_table_cell(round_table._cellvalues[1][4]) == (
        "Round: 80 µm dia."
    )
    oval_table = _layer_mapping_table(sample_oval())
    assert _plain_table_cell(oval_table._cellvalues[0][4]) == (
        "Oval Size (µm)"
    )
    assert _plain_table_cell(oval_table._cellvalues[1][4]) == (
        "Oval: 40 x 80 µm"
    )


def test_round_report_dimension_table_does_not_include_angles() -> None:
    config = sample_round()
    layouts = build_layouts(config)
    dimension_table = _dimension_table(config, layouts)
    assert "Angle" not in [
        _plain_table_cell(cell) for cell in dimension_table._cellvalues[0]
    ]
    assert not any(
        "0D" in [_plain_table_cell(cell) for cell in row]
        for row in dimension_table._cellvalues[1:]
    )
    assert [
        _plain_table_cell(cell)
        for cell in dimension_table._cellvalues[1][1:]
    ] == [
        "80.00000",
        "80.00000",
        "80.00000",
    ]


def test_oval_report_dimension_table_keeps_angles() -> None:
    config = sample_oval()
    layouts = build_layouts(config)
    assert _plain_table_cell(
        _dimension_table(config, layouts)._cellvalues[0][0]
    ) == "Angle"


def test_combined_report_tables_merge_round_and_oval_rows() -> None:
    reports = sample_combined_reports()

    names = _combined_generated_names_table(reports)
    checksums = _combined_checksums_table(reports)
    dimensions = _combined_dimension_table(reports)
    validation = _combined_validation_table(reports)

    assert names._nrows == 6
    assert _plain_table_cell(names._cellvalues[0][0]) == "Shape / Angle"
    assert checksums._nrows == 11
    assert dimensions._nrows == 21
    assert _plain_table_cell(dimensions._cellvalues[0][0]) == "Shape / Angle"
    assert validation._nrows == 3


def test_coordinate_and_dimension_formats_follow_dbu_precision() -> None:
    dbu = Decimal("0.0005")
    assert dbu_decimal_places(dbu) == 4
    assert format_coordinate_um(Decimal("30"), dbu) == "30.0000"
    assert format_dimension_um(Decimal("30"), dbu) == "30.00000"
    assert format_coordinate_um(Decimal("30"), Decimal("0.001")) == "30.000"
    assert format_dimension_um(Decimal("30"), Decimal("0.001")) == "30.0000"
    assert _format_axis_tick(30, 10) == "30"


def test_pdf_preview_embeds_final_bumpcell_center() -> None:
    config = sample_round()
    drawing = _preview_drawing(build_layouts(config), config)
    texts = [item.text for item in drawing.contents if hasattr(item, "text")]
    assert "Center: X 40.0000 µm, Y 40.0000 µm" in texts
    assert "0" in texts
    assert "20" in texts


def test_pdf_lef_preview_contains_pin_label_boundary_and_first_point_anchor() -> None:
    config = sample_round()
    layouts = build_layouts(config)
    elements = lef_preview_elements(config, layouts[0])
    drawing = _preview_drawing(layouts, config, lef_mode=True)
    texts = [item.text for item in drawing.contents if hasattr(item, "text")]

    assert elements.label_anchor_dbu == elements.pin_geometry.points_dbu[0]
    assert elements.label_anchor_dbu == (160000, 80000)
    assert elements.boundary_dbu.min_x == 0
    assert elements.boundary_dbu.min_y == 0
    assert elements.boundary_dbu.max_x == 160000
    assert elements.boundary_dbu.max_y == 160000
    assert elements.pin_layer_name in texts
    assert elements.label_layer_name in texts
    assert elements.boundary_layer_name in texts
    assert elements.label_text in texts
    assert not any(text.startswith("Label BUMP anchor:") for text in texts)


def test_combined_previews_use_one_compact_grid_and_common_scale() -> None:
    reports = sample_combined_reports()

    gds_drawing = _combined_preview_drawing(reports)
    gds_texts = [
        item.text for item in gds_drawing.contents if hasattr(item, "text")
    ]
    assert [
        text
        for text in gds_texts
        if text == "Round" or text.startswith("Oval ")
    ] == [
        "Round",
        "Oval 0 Degree",
        "Oval 45 Degree",
        "Oval 90 Degree",
        "Oval 135 Degree",
    ]
    assert not any(
        layout.cell_name in gds_texts
        for report in reports
        for layout in report.layouts
    )
    expected_gds_legend_names = [
        layer.definition.meaning
        for layer in reports[0].layouts[0].layers
    ]
    gds_legend_items = [
        item
        for item in gds_drawing.contents
        if getattr(item, "text", None) in expected_gds_legend_names
    ]
    assert [item.text for item in gds_legend_items] == (
        expected_gds_legend_names
    )
    assert all(
        item.fontSize == _PREVIEW_LEGEND_FONT_SIZE
        for item in gds_legend_items
    )

    def assert_panel_positions(drawing, prefix: str = "") -> None:
        titles = {
            item.text: item
            for item in drawing.contents
            if hasattr(item, "text")
        }
        round_title = titles[f"{prefix}Round"]
        oval_0 = titles[f"{prefix}Oval 0 Degree"]
        oval_45 = titles[f"{prefix}Oval 45 Degree"]
        oval_90 = titles[f"{prefix}Oval 90 Degree"]
        oval_135 = titles[f"{prefix}Oval 135 Degree"]

        assert round_title.x < oval_0.x < oval_45.x
        assert round_title.y == pytest.approx(oval_0.y)
        assert round_title.y == pytest.approx(oval_45.y)
        assert oval_90.x == pytest.approx(oval_0.x)
        assert oval_135.x == pytest.approx(oval_45.x)
        assert oval_90.y < round_title.y
        assert oval_135.y == pytest.approx(oval_90.y)

    assert_panel_positions(gds_drawing)

    def filled_polygon_span(item) -> float:
        return max(
            max(item.points[0::2]) - min(item.points[0::2]),
            max(item.points[1::2]) - min(item.points[1::2]),
        )

    gds_layer_polygons = [
        item
        for item in gds_drawing.contents
        if item.__class__.__name__ == "Polygon"
        and getattr(getattr(item, "fillColor", None), "alpha", None)
        == pytest.approx(0.06)
    ]
    assert len(gds_layer_polygons) == 20
    assert filled_polygon_span(gds_layer_polygons[0]) == pytest.approx(
        filled_polygon_span(gds_layer_polygons[4])
    )

    lef_drawing = _combined_preview_drawing(reports, lef_mode=True)
    lef_layer_polygons = [
        item
        for item in lef_drawing.contents
        if item.__class__.__name__ == "Polygon"
        and getattr(getattr(item, "fillColor", None), "alpha", None)
        == pytest.approx(0.06)
    ]
    assert len(lef_layer_polygons) == 5
    assert filled_polygon_span(lef_layer_polygons[0]) == pytest.approx(
        filled_polygon_span(lef_layer_polygons[1])
    )
    lef_elements = lef_preview_elements(
        reports[0].config,
        reports[0].layouts[0],
    )
    expected_lef_legend_names = [
        lef_elements.pin_layer_name,
        lef_elements.label_layer_name,
        lef_elements.boundary_layer_name,
    ]
    lef_legend_items = [
        item
        for item in lef_drawing.contents
        if getattr(item, "text", None) in expected_lef_legend_names
    ]
    assert [item.text for item in lef_legend_items] == (
        expected_lef_legend_names
    )
    assert all(
        item.fontSize == _PREVIEW_LEGEND_FONT_SIZE
        for item in lef_legend_items
    )
    assert_panel_positions(lef_drawing, "LEF - ")


def test_lef_preview_uses_macro_origin_coordinates_for_center_origin() -> None:
    config = sample_round()
    config.origin_mode = OriginMode.CENTER
    elements = lef_preview_elements(config, build_layouts(config)[0])

    assert elements.pin_geometry.bbox_dbu.min_x == -80000
    assert elements.pin_geometry.bbox_dbu.min_y == -80000
    assert elements.pin_geometry.bbox_dbu.max_x == 80000
    assert elements.pin_geometry.bbox_dbu.max_y == 80000
    assert elements.label_anchor_dbu == (80000, 0)
    assert elements.boundary_dbu.min_x == -80000
    assert elements.boundary_dbu.min_y == -80000
    assert elements.boundary_dbu.max_x == 80000
    assert elements.boundary_dbu.max_y == 80000


def test_lef_boundary_uses_size_after_matching_polygon_bounds() -> None:
    text = """
MACRO BUMP_SAMPLE
  ORIGIN 0 0 ;
  SIZE 65.213 BY 65.213 ;
  PIN BUMP
    PORT
      POLYGON 0 0 65.213 0 65.213 65.213 0 65.213 ;
    END
  END BUMP
END BUMP_SAMPLE
"""
    boundary = lef_boundary_from_text(text, Decimal("0.0005"))

    assert boundary.min_x == 0
    assert boundary.min_y == 0
    assert boundary.max_x == 130426
    assert boundary.max_y == 130426


def test_lef_boundary_rejects_size_that_does_not_match_polygon_bounds() -> None:
    text = """
MACRO BUMP_SAMPLE
  ORIGIN 0 0 ;
  SIZE 65.213 BY 65.213 ;
  PIN BUMP
    PORT
      POLYGON 0 0 65.212 0 65.212 65.213 0 65.213 ;
    END
  END BUMP
END BUMP_SAMPLE
"""
    with pytest.raises(
        ValueError,
        match="SIZE 65.213 BY 65.213 defines PIN POLYGON bounds",
    ):
        lef_boundary_from_text(text, Decimal("0.0005"))


def test_lef_boundary_uses_positive_origin_for_centered_polygon() -> None:
    text = """
MACRO BUMP_SAMPLE
  ORIGIN 32.6065 32.6065 ;
  SIZE 65.213 BY 65.213 ;
  PIN BUMP
    PORT
      POLYGON -32.6065 -32.6065 32.6065 -32.6065 32.6065 32.6065 -32.6065 32.6065 ;
    END
  END BUMP
END BUMP_SAMPLE
"""
    boundary = lef_boundary_from_text(text, Decimal("0.0005"))

    assert boundary.min_x == -65213
    assert boundary.min_y == -65213
    assert boundary.max_x == 65213
    assert boundary.max_y == 65213


def test_lef_boundary_rejects_negative_origin_with_centered_polygon() -> None:
    text = """
MACRO BUMP_SAMPLE
  ORIGIN -32.6065 -32.6065 ;
  SIZE 65.213 BY 65.213 ;
  PIN BUMP
    PORT
      POLYGON -32.6065 -32.6065 32.6065 -32.6065 32.6065 32.6065 -32.6065 32.6065 ;
    END
  END BUMP
END BUMP_SAMPLE
"""
    with pytest.raises(
        ValueError,
        match="but found",
    ):
        lef_boundary_from_text(text, Decimal("0.0005"))


def test_lef_preview_geometry_is_parsed_only_from_serialized_lef() -> None:
    config = sample_round()
    layout = build_layouts(config)[0]
    definition = """
MACRO LEF_SOURCE
  ORIGIN 10 20 ;
  SIZE 4 BY 6 ;
  PIN FROM_LEF
    PORT
      LAYER LEF_AP ;
      POLYGON -10 -20 -6 -20 -6 -14 -10 -14 ;
    END
  END FROM_LEF
END LEF_SOURCE
"""

    elements = lef_preview_elements(
        config,
        layout,
        lef_definition=definition,
    )

    assert elements.pin_layer_name == "LEF_AP.PIN"
    assert elements.label_layer_name == "LEF_AP.LABEL"
    assert elements.label_text == "FROM_LEF"
    assert elements.pin_geometry.points_dbu == (
        (-20000, -40000),
        (-12000, -40000),
        (-12000, -28000),
        (-20000, -28000),
    )
    assert elements.label_anchor_dbu == (-20000, -40000)
    assert elements.boundary_dbu.min_x == -20000
    assert elements.boundary_dbu.min_y == -40000
    assert elements.boundary_dbu.max_x == -12000
    assert elements.boundary_dbu.max_y == -28000


def test_pdf_lef_preview_uses_exported_lef_definition() -> None:
    config = sample_round()
    layout = build_layouts(config)[0]
    definition = """
MACRO LEF_SOURCE
  ORIGIN 10 20 ;
  SIZE 4 BY 6 ;
  PIN FROM_LEF
    PORT
      LAYER LEF_AP ;
      POLYGON -10 -20 -6 -20 -6 -14 -10 -14 ;
    END
  END FROM_LEF
END LEF_SOURCE
"""
    drawing = _combined_preview_drawing(
        [
            ShapeReportData(
                config,
                (layout,),
                (),
                (),
                (definition,),
            )
        ],
        lef_mode=True,
    )
    texts = [
        item.text for item in drawing.contents if hasattr(item, "text")
    ]

    assert "LEF_AP.PIN" in texts
    assert "LEF_AP.LABEL" in texts
    assert "FROM_LEF" in texts


def test_export_passes_exact_written_lef_definitions_to_pdf(
    tmp_path,
    monkeypatch,
) -> None:
    import easybumpcell.services.batch_export as batch_export

    captured: list[str] = []

    def recording_pdf(
        path,
        config,
        layouts,
        checksums,
        issues,
        lef_definitions=None,
    ):
        captured.extend(lef_definitions or ())
        destination = Path(path)
        destination.write_bytes(b"%PDF-1.4\n%%EOF\n")
        return destination

    monkeypatch.setattr(batch_export, "create_pdf_report", recording_pdf)
    result = export_project(sample_round(), tmp_path)

    assert captured == [
        path.read_text(encoding="ascii") for path in result.lef_paths
    ]


def test_report_filters_only_long_cell_name_warning() -> None:
    config = sample_round()
    config.bump_type = "LEGACY_COMPATIBILITY_BUMP"
    config.strict_legacy_gdsii_compatibility = True
    issues = validate_project(config, for_export=True)
    assert any(issue.code == "long_cell_name" for issue in issues)
    assert _report_warning_messages(issues) == []
    retained = ValidationIssue(IssueLevel.WARNING, "other_warning", "Keep this warning")
    assert _report_warning_messages([*issues, retained]) == ["Keep this warning"]


def test_vector_hatch_segments_are_clipped_to_polygon() -> None:
    square = [(0.0, 0.0), (20.0, 0.0), (20.0, 20.0), (0.0, 20.0)]
    segments = _clipped_parallel_segments(square, (1.0, 1.0), 5.0)
    assert segments
    for segment in segments:
        for x, y in segment:
            assert 0 <= x <= 20
            assert 0 <= y <= 20


def test_pdf_tables_match_identity_font_sizes_and_wrap_all_text() -> None:
    table = _styled_table(
        [
            ["Long Table Header"],
            ["Technology_Name_C1x_Version_V2_Bump_Type_CuBOT"],
        ],
        [30],
    )
    header = table._cellvalues[0][0]
    body = table._cellvalues[1][0]

    assert header.style.fontSize == 9
    assert body.style.fontSize == 10
    header.wrap(30, 500)
    body.wrap(30, 500)
    assert len(header.blPara.lines) > 1
    assert len(body.blPara.lines) > 1


def test_pdf_long_names_wrap_at_underscores() -> None:
    value = "LF_AP4080_UBM3060_135D"
    markup = _underscore_break_markup(value)
    assert markup.count('<font size="0"> </font>') == value.count("_")

    paragraph = _underscore_wrapped_paragraph(
        value,
        _table_text_style(8),
    )
    paragraph.wrap(55, 500)
    lines = [
        "".join(getattr(word, "text", "") for word in line.words)
        for line in paragraph.blPara.lines
    ]
    assert lines == ["LF_AP4080_", "UBM3060_", "135D"]
    vector_lines = _wrap_text_at_underscores(
        value,
        55,
        "Helvetica",
        8,
    )
    assert "".join(vector_lines) == value
    assert all(line.endswith("_") for line in vector_lines[:-1])


def test_report_section_order(tmp_path, monkeypatch) -> None:
    import easybumpcell.services.pdf_report as pdf_report

    section_titles: list[str] = []
    section_contents: dict[str, object] = {}
    identity_grids = []
    original_section = pdf_report._section
    original_identity_grid = pdf_report._identity_grid

    def recording_section(title, content, styles, **kwargs):
        section_titles.append(title)
        section_contents[title] = content
        return original_section(title, content, styles, **kwargs)

    def recording_identity_grid(items, styles, width):
        grid = original_identity_grid(items, styles, width)
        identity_grids.append((items, grid))
        return grid

    monkeypatch.setattr(pdf_report, "_section", recording_section)
    monkeypatch.setattr(pdf_report, "_identity_grid", recording_identity_grid)
    export_project(sample_round(), tmp_path)
    assert section_titles == [
        "LEF PIN Layer and Process DBU",
        "Layer Number/Datatype Mapping",
        "GDS Preview - Common Scale",
        "LEF Preview - Common Scale",
        "Generated GDS, LEF, Cell and Macro Names",
        "POSIX Checksums",
        "Nominal Dimensions vs Actual Quantized Axis Dimensions",
        "Coordinate and Validation Summary",
    ]
    assert len(identity_grids) == 1
    identity_items, identity_grid = identity_grids[0]
    assert identity_items == [
        ("Technology Name", "TechName"),
        ("Bump Type", "LF"),
        ("Version", "V1"),
        ("Shape Type", "Round"),
    ]
    assert identity_grid._nrows == 2
    assert identity_grid._ncols == 2
    lef_layer_identity = section_contents["LEF PIN Layer and Process DBU"]
    assert isinstance(lef_layer_identity, str)
    assert "PIN BUMP" not in lef_layer_identity
    assert "LEF Layer Name" in lef_layer_identity
    assert REPORT_TITLE == "Sample GDS report"


def test_oval_report_uses_shared_order_and_keeps_angle_convention(
    tmp_path,
    monkeypatch,
) -> None:
    import easybumpcell.services.pdf_report as pdf_report

    section_titles: list[str] = []
    summary_orientations = []
    original_section = pdf_report._section
    original_summary = pdf_report._combined_validation_table

    def recording_section(title, content, styles, **kwargs):
        section_titles.append(title)
        return original_section(title, content, styles, **kwargs)

    def recording_summary(reports):
        table = original_summary(reports)
        summary_orientations.append(
            _plain_table_cell(table._cellvalues[1][2])
        )
        return table

    monkeypatch.setattr(pdf_report, "_section", recording_section)
    monkeypatch.setattr(
        pdf_report,
        "_combined_validation_table",
        recording_summary,
    )
    export_project(sample_oval(), tmp_path)
    assert section_titles == [
        "LEF PIN Layer and Process DBU",
        "Layer Number/Datatype Mapping",
        "GDS Preview - Common Scale",
        "LEF Preview - Common Scale",
        "Generated GDS, LEF, Cell and Macro Names",
        "POSIX Checksums",
        "Nominal Dimensions vs Actual Quantized Axis Dimensions",
        "Coordinate and Validation Summary",
    ]
    orientation = summary_orientations[0]
    assert "Zero degree: X Axis" in orientation
    assert "positive rotation: Counterclockwise" in orientation


def test_round_end_to_end_export(tmp_path) -> None:
    config = sample_round()
    layout = build_layouts(config)[0]
    result = export_project(config, tmp_path)
    assert len(result.gds_paths) == 1
    assert result.gds_paths[0].is_file()
    library = gdstk.read_gds(result.gds_paths[0])
    assert library.name == "Bumpcell"
    assert library.cells[0].name == generated_names(sample_round())[0]
    assert result.report_path.is_file()
    assert len(result.lef_paths) == 1
    assert result.lef_paths[0].is_file()
    assert result.gds_paths[0].name.endswith("_V1.gds")
    assert result.lef_paths[0].name.endswith("_V1.lef")
    assert result.report_path.name.endswith("_Report_V1.pdf")
    assert result.report_path.stat().st_size > 1000
    assert [item.file_name for item in result.checksums] == [
        result.gds_paths[0].name,
        result.lef_paths[0].name,
    ]
    assert result.checksums[0].byte_count == result.gds_paths[0].stat().st_size
    assert result.checksums[1].byte_count == result.lef_paths[0].stat().st_size
    verify_lef(
        result.lef_paths[0],
        config,
        layout,
    )
    selected = next(
        layer
        for layer in layout.layers
        if layer.definition.uid == config.al_pad_layer_uid
    )
    gds_points = _gds_layer_points_dbu(
        result.gds_paths[0],
        config,
        selected.definition,
    )
    lef_points = _lef_polygon_points_dbu(
        result.lef_paths[0].read_text(encoding="ascii"),
        config.dbu_um,
    )
    assert gds_points == selected.points_dbu
    assert lef_points == selected.points_dbu


def test_export_supports_output_directory_with_chinese_characters(
    tmp_path,
    monkeypatch,
) -> None:
    import easybumpcell.services.gdstk_io as gdstk_io

    output_directory = tmp_path / "晶圆项目" / "导出结果"
    monkeypatch.setattr(
        gdstk_io,
        "_needs_ascii_bridge",
        lambda path: not os.fspath(path).isascii(),
    )

    config = sample_round()
    layout = build_layouts(config)[0]
    result = export_project(config, output_directory)

    assert all(
        path.is_file()
        for path in (*result.gds_paths, *result.lef_paths, result.report_path)
    )
    verify_gds(result.gds_paths[0], config, layout)


def test_decimal_round_end_to_end_export(tmp_path) -> None:
    config = sample_round()
    config.layers[0].diameter_um = Decimal("80.5")
    config.layers[-1].diameter_um = Decimal("60.4")
    result = export_project(config, tmp_path)
    assert result.gds_paths[0].name.endswith(
        "_81AP_40CB2_30PIO_60UBM_V1.gds"
    )
    library = gdstk.read_gds(result.gds_paths[0])
    assert library.cells[0].name == "LF_AP81_UBM60"
    assert result.report_path.name.endswith(
        "_81AP_40CB2_30PIO_60UBM_Report_V1.pdf"
    )


def test_oval_end_to_end_export(tmp_path) -> None:
    config = sample_oval()
    layouts = build_layouts(config)
    result = export_project(config, tmp_path)
    assert len(result.gds_paths) == 4
    assert [path.stem.rsplit("_", 2)[-2:] for path in result.gds_paths] == [
        ["0D", "V1"],
        ["45D", "V1"],
        ["90D", "V1"],
        ["135D", "V1"],
    ]
    assert all(path.is_file() for path in result.gds_paths)
    assert len(result.lef_paths) == 4
    assert all(path.is_file() for path in result.lef_paths)
    assert result.report_path.is_file()
    expected_checksum_names = [
        path.name
        for pair in zip(result.gds_paths, result.lef_paths)
        for path in pair
    ]
    assert [item.file_name for item in result.checksums] == (
        expected_checksum_names
    )
    for layout, gds_path, lef_path in zip(
        layouts,
        result.gds_paths,
        result.lef_paths,
    ):
        selected = next(
            layer
            for layer in layout.layers
            if layer.definition.uid == config.al_pad_layer_uid
        )
        gds_points = _gds_layer_points_dbu(
            gds_path,
            config,
            selected.definition,
        )
        lef_points = _lef_polygon_points_dbu(
            lef_path.read_text(encoding="ascii"),
            config.dbu_um,
        )
        assert gds_points == selected.points_dbu
        assert lef_points == selected.points_dbu


@pytest.mark.parametrize("dbu_um", [Decimal("0.001"), Decimal("0.0005")])
@pytest.mark.parametrize(
    ("zero_axis", "rotation_direction"),
    [
        (ZeroDegreeAxis.X, RotationDirection.COUNTERCLOCKWISE),
        (ZeroDegreeAxis.X, RotationDirection.CLOCKWISE),
        (ZeroDegreeAxis.Y, RotationDirection.COUNTERCLOCKWISE),
        (ZeroDegreeAxis.Y, RotationDirection.CLOCKWISE),
    ],
)
def test_gds_readback_confirms_45_135_reflections_for_all_conventions(
    tmp_path,
    dbu_um,
    zero_axis,
    rotation_direction,
) -> None:
    config = sample_oval()
    config.dbu_um = dbu_um
    config.zero_degree_axis = zero_axis
    config.rotation_direction = rotation_direction
    layouts = build_layouts(config)
    readbacks = {}

    for layout in layouts:
        path = write_gds(
            tmp_path / layout.gds_file_name,
            config,
            layout,
        )
        readbacks[layout.logical_angle] = verify_gds(
            path,
            config,
            layout,
        )

    verify_oval_gds_readback_reflections(readbacks, layouts)


def test_gds_readback_rejects_asymmetric_oval_even_when_expected_matches(
    tmp_path,
) -> None:
    config = sample_oval()
    config.origin_mode = OriginMode.CENTER
    layout = build_layouts(config)[1]
    layer = layout.layers[0]
    tampered_points = list(layer.points_dbu)
    x, y = tampered_points[1]
    tampered_points[1] = (x + 1, y)
    tampered_layer = replace(layer, points_dbu=tuple(tampered_points))
    tampered_layout = replace(
        layout,
        layers=(tampered_layer, *layout.layers[1:]),
    )
    path = write_gds(
        tmp_path / tampered_layout.gds_file_name,
        config,
        tampered_layout,
    )

    with pytest.raises(
        GdsVerificationError,
        match="not centrally symmetric after GDS readback",
    ):
        verify_gds(path, config, tampered_layout)


def test_gds_readback_rejects_45_135_pair_that_is_individually_symmetric(
    tmp_path,
) -> None:
    config = sample_oval()
    config.origin_mode = OriginMode.CENTER
    layouts = {
        layout.logical_angle: layout
        for layout in build_layouts(config)
    }
    layout_45 = layouts[45]
    layout_135 = layouts[135]
    layer_135 = layout_135.layers[0]
    scaled_layer_135 = replace(
        layer_135,
        points_dbu=tuple(
            (x * 2, y * 2)
            for x, y in layer_135.points_dbu
        ),
    )
    mismatched_layout_135 = replace(
        layout_135,
        layers=(scaled_layer_135, *layout_135.layers[1:]),
    )

    path_45 = write_gds(
        tmp_path / layout_45.gds_file_name,
        config,
        layout_45,
    )
    path_135 = write_gds(
        tmp_path / mismatched_layout_135.gds_file_name,
        config,
        mismatched_layout_135,
    )
    readbacks = {
        45: verify_gds(path_45, config, layout_45),
        135: verify_gds(
            path_135,
            config,
            mismatched_layout_135,
        ),
    }

    with pytest.raises(
        GdsVerificationError,
        match="not X-axis reflections",
    ):
        verify_oval_gds_readback_reflections(
            readbacks,
            (layout_45, mismatched_layout_135),
        )


def test_lef_bump_pin_and_polygon_match_selected_gds_layer() -> None:
    config = sample_round()
    config.al_pad_layer_uid = config.layers[2].uid
    layout = build_layouts(config)[0]
    text = lef_text(config, layout)
    selected = layout.layers[2]

    assert "  PIN BUMP\n" in text
    assert "  END BUMP\n" in text
    assert "  PIN PIO\n" not in text
    assert "      LAYER PIO ;\n" in text
    assert "LAYER AP" not in text
    assert "LAYER CB2" not in text
    assert "LAYER UBM" not in text
    assert "NAMESCASESENSITIVE" not in text
    assert "\nUNITS\n" not in text
    assert "\n  ORIGIN " in text
    assert "\n      CLASS BUMP ;" not in text
    assert re.search(r"^\s*POLYGON [^\n]+ ;$", text, flags=re.MULTILINE)
    points = _lef_polygon_points(text)
    assert len(points) == 64
    assert points == tuple(
        (
            Decimal(x) * config.dbu_um,
            Decimal(y) * config.dbu_um,
        )
        for x, y in selected.points_dbu
    )


def test_lef_layer_preserves_confirmed_name_case_with_fixed_bump_pin() -> None:
    config = sample_round()
    config.layers[0].meaning = "AlPad"
    text = lef_text(config, build_layouts(config)[0])
    assert "  PIN BUMP\n" in text
    assert "      LAYER AlPad ;\n" in text
    assert "  END BUMP\n" in text


def test_center_origin_lef_uses_positive_origin_and_copies_gds_polygon() -> None:
    config = sample_round()
    config.origin_mode = OriginMode.CENTER
    layout = build_layouts(config)[0]
    text = lef_text(config, layout)
    selected = layout.layers[0]

    assert f"  FOREIGN {layout.cell_name} -40.000 -40.000 ;" in text
    assert "  ORIGIN 40.000 40.000 ;" in text
    assert "  SIZE 80.000 BY 80.000 ;" in text
    assert _lef_polygon_points_dbu(text, config.dbu_um) == selected.points_dbu
    assert _lef_polygon_points_dbu(text, config.dbu_um)[0] == (80000, 0)


def test_user_oval_template_uses_official_foreign_and_origin_offsets() -> None:
    config = sample_oval()
    config.bump_type = "CuBOT"
    config.layers[0].minor_axis_um = Decimal("44")
    config.layers[0].major_axis_um = Decimal("74")
    config.layers[-1].minor_axis_um = Decimal("40")
    config.layers[-1].major_axis_um = Decimal("70")
    layout = build_layouts(config)[2]
    text = lef_text(config, layout)

    assert layout.cell_name == "CuBOT_AP4474_UBM4070_90D"
    assert (
        "  CLASS COVER BUMP ;\n"
        "  FOREIGN CuBOT_AP4474_UBM4070_90D 0.000 0.000 ;\n"
        "  ORIGIN 0.000 0.000 ;\n\n"
        "  SIZE 44.000 BY 74.000 ;"
    ) in text
    assert _lef_polygon_points(text)[0] == (Decimal("22"), Decimal("74"))

    config.origin_mode = OriginMode.CENTER
    centered_layout = build_layouts(config)[2]
    centered_text = lef_text(config, centered_layout)
    centered_selected = centered_layout.layers[0]
    assert (
        "  FOREIGN CuBOT_AP4474_UBM4070_90D -22.000 -37.000 ;\n"
        "  ORIGIN 22.000 37.000 ;\n\n"
        "  SIZE 44.000 BY 74.000 ;"
    ) in centered_text
    assert _lef_polygon_points_dbu(
        centered_text,
        config.dbu_um,
    ) == centered_selected.points_dbu
    assert _lef_polygon_points(centered_text)[0] == (
        Decimal("0"),
        Decimal("37"),
    )


def test_oval_lef_uses_all_66_gds_nodes_for_each_angle() -> None:
    config = sample_oval()
    for layout in build_layouts(config):
        text = lef_text(config, layout)
        points = _lef_polygon_points(text)
        selected = next(
            layer
            for layer in layout.layers
            if layer.definition.uid == config.al_pad_layer_uid
        )
        assert len(points) == 66
        assert points == tuple(
            (
                Decimal(x) * config.dbu_um,
                Decimal(y) * config.dbu_um,
            )
            for x, y in selected.points_dbu
        )


def test_intended_paths_include_each_gds_lef_pair_and_one_report(tmp_path) -> None:
    paths = intended_paths(sample_oval(), tmp_path)
    assert len(paths) == 9
    assert [path.suffix for path in paths] == [
        ".gds",
        ".lef",
        ".gds",
        ".lef",
        ".gds",
        ".lef",
        ".gds",
        ".lef",
        ".pdf",
    ]


def test_combined_report_uses_one_section_per_table_and_preview(
    tmp_path,
    monkeypatch,
) -> None:
    import easybumpcell.services.pdf_report as pdf_report

    section_titles = []
    original_section = pdf_report._section

    def recording_section(title, content, styles, **kwargs):
        section_titles.append(title)
        return original_section(title, content, styles, **kwargs)

    monkeypatch.setattr(pdf_report, "_section", recording_section)
    export_project_shapes(
        sample_round_and_oval(),
        (ShapeType.ROUND, ShapeType.OVAL),
        tmp_path,
    )

    assert section_titles == [
        "LEF PIN Layer and Process DBU",
        "Layer Number/Datatype Mapping",
        "GDS Preview - Common Scale",
        "LEF Preview - Common Scale",
        "Generated GDS, LEF, Cell and Macro Names",
        "POSIX Checksums",
        "Nominal Dimensions vs Actual Quantized Axis Dimensions",
        "Coordinate and Validation Summary",
    ]


def test_exporting_both_shapes_writes_all_files_and_one_combined_report(
    tmp_path,
) -> None:
    config = sample_round_and_oval()
    shape_types = (ShapeType.ROUND, ShapeType.OVAL)

    paths = intended_paths_for_shapes(config, shape_types, tmp_path)
    result = export_project_shapes(config, shape_types, tmp_path)

    assert len(paths) == 11
    assert len(result.gds_paths) == 5
    assert len(result.lef_paths) == 5
    assert len(result.checksums) == 10
    assert all(path.is_file() for path in paths)
    assert any("_Round_" in path.name for path in result.gds_paths)
    assert sum("_Oval_" in path.name for path in result.gds_paths) == 4
    assert result.report_path.name == (
        "TechName_LF_Round_Oval_Report_V1.pdf"
    )
    assert result.report_path.stat().st_size > 1000
    assert combined_shape_report_name(config, shape_types) == (
        result.report_path.name
    )


def test_failed_lef_verification_keeps_formal_output_empty(
    tmp_path,
    monkeypatch,
) -> None:
    import easybumpcell.services.batch_export as batch_export

    def fail_verification(*args, **kwargs):
        raise ValueError("synthetic LEF verification failure")

    monkeypatch.setattr(batch_export, "verify_lef", fail_verification)
    with pytest.raises(ValueError, match="synthetic LEF"):
        batch_export.export_project(sample_round(), tmp_path)
    assert list(tmp_path.iterdir()) == []


def test_failed_oval_gds_readback_symmetry_keeps_formal_output_empty(
    tmp_path,
    monkeypatch,
) -> None:
    import easybumpcell.services.batch_export as batch_export

    def fail_verification(*args, **kwargs):
        raise GdsVerificationError("synthetic GDS symmetry failure")

    monkeypatch.setattr(
        batch_export,
        "verify_oval_gds_readback_reflections",
        fail_verification,
    )
    with pytest.raises(GdsVerificationError, match="synthetic GDS symmetry"):
        batch_export.export_project(sample_oval(), tmp_path)
    assert list(tmp_path.iterdir()) == []
