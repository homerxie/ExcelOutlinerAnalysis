from __future__ import annotations

from pathlib import Path
import sys

import pytest
from PySide6.QtCore import QSize
from PySide6.QtGui import QIcon

from easybumpcell.app_resources import (
    find_icon_directory,
    icon_directory_candidates,
    load_application_icon,
)
from scripts.package_windows_release import _pyinstaller_command


ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.skipif(
    sys.platform != "darwin",
    reason="macOS ICNS rendering is only available on macOS",
)
def test_macos_icon_has_transparent_safe_margin(qapp) -> None:
    icon = QIcon(str(ROOT / "Icon" / "NeonDoubleRingIcon.icns"))
    image = icon.pixmap(QSize(1024, 1024)).toImage()

    assert image.pixelColor(50, 512).alpha() == 0
    assert image.pixelColor(512, 512).alpha() > 0


def test_application_icon_loads_all_required_source_sizes(qapp) -> None:
    assert find_icon_directory() == ROOT / "Icon"
    icon = load_application_icon()
    assert not icon.isNull()
    available_sizes = set(icon.availableSizes())
    if sys.platform == "darwin":
        assert QSize(32, 32) in available_sizes
        assert QSize(512, 512) in available_sizes
        assert QSize(1024, 1024) in available_sizes
        assert QSize(16, 16) not in available_sizes
        return

    assert QSize(16, 16) in available_sizes
    assert QSize(64, 64) in available_sizes
    assert QSize(256, 256) in available_sizes
    assert QSize(1024, 1024) in available_sizes


def test_frozen_icon_candidates_include_internal_directories(
    monkeypatch,
    tmp_path,
) -> None:
    executable = tmp_path / "EasyBumpcell.exe"
    pyinstaller_root = tmp_path / "internal"
    monkeypatch.setattr(sys, "frozen", True, raising=False)
    monkeypatch.setattr(sys, "executable", str(executable))
    monkeypatch.setattr(
        sys,
        "_MEIPASS",
        str(pyinstaller_root),
        raising=False,
    )

    candidates = icon_directory_candidates()
    assert pyinstaller_root / "Icon" in candidates
    assert tmp_path / "internal" / "Icon" in candidates
    assert tmp_path / "_internal" / "Icon" in candidates


def test_windows_packaging_places_icons_under_internal() -> None:
    command = _pyinstaller_command()
    assert command[command.index("--contents-directory") + 1] == "internal"
    data_mapping = command[command.index("--add-data") + 1]
    source, destination = data_mapping.rsplit(";", 1)
    assert Path(source) == ROOT / "Icon"
    assert destination == "Icon"
    assert Path(command[command.index("--icon") + 1]) == (
        ROOT / "Icon" / "NeonDoubleRingIcon.ico"
    )
