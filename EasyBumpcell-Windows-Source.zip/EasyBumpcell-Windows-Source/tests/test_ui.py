from __future__ import annotations

from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path

from PySide6.QtGui import (
    QIcon,
    QKeySequence,
    QMouseEvent,
    QPixmap,
    QValidator,
)
from PySide6.QtCore import QEvent, QPoint, QPointF, Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QGridLayout,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QSizePolicy,
    QSpinBox,
    QStyle,
)

from easybumpcell import APPLICATION_TITLE
from easybumpcell.domain.enums import OriginMode, RotationDirection, ShapeType, ZeroDegreeAxis
from easybumpcell.domain.models import ProjectConfig
from easybumpcell.export_checklist import (
    DEFAULT_EXPORT_CHECKLIST_PATH,
    load_export_checklist,
)
from easybumpcell.preview_patterns import DEFAULT_PREVIEW_PATTERNS
from easybumpcell.services.process_templates import (
    load_process_template,
    process_template_from_config,
    save_process_template,
)
import easybumpcell.ui.main_window as main_window_module
from easybumpcell.ui.advanced_dialog import AdvancedSettingsDialog
from easybumpcell.ui.export_dialog import ExportConfirmationDialog
from easybumpcell.ui.export_shape_dialog import ExportShapeDialog
from easybumpcell.ui.main_window import (
    LAYER_MAPPING_HELP_IMAGE,
    PROCESS_DBU_HELP_IMAGE,
    MainWindow,
)
from easybumpcell.ui.preview_widget import (
    _format_tick,
    _nice_tick_spacing,
    _tick_values,
)
from easybumpcell.ui.template_save_dialog import TemplateSaveDialog


def _fill_round_window(window: MainWindow) -> None:
    window.ui.technologyEdit.setText("TechName")
    window.ui.bumpTypeEdit.setText("LF")
    window.ui.versionEdit.setText("V1")
    values = [
        ("AP", 1, 0, 80),
        ("ALPAD", 5, 0, 70),
        ("CB2", 2, 0, 40),
        ("PIO", 3, 0, 30),
        ("UBM", 4, 0, 60),
        ("UBM_CU", 6, 0, 90),
    ]
    for row, (_, layer_number, datatype, diameter) in enumerate(values):
        window.model.setData(window.model.index(row, 2), layer_number)
        window.model.setData(window.model.index(row, 3), datatype)
        window.model.setData(window.model.index(row, 4), diameter)
    window.ui.alPadLayerCombo.setCurrentIndex(
        window.ui.alPadLayerCombo.findData(window.config.layers[0].uid)
    )


def _send_mouse_move(widget, point: QPoint) -> None:
    local_position = QPointF(point)
    global_position = QPointF(widget.mapToGlobal(point))
    event = QMouseEvent(
        QEvent.Type.MouseMove,
        local_position,
        global_position,
        Qt.MouseButton.NoButton,
        Qt.MouseButton.NoButton,
        Qt.KeyboardModifier.NoModifier,
    )
    QApplication.sendEvent(widget, event)


def test_main_window_starts_with_default_layers(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    assert window.minimumHeight() == 820
    assert window.model.rowCount() == 6
    assert [
        window.model.headerData(
            column,
            Qt.Orientation.Horizontal,
            Qt.ItemDataRole.DisplayRole,
        )
        for column in range(4)
    ] == ["Tapeout?", "Layer Name", "Layer Number", "Datatype"]
    assert [layer.tapeout for layer in window.config.layers] == [
        True,
        False,
        True,
        True,
        True,
        False,
    ]
    assert [
        window.model.data(
            window.model.index(row, 0),
            Qt.ItemDataRole.CheckStateRole,
        )
        for row in range(window.model.rowCount())
    ] == [
        Qt.CheckState.Checked,
        Qt.CheckState.Unchecked,
        Qt.CheckState.Checked,
        Qt.CheckState.Checked,
        Qt.CheckState.Checked,
        Qt.CheckState.Unchecked,
    ]
    tapeout_tooltip = "Only tapeout layers participate in GDS and Cell naming."
    assert (
        window.model.headerData(
            0,
            Qt.Orientation.Horizontal,
            Qt.ItemDataRole.ToolTipRole,
        )
        == tapeout_tooltip
    )
    assert all(
        window.model.data(
            window.model.index(row, 0),
            Qt.ItemDataRole.ToolTipRole,
        )
        == tapeout_tooltip
        for row in range(window.model.rowCount())
    )
    assert window.config.dbu_um == Decimal("0.0005")
    assert [
        window.ui.dbuCombo.itemText(index)
        for index in range(window.ui.dbuCombo.count())
    ] == ["0.001 µm", "0.0005 µm"]
    assert window.ui.dbuCombo.currentData() == "0.0005"
    assert window.ui.dbuHintLabel.text() == (
        "Please confirm that the Process DBU exactly matches the DBU "
        "definition in the — Process techfile (*.tf)."
    )
    assert (
        window.ui.dbuHintLabel.minimumSize()
        == window.ui.processHintLabel.minimumSize()
    )
    assert (
        window.ui.dbuHintLabel.maximumSize()
        == window.ui.processHintLabel.maximumSize()
    )
    assert (
        window.ui.dbuHintLabel.sizePolicy()
        == window.ui.processHintLabel.sizePolicy()
    )
    assert (
        window.ui.dbuHintLabel.styleSheet()
        == window.ui.processHintLabel.styleSheet()
    )
    assert window.ui.dbuHintLabel.wordWrap()
    assert window.ui.processHintLabel.wordWrap()
    selectable_text_flags = (
        Qt.TextInteractionFlag.TextSelectableByKeyboard
        | Qt.TextInteractionFlag.TextSelectableByMouse
    )
    for warning_label in (
        window.ui.dbuHintLabel,
        window.ui.processHintLabel,
        window.ui.alPadHintLabel,
    ):
        assert (
            warning_label.textInteractionFlags()
            & selectable_text_flags
        ) == selectable_text_flags
    assert (
        window.ui.alPadHintLabel.minimumSize()
        == window.ui.processHintLabel.minimumSize()
    )
    assert (
        window.ui.alPadHintLabel.maximumSize()
        == window.ui.processHintLabel.maximumSize()
    )
    assert (
        window.ui.alPadHintLabel.sizePolicy()
        == window.ui.processHintLabel.sizePolicy()
    )
    assert (
        window.ui.alPadHintLabel.styleSheet()
        == window.ui.processHintLabel.styleSheet()
    )
    assert window.ui.alPadHintLabel.wordWrap()
    assert isinstance(window.ui.projectGrid, QGridLayout)
    assert window.ui.projectGrid.verticalSpacing() == 6
    assert window.ui.projectGrid.horizontalSpacing() == 6
    assert [
        window.ui.projectGrid.columnStretch(column)
        for column in range(4)
    ] == [0, 1, 0, 1]
    assert window.ui.layersLayout.spacing() == 6
    assert (
        window.ui.summaryGroup.sizePolicy().verticalPolicy()
        is QSizePolicy.Policy.Minimum
    )
    assert [layer.meaning for layer in window.config.layers] == [
        "AP",
        "ALPAD",
        "CB2",
        "PIO",
        "UBM",
        "UBM_CU",
    ]
    assert [layer.preview_pattern for layer in window.config.layers] == list(
        DEFAULT_PREVIEW_PATTERNS[:6]
    )
    assert not window.ui.exportButton.isEnabled()
    assert not window.ui.exportButton.isDefault()
    assert window.ui.advancedSettingsAction.isEnabled()
    assert window.ui.processHintLabel.text() == (
        "Please confirm:\n"
        "1. The following GDS Layers and their Layer Number/Datatype match "
        "the design rule for the current Bump type of — Process. This "
        "will affect the accuracy of GDS generation.\n"
        "2. The mapping between the Al drawing layer's Layer Name and its "
        "Layer Number/Datatype matches the definition in the layermap "
        "(*.map / *.layermap) of — Process. This will affect the accuracy "
        "of LEF generation."
    )
    assert not window.ui.settingsSummaryLabel.wordWrap()
    assert window.ui.settingsSummaryLabel.sizePolicy().verticalPolicy() is QSizePolicy.Policy.Fixed
    assert window.ui.settingsSummaryLabel.maximumHeight() == 24
    assert isinstance(window.ui.validationText, QPlainTextEdit)
    assert window.ui.validationText.isReadOnly()
    expected_validation_height = (
        window.ui.validationText.fontMetrics().lineSpacing() * 3
        + round(
            window.ui.validationText.document().documentMargin() * 2
        )
        + window.ui.validationText.frameWidth() * 2
    )
    assert window.ui.validationText.height() == expected_validation_height
    assert window.ui.validationText.height() < 96
    assert window.ui.validationCaption.alignment() & Qt.AlignmentFlag.AlignTop
    layer_name_index = window.model.index(0, 1)
    assert isinstance(
        window.model.data(layer_name_index, Qt.ItemDataRole.DecorationRole),
        QIcon,
    )
    assert "Forward Diagonal" in window.model.data(
        layer_name_index,
        Qt.ItemDataRole.ToolTipRole,
    )
    assert window.ui.showNodesCheck.isChecked()
    assert window.ui.snapNodesCheck.isChecked()
    assert window.preview.show_nodes
    assert window.preview.snap_to_nodes
    assert window.lef_preview.show_nodes
    assert window.lef_preview.snap_to_nodes
    assert (
        window.ui.previewTabs.cornerWidget(Qt.Corner.TopRightCorner)
        is window.ui.nodeControlsWidget
    )
    assert window.ui.versionEdit.text() == ""
    assert "not to the internal GDS Cell name" in window.ui.versionEdit.toolTip()
    assert window.ui.generatedNameCaption.text() == "Cell Base Name"
    assert not window.ui.generatedNameLabel.wordWrap()
    assert window.ui.generatedNameLabel.maximumHeight() == 24
    assert (
        window.ui.generatedNameLabel.sizePolicy().verticalPolicy()
        is QSizePolicy.Policy.Fixed
    )
    assert window.ui.summaryForm.verticalSpacing() == 4
    assert not hasattr(window.ui, "summaryBottomSpacer")
    assert window.ui.nodeCountCaption.text() == "Polygon"
    assert window.ui.nodeCountLabel.text() == "—"
    assert not hasattr(window.ui, "centerSummaryCaption")
    assert not hasattr(window.ui, "centerSummaryLabel")
    version_validator = window.ui.versionEdit.validator()
    assert version_validator.validate("V1.2-rc1", 8)[0] == QValidator.State.Acceptable
    assert version_validator.validate("V1_bad", 6)[0] == QValidator.State.Invalid
    assert "PDF" in window.ui.showNodesCheck.toolTip()
    assert "PDF" in window.ui.snapNodesCheck.toolTip()
    assert "GDS and LEF" in window.ui.showNodesCheck.toolTip()
    assert "GDS and LEF" in window.ui.snapNodesCheck.toolTip()
    assert window.ui.previewTabs.count() == 2
    assert window.ui.previewTabs.tabText(0) == "GDS Preview"
    assert window.ui.previewTabs.tabText(1) == "LEF Preview"
    assert window.ui.alPadLayerCombo.currentData() is None
    assert window.config.al_pad_layer_uid is None
    assert window.config.layers[0].meaning == "AP"


def test_process_template_controls_are_above_process(qtbot, tmp_path) -> None:
    window = MainWindow(template_directory=tmp_path / "template")
    qtbot.addWidget(window)

    assert window.ui.templateGroup.title() == "Process Templates"
    assert window.ui.controlLayout.indexOf(window.ui.templateGroup) < (
        window.ui.controlLayout.indexOf(window.ui.projectGroup)
    )
    assert window.ui.templateCombo.currentData() is None
    assert not hasattr(window.ui, "templateSuffixEdit")
    assert not window.ui.deleteTemplateButton.isEnabled()
    assert not window.ui.exportTemplateButton.isEnabled()
    assert str(tmp_path / "template") in window.ui.templateCombo.toolTip()


def test_template_save_dialog_previews_file_name_and_validates_suffix(
    qtbot,
) -> None:
    config = ProjectConfig(
        technology_name="N3Tech",
        bump_type="LF",
        shape_type=ShapeType.OVAL,
    )
    for index, layer in enumerate(config.layers):
        layer.diameter_um = Decimal(50 + index * 10)
        layer.minor_axis_um = Decimal(30 + index * 10)
        layer.major_axis_um = Decimal(60 + index * 10)
    dialog = TemplateSaveDialog(config)
    qtbot.addWidget(dialog)
    save_button = dialog.ui.buttonBox.button(
        QDialogButtonBox.StandardButton.Save
    )

    assert dialog.file_name() == "N3Tech_LF_Round_Oval.json"
    assert dialog.ui.shapeStatusLabel.text() == (
        "Both Round and Oval dimensions will be saved."
    )
    assert dialog.ui.roundCheck.isChecked()
    assert dialog.ui.ovalCheck.isChecked()
    assert dialog.selected_shape_types() == (
        ShapeType.ROUND,
        ShapeType.OVAL,
    )
    assert save_button.isEnabled()
    assert dialog.ui.templateForm.getWidgetPosition(
        dialog.ui.fileNamePreviewLabel
    )[0] < dialog.ui.templateForm.getWidgetPosition(
        dialog.ui.suffixEdit
    )[0]

    dialog.ui.suffixEdit.setText("Rev-1.2")

    assert dialog.custom_suffix() == "Rev-1.2"
    assert dialog.file_name() == "N3Tech_LF_Round_Oval_Rev-1.2.json"
    assert save_button.isEnabled()
    validator = dialog.ui.suffixEdit.validator()
    assert (
        validator.validate("bad suffix", len("bad suffix"))[0]
        is QValidator.State.Invalid
    )
    assert (
        validator.validate("_leading", len("_leading"))[0]
        is QValidator.State.Invalid
    )

    dialog.ui.ovalCheck.setChecked(False)
    assert dialog.selected_shape_types() == (ShapeType.ROUND,)
    assert dialog.file_name() == "N3Tech_LF_Round_Rev-1.2.json"
    assert dialog.ui.shapeStatusLabel.text() == (
        "Only Round dimensions will be saved."
    )

    dialog.ui.roundCheck.setChecked(False)
    assert dialog.file_name() == "—"
    assert not save_button.isEnabled()
    assert dialog.ui.shapeStatusLabel.text() == (
        "Select at least one shape to save."
    )


def test_save_template_uses_generated_name_and_can_overwrite(
    qtbot,
    tmp_path,
    monkeypatch,
) -> None:
    template_directory = tmp_path / "template"
    window = MainWindow(template_directory=template_directory)
    qtbot.addWidget(window)
    _fill_round_window(window)
    dialog_suffixes: list[str] = []

    class FakeTemplateSaveDialog:
        def __init__(self, _config, *, initial_suffix, parent):
            dialog_suffixes.append(initial_suffix)

        def exec(self):
            return True

        def custom_suffix(self):
            return "Rev_A"

        def selected_shape_types(self):
            return (ShapeType.ROUND,)

    monkeypatch.setattr(
        main_window_module,
        "TemplateSaveDialog",
        FakeTemplateSaveDialog,
    )
    notices: list[str] = []
    monkeypatch.setattr(
        QMessageBox,
        "information",
        lambda _parent, _title, message, *_args: notices.append(message),
    )

    window._save_template()

    path = template_directory / "TechName_LF_Round_Rev_A.json"
    assert path.is_file()
    document = json.loads(path.read_text(encoding="utf-8"))
    assert "version" not in document
    assert document["technology_name"] == "TechName"
    assert document["shape_types"] == ["Round"]
    assert window.ui.templateCombo.currentData() == str(path)
    assert window.ui.exportTemplateButton.isEnabled()
    assert notices

    window.config.layers[0].layer = 99
    overwrite_prompts: list[str] = []

    def approve_overwrite(_parent, _title, message, *_args):
        overwrite_prompts.append(message)
        return QMessageBox.StandardButton.Yes

    monkeypatch.setattr(QMessageBox, "question", approve_overwrite)
    window._save_template()

    assert overwrite_prompts == [
        'Replace the stored template "TechName_LF_Round_Rev_A"?'
    ]
    assert dialog_suffixes == ["", "Rev_A"]
    assert load_process_template(path).layers[0].layer == 99


def test_selected_template_can_be_deleted_after_confirmation(
    qtbot,
    tmp_path,
    monkeypatch,
) -> None:
    template_directory = tmp_path / "template"
    config = ProjectConfig(technology_name="DeleteTech")
    for layer in config.layers:
        layer.diameter_um = Decimal("50")
    template = process_template_from_config(config, "Old")
    path = save_process_template(
        template,
        template_directory / f"{template.name}.json",
    )
    window = MainWindow(template_directory=template_directory)
    qtbot.addWidget(window)
    window._refresh_template_combo(path)
    assert window.ui.deleteTemplateButton.isEnabled()

    monkeypatch.setattr(
        QMessageBox,
        "question",
        lambda *_args, **_kwargs: QMessageBox.StandardButton.Cancel,
    )
    window._delete_template()
    assert path.is_file()

    notices: list[str] = []
    monkeypatch.setattr(
        QMessageBox,
        "question",
        lambda *_args, **_kwargs: QMessageBox.StandardButton.Yes,
    )
    monkeypatch.setattr(
        QMessageBox,
        "information",
        lambda _parent, _title, message, *_args: notices.append(message),
    )
    window._delete_template()

    assert not path.exists()
    assert window.ui.templateCombo.currentData() is None
    assert not window.ui.deleteTemplateButton.isEnabled()
    assert not window.ui.exportTemplateButton.isEnabled()
    assert notices == ['Template "DeleteTech_Round_Old" was deleted.']


def test_selecting_template_preserves_version_and_warns_user(
    qtbot,
    tmp_path,
    monkeypatch,
) -> None:
    template_directory = tmp_path / "template"
    source = MainWindow(template_directory=template_directory)
    qtbot.addWidget(source)
    _fill_round_window(source)
    source.config.dbu_um = Decimal("0.001")
    source.config.layers[0].layer = 88
    source.config.process_order_confirmed = True
    template = process_template_from_config(source.config, "Production")
    saved_path = save_process_template(
        template,
        template_directory / f"{template.name}.json",
    )

    window = MainWindow(template_directory=template_directory)
    qtbot.addWidget(window)
    window.ui.versionEdit.setText("V99")
    window.config.process_order_confirmed = True
    confirmations: list[str] = []

    def confirm_application(_parent, _title, message, *_args):
        confirmations.append(message)
        return QMessageBox.StandardButton.Ok

    monkeypatch.setattr(
        QMessageBox,
        "question",
        confirm_application,
    )

    window.ui.templateCombo.setCurrentIndex(
        window.ui.templateCombo.findData(str(saved_path))
    )

    assert window.config.technology_name == "TechName"
    assert window.config.bump_type == "LF"
    assert window.config.shape_type is ShapeType.ROUND
    assert window.config.layers[0].layer == 88
    assert window.config.dbu_um == Decimal("0.001")
    assert window.ui.dbuCombo.currentData() == "0.001"
    assert window.ui.versionEdit.text() == "V99"
    assert window.config.version == "V99"
    assert not window.config.process_order_confirmed
    assert confirmations == [
        "Please carefully check that the content is correct.\n\n"
        "Applying this template will replace all current content."
    ]


def test_canceling_template_application_preserves_current_content(
    qtbot,
    tmp_path,
    monkeypatch,
) -> None:
    template_directory = tmp_path / "template"
    config = ProjectConfig(
        technology_name="ReplacementTech",
        bump_type="Cu",
        dbu_um=Decimal("0.001"),
    )
    for layer in config.layers:
        layer.diameter_um = Decimal("50")
    template = process_template_from_config(config)
    path = save_process_template(
        template,
        template_directory / f"{template.name}.json",
    )
    window = MainWindow(template_directory=template_directory)
    qtbot.addWidget(window)
    window.ui.technologyEdit.setText("CurrentTech")
    window.ui.versionEdit.setText("V8")
    window.config.process_order_confirmed = True
    monkeypatch.setattr(
        QMessageBox,
        "question",
        lambda *_args, **_kwargs: QMessageBox.StandardButton.Cancel,
    )

    window.ui.templateCombo.setCurrentIndex(
        window.ui.templateCombo.findData(str(path))
    )

    assert window.config.technology_name == "CurrentTech"
    assert window.config.version == "V8"
    assert window.config.dbu_um == Decimal("0.0005")
    assert window.config.process_order_confirmed
    assert window.ui.templateCombo.currentData() is None


def test_export_shape_dialog_selects_available_shapes(qtbot) -> None:
    dialog = ExportShapeDialog(
        (ShapeType.ROUND, ShapeType.OVAL),
        ShapeType.ROUND,
    )
    qtbot.addWidget(dialog)
    ok_button = dialog.ui.buttonBox.button(
        QDialogButtonBox.StandardButton.Ok
    )

    assert dialog.ui.roundCheck.isChecked()
    assert not dialog.ui.ovalCheck.isChecked()
    assert dialog.selected_shapes() == (ShapeType.ROUND,)
    assert ok_button.isEnabled()
    assert dialog.ui.availabilityLabel.text() == (
        "Complete dimensions are available for both shapes."
    )

    dialog.ui.ovalCheck.setChecked(True)
    assert dialog.selected_shapes() == (ShapeType.ROUND, ShapeType.OVAL)

    dialog.ui.roundCheck.setChecked(False)
    dialog.ui.ovalCheck.setChecked(False)
    assert not ok_button.isEnabled()


def test_export_shape_dialog_disables_shape_with_missing_dimensions(
    qtbot,
) -> None:
    dialog = ExportShapeDialog((ShapeType.OVAL,), ShapeType.ROUND)
    qtbot.addWidget(dialog)

    assert not dialog.ui.roundCheck.isEnabled()
    assert dialog.ui.ovalCheck.isEnabled()
    assert dialog.ui.ovalCheck.isChecked()
    assert dialog.selected_shapes() == (ShapeType.OVAL,)
    assert dialog.ui.availabilityLabel.text() == (
        "Missing complete dimensions: Round"
    )


def test_template_application_confirmation_is_translated(
    qtbot,
    tmp_path,
    monkeypatch,
) -> None:
    window = MainWindow(template_directory=tmp_path / "template")
    qtbot.addWidget(window)
    window.ui.simplifiedChineseAction.trigger()
    prompts: list[tuple[str, str]] = []

    def cancel_application(_parent, title, message, *_args):
        prompts.append((title, message))
        return QMessageBox.StandardButton.Cancel

    monkeypatch.setattr(QMessageBox, "question", cancel_application)

    confirmed = window._confirm_template_application()
    window.ui.englishAction.trigger()

    assert not confirmed
    assert prompts == [
        (
            "应用工艺模板",
            "用户需仔细检查内容正确。\n\n"
            "应用该模版将替换当前所有内容。",
        )
    ]


def test_import_and_export_selected_process_template(
    qtbot,
    tmp_path,
    monkeypatch,
) -> None:
    external_directory = tmp_path / "external"
    library_directory = tmp_path / "template"
    export_directory = tmp_path / "exported"
    config = ProjectConfig(
        technology_name="N5Tech",
        bump_type="Cu",
        version="MustNotBeStored",
    )
    for layer in config.layers:
        layer.diameter_um = Decimal("50")
    template = process_template_from_config(config, "Imported")
    source_path = save_process_template(
        template,
        external_directory / f"{template.name}.json",
    )
    window = MainWindow(template_directory=library_directory)
    qtbot.addWidget(window)
    notices: list[str] = []
    confirmations: list[str] = []
    monkeypatch.setattr(
        QMessageBox,
        "information",
        lambda _parent, _title, message, *_args: notices.append(message),
    )
    monkeypatch.setattr(
        QMessageBox,
        "question",
        lambda _parent, _title, message, *_args: (
            confirmations.append(message)
            or QMessageBox.StandardButton.Ok
        ),
    )
    monkeypatch.setattr(
        QFileDialog,
        "getOpenFileName",
        lambda *_args, **_kwargs: (str(source_path), "JSON Files (*.json)"),
    )

    window._import_template()

    imported_path = library_directory / source_path.name
    assert imported_path.is_file()
    assert window.ui.templateCombo.currentData() == str(imported_path)
    assert window.config.technology_name == "N5Tech"
    assert window.ui.versionEdit.text() == ""
    assert confirmations == [
        "Please carefully check that the content is correct.\n\n"
        "Applying this template will replace all current content."
    ]

    export_path = export_directory / "shared-template.json"
    monkeypatch.setattr(
        QFileDialog,
        "getSaveFileName",
        lambda *_args, **_kwargs: (str(export_path), "JSON Files (*.json)"),
    )
    window._export_template()

    assert load_process_template(export_path) == template


def test_complete_round_project_enables_preview_and_export(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.refresh()
    assert window.ui.exportButton.isEnabled()
    assert len(window.preview.layouts) == 1
    assert window.preview.layouts[0].cell_name == "LF_AP80_UBM60"
    assert window.preview.layouts[0].gds_file_name.endswith("_V1.gds")
    assert len(window.lef_preview.layouts) == 1
    assert len(window.lef_preview.layouts[0].layers) == 1
    assert (
        window.lef_preview.layouts[0].layers[0].definition.uid
        == window.config.layers[0].uid
    )
    assert window.lef_preview.lef_mode
    assert not hasattr(window.ui, "lefPinSummaryLabel")
    hint = window.ui.alPadHintLabel.text()
    assert hint == (
        "Please confirm again: AP 1.0 is the actual Al Drawing Layer in "
        "use (not a Marking Layer or Dummy Layer)."
    )
    assert "BOUNDARY" not in hint
    assert "SIZE" not in hint
    assert window.ui.nodeCountLabel.text() == "64-gon"


def test_export_is_available_when_only_noncurrent_shape_is_complete(
    qtbot,
) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    for index, layer in enumerate(window.config.layers):
        layer.diameter_um = None
        layer.minor_axis_um = Decimal(20 + index * 5)
        layer.major_axis_um = Decimal(40 + index * 10)
    window.config.process_order_confirmed = True
    window.refresh()

    assert window.config.shape_type is ShapeType.ROUND
    assert window.ui.exportButton.isEnabled()


def test_process_confirmation_hints_use_actual_technology_name(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.ui.technologyEdit.setText("N3Tech")
    window.refresh()

    assert window.ui.dbuHintLabel.text() == (
        "Please confirm that the Process DBU exactly matches the DBU "
        "definition in the N3Tech Process techfile (*.tf)."
    )
    assert window.ui.processHintLabel.text() == (
        "Please confirm:\n"
        "1. The following GDS Layers and their Layer Number/Datatype match "
        "the design rule for the current Bump type of N3Tech Process. "
        "This will affect the accuracy of GDS generation.\n"
        "2. The mapping between the Al drawing layer's Layer Name and its "
        "Layer Number/Datatype matches the definition in the layermap "
        "(*.map / *.layermap) of N3Tech Process. This will affect the "
        "accuracy of LEF generation."
    )

    window.ui.simplifiedChineseAction.trigger()
    assert window.ui.dbuHintLabel.text() == (
        "请确认 Process DBU 与 N3Tech 工艺 techfile (*.tf) 中的 "
        "DBU 定义完全一致。"
    )
    assert window.ui.processHintLabel.text() == (
        "请确认：\n"
        "1. 以下 GDS Layer 及其 Layer Number、Datatype 与 N3Tech "
        "工艺当前 Bump 类型的design rule 一致。"
        "这将影响GDS文件的准确生成。\n"
        "2. Al drawing layer的Layer Name与Layer Number、Datatype的"
        "对应关系与N3Tech 工艺的layermap (*.map / *.layermap) "
        "文件中的定义一致。"
        "这将影响LEF文件的准确生成。"
    )
    window.ui.englishAction.trigger()


def test_warning_help_buttons_load_aspect_ratio_tooltip_images(
    qtbot,
    tmp_path,
    monkeypatch,
) -> None:
    help_directory = tmp_path / "help_images"
    help_directory.mkdir()
    process_image = QPixmap(1000, 500)
    process_image.fill(Qt.GlobalColor.red)
    assert process_image.save(
        str(help_directory / "process_dbu_help.png")
    )
    layer_image = QPixmap(200, 400)
    layer_image.fill(Qt.GlobalColor.blue)
    assert layer_image.save(
        str(help_directory / "layer_mapping_help.png")
    )
    monkeypatch.chdir(tmp_path)
    QApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    QApplication.processEvents()

    window = MainWindow()
    qtbot.addWidget(window)
    monkeypatch.setattr(
        window,
        "_help_image_bases",
        lambda: (tmp_path,),
    )

    assert window.ui.dbuHelpButton.text() == "?"
    assert window.ui.layerMappingHelpButton.text() == "?"
    assert window.ui.dbuHelpButton.size().width() == 24
    assert window.ui.dbuHelpButton.size().height() == 24
    assert "border-radius: 11px" in window.ui.dbuHelpButton.styleSheet()
    assert window.ui.dbuHelpButton.toolTip()
    process_pixmap, process_error = window._load_help_tooltip_pixmap(
        PROCESS_DBU_HELP_IMAGE,
        window.screen(),
    )
    layer_pixmap, layer_error = window._load_help_tooltip_pixmap(
        LAYER_MAPPING_HELP_IMAGE,
        window.screen(),
    )
    assert process_error is None
    assert layer_error is None
    assert process_pixmap is not None
    assert layer_pixmap is not None
    logical_limit = window._help_tooltip_logical_limit(window.screen())
    device_pixel_ratio = max(
        1.0,
        float(window.screen().devicePixelRatio()),
    )
    assert (
        abs(process_pixmap.devicePixelRatio() - device_pixel_ratio)
        < 0.001
    )
    assert (
        abs(layer_pixmap.devicePixelRatio() - device_pixel_ratio)
        < 0.001
    )
    assert process_pixmap.width() <= process_image.width()
    assert process_pixmap.height() <= process_image.height()
    assert layer_pixmap.width() <= layer_image.width()
    assert layer_pixmap.height() <= layer_image.height()
    process_logical_size = process_pixmap.deviceIndependentSize()
    layer_logical_size = layer_pixmap.deviceIndependentSize()
    assert process_logical_size.width() <= logical_limit.width()
    assert process_logical_size.height() <= logical_limit.height()
    assert layer_logical_size.width() <= logical_limit.width()
    assert layer_logical_size.height() <= logical_limit.height()
    assert abs(
        process_pixmap.width() / process_pixmap.height()
        - process_image.width() / process_image.height()
    ) < 0.01
    assert abs(
        layer_pixmap.width() / layer_pixmap.height()
        - layer_image.width() / layer_image.height()
    ) < 0.01
    assert logical_limit.width() <= 720
    assert logical_limit.height() <= 480
    missing_pixmap, missing_error = window._load_help_tooltip_pixmap(
        "help_images/missing.png"
    )
    assert missing_pixmap is None
    assert missing_error is not None
    assert "help_images/missing.png" in missing_error
    assert str(tmp_path) not in missing_error


def test_interface_language_switches_between_english_and_chinese(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)

    assert not hasattr(window.ui, "languageCombo")
    assert not hasattr(window.ui, "advancedButton")
    assert window.ui.englishAction.isChecked()
    assert not window.ui.simplifiedChineseAction.isChecked()
    assert window.ui.englishAction.text() == "English"
    assert window.ui.simplifiedChineseAction.text() == "简体中文"
    assert window.ui.settingsMenu.title() == "Settings"
    assert window.ui.languageMenu.title() == "Language"
    assert window.windowTitle() == APPLICATION_TITLE
    assert window.ui.templateGroup.title() == "Process Templates"
    assert window.ui.projectGroup.title() == "Process"
    assert window.config.shape_type is ShapeType.ROUND

    window.ui.simplifiedChineseAction.trigger()

    assert not window.ui.englishAction.isChecked()
    assert window.ui.simplifiedChineseAction.isChecked()
    assert window.ui.settingsMenu.title() == "设置"
    assert window.ui.languageMenu.title() == "语言"
    assert window.windowTitle() == APPLICATION_TITLE
    assert window.ui.advancedSettingsAction.text() == "高级设置"
    assert window.ui.templateGroup.title() == "工艺模板"
    assert window.ui.templateCombo.itemText(0) == "选择模板…"
    assert window.ui.deleteTemplateButton.text() == "删除"
    assert window.ui.projectGroup.title() == "工艺"
    assert window.ui.bumpTypeLabel.text() == "Bump Type"
    assert window.ui.processHintLabel.text() == (
        "请确认：\n"
        "1. 以下 GDS Layer 及其 Layer Number、Datatype 与 — "
        "工艺当前 Bump 类型的design rule 一致。"
        "这将影响GDS文件的准确生成。\n"
        "2. Al drawing layer的Layer Name与Layer Number、Datatype的"
        "对应关系与— 工艺的layermap (*.map / *.layermap) "
        "文件中的定义一致。"
        "这将影响LEF文件的准确生成。"
    )
    assert window.ui.dbuLabel.text() == "Process DBU（µm）*"
    assert window.ui.dbuHintLabel.text() == (
        "请确认 Process DBU 与 — 工艺 techfile (*.tf) 中的 "
        "DBU 定义完全一致。"
    )
    assert window.ui.shapeCombo.currentText() == "圆形"
    assert window.ui.shapeCombo.currentData() == ShapeType.ROUND.value
    assert window.config.shape_type is ShapeType.ROUND
    assert [
        window.model.headerData(column, Qt.Orientation.Horizontal)
        for column in range(window.model.columnCount())
    ] == ["Tapeout？", "Layer Name", "Layer Number", "Datatype", "直径（µm）"]
    tapeout_tooltip = "只有 Tapeout 的 Layer 参与 GDS 和 Cell 命名。"
    assert (
        window.model.headerData(
            0,
            Qt.Orientation.Horizontal,
            Qt.ItemDataRole.ToolTipRole,
        )
        == tapeout_tooltip
    )
    assert (
        window.model.data(
            window.model.index(0, 0),
            Qt.ItemDataRole.ToolTipRole,
        )
        == tapeout_tooltip
    )
    assert window.ui.previewTabs.tabText(0) == "GDS 预览"
    assert window.ui.previewTitleLabel.text() == "符合格点要求的 GDS 预览"
    assert window.ui.showNodesCheck.text() == "显示节点"
    assert window.ui.nodeCountCaption.text() == "多边形"
    assert "错误：" in window.ui.validationText.toPlainText()
    assert (
        window.ui.previewTabs.cornerWidget(Qt.Corner.TopRightCorner)
        is window.ui.nodeControlsWidget
    )
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.refresh()
    assert window.ui.nodeCountLabel.text() == "64边形"
    assert window.ui.alPadLayerLabel.text() == "Al Pad drawing *"
    assert window.ui.alPadHintLabel.text() == (
        "请再次确认：AP 1.0 是实际使用的 Al Drawing Layer"
        "（而不是 Marking Layer 或 Dummy Layer）。"
    )

    advanced = AdvancedSettingsDialog(window.config, window)
    qtbot.addWidget(advanced)
    assert advanced.windowTitle() == "高级设置"
    assert not hasattr(advanced.ui, "dbuSpin")
    assert not hasattr(advanced.ui, "dbuCombo")
    assert not hasattr(advanced.ui, "warningLabel")
    assert (
        advanced.ui.originModeCombo.itemText(0)
        == "Reference Layer Bounding Box 左下角"
    )
    assert (
        advanced.ui.buttonBox.button(
            QDialogButtonBox.StandardButton.Cancel
        ).text()
        == "取消"
    )

    template_save = TemplateSaveDialog(window.config, parent=window)
    qtbot.addWidget(template_save)
    assert template_save.windowTitle() == "保存工艺模板"
    assert template_save.ui.fileNameCaption.text() == "文件名预览"
    assert template_save.ui.suffixLabel.text() == "自定义后缀"
    assert template_save.ui.suffixEdit.placeholderText() == "可选"
    assert template_save.ui.shapeSelectionLabel.text() == "要保存的形状"
    assert template_save.ui.roundCheck.text() == "圆形"
    assert template_save.ui.ovalCheck.text() == "椭圆"
    assert template_save.ui.roundCheck.isEnabled()
    assert not template_save.ui.ovalCheck.isEnabled()
    assert template_save.ui.shapeStatusLabel.text() == "只保存圆形尺寸。"
    assert (
        template_save.ui.buttonBox.button(
            QDialogButtonBox.StandardButton.Cancel
        ).text()
        == "取消"
    )

    export = ExportConfirmationDialog(
        [Path("sample.gds")],
        [],
        [],
        window.config.layers[0],
        window,
    )
    qtbot.addWidget(export)
    assert export.windowTitle() == "确认导出"
    assert not hasattr(export.ui, "alPadSummaryLabel")
    assert export.ui.exportChecklist.count() == len(
        load_export_checklist("zh_CN").confirmations
    )
    checklist_text = "\n".join(export.checklist_texts())
    assert "GDS Layer 及其 Layer Number" in checklist_text
    assert "0.0005 µm" in checklist_text
    assert "Tapeout layers 及其正确的工艺顺序" in checklist_text
    assert "Al Drawing Layer" in checklist_text
    assert "1.0" in checklist_text
    assert "Layer Name 为 AP" in checklist_text
    assert "TechName 工艺" in checklist_text
    assert "AP → CB2 → PIO → UBM" in checklist_text
    assert (
        "AP 1,0\nALPAD 5,0\nCB2 2,0\nPIO 3,0\n"
        "UBM 4,0\nUBM_CU 6,0"
        in checklist_text
    )
    assert "techfile (*.tf)" in checklist_text
    assert "layermap (*.map / *.layermap)" in checklist_text
    assert not hasattr(export.ui, "warningLabel")
    assert not hasattr(export.ui, "riskAcknowledgeCheck")
    assert not hasattr(export.ui, "layermapAcknowledgeCheck")
    assert export.ui.exportChecklistGroup.styleSheet() == ""
    assert export.ui.checklistIntroLabel.styleSheet() == ""
    checklist_style = export.ui.exportChecklist.styleSheet()
    assert "#7A5200" in checklist_style
    assert "#FFF6D8" in checklist_style
    assert "#E6C86E" in checklist_style
    assert (
        export.ui.buttonBox.button(
            QDialogButtonBox.StandardButton.Save
        ).text()
        == "导出"
    )

    window.ui.englishAction.trigger()
    assert window.ui.englishAction.isChecked()
    assert not window.ui.simplifiedChineseAction.isChecked()
    assert window.ui.projectGroup.title() == "Process"
    assert window.ui.shapeCombo.currentText() == "Round"
    assert window.config.shape_type is ShapeType.ROUND


def test_advanced_settings_opens_from_settings_menu(qtbot, monkeypatch) -> None:
    opened_with = []

    class _FakeAdvancedSettingsDialog:
        def __init__(self, config, parent) -> None:
            opened_with.append((config, parent))

        def exec(self) -> bool:
            return False

    monkeypatch.setattr(
        "easybumpcell.ui.main_window.AdvancedSettingsDialog",
        _FakeAdvancedSettingsDialog,
    )
    window = MainWindow()
    qtbot.addWidget(window)

    window.ui.advancedSettingsAction.trigger()

    assert opened_with == [(window.config, window)]


def test_oval_mode_shows_four_layouts(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.ui.technologyEdit.setText("TechName")
    window.ui.bumpTypeEdit.setText("LF")
    window.ui.versionEdit.setText("V1")
    window.model.set_shape_type(ShapeType.OVAL)
    for row, layer in enumerate(window.config.layers):
        window.model.setData(window.model.index(row, 2), row + 1)
        window.model.setData(window.model.index(row, 3), 0)
        window.model.setData(window.model.index(row, 4), 10 + row * 10)
        window.model.setData(window.model.index(row, 5), 30 + row * 20)
    window.ui.alPadLayerCombo.setCurrentIndex(
        window.ui.alPadLayerCombo.findData(window.config.layers[0].uid)
    )
    window.config.process_order_confirmed = True
    window.refresh()
    window.resize(1380, 820)
    window.show()
    qtbot.waitUntil(lambda: len(window.preview._panel_views) == 4)
    assert window.ui.exportButton.isEnabled()
    assert [layout.logical_angle for layout in window.preview.layouts] == [0, 45, 90, 135]
    assert window.ui.nodeCountLabel.text() == "66-gon"
    assert len(window.preview._panel_views) == 4
    assert len({view.tick_spacing_um for view in window.preview._panel_views}) == 1
    assert len(window.lef_preview.layouts) == 4
    assert all(
        len(layout.layers) == 1
        and len(layout.layers[0].points_dbu) == 66
        for layout in window.lef_preview.layouts
    )


def test_reordering_resets_process_confirmation(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.config.process_order_confirmed = True
    original_style = (
        window.config.layers[0].color,
        window.config.layers[0].preview_pattern,
    )
    assert window.model.moveRows(
        window.model.index(-1, -1),
        0,
        1,
        window.model.index(-1, -1),
        3,
    )
    assert not window.config.process_order_confirmed
    assert [layer.meaning for layer in window.config.layers] == [
        "ALPAD",
        "CB2",
        "PIO",
        "AP",
        "UBM",
        "UBM_CU",
    ]
    assert (
        window.config.layers[3].color,
        window.config.layers[3].preview_pattern,
    ) == original_style


def test_confirmed_process_order_uses_compact_button_text(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.config.process_order_confirmed = True
    window.refresh()
    assert window.ui.confirmOrderButton.text() == "Order Confirmed"
    assert "current process order" in window.ui.confirmOrderButton.toolTip()


def test_tapeout_checkbox_updates_layer_and_invalidates_process_order(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.config.process_order_confirmed = True
    index = window.model.index(2, 0)

    assert window.model.flags(index) & Qt.ItemFlag.ItemIsUserCheckable
    assert window.model.setData(
        index,
        Qt.CheckState.Unchecked,
        Qt.ItemDataRole.CheckStateRole,
    )

    assert not window.config.layers[2].tapeout
    assert not window.config.process_order_confirmed
    assert (
        window.model.data(index, Qt.ItemDataRole.CheckStateRole)
        == Qt.CheckState.Unchecked
    )
    assert window.model.data(
        index,
        Qt.ItemDataRole.ToolTipRole,
    ) == "Only tapeout layers participate in GDS and Cell naming."


def test_non_tapeout_layers_are_hidden_from_naming_but_available_for_lef(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    ubm = window.config.layers[4]
    window.model.setData(
        window.model.index(4, 0),
        Qt.CheckState.Unchecked,
        Qt.ItemDataRole.CheckStateRole,
    )
    window.refresh()

    assert ubm.meaning not in window.ui.generatedNameLabel.text()
    assert window.ui.alPadLayerCombo.findData(ubm.uid) >= 0
    dialog = AdvancedSettingsDialog(window.config, window)
    qtbot.addWidget(dialog)
    assert ubm.uid not in [
        dialog.ui.cellNameLayersCombo.itemData(row)
        for row in range(dialog.ui.cellNameLayersCombo.count())
    ]


def test_dimension_editor_accepts_one_decimal_place(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    delegate = window.ui.layerTable.itemDelegateForColumn(4)
    editor = delegate.createEditor(window.ui.layerTable, None, window.model.index(0, 4))
    assert isinstance(editor, QDoubleSpinBox)
    assert editor.decimals() == 1
    assert editor.singleStep() == 0.1
    assert editor.minimum() == 0.1
    assert editor.maximum() > 1_000_000

    assert window.model.setData(
        window.model.index(0, 4),
        Decimal("80.5"),
    )
    assert window.config.layers[0].diameter_um == Decimal("80.5")
    assert window.model.data(window.model.index(0, 4)) == "80.5"


def test_integer_layer_editor_selects_zero_for_direct_replacement(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.show()
    qtbot.waitExposed(window)
    index = window.model.index(0, 2)
    delegate = window.ui.layerTable.itemDelegateForColumn(2)
    editor = delegate.createEditor(window.ui.layerTable, None, index)
    qtbot.addWidget(editor)
    editor.show()
    editor.setFocus()

    delegate.setEditorData(editor, index)
    qtbot.wait(1)

    assert isinstance(editor, QSpinBox)
    assert editor.maximum() == 65_535
    assert editor.lineEdit().selectedText() == "0"
    qtbot.keyClicks(editor, "12")
    assert editor.value() == 12

    datatype_index = window.model.index(0, 3)
    datatype_delegate = window.ui.layerTable.itemDelegateForColumn(3)
    datatype_editor = datatype_delegate.createEditor(
        window.ui.layerTable,
        None,
        datatype_index,
    )
    qtbot.addWidget(datatype_editor)
    assert datatype_editor.maximum() == 255


def test_layer_name_editor_is_text_and_rejects_spaces(
    qtbot,
    monkeypatch,
) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    monkeypatch.setattr(
        QMessageBox,
        "information",
        lambda *_args: QMessageBox.StandardButton.Ok,
    )
    delegate = window.ui.layerTable.itemDelegateForColumn(1)
    editor = delegate.createEditor(window.ui.layerTable, None, window.model.index(0, 1))
    assert isinstance(editor, QLineEdit)
    validator = editor.validator()
    assert validator.validate("CB2", 3)[0] == QValidator.State.Acceptable
    assert validator.validate("UBM_CU", 6)[0] == QValidator.State.Acceptable
    assert validator.validate("CB 2", 4)[0] == QValidator.State.Invalid
    assert window.model.setData(window.model.index(0, 1), "AP_PAD")
    assert window.config.layers[0].meaning == "AP_PAD"
    assert not window.model.setData(window.model.index(0, 1), "CB 2")
    assert window.config.layers[0].meaning == "AP_PAD"


def test_advanced_settings_preserve_enum_types(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    dialog = AdvancedSettingsDialog(window.config, window)
    qtbot.addWidget(dialog)
    dialog.ui.originModeCombo.setCurrentIndex(
        dialog.ui.originModeCombo.findData(OriginMode.CENTER.value)
    )
    dialog.ui.zeroAxisCombo.setCurrentIndex(
        dialog.ui.zeroAxisCombo.findData(ZeroDegreeAxis.Y.value)
    )
    dialog.ui.rotationDirectionCombo.setCurrentIndex(
        dialog.ui.rotationDirectionCombo.findData(RotationDirection.CLOCKWISE.value)
    )
    dialog.apply_to_config()
    assert window.config.origin_mode is OriginMode.CENTER
    assert window.config.zero_degree_axis is ZeroDegreeAxis.Y
    assert window.config.rotation_direction is RotationDirection.CLOCKWISE
    assert window._format_settings_summary().endswith("Origin Common Center")


def test_advanced_origin_reference_syncs_to_lef_al_pad_by_default(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    dialog = AdvancedSettingsDialog(window.config, window)
    qtbot.addWidget(dialog)

    assert dialog.ui.syncOriginToAlPadCheck.isChecked()
    assert not dialog.ui.originReferenceCombo.isEnabled()
    assert (
        dialog.ui.originReferenceCombo.currentData()
        == window.config.al_pad_layer_uid
    )

    dialog.ui.syncOriginToAlPadCheck.setChecked(False)
    assert dialog.ui.originReferenceCombo.isEnabled()
    manual_origin = window.config.layers[3]
    dialog.ui.originReferenceCombo.setCurrentIndex(
        dialog.ui.originReferenceCombo.findData(manual_origin.uid)
    )
    dialog.apply_to_config()

    assert not window.config.sync_origin_to_al_pad
    assert window.config.origin_reference_uid == manual_origin.uid


def test_process_dbu_is_edited_from_project_section(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)

    window.ui.dbuCombo.setCurrentIndex(
        window.ui.dbuCombo.findData("0.001")
    )
    window.refresh()

    assert window.config.dbu_um == Decimal("0.001")
    assert window._format_settings_summary().startswith("DBU 0.001 µm")


def test_project_row_spacing_stays_fixed_when_window_height_changes(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.show()

    window.resize(1380, 680)
    QApplication.processEvents()
    QApplication.processEvents()
    compact_project_height = window.ui.projectGroup.height()
    compact_rows = [
        (widget.y(), widget.height())
        for widget in (
            window.ui.technologyEdit,
            window.ui.bumpTypeEdit,
            window.ui.versionEdit,
            window.ui.shapeCombo,
            window.ui.dbuCombo,
            window.ui.dbuHintLabel,
        )
    ]

    window.resize(1380, 980)
    QApplication.processEvents()
    QApplication.processEvents()
    expanded_project_height = window.ui.projectGroup.height()
    expanded_rows = [
        (widget.y(), widget.height())
        for widget in (
            window.ui.technologyEdit,
            window.ui.bumpTypeEdit,
            window.ui.versionEdit,
            window.ui.shapeCombo,
            window.ui.dbuCombo,
            window.ui.dbuHintLabel,
        )
    ]

    assert compact_project_height == expanded_project_height
    assert compact_rows == expanded_rows


def test_validation_warning_count_does_not_resize_layer_table(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.config.bump_type = "LEGACY_COMPATIBILITY_BUMP"
    window.config.strict_legacy_gdsii_compatibility = True
    window.config.al_pad_layer_uid = None
    window.resize(1380, window.minimumHeight())
    window.show()
    window.refresh()
    QApplication.processEvents()

    assert window.ui.validationText.toPlainText().count("\n") >= 1
    warning_sizes = (
        window.ui.layerTable.height(),
        window.ui.summaryGroup.height(),
        window.ui.validationText.height(),
    )

    window.config.bump_type = "LF"
    window.config.strict_legacy_gdsii_compatibility = False
    window.config.al_pad_layer_uid = window.config.layers[0].uid
    window.refresh()
    QApplication.processEvents()

    assert window.ui.validationText.toPlainText() == "PASS"
    assert (
        window.ui.layerTable.height(),
        window.ui.summaryGroup.height(),
        window.ui.validationText.height(),
    ) == warning_sizes


def test_output_summary_keeps_compact_content_height(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.resize(1380, window.minimumHeight())
    window.show()
    QApplication.processEvents()

    compact_summary_height = window.ui.summaryGroup.height()
    compact_table_height = window.ui.layerTable.height()
    assert compact_summary_height == window.ui.summaryGroup.sizeHint().height()

    window.resize(1380, window.minimumHeight() + 160)
    QApplication.processEvents()

    assert window.ui.summaryGroup.height() == compact_summary_height
    assert window.ui.layerTable.height() == compact_table_height + 160


def test_left_panel_groups_and_layer_controls_do_not_overlap(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.resize(1120, window.minimumHeight())
    window.show()
    QApplication.processEvents()
    QApplication.processEvents()

    project_bottom = (
        window.ui.projectGroup.y() + window.ui.projectGroup.height()
    )
    assert (
        window.ui.layersGroup.y() - project_bottom
        >= window.ui.controlLayout.spacing()
    )

    hint_bottom = (
        window.ui.processHintLabel.y()
        + window.ui.processHintLabel.height()
    )
    assert (
        window.ui.layerTable.y() - hint_bottom
        >= window.ui.layersLayout.spacing()
    )

    table_bottom = window.ui.layerTable.y() + window.ui.layerTable.height()
    assert (
        window.ui.addLayerButton.y() - table_bottom
        >= window.ui.layersLayout.spacing()
    )


def test_minimum_window_keeps_left_panel_and_lef_controls_separate(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.ui.previewTabs.setCurrentIndex(1)
    window.resize(1, window.minimumHeight())
    window.show()
    QApplication.processEvents()
    QApplication.processEvents()

    assert window.minimumWidth() == 1280
    assert not window.ui.mainSplitter.childrenCollapsible()
    assert window.ui.controlPanel.width() >= 640
    assert window.ui.previewPanel.width() >= 440
    assert (
        window.ui.controlPanel.mapToGlobal(
            window.ui.controlPanel.rect().topRight()
        ).x()
        < window.ui.previewPanel.mapToGlobal(
            window.ui.previewPanel.rect().topLeft()
        ).x()
    )
    assert (
        window.ui.alPadLayerLabel.mapToGlobal(
            window.ui.alPadLayerLabel.rect().topRight()
        ).x()
        < window.ui.alPadLayerCombo.mapToGlobal(
            window.ui.alPadLayerCombo.rect().topLeft()
        ).x()
    )
    assert (
        window.ui.alPadLayerCombo.mapToGlobal(
            window.ui.alPadLayerCombo.rect().topRight()
        ).x()
        <= window.ui.controlPanel.mapToGlobal(
            window.ui.controlPanel.rect().topRight()
        ).x()
    )
    assert window.ui.alPadLayerCombo.parent() is window.ui.layersGroup
    assert (
        window.ui.alPadLayerCombo.mapToGlobal(
            window.ui.alPadLayerCombo.rect().topLeft()
        ).y()
        > window.ui.layerTable.mapToGlobal(
            window.ui.layerTable.rect().bottomLeft()
        ).y()
    )
    assert not hasattr(window.ui, "lefPinSummaryLabel")
    assert not hasattr(window.ui, "alPadSelectionSpacer")
    assert (
        window.ui.alPadLayerCombo.sizePolicy().horizontalPolicy()
        is QSizePolicy.Policy.Expanding
    )
    assert (
        window.ui.alPadLayerCombo.geometry().right()
        == window.ui.alPadSelectionLayout.geometry().right()
    )


def test_oval_layer_headers_fit_and_left_panel_can_expand(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.model.set_shape_type(ShapeType.OVAL)
    window.resize(1380, window.minimumHeight())
    window.show()
    QApplication.processEvents()
    QApplication.processEvents()

    assert window.ui.controlPanel.width() >= 640
    header = window.ui.layerTable.horizontalHeader()
    for column in range(window.model.columnCount()):
        text = str(window.model.headerData(column, Qt.Orientation.Horizontal))
        assert header.sectionSize(column) >= (
            header.fontMetrics().horizontalAdvance(text) + 8
        )

    initial_width = window.ui.controlPanel.width()
    window.ui.mainSplitter.setSizes([10_000, 1])
    QApplication.processEvents()
    assert window.ui.controlPanel.width() > initial_width
    assert window.ui.controlPanel.width() >= 900


def test_lef_warning_height_adapts_to_wrapped_content(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.resize(1380, window.minimumHeight())
    window.ui.previewTabs.setCurrentIndex(1)
    window.show()

    window.ui.mainSplitter.setSizes([900, 480])
    window.ui.alPadHintLabel.setText("Short warning")
    QApplication.processEvents()
    short_height = window.ui.alPadHintLabel.height()

    window.ui.alPadHintLabel.setText(
        "This is a deliberately long LEF warning used to verify wrapped "
        "content height. " * 8
    )
    QApplication.processEvents()
    long_height = window.ui.alPadHintLabel.height()

    assert long_height > short_height


def test_advanced_cell_name_layer_selection_and_legacy_toggle(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    dialog = AdvancedSettingsDialog(window.config, window)
    qtbot.addWidget(dialog)
    assert dialog.ui.cellNameLayersCombo.checked_data() == [
        window.config.layers[0].uid,
        window.config.layers[4].uid,
    ]
    selected = [
        window.config.layers[0].uid,
        window.config.layers[3].uid,
        window.config.layers[4].uid,
    ]
    dialog.ui.cellNameLayersCombo.set_checked_data(selected)
    dialog.ui.strictLegacyCheck.setChecked(True)
    dialog.apply_to_config()
    assert window.config.cell_name_layer_uids == selected
    assert window.config.strict_legacy_gdsii_compatibility


def test_lef_preview_layer_selection_controls_single_layer_preview(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    pio = window.config.layers[3]
    index = window.ui.alPadLayerCombo.findData(pio.uid)
    window.ui.alPadLayerCombo.setCurrentIndex(index)

    assert window.config.al_pad_layer_uid == pio.uid
    assert len(window.lef_preview.layouts) == 1
    assert [layer.definition.uid for layer in window.lef_preview.layouts[0].layers] == [
        pio.uid
    ]
    assert len(window.lef_preview.layouts[0].layers[0].points_dbu) == 64
    assert not hasattr(window.ui, "lefPinSummaryLabel")


def test_non_tapeout_al_pad_selection_requires_confirmation(
    qtbot,
    monkeypatch,
) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    original = window.config.layers[0]
    non_tapeout = window.config.layers[1]
    index = window.ui.alPadLayerCombo.findData(non_tapeout.uid)
    prompts: list[tuple[str, str]] = []

    def reject_selection(_parent, title, message, *_args):
        prompts.append((title, message))
        return QMessageBox.StandardButton.No

    monkeypatch.setattr(QMessageBox, "question", reject_selection)
    window.ui.alPadLayerCombo.setCurrentIndex(index)

    assert prompts
    assert "not marked for Tapeout" in prompts[-1][1]
    assert window.config.al_pad_layer_uid == original.uid
    assert window.config.origin_reference_uid == original.uid
    assert window.ui.alPadLayerCombo.currentData() == original.uid

    def accept_selection(_parent, title, message, *_args):
        prompts.append((title, message))
        return QMessageBox.StandardButton.Yes

    monkeypatch.setattr(QMessageBox, "question", accept_selection)
    window.ui.alPadLayerCombo.setCurrentIndex(index)

    assert window.config.al_pad_layer_uid == non_tapeout.uid
    assert window.config.origin_reference_uid == non_tapeout.uid
    assert window.config.al_pad_layer() is non_tapeout
    assert [
        layer.definition.uid
        for layer in window.lef_preview.layouts[0].layers
    ] == [non_tapeout.uid]


def test_unselected_layer_rename_does_not_show_al_pad_notice(
    qtbot,
    monkeypatch,
) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    notices: list[tuple[str, str]] = []

    def record_notice(_parent, title, message, *_args):
        notices.append((title, message))
        return QMessageBox.StandardButton.Ok

    monkeypatch.setattr(QMessageBox, "information", record_notice)
    assert window.model.setData(
        window.model.index(0, 1),
        "AP_DRAWING",
    )

    assert notices == []
    assert window.config.al_pad_layer_uid is None


def test_selected_manual_al_pad_rename_shows_name_change_notice(
    qtbot,
    monkeypatch,
) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    pio = window.config.layers[3]
    window.ui.alPadLayerCombo.setCurrentIndex(
        window.ui.alPadLayerCombo.findData(pio.uid)
    )
    notices: list[str] = []

    def record_notice(_parent, _title, message, *_args):
        notices.append(message)
        return QMessageBox.StandardButton.Ok

    monkeypatch.setattr(QMessageBox, "information", record_notice)
    assert window.model.setData(
        window.model.index(0, 1),
        "AP_DRAWING",
    )
    assert notices == []
    assert window.model.setData(
        window.model.index(3, 1),
        "PIO_DRAWING",
    )

    assert len(notices) == 1
    assert "Before: PIO" in notices[0]
    assert "After: PIO_DRAWING" in notices[0]
    assert window.config.al_pad_layer_uid == pio.uid


def test_layer_name_and_order_changes_never_select_al_pad_automatically(
    qtbot,
    monkeypatch,
) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    ap = window.config.layers[0]
    notices: list[str] = []

    monkeypatch.setattr(
        QMessageBox,
        "information",
        lambda _parent, _title, message, *_args: notices.append(message),
    )
    assert window.model.moveRows(
        window.model.index(-1, -1),
        2,
        1,
        window.model.index(-1, -1),
        0,
    )
    ap_row = next(
        row
        for row, layer in enumerate(window.config.layers)
        if layer.uid == ap.uid
    )
    assert window.model.setData(
        window.model.index(ap_row, 1),
        "RDL",
    )

    assert notices == []
    assert window.config.al_pad_layer_uid is None
    assert window.config.origin_reference_uid is None


def test_restoring_default_layers_clears_manual_al_pad_selection(
    qtbot,
) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    assert window.config.al_pad_layer_uid is not None

    window.model.restore_defaults()
    window.refresh()

    assert window.config.al_pad_layer_uid is None
    assert window.config.origin_reference_uid is None
    assert window.ui.alPadLayerCombo.currentData() is None


def test_missing_al_pad_selection_disables_export(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.ui.alPadLayerCombo.setCurrentIndex(0)

    assert window.config.al_pad_layer_uid is None
    assert not window.ui.exportButton.isEnabled()
    assert "Select the Al Pad Layer" in window.ui.validationText.toPlainText()


def test_export_dialog_requires_every_checklist_confirmation(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    layer = window.config.layers[0]
    dialog = ExportConfirmationDialog(
        [Path("sample.gds"), Path("sample.lef"), Path("sample.pdf")],
        [],
        [],
        layer,
        window,
    )
    qtbot.addWidget(dialog)
    save_button = dialog.ui.buttonBox.button(
        QDialogButtonBox.StandardButton.Save
    )

    assert not save_button.isEnabled()
    assert not hasattr(dialog.ui, "alPadSummaryLabel")
    assert dialog.ui.exportChecklist.count() == len(
        load_export_checklist("en").confirmations
    )
    for _item, checkbox in dialog._checklist_checkboxes[:-1]:
        checkbox.setChecked(True)
    assert not save_button.isEnabled()
    dialog._checklist_checkboxes[-1][1].setChecked(True)
    assert save_button.isEnabled()
    dialog._checklist_checkboxes[0][1].setChecked(False)
    assert not save_button.isEnabled()


def test_export_checklist_uses_native_shape_style_checkboxes(
    qtbot,
) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    dialog = ExportConfirmationDialog(
        [Path("sample.gds")],
        [],
        [],
        window.config.layers[0],
        window,
    )
    qtbot.addWidget(dialog)
    shape_dialog = ExportShapeDialog(
        (ShapeType.ROUND,),
        ShapeType.ROUND,
        window,
    )
    qtbot.addWidget(shape_dialog)
    dialog.show()
    qtbot.waitUntil(lambda: dialog.ui.exportChecklist.isVisible())

    checklist = dialog.ui.exportChecklist
    item, checkbox = next(
        (item, candidate)
        for item, candidate in dialog._checklist_checkboxes
        if "\n" in str(
            item.data(dialog.CHECKLIST_TEXT_ROLE) or ""
        )
    )
    qtbot.waitUntil(
        lambda: checkbox.width() > 500
    )
    assert isinstance(checkbox, QCheckBox)
    assert checkbox.styleSheet() == shape_dialog.ui.roundCheck.styleSheet() == ""
    assert checkbox.font() == shape_dialog.ui.roundCheck.font()
    assert checkbox.style().pixelMetric(
        QStyle.PixelMetric.PM_IndicatorWidth
    ) == shape_dialog.ui.roundCheck.style().pixelMetric(
        QStyle.PixelMetric.PM_IndicatorWidth
    )
    assert not hasattr(dialog, "_checklist_delegate")
    assert "\n" in checkbox.text()
    assert item.text() == ""
    assert item.data(Qt.ItemDataRole.CheckStateRole) is None
    assert not (item.flags() & Qt.ItemFlag.ItemIsUserCheckable)

    indicator_width = checkbox.style().pixelMetric(
        QStyle.PixelMetric.PM_IndicatorWidth
    )
    text_position = QPoint(
        indicator_width + 24,
        checkbox.fontMetrics().height() // 2 + 2,
    )
    qtbot.mouseClick(
        checkbox,
        Qt.MouseButton.LeftButton,
        pos=text_position,
    )
    assert checkbox.isChecked()
    assert item.isSelected()


def test_export_warnings_and_replacements_are_checklist_items(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    dialog = ExportConfirmationDialog(
        [Path("sample.gds"), Path("sample.lef"), Path("sample.pdf")],
        ["Synthetic DBU warning"],
        [Path("sample.gds")],
        window.config.layers[0],
        window,
    )
    qtbot.addWidget(dialog)
    save_button = dialog.ui.buttonBox.button(
        QDialogButtonBox.StandardButton.Save
    )

    assert dialog.ui.exportChecklist.count() == (
        len(load_export_checklist("en").confirmations) + 2
    )
    checklist_text = "\n".join(dialog.checklist_texts())
    assert "Synthetic DBU warning" in checklist_text
    assert "1 existing output file(s) will be replaced" in checklist_text
    assert "[WILL BE REPLACED]" in dialog.ui.fileList.item(0).text()
    assert (
        dialog.ui.exportChecklist.selectionMode()
        is QAbstractItemView.SelectionMode.ExtendedSelection
    )
    assert dialog._copy_checklist_shortcut.key().matches(
        QKeySequence(QKeySequence.StandardKey.Copy)
    ) is QKeySequence.SequenceMatch.ExactMatch

    fixed_confirmation_count = dialog.ui.exportChecklist.count() - 2
    warning_item = dialog.ui.exportChecklist.item(fixed_confirmation_count)
    replacement_item = dialog.ui.exportChecklist.item(
        fixed_confirmation_count + 1
    )
    warning_item.setSelected(True)
    replacement_item.setSelected(True)
    QApplication.clipboard().clear()
    dialog._copy_selected_checklist_items()
    checklist_texts = dialog.checklist_texts()
    assert QApplication.clipboard().text() == (
        f"{checklist_texts[fixed_confirmation_count]}\n"
        f"{checklist_texts[fixed_confirmation_count + 1]}"
    )
    for _item, checkbox in dialog._checklist_checkboxes[
        :fixed_confirmation_count
    ]:
        checkbox.setChecked(True)
    assert not save_button.isEnabled()
    for _item, checkbox in dialog._checklist_checkboxes[
        fixed_confirmation_count:
    ]:
        checkbox.setChecked(True)
    assert save_button.isEnabled()


def test_template_warning_dialog_text_is_selectable(
    qtbot,
    monkeypatch,
) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    captured = {}

    def record_message_box(message_box) -> int:
        captured["text"] = message_box.text()
        captured["flags"] = message_box.textInteractionFlags()
        return QMessageBox.StandardButton.Ok.value

    monkeypatch.setattr(QMessageBox, "exec", record_message_box)
    window._show_template_error(RuntimeError("Copy this warning"))

    assert captured["text"] == "Copy this warning"
    selectable_text_flags = (
        Qt.TextInteractionFlag.TextSelectableByKeyboard
        | Qt.TextInteractionFlag.TextSelectableByMouse
    )
    assert captured["flags"] & selectable_text_flags == selectable_text_flags


def test_export_checklist_can_be_customized_with_bilingual_json(
    qtbot,
    tmp_path,
) -> None:
    document = json.loads(
        DEFAULT_EXPORT_CHECKLIST_PATH.read_text(encoding="utf-8")
    )
    document["zh_CN"]["title"] = "自定义确认清单"
    document["zh_CN"]["intro"] = "自定义说明"
    document["zh_CN"]["confirmations"] = [
        "确认自定义 Al Pad Layer Name：{name}；"
        "Process：{technology_name}；DBU：{DBU} µm；"
        "工艺顺序：{process_order}\n所有 Layer：\n{all_layers}\n"
        "Al Pad：{Al_layername} {Al_layernumb_datatype}"
    ]
    document["zh_CN"]["warning_template"] = "自定义警告：{message}"
    document["zh_CN"]["replacement_template"] = "自定义覆盖数量：{count}"
    config_path = tmp_path / "export_checklist.json"
    config_path.write_text(
        json.dumps(document, ensure_ascii=False),
        encoding="utf-8",
    )

    window = MainWindow()
    qtbot.addWidget(window)
    window.ui.technologyEdit.setText("CustomTech")
    window.config.layers[0].layer = 1
    dialog = ExportConfirmationDialog(
        [Path("sample.gds")],
        ["test warning"],
        [Path("sample.gds")],
        window.config.layers[0],
        window,
        language="zh_CN",
        checklist_path=config_path,
        dbu_um=Decimal("0.001"),
        process_order="AP → CB2 → UBM",
        all_layers="AP 1,0\nALPAD 2,1\nUBM 3,0",
    )
    qtbot.addWidget(dialog)

    assert dialog.ui.exportChecklistGroup.title() == "自定义确认清单"
    assert dialog.ui.checklistIntroLabel.text() == "自定义说明"
    assert dialog.ui.exportChecklist.count() == 3
    checklist_text = "\n".join(dialog.checklist_texts())
    assert (
        "确认自定义 Al Pad Layer Name：AP；Process：CustomTech；"
        "DBU：0.001 µm；工艺顺序：AP → CB2 → UBM\n"
        "所有 Layer：\nAP 1,0\nALPAD 2,1\nUBM 3,0\nAl Pad：AP 1.0"
        in checklist_text
    )
    assert "自定义警告：test warning" in checklist_text
    assert "自定义覆盖数量：1" in checklist_text


def test_bump_type_editor_accepts_underscores(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    validator = window.ui.bumpTypeEdit.validator()
    assert validator.validate("Flip_Chip_LF", 12)[0] == QValidator.State.Acceptable
    assert validator.validate("Flip Chip", 9)[0] == QValidator.State.Invalid


def test_validation_area_displays_multiple_messages(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.refresh()
    lines = window.ui.validationText.toPlainText().splitlines()
    assert len(lines) > 1
    assert any(line.startswith("ERROR:") for line in lines)
    assert any(line.startswith("WARNING:") for line in lines)
    assert "Select the Al Pad Layer" in window.ui.validationText.toPlainText()


def test_preview_axis_uses_nice_micrometer_ticks() -> None:
    assert _nice_tick_spacing(0.7) == 1
    assert _nice_tick_spacing(1.1) == 2
    assert _nice_tick_spacing(2.1) == 5
    assert _nice_tick_spacing(6.0) == 10
    assert _tick_values(-11, 11, 5) == [-10, -5, 0, 5, 10]
    assert _format_tick(80, 10) == "80"
    assert _format_tick(0.5, 0.1) == "0.5"


def test_preview_origin_maps_to_zero_and_mouse_coordinate_is_available(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.resize(1380, 820)
    window.refresh()
    window.show()
    qtbot.waitUntil(lambda: len(window.preview._panel_views) == 1)

    view = window.preview._panel_views[0]
    origin = view.map_point(0, 0)
    assert view.screen_to_um(origin) == (0.0, 0.0)
    _send_mouse_move(window.preview, origin.toPoint())
    assert window.preview.hover_coordinate_um is not None
    assert abs(window.preview.hover_coordinate_um[0]) < 0.2
    assert abs(window.preview.hover_coordinate_um[1]) < 0.2


def test_preview_mouse_tracking_reuses_static_cache(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.resize(1380, 820)
    window.refresh()
    window.show()
    qtbot.waitUntil(lambda: len(window.preview._panel_views) == 1)

    preview = window.preview
    view = preview._panel_views[0]
    cached_pixmap = preview._static_cache
    cache_build_count = preview._static_cache_build_count
    assert cached_pixmap is not None

    for step in range(100):
        x = round(view.plot.left() + 5 + step % max(1, int(view.plot.width() - 10)))
        y = round(view.plot.top() + 5 + (step * 7) % max(1, int(view.plot.height() - 10)))
        _send_mouse_move(preview, QPoint(x, y))

    qtbot.wait(10)
    assert preview.hover_coordinate_um is not None
    assert preview._static_cache is cached_pixmap
    assert preview._static_cache_build_count == cache_build_count


def test_preview_cache_is_rebuilt_after_layer_selection_changes(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.resize(1380, 820)
    window.refresh()
    window.show()
    qtbot.waitUntil(lambda: len(window.preview._panel_views) == 1)

    preview = window.preview
    cache_build_count = preview._static_cache_build_count
    preview.set_selected_layer(window.config.layers[1].uid)
    assert preview._static_cache is None

    preview.repaint()
    assert preview._static_cache is not None
    assert preview._static_cache_build_count == cache_build_count + 1


def test_show_nodes_uses_small_markers_and_rebuilds_only_static_cache(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.resize(1380, 820)
    window.refresh()
    window.show()
    qtbot.waitUntil(lambda: len(window.preview._panel_views) == 1)

    preview = window.preview
    assert preview.show_nodes
    window.ui.showNodesCheck.setChecked(False)
    assert not preview.show_nodes
    assert not window.lef_preview.show_nodes
    preview.repaint()
    cache_build_count = preview._static_cache_build_count
    window.ui.showNodesCheck.setChecked(True)
    assert preview.show_nodes
    assert window.lef_preview.show_nodes
    assert preview._static_cache is None
    assert preview.NODE_RADIUS_PX <= 1.5
    assert preview.SELECTED_NODE_RADIUS_PX <= 2.0

    preview.repaint()
    assert preview._static_cache_build_count == cache_build_count + 1
    assert len(preview._panel_nodes[0]) == 6 * 64


def test_snap_to_nodes_uses_quantized_vertex_and_does_not_require_node_display(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.resize(1380, 820)
    window.refresh()
    window.show()
    qtbot.waitUntil(lambda: len(window.preview._panel_views) == 1)

    preview = window.preview
    window.ui.showNodesCheck.setChecked(False)
    assert not window.ui.showNodesCheck.isChecked()
    assert not window.lef_preview.show_nodes
    assert preview.snap_to_nodes
    assert window.lef_preview.snap_to_nodes
    preview.repaint()
    cache_build_count = preview._static_cache_build_count

    target = preview._panel_nodes[0][0]
    nearby_point = QPoint(
        round(target.position.x() + 5),
        round(target.position.y() + 2),
    )
    _send_mouse_move(preview, nearby_point)

    assert preview._snapped_node == target
    assert preview._hover_position == target.position
    assert preview.hover_coordinate_um == (
        target.x_dbu * float(window.config.dbu_um),
        target.y_dbu * float(window.config.dbu_um),
    )
    assert preview._static_cache_build_count == cache_build_count

    window.ui.snapNodesCheck.setChecked(False)
    assert not window.lef_preview.snap_to_nodes
    assert preview._snapped_node is None
    assert preview._hover_position != target.position


def test_node_controls_do_not_modify_export_configuration(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    config_before = deepcopy(window.config)
    window.ui.showNodesCheck.setChecked(False)
    window.ui.snapNodesCheck.setChecked(False)
    assert window.config == config_before
    assert not hasattr(window.config, "show_nodes")
    assert not hasattr(window.config, "snap_to_nodes")
