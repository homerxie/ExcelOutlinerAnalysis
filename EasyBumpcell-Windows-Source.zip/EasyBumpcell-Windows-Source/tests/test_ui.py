from __future__ import annotations

from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path

from PySide6.QtGui import QIcon, QMouseEvent, QPixmap, QValidator
from PySide6.QtCore import QEvent, QPoint, QPointF, Qt
from PySide6.QtWidgets import (
    QApplication,
    QDialogButtonBox,
    QDoubleSpinBox,
    QGridLayout,
    QLineEdit,
    QPlainTextEdit,
    QSizePolicy,
)

from easybumpcell.domain.enums import OriginMode, RotationDirection, ShapeType, ZeroDegreeAxis
from easybumpcell.export_checklist import DEFAULT_EXPORT_CHECKLIST_PATH
from easybumpcell.preview_patterns import DEFAULT_PREVIEW_PATTERNS
from easybumpcell.ui.advanced_dialog import AdvancedSettingsDialog
from easybumpcell.ui.export_dialog import ExportConfirmationDialog
from easybumpcell.ui.main_window import (
    LAYER_MAPPING_HELP_IMAGE,
    PROCESS_DBU_HELP_IMAGE,
    MainWindow,
)
from easybumpcell.ui.preview_widget import (
    _format_tick,
    _nice_tick_spacing,
    _tick_values,
)


def _fill_round_window(window: MainWindow) -> None:
    window.ui.technologyEdit.setText("TechName")
    window.ui.bumpTypeEdit.setText("LF")
    window.ui.versionEdit.setText("V1")
    values = [
        ("AP", 1, 0, 80),
        ("CB2", 2, 0, 40),
        ("PIO", 3, 0, 30),
        ("UBM", 4, 0, 60),
    ]
    for row, (_, layer_number, datatype, diameter) in enumerate(values):
        window.model.setData(window.model.index(row, 2), layer_number)
        window.model.setData(window.model.index(row, 3), datatype)
        window.model.setData(window.model.index(row, 4), diameter)


def _send_mouse_move(widget, point: QPoint) -> None:
    local_position = QPointF(point)
    global_position = QPointF(widget.mapToGlobal(point))
    event = QMouseEvent(
        QEvent.Type.MouseMove,
        local_position,
        global_position,
        Qt.MouseButton.NoButton,
        Qt.MouseButton.NoButton,
        Qt.KeyboardModifier.NoModifier,
    )
    QApplication.sendEvent(widget, event)


def test_main_window_starts_with_default_layers(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    assert window.minimumHeight() == 820
    assert window.model.rowCount() == 4
    assert [
        window.model.headerData(
            column,
            Qt.Orientation.Horizontal,
            Qt.ItemDataRole.DisplayRole,
        )
        for column in range(4)
    ] == ["Order", "Layer Name", "Layer Number", "Datatype"]
    assert window.config.dbu_um == Decimal("0.0005")
    assert [
        window.ui.dbuCombo.itemText(index)
        for index in range(window.ui.dbuCombo.count())
    ] == ["0.001 µm", "0.0005 µm"]
    assert window.ui.dbuCombo.currentData() == "0.0005"
    assert window.ui.dbuHintLabel.text() == (
        "Please confirm that the Process DBU exactly matches the DBU "
        "definition in the techfile (*.tf) of — Process."
    )
    assert (
        window.ui.dbuHintLabel.minimumSize()
        == window.ui.processHintLabel.minimumSize()
    )
    assert (
        window.ui.dbuHintLabel.maximumSize()
        == window.ui.processHintLabel.maximumSize()
    )
    assert (
        window.ui.dbuHintLabel.sizePolicy()
        == window.ui.processHintLabel.sizePolicy()
    )
    assert (
        window.ui.dbuHintLabel.styleSheet()
        == window.ui.processHintLabel.styleSheet()
    )
    assert window.ui.dbuHintLabel.wordWrap()
    assert window.ui.processHintLabel.wordWrap()
    assert isinstance(window.ui.projectGrid, QGridLayout)
    assert window.ui.projectGrid.verticalSpacing() == 6
    assert window.ui.projectGrid.horizontalSpacing() == 6
    assert [
        window.ui.projectGrid.columnStretch(column)
        for column in range(4)
    ] == [0, 1, 0, 1]
    assert window.ui.layersLayout.spacing() == 6
    assert window.ui.summaryGroup.minimumHeight() == 0
    assert [layer.meaning for layer in window.config.layers] == ["AP", "CB2", "PIO", "UBM"]
    assert [layer.preview_pattern for layer in window.config.layers] == list(
        DEFAULT_PREVIEW_PATTERNS[:4]
    )
    assert not window.ui.exportButton.isEnabled()
    assert not window.ui.exportButton.isDefault()
    assert window.ui.advancedSettingsAction.isEnabled()
    assert window.ui.processHintLabel.text() == (
        "Please confirm:\n"
        "1. The GDS Layer Number, Datatype are the correct layers used "
        "in the current package bump type of — Process. This will affect "
        "the GDS generation.\n"
        "2. The GDS Layer Name exactly matches the GDS Layer "
        "Number/Datatype defined in the layermap (*.map) of — Process. "
        "This will affect the LEF generation."
    )
    assert not window.ui.settingsSummaryLabel.wordWrap()
    assert window.ui.settingsSummaryLabel.sizePolicy().verticalPolicy() is QSizePolicy.Policy.Fixed
    assert window.ui.settingsSummaryLabel.maximumHeight() == 24
    assert isinstance(window.ui.validationText, QPlainTextEdit)
    assert window.ui.validationText.isReadOnly()
    assert 24 <= window.ui.validationText.height() <= 96
    assert window.ui.validationCaption.alignment() & Qt.AlignmentFlag.AlignTop
    layer_name_index = window.model.index(0, 1)
    assert isinstance(
        window.model.data(layer_name_index, Qt.ItemDataRole.DecorationRole),
        QIcon,
    )
    assert "Forward Diagonal" in window.model.data(
        layer_name_index,
        Qt.ItemDataRole.ToolTipRole,
    )
    assert window.ui.showNodesCheck.isChecked()
    assert window.ui.snapNodesCheck.isChecked()
    assert window.preview.show_nodes
    assert window.preview.snap_to_nodes
    assert window.lef_preview.show_nodes
    assert window.lef_preview.snap_to_nodes
    assert (
        window.ui.previewTabs.cornerWidget(Qt.Corner.TopRightCorner)
        is window.ui.nodeControlsWidget
    )
    assert window.ui.versionEdit.text() == ""
    assert "not to the internal GDS Cell name" in window.ui.versionEdit.toolTip()
    assert window.ui.generatedNameCaption.text() == "Cell Base Name"
    assert not window.ui.generatedNameLabel.wordWrap()
    assert window.ui.generatedNameLabel.maximumHeight() == 24
    assert (
        window.ui.generatedNameLabel.sizePolicy().verticalPolicy()
        is QSizePolicy.Policy.Fixed
    )
    assert window.ui.summaryForm.verticalSpacing() == 4
    assert (
        window.ui.summaryBottomSpacer.expandingDirections()
        & Qt.Orientation.Vertical
    )
    assert window.ui.nodeCountCaption.text() == "Polygon"
    assert window.ui.nodeCountLabel.text() == "—"
    assert window.ui.centerSummaryCaption.text() == "Bumpcell Center"
    assert window.ui.centerSummaryLabel.text() == "—"
    assert window.ui.centerSummaryLabel.height() == 24
    assert (
        window.ui.centerSummaryLabel.sizePolicy().verticalPolicy()
        is QSizePolicy.Policy.Fixed
    )
    version_validator = window.ui.versionEdit.validator()
    assert version_validator.validate("V1.2-rc1", 8)[0] == QValidator.State.Acceptable
    assert version_validator.validate("V1_bad", 6)[0] == QValidator.State.Invalid
    assert "PDF" in window.ui.showNodesCheck.toolTip()
    assert "PDF" in window.ui.snapNodesCheck.toolTip()
    assert "GDS and LEF" in window.ui.showNodesCheck.toolTip()
    assert "GDS and LEF" in window.ui.snapNodesCheck.toolTip()
    assert window.ui.previewTabs.count() == 2
    assert window.ui.previewTabs.tabText(0) == "GDS Preview"
    assert window.ui.previewTabs.tabText(1) == "LEF Preview"
    assert (
        window.ui.alPadLayerCombo.currentData()
        == window.config.layers[0].uid
    )
    assert window.config.layers[0].meaning == "AP"


def test_complete_round_project_enables_preview_and_export(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.refresh()
    assert window.ui.exportButton.isEnabled()
    assert len(window.preview.layouts) == 1
    assert window.preview.layouts[0].cell_name == "LF_AP80_UBM60"
    assert window.preview.layouts[0].gds_file_name.endswith("_V1.gds")
    assert len(window.lef_preview.layouts) == 1
    assert len(window.lef_preview.layouts[0].layers) == 1
    assert (
        window.lef_preview.layouts[0].layers[0].definition.uid
        == window.config.layers[0].uid
    )
    assert window.lef_preview.lef_mode
    assert "AP.PIN" in window.ui.lefPinSummaryLabel.text()
    assert "AP.LABEL (BUMP)" in window.ui.lefPinSummaryLabel.text()
    assert "BOUNDARY" in window.ui.lefPinSummaryLabel.text()
    hint = window.ui.alPadHintLabel.text()
    assert hint == (
        "Please confirm again:\n"
        "1. The Layername.Datatype of the Al Pad Drawing layer "
        "(not the Marking or Dummy layer) is 1.0.\n"
        "2. The layer name defined for Layername.Datatype 1.0 in the "
        "technology layermap (*.map) file is AP."
    )
    assert "BOUNDARY" not in hint
    assert "SIZE" not in hint
    assert window.ui.nodeCountLabel.text() == "64-gon"
    assert window.ui.centerSummaryLabel.text() == "X 40.0000 µm · Y 40.0000 µm"
    assert window.ui.centerSummaryLabel.height() == 24


def test_process_confirmation_hints_use_actual_technology_name(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.ui.technologyEdit.setText("N3Tech")
    window.refresh()

    assert window.ui.dbuHintLabel.text() == (
        "Please confirm that the Process DBU exactly matches the DBU "
        "definition in the techfile (*.tf) of N3Tech Process."
    )
    assert window.ui.processHintLabel.text() == (
        "Please confirm:\n"
        "1. The GDS Layer Number, Datatype are the correct layers used "
        "in the current package bump type of N3Tech Process. This will "
        "affect the GDS generation.\n"
        "2. The GDS Layer Name exactly matches the GDS Layer "
        "Number/Datatype defined in the layermap (*.map) of N3Tech "
        "Process. This will affect the LEF generation."
    )

    window.ui.simplifiedChineseAction.trigger()
    assert window.ui.dbuHintLabel.text() == (
        "请确认 Process DBU 与 N3Tech Process 的 techfile (*.tf) 中的 "
        "DBU 定义完全一致。"
    )
    assert window.ui.processHintLabel.text() == (
        "请确认：\n"
        "1. 下表的GDS Layer Number、Datatype就是 N3Tech "
        "工艺当前封装类型下的bump所使用的drawing layer的Layer "
        "Number、Datatype。这将影响GDS文件的准确生成。\n"
        "2. GDS Layer Name与Layer Number、Datatype的对应关系与N3Tech "
        "工艺的layermap （*.map）文件中的定义一致。"
        "这将影响LEF文件的准确生成。"
    )


def test_warning_help_buttons_load_aspect_ratio_tooltip_images(
    qtbot,
    tmp_path,
    monkeypatch,
) -> None:
    help_directory = tmp_path / "help_images"
    help_directory.mkdir()
    process_image = QPixmap(1000, 500)
    process_image.fill(Qt.GlobalColor.red)
    assert process_image.save(
        str(help_directory / "process_dbu_help.png")
    )
    layer_image = QPixmap(200, 400)
    layer_image.fill(Qt.GlobalColor.blue)
    assert layer_image.save(
        str(help_directory / "layer_mapping_help.png")
    )
    monkeypatch.chdir(tmp_path)
    QApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    QApplication.processEvents()

    window = MainWindow()
    qtbot.addWidget(window)
    monkeypatch.setattr(
        window,
        "_help_image_bases",
        lambda: (tmp_path,),
    )

    assert window.ui.dbuHelpButton.text() == "?"
    assert window.ui.layerMappingHelpButton.text() == "?"
    assert window.ui.dbuHelpButton.size().width() == 24
    assert window.ui.dbuHelpButton.size().height() == 24
    assert "border-radius: 11px" in window.ui.dbuHelpButton.styleSheet()
    assert window.ui.dbuHelpButton.toolTip()
    process_pixmap, process_error = window._load_help_tooltip_pixmap(
        PROCESS_DBU_HELP_IMAGE,
        window.screen(),
    )
    layer_pixmap, layer_error = window._load_help_tooltip_pixmap(
        LAYER_MAPPING_HELP_IMAGE,
        window.screen(),
    )
    assert process_error is None
    assert layer_error is None
    assert process_pixmap is not None
    assert layer_pixmap is not None
    logical_limit = window._help_tooltip_logical_limit(window.screen())
    device_pixel_ratio = max(
        1.0,
        float(window.screen().devicePixelRatio()),
    )
    assert (
        abs(process_pixmap.devicePixelRatio() - device_pixel_ratio)
        < 0.001
    )
    assert (
        abs(layer_pixmap.devicePixelRatio() - device_pixel_ratio)
        < 0.001
    )
    assert process_pixmap.width() <= process_image.width()
    assert process_pixmap.height() <= process_image.height()
    assert layer_pixmap.width() <= layer_image.width()
    assert layer_pixmap.height() <= layer_image.height()
    process_logical_size = process_pixmap.deviceIndependentSize()
    layer_logical_size = layer_pixmap.deviceIndependentSize()
    assert process_logical_size.width() <= logical_limit.width()
    assert process_logical_size.height() <= logical_limit.height()
    assert layer_logical_size.width() <= logical_limit.width()
    assert layer_logical_size.height() <= logical_limit.height()
    assert abs(
        process_pixmap.width() / process_pixmap.height()
        - process_image.width() / process_image.height()
    ) < 0.01
    assert abs(
        layer_pixmap.width() / layer_pixmap.height()
        - layer_image.width() / layer_image.height()
    ) < 0.01
    assert logical_limit.width() <= 720
    assert logical_limit.height() <= 480
    missing_pixmap, missing_error = window._load_help_tooltip_pixmap(
        "help_images/missing.png"
    )
    assert missing_pixmap is None
    assert missing_error is not None
    assert "help_images/missing.png" in missing_error
    assert str(tmp_path) not in missing_error


def test_interface_language_switches_between_english_and_chinese(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)

    assert not hasattr(window.ui, "languageCombo")
    assert not hasattr(window.ui, "advancedButton")
    assert window.ui.englishAction.isChecked()
    assert not window.ui.simplifiedChineseAction.isChecked()
    assert window.ui.englishAction.text() == "English"
    assert window.ui.simplifiedChineseAction.text() == "简体中文"
    assert window.ui.settingsMenu.title() == "Settings"
    assert window.ui.languageMenu.title() == "Language"
    assert window.ui.projectGroup.title() == "Process"
    assert window.config.shape_type is ShapeType.ROUND

    window.ui.simplifiedChineseAction.trigger()

    assert not window.ui.englishAction.isChecked()
    assert window.ui.simplifiedChineseAction.isChecked()
    assert window.ui.settingsMenu.title() == "设置"
    assert window.ui.languageMenu.title() == "语言"
    assert window.ui.advancedSettingsAction.text() == "高级设置"
    assert window.ui.projectGroup.title() == "工艺"
    assert window.ui.bumpTypeLabel.text() == "Bump Type"
    assert window.ui.processHintLabel.text() == (
        "请确认：\n"
        "1. 下表的GDS Layer Number、Datatype就是 — "
        "工艺当前封装类型下的bump所使用的drawing layer的Layer "
        "Number、Datatype。这将影响GDS文件的准确生成。\n"
        "2. GDS Layer Name与Layer Number、Datatype的对应关系与— "
        "工艺的layermap （*.map）文件中的定义一致。"
        "这将影响LEF文件的准确生成。"
    )
    assert window.ui.dbuLabel.text() == "Process DBU（µm）*"
    assert window.ui.dbuHintLabel.text() == (
        "请确认 Process DBU 与 — Process 的 techfile (*.tf) 中的 "
        "DBU 定义完全一致。"
    )
    assert window.ui.shapeCombo.currentText() == "圆形"
    assert window.ui.shapeCombo.currentData() == ShapeType.ROUND.value
    assert window.config.shape_type is ShapeType.ROUND
    assert [
        window.model.headerData(column, Qt.Orientation.Horizontal)
        for column in range(window.model.columnCount())
    ] == ["顺序", "Layer Name", "Layer Number", "Datatype", "直径（µm）"]
    assert window.ui.previewTabs.tabText(0) == "GDS 预览"
    assert window.ui.previewTitleLabel.text() == "符合格点要求的 GDS 预览"
    assert window.ui.showNodesCheck.text() == "显示节点"
    assert window.ui.nodeCountCaption.text() == "多边形"
    assert "错误：" in window.ui.validationText.toPlainText()
    assert (
        window.ui.previewTabs.cornerWidget(Qt.Corner.TopRightCorner)
        is window.ui.nodeControlsWidget
    )
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.refresh()
    assert window.ui.nodeCountLabel.text() == "64边形"
    assert window.ui.alPadLayerLabel.text() == "Al Pad drawing *"
    assert window.ui.alPadHintLabel.text() == (
        "请再次确认：\n"
        "1. Al Pad Drawing 层(而不是Marking或者Dummy 层)的"
        "Layername.Datatype就是1.0.\n"
        "2. Layername.Datatype 1.0 在该工艺layermap (*.map)文件中的"
        "layer name定义就是AP。"
    )

    advanced = AdvancedSettingsDialog(window.config, window)
    qtbot.addWidget(advanced)
    assert advanced.windowTitle() == "高级设置"
    assert not hasattr(advanced.ui, "dbuSpin")
    assert not hasattr(advanced.ui, "dbuCombo")
    assert not hasattr(advanced.ui, "warningLabel")
    assert (
        advanced.ui.originModeCombo.itemText(0)
        == "Reference Layer Bounding Box 左下角"
    )
    assert (
        advanced.ui.buttonBox.button(
            QDialogButtonBox.StandardButton.Cancel
        ).text()
        == "取消"
    )

    export = ExportConfirmationDialog(
        [Path("sample.gds")],
        [],
        [],
        window.config.layers[0],
        window,
    )
    qtbot.addWidget(export)
    assert export.windowTitle() == "确认导出"
    assert "Al Pad" in export.ui.alPadSummaryLabel.text()
    assert "Layer Name" in export.ui.alPadSummaryLabel.text()
    assert "Layer Number" in export.ui.alPadSummaryLabel.text()
    assert "Datatype" in export.ui.alPadSummaryLabel.text()
    assert "铝焊盘" not in export.ui.alPadSummaryLabel.text()
    assert "PIN" not in export.ui.alPadSummaryLabel.text()
    assert "BUMP" not in export.ui.alPadSummaryLabel.text()
    assert export.ui.exportChecklist.count() == 5
    checklist_text = "\n".join(
        export.ui.exportChecklist.item(index).text()
        for index in range(export.ui.exportChecklist.count())
    )
    assert "GDS Layer Number" in checklist_text
    assert "Process DBU" in checklist_text
    assert "Layer 工艺顺序" in checklist_text
    assert "Al Pad Drawing 层(而不是Marking或者Dummy 层)" in checklist_text
    assert "1.0" in checklist_text
    assert "layer name定义就是AP" in checklist_text
    assert "TechName Process" in checklist_text
    assert "techfile (*.tf)" in checklist_text
    assert "layermap (*.map)" in checklist_text
    assert not hasattr(export.ui, "warningLabel")
    assert not hasattr(export.ui, "riskAcknowledgeCheck")
    assert not hasattr(export.ui, "layermapAcknowledgeCheck")
    assert export.ui.exportChecklistGroup.styleSheet() == ""
    assert export.ui.alPadSummaryLabel.styleSheet() == ""
    assert export.ui.checklistIntroLabel.styleSheet() == ""
    checklist_style = export.ui.exportChecklist.styleSheet()
    assert "#7A5200" in checklist_style
    assert "#FFF6D8" in checklist_style
    assert "#E6C86E" in checklist_style
    assert (
        export.ui.buttonBox.button(
            QDialogButtonBox.StandardButton.Save
        ).text()
        == "导出"
    )

    window.ui.englishAction.trigger()
    assert window.ui.englishAction.isChecked()
    assert not window.ui.simplifiedChineseAction.isChecked()
    assert window.ui.projectGroup.title() == "Process"
    assert window.ui.shapeCombo.currentText() == "Round"
    assert window.config.shape_type is ShapeType.ROUND


def test_advanced_settings_opens_from_settings_menu(qtbot, monkeypatch) -> None:
    opened_with = []

    class _FakeAdvancedSettingsDialog:
        def __init__(self, config, parent) -> None:
            opened_with.append((config, parent))

        def exec(self) -> bool:
            return False

    monkeypatch.setattr(
        "easybumpcell.ui.main_window.AdvancedSettingsDialog",
        _FakeAdvancedSettingsDialog,
    )
    window = MainWindow()
    qtbot.addWidget(window)

    window.ui.advancedSettingsAction.trigger()

    assert opened_with == [(window.config, window)]


def test_oval_mode_shows_four_layouts(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.ui.technologyEdit.setText("TechName")
    window.ui.bumpTypeEdit.setText("LF")
    window.ui.versionEdit.setText("V1")
    window.model.set_shape_type(ShapeType.OVAL)
    for row, layer in enumerate(window.config.layers):
        window.model.setData(window.model.index(row, 2), row + 1)
        window.model.setData(window.model.index(row, 3), 0)
        window.model.setData(window.model.index(row, 4), 10 + row * 10)
        window.model.setData(window.model.index(row, 5), 30 + row * 20)
    window.config.process_order_confirmed = True
    window.refresh()
    window.resize(1380, 820)
    window.show()
    qtbot.waitUntil(lambda: len(window.preview._panel_views) == 4)
    assert window.ui.exportButton.isEnabled()
    assert [layout.logical_angle for layout in window.preview.layouts] == [0, 45, 90, 135]
    assert window.ui.nodeCountLabel.text() == "66-gon"
    center_lines = window.ui.centerSummaryLabel.text().splitlines()
    assert [line.split(":", 1)[0] for line in center_lines] == [
        "0D",
        "45D",
        "90D",
        "135D",
    ]
    assert window.ui.centerSummaryLabel.height() > 24
    assert len(window.preview._panel_views) == 4
    assert len({view.tick_spacing_um for view in window.preview._panel_views}) == 1
    assert len(window.lef_preview.layouts) == 4
    assert all(
        len(layout.layers) == 1
        and len(layout.layers[0].points_dbu) == 66
        for layout in window.lef_preview.layouts
    )


def test_reordering_resets_process_confirmation(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.config.process_order_confirmed = True
    original_style = (
        window.config.layers[0].color,
        window.config.layers[0].preview_pattern,
    )
    assert window.model.moveRows(
        window.model.index(-1, -1),
        0,
        1,
        window.model.index(-1, -1),
        3,
    )
    assert not window.config.process_order_confirmed
    assert [layer.meaning for layer in window.config.layers] == ["CB2", "PIO", "UBM", "AP"]
    assert (
        window.config.layers[-1].color,
        window.config.layers[-1].preview_pattern,
    ) == original_style


def test_confirmed_process_order_uses_compact_button_text(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.config.process_order_confirmed = True
    window.refresh()
    assert window.ui.confirmOrderButton.text() == "Order Confirmed"
    assert "current process order" in window.ui.confirmOrderButton.toolTip()


def test_dimension_editor_accepts_one_decimal_place(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    delegate = window.ui.layerTable.itemDelegateForColumn(4)
    editor = delegate.createEditor(window.ui.layerTable, None, window.model.index(0, 4))
    assert isinstance(editor, QDoubleSpinBox)
    assert editor.decimals() == 1
    assert editor.singleStep() == 0.1
    assert editor.minimum() == 0.1
    assert editor.maximum() > 1_000_000

    assert window.model.setData(
        window.model.index(0, 4),
        Decimal("80.5"),
    )
    assert window.config.layers[0].diameter_um == Decimal("80.5")
    assert window.model.data(window.model.index(0, 4)) == "80.5"


def test_layer_name_editor_is_text_and_rejects_spaces(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    delegate = window.ui.layerTable.itemDelegateForColumn(1)
    editor = delegate.createEditor(window.ui.layerTable, None, window.model.index(0, 1))
    assert isinstance(editor, QLineEdit)
    validator = editor.validator()
    assert validator.validate("CB2", 3)[0] == QValidator.State.Acceptable
    assert validator.validate("CB 2", 4)[0] == QValidator.State.Invalid
    assert not window.model.setData(window.model.index(0, 1), "CB 2")
    assert window.config.layers[0].meaning == "AP"


def test_advanced_settings_preserve_enum_types(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    dialog = AdvancedSettingsDialog(window.config, window)
    qtbot.addWidget(dialog)
    dialog.ui.originModeCombo.setCurrentIndex(
        dialog.ui.originModeCombo.findData(OriginMode.CENTER.value)
    )
    dialog.ui.zeroAxisCombo.setCurrentIndex(
        dialog.ui.zeroAxisCombo.findData(ZeroDegreeAxis.Y.value)
    )
    dialog.ui.rotationDirectionCombo.setCurrentIndex(
        dialog.ui.rotationDirectionCombo.findData(RotationDirection.CLOCKWISE.value)
    )
    dialog.apply_to_config()
    assert window.config.origin_mode is OriginMode.CENTER
    assert window.config.zero_degree_axis is ZeroDegreeAxis.Y
    assert window.config.rotation_direction is RotationDirection.CLOCKWISE
    assert window._format_settings_summary().endswith("Origin Common Center")


def test_process_dbu_is_edited_from_project_section(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)

    window.ui.dbuCombo.setCurrentIndex(
        window.ui.dbuCombo.findData("0.001")
    )
    window.refresh()

    assert window.config.dbu_um == Decimal("0.001")
    assert window._format_settings_summary().startswith("DBU 0.001 µm")


def test_project_row_spacing_stays_fixed_when_window_height_changes(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.show()

    window.resize(1380, 680)
    QApplication.processEvents()
    QApplication.processEvents()
    compact_project_height = window.ui.projectGroup.height()
    compact_rows = [
        (widget.y(), widget.height())
        for widget in (
            window.ui.technologyEdit,
            window.ui.bumpTypeEdit,
            window.ui.versionEdit,
            window.ui.shapeCombo,
            window.ui.dbuCombo,
            window.ui.dbuHintLabel,
        )
    ]

    window.resize(1380, 980)
    QApplication.processEvents()
    QApplication.processEvents()
    expanded_project_height = window.ui.projectGroup.height()
    expanded_rows = [
        (widget.y(), widget.height())
        for widget in (
            window.ui.technologyEdit,
            window.ui.bumpTypeEdit,
            window.ui.versionEdit,
            window.ui.shapeCombo,
            window.ui.dbuCombo,
            window.ui.dbuHintLabel,
        )
    ]

    assert compact_project_height == expanded_project_height
    assert compact_rows == expanded_rows


def test_left_panel_groups_and_layer_controls_do_not_overlap(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.resize(1120, window.minimumHeight())
    window.show()
    QApplication.processEvents()
    QApplication.processEvents()

    project_bottom = (
        window.ui.projectGroup.y() + window.ui.projectGroup.height()
    )
    assert (
        window.ui.layersGroup.y() - project_bottom
        >= window.ui.controlLayout.spacing()
    )

    hint_bottom = (
        window.ui.processHintLabel.y()
        + window.ui.processHintLabel.height()
    )
    assert (
        window.ui.layerTable.y() - hint_bottom
        >= window.ui.layersLayout.spacing()
    )

    table_bottom = window.ui.layerTable.y() + window.ui.layerTable.height()
    assert (
        window.ui.addLayerButton.y() - table_bottom
        >= window.ui.layersLayout.spacing()
    )


def test_advanced_cell_name_layer_selection_and_legacy_toggle(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    dialog = AdvancedSettingsDialog(window.config, window)
    qtbot.addWidget(dialog)
    assert dialog.ui.cellNameLayersCombo.checked_data() == [
        window.config.layers[0].uid,
        window.config.layers[-1].uid,
    ]
    selected = [
        window.config.layers[0].uid,
        window.config.layers[2].uid,
        window.config.layers[-1].uid,
    ]
    dialog.ui.cellNameLayersCombo.set_checked_data(selected)
    dialog.ui.strictLegacyCheck.setChecked(True)
    dialog.apply_to_config()
    assert window.config.cell_name_layer_uids == selected
    assert window.config.strict_legacy_gdsii_compatibility


def test_lef_preview_layer_selection_controls_single_layer_preview(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    pio = window.config.layers[2]
    index = window.ui.alPadLayerCombo.findData(pio.uid)
    window.ui.alPadLayerCombo.setCurrentIndex(index)

    assert window.config.al_pad_layer_uid == pio.uid
    assert len(window.lef_preview.layouts) == 1
    assert [layer.definition.uid for layer in window.lef_preview.layouts[0].layers] == [
        pio.uid
    ]
    assert len(window.lef_preview.layouts[0].layers[0].points_dbu) == 64
    assert "PIO.PIN" in window.ui.lefPinSummaryLabel.text()
    assert "PIO.LABEL (BUMP)" in window.ui.lefPinSummaryLabel.text()
    assert "BOUNDARY" in window.ui.lefPinSummaryLabel.text()
    assert "GDS Layer Number 3 / Datatype 0" in window.ui.lefPinSummaryLabel.text()


def test_missing_al_pad_selection_disables_export(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.ui.alPadLayerCombo.setCurrentIndex(0)

    assert window.config.al_pad_layer_uid is None
    assert not window.ui.exportButton.isEnabled()
    assert "Select the Al Pad Layer" in window.ui.validationText.toPlainText()


def test_export_dialog_requires_every_checklist_confirmation(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    layer = window.config.layers[0]
    dialog = ExportConfirmationDialog(
        [Path("sample.gds"), Path("sample.lef"), Path("sample.pdf")],
        [],
        [],
        layer,
        window,
    )
    qtbot.addWidget(dialog)
    save_button = dialog.ui.buttonBox.button(
        QDialogButtonBox.StandardButton.Save
    )

    assert not save_button.isEnabled()
    assert f'"{layer.meaning}"' in dialog.ui.alPadSummaryLabel.text()
    assert "GDS Layer Number" in dialog.ui.alPadSummaryLabel.text()
    assert "Datatype" in dialog.ui.alPadSummaryLabel.text()
    assert "PIN" not in dialog.ui.alPadSummaryLabel.text()
    assert "BUMP" not in dialog.ui.alPadSummaryLabel.text()
    assert dialog.ui.exportChecklist.count() == 5
    for index in range(dialog.ui.exportChecklist.count() - 1):
        dialog.ui.exportChecklist.item(index).setCheckState(
            Qt.CheckState.Checked
        )
    assert not save_button.isEnabled()
    dialog.ui.exportChecklist.item(4).setCheckState(
        Qt.CheckState.Checked
    )
    assert save_button.isEnabled()
    dialog.ui.exportChecklist.item(0).setCheckState(
        Qt.CheckState.Unchecked
    )
    assert not save_button.isEnabled()


def test_export_warnings_and_replacements_are_checklist_items(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    dialog = ExportConfirmationDialog(
        [Path("sample.gds"), Path("sample.lef"), Path("sample.pdf")],
        ["Synthetic DBU warning"],
        [Path("sample.gds")],
        window.config.layers[0],
        window,
    )
    qtbot.addWidget(dialog)
    save_button = dialog.ui.buttonBox.button(
        QDialogButtonBox.StandardButton.Save
    )

    assert dialog.ui.exportChecklist.count() == 7
    checklist_text = "\n".join(
        dialog.ui.exportChecklist.item(index).text()
        for index in range(dialog.ui.exportChecklist.count())
    )
    assert "Synthetic DBU warning" in checklist_text
    assert "1 existing output file(s) will be replaced" in checklist_text
    assert "[WILL BE REPLACED]" in dialog.ui.fileList.item(0).text()

    for index in range(5):
        dialog.ui.exportChecklist.item(index).setCheckState(
            Qt.CheckState.Checked
        )
    assert not save_button.isEnabled()
    for index in range(5, dialog.ui.exportChecklist.count()):
        dialog.ui.exportChecklist.item(index).setCheckState(
            Qt.CheckState.Checked
        )
    assert save_button.isEnabled()


def test_export_checklist_can_be_customized_with_bilingual_json(
    qtbot,
    tmp_path,
) -> None:
    document = json.loads(
        DEFAULT_EXPORT_CHECKLIST_PATH.read_text(encoding="utf-8")
    )
    document["zh_CN"]["title"] = "自定义确认清单"
    document["zh_CN"]["intro"] = "自定义说明"
    document["zh_CN"]["confirmations"] = [
        "确认自定义 Al Pad Layer Name：{name}；Process：{technology_name}"
    ]
    document["zh_CN"]["warning_template"] = "自定义警告：{message}"
    document["zh_CN"]["replacement_template"] = "自定义覆盖数量：{count}"
    config_path = tmp_path / "export_checklist.json"
    config_path.write_text(
        json.dumps(document, ensure_ascii=False),
        encoding="utf-8",
    )

    window = MainWindow()
    qtbot.addWidget(window)
    window.ui.technologyEdit.setText("CustomTech")
    dialog = ExportConfirmationDialog(
        [Path("sample.gds")],
        ["test warning"],
        [Path("sample.gds")],
        window.config.layers[0],
        window,
        language="zh_CN",
        checklist_path=config_path,
    )
    qtbot.addWidget(dialog)

    assert dialog.ui.exportChecklistGroup.title() == "自定义确认清单"
    assert dialog.ui.checklistIntroLabel.text() == "自定义说明"
    assert dialog.ui.exportChecklist.count() == 3
    checklist_text = "\n".join(
        dialog.ui.exportChecklist.item(index).text()
        for index in range(dialog.ui.exportChecklist.count())
    )
    assert (
        "确认自定义 Al Pad Layer Name：AP；Process：CustomTech"
        in checklist_text
    )
    assert "自定义警告：test warning" in checklist_text
    assert "自定义覆盖数量：1" in checklist_text


def test_bump_type_editor_accepts_underscores(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    validator = window.ui.bumpTypeEdit.validator()
    assert validator.validate("Flip_Chip_LF", 12)[0] == QValidator.State.Acceptable
    assert validator.validate("Flip Chip", 9)[0] == QValidator.State.Invalid


def test_validation_area_displays_multiple_messages(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    window.refresh()
    lines = window.ui.validationText.toPlainText().splitlines()
    assert len(lines) > 1
    assert all(line.startswith("ERROR:") for line in lines)


def test_preview_axis_uses_nice_micrometer_ticks() -> None:
    assert _nice_tick_spacing(0.7) == 1
    assert _nice_tick_spacing(1.1) == 2
    assert _nice_tick_spacing(2.1) == 5
    assert _nice_tick_spacing(6.0) == 10
    assert _tick_values(-11, 11, 5) == [-10, -5, 0, 5, 10]
    assert _format_tick(80, 10) == "80"
    assert _format_tick(0.5, 0.1) == "0.5"


def test_preview_origin_maps_to_zero_and_mouse_coordinate_is_available(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.resize(1380, 820)
    window.refresh()
    window.show()
    qtbot.waitUntil(lambda: len(window.preview._panel_views) == 1)

    view = window.preview._panel_views[0]
    origin = view.map_point(0, 0)
    assert view.screen_to_um(origin) == (0.0, 0.0)
    _send_mouse_move(window.preview, origin.toPoint())
    assert window.preview.hover_coordinate_um is not None
    assert abs(window.preview.hover_coordinate_um[0]) < 0.2
    assert abs(window.preview.hover_coordinate_um[1]) < 0.2


def test_preview_mouse_tracking_reuses_static_cache(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.resize(1380, 820)
    window.refresh()
    window.show()
    qtbot.waitUntil(lambda: len(window.preview._panel_views) == 1)

    preview = window.preview
    view = preview._panel_views[0]
    cached_pixmap = preview._static_cache
    cache_build_count = preview._static_cache_build_count
    assert cached_pixmap is not None

    for step in range(100):
        x = round(view.plot.left() + 5 + step % max(1, int(view.plot.width() - 10)))
        y = round(view.plot.top() + 5 + (step * 7) % max(1, int(view.plot.height() - 10)))
        _send_mouse_move(preview, QPoint(x, y))

    qtbot.wait(10)
    assert preview.hover_coordinate_um is not None
    assert preview._static_cache is cached_pixmap
    assert preview._static_cache_build_count == cache_build_count


def test_preview_cache_is_rebuilt_after_layer_selection_changes(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.resize(1380, 820)
    window.refresh()
    window.show()
    qtbot.waitUntil(lambda: len(window.preview._panel_views) == 1)

    preview = window.preview
    cache_build_count = preview._static_cache_build_count
    preview.set_selected_layer(window.config.layers[1].uid)
    assert preview._static_cache is None

    preview.repaint()
    assert preview._static_cache is not None
    assert preview._static_cache_build_count == cache_build_count + 1


def test_show_nodes_uses_small_markers_and_rebuilds_only_static_cache(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.resize(1380, 820)
    window.refresh()
    window.show()
    qtbot.waitUntil(lambda: len(window.preview._panel_views) == 1)

    preview = window.preview
    assert preview.show_nodes
    window.ui.showNodesCheck.setChecked(False)
    assert not preview.show_nodes
    assert not window.lef_preview.show_nodes
    preview.repaint()
    cache_build_count = preview._static_cache_build_count
    window.ui.showNodesCheck.setChecked(True)
    assert preview.show_nodes
    assert window.lef_preview.show_nodes
    assert preview._static_cache is None
    assert preview.NODE_RADIUS_PX <= 1.5
    assert preview.SELECTED_NODE_RADIUS_PX <= 2.0

    preview.repaint()
    assert preview._static_cache_build_count == cache_build_count + 1
    assert len(preview._panel_nodes[0]) == 4 * 64


def test_snap_to_nodes_uses_quantized_vertex_and_does_not_require_node_display(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    _fill_round_window(window)
    window.config.process_order_confirmed = True
    window.resize(1380, 820)
    window.refresh()
    window.show()
    qtbot.waitUntil(lambda: len(window.preview._panel_views) == 1)

    preview = window.preview
    window.ui.showNodesCheck.setChecked(False)
    assert not window.ui.showNodesCheck.isChecked()
    assert not window.lef_preview.show_nodes
    assert preview.snap_to_nodes
    assert window.lef_preview.snap_to_nodes
    preview.repaint()
    cache_build_count = preview._static_cache_build_count

    target = preview._panel_nodes[0][0]
    nearby_point = QPoint(
        round(target.position.x() + 5),
        round(target.position.y() + 2),
    )
    _send_mouse_move(preview, nearby_point)

    assert preview._snapped_node == target
    assert preview._hover_position == target.position
    assert preview.hover_coordinate_um == (
        target.x_dbu * float(window.config.dbu_um),
        target.y_dbu * float(window.config.dbu_um),
    )
    assert preview._static_cache_build_count == cache_build_count

    window.ui.snapNodesCheck.setChecked(False)
    assert not window.lef_preview.snap_to_nodes
    assert preview._snapped_node is None
    assert preview._hover_position != target.position


def test_node_controls_do_not_modify_export_configuration(qtbot) -> None:
    window = MainWindow()
    qtbot.addWidget(window)
    config_before = deepcopy(window.config)
    window.ui.showNodesCheck.setChecked(False)
    window.ui.snapNodesCheck.setChecked(False)
    assert window.config == config_before
    assert not hasattr(window.config, "show_nodes")
    assert not hasattr(window.config, "snap_to_nodes")
