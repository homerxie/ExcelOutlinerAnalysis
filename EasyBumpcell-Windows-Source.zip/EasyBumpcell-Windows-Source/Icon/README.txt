Windows: use NeonDoubleRingIcon.ico
macOS: use NeonDoubleRingIcon.icns
Linux: use the PNG files (recommended 256x256 or 512x512).
All files use transparent outer corners.
