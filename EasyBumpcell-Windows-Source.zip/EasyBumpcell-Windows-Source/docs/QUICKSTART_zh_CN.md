# EasyBumpcell 快速入门

特别鸣谢：

这份教程带你使用示例工艺模板，完成一次 Round Bump 的 GDS、LEF 和 PDF 导出。

> **重要：** 教程中的 `C1x_CuBOT_Round_Oval` 只是演示数据，不能直接用于真实 Sample GDS输出。正式导出前，必须换成项目中经过审核的工艺数据。

## 1. 启动程序并切换中文

程序已经打包，直接启动 `EasyBumpcell.exe` 。

需要中文界面时，选择菜单：

```text
Settings（设置） → Language（语言） → 简体中文
```

软件会记住语言设置。GDS、LEF 和 PDF 的内容不会因为界面语言改变。
![step0](images/step0.png)

## 2. 载入示例工艺模板

在窗口左上角的“工艺模板”下拉框中选择：

```text
C1x_CuBOT_Round_Oval
```

出现“应用工艺模板”确认框后，确认模板会替换当前内容，再点击“确定”。

如果下拉框中没有这个模板：

1. 点击“导入”。
2. 选择程序文件夹中的 `template/C1x_CuBOT_Round_Oval.json`。
3. 确认导入并应用。

模板会自动填入以下演示数据：

- Technology Name 和 Bump Type
- Process DBU
- Layer Name、Layer Number、Datatype 和尺寸
- Tapeout Layer
- Al Pad drawing Layer

模板不会修改 Version，也不会自动确认工艺顺序。

## 3. 填写 Version

在“版本 *”中输入：

```text
V1
```

Version 会写入输出文件名，但不会写入内部 GDS Cell Name。

## 4. 检查Layer 、形状、 DBU和Al Pad图层

为了完成第一次简单导出，“形状类型”保持“圆形”。

检查 Layer 表格已经显示演示数据，并确认：

- `Tapeout?` 指的是该gds layer是否会tapout成mask，也就是他是不是真的会被制造出来。这决定哪些 Layer 参与输出gds文件名、 Cell Name 命名；未勾选的 Layer 仍会保留在 GDS 几何中，只是不参与命名。
- `Layer Number / Datatype` 他们的组合必须是唯一的（程序会自动检查）。
- Round 使用“直径”；Oval 使用“短轴”和“长轴”。
- Oval 的任意层的长轴必须大于短轴（程序会自动检查）。
- 然后检查表格下方的 `Al Pad drawing *`。示例应显示：`AP — GDS Layer Number 10 / Datatype 0`，真实项目中，这里必须选择实际使用的 Al Drawing Layer，不能选择 Marking Layer 或 Dummy Layer，以确保LEF的图层使用正确。

- 按照软件提示，检查DBU及Layer Name、Layer Number、Data Type，鼠标悬浮在"?"上可以获得详细教程。
  ![step4.1](images/step4.1.png)

  ![step4.2](images/step4.2.png)

在上述所有点输入完整，校验无误时，右侧出现 GDS / LEF 图形预览。

![step4](images/step4.png)

## 5. 确认工艺顺序

点击表格右下方的“确认工艺顺序”。

示例模板的 Tapeout 工艺顺序是：

```text
AP → CB2 → PIO → UBM
```

核对无误后点击“是”。如果之后修改、增加、删除或拖动 Layer，需要重新确认。这将确定gds文件名、 Cell Name 命名顺序。默认情况下，tapeout层按照工艺顺序参与gds命名，其中第一层和最后一层参与cell命名。

完成上述步骤后，界面应接近下图：

![step5](images/step5.png)

此时应同时看到：

- 右侧 GDS 图形预览，可以看到所有NODE位置，零点处于Al pad最小外接矩形的左下角。
- “输出摘要”中的“校验”显示绿色“通过”。
- “导出 GDS + LEF + PDF”按钮可以点击。

也可以打开“LEF 预览”页，检查所选 Al Pad 的 PIN、LABEL 和 BOUNDARY。

## 6. 导出文件

1. 点击“导出 GDS + LEF + PDF”。
2. 在“选择导出形状”中只勾选“圆形”，然后确定。
   <img src="images/step6.1.png" alt="step6.1" style="zoom:67%;" />
3. 选择一个文件夹作为输出目录。
4. 在“导出前必须确认”窗口中逐条核对内容（实际核对项目可能随版本更新有所差异）。
   <img src="images/step6.2-6427024.png" alt="step6.2" style="zoom:50%;" />
5. 只有确认信息确实正确后，才勾选对应项目。
6. 全部确认完成后，点击“导出”。

成功后会显示“导出完成”，输出目录中包含：

- 一个 `.gds` 文件
- 一个对应的 `.lef` 文件
- 一个英文 `.pdf` 验证报告，用于查看详细信息和相关评审。

软件会在导出过程中重新读取并验证生成的文件。

对于Round / Oval 同时存在的mixed bumpcells，在两种形状尺寸设置完成后，可以同时导出GDS、LEF和合并的PDF。

## 常见问题

### 导出按钮是灰色的

查看左下角“输出摘要”中的“校验”。常见原因包括：

- Technology Name 或 Version 未填写。
- Layer Number、Datatype 或尺寸不完整。
- 没有选择 Al Pad drawing Layer。
- 修改 Layer 后没有重新确认工艺顺序。

### 右侧没有预览

说明当前形状仍有必填数据不完整。Round 的每个 Layer 都需要直径；Oval 的每个 Layer 都需要短轴和长轴。

### 修改了模板数据，为什么“顺序已确认”消失了

影响 Tapeout Layer 或工艺顺序的修改会自动取消确认。这是正常的安全保护，需要重新检查后确认。

### 能否增加参与Cell命名的图层？

可以，在左上角设置中的高级选项，可以选择增加参与cell name命名的图层，注意cell名字不允许超过127个字符，最好不要超过32个字符以保证最佳兼容性。

默认情况下，程序使用参与实际tapeout第一个图层和最后一个图层进行命名，一般分别对应后端最相关的Al和封装pitch最相关的UBM层。

<img src="images/QA1.png" alt="QA1" style="zoom:50%;" />

### 能否使用Bumpcell中心作为原点？

可以，在左上角设置中的高级选项，原点定义下来框选择公共中心即可。

需要注意：当前大部分工艺sample gds使用Al pad drawing最小外接矩形的左下角作为原点，如使用中心作为原点，请与后端确认导出的LEF原点正确。

<img src="images/QA2.png" alt="QA2" style="zoom:50%;" />

### 椭圆形Bumpcell的旋转角度如何定义

按照大部分工艺sample gds的定义，取X轴方向为0度，正旋转方向为逆时针方向。可以在高级设置中修改，但注意修改是否与设计者理解一致。

### 能否保存当前工程

本软件支持将当前设置保存为模板，模板默认存于程序目录下的`template`文件夹内。用户可以在软件界面保存、删除当前数据。请注意，应用新的模板会覆盖当前窗口所有设置，包含高级选项中的设置。

### 可以直接使用示例模板生产吗

不可以。真实项目至少要从 techfile、layermap 和 design rule 中重新核对：

1. Process DBU。
2. 每个 GDS Layer Number 和 Datatype。
3. Al Drawing Layer 的名称与映射。
4. Tapeout Layer 及其工艺顺序。
5. 所有几何尺寸。

确认这些数据后，建议把它们保存为该项目专用的工艺模板，后续任务直接复用。
