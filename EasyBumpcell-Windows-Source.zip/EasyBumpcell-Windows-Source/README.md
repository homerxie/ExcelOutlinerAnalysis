# EasyBumpcell

**English** | [简体中文](README_zh_CN.md)

EasyBumpcell v1.2 is a cross-platform PySide6 desktop application for generating concentric Round or Oval sample GDS files, matching Al-pad LEF abstracts, and an English PDF verification report.

- New user: follow the Chinese [5-minute quick-start tutorial](docs/QUICKSTART_zh_CN.md).
- Product requirements: [PRODUCT_SPECIFICATION.md](PRODUCT_SPECIFICATION.md)
- Development plan: [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md)

![EasyBumpcell with a complete Round example](docs/images/quickstart-ready.png)

## What it generates

| Export selection | GDS files | LEF files | PDF report |
|---|---:|---:|---:|
| Round | 1 | 1 | 1 Round report |
| Oval | 4 (`0D`, `45D`, `90D`, `135D`) | 4 | 1 Oval report |
| Round + Oval | 5 | 5 | 1 combined report |

Each GDS contains all configured layer polygons. Each matching LEF contains one macro for the user-selected Al Pad drawing layer. The report records the generated names, checksums, geometry, coordinate conventions, and validation result.

## Typical workflow

1. Apply an approved process template or enter the process data manually.
2. Enter the required file Version and select Round or Oval for the live view.
3. Complete every Layer Name, Layer Number, Datatype, and shape dimension.
4. Mark the Tapeout layers and drag the rows into the required process order.
5. Select and verify the actual Al Pad drawing layer used by the LEF.
6. Confirm the Tapeout process order.
7. Review the grid-compliant GDS and parsed LEF previews.
8. Click Export, select one or both complete shapes, and choose an output directory.
9. Check every item in the Required Export Checklist before writing the files.

The application cannot inspect an external techfile, layermap, or design-rule document by itself. The user remains responsible for confirming those process definitions.

## Current defaults

- Interface language: English on first launch; English and Simplified Chinese can be switched at runtime and the selection is persisted.
- Shape Type: `Round`.
- Process DBU: `0.0005 µm`; the other supported value is `0.001 µm`.
- Al Pad Layer: no default selection. It must be chosen explicitly.
- Origin: synchronized to the selected Al Pad Layer and placed at that layer's final quantized bounding-box lower-left.
- Preview controls: `Show Nodes` and `Snap to Nodes` are both enabled.
- Layer Number and dimensions start empty; Datatype starts at `0`.

The default layer table is:

| Order | Layer Name | Tapeout? |
|---:|---|:---:|
| 1 | AP | Yes |
| 2 | ALPAD | No |
| 3 | CB2 | Yes |
| 4 | PIO | Yes |
| 5 | UBM | Yes |
| 6 | UBM_CU | No |

`Tapeout?` controls which layers participate in generated file names, automatic Cell Name selection, and the confirmed process-order text. Non-Tapeout layers remain in the GDS geometry and can still be selected as the LEF Al Pad layer after explicit confirmation.

## Geometry and coordinate guarantees

### Round

- One regular 64-sided polygon per layer.
- The first point is the rightmost vertical midpoint.
- The points are counterclockwise and include all four axis extrema.

### Oval

- One 66-sided elongated-circle polygon per layer: 33 points on each semicircular end, joined by two straight edges.
- Four independent layouts are generated at logical angles `0D`, `45D`, `90D`, and `135D`.
- At `0D`, the first point is the positive major-axis endpoint. The first point rotates with the geometry, and every polygon remains counterclockwise.
- The default zero-degree major axis is X and the default positive rotation is counterclockwise. Both are configurable in Advanced Settings.

### DBU and origin

- All input dimensions are positive micrometer values with at most one decimal place.
- Oval requires `Major Axis > Minor Axis > 0`.
- Geometry is rotated and then quantized to integer Process-DBU coordinates.
- GDS and LEF reuse the same ordered, quantized Al Pad polygon coordinates, including the first point.
- The default origin follows the selected Al Pad layer. Advanced Settings can disable that synchronization, choose another reference layer, or use the common center.
- LEF `FOREIGN` records the vector from the GDS origin to the macro lower-left; `ORIGIN` records the opposite vector from that lower-left to the macro origin.

## Layers, LEF, and naming

- Layer Number must be an integer from `0` to `65535`.
- Datatype must be an integer from `0` to `255`.
- Layer Number/Datatype pairs and Layer Names must be unique.
- Technology Name accepts ASCII letters and digits.
- Bump Type and Layer Name accept ASCII letters, digits, and underscores.
- Version accepts ASCII letters and digits with periods or hyphens only between alphanumeric groups, for example `V1`, `1.0`, or `V1.2-rc1`.
- Version is appended to every GDS, LEF, and PDF file name, but never to the internal GDS Cell Name or LEF Macro Name.
- Output file names include every Tapeout layer and its rounded dimension token.
- The automatic internal Cell Name uses Bump Type plus the first and last Tapeout layers by default. Advanced Settings can select additional Tapeout layers or apply a manual override.
- Cell Names have a 127-character hard limit; output file names have a 255-character hard limit. Optional strict legacy mode warns above the historical 32-character Cell Name limit.

Every generated LEF uses version `5.8` and contains one `CLASS COVER BUMP` macro. The LEF Macro Name exactly matches the corresponding GDS Cell Name. Its PIN polygon directly copies the selected Al Pad layer's final GDS polygon without contour conversion or translation.

The live LEF preview is not independently reconstructed from the GDS shape. EasyBumpcell first serializes the complete LEF definition and then parses the PIN, LABEL, and `ORIGIN`/`SIZE` BOUNDARY from that same text. PDF reports parse the exact staged LEF file contents.

## Process templates

Process templates are JSON files stored in the `template` folder beside the source checkout or packaged executable.

A schema-v3 template contains:

- Technology Name and optional Bump Type
- one or both complete Shape Types
- Process DBU
- the full ordered layer list
- Layer Number, Datatype, Round/Oval dimensions, color, preview pattern, and Tapeout state
- the selected Al Pad Layer
- every Advanced Settings option: origin synchronization/reference/mode, Oval
  axis and rotation convention, Cell Name layer selection/manual override, and
  strict legacy GDSII compatibility

Version is intentionally excluded. Applying a template preserves the current Version and always resets Process Order confirmation for manual review.

Only shape types with complete dimensions can be saved. Selecting both creates a `Round_Oval` template name. Templates can be saved, imported, exported, overwritten, and deleted through the main window. Schema-v1 and schema-v2 templates remain readable; because they predate stored Advanced Settings, applying them preserves the current Advanced Settings.

The source checkout includes `template/C1x_CuBOT_Round_Oval_V2.json` for the quick-start tutorial. It is demonstration data and must not be used for a real Tapeout. The packaged Windows release script creates an initially empty writable `template` folder.

## Preview and report

The main window has separate GDS and LEF preview tabs.

- GDS Preview shows all final quantized layer polygons.
- LEF Preview shows the selected Al Pad PIN polygon, LABEL anchor, and validated BOUNDARY.
- Color plus transparent vector patterns keep coincident layers distinguishable.
- Adaptive micrometer axes, numeric ticks, a mouse crosshair, and real-time coordinates use the final GDS coordinate system.
- `Show Nodes` displays the actual quantized polygon vertices.
- `Snap to Nodes` snaps the crosshair to the nearest real vertex within the UI threshold.
- The preview title shows the actual polygon node count and final bumpcell center.
- Output Summary shows the Cell Base Name, polygon node count, DBU/origin settings, and validation state.
- Node display and snapping affect only the live UI and never alter GDS, LEF, templates, or PDF output.

The English landscape-A4 PDF is titled `Sample GDS report`. Technology Name, Bump Type, Version, and Shape Type appear in the identity header, followed by this shared section order for Round, Oval, and combined reports:

1. LEF PIN Layer and Process DBU
2. Layer Number/Datatype Mapping, including Tapeout state
3. GDS Preview - Common Scale
4. LEF Preview - Common Scale
5. Generated GDS, LEF, Cell, and Macro Names
6. POSIX Checksums
7. Nominal Dimensions vs Actual Quantized Axis Dimensions
8. Coordinate and Validation Summary

Oval rows additionally record the zero-degree axis and positive-rotation convention. Combined exports share one set of tables and common-scale previews rather than repeating a separate report section for each shape.

## Validation and export safety

Before Export is enabled, at least one complete shape must pass project validation, an Al Pad Layer must be selected, and the Tapeout process order must be confirmed.

The Required Export Checklist asks the user to confirm:

- Process DBU against the selected process techfile (`*.tf`)
- every GDS Layer Number and Datatype against the current Bump design rule
- the selected Al Drawing Layer Name and Layer Number/Datatype against the process layermap (`*.map` / `*.layermap`)
- that the selection is the actual Al Drawing Layer, not a Marking or Dummy Layer
- the Tapeout layers and their process order
- every runtime quantization warning and any existing-file replacement

Every item must be checked individually. Checklist text is loaded at dialog-open time from `src/easybumpcell/export_checklist.json`.

Export is staged and committed as one operation:

1. Generate every requested GDS in a temporary directory.
2. Read each GDS back and verify its library, Cell, layer mapping, coordinates, node order, and bounds.
3. Generate and verify each matching LEF.
4. Compute the POSIX/Linux `cksum` CRC and byte count for every GDS and LEF.
5. Generate the PDF from the verified staged files.
6. Move the complete output set into the target directory, restoring prior files if the final commit fails.

A failed generation or verification does not leave a partial formal output set.

## Source checkout setup

Python 3.10 or newer is required.

### Windows PowerShell

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip setuptools wheel
python -m pip install -e ".[dev]"
python scripts\generate_ui.py
python scripts\generate_translations.py
python -m pytest
python -m easybumpcell.app
```

If PowerShell blocks activation scripts, call the virtual-environment executables directly:

```powershell
.\.venv\Scripts\python.exe scripts\generate_ui.py
.\.venv\Scripts\python.exe scripts\generate_translations.py
.\.venv\Scripts\python.exe -m pytest
.\.venv\Scripts\python.exe -m easybumpcell.app
```

### macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -e '.[dev]'
python scripts/generate_ui.py
python scripts/generate_translations.py
python -m pytest
python -m easybumpcell.app
```

### Linux

Install Python, venv support, and the desktop libraries required by Qt. On Debian/Ubuntu, a typical starting point is:

```bash
sudo apt-get install python3 python3-venv libegl1 libgl1
```

Then run:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -e '.[dev]'
python scripts/generate_ui.py
python scripts/generate_translations.py
python -m pytest
python -m easybumpcell.app
```

After installation, the console command `easybumpcell` is also available.

The source package includes `.vscode/launch.json`. Open the directory containing `pyproject.toml`, select the virtual-environment Python interpreter, choose `Debug EasyBumpcell`, and press F5.

## Development workflow

### Repository layout

```text
src/easybumpcell/domain/       Project and layer models
src/easybumpcell/geometry/     Round/Oval construction, rotation, quantization
src/easybumpcell/services/     Naming, validation, GDS/LEF/PDF export and verification
src/easybumpcell/ui/           Hand-written Qt controllers and custom widgets
src/easybumpcell/ui_generated/ Generated pyside6-uic modules
ui/                            Qt Designer source files
tests/                         Core, UI, i18n, resource and template tests
template/                      Source-checkout process templates
demo/                          Example generated outputs
```

Run the full test suite:

```bash
python -m pytest
```

Verify POSIX checksum compatibility manually:

```bash
cksum path/to/generated.gds
```

The decimal CRC and byte count must match the values in the PDF report.

### Qt Designer and Qt Linguist

The `.ui` files under `ui/` are the only source of static window and dialog layout:

```text
ui/main_window.ui
ui/advanced_dialog.ui
ui/export_dialog.ui
ui/export_shape_dialog.ui
ui/template_save_dialog.ui
```

After changing a `.ui` file, regenerate the Python modules:

```bash
python scripts/generate_ui.py
```

Never edit `src/easybumpcell/ui_generated/ui_*.py` manually. Signals, models, validation, and custom painting belong under `src/easybumpcell/ui/`.

English is the UI source language. Simplified Chinese is maintained in `src/easybumpcell/translations/easybumpcell_zh_CN.ts`. After changing visible UI text:

```bash
python scripts/generate_translations.py
pyside6-linguist src/easybumpcell/translations/easybumpcell_zh_CN.ts
python scripts/generate_translations.py
```

The export checklist is the exception: its English and Chinese text comes directly from `src/easybumpcell/export_checklist.json`, not Qt Linguist. Preserve the placeholders used by each string, including `{DBU}`, `{technology_name}`, `{process_order}`, `{all_layers}`, `{Al_layername}`, `{Al_layernumb_datatype}`, `{layer_number}`, `{datatype}`, `{message}`, and `{count}`.

### Help images

The circular `?` buttons beside Process DBU and Layers and Process Order display image tooltips loaded from:

```text
src/easybumpcell/help_images/process_dbu_help.png
src/easybumpcell/help_images/layer_mapping_help.png
```

PyInstaller includes these as package data. A packaged application can override them with a `help_images` folder beside the executable. Images preserve aspect ratio, are never enlarged, and are smoothly reduced only when they exceed the `720 × 480` logical-pixel tooltip limit or 90% of the current screen's available geometry.

## Packaging

Prebuilt applications are not delivered by this repository. Build on the same operating system as the intended output. Before packaging, regenerate the UI and translations and run the tests:

```bash
python scripts/generate_ui.py
python scripts/generate_translations.py
python -m pytest
```

### Windows

PyInstaller cannot cross-compile a Windows executable from macOS or Linux. On Windows, run:

```powershell
python scripts\package_windows_release.py
```

The script regenerates UI/translations, runs the tests, builds a PyInstaller one-directory application, and creates `dist\EasyBumpcell-Windows.zip`. Launch the packaged application with `EasyBumpcell\EasyBumpcell.exe`.

Use `python scripts\package_windows_release.py --skip-tests` only when the tests already passed in the same checkout. The executable embeds `Icon/NeonDoubleRingIcon.ico`; the full runtime icon set is copied under `EasyBumpcell\internal\Icon\`.

### macOS

Run natively on the intended CPU architecture:

```bash
python -m PyInstaller --noconfirm --clean --windowed \
  --contents-directory internal \
  --name EasyBumpcell \
  --paths src \
  --collect-data easybumpcell \
  --add-data Icon:Icon \
  --icon Icon/NeonDoubleRingIcon.icns \
  src/easybumpcell/app.py
```

The result is `dist/EasyBumpcell.app`. Build separately on Apple Silicon and Intel unless a universal Python environment and universal dependency set have been prepared and tested.

### Linux

Build on the oldest Linux/glibc environment that must be supported:

```bash
python -m PyInstaller --noconfirm --clean --windowed \
  --contents-directory internal \
  --name EasyBumpcell \
  --paths src \
  --collect-data easybumpcell \
  --add-data Icon:Icon \
  src/easybumpcell/app.py
```

The result is created under `dist/EasyBumpcell/`. It can be distributed as a directory archive or used as the input to an AppImage workflow.

## Output naming examples

Round:

```text
TechName_LF_Round_80AP_40CB2_30PIO_60UBM_V1.gds
TechName_LF_Round_80AP_40CB2_30PIO_60UBM_V1.lef
TechName_LF_Round_80AP_40CB2_30PIO_60UBM_Report_V1.pdf
```

The default internal Round Cell/LEF Macro Name for that example is:

```text
LF_AP80_UBM60
```

Oval:

```text
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_0D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_0D_V1.lef
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_45D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_45D_V1.lef
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_90D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_90D_V1.lef
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_135D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_135D_V1.lef
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_Report_V1.pdf
```

Exporting both shapes uses the same five GDS/LEF pairs and one combined report:

```text
TechName_LF_Round_Oval_Report_V1.pdf
```
