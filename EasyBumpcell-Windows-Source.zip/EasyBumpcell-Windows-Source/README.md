# EasyBumpcell

EasyBumpcell is a PySide6 desktop application for generating concentric Round or Oval sample GDS files, matching Al-pad LEF abstracts and an English PDF verification report.

The authoritative requirements are in:

- `PRODUCT_SPECIFICATION.md`
- `DEVELOPMENT_PLAN.md`

## Main behavior

- Round uses one regular 64-sided polygon per layer. Its first point is the rightmost vertical midpoint (`Xmax`, `Ymax / 2` with the default lower-left origin), followed by counterclockwise points.
- Oval uses one 66-sided elongated-circle polygon per layer. At `0D` its first point is the `Xmax` major-axis endpoint; the first point rotates with the `45D`, `90D` and `135D` geometry, and every polygon remains counterclockwise.
- GDS and LEF reuse exactly the same ordered, quantized polygon coordinates, including the first point. `FOREIGN` records `(Xmin, Ymin)` from the GDS foreign origin to the macro lower-left, while `ORIGIN` records the opposite vector `(-Xmin, -Ymin)` from that lower-left to the macro origin.
- The right-side workspace has separate GDS and LEF preview tabs. LEF Preview serializes the current LEF macro and parses `{Layer}.PIN`, `{Layer}.LABEL`, and `BOUNDARY` from that single definition; it does not independently reconstruct preview geometry from GDS assumptions. PDF reports parse the exact staged LEF file contents.
- The Al Pad Layer is unselected by default and must be chosen manually below the Layer table. All Layers remain available for selection.
- Before every export, the user must confirm that the selected Layer Name exactly matches the target technology LEF/layermap.
- Before Export is enabled, every fixed process confirmation, runtime warning, and existing-file replacement must be checked individually in the Required Export Checklist.
- Every LEF contains one `CLASS COVER BUMP` macro. Its LAYER name exactly matches the user-confirmed Al Pad Layer Name. Its POLYGON directly copies every final grid-compliant GDS vertex and its order without translation or contour conversion.
- All dimensions are positive micrometer values with at most one decimal place.
- A required file version is appended to every GDS and report file name but never to the internal GDS Cell name.
- The Process DBU changes only through direct user editing or when the user
  explicitly applies a saved process template.
- Process templates are stored as JSON in the `template` folder beside the
  source application or packaged executable. A template contains Technology,
  Bump Type, one or both available Shapes, Process DBU, the complete ordered
  layer definitions and the selected Al Pad layer. It never contains or changes
  Version, and applying a template always resets Process Order confirmation for
  manual review.
- Saving a process template opens a confirmation dialog with a live JSON file
  name preview, Round/Oval selection and an optional suffix. Only shapes with
  complete dimensions can be selected; selecting both produces a
  `Round_Oval` template name. The suffix follows the generated GDS file-name
  character rules. Stored templates can be exported, imported, overwritten or
  deleted after confirmation.
- Process DBU is limited to `0.001 µm` and `0.0005 µm`, with `0.0005 µm` selected by default.
- Process DBU is edited in the main Project section, which reminds the user to confirm that it exactly matches the project's techfile DBU definition.
- Every GDS is read back and verified before final output.
- Export asks which available shapes to generate. Selecting both writes the
  Round and Oval GDS/LEF sets together and creates one combined PDF report with
  separate sections for both shapes.
- The report uses the default POSIX/Linux `cksum` CRC, byte count and file name for every generated GDS and LEF file.
- UI and PDF previews combine color with transparent vector patterns so coincident layers remain distinguishable; the report mapping includes the matching pattern legend.
- The live UI preview and Output Summary show the actual node count and final GDS bumpcell-center coordinates. The preview also includes adaptive micrometer axes, numeric ticks, a mouse crosshair, real-time coordinates, quantized-vertex markers and nearest-node snapping; both node controls are enabled by default. Node controls affect the live preview only and never appear in the PDF.
- The PDF lists each GDS/LEF file pair, confirms that the GDS Cell Name exactly matches the LEF Macro Name, and records the selected LEF Layer Name.
- The PDF writes each final GDS bumpcell center directly into its Sample GDS Preview panel, followed by Layer Number/Datatype Mapping. A separate LEF Preview shows PIN, LABEL and BOUNDARY with an in-figure legend. BOUNDARY is parsed from `ORIGIN` and `SIZE` as `(-ORIGIN_X, -ORIGIN_Y)` to `(SIZE_X-ORIGIN_X, SIZE_Y-ORIGIN_Y)` and is drawn only after those four edges exactly match the exported POLYGON bounds. The report omits label-anchor coordinates, the internal GDS User Unit and the legacy-tool long-name warning.
- Concrete coordinate readouts use fixed Process-DBU precision, while reported diameter/axis dimensions use one additional decimal place; axis tick labels stay compact.
- Window layouts are maintained as Qt Designer `.ui` files and converted with `pyside6-uic`.

## PDF report order

1. `Sample GDS report`
2. Technology Name
3. Bump Type
4. Version
5. Shape Type
6. Generated GDS and Cell Names
7. LEF PIN Layer Name
8. POSIX Checksums
9. Sample GDS Preview
10. Layer Number/Datatype Mapping
11. Nominal Dimensions vs Actual Quantized Axis Dimensions
12. LEF Preview
13. Origin Definition
14. Process DBU
15. Zero-Degree Axis (Oval only)
16. Positive Rotation Direction (Oval only)
17. Validation Status

Round reports omit the two Oval-only angle-convention sections.

## Source checkout setup

Python 3.10 or newer is required when running from source.

### Windows PowerShell

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt
python -m pip install -e . --no-deps
python scripts\generate_ui.py
python scripts\generate_translations.py
python -m pytest
python -m easybumpcell.app
```

The source package includes `.vscode\launch.json`. Open the directory that
contains `pyproject.toml` in VS Code, select `.venv\Scripts\python.exe` as the
interpreter, choose `Debug EasyBumpcell`, and press F5. The module name
`easybumpcell.app` refers to the file `src\easybumpcell\app.py`.

If PowerShell blocks activation scripts, either update the current-user execution policy or call the virtual-environment executables directly:

```powershell
.\.venv\Scripts\python.exe scripts\generate_ui.py
.\.venv\Scripts\python.exe scripts\generate_translations.py
.\.venv\Scripts\python.exe -m easybumpcell.app
```

### macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -e '.[dev]'
python scripts/generate_ui.py
python scripts/generate_translations.py
python -m pytest
python -m easybumpcell.app
```

### Linux

Install Python, venv support and the desktop libraries required by Qt using the package manager for the selected distribution. Then:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -e '.[dev]'
python scripts/generate_ui.py
python scripts/generate_translations.py
python -m pytest
python -m easybumpcell.app
```

On Debian/Ubuntu, a typical starting point is:

```bash
sudo apt-get install python3 python3-venv libegl1 libgl1
```

## Qt Designer and Qt Linguist workflow

The files under `ui/` are the only source of static window and dialog layout:

```text
ui/main_window.ui
ui/advanced_dialog.ui
ui/export_dialog.ui
ui/export_shape_dialog.ui
ui/template_save_dialog.ui
```

Regenerate Python UI modules after every `.ui` change:

```bash
python scripts/generate_ui.py
```

English is the source language. Simplified Chinese is maintained in
`src/easybumpcell/translations/easybumpcell_zh_CN.ts`. The export checklist is
the exception: its English and Chinese text is configured directly in
`src/easybumpcell/export_checklist.json`, and does not use Qt Linguist. The
JSON is read each time the export confirmation dialog opens, so its checklist
title, instruction, fixed confirmations, warning template and replacement
template can be customized without regenerating `.ts` or `.qm` files. Preserve
the applicable `{name}`, `{technology_name}`, `{layer_number}`, `{datatype}`,
`{message}` and `{count}` placeholders when they are needed.

The circular `?` buttons beside the Process DBU and Layers and Process Order
warnings display image Tooltips. The portable relative paths are:

```text
help_images/process_dbu_help.png
help_images/layer_mapping_help.png
```

When running from source, put the files under
`src/easybumpcell/help_images/`. PyInstaller includes them through
`--collect-data easybumpcell`. A packaged application can override the bundled
files by placing the same relative `help_images/` directory beside the
executable. The files are read when the Tooltip opens. Images keep their
original aspect ratio and are scaled down only when they exceed the
`720 × 480` device-independent-pixel Tooltip limit. The limit is also capped
to 90% of the current screen's available logical geometry; Qt applies the
application's active per-screen DPI scale when rendering the Tooltip. The
application uses smooth downsampling and never enlarges the source PNG, which
avoids an additional low-quality Windows resampling pass. For a full-width
720-logical-pixel Tooltip, use images at least 900 px wide for 125% DPI,
1080 px for 150%, and 1440 px for 200%.

After changing other visible text, update the catalog, edit it with Qt
Linguist, and compile the runtime translation:

```bash
python scripts/generate_translations.py
pyside6-linguist src/easybumpcell/translations/easybumpcell_zh_CN.ts
python scripts/generate_translations.py
```

Generated modules are written to:

```text
src/easybumpcell/ui_generated/
```

Never edit `ui_generated/ui_*.py` manually. Hand-written signal wiring, models, validation and custom painting belong under `src/easybumpcell/ui/`.

## Development commands

Run all tests:

```bash
python -m pytest
```

Run the application:

```bash
python -m easybumpcell.app
```

Verify POSIX checksum compatibility manually:

```bash
cksum path/to/generated.gds
```

The decimal CRC and byte count must match the values in the PDF report.

## Packaging commands

Prebuilt applications are not delivered with this repository. Package on the same operating system as the intended output.

Always run the UI generator and tests first:

```bash
python scripts/generate_ui.py
python scripts/generate_translations.py
python -m pytest
```

### Windows

PyInstaller cannot cross-compile a Windows executable from macOS or Linux.
Run the release build on Windows in an activated virtual environment:

```powershell
python scripts\package_windows_release.py
```

This one command regenerates the UI and translations, runs the test suite,
builds the application with PyInstaller, and creates the distributable archive
`dist\EasyBumpcell-Windows.zip`. The archive contains the one-directory
application; launch it with `EasyBumpcell\EasyBumpcell.exe`.
The archive also includes an initially empty `EasyBumpcell\template` folder;
templates saved in the packaged application are written there.

The script uses the following PyInstaller command:

```powershell
python -m PyInstaller --noconfirm --clean --windowed --onedir --noupx `
  --contents-directory internal `
  --name EasyBumpcell `
  --paths src `
  --collect-data easybumpcell `
  --add-data "$PWD\Icon;Icon" `
  --icon "$PWD\Icon\NeonDoubleRingIcon.ico" `
  --distpath dist `
  --workpath build\pyinstaller `
  --specpath build\pyinstaller `
  src\easybumpcell\app.py
```

Use `python scripts\package_windows_release.py --skip-tests` only when the
tests have already passed in the same source checkout.

The Windows executable embeds `NeonDoubleRingIcon.ico`. The complete icon
set is copied to `EasyBumpcell\internal\Icon\` for Qt runtime loading.

### macOS

Run natively on the intended CPU architecture:

```bash
python -m PyInstaller --noconfirm --clean --windowed \
  --contents-directory internal \
  --name EasyBumpcell \
  --paths src \
  --collect-data easybumpcell \
  --add-data Icon:Icon \
  --icon Icon/NeonDoubleRingIcon.icns \
  src/easybumpcell/app.py
```

The application bundle is created as `dist/EasyBumpcell.app`. Its Finder and
Dock icon uses `NeonDoubleRingIcon.icns`; the PNG set remains available to Qt
inside the native application resources. Build separately on Apple Silicon
and Intel unless a universal Python environment and universal dependency set
have been prepared and tested.

### Linux

Build on the oldest Linux/glibc environment that must be supported:

```bash
python -m PyInstaller --noconfirm --clean --windowed \
  --contents-directory internal \
  --name EasyBumpcell \
  --paths src \
  --collect-data easybumpcell \
  --add-data Icon:Icon \
  src/easybumpcell/app.py
```

The result is created under `dist/EasyBumpcell/`; the runtime PNG icon set is
stored under `internal/Icon/`. It can be distributed as a directory archive
or used as the input for an AppImage workflow.

## Output examples

Round:

```text
TechName_LF_Round_80AP_40CB2_30PIO_60UBM_V1.gds
TechName_LF_Round_80AP_40CB2_30PIO_60UBM_V1.lef
TechName_LF_Round_80AP_40CB2_30PIO_60UBM_Report_V1.pdf
```

Oval:

```text
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_0D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_0D_V1.lef
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_45D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_45D_V1.lef
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_90D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_90D_V1.lef
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_135D_V1.gds
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_135D_V1.lef
TechName_LF_Oval_4080AP_2040CB2_1030PIO_3060UBM_Report_V1.pdf
```
