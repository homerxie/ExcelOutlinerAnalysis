from __future__ import annotations

from decimal import Decimal


def dbu_decimal_places(dbu_um: Decimal) -> int:
    dbu = Decimal(dbu_um)
    if not dbu.is_finite() or dbu <= 0:
        raise ValueError("Process DBU must be a positive finite value")
    return max(0, -dbu.normalize().as_tuple().exponent)


def format_coordinate_um(value: Decimal | float, dbu_um: Decimal) -> str:
    decimal_value = value if isinstance(value, Decimal) else Decimal(str(value))
    return f"{decimal_value:.{dbu_decimal_places(dbu_um)}f}"


def format_dimension_um(value: Decimal | float | int, dbu_um: Decimal) -> str:
    decimal_value = value if isinstance(value, Decimal) else Decimal(str(value))
    return f"{decimal_value:.{dbu_decimal_places(dbu_um) + 1}f}"
