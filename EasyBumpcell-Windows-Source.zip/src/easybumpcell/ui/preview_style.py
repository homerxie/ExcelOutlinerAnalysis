from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QIcon, QPainter, QPainterPath, QPen, QPixmap, QPolygonF

from easybumpcell.preview_patterns import (
    BACKWARD_DIAGONAL,
    DENSE_DOTS,
    DIAGONAL_CROSS,
    DOTS,
    FORWARD_DIAGONAL,
    GRID,
    HORIZONTAL,
    VERTICAL,
)


def _positions(minimum: float, maximum: float, spacing: float, phase: float = 0) -> list[float]:
    first = math.floor((minimum - phase) / spacing) * spacing + phase
    values = []
    value = first
    while value <= maximum + 1e-8:
        values.append(value)
        value += spacing
    return values


def draw_preview_pattern(
    painter: QPainter,
    polygon: QPolygonF,
    color: QColor,
    pattern: str,
    *,
    base_spacing: float = 9.0,
    dot_radius: float = 1.15,
) -> None:
    path = QPainterPath()
    path.addPolygon(polygon)
    path.closeSubpath()
    bounds = path.boundingRect()
    painter.save()
    painter.setClipPath(path)

    tint = QColor(color)
    tint.setAlpha(13)
    painter.fillPath(path, tint)

    texture_color = QColor(color)
    texture_color.setAlpha(195)
    painter.setPen(QPen(texture_color, 0.9))
    painter.setBrush(texture_color)

    if pattern in (FORWARD_DIAGONAL, BACKWARD_DIAGONAL, DIAGONAL_CROSS):
        spacing = base_spacing * (1.35 if pattern == DIAGONAL_CROSS else 1.0)
        phase = spacing * 0.27 if pattern == DIAGONAL_CROSS else 0
        extent = bounds.height()
        starts = _positions(
            bounds.left() - bounds.height(),
            bounds.right(),
            spacing,
            phase,
        )
        if pattern in (FORWARD_DIAGONAL, DIAGONAL_CROSS):
            for start in starts:
                painter.drawLine(
                    QPointF(start, bounds.bottom()),
                    QPointF(start + extent, bounds.top()),
                )
        if pattern in (BACKWARD_DIAGONAL, DIAGONAL_CROSS):
            for start in starts:
                painter.drawLine(
                    QPointF(start, bounds.top()),
                    QPointF(start + extent, bounds.bottom()),
                )
    elif pattern in (HORIZONTAL, VERTICAL, GRID):
        spacing = base_spacing * (1.35 if pattern == GRID else 1.0)
        phase = spacing * 0.27 if pattern == GRID else 0
        if pattern in (HORIZONTAL, GRID):
            for y in _positions(bounds.top(), bounds.bottom(), spacing, phase):
                painter.drawLine(
                    QPointF(bounds.left(), y),
                    QPointF(bounds.right(), y),
                )
        if pattern in (VERTICAL, GRID):
            for x in _positions(bounds.left(), bounds.right(), spacing, phase):
                painter.drawLine(
                    QPointF(x, bounds.top()),
                    QPointF(x, bounds.bottom()),
                )
    elif pattern in (DOTS, DENSE_DOTS):
        spacing = base_spacing * (1.18 if pattern == DOTS else 0.72)
        radius = dot_radius if pattern == DOTS else dot_radius * 0.78
        columns = _positions(bounds.left(), bounds.right(), spacing)
        for column, x in enumerate(columns):
            offset = spacing / 2 if column % 2 else 0
            for y in _positions(
                bounds.top(),
                bounds.bottom(),
                spacing,
                offset,
            ):
                painter.drawEllipse(QPointF(x, y), radius, radius)
    else:
        painter.restore()
        raise ValueError(f"Unsupported preview pattern: {pattern}")
    painter.restore()


def preview_style_icon(color_value: str, pattern: str) -> QIcon:
    width, height = 30, 16
    pixmap = QPixmap(width, height)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    color = QColor(color_value)
    polygon = QPolygonF(
        [
            QPointF(1, 1),
            QPointF(width - 1, 1),
            QPointF(width - 1, height - 1),
            QPointF(1, height - 1),
        ]
    )
    draw_preview_pattern(
        painter,
        polygon,
        color,
        pattern,
        base_spacing=5.0,
        dot_radius=0.9,
    )
    painter.setPen(QPen(color, 1.1))
    painter.setBrush(Qt.BrushStyle.NoBrush)
    painter.drawRect(QRectF(1, 1, width - 2, height - 2))
    painter.end()
    return QIcon(pixmap)
