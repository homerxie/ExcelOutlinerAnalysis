from __future__ import annotations

import re

from PySide6.QtCore import (
    QAbstractTableModel,
    QByteArray,
    QMimeData,
    QModelIndex,
    QRegularExpression,
    Qt,
    Signal,
)
from PySide6.QtGui import QRegularExpressionValidator
from PySide6.QtWidgets import (
    QDoubleSpinBox,
    QLineEdit,
    QSpinBox,
    QStyledItemDelegate,
)

from easybumpcell.dimensions import dimension_decimal, format_input_dimension
from easybumpcell.domain.enums import ShapeType
from easybumpcell.domain.models import (
    DEFAULT_COLORS,
    LayerDefinition,
    ProjectConfig,
    default_layers,
    suggested_al_pad_layer_uid,
)
from easybumpcell.i18n import translate_preview_pattern
from easybumpcell.preview_patterns import preview_pattern_for_index, preview_pattern_label
from easybumpcell.ui.preview_style import preview_style_icon


class IntegerDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QSpinBox(parent)
        editor.setFrame(False)
        editor.setRange(0, 255)
        return editor


class DimensionDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QDoubleSpinBox(parent)
        editor.setFrame(False)
        editor.setDecimals(1)
        editor.setRange(0.1, 2_000_000_000.0)
        editor.setSingleStep(0.1)
        editor.setKeyboardTracking(False)
        return editor


class LayerNameDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setFrame(False)
        editor.setValidator(
            QRegularExpressionValidator(QRegularExpression("[A-Za-z0-9]*"), editor)
        )
        editor.setPlaceholderText(self.tr("Letters and digits only"))
        return editor


class LayerTableModel(QAbstractTableModel):
    contentChanged = Signal()
    processOrderChanged = Signal()
    MIME_TYPE = "application/x-easybumpcell-layer-row"

    def __init__(self, config: ProjectConfig, parent=None) -> None:
        super().__init__(parent)
        self.config = config

    def _headers(self) -> list[str]:
        base = [
            self.tr("Order"),
            self.tr("Layer Name"),
            self.tr("Layer Number"),
            self.tr("Datatype"),
        ]
        if self.config.shape_type is ShapeType.ROUND:
            return base + [self.tr("Diameter (µm)")]
        return base + [
            self.tr("Minor Axis (µm)"),
            self.tr("Major Axis (µm)"),
        ]

    def retranslate(self) -> None:
        last_column = self.columnCount() - 1
        if last_column >= 0:
            self.headerDataChanged.emit(
                Qt.Orientation.Horizontal,
                0,
                last_column,
            )
        if self.rowCount() and self.columnCount():
            self.dataChanged.emit(
                self.index(0, 0),
                self.index(self.rowCount() - 1, self.columnCount() - 1),
                [Qt.ItemDataRole.ToolTipRole],
            )

    def rowCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self.config.layers)

    def columnCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self._headers())

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role != Qt.ItemDataRole.DisplayRole:
            return None
        if orientation == Qt.Orientation.Horizontal:
            return self._headers()[section]
        return section + 1

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        layer = self.config.layers[index.row()]
        column = index.column()
        if role in (Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.EditRole):
            if column == 0:
                return index.row() + 1
            if column == 1:
                return layer.meaning
            if column == 2:
                return "" if layer.layer is None else layer.layer
            if column == 3:
                return "" if layer.datatype is None else layer.datatype
            if self.config.shape_type is ShapeType.ROUND:
                value = layer.diameter_um
            elif column == 4:
                value = layer.minor_axis_um
            else:
                value = layer.major_axis_um
            if value is None:
                return ""
            if role == Qt.ItemDataRole.EditRole:
                return float(dimension_decimal(value))
            return format_input_dimension(value)
        if role == Qt.ItemDataRole.DecorationRole and column == 1:
            return preview_style_icon(layer.color, layer.preview_pattern)
        if role == Qt.ItemDataRole.TextAlignmentRole and column != 1:
            return int(Qt.AlignmentFlag.AlignCenter)
        if role == Qt.ItemDataRole.ToolTipRole and column == 0:
            return self.tr("Drag this row to change the process order.")
        if role == Qt.ItemDataRole.ToolTipRole and column == 1:
            return self.tr("Preview style: {color} / {pattern}").format(
                color=layer.color.upper(),
                pattern=translate_preview_pattern(
                    preview_pattern_label(layer.preview_pattern)
                ),
            )
        return None

    def flags(self, index):
        if not index.isValid():
            return Qt.ItemFlag.ItemIsDropEnabled
        flags = (
            Qt.ItemFlag.ItemIsEnabled
            | Qt.ItemFlag.ItemIsSelectable
            | Qt.ItemFlag.ItemIsDragEnabled
            | Qt.ItemFlag.ItemIsDropEnabled
        )
        if index.column() != 0:
            flags |= Qt.ItemFlag.ItemIsEditable
        return flags

    def setData(self, index, value, role=Qt.ItemDataRole.EditRole) -> bool:
        if role != Qt.ItemDataRole.EditRole or not index.isValid():
            return False
        layer = self.config.layers[index.row()]
        column = index.column()
        try:
            if column == 1:
                meaning = str(value)
                if not re.fullmatch(r"[A-Za-z0-9]*", meaning):
                    return False
                layer.meaning = meaning
            elif column == 2:
                layer.layer = int(value)
            elif column == 3:
                layer.datatype = int(value)
            elif self.config.shape_type is ShapeType.ROUND and column == 4:
                layer.diameter_um = dimension_decimal(value, "Diameter")
            elif self.config.shape_type is ShapeType.OVAL and column == 4:
                layer.minor_axis_um = dimension_decimal(value, "Minor Axis")
            elif self.config.shape_type is ShapeType.OVAL and column == 5:
                layer.major_axis_um = dimension_decimal(value, "Major Axis")
            else:
                return False
        except (TypeError, ValueError):
            return False
        self.dataChanged.emit(index, index, [role])
        self.contentChanged.emit()
        return True

    def set_shape_type(self, shape_type: ShapeType) -> None:
        if self.config.shape_type is shape_type:
            return
        self.beginResetModel()
        self.config.shape_type = shape_type
        self.endResetModel()
        self.contentChanged.emit()

    def add_layer(self) -> None:
        row = len(self.config.layers)
        self.beginInsertRows(QModelIndex(), row, row)
        color = DEFAULT_COLORS[row % len(DEFAULT_COLORS)]
        self.config.layers.append(
            LayerDefinition(
                f"LAYER{row + 1}",
                color=color,
                preview_pattern=preview_pattern_for_index(row),
            )
        )
        self.endInsertRows()
        self.config.process_order_confirmed = False
        self.processOrderChanged.emit()
        self.contentChanged.emit()

    def remove_row(self, row: int) -> bool:
        if not 0 <= row < len(self.config.layers) or len(self.config.layers) <= 1:
            return False
        removed_uid = self.config.layers[row].uid
        self.beginRemoveRows(QModelIndex(), row, row)
        del self.config.layers[row]
        self.endRemoveRows()
        if self.config.cell_name_layer_uids is not None:
            self.config.cell_name_layer_uids = [
                uid
                for uid in self.config.cell_name_layer_uids
                if uid != removed_uid
            ]
        if self.config.origin_reference_uid == removed_uid:
            self.config.origin_reference_uid = self.config.layers[0].uid
        if self.config.al_pad_layer_uid == removed_uid:
            self.config.al_pad_layer_uid = suggested_al_pad_layer_uid(
                self.config.layers
            )
        self.config.process_order_confirmed = False
        self.processOrderChanged.emit()
        self.contentChanged.emit()
        return True

    def restore_defaults(self) -> None:
        self.beginResetModel()
        self.config.layers = default_layers()
        self.config.origin_reference_uid = self.config.layers[0].uid
        self.config.cell_name_layer_uids = None
        self.config.al_pad_layer_uid = suggested_al_pad_layer_uid(
            self.config.layers
        )
        self.config.process_order_confirmed = False
        self.endResetModel()
        self.processOrderChanged.emit()
        self.contentChanged.emit()

    def supportedDropActions(self):
        return Qt.DropAction.MoveAction

    def mimeTypes(self) -> list[str]:
        return [self.MIME_TYPE]

    def mimeData(self, indexes) -> QMimeData:
        rows = sorted({index.row() for index in indexes if index.isValid()})
        mime = QMimeData()
        if rows:
            mime.setData(self.MIME_TYPE, QByteArray(str(rows[0]).encode("ascii")))
        return mime

    def dropMimeData(self, data, action, row, column, parent) -> bool:
        if action == Qt.DropAction.IgnoreAction:
            return True
        if action != Qt.DropAction.MoveAction or not data.hasFormat(self.MIME_TYPE):
            return False
        source_row = int(bytes(data.data(self.MIME_TYPE)).decode("ascii"))
        destination_row = row if row >= 0 else (parent.row() if parent.isValid() else len(self.config.layers))
        if destination_row > source_row:
            destination_row -= 1
        if destination_row == source_row:
            return False
        return self.moveRows(QModelIndex(), source_row, 1, QModelIndex(), destination_row)

    def moveRows(self, source_parent, source_row, count, destination_parent, destination_child) -> bool:
        if count != 1 or not 0 <= source_row < len(self.config.layers):
            return False
        if not 0 <= destination_child <= len(self.config.layers):
            return False
        qt_destination = destination_child
        if destination_child > source_row:
            qt_destination += 1
        if not self.beginMoveRows(source_parent, source_row, source_row, destination_parent, qt_destination):
            return False
        layer = self.config.layers.pop(source_row)
        self.config.layers.insert(destination_child, layer)
        self.endMoveRows()
        self.config.process_order_confirmed = False
        self.processOrderChanged.emit()
        self.contentChanged.emit()
        return True
