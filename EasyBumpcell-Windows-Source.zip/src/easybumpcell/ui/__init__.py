"""Hand-written Qt controllers and custom widgets."""

