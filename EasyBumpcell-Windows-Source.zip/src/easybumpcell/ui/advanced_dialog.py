from __future__ import annotations

from PySide6.QtCore import QRegularExpression
from PySide6.QtGui import QRegularExpressionValidator
from PySide6.QtWidgets import QDialog, QDialogButtonBox

from easybumpcell.domain.enums import OriginMode, RotationDirection, ZeroDegreeAxis
from easybumpcell.domain.models import ProjectConfig
from easybumpcell.i18n import translate_enum
from easybumpcell.services.naming import default_cell_name_layer_uids
from easybumpcell.ui_generated.ui_advanced_dialog import Ui_AdvancedDialog


class AdvancedSettingsDialog(QDialog):
    def __init__(self, config: ProjectConfig, parent=None) -> None:
        super().__init__(parent)
        self.ui = Ui_AdvancedDialog()
        self.ui.setupUi(self)
        self.config = config
        self.ui.manualNameEdit.setValidator(
            QRegularExpressionValidator(
                QRegularExpression("[A-Za-z0-9_]*"),
                self.ui.manualNameEdit,
            )
        )

        for layer in config.layers:
            self.ui.originReferenceCombo.addItem(layer.meaning, layer.uid)
        reference_index = self.ui.originReferenceCombo.findData(config.origin_reference_uid)
        self.ui.originReferenceCombo.setCurrentIndex(max(reference_index, 0))

        for value in OriginMode:
            self.ui.originModeCombo.addItem(
                translate_enum(value.value),
                value.value,
            )
        self.ui.originModeCombo.setCurrentIndex(
            self.ui.originModeCombo.findData(config.origin_mode.value)
        )
        for value in ZeroDegreeAxis:
            self.ui.zeroAxisCombo.addItem(
                translate_enum(value.value),
                value.value,
            )
        self.ui.zeroAxisCombo.setCurrentIndex(
            self.ui.zeroAxisCombo.findData(config.zero_degree_axis.value)
        )
        for value in RotationDirection:
            self.ui.rotationDirectionCombo.addItem(
                translate_enum(value.value),
                value.value,
            )
        self.ui.rotationDirectionCombo.setCurrentIndex(
            self.ui.rotationDirectionCombo.findData(config.rotation_direction.value)
        )
        has_manual = bool(config.manual_cell_base_name)
        self.ui.manualNameCheck.setChecked(has_manual)
        self.ui.manualNameEdit.setText(config.manual_cell_base_name or "")
        selected_uids = (
            default_cell_name_layer_uids(config)
            if config.cell_name_layer_uids is None
            else config.cell_name_layer_uids
        )
        for layer in config.layers:
            layer_number = "—" if layer.layer is None else str(layer.layer)
            datatype = "—" if layer.datatype is None else str(layer.datatype)
            self.ui.cellNameLayersCombo.add_check_item(
                self.tr(
                    "{name} — Layer Number {layer} / Datatype {datatype}"
                ).format(
                    name=layer.meaning,
                    layer=layer_number,
                    datatype=datatype,
                ),
                layer.uid,
                checked=layer.uid in selected_uids,
            )
        self.ui.strictLegacyCheck.setChecked(
            config.strict_legacy_gdsii_compatibility
        )
        self.ui.resetCellNameLayersButton.clicked.connect(
            self._reset_cell_name_layers
        )
        self.ui.cellNameLayersCombo.checkedDataChanged.connect(
            self._update_ok_state
        )
        self._update_ok_state()

    def _reset_cell_name_layers(self) -> None:
        self.ui.cellNameLayersCombo.set_checked_data(
            default_cell_name_layer_uids(self.config)
        )

    def _update_ok_state(self) -> None:
        ok_button = self.ui.buttonBox.button(
            QDialogButtonBox.StandardButton.Ok
        )
        ok_button.setEnabled(bool(self.ui.cellNameLayersCombo.checked_data()))

    def apply_to_config(self) -> None:
        self.config.origin_reference_uid = self.ui.originReferenceCombo.currentData()
        self.config.origin_mode = OriginMode(self.ui.originModeCombo.currentData())
        self.config.zero_degree_axis = ZeroDegreeAxis(self.ui.zeroAxisCombo.currentData())
        self.config.rotation_direction = RotationDirection(
            self.ui.rotationDirectionCombo.currentData()
        )
        selected_uids = [
            str(uid) for uid in self.ui.cellNameLayersCombo.checked_data()
        ]
        if not selected_uids:
            raise ValueError("Select at least one layer for the Cell Name")
        default_uids = default_cell_name_layer_uids(self.config)
        self.config.cell_name_layer_uids = (
            None if selected_uids == default_uids else selected_uids
        )
        self.config.strict_legacy_gdsii_compatibility = (
            self.ui.strictLegacyCheck.isChecked()
        )
        self.config.manual_cell_base_name = (
            self.ui.manualNameEdit.text().strip() if self.ui.manualNameCheck.isChecked() else None
        )
