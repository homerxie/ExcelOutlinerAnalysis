from __future__ import annotations

from PySide6.QtCore import QEvent, Signal
from PySide6.QtGui import QStandardItem, QStandardItemModel
from PySide6.QtWidgets import QComboBox


class CheckableComboBox(QComboBox):
    checkedDataChanged = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setEditable(True)
        self.lineEdit().setReadOnly(True)
        self.lineEdit().setPlaceholderText(
            self.tr("Select at least one layer")
        )
        self.view().viewport().installEventFilter(self)

    def add_check_item(
        self,
        text: str,
        user_data: object,
        *,
        checked: bool = False,
    ) -> None:
        item = QStandardItem(text)
        item.setData(user_data)
        item.setCheckable(True)
        item.setCheckState(
            self._checked_state() if checked else self._unchecked_state()
        )
        self._standard_model().appendRow(item)
        self._update_summary()

    def checked_data(self) -> list[object]:
        return [
            item.data()
            for item in self._items()
            if item.checkState() == self._checked_state()
        ]

    def set_checked_data(self, values) -> None:
        selected = set(values)
        for item in self._items():
            item.setCheckState(
                self._checked_state()
                if item.data() in selected
                else self._unchecked_state()
            )
        self._update_summary()
        self.checkedDataChanged.emit()

    def eventFilter(self, watched, event) -> bool:
        if (
            watched is self.view().viewport()
            and event.type() == QEvent.Type.MouseButtonRelease
        ):
            index = self.view().indexAt(event.position().toPoint())
            if index.isValid():
                item = self._standard_model().itemFromIndex(index)
                item.setCheckState(
                    self._unchecked_state()
                    if item.checkState() == self._checked_state()
                    else self._checked_state()
                )
                self._update_summary()
                self.checkedDataChanged.emit()
            return True
        return super().eventFilter(watched, event)

    def _items(self) -> list[QStandardItem]:
        model = self._standard_model()
        return [model.item(row) for row in range(model.rowCount())]

    def _standard_model(self) -> QStandardItemModel:
        model = self.model()
        if not isinstance(model, QStandardItemModel):
            raise TypeError("CheckableComboBox requires a QStandardItemModel")
        return model

    def _update_summary(self) -> None:
        selected = [
            item.text().split(" —", 1)[0]
            for item in self._items()
            if item.checkState() == self._checked_state()
        ]
        self.lineEdit().setText(", ".join(selected))

    @staticmethod
    def _checked_state():
        from PySide6.QtCore import Qt

        return Qt.CheckState.Checked

    @staticmethod
    def _unchecked_state():
        from PySide6.QtCore import Qt

        return Qt.CheckState.Unchecked
