from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QListWidgetItem,
)

from easybumpcell.domain.models import LayerDefinition
from easybumpcell.export_checklist import (
    format_export_checklist_text,
    load_export_checklist,
)
from easybumpcell.i18n import ENGLISH
from easybumpcell.ui_generated.ui_export_dialog import Ui_ExportDialog


class ExportConfirmationDialog(QDialog):
    def __init__(
        self,
        paths: list[Path],
        warnings: list[str],
        existing: list[Path],
        al_pad_layer: LayerDefinition,
        parent=None,
        *,
        language: str | None = None,
        checklist_path: Path | None = None,
        technology_name: str | None = None,
    ) -> None:
        super().__init__(parent)
        self.ui = Ui_ExportDialog()
        self.ui.setupUi(self)
        if language is None:
            language_manager = getattr(parent, "language_manager", None)
            language = getattr(language_manager, "language", ENGLISH)
        if technology_name is None:
            project_config = getattr(parent, "config", None)
            technology_name = getattr(
                project_config,
                "technology_name",
                "",
            )
        technology_name = technology_name or "—"
        checklist_text = load_export_checklist(language, checklist_path)
        self.ui.exportChecklistGroup.setTitle(checklist_text.title)
        self.ui.checklistIntroLabel.setText(checklist_text.intro)
        for path in paths:
            suffix = (
                self.tr("  [WILL BE REPLACED]")
                if path in existing
                else ""
            )
            self.ui.fileList.addItem(path.name + suffix)
        layer_number = (
            "—" if al_pad_layer.layer is None else str(al_pad_layer.layer)
        )
        datatype = (
            "—" if al_pad_layer.datatype is None else str(al_pad_layer.datatype)
        )
        self.ui.alPadSummaryLabel.setText(
            format_export_checklist_text(
                checklist_text.al_pad_summary,
                "al_pad_summary",
                name=al_pad_layer.meaning,
                layer=layer_number,
                datatype=datatype,
            )
        )

        for confirmation in checklist_text.confirmations:
            self._add_checklist_item(
                format_export_checklist_text(
                    confirmation,
                    "confirmations",
                    name=al_pad_layer.meaning,
                    technology_name=technology_name,
                    layer_number=layer_number,
                    datatype=datatype,
                )
            )

        for warning in warnings:
            self._add_checklist_item(
                format_export_checklist_text(
                    checklist_text.warning_template,
                    "warning_template",
                    message=warning,
                )
            )
        if existing:
            self._add_checklist_item(
                format_export_checklist_text(
                    checklist_text.replacement_template,
                    "replacement_template",
                    count=len(existing),
                )
            )

        self.ui.exportChecklist.setTextElideMode(
            Qt.TextElideMode.ElideNone
        )
        self.ui.exportChecklist.setSpacing(4)
        self._save_button = self.ui.buttonBox.button(
            QDialogButtonBox.StandardButton.Save
        )
        self._save_button.setText(self.tr("Export"))
        self.ui.exportChecklist.itemChanged.connect(
            self._update_save_state
        )
        self._update_save_state()

    def _add_checklist_item(self, text: str) -> None:
        item = QListWidgetItem(text)
        item.setFlags(
            item.flags()
            | Qt.ItemFlag.ItemIsEnabled
            | Qt.ItemFlag.ItemIsUserCheckable
        )
        item.setCheckState(Qt.CheckState.Unchecked)
        self.ui.exportChecklist.addItem(item)

    def _update_save_state(self, *_args) -> None:
        checklist = self.ui.exportChecklist
        all_confirmed = checklist.count() > 0 and all(
            checklist.item(index).checkState()
            == Qt.CheckState.Checked
            for index in range(checklist.count())
        )
        self._save_button.setEnabled(all_confirmed)
