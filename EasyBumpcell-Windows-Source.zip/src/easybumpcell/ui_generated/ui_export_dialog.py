# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'export_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QAbstractItemView, QApplication, QDialog,
    QDialogButtonBox, QGroupBox, QLabel, QListWidget,
    QListWidgetItem, QSizePolicy, QVBoxLayout, QWidget)

class Ui_ExportDialog(object):
    def setupUi(self, ExportDialog):
        if not ExportDialog.objectName():
            ExportDialog.setObjectName(u"ExportDialog")
        ExportDialog.setMinimumSize(QSize(760, 620))
        self.verticalLayout = QVBoxLayout(ExportDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.summaryLabel = QLabel(ExportDialog)
        self.summaryLabel.setObjectName(u"summaryLabel")
        self.summaryLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.summaryLabel)

        self.fileList = QListWidget(ExportDialog)
        self.fileList.setObjectName(u"fileList")
        self.fileList.setMaximumSize(QSize(16777215, 140))

        self.verticalLayout.addWidget(self.fileList)

        self.exportChecklistGroup = QGroupBox(ExportDialog)
        self.exportChecklistGroup.setObjectName(u"exportChecklistGroup")
        self.exportChecklistGroup.setTitle(u"")
        self.exportChecklistLayout = QVBoxLayout(self.exportChecklistGroup)
        self.exportChecklistLayout.setObjectName(u"exportChecklistLayout")
        self.alPadSummaryLabel = QLabel(self.exportChecklistGroup)
        self.alPadSummaryLabel.setObjectName(u"alPadSummaryLabel")
        self.alPadSummaryLabel.setText(u"")
        self.alPadSummaryLabel.setWordWrap(True)

        self.exportChecklistLayout.addWidget(self.alPadSummaryLabel)

        self.checklistIntroLabel = QLabel(self.exportChecklistGroup)
        self.checklistIntroLabel.setObjectName(u"checklistIntroLabel")
        self.checklistIntroLabel.setText(u"")
        self.checklistIntroLabel.setWordWrap(True)

        self.exportChecklistLayout.addWidget(self.checklistIntroLabel)

        self.exportChecklist = QListWidget(self.exportChecklistGroup)
        self.exportChecklist.setObjectName(u"exportChecklist")
        self.exportChecklist.setStyleSheet(u"QListWidget#exportChecklist {\n"
"    color: #7A5200;\n"
"    background: #FFF6D8;\n"
"    border: 1px solid #E6C86E;\n"
"}\n"
"QListWidget#exportChecklist::item {\n"
"    color: #7A5200;\n"
"    background: #FFF6D8;\n"
"}")
        self.exportChecklist.setMinimumSize(QSize(0, 280))
        self.exportChecklist.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.exportChecklist.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.exportChecklist.setWordWrap(True)

        self.exportChecklistLayout.addWidget(self.exportChecklist)


        self.verticalLayout.addWidget(self.exportChecklistGroup)

        self.buttonBox = QDialogButtonBox(ExportDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Save)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(ExportDialog)
        self.buttonBox.accepted.connect(ExportDialog.accept)
        self.buttonBox.rejected.connect(ExportDialog.reject)

        QMetaObject.connectSlotsByName(ExportDialog)
    # setupUi

    def retranslateUi(self, ExportDialog):
        ExportDialog.setWindowTitle(QCoreApplication.translate("ExportDialog", u"Confirm Export", None))
        self.summaryLabel.setText(QCoreApplication.translate("ExportDialog", u"The following files will be generated:", None))
    # retranslateUi

