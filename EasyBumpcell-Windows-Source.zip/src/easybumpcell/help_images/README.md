# Warning help images

Place the two warning tutorial images in this directory before packaging:

```text
process_dbu_help.png
layer_mapping_help.png
```

The PyInstaller commands in the repository use `--collect-data easybumpcell`,
so these files are included automatically. A packaged application can also
override them with a `help_images` directory beside the executable.

Tooltip image sizes use Qt device-independent pixels and the active screen's
per-screen DPI scale. Images are never stretched or cropped.
