from __future__ import annotations

import math

from easybumpcell.dimensions import dimension_decimal

Point = tuple[float, float]


def round_polygon(diameter_um) -> list[Point]:
    """Return 64 counterclockwise points starting at the rightmost midpoint."""
    diameter = dimension_decimal(diameter_um, "Diameter")
    radius = float(diameter) / 2.0
    return [
        (
            radius * math.cos(2.0 * math.pi * index / 64.0),
            radius * math.sin(2.0 * math.pi * index / 64.0),
        )
        for index in range(64)
    ]
