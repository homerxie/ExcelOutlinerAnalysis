from __future__ import annotations

import math

from easybumpcell.dimensions import dimension_decimal

Point = tuple[float, float]


def oval_polygon(minor_axis_um, major_axis_um) -> list[Point]:
    """Return 66 counterclockwise points starting at the +X major-axis end."""
    minor_axis = dimension_decimal(minor_axis_um, "Minor Axis")
    major_axis = dimension_decimal(major_axis_um, "Major Axis")
    if major_axis <= minor_axis:
        raise ValueError("Major Axis must be greater than Minor Axis")

    radius = float(minor_axis) / 2.0
    offset = float(major_axis - minor_axis) / 2.0
    right = []
    left = []
    for index in range(33):
        angle = -math.pi / 2.0 + math.pi * index / 32.0
        right.append((offset + radius * math.cos(angle), radius * math.sin(angle)))
    for index in range(33):
        angle = math.pi / 2.0 + math.pi * index / 32.0
        left.append((-offset + radius * math.cos(angle), radius * math.sin(angle)))
    points = right + left

    # The original two-arc construction starts at the lower-right tangent.
    # Rotate the cyclic sequence to the +X major-axis endpoint while preserving
    # the counterclockwise winding and all 66 vertices.
    major_axis_positive_end = 16
    return (
        points[major_axis_positive_end:]
        + points[:major_axis_positive_end]
    )
