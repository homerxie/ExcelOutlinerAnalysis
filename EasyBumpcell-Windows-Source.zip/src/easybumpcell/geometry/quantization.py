from __future__ import annotations

import math
from dataclasses import dataclass
from decimal import Decimal

Point = tuple[float, float]
IntPoint = tuple[int, int]


@dataclass(frozen=True)
class BoundingBox:
    min_x: int
    min_y: int
    max_x: int
    max_y: int

    @property
    def width(self) -> int:
        return self.max_x - self.min_x

    @property
    def height(self) -> int:
        return self.max_y - self.min_y


def bounding_box(points: list[IntPoint] | tuple[IntPoint, ...]) -> BoundingBox:
    xs = [point[0] for point in points]
    ys = [point[1] for point in points]
    return BoundingBox(min(xs), min(ys), max(xs), max(ys))


def _inside_convex(point: IntPoint, polygon: list[Point], tolerance: float = 1e-8) -> bool:
    x, y = point
    sign = 0
    for index, start in enumerate(polygon):
        end = polygon[(index + 1) % len(polygon)]
        cross = (end[0] - start[0]) * (y - start[1]) - (end[1] - start[1]) * (x - start[0])
        if abs(cross) <= tolerance:
            continue
        current = 1 if cross > 0 else -1
        if sign == 0:
            sign = current
        elif current != sign:
            return False
    return True


def _nearest_inside_integer(point: Point, polygon: list[Point]) -> IntPoint:
    x, y = point
    floor_x = math.floor(x)
    ceil_x = math.ceil(x)
    floor_y = math.floor(y)
    ceil_y = math.ceil(y)
    candidates: list[tuple[float, int, int]] = []
    for qx in range(floor_x - 1, ceil_x + 2):
        for qy in range(floor_y - 1, ceil_y + 2):
            if _inside_convex((qx, qy), polygon):
                distance = (qx - x) ** 2 + (qy - y) ** 2
                candidates.append((distance, qx, qy))
    if not candidates:
        # Moving toward the center is guaranteed to enter a convex polygon.
        scale = 0.999
        for _ in range(1000):
            qx = round(x * scale)
            qy = round(y * scale)
            if _inside_convex((qx, qy), polygon):
                return qx, qy
            scale *= 0.999
        raise ValueError("Unable to quantize polygon vertex inside the nominal polygon")
    _, qx, qy = min(candidates, key=lambda value: (value[0], -(value[1] ** 2 + value[2] ** 2), value[1], value[2]))
    return qx, qy


def quantize_centrally_symmetric_polygon(points_um: list[Point], dbu_um: Decimal) -> list[IntPoint]:
    if len(points_um) % 2:
        raise ValueError("A centrally symmetric polygon must have an even vertex count")
    dbu = float(dbu_um)
    if not math.isfinite(dbu) or dbu <= 0:
        raise ValueError("DBU must be positive")
    scaled = [(x / dbu, y / dbu) for x, y in points_um]
    half = len(scaled) // 2
    result: list[IntPoint | None] = [None] * len(scaled)
    for index in range(half):
        opposite = scaled[index + half]
        point = scaled[index]
        if abs(point[0] + opposite[0]) > 1e-6 or abs(point[1] + opposite[1]) > 1e-6:
            raise ValueError("Polygon is not centrally symmetric")
        quantized = _nearest_inside_integer(point, scaled)
        result[index] = quantized
        result[index + half] = (-quantized[0], -quantized[1])
    return [point for point in result if point is not None]


def translate(points: list[IntPoint], dx: int, dy: int) -> list[IntPoint]:
    return [(x + dx, y + dy) for x, y in points]


def half_grid_risk(dimension_um, dbu_um: Decimal) -> bool:
    half_steps = Decimal(str(dimension_um)) / (Decimal(2) * dbu_um)
    return half_steps != half_steps.to_integral_value()
