from __future__ import annotations

import math
from dataclasses import dataclass
from decimal import Decimal

from easybumpcell.dimensions import dimension_decimal
from easybumpcell.domain.enums import OriginMode, ShapeType
from easybumpcell.domain.models import LayerDefinition, ProjectConfig
from easybumpcell.geometry.oval import oval_polygon
from easybumpcell.geometry.quantization import (
    BoundingBox,
    IntPoint,
    bounding_box,
    half_grid_risk,
    quantize_centrally_symmetric_polygon,
    translate,
)
from easybumpcell.geometry.rotation import actual_rotation_degrees, rotate_points
from easybumpcell.geometry.round import round_polygon
from easybumpcell.services.naming import OVAL_ANGLES, gds_file_name, generated_names


@dataclass(frozen=True)
class QuantizationDeviation:
    layer_uid: str
    meaning: str
    logical_angle: int
    axis: str
    nominal_um: Decimal
    actual_um: Decimal

    @property
    def deviation_um(self) -> Decimal:
        return self.actual_um - self.nominal_um


@dataclass(frozen=True)
class QuantizationRisk:
    layer_uid: str
    meaning: str
    dimension: str
    message: str


@dataclass(frozen=True)
class QuantizedLayer:
    definition: LayerDefinition
    points_dbu: tuple[IntPoint, ...]
    bbox_dbu: BoundingBox


@dataclass(frozen=True)
class GeneratedLayout:
    logical_angle: int
    actual_angle_degrees: float
    cell_name: str
    gds_file_name: str
    layers: tuple[QuantizedLayer, ...]
    common_center_dbu: IntPoint
    risks: tuple[QuantizationRisk, ...]
    deviations: tuple[QuantizationDeviation, ...]

    @property
    def nodes_per_polygon(self) -> int:
        counts = {len(layer.points_dbu) for layer in self.layers}
        if len(counts) != 1:
            raise ValueError(
                "All layer polygons in one generated layout must use the same node count"
            )
        return next(iter(counts))


def _ideal_points(layer: LayerDefinition, shape_type: ShapeType) -> list[tuple[float, float]]:
    if shape_type is ShapeType.ROUND:
        return round_polygon(layer.diameter_um)  # type: ignore[arg-type]
    return oval_polygon(layer.minor_axis_um, layer.major_axis_um)  # type: ignore[arg-type]


def _projected_span_um(
    points_dbu: list[IntPoint],
    axis_degrees: float,
    dbu_um: Decimal,
) -> Decimal:
    angle = math.radians(axis_degrees)
    cosine = math.cos(angle)
    sine = math.sin(angle)
    projections = [x * cosine + y * sine for x, y in points_dbu]
    return Decimal(str(max(projections) - min(projections))) * dbu_um


def _risks_for_layer(layer: LayerDefinition, config: ProjectConfig) -> list[QuantizationRisk]:
    dimensions: list[tuple[str, Decimal]]
    if config.shape_type is ShapeType.ROUND:
        dimensions = [
            (
                "Diameter",
                dimension_decimal(layer.diameter_um, f"{layer.meaning} Diameter"),
            )
        ]
    else:
        dimensions = [
            (
                "Minor Axis",
                dimension_decimal(
                    layer.minor_axis_um,
                    f"{layer.meaning} Minor Axis",
                ),
            ),
            (
                "Major Axis",
                dimension_decimal(
                    layer.major_axis_um,
                    f"{layer.meaning} Major Axis",
                ),
            ),
        ]
    risks = []
    for label, value in dimensions:
        if half_grid_risk(value, config.dbu_um):
            risks.append(
                QuantizationRisk(
                    layer.uid,
                    layer.meaning,
                    label,
                    (
                        f"{layer.meaning} {label} endpoints fall on half-grid positions "
                        f"for Process DBU {config.dbu_um} µm. DBU will not be changed."
                    ),
                )
            )
    return risks


def build_layouts(config: ProjectConfig) -> list[GeneratedLayout]:
    names = generated_names(config)
    logical_angles = (0,) if config.shape_type is ShapeType.ROUND else OVAL_ANGLES
    reference = config.reference_layer()
    if reference is None:
        raise ValueError("Origin reference layer does not exist")

    common_risks = tuple(risk for layer in config.layers for risk in _risks_for_layer(layer, config))
    layouts: list[GeneratedLayout] = []
    for logical_angle, name in zip(logical_angles, names):
        actual_angle = actual_rotation_degrees(
            logical_angle,
            config.zero_degree_axis,
            config.rotation_direction,
        )
        centered_layers: list[tuple[LayerDefinition, list[IntPoint]]] = []
        for layer in config.layers:
            rotated = rotate_points(_ideal_points(layer, config.shape_type), actual_angle)
            quantized = quantize_centrally_symmetric_polygon(rotated, config.dbu_um)
            centered_layers.append((layer, quantized))

        if config.origin_mode is OriginMode.REFERENCE_LOWER_LEFT:
            reference_points = next(points for layer, points in centered_layers if layer.uid == reference.uid)
            reference_bbox = bounding_box(reference_points)
            dx, dy = -reference_bbox.min_x, -reference_bbox.min_y
        else:
            dx, dy = 0, 0

        output_layers: list[QuantizedLayer] = []
        deviations: list[QuantizationDeviation] = []
        for layer, points in centered_layers:
            shifted = translate(points, dx, dy)
            bbox = bounding_box(shifted)
            output_layers.append(
                QuantizedLayer(layer, tuple(shifted), bbox)
            )
            if config.shape_type is ShapeType.ROUND:
                dimension_specs = (
                    ("Width (X)", layer.diameter_um, 0.0),
                    ("Height (Y)", layer.diameter_um, 90.0),
                )
            else:
                dimension_specs = (
                    ("Minor Axis", layer.minor_axis_um, actual_angle + 90.0),
                    ("Major Axis", layer.major_axis_um, actual_angle),
                )
            for axis, nominal, axis_degrees in dimension_specs:
                actual = _projected_span_um(points, axis_degrees, config.dbu_um)
                deviations.append(
                    QuantizationDeviation(
                        layer.uid,
                        layer.meaning,
                        logical_angle,
                        axis,
                        Decimal(str(nominal)),
                        actual,
                    )
                )

        layouts.append(
            GeneratedLayout(
                logical_angle,
                actual_angle,
                name,
                gds_file_name(config, logical_angle),
                tuple(output_layers),
                (dx, dy),
                common_risks,
                tuple(deviations),
            )
        )
    return layouts
