from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass
from pathlib import Path

from easybumpcell.domain.enums import IssueLevel
from easybumpcell.domain.models import ProjectConfig, ValidationIssue
from easybumpcell.geometry import GeneratedLayout, build_layouts
from easybumpcell.services.gds_export import write_gds
from easybumpcell.services.gds_verify import verify_gds
from easybumpcell.services.lef_export import write_lef
from easybumpcell.services.lef_verify import verify_lef
from easybumpcell.services.naming import lef_file_name, report_name
from easybumpcell.services.pdf_report import create_pdf_report
from easybumpcell.services.posix_cksum import PosixChecksum, posix_cksum
from easybumpcell.services.validation import has_errors, validate_project


@dataclass(frozen=True)
class ExportResult:
    gds_paths: tuple[Path, ...]
    lef_paths: tuple[Path, ...]
    report_path: Path
    checksums: tuple[PosixChecksum, ...]
    issues: tuple[ValidationIssue, ...]


def intended_paths(config: ProjectConfig, output_directory: str | Path) -> list[Path]:
    directory = Path(output_directory)
    layouts = build_layouts(config)
    paths: list[Path] = []
    for layout in layouts:
        paths.extend(
            (
                directory / layout.gds_file_name,
                directory / lef_file_name(config, layout.logical_angle),
            )
        )
    return [*paths, directory / report_name(config)]


def _commit_files(staged: list[Path], targets: list[Path]) -> None:
    backup_directory = staged[0].parent / "_backup"
    backup_directory.mkdir(exist_ok=True)
    backed_up: list[tuple[Path, Path]] = []
    committed: list[Path] = []
    try:
        for target in targets:
            if target.exists():
                backup = backup_directory / target.name
                os.replace(target, backup)
                backed_up.append((backup, target))
        for source, target in zip(staged, targets):
            os.replace(source, target)
            committed.append(target)
    except Exception:
        for target in committed:
            if target.exists():
                target.unlink()
        for backup, target in backed_up:
            if backup.exists():
                os.replace(backup, target)
        raise


def export_project(
    config: ProjectConfig,
    output_directory: str | Path,
    *,
    overwrite: bool = False,
) -> ExportResult:
    issues = validate_project(config, for_export=True)
    if has_errors(issues):
        messages = "; ".join(issue.message for issue in issues if issue.level is IssueLevel.ERROR)
        raise ValueError(messages)

    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    layouts: list[GeneratedLayout] = build_layouts(config)
    gds_targets = [output / layout.gds_file_name for layout in layouts]
    lef_targets = [
        output / lef_file_name(config, layout.logical_angle)
        for layout in layouts
    ]
    report_target = output / report_name(config)
    targets: list[Path] = []
    for gds_target, lef_target in zip(gds_targets, lef_targets):
        targets.extend((gds_target, lef_target))
    targets.append(report_target)
    existing = [path for path in targets if path.exists()]
    if existing and not overwrite:
        raise FileExistsError("Output files already exist: " + ", ".join(path.name for path in existing))

    with tempfile.TemporaryDirectory(prefix=".easybumpcell-", dir=output) as temporary:
        staging = Path(temporary)
        staged_outputs: list[Path] = []
        checksums: list[PosixChecksum] = []
        for layout in layouts:
            gds_path = write_gds(staging / layout.gds_file_name, config, layout)
            verify_gds(gds_path, config, layout)
            lef_path = write_lef(
                staging / lef_file_name(config, layout.logical_angle),
                config,
                layout,
            )
            verify_lef(lef_path, config, layout)
            checksums.extend(
                (
                    posix_cksum(gds_path),
                    posix_cksum(lef_path),
                )
            )
            staged_outputs.extend((gds_path, lef_path))

        report_path = create_pdf_report(
            staging / report_name(config),
            config,
            layouts,
            checksums,
            issues,
        )
        _commit_files([*staged_outputs, report_path], targets)

    return ExportResult(
        tuple(gds_targets),
        tuple(lef_targets),
        report_target,
        tuple(checksums),
        tuple(issues),
    )
