from __future__ import annotations

import math
from decimal import Decimal
from html import escape
from pathlib import Path

from reportlab.graphics.shapes import Circle, Drawing, Line, Polygon, Rect, String
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.platypus import (
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from easybumpcell.coordinate_format import (
    format_coordinate_um,
    format_dimension_um,
)
from easybumpcell.domain.enums import IssueLevel, ShapeType
from easybumpcell.domain.models import LayerDefinition, ProjectConfig, ValidationIssue
from easybumpcell.geometry.layout import GeneratedLayout
from easybumpcell.preview_patterns import (
    BACKWARD_DIAGONAL,
    DENSE_DOTS,
    DIAGONAL_CROSS,
    DOTS,
    FORWARD_DIAGONAL,
    GRID,
    HORIZONTAL,
    VERTICAL,
)
from easybumpcell.services.lef_export import (
    LEFPreviewElements,
    lef_preview_elements,
)
from easybumpcell.services.naming import lef_file_name
from easybumpcell.services.posix_cksum import PosixChecksum


REPORT_TITLE = "Sample GDS report"
_UNDERSCORE_BREAK = '_<font size="0"> </font>'


def _underscore_break_markup(value: str) -> str:
    return escape(value).replace("_", _UNDERSCORE_BREAK)


def _underscore_wrapped_paragraph(
    value: str,
    style,
) -> Paragraph:
    return Paragraph(_underscore_break_markup(value), style)


def _table_text_style(font_size: int) -> ParagraphStyle:
    return ParagraphStyle(
        f"UnderscoreWrappedTableText{font_size}",
        fontName="Helvetica",
        fontSize=font_size,
        leading=font_size + 2,
        splitLongWords=True,
        spaceBefore=0,
        spaceAfter=0,
    )


def _split_text_to_width(
    value: str,
    max_width: float,
    font_name: str,
    font_size: float,
) -> list[str]:
    if not value:
        return [""]
    lines: list[str] = []
    remaining = value
    while remaining:
        fit = 0
        for index in range(1, len(remaining) + 1):
            if stringWidth(remaining[:index], font_name, font_size) > max_width:
                break
            fit = index
        if fit == 0:
            fit = 1
        lines.append(remaining[:fit])
        remaining = remaining[fit:]
    return lines


def _wrap_text_at_underscores(
    value: str,
    max_width: float,
    font_name: str,
    font_size: float,
) -> list[str]:
    parts = value.split("_")
    segments = [
        part + ("_" if index < len(parts) - 1 else "")
        for index, part in enumerate(parts)
    ]
    lines: list[str] = []
    current = ""
    for segment in segments:
        candidate = current + segment
        if stringWidth(candidate, font_name, font_size) <= max_width:
            current = candidate
            continue
        if current:
            lines.append(current)
        if stringWidth(segment, font_name, font_size) <= max_width:
            current = segment
            continue
        segment_lines = _split_text_to_width(
            segment,
            max_width,
            font_name,
            font_size,
        )
        lines.extend(segment_lines[:-1])
        current = segment_lines[-1]
    if current or not lines:
        lines.append(current)
    return lines


def _nice_tick_spacing(desired_um: float) -> float:
    if not math.isfinite(desired_um) or desired_um <= 0:
        return 1.0
    exponent = math.floor(math.log10(desired_um))
    magnitude = 10.0 ** exponent
    fraction = desired_um / magnitude
    if fraction <= 1:
        nice_fraction = 1.0
    elif fraction <= 2:
        nice_fraction = 2.0
    elif fraction <= 5:
        nice_fraction = 5.0
    else:
        nice_fraction = 10.0
    return nice_fraction * magnitude


def _tick_values(minimum: float, maximum: float, spacing: float) -> list[float]:
    first = math.ceil((minimum - spacing * 1e-9) / spacing) * spacing
    values = []
    value = first
    while value <= maximum + spacing * 1e-9 and len(values) < 100:
        values.append(0.0 if abs(value) < spacing * 1e-9 else value)
        value += spacing
    return values


def _format_axis_tick(value: float, spacing: float) -> str:
    if abs(value) < spacing * 1e-9:
        return "0"
    decimals = max(0, min(6, -math.floor(math.log10(spacing))))
    text = f"{value:.{decimals}f}"
    return text.rstrip("0").rstrip(".") if decimals else text


def _section(
    title: str,
    content,
    styles,
    *,
    keep_together: bool = False,
) -> list:
    section = [
        Paragraph(title, styles["Section"]),
        (
            content
            if not isinstance(content, str)
            else _underscore_wrapped_paragraph(
                content or "N/A",
                styles["BodyText"],
            )
        ),
        Spacer(1, 3 * mm),
    ]
    return (
        [KeepTogether(section)]
        if isinstance(content, str) or keep_together
        else section
    )


def _styled_table(data: list[list[object]], widths=None, font_size: int = 8) -> Table:
    paragraph_style = _table_text_style(font_size)
    wrapped_data = [
        [
            (
                _underscore_wrapped_paragraph(cell, paragraph_style)
                if row_index > 0
                and isinstance(cell, str)
                and "_" in cell
                else cell
            )
            for cell in row
        ]
        for row_index, row in enumerate(data)
    ]
    table = Table(wrapped_data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#243447")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                ("FONTSIZE", (0, 0), (-1, -1), font_size),
                ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#AAB4BE")),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F2F5F7")]),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]
        )
    )
    return table


def _clipped_parallel_segments(
    polygon: list[tuple[float, float]],
    direction: tuple[float, float],
    spacing: float,
    phase: float = 0,
) -> list[tuple[tuple[float, float], tuple[float, float]]]:
    direction_length = math.hypot(*direction)
    unit_direction = (
        direction[0] / direction_length,
        direction[1] / direction_length,
    )
    normal = (-unit_direction[1], unit_direction[0])
    normal_positions = [
        point[0] * normal[0] + point[1] * normal[1]
        for point in polygon
    ]
    first_offset = (
        math.floor((min(normal_positions) - phase) / spacing) * spacing
        + phase
    )
    last_offset = (
        math.ceil((max(normal_positions) - phase) / spacing) * spacing
        + phase
    )
    segments = []
    offset = first_offset
    while offset <= last_offset + 1e-8:
        intersections: list[tuple[float, float]] = []
        for index, start in enumerate(polygon):
            end = polygon[(index + 1) % len(polygon)]
            start_distance = start[0] * normal[0] + start[1] * normal[1] - offset
            end_distance = end[0] * normal[0] + end[1] * normal[1] - offset
            if abs(start_distance) <= 1e-8:
                intersections.append(start)
            denominator = start_distance - end_distance
            if abs(denominator) > 1e-8:
                edge_fraction = start_distance / denominator
                if 1e-8 < edge_fraction < 1 - 1e-8:
                    intersections.append(
                        (
                            start[0] + edge_fraction * (end[0] - start[0]),
                            start[1] + edge_fraction * (end[1] - start[1]),
                        )
                    )
        unique: list[tuple[float, float]] = []
        for point in intersections:
            if not any(
                abs(point[0] - existing[0]) <= 1e-6
                and abs(point[1] - existing[1]) <= 1e-6
                for existing in unique
            ):
                unique.append(point)
        if len(unique) >= 2:
            ordered = sorted(
                unique,
                key=lambda point: (
                    point[0] * unit_direction[0]
                    + point[1] * unit_direction[1]
                ),
            )
            segments.append((ordered[0], ordered[-1]))
        offset += spacing
    return segments


def _point_inside_convex_polygon(
    point: tuple[float, float],
    polygon: list[tuple[float, float]],
) -> bool:
    sign = 0
    for index, start in enumerate(polygon):
        end = polygon[(index + 1) % len(polygon)]
        cross = (
            (end[0] - start[0]) * (point[1] - start[1])
            - (end[1] - start[1]) * (point[0] - start[0])
        )
        if abs(cross) <= 1e-8:
            continue
        current = 1 if cross > 0 else -1
        if sign == 0:
            sign = current
        elif current != sign:
            return False
    return True


def _add_vector_pattern(
    drawing: Drawing,
    polygon: list[tuple[float, float]],
    pattern: str,
    color,
    *,
    spacing: float = 6.0,
    stroke_width: float = 0.55,
) -> None:
    pattern_color = colors.Color(
        color.red,
        color.green,
        color.blue,
        alpha=0.82,
    )
    directions = {
        FORWARD_DIAGONAL: ((1.0, 1.0),),
        BACKWARD_DIAGONAL: ((1.0, -1.0),),
        DIAGONAL_CROSS: ((1.0, 1.0), (1.0, -1.0)),
        HORIZONTAL: ((1.0, 0.0),),
        VERTICAL: ((0.0, 1.0),),
        GRID: ((1.0, 0.0), (0.0, 1.0)),
    }
    if pattern in directions:
        effective_spacing = spacing * (
            1.35 if pattern in (DIAGONAL_CROSS, GRID) else 1.0
        )
        phase = (
            effective_spacing * 0.27
            if pattern in (DIAGONAL_CROSS, GRID)
            else 0
        )
        for direction in directions[pattern]:
            for start, end in _clipped_parallel_segments(
                polygon,
                direction,
                effective_spacing,
                phase,
            ):
                drawing.add(
                    Line(
                        start[0],
                        start[1],
                        end[0],
                        end[1],
                        strokeColor=pattern_color,
                        strokeWidth=stroke_width,
                    )
                )
        return

    if pattern not in (DOTS, DENSE_DOTS):
        raise ValueError(f"Unsupported preview pattern: {pattern}")
    dot_spacing = spacing * (1.18 if pattern == DOTS else 0.72)
    dot_radius = 0.75 if pattern == DOTS else 0.6
    min_x = min(point[0] for point in polygon)
    max_x = max(point[0] for point in polygon)
    min_y = min(point[1] for point in polygon)
    max_y = max(point[1] for point in polygon)
    x = math.floor(min_x / dot_spacing) * dot_spacing
    column = 0
    while x <= max_x + 1e-8:
        y_offset = dot_spacing / 2 if column % 2 else 0
        y = math.floor((min_y - y_offset) / dot_spacing) * dot_spacing + y_offset
        while y <= max_y + 1e-8:
            if _point_inside_convex_polygon((x, y), polygon):
                drawing.add(
                    Circle(
                        x,
                        y,
                        dot_radius,
                        fillColor=pattern_color,
                        strokeColor=None,
                    )
                )
            y += dot_spacing
        x += dot_spacing
        column += 1


def _preview_style_swatch(layer: LayerDefinition) -> Drawing:
    width = 27 * mm
    height = 6 * mm
    inset = 0.6
    drawing = Drawing(width, height)
    color = colors.HexColor(layer.color)
    polygon = [
        (inset, inset),
        (width - inset, inset),
        (width - inset, height - inset),
        (inset, height - inset),
    ]
    drawing.add(
        Rect(
            inset,
            inset,
            width - 2 * inset,
            height - 2 * inset,
            fillColor=colors.Color(color.red, color.green, color.blue, alpha=0.08),
            strokeColor=None,
        )
    )
    _add_vector_pattern(
        drawing,
        polygon,
        layer.preview_pattern,
        color,
        spacing=3.5,
        stroke_width=0.5,
    )
    drawing.add(
        Rect(
            inset,
            inset,
            width - 2 * inset,
            height - 2 * inset,
            fillColor=None,
            strokeColor=color,
            strokeWidth=0.7,
        )
    )
    return drawing


def _layer_mapping_table(config: ProjectConfig) -> Table:
    rows = [[
        "Order",
        "Layer Name",
        "Layer Number",
        "Datatype",
        "Preview",
    ]]
    rows.extend(
        [
            [
                str(index),
                layer.meaning,
                str(layer.layer),
                str(layer.datatype),
                _preview_style_swatch(layer),
            ]
            for index, layer in enumerate(config.layers, start=1)
        ]
    )
    return _styled_table(
        rows,
        [16 * mm, 43 * mm, 25 * mm, 28 * mm, 31 * mm],
    )


def _all_bounds(layouts: list[GeneratedLayout]) -> tuple[int, int, int, int]:
    boxes = [layer.bbox_dbu for layout in layouts for layer in layout.layers]
    min_x = min(min(box.min_x for box in boxes), 0)
    min_y = min(min(box.min_y for box in boxes), 0)
    max_x = max(max(box.max_x for box in boxes), 0)
    max_y = max(max(box.max_y for box in boxes), 0)
    if max_x == min_x:
        max_x += 1
    if max_y == min_y:
        max_y += 1
    return min_x, min_y, max_x, max_y


def _lef_all_bounds(
    elements: list[LEFPreviewElements],
) -> tuple[int, int, int, int]:
    boxes = [
        box
        for item in elements
        for box in (item.pin_geometry.bbox_dbu, item.boundary_dbu)
    ]
    min_x = min(min(box.min_x for box in boxes), 0)
    min_y = min(min(box.min_y for box in boxes), 0)
    max_x = max(max(box.max_x for box in boxes), 0)
    max_y = max(max(box.max_y for box in boxes), 0)
    width = max_x - min_x
    height = max_y - min_y
    pad_x = max(1, math.ceil(width * 0.14))
    pad_y = max(1, math.ceil(height * 0.14))
    return (
        min_x - pad_x,
        min_y - pad_y,
        max_x + pad_x,
        max_y + pad_y,
    )


def _preview_drawing(
    layouts: list[GeneratedLayout],
    config: ProjectConfig,
    *,
    lef_mode: bool = False,
) -> Drawing:
    if len(layouts) == 1:
        columns, rows = 1, 1
        width, height = 245 * mm, 135 * mm
    else:
        columns, rows = 2, 2
        width, height = 245 * mm, 155 * mm
    drawing = Drawing(width, height)
    gap = 5 * mm
    panel_w = (width - gap * (columns - 1)) / columns
    panel_h = (height - gap * (rows - 1)) / rows
    cell_name_font = "Helvetica"
    cell_name_font_size = 5.5
    cell_name_max_width = panel_w - 8 * mm
    wrapped_cell_names = [
        _wrap_text_at_underscores(
            layout.cell_name,
            cell_name_max_width,
            cell_name_font,
            cell_name_font_size,
        )
        for layout in layouts
    ]
    maximum_cell_name_lines = max(map(len, wrapped_cell_names))
    cell_name_line_step = 2.4 * mm
    lef_elements = (
        [lef_preview_elements(config, layout) for layout in layouts]
        if lef_mode
        else []
    )
    min_x, min_y, max_x, max_y = (
        _lef_all_bounds(lef_elements)
        if lef_mode
        else _all_bounds(layouts)
    )
    world_w = max_x - min_x
    world_h = max_y - min_y

    for index, layout in enumerate(layouts):
        elements = lef_elements[index] if lef_mode else None
        column = index % columns
        row = rows - 1 - index // columns
        left = column * (panel_w + gap)
        bottom = row * (panel_h + gap)
        title_h = (
            (17 if lef_mode else 14) * mm
            + (maximum_cell_name_lines - 1) * cell_name_line_step
        )
        left_margin = 15 * mm
        right_margin = 6 * mm
        bottom_margin = 9 * mm
        plot_w = panel_w - left_margin - right_margin
        plot_h = panel_h - title_h - bottom_margin
        scale = min(plot_w / world_w, plot_h / world_h)
        plot_left = left + left_margin
        plot_bottom = bottom + bottom_margin
        plot_right = plot_left + plot_w
        plot_top = plot_bottom + plot_h
        offset_x = plot_left + (plot_w - world_w * scale) / 2 - min_x * scale
        offset_y = plot_bottom + (plot_h - world_h * scale) / 2 - min_y * scale

        drawing.add(
            Polygon(
                [left, bottom, left + panel_w, bottom, left + panel_w, bottom + panel_h, left, bottom + panel_h],
                fillColor=colors.HexColor("#FAFBFC"),
                strokeColor=colors.HexColor("#CAD2D9"),
                strokeWidth=0.6,
            )
        )
        shape_title = (
            "Round"
            if config.shape_type is ShapeType.ROUND
            else f"{layout.logical_angle} Degree"
        )
        title = f"LEF - {shape_title}" if lef_mode else shape_title
        drawing.add(
            String(
                left + panel_w / 2,
                bottom + panel_h - 3.7 * mm,
                title,
                textAnchor="middle",
                fontName="Helvetica-Bold",
                fontSize=10,
                fillColor=colors.HexColor("#1F2D3D"),
            )
        )
        for line_index, line in enumerate(wrapped_cell_names[index]):
            drawing.add(
                String(
                    left + panel_w / 2,
                    bottom + panel_h - 7.5 * mm - line_index * cell_name_line_step,
                    line,
                    textAnchor="middle",
                    fontName=cell_name_font,
                    fontSize=cell_name_font_size,
                    fillColor=colors.HexColor("#536270"),
                )
            )
        if elements is None:
            summary_x_dbu, summary_y_dbu = layout.common_center_dbu
            summary_x_um = Decimal(summary_x_dbu) * config.dbu_um
            summary_y_um = Decimal(summary_y_dbu) * config.dbu_um
            drawing.add(
                String(
                    left + panel_w / 2,
                    bottom
                    + panel_h
                    - 11 * mm
                    - (maximum_cell_name_lines - 1) * cell_name_line_step,
                    (
                        "Center: "
                        f"X {format_coordinate_um(summary_x_um, config.dbu_um)} µm, "
                        f"Y {format_coordinate_um(summary_y_um, config.dbu_um)} µm"
                    ),
                    textAnchor="middle",
                    fontName="Helvetica",
                    fontSize=5.5,
                    fillColor=colors.HexColor("#536270"),
                )
            )
        if elements is not None:
            legend_y = (
                bottom
                + panel_h
                - 12.3 * mm
                - (maximum_cell_name_lines - 1) * cell_name_line_step
            )
            legend_items = (
                (elements.pin_layer_name, "pin"),
                (elements.label_layer_name, "label"),
                (elements.boundary_layer_name, "boundary"),
            )
            legend_widths = [
                stringWidth(name, "Helvetica-Bold", 5.2) + 10 * mm
                for name, _ in legend_items
            ]
            legend_x = left + (panel_w - sum(legend_widths)) / 2
            for (name, kind), item_width in zip(
                legend_items,
                legend_widths,
            ):
                icon_x = legend_x + 1.2 * mm
                icon_y = legend_y + 0.5 * mm
                if kind == "pin":
                    drawing.add(
                        Line(
                            icon_x,
                            icon_y,
                            icon_x + 4 * mm,
                            icon_y,
                            strokeColor=colors.HexColor(
                                elements.definition.color
                            ),
                            strokeWidth=1.1,
                        )
                    )
                elif kind == "label":
                    drawing.add(
                        Circle(
                            icon_x + 2 * mm,
                            icon_y,
                            1.1 * mm,
                            fillColor=colors.white,
                            strokeColor=colors.HexColor("#7B1FA2"),
                            strokeWidth=0.8,
                        )
                    )
                else:
                    drawing.add(
                        Line(
                            icon_x,
                            icon_y,
                            icon_x + 4 * mm,
                            icon_y,
                            strokeColor=colors.HexColor("#455A64"),
                            strokeWidth=0.8,
                            strokeDashArray=[2, 1.5],
                        )
                    )
                drawing.add(
                    String(
                        icon_x + 5.2 * mm,
                        legend_y - 0.6 * mm,
                        name,
                        fontName="Helvetica-Bold",
                        fontSize=5.2,
                        fillColor=colors.HexColor("#34434F"),
                    )
                )
                legend_x += item_width

        layers_to_draw = (
            [elements.pin_geometry]
            if elements is not None
            else list(layout.layers)
        )
        for layer in sorted(
            layers_to_draw,
            key=lambda item: item.bbox_dbu.width * item.bbox_dbu.height,
            reverse=True,
        ):
            coordinates: list[float] = []
            for x, y in layer.points_dbu:
                coordinates.extend((offset_x + x * scale, offset_y + y * scale))
            color = colors.HexColor(layer.definition.color)
            polygon_points = [
                (coordinates[index], coordinates[index + 1])
                for index in range(0, len(coordinates), 2)
            ]
            drawing.add(
                Polygon(
                    coordinates,
                    fillColor=colors.Color(color.red, color.green, color.blue, alpha=0.06),
                    strokeColor=None,
                )
            )
            _add_vector_pattern(
                drawing,
                polygon_points,
                layer.definition.preview_pattern,
                color,
            )
            drawing.add(
                Polygon(
                    coordinates,
                    fillColor=None,
                    strokeColor=color,
                    strokeWidth=0.65,
                )
            )
        if elements is not None:
            boundary = elements.boundary_dbu
            drawing.add(
                Rect(
                    offset_x + boundary.min_x * scale,
                    offset_y + boundary.min_y * scale,
                    boundary.width * scale,
                    boundary.height * scale,
                    fillColor=None,
                    strokeColor=colors.HexColor("#455A64"),
                    strokeWidth=0.85,
                    strokeDashArray=[3, 2],
                )
            )

        origin_x = offset_x
        origin_y = offset_y
        axis_color = colors.HexColor("#7C8993")
        label_color = colors.HexColor("#52636F")
        drawing.add(
            Line(
                plot_left,
                origin_y,
                plot_right,
                origin_y,
                strokeColor=axis_color,
                strokeWidth=0.45,
            )
        )
        drawing.add(
            Line(
                origin_x,
                plot_bottom,
                origin_x,
                plot_top,
                strokeColor=axis_color,
                strokeWidth=0.45,
            )
        )

        dbu_um = float(config.dbu_um)
        points_per_um = scale / dbu_um
        tick_spacing_um = _nice_tick_spacing(32.0 / points_per_um)
        min_x_um = min_x * dbu_um
        max_x_um = max_x * dbu_um
        min_y_um = min_y * dbu_um
        max_y_um = max_y * dbu_um
        for value_um in _tick_values(min_x_um, max_x_um, tick_spacing_um):
            tick_x = offset_x + value_um / dbu_um * scale
            drawing.add(
                Line(
                    tick_x,
                    origin_y - 1.1 * mm,
                    tick_x,
                    origin_y + 1.1 * mm,
                    strokeColor=axis_color,
                    strokeWidth=0.45,
                )
            )
            drawing.add(
                String(
                    tick_x,
                    origin_y - 3.2 * mm,
                    _format_axis_tick(value_um, tick_spacing_um),
                    textAnchor="middle",
                    fontName="Helvetica",
                    fontSize=4.5,
                    fillColor=label_color,
                )
            )
        for value_um in _tick_values(min_y_um, max_y_um, tick_spacing_um):
            tick_y = offset_y + value_um / dbu_um * scale
            drawing.add(
                Line(
                    origin_x - 1.1 * mm,
                    tick_y,
                    origin_x + 1.1 * mm,
                    tick_y,
                    strokeColor=axis_color,
                    strokeWidth=0.45,
                )
            )
            if abs(value_um) < tick_spacing_um * 1e-9:
                continue
            drawing.add(
                String(
                    origin_x - 1.8 * mm,
                    tick_y - 1.3,
                    _format_axis_tick(value_um, tick_spacing_um),
                    textAnchor="end",
                    fontName="Helvetica",
                    fontSize=4.5,
                    fillColor=label_color,
                )
            )
        drawing.add(
            String(
                plot_right,
                origin_y + 1.8 * mm,
                "X (µm)",
                textAnchor="end",
                fontName="Helvetica-Bold",
                fontSize=4.8,
                fillColor=label_color,
            )
        )
        drawing.add(
            String(
                origin_x + 1.8 * mm,
                plot_top - 2.4 * mm,
                "Y (µm)",
                fontName="Helvetica-Bold",
                fontSize=4.8,
                fillColor=label_color,
            )
        )
        drawing.add(Line(origin_x - 2.5, origin_y, origin_x + 2.5, origin_y, strokeColor=colors.black, strokeWidth=0.8))
        drawing.add(Line(origin_x, origin_y - 2.5, origin_x, origin_y + 2.5, strokeColor=colors.black, strokeWidth=0.8))
        if elements is not None:
            anchor_x = offset_x + elements.label_anchor_dbu[0] * scale
            anchor_y = offset_y + elements.label_anchor_dbu[1] * scale
            anchor_color = colors.HexColor("#7B1FA2")
            drawing.add(
                Circle(
                    anchor_x,
                    anchor_y,
                    0.8 * mm,
                    fillColor=colors.white,
                    strokeColor=anchor_color,
                    strokeWidth=0.9,
                )
            )
            drawing.add(
                Line(
                    anchor_x - 1.9 * mm,
                    anchor_y,
                    anchor_x + 1.9 * mm,
                    anchor_y,
                    strokeColor=anchor_color,
                    strokeWidth=0.7,
                )
            )
            drawing.add(
                Line(
                    anchor_x,
                    anchor_y - 1.9 * mm,
                    anchor_x,
                    anchor_y + 1.9 * mm,
                    strokeColor=anchor_color,
                    strokeWidth=0.7,
                )
            )
            label_width = stringWidth(
                elements.label_text,
                "Helvetica-Bold",
                7,
            )
            label_x = anchor_x + 2.6 * mm
            text_anchor = "start"
            if label_x + label_width > plot_right:
                label_x = anchor_x - 2.6 * mm
                text_anchor = "end"
            label_y = anchor_y + 2.1 * mm
            if label_y + 7 > plot_top:
                label_y = anchor_y - 4.1 * mm
            drawing.add(
                String(
                    label_x,
                    label_y,
                    elements.label_text,
                    textAnchor=text_anchor,
                    fontName="Helvetica-Bold",
                    fontSize=7,
                    fillColor=anchor_color,
                )
            )
    return drawing


def _dimension_table(
    config: ProjectConfig,
    layouts: list[GeneratedLayout],
) -> Table:
    if config.shape_type is ShapeType.ROUND:
        rows = [[
            "Layer Name",
            "Nominal Diameter (µm)",
            "Actual Width (µm)",
            "Actual Height (µm)",
        ]]
    else:
        rows = [[
            "Angle",
            "Layer Name",
            "Nominal Minor Axis (µm)",
            "Actual Minor Axis (µm)",
            "Nominal Major Axis (µm)",
            "Actual Major Axis (µm)",
        ]]
    for layout in layouts:
        actual_by_layer_and_dimension = {
            (deviation.layer_uid, deviation.axis): deviation.actual_um
            for deviation in layout.deviations
        }
        for layer in layout.layers:
            if config.shape_type is ShapeType.ROUND:
                rows.append([
                    layer.definition.meaning,
                    format_dimension_um(
                        layer.definition.diameter_um,
                        config.dbu_um,
                    ),
                    format_dimension_um(
                        actual_by_layer_and_dimension[
                            (layer.definition.uid, "Width (X)")
                        ],
                        config.dbu_um,
                    ),
                    format_dimension_um(
                        actual_by_layer_and_dimension[
                            (layer.definition.uid, "Height (Y)")
                        ],
                        config.dbu_um,
                    ),
                ])
            else:
                rows.append([
                    f"{layout.logical_angle}D",
                    layer.definition.meaning,
                    format_dimension_um(
                        layer.definition.minor_axis_um,
                        config.dbu_um,
                    ),
                    format_dimension_um(
                        actual_by_layer_and_dimension[
                            (layer.definition.uid, "Minor Axis")
                        ],
                        config.dbu_um,
                    ),
                    format_dimension_um(
                        layer.definition.major_axis_um,
                        config.dbu_um,
                    ),
                    format_dimension_um(
                        actual_by_layer_and_dimension[
                            (layer.definition.uid, "Major Axis")
                        ],
                        config.dbu_um,
                    ),
                ])
    return _styled_table(rows, font_size=7)


def _generated_names_table(
    config: ProjectConfig,
    layouts: list[GeneratedLayout],
) -> Table:
    rows = [[
        "GDS File Name",
        "GDS Cell Name",
        "LEF File Name",
        "LEF Macro Name",
        "Polygon",
    ]]
    rows.extend(
        [
            [
                layout.gds_file_name,
                layout.cell_name,
                lef_file_name(config, layout.logical_angle),
                layout.cell_name,
                f"{layout.nodes_per_polygon}-gon",
            ]
            for layout in layouts
        ]
    )
    return _styled_table(
        rows,
        [68 * mm, 52 * mm, 68 * mm, 52 * mm, 20 * mm],
        font_size=6,
    )


def _report_warning_messages(issues: list[ValidationIssue]) -> list[str]:
    return [
        issue.message
        for issue in issues
        if issue.level is IssueLevel.WARNING and issue.code != "long_cell_name"
    ]


def create_pdf_report(
    path: str | Path,
    config: ProjectConfig,
    layouts: list[GeneratedLayout],
    checksums: list[PosixChecksum],
    issues: list[ValidationIssue],
) -> Path:
    destination = Path(path)
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            "ReportTitle",
            parent=styles["Title"],
            fontName="Helvetica-Bold",
            fontSize=20,
            leading=24,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#142638"),
            spaceAfter=8 * mm,
        )
    )
    styles.add(
        ParagraphStyle(
            "Section",
            parent=styles["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=11,
            leading=14,
            textColor=colors.HexColor("#174A7E"),
            spaceAfter=2 * mm,
            keepWithNext=True,
        )
    )
    document = SimpleDocTemplate(
        str(destination),
        pagesize=landscape(A4),
        leftMargin=16 * mm,
        rightMargin=16 * mm,
        topMargin=14 * mm,
        bottomMargin=14 * mm,
        title=REPORT_TITLE,
        author="EasyBumpcell",
    )
    story: list = [Paragraph(REPORT_TITLE, styles["ReportTitle"])]

    # Basic identity
    story += _section("Technology Name", config.technology_name, styles)
    story += _section("Bump Type", config.bump_type or "N/A", styles)
    story += _section("Version", config.version, styles)
    story += _section("Shape Type", config.shape_type.value, styles)

    # 5. Generated file and Cell/Macro names
    name_consistency = Paragraph(
        (
            "Each generated GDS Cell Name is exactly identical to the "
            "corresponding LEF Macro Name."
        ),
        styles["BodyText"],
    )
    story += _section(
        "Generated GDS and Cell Names",
        KeepTogether(
            [
                name_consistency,
                Spacer(1, 1.5 * mm),
                _generated_names_table(config, layouts),
            ]
        ),
        styles,
    )

    # 6. LEF PIN layer identity
    pin_layer = config.al_pad_layer()
    if pin_layer is None:
        raise ValueError("Select the Al Pad Layer for LEF output")
    story += _section(
        "LEF PIN Layer Name",
        (
            f'LEF Layer Name "{pin_layer.meaning}" '
            f"(GDS Layer Number {pin_layer.layer} / "
            f"Datatype {pin_layer.datatype})."
        ),
        styles,
    )

    # 7. POSIX checksums for every generated GDS and LEF file
    checksum_rows = [["POSIX CRC", "Byte Count", "File Name"]]
    checksum_rows.extend([[str(item.crc), str(item.byte_count), item.file_name] for item in checksums])
    story += _section("POSIX Checksums", _styled_table(checksum_rows, [45 * mm, 45 * mm, 160 * mm]), styles)

    # 8. GDS vector preview
    # Replace the checksum section's trailing spacer so a long Oval checksum
    # table cannot move only that spacer to a new page before the page break.
    story[-1] = PageBreak()
    story += _section(
        "Sample GDS Preview",
        KeepTogether([_preview_drawing(layouts, config)]),
        styles,
    )

    # 9. Layer mapping immediately follows the GDS preview.
    story += _section(
        "Layer Number/Datatype Mapping",
        _layer_mapping_table(config),
        styles,
        keep_together=len(config.layers) <= 10,
    )

    # 10. Nominal vs actual dimensions. Oval dimensions are measured along the
    # local minor/major axes, never from the rotated world-coordinate bounding box.
    story += _section(
        "Nominal Dimensions vs Actual Quantized Axis Dimensions",
        _dimension_table(config, layouts),
        styles,
    )

    # 11. KLayout-style LEF view: PIN geometry, generated PIN label and macro
    # boundary. The in-figure legend identifies all three objects.
    story.append(PageBreak())
    story += _section(
        "LEF Preview",
        KeepTogether([_preview_drawing(layouts, config, lef_mode=True)]),
        styles,
    )

    # Coordinate definitions
    reference = config.reference_layer()
    origin_text = (
        "Common Center"
        if config.origin_mode.value == "Common Center"
        else f"{reference.meaning if reference else 'N/A'} Quantized Bounding Box Lower-left"
    )
    story += _section("Origin Definition", origin_text, styles)
    story += _section("Process DBU", f"{config.dbu_um} µm", styles)
    if config.shape_type is ShapeType.OVAL:
        story += _section("Zero-Degree Axis", config.zero_degree_axis.value, styles)
        story += _section(
            "Positive Rotation Direction",
            config.rotation_direction.value,
            styles,
        )

    # Validation status
    warning_messages = _report_warning_messages(issues)
    risk_messages = sorted({risk.message for layout in layouts for risk in layout.risks})
    status = "WARNING" if warning_messages or risk_messages else "PASS"
    validation_content: list = [
        Paragraph(
            status,
            ParagraphStyle(
                "ValidationStatus",
                parent=styles["BodyText"],
                textColor=colors.HexColor("#B26A00" if status == "WARNING" else "#1B7F3A"),
                fontName="Helvetica-Bold",
                fontSize=12,
                leading=15,
                spaceBefore=0,
                spaceAfter=0,
                keepWithNext=False,
            ),
        )
    ]
    for message in warning_messages + risk_messages:
        validation_content.append(Paragraph(f"- {message}", styles["BodyText"]))
    validation_section = _section(
        "Validation Status",
        KeepTogether(validation_content),
        styles,
    )
    validation_section.pop()  # No trailing spacer after the final report section.
    story += validation_section

    def draw_page_number(canvas, document_template) -> None:
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(colors.HexColor("#73808C"))
        canvas.drawCentredString(landscape(A4)[0] / 2, 7 * mm, f"Page {document_template.page}")
        canvas.restoreState()

    document.build(story, onFirstPage=draw_page_number, onLaterPages=draw_page_number)
    return destination
