from __future__ import annotations

import re
from decimal import Decimal
from pathlib import Path

from easybumpcell.domain.models import ProjectConfig
from easybumpcell.geometry.layout import GeneratedLayout
from easybumpcell.services.lef_export import (
    LEF_PIN_NAME,
    LEF_VERSION,
    al_pad_geometry,
    lef_boundary_from_text,
)


_NUMBER_TOKEN = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)"
_NUMBER_RE = re.compile(_NUMBER_TOKEN)


def _require_match(pattern: str, text: str, label: str) -> re.Match[str]:
    match = re.search(pattern, text, flags=re.MULTILINE | re.DOTALL)
    if match is None:
        raise ValueError(f"LEF verification failed: missing or invalid {label}")
    return match


def verify_lef(
    path: str | Path,
    config: ProjectConfig,
    layout: GeneratedLayout,
) -> None:
    source = Path(path)
    text = source.read_text(encoding="ascii")
    definition, geometry = al_pad_geometry(config, layout)

    _require_match(
        rf"^VERSION\s+{re.escape(LEF_VERSION)}\s*;",
        text,
        "VERSION",
    )
    _require_match(
        rf"^MACRO\s+{re.escape(layout.cell_name)}\s*$",
        text,
        "MACRO name",
    )
    _require_match(
        rf"^\s*PIN\s+{re.escape(LEF_PIN_NAME)}\s*$",
        text,
        "PIN name",
    )
    _require_match(
        rf"^\s*END\s+{re.escape(LEF_PIN_NAME)}\s*$",
        text,
        "PIN end name",
    )
    _require_match(r"^\s*CLASS\s+COVER\s+BUMP\s*;", text, "macro CLASS")
    forbidden_statements = {
        "NAMESCASESENSITIVE": r"^\s*NAMESCASESENSITIVE\b",
        "UNITS": r"^\s*UNITS\b",
        "ORIGIN": r"^\s*ORIGIN\b",
        "PORT CLASS": r"^\s*CLASS\s+BUMP\s*;",
    }
    for label, pattern in forbidden_statements.items():
        if re.search(pattern, text, flags=re.MULTILINE):
            raise ValueError(
                f"LEF verification failed: unexpected {label} statement"
            )

    bbox = geometry.bbox_dbu
    minimum_x = Decimal(bbox.min_x) * config.dbu_um
    minimum_y = Decimal(bbox.min_y) * config.dbu_um
    width = Decimal(bbox.width) * config.dbu_um
    height = Decimal(bbox.height) * config.dbu_um
    foreign = _require_match(
        (
            rf"^\s*FOREIGN\s+{re.escape(layout.cell_name)}\s+"
            rf"({_NUMBER_TOKEN})\s+({_NUMBER_TOKEN})\s*;"
        ),
        text,
        "FOREIGN",
    )
    size = _require_match(
        rf"^\s*SIZE\s+({_NUMBER_TOKEN})\s+BY\s+({_NUMBER_TOKEN})\s*;",
        text,
        "SIZE",
    )
    if (Decimal(foreign.group(1)), Decimal(foreign.group(2))) != (
        minimum_x,
        minimum_y,
    ):
        raise ValueError("LEF verification failed: FOREIGN differs from GDS origin")
    if (Decimal(size.group(1)), Decimal(size.group(2))) != (width, height):
        raise ValueError("LEF verification failed: SIZE differs from Al Pad bounds")
    boundary = lef_boundary_from_text(text, config.dbu_um)
    if (boundary.width, boundary.height) != (
        bbox.width,
        bbox.height,
    ):
        raise ValueError(
            "LEF verification failed: validated SIZE/POLYGON boundary "
            "differs from Al Pad bounds"
        )

    layers = re.findall(r"^\s*LAYER\s+(\S+)\s*;", text, flags=re.MULTILINE)
    if layers != [definition.meaning]:
        raise ValueError(
            "LEF verification failed: output must contain only the selected "
            f"Al Pad Layer {definition.meaning!r}"
        )

    polygon_match = _require_match(
        r"^\s*POLYGON\s*(.*?)\s*;",
        text,
        "PIN POLYGON",
    )
    numbers = [Decimal(value) for value in _NUMBER_RE.findall(polygon_match.group(1))]
    if len(numbers) % 2:
        raise ValueError("LEF verification failed: POLYGON has an incomplete coordinate")
    actual_points = tuple(zip(numbers[0::2], numbers[1::2]))
    expected_points = tuple(
        (
            Decimal(x) * config.dbu_um,
            Decimal(y) * config.dbu_um,
        )
        for x, y in geometry.points_dbu
    )
    if actual_points != expected_points:
        raise ValueError(
            "LEF verification failed: PIN POLYGON coordinates differ from GDS"
        )
