from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

POLYNOMIAL = 0x04C11DB7


def _crc_table() -> tuple[int, ...]:
    table: list[int] = []
    for byte in range(256):
        value = byte << 24
        for _ in range(8):
            value = ((value << 1) ^ POLYNOMIAL) & 0xFFFFFFFF if value & 0x80000000 else (value << 1) & 0xFFFFFFFF
        table.append(value)
    return tuple(table)


CRC_TABLE = _crc_table()


@dataclass(frozen=True)
class PosixChecksum:
    crc: int
    byte_count: int
    file_name: str

    def legacy_output(self) -> str:
        return f"{self.crc} {self.byte_count} {self.file_name}"


def _update(crc: int, byte: int) -> int:
    return ((crc << 8) & 0xFFFFFFFF) ^ CRC_TABLE[((crc >> 24) ^ byte) & 0xFF]


def posix_cksum(path: str | Path, *, chunk_size: int = 1024 * 1024) -> PosixChecksum:
    source = Path(path)
    crc = 0
    length = 0
    with source.open("rb") as stream:
        while chunk := stream.read(chunk_size):
            length += len(chunk)
            for byte in chunk:
                crc = _update(crc, byte)

    remaining = length
    while remaining:
        crc = _update(crc, remaining & 0xFF)
        remaining >>= 8
    crc = (~crc) & 0xFFFFFFFF
    return PosixChecksum(crc, length, source.name)

