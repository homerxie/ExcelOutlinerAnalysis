from __future__ import annotations

import math
from decimal import Decimal
from pathlib import Path

import gdstk

from easybumpcell.domain.enums import ShapeType
from easybumpcell.domain.models import ProjectConfig
from easybumpcell.geometry.layout import GeneratedLayout
from easybumpcell.services.gds_export import GDS_LIBRARY_NAME


class GdsVerificationError(RuntimeError):
    pass


def _fail(message: str) -> None:
    raise GdsVerificationError(message)


def verify_gds(path: str | Path, config: ProjectConfig, expected: GeneratedLayout) -> None:
    source = Path(path)
    library = gdstk.read_gds(source)
    expected_precision = float(config.dbu_um * Decimal("1e-6"))
    if library.name != GDS_LIBRARY_NAME:
        _fail(
            f"{source.name}: expected Library {GDS_LIBRARY_NAME}, "
            f"found {library.name}"
        )
    if not math.isclose(library.unit, 1e-6, rel_tol=0, abs_tol=1e-18):
        _fail(f"{source.name}: unexpected User Unit {library.unit}")
    if not math.isclose(library.precision, expected_precision, rel_tol=1e-12, abs_tol=1e-18):
        _fail(f"{source.name}: unexpected DBU {library.precision}")
    if len(library.cells) != 1:
        _fail(f"{source.name}: expected one Cell, found {len(library.cells)}")
    top_cells = library.top_level()
    if len(top_cells) != 1:
        _fail(f"{source.name}: expected one top-level Cell, found {len(top_cells)}")
    cell = library.cells[0]
    if cell.name != expected.cell_name:
        _fail(f"{source.name}: expected Cell {expected.cell_name}, found {cell.name}")
    if len(cell.polygons) != len(expected.layers):
        _fail(f"{source.name}: expected {len(expected.layers)} polygons, found {len(cell.polygons)}")

    expected_by_tag = {
        (layer.definition.layer, layer.definition.datatype): layer
        for layer in expected.layers
    }
    required_vertices = 64 if config.shape_type is ShapeType.ROUND else 66
    for polygon in cell.polygons:
        tag = (polygon.layer, polygon.datatype)
        if tag not in expected_by_tag:
            _fail(f"{source.name}: unexpected Layer/Datatype {tag[0]}/{tag[1]}")
        expected_layer = expected_by_tag[tag]
        if polygon.size != required_vertices:
            _fail(
                f"{source.name}: Layer/Datatype {tag[0]}/{tag[1]} has "
                f"{polygon.size} vertices, expected {required_vertices}"
            )
        actual_points = tuple(
            (
                round(float(point[0]) / float(config.dbu_um)),
                round(float(point[1]) / float(config.dbu_um)),
            )
            for point in polygon.points
        )
        expected_points = expected_layer.points_dbu
        if actual_points != expected_points:
            _fail(
                f"{source.name}: coordinate or point-order mismatch on "
                f"Layer/Datatype {tag[0]}/{tag[1]}"
            )
