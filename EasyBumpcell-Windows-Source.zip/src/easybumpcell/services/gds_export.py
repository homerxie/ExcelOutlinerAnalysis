from __future__ import annotations

from decimal import Decimal
from pathlib import Path

import gdstk

from easybumpcell.domain.models import ProjectConfig
from easybumpcell.geometry.layout import GeneratedLayout


GDS_LIBRARY_NAME = "Bumpcell"


def _coordinate_um(value_dbu: int, dbu_um: Decimal) -> float:
    return float(Decimal(value_dbu) * dbu_um)


def write_gds(path: str | Path, config: ProjectConfig, layout: GeneratedLayout) -> Path:
    destination = Path(path)
    library = gdstk.Library(
        name=GDS_LIBRARY_NAME,
        unit=1e-6,
        precision=float(config.dbu_um * Decimal("1e-6")),
    )
    cell = library.new_cell(layout.cell_name)
    for layer in layout.layers:
        points_um = [
            (
                _coordinate_um(x, config.dbu_um),
                _coordinate_um(y, config.dbu_um),
            )
            for x, y in layer.points_dbu
        ]
        cell.add(
            gdstk.Polygon(
                points_um,
                layer=layer.definition.layer,
                datatype=layer.definition.datatype,
            )
        )
    library.write_gds(destination)
    return destination
