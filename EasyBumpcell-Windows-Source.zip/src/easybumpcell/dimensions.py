from __future__ import annotations

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP


DIMENSION_QUANTUM_UM = Decimal("0.1")


def dimension_decimal(value, field_name: str = "Dimension") -> Decimal:
    if isinstance(value, bool) or value is None:
        raise ValueError(f"{field_name} must be a positive number with at most one decimal place")
    try:
        decimal_value = value if isinstance(value, Decimal) else Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError(
            f"{field_name} must be a positive number with at most one decimal place"
        ) from None
    if (
        not decimal_value.is_finite()
        or decimal_value <= 0
        or decimal_value != decimal_value.quantize(DIMENSION_QUANTUM_UM)
    ):
        raise ValueError(
            f"{field_name} must be a positive number with at most one decimal place"
        )
    return decimal_value


def format_input_dimension(value) -> str:
    return f"{dimension_decimal(value):.1f}"


def format_cell_dimension(value) -> str:
    decimal_value = dimension_decimal(value)
    rounded = decimal_value.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return f"{rounded:.0f}"
