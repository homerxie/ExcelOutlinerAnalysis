from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path


DEFAULT_EXPORT_CHECKLIST_PATH = (
    Path(__file__).resolve().with_name("export_checklist.json")
)


@dataclass(frozen=True)
class ExportChecklistText:
    title: str
    intro: str
    al_pad_summary: str
    confirmations: tuple[str, ...]
    warning_template: str
    replacement_template: str


def load_export_checklist(
    language: str,
    path: Path | None = None,
) -> ExportChecklistText:
    config_path = path or DEFAULT_EXPORT_CHECKLIST_PATH
    try:
        document = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(
            f"Unable to read export checklist JSON: {config_path}"
        ) from exc

    try:
        localized = document[language]
        confirmations = localized["confirmations"]
        if not isinstance(localized, dict) or not isinstance(
            confirmations, list
        ):
            raise TypeError
        values = ExportChecklistText(
            title=localized["title"],
            intro=localized["intro"],
            al_pad_summary=localized["al_pad_summary"],
            confirmations=tuple(confirmations),
            warning_template=localized["warning_template"],
            replacement_template=localized["replacement_template"],
        )
    except (KeyError, TypeError) as exc:
        raise ValueError(
            f"Invalid export checklist definition for language {language!r}: "
            f"{config_path}"
        ) from exc

    text_fields = (
        values.title,
        values.intro,
        values.al_pad_summary,
        values.warning_template,
        values.replacement_template,
        *values.confirmations,
    )
    if (
        not values.confirmations
        or any(not isinstance(text, str) or not text.strip() for text in text_fields)
    ):
        raise ValueError(
            f"Export checklist text must contain non-empty strings: {config_path}"
        )
    return values


def format_export_checklist_text(
    template: str,
    field_name: str,
    **values: object,
) -> str:
    try:
        return template.format(**values)
    except (IndexError, KeyError, ValueError) as exc:
        raise ValueError(
            f"Invalid placeholder in export checklist field {field_name!r}"
        ) from exc
