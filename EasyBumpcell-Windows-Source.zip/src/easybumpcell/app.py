from __future__ import annotations

import sys

import qdarktheme
from PySide6.QtWidgets import QApplication

from easybumpcell.i18n import LanguageManager
from easybumpcell.ui.main_window import MainWindow


def main() -> int:
    application = QApplication(sys.argv)
    application.setApplicationName("EasyBumpcell")
    application.setOrganizationName("EasyBumpcell")
    qdarktheme.setup_theme("dark")
    language_manager = LanguageManager(application)
    window = MainWindow(language_manager)
    window.show()
    return application.exec()


if __name__ == "__main__":
    raise SystemExit(main())
