"""Domain models for EasyBumpcell."""

