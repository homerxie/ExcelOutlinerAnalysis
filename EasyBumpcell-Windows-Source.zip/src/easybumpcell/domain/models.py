from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from uuid import uuid4

from easybumpcell.dimensions import dimension_decimal
from .enums import (
    IssueLevel,
    OriginMode,
    RotationDirection,
    ShapeType,
    ZeroDegreeAxis,
)
from easybumpcell.preview_patterns import preview_pattern_for_index


DEFAULT_COLORS = ("#E53935", "#1E88E5", "#43A047", "#FDD835", "#8E24AA", "#00ACC1")
AL_PAD_LAYER_NAME_CANDIDATES = ("ALPA", "AP", "ALPAD", "AL")


@dataclass
class LayerDefinition:
    meaning: str
    layer: int | None = None
    datatype: int | None = 0
    diameter_um: Decimal | int | float | None = None
    minor_axis_um: Decimal | int | float | None = None
    major_axis_um: Decimal | int | float | None = None
    color: str = "#1E88E5"
    preview_pattern: str = preview_pattern_for_index(0)
    uid: str = field(default_factory=lambda: uuid4().hex)

    def nominal_dimensions(self, shape_type: ShapeType) -> tuple[Decimal, ...]:
        if shape_type is ShapeType.ROUND:
            return (
                dimension_decimal(
                    self.diameter_um,
                    f"{self.meaning} Diameter",
                ),
            )
        return (
            dimension_decimal(
                self.minor_axis_um,
                f"{self.meaning} Minor Axis",
            ),
            dimension_decimal(
                self.major_axis_um,
                f"{self.meaning} Major Axis",
            ),
        )


def default_layers() -> list[LayerDefinition]:
    meanings = ("AP", "CB2", "PIO", "UBM")
    return [
        LayerDefinition(
            meaning=meaning,
            color=DEFAULT_COLORS[index % len(DEFAULT_COLORS)],
            preview_pattern=preview_pattern_for_index(index),
        )
        for index, meaning in enumerate(meanings)
    ]


def suggested_al_pad_layer_uid(
    layers: list[LayerDefinition],
) -> str | None:
    """Return the first exact, case-insensitive Al-pad layer-name match."""
    by_upper_name = {
        layer.meaning.upper(): layer.uid
        for layer in layers
        if layer.meaning
    }
    return next(
        (
            by_upper_name[name]
            for name in AL_PAD_LAYER_NAME_CANDIDATES
            if name in by_upper_name
        ),
        None,
    )


@dataclass
class ProjectConfig:
    technology_name: str = ""
    bump_type: str = ""
    version: str = ""
    shape_type: ShapeType = ShapeType.ROUND
    layers: list[LayerDefinition] = field(default_factory=default_layers)
    process_order_confirmed: bool = False
    dbu_um: Decimal = Decimal("0.0005")
    origin_mode: OriginMode = OriginMode.REFERENCE_LOWER_LEFT
    origin_reference_uid: str | None = None
    zero_degree_axis: ZeroDegreeAxis = ZeroDegreeAxis.X
    rotation_direction: RotationDirection = RotationDirection.COUNTERCLOCKWISE
    manual_cell_base_name: str | None = None
    cell_name_layer_uids: list[str] | None = None
    strict_legacy_gdsii_compatibility: bool = False
    al_pad_layer_uid: str | None = None

    def __post_init__(self) -> None:
        self.shape_type = ShapeType(self.shape_type)
        self.origin_mode = OriginMode(self.origin_mode)
        self.zero_degree_axis = ZeroDegreeAxis(self.zero_degree_axis)
        self.rotation_direction = RotationDirection(self.rotation_direction)
        self.dbu_um = Decimal(self.dbu_um)
        if self.origin_reference_uid is None and self.layers:
            self.origin_reference_uid = self.layers[0].uid
        if self.al_pad_layer_uid is None:
            self.al_pad_layer_uid = suggested_al_pad_layer_uid(self.layers)

    def reference_layer(self) -> LayerDefinition | None:
        return next((layer for layer in self.layers if layer.uid == self.origin_reference_uid), None)

    def al_pad_layer(self) -> LayerDefinition | None:
        return next(
            (layer for layer in self.layers if layer.uid == self.al_pad_layer_uid),
            None,
        )


@dataclass(frozen=True)
class ValidationIssue:
    level: IssueLevel
    code: str
    message: str
    layer_uid: str | None = None
