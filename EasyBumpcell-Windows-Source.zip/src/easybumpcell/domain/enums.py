from __future__ import annotations

from enum import Enum


class ShapeType(str, Enum):
    ROUND = "Round"
    OVAL = "Oval"


class OriginMode(str, Enum):
    REFERENCE_LOWER_LEFT = "Reference Layer Bounding Box Lower-left"
    CENTER = "Common Center"


class ZeroDegreeAxis(str, Enum):
    X = "X Axis"
    Y = "Y Axis"


class RotationDirection(str, Enum):
    COUNTERCLOCKWISE = "Counterclockwise"
    CLOCKWISE = "Clockwise"


class IssueLevel(str, Enum):
    ERROR = "ERROR"
    WARNING = "WARNING"

