<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>AdvancedDialog</name>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="6"/>
        <source>Advanced Settings</source>
        <translation>高级设置</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="18"/>
        <source>Coordinate Settings</source>
        <translation>坐标设置</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="24"/>
        <source>Origin Reference Layer</source>
        <translation>原点 Reference Layer</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="34"/>
        <source>Origin Definition</source>
        <translation>原点定义</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="47"/>
        <source>Oval Angle Convention</source>
        <translation>椭圆角度约定</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="53"/>
        <source>Zero-Degree Axis</source>
        <translation>零度轴</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="63"/>
        <source>Positive Rotation</source>
        <translation>正向旋转</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="76"/>
        <source>Cell Name Settings</source>
        <translation>Cell Name 设置</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="82"/>
        <source>Dimensions Included in Cell Name</source>
        <translation>Cell Name 包含的尺寸</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="92"/>
        <source>Reset to First and Last Layers</source>
        <translation>重置为首层和末层</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="99"/>
        <source>Strict Legacy GDSII Compatibility</source>
        <translation>严格兼容旧版 GDSII</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="102"/>
        <source>Warn when a generated Cell Name exceeds the legacy 32-character limit.</source>
        <translation>生成的 Cell Name 超过旧版 32 字符限制时发出警告。</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="109"/>
        <source>Override automatically generated base name</source>
        <translation>覆盖自动生成的基础名称</translation>
    </message>
    <message>
        <location filename="../../../ui/advanced_dialog.ui" line="119"/>
        <source>ASCII letters, digits and underscores only</source>
        <translation>仅限 ASCII 字母、数字和下划线</translation>
    </message>
</context>
<context>
    <name>AdvancedSettingsDialog</name>
    <message>
        <location filename="../ui/advanced_dialog.py" line="69"/>
        <source>{name} — Layer Number {layer} / Datatype {datatype}</source>
        <translation>{name} — Layer Number {layer} / Datatype {datatype}</translation>
    </message>
</context>
<context>
    <name>CheckableComboBox</name>
    <message>
        <location filename="../ui/checkable_combo_box.py" line="16"/>
        <source>Select at least one layer</source>
        <translation>请至少选择一层</translation>
    </message>
</context>
<context>
    <name>Enums</name>
    <message>
        <location filename="../i18n.py" line="26"/>
        <source>Round</source>
        <translation>圆形</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="27"/>
        <source>Oval</source>
        <translation>椭圆</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="28"/>
        <source>Reference Layer Bounding Box Lower-left</source>
        <translation>Reference Layer Bounding Box 左下角</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="32"/>
        <source>Common Center</source>
        <translation>公共中心</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="33"/>
        <source>X Axis</source>
        <translation>X 轴</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="34"/>
        <source>Y Axis</source>
        <translation>Y 轴</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="35"/>
        <source>Counterclockwise</source>
        <translation>逆时针</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="36"/>
        <source>Clockwise</source>
        <translation>顺时针</translation>
    </message>
</context>
<context>
    <name>ExportConfirmationDialog</name>
    <message>
        <location filename="../ui/export_dialog.py" line="53"/>
        <source>  [WILL BE REPLACED]</source>
        <translation>  [将被替换]</translation>
    </message>
    <message>
        <location filename="../ui/export_dialog.py" line="110"/>
        <source>Export</source>
        <translation>导出</translation>
    </message>
</context>
<context>
    <name>ExportDialog</name>
    <message>
        <location filename="../../../ui/export_dialog.ui" line="6"/>
        <source>Confirm Export</source>
        <translation>确认导出</translation>
    </message>
    <message>
        <location filename="../../../ui/export_dialog.ui" line="18"/>
        <source>The following files will be generated:</source>
        <translation>将生成以下文件：</translation>
    </message>
</context>
<context>
    <name>LayerNameDelegate</name>
    <message>
        <location filename="../ui/layer_table_model.py" line="62"/>
        <source>Letters and digits only</source>
        <translation>仅限字母和数字</translation>
    </message>
</context>
<context>
    <name>LayerTableModel</name>
    <message>
        <location filename="../ui/layer_table_model.py" line="77"/>
        <source>Order</source>
        <translation>顺序</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="78"/>
        <source>Layer Name</source>
        <translation>Layer Name</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="79"/>
        <source>Layer Number</source>
        <translation>Layer Number</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="80"/>
        <source>Datatype</source>
        <translation>Datatype</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="83"/>
        <source>Diameter (µm)</source>
        <translation>直径（µm）</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="85"/>
        <source>Minor Axis (µm)</source>
        <translation>短轴（µm）</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="86"/>
        <source>Major Axis (µm)</source>
        <translation>长轴（µm）</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="147"/>
        <source>Drag this row to change the process order.</source>
        <translation>拖动此行可更改工艺顺序。</translation>
    </message>
    <message>
        <location filename="../ui/layer_table_model.py" line="149"/>
        <source>Preview style: {color} / {pattern}</source>
        <translation>预览样式：{color} / {pattern}</translation>
    </message>
</context>
<context>
    <name>LayoutPreviewWidget</name>
    <message>
        <location filename="../ui/preview_widget.py" line="331"/>
        <source>Round</source>
        <translation>圆形</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="151"/>
        <source>Complete the project data to preview the grid-compliant GDS.</source>
        <translation>请补全项目数据，以预览符合格点要求的 GDS。</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="147"/>
        <source>Select the Al Pad Layer and complete the project data to preview the LEF PIN, label and boundary.</source>
        <translation>请选择 Al Pad Layer 并补全项目数据，以预览 LEF PIN、LABEL 和 BOUNDARY。</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="336"/>
        <source>{shape} - LEF {count}-gon PIN</source>
        <translation>{shape} - LEF {count}边形 PIN</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="341"/>
        <source>{shape} - {count}-gon</source>
        <translation>{shape} - {count}边形</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="358"/>
        <source>Center</source>
        <translation>中心</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="362"/>
        <source>Label {label} anchor</source>
        <translation>LABEL {label} 锚点</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="365"/>
        <source> · first LEF point</source>
        <translation> · 首个 LEF 点</translation>
    </message>
    <message>
        <location filename="../ui/preview_widget.py" line="696"/>
        <source>    NODE</source>
        <translation>    节点</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../ui/main_window.ui" line="20"/>
        <source>EasyBumpcell</source>
        <translation>EasyBumpcell</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="88"/>
        <source>Technology Name *</source>
        <translation>Technology Name *</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="95"/>
        <source>e.g. TechName</source>
        <translation>例如 TechName</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="102"/>
        <source>Bump Type</source>
        <translation>Bump Type</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="109"/>
        <source>Optional, e.g. LF</source>
        <translation>可选，例如 LF</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="116"/>
        <source>Version *</source>
        <translation>版本 *</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="123"/>
        <source>Required file version. It is appended to output file names but not to the internal GDS Cell name.</source>
        <translation>必填的文件版本。该版本会附加到输出文件名，但不会加入内部 GDS Cell Name。</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="126"/>
        <source>e.g. V1 or 1.0</source>
        <translation>例如 V1 或 1.0</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="133"/>
        <source>Shape Type</source>
        <translation>形状类型</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="141"/>
        <source>Round</source>
        <translation>圆形</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="146"/>
        <source>Oval</source>
        <translation>椭圆</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="154"/>
        <source>Process DBU (µm) *</source>
        <translation>Process DBU（µm）*</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="162"/>
        <source>0.001 µm</source>
        <translation>0.001 µm</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="167"/>
        <source>0.0005 µm</source>
        <translation>0.0005 µm</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="432"/>
        <source>Polygon</source>
        <translation>多边形</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="685"/>
        <source>Grid-compliant GDS Preview</source>
        <translation>符合格点要求的 GDS 预览</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="802"/>
        <source>Al Pad drawing *</source>
        <translation>Al Pad drawing *</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="909"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="232"/>
        <source>Layers and Process Order</source>
        <translation>Layer 与工艺顺序</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="76"/>
        <source>Process</source>
        <translation>工艺</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="319"/>
        <source>Add Layer</source>
        <translation>添加 Layer</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="326"/>
        <location filename="../ui/main_window.py" line="348"/>
        <source>Delete Layer</source>
        <translation>删除 Layer</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="333"/>
        <source>Restore Defaults</source>
        <translation>恢复默认值</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="353"/>
        <location filename="../ui/main_window.py" line="370"/>
        <location filename="../ui/main_window.py" line="648"/>
        <source>Confirm Process Order</source>
        <translation>确认工艺顺序</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="371"/>
        <source>Output Summary</source>
        <translation>输出摘要</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="397"/>
        <source>Cell Base Name</source>
        <translation>Cell Base Name</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="416"/>
        <location filename="../../../ui/main_window.ui" line="451"/>
        <location filename="../../../ui/main_window.ui" line="489"/>
        <location filename="../../../ui/main_window.ui" line="524"/>
        <source>—</source>
        <translation>—</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="464"/>
        <source>Bumpcell Center</source>
        <translation>Bumpcell 中心</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="505"/>
        <source>DBU / Origin</source>
        <translation>DBU / Origin</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="537"/>
        <source>Validation</source>
        <translation>校验</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="575"/>
        <source>Enter project data.</source>
        <translation>请输入项目数据。</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="905"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="941"/>
        <source>Advanced Settings</source>
        <translation>高级设置</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="618"/>
        <source>Export GDS + LEF + PDF</source>
        <translation>导出 GDS + LEF + PDF</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="647"/>
        <source>GDS Preview</source>
        <translation>GDS 预览</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="726"/>
        <source>Show the actual quantized polygon vertices in both the GDS and LEF live previews. Exported GDS, LEF and PDF files are unchanged.</source>
        <translation>在 GDS 和 LEF 实时预览中显示实际量化多边形顶点。导出的 GDS、LEF 和 PDF 文件不受影响。</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="729"/>
        <source>Show Nodes</source>
        <translation>显示节点</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="739"/>
        <source>Snap the crosshair and coordinate readout in both the GDS and LEF live previews to the nearest quantized polygon vertex. Exported GDS, LEF and PDF files are unchanged.</source>
        <translation>在 GDS 和 LEF 实时预览中，将十字准线和坐标读数吸附到最近的量化多边形顶点。导出的 GDS、LEF 和 PDF 文件不受影响。</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="742"/>
        <source>Snap to Nodes</source>
        <translation>吸附到节点</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="773"/>
        <source>LEF Preview</source>
        <translation>LEF 预览</translation>
    </message>
    <message>
        <location filename="../../../ui/main_window.ui" line="838"/>
        <source>PIN: — · LABEL (BUMP): — · BOUNDARY</source>
        <translation>PIN：— · LABEL（BUMP）：— · BOUNDARY</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="222"/>
        <source>Show detailed confirmation guide</source>
        <translation>显示详细确认教程</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="263"/>
        <source>Help image not found at relative path {path}.</source>
        <translation>未找到相对路径 {path} 下的教程图片。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="272"/>
        <source>Unable to display help image: {path}</source>
        <translation>无法显示教程图片：{path}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="349"/>
        <source>At least one layer is required.</source>
        <translation>至少需要一层。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="355"/>
        <source>Restore Default Layers</source>
        <translation>恢复默认 Layer</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="357"/>
        <source>Replace the current layer table with AP, CB2, PIO and UBM?</source>
        <translation>是否用 AP、CB2、PIO 和 UBM 替换当前 Layer 表？</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="365"/>
        <location filename="../ui/main_window.py" line="405"/>
        <source>(unnamed)</source>
        <translation>（未命名）</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="371"/>
        <source>Confirm this process order?

{order}</source>
        <translation>确认以下工艺顺序？

{order}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="394"/>
        <source>Select Al Pad Layer…</source>
        <translation>选择 Al Pad Layer…</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="402"/>
        <source>{name} — GDS Layer Number {layer} / Datatype {datatype}</source>
        <translation>{name} — GDS Layer Number {layer} / Datatype {datatype}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="442"/>
        <source>Please confirm again:
1. The Layername.Datatype of the Al Pad Drawing layer (not the Marking or Dummy layer) is {layer_number}.{datatype}.
2. The layer name defined for Layername.Datatype {layer_number}.{datatype} in the technology layermap (*.map) file is {layer_name}.</source>
        <translation>请再次确认：
1. Al Pad Drawing 层(而不是Marking或者Dummy 层)的Layername.Datatype就是{layer_number}.{datatype}.
2. Layername.Datatype {layer_number}.{datatype} 在该工艺layermap (*.map)文件中的layer name定义就是{layer_name}。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="495"/>
        <source>Common Center</source>
        <translation>公共中心</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="497"/>
        <source>{name} Lower-left</source>
        <translation>{name} 左下角</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="501"/>
        <source>Missing</source>
        <translation>缺失</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="504"/>
        <source>DBU {dbu} µm · Origin {origin}</source>
        <translation>DBU {dbu} µm · Origin {origin}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="580"/>
        <source>{count}-gon</source>
        <translation>{count}边形</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="597"/>
        <source>ERROR: {message}</source>
        <translation>错误：{message}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="603"/>
        <location filename="../ui/main_window.py" line="615"/>
        <source>WARNING: {message}</source>
        <translation>警告：{message}</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="626"/>
        <source>Confirm the process order before export.</source>
        <translation>请在导出前确认工艺顺序。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="633"/>
        <source>PASS</source>
        <translation>通过</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="642"/>
        <source>Order Confirmed</source>
        <translation>顺序已确认</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="644"/>
        <source>The current process order has been confirmed.</source>
        <translation>当前工艺顺序已经确认。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="652"/>
        <source>Review and confirm the layer process order before export.</source>
        <translation>请在导出前检查并确认 Layer 工艺顺序。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="670"/>
        <source>Please confirm that the Process DBU exactly matches the DBU definition in the techfile (*.tf) of {technology_name} Process.</source>
        <translation>请确认 Process DBU 与 {technology_name} Process 的 techfile (*.tf) 中的 DBU 定义完全一致。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="677"/>
        <source>Please confirm:
1. The GDS Layer Number, Datatype are the correct layers used in the current package bump type of {technology_name} Process. This will affect the GDS generation.
2. The GDS Layer Name exactly matches the GDS Layer Number/Datatype defined in the layermap (*.map) of {technology_name} Process. This will affect the LEF generation.</source>
        <translation>请确认：
1. 下表的GDS Layer Number、Datatype就是 {technology_name} 工艺当前封装类型下的bump所使用的drawing layer的Layer Number、Datatype。这将影响GDS文件的准确生成。
2. GDS Layer Name与Layer Number、Datatype的对应关系与{technology_name} 工艺的layermap （*.map）文件中的定义一致。这将影响LEF文件的准确生成。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="695"/>
        <location filename="../ui/main_window.py" line="730"/>
        <source>Cannot Export</source>
        <translation>无法导出</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="705"/>
        <source>Select Output Directory</source>
        <translation>选择输出目录</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="732"/>
        <source>Select and verify the Al Pad Layer in LEF Preview.</source>
        <translation>请在 LEF 预览中选择并确认 Al Pad Layer。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="752"/>
        <source>Export Failed</source>
        <translation>导出失败</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="762"/>
        <source>Export Complete</source>
        <translation>导出完成</translation>
    </message>
    <message>
        <location filename="../ui/main_window.py" line="763"/>
        <source>Generated and verified:

{files}</source>
        <translation>已生成并验证：

{files}</translation>
    </message>
</context>
<context>
    <name>PreviewPatterns</name>
    <message>
        <location filename="../i18n.py" line="43"/>
        <source>Forward Diagonal</source>
        <translation>正斜线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="44"/>
        <source>Backward Diagonal</source>
        <translation>反斜线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="45"/>
        <source>Diagonal Crosshatch</source>
        <translation>斜向交叉线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="49"/>
        <source>Dots</source>
        <translation>点状</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="50"/>
        <source>Horizontal Lines</source>
        <translation>水平线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="51"/>
        <source>Vertical Lines</source>
        <translation>垂直线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="52"/>
        <source>Grid</source>
        <translation>网格</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="53"/>
        <source>Dense Dots</source>
        <translation>密集点状</translation>
    </message>
</context>
<context>
    <name>Validation</name>
    <message>
        <location filename="../i18n.py" line="60"/>
        <location filename="../i18n.py" line="76"/>
        <source>Minor Axis</source>
        <translation>短轴</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="61"/>
        <location filename="../i18n.py" line="77"/>
        <source>Major Axis</source>
        <translation>长轴</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="62"/>
        <location filename="../i18n.py" line="75"/>
        <source>Diameter</source>
        <translation>直径</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="68"/>
        <source>Technology Name</source>
        <translation>Technology Name</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="69"/>
        <source>Layer Name</source>
        <translation>Layer Name</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="70"/>
        <source>Layer Number</source>
        <translation>Layer Number</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="71"/>
        <source>Datatype</source>
        <translation>Datatype</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="72"/>
        <source>Version</source>
        <translation>版本</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="73"/>
        <source>Bump Type</source>
        <translation>Bump Type</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="74"/>
        <source>Dimension</source>
        <translation>尺寸</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="84"/>
        <source>At least one layer is required</source>
        <translation>至少需要一层</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="88"/>
        <source>Process DBU must be a positive finite value</source>
        <translation>Process DBU 必须是正有限值</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="92"/>
        <source>The origin reference layer does not exist</source>
        <translation>原点 Reference Layer 不存在</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="96"/>
        <source>Origin reference layer does not exist</source>
        <translation>原点 Reference Layer 不存在</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="100"/>
        <source>Select the Al Pad Layer for LEF output</source>
        <translation>请选择用于 LEF 输出的 Al Pad Layer</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="104"/>
        <source>Select the Al Pad Layer in LEF Preview before export</source>
        <translation>请在导出前于 LEF 预览中选择 Al Pad Layer</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="108"/>
        <source>Confirm the layer process order before export</source>
        <translation>请在导出前确认 Layer 工艺顺序</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="112"/>
        <source>Cell Name dimension selection contains deleted layers</source>
        <translation>Cell Name 尺寸选择中包含已删除的 Layer</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="116"/>
        <source>Select at least one layer for the Cell Name</source>
        <translation>请至少为 Cell Name 选择一个 Layer</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="120"/>
        <source>Manual Cell Name may contain ASCII letters, digits and underscores only</source>
        <translation>手动 Cell Name 仅可包含 ASCII 字母、数字和下划线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="124"/>
        <source>Version may contain ASCII letters, digits, periods and hyphens, with separators only between alphanumeric groups</source>
        <translation>版本仅可包含 ASCII 字母、数字、句点和连字符，且分隔符只能位于字母数字组之间</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="128"/>
        <source>Bump Type may contain ASCII letters, digits and underscores only</source>
        <translation>Bump 类型仅可包含 ASCII 字母、数字和下划线</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="132"/>
        <source>Unable to quantize polygon vertex inside the nominal polygon</source>
        <translation>无法在标称多边形内部量化多边形顶点</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="136"/>
        <source>A centrally symmetric polygon must have an even vertex count</source>
        <translation>中心对称多边形必须具有偶数个顶点</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="140"/>
        <source>Polygon is not centrally symmetric</source>
        <translation>多边形不是中心对称图形</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="144"/>
        <source>All layer polygons in one generated layout must use the same node count</source>
        <translation>同一生成布局中的所有 Layer 多边形必须使用相同的节点数</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="155"/>
        <source>{field} is required</source>
        <translation>{field}为必填项</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="163"/>
        <source>{field} may contain ASCII letters and digits only</source>
        <translation>{field}仅可包含 ASCII 字母和数字</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="172"/>
        <source>{field} must be a positive number with at most one decimal place</source>
        <translation>{field}必须是最多一位小数的正数</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="178"/>
        <source>Duplicate Layer Name: {name}</source>
        <translation>Layer Name 重复：{name}</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="186"/>
        <source>{name}: Major Axis must be greater than Minor Axis</source>
        <translation>{name}：长轴必须大于短轴</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="196"/>
        <source>{name}: {field} must be an integer from 0 to 255</source>
        <translation>{name}：{field}必须是 0 到 255 的整数</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="202"/>
        <source>Duplicate Layer Number/Datatype: {pair}</source>
        <translation>Layer Number/Datatype 重复：{pair}</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="211"/>
        <source>{name}: unsupported preview pattern {pattern}</source>
        <translation>{name}：不支持的预览纹理 {pattern}</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="220"/>
        <source>{name} {dimension} endpoints fall on half-grid positions for Process DBU {dbu} µm. DBU will not be changed.</source>
        <translation>{name} 的{dimension}端点位于 Process DBU {dbu} µm 的半网格位置。DBU 不会被更改。</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="233"/>
        <source>{count} existing output file(s) will be replaced.</source>
        <translation>将替换 {count} 个已存在的输出文件。</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="242"/>
        <source>{count} generated Cell name(s) exceed the {limit}-character limit (maximum {maximum})</source>
        <translation>{count} 个生成的 Cell Name 超过 {limit} 字符限制（最大 {maximum}）</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="255"/>
        <source>{count} generated Cell name(s) exceed 32 characters (maximum {maximum}); some legacy GDS tools may reject them</source>
        <translation>{count} 个生成的 Cell Name 超过 32 个字符（最大 {maximum}）；某些旧版 GDS 工具可能会拒绝它们</translation>
    </message>
    <message>
        <location filename="../i18n.py" line="264"/>
        <source>{count} output file name(s) exceed the {limit}-character limit (maximum {maximum})</source>
        <translation>{count} 个输出文件名超过 {limit} 字符限制（最大 {maximum}）</translation>
    </message>
</context>
</TS>
