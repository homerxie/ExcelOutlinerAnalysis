from __future__ import annotations


FORWARD_DIAGONAL = "forward_diagonal"
BACKWARD_DIAGONAL = "backward_diagonal"
DIAGONAL_CROSS = "diagonal_cross"
DOTS = "dots"
HORIZONTAL = "horizontal"
VERTICAL = "vertical"
GRID = "grid"
DENSE_DOTS = "dense_dots"

DEFAULT_PREVIEW_PATTERNS = (
    FORWARD_DIAGONAL,
    BACKWARD_DIAGONAL,
    DIAGONAL_CROSS,
    DOTS,
    HORIZONTAL,
    VERTICAL,
    GRID,
    DENSE_DOTS,
)

PATTERN_LABELS = {
    FORWARD_DIAGONAL: "Forward Diagonal",
    BACKWARD_DIAGONAL: "Backward Diagonal",
    DIAGONAL_CROSS: "Diagonal Crosshatch",
    DOTS: "Dots",
    HORIZONTAL: "Horizontal Lines",
    VERTICAL: "Vertical Lines",
    GRID: "Grid",
    DENSE_DOTS: "Dense Dots",
}


def preview_pattern_for_index(index: int) -> str:
    return DEFAULT_PREVIEW_PATTERNS[index % len(DEFAULT_PREVIEW_PATTERNS)]


def preview_pattern_label(pattern: str) -> str:
    try:
        return PATTERN_LABELS[pattern]
    except KeyError as exc:
        raise ValueError(f"Unsupported preview pattern: {pattern}") from exc
