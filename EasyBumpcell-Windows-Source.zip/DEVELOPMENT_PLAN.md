# EasyBumpcell 开发实施计划

## 1. 开发目标

依据 `PRODUCT_SPECIFICATION.md` 实现 EasyBumpcell 第一版跨平台桌面程序。开发必须优先保证：

1. GDS/LEF 几何和 DBU 处理正确。
2. 命名、工艺顺序和原点规则可预测。
3. Oval 输出四个独立 GDS/LEF 对，每个文件对应一个 Cell/Macro。
4. PDF 报告全英文，并包含与 Linux 默认 `cksum` 一致的 POSIX CRC。
5. 源代码可在安装了受支持 Python 和项目依赖的 Windows、macOS 和 Linux 上运行。
6. 提供三平台原生打包配置、命令和教程，但不交付预构建二进制应用。

## 2. 总体架构

```text
EasyBumpcell/
├── pyproject.toml
├── README.md
├── PRODUCT_SPECIFICATION.md
├── DEVELOPMENT_PLAN.md
├── src/
│   └── easybumpcell/
│       ├── app.py
│       ├── domain/
│       │   ├── enums.py
│       │   └── models.py
│       ├── geometry/
│       │   ├── round.py
│       │   ├── oval.py
│       │   ├── rotation.py
│       │   ├── origin.py
│       │   └── quantization.py
│       ├── services/
│       │   ├── naming.py
│       │   ├── validation.py
│       │   ├── posix_cksum.py
│       │   ├── gds_export.py
│       │   ├── gds_verify.py
│       │   ├── lef_export.py
│       │   ├── lef_verify.py
│       │   ├── pdf_report.py
│       │   └── batch_export.py
│       ├── ui/
│       │   ├── main_window.py
│       │   ├── layer_table_model.py
│       │   ├── preview_widget.py
│       │   ├── advanced_dialog.py
│       │   └── export_dialog.py
│       ├── ui_generated/
│       │   ├── ui_main_window.py
│       │   ├── ui_advanced_dialog.py
│       │   └── ui_export_dialog.py
│       └── resources/
├── ui/
│   ├── main_window.ui
│   ├── advanced_dialog.ui
│   └── export_dialog.ui
├── scripts/
│   └── generate_ui.py
└── tests/
    ├── unit/
    ├── integration/
    ├── ui/
    ├── compatibility/
    └── golden/
```

界面不得直接实现几何、命名、GDS 或校验算法。所有核心逻辑必须可以脱离 Qt 独立测试。

Qt Designer `.ui` 文件是布局的唯一源文件。`src/easybumpcell/ui_generated/` 中的 `ui_*.py` 由 `pyside6-uic` 自动生成，禁止手工修改。`ui/` 下的 Controller/Widget 类负责调用生成的 `setupUi`、连接信号、绑定模型和处理界面状态。

统一生成脚本应等价执行：

```text
pyside6-uic ui/main_window.ui -o src/easybumpcell/ui_generated/ui_main_window.py
pyside6-uic ui/advanced_dialog.ui -o src/easybumpcell/ui_generated/ui_advanced_dialog.py
pyside6-uic ui/export_dialog.ui -o src/easybumpcell/ui_generated/ui_export_dialog.py
```

正式测试以及用户执行打包命令前必须先运行该脚本。

## 3. 数据模型

### 3.1 ProjectConfig

包含：

- Technology Name。
- Bump Type。
- 文件 Version。
- Shape Type。
- 有序图层列表。
- 工艺顺序确认状态。
- DBU。
- Origin 设置。
- Angle Convention。
- 自动/手动 Cell Name 状态。
- Al Pad Layer UID；默认候选只通过 `ALPA`、`AP`、`ALPAD`、`AL` 的忽略大小写完整匹配产生。

### 3.2 LayerDefinition

包含：

- 唯一内部 ID。
- Layer Name（领域模型内部字段仍可使用 `meaning`）。
- Layer Number。
- Datatype（对应 GDS Datatype）。
- Round Diameter，正数 µm，最多一位小数。
- Oval Minor Axis，正数 µm，最多一位小数。
- Oval Major Axis，正数 µm，最多一位小数。
- Preview Color。
- Preview Pattern。纹理是图层属性，拖拽工艺顺序时不得重新分配。

### 3.3 GeneratedLayout

包含：

- 逻辑角度。
- 实际旋转角度。
- Cell Name。
- GDS File Name。
- 原点平移完成后、以整数 DBU 表示的 Bumpcell Common Center。
- 每层名义 Polygon。
- 每层量化后 Polygon。
- Origin。
- Nominal Bounding Box。
- Actual Bounding Box。
- Quantization Warnings。

## 4. 开发阶段

### 阶段 0：项目初始化

任务：

- 建立 `pyproject.toml`。
- 配置 src-layout Python 包。
- 添加 PySide6、gdstk、ReportLab、pytest、pytest-qt。
- 配置代码格式、静态检查和测试命令。
- 建立 `ui/` Qt Designer 源文件目录。
- 建立统一的 UIC 转换脚本和生成文件目录。
- 建立 Windows、macOS 和 Linux 打包配置及教程占位。
- 创建基础 README。

完成标准：

- 可运行空白 PySide6 主窗口。
- 空白主窗口由 `.ui` 经 `pyside6-uic` 生成的 Python 模块加载。
- `pytest` 可执行。
- Windows、macOS 和 Linux 均能安装依赖并运行测试。

### 阶段 1：领域模型和一位小数输入规则

任务：

- 实现项目、图层、原点和角度模型。
- 所有尺寸字段使用精确十进制语义，允许最多一位小数。
- 建立不可变的业务校验结果结构。
- 明确 UI 显示值与 GDS 计算值的单位转换。

测试：

- 接受正数整数或一位小数；拒绝 0、负数、两位及更多小数、字符串和空尺寸。
- Oval 拒绝 `Major Axis <= Minor Axis`。
- Round/Oval 模式切换不混用尺寸字段。

完成标准：

- 核心模型不依赖 Qt。
- 超过一位小数的尺寸无法进入有效项目模型。

### 阶段 2：命名和工艺顺序

任务：

- 实现 Technology Name、Bump Type、Version 和 Layer Name 校验。
- 实现 Round 名称生成。
- 实现 Oval 名称生成。
- 实现 `_0D`、`_45D`、`_90D`、`_135D`。
- 将 Version 作为扩展名前最后一个文件名字段，同时确保内部 Cell Name 不包含 Version。
- 将 GDS `LIBNAME` 固定为短名称 `Bumpcell`，仅由 `STRNAME` 承载最终 Cell Name。
- 实现空 Bump Type 规则。
- Bump Type 允许 ASCII 字母、数字和下划线。
- 将内部 Cell Name 与完整输出文件名分离：默认 Cell Name 为 `BumpType + 首层LayerName/尺寸 + 末层LayerName/尺寸 + Oval角度`，不包含 Technology、Shape 或 Version。
- 文件名继续包含 Technology、Bump Type、Shape、全部工艺层尺寸、Oval 角度和 Version，其中尺寸与 Cell Name 一样使用 `ROUND_HALF_UP` 四舍五入整数。
- 实现高级设置中的 Cell Name 命名图层可勾选下拉列表；默认首尾层，输出始终按工艺顺序。
- 实现 Cell Name 127 字符硬上限和输出文件名 255 字符硬上限。
- 仅当 `Strict Legacy GDSII Compatibility` 打开时实现超过 32 字符的 WARNING。
- 实现手动名称覆盖和恢复自动名称。

测试：

- 精确匹配短 Cell Name 和完整文件名示例。
- 图层拖拽后名称顺序变化。
- 默认首尾层、自定义增加层、删除已选层和恢复默认选择。
- 添加、删除、拖拽重置顺序确认状态。
- 空 Bump Type 不产生双下划线。
- Bump Type 下划线、非法 Unicode 和超长名称。
- Cell Name 超过 127 字符禁止导出；Legacy 开关关闭时不产生 32 字符警告，打开时产生警告。

完成标准：

- 所有文件名和 Cell 名均可由同一个 Naming Service 生成，并明确区分版本化文件名与无版本 Cell 名。
- UI 和导出器不得各自拼接名称。

### 阶段 3：Round/Oval 几何核心

任务：

- 实现规则 64 边形。
- 实现 66 边 Oval。
- 实现逻辑角度到实际角度的映射。
- 实现0、45、90、135 Degree 旋转。
- 实现 Bounding Box 和中心计算。

测试：

- Round 正好 64 个唯一顶点。
- Round 极值和名义直径正确。
- Oval 正好 66 个唯一顶点。
- Oval 的名义长短轴正确。
- 无连续重复点和自交。
- CW/CCW 和0 Degree 基准映射正确。

完成标准：

- 几何模块只返回坐标，不依赖 gdstk 或 Qt。

### 阶段 4：DBU 量化和风险检测

任务：

- 将 µm 坐标映射到整数 DBU。
- 实现对称点成对量化。
- 实现共同中心优先策略。
- 实现向内量化策略。
- 检测尺寸端点和中心的半格点风险。
- 计算名义与实际 Bounding Box 偏差。
- 建立结构化 Quantization Warning。
- 确保 DBU 不会被业务逻辑修改。

测试场景：

- 所有尺寸与中心可精确表示。
- Center Origin 下出现半格点。
- Lower-left Origin 下不同层尺寸奇偶性不一致。
- Round 多层同心。
- Oval 四个角度同心。
- 风险出现时 DBU 保持原值。
- 实际尺寸不超过名义尺寸。
- 最大偏差符合设计上限。

完成标准：

- 同一输入和 DBU 始终产生相同整数坐标。
- 风险可以精确追溯到图层和坐标轴。

### 阶段 5：原点系统

任务：

- 实现 Reference Layer 选择。
- 实现 Lower-left Origin。
- 实现 Center Origin。
- 实现每个 Oval 角度独立旋转、量化和定位。
- 实现参考层删除后的回退规则。

测试：

- AP Lower-left 时 AP 实际 Bounding Box 左下角为 `(0, 0)`。
- Center Origin 时共同中心为 `(0, 0)`。
- 0、45、90、135 Degree 分别满足原点规则。
- 其他层可以合法出现负坐标。

完成标准：

- Preview、GDS 和 PDF 共享完全相同的最终坐标。

### 阶段 6：GDS/LEF 写入和回读验证

任务：

- 实现 Round 单 GDS 写入。
- 实现 Oval 四个独立 GDS 写入。
- 每个 GDS 仅创建一个 Cell。
- 每层仅写入一个 Polygon。
- 不使用 Reference 或辅助 Cell。
- 实现 gdstk 回读验证。
- 为每个 GDS 输出同名 LEF，Macro 名与 GDS Cell 名一致。
- LEF 只输出用户所选 Al Pad Layer；PIN 名固定为 `BUMP`，LAYER 名逐字使用用户确认的 Layer Name。
- LEF Polygon 直接复用 GDS 最终 64/66 个量化节点，不进行角度限制或轮廓近似。
- Round 首点为右侧中点；默认左下角原点下坐标为 `(Xmax, Ymax / 2)`，后续节点逆时针。
- Oval 0 Degree 首点为长轴 `Xmax` 端点，其他角度的首点随几何旋转，后续节点始终逆时针。
- GDS 与 LEF 必须复用包含首点在内的完整有序节点序列。
- 实现 LEF 文本回读，验证 Macro、PIN、Layer、节点数量、顺序和坐标。

回读检查：

- Library Unit 和 Precision。
- Cell 数量和名称。
- 顶层 Cell 数量。
- Polygon 数量。
- Layer/Datatype。
- 64/66 顶点。
- 首点位置和逆时针 winding。
- Bounding Box。
- Origin。
- LEF 固定 `PIN BUMP`、用户确认的 LAYER 名及 Polygon 与 GDS Al Pad 的逐点一致性。

完成标准：

- 任何回读不一致都视为导出失败。

### 阶段 7：POSIX cksum

任务：

- 实现跨平台 `posix_cksum(path)`。
- 使用二进制流分块读取，避免大文件内存问题。
- 返回无符号十进制 CRC、Byte Count 和 File Name。
- 输出语义与 Linux `cksum filename` 默认模式一致。

验证：

- 建立空文件、短文本、二进制文件和生成 GDS 的测试向量。
- 在 Linux 上运行 GNU Coreutils `cksum` 获取 golden values。
- 在 Windows、macOS 和 Linux 上运行 Python 实现并逐项比对。
- 验证带空格和非 ASCII 路径时，算法值和字节数不受路径编码影响。

完成标准：

- 三个平台的结果均与 Linux/GNU 默认 `cksum` 的 CRC 和 Byte Count 完全一致。
- 应用运行时不依赖外部 `cksum.exe`、WSL 或 Git Bash。

### 阶段 8：主窗口和可拖拽图层表

任务：

- 使用 Qt Designer 创建和维护 `main_window.ui`。
- 通过统一 UIC 脚本生成 `ui_main_window.py`。
- 实现基本信息输入。
- Project 区域使用四列 Grid 布局，每行放置两组参数，字段行高和间距不随窗口高度变化。
- 在 Project 区域提供 Process DBU 下拉选项，仅包含 `0.001 µm` 和 `0.0005 µm`，并提示用户确认其与项目 techfile 的 DBU 定义完全一致。
- 使用 `QAbstractTableModel` 管理图层数据。
- 实现整行拖拽排序。
- 实现添加、删除和恢复默认层。
- 实现工艺顺序确认状态。
- 使用固定一位小数、步进 `0.1 µm` 的输入控件填写尺寸。
- 实现实时校验和错误定位。
- 实现自动名称只读预览。
- 将 Output Summary 的 Cell Base Name 固定为单行；按内容动态调整 Center/Validation 高度，并使用底部 Expanding Spacer 吸收窗口增加的高度。

完成标准：

- 普通用户无需打开高级设置即可完成标准导出。
- 两位及更多小数无法通过键盘、粘贴或程序恢复进入尺寸字段。

### 阶段 9：预览系统

任务：

- 实现 Qt 矢量 Polygon 绘制。
- 将右侧预览区组织为 GDS Preview 和 LEF Preview 两个标签页。
- 在 LEF Preview 顶部提供 Al Pad Layer 选择器，显示 Layer Name 和 GDS Layer Number/Datatype；绘制所选 Layer 的 `{Layer}.PIN`、`{Layer}.LABEL` 和 `BOUNDARY`。Label 锚点直接使用导出 LEF POLYGON 的首点，不重排 hull。
- 对 `ALPA`、`AP`、`ALPAD`、`AL` 提供忽略大小写的自动候选，但允许用户明确改选。
- Round 单预览。
- Oval 四宫格同步预览。
- 统一缩放、图层颜色、透明矢量纹理、选择高亮和坐标轴。
- 实现以 `µm` 为单位的 1/2/5 自适应主刻度、刻度数值和 X/Y 轴名称。
- 实现鼠标十字准线及相对于实际 GDS 原点的实时 X/Y 坐标标签。
- 在 Output Summary 和每个预览面板标题中，根据最终 `points_dbu` 的数量显示 `64-gon` 或 `66-gon`（中文为 `64边形` 或 `66边形`），并显示由 `common_center_dbu` 换算的最终 GDS Bumpcell Center 坐标。
- 中心坐标和鼠标坐标固定使用 Process DBU 小数位数；坐标轴刻度继续使用简洁的 1/2/5 自适应格式，不补尾随零。
- 在 `main_window.ui` 的预览标题区加入默认开启、相互独立的 `Show Nodes` 与 `Snap to Nodes` 开关。
- 节点显示使用小型 DPI 感知标记，按图层颜色绘制最终量化 Polygon 顶点；吸附采用 8 个逻辑像素的最近节点判定。
- 吸附后的坐标直接读取整数 DBU 节点坐标；节点显示和吸附状态只存放在预览 Widget，不进入 `ProjectConfig`、GDS 或 PDF。
- 将几何、纹理和坐标轴渲染到高 DPI 静态缓存；鼠标移动时仅恢复旧/新十字准线覆盖的窄条区域，并重绘坐标标签，不刷新整个面板。
- 几何、尺寸、图层选择、窗口尺寸或高级设置变化时必须可靠地使静态缓存失效。
- 建立正斜线、反斜线、交叉斜线、点阵、横线、竖线等稳定纹理集合。
- 纹理只绘制线或点，不使用会遮住下层的实心不透明背景。
- 显示 Origin 和 Oval 长轴方向。
- 显示对应 GDS/Cell 名。
- 显示最终量化坐标，而非理想浮点几何。

完成标准：

- Preview 与回读 GDS 的实际坐标一致。
- LEF Preview 的 PIN 与正式 LEF/GDS Al Pad 的实际节点逐点一致，并显示首点 LABEL 锚点和 MACRO BOUNDARY。
- 四个 Oval 预览同时可见，无需切换 Tab。
- 完全同尺寸、完全重合的两个或多个图层仍可通过颜色和纹理组合区分。
- 图层拖拽前后保持同一 Preview Color 和 Preview Pattern。
- Round 与 Oval 四宫格的刻度间距稳定一致，鼠标移动到原点时坐标读数为 `(0, 0)`。
- Show Nodes 开启后节点尺寸协调且不遮蔽轮廓；Snap to Nodes 可在 Show Nodes 关闭时独立工作，并明确显示 `NODE` 吸附状态。
- 无论两个节点开关状态如何，PDF 矢量预览均不得绘制节点或吸附标记。
- 连续鼠标移动不得重复生成 Polygon、纹理或坐标轴静态内容；Oval 四宫格中只更新当前/上一个悬停面板内的十字线窄条与标签区域。

### 阶段 10：高级设置

任务：

- 使用 Qt Designer 创建和维护 `advanced_dialog.ui`。
- 通过统一 UIC 脚本生成 `ui_advanced_dialog.py`。
- Reference Layer 和 Origin Mode。
- Zero-Degree Axis。
- Positive Rotation Direction。
- Strict Legacy GDSII Compatibility。
- Dimensions Included in Cell Name 可勾选下拉列表、首尾层默认值及重置按钮。
- Cell Name 覆盖及恢复。
- 设置修改后的预览和校验刷新。
- QSettings 持久化。

完成标准：

- DBU 修改只能来自用户在主界面 Project 区域的明确操作。
- 任何校验逻辑都不能自动改变 DBU。

### 阶段 11：英文 PDF 报告

任务：

- 建立严格按照产品规格17项（其中2项仅适用于 Oval）顺序排版的英文报告模板。
- 使用 `Sample GDS report` 标题，依次输出 Technology Name、Bump Type、Version 和 Shape Type。
- 在 Generated GDS and Cell Names 表中同时输出 GDS File/Cell Name、LEF File/Macro Name，以及由对应 GeneratedLayout 实际顶点数据计算的 `Polygon` 列，内容为 `64-gon` 或 `66-gon`。
- 明确说明每对 GDS Cell Name 与 LEF Macro Name 完全一致。
- 单独显示所选 LEF Layer Name 及对应 GDS Layer Number/Datatype，不提示固定 PIN 名称。
- 输出每个 GDS 和 LEF 的 POSIX CRC、Byte Count 和 File Name。
- 对 PDF 中过长的 GDS 文件名、Cell Name 和包含下划线的身份字段添加条件换行点；表格与矢量预览标题优先在下划线之后换行，并保留下划线。
- 绘制 Round 单图或 Oval 四宫格 `Sample GDS Preview`；每个面板直接显示最终 GDS Bumpcell Center，并绘制带数值刻度的 X/Y 坐标轴。
- 紧接 `Sample GDS Preview` 输出 Layer Number/Datatype Mapping，并显示与预览一致的矢量颜色/纹理样本，不输出独立的 `Color / Pattern` 描述列；以表格行顺序体现已确认的工艺顺序。
- 在 Layer Number/Datatype Mapping 之后、`LEF Preview` 之前输出 Nominal Dimensions vs Actual Quantized Axis Dimensions。
- 增加独立 `LEF Preview`，以图内图例显示 `{Layer}.PIN`、`{Layer}.LABEL` 与 `BOUNDARY`；BOUNDARY 尺寸必须解析自生成 LEF 的 `SIZE` 语句，并且仅在 `SIZE` 与同一 LEF `POLYGON` 外接尺寸完全一致后绘制。不再输出重复的 LEF Preview Layers 表，也不显示 PIN label 锚点坐标说明。
- 将 Nominal Dimensions 与 Actual Quantized Axis Dimensions 放在同一对照章节。Oval 必须沿图形自身的短轴/长轴方向计算实际量化尺寸，不得报告旋转后的全局 X/Y 外接框尺寸。
- 尺寸表中的直径、短轴和长轴使用比 Process DBU 多一位的小数精度。
- 输出 Origin Definition 和 Process DBU；不建立独立 Bumpcell Center 表格，也不输出 GDS User Unit。Zero-Degree Axis 和 Positive Rotation Direction 仅对 Oval 输出。
- Round 的尺寸表和偏差表不输出 Angle 列或 `0D`。
- 最后输出 Validation Status 及详细风险，但 `long_cell_name` 兼容性警告只在程序校验和导出确认中显示，不进入 PDF。
- 不输出独立工艺顺序章节、Generation Time 或 Application Version；用户输入的文件 Version 必须输出。

完成标准：

- 报告全部为英文。
- 报告章节顺序与 `PRODUCT_SPECIFICATION.md` 完全一致。
- 报告不包含与尺寸对照表重复的 Quantization Deviations 章节，Polygon Node Count 与实际 GDS Polygon 顶点数一致。
- PDF 放大后 Polygon 边界保持清晰。
- PDF 纹理和图例均保持矢量，完全重合的同尺寸图层可从纹理组合中识别。
- 报告不包含 Layer Name/颜色常识页脚。
- PDF 不计算自身 `cksum`。

### 阶段 12：原子批量导出

任务：

- 使用 Qt Designer 创建和维护导出/覆盖确认对话框。
- 通过统一 UIC 脚本生成对应 `ui_*.py`。
- 用户选择输出目录。
- 预先列出全部目标文件。
- 将全部固定确认点、运行时风险和覆盖已有文件统一显示为 Required Export Checklist。
- 固定条目覆盖 Layer mapping、Process DBU、Layer 工艺顺序、Al Pad drawing Layer 和 Al Pad Layer Name。
- LEF Preview 警告和 Checklist 动态显示所选 Al Pad 的 `{layer_number}.{datatype}` 与 Layer Name，并明确排除 Marking、Dummy layer。
- Layer mapping 和 Process DBU 提示将 JSON 中的 `{technology_name}` 动态替换为用户输入的实际 Technology Name，并明确引用对应 Process 的 `layermap (*.map)` 和 `techfile (*.tf)`。
- 将 Project GroupBox 显示名称改为 Process，并在 Process DBU 与 Layer mapping 警告前加入圆形 `?`；使用 `help_images/` 相对目录兼容源码、PyInstaller package data 和可执行文件旁覆盖，以不裁切的等比例图片 Tooltip 显示教程。
- 每条运行时风险及覆盖提示均为独立 checkbox；全部勾选前 Export 保持禁用。
- 外层 Required Export Checklist frame 保持普通配色，仅 checkbox 列表 frame 和条目使用黄色警告配色。
- 使用一个可自定义 JSON 统一维护 Checklist 的中英文标题、说明、固定条目和动态条目模板，不纳入 Qt Linguist。
- 在临时目录生成并验证 GDS/LEF、计算 GDS `cksum` 和生成 PDF。
- 全部成功后再提交到目标目录。
- 失败时保留清晰错误信息，不留下部分正式文件。

完成标准：

- Oval 要么完整得到四个 GDS、四个 LEF 和一个 PDF，要么正式目录不发生变化。

### 阶段 13：跨平台运行与打包教程

任务：

- 编写 Windows、macOS 和 Linux 的 Python 环境安装教程。
- 编写三平台源码运行和测试命令。
- 建立共享 PyInstaller spec 和各平台构建入口。
- 文档明确要求打包前运行统一 UIC 转换并验证生成文件无差异。
- 提供 Windows 原生打包命令示例。
- 提供 macOS 原生 `.app` 打包命令示例，并说明可选 `.dmg` 后处理。
- 提供 Linux 原生打包命令示例，并说明目录包、AppImage 等可选交付方式。
- 记录 PySide6 平台插件、gdstk 和 ReportLab 的依赖收集要求。
- 记录三平台应用图标、版本信息和文件元数据配置方式。
- 说明高 DPI、字体、文件选择器和路径兼容性的验证方法。
- 说明打包后的程序不应依赖系统 `cksum`、WSL 或 GNU Coreutils。
- 明确不同平台必须在对应平台执行打包命令，产物不能跨平台复用。
- 不生成或交付正式 `.exe`、安装程序、`.app`、`.dmg`、AppImage 或其他预构建包。

完成标准：

- 三个平台的环境安装、源码运行、测试和打包命令均完整、可复制。
- 源码在三个目标平台的受支持 Python 环境中可以启动。
- 可在普通用户权限目录导出。
- PDF 和 GDS 在三个目标平台中生成正确。
- 三个平台计算的 POSIX CRC 均与 Linux `cksum` 一致。
- Definition of Done 不要求产生预构建二进制包。

## 5. 测试矩阵

### 5.1 命名

- 有/无 Bump Type。
- Bump Type 包含下划线。
- Round/Oval。
- 默认四层。
- 默认首尾命名层和自定义增加命名层。
- 不同拖拽顺序。
- 127 字符硬上限和 255 字符文件名上限。
- Legacy 开关开启/关闭时的 32 字符警告。
- 手动名称覆盖与恢复。

### 5.2 尺寸

- 最小值 `0.1 µm`。
- 常见整数和一位小数尺寸。
- 大尺寸和坐标上限。
- 0、负数和两位及更多小数拒绝。
- Oval 长短轴关系。

### 5.3 DBU

- 0.001 µm。
- 0.0005 µm。
- 下拉框不允许输入其他 Process DBU。
- 无风险格点。
- 半格点风险。
- 多层尺寸奇偶性冲突。
- Center/Lower-left Origin。

### 5.4 GDS

- Round 单文件单 Cell。
- Oval 四文件，每文件单 Cell。
- 64/66 顶点。
- Layer/Datatype 映射。
- Origin 和 Bounding Box。
- 超长 Cell Name 兼容性警告。

### 5.5 LEF

- `ALPA`、`AP`、`ALPAD`、`AL` 自动候选及手动改选。
- 输出前 layermap 强制确认。
- PIN Name 固定为 `BUMP`，Layer Name 与用户确认的 Al Pad Layer Name 完全一致。
- Round 64 节点、Oval 66 节点与 GDS 逐点一致。
- LEF 只包含所选 Al Pad Layer。
- Center/Lower-left Origin 下的 SIZE 和 FOREIGN；LEF 模板不输出 ORIGIN。

### 5.6 报告

- Round 英文报告。
- Oval 英文四宫格报告。
- PASS。
- WARNING。
- 多页图层表。
- POSIX CRC 和 Byte Count。
- PDF 页面渲染。

### 5.7 平台兼容性

- Windows 10 64-bit。
- Windows 11 64-bit。
- 受支持的 macOS Intel 构建。
- 受支持的 macOS Apple Silicon 构建。
- 选定最低兼容环境及主流 64-bit Linux 桌面发行版。
- Windows 100%、125%、150%、200% DPI。
- macOS Retina/非 Retina 缩放。
- Linux 常见桌面缩放。
- 英文和中文系统区域设置。
- 路径包含空格。
- 路径包含中文。
- 源码运行环境安装了文档规定的 Python 和项目依赖。
- 程序不调用系统 `cksum`，也不依赖 WSL 或 GNU Coreutils。

### 5.7 UI 生成一致性

- 在干净工作区运行统一 UIC 转换命令。
- 确认生成文件与版本库中的 `ui_*.py` 一致。
- 检查生成文件头部包含“禁止手工修改”的说明。
- 修改 `.ui` 后未重新生成 Python 文件时，自动测试必须失败。
- Controller 和自定义 Widget 中不得复制 Qt Designer 负责的静态布局。

## 6. 发布前人工验收

1. 使用规格示例生成 Round。
2. 使用规格示例生成 Oval。
3. 在 KLayout 或等效查看器中逐个打开 GDS。
4. 确认每个文件只有一个 Cell。
5. 确认 Layer 数量、Layer Number、Datatype 和尺寸。
6. 确认四个 Oval 角度方向。
7. 确认每个角度的 Origin。
8. 在 Linux 上分别对 Windows、macOS 和 Linux 版本生成的 GDS 执行 `cksum`。
9. 将结果与各自 PDF 中的 CRC 和 Byte Count 比对。
10. 按文档在 Windows、macOS 和 Linux 的 Python 环境中分别完成一次从源码启动到导出的完整流程。

## 7. 主要风险和控制措施

### 7.1 超长 Cell Name

风险：部分旧 GDS 工具可能不支持超过 32 字符的 Cell Name。

控制：

- 默认实施 127 字符硬上限。
- 仅在用户开启 `Strict Legacy GDSII Compatibility` 时显示 32 字符警告。
- 不擅自截断。
- 使用目标下游工具进行验收。

### 7.2 半格点和旋转量化

风险：名义尺寸、共同中心和 DBU 无法同时精确满足。

控制：

- 结构化检测。
- 同心优先。
- 对称成对量化。
- 向内处理。
- Preview、GDS 和 PDF 使用同一坐标源。
- 报告实际尺寸和偏差。

### 7.3 跨平台 cksum 差异

风险：误用 `zlib.crc32`、SHA-256 或其他 CRC 变体。

控制：

- 独立实现 POSIX `cksum` 语义。
- 使用 GNU Coreutils 结果作为 golden values。
- 在 Windows、macOS 和 Linux CI/发布测试中比对。

### 7.4 批量输出不完整

风险：Oval 四个 GDS 中只有部分成功。

控制：

- 临时目录生成。
- 全量回读验证。
- 原子提交。
- 失败时不修改正式输出目录。

### 7.5 手工修改 UIC 生成文件

风险：开发者直接修改 `ui_*.py`，下一次运行 UIC 时变更丢失。

控制：

- `.ui` 作为唯一布局源文件。
- 生成文件目录与手写 UI 逻辑目录分离。
- 在 README 和生成文件中注明禁止手工修改。
- CI 重新生成 UI 并检查工作区差异。

## 8. Definition of Done

只有以下条件全部满足，第一版才算完成：

- `PRODUCT_SPECIFICATION.md` 中的第一版验收标准全部通过。
- 自动测试全部通过。
- Windows、macOS 和 Linux 的源码运行及打包教程完整，并经过命令审查；不要求交付预构建发布包。
- Round 和 Oval 示例完成外部查看器人工检查。
- 三个平台生成的 GDS 校验值均与 Linux 默认 `cksum` 一致。
- PDF 为全英文并正确记录每个 GDS 的 CRC 和 Byte Count。
- 没有任何路径会自动改变用户选择的 DBU。
- Oval 一次完整输出四个独立单 Cell GDS、四个对应 LEF 和一个汇总 PDF。
- 所有窗口和对话框布局均以 `.ui` 为源文件，并可通过统一 UIC 命令无差异重新生成 Python 模块。
