from __future__ import annotations

import math
import re
from decimal import Decimal

import gdstk
import pytest

from easybumpcell.coordinate_format import (
    dbu_decimal_places,
    format_coordinate_um,
    format_dimension_um,
)
from easybumpcell.domain.enums import IssueLevel, OriginMode, ShapeType
from easybumpcell.domain.models import (
    DEFAULT_COLORS,
    LayerDefinition,
    ProjectConfig,
    ValidationIssue,
    suggested_al_pad_layer_uid,
)
from easybumpcell.geometry import build_layouts
from easybumpcell.geometry.oval import oval_polygon
from easybumpcell.geometry.round import round_polygon
from easybumpcell.preview_patterns import (
    DEFAULT_PREVIEW_PATTERNS,
)
from easybumpcell.services.lef_export import (
    lef_boundary_from_text,
    lef_preview_elements,
    lef_text,
)
from easybumpcell.services.lef_verify import verify_lef
from easybumpcell.services.naming import (
    generated_names,
    lef_file_name,
    report_name,
)
from easybumpcell.services.posix_cksum import posix_cksum
from easybumpcell.services.pdf_report import (
    REPORT_TITLE,
    _clipped_parallel_segments,
    _dimension_table,
    _format_axis_tick,
    _generated_names_table,
    _layer_mapping_table,
    _preview_drawing,
    _report_warning_messages,
    _table_text_style,
    _underscore_break_markup,
    _underscore_wrapped_paragraph,
    _wrap_text_at_underscores,
)
from easybumpcell.services.validation import has_errors, validate_project
from easybumpcell.services.batch_export import export_project, intended_paths


def _lef_polygon_points(text: str) -> tuple[tuple[Decimal, Decimal], ...]:
    match = re.search(r"\bPOLYGON\s+(.*?)\s*;", text, flags=re.DOTALL)
    assert match is not None
    values = [
        Decimal(value)
        for value in re.findall(
            r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)",
            match.group(1),
        )
    ]
    assert len(values) % 2 == 0
    return tuple(zip(values[0::2], values[1::2]))


def _signed_double_area(points) -> float:
    return sum(
        start[0] * end[1] - end[0] * start[1]
        for start, end in zip(points, (*points[1:], points[0]))
    )


def _gds_layer_points_dbu(path, config, definition) -> tuple[tuple[int, int], ...]:
    library = gdstk.read_gds(path)
    polygon = next(
        polygon
        for polygon in library.cells[0].polygons
        if (
            polygon.layer,
            polygon.datatype,
        )
        == (
            definition.layer,
            definition.datatype,
        )
    )
    return tuple(
        (
            round(float(point[0]) / float(config.dbu_um)),
            round(float(point[1]) / float(config.dbu_um)),
        )
        for point in polygon.points
    )


def _lef_polygon_points_dbu(
    text: str,
    dbu_um: Decimal,
) -> tuple[tuple[int, int], ...]:
    return tuple(
        (
            int(x / dbu_um),
            int(y / dbu_um),
        )
        for x, y in _lef_polygon_points(text)
    )


def sample_round() -> ProjectConfig:
    config = ProjectConfig(
        technology_name="TechName",
        bump_type="LF",
        version="V1",
        shape_type=ShapeType.ROUND,
        layers=[
            LayerDefinition("AP", 1, 0, diameter_um=80, color=DEFAULT_COLORS[0], preview_pattern=DEFAULT_PREVIEW_PATTERNS[0]),
            LayerDefinition("CB2", 2, 0, diameter_um=40, color=DEFAULT_COLORS[1], preview_pattern=DEFAULT_PREVIEW_PATTERNS[1]),
            LayerDefinition("PIO", 3, 0, diameter_um=30, color=DEFAULT_COLORS[2], preview_pattern=DEFAULT_PREVIEW_PATTERNS[2]),
            LayerDefinition("UBM", 4, 0, diameter_um=60, color=DEFAULT_COLORS[3], preview_pattern=DEFAULT_PREVIEW_PATTERNS[3]),
        ],
        process_order_confirmed=True,
    )
    config.origin_reference_uid = config.layers[0].uid
    return config


def sample_oval() -> ProjectConfig:
    config = ProjectConfig(
        technology_name="TechName",
        bump_type="LF",
        version="V1",
        shape_type=ShapeType.OVAL,
        layers=[
            LayerDefinition("AP", 1, 0, minor_axis_um=40, major_axis_um=80, color=DEFAULT_COLORS[0], preview_pattern=DEFAULT_PREVIEW_PATTERNS[0]),
            LayerDefinition("CB2", 2, 0, minor_axis_um=20, major_axis_um=40, color=DEFAULT_COLORS[1], preview_pattern=DEFAULT_PREVIEW_PATTERNS[1]),
            LayerDefinition("PIO", 3, 0, minor_axis_um=10, major_axis_um=30, color=DEFAULT_COLORS[2], preview_pattern=DEFAULT_PREVIEW_PATTERNS[2]),
            LayerDefinition("UBM", 4, 0, minor_axis_um=30, major_axis_um=60, color=DEFAULT_COLORS[3], preview_pattern=DEFAULT_PREVIEW_PATTERNS[3]),
        ],
        process_order_confirmed=True,
    )
    config.origin_reference_uid = config.layers[0].uid
    return config


def test_round_has_64_vertices_and_exact_extents() -> None:
    points = round_polygon(80)
    assert len(points) == 64
    assert points[0] == pytest.approx((40, 0))
    assert max(x for x, _ in points) == pytest.approx(40)
    assert min(x for x, _ in points) == pytest.approx(-40)
    assert max(y for _, y in points) == pytest.approx(40)
    assert min(y for _, y in points) == pytest.approx(-40)
    assert _signed_double_area(points) > 0


def test_oval_has_66_vertices_and_exact_extents() -> None:
    points = oval_polygon(40, 80)
    assert len(points) == 66
    assert points[0] == pytest.approx((40, 0))
    assert max(x for x, _ in points) == pytest.approx(40)
    assert min(x for x, _ in points) == pytest.approx(-40)
    assert max(y for _, y in points) == pytest.approx(20)
    assert min(y for _, y in points) == pytest.approx(-20)
    assert _signed_double_area(points) > 0


def test_required_names() -> None:
    assert generated_names(sample_round()) == ["LF_AP80_UBM60"]
    assert generated_names(sample_oval()) == [
        "LF_AP4080_UBM3060_0D",
        "LF_AP4080_UBM3060_45D",
        "LF_AP4080_UBM3060_90D",
        "LF_AP4080_UBM3060_135D",
    ]
    round_layout = build_layouts(sample_round())[0]
    assert round_layout.gds_file_name == (
        "TechName_LF_Round_80AP_40CB2_30PIO_60UBM_V1.gds"
    )
    assert round_layout.cell_name == "LF_AP80_UBM60"
    assert report_name(sample_round()) == (
        "TechName_LF_Round_80AP_40CB2_30PIO_60UBM_Report_V1.pdf"
    )
    assert lef_file_name(sample_round(), 0) == (
        "TechName_LF_Round_80AP_40CB2_30PIO_60UBM_V1.lef"
    )


def test_al_pad_layer_name_candidates_are_case_insensitive_and_prioritized() -> None:
    layers = [
        LayerDefinition("al", 4, 0, diameter_um=60),
        LayerDefinition("alpad", 3, 0, diameter_um=50),
        LayerDefinition("ap", 2, 0, diameter_um=40),
        LayerDefinition("alpa", 1, 0, diameter_um=30),
    ]
    assert suggested_al_pad_layer_uid(layers) == layers[3].uid
    assert ProjectConfig(layers=layers).al_pad_layer_uid == layers[3].uid
    assert (
        suggested_al_pad_layer_uid(
            [LayerDefinition("RDL", 1, 0, diameter_um=30)]
        )
        is None
    )


def test_al_pad_layer_is_required_only_for_formal_export() -> None:
    config = sample_round()
    config.al_pad_layer_uid = None
    preview_issues = validate_project(config, for_export=False)
    export_issues = validate_project(config, for_export=True)
    assert any(
        issue.code == "al_pad_layer" and issue.level is IssueLevel.WARNING
        for issue in preview_issues
    )
    assert any(
        issue.code == "al_pad_layer" and issue.level is IssueLevel.ERROR
        for issue in export_issues
    )


def test_cell_name_can_include_custom_layers_but_keeps_process_order() -> None:
    config = sample_round()
    config.cell_name_layer_uids = [
        config.layers[3].uid,
        config.layers[0].uid,
        config.layers[2].uid,
    ]
    assert generated_names(config) == ["LF_AP80_PIO30_UBM60"]


def test_bump_type_allows_underscores_in_cell_name() -> None:
    config = sample_round()
    config.bump_type = "Flip_Chip_LF"
    assert generated_names(config) == ["Flip_Chip_LF_AP80_UBM60"]
    assert not any(issue.code == "bump_type" for issue in validate_project(config))


def test_cell_name_length_and_legacy_warning_rules() -> None:
    config = sample_round()
    config.bump_type = "LEGACY_COMPATIBILITY_BUMP"
    issues = validate_project(config)
    assert not any(issue.code == "long_cell_name" for issue in issues)

    config.strict_legacy_gdsii_compatibility = True
    issues = validate_project(config)
    assert any(issue.code == "long_cell_name" for issue in issues)
    assert not has_errors(issues)

    config.manual_cell_base_name = "A" * 128
    issues = validate_project(config)
    assert any(issue.code == "cell_name_length" for issue in issues)
    assert has_errors(issues)


def test_cell_name_rejects_non_ascii_characters() -> None:
    config = sample_round()
    config.manual_cell_base_name = "LF_AP80_中文"
    assert any(issue.code == "naming" for issue in validate_project(config))


def test_output_file_names_have_255_character_hard_limit() -> None:
    config = sample_round()
    config.technology_name = "T" * 240
    issues = validate_project(config)
    assert any(issue.code == "file_name_length" for issue in issues)
    assert has_errors(issues)


def test_validation_requires_a_safe_version() -> None:
    config = sample_round()
    config.version = ""
    assert any(issue.code == "version" for issue in validate_project(config))
    config.version = "V1_bad"
    assert any(issue.code == "version" for issue in validate_project(config))
    config.version = "V1.2-rc1"
    assert not any(issue.code == "version" for issue in validate_project(config))


def test_validation_accepts_one_decimal_and_rejects_more_precision() -> None:
    config = sample_round()
    config.layers[0].diameter_um = Decimal("80.5")
    assert not has_errors(validate_project(config))
    config.layers[0].diameter_um = Decimal("80.55")
    assert has_errors(validate_project(config))


def test_decimal_round_dimensions_use_real_geometry_and_rounded_cell_name() -> None:
    config = sample_round()
    config.layers[0].diameter_um = Decimal("80.5")
    config.layers[-1].diameter_um = Decimal("60.4")
    layout = build_layouts(config)[0]
    assert layout.cell_name == "LF_AP81_UBM60"
    assert layout.gds_file_name == (
        "TechName_LF_Round_81AP_40CB2_30PIO_60UBM_V1.gds"
    )
    ap = layout.layers[0]
    assert Decimal(ap.bbox_dbu.width) * config.dbu_um == Decimal("80.5")
    assert Decimal(ap.bbox_dbu.height) * config.dbu_um == Decimal("80.5")


def test_decimal_oval_dimensions_round_half_up_only_for_cell_name() -> None:
    config = sample_oval()
    config.layers[0].minor_axis_um = Decimal("40.5")
    config.layers[0].major_axis_um = Decimal("80.5")
    config.layers[-1].minor_axis_um = Decimal("30.4")
    config.layers[-1].major_axis_um = Decimal("60.5")
    layouts = build_layouts(config)
    assert layouts[0].cell_name == "LF_AP4181_UBM3061_0D"
    assert layouts[1].cell_name == "LF_AP4181_UBM3061_45D"
    assert layouts[0].gds_file_name == (
        "TechName_LF_Oval_4181AP_2040CB2_1030PIO_3061UBM_0D_V1.gds"
    )
    assert layouts[0].deviations[0].nominal_um == Decimal("40.5")


def test_validation_rejects_unknown_preview_pattern() -> None:
    config = sample_round()
    config.layers[0].preview_pattern = "unknown_pattern"
    issues = validate_project(config)
    assert any(issue.code == "preview_pattern" for issue in issues)


def test_round_layout_uses_ap_lower_left_origin() -> None:
    config = sample_round()
    layout = build_layouts(config)[0]
    ap = layout.layers[0]
    assert ap.bbox_dbu.min_x == 0
    assert ap.bbox_dbu.min_y == 0
    assert len(ap.points_dbu) == 64
    assert ap.points_dbu[0] == (
        ap.bbox_dbu.max_x,
        ap.bbox_dbu.max_y // 2,
    )
    assert _signed_double_area(ap.points_dbu) > 0


def test_oval_builds_four_independent_layouts() -> None:
    layouts = build_layouts(sample_oval())
    assert [layout.logical_angle for layout in layouts] == [0, 45, 90, 135]
    assert all(len(layer.points_dbu) == 66 for layout in layouts for layer in layout.layers)
    assert all(layout.layers[0].bbox_dbu.min_x == 0 for layout in layouts)
    assert all(layout.layers[0].bbox_dbu.min_y == 0 for layout in layouts)
    assert all(layout.nodes_per_polygon == 66 for layout in layouts)
    for layout in layouts:
        ap = layout.layers[0]
        angle = math.radians(layout.actual_angle_degrees)
        major_axis = (math.cos(angle), math.sin(angle))
        projections = [
            x * major_axis[0] + y * major_axis[1]
            for x, y in ap.points_dbu
        ]
        first_projection = (
            ap.points_dbu[0][0] * major_axis[0]
            + ap.points_dbu[0][1] * major_axis[1]
        )
        assert first_projection == pytest.approx(max(projections))
        assert _signed_double_area(ap.points_dbu) > 0


def test_report_node_count_uses_generated_polygon_vertices() -> None:
    round_config = sample_round()
    oval_config = sample_oval()
    round_layouts = build_layouts(round_config)
    oval_layouts = build_layouts(oval_config)
    assert round_layouts[0].nodes_per_polygon == 64
    assert _generated_names_table(
        round_config,
        round_layouts,
    )._cellvalues[0] == [
        "GDS File Name",
        "GDS Cell Name",
        "LEF File Name",
        "LEF Macro Name",
        "Polygon",
    ]
    assert [
        row[4]
        for row in _generated_names_table(
            round_config,
            round_layouts,
        )._cellvalues[1:]
    ] == ["64-gon"]
    assert [
        row[4]
        for row in _generated_names_table(
            oval_config,
            oval_layouts,
        )._cellvalues[1:]
    ] == ["66-gon", "66-gon", "66-gon", "66-gon"]
    round_row = _generated_names_table(
        round_config,
        round_layouts,
    )._cellvalues[1]
    assert round_row[0].getPlainText().endswith(".gds")
    assert round_row[2].getPlainText().endswith(".lef")
    assert round_row[1].getPlainText() == round_row[3].getPlainText()


def test_rotated_oval_dimensions_are_reported_on_local_axes_not_world_bbox() -> None:
    config = sample_oval()
    layouts = build_layouts(config)
    assert _dimension_table(config, layouts)._cellvalues[0][1] == "Layer Name"
    layout = next(item for item in layouts if item.logical_angle == 45)
    ap = layout.layers[0]
    actual = {
        deviation.axis: deviation.actual_um
        for deviation in layout.deviations
        if deviation.layer_uid == ap.definition.uid
    }
    world_width = Decimal(ap.bbox_dbu.width) * config.dbu_um
    world_height = Decimal(ap.bbox_dbu.height) * config.dbu_um

    assert set(actual) == {"Minor Axis", "Major Axis"}
    assert actual["Minor Axis"] == pytest.approx(Decimal("40"), abs=Decimal("0.002"))
    assert actual["Major Axis"] == pytest.approx(Decimal("80"), abs=Decimal("0.002"))
    assert Decimal("68") < world_width < Decimal("69")
    assert Decimal("68") < world_height < Decimal("69")
    assert world_width not in (actual["Minor Axis"], actual["Major Axis"])


def test_half_grid_risk_does_not_modify_dbu() -> None:
    config = sample_round()
    config.dbu_um = Decimal("0.4")
    original = config.dbu_um
    layouts = build_layouts(config)
    assert config.dbu_um == original
    assert layouts[0].risks


def test_posix_cksum_empty_file(tmp_path) -> None:
    path = tmp_path / "empty.bin"
    path.write_bytes(b"")
    result = posix_cksum(path)
    assert result.crc == 4294967295
    assert result.byte_count == 0


def test_posix_cksum_matches_posix_golden_value(tmp_path) -> None:
    path = tmp_path / "vector.bin"
    path.write_bytes(b"123456789")
    result = posix_cksum(path)
    assert result.crc == 930766865
    assert result.byte_count == 9


def test_report_mapping_uses_swatch_without_color_pattern_description() -> None:
    config = sample_oval()
    table = _layer_mapping_table(config)
    assert table._cellvalues[0] == [
        "Order",
        "Layer Name",
        "Layer Number",
        "Datatype",
        "Preview",
    ]
    assert all(row[4].contents for row in table._cellvalues[1:])
    assert all(len(row) == 5 for row in table._cellvalues)


def test_round_report_dimension_table_does_not_include_angles() -> None:
    config = sample_round()
    layouts = build_layouts(config)
    dimension_table = _dimension_table(config, layouts)
    assert "Angle" not in dimension_table._cellvalues[0]
    assert not any("0D" in row for row in dimension_table._cellvalues[1:])
    assert dimension_table._cellvalues[1][1:] == [
        "80.00000",
        "80.00000",
        "80.00000",
    ]


def test_oval_report_dimension_table_keeps_angles() -> None:
    config = sample_oval()
    layouts = build_layouts(config)
    assert _dimension_table(config, layouts)._cellvalues[0][0] == "Angle"


def test_coordinate_and_dimension_formats_follow_dbu_precision() -> None:
    dbu = Decimal("0.0005")
    assert dbu_decimal_places(dbu) == 4
    assert format_coordinate_um(Decimal("30"), dbu) == "30.0000"
    assert format_dimension_um(Decimal("30"), dbu) == "30.00000"
    assert format_coordinate_um(Decimal("30"), Decimal("0.001")) == "30.000"
    assert format_dimension_um(Decimal("30"), Decimal("0.001")) == "30.0000"
    assert _format_axis_tick(30, 10) == "30"


def test_pdf_preview_embeds_final_bumpcell_center() -> None:
    config = sample_round()
    drawing = _preview_drawing(build_layouts(config), config)
    texts = [item.text for item in drawing.contents if hasattr(item, "text")]
    assert "Center: X 40.0000 µm, Y 40.0000 µm" in texts
    assert "0" in texts
    assert "20" in texts


def test_pdf_lef_preview_contains_pin_label_boundary_and_first_point_anchor() -> None:
    config = sample_round()
    layouts = build_layouts(config)
    elements = lef_preview_elements(config, layouts[0])
    drawing = _preview_drawing(layouts, config, lef_mode=True)
    texts = [item.text for item in drawing.contents if hasattr(item, "text")]

    assert elements.label_anchor_dbu == elements.pin_geometry.points_dbu[0]
    assert elements.label_anchor_dbu == (160000, 80000)
    assert elements.boundary_dbu.min_x == 0
    assert elements.boundary_dbu.min_y == 0
    assert elements.boundary_dbu.max_x == 160000
    assert elements.boundary_dbu.max_y == 160000
    assert elements.pin_layer_name in texts
    assert elements.label_layer_name in texts
    assert elements.boundary_layer_name in texts
    assert elements.label_text in texts
    assert not any(text.startswith("Label BUMP anchor:") for text in texts)


def test_lef_preview_boundary_uses_size_box_for_center_origin() -> None:
    config = sample_round()
    config.origin_mode = OriginMode.CENTER
    elements = lef_preview_elements(config, build_layouts(config)[0])

    assert elements.pin_geometry.bbox_dbu.min_x == -80000
    assert elements.pin_geometry.bbox_dbu.min_y == -80000
    assert elements.pin_geometry.bbox_dbu.max_x == 80000
    assert elements.pin_geometry.bbox_dbu.max_y == 80000
    assert elements.boundary_dbu.min_x == 0
    assert elements.boundary_dbu.min_y == 0
    assert elements.boundary_dbu.max_x == 160000
    assert elements.boundary_dbu.max_y == 160000


def test_lef_boundary_uses_size_after_matching_polygon_bounds() -> None:
    text = """
MACRO BUMP_SAMPLE
  SIZE 65.213 BY 65.213 ;
  PIN BUMP
    PORT
      POLYGON 0 0 65.213 0 65.213 65.213 0 65.213 ;
    END
  END BUMP
END BUMP_SAMPLE
"""
    boundary = lef_boundary_from_text(text, Decimal("0.0005"))

    assert boundary.min_x == 0
    assert boundary.min_y == 0
    assert boundary.max_x == 130426
    assert boundary.max_y == 130426


def test_lef_boundary_rejects_size_that_does_not_match_polygon_bounds() -> None:
    text = """
MACRO BUMP_SAMPLE
  SIZE 65.213 BY 65.213 ;
  PIN BUMP
    PORT
      POLYGON 0 0 65.212 0 65.212 65.213 0 65.213 ;
    END
  END BUMP
END BUMP_SAMPLE
"""
    with pytest.raises(
        ValueError,
        match="SIZE 65.213 BY 65.213 does not match PIN POLYGON bounds",
    ):
        lef_boundary_from_text(text, Decimal("0.0005"))


def test_report_filters_only_long_cell_name_warning() -> None:
    config = sample_round()
    config.bump_type = "LEGACY_COMPATIBILITY_BUMP"
    config.strict_legacy_gdsii_compatibility = True
    issues = validate_project(config, for_export=True)
    assert any(issue.code == "long_cell_name" for issue in issues)
    assert _report_warning_messages(issues) == []
    retained = ValidationIssue(IssueLevel.WARNING, "other_warning", "Keep this warning")
    assert _report_warning_messages([*issues, retained]) == ["Keep this warning"]


def test_vector_hatch_segments_are_clipped_to_polygon() -> None:
    square = [(0.0, 0.0), (20.0, 0.0), (20.0, 20.0), (0.0, 20.0)]
    segments = _clipped_parallel_segments(square, (1.0, 1.0), 5.0)
    assert segments
    for segment in segments:
        for x, y in segment:
            assert 0 <= x <= 20
            assert 0 <= y <= 20


def test_pdf_long_names_wrap_at_underscores() -> None:
    value = "LF_AP4080_UBM3060_135D"
    markup = _underscore_break_markup(value)
    assert markup.count('<font size="0"> </font>') == value.count("_")

    paragraph = _underscore_wrapped_paragraph(
        value,
        _table_text_style(8),
    )
    paragraph.wrap(55, 500)
    lines = [
        "".join(getattr(word, "text", "") for word in line.words)
        for line in paragraph.blPara.lines
    ]
    assert lines == ["LF_AP4080_", "UBM3060_", "135D"]
    vector_lines = _wrap_text_at_underscores(
        value,
        55,
        "Helvetica",
        8,
    )
    assert "".join(vector_lines) == value
    assert all(line.endswith("_") for line in vector_lines[:-1])


def test_report_section_order(tmp_path, monkeypatch) -> None:
    import easybumpcell.services.pdf_report as pdf_report

    section_titles: list[str] = []
    section_contents: dict[str, object] = {}
    original_section = pdf_report._section

    def recording_section(title, content, styles, **kwargs):
        section_titles.append(title)
        section_contents[title] = content
        return original_section(title, content, styles, **kwargs)

    monkeypatch.setattr(pdf_report, "_section", recording_section)
    export_project(sample_round(), tmp_path)
    assert section_titles == [
        "Technology Name",
        "Bump Type",
        "Version",
        "Shape Type",
        "Generated GDS and Cell Names",
        "LEF PIN Layer Name",
        "POSIX Checksums",
        "Sample GDS Preview",
        "Layer Number/Datatype Mapping",
        "Nominal Dimensions vs Actual Quantized Axis Dimensions",
        "LEF Preview",
        "Origin Definition",
        "Process DBU",
        "Validation Status",
    ]
    lef_layer_identity = section_contents["LEF PIN Layer Name"]
    assert isinstance(lef_layer_identity, str)
    assert "PIN BUMP" not in lef_layer_identity
    assert "LEF Layer Name" in lef_layer_identity
    assert REPORT_TITLE == "Sample GDS report"


def test_oval_report_keeps_angle_convention_sections(tmp_path, monkeypatch) -> None:
    import easybumpcell.services.pdf_report as pdf_report

    section_titles: list[str] = []
    original_section = pdf_report._section

    def recording_section(title, content, styles, **kwargs):
        section_titles.append(title)
        return original_section(title, content, styles, **kwargs)

    monkeypatch.setattr(pdf_report, "_section", recording_section)
    export_project(sample_oval(), tmp_path)
    assert "Zero-Degree Axis" in section_titles
    assert "Positive Rotation Direction" in section_titles


def test_round_end_to_end_export(tmp_path) -> None:
    config = sample_round()
    layout = build_layouts(config)[0]
    result = export_project(config, tmp_path)
    assert len(result.gds_paths) == 1
    assert result.gds_paths[0].is_file()
    library = gdstk.read_gds(result.gds_paths[0])
    assert library.name == "Bumpcell"
    assert library.cells[0].name == generated_names(sample_round())[0]
    assert result.report_path.is_file()
    assert len(result.lef_paths) == 1
    assert result.lef_paths[0].is_file()
    assert result.gds_paths[0].name.endswith("_V1.gds")
    assert result.lef_paths[0].name.endswith("_V1.lef")
    assert result.report_path.name.endswith("_Report_V1.pdf")
    assert result.report_path.stat().st_size > 1000
    assert [item.file_name for item in result.checksums] == [
        result.gds_paths[0].name,
        result.lef_paths[0].name,
    ]
    assert result.checksums[0].byte_count == result.gds_paths[0].stat().st_size
    assert result.checksums[1].byte_count == result.lef_paths[0].stat().st_size
    verify_lef(
        result.lef_paths[0],
        config,
        layout,
    )
    selected = next(
        layer
        for layer in layout.layers
        if layer.definition.uid == config.al_pad_layer_uid
    )
    gds_points = _gds_layer_points_dbu(
        result.gds_paths[0],
        config,
        selected.definition,
    )
    lef_points = _lef_polygon_points_dbu(
        result.lef_paths[0].read_text(encoding="ascii"),
        config.dbu_um,
    )
    assert gds_points == selected.points_dbu
    assert lef_points == selected.points_dbu


def test_decimal_round_end_to_end_export(tmp_path) -> None:
    config = sample_round()
    config.layers[0].diameter_um = Decimal("80.5")
    config.layers[-1].diameter_um = Decimal("60.4")
    result = export_project(config, tmp_path)
    assert result.gds_paths[0].name.endswith(
        "_81AP_40CB2_30PIO_60UBM_V1.gds"
    )
    library = gdstk.read_gds(result.gds_paths[0])
    assert library.cells[0].name == "LF_AP81_UBM60"
    assert result.report_path.name.endswith(
        "_81AP_40CB2_30PIO_60UBM_Report_V1.pdf"
    )


def test_oval_end_to_end_export(tmp_path) -> None:
    config = sample_oval()
    layouts = build_layouts(config)
    result = export_project(config, tmp_path)
    assert len(result.gds_paths) == 4
    assert [path.stem.rsplit("_", 2)[-2:] for path in result.gds_paths] == [
        ["0D", "V1"],
        ["45D", "V1"],
        ["90D", "V1"],
        ["135D", "V1"],
    ]
    assert all(path.is_file() for path in result.gds_paths)
    assert len(result.lef_paths) == 4
    assert all(path.is_file() for path in result.lef_paths)
    assert result.report_path.is_file()
    expected_checksum_names = [
        path.name
        for pair in zip(result.gds_paths, result.lef_paths)
        for path in pair
    ]
    assert [item.file_name for item in result.checksums] == (
        expected_checksum_names
    )
    for layout, gds_path, lef_path in zip(
        layouts,
        result.gds_paths,
        result.lef_paths,
    ):
        selected = next(
            layer
            for layer in layout.layers
            if layer.definition.uid == config.al_pad_layer_uid
        )
        gds_points = _gds_layer_points_dbu(
            gds_path,
            config,
            selected.definition,
        )
        lef_points = _lef_polygon_points_dbu(
            lef_path.read_text(encoding="ascii"),
            config.dbu_um,
        )
        assert gds_points == selected.points_dbu
        assert lef_points == selected.points_dbu


def test_lef_bump_pin_and_polygon_match_selected_gds_layer() -> None:
    config = sample_round()
    config.al_pad_layer_uid = config.layers[2].uid
    layout = build_layouts(config)[0]
    text = lef_text(config, layout)
    selected = layout.layers[2]

    assert "  PIN BUMP\n" in text
    assert "  END BUMP\n" in text
    assert "  PIN PIO\n" not in text
    assert "      LAYER PIO ;\n" in text
    assert "LAYER AP" not in text
    assert "LAYER CB2" not in text
    assert "LAYER UBM" not in text
    assert "NAMESCASESENSITIVE" not in text
    assert "\nUNITS\n" not in text
    assert "\n  ORIGIN " not in text
    assert "\n      CLASS BUMP ;" not in text
    assert re.search(r"^\s*POLYGON [^\n]+ ;$", text, flags=re.MULTILINE)
    points = _lef_polygon_points(text)
    assert len(points) == 64
    assert points == tuple(
        (
            Decimal(x) * config.dbu_um,
            Decimal(y) * config.dbu_um,
        )
        for x, y in selected.points_dbu
    )


def test_lef_layer_preserves_confirmed_name_case_with_fixed_bump_pin() -> None:
    config = sample_round()
    config.layers[0].meaning = "AlPad"
    text = lef_text(config, build_layouts(config)[0])
    assert "  PIN BUMP\n" in text
    assert "      LAYER AlPad ;\n" in text
    assert "  END BUMP\n" in text


def test_center_origin_lef_omits_origin_and_keeps_foreign_coordinates() -> None:
    config = sample_round()
    config.origin_mode = OriginMode.CENTER
    layout = build_layouts(config)[0]
    text = lef_text(config, layout)

    assert f"  FOREIGN {layout.cell_name} -40.000 -40.000 ;" in text
    assert "  ORIGIN " not in text
    assert "  SIZE 80.000 BY 80.000 ;" in text


def test_oval_lef_uses_all_66_gds_nodes_for_each_angle() -> None:
    config = sample_oval()
    for layout in build_layouts(config):
        text = lef_text(config, layout)
        points = _lef_polygon_points(text)
        selected = next(
            layer
            for layer in layout.layers
            if layer.definition.uid == config.al_pad_layer_uid
        )
        assert len(points) == 66
        assert points == tuple(
            (
                Decimal(x) * config.dbu_um,
                Decimal(y) * config.dbu_um,
            )
            for x, y in selected.points_dbu
        )


def test_intended_paths_include_each_gds_lef_pair_and_one_report(tmp_path) -> None:
    paths = intended_paths(sample_oval(), tmp_path)
    assert len(paths) == 9
    assert [path.suffix for path in paths] == [
        ".gds",
        ".lef",
        ".gds",
        ".lef",
        ".gds",
        ".lef",
        ".gds",
        ".lef",
        ".pdf",
    ]


def test_failed_lef_verification_keeps_formal_output_empty(
    tmp_path,
    monkeypatch,
) -> None:
    import easybumpcell.services.batch_export as batch_export

    def fail_verification(*args, **kwargs):
        raise ValueError("synthetic LEF verification failure")

    monkeypatch.setattr(batch_export, "verify_lef", fail_verification)
    with pytest.raises(ValueError, match="synthetic LEF"):
        batch_export.export_project(sample_round(), tmp_path)
    assert list(tmp_path.iterdir()) == []
