from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE_DIRECTORY = ROOT / "ui"
OUTPUT_DIRECTORY = ROOT / "src" / "easybumpcell" / "ui_generated"
FORMS = ("main_window", "advanced_dialog", "export_dialog")


def main() -> int:
    sibling_name = "pyside6-uic.exe" if sys.platform == "win32" else "pyside6-uic"
    sibling = Path(sys.executable).parent / sibling_name
    executable = str(sibling) if sibling.is_file() else shutil.which("pyside6-uic")
    if not executable:
        print(
            "pyside6-uic was not found. Activate the project virtual environment first.",
            file=sys.stderr,
        )
        return 1
    OUTPUT_DIRECTORY.mkdir(parents=True, exist_ok=True)
    for form in FORMS:
        source = SOURCE_DIRECTORY / f"{form}.ui"
        destination = OUTPUT_DIRECTORY / f"ui_{form}.py"
        subprocess.run(
            [executable, str(source), "-o", str(destination)],
            check=True,
        )
        print(f"Generated {destination.relative_to(ROOT)}")
    init_file = OUTPUT_DIRECTORY / "__init__.py"
    if not init_file.exists():
        init_file.touch()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
