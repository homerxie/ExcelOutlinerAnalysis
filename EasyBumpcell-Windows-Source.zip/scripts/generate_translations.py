from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TRANSLATION_DIRECTORY = ROOT / "src" / "easybumpcell" / "translations"
TS_FILE = TRANSLATION_DIRECTORY / "easybumpcell_zh_CN.ts"
QM_FILE = TRANSLATION_DIRECTORY / "easybumpcell_zh_CN.qm"


def _tool(name: str) -> str:
    executable_name = f"{name}.exe" if sys.platform == "win32" else name
    sibling = Path(sys.executable).with_name(executable_name)
    executable = str(sibling) if sibling.is_file() else shutil.which(name)
    if executable is None:
        raise SystemExit(
            f"{name} was not found. Activate the project virtual environment first."
        )
    return executable


def main() -> None:
    sources = [
        *sorted((ROOT / "ui").glob("*.ui")),
        ROOT / "src" / "easybumpcell" / "i18n.py",
        *sorted((ROOT / "src" / "easybumpcell" / "ui").glob("*.py")),
    ]
    TRANSLATION_DIRECTORY.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [
            _tool("pyside6-lupdate"),
            "-tr-function-alias",
            "translate+=_translate",
            "-no-obsolete",
            *(str(source) for source in sources),
            "-ts",
            str(TS_FILE),
        ],
        check=True,
        cwd=ROOT,
    )
    subprocess.run(
        [
            _tool("pyside6-lrelease"),
            str(TS_FILE),
            "-qm",
            str(QM_FILE),
        ],
        check=True,
        cwd=ROOT,
    )


if __name__ == "__main__":
    main()
