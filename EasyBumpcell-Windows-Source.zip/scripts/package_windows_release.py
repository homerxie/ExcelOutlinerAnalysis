from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DIST_DIRECTORY = ROOT / "dist"
APPLICATION_DIRECTORY = DIST_DIRECTORY / "EasyBumpcell"
ARCHIVE_PATH = DIST_DIRECTORY / "EasyBumpcell-Windows.zip"


def _run(command: list[str]) -> None:
    print(f"> {subprocess.list2cmdline(command)}", flush=True)
    subprocess.run(command, check=True, cwd=ROOT)


def _pyinstaller_command() -> list[str]:
    return [
        sys.executable,
        "-m",
        "PyInstaller",
        "--noconfirm",
        "--clean",
        "--windowed",
        "--onedir",
        "--noupx",
        "--name",
        "EasyBumpcell",
        "--paths",
        "src",
        "--collect-data",
        "easybumpcell",
        "--distpath",
        "dist",
        "--workpath",
        "build/pyinstaller",
        "--specpath",
        "build/pyinstaller",
        "src/easybumpcell/app.py",
    ]


def _create_archive() -> None:
    if not APPLICATION_DIRECTORY.is_dir():
        raise SystemExit(
            f"PyInstaller output was not found: {APPLICATION_DIRECTORY}"
        )
    if ARCHIVE_PATH.exists():
        ARCHIVE_PATH.unlink()
    shutil.make_archive(
        str(ARCHIVE_PATH.with_suffix("")),
        "zip",
        root_dir=APPLICATION_DIRECTORY.parent,
        base_dir=APPLICATION_DIRECTORY.name,
    )
    print(f"Windows release package: {ARCHIVE_PATH}", flush=True)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Build and zip the EasyBumpcell Windows release."
    )
    parser.add_argument(
        "--skip-tests",
        action="store_true",
        help="Skip pytest (intended only after tests have already passed).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the PyInstaller command without building.",
    )
    arguments = parser.parse_args()

    if arguments.dry_run:
        print(subprocess.list2cmdline(_pyinstaller_command()))
        return 0
    if sys.platform != "win32":
        parser.error(
            "Windows releases must be built on Windows; "
            "PyInstaller does not cross-compile Windows executables."
        )

    _run([sys.executable, "scripts/generate_ui.py"])
    _run([sys.executable, "scripts/generate_translations.py"])
    if not arguments.skip_tests:
        _run([sys.executable, "-m", "pytest"])
    _run(_pyinstaller_command())
    _create_archive()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
