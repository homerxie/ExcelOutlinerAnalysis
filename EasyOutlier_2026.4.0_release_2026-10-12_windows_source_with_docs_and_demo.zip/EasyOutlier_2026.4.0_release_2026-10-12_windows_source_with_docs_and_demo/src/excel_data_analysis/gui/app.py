from __future__ import annotations

from datetime import datetime
from copy import deepcopy
from dataclasses import fields
from decimal import Decimal
import json
import os
import pickle
import multiprocessing as mp
from queue import Empty
import re
import shutil
import sys
from tempfile import TemporaryDirectory, TemporaryFile
from time import monotonic
import traceback
from uuid import uuid4
from pathlib import Path
import qdarktheme

from ..golden_rules import (
    OUTLIER_GOLDEN_METHOD_EXAMPLES,
    normalize_outlier_golden_method,
    outlier_golden_method_modifiers,
    outlier_golden_method_terms,
)
from ..gui_state import load_gui_state, save_gui_state
from ..database_save import save_database_job
from .. import compute_resources
from ..zscore_cache import get_shared_zscore_cache
from ..process_logging import (
    drain_process_logs, logged_process_entry, prepare_process_log_queue,
    subscribe_terminal_logs, unsubscribe_terminal_logs,
    write_terminal,
)
from .. import tsk_run_history
from ..tsk_analysis_state import (
    encode_analysis_snapshot, decode_analysis_snapshot, snapshot_bytes, write_analysis_snapshot,
)
from ..analysis_snapshot_state import (
    FORMAT as ANALYSIS_SNAPSHOT_FORMAT,
    decode_analysis_snapshot as decode_full_analysis_snapshot,
    save_analysis_snapshot,
)
from ..gui_paths import absolute_path, display_path, available_path, dialog_start, pack_paths, restore_paths
from ..output_paths import derive_split_output_paths, resolve_split_output_base_path
from ..measurement_storage import MeasurementStorage
from ..runtime import (
    APP_DISPLAY_NAME,
    APP_TEAM,
    APP_VERSION,
    app_root,
    package_root,
    bundled_template_path,
    default_database_root,
    default_output_path,
    icon_png_path,
)
from ..service import (
    SAMPLE_KEY_FILTER,
    build_column_filters,
    build_dimension_filters,
    delete_storage_workspace,
    create_golden_reference,
    delete_storage_import,
    delete_storage_rows,
    discard_storage_workspace_changes,
    describe_storage,
    ensure_storage_workspace,
    analyze_outlier_report_from_storage,
    export_outlier_report,
    export_data_report,
    list_outlier_export_nodes_from_storage,
    import_dataset,
    list_import_history,
    parse_csv_items,
    parse_filter_text,
    parse_semicolon_items,
    preview_import,
    save_debug_bundle,
    storage_workspace_differs,
    summarize_built_golden_coverage_for_storage,
)
from ..template import (
    OUTLIER_MERGE_ORDER_OPTIONS,
    load_template,
    save_template,
    summarize_template,
    validate_report_identity,
    template_to_payload,
)
from ..workspace import default_database_output_path
from ..summary_snapshot import (
    capture_summary_snapshot, summary_snapshot_error, summary_plot_context,
)
from .comparison_window import PlotInspectorContext, PlotInspectorWindow
from .loading import LoadingMixin
from .report_identity import ReportIdentityControls
from .result_table_model import OutlierRatioTableModel
from .table_filter import TableFilterController
from .outlier_export_dialog import OutlierExportDialog
from .analysis_output_dialog import AnalysisOutputDialog
from .summary_sample_navigation import OutlierSampleNavigator
from ..merge_config import normalize_merge_order, chain_level, column_levels, MERGE_RULE_FIELDS, initial_row_level, initial_column_level
from ..template_upgrade import save_template_atomically
from .ui_about_dialog import Ui_AboutDialog
from .ui_main_window import Ui_MainWindow
from .ui_analysis_settings_dialog import Ui_AnalysisSettingsDialog
from .ui_computation_settings_dialog import Ui_ComputationSettingsDialog
from .ui_analysis_scope_dialog import Ui_AnalysisScopeDialog
from .ui_template_edit_dialog import Ui_TemplateEditDialog
from .ui_tsk_completion_dialog import Ui_TskCompletionDialog
from .ui_tsk_delete_analysis_dialog import Ui_TskDeleteAnalysisDialog
from ..merge_config import validate_same_level_rules

try:
    from PySide6.QtCore import QDateTime, QSettings, QObject, QThread, QTimer, Qt, QUrl, Signal, Slot
    from PySide6.QtGui import QAction, QCloseEvent, QDesktopServices, QIcon, QPixmap
    from PySide6.QtWidgets import (
        QApplication,
        QDialog,
        QFileDialog,
        QInputDialog,
        QListWidgetItem,
        QMainWindow,
        QMenu,
        QMessageBox,
        QPushButton,
        QTableWidgetItem,
    )
except ImportError as exc:
    raise RuntimeError(
        "PySide6 is not installed yet. Activate the project virtual environment and install dependencies first."
    ) from exc


OUTLIER_CRITERIA_OPTIONS = [
    ("Modified Z Score", "modified_z_score"),
    ("Golden Deviation", "golden_deviation"),
    ("Modified Z Score And Golden Deviation", "zscore_and_golden"),
    ("Modified Z Score Or Golden Deviation", "zscore_or_golden"),
]
ANALYSIS_SCOPE_CODES = ("entire_database", "checked_imports")
CENTER_METHOD_OPTIONS = [
    ("Mean", "mean"),
    ("Median", "median"),
]
OUTLIER_GOLDEN_METHOD_OPTIONS = [
    (item, item) for item in OUTLIER_GOLDEN_METHOD_EXAMPLES
]
NUMERIC_CLEANUP_MODE_OPTIONS = [
    ("Remove All Non-Numeric Characters", "all_non_numeric"),
    ("Remove Specified Characters", "specified_chars"),
]
OUTLIER_MERGE_ORDER_GUI_OPTIONS = [(item, item) for item in OUTLIER_MERGE_ORDER_OPTIONS]


def _natural_sort_key(value: str) -> tuple[object, ...]:
    parts = re.split(r"(\d+)", str(value or ""))
    key: list[object] = []
    for part in parts:
        if not part:
            continue
        if part.isdigit():
            key.append((0, int(part)))
        else:
            key.append((1, part.lower()))
    return tuple(key)


class NaturalSortTableWidgetItem(QTableWidgetItem):
    def __lt__(self, other: object) -> bool:
        if not isinstance(other, QTableWidgetItem):
            return super().__lt__(other)
        return _natural_sort_key(self.text()) < _natural_sort_key(other.text())


class BackgroundTaskWorker(QObject):
    progress = Signal(int, str)
    finished = Signal(object)
    failed = Signal(str, str)

    def __init__(self, task_callable) -> None:
        super().__init__()
        self._task_callable = task_callable

    @Slot()
    def run(self) -> None:
        try:
            result = self._task_callable(self._report_progress)
        except Exception as exc:  # pragma: no cover - UI path
            self.failed.emit(str(exc), traceback.format_exc())
            return
        self.finished.emit(result)

    def _report_progress(self, value: int, message: str) -> None:
        self.progress.emit(value, message)


def _install_process_resources(payload: dict[str, object]) -> dict[str, object]:
    """Freeze GUI resource preferences without adding them to analysis inputs."""
    request = dict(payload)
    compute_resources.set_process_limit(request.pop("_compute_process_limit", 0))
    return request


def _read_analysis_zscore_cache(path: str | Path | None) -> None:
    """Merge only application-owned session files, never database/user files."""
    if not path:
        return
    try:
        with Path(path).open("rb") as handle:
            state = pickle.load(handle)
        get_shared_zscore_cache().import_state(state)
    except (OSError, pickle.PickleError, EOFError, ValueError, TypeError, AttributeError):
        # Cache transfer is optional; the analysis can rebuild a missing entry.
        return


def _write_analysis_zscore_cache(path: str | Path | None) -> str | None:
    if not path:
        return None
    target = Path(path)
    try:
        with target.open("wb") as handle:
            pickle.dump(get_shared_zscore_cache().export_state(), handle, protocol=pickle.HIGHEST_PROTOCOL)
    except (OSError, pickle.PickleError, ValueError, TypeError, AttributeError):
        return None
    return str(target)


@logged_process_entry
def _run_analysis_in_subprocess(payload: dict[str, object], result_queue) -> None:
    def send_progress(value: int, message: str) -> None:
        result_queue.put({"type": "progress", "value": value, "message": message})

    try:
        payload = _install_process_resources(payload)
        _read_analysis_zscore_cache(payload.get("_zscore_cache_input_path"))
        analysis_scope = str(payload["analysis_scope"])
        template_path = str(payload["template_path"])
        built_golden_path = payload.get("built_golden_path")
        if built_golden_path is not None:
            built_golden_path = str(built_golden_path)
        outlier_fail_method = payload.get("outlier_fail_method_override")
        if outlier_fail_method is not None:
            outlier_fail_method = str(outlier_fail_method)
        outlier_merge_order = payload.get("outlier_merge_order_override")
        if outlier_merge_order is not None:
            outlier_merge_order = str(outlier_merge_order)
        outlier_treat_empty_cells_as_fail = payload.get(
            "outlier_treat_empty_cells_as_fail_override"
        )
        if outlier_treat_empty_cells_as_fail is not None:
            outlier_treat_empty_cells_as_fail = bool(outlier_treat_empty_cells_as_fail)
        zscore_threshold_override = payload.get("zscore_threshold_override")
        dataset_ids = payload.get("dataset_ids")
        dimension_filters = payload.get("dimension_filters")
        column_filters = payload.get("column_filters")
        snapshot_path = Path(str(payload["snapshot_path"]))

        if analysis_scope not in ANALYSIS_SCOPE_CODES:
            raise ValueError("Unsupported analysis scope. Choose Entire Database or Selected Database.")
        if analysis_scope == "checked_imports" and not dataset_ids:
            raise ValueError("Please check at least one import entry to analyze.")
        if analysis_scope == "entire_database":
            dataset_ids = None
        storage_path = str(payload["storage_path"])
        golden_coverage_summary = None
        if built_golden_path:
            golden_coverage_summary = summarize_built_golden_coverage_for_storage(
                storage_path=storage_path,
                golden_path=built_golden_path,
                dataset_ids=dataset_ids,
                dimension_filters=dimension_filters,
                column_filters=column_filters,
                template_path=template_path,
                progress_callback=lambda value, message: send_progress(
                    min(18, max(2, value // 6)),
                    message,
                ),
            )
        send_progress(22, "Preparing analysis...")
        snapshot = analyze_outlier_report_from_storage(
            template_path=template_path,
            storage_path=storage_path,
            built_golden_path=built_golden_path,
            outlier_fail_method_override=outlier_fail_method,
            outlier_merge_order_override=outlier_merge_order,
            outlier_treat_empty_cells_as_fail_override=outlier_treat_empty_cells_as_fail,
            zscore_threshold_override=zscore_threshold_override,
            dataset_ids=dataset_ids,
            dimension_filters=dimension_filters,
            column_filters=column_filters,
            progress_callback=lambda value, message: send_progress(
                20 + int(value * 0.78),
                message,
            ),
        )
        # Keep the complete frozen analysis on disk, away from Qt and its IPC
        # queue. Export reads only this private, session-owned snapshot.
        outlier_artifacts = snapshot["summary_artifacts"]
        with snapshot_path.open("wb") as handle:
            pickle.dump(snapshot, handle, protocol=pickle.HIGHEST_PROTOCOL)
        send_progress(98, "Compressing completed analysis for database storage...")
        analysis_snapshot_path = snapshot_path.with_name("analysis.json.gz")
        save_analysis_snapshot(snapshot, analysis_snapshot_path)
        tsk_analysis_snapshot = encode_analysis_snapshot(snapshot)
        tsk_snapshot_path = snapshot_path.with_name("tsk-analysis.json.gz")
        write_analysis_snapshot(tsk_analysis_snapshot, tsk_snapshot_path)
        zscore_cache_path = _write_analysis_zscore_cache(payload.get("_zscore_cache_output_path"))
        send_progress(99, "Finalizing analysis result...")
        result_queue.put(
            {
                "type": "result",
                "ok": True,
                "payload": snapshot["result"],
                "snapshot_path": str(snapshot_path),
                "analysis_snapshot_path": str(analysis_snapshot_path),
                "tsk_analysis_snapshot": tsk_analysis_snapshot,
                "tsk_snapshot_path": str(tsk_snapshot_path),
                "zscore_cache_path": zscore_cache_path,
                "available_nodes": snapshot["available_nodes"],
                "analysis_template": snapshot.get("template"),
                "golden_coverage_summary": golden_coverage_summary,
                "outlier_summary_stats_rows": outlier_artifacts.get("summary_stats_rows", []),
                "outlier_ratio_rows": outlier_artifacts["ratio_rows"],
                "plot_inspector_snapshot": payload.get("plot_inspector_snapshot"),
            }
        )
    except Exception as exc:  # pragma: no cover - subprocess path
        result_queue.put(
            {
                "type": "result",
                "ok": False,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            }
        )


@logged_process_entry
def _run_report_export_in_subprocess(payload: dict[str, object], result_queue) -> None:
    def send_progress(value: int, message: str) -> None:
        result_queue.put({"type": "progress", "value": value, "message": message})

    try:
        payload = _install_process_resources(payload)
        snapshot_path = Path(str(payload["snapshot_path"]))
        if snapshot_path.name.endswith(".json.gz"):
            snapshot = decode_full_analysis_snapshot(snapshot_path.read_bytes())
        else:
            # Only the live, private session file uses pickle. Saved databases
            # restore data-only compressed JSON into a new private directory.
            with snapshot_path.open("rb") as handle:
                snapshot = pickle.load(handle)
        kwargs = {"snapshot": snapshot, "output_path": str(payload["temp_output_path"]),
                  "progress_callback": send_progress}
        if payload["kind"] == "outlier":
            result = export_outlier_report(**kwargs, scope=payload["scope"])
        elif payload["kind"] == "data":
            result = export_data_report(**kwargs)
        else:
            raise ValueError("Unsupported report export kind.")
        result_queue.put({"type": "result", "ok": True, "payload": result})
    except Exception as exc:
        result_queue.put({"type": "result", "ok": False, "error": str(exc),
                          "traceback": traceback.format_exc()})


@logged_process_entry
def _run_tsk_in_subprocess(payload: dict[str, object], result_queue) -> None:
    """Keep numerical solvers (including native code) outside the GUI process."""
    from ..tsk_service import analyze_tsk_workspace

    def send_progress(value: int, message: str) -> None:
        result_queue.put({"type": "progress", "value": value, "message": message})

    def send_activity(event: dict) -> None:
        result_queue.put({"type": "tsk_activity", "event": event})

    def send_partial_result(event: dict) -> None:
        result_queue.put({"type": "tsk_partial", "event": event})

    try:
        payload = _install_process_resources(payload)
        result = analyze_tsk_workspace(**payload, progress_callback=send_progress,
                                       activity_callback=send_activity, result_callback=send_partial_result)
        result_queue.put({"type": "result", "ok": True, "payload": result})
    except Exception as exc:
        result_queue.put({"type": "result", "ok": False, "error": str(exc),
                          "invalidates_fit": bool(getattr(exc, "invalidates_fit", False)),
                          "traceback": traceback.format_exc()})


@logged_process_entry
def _run_tsk_combinations_in_subprocess(payload: dict[str, object], result_queue) -> None:
    from ..tsk_service import analyze_tsk_combinations

    def send_progress(value: int, message: str) -> None:
        result_queue.put({"type": "progress", "value": value, "message": message})

    def send_activity(event: dict) -> None:
        result_queue.put({"type": "tsk_activity", "event": event})

    try:
        payload = _install_process_resources(payload)
        result = analyze_tsk_combinations(**payload, progress_callback=send_progress, activity_callback=send_activity)
        result_queue.put({"type": "result", "ok": True, "payload": result})
    except Exception as exc:
        result_queue.put({"type": "result", "ok": False, "error": str(exc),
                          "traceback": traceback.format_exc()})


@logged_process_entry
def _run_tsk_deletion_in_subprocess(payload: dict[str, object], result_queue) -> None:
    """Compute explicitly requested feature deletions from the frozen fit."""
    from ..tsk_feature_effects import compute_tsk_deletion_analysis

    started = monotonic()
    def activity(state, value, message):
        result_queue.put({"type": "tsk_activity", "event": {
            "event": "task", "group_id": "0", "group_label": payload.get("group_label", ""),
            "task_id": "deletion_analysis", "task_label": payload.get("task_label", ""),
            "state": state, "progress": value, "elapsed_seconds": monotonic() - started,
            "message": message}})

    def send_progress(value: float, message: str) -> None:
        result_queue.put({"type": "progress", "value": value, "message": message})
        activity("running", value, message)

    try:
        payload = _install_process_resources(payload)
        result = compute_tsk_deletion_analysis(
            payload["group"], progress_callback=send_progress,
            analysis_workers=payload.get("analysis_workers", 0))
        activity("completed", 100, result.get("reason", ""))
        result_queue.put({"type": "result", "ok": True, "payload": result})
    except Exception as exc:
        activity("failed", None, str(exc))
        result_queue.put({"type": "result", "ok": False, "error": str(exc),
                          "traceback": traceback.format_exc()})


class MainWindow(LoadingMixin, QMainWindow):
    terminal_message = Signal(str, str)

    def __init__(self, *, defer_loading: bool = True) -> None:
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.terminal_message.connect(self._append_terminal_message, Qt.ConnectionType.QueuedConnection)
        self._terminal_log_token = subscribe_terminal_logs(self.terminal_message.emit)
        token = self._terminal_log_token
        self.destroyed.connect(lambda: unsubscribe_terminal_logs(token))
        self._terminal_log_timer = QTimer(self)
        self._terminal_log_timer.setInterval(100)
        self._terminal_log_timer.timeout.connect(drain_process_logs)
        self._terminal_log_timer.start()
        self._outlier_ratio_model = OutlierRatioTableModel(self.ui.outlierRatioTableWidget)
        self._outlier_ratio_filter = TableFilterController(self.ui.outlierRatioTableWidget, self.ui.outlierRatioHeader)
        self.ui.outlierRatioTableWidget.setModel(self._outlier_ratio_model)
        self.ui.outlierRatioTableWidget.horizontalHeader().setResizeContentsPrecision(100)
        self._template_edit_unlocked = False
        self.identity_controls = ReportIdentityControls(self.ui.analysisGroupBox, fields=(
            self.ui.uniqueSampleIdFieldsEdit,
            self.ui.reliabilityNodeRowLevelComboBox,
            self.ui.chainColumnLevelComboBox,
        ))
        self.merge_controls = self.ui.outlierMergeControls
        self.ui.outlierMergeOrderComboBox.currentTextChanged.connect(self.merge_controls.reorder)
        self.identity_controls.node_combo.currentIndexChanged.connect(self._sync_merge_roles)
        self.identity_controls.chain_combo.currentIndexChanged.connect(self._sync_merge_roles)
        self._last_setup_splitter_sizes: list[int] | None = None
        self._setup_sidebar_before_tsk_details: tuple[bool, list[int]] | None = None
        self._ensure_help_menu()
        self._apply_window_icon()
        self._configure_combo_boxes()
        self.current_golden_coverage_summary: dict | None = None
        self.current_outlier_summary_rows: list[dict[str, object]] = []
        self.current_outlier_ratio_rows: list[dict[str, object]] = []
        self.current_plot_inspector_snapshot: dict | None = None
        self._summary_navigator = OutlierSampleNavigator(
            self.ui.outlierRatioTableWidget, self._outlier_ratio_model, self,
        )
        self._summary_navigator.sampleActivated.connect(self._open_summary_sample)
        self.current_tsk_result: dict | None = None
        self._tsk_stream_result: dict | None = None
        self._tsk_live_result: dict | None = None
        self._tsk_live_key: str | None = None
        self._tsk_viewing_live = False
        self._tsk_analysis_snapshot: dict | None = None
        self._tsk_snapshot_path: str | None = None
        self._restored_tsk_snapshot_directory: TemporaryDirectory | None = None
        self._tsk_snapshot_restore_error: str | None = None
        self.tsk_run_history = tsk_run_history.empty_history()
        self._pending_tsk_run_signature = None
        self._template_backed_golden_values: dict[str, float | None] = {
            "relative_limit": None,
            "sigma_multiplier": None,
            "mad_multiplier": None,
            "absolute_lower_bound": None,
            "absolute_upper_bound": None,
            "overwrite_lowerbound": None,
            "overwrite_upperbound": None,
            "continuous_interval": None,
        }
        self._template_analysis_dimension_filters: dict[str, dict[str, list[str]]] = {}
        self._template_analysis_column_filters: dict[str, dict[str, list[str]]] = {}
        self.current_storage_headers: list[str] = []
        self._storage_overview_payload: dict | None = None
        self.current_workspace_path: str = ""
        self._verbose_logging_enabled = False
        self._last_verbose_progress_signature: tuple[str | None, int, str] | None = None
        self._active_task_thread: QThread | None = None
        self._active_task_worker: BackgroundTaskWorker | None = None
        self._active_task_title: str | None = None
        self._active_task_success_handler = None
        self._background_task_outcome: tuple[str, object] | tuple[str, str, str] | None = None
        self._retained_background_workers: list[BackgroundTaskWorker] = []
        self._analysis_process: mp.Process | None = None
        self._analysis_process_title = "Run Analysis"
        self._analysis_process_success_handler = None
        self._analysis_tsk_monitor_generation = None
        self._tsk_monitor_generation = 0
        self._analysis_last_progress_at: float | None = None
        self._analysis_last_progress_message: str | None = None
        self._plot_inspector_window: PlotInspectorWindow | None = None
        self._plot_inspector_source_revisions: dict | None = None
        self._analysis_result_queue = None
        self._analysis_poll_timer = QTimer(self)
        self._analysis_poll_timer.setInterval(200)
        self._analysis_poll_timer.timeout.connect(self._poll_analysis_process)
        self._pending_tsk_result_state = None
        self._close_after_save_ready = False
        self._tsk_result_save_timer = QTimer(self)
        self._tsk_result_save_timer.setSingleShot(True)
        self._tsk_result_save_timer.timeout.connect(self._save_pending_tsk_result)
        self._analysis_final_output_path: str | None = None
        self._analysis_temp_output_path: str | None = None
        self._analysis_template_directory: TemporaryDirectory | None = None
        self._pending_outlier_snapshot_directory: TemporaryDirectory | None = None
        self._outlier_snapshot_directory: TemporaryDirectory | None = None
        self._outlier_snapshot_path: str | None = None
        self._analysis_snapshot_path: str | None = None
        self._analysis_snapshot_restore_error: str | None = None
        self._outlier_analysis_template = None
        self._outlier_export_result_id: str | None = None
        self._outlier_export_nodes: list[str] = []
        self._report_export_kind: str | None = None
        self._analysis_requested_exports: list[str] = []
        self._queued_report_exports: list[str] = []
        self._analysis_requested_outlier_scope: dict | None = None
        self._queued_outlier_export_scope: dict | None = None
        self._analysis_requested_export_paths: dict[str, str] = {}
        self._queued_report_export_paths: dict[str, str] = {}
        self._import_template_directory: TemporaryDirectory | None = None
        self._progress_bar = self.ui.taskProgressBar
        self._cancel_task_button = self.ui.cancelTaskButton
        self._setup_progress_widgets()
        self._wire_events()
        self._apply_defaults()
        self._recent_database_settings = QSettings("EasyOutlier", "EasyOutlier")
        self._load_computation_settings()
        self._recent_database_actions = []
        self._refresh_recent_databases()
        if defer_loading:
            self._set_template_edit_unlocked(False)
            self._set_busy_state(True, "准备打开数据库…")
            QTimer.singleShot(0, lambda: self._load_database_async(self._database_root_path()))
        else:
            self._ensure_storage_workspace_for_current_database(silent=True)
            self._prompt_workspace_recovery_if_needed()
            self._update_analysis_mode_state()
            self._refresh_analysis_imports(silent=True)
            self._refresh_storage_overview(silent=True)
            self._refresh_golden_coverage_view(None)
            self._refresh_outlier_summary_view([], [])
            self._load_saved_settings_for_current_database(silent=True)
            self._set_template_edit_unlocked(False)

    def _load_computation_settings(self) -> None:
        value = self._recent_database_settings.value(compute_resources.SETTINGS_KEY, 0)
        try:
            # Native and INI QSettings backends can return different scalar types.
            if isinstance(value, str):
                if re.fullmatch(r"[0-9]+", value.strip()) is None:
                    raise ValueError("Invalid saved process limit")
                value = int(value)
            value = compute_resources.validate_process_limit(value)
        except (TypeError, ValueError):
            value = 0
        self._process_worker_limit = min(value, compute_resources.available_process_limit())
        compute_resources.set_process_limit(self._process_worker_limit)

    def _show_computation_settings(self) -> None:
        dialog = QDialog(self)
        ui = Ui_ComputationSettingsDialog()
        ui.setupUi(dialog)
        topology = compute_resources.cpu_topology()
        maximum = min(compute_resources.available_process_limit(), topology["logical_cpus"])
        physical = topology.get("physical_cores")
        smt_property = ("smtAvailableText" if topology.get("smt_active") is True else
                        "smtUnavailableText" if topology.get("smt_active") is False else "smtUnknownText")
        ui.detectedCoresLabel.setText(ui.detectedCoresLabel.property("formatText").format(
            physical=physical or ui.detectedCoresLabel.property("unknownCountText"),
            logical=topology["logical_cpus"], smt=ui.detectedCoresLabel.property(smt_property), maximum=maximum))
        scope_property = ("primaryGroupText" if topology.get("affinity_scope") == "primary_processor_group" else
                          "restrictedAffinityText" if topology.get("affinity_limited") is True else
                          "unknownAffinityText" if topology.get("affinity_scope") == "system_affinity_unknown" else None)
        if scope_property is not None:
            ui.topologyScopeLabel.setText(ui.topologyScopeLabel.property(scope_property))
            ui.topologyScopeLabel.setVisible(True)
        budget_property = "formatText" if physical is not None else "fallbackFormatText"
        ui.autoWorkersDescriptionLabel.setText(ui.autoWorkersDescriptionLabel.property(budget_property).format(
            budget=compute_resources.automatic_tsk_budget(topology, process_limit=0)))
        ui.workerCountSpinBox.setMaximum(maximum)
        ui.workerCountSpinBox.setValue(max(1, self._process_worker_limit))
        custom = self._process_worker_limit > 0
        ui.autoWorkersRadioButton.setChecked(not custom)
        ui.customWorkersRadioButton.setChecked(custom)
        ui.workerCountSpinBox.setEnabled(custom)
        ui.customWorkersRadioButton.toggled.connect(ui.workerCountSpinBox.setEnabled)
        if dialog.exec() != QDialog.Accepted:
            return
        limit = ui.workerCountSpinBox.value() if ui.customWorkersRadioButton.isChecked() else 0
        self._recent_database_settings.setValue(compute_resources.SETTINGS_KEY, limit)
        self._recent_database_settings.sync()
        self._process_worker_limit = limit
        compute_resources.set_process_limit(limit)
        self.statusBar().showMessage("计算资源设置已保存，将用于后续分析任务和新打开的绘图窗口。", 7000)

    def _template_edit_widgets(self):
        # Lock containers where possible so child-specific enabled states survive.
        names = (
            "numericCleanupGroupBox", "outlierMergeControls",
            "referenceDimsEdit", "centerMethodComboBox", "thresholdModeComboBox",
            "relativeLimitSpinBox", "sigmaMultiplierSpinBox", "madMultiplierSpinBox",
            "absoluteLowerBoundEdit", "absoluteUpperBoundEdit",
            "overwriteMinEdit", "overwriteMaxEdit", "filtersEdit",
            "continuousIntervalCheckBox", "emptyRangeFallbackCheckBox",
            "uniqueSampleIdFieldsEdit", "reliabilityNodeRowLevelComboBox",
            "chainColumnLevelComboBox", "outlierFailModeComboBox",
            "outlierMergeOrderComboBox", "zThresholdSpinBox", "zscoreUseGoldenCheckBox", "emptyCellsFailCheckBox",
            "analysisSampleIdsEdit", "analysisExcludeSampleIdsEdit",
            "analysisNodesEdit", "analysisExcludeNodesEdit",
            "analysisTestsEdit", "analysisExcludeTestsEdit",
        )
        return tuple(getattr(self.ui, name) for name in names)

    def _confirm_template_edit(self) -> bool:
        dialog = QDialog(self)
        ui = Ui_TemplateEditDialog()
        ui.setupUi(dialog)
        return dialog.exec() == QDialog.Accepted

    def _on_template_edit_toggled(self, unlocked: bool) -> None:
        if unlocked and not self._confirm_template_edit():
            unlocked = False
        self._set_template_edit_unlocked(unlocked)

    def _set_template_edit_unlocked(self, unlocked: bool) -> None:
        self._template_edit_unlocked = unlocked
        button = self.ui.templateEditToggleButton
        previous = button.blockSignals(True)
        button.setChecked(unlocked)
        button.blockSignals(previous)
        state_property = "unlockedText" if unlocked else "lockedText"
        button.setText(button.property(state_property))
        self.ui.templateEditStateLabel.setText(self.ui.templateEditStateLabel.property(state_property))
        for widget in self._template_edit_widgets():
            widget.setEnabled(unlocked)
        self._update_numeric_cleanup_state()
        self._update_golden_threshold_mode_state()
        self._update_template_conversion_buttons()
        self._update_zscore_reference_state()

    def _ensure_help_menu(self) -> None:
        menu_bar = self.menuBar()
        menu_help = getattr(self.ui, "menuHelp", None)
        if menu_help is None:
            menu_help = QMenu("Help", self)
            menu_help.setObjectName("menuHelp")
            self.ui.menuHelp = menu_help

        action_about = getattr(self.ui, "actionAboutEasyOutlier", None)
        if action_about is None:
            action_about = QAction("About Easy Outlier", self)
            action_about.setObjectName("actionAboutEasyOutlier")
            self.ui.actionAboutEasyOutlier = action_about

        menu_help.setTitle("Help")
        action_about.setText("About Easy Outlier")

        if action_about not in menu_help.actions():
            menu_help.addAction(action_about)

        existing_menu_actions = {action.menu() for action in menu_bar.actions() if action.menu() is not None}
        if menu_help not in existing_menu_actions:
            menu_bar.addMenu(menu_help)

    def _wire_events(self) -> None:
        self.ui.outlierRatioSearchEdit.textChanged.connect(self._outlier_ratio_model.set_search_text)
        self._outlier_ratio_model.modelReset.connect(self._update_outlier_ratio_search_count)
        self.ui.outlierRatioClearFiltersButton.clicked.connect(self._outlier_ratio_model.clear_column_filters)
        self.ui.setupSidebarToggleButton.clicked.connect(self._toggle_setup_sidebar)
        self.ui.mainSplitter.splitterMoved.connect(self._on_setup_splitter_moved)
        self.ui.resultTabWidget.currentChanged.connect(self._sync_tsk_detail_layout)
        self.ui.tskResultsPanel.detail_visibility_changed.connect(self._sync_tsk_detail_layout)
        self.ui.templateEditToggleButton.toggled.connect(self._on_template_edit_toggled)
        self.ui.actionOpenDatabase.triggered.connect(self._browse_storage)
        self.ui.actionClearRecentDatabases.triggered.connect(self._clear_recent_databases)
        self.ui.actionSaveDatabase.triggered.connect(self._save_database)
        self.ui.actionSaveDatabaseAs.triggered.connect(self._save_database_as)
        self.ui.actionVerboseLogging.toggled.connect(self._on_verbose_logging_toggled)
        self.ui.actionAboutEasyOutlier.triggered.connect(self._show_about_dialog)
        self.ui.actionComputationSettings.triggered.connect(self._show_computation_settings)
        self.ui.browseTemplateButton.clicked.connect(self._browse_template)
        self.ui.validateTemplateButton.clicked.connect(self._validate_template)
        self.ui.exportTemplateJsonButton.clicked.connect(self._export_template_json)
        self.ui.exportTemplateExcelButton.clicked.connect(self._export_template_excel)
        self.ui.saveDebugBundleButton.clicked.connect(self._save_debug_bundle)
        self.ui.browseInputButton.clicked.connect(self._browse_input)
        self.ui.browseStorageButton.clicked.connect(self._browse_storage)
        self.ui.browseGoldenButton.clicked.connect(self._browse_golden)
        self.ui.browseOutputButton.clicked.connect(self._browse_output)
        self.ui.importButton.clicked.connect(self._import_dataset)
        self.ui.refreshStorageViewButton.clicked.connect(self._refresh_storage_overview)
        self.ui.deleteSelectedRowsButton.clicked.connect(self._delete_selected_storage_rows)
        self.ui.deleteCurrentSourceButton.clicked.connect(self._delete_current_storage_source)
        self.ui.storageImportComboBox.currentIndexChanged.connect(self._render_storage_snapshot)
        self.identity_controls.node_combo.currentIndexChanged.connect(self._render_storage_snapshot)
        self.ui.storageTableWidget.itemSelectionChanged.connect(
            lambda: self.ui.deleteSelectedRowsButton.setEnabled(bool(self._selected_storage_row_selectors()))
        )
        self.ui.refreshAnalysisImportsButton.clicked.connect(self._refresh_analysis_imports)
        self.ui.buildGoldenButton.clicked.connect(self._build_golden)
        self.ui.runAnalysisButton.clicked.connect(self._run_analysis)
        self.ui.exportOutlierButton.clicked.connect(self._export_outlier_report)
        self.ui.exportDataButton.clicked.connect(self._export_data_report)
        self.ui.tskAnalysisPanel.run_requested.connect(self._run_tsk_analysis)
        self.ui.tskAnalysisPanel.mode_selected.connect(self._show_cached_tsk_mode)
        self.ui.tskAnalysisPanel.save_html_requested.connect(self._export_tsk_html_results)
        self.ui.tskResultsPanel.result_available_changed.connect(self.ui.tskAnalysisPanel.set_result_available)
        self.ui.tskAnalysisPanel.refresh_requested.connect(self._refresh_analysis_imports)
        self.ui.tskAnalysisPanel.batch_scan_requested.connect(self._scan_tsk_batches)
        self.ui.tskResultsPanel.export_requested.connect(self._export_tsk_results)
        self.ui.tskResultsPanel.coordinate_preview_requested.connect(self._load_tsk_coordinate_preview)
        self.ui.tskResultsPanel.saved_analysis_selected.connect(self._activate_saved_tsk_analysis)
        self.ui.tskResultsPanel.saved_analysis_delete_requested.connect(self._delete_saved_tsk_analysis)
        self.ui.tskResultsPanel.combination_requested.connect(self._run_tsk_combinations)
        self.ui.tskResultsPanel.ui.featureEffectsPanel.deletion_analysis_requested.connect(
            self._run_tsk_deletion_analysis)
        self.ui.tskResultsPanel.full_combination_requested.connect(self._confirm_tsk_combination_completion)
        self.ui.outlierFailModeComboBox.currentIndexChanged.connect(self._sync_tsk_fail_rules)
        self.ui.outlierFailModeComboBox.currentIndexChanged.connect(self._update_zscore_reference_state)
        self.ui.zscoreUseGoldenCheckBox.toggled.connect(self._sync_tsk_fail_rules)
        self.ui.zThresholdSpinBox.valueChanged.connect(self._sync_tsk_fail_rules)
        self.ui.emptyCellsFailCheckBox.toggled.connect(self._sync_tsk_fail_rules)
        self.ui.outlierMergeOrderComboBox.currentIndexChanged.connect(self._sync_tsk_fail_rules)
        self.merge_controls.changed.connect(self._sync_tsk_fail_rules)
        self.identity_controls.node_combo.currentIndexChanged.connect(self._sync_tsk_fail_rules)
        self.identity_controls.chain_combo.currentIndexChanged.connect(self._sync_tsk_fail_rules)
        self.ui.openPlotInspectorButton.clicked.connect(self._open_plot_inspector)
        self.ui.analysisScopeComboBox.currentTextChanged.connect(self._update_analysis_mode_state)
        self.ui.thresholdModeComboBox.currentTextChanged.connect(self._update_golden_threshold_mode_state)
        self.ui.numericCleanupCheckBox.toggled.connect(self._update_numeric_cleanup_state)
        self.ui.numericCleanupModeComboBox.currentTextChanged.connect(self._update_numeric_cleanup_state)
        self.ui.templatePathEdit.textChanged.connect(self._update_template_conversion_buttons)
        for widget in (self.ui.templatePathEdit, self.ui.inputPathEdit, self.ui.storagePathEdit,
                       self.ui.goldenPathEdit, self.ui.outputPathEdit):
            widget.editingFinished.connect(
                lambda widget=widget: widget.setText(self._display_path(widget.text().strip()))
            )
            widget.setToolTip("Relative paths use the application folder: " + str(app_root()))
        self._connect_optional_button("openTemplateButton", self._open_template_file)
        self._connect_optional_button("openInputButton", self._open_input_file)
        self._connect_optional_button("openGoldenButton", self._open_golden_file)
        self._connect_optional_button("openDatabaseButton", self._open_database_folder)
        self._connect_optional_button("openResultButton", self._open_result_folder)

    def _setup_sidebar_expanded(self) -> bool:
        sizes = self.ui.mainSplitter.sizes()
        return not self.ui.leftPanel.isHidden() and (not any(sizes) or sizes[0] > 0)

    def _sync_setup_sidebar_button(self) -> None:
        button = self.ui.setupSidebarToggleButton
        button.setText(button.property("collapseText" if self._setup_sidebar_expanded() else "expandText"))

    def _on_setup_splitter_moved(self, *_args) -> None:
        sizes = self.ui.mainSplitter.sizes()
        if self._setup_sidebar_expanded() and sizes[0] > 0:
            self._last_setup_splitter_sizes = sizes
        self._sync_setup_sidebar_button()

    def _set_setup_sidebar_expanded(self, expanded: bool, sizes: list[int] | None = None) -> None:
        current_sizes = self.ui.mainSplitter.sizes()
        if self._setup_sidebar_expanded() and current_sizes[0] > 0:
            self._last_setup_splitter_sizes = current_sizes
        self.ui.leftPanel.setVisible(expanded)
        if expanded:
            restored = sizes or self._last_setup_splitter_sizes
            if not restored or restored[0] <= 0:
                width = int(self.ui.mainSplitter.property("defaultSetupWidth"))
                restored = [width, max(width, self.ui.mainSplitter.width() - width)]
            self.ui.mainSplitter.setSizes(restored)
        self._sync_setup_sidebar_button()

    def _toggle_setup_sidebar(self) -> None:
        self._set_setup_sidebar_expanded(not self._setup_sidebar_expanded())

    def _sync_tsk_detail_layout(self, *_args) -> None:
        if self._analysis_tsk_monitor_generation is not None:
            # Preserve the user's sidebar choice while a readable monitor is
            # active; result-detail updates must not automatically hide it.
            return
        details_active = (self.ui.resultTabWidget.currentWidget() is self.ui.tskResultsTab
                          and self.ui.tskResultsPanel.detail_visible)
        if details_active and self._setup_sidebar_before_tsk_details is None:
            self._setup_sidebar_before_tsk_details = (
                self._setup_sidebar_expanded(), self.ui.mainSplitter.sizes(),
            )
            self._set_setup_sidebar_expanded(False)
        elif not details_active and self._setup_sidebar_before_tsk_details is not None:
            expanded, sizes = self._setup_sidebar_before_tsk_details
            self._setup_sidebar_before_tsk_details = None
            self._set_setup_sidebar_expanded(expanded, sizes)

    def _saved_main_splitter_sizes(self) -> list[int]:
        # Opening result details is temporary and must not become the saved layout.
        if self._setup_sidebar_before_tsk_details is not None:
            return self._setup_sidebar_before_tsk_details[1]
        return self.ui.mainSplitter.sizes()

    def _apply_window_icon(self) -> None:
        icon_path = icon_png_path()
        if icon_path is None:
            return
        icon = QIcon(str(icon_path))
        self.setWindowIcon(icon)
        app = QApplication.instance()
        if app is not None:
            app.setWindowIcon(icon)

    def _show_about_dialog(self) -> None:
        dialog = AboutDialog(self)
        dialog.exec()

    def _setup_progress_widgets(self) -> None:
        self._cancel_task_button.clicked.connect(self._cancel_analysis_process)
        self._progress_bar.hide()
        self._cancel_task_button.hide()
        self.statusBar().addPermanentWidget(self._progress_bar)
        self.statusBar().addPermanentWidget(self._cancel_task_button)

    def _update_numeric_cleanup_state(self) -> None:
        enabled = self.ui.numericCleanupCheckBox.isChecked()
        mode = self._combo_code(self.ui.numericCleanupModeComboBox)
        self.ui.numericCleanupModeComboBox.setEnabled(enabled)
        self.ui.numericCleanupCharsEdit.setEnabled(enabled and mode == "specified_chars")

    def _update_template_conversion_buttons(self) -> None:
        suffix = Path(self._path_value(self.ui.templatePathEdit)).suffix.lower()
        disable_to_xlsx = suffix == ".xlsx"
        disable_to_json = suffix == ".json"
        self.ui.exportTemplateJsonButton.setEnabled(self._template_edit_unlocked and not disable_to_xlsx)
        self.ui.exportTemplateExcelButton.setEnabled(self._template_edit_unlocked and not disable_to_json)

    def _set_busy_state(self, busy: bool, title: str | None = None) -> None:
        self._update_report_export_state(busy=busy)
        self.ui.templateEditToggleButton.setEnabled(not busy)
        monitor_running = busy and title in {"TSK Risk Analysis", "TSK Combination Analysis", "TSK Deletion Analysis"}
        self.ui.workbenchTabWidget.setEnabled(not busy or monitor_running)
        for index in range(self.ui.workbenchTabWidget.count()):
            page = self.ui.workbenchTabWidget.widget(index)
            page.setEnabled(not busy or (monitor_running and page is self.ui.tskAnalysisTab))
        self.ui.tskAnalysisPanel.set_analysis_busy(busy)
        self.ui.actionOpenDatabase.setEnabled(not busy)
        self.ui.menuRecentDatabases.setEnabled(not busy)
        self.ui.actionSaveDatabase.setEnabled(not busy)
        self.ui.actionSaveDatabaseAs.setEnabled(not busy)
        self.ui.tskResultsPanel.set_combination_busy(busy)
        self.ui.tskResultsPanel.set_history_busy(busy)
        self.ui.tskResultsPanel.ui.featureEffectsPanel.set_busy(busy)
        self._last_verbose_progress_signature = None
        if busy:
            self._progress_bar.setRange(0, 0)
            self._progress_bar.show()
            self._cancel_task_button.setVisible(self._analysis_process is not None)
            self.statusBar().showMessage(title or "Working...")
        else:
            self._progress_bar.hide()
            self._cancel_task_button.hide()
            self._progress_bar.setRange(0, 100)
            self._progress_bar.setValue(0)

    def _update_task_progress(self, value: int, message: str) -> None:
        if value < 0:
            self._progress_bar.setRange(0, 0)
        else:
            if self._progress_bar.maximum() == 0:
                self._progress_bar.setRange(0, 100)
            self._progress_bar.setValue(max(0, min(100, value)))
        self.statusBar().showMessage(message)
        # Keep the full numerical progress readable when the status line is
        # narrower than the current fit/condition diagnostics.
        self.statusBar().setToolTip(message)
        self._progress_bar.setToolTip(message)

    def _start_background_task(
        self,
        title: str,
        task_callable,
        success_handler,
    ) -> None:
        if self._active_task_thread is not None or self._analysis_process is not None:
            QMessageBox.information(
                self,
                "Task Running",
                "Another background task is still running. Please wait for it to finish first.",
            )
            return
        thread = QThread(self)
        worker = BackgroundTaskWorker(task_callable)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._update_task_progress)
        worker.finished.connect(self._store_background_task_success)
        worker.failed.connect(self._store_background_task_failure)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(self._on_background_task_thread_finished)
        thread.finished.connect(thread.deleteLater)
        self._active_task_thread = thread
        self._active_task_worker = worker
        self._active_task_title = title
        self._active_task_success_handler = success_handler
        self._background_task_outcome = None
        self._set_busy_state(True, title)
        thread.start()

    def _clear_background_task(self) -> None:
        self._active_task_thread = None
        self._active_task_worker = None
        self._active_task_title = None
        self._active_task_success_handler = None
        self._background_task_outcome = None
        self._set_busy_state(False)

    @Slot(object)
    def _store_background_task_success(self, result) -> None:
        self._background_task_outcome = ("success", result)

    @Slot(str, str)
    def _store_background_task_failure(self, message: str, details: str) -> None:
        self._background_task_outcome = ("failure", message, details)

    @Slot()
    def _on_background_task_thread_finished(self) -> None:
        title = self._active_task_title or "Task"
        success_handler = self._active_task_success_handler
        worker = self._active_task_worker
        outcome = self._background_task_outcome
        if worker is not None:
            self._retained_background_workers.append(worker)
        self._clear_background_task()
        if outcome is None or outcome[0] == "failure":
            if title in {"Import Preview", "Import Dataset"}:
                self._cleanup_import_template()
        if outcome is None:
            self._log(f"{title} failed:\nBackground task finished without emitting a result.")
            QMessageBox.critical(
                self,
                f"{title} failed",
                "Background task finished without emitting a result.",
            )
            self.statusBar().showMessage(f"{title} failed", 5000)
            return
        if outcome[0] == "success":
            if success_handler is None:
                return
            try:
                success_handler(outcome[1])
            except Exception as exc:  # pragma: no cover - UI path
                if title in {"Import Preview", "Import Dataset"}:
                    self._cleanup_import_template()
                self._show_error(f"{title} post-processing failed", exc)
            return
        message = str(outcome[1])
        details = str(outcome[2])
        if title == "TSK Risk Analysis":
            self.ui.tskResultsPanel.clear_result(message)
        self._log(f"{title} failed:\n{details}")
        write_terminal(f"{title} failed: {message}\n")
        if details:
            write_terminal(details + "\n")
        QMessageBox.critical(self, f"{title} failed", message)
        self.statusBar().showMessage(f"{title} failed", 5000)

    def _start_analysis_process(self, payload: dict[str, object]) -> None:
        if self._active_task_thread is not None or self._analysis_process is not None:
            QMessageBox.information(
                self,
                "Task Running",
                "Another task is still running. Please wait for it to finish first.",
            )
            return
        payload = dict(payload)
        self._analysis_requested_exports = list(payload.pop("export_kinds", []))
        self._analysis_requested_outlier_scope = deepcopy(payload.pop("outlier_export_scope", None))
        self._analysis_requested_export_paths = dict(payload.pop("export_paths", {}))
        payload.pop("output_base_path", None)
        if any(kind not in self._analysis_requested_export_paths for kind in self._analysis_requested_exports):
            raise ValueError("Confirm all Excel output paths before starting analysis.")
        payload["plot_inspector_snapshot"] = capture_summary_snapshot(payload)
        if "template_payload" in payload:
            self._analysis_template_directory = TemporaryDirectory(prefix="easy-outlier-analysis-")
            runtime_path = Path(self._analysis_template_directory.name) / "template.json"
            try:
                runtime_path.write_text(json.dumps(payload.pop("template_payload"), ensure_ascii=False), encoding="utf-8")
            except Exception:
                self._analysis_template_directory.cleanup()
                self._analysis_template_directory = None
                raise
            payload["template_path"] = str(runtime_path)
        self._pending_outlier_snapshot_directory = TemporaryDirectory(prefix="easy-outlier-result-")
        snapshot_directory = Path(self._pending_outlier_snapshot_directory.name)
        payload["snapshot_path"] = str(snapshot_directory / "analysis.pickle")
        payload["_zscore_cache_input_path"] = _write_analysis_zscore_cache(
            snapshot_directory / "zscore-cache-input.pickle"
        )
        payload["_zscore_cache_output_path"] = str(snapshot_directory / "zscore-cache-output.pickle")
        self._start_process_task("Run Analysis", _run_analysis_in_subprocess, payload)

    def _start_tsk_process(self, payload: dict[str, object]) -> None:
        self._tsk_stream_result = None
        self._tsk_live_result = None
        self._tsk_live_key = None
        self._tsk_viewing_live = True
        self.ui.tskResultsPanel.set_live_analysis_available(False)
        self._start_process_task("TSK Risk Analysis", _run_tsk_in_subprocess,
                                 {**payload, "include_all_combinations": True},
                                 self._handle_tsk_analysis_completed)

    def _begin_tsk_task_monitor(self, title):
        if title not in {"TSK Risk Analysis", "TSK Combination Analysis", "TSK Deletion Analysis"}:
            return None
        self._tsk_monitor_generation += 1
        self.ui.tskAnalysisPanel.begin_task_monitor(title=title)
        # Select the monitor's page without changing result tabs or reopening
        # a sidebar the user deliberately collapsed.
        self.ui.workbenchTabWidget.setCurrentWidget(self.ui.tskAnalysisTab)
        return self._tsk_monitor_generation

    def _finish_tsk_task_monitor(self, generation, state, message):
        # A success handler can start another calculation before it returns.
        # Never apply the old task's terminal event to that new monitor.
        if generation is not None and generation == self._tsk_monitor_generation:
            self.ui.tskAnalysisPanel.finish_task_monitor(state, message)

    def _start_process_task(self, title, target, payload, success_handler=None) -> None:
        if self._active_task_thread is not None or self._analysis_process is not None:
            QMessageBox.information(
                self, "Task Running",
                "Another task is still running. Please wait for it to finish first.",
            )
            return
        monitor_generation = self._begin_tsk_task_monitor(title)
        try:
            ctx = mp.get_context("spawn")
            self._analysis_result_queue = prepare_process_log_queue(ctx.Queue())
            payload = {**payload, "_compute_process_limit": self._process_worker_limit}
            process = ctx.Process(
                target=target,
                args=(payload, self._analysis_result_queue),
            )
            self._analysis_process = process
            self._analysis_process_title = title
            self._analysis_process_success_handler = success_handler
            self._analysis_tsk_monitor_generation = monitor_generation
            self._set_busy_state(True, title)
            self._progress_bar.setRange(0, 100)
            self._progress_bar.setValue(0)
            self.statusBar().showMessage("Starting analysis process...")
            self._analysis_last_progress_at = monotonic()
            self._analysis_last_progress_message = self.statusBar().currentMessage()
            self._cancel_task_button.show()
            if title in {"TSK Risk Analysis", "TSK Combination Analysis", "TSK Deletion Analysis"}:
                from ..tsk_parallel import start_tsk_process
                start_tsk_process(process)
            else:
                process.start()
        except Exception as exc:
            self._cleanup_analysis_process_state()
            self._cleanup_analysis_temp_output()
            self._finish_tsk_task_monitor(monitor_generation, "failed", str(exc))
            raise
        self._analysis_poll_timer.start()

    def _poll_analysis_process(self) -> None:
        if self._analysis_process is None or self._analysis_result_queue is None:
            self._analysis_poll_timer.stop()
            return
        result = None
        title = self._analysis_process_title
        success_handler = self._analysis_process_success_handler
        monitor_generation = self._analysis_tsk_monitor_generation
        try:
            # Yield to painting/input even when the solver emits many updates.
            for _ in range(100):
                item = self._analysis_result_queue.get_nowait()
                if item.get("type") == "log":
                    self._append_terminal_message(str(item.get("stream", "stdout")),
                                                  str(item.get("message", "")))
                    continue
                if item.get("type") == "progress":
                    self._analysis_last_progress_at = monotonic()
                    self._analysis_last_progress_message = str(item.get("message", "Running analysis..."))
                    self._update_task_progress(
                        int(item.get("value", -1)),
                        self._analysis_last_progress_message,
                    )
                    continue
                if item.get("type") == "tsk_activity":
                    event = item.get("event")
                    if monitor_generation is not None and isinstance(event, dict):
                        self._analysis_last_progress_at = monotonic()
                        self.ui.tskAnalysisPanel.update_task_monitor(event)
                    continue
                if item.get("type") == "tsk_partial":
                    if title == "TSK Risk Analysis" and isinstance(item.get("event"), dict):
                        self._handle_tsk_partial_result(item["event"])
                    continue
                result = item
                break
        except Empty:
            if self._analysis_process.is_alive():
                self._refresh_analysis_waiting_progress()
                return
            self._analysis_poll_timer.stop()
            exit_code = self._analysis_process.exitcode
            self._cleanup_analysis_process_state()
            self._cleanup_analysis_temp_output()
            message = (f"Background analysis process exited with code {exit_code}."
                       if exit_code not in {0, None} else
                       "Background task finished without emitting a result.")
            self._finish_tsk_task_monitor(monitor_generation, "failed", message)
            self._show_process_failure(title, message)
            return
        if result is None:
            self._refresh_analysis_waiting_progress()
            return
        self._analysis_poll_timer.stop()
        self._analysis_process.join(timeout=1)
        self._cleanup_analysis_process_state()
        if not result.get("ok"):
            self._cleanup_analysis_temp_output()
            details = str(result.get("traceback", ""))
            message = str(result.get("error", "Run Analysis failed"))
            self._finish_tsk_task_monitor(monitor_generation, "failed", message)
            self._show_process_failure(title, message, details,
                                       invalidates_fit=bool(result.get("invalidates_fit")))
            return
        if success_handler is not None:
            try:
                success_handler(result["payload"])
            except Exception as exc:
                self._cleanup_analysis_temp_output()
                self._finish_tsk_task_monitor(monitor_generation, "failed", str(exc))
                self._show_process_failure(title, str(exc), traceback.format_exc())
            else:
                self._finish_tsk_task_monitor(monitor_generation, "completed", f"{title} completed.")
            return
        self._handle_run_analysis_completed(
            {
                "payload": result["payload"],
                "snapshot_path": result.get("snapshot_path"),
                "analysis_snapshot_path": result.get("analysis_snapshot_path"),
                "tsk_analysis_snapshot": result.get("tsk_analysis_snapshot"),
                "tsk_snapshot_path": result.get("tsk_snapshot_path"),
                "zscore_cache_path": result.get("zscore_cache_path"),
                "available_nodes": result.get("available_nodes", []),
                "analysis_template": result.get("analysis_template"),
                "golden_coverage_summary": result["golden_coverage_summary"],
                "outlier_summary_stats_rows": result.get("outlier_summary_stats_rows", []),
                "outlier_ratio_rows": result["outlier_ratio_rows"],
                "plot_inspector_snapshot": result.get("plot_inspector_snapshot"),
            }
        )

    def _refresh_analysis_waiting_progress(self) -> None:
        if self._analysis_last_progress_at is None or self._analysis_last_progress_message is None:
            return
        seconds = int(monotonic() - self._analysis_last_progress_at)
        if seconds < 5:
            return
        message = f"{self._analysis_last_progress_message} · 距上次计算进度更新 {seconds}s"
        if self.statusBar().currentMessage() != message:
            # This timer reports elapsed silence only; it cannot establish
            # solver progress and must not advance the percentage.
            self.statusBar().showMessage(message)
            self.statusBar().setToolTip(message)
            self._progress_bar.setToolTip(message)

    def _clear_report_export_requests(self) -> None:
        self._analysis_requested_exports = []
        self._queued_report_exports = []
        self._analysis_requested_outlier_scope = None
        self._queued_outlier_export_scope = None
        self._analysis_requested_export_paths = {}
        self._queued_report_export_paths = {}

    def _show_process_failure(self, title, message, details="", *, invalidates_fit=False) -> None:
        self._clear_report_export_requests()
        if title == "TSK Risk Analysis":
            self._pending_tsk_run_signature = None
            self._finish_tsk_partial_result(message, invalidates_fit=invalidates_fit)
            if self.current_tsk_result is None:
                self.ui.tskResultsPanel.clear_result(message)
        elif title == "TSK Combination Analysis":
            self.ui.tskResultsPanel.finish_combination_request()
        self._log(f"{title} failed:\n{details or message}")
        QMessageBox.critical(self, f"{title} failed", message)
        self.statusBar().showMessage(f"{title} failed", 5000)

    def _cancel_analysis_process(self) -> None:
        process = self._analysis_process
        if process is None:
            return
        response = QMessageBox.question(
            self,
            "Cancel Task",
            (
                "Stop the current task?\n\n"
                "This will terminate the background process and remove unfinished temporary files. "
                "The database will not be modified."
            ),
            QMessageBox.Yes | QMessageBox.Cancel,
            QMessageBox.Cancel,
        )
        # The modal dialog runs a nested event loop; the task can finish while
        # the user decides. Never cancel a completed (or replacement) process.
        if response != QMessageBox.Yes or self._analysis_process is not process:
            return
        title = self._analysis_process_title
        monitor_generation = self._analysis_tsk_monitor_generation
        self._clear_report_export_requests()
        self._analysis_poll_timer.stop()
        if process.is_alive():
            process.terminate()
            process.join(timeout=2)
            if process.is_alive():
                process.kill()
                process.join(timeout=2)
        self._cleanup_analysis_process_state()
        self._cleanup_analysis_temp_output()
        self._finish_tsk_task_monitor(monitor_generation, "cancelled", f"{title} cancelled.")
        if title == "TSK Risk Analysis":
            self._pending_tsk_run_signature = None
            self._finish_tsk_partial_result("用户已停止后续计算。")
            if self.current_tsk_result is None:
                self.ui.tskResultsPanel.clear_result("TSK analysis cancelled.")
        elif title == "TSK Combination Analysis":
            self.ui.tskResultsPanel.finish_combination_request()
        self._log(f"{title} cancelled by user.")
        self.statusBar().showMessage("Analysis cancelled.", 5000)

    def _cleanup_analysis_process_state(self) -> None:
        process = self._analysis_process
        result_queue = self._analysis_result_queue
        self._analysis_process = None
        self._analysis_result_queue = None
        self._analysis_process_title = "Run Analysis"
        self._analysis_process_success_handler = None
        self._analysis_tsk_monitor_generation = None
        self._analysis_last_progress_at = None
        self._analysis_last_progress_message = None
        self.statusBar().setToolTip("")
        self._progress_bar.setToolTip("")
        if result_queue is not None:
            result_queue.close()
        if process is not None and not process.is_alive():
            if process.pid is not None:
                process.join(timeout=0)
            process.close()
        if self._analysis_template_directory is not None:
            self._analysis_template_directory.cleanup()
            self._analysis_template_directory = None
        self._set_busy_state(False)

    def _prepare_analysis_temp_output_path(self, final_output_path: str) -> str:
        target = Path(final_output_path)
        return str(
            target.with_name(f"{target.stem}.__running__.{uuid4().hex}{target.suffix}")
        )

    def _finalize_analysis_output_file(self) -> None:
        if not self._analysis_temp_output_path or not self._analysis_final_output_path:
            return
        if self._report_export_kind:
            temp_paths = {self._report_export_kind: Path(self._analysis_temp_output_path)}
            final_paths = {self._report_export_kind: Path(self._analysis_final_output_path)}
        else:
            temp_paths = derive_split_output_paths(self._analysis_temp_output_path)
            final_paths = derive_split_output_paths(self._analysis_final_output_path)
        for key, temp_path in temp_paths.items():
            final_path = final_paths[key]
            if not temp_path.exists():
                raise FileNotFoundError(f"Report output was not created: {temp_path}")
            final_path.parent.mkdir(parents=True, exist_ok=True)
            temp_path.replace(final_path)
        self._analysis_temp_output_path = None
        self._analysis_final_output_path = None
        self._report_export_kind = None

    def _cleanup_analysis_temp_output(self) -> None:
        if self._pending_outlier_snapshot_directory is not None:
            self._pending_outlier_snapshot_directory.cleanup()
            self._pending_outlier_snapshot_directory = None
        if not self._analysis_temp_output_path:
            return
        paths = ([Path(self._analysis_temp_output_path)] if self._report_export_kind else
                 derive_split_output_paths(self._analysis_temp_output_path).values())
        for temp_path in paths:
            if temp_path.exists():
                try:
                    temp_path.unlink()
                except OSError:
                    pass
        self._analysis_temp_output_path = None
        self._analysis_final_output_path = None
        self._report_export_kind = None

    def closeEvent(self, event: QCloseEvent) -> None:
        if self._active_task_thread is not None or self._analysis_process is not None:
            QMessageBox.information(
                self,
                "Task Running",
                "A background task is still running. Please wait for it to finish before closing the window.",
            )
            event.ignore()
            return
        if self._close_after_save_ready:
            self._cleanup_import_template()
            self._close_terminal_logging()
            event.accept()
            return
        if self._pending_tsk_result_state is not None:
            self._tsk_result_save_timer.stop()
            pending = self._pending_tsk_result_state
            root, payload = pending

            def save_pending(progress):
                progress(-1, "Saving pending TSK results")
                target = save_gui_state(root, payload)
                progress(100, "TSK results saved")
                return target

            def pending_saved(_target):
                if self._pending_tsk_result_state is pending:
                    self._pending_tsk_result_state = None
                self.close()

            self._start_background_task("Save TSK Results", save_pending, pending_saved)
            event.ignore()
            return
        if not self._should_prompt_save_temp_database_on_close():
            self._cleanup_import_template()
            self._close_terminal_logging()
            event.accept()
            return
        outcome = self._prompt_save_temp_database_before_exit()
        if outcome in {"cancel", "saving"}:
            event.ignore()
            return
        self._cleanup_import_template()
        self._close_terminal_logging()
        event.accept()

    @Slot(str, str)
    def _append_terminal_message(self, stream: str, message: str) -> None:
        try:
            self._log(("[stderr] " if stream == "stderr" else "") + message)
        except Exception:
            # Printing here would feed a failed log widget back into itself.
            pass

    def _close_terminal_logging(self) -> None:
        self._clear_outlier_export_snapshot()
        self._terminal_log_timer.stop()
        unsubscribe_terminal_logs(self._terminal_log_token)

    def _apply_defaults(self) -> None:
        template_path = bundled_template_path()
        self.ui.templatePathEdit.setText(self._display_path(template_path))
        self.ui.inputPathEdit.setText("")
        self.ui.storagePathEdit.setText(self._display_path(default_database_root()))
        self.ui.goldenNameEdit.setText("sample_t0_golden")
        self.ui.referenceDimsEdit.setText("sample_id")
        self.ui.filtersEdit.setPlainText("reliability_node=T0")
        self._set_combo_code_if_present(self.ui.centerMethodComboBox, "mean")
        self._set_combo_code_if_present(self.ui.outlierFailModeComboBox, "golden_deviation")
        self.ui.numericCleanupCheckBox.setChecked(False)
        self._set_combo_code_if_present(self.ui.numericCleanupModeComboBox, "all_non_numeric")
        self.ui.numericCleanupCharsEdit.setText("")
        self.ui.zThresholdSpinBox.setValue(3.5)
        self._set_combo_code_if_present(self.ui.analysisScopeComboBox, "entire_database")
        self._sync_template_backed_settings_from_template(silent=True)
        self._update_golden_threshold_mode_state()
        self._update_numeric_cleanup_state()
        self._update_template_conversion_buttons()
        self._refresh_default_output_path()

    def _path_value(self, widget) -> str:
        value = widget.text().strip()
        return str(absolute_path(value, app_root())) if value else ""

    @staticmethod
    def _display_path(value: str | Path) -> str:
        return display_path(value, app_root())

    @staticmethod
    def _dialog_start(value: str, *, directory: bool = False, save: bool = False) -> str:
        return dialog_start(value, app_root(), directory=directory, save=save)

    @staticmethod
    def _dialog_options():
        # Use the platform's native picker; sanitize stale paths before opening it.
        return QFileDialog.Option(0)

    def _browse_template(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Template File",
            self._dialog_start(self.ui.templatePathEdit.text()),
            "Template Files (*.json *.xlsx);;JSON Files (*.json);;Excel Files (*.xlsx)",
            options=self._dialog_options(),
        )
        if path:
            self._load_template_async(path)

    def _validate_template(self) -> None:
        if not self._prepare_template_for_use():
            return
        try:
            template_path = self._ensure_template_path()
            template = load_template(template_path)
            validate_report_identity(template)
        except Exception as exc:
            self._show_error("Validate template failed", exc)
            return
        payload = {
            "template_path": str(Path(template_path).resolve()),
            "summary": summarize_template(template),
        }
        self._log("Template valid:\n" + json.dumps(payload, ensure_ascii=False, indent=2))
        QMessageBox.information(self, "Template Valid", json.dumps(payload, ensure_ascii=False, indent=2))
        self.statusBar().showMessage("Template validated.", 5000)

    def _export_template_json(self) -> None:
        self._export_template(".xlsx", "Excel Files (*.xlsx)")

    def _export_template_excel(self) -> None:
        self._export_template(".json", "JSON Files (*.json)")

    def _export_template(self, suffix: str, file_filter: str) -> None:
        if not self._prepare_template_for_use():
            return
        try:
            template_path = self._ensure_template_path()
            template = load_template(template_path)
            default_path = str(Path(template_path).with_suffix(suffix))
            output_path, _ = QFileDialog.getSaveFileName(
                self,
                f"Save Template As {suffix.upper().lstrip('.')}",
                self._dialog_start(default_path, save=True),
                file_filter,
                options=self._dialog_options(),
            )
            if not output_path:
                return
            resolved_output_path = self._resolve_existing_output_path(
                output_path,
                "Template output file",
            )
            if resolved_output_path is None:
                self.statusBar().showMessage("Template export cancelled.", 5000)
                return
            resolved_output = save_template(
                template,
                resolved_output_path,
                if_exists="overwrite",
            )
        except Exception as exc:
            self._show_error("Template export failed", exc)
            return
        payload = {
            "input": str(Path(template_path).resolve()),
            "output": str(Path(resolved_output).resolve()),
            "summary": summarize_template(template),
        }
        self._log("Template converted:\n" + json.dumps(payload, ensure_ascii=False, indent=2))
        self.statusBar().showMessage("Template exported.", 5000)

    def _browse_input(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Input File",
            self._dialog_start(self.ui.inputPathEdit.text()),
            "Table Files (*.csv *.xlsx *.xlsm);;CSV Files (*.csv);;Excel Files (*.xlsx *.xlsm)",
            options=self._dialog_options(),
        )
        if path:
            self.ui.inputPathEdit.setText(self._display_path(path))

    def _recent_database_paths(self) -> list[str]:
        paths = self._recent_database_settings.value("recentDatabases", [])
        if isinstance(paths, str):
            paths = [paths]
        return [path for path in paths if isinstance(path, str) and path.strip()][:10] if isinstance(paths, list) else []

    def _refresh_recent_databases(self) -> None:
        menu = self.ui.menuRecentDatabases
        for action in self._recent_database_actions:
            menu.removeAction(action)
            action.deleteLater()
        self._recent_database_actions = []
        paths = self._recent_database_paths()
        self.ui.actionNoRecentDatabases.setVisible(not paths)
        self.ui.actionClearRecentDatabases.setEnabled(bool(paths))
        for index, path in enumerate(paths, 1):
            action = QAction(f"{index}. {path.replace('&', '&&')}", menu)
            action.setData(path)
            action.setToolTip(path)
            action.triggered.connect(lambda checked=False, target=path: self._open_recent_database(target))
            menu.insertAction(self.ui.actionNoRecentDatabases, action)
            self._recent_database_actions.append(action)

    def _remember_database(self, root: str) -> None:
        path = str(absolute_path(root, app_root()))
        if os.path.normcase(path) == os.path.normcase(str(default_database_root().resolve())):
            return
        paths = [item for item in self._recent_database_paths()
                 if os.path.normcase(item) != os.path.normcase(path)]
        self._recent_database_settings.setValue("recentDatabases", [path, *paths][:10])
        self._recent_database_settings.sync()
        self._refresh_recent_databases()

    def _clear_recent_databases(self) -> None:
        self._recent_database_settings.remove("recentDatabases")
        self._recent_database_settings.sync()
        self._refresh_recent_databases()

    def _open_recent_database(self, path: str) -> None:
        if not available_path(Path(path), directory=True):
            QMessageBox.warning(self, "Open Recent Database", f"Database folder is unavailable:\n{path}")
            return
        self._load_database_async(path)

    def _browse_storage(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Select Database Folder", self._dialog_start(self.ui.storagePathEdit.text(), directory=True), options=self._dialog_options())
        if path:
            self._load_database_async(path)

    def _browse_golden(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select Golden Reference File", self._dialog_start(self.ui.goldenPathEdit.text()), "JSON Files (*.json)", options=self._dialog_options())
        if path:
            self.ui.goldenPathEdit.setText(self._display_path(path))
            self._sync_build_golden_controls_from_file(path)

    def _browse_output(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Select Report Output File",
            self._dialog_start(self.ui.outputPathEdit.text() or str(default_output_path()), save=True),
            "Excel Files (*.xlsx)",
            options=self._dialog_options(),
        )
        if path:
            self.ui.outputPathEdit.setText(self._display_path(path))

    def _connect_optional_button(self, button_name: str, handler) -> None:
        button = getattr(self.ui, button_name, None)
        if isinstance(button, QPushButton):
            button.clicked.connect(handler)

    def _open_template_file(self) -> None:
        self._open_local_target(
            self._path_value(self.ui.templatePathEdit),
            "Template file",
            target_type="file",
        )

    def _open_input_file(self) -> None:
        self._open_local_target(
            self._path_value(self.ui.inputPathEdit),
            "Input file",
            target_type="file",
        )

    def _open_golden_file(self) -> None:
        self._open_local_target(
            self._path_value(self.ui.goldenPathEdit),
            "Golden reference file",
            target_type="file",
        )

    def _open_database_folder(self) -> None:
        self._open_local_target(
            self._path_value(self.ui.storagePathEdit),
            "Database folder",
            target_type="directory",
        )

    def _open_result_folder(self) -> None:
        output_path = self._path_value(self.ui.outputPathEdit)
        if not output_path:
            QMessageBox.information(
                self,
                "Open Output Folder",
                "Report Output File is empty. Please choose an output path first.",
            )
            return
        output_target = Path(output_path).expanduser()
        folder_target = output_target if output_target.is_dir() else output_target.parent
        self._open_local_target(
            str(folder_target),
            "Report output folder",
            target_type="directory",
        )

    def _open_plot_inspector(self) -> None:
        try:
            analysis_scope = self._analysis_scope_code()
            self._ensure_analysis_paths(analysis_scope)
            template_path = self._path_value(self.ui.templatePathEdit)
            built_golden_path = self._path_value(self.ui.goldenPathEdit)
            outlier_fail_method = self._outlier_fail_mode_code()
            if self._analysis_requires_golden_file() and not built_golden_path:
                raise ValueError(
                    "Golden File is required for Golden Deviation or Use Golden Range for Z Score. "
                    "Build/select a Golden file, or disable Use Golden Range for Z Score to use the analysis population."
                )
            dataset_ids, dimension_filters, column_filters = self._collect_database_analysis_filters(
                analysis_scope
            )
            context = PlotInspectorContext(
                template_path=template_path,
                analysis_scope=analysis_scope,
                input_path=self._path_value(self.ui.inputPathEdit),
                storage_path=self._active_storage_path(),
                golden_path=built_golden_path,
                dataset_ids=dataset_ids,
                dimension_filters=dimension_filters,
                column_filters=column_filters,
                outlier_fail_method=outlier_fail_method,
                zscore_threshold=self.ui.zThresholdSpinBox.value(),
                zscore_use_golden_reference=self.ui.zscoreUseGoldenCheckBox.isChecked(),
            )
        except Exception as exc:
            self._show_error("Open Plot Inspector failed", exc)
            return
        self._show_plot_inspector(context)

    def _show_plot_inspector(self, context: PlotInspectorContext, *, reuse: bool = False,
                             source_revisions: dict | None = None) -> PlotInspectorWindow:
        existing = self._plot_inspector_window
        if (reuse and existing is not None and not existing._close_requested and existing.context() == context
                and self._plot_inspector_source_revisions == source_revisions):
            existing.show()
            existing.raise_()
            existing.activateWindow()
            return existing
        if self._plot_inspector_window is not None:
            old_window = self._plot_inspector_window
            self._plot_inspector_window = None
            old_window.close()
        window = PlotInspectorWindow(context, self)
        self._plot_inspector_window = window
        self._plot_inspector_source_revisions = deepcopy(source_revisions)
        window.destroyed.connect(lambda *args, window=window: self._clear_plot_inspector_window(window))
        window.show()
        window.raise_()
        window.activateWindow()
        return window

    def _open_summary_sample(self, navigation: dict, target: dict) -> None:
        snapshot = self.current_plot_inspector_snapshot
        error = summary_snapshot_error(snapshot)
        if error:
            QMessageBox.information(self, "Summary sample unavailable", error)
            return
        try:
            context = PlotInspectorContext(**summary_plot_context(snapshot))
            window = self._show_plot_inspector(context, reuse=True, source_revisions=snapshot["sources"])
            window.navigate_to_summary(target, navigation)
        except Exception as exc:
            self._show_error("Locate Summary sample failed", exc)

    def _clear_plot_inspector_window(self, window: PlotInspectorWindow | None = None, *args: object) -> None:
        if window is None or self._plot_inspector_window is window:
            self._plot_inspector_window = None

    def _open_local_target(
        self,
        raw_path: str,
        label: str,
        target_type: str,
    ) -> None:
        if not raw_path:
            QMessageBox.information(
                self,
                f"Open {label}",
                f"{label} is empty. Please choose a path first.",
            )
            return
        target = absolute_path(raw_path, app_root())
        if target_type == "directory":
            exists = target.is_dir()
        else:
            exists = target.is_file()
        if not exists:
            self._show_error(
                f"Open {label} failed",
                FileNotFoundError(f"{label} does not exist:\n{target}"),
            )
            return
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(target))):
            self._show_error(
                f"Open {label} failed",
                RuntimeError(f"Could not open {label.lower()}:\n{target}"),
            )

    def _save_debug_bundle(self) -> None:
        try:
            parent = QFileDialog.getExistingDirectory(
                self,
                "Select Folder For Debug Bundle",
                self._dialog_start(self.ui.storagePathEdit.text(), directory=True),
                options=self._dialog_options(),
            )
            if not parent:
                return
            bundle_path = Path(parent) / "excel_data_analysis_debug_bundle"
            resolved_bundle_path = self._resolve_existing_output_directory(
                bundle_path,
                "Debug bundle folder",
            )
            if resolved_bundle_path is None:
                self.statusBar().showMessage("Save debug bundle cancelled.", 5000)
                return
            payload = save_debug_bundle(
                bundle_path=resolved_bundle_path,
                gui_settings=self._collect_gui_settings_snapshot(),
                current_results=self._collect_current_results_snapshot(),
                log_text=self.ui.logPlainTextEdit.toPlainText(),
                template_path=self._path_value(self.ui.templatePathEdit) or None,
                input_path=self._path_value(self.ui.inputPathEdit) or None,
                storage_path=self._active_storage_path() or None,
                golden_path=self._path_value(self.ui.goldenPathEdit) or None,
                output_path=self._path_value(self.ui.outputPathEdit) or None,
                if_exists="overwrite",
            )
        except Exception as exc:
            self._show_error("Save debug bundle failed", exc)
            return
        self._log("Saved debug bundle:\n" + json.dumps(payload, ensure_ascii=False, indent=2))
        self.statusBar().showMessage("Debug bundle saved.", 5000)
        QMessageBox.information(
            self,
            "Debug Bundle Saved",
            (
                "Current GUI settings and results were saved to:\n"
                f"{payload['bundle_root']}"
            ),
        )

    def _save_database(self) -> None:
        database_root = self._database_root_path()
        if not database_root:
            self._show_error("Save database failed", ValueError("Database Folder is required."))
            return
        if Path(database_root).resolve() == default_database_root().resolve():
            self._save_database_as()
            return
        self._start_database_save(database_root)

    def _save_database_as(self) -> None:
        if self._active_task_thread is not None or self._analysis_process is not None:
            return
        if not self._database_root_path():
            self._show_error("Save database as failed", ValueError("Database Folder is required."))
            return
        try:
            target = self._choose_database_save_as_target()
        except Exception as exc:
            self._show_error("Save database as failed", exc)
            return
        if not target:
            self.statusBar().showMessage("Save database as cancelled.", 5000)
            return
        self._start_database_save(target)

    def _choose_database_save_as_target(self) -> str | None:
        parent = QFileDialog.getExistingDirectory(
            self,
            "Select Parent Folder For Saved Database",
            self._dialog_start("", directory=True),
            options=self._dialog_options(),
        )
        if not parent:
            return None
        folder_name, ok = QInputDialog.getText(
            self,
            "Database Folder Name",
            "Enter a folder name for the saved database:",
            text="projectDatabase",
        )
        if not ok:
            return None
        folder_name = folder_name.strip()
        if not folder_name:
            raise ValueError("Database folder name cannot be empty.")
        target = self._resolve_existing_output_directory(Path(parent) / folder_name, "Saved database folder")
        return str(Path(target).resolve()) if target else None

    def _start_database_save(self, target_root: str, *, close_after_save: bool = False) -> bool:
        if self._active_task_thread is not None or self._analysis_process is not None:
            return False
        source_root = self._database_root_path()
        try:
            if not source_root:
                raise ValueError("Database Folder is required.")
            target_root = str(Path(target_root).resolve())
            # Read widgets only here. All compression, copying and database reads
            # are performed by the worker, including the completion overview.
            request = {
                "source_root": source_root,
                "target_root": target_root,
                "storage_path": self._storage_path_for_read(),
                "gui_state": self._collect_persistent_gui_state(database_root=target_root),
                "summary_snapshot": self.current_plot_inspector_snapshot,
                "clear_default_source": Path(source_root).resolve() == default_database_root().resolve(),
                "template_path": self._path_value(self.ui.templatePathEdit),
            }
        except Exception as exc:
            self._show_error("Save database failed", exc)
            return False
        # A manual save includes the queued TSK state. Keep it available for a
        # retry on failure, but prevent its timer from racing this write.
        pending_tsk_state = self._pending_tsk_result_state
        self._tsk_result_save_timer.stop()

        def completed(result):
            if self._pending_tsk_result_state is pending_tsk_state:
                self._pending_tsk_result_state = None
            self.ui.storagePathEdit.setText(self._display_path(result["root"]))
            self.current_workspace_path = ""
            self.current_plot_inspector_snapshot = result["snapshot"]
            self._outlier_ratio_model.set_navigation_available(bool(result["snapshot"]))
            self._refresh_database_scoped_paths(source_root, result["root"])
            self._refresh_storage_overview(silent=True, payload=result["overview"], entries=result["entries"])
            self._remember_database(result["root"])
            self._log("Saved database:\n" + json.dumps({
                key: result[key] for key in ("root", "settings_file", "workspace_merge", "workspace_cleanup")
            }, ensure_ascii=False, indent=2))
            if result.get("cleanup_error"):
                self._log(f"Saved database; temporary workspace cleanup failed: {result['cleanup_error']}")
                action = self.ui.actionSaveDatabase
                QMessageBox.warning(self, action.property("cleanupWarningTitle"),
                                    action.property("cleanupWarningMessage").format(reason=result["cleanup_error"]))
            self.statusBar().showMessage("Database saved.", 5000)
            if close_after_save:
                self._close_after_save_ready = True
                self.close()
            else:
                action = self.ui.actionSaveDatabase
                QMessageBox.information(self, action.property("savedTitle"),
                                        action.property("savedMessage").format(root=result["root"]))

        title = "Save Database" if Path(source_root).resolve() == Path(target_root) else "Save Database As"
        self._start_background_task(title, lambda progress: save_database_job(request, progress_callback=progress), completed)
        return True

    def _import_dataset(self) -> None:
        self._cleanup_import_template()
        self._update_import_warnings({})
        self._set_template_edit_unlocked(False)
        if not self._prepare_template_for_use():
            return
        try:
            self._ensure_required_paths(require_input=True)
            template_path = self._path_value(self.ui.templatePathEdit)
            template = load_template(template_path)
            if self._maybe_write_back_template_settings(
                template_path,
                template,
                scope="import",
            ) is None:
                self.statusBar().showMessage("Import cancelled.", 5000)
                return
            input_path = self._path_value(self.ui.inputPathEdit)
            storage_path = self._active_storage_path()
            self._import_template_directory = TemporaryDirectory(prefix="easy-outlier-import-")
            runtime_template_path = str(Path(self._import_template_directory.name) / "template.json")
            save_template(template, runtime_template_path)
        except Exception as exc:
            self._cleanup_import_template()
            self._show_error("Import failed", exc)
            return
        self._verbose_log_storage_snapshot("Before Import")
        def task(report_progress):
            report_progress(-1, "Previewing import conflicts...")
            preview = preview_import(
                runtime_template_path,
                input_path,
                storage_path,
            )
            return {
                "template_path": runtime_template_path,
                "source_template_path": template_path,
                "input_path": input_path,
                "storage_path": storage_path,
                "preview": preview,
            }

        self._start_background_task(
            "Import Preview",
            task,
            self._handle_import_preview_ready,
        )

    def _handle_import_preview_ready(self, result: dict[str, object]) -> None:
        preview = result["preview"]
        self._update_import_warnings(preview)
        self._log(
            "Import preview:\n"
            + json.dumps(
                {
                    "template_path": result.get("source_template_path", result["template_path"]),
                    "input_path": result["input_path"],
                    "storage_path": result["storage_path"],
                    "existing_measurement_count": preview["existing_measurement_count"],
                    "incoming_measurement_count": preview["incoming_measurement_count"],
                    "existing_row_count": preview["existing_row_count"],
                    "incoming_row_count": preview["incoming_row_count"],
                    "conflict_row_count": preview["conflict_row_count"],
                    "existing_conflict_row_count": preview["existing_conflict_row_count"],
                    "dimensions": preview["dimensions"],
                    "conflict_rows_preview": preview["conflict_rows_preview"],
                    "warnings": preview.get("warnings", []),
                    "warning_count": preview.get("warning_count", 0),
                    "warning_file": preview.get("warning_file"),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        if int(preview["incoming_measurement_count"]) == 0:
            QMessageBox.warning(
                self,
                "Import Preview Warning",
                (
                    "This input produced 0 measurements during preview.\n\n"
                    "The database would remain empty after import unless the file/template mapping is adjusted.\n"
                    "Please check the GUI Log for preview details, then verify row dimensions, test columns, and numeric cleanup settings."
                ),
            )
        conflict_mode = "error"
        if preview["conflict_row_count"]:
            conflict_mode = self._prompt_import_conflict_mode(preview)
            if conflict_mode is None:
                self._cleanup_import_template()
                self.statusBar().showMessage("Import cancelled.", 5000)
                return
        template_path = str(result["template_path"])
        input_path = str(result["input_path"])
        storage_path = str(result["storage_path"])

        def task(report_progress):
            return import_dataset(
                template_path,
                input_path,
                storage_path,
                conflict_mode=conflict_mode,
                progress_callback=report_progress,
            )

        def start_import_task() -> None:
            self._start_background_task(
                "Import Dataset",
                task,
                self._handle_import_completed,
            )

        # Start the second import stage on the next event-loop turn.
        # This avoids creating a fresh worker thread while the preview
        # thread is still unwinding its finished signal cleanup.
        QTimer.singleShot(0, start_import_task)

    def _cleanup_import_template(self) -> None:
        if self._import_template_directory is not None:
            self._import_template_directory.cleanup()
            self._import_template_directory = None

    def _update_import_warnings(self, payload: dict[str, object]) -> None:
        label = self.ui.importWarningsLabel
        warning_count = int(payload.get("warning_count", 0) or 0)
        warning_file = str(payload.get("warning_file") or "")
        if warning_count:
            location = (
                label.property("savedLocationText").format(warning_file=Path(warning_file).name)
                if warning_file else label.property("previewLocationText")
            )
            label.setText(label.property("warningText").format(
                count=warning_count, warning_location=location,
            ))
        else:
            label.clear()
        label.setToolTip(warning_file)
        label.setVisible(warning_count > 0)

    def _handle_import_completed(self, payload: dict[str, object]) -> None:
        self._cleanup_import_template()
        self._update_import_warnings(payload)
        self._log(f"Imported dataset:\n{json.dumps(payload, ensure_ascii=False, indent=2)}")
        self._refresh_storage_overview(silent=True)
        self._verbose_log_storage_snapshot("After Import")
        imported_measurements = int(payload.get("imported_measurements", 0) or 0)
        imported_rows = int(payload.get("imported_rows", 0) or 0)
        if imported_measurements == 0 or imported_rows == 0:
            QMessageBox.warning(
                self,
                "Import Completed With No Data",
                (
                    "Import finished, but 0 measurements or 0 rows were written.\n\n"
                    "Please open the GUI Log and review the Import preview / Imported dataset sections.\n"
                    "That output now includes the incoming measurement count and the post-import database summary."
                ),
            )
        warning_count = int(payload.get("warning_count", 0) or 0)
        if warning_count:
            self.statusBar().showMessage(
                self.property("importWarningsStatusText").format(count=warning_count),
                15000,
            )
        else:
            self.statusBar().showMessage("Dataset imported.", 5000)

    def _delete_selected_storage_rows(self) -> None:
        database_root = self._database_root_path()
        if not database_root:
            self._show_error("Delete rows failed", ValueError("Database Folder is required."))
            return
        selectors = self._selected_storage_row_selectors()
        if not selectors:
            QMessageBox.information(
                self,
                "No Rows Selected",
                "Please select one or more database rows to delete.",
            )
            return
        response = QMessageBox.question(
            self,
            "Delete Selected Database Rows",
            (
                f"Delete {len(selectors)} selected database row(s)?\n\n"
                "Use this for cases like mistaken imports or rows that should be removed from the database."
            ),
            QMessageBox.Yes | QMessageBox.Cancel,
            QMessageBox.Cancel,
        )
        if response != QMessageBox.Yes:
            self.statusBar().showMessage("Delete rows cancelled.", 5000)
            return
        self._verbose_log(
            "Delete rows request:\n"
            + json.dumps(selectors, ensure_ascii=False, indent=2)
        )
        self._verbose_log_storage_snapshot("Before Delete Rows")
        try:
            payload = delete_storage_rows(self._active_storage_path(), selectors)
        except Exception as exc:
            self._show_error("Delete rows failed", exc)
            return
        self._log("Deleted database rows:\n" + json.dumps(payload, ensure_ascii=False, indent=2))
        self._refresh_storage_overview(silent=True)
        self._verbose_log_storage_snapshot("After Delete Rows")
        self.statusBar().showMessage("Selected database rows deleted.", 5000)

    def _delete_current_storage_source(self) -> None:
        payload = self._storage_overview_payload
        selected = self.ui.storageImportComboBox.currentData()
        if payload is None or selected is None:
            return
        entry = next((item for item in payload.get("imports", [])
                      if (item["dataset_id"], item["source_file"]) == tuple(selected)), None)
        if entry is None or not entry["row_count"]:
            return
        button = self.ui.deleteCurrentSourceButton
        response = QMessageBox.question(
            self,
            str(button.property("confirmationTitle")),
            str(button.property("confirmationText")).format(**entry),
            QMessageBox.Yes | QMessageBox.Cancel,
            QMessageBox.Cancel,
        )
        if response != QMessageBox.Yes:
            self.statusBar().showMessage("Delete source cancelled.", 5000)
            return
        storage_path = self._active_storage_path()
        if not storage_path:
            self._show_error("Delete source failed", ValueError("Database Folder is required."))
            return
        template_path = self._path_value(self.ui.templatePathEdit) or None
        dataset_id, source_file = entry["dataset_id"], entry["source_file"]

        def task(report_progress):
            report_progress(-1, "Deleting current source data...")
            result = delete_storage_import(storage_path, dataset_id, source_file)
            report_progress(-1, "Refreshing database snapshot...")
            try:
                return {
                    "deleted": result,
                    "snapshot": describe_storage(storage_path, template_path=template_path, limit=500),
                    "entries": list_import_history(storage_path),
                }
            except Exception as exc:
                return {"deleted": result, "refresh_error": str(exc)}

        self._start_background_task("Delete Current Source", task, self._handle_delete_source_completed)

    def _handle_delete_source_completed(self, result: dict[str, object]) -> None:
        deleted = result["deleted"]
        self._log("Deleted source data:\n" + json.dumps(deleted, ensure_ascii=False, indent=2))
        if "refresh_error" in result:
            self._clear_storage_snapshot("Source data deleted. Refresh the database snapshot to continue.")
            self._show_error("Source deleted; snapshot refresh failed", RuntimeError(result["refresh_error"]))
            return
        self._refresh_storage_overview(silent=True, payload=result["snapshot"], entries=result["entries"])
        self.statusBar().showMessage(
            f"Deleted {deleted['deleted_row_count']:,} rows from the selected import.", 5000,
        )

    def _build_golden(self) -> None:
        self._set_template_edit_unlocked(False)
        if not self._prepare_template_for_use():
            return
        try:
            self._ensure_required_paths(require_input=False)
            template_path = self._path_value(self.ui.templatePathEdit)
            template = load_template(
                template_path,
                analysis_group_conflict_mode="error",
            )
            if self._maybe_write_back_template_settings(
                template_path,
                template,
                scope="build_golden",
            ) is None:
                self.statusBar().showMessage("Build golden cancelled.", 5000)
                return
            golden_name = self.ui.goldenNameEdit.text().strip() or "golden_reference"
            golden_target_path = (
                Path(self._active_storage_path()) / "golden" / f"{golden_name}.json"
            )
            existing_mode = self._resolve_existing_output_mode(
                golden_target_path,
                "Golden reference file",
            )
            if existing_mode is None:
                self.statusBar().showMessage("Build golden cancelled.", 5000)
                return
        except Exception as exc:
            self._show_error("Build golden failed", exc)
            return
        storage_path = self._active_storage_path()
        reference_dimensions = parse_csv_items(self.ui.referenceDimsEdit.text().strip())
        filters = parse_filter_text(self.ui.filtersEdit.toPlainText())
        center_method = self._combo_code(self.ui.centerMethodComboBox)
        outlier_golden_method = self._resolved_outlier_golden_method()
        relative_limit = self._resolve_relative_limit()
        sigma_multiplier = self._resolve_sigma_multiplier()
        mad_multiplier = self._resolve_mad_multiplier()
        absolute_lower_bound = self._resolve_absolute_lower_bound()
        absolute_upper_bound = self._resolve_absolute_upper_bound()
        overwrite_lowerbound = self._resolve_overwrite_lowerbound()
        overwrite_upperbound = self._resolve_overwrite_upperbound()
        continuous_interval = self._resolve_continuous_interval()
        empty_range_fallback_to_absolute = self._resolve_empty_range_fallback_to_absolute()

        def task(report_progress):
            reference, path = create_golden_reference(
                storage_path=storage_path,
                name=golden_name,
                reference_dimensions=reference_dimensions,
                filters=filters,
                center_method=center_method,
                outlier_golden_method=outlier_golden_method,
                relative_limit=relative_limit,
                sigma_multiplier=sigma_multiplier,
                mad_multiplier=mad_multiplier,
                absolute_lower_bound=absolute_lower_bound,
                absolute_upper_bound=absolute_upper_bound,
                overwrite_lowerbound=overwrite_lowerbound,
                overwrite_upperbound=overwrite_upperbound,
                continuous_interval=continuous_interval,
                empty_range_fallback_to_absolute=empty_range_fallback_to_absolute,
                template_path=template_path,
                analysis_group_conflict_mode="error",
                if_exists=existing_mode,
                progress_callback=report_progress,
            )
            return {"reference": reference, "path": path}

        self._start_background_task(
            "Build Golden",
            task,
            self._handle_build_golden_completed,
        )

    def _handle_build_golden_completed(self, payload: dict[str, object]) -> None:
        reference = payload["reference"]
        path = str(payload["path"])
        self.ui.goldenPathEdit.setText(self._display_path(path))
        self._log(
            "Golden built:\n"
            + json.dumps(
                {
                    "golden_name": reference.name,
                    "metric_count": len(reference.metrics),
                    "center_method": reference.center_method,
                    "empty_range_fallback_count": sum(
                        1 for metric in reference.metrics if metric.empty_range_fallback_used
                    ),
                    "saved_to": path,
                    "excel_saved_to": str(Path(path).with_suffix(".xlsx")),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        self._verbose_log_storage_snapshot("After Build Golden")
        fallback_warnings = [
            metric.empty_range_fallback_reason
            for metric in reference.metrics
            if metric.empty_range_fallback_used and metric.empty_range_fallback_reason
        ]
        if fallback_warnings:
            QMessageBox.warning(
                self,
                "Golden Fallback Warning",
                "部分 golden allowed range 为空，已 fallback 到 absolute 数值范围。\n\n"
                + "\n\n".join(fallback_warnings[:5])
                + (
                    "\n\nOnly the first 5 warnings are shown."
                    if len(fallback_warnings) > 5
                    else ""
                ),
            )
        self.statusBar().showMessage("Golden reference created.", 5000)

    def _sync_merge_roles(self, *args) -> None:
        self.merge_controls.set_roles(
            str(self.identity_controls.node_combo.currentData() or ""),
            str(self.identity_controls.chain_combo.currentData() or ""),
        )

    def _confirm_template_upgrade(self, template):
        repair = bool(template.migration_issues)
        if repair:
            levels = column_levels(template)
            chain = chain_level(template)
            index = levels.index(chain)
            child = levels[index + 1] if index + 1 < len(levels) else "（没有下一级：保留 Chain，本阶段不合并列）"
            reply = QMessageBox.critical(
                self, "旧模板合并边界错误",
                "旧模板的列合并起点会合掉 Chain，不允许把不同 Chain 合在一起。\n\n"
                f"点击确定：旧起点修正为 Chain 的下一级 {child}，新参数 initial_column_merge_level = {chain}。\n"
                "这会改变原来的跨 Chain 合并行为。程序将备份原文件，并刷新为新版字段、步骤名称及中文填写说明。",
                QMessageBox.Ok | QMessageBox.Cancel, QMessageBox.Cancel,
            )
            if reply != QMessageBox.Ok:
                return False, repair
        else:
            QMessageBox.information(
                self, "旧模板升级",
                "检测到旧版模板。程序将先备份原文件，再刷新为最新格式。\n"
                "配置页会增加一行中文填写说明：第 2 行为英文表头，第 3 行开始填写。\n"
                "已有新版合并设置保持不变。如仍使用旧的合并起点，将转换为它上方一层，即合并后保留的层级。\n"
                "Final 行固定到可靠性节点，Final 列固定到选定的 Chain 层级。",
            )
        return True, repair

    def _prepare_template_for_use(self) -> bool:
        try:
            path = self._ensure_template_path()
            template = load_template(path)
            decision = self._decide_loaded_template(template, path)
            if decision is None:
                return False
            selected, write, repair = decision
            if write:
                selected, path = self._persist_loaded_template(selected, path, repair)
                self._apply_template_settings(selected, path)
                self.ui.templatePathEdit.setText(self._display_path(path))
            return True
        except Exception as exc:
            self._show_error("Template validation failed", exc)
            return False

    def _current_analysis_rules_template(self, template=None, *, validate=True):
        """Snapshot the shared Analyze controls without applying its data filters."""
        selected = self.identity_controls.updated_template(template, validate=False)
        self.merge_controls.apply_to(selected, validate=False)
        report = selected.report
        report.outlier_fail_method = self._outlier_fail_mode_code()
        report.zscore_use_golden_reference = self.ui.zscoreUseGoldenCheckBox.isChecked()
        report.outlier_merge_order = self._outlier_merge_order_text()
        report.outlier_treat_empty_cells_as_fail = self.ui.emptyCellsFailCheckBox.isChecked()
        report.zscore_thresholds.default = float(self.ui.zThresholdSpinBox.value())
        if validate:
            validate_report_identity(selected)
        return selected

    def _sync_tsk_fail_rules(self, *_args) -> None:
        template = self._outlier_analysis_template
        self.ui.tskAnalysisPanel.set_shared_fail_rules(template.report if template is not None else None)
        self.ui.tskAnalysisPanel.set_node_context(
            template or self.ui.tskAnalysisPanel.template,
            self._outlier_export_nodes if template is not None else None,
        )

    def _scan_tsk_batches(self, settings: dict) -> None:
        from ..tsk_service import discover_tsk_batches

        self._set_template_edit_unlocked(False)
        self.ui.tskAnalysisPanel.restore_settings(settings)
        try:
            request = self._tsk_analysis_request(settings)
            request.pop("include_all_combinations")
        except Exception as exc:
            self._show_error("TSK batch discovery failed", exc)
            return
        self._start_background_task(
            "TSK Batch Discovery",
            lambda progress: discover_tsk_batches(**request, progress_callback=progress),
            self._handle_tsk_batches_discovered,
        )

    def _load_tsk_coordinate_preview(self) -> None:
        from ..tsk_coordinate_data import coordinate_preview_from_template, coordinate_preview_from_snapshot
        from ..tsk_observations import read_analysis_snapshot

        panel = self.ui.tskResultsPanel
        if panel.result.get("groups"):
            return
        # Drop previous observation colors before loading a different scope.
        panel.set_coordinate_preview(coordinate_preview_from_template(self.ui.tskAnalysisPanel.template))
        snapshot_path = self._tsk_snapshot_path or self._outlier_snapshot_path
        if not snapshot_path or not Path(snapshot_path).is_file():
            return
        if self._active_task_thread is not None or self._analysis_process is not None:
            return
        settings = self.ui.tskAnalysisPanel.settings()
        def load_preview(progress):
            progress(10, "读取 Analyze 已完成的链路判定…")
            payload = coordinate_preview_from_snapshot(read_analysis_snapshot(snapshot_path), settings)
            progress(100, "链路观测失效率已准备完成。")
            return payload
        self._start_background_task("TSK Coordinate Observations", load_preview, panel.set_coordinate_preview)

    def _handle_tsk_batches_discovered(self, values: list[str]) -> None:
        self.ui.tskAnalysisPanel.set_batch_values(values)
        self.statusBar().showMessage(f"TSK：已读取 {len(values)} 个原批次，可填写母批编号。", 5000)

    def _tsk_analysis_request(self, settings: dict) -> dict:
        """Freeze a reference to the completed Analyze result, not the live controls."""
        snapshot_path = self._tsk_snapshot_path or self._outlier_snapshot_path
        if not snapshot_path or not Path(snapshot_path).is_file():
            if self._tsk_snapshot_restore_error:
                raise ValueError("保存的 Analyze 输入无法恢复，请重新运行 Analyze。\n" + self._tsk_snapshot_restore_error)
            if self.current_outlier_summary_rows or self.current_outlier_ratio_rows:
                raise ValueError("此保存记录只有 Analyze 汇总，缺少 TSK 所需的样品/链路判定结果（旧版本不会保存这些输入）。"
                                 "请重新运行一次 Analyze 并保存数据库，之后重新打开即可继续 TSK。")
            raise ValueError("请先在 Analyze 完成分析，再运行 TSK；TSK 必须基于已完成的 Analyze 结果。")
        options = deepcopy(settings)
        for retired in ("source", "analysis_scope", "dataset_ids", "fail_method", "classification_pool"):
            options.pop(retired, None)
        return {
            "template_path": self._path_value(self.ui.templatePathEdit), "source": "analyze",
            "analysis_snapshot_path": snapshot_path,
            "settings": options,
            "include_all_combinations": True,
        }

    def _activate_saved_tsk_analysis(self, key: str) -> bool:
        if key == "__live_tsk_analysis__":
            if self._tsk_live_result is None:
                return False
            self._tsk_viewing_live = True
            self.tsk_run_history["active_key"] = self._tsk_live_key
            self.current_tsk_result = self._tsk_live_result
        else:
            entry = tsk_run_history.find_run(self.tsk_run_history, key)
            if entry is None:
                return False
            self._tsk_viewing_live = False
            self.tsk_run_history["active_key"] = key
            self.current_tsk_result = entry["result"]
        self.ui.tskResultsPanel.set_partial_result(self.current_tsk_result, reset=True)
        self._refresh_tsk_result_history()
        self.ui.resultTabWidget.setCurrentWidget(self.ui.tskResultsTab)
        self.statusBar().showMessage(self.ui.tskResultsPanel.ui.savedAnalysesComboBox.property(
            "liveAnalysisText" if key == "__live_tsk_analysis__" else "cachedText"), 7000)
        # Viewing a saved result must never trigger fitting or missing-combination work.
        if self._active_task_thread is None and self._analysis_process is None:
            self._queue_tsk_result_save()
        return True

    def _refresh_tsk_result_history(self) -> None:
        history = self.tsk_run_history
        if self._tsk_viewing_live and self._tsk_live_result is not None:
            history = {**history, "active_key": "__live_tsk_analysis__"}
        self.ui.tskResultsPanel.set_run_history(history)

    def _retains_tsk_result(self, result: dict) -> bool:
        return (self.current_tsk_result is result or self._tsk_live_result is result
                or any(entry.get("result") is result for entry in self.tsk_run_history.get("entries", [])))

    def _show_cached_tsk_mode(self, settings: dict) -> None:
        try:
            signature = tsk_run_history.run_signature(self._tsk_analysis_request(settings))
        except (OSError, ValueError, TypeError):
            signature = None
        if signature is not None and self._activate_saved_tsk_analysis(signature["key"]):
            return
        self.statusBar().showMessage(self.ui.tskResultsPanel.ui.savedAnalysesComboBox.property("missingText"), 10000)

    def _delete_saved_tsk_analysis(self, key: str) -> None:
        if self._active_task_thread is not None or self._analysis_process is not None:
            return
        history = self.tsk_run_history
        entry = tsk_run_history.find_run(history, key)
        panel = self.ui.tskResultsPanel
        index = panel.ui.savedAnalysesComboBox.findData(key)
        if entry is None or index < 0:
            return
        root = self._database_root_path()
        dialog = QDialog(self)
        ui = Ui_TskDeleteAnalysisDialog()
        ui.setupUi(dialog)
        ui.analysisLabel.setText(panel.ui.savedAnalysesComboBox.itemText(index))
        if dialog.exec() != QDialog.Accepted:
            return
        # The modal event loop may load another database or replace this run.
        if (self.tsk_run_history is not history or self._database_root_path() != root
                or tsk_run_history.find_run(history, key) is not entry
                or self._active_task_thread is not None or self._analysis_process is not None):
            return
        remaining = [item for item in history["entries"] if item["key"] != key]
        self.tsk_run_history = {**history, "entries": remaining}
        if history.get("active_key") == key:
            replacement = remaining[-1] if remaining else None
            self.tsk_run_history["active_key"] = replacement["key"] if replacement else None
            self.current_tsk_result = replacement["result"] if replacement else None
            if replacement:
                panel.set_result(self.current_tsk_result)
            else:
                panel.clear_result()
        panel.set_run_history(self.tsk_run_history)
        self._queue_tsk_result_save()
        self.statusBar().showMessage(panel.ui.deleteSavedAnalysisButton.property("deletedText"), 7000)

    def _run_tsk_analysis(self, settings: dict) -> None:
        """Fit only the current completed Analyze result."""
        if self._active_task_thread is not None or self._analysis_process is not None:
            return
        self._set_template_edit_unlocked(False)
        self.ui.tskAnalysisPanel.restore_settings(settings)
        try:
            request = self._tsk_analysis_request(settings)
            self._sync_tsk_fail_rules()
        except Exception as exc:
            self._show_error("TSK analysis failed", exc)
            return
        try:
            signature = tsk_run_history.run_signature(request)
        except (OSError, ValueError, TypeError) as exc:
            # A missing optional input must not change the workflow's own validation.
            signature = None
            self._log(f"TSK result reuse unavailable: {exc}")
        if (signature is not None
                and tsk_run_history.can_reuse_run(tsk_run_history.find_run(self.tsk_run_history, signature["key"]))
                and self._activate_saved_tsk_analysis(signature["key"])):
            return
        self._pending_tsk_run_signature = signature
        self.ui.resultTabWidget.setCurrentWidget(self.ui.tskResultsTab)
        if self.current_tsk_result is None:
            self.ui.tskResultsPanel.clear_result("正在基于 Analyze 结果进行 TSK 分析…")
        try:
            self._start_tsk_process(request)
        except Exception as exc:
            self._pending_tsk_run_signature = None
            if self.current_tsk_result is None:
                self.ui.tskResultsPanel.clear_result(str(exc))
            self._show_error("TSK analysis failed", exc)

    def _handle_tsk_partial_result(self, event: dict) -> None:
        """Publish completed modules while the isolated solver keeps running."""
        if event.get("event") == "initial":
            payload = event.get("payload")
            if not isinstance(payload, dict) or not isinstance(payload.get("groups"), list):
                return
            result = {**payload, "analysis_status": "running"}
            if self._tsk_viewing_live:
                self.tsk_run_history["active_key"] = None
        elif event.get("event") == "group":
            index, group = event.get("group_index"), event.get("group")
            if (self._tsk_stream_result is None or not isinstance(index, int)
                    or not isinstance(group, dict)
                    or not 0 <= index < len(self._tsk_stream_result["groups"])):
                return
            groups = list(self._tsk_stream_result["groups"])
            groups[index] = group
            result = {**self._tsk_stream_result, "groups": groups, "updated_group_index": index}
        else:
            return
        self._tsk_stream_result = self._tsk_live_result = result
        if event.get("event") == "initial":
            self.ui.tskResultsPanel.set_live_analysis_available(True)
            self._refresh_tsk_result_history()
        if self._tsk_viewing_live:
            self.current_tsk_result = result
            self.ui.tskResultsPanel.set_partial_result(result, reset=event.get("event") == "initial")

    def _finish_tsk_partial_result(self, message: str, *, invalidates_fit=False) -> None:
        result = self._tsk_stream_result
        self._tsk_stream_result = None
        if result is None:
            return
        result = {key: value for key, value in result.items() if key != "updated_group_index"}
        result.update(analysis_status="interrupted", interruption_reason=message,
                      fit_invalidated=invalidates_fit)
        result["groups"] = [
            {**group, "analysis_status": "interrupted"}
            if group.get("analysis_status") != "completed" else group
            for group in result["groups"]]
        self._tsk_live_result = result
        if self._tsk_viewing_live:
            self.current_tsk_result = result
            self.ui.tskResultsPanel.set_partial_result(result)

    def _handle_tsk_analysis_completed(self, result: dict) -> None:
        was_streaming = self._tsk_stream_result is not None
        self._tsk_stream_result = None
        signature = self._pending_tsk_run_signature
        self._pending_tsk_run_signature = None
        viewed_key = self.tsk_run_history.get("active_key")
        if signature is not None:
            tsk_run_history.store_run(self.tsk_run_history, signature, result)
        else:
            self.tsk_run_history["active_key"] = None
        self._tsk_live_result = result
        self._tsk_live_key = signature["key"] if signature is not None else None
        self.ui.tskResultsPanel.set_live_analysis_available(True)
        show_completed = not was_streaming or self._tsk_viewing_live
        if show_completed:
            self._tsk_viewing_live = True
            self.current_tsk_result = result
            self.ui.tskResultsPanel.set_result(result)
            if not was_streaming:
                self.ui.resultTabWidget.setCurrentWidget(self.ui.tskResultsTab)
        else:
            self.tsk_run_history["active_key"] = viewed_key
            if signature is not None and viewed_key == signature["key"]:
                # Recomputing an unusable saved run replaces that same entry.
                # Keep its selection and navigation, with the refreshed values.
                self.current_tsk_result = result
                self.ui.tskResultsPanel.set_partial_result(result)
        if signature is not None:
            # Completed runs have a permanent history entry; the temporary
            # selector is needed only while the run has no saved entry yet.
            self._tsk_live_result = None
            self._tsk_live_key = None
            self._tsk_viewing_live = False
            self.ui.tskResultsPanel.set_live_analysis_available(False)
        self._refresh_tsk_result_history()
        self._log(f"TSK analysis completed: {len(result.get('groups', []))} node/batch groups.")
        self.statusBar().showMessage("基于 Analyze 结果的 TSK 分析完成。", 5000)
        if show_completed:
            self.ui.tskResultsPanel.ensure_all_combinations()
        self._queue_tsk_result_save()

    def _queue_tsk_result_save(self) -> None:
        root = self._database_root_path()
        if root:
            self._pending_tsk_result_state = (root, self._collect_persistent_gui_state())
            self._tsk_result_save_timer.start(0)

    def _save_pending_tsk_result(self) -> None:
        if self._pending_tsk_result_state is None:
            return
        if self._active_task_thread is not None or self._analysis_process is not None:
            self._tsk_result_save_timer.start(100)
            return
        root, payload = self._pending_tsk_result_state
        self._pending_tsk_result_state = None
        result = payload["current_results"]["tsk_result"]

        def saved(_target):
            if self.current_tsk_result is result and self._database_root_path() == root:
                message = ("TSK 结果已自动保存，重新打开数据库可直接查看。" if result is not None
                           else self.ui.tskResultsPanel.ui.deleteSavedAnalysisButton.property("savedText"))
                self.statusBar().showMessage(message, 10000)

        self._start_background_task("Save TSK Results", lambda progress: save_gui_state(root, payload), saved)

    def _export_tsk_html_results(self) -> None:
        payload = self.current_tsk_result
        if (not payload or not payload.get("groups") or not self.ui.tskResultsPanel.result.get("groups")
                or payload.get("analysis_status") in {"running", "interrupted"} or payload.get("fit_invalidated")
                or self._active_task_thread is not None or self._analysis_process is not None):
            return
        from ..tsk_html_export import export_tsk_html
        payload = tsk_run_history.export_payload(payload, self.tsk_run_history)

        button = self.ui.tskAnalysisPanel.ui.saveHtmlButton
        initial = str(Path(self._database_root_path() or app_root()) / "result" / button.property("defaultFilename"))
        path, _ = QFileDialog.getSaveFileName(self, button.property("dialogTitle"), initial, button.property("fileFilter"))
        if not path:
            return
        # Read Qt state on the GUI thread; the report itself is built in the worker.
        view_state = self.ui.tskResultsPanel.html_view_state()
        saved_format = button.property("savedFormat")
        self._start_background_task(
            button.property("taskTitle"),
            lambda progress: export_tsk_html(payload, path, view_state=view_state),
            lambda output: self.statusBar().showMessage(saved_format.format(path=output), 10000),
        )

    def _export_tsk_results(self) -> None:
        if (not self.current_tsk_result
                or self.current_tsk_result.get("analysis_status") in {"running", "interrupted"}
                or self.current_tsk_result.get("fit_invalidated")):
            return
        from ..tsk_service import export_tsk_result

        initial = str(Path(self._database_root_path() or app_root()) / "result" / "tsk_risk.xlsx")
        path, _ = QFileDialog.getSaveFileName(self, "Export TSK Results", initial, "Excel Workbook (*.xlsx)")
        if not path:
            return
        payload = self.current_tsk_result
        self._start_background_task(
            "Export TSK Results",
            lambda progress: export_tsk_result(payload, path),
            lambda output: self.statusBar().showMessage(f"TSK 结果已导出：{output}", 10000),
        )

    def _confirm_tsk_combination_completion(self, settings: dict) -> None:
        panel = self.ui.tskResultsPanel
        result = self.current_tsk_result
        group = panel.current_group
        if not result or not group:
            panel.finish_combination_request()
            return
        dialog = QDialog(self)
        ui = Ui_TskCompletionDialog()
        ui.setupUi(dialog)
        ui.contextLabel.setText(ui.contextLabel.property("formatText").format(
            group=group.get("label") or group.get("node") or "—",
            count=panel.full_combination_count(),
        ))
        accepted = dialog.exec() == QDialog.Accepted
        # A modal dialog processes queued events; do not apply its answer to a
        # replacement result or another group.
        if self.current_tsk_result is not result or panel.current_group is not group:
            return
        if accepted:
            self._run_tsk_combinations(settings)
        else:
            panel.defer_combination_request()

    def _run_tsk_combinations(self, settings: dict) -> None:
        from ..tsk_service import store_tsk_combination_view

        result = self.current_tsk_result
        group_index = self.ui.tskResultsPanel.ui.groupComboBox.currentIndex()
        if not result or not 0 <= group_index < len(result.get("groups", [])):
            return
        if result["groups"][group_index].get("saved_display_only"):
            self.ui.tskResultsPanel.finish_combination_request()
            return
        selected_group = result["groups"][group_index]
        snapshot = {"groups": [{"prediction_context": deepcopy(selected_group.get("prediction_context")),
                                "label": selected_group.get("label", f"组 {group_index + 1}"),
                                "node": selected_group.get("node"), "batch": selected_group.get("batch")}]}
        request = deepcopy(settings)

        def completed(response):
            # History browsing does not discard work on the original run.
            if not self._retains_tsk_result(result):
                return
            self.ui.tskResultsPanel.finish_combination_request()
            view = response["view"]
            store_tsk_combination_view(result, group_index, view)
            if (self.current_tsk_result is result
                    and self.ui.tskResultsPanel.ui.groupComboBox.currentIndex() == group_index):
                self.ui.tskResultsPanel.set_combination_result(view)
            self._log(f"TSK combinations completed: {len(view['rows'])} cells, {view['dimension']}.")
            self.statusBar().showMessage("TSK 组合概率与区间已计算。", 5000)
            if self.current_tsk_result is result:
                self.ui.tskResultsPanel.ensure_all_combinations()
            self._queue_tsk_result_save()

        try:
            self._start_process_task(
                "TSK Combination Analysis", _run_tsk_combinations_in_subprocess,
                {"payload": snapshot, "group_index": 0, "settings": request}, completed,
            )
        except Exception as exc:
            self.ui.tskResultsPanel.finish_combination_request()
            self._show_error("TSK combination analysis failed", exc)

    def _run_tsk_deletion_analysis(self) -> None:
        if self._active_task_thread is not None or self._analysis_process is not None:
            return
        panel = self.ui.tskResultsPanel
        result, group = self.current_tsk_result, panel.current_group
        if not result or not group:
            return
        context = group.get("feature_effects_context") or group.get("prediction_context") or {}
        if (any(context.get(key) is None for key in ("design", "chain_index", "n_tested", "n_failed"))
                or not (group.get("feature_effects") or {}).get("features")):
            return
        snapshot = deepcopy({key: group[key] for key in
                             ("feature_effects_context", "prediction_context", "feature_effects", "options")
                             if key in group})
        button = panel.ui.featureEffectsPanel.ui.deletionAnalysisButton

        def completed(report):
            # Keep a result attached to its original run and group even if the
            # user changes the visible group while the process is working.
            if not self._retains_tsk_result(result) or not any(item is group for item in result["groups"]):
                return
            group["feature_effects"] = report
            if panel.current_group is group:
                panel.ui.featureEffectsPanel.set_group(group)
            self._queue_tsk_result_save()
            self.statusBar().showMessage(button.property("completedText"), 7000)

        try:
            self._start_process_task(
                button.property("taskTitle"), _run_tsk_deletion_in_subprocess,
                {"group": snapshot, "group_label": group.get("label") or group.get("node") or "",
                 "task_label": button.text()}, completed)
        except Exception as exc:
            self._show_error(button.property("errorTitle"), exc)

    def _run_analysis(self) -> None:
        self._set_template_edit_unlocked(False)
        if not self._prepare_template_for_use():
            return
        try:
            analysis_scope = self._analysis_scope_code()
            self._ensure_analysis_paths(analysis_scope)
            template_path = self._path_value(self.ui.templatePathEdit)
            template = load_template(template_path)
            if self._maybe_write_back_template_settings(
                template_path,
                template,
                scope="analysis",
            ) is None:
                self.statusBar().showMessage("Analysis cancelled.", 5000)
                return
            report_outlier_fail_method = None
            report_outlier_merge_order = template.report.outlier_merge_order
            report_empty_cells_as_fail = template.report.outlier_treat_empty_cells_as_fail
            built_golden_path = self._path_value(self.ui.goldenPathEdit) or None
            dataset_ids, dimension_filters, column_filters = self._collect_database_analysis_filters(
                analysis_scope, template=template
            )
            if analysis_scope == "checked_imports" and not self._confirm_selected_analysis_scope(dataset_ids):
                self.statusBar().showMessage("Analysis cancelled.", 5000)
                return
            if self._should_use_report_mode(template):
                report_outlier_fail_method = template.report.outlier_fail_method

            zscore_threshold_override = template.report.zscore_thresholds.default
        except Exception as exc:
            self._show_error("Analysis failed", exc)
            return
        storage_path = self._active_storage_path()
        if self._analysis_requires_golden_file() and not built_golden_path:
            self._show_error(
                "Analysis failed",
                ValueError(
                    "Golden File is required for Golden Deviation or Use Golden Range for Z Score. "
                    "Build/select a Golden file, or disable Use Golden Range for Z Score to use the analysis population."
                ),
            )
            return

        export_kinds = self._choose_analysis_exports()
        if export_kinds is None:
            return
        request = {
            "analysis_scope": analysis_scope,
            "template_path": template_path,
            "template_payload": template_to_payload(template),
            "storage_path": storage_path,
            "built_golden_path": built_golden_path,
            "outlier_fail_method_override": report_outlier_fail_method,
            "outlier_merge_order_override": report_outlier_merge_order,
            "outlier_treat_empty_cells_as_fail_override": report_empty_cells_as_fail,
            "zscore_threshold_override": zscore_threshold_override,
            "dataset_ids": dataset_ids,
            "dimension_filters": dimension_filters,
            "column_filters": column_filters,
            "export_kinds": export_kinds,
            "output_base_path": self._path_value(self.ui.outputPathEdit) or str(
                default_database_output_path(self._database_root_path())
            ),
        }
        if "outlier" in export_kinds:
            # Discover only node choices, without numerical analysis. Freeze the
            # request before background work so subsequent UI edits cannot alter it.
            request = deepcopy(request)
            node_request = {name: request[name] for name in (
                "template_path", "template_payload", "storage_path", "dataset_ids",
                "dimension_filters", "column_filters",
            )}
            self._start_background_task(
                "Preparing Outlier Export",
                lambda progress: list_outlier_export_nodes_from_storage(
                    **node_request, progress_callback=progress,
                ),
                lambda nodes: self._confirm_outlier_export_before_analysis(request, nodes),
            )
        else:
            self._prepare_analysis_exports_and_start(request)

    def _confirm_outlier_export_before_analysis(self, request: dict, nodes: list[str]) -> None:
        dialog = OutlierExportDialog(nodes, self, before_analysis=True)
        if dialog.exec() != QDialog.Accepted:
            self.statusBar().showMessage("Analysis cancelled.", 5000)
            return
        self._prepare_analysis_exports_and_start({**request, "outlier_export_scope": dialog.export_scope()})

    def _prepare_analysis_exports_and_start(self, request: dict) -> None:
        """Finish all normal output decisions before any analysis is dispatched."""
        try:
            paths = {}
            for kind in request["export_kinds"]:
                path = self._prepare_report_output_path(kind, request["output_base_path"])
                if path is None:
                    self.statusBar().showMessage("Analysis cancelled.", 5000)
                    return
                paths[kind] = path
            self._start_analysis_process({**request, "export_paths": paths})
        except Exception as exc:
            self._cleanup_analysis_temp_output()
            self._clear_report_export_requests()
            self._show_error("Prepare analysis failed", exc)

    def _prepare_report_output_path(self, kind: str, base_path: str) -> str | None:
        output_path = derive_split_output_paths(base_path)[kind].with_suffix(".xlsx")
        if output_path.is_dir():
            raise IsADirectoryError(f"Excel output path is a directory: {output_path}")
        resolved_path = self._resolve_existing_output_path(output_path, f"{kind.title()} Excel")
        if resolved_path is None:
            return None
        target = Path(resolved_path).expanduser().absolute()
        target.parent.mkdir(parents=True, exist_ok=True)
        # Check the destination without touching existing report contents.
        with TemporaryFile(dir=target.parent):
            pass
        if target.exists():
            with target.open("r+b"):
                pass
        return str(target)

    def _choose_analysis_exports(self) -> list[str] | None:
        dialog = AnalysisOutputDialog(self)
        return dialog.export_kinds() if dialog.exec() == QDialog.Accepted else None

    def _confirm_selected_analysis_scope(self, dataset_ids: list[str]) -> bool:
        dialog = QDialog(self)
        ui = Ui_AnalysisScopeDialog()
        ui.setupUi(dialog)
        selected_ids = set(dataset_ids)
        entries = []
        for index in range(self.ui.analysisImportsListWidget.count()):
            item = self.ui.analysisImportsListWidget.item(index)
            if str(item.data(Qt.UserRole)) in selected_ids:
                entries.append(item.text())
        ui.selectedImportsEdit.setPlainText("\n".join(entries))
        ui.confirmButton.clicked.connect(dialog.accept)
        ui.cancelButton.clicked.connect(dialog.reject)
        return dialog.exec() == QDialog.Accepted

    def _handle_run_analysis_completed(self, result: dict[str, object]) -> None:
        payload = dict(result["payload"])
        cache_path = result.get("zscore_cache_path")
        if cache_path and self._pending_outlier_snapshot_directory is not None:
            expected = Path(self._pending_outlier_snapshot_directory.name) / "zscore-cache-output.pickle"
            if Path(str(cache_path)) == expected:
                _read_analysis_zscore_cache(expected)
        snapshot_path = result.get("snapshot_path")
        self._clear_outlier_export_snapshot()
        if snapshot_path and Path(str(snapshot_path)).is_file():
            self._outlier_snapshot_directory = self._pending_outlier_snapshot_directory
            self._pending_outlier_snapshot_directory = None
            self._outlier_snapshot_path = str(snapshot_path)
            self._analysis_snapshot_path = result.get("analysis_snapshot_path")
            self._tsk_analysis_snapshot = result.get("tsk_analysis_snapshot")
            self._tsk_snapshot_path = result.get("tsk_snapshot_path")
            self._outlier_analysis_template = result.get("analysis_template")
            self._outlier_export_result_id = uuid4().hex
            self._outlier_export_nodes = list(result.get("available_nodes", []))
        else:
            self._cleanup_analysis_temp_output()
        self._update_report_export_state()
        self._sync_tsk_fail_rules()
        golden_coverage_summary = result["golden_coverage_summary"]
        outlier_summary_rows = result["outlier_summary_stats_rows"]
        outlier_ratio_rows = result["outlier_ratio_rows"]
        self.current_golden_coverage_summary = golden_coverage_summary
        self.current_outlier_summary_rows = outlier_summary_rows
        self.current_outlier_ratio_rows = outlier_ratio_rows
        self.current_plot_inspector_snapshot = result.get("plot_inspector_snapshot")
        self._refresh_golden_coverage_view(golden_coverage_summary)
        self._refresh_outlier_summary_view(outlier_summary_rows, outlier_ratio_rows)
        if outlier_summary_rows or outlier_ratio_rows:
            self.ui.resultTabWidget.setCurrentWidget(self.ui.outlierSummaryTab)
        elif golden_coverage_summary:
            self.ui.resultTabWidget.setCurrentWidget(self.ui.goldenCoverageTab)
        else:
            self.ui.resultTabWidget.setCurrentWidget(self.ui.logTab)
        self._log("Analysis completed (Excel export is available separately):\n" + json.dumps(payload, ensure_ascii=False, indent=2))
        self._verbose_log_storage_snapshot("After Run Analysis")
        self.statusBar().showMessage("Analysis completed. Choose Export Outlier Excel or Export Data Excel.", 5000)
        self._queued_report_exports = self._analysis_requested_exports
        self._analysis_requested_exports = []
        self._queued_outlier_export_scope = self._analysis_requested_outlier_scope
        self._analysis_requested_outlier_scope = None
        self._queued_report_export_paths = self._analysis_requested_export_paths
        self._analysis_requested_export_paths = {}
        if self._queued_report_exports:
            QTimer.singleShot(0, self._export_next_report)

    def _update_report_export_state(self, *, busy: bool = False) -> None:
        available = bool(self._outlier_snapshot_path and Path(self._outlier_snapshot_path).is_file())
        self.ui.exportOutlierButton.setEnabled(available and not busy)
        self.ui.exportDataButton.setEnabled(available and not busy)
        label = self.ui.reportExportStatusLabel
        state = "readyText" if available else "emptyText"
        if not available:
            if self._analysis_snapshot_restore_error:
                state = "restoreErrorText"
            elif self.current_outlier_summary_rows or self.current_outlier_ratio_rows or self._tsk_analysis_snapshot:
                state = "legacyText"
        label.setText(str(label.property(state)))
        label.setToolTip(self._analysis_snapshot_restore_error or "")

    def _clear_outlier_export_snapshot(self) -> None:
        if self._outlier_snapshot_directory is not None:
            self._outlier_snapshot_directory.cleanup()
            self._outlier_snapshot_directory = None
        if self._restored_tsk_snapshot_directory is not None:
            self._restored_tsk_snapshot_directory.cleanup()
            self._restored_tsk_snapshot_directory = None
        self._tsk_analysis_snapshot = None
        self._tsk_snapshot_path = None
        self._tsk_snapshot_restore_error = None
        self._outlier_snapshot_path = None
        self._analysis_snapshot_path = None
        self._analysis_snapshot_restore_error = None
        self._outlier_analysis_template = None
        self._outlier_export_result_id = None
        self._outlier_export_nodes = []
        self._update_report_export_state()
        self._sync_tsk_fail_rules()
        from ..tsk_coordinate_data import coordinate_preview_from_template
        self.ui.tskResultsPanel.set_coordinate_preview(coordinate_preview_from_template(self.ui.tskAnalysisPanel.template))

    def _export_outlier_report(self) -> bool:
        if not self._outlier_snapshot_path:
            return False
        dialog = OutlierExportDialog(self._outlier_export_nodes, self)
        if dialog.exec() == QDialog.Accepted:
            return self._start_report_export("outlier", dialog.export_scope())
        return False

    def _export_data_report(self) -> None:
        self._start_report_export("data")

    def _export_next_report(self) -> None:
        if not self._queued_report_exports or not self._outlier_snapshot_path:
            return
        kind = self._queued_report_exports.pop(0)
        scope = self._queued_outlier_export_scope if kind == "outlier" else None
        if kind == "outlier":
            self._queued_outlier_export_scope = None
        resolved_path = self._queued_report_export_paths.pop(kind)
        started = self._start_report_export(kind, scope, resolved_output_path=resolved_path)
        if not started and self._queued_report_exports:
            QTimer.singleShot(0, self._export_next_report)

    def _start_report_export(
        self, kind: str, scope: dict | None = None, *, resolved_output_path: str | None = None,
    ) -> bool:
        if self._active_task_thread is not None or self._analysis_process is not None:
            return False
        if not self._outlier_snapshot_path or not Path(self._outlier_snapshot_path).is_file():
            self._update_report_export_state()
            return False
        try:
            resolved_path = resolved_output_path
            if resolved_path is None:
                base_path = self._path_value(self.ui.outputPathEdit) or str(default_database_output_path(self._database_root_path()))
                resolved_path = self._prepare_report_output_path(kind, base_path)
            if resolved_path is None:
                return False
            Path(resolved_path).parent.mkdir(parents=True, exist_ok=True)
            self._analysis_final_output_path = resolved_path
            self._analysis_temp_output_path = self._prepare_analysis_temp_output_path(resolved_path)
            self._report_export_kind = kind
            self._start_process_task(
                f"Export {kind.title()} Excel", _run_report_export_in_subprocess,
                {"kind": kind, "scope": scope, "snapshot_path": self._outlier_snapshot_path,
                 "temp_output_path": self._analysis_temp_output_path},
                self._handle_report_export_completed,
            )
            return True
        except Exception as exc:
            self._cleanup_analysis_temp_output()
            self._clear_report_export_requests()
            self._show_error("Export failed", exc)
            return False

    def _handle_report_export_completed(self, payload: dict) -> None:
        output_path = self._analysis_final_output_path
        kind = self._report_export_kind
        self._finalize_analysis_output_file()
        payload = {**payload, "output": output_path, "outputs": {kind: output_path}}
        self._log("Report exported:\n" + json.dumps(payload, ensure_ascii=False, indent=2))
        self.statusBar().showMessage(f"Export completed: {output_path}", 10000)
        if self._queued_report_exports:
            QTimer.singleShot(0, self._export_next_report)

    def _refresh_storage_overview(self, silent: bool = False, *, payload=None, entries=None) -> None:
        database_root = self._database_root_path()
        if not database_root:
            self._clear_storage_snapshot("Database folder is empty.")
            return
        storage_path = self._storage_path_for_read()
        if payload is None:
            template_path = self._path_value(self.ui.templatePathEdit) or None
            if template_path and not available_path(Path(template_path)):
                template_path = None
            try:
                storage_path = self._storage_path_for_read()
                payload = describe_storage(storage_path, template_path=template_path, limit=500)
            except Exception as exc:
                self._clear_storage_snapshot(f"Current database view unavailable: {exc}")
                if not silent:
                    self._show_error("Refresh database view failed", exc)
                return

        combo = self.ui.storageImportComboBox
        selected = combo.currentData()
        if not self._storage_overview_payload or self._storage_overview_payload.get("storage") != payload.get("storage"):
            selected = None
        self._storage_overview_payload = payload
        imports = payload.get("imports", [])
        combo.blockSignals(True)
        combo.clear()
        if len(imports) != 1:
            combo.addItem(f"{combo.property('allImportsText')} ({len(imports)})", None)
        selected_index = 0
        for number, entry in enumerate(imports, 1):
            key = (entry["dataset_id"], entry["source_file"])
            filename = entry["source_file"].replace("\\", "/").rsplit("/", 1)[-1]
            combo.addItem(f"#{number}  {filename}", key)
            tooltip = "\n".join(str(value) for value in (
                entry["source_file"], f"Batch: {entry['dataset_id']}",
                entry.get("template_name"), entry.get("created_at_utc"),
            ) if value)
            combo.setItemData(combo.count() - 1, tooltip, Qt.ToolTipRole)
            if selected is not None and tuple(selected) == key:
                selected_index = combo.count() - 1
        combo.setCurrentIndex(selected_index)
        combo.setEnabled(bool(imports))
        combo.blockSignals(False)
        self.ui.storageSummaryLabel.setToolTip(
            f"Database: {absolute_path(database_root, app_root())}\n"
            f"Workspace: {absolute_path(storage_path, app_root())}"
        )
        self._render_storage_snapshot()
        self._refresh_analysis_imports(silent=True, entries=entries)

    def _clear_storage_snapshot(self, message: str) -> None:
        self._storage_overview_payload = None
        self.current_storage_headers = []
        self.ui.storageSummaryLabel.setText(message)
        self.ui.storageSummaryLabel.setToolTip("")
        self.ui.storageSharedInfoLabel.clear()
        self.ui.storageSharedInfoLabel.hide()
        combo = self.ui.storageImportComboBox
        combo.blockSignals(True)
        combo.clear()
        combo.addItem(str(combo.property("allImportsText")), None)
        combo.setToolTip("")
        combo.setEnabled(False)
        combo.blockSignals(False)
        self._populate_table(self.ui.storageTableWidget, ["Current Database Rows"], [])
        self.ui.deleteSelectedRowsButton.setEnabled(False)
        self.ui.deleteCurrentSourceButton.setEnabled(False)

    def _render_storage_snapshot(self) -> None:
        payload = self._storage_overview_payload
        if payload is None:
            return
        combo = self.ui.storageImportComboBox
        selected = combo.currentData()
        imports = payload.get("imports", [])
        view = payload
        if selected is not None:
            view = next((entry for entry in imports
                         if (entry["dataset_id"], entry["source_file"]) == tuple(selected)), payload)
        combo.setToolTip(str(combo.itemData(combo.currentIndex(), Qt.ToolTipRole) or ""))
        shared = view.get("common_values", {})
        always_visible = set(self.ui.storageTableWidget.property("alwaysVisibleDimensions") or [])
        always_visible.add(str(self.identity_controls.node_combo.currentData() or ""))
        fields = [name for name in [*payload["dimensions"], "measurement_count"]
                  if name not in shared or name in always_visible]
        show_import = view is payload and len(imports) > 1
        headers = ["row_number", *(["Import"] if show_import else []), *fields]
        import_numbers = {(entry["dataset_id"], entry["source_file"]): f"#{number}"
                          for number, entry in enumerate(imports, 1)}
        rows, selectors = [], []
        for item in view["rows"]:
            values = [str(item["row_number"])]
            if show_import:
                values.append(import_numbers[(item["dataset_id"], item["source_file"])])
            values.extend(str(item.get(name, "")) for name in fields)
            rows.append(values)
            selectors.append({name: item[name] for name in ("dataset_id", "source_file", "row_number")})
        self.current_storage_headers = headers
        self._populate_table(self.ui.storageTableWidget, headers, rows, row_data=selectors)
        parts = []
        for name, value in shared.items():
            if name in fields or value == "" or value is None:
                continue
            if name == "measurement_count":
                noun = "measurement" if value == 1 else "measurements"
                parts.append(f"{value:,} {noun} / row")
            else:
                parts.append(f"{self._display_header_label(name)}: {value}")
        self.ui.storageSharedInfoLabel.setText(
            str(self.ui.storageSharedInfoLabel.property("prefixText")) + " · ".join(parts)
        )
        self.ui.storageSharedInfoLabel.setVisible(bool(parts))
        import_count = len(imports) if view is payload else 1
        import_noun = "import" if import_count == 1 else "imports"
        summary = f"{import_count:,} {import_noun} · {view['row_count']:,} rows · {view['measurement_count']:,} measurements"
        if view["truncated"]:
            summary += f"\nShowing the first {len(view['rows']):,} rows."
        self.ui.storageSummaryLabel.setText(summary)
        self.ui.deleteSelectedRowsButton.setEnabled(False)
        self.ui.deleteCurrentSourceButton.setEnabled(view is not payload and bool(view["row_count"]))

    def _refresh_golden_coverage_view(self, summary: dict | None) -> None:
        if not summary:
            self.ui.goldenCoverageSummaryLabel.setText(
                "No built golden coverage checked yet."
            )
            self._populate_table(
                self.ui.goldenCoverageSummaryTableWidget,
                ["scope", "total_measurement_count", "matched_measurement_count", "unmatched_measurement_count", "matched_row_count", "unmatched_row_count"],
                [],
            )
            self._populate_table(
                self.ui.goldenCoverageExamplesTableWidget,
                ["row_number", "dataset_id", "logical_metric", "raw_column", "dimensions"],
                [],
            )
            return

        self.ui.goldenCoverageSummaryLabel.setText(
            (
                f"Built golden coverage for {summary.get('scope', 'analysis')}: "
                f"{summary.get('matched_measurement_count', 0)}/"
                f"{summary.get('total_measurement_count', 0)} measurements matched."
            )
        )
        summary_headers = [
            "scope",
            "total_measurement_count",
            "matched_measurement_count",
            "unmatched_measurement_count",
            "matched_row_count",
            "unmatched_row_count",
        ]
        self._populate_table(
            self.ui.goldenCoverageSummaryTableWidget,
            summary_headers,
            [[str(summary.get(header, "")) for header in summary_headers]],
        )
        example_headers = ["row_number", "dataset_id", "logical_metric", "raw_column", "dimensions"]
        example_rows = [
            [
                str(item.get("row_number", "")),
                str(item.get("dataset_id", "")),
                str(item.get("logical_metric", "")),
                str(item.get("raw_column", "")),
                json.dumps(item.get("dimensions", {}), ensure_ascii=False, sort_keys=True),
            ]
            for item in summary.get("unmatched_examples", [])
        ]
        self._populate_table(
            self.ui.goldenCoverageExamplesTableWidget,
            example_headers,
            example_rows,
        )

    def _update_outlier_ratio_search_count(self) -> None:
        label = self.ui.outlierRatioSearchCountLabel
        label.setText(label.property("formatText").format(
            shown=self._outlier_ratio_model.rowCount(),
            total=self._outlier_ratio_model.total_row_count(),
        ))
        self.ui.outlierRatioClearFiltersButton.setEnabled(self._outlier_ratio_model.has_column_filters())
        self.ui.outlierRatioHeader.viewport().update()

    def _refresh_outlier_summary_view(
        self,
        rows: list[dict[str, object]],
        ratio_rows: list[dict[str, object]],
    ) -> None:
        self._outlier_ratio_model.set_navigation_available(bool(self.current_plot_inspector_snapshot))
        if not rows and not ratio_rows:
            self.ui.outlierSummaryLabel.setText("No outlier summary statistics available for the current analysis scope.")
            self._populate_table(
                self.ui.outlierSummaryTableWidget,
                ["metric", "value", "note"],
                [],
            )
            self.ui.outlierRatioSummaryLabel.setText("No outlier ratio statistics configured for the current analysis scope.")
            self._outlier_ratio_model.set_rows([])
            return
        self.ui.outlierSummaryLabel.setText(
            f"Current outlier summary statistics contain {len(rows)} row(s)."
        )
        self._populate_table(
            self.ui.outlierSummaryTableWidget,
            ["metric", "value", "note"],
            [
                [
                    str(item.get("metric", "")),
                    str(item.get("value", "")),
                    str(item.get("note", "")),
                ]
                for item in rows
            ],
        )
        linked = bool(self.current_plot_inspector_snapshot) and any(
            isinstance(row.get("plot_navigation"), dict) and row["plot_navigation"].get("targets")
            for row in ratio_rows
        )
        has_ids = any(row.get("lot_sample_pairs") for row in ratio_rows)
        help_property = "linkedHelpText" if linked else "legacyHelpText" if has_ids else "emptyHelpText"
        help_text = self.ui.outlierRatioSummaryLabel.property(help_property)
        self.ui.outlierRatioSummaryLabel.setText(
            f"Current outlier ratio statistics contain {len(ratio_rows)} row(s).\n{help_text}"
        )
        self._outlier_ratio_model.set_rows(ratio_rows)
        # Inspect a bounded sample rather than all rows for each column.
        self.ui.outlierRatioTableWidget.resizeColumnsToContents()

    def _refresh_analysis_imports(self, silent: bool = False, *, entries=None) -> None:
        widget = self.ui.analysisImportsListWidget
        checked_ids = set(self._selected_analysis_dataset_ids())
        widget.blockSignals(True)
        widget.clear()
        database_root = self._database_root_path()
        if not database_root:
            widget.blockSignals(False)
            self.ui.tskAnalysisPanel.set_import_entries([])
            return
        try:
            if entries is None:
                entries = list_import_history(self._storage_path_for_read())
        except Exception as exc:
            widget.blockSignals(False)
            if not silent:
                self._show_error("Refresh import list failed", exc)
            return
        for entry in entries:
            dataset_id = str(entry.get("dataset_id", ""))
            created_at = str(entry.get("created_at_utc", ""))
            source_file = Path(str(entry.get("source_file", "") or "")).name
            measurement_count = entry.get("measurement_count", "")
            label = (
                f"{created_at} | {dataset_id} | {source_file} | "
                f"{measurement_count} measurements"
            )
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, dataset_id)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if dataset_id in checked_ids else Qt.Unchecked)
            widget.addItem(item)
        widget.blockSignals(False)

        self.ui.tskAnalysisPanel.set_import_entries(entries)

    def _update_analysis_mode_state(self) -> None:
        checked_imports_scope = self._analysis_scope_code() == "checked_imports"
        self.ui.goldenPathEdit.setEnabled(True)
        self.ui.browseGoldenButton.setEnabled(True)
        self.ui.analysisSampleIdsEdit.setEnabled(self._template_edit_unlocked)
        self.ui.analysisExcludeSampleIdsEdit.setEnabled(self._template_edit_unlocked)
        self.ui.analysisNodesEdit.setEnabled(self._template_edit_unlocked)
        self.ui.analysisExcludeNodesEdit.setEnabled(self._template_edit_unlocked)
        self.ui.analysisTestsEdit.setEnabled(self._template_edit_unlocked)
        self.ui.analysisExcludeTestsEdit.setEnabled(self._template_edit_unlocked)
        self.ui.refreshAnalysisImportsButton.setEnabled(True)
        self.ui.analysisImportsListWidget.setEnabled(checked_imports_scope)
        self.ui.outputPathEdit.setEnabled(True)
        self.ui.browseOutputButton.setEnabled(True)
        self._update_golden_threshold_mode_state()

    def _update_golden_threshold_mode_state(self) -> None:
        try:
            terms = outlier_golden_method_terms(self._outlier_golden_method_text())
        except Exception:
            terms = {"relative", "sigma", "mad", "absolute"}
        try:
            modifiers = outlier_golden_method_modifiers(self._outlier_golden_method_text())
        except Exception:
            modifiers = {"overwrite_lowerbound", "overwrite_upperbound"}
        self.ui.relativeLimitSpinBox.setEnabled(self._template_edit_unlocked and "relative" in terms)
        self.ui.sigmaMultiplierSpinBox.setEnabled(self._template_edit_unlocked and "sigma" in terms)
        self.ui.madMultiplierSpinBox.setEnabled(self._template_edit_unlocked and "mad" in terms)
        self.ui.absoluteLowerBoundEdit.setEnabled(self._template_edit_unlocked and "absolute" in terms)
        self.ui.absoluteUpperBoundEdit.setEnabled(self._template_edit_unlocked and "absolute" in terms)
        self.ui.overwriteMinEdit.setEnabled(self._template_edit_unlocked and "overwrite_lowerbound" in modifiers)
        self.ui.overwriteMaxEdit.setEnabled(self._template_edit_unlocked and "overwrite_upperbound" in modifiers)

    def _ensure_required_paths(self, require_input: bool) -> None:
        self._ensure_template_path()
        if require_input and not self._path_value(self.ui.inputPathEdit):
            raise ValueError("Input Excel/CSV path is required.")
        if not self._database_root_path():
            raise ValueError("Storage Folder is required.")

    def _ensure_report_paths(self) -> None:
        self._ensure_template_path()
        if not self._path_value(self.ui.inputPathEdit):
            raise ValueError("Input Excel/CSV path is required.")

    def _ensure_analysis_paths(self, analysis_scope: str) -> None:
        self._ensure_template_path()
        if analysis_scope not in ANALYSIS_SCOPE_CODES:
            raise ValueError("Unsupported analysis scope. Choose Entire Database or Selected Database.")
        if not self._database_root_path():
            raise ValueError("Database Folder is required.")

    def _ensure_template_path(self) -> str:
        template_path = self._path_value(self.ui.templatePathEdit)
        if not template_path:
            raise ValueError("Template path is required.")
        return template_path

    def _outlier_golden_method_text(self) -> str:
        return str(self.ui.thresholdModeComboBox.currentText() or "").strip()

    def _resolved_outlier_golden_method(self) -> str:
        return normalize_outlier_golden_method(self._outlier_golden_method_text())

    def _outlier_merge_order_text(self) -> str:
        return str(self.ui.outlierMergeOrderComboBox.currentText() or "").strip()

    def _resolve_relative_limit(self) -> float | None:
        if (
            "relative" in outlier_golden_method_terms(self._resolved_outlier_golden_method())
            or self._template_backed_golden_values.get("relative_limit") is not None
        ):
            return None if self.ui.relativeLimitSpinBox.value() == -1 else self.ui.relativeLimitSpinBox.value()
        return None

    def _resolve_sigma_multiplier(self) -> float | None:
        if (
            "sigma" in outlier_golden_method_terms(self._resolved_outlier_golden_method())
            or self._template_backed_golden_values.get("sigma_multiplier") is not None
        ):
            return None if self.ui.sigmaMultiplierSpinBox.value() == -1 else self.ui.sigmaMultiplierSpinBox.value()
        return None

    def _resolve_mad_multiplier(self) -> float | None:
        if (
            "mad" in outlier_golden_method_terms(self._resolved_outlier_golden_method())
            or self._template_backed_golden_values.get("mad_multiplier") is not None
        ):
            return None if self.ui.madMultiplierSpinBox.value() == -1 else self.ui.madMultiplierSpinBox.value()
        return None

    def _parse_optional_float_text(self, text: str, label: str) -> float | None:
        value = text.strip()
        if not value:
            return None
        try:
            return float(value)
        except ValueError as exc:
            raise ValueError(f"{label} must be a valid number.") from exc

    def _resolve_absolute_lower_bound(self) -> float | None:
        if (
            "absolute" in outlier_golden_method_terms(self._resolved_outlier_golden_method())
            or self._template_backed_golden_values.get("absolute_lower_bound") is not None
        ):
            return self._parse_optional_float_text(
                self.ui.absoluteLowerBoundEdit.text(),
                "Absolute Lower Bound",
            )
        return None

    def _resolve_absolute_upper_bound(self) -> float | None:
        if (
            "absolute" in outlier_golden_method_terms(self._resolved_outlier_golden_method())
            or self._template_backed_golden_values.get("absolute_upper_bound") is not None
        ):
            return self._parse_optional_float_text(
                self.ui.absoluteUpperBoundEdit.text(),
                "Absolute Upper Bound",
            )
        return None

    def _resolve_overwrite_lowerbound(self) -> float | None:
        if (
            "overwrite_lowerbound"
            in outlier_golden_method_modifiers(self._resolved_outlier_golden_method())
            or self._template_backed_golden_values.get("overwrite_lowerbound") is not None
        ):
            return self._parse_optional_float_text(
                self.ui.overwriteMinEdit.text(),
                "Overwrite Lower Bound",
            )
        return None

    def _resolve_overwrite_upperbound(self) -> float | None:
        if (
            "overwrite_upperbound"
            in outlier_golden_method_modifiers(self._resolved_outlier_golden_method())
            or self._template_backed_golden_values.get("overwrite_upperbound") is not None
        ):
            return self._parse_optional_float_text(
                self.ui.overwriteMaxEdit.text(),
                "Overwrite Upper Bound",
            )
        return None

    def _resolve_continuous_interval(self) -> bool:
        return bool(self.ui.continuousIntervalCheckBox.isChecked())

    def _resolve_empty_range_fallback_to_absolute(self) -> bool:
        return bool(self.ui.emptyRangeFallbackCheckBox.isChecked())

    def _parse_numeric_cleanup_chars(self) -> list[str]:
        text = self.ui.numericCleanupCharsEdit.text().strip()
        if not text:
            return []
        return [item.strip() for item in text.split(";") if item.strip()]

    def _database_root_path(self) -> str:
        return self._path_value(self.ui.storagePathEdit)

    def _active_storage_path(self) -> str:
        database_root = self._database_root_path()
        if not database_root:
            return ""
        if self.current_workspace_path:
            return self.current_workspace_path
        self._ensure_storage_workspace_for_current_database(silent=True)
        return self.current_workspace_path

    def _storage_path_for_read(self) -> str:
        if self.current_workspace_path:
            return self.current_workspace_path
        database_root = self._database_root_path()
        return str(absolute_path(database_root, app_root())) if database_root else ""

    def _ensure_storage_workspace_for_current_database(self, silent: bool) -> None:
        database_root = self._database_root_path()
        if not database_root:
            self.current_workspace_path = ""
            return
        try:
            payload = ensure_storage_workspace(database_root)
        except Exception as exc:
            self.current_workspace_path = ""
            if not silent:
                self._show_error("Prepare database workspace failed", exc)
            return
        self.current_workspace_path = str(Path(payload["workspace"]).resolve())

    def _refresh_default_output_path(self) -> None:
        database_root = self._database_root_path()
        if not database_root:
            self.ui.outputPathEdit.setText(
                self._display_path(default_output_path("sample_chip_data_real_result.xlsx"))
            )
            return
        self.ui.outputPathEdit.setText(
            self._display_path(default_database_output_path(database_root))
        )

    def _refresh_database_scoped_paths(
        self,
        previous_database_root: str | Path | None,
        new_database_root: str | Path | None,
    ) -> None:
        if not new_database_root:
            return
        new_root = absolute_path(new_database_root, app_root())
        previous_root = absolute_path(previous_database_root, app_root()) if previous_database_root else None

        current_output = self._path_value(self.ui.outputPathEdit)
        if current_output:
            remapped_output = self._remap_database_scoped_path(
                current_output,
                previous_root,
                new_root,
                category="result",
            )
            if remapped_output is not None:
                self.ui.outputPathEdit.setText(self._display_path(str(remapped_output)))
        else:
            self.ui.outputPathEdit.setText(self._display_path(default_database_output_path(new_root)))

        current_golden = self._path_value(self.ui.goldenPathEdit)
        if current_golden:
            remapped_golden = self._remap_database_scoped_path(
                current_golden,
                previous_root,
                new_root,
                category="golden",
            )
            if remapped_golden is not None:
                self.ui.goldenPathEdit.setText(self._display_path(str(remapped_golden)))

    @staticmethod
    def _remap_database_scoped_path(
        current_path: str,
        previous_database_root: Path | None,
        new_database_root: Path,
        category: str,
    ) -> Path | None:
        try:
            path = absolute_path(current_path, app_root())
        except Exception:
            return None

        category_dir_name = "result" if category == "result" else "golden"
        candidate_bases: list[tuple[Path, Path]] = []
        if previous_database_root is not None:
            candidate_bases.extend(
                [
                    (previous_database_root / category_dir_name, new_database_root / category_dir_name),
                    (previous_database_root / "temp" / category_dir_name, new_database_root / category_dir_name),
                    (previous_database_root / "temp", new_database_root / category_dir_name),
                ]
            )
        candidate_bases.extend(
            [
                (new_database_root / "temp" / category_dir_name, new_database_root / category_dir_name),
                (new_database_root / "temp", new_database_root / category_dir_name),
            ]
        )

        for source_base, target_base in candidate_bases:
            try:
                relative = path.relative_to(source_base)
            except ValueError:
                continue
            return target_base / relative
        return None

    def _prompt_workspace_recovery_if_needed(self) -> None:
        database_root = self._database_root_path()
        if not database_root:
            return
        try:
            payload = storage_workspace_differs(database_root)
        except Exception as exc:
            self._show_error("Check temp workspace failed", exc)
            return
        if not payload.get("differs"):
            return
        response = QMessageBox(self)
        response.setWindowTitle("Unsaved Temp Workspace Found")
        response.setIcon(QMessageBox.Warning)
        response.setText(
            (
                "This database contains a temp workspace that is different from the last saved database.\n\n"
                f"Database root:\n{database_root}\n\n"
                f"Temp workspace:\n{payload.get('workspace', '')}"
            )
        )
        response.setInformativeText(
            "Choose Continue Temp Workspace to keep working from temp/, or Discard Temp And Reload Saved Database to drop those unsaved temp changes."
        )
        continue_button = response.addButton("Continue Temp Workspace", QMessageBox.AcceptRole)
        discard_button = response.addButton("Discard Temp And Reload Saved Database", QMessageBox.DestructiveRole)
        response.setDefaultButton(continue_button)
        self._ensure_message_box_button_widths(response)
        response.exec()
        if response.clickedButton() == discard_button:
            try:
                reset_payload = discard_storage_workspace_changes(database_root)
            except Exception as exc:
                self._show_error("Discard temp workspace failed", exc)
                return
            self.current_workspace_path = str(Path(reset_payload["workspace"]).resolve())
            self._log(
                "Discarded temp workspace changes and reloaded saved database:\n"
                + json.dumps(reset_payload, ensure_ascii=False, indent=2)
            )
        else:
            self._log(
                "Continuing with unsaved temp workspace:\n"
                + json.dumps(payload, ensure_ascii=False, indent=2)
            )

    def _show_error(self, title: str, exc: Exception) -> None:
        self._log(f"{title}: {exc}")
        QMessageBox.critical(self, title, str(exc))
        self.statusBar().showMessage(title, 5000)

    @staticmethod
    def _ensure_message_box_button_widths(message_box: QMessageBox) -> None:
        for button in message_box.buttons():
            desired_width = max(
                button.minimumSizeHint().width(),
                button.sizeHint().width(),
            )
            button.setMinimumWidth(desired_width)

    def _log(self, message: str) -> None:
        timestamp = QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
        self.ui.logPlainTextEdit.appendPlainText(f"[{timestamp}] {message}")

    @staticmethod
    def _should_use_report_mode(template) -> bool:
        return bool(
            template.test_data_header_row != template.row_header_row
            or template.unit_row is not None
        )

    def _analysis_requires_golden_file(self) -> bool:
        return self._outlier_fail_mode_code() in {
            "golden_deviation",
            "zscore_and_golden",
            "zscore_or_golden",
        } or self.ui.zscoreUseGoldenCheckBox.isChecked()

    def _update_zscore_reference_state(self, *_args) -> None:
        self.ui.zscoreUseGoldenCheckBox.setEnabled(
            self._template_edit_unlocked and self._outlier_fail_mode_code() != "golden_deviation"
        )

    @staticmethod
    def _format_outlier_method_label(method: str) -> str:
        if method == "golden_deviation":
            return "Golden Deviation"
        if method == "zscore_and_golden":
            return "Modified Z Score And Golden Deviation"
        if method == "zscore_or_golden":
            return "Modified Z Score Or Golden Deviation"
        return "Modified Z Score"

    def _prompt_import_conflict_mode(self, preview: dict) -> str | None:
        message_box = QMessageBox(self)
        message_box.setWindowTitle("Import Conflict Detected")
        message_box.setIcon(QMessageBox.Warning)
        message_box.setText(
            (
                "Current database already contains rows with the same sample attributes.\n\n"
                f"Incoming conflicting rows: {preview['conflict_row_count']}\n"
                f"Existing rows affected: {preview['existing_conflict_row_count']}"
            )
        )

        preview_lines = []
        for item in preview["conflict_rows_preview"][:5]:
            text = ", ".join(f"{key}={value}" for key, value in item.items() if value != "")
            if text:
                preview_lines.append(text)
        informative_lines = [
            "Replace: remove existing rows with the same sample/node/site... key, then import this file.",
        ]
        if preview["has_repeat_dimension"]:
            informative_lines.append(
                "Append: keep existing rows and shift repeat_id upward for the new file."
            )
        else:
            informative_lines.append(
                "Append is unavailable because conflicting rows do not contain a valid repeat_id."
            )
        if preview_lines:
            informative_lines.append("")
            informative_lines.append("Examples:")
            informative_lines.extend(preview_lines)
        message_box.setInformativeText("\n".join(informative_lines))

        replace_button = message_box.addButton("Replace Existing", QMessageBox.AcceptRole)
        append_button = None
        if preview["has_repeat_dimension"]:
            append_button = message_box.addButton("Append And Shift Repeat", QMessageBox.ActionRole)
        cancel_button = message_box.addButton(QMessageBox.Cancel)
        message_box.setDefaultButton(replace_button)
        self._ensure_message_box_button_widths(message_box)
        message_box.exec()

        clicked = message_box.clickedButton()
        if clicked == replace_button:
            return "replace"
        if append_button is not None and clicked == append_button:
            return "append"
        if clicked == cancel_button:
            return None
        return None

    def _selected_analysis_dataset_ids(self) -> list[str]:
        dataset_ids: list[str] = []
        for index in range(self.ui.analysisImportsListWidget.count()):
            item = self.ui.analysisImportsListWidget.item(index)
            if item.checkState() == Qt.Checked:
                dataset_ids.append(str(item.data(Qt.UserRole)))
        return dataset_ids

    @staticmethod
    def _format_analysis_column_filter_text(filters: dict[str, list[str]]) -> str:
        parts: list[str] = []
        for key, values in filters.items():
            normalized_values = [str(value).strip() for value in values if str(value).strip()]
            if normalized_values:
                parts.append(f"{key}={','.join(normalized_values)}")
        return ";".join(parts)

    def _apply_analysis_column_filter_text(
        self,
        widget,
        filters: dict[str, list[str]],
    ) -> None:
        text = self._format_analysis_column_filter_text(filters)
        widget.setReadOnly(False)
        widget.setToolTip(text)
        widget.setText(text)

    @staticmethod
    def _analysis_dimension_filter_text(
        filters: dict[str, list[str]],
        key: str,
        *,
        separator: str,
    ) -> str:
        values = filters.get(key, [])
        normalized_values: list[str] = []
        for value in values:
            text = str(value).strip()
            if not text:
                continue
            if key == "sample_key":
                text = text.replace(";", ",")
            normalized_values.append(text)
        return separator.join(normalized_values)

    @staticmethod
    def _normalize_filter_payload(
        payload: dict[str, dict[str, list[str]]] | None,
    ) -> dict[str, dict[str, list[str]]]:
        normalized: dict[str, dict[str, list[str]]] = {}
        if not isinstance(payload, dict):
            return normalized
        for mode_name, filters in payload.items():
            if not isinstance(filters, dict):
                continue
            normalized_filters: dict[str, list[str]] = {}
            for key, values in filters.items():
                if not isinstance(values, list):
                    continue
                normalized_values = [
                    str(value).strip() for value in values if str(value).strip()
                ]
                if normalized_values:
                    normalized_filters[str(key)] = normalized_values
            if normalized_filters:
                normalized[mode_name] = normalized_filters
        return normalized

    def _resolve_analysis_column_filters(
        self,
        template,
    ) -> dict[str, dict[str, list[str]]]:
        tests = parse_semicolon_items(self.ui.analysisTestsEdit.text().strip())
        exclude_tests = parse_semicolon_items(self.ui.analysisExcludeTestsEdit.text().strip())
        return build_column_filters(
            template,
            include_tests=tests,
            exclude_tests=exclude_tests,
        )

    def _analysis_test_text_for_state(self, mode: str) -> str:
        if mode == "include":
            widget = self.ui.analysisTestsEdit
        else:
            widget = self.ui.analysisExcludeTestsEdit
        return widget.text().strip()

    def _resolve_analysis_dimension_filters(self) -> dict[str, dict[str, list[str]]]:
        return {
            "include": {
                "sample_key": parse_semicolon_items(
                    self.ui.analysisSampleIdsEdit.text().strip()
                ),
                "reliability_node": parse_csv_items(
                    self.ui.analysisNodesEdit.text().strip()
                ),
            },
            "exclude": {
                "sample_key": parse_semicolon_items(
                    self.ui.analysisExcludeSampleIdsEdit.text().strip()
                ),
                "reliability_node": parse_csv_items(
                    self.ui.analysisExcludeNodesEdit.text().strip()
                ),
            },
        }

    def _collect_database_analysis_filters(
        self,
        analysis_scope: str,
        *, template=None,
    ) -> tuple[
        list[str] | None,
        dict[str, dict[str, list[str]]],
        dict[str, dict[str, list[str]]],
    ]:
        dataset_ids: list[str] | None = None
        if analysis_scope == "checked_imports":
            dataset_ids = self._selected_analysis_dataset_ids()
            if not dataset_ids:
                raise ValueError("Please check at least one import entry to analyze.")
        template = template if template is not None else load_template(self._ensure_template_path())
        return (
            dataset_ids,
            self._analysis_dimension_filters_for_template(template),
            self._resolve_analysis_column_filters(template),
        )

    def _analysis_dimension_filters_for_template(self, template, filters=None):
        filters = self._resolve_analysis_dimension_filters() if filters is None else filters
        return build_dimension_filters(
            sample_keys=filters.get("include", {}).get("sample_key", []),
            sample_dimension_names=template.report.sample_dimension_names,
            reliability_node_dimension=template.report.reliability_node_dimension,
            reliability_nodes=filters.get("include", {}).get("reliability_node", []),
            exclude_sample_keys=filters.get("exclude", {}).get("sample_key", []),
            exclude_reliability_nodes=filters.get("exclude", {}).get("reliability_node", []),
        )

    def _collect_template_write_back_diffs(
        self,
        template,
        scope: str,
    ) -> list[dict[str, object]]:
        diffs: list[dict[str, object]] = []
        if scope in {"analysis", "build_golden"}:
            desired_zscore_reference = self.ui.zscoreUseGoldenCheckBox.isChecked()
            if desired_zscore_reference != template.report.zscore_use_golden_reference:
                diffs.append(
                    {
                        "label": "Use Golden Range for Z Score",
                        "gui": str(desired_zscore_reference),
                        "template": str(template.report.zscore_use_golden_reference),
                        "apply": lambda item, desired=desired_zscore_reference: setattr(
                            item.report, "zscore_use_golden_reference", desired,
                        ),
                    }
                )
        if scope == "import":
            desired_numeric_cleanup_enabled = self.ui.numericCleanupCheckBox.isChecked()
            desired_numeric_cleanup_mode = self._combo_code(
                self.ui.numericCleanupModeComboBox
            )
            desired_numeric_cleanup_chars = self._parse_numeric_cleanup_chars()
            template_numeric_cleanup = template.numeric_cleanup
            if desired_numeric_cleanup_enabled != template_numeric_cleanup.enabled:
                diffs.append(
                    {
                        "label": "Numeric Cleanup Enabled",
                        "gui": "Enabled" if desired_numeric_cleanup_enabled else "Disabled",
                        "template": "Enabled"
                        if template_numeric_cleanup.enabled
                        else "Disabled",
                        "apply": lambda item, desired=desired_numeric_cleanup_enabled: setattr(
                            item.numeric_cleanup,
                            "enabled",
                            desired,
                        ),
                    }
                )
            if desired_numeric_cleanup_mode != template_numeric_cleanup.mode:
                diffs.append(
                    {
                        "label": "Numeric Cleanup Mode",
                        "gui": desired_numeric_cleanup_mode,
                        "template": template_numeric_cleanup.mode,
                        "apply": lambda item, desired=desired_numeric_cleanup_mode: setattr(
                            item.numeric_cleanup,
                            "mode",
                            desired,
                        ),
                    }
                )
            if desired_numeric_cleanup_chars != template_numeric_cleanup.characters:
                diffs.append(
                    {
                        "label": "Numeric Cleanup Characters",
                        "gui": ";".join(desired_numeric_cleanup_chars) or "(empty)",
                        "template": ";".join(template_numeric_cleanup.characters)
                        or "(empty)",
                        "apply": lambda item, desired=desired_numeric_cleanup_chars: setattr(
                            item.numeric_cleanup,
                            "characters",
                            list(desired),
                        ),
                    }
                )
            return diffs

        if scope == "analysis":
            desired = self._current_analysis_rules_template(template, validate=False)
            settings = [
                ("sample_dimension_names", "Unique Sample ID Fields", template.report.sample_dimension_names),
                ("reliability_node_dimension", "Reliability Node Row Level", template.report.reliability_node_dimension),
                ("chain_column_level", "Chain Column Level", chain_level(template)),
                ("initial_row_merge_level", "Initial row merge level", initial_row_level(template)),
                ("initial_column_merge_level", "Initial column merge level", initial_column_level(template)),
                *[(backing, public.replace("_", " "), getattr(template.report, backing)) for public, backing in MERGE_RULE_FIELDS.items()],
            ]
            for field, label, previous in settings:
                value = getattr(desired.report, field)
                if value != previous:
                    diffs.append({
                        "label": label,
                        "gui": ";".join(value) if isinstance(value, list) else str(value or "(empty)"),
                        "template": ";".join(previous) if isinstance(previous, list) else str(previous or "(empty)"),
                        "apply": lambda item, name=field, selected=deepcopy(value): setattr(item.report, name, deepcopy(selected)),
                    })
            desired_dimension_filters = self._resolve_analysis_dimension_filters()
            try:
                normalized_dimension_filters = self._analysis_dimension_filters_for_template(desired)
            except ValueError:
                # Let the user restore the template or cancel even if edited filters are invalid.
                normalized_dimension_filters = {SAMPLE_KEY_FILTER: {
                    mode: desired_dimension_filters.get(mode, {}).get("sample_key", [])
                    for mode in ("include", "exclude")
                }}
            template_dimension_filters = self._normalize_filter_payload({
                "include": {
                    key: list(values)
                    for key, values in template.report.analysis_dimension_filters.include.items()
                },
                "exclude": {
                    key: list(values)
                    for key, values in template.report.analysis_dimension_filters.exclude.items()
                },
            })
            desired_sample_filters = {
                "include": normalized_dimension_filters.get(SAMPLE_KEY_FILTER, {}).get(
                    "include", []
                ),
                "exclude": normalized_dimension_filters.get(SAMPLE_KEY_FILTER, {}).get(
                    "exclude", []
                ),
            }
            template_sample_filters = {
                "include": template_dimension_filters.get("include", {}).get(
                    "sample_key", []
                ),
                "exclude": template_dimension_filters.get("exclude", {}).get(
                    "sample_key", []
                ),
            }
            try:
                normalized_template_filters = self._analysis_dimension_filters_for_template(
                    template, template_dimension_filters
                ).get(SAMPLE_KEY_FILTER, {})
                template_sample_filters = {
                    mode: normalized_template_filters.get(mode, [])
                    for mode in ("include", "exclude")
                }
            except ValueError:
                # Keep invalid template text visible in the difference dialog.
                pass
            if desired_sample_filters != template_sample_filters:
                diffs.append(
                    {
                        "label": "Analysis Sample-Key Filters",
                        "gui": (
                            f"include={';'.join(desired_sample_filters.get('include', [])) or '(empty)'} | "
                            f"exclude={';'.join(desired_sample_filters.get('exclude', [])) or '(empty)'}"
                        ),
                        "template": (
                            f"include={';'.join(template_sample_filters.get('include', [])) or '(empty)'} | "
                            f"exclude={';'.join(template_sample_filters.get('exclude', [])) or '(empty)'}"
                        ),
                        "apply": lambda item, desired=desired_dimension_filters: setattr(
                            item.report,
                            "analysis_dimension_filters",
                            item.report.analysis_dimension_filters.__class__(
                                include={
                                    key: list(values)
                                    for key, values in desired.get("include", {}).items()
                                },
                                exclude={
                                    key: list(values)
                                    for key, values in desired.get("exclude", {}).items()
                                },
                            ),
                        ),
                    }
                )
            desired_node_filters = {
                "include": desired_dimension_filters.get("include", {}).get(
                    "reliability_node", []
                ),
                "exclude": desired_dimension_filters.get("exclude", {}).get(
                    "reliability_node", []
                ),
            }
            template_node_filters = {
                "include": template_dimension_filters.get("include", {}).get(
                    "reliability_node", []
                ),
                "exclude": template_dimension_filters.get("exclude", {}).get(
                    "reliability_node", []
                ),
            }
            if desired_node_filters != template_node_filters:
                diffs.append(
                    {
                        "label": "Analysis Node Filters",
                        "gui": (
                            f"include={','.join(desired_node_filters.get('include', [])) or '(empty)'} | "
                            f"exclude={','.join(desired_node_filters.get('exclude', [])) or '(empty)'}"
                        ),
                        "template": (
                            f"include={','.join(template_node_filters.get('include', [])) or '(empty)'} | "
                            f"exclude={','.join(template_node_filters.get('exclude', [])) or '(empty)'}"
                        ),
                        "apply": lambda item, desired=desired_dimension_filters: setattr(
                            item.report,
                            "analysis_dimension_filters",
                            item.report.analysis_dimension_filters.__class__(
                                include={
                                    key: list(values)
                                    for key, values in desired.get("include", {}).items()
                                },
                                exclude={
                                    key: list(values)
                                    for key, values in desired.get("exclude", {}).items()
                                },
                            ),
                        ),
                    }
                )
            desired_outlier = desired.report.outlier_fail_method
            if desired_outlier != template.report.outlier_fail_method:
                diffs.append(
                    {
                        "label": "Outlier Criteria",
                        "gui": self._format_outlier_method_label(desired_outlier),
                        "template": self._format_outlier_method_label(
                            template.report.outlier_fail_method
                        ),
                        "apply": lambda item, desired=desired_outlier: setattr(
                            item.report,
                            "outlier_fail_method",
                            desired,
                        ),
                    }
                )
            desired_merge_order = desired.report.outlier_merge_order
            if desired_merge_order != template.report.outlier_merge_order:
                diffs.append(
                    {
                        "label": "Outlier Merge Order",
                        "gui": desired_merge_order,
                        "template": template.report.outlier_merge_order,
                        "apply": lambda item, desired=desired_merge_order: setattr(
                            item.report,
                            "outlier_merge_order",
                            desired,
                        ),
                    }
                )
            desired_empty_cells_as_fail = desired.report.outlier_treat_empty_cells_as_fail
            if (
                desired_empty_cells_as_fail
                != template.report.outlier_treat_empty_cells_as_fail
            ):
                diffs.append(
                    {
                        "label": "Empty Test Cells Count As Fail",
                        "gui": "True" if desired_empty_cells_as_fail else "False",
                        "template": (
                            "True"
                            if template.report.outlier_treat_empty_cells_as_fail
                            else "False"
                        ),
                        "note": (
                            "Empty/non-numeric cells never participate in golden "
                            "calculation; this setting only controls raw-cell "
                            "outlier pass/fail."
                        ),
                        "apply": lambda item, desired=desired_empty_cells_as_fail: setattr(
                            item.report,
                            "outlier_treat_empty_cells_as_fail",
                            desired,
                        ),
                    }
                )
            desired_column_filters = self._normalize_filter_payload(
                self._resolve_analysis_column_filters(template)
            )
            template_column_filters = self._normalize_filter_payload({
                "include": {
                    key: list(values)
                    for key, values in template.report.analysis_column_filters.include.items()
                },
                "exclude": {
                    key: list(values)
                    for key, values in template.report.analysis_column_filters.exclude.items()
                },
            })
            if desired_column_filters != template_column_filters:
                diffs.append(
                    {
                        "label": "Analysis Test Filters",
                        "gui": (
                            f"include={self._format_analysis_column_filter_text(desired_column_filters.get('include', {})) or '(empty)'} | "
                            f"exclude={self._format_analysis_column_filter_text(desired_column_filters.get('exclude', {})) or '(empty)'}"
                        ),
                        "template": (
                            f"include={self._format_analysis_column_filter_text(template_column_filters.get('include', {})) or '(empty)'} | "
                            f"exclude={self._format_analysis_column_filter_text(template_column_filters.get('exclude', {})) or '(empty)'}"
                        ),
                        "apply": lambda item, desired=desired_column_filters: setattr(
                            item.report,
                            "analysis_column_filters",
                            item.report.analysis_column_filters.__class__(
                                include={
                                    key: list(values)
                                    for key, values in desired.get("include", {}).items()
                                },
                                exclude={
                                    key: list(values)
                                    for key, values in desired.get("exclude", {}).items()
                                },
                            ),
                        ),
                    }
                )
            desired_z = desired.report.zscore_thresholds.default
            template_z = float(template.report.zscore_thresholds.default)
            override_count = len(template.report.zscore_thresholds.overrides)
            if abs(desired_z - template_z) > 1e-12:
                template_label = f"{template_z:g}"
                if override_count:
                    template_label = f"{template_label} (+{override_count} override)"
                    if override_count > 1:
                        template_label += "s"
                diffs.append(
                    {
                        "label": "Z Threshold",
                        "gui": f"{desired_z:g}",
                        "template": template_label,
                        "note": (
                            "Writing back updates the default z-threshold. "
                            "Metric-specific zscore thresholds remain in effect and take precedence."
                        )
                        if override_count
                        else None,
                        "apply": lambda item, desired=desired_z: setattr(
                            item.report.zscore_thresholds,
                            "default",
                            desired,
                        ),
                    }
                )
            return diffs

        if scope == "build_golden":
            golden_defaults = template.golden_reference_defaults
            desired_reference_dims = parse_csv_items(
                self.ui.referenceDimsEdit.text().strip()
            )
            if desired_reference_dims != golden_defaults.reference_dimensions:
                diffs.append(
                    {
                        "label": "Golden Reference Dims",
                        "gui": ",".join(desired_reference_dims) or "(empty)",
                        "template": ",".join(golden_defaults.reference_dimensions)
                        or "(empty)",
                        "apply": lambda item, desired=desired_reference_dims: setattr(
                            item.golden_reference_defaults,
                            "reference_dimensions",
                            list(desired),
                        ),
                    }
                )
            desired_filters = parse_filter_text(self.ui.filtersEdit.toPlainText())
            if desired_filters != golden_defaults.filters:
                diffs.append(
                    {
                        "label": "Golden Filters",
                        "gui": "; ".join(
                            f"{key}={value}" for key, value in desired_filters.items()
                        )
                        or "(empty)",
                        "template": "; ".join(
                            f"{key}={value}"
                            for key, value in golden_defaults.filters.items()
                        )
                        or "(empty)",
                        "apply": lambda item, desired=desired_filters: setattr(
                            item.golden_reference_defaults,
                            "filters",
                            dict(desired),
                        ),
                    }
                )
            desired_center_method = self._combo_code(self.ui.centerMethodComboBox)
            if desired_center_method != golden_defaults.center_method:
                diffs.append(
                    {
                        "label": "Golden Center",
                        "gui": desired_center_method,
                        "template": golden_defaults.center_method,
                        "apply": lambda item, desired=desired_center_method: setattr(
                            item.golden_reference_defaults,
                            "center_method",
                            desired,
                        ),
                    }
                )
            desired_outlier_golden_method = self._resolved_outlier_golden_method()
            if desired_outlier_golden_method != golden_defaults.outlier_golden_method:
                diffs.append(
                    {
                        "label": "Outlier Golden Method",
                        "gui": desired_outlier_golden_method,
                        "template": golden_defaults.outlier_golden_method,
                        "apply": lambda item, desired=desired_outlier_golden_method: setattr(
                            item.golden_reference_defaults,
                            "outlier_golden_method",
                            desired,
                        ),
                    }
                )
            desired_relative_limit = self._resolve_relative_limit()
            template_relative_limit = golden_defaults.relative_limit
            if desired_relative_limit != template_relative_limit:
                diffs.append(
                    {
                        "label": "Golden Relative Limit",
                        "gui": self._format_optional_number(desired_relative_limit),
                        "template": self._format_optional_number(
                            template_relative_limit
                        ),
                        "apply": lambda item, desired=desired_relative_limit: setattr(
                            item.golden_reference_defaults,
                            "relative_limit",
                            desired,
                        ),
                    }
                )
            desired_sigma_multiplier = self._resolve_sigma_multiplier()
            template_sigma_multiplier = golden_defaults.sigma_multiplier
            if desired_sigma_multiplier != template_sigma_multiplier:
                diffs.append(
                    {
                        "label": "Golden Sigma Multiplier",
                        "gui": self._format_optional_number(desired_sigma_multiplier),
                        "template": self._format_optional_number(
                            template_sigma_multiplier
                        ),
                        "apply": lambda item, desired=desired_sigma_multiplier: setattr(
                            item.golden_reference_defaults,
                            "sigma_multiplier",
                            desired,
                        ),
                    }
                )
            desired_mad_multiplier = self._resolve_mad_multiplier()
            template_mad_multiplier = golden_defaults.mad_multiplier
            if desired_mad_multiplier != template_mad_multiplier:
                diffs.append(
                    {
                        "label": "Golden MAD Multiplier",
                        "gui": self._format_optional_number(desired_mad_multiplier),
                        "template": self._format_optional_number(
                            template_mad_multiplier
                        ),
                        "apply": lambda item, desired=desired_mad_multiplier: setattr(
                            item.golden_reference_defaults,
                            "mad_multiplier",
                            desired,
                        ),
                    }
                )
            desired_absolute_lower_bound = self._resolve_absolute_lower_bound()
            if desired_absolute_lower_bound != golden_defaults.absolute_lower_bound:
                diffs.append(
                    {
                        "label": "Golden Absolute Lower Bound",
                        "gui": self._format_optional_number(
                            desired_absolute_lower_bound
                        ),
                        "template": self._format_optional_number(
                            golden_defaults.absolute_lower_bound
                        ),
                        "apply": lambda item, desired=desired_absolute_lower_bound: setattr(
                            item.golden_reference_defaults,
                            "absolute_lower_bound",
                            desired,
                        ),
                    }
                )
            desired_absolute_upper_bound = self._resolve_absolute_upper_bound()
            if desired_absolute_upper_bound != golden_defaults.absolute_upper_bound:
                diffs.append(
                    {
                        "label": "Golden Absolute Upper Bound",
                        "gui": self._format_optional_number(
                            desired_absolute_upper_bound
                        ),
                        "template": self._format_optional_number(
                            golden_defaults.absolute_upper_bound
                        ),
                        "apply": lambda item, desired=desired_absolute_upper_bound: setattr(
                            item.golden_reference_defaults,
                            "absolute_upper_bound",
                            desired,
                        ),
                    }
                )
            desired_overwrite_lowerbound = self._resolve_overwrite_lowerbound()
            if desired_overwrite_lowerbound != golden_defaults.overwrite_lowerbound:
                diffs.append(
                    {
                        "label": "Golden Overwrite Lower Bound",
                        "gui": self._format_optional_number(
                            desired_overwrite_lowerbound
                        ),
                        "template": self._format_optional_number(
                            golden_defaults.overwrite_lowerbound
                        ),
                        "apply": lambda item, desired=desired_overwrite_lowerbound: setattr(
                            item.golden_reference_defaults,
                            "overwrite_lowerbound",
                            desired,
                        ),
                    }
                )
            desired_overwrite_upperbound = self._resolve_overwrite_upperbound()
            if desired_overwrite_upperbound != golden_defaults.overwrite_upperbound:
                diffs.append(
                    {
                        "label": "Golden Overwrite Upper Bound",
                        "gui": self._format_optional_number(
                            desired_overwrite_upperbound
                        ),
                        "template": self._format_optional_number(
                            golden_defaults.overwrite_upperbound
                        ),
                        "apply": lambda item, desired=desired_overwrite_upperbound: setattr(
                            item.golden_reference_defaults,
                            "overwrite_upperbound",
                            desired,
                        ),
                    }
                )
            desired_continuous_interval = self._resolve_continuous_interval()
            if desired_continuous_interval != bool(golden_defaults.continuous_interval):
                diffs.append(
                    {
                        "label": "Golden Continuous Interval",
                        "gui": "True" if desired_continuous_interval else "False",
                        "template": (
                            "True" if golden_defaults.continuous_interval else "False"
                        ),
                        "apply": lambda item, desired=desired_continuous_interval: setattr(
                            item.golden_reference_defaults,
                            "continuous_interval",
                            desired,
                        ),
                    }
                )
            desired_empty_range_fallback = self._resolve_empty_range_fallback_to_absolute()
            if (
                desired_empty_range_fallback
                != bool(golden_defaults.empty_range_fallback_to_absolute)
            ):
                diffs.append(
                    {
                        "label": "Golden Empty Range Fallback To Absolute",
                        "gui": "True" if desired_empty_range_fallback else "False",
                        "template": (
                            "True"
                            if golden_defaults.empty_range_fallback_to_absolute
                            else "False"
                        ),
                        "apply": lambda item, desired=desired_empty_range_fallback: setattr(
                            item.golden_reference_defaults,
                            "empty_range_fallback_to_absolute",
                            desired,
                        ),
                    }
                )
            return diffs

        raise ValueError(f"Unsupported template write-back scope: {scope}")

    def _sync_template_backed_settings_from_template(self, silent: bool = False) -> None:
        try:
            template_path = self._ensure_template_path()
            template = load_template(template_path)
            self._apply_template_settings(template, template_path)
        except Exception as exc:
            if not silent:
                self._show_error("Load template failed", exc)
            else:
                self._log(f"Template settings were not applied: {exc}")
            raise

    @staticmethod
    def _set_template_number(spin, value) -> None:
        number = float(value) if value is not None else -1.0
        precision = max(0, -Decimal(str(number)).as_tuple().exponent)
        spin.setDecimals(max(spin.decimals(), precision))
        spin.setRange(min(spin.minimum(), number), max(spin.maximum(), number))
        spin.setValue(number)

    def _apply_template_settings(self, template, template_path: str) -> None:
        """Apply an already loaded configuration. Never probe or re-read the file."""
        validate_same_level_rules(template)
        self.ui.tskAnalysisPanel.set_template(template)
        self.current_tsk_result = None
        self._tsk_stream_result = self._tsk_live_result = None
        self._tsk_live_key = None
        self._tsk_viewing_live = False
        self.ui.tskResultsPanel.set_live_analysis_available(False)
        self.tsk_run_history = {**self.tsk_run_history, "active_key": None}
        self.ui.tskResultsPanel.clear_result()
        from ..tsk_coordinate_data import coordinate_preview_from_template
        self.ui.tskResultsPanel.set_coordinate_preview(coordinate_preview_from_template(template))
        self.ui.tskResultsPanel.set_run_history(self.tsk_run_history)
        self.identity_controls.set_template(template, template_path)
        self._render_storage_snapshot()
        self.merge_controls.set_template(template)
        self._set_combo_code_if_present(
            self.ui.outlierFailModeComboBox,
            template.report.outlier_fail_method,
        )
        self._set_combo_code_if_present(
            self.ui.outlierMergeOrderComboBox,
            template.report.outlier_merge_order,
        )
        self.ui.emptyCellsFailCheckBox.setChecked(
            bool(template.report.outlier_treat_empty_cells_as_fail)
        )
        self._set_template_number(self.ui.zThresholdSpinBox, template.report.zscore_thresholds.default)
        self.ui.zscoreUseGoldenCheckBox.setChecked(template.report.zscore_use_golden_reference)
        self._update_zscore_reference_state()
        golden_defaults = template.golden_reference_defaults
        self._template_backed_golden_values = {
            "relative_limit": golden_defaults.relative_limit,
            "sigma_multiplier": golden_defaults.sigma_multiplier,
            "mad_multiplier": golden_defaults.mad_multiplier,
            "absolute_lower_bound": golden_defaults.absolute_lower_bound,
            "absolute_upper_bound": golden_defaults.absolute_upper_bound,
            "overwrite_lowerbound": golden_defaults.overwrite_lowerbound,
            "overwrite_upperbound": golden_defaults.overwrite_upperbound,
            "continuous_interval": golden_defaults.continuous_interval,
            "empty_range_fallback_to_absolute": golden_defaults.empty_range_fallback_to_absolute,
        }
        self.ui.referenceDimsEdit.setText(",".join(golden_defaults.reference_dimensions))
        self.ui.filtersEdit.setPlainText(
            "\n".join(f"{key}={value}" for key, value in golden_defaults.filters.items())
        )
        self._set_combo_code_if_present(
            self.ui.centerMethodComboBox,
            golden_defaults.center_method,
        )
        self._set_combo_code_if_present(
            self.ui.thresholdModeComboBox,
            golden_defaults.outlier_golden_method,
        )
        self._set_template_number(self.ui.relativeLimitSpinBox, golden_defaults.relative_limit)
        self._set_template_number(self.ui.sigmaMultiplierSpinBox, golden_defaults.sigma_multiplier)
        self._set_template_number(self.ui.madMultiplierSpinBox, golden_defaults.mad_multiplier)
        self.ui.absoluteLowerBoundEdit.setText(
            self._format_optional_input_number(golden_defaults.absolute_lower_bound)
        )
        self.ui.absoluteUpperBoundEdit.setText(
            self._format_optional_input_number(golden_defaults.absolute_upper_bound)
        )
        self.ui.overwriteMinEdit.setText(
            self._format_optional_input_number(golden_defaults.overwrite_lowerbound)
        )
        self.ui.overwriteMaxEdit.setText(
            self._format_optional_input_number(golden_defaults.overwrite_upperbound)
        )
        self.ui.continuousIntervalCheckBox.setChecked(
            bool(golden_defaults.continuous_interval)
        )
        self.ui.emptyRangeFallbackCheckBox.setChecked(
            bool(golden_defaults.empty_range_fallback_to_absolute)
        )
        numeric_cleanup = template.numeric_cleanup
        self.ui.numericCleanupCheckBox.setChecked(bool(numeric_cleanup.enabled))
        self._set_combo_code_if_present(
            self.ui.numericCleanupModeComboBox,
            numeric_cleanup.mode,
        )
        self.ui.numericCleanupCharsEdit.setText(";".join(numeric_cleanup.characters))
        self._update_numeric_cleanup_state()
        self._template_analysis_dimension_filters = {
            "include": {
                key: list(values)
                for key, values in template.report.analysis_dimension_filters.include.items()
            },
            "exclude": {
                key: list(values)
                for key, values in template.report.analysis_dimension_filters.exclude.items()
            },
        }
        self.ui.analysisSampleIdsEdit.setText(
            self._analysis_dimension_filter_text(
                self._template_analysis_dimension_filters.get("include", {}),
                "sample_key",
                separator=";",
            )
        )
        self.ui.analysisExcludeSampleIdsEdit.setText(
            self._analysis_dimension_filter_text(
                self._template_analysis_dimension_filters.get("exclude", {}),
                "sample_key",
                separator=";",
            )
        )
        self.ui.analysisNodesEdit.setText(
            self._analysis_dimension_filter_text(
                self._template_analysis_dimension_filters.get("include", {}),
                "reliability_node",
                separator=",",
            )
        )
        self.ui.analysisExcludeNodesEdit.setText(
            self._analysis_dimension_filter_text(
                self._template_analysis_dimension_filters.get("exclude", {}),
                "reliability_node",
                separator=",",
            )
        )
        self._template_analysis_column_filters = {
            "include": {
                key: list(values)
                for key, values in template.report.analysis_column_filters.include.items()
            },
            "exclude": {
                key: list(values)
                for key, values in template.report.analysis_column_filters.exclude.items()
            },
        }
        self._apply_analysis_column_filter_text(
            self.ui.analysisTestsEdit,
            self._template_analysis_column_filters.get("include", {}),
        )
        self._apply_analysis_column_filter_text(
            self.ui.analysisExcludeTestsEdit,
            self._template_analysis_column_filters.get("exclude", {}),
        )
        self._update_golden_threshold_mode_state()

        self._sync_tsk_fail_rules()

    def _sync_build_golden_controls_from_file(self, golden_path: str) -> None:
        try:
            golden = json.loads(Path(golden_path).read_text(encoding="utf-8"))
        except Exception:
            return
        default_rule = golden.get("default_rule", golden)
        self._template_backed_golden_values = {
            "relative_limit": default_rule.get("relative_limit"),
            "sigma_multiplier": default_rule.get("sigma_multiplier"),
            "mad_multiplier": default_rule.get("mad_multiplier", 3.5),
            "absolute_lower_bound": default_rule.get("absolute_lower_bound"),
            "absolute_upper_bound": default_rule.get("absolute_upper_bound"),
            "overwrite_lowerbound": default_rule.get(
                "overwrite_lowerbound",
                default_rule.get("overwrite_min"),
            ),
            "overwrite_upperbound": default_rule.get(
                "overwrite_upperbound",
                default_rule.get("overwrite_max"),
            ),
            "continuous_interval": default_rule.get("continuous_interval"),
            "empty_range_fallback_to_absolute": default_rule.get(
                "empty_range_fallback_to_absolute"
            ),
        }
        self._set_combo_code_if_present(
            self.ui.centerMethodComboBox,
            golden.get("center_method"),
        )
        self._set_combo_code_if_present(
            self.ui.thresholdModeComboBox,
            default_rule.get("outlier_golden_method"),
        )
        self._set_template_number(self.ui.relativeLimitSpinBox, default_rule.get("relative_limit"))
        self._set_template_number(self.ui.sigmaMultiplierSpinBox, default_rule.get("sigma_multiplier"))
        self._set_template_number(self.ui.madMultiplierSpinBox, default_rule.get("mad_multiplier", 3.5))
        self.ui.absoluteLowerBoundEdit.setText(
            self._format_optional_input_number(default_rule.get("absolute_lower_bound"))
        )
        self.ui.absoluteUpperBoundEdit.setText(
            self._format_optional_input_number(default_rule.get("absolute_upper_bound"))
        )
        self.ui.overwriteMinEdit.setText(
            self._format_optional_input_number(
                default_rule.get("overwrite_lowerbound", default_rule.get("overwrite_min"))
            )
        )
        self.ui.overwriteMaxEdit.setText(
            self._format_optional_input_number(
                default_rule.get("overwrite_upperbound", default_rule.get("overwrite_max"))
            )
        )
        self.ui.continuousIntervalCheckBox.setChecked(
            bool(default_rule.get("continuous_interval", False))
        )
        self.ui.emptyRangeFallbackCheckBox.setChecked(
            bool(default_rule.get("empty_range_fallback_to_absolute", False))
        )
        self._update_golden_threshold_mode_state()

    def _maybe_write_back_template_settings(
        self,
        template_path: str,
        template,
        scope: str,
    ) -> bool | None:
        diffs = self._collect_template_write_back_diffs(template, scope)
        if (
            scope == "analysis"
            and not self._template_has_report_field(
                template_path,
                "outlier_treat_empty_cells_as_fail",
            )
            and not any(
                diff.get("label") == "Empty Test Cells Count As Fail"
                for diff in diffs
            )
        ):
            desired_empty_cells_as_fail = self.ui.emptyCellsFailCheckBox.isChecked()
            diffs.append(
                {
                    "label": "Empty Test Cells Count As Fail",
                    "gui": "True" if desired_empty_cells_as_fail else "False",
                    "template": "(missing; default True)",
                    "note": (
                        "This template was created before the empty-cell fail "
                        "setting existed. The program can write it into the "
                        "template now. Empty/non-numeric cells still never "
                        "participate in golden calculation."
                    ),
                    "apply": lambda item, desired=desired_empty_cells_as_fail: setattr(
                        item.report,
                        "outlier_treat_empty_cells_as_fail",
                        desired,
                    ),
                }
            )
        if (
            scope == "build_golden"
            and not self._template_has_golden_reference_field(
                template_path,
                "empty_range_fallback_to_absolute",
            )
            and not any(
                diff.get("label") == "Golden Empty Range Fallback To Absolute"
                for diff in diffs
            )
        ):
            desired_empty_range_fallback = self.ui.emptyRangeFallbackCheckBox.isChecked()
            diffs.append(
                {
                    "label": "Golden Empty Range Fallback To Absolute",
                    "gui": "True" if desired_empty_range_fallback else "False",
                    "template": "(missing; default False)",
                    "note": (
                        "This template was created before the empty allowed-range "
                        "fallback setting existed. The program can write it into "
                        "the template now."
                    ),
                    "apply": lambda item, desired=desired_empty_range_fallback: setattr(
                        item.golden_reference_defaults,
                        "empty_range_fallback_to_absolute",
                        desired,
                    ),
                }
            )

        if scope == "analysis":
            return self._resolve_analysis_template_settings(template_path, template, diffs)

        if not diffs:
            return True

        lines = ["当前 GUI 设置和 template 中的默认值不一致：", ""]
        for diff in diffs:
            lines.append(
                f"- {diff['label']}: GUI={diff['gui']} | Template={diff['template']}"
            )
            note = diff.get("note")
            if note:
                lines.append(f"  {note}")
        lines.extend(
            [
                "",
                "是否把这些值回写到当前 template？",
                "选择 Yes 会保存到 template；选择 No 只对本次操作生效。",
            ]
        )
        response = QMessageBox.question(
            self,
            "Sync Settings Back To Template",
            "\n".join(lines),
            QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
            QMessageBox.Yes,
        )
        if response == QMessageBox.Cancel:
            return None
        if response == QMessageBox.No:
            for diff in diffs:
                diff["apply"](template)
            return True

        updated_template = load_template(template_path)
        for diff in diffs:
            apply_fn = diff["apply"]
            apply_fn(updated_template)
        save_template_atomically(updated_template, template_path)
        template.numeric_cleanup = deepcopy(updated_template.numeric_cleanup)
        template.golden_reference_defaults = deepcopy(updated_template.golden_reference_defaults)
        template.report.zscore_use_golden_reference = updated_template.report.zscore_use_golden_reference
        self._apply_template_settings(updated_template, template_path)
        self._log(
            "Updated template-backed GUI settings in "
            f"{template_path}:\n"
            + json.dumps(
                [
                    {
                        "label": diff["label"],
                        "gui": diff["gui"],
                        "template_previous": diff["template"],
                    }
                    for diff in diffs
                ],
                ensure_ascii=False,
                indent=2,
            )
        )
        return True

    def _resolve_analysis_template_settings(self, template_path, template, diffs) -> bool | None:
        action = self._prompt_analysis_template_action(template_path, diffs) if diffs else "once"
        if action == "cancel":
            return None
        if action == "restore":
            selected = load_template(template_path)
            if self._should_use_report_mode(selected):
                validate_report_identity(selected)
            self._apply_template_settings(selected, template_path)
        else:
            # Save against the current file so unrelated settings are not overwritten.
            selected = load_template(template_path) if action == "save" else deepcopy(template)
            for diff in diffs:
                diff["apply"](selected)
            if self._should_use_report_mode(selected):
                selected = self.identity_controls.updated_template(selected)
                self.merge_controls.apply_to(selected)
                validate_report_identity(selected)
            self._analysis_dimension_filters_for_template(selected)
            if action == "save":
                save_template_atomically(selected, template_path)
                self._apply_template_settings(selected, template_path)
                self._log(f"Analysis settings saved to template: {template_path}")
        # The caller and background worker must use the same selected configuration.
        for field in fields(selected):
            setattr(template, field.name, deepcopy(getattr(selected, field.name)))
        return True

    def _prompt_analysis_template_action(self, template_path, diffs) -> str:
        dialog = QDialog(self)
        ui = Ui_AnalysisSettingsDialog()
        ui.setupUi(dialog)
        ui.differencesEdit.setPlainText(
            "\n".join(f"{diff['label']}: GUI={diff['gui']} | Template={diff['template']}" for diff in diffs)
            + f"\n\n模板位置：{template_path}"
        )
        ui.runOnceButton.clicked.connect(lambda: dialog.done(1))
        ui.saveRunButton.clicked.connect(lambda: dialog.done(2))
        ui.restoreRunButton.clicked.connect(lambda: dialog.done(3))
        ui.cancelButton.clicked.connect(dialog.reject)
        return {1: "once", 2: "save", 3: "restore"}.get(dialog.exec(), "cancel")

    @staticmethod
    def _template_has_report_field(template_path: str, field_name: str) -> bool:
        path = Path(template_path)
        suffix = path.suffix.lower()
        try:
            if suffix == ".json":
                payload = json.loads(path.read_text(encoding="utf-8"))
                report = payload.get("report", {})
                return isinstance(report, dict) and field_name in report
            if suffix in {".xlsx", ".xlsm"}:
                from openpyxl import load_workbook

                workbook = load_workbook(path, data_only=True, read_only=True)
                if "template_info" not in workbook.sheetnames:
                    return False
                sheet = workbook["template_info"]
                for row in sheet.iter_rows(min_row=2, values_only=True):
                    if not row:
                        continue
                    if str(row[0] or "").strip() == field_name:
                        return True
                return False
        except Exception:
            return True
        return True

    @staticmethod
    def _template_has_golden_reference_field(template_path: str, field_name: str) -> bool:
        path = Path(template_path)
        suffix = path.suffix.lower()
        try:
            if suffix == ".json":
                payload = json.loads(path.read_text(encoding="utf-8"))
                defaults = payload.get("golden_reference_defaults", {})
                return isinstance(defaults, dict) and field_name in defaults
            if suffix in {".xlsx", ".xlsm"}:
                from openpyxl import load_workbook

                workbook = load_workbook(path, data_only=True, read_only=True)
                if "template_info" not in workbook.sheetnames:
                    return False
                sheet = workbook["template_info"]
                template_info_field = f"golden_{field_name}"
                for row in sheet.iter_rows(min_row=2, values_only=True):
                    if not row:
                        continue
                    key = str(row[0] or "").strip()
                    if key in {field_name, template_info_field}:
                        return True
                return False
        except Exception:
            return True
        return True

    @staticmethod
    def _format_optional_number(value: float | None) -> str:
        if value is None:
            return "(empty)"
        return f"{value:g}"

    @staticmethod
    def _format_optional_input_number(value: object) -> str:
        if value in {None, ""}:
            return ""
        return f"{float(value):g}"

    def _warn_built_golden_coverage_for_input(
        self,
        golden_path: str,
        dimension_filters: dict[str, dict[str, list[str]]] | None = None,
    ) -> dict:
        summary = summarize_built_golden_coverage_for_input(
            self._path_value(self.ui.templatePathEdit),
            self._path_value(self.ui.inputPathEdit),
            golden_path,
            dimension_filters=dimension_filters,
        )
        self._show_built_golden_coverage_summary(summary)
        return summary

    def _warn_built_golden_coverage_for_storage(
        self,
        golden_path: str,
        dataset_ids: list[str] | None,
        dimension_filters: dict[str, dict[str, list[str]]],
    ) -> dict:
        summary = summarize_built_golden_coverage_for_storage(
            self._active_storage_path(),
            golden_path,
            dataset_ids=dataset_ids,
            dimension_filters=dimension_filters,
        )
        self._show_built_golden_coverage_summary(summary)
        return summary

    def _show_built_golden_coverage_summary(self, summary: dict) -> None:
        matched = summary["matched_measurement_count"]
        unmatched = summary["unmatched_measurement_count"]
        total = summary["total_measurement_count"]
        self._log(
            "Built golden coverage:\n"
            + json.dumps(summary, ensure_ascii=False, indent=2)
        )
        if total == 0:
            QMessageBox.information(
                self,
                "Built Golden Coverage",
                "Current analysis scope does not contain any measurement data.",
            )
            return
        if unmatched == 0:
            self.statusBar().showMessage(
                f"Built golden coverage: {matched}/{total} measurements matched.",
                5000,
            )
            return

        examples = []
        for item in summary.get("unmatched_examples", [])[:5]:
            dimensions = item.get("dimensions", {})
            dimension_text = ", ".join(
                f"{key}={value}" for key, value in dimensions.items() if value != ""
            )
            examples.append(
                f"- row {item.get('row_number')} | {item.get('raw_column')} | {dimension_text}"
            )
        detail = [
            (
                f"Built golden matched {matched}/{total} measurements, "
                f"but {unmatched} measurements in {summary['unmatched_row_count']} row(s) "
                "did not match any golden key."
            ),
        ]
        if examples:
            detail.append("")
            detail.append("Examples:")
            detail.extend(examples)
        QMessageBox.warning(
            self,
            "Built Golden Coverage Warning",
            "\n".join(detail),
        )

    def _collect_persistent_gui_settings(self, *, database_root=None) -> dict[str, object]:
        payload = {
            "version": 2,
            "paths": {
                "template_path": self._path_value(self.ui.templatePathEdit),
                "input_path": self._path_value(self.ui.inputPathEdit),
                "golden_path": self._path_value(self.ui.goldenPathEdit),
                "output_path": self._path_value(self.ui.outputPathEdit),
            },
            "golden": {
                "golden_name": self.ui.goldenNameEdit.text().strip(),
                "reference_dims_text": self.ui.referenceDimsEdit.text().strip(),
                "filters_text": self.ui.filtersEdit.toPlainText(),
                "center_method": self._combo_code(self.ui.centerMethodComboBox),
                "outlier_golden_method": self._outlier_golden_method_text(),
                "relative_limit": self.ui.relativeLimitSpinBox.value(),
                "sigma_multiplier": self.ui.sigmaMultiplierSpinBox.value(),
                "mad_multiplier": self.ui.madMultiplierSpinBox.value(),
                "absolute_lower_bound": self.ui.absoluteLowerBoundEdit.text().strip(),
                "absolute_upper_bound": self.ui.absoluteUpperBoundEdit.text().strip(),
                "overwrite_lowerbound": self.ui.overwriteMinEdit.text().strip(),
                "overwrite_upperbound": self.ui.overwriteMaxEdit.text().strip(),
                "continuous_interval": self.ui.continuousIntervalCheckBox.isChecked(),
                "empty_range_fallback_to_absolute": self.ui.emptyRangeFallbackCheckBox.isChecked(),
            },
            "parsing": {
                "numeric_cleanup_enabled": self.ui.numericCleanupCheckBox.isChecked(),
                "numeric_cleanup_mode": self._combo_code(self.ui.numericCleanupModeComboBox),
                "numeric_cleanup_characters": self.ui.numericCleanupCharsEdit.text().strip(),
            },
            "analysis": {
                "analysis_scope": self._analysis_scope_code(),
                "outlier_fail_mode": self._outlier_fail_mode_code(),
                "outlier_merge_order": self._outlier_merge_order_text(),
                "empty_cells_as_fail": self.ui.emptyCellsFailCheckBox.isChecked(),
                "z_threshold": self.ui.zThresholdSpinBox.value(),
                "zscore_use_golden_reference": self.ui.zscoreUseGoldenCheckBox.isChecked(),
                "sample_ids_text": self.ui.analysisSampleIdsEdit.text().strip(),
                "exclude_sample_ids_text": self.ui.analysisExcludeSampleIdsEdit.text().strip(),
                "nodes_text": self.ui.analysisNodesEdit.text().strip(),
                "exclude_nodes_text": self.ui.analysisExcludeNodesEdit.text().strip(),
                "tests_text": self._analysis_test_text_for_state("include"),
                "exclude_tests_text": self._analysis_test_text_for_state("exclude"),
                "selected_dataset_ids": self._selected_analysis_dataset_ids(),
            },
            "debug": {
                "verbose_logging_enabled": self._verbose_logging_enabled,
            },
            "tsk_analysis": self.ui.tskAnalysisPanel.settings(),
            "ui_state": {
                "workbench_tab_index": self.ui.workbenchTabWidget.currentIndex(),
                "result_tab_index": self.ui.resultTabWidget.currentIndex(),
                "splitter_sizes": self._saved_main_splitter_sizes(),
            },
        }
        if self.identity_controls.template is not None:
            selected = self.identity_controls.updated_template(validate=False)
            self.merge_controls.apply_to(selected, validate=False)
            payload["analysis"]["report_controls"] = {
                name: deepcopy(getattr(selected.report, name)) for name in (
                    "sample_dimension_names", "reliability_node_dimension", "chain_column_level",
                    "initial_row_merge_level", "initial_column_merge_level", *MERGE_RULE_FIELDS.values(),
                )
            }
        target_root = Path(database_root or self._database_root_path() or app_root())
        previous_root = Path(self._database_root_path()) if self._database_root_path() else None
        for key, category in (("golden_path", "golden"), ("output_path", "result")):
            if payload["paths"][key]:
                remapped = self._remap_database_scoped_path(payload["paths"][key], previous_root, target_root, category)
                if remapped is not None:
                    payload["paths"][key] = str(remapped)
        payload.update(pack_paths(
            payload["paths"], app=app_root(),
            database=target_root, package=package_root(),
        ))
        return payload

    def _collect_persistent_gui_state(self, *, database_root=None) -> dict[str, object]:
        payload = self._collect_persistent_gui_settings(database_root=database_root)
        payload["current_results"] = self._collect_current_results_snapshot()
        payload["log_text"] = self.ui.logPlainTextEdit.toPlainText()
        return payload

    def _load_saved_settings_for_current_database(self, silent: bool) -> None:
        database_root = self._database_root_path()
        if not database_root:
            return
        try:
            payload = load_gui_state(database_root)
        except Exception as exc:
            if not silent:
                self._show_error("Load settings failed", exc)
            return
        if payload is None:
            if not silent:
                QMessageBox.information(
                    self,
                    "No Saved Settings",
                    "Current database does not contain any saved GUI settings yet.",
                )
            return
        try:
            self._apply_persistent_gui_settings(payload)
        except Exception as exc:
            if not silent:
                self._show_error("Apply settings failed", exc)
            return
        self._refresh_database_scoped_paths(database_root, database_root)
        self._log(f"Loaded database GUI settings from {Path(database_root) / '.excel_data_analysis_gui_state.json'}")
        self.statusBar().showMessage("Saved database settings loaded.", 5000)

    def _should_prompt_save_temp_database_on_close(self) -> bool:
        database_root = self._database_root_path()
        if not database_root:
            return False
        try:
            current = Path(database_root).resolve()
            default_temp = default_database_root().resolve()
        except Exception:
            return False
        if current != default_temp:
            return True
        return (
            bool(self._analysis_snapshot_path or self.current_outlier_summary_rows or self.current_tsk_result)
            or self._storage_has_user_content(Path(self._storage_path_for_read()))
            or self._storage_has_user_content(current)
        )

    @staticmethod
    def _storage_has_user_content(storage_path: Path) -> bool:
        try:
            has_measurements = MeasurementStorage(storage_path).has_records()
        except (OSError, ValueError, EOFError):
            # Unreadable data must still trigger the save/recovery prompt.
            has_measurements = True
        datasets_path = storage_path / "datasets.jsonl"
        golden_dir = storage_path / "golden"
        imports_dir = storage_path / "imports"
        return (
            has_measurements
            or (datasets_path.exists() and datasets_path.stat().st_size > 0)
            or (golden_dir.exists() and any(golden_dir.iterdir()))
            or (imports_dir.exists() and any(imports_dir.iterdir()))
        )

    def _prompt_save_temp_database_before_exit(self) -> str:
        database_root = self._database_root_path()
        if not database_root:
            return "exit"
        current_root = Path(database_root).resolve()
        default_temp_root = default_database_root().resolve()
        is_default_temp = current_root == default_temp_root
        message_box = QMessageBox(self)
        message_box.setWindowTitle("Unsaved Database Changes")
        message_box.setIcon(QMessageBox.Warning)
        if is_default_temp:
            message_box.setText(
                (
                    "Current database is still using the default temporary folder:\n"
                    f"{default_temp_root}\n\n"
                    "Please save it to a proper project directory before closing."
                )
            )
            message_box.setInformativeText(
                "Choose Save Database to copy the current database to a new folder, Exit Anyway to discard the unsaved workspace reminder, or Cancel to stay in the app."
            )
        else:
            message_box.setText(
                (
                    "Current database is using a temp workspace under this database folder:\n"
                    f"{current_root / 'temp'}\n\n"
                    "Do you want to save temp/ back into the database root before closing?"
                )
            )
            message_box.setInformativeText(
                "Choose Save Database to merge temp/ into the database root, Don't Save to discard temp/ changes, or Cancel to stay in the app. In both Save and Don't Save cases, temp/ will be deleted before the app exits."
            )
        save_button = message_box.addButton("Save Database", QMessageBox.AcceptRole)
        exit_button = message_box.addButton(
            "Exit Anyway" if is_default_temp else "Don't Save",
            QMessageBox.DestructiveRole,
        )
        cancel_button = message_box.addButton(QMessageBox.Cancel)
        message_box.setDefaultButton(save_button)
        self._ensure_message_box_button_widths(message_box)
        message_box.exec()
        clicked = message_box.clickedButton()
        if clicked == cancel_button:
            return "cancel"
        if clicked == exit_button:
            if is_default_temp:
                return "exit"
            try:
                cleanup_payload = delete_storage_workspace(database_root)
            except Exception as exc:
                # Cleanup may have detached temp before failing to remove its
                # isolated copy. Do not keep reading that now-missing path.
                if self.current_workspace_path and not Path(self.current_workspace_path).exists():
                    self.current_workspace_path = ""
                self._show_error("Discard temp workspace failed", exc)
                return "cancel"
            self.current_workspace_path = ""
            self._log(
                "Discarded temp workspace on exit:\n"
                + json.dumps(cleanup_payload, ensure_ascii=False, indent=2)
            )
            return "exit"
        if clicked == save_button:
            try:
                target = self._choose_database_save_as_target() if is_default_temp else database_root
            except Exception as exc:
                self._show_error("Save database failed", exc)
                return "cancel"
            if target and self._start_database_save(target, close_after_save=True):
                return "saving"
        return "cancel"

    def _apply_persistent_gui_settings(self, payload: dict[str, object], *, resolved_paths=None, template=None, entries=None) -> None:
        if template is not None:
            self._validate_saved_settings(payload, template)
        paths = resolved_paths if resolved_paths is not None else restore_paths(
            payload, app=app_root(), database=Path(self._database_root_path() or app_root()),
            package=package_root(),
        )
        if isinstance(paths, dict):
            self.ui.templatePathEdit.setText(self._coerce_saved_text(paths.get("template_path"), self.ui.templatePathEdit.text()))
            self.ui.inputPathEdit.setText(self._coerce_saved_text(paths.get("input_path"), self.ui.inputPathEdit.text()))
            self.ui.goldenPathEdit.setText(self._coerce_saved_text(paths.get("golden_path"), self.ui.goldenPathEdit.text()))
            self.ui.outputPathEdit.setText(self._coerce_saved_text(paths.get("output_path"), self.ui.outputPathEdit.text()))
        if self._path_value(self.ui.templatePathEdit):
            if template is not None:
                self._apply_template_settings(template, self._path_value(self.ui.templatePathEdit))
            else:
                self._sync_template_backed_settings_from_template(silent=True)
        else:
            self._template_backed_golden_values = {
                "relative_limit": None,
                "sigma_multiplier": None,
                "mad_multiplier": None,
                "absolute_lower_bound": None,
                "absolute_upper_bound": None,
                "overwrite_lowerbound": None,
                "overwrite_upperbound": None,
                "continuous_interval": None,
                "empty_range_fallback_to_absolute": None,
            }
            self.ui.continuousIntervalCheckBox.setChecked(False)
            self.ui.emptyRangeFallbackCheckBox.setChecked(False)
            self._template_analysis_dimension_filters = {}
            self.ui.analysisSampleIdsEdit.clear()
            self.ui.analysisExcludeSampleIdsEdit.clear()
            self.ui.analysisNodesEdit.clear()
            self.ui.analysisExcludeNodesEdit.clear()
            self._template_analysis_column_filters = {}
            self._apply_analysis_column_filter_text(self.ui.analysisTestsEdit, {})
            self._apply_analysis_column_filter_text(self.ui.analysisExcludeTestsEdit, {})

        golden = payload.get("golden", {})
        if isinstance(golden, dict):
            default_rule = golden.get("default_rule", golden)
            self.ui.goldenNameEdit.setText(self._coerce_saved_text(golden.get("golden_name"), self.ui.goldenNameEdit.text()))
            self.ui.referenceDimsEdit.setText(self._coerce_saved_text(golden.get("reference_dims_text"), self.ui.referenceDimsEdit.text()))
            self.ui.filtersEdit.setPlainText(self._coerce_saved_text(golden.get("filters_text"), self.ui.filtersEdit.toPlainText()))
            self._set_combo_code_if_present(self.ui.centerMethodComboBox, golden.get("center_method"))
            self._set_combo_code_if_present(
                self.ui.thresholdModeComboBox,
                default_rule.get("outlier_golden_method"),
            )
            if "relative_limit" in default_rule:
                self._set_template_number(self.ui.relativeLimitSpinBox, default_rule["relative_limit"])
            if "sigma_multiplier" in default_rule:
                self._set_template_number(self.ui.sigmaMultiplierSpinBox, default_rule["sigma_multiplier"])
            if "mad_multiplier" in default_rule:
                self._set_template_number(self.ui.madMultiplierSpinBox, default_rule["mad_multiplier"])
            self.ui.absoluteLowerBoundEdit.setText(
                self._coerce_saved_text(
                    default_rule.get("absolute_lower_bound"),
                    self.ui.absoluteLowerBoundEdit.text(),
                )
            )
            self.ui.absoluteUpperBoundEdit.setText(
                self._coerce_saved_text(
                    default_rule.get("absolute_upper_bound"),
                    self.ui.absoluteUpperBoundEdit.text(),
                )
            )
            self.ui.overwriteMinEdit.setText(
                self._coerce_saved_text(
                    default_rule.get(
                        "overwrite_lowerbound",
                        default_rule.get("overwrite_min"),
                    ),
                    self.ui.overwriteMinEdit.text(),
                )
            )
            self.ui.overwriteMaxEdit.setText(
                self._coerce_saved_text(
                    default_rule.get(
                        "overwrite_upperbound",
                        default_rule.get("overwrite_max"),
                    ),
                    self.ui.overwriteMaxEdit.text(),
                )
            )
            if "continuous_interval" in default_rule:
                self.ui.continuousIntervalCheckBox.setChecked(
                    bool(default_rule.get("continuous_interval"))
                )
            if "empty_range_fallback_to_absolute" in default_rule:
                self.ui.emptyRangeFallbackCheckBox.setChecked(
                    bool(default_rule.get("empty_range_fallback_to_absolute"))
                )

        # A removed/unknown scope (or settings from another database without a scope)
        # must never inherit the previous database's partial selection mode.
        self._set_combo_code_if_present(self.ui.analysisScopeComboBox, "entire_database")
        analysis = payload.get("analysis", {})
        selected_dataset_ids: list[str] = []
        parsing = payload.get("parsing", {})
        if isinstance(parsing, dict):
            if "numeric_cleanup_enabled" in parsing:
                self.ui.numericCleanupCheckBox.setChecked(bool(parsing["numeric_cleanup_enabled"]))
            self._set_combo_code_if_present(self.ui.numericCleanupModeComboBox, parsing.get("numeric_cleanup_mode"))
            self.ui.numericCleanupCharsEdit.setText(
                self._coerce_saved_text(parsing.get("numeric_cleanup_characters"), self.ui.numericCleanupCharsEdit.text())
            )
            self._update_numeric_cleanup_state()
        if isinstance(analysis, dict):
            report_controls = analysis.get("report_controls")
            if isinstance(report_controls, dict) and self.identity_controls.template is not None:
                selected = self._saved_report_template(self.identity_controls.template, report_controls)
                self.identity_controls.set_template(selected, self._path_value(self.ui.templatePathEdit))
                self._render_storage_snapshot()
                self.merge_controls.set_template(selected)
            self._set_combo_code_if_present(self.ui.analysisScopeComboBox, analysis.get("analysis_scope"))
            self._set_combo_code_if_present(self.ui.outlierFailModeComboBox, analysis.get("outlier_fail_mode"))
            if "outlier_merge_order" in analysis:
                self._set_combo_code_if_present(self.ui.outlierMergeOrderComboBox, normalize_merge_order(str(analysis["outlier_merge_order"] or "")))
            if "empty_cells_as_fail" in analysis:
                self.ui.emptyCellsFailCheckBox.setChecked(
                    bool(analysis["empty_cells_as_fail"])
                )
            if "zscore_use_golden_reference" in analysis:
                self.ui.zscoreUseGoldenCheckBox.setChecked(bool(analysis["zscore_use_golden_reference"]))
            if "z_threshold" in analysis:
                self._set_template_number(self.ui.zThresholdSpinBox, analysis["z_threshold"])
            self.ui.analysisSampleIdsEdit.setText(self._coerce_saved_text(analysis.get("sample_ids_text"), self.ui.analysisSampleIdsEdit.text()))
            self.ui.analysisExcludeSampleIdsEdit.setText(self._coerce_saved_text(analysis.get("exclude_sample_ids_text"), self.ui.analysisExcludeSampleIdsEdit.text()))
            self.ui.analysisNodesEdit.setText(self._coerce_saved_text(analysis.get("nodes_text"), self.ui.analysisNodesEdit.text()))
            self.ui.analysisExcludeNodesEdit.setText(self._coerce_saved_text(analysis.get("exclude_nodes_text"), self.ui.analysisExcludeNodesEdit.text()))
            if not self.ui.analysisTestsEdit.isReadOnly():
                self.ui.analysisTestsEdit.setText(self._coerce_saved_text(analysis.get("tests_text"), self.ui.analysisTestsEdit.text()))
            if not self.ui.analysisExcludeTestsEdit.isReadOnly():
                self.ui.analysisExcludeTestsEdit.setText(self._coerce_saved_text(analysis.get("exclude_tests_text"), self.ui.analysisExcludeTestsEdit.text()))
            selected_dataset_ids = [str(item) for item in analysis.get("selected_dataset_ids", [])]

        debug = payload.get("debug", {})
        if isinstance(debug, dict):
            self._set_verbose_logging_enabled(
                bool(debug.get("verbose_logging_enabled", False)),
                log_change=False,
            )

        ui_state = payload.get("ui_state", {})
        splitter_sizes: list[int] | None = None
        if isinstance(ui_state, dict):
            if isinstance(ui_state.get("splitter_sizes"), list):
                splitter_sizes = [int(item) for item in ui_state["splitter_sizes"]]

        self._refresh_analysis_imports(silent=True, entries=entries)
        self._set_selected_analysis_dataset_ids(selected_dataset_ids)
        self.ui.tskAnalysisPanel.restore_settings(payload.get("tsk_analysis", {}))
        self._sync_tsk_fail_rules()
        self._update_analysis_mode_state()
        self.ui.workbenchTabWidget.setCurrentIndex(0)
        self.ui.resultTabWidget.setCurrentIndex(0)
        if splitter_sizes:
            self.ui.leftPanel.setVisible(splitter_sizes[0] > 0)
            self.ui.mainSplitter.setSizes(splitter_sizes)
        self._on_setup_splitter_moved()
        self._apply_persistent_result_state(payload)

    def _restore_analysis_export_snapshot(self, current_results: dict) -> None:
        reference = current_results.get("analysis_snapshot")
        if self._outlier_snapshot_path and Path(self._outlier_snapshot_path).is_file():
            return
        error = current_results.get("analysis_snapshot_restore_error")
        if error:
            self._analysis_snapshot_restore_error = str(error.get("message", error) if isinstance(error, dict) else error)
        if reference is None:
            return
        directory = None
        try:
            if not isinstance(reference, dict) or reference.get("format") != ANALYSIS_SNAPSHOT_FORMAT:
                raise ValueError("Unsupported saved Analyze snapshot format")
            directory = TemporaryDirectory(prefix="easy-outlier-restored-result-")
            path = Path(directory.name) / "analysis.json.gz"
            shutil.copyfile(reference["path"], path)
            snapshot = decode_full_analysis_snapshot(path.read_bytes())
            # Freeze a private copy so subsequent database saves or file changes
            # cannot change the completed analysis behind the export buttons.
            if self._tsk_analysis_snapshot is None:
                tsk_state = encode_analysis_snapshot(snapshot)
                tsk_path = path.with_name("tsk-analysis.json.gz")
                write_analysis_snapshot(tsk_state, tsk_path)
                self._tsk_analysis_snapshot = tsk_state
                self._tsk_snapshot_path = str(tsk_path)
                self._tsk_snapshot_restore_error = None
            self._outlier_snapshot_directory = directory
            self._outlier_snapshot_path = str(path)
            self._analysis_snapshot_path = str(path)
            self._outlier_analysis_template = snapshot["template"]
            self._outlier_export_nodes = list(snapshot["available_nodes"])
            self._outlier_export_result_id = current_results.get("outlier_export_result_id") or uuid4().hex
            self._analysis_snapshot_restore_error = None
        except Exception as exc:
            if directory is not None:
                directory.cleanup()
            self._analysis_snapshot_restore_error = str(exc)

    def _apply_persistent_result_state(self, payload: dict[str, object]) -> None:
        current_results = payload.get("current_results", {})
        if not isinstance(current_results, dict):
            current_results = {}
        if (not self._outlier_export_result_id or
                current_results.get("outlier_export_result_id") != self._outlier_export_result_id):
            self._clear_outlier_export_snapshot()
        saved_analysis = current_results.get("tsk_analysis_snapshot")
        if saved_analysis is not None and self._tsk_analysis_snapshot is None:
            directory = None
            try:
                data = snapshot_bytes(saved_analysis)
                snapshot = decode_analysis_snapshot(data)
                directory = TemporaryDirectory(prefix="easy-outlier-tsk-input-")
                path = Path(directory.name) / "tsk-analysis.json.gz"
                path.write_bytes(data)
                self._restored_tsk_snapshot_directory = directory
                self._tsk_snapshot_path = str(path)
                self._tsk_analysis_snapshot = saved_analysis
                self._outlier_analysis_template = snapshot["template"]
                node_dimension = snapshot["template"].report.reliability_node_dimension
                self._outlier_export_nodes = list(dict.fromkeys(
                    row.dimensions[node_dimension] for row in snapshot["rows"]))
                self._outlier_export_result_id = current_results.get("outlier_export_result_id")
                self._sync_tsk_fail_rules()
            except Exception as exc:
                if directory is not None:
                    directory.cleanup()
                self._tsk_snapshot_restore_error = str(exc)
        self._restore_analysis_export_snapshot(current_results)
        self._sync_tsk_fail_rules()

        golden_summary = current_results.get("golden_coverage_summary")
        if not isinstance(golden_summary, dict):
            golden_summary = None

        outlier_summary_rows = current_results.get("outlier_summary_rows", [])
        if not isinstance(outlier_summary_rows, list):
            outlier_summary_rows = []

        outlier_ratio_rows = current_results.get("outlier_ratio_rows", [])
        if not isinstance(outlier_ratio_rows, list):
            outlier_ratio_rows = []

        self.current_golden_coverage_summary = golden_summary
        self.current_outlier_summary_rows = list(outlier_summary_rows)
        self.current_outlier_ratio_rows = list(outlier_ratio_rows)
        self._update_report_export_state()
        snapshot = current_results.get("plot_inspector_snapshot")
        self.current_plot_inspector_snapshot = snapshot if isinstance(snapshot, dict) else None
        self._refresh_golden_coverage_view(golden_summary)
        self._refresh_outlier_summary_view(
            self.current_outlier_summary_rows,
            self.current_outlier_ratio_rows,
        )
        history = current_results.get("tsk_history")
        self.tsk_run_history = history if isinstance(history, dict) and history.get("version") == 1 else tsk_run_history.empty_history()
        self._pending_tsk_run_signature = None
        self._tsk_stream_result = self._tsk_live_result = None
        self._tsk_live_key = None
        self._tsk_viewing_live = False
        self.ui.tskResultsPanel.set_live_analysis_available(False)
        active = tsk_run_history.find_run(self.tsk_run_history, self.tsk_run_history.get("active_key"))
        self.current_tsk_result = active["result"] if active is not None else current_results.get("tsk_result")
        live = current_results.get("tsk_live_result")
        if isinstance(live, dict):
            self._tsk_live_result = live
        if (isinstance(self.current_tsk_result, dict) and (
                current_results.get("tsk_viewing_live")
                or self.current_tsk_result.get("analysis_status") in {"running", "interrupted"})):
            self._tsk_viewing_live = True
            self._tsk_live_result = self.current_tsk_result
        self.ui.tskResultsPanel.set_live_analysis_available(self._tsk_live_result is not None)
        self._refresh_tsk_result_history()
        if isinstance(self.current_tsk_result, dict):
            self.ui.tskResultsPanel.set_result(self.current_tsk_result)
        else:
            self.current_tsk_result = None
            error = current_results.get("tsk_result_restore_error")
            message = self.ui.tskResultsPanel.ui.summaryLabel.property("restoreErrorText") if error else ""
            self.ui.tskResultsPanel.clear_result(message)

        log_text = payload.get("log_text")
        if isinstance(log_text, str):
            self.ui.logPlainTextEdit.setPlainText(log_text)
        if self._tsk_snapshot_restore_error:
            self._log("Saved Analyze inputs could not be restored: " + self._tsk_snapshot_restore_error)
        if self._analysis_snapshot_restore_error:
            self._log("Saved Analyze export data could not be restored: " + self._analysis_snapshot_restore_error)

    @staticmethod
    def _set_combo_code_if_present(combo_box, value: object) -> None:
        if value is None:
            return
        text = str(value).strip()
        index = combo_box.findData(text)
        if index >= 0:
            combo_box.setCurrentIndex(index)
            return
        text_index = combo_box.findText(text)
        if text_index >= 0:
            combo_box.setCurrentIndex(text_index)
            return
        if text == "filtered_database":
            fallback_index = combo_box.findData("entire_database")
            if fallback_index >= 0:
                combo_box.setCurrentIndex(fallback_index)
                return
        if combo_box.isEditable():
            combo_box.setCurrentIndex(-1)
            combo_box.setEditText(text)

    @staticmethod
    def _coerce_saved_text(value: object, fallback: str) -> str:
        if value is None:
            return fallback
        return str(value)

    @Slot(bool)
    def _on_verbose_logging_toggled(self, checked: bool) -> None:
        self._set_verbose_logging_enabled(checked, log_change=True)

    def _set_verbose_logging_enabled(self, enabled: bool, log_change: bool) -> None:
        self._verbose_logging_enabled = bool(enabled)
        if self.ui.actionVerboseLogging.isChecked() != self._verbose_logging_enabled:
            self.ui.actionVerboseLogging.setChecked(self._verbose_logging_enabled)
        if log_change:
            if self._verbose_logging_enabled:
                self._safe_log(
                    "Verbose logging enabled. Extra progress details and database snapshots will be written to the Log tab."
                )
            else:
                self._safe_log("Verbose logging disabled.")

    def _verbose_log(self, message: str) -> None:
        if not self._verbose_logging_enabled:
            return
        self._safe_log("[Verbose] " + message)

    def _collect_storage_snapshot_for_logging(self) -> dict[str, object] | None:
        storage_path = self._storage_path_for_read()
        if not storage_path:
            return None
        template_path = self._path_value(self.ui.templatePathEdit) or None
        payload = describe_storage(storage_path, template_path=template_path, limit=20)
        return {
            "database_root": self._database_root_path(),
            "workspace": storage_path,
            "dataset_count": payload["dataset_count"],
            "row_count": payload["row_count"],
            "measurement_count": payload["measurement_count"],
            "import_history_count": payload["import_history_count"],
            "dimensions": payload["dimensions"],
            "preview_rows": payload["rows"],
            "truncated": payload["truncated"],
        }

    def _verbose_log_storage_snapshot(self, label: str) -> None:
        if not self._verbose_logging_enabled:
            return
        try:
            snapshot = self._collect_storage_snapshot_for_logging()
        except Exception as exc:
            self._safe_log(f"[Verbose] {label}: failed to collect storage snapshot: {exc}")
            return
        self._safe_log(
            "[Verbose] "
            + label
            + ":\n"
            + json.dumps(snapshot, ensure_ascii=False, indent=2)
        )

    def _safe_log(self, message: str) -> None:
        try:
            self._log(message)
        except Exception as exc:
            print(f"GUI log write failed: {exc}", file=sys.stderr, flush=True)
            print(message, file=sys.stderr, flush=True)

    def _configure_combo_boxes(self) -> None:
        self._populate_combo_box(self.ui.outlierFailModeComboBox, OUTLIER_CRITERIA_OPTIONS)
        self._populate_combo_box(self.ui.outlierMergeOrderComboBox, OUTLIER_MERGE_ORDER_GUI_OPTIONS)
        for index, code in enumerate(ANALYSIS_SCOPE_CODES):
            self.ui.analysisScopeComboBox.setItemData(index, code)
        self._populate_combo_box(self.ui.centerMethodComboBox, CENTER_METHOD_OPTIONS)
        self._populate_combo_box(self.ui.thresholdModeComboBox, OUTLIER_GOLDEN_METHOD_OPTIONS)
        self.ui.thresholdModeComboBox.setEditable(True)
        self._populate_combo_box(self.ui.numericCleanupModeComboBox, NUMERIC_CLEANUP_MODE_OPTIONS)

    @staticmethod
    def _populate_combo_box(combo_box, options: list[tuple[str, str]]) -> None:
        combo_box.clear()
        for label, code in options:
            combo_box.addItem(label, code)

    @staticmethod
    def _combo_code(combo_box) -> str:
        if combo_box.isEditable():
            return str(combo_box.currentText() or "").strip()
        value = combo_box.currentData()
        if value is None:
            return str(combo_box.currentText() or "").strip()
        return str(value).strip()

    def _analysis_scope_code(self) -> str:
        return self._combo_code(self.ui.analysisScopeComboBox)

    def _outlier_fail_mode_code(self) -> str:
        return self._combo_code(self.ui.outlierFailModeComboBox)

    def _set_selected_analysis_dataset_ids(self, dataset_ids: list[str]) -> None:
        selected_ids = set(dataset_ids)
        for index in range(self.ui.analysisImportsListWidget.count()):
            item = self.ui.analysisImportsListWidget.item(index)
            item.setCheckState(Qt.Checked if str(item.data(Qt.UserRole)) in selected_ids else Qt.Unchecked)

    def _selected_storage_row_selectors(self) -> list[dict[str, object]]:
        selectors: list[dict[str, object]] = []
        for row_index in sorted({item.row() for item in self.ui.storageTableWidget.selectedItems()}):
            item = self.ui.storageTableWidget.item(row_index, 0)
            if item is not None and isinstance(item.data(Qt.UserRole), dict):
                selectors.append(dict(item.data(Qt.UserRole)))
        return selectors

    @staticmethod
    def _header_index(headers: list[str], name: str) -> int:
        try:
            return headers.index(name)
        except ValueError:
            return -1

    @staticmethod
    def _set_hidden_table_columns(table, hidden_headers: list[str]) -> None:
        actual_headers = [
            table.horizontalHeaderItem(index).text()
            if table.horizontalHeaderItem(index) is not None
            else ""
            for index in range(table.columnCount())
        ]
        for header in hidden_headers:
            if header in actual_headers:
                table.setColumnHidden(actual_headers.index(header), True)

    def _collect_gui_settings_snapshot(self) -> dict[str, object]:
        template_summary = None
        template_error = None
        template_path = self._path_value(self.ui.templatePathEdit)
        if template_path:
            try:
                template_summary = summarize_template(load_template(template_path))
            except Exception as exc:
                template_error = str(exc)
        return {
            "paths": {
                "template_path": template_path,
                "input_path": self._path_value(self.ui.inputPathEdit),
                "database_root_path": self._database_root_path(),
                "workspace_storage_path": self._active_storage_path(),
                "storage_path": self._active_storage_path(),
                "golden_path": self._path_value(self.ui.goldenPathEdit),
                "output_path": self._path_value(self.ui.outputPathEdit),
            },
            "template_summary": template_summary,
            "template_summary_error": template_error,
            "golden": {
                "golden_name": self.ui.goldenNameEdit.text().strip(),
                "reference_dims_text": self.ui.referenceDimsEdit.text().strip(),
                "filters_text": self.ui.filtersEdit.toPlainText(),
                "center_method": self._combo_code(self.ui.centerMethodComboBox),
                "outlier_golden_method": self._outlier_golden_method_text(),
                "relative_limit": self.ui.relativeLimitSpinBox.value(),
                "sigma_multiplier": self.ui.sigmaMultiplierSpinBox.value(),
                "mad_multiplier": self.ui.madMultiplierSpinBox.value(),
                "absolute_lower_bound": self.ui.absoluteLowerBoundEdit.text().strip(),
                "absolute_upper_bound": self.ui.absoluteUpperBoundEdit.text().strip(),
                "overwrite_lowerbound": self.ui.overwriteMinEdit.text().strip(),
                "overwrite_upperbound": self.ui.overwriteMaxEdit.text().strip(),
                "continuous_interval": self.ui.continuousIntervalCheckBox.isChecked(),
                "empty_range_fallback_to_absolute": self.ui.emptyRangeFallbackCheckBox.isChecked(),
            },
            "analysis": {
                "analysis_scope": self._analysis_scope_code(),
                "outlier_fail_mode": self._outlier_fail_mode_code(),
                "outlier_merge_order": self._outlier_merge_order_text(),
                "empty_cells_as_fail": self.ui.emptyCellsFailCheckBox.isChecked(),
                "z_threshold": self.ui.zThresholdSpinBox.value(),
                "zscore_use_golden_reference": self.ui.zscoreUseGoldenCheckBox.isChecked(),
                "sample_ids_text": self.ui.analysisSampleIdsEdit.text().strip(),
                "exclude_sample_ids_text": self.ui.analysisExcludeSampleIdsEdit.text().strip(),
                "nodes_text": self.ui.analysisNodesEdit.text().strip(),
                "exclude_nodes_text": self.ui.analysisExcludeNodesEdit.text().strip(),
                "tests_text": self._analysis_test_text_for_state("include"),
                "exclude_tests_text": self._analysis_test_text_for_state("exclude"),
                "selected_dataset_ids": self._selected_analysis_dataset_ids(),
                "selected_import_entries": self._selected_analysis_import_entries(),
                "workbench_tab": self.ui.workbenchTabWidget.tabText(
                    self.ui.workbenchTabWidget.currentIndex()
                ),
                "result_tab": self.ui.resultTabWidget.tabText(
                    self.ui.resultTabWidget.currentIndex()
                ),
            },
        }

    def _collect_current_results_snapshot(self) -> dict[str, object]:
        return {
            "tsk_result": self.current_tsk_result,
            "tsk_live_result": (self._tsk_live_result if self._tsk_live_result is not self.current_tsk_result else None),
            "tsk_viewing_live": (self._tsk_viewing_live and self._tsk_live_result is not None
                                 and self._tsk_live_result is self.current_tsk_result),
            "tsk_history": self.tsk_run_history,
            "tsk_analysis_snapshot": self._tsk_analysis_snapshot,
            "analysis_snapshot": ({"format": ANALYSIS_SNAPSHOT_FORMAT, "path": self._analysis_snapshot_path}
                                  if self._analysis_snapshot_path else None),
            "golden_coverage_summary": self.current_golden_coverage_summary,
            "outlier_summary_rows": self.current_outlier_summary_rows,
            "outlier_ratio_rows": self.current_outlier_ratio_rows,
            "plot_inspector_snapshot": self.current_plot_inspector_snapshot,
            "outlier_export_result_id": self._outlier_export_result_id,
            "storage_summary_label": self.ui.storageSummaryLabel.text(),
            "golden_coverage_summary_label": self.ui.goldenCoverageSummaryLabel.text(),
            "outlier_summary_label": self.ui.outlierSummaryLabel.text(),
            "outlier_ratio_summary_label": self.ui.outlierRatioSummaryLabel.text(),
        }

    def _resolve_existing_output_path(
        self,
        output_path: str | Path,
        label: str,
    ) -> str | None:
        mode = self._resolve_existing_output_mode(output_path, label)
        if mode is None:
            return None
        if mode == "timestamp":
            from ..output_paths import resolve_output_path

            return str(resolve_output_path(output_path, if_exists="timestamp"))
        return str(output_path)

    def _resolve_existing_report_output_base_path(
        self,
        output_path: str | Path,
        label: str,
    ) -> str | None:
        mode = self._resolve_existing_report_output_mode(output_path, label)
        if mode is None:
            return None
        if mode == "timestamp":
            return str(resolve_split_output_base_path(output_path, if_exists="timestamp"))
        return str(output_path)

    def _resolve_existing_report_output_mode(
        self,
        output_path: str | Path,
        label: str,
    ) -> str | None:
        target = Path(output_path)
        split_paths = derive_split_output_paths(target)
        existing_paths = [path for path in split_paths.values() if path.exists()]
        if not existing_paths:
            return "overwrite"
        message_box = QMessageBox(self)
        message_box.setWindowTitle("Output Path Already Exists")
        message_box.setIcon(QMessageBox.Warning)
        message_box.setText(
            f"{label} already exists:\n" + "\n".join(str(path) for path in existing_paths)
        )
        message_box.setInformativeText(
            "Choose Overwrite to replace them, Timestamp Suffix to keep the old files and create a new pair, or Cancel to stop this action."
        )
        overwrite_button = message_box.addButton("Overwrite", QMessageBox.AcceptRole)
        timestamp_button = message_box.addButton("Timestamp Suffix", QMessageBox.ActionRole)
        cancel_button = message_box.addButton(QMessageBox.Cancel)
        message_box.setDefaultButton(timestamp_button)
        self._ensure_message_box_button_widths(message_box)
        message_box.exec()
        clicked = message_box.clickedButton()
        if clicked == overwrite_button:
            return "overwrite"
        if clicked == timestamp_button:
            return "timestamp"
        if clicked == cancel_button:
            return None
        return None

    def _resolve_existing_output_directory(
        self,
        output_path: str | Path,
        label: str,
    ) -> str | None:
        mode = self._resolve_existing_output_mode(output_path, label)
        if mode is None:
            return None
        if mode == "timestamp":
            from ..output_paths import prepare_output_directory

            resolved = prepare_output_directory(output_path, if_exists="timestamp")
            return str(resolved)
        return str(output_path)

    def _resolve_existing_output_mode(
        self,
        output_path: str | Path,
        label: str,
    ) -> str | None:
        target = Path(output_path)
        if not target.exists():
            return "overwrite"
        message_box = QMessageBox(self)
        message_box.setWindowTitle("Output Path Already Exists")
        message_box.setIcon(QMessageBox.Warning)
        message_box.setText(
            f"{label} already exists:\n{target}"
        )
        message_box.setInformativeText(
            "Choose Overwrite to replace it, Timestamp Suffix to keep the old file and create a new one, or Cancel to stop this action."
        )
        overwrite_button = message_box.addButton("Overwrite", QMessageBox.AcceptRole)
        timestamp_button = message_box.addButton("Timestamp Suffix", QMessageBox.ActionRole)
        cancel_button = message_box.addButton(QMessageBox.Cancel)
        message_box.setDefaultButton(timestamp_button)
        self._ensure_message_box_button_widths(message_box)
        message_box.exec()
        clicked = message_box.clickedButton()
        if clicked == overwrite_button:
            return "overwrite"
        if clicked == timestamp_button:
            return "timestamp"
        if clicked == cancel_button:
            return None
        return None

    def _selected_analysis_import_entries(self) -> list[dict[str, str]]:
        entries: list[dict[str, str]] = []
        for index in range(self.ui.analysisImportsListWidget.count()):
            item = self.ui.analysisImportsListWidget.item(index)
            if item.checkState() != Qt.Checked:
                continue
            entries.append(
                {
                    "dataset_id": str(item.data(Qt.UserRole)),
                    "label": item.text(),
                }
            )
        return entries

    @staticmethod
    def _populate_table(table, headers: list[str], rows: list[list[str]], *, row_data=None) -> None:
        table.setSortingEnabled(False)
        table.clearContents()
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(
            [MainWindow._display_header_label(header) for header in headers]
        )
        table.setRowCount(len(rows))
        for row_index, values in enumerate(rows):
            for column_index, value in enumerate(values):
                item = NaturalSortTableWidgetItem(value)
                if column_index == 0 and row_data is not None:
                    item.setData(Qt.UserRole, row_data[row_index])
                table.setItem(
                    row_index,
                    column_index,
                    item,
                )
        table.resizeColumnsToContents()
        table.setSortingEnabled(True)

    @staticmethod
    def _display_header_label(header: str) -> str:
        if not header:
            return header
        if " " in header and "_" not in header:
            return header
        normalized = str(header).strip()
        special = {
            "id": "ID",
            "sample_id": "Sample ID",
            "dataset_id": "Dataset ID",
            "row_number": "Row Number",
            "logical_metric": "Logical Metric",
            "raw_column": "Raw Column",
            "display_name": "Display Name",
            "chain": "Chain Name",
            "group_by_dimension": "Group By Dimension",
            "group_value": "Group Value",
            "outlier_sample_count": "Outlier Sample Count",
            "total_sample_count": "Total Sample Count",
            "outlier_ratio": "Outlier Ratio",
            "filter_summary": "Filter Summary",
            "total_measurement_count": "Total Measurement Count",
            "matched_measurement_count": "Matched Measurement Count",
            "unmatched_measurement_count": "Unmatched Measurement Count",
            "matched_row_count": "Matched Row Count",
            "unmatched_row_count": "Unmatched Row Count",
            "current_database_rows": "Current Database Rows",
        }
        if normalized in special:
            return special[normalized]
        words = normalized.replace("_", " ").split()
        return " ".join(
            "ID" if word.lower() == "id" else word.capitalize()
            for word in words
        )


class AboutDialog(QDialog):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.ui = Ui_AboutDialog()
        self.ui.setupUi(self)
        self.setWindowTitle(f"About {APP_DISPLAY_NAME}")
        self.ui.summaryLabel.setText(
            f"{APP_DISPLAY_NAME} helps teams import evolving test data, compare it with golden or z-score criteria, and generate highly configurable outlier reports with node-aware tracking."
        )
        self.ui.versionLabel.setText(f"Version: {APP_VERSION}")
        self.ui.teamLabel.setText(f"Team: {APP_TEAM}")
        icon_path = icon_png_path()
        if icon_path is not None and icon_path.exists():
            pixmap = QPixmap(str(icon_path))
            if not pixmap.isNull():
                self.ui.iconLabel.setPixmap(
                    pixmap.scaled(
                        144,
                        144,
                        Qt.KeepAspectRatio,
                        Qt.SmoothTransformation,
                    )
                )


def launch() -> None:
    mp.freeze_support()
    app = QApplication(sys.argv)
    qdarktheme.setup_theme("dark")
    window = MainWindow()
    window.setWindowTitle(f"{APP_DISPLAY_NAME} {APP_VERSION}")
    window.show()
    app.exec()


if __name__ == "__main__":
    launch()
