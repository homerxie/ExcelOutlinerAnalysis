from __future__ import annotations

import hashlib
from pathlib import Path
import tempfile
import unittest
import zipfile

from scripts.build_windows_share import build_share


class WindowsShareTests(unittest.TestCase):
    def setUp(self) -> None:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name) / "source"
        self.output_dir = Path(temporary.name) / "output"
        for name in (
            "MANIFEST.in", "README.md", "requirements.txt", "requirements-build.txt",
            "run_demo.py", "EasyMesh.spec", "packaging/windows/README_WINDOWS.md",
            "packaging/windows/hooks/hook-gmsh.py", "examples/local_template_lid.source.json",
            "examples/layout_coordinates.csv",
            "examples/package_v2/demo.source.json", "scripts/benchmark_preview_3d.py",
            "scripts/check_windows_runtime.py", "scripts/create_package_v2_demo_job.py",
            "scripts/generate_ui.py", "scripts/build_windows_share.py",
            "ui/main_window.ui", "ui/workflow_panel.ui", "docs/windows-compatibility.md",
            "tests/test_app_runtime.py", "tests/test_package_v2_preview_3d.py",
            "tests/package_v2_current_sources.py", "tests/test_windows_share.py",
            "tests/fixtures/current/demo.json",
        ):
            self.write(name, f"fixture: {name}\n")
        for name in ("install_windows.bat", "check_windows.bat", "run_windows.bat", "build_windows.bat"):
            self.write("packaging/windows/" + name, "@echo off\nexit /b 0\n")
        self.write("pyproject.toml", '[project]\nname = "easymesh-gmsh-demo"\nversion = "0.2.0b1"\n')
        self.write("src/easymesh/__init__.py", 'raise RuntimeError("Do not import the app when packaging")\n')
        self.write("src/easymesh/version.py", '__version__ = "0.2.0b1"\nDISPLAY_VERSION = "beta 0.2"\n')
        self.write("src/easymesh/resources/bumpcell.layer", "bundled safe layer\n")
        self.write("src/easymesh/resources/package_v2_preview_3d.qml", "Item {}\n")
        self.write("examples/bumpcell.layer", "private edited layer\n")
        self.write("examples/FCBGA/private.json", "private project\n")
        self.write("outputs/private.msh", "private mesh\n")
        self.write("src/easymesh/__pycache__/version.pyc", "generated cache\n")
        self.wheel = Path(temporary.name) / "easymesh_gmsh_demo-0.2.0b1-py3-none-any.whl"

    def write(self, name: str, content: str) -> None:
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def make_wheel(
        self, *, omit: str | None = None, extra: str | None = None, tag: str = "py3-none-any",
    ) -> None:
        with zipfile.ZipFile(self.wheel, "w") as archive:
            for path in (self.root / "src").rglob("*"):
                if path.is_file() and path.suffix != ".pyc":
                    name = path.relative_to(self.root / "src").as_posix()
                    if name != omit:
                        archive.write(path, name)
            if extra:
                archive.writestr(extra, "# old module\n")
            info = "easymesh_gmsh_demo-0.2.0b1.dist-info"
            archive.writestr(info + "/METADATA", "Name: easymesh-gmsh-demo\nVersion: 0.2.0b1\n")
            archive.writestr(info + "/WHEEL", f"Wheel-Version: 1.0\nRoot-Is-Purelib: true\nTag: {tag}\n")

    def test_share_is_complete_verifiable_and_can_be_repackaged(self) -> None:
        self.make_wheel()
        output = build_share(self.wheel, self.output_dir, root=self.root)
        self.assertEqual(output.name, "EasyMesh-Windows-beta-0.2.zip")
        prefix = output.stem + "/"
        with zipfile.ZipFile(output) as archive:
            contents = {
                name.removeprefix(prefix): archive.read(name) for name in archive.namelist()
            }
            for name in (
                "requirements-build.txt", "EasyMesh.spec", "README_WINDOWS.md",
                "packaging/windows/hooks/hook-gmsh.py", "packaging/windows/build_windows.bat",
                "scripts/build_windows_share.py", "ui/main_window.ui", "ui/workflow_panel.ui",
                "examples/layout_coordinates.csv",
                "wheels/" + self.wheel.name,
            ):
                self.assertIn(name, contents)
            self.assertEqual(contents["build_windows.bat"], b"@echo off\r\nexit /b 0\r\n")
            self.assertEqual(contents["examples/bumpcell.layer"], b"bundled safe layer\n")
            self.assertNotIn("examples/FCBGA/private.json", contents)
            self.assertNotIn("outputs/private.msh", contents)
            self.assertFalse(any("__pycache__" in name for name in contents))
            manifest = dict(
                (name, digest)
                for digest, name in (
                    line.split("  ", 1) for line in contents["SHA256SUMS.txt"].decode().splitlines()
                )
            )
            self.assertEqual(manifest.keys(), contents.keys() - {"SHA256SUMS.txt"})
            for name, digest in manifest.items():
                self.assertEqual(digest, hashlib.sha256(contents[name]).hexdigest(), name)
            extracted = self.output_dir / "unpacked"
            archive.extractall(extracted)
        self.assertEqual(
            output.with_suffix(".zip.sha256").read_text(encoding="ascii"),
            f"{hashlib.sha256(output.read_bytes()).hexdigest()}  {output.name}\n",
        )
        unpacked_root = extracted / output.stem
        repacked = build_share(
            unpacked_root / "wheels" / self.wheel.name,
            self.output_dir / "repacked",
            root=unpacked_root,
        )
        with zipfile.ZipFile(repacked) as archive:
            self.assertEqual(
                {name.removeprefix(prefix): archive.read(name) for name in archive.namelist()},
                contents,
            )

    def test_wheel_missing_qml_resource_is_rejected(self) -> None:
        self.make_wheel(omit="easymesh/resources/package_v2_preview_3d.qml")
        with self.assertRaisesRegex(ValueError, "missing files=.*package_v2_preview_3d.qml"):
            build_share(self.wheel, self.output_dir, root=self.root)
        self.assertFalse(self.output_dir.exists())

    def test_stale_wheel_is_rejected_after_source_changes(self) -> None:
        self.make_wheel()
        self.write("src/easymesh/__init__.py", "# newer source\n")
        with self.assertRaisesRegex(ValueError, "Rebuild stale wheel"):
            build_share(self.wheel, self.output_dir, root=self.root)

    def test_removed_module_in_wheel_is_rejected(self) -> None:
        self.make_wheel(extra="easymesh/removed.py")
        with self.assertRaisesRegex(ValueError, "extra files=.*removed.py"):
            build_share(self.wheel, self.output_dir, root=self.root)

    def test_platform_specific_wheel_is_rejected(self) -> None:
        self.make_wheel(tag="cp311-cp311-macosx_11_0_arm64")
        with self.assertRaisesRegex(ValueError, "py3-none-any"):
            build_share(self.wheel, self.output_dir, root=self.root)

    def test_missing_pyinstaller_spec_is_rejected_before_writing(self) -> None:
        self.make_wheel()
        (self.root / "EasyMesh.spec").unlink()
        with self.assertRaisesRegex(FileNotFoundError, "Required packaging file.*EasyMesh.spec"):
            build_share(self.wheel, self.output_dir, root=self.root)
        self.assertFalse(self.output_dir.exists())

    def test_mismatched_version_constants_are_rejected(self) -> None:
        self.make_wheel()
        self.write("src/easymesh/version.py", '__version__ = "0.2.0"\nDISPLAY_VERSION = "beta 0.2"\n')
        with self.assertRaisesRegex(ValueError, "versions do not match"):
            build_share(self.wheel, self.output_dir, root=self.root)


if __name__ == "__main__":
    unittest.main()
