# EasyMesh beta 0.2 · Windows 使用与打包

显示版本：**beta 0.2**。pip / wheel 使用标准预发布版本号 `0.2.0b1`。
本 ZIP 包含完整应用源码、应用 wheel、运行依赖清单和 PyInstaller 构建配置。
首次安装需要联网；建议使用 **Windows 10/11、x86-64 Python 3.12**，
也兼容 Python 3.10。请将 ZIP 完整解压到可写目录，例如 `D:\EasyMesh`。

## 直接运行 Python 版本

1. 安装 64 位 Python，启用 Python Launcher（`py`）或 Add Python to PATH。
2. 双击解压目录的 `install_windows.bat`，等待 `Installation complete`。
3. 双击 `run_windows.bat`；可先运行 `check_windows.bat` 检查依赖与网格生成。

安装脚本优先 Python 3.12，其次 3.10，再尝试 PATH 中的 Python。
无需管理员权限，也不需要激活 PowerShell 脚本。源码运行的结果保存在包内
`output`；运行期间保留命令行窗口。移动目录后重新执行安装脚本。

手动安装（在解压目录的命令提示符中）：

```bat
py -3.12 -m venv .venv
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install --only-binary=:all: -r requirements.txt
.venv\Scripts\python.exe -m pip install --no-deps wheels\easymesh_gmsh_demo-0.2.0b1-py3-none-any.whl
run_windows.bat
```

## 在 Windows 用 PyInstaller 生成 EXE

双击解压目录的 **`build_windows.bat`**。脚本会创建独立的 `.venv-build`，
安装 `requirements-build.txt`，使用 `EasyMesh.spec` 构建并检查实际 worker。
在 Git 源码目录中也可以直接运行 `packaging\windows\build_windows.bat`。

手动构建：

```bat
py -3.12 -m venv .venv-build
.venv-build\Scripts\python.exe -m pip install --upgrade pip
.venv-build\Scripts\python.exe -m pip install --only-binary=:all: -r requirements-build.txt
.venv-build\Scripts\python.exe -m PyInstaller --clean --noconfirm EasyMesh.spec
set "PYTHONPATH=%CD%\src"
.venv-build\Scripts\python.exe scripts\check_windows_runtime.py --worker-executable dist\EasyMesh\EasyMesh-worker.exe
```

输出目录：

```text
dist\EasyMesh\
  EasyMesh.exe          界面入口，双击运行
  EasyMesh-worker.exe   后台网格/接触检测/转换程序
  _internal\           Python、Gmsh DLL、Qt/QML、主题和示例资源
```

向其他 Windows 电脑分发时，将 **整个 `dist\EasyMesh` 文件夹**压缩发送。
接收者无需安装 Python。不要只复制 `EasyMesh.exe`，也不要将此 spec 改成
单 EXE/windowed worker：后台任务需要独立控制台 worker 提供 UTF-8 管道。
当前配置为 onedir，支持多进程 spawn，并包含 Gmsh DLL 和 Qt Quick 3D 资源。
Windows EXE 必须在 Windows 构建；此 ZIP 是待构建的源码分享包，未包含 Windows EXE。

EXE 默认把工作文件写入系统“文档”下的 `EasyMesh`，不会写入 `_internal`。
可在启动前指定其他可写位置：

```bat
set "EASYMESH_HOME=D:\EasyMeshData"
dist\EasyMesh\EasyMesh.exe
```

## pip 依赖

`requirements.txt` 为运行依赖，`requirement.txt` 是兼容别名。
`requirements-build.txt` 引用运行依赖并增加固定版本的 PyInstaller。

```text
gmsh==4.15.2
numpy>=1.24,<3
openpyxl>=3.1,<4
xlrd>=2.0,<3
PySide6==6.11.2
pyqtdarktheme==2.1.0; python_version < '3.12'
pyqtdarktheme-fork==2.3.6; python_version >= '3.12'
```

Excel 坐标导入需要 openpyxl（`.xlsx`）与 xlrd（`.xls`）。
pip 自动安装 PySide6 Addons、Essentials、shiboken6 等间接依赖。
应用 wheel 是 `py3-none-any`；pip 会下载对应 Windows 的第三方 wheel。
如下载失败，请检查网络、代理和 pip 源是否提供指定版本。

## 示例与验收

- Layer 默认使用 `examples/bumpcell.layer`。
- Package 可打开 `examples/package_v2/` 下的 Source 示例，或
  `examples/local_template_lid.source.json`；这些示例不依赖外部 Frozen MSH。
- 转移自己的工程时保留 Source、MSH 和旁车文件的相对目录结构；
  在目标电脑重新生成 Job，避免复用原电脑的绝对路径。
- 分享包不附带开发机输出、大型网格、私人工程、虚拟环境或 `.git`。

`check_windows.bat` 检查依赖、示例编译、worker 中文管道、Layer 网格生成、
CDB 转换及 Gmsh 中文路径读写。构建脚本还对打包后的 worker 执行这些任务。
在 Windows 打包后，应打开 `EasyMesh.exe`，检查默认 Layer、3D 预览、
接触检测、网格生成与 CDB 导出。多进程及图形显示仍需在目标 Windows 实机验证。

源码版本的 D3D11 测速（PowerShell，窗口保持可见）：

```powershell
$env:QT_QPA_PLATFORM = "windows"
$env:QSG_RHI_BACKEND = "d3d11"
Remove-Item Env:QT_QUICK_BACKEND -ErrorAction SilentlyContinue
.\.venv\Scripts\python.exe scripts/benchmark_preview_3d.py --expect-backend Direct3D11 --min-fps 30 --output preview-performance.json
```

`offscreen` 或 software 后端不能验收实际 3D 渲染。此次发布包在 macOS 上整理和
验证，Windows EXE 的构建与实机图形验收需在 Windows 完成。
历史检查记录见 `docs/windows-compatibility.md`。

构建依据：[PyInstaller spec](https://pyinstaller.org/en/stable/spec-files.html)、
[多进程与窗口模式说明](https://pyinstaller.org/en/stable/common-issues-and-pitfalls.html)。
