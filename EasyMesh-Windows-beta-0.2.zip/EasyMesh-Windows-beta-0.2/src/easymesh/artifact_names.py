"""Readable, portable names for user-owned workflow artifacts."""
from __future__ import annotations

from pathlib import Path
import re
import unicodedata


def readable_name(value: str, fallback: str = "asset") -> str:
    """Keep Unicode collection names while avoiding unsafe path components."""
    name = unicodedata.normalize("NFC", value)
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f\x7f]', "_", name).strip(" .")
    if not name or not name.strip("_"):
        name = fallback
    if name.isdecimal():
        name = f"{fallback}_{name}"
    if re.fullmatch(r"(?i)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?", name):
        name = "_" + name
    # Leave room for extensions and collision suffixes on common filesystems.
    while len(name.encode("utf-8")) > 120:
        name = name[:-1]
    return name.rstrip(" .") or fallback


def readable_filename(value: str, fallback: str = "asset") -> str:
    name = Path(value).name
    suffix = next((suffix for suffix in (".source.json", ".job.json", ".easymesh.json")
                   if name.endswith(suffix)), Path(name).suffix)
    stem = name[:-len(suffix)] if suffix else name
    if re.fullmatch(r"[0-9a-fA-F]{12,}", stem):
        stem = fallback
    return readable_name(stem, fallback) + suffix


def unique_named_path(parent: Path, name: str, suffix: str = "") -> Path:
    """Choose a readable unused path; callers own publication/locking."""
    stem = readable_name(name)
    target = parent / (stem + suffix)
    counter = 2
    while target.exists() or target.is_symlink():
        target = parent / f"{stem}_{counter}{suffix}"
        counter += 1
    return target
