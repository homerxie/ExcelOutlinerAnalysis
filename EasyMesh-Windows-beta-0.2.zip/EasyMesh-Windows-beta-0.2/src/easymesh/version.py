"""Release identifiers shared by the GUI, CLI and packaging metadata."""

__version__ = "0.2.0b1"
DISPLAY_VERSION = "beta 0.2"
