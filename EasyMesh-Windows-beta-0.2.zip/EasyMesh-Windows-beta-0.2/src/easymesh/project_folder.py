"""Portable, classified folders for editable GUI projects.

The folder envelope owns relative paths, while the existing project validator
continues to own the editable document. Files are prepared in new directories
before the envelope is atomically published; original files are never moved.
Immutable Package Jobs are history, because relocating one changes its identity.
"""
from __future__ import annotations

from copy import deepcopy
import csv
import io
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
from typing import Any

from .artifact_names import readable_filename, readable_name, unique_named_path
from .bump_layout import parse_bump_layout_text
from .output_artifacts import atomic_write_text, sha256_file
from .project_file import MAX_PROJECT_BYTES, PROJECT_SCHEMA, PROJECT_SUFFIX, validate_project_document
from .workflow_state import empty_workflow_state

FOLDER_SCHEMA = "easymesh-project-folder-v1"
_NAMING_VERSION = 1
STAGE_DIRECTORIES = {
    "layer": "01_single_bump",
    "layout": "02_connected_bumps",
    "package_v2": "03_package",
    "cdb": "04_exports",
}
_SIDECARS = (".parameters.json", ".report.json", ".quality.json", ".quality.txt", ".quality.html", ".log")


def project_file_in_folder(selected: str | Path) -> Path:
    """Turn either a folder or a Save dialog filename into the folder entry."""
    path = Path(selected).expanduser().resolve()
    if path.is_dir():
        canonical = path / (path.name + PROJECT_SUFFIX)
        if not canonical.exists():
            entries = [entry for entry in path.glob("*" + PROJECT_SUFFIX) if is_project_folder(entry)]
            if len(entries) == 1:
                return entries[0]
        return canonical
    if path.is_file() and is_project_folder(path):
        return path
    if not path.suffix:
        return path / (path.name + PROJECT_SUFFIX)
    name = path.name
    if name.lower().endswith(PROJECT_SUFFIX):
        name = name[:-len(PROJECT_SUFFIX)]
    elif path.suffix.lower() == ".json":
        name = path.stem
    if not name:
        raise ValueError("工程文件夹名称不能为空。")
    if path.parent.name == name and path.name == name + PROJECT_SUFFIX:
        return path
    return path.parent / name / (name + PROJECT_SUFFIX)


def new_project_path(selected: str | Path) -> Path:
    """Resolve a new project destination without changing any files."""
    path = project_file_in_folder(selected)
    root = path.parent
    if root.exists() and (not root.is_dir() or any(root.iterdir())):
        raise ValueError("新建工程需要空文件夹。请选择新的工程名称或空文件夹；已有工程请使用“打开工程”。")
    return path


def create_project_folder(selected: str | Path) -> tuple[Path, dict[str, Any]]:
    """Create an independent blank project, never importing the current GUI."""
    path = new_project_path(selected)
    root = path.parent
    existed = root.exists()
    document = {
        "schema": PROJECT_SCHEMA,
        "active_tab": "layer",
        "layer": {
            "source_path": "", "source_text": "",
            "target_xy_text": "4.0", "target_angular_text": "4.0", "target_z_text": "1.35",
            "symmetry_mode": "xy_45", "canonical_ring_mesh": True,
            "local_size_inputs": [],
            "output_path": str(root / STAGE_DIRECTORIES["layer"] / "meshes" / "bump.msh"),
        },
        "layout": {
            "source_path": "", "source_text": "", "material_inputs": {},
            "far_field_size_text": "80", "transition_distance_text": "120",
            "output_path": str(root / STAGE_DIRECTORIES["layout"] / "meshes" / "connected.msh"),
        },
        "cdb": {
            "input_path": "", "output_path": str(root / STAGE_DIRECTORIES["cdb"] / "mesh.cdb"),
            "element_type": 185, "coordinate_scale_text": "1.0", "units": "MPA",
        },
        "workflow": empty_workflow_state(),
    }
    try:
        return path, save_project_folder(path, document, workspace_root=root)
    except BaseException:
        # save_project_folder rolls back its staged files/subdirectories. Only
        # the empty stage roots may remain; never remove pre-existing data.
        for name in STAGE_DIRECTORIES.values():
            try:
                (root / name).rmdir()
            except OSError:
                pass
        if not existed:
            try:
                root.rmdir()
            except OSError:
                pass
        raise


def _read_json(path: Path) -> dict[str, Any]:
    if not path.is_file() or path.stat().st_size > MAX_PROJECT_BYTES:
        raise ValueError(f"工程文件不存在或超过大小限制：{path}")
    result = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(result, dict):
        raise ValueError("工程文件必须是 JSON 对象。")
    return result


def is_project_folder(project_path: str | Path) -> bool:
    path = Path(project_path).expanduser().resolve()
    if path.is_dir():
        path = project_file_in_folder(path)
    try:
        return _read_json(path).get("schema") == FOLDER_SCHEMA
    except (OSError, UnicodeError, ValueError):
        return False


def _child(root: Path, value: str) -> Path:
    path = Path(value)
    if not value or path.is_absolute() or ".." in path.parts or "\\" in value:
        raise ValueError(f"工程路径必须位于工程文件夹内：{value}")
    result = (root / path).resolve()
    if not result.is_relative_to(root):
        raise ValueError(f"工程路径超出工程文件夹：{value}")
    return result


def _validate_envelope(envelope: dict[str, Any]) -> None:
    if envelope.get("schema") != FOLDER_SCHEMA:
        raise ValueError("不是 EasyMesh 工程文件夹。")
    if not isinstance(envelope.get("document"), dict):
        raise ValueError("工程文件缺少编辑状态。")
    if envelope.get("active_tab") not in ("layer", "layout", "package_v2", "cdb"):
        raise ValueError("工程活动页面无效。")
    warnings = envelope.get("warnings", [])
    if not isinstance(warnings, list) or any(not isinstance(item, str) for item in warnings):
        raise ValueError("工程警告记录无效。")
    for field, required in (("package_history", ("job", "output", "request_sha256")),
                            ("report_bindings", ("report", "mesh", "identity"))):
        records = envelope.get(field, [])
        if not isinstance(records, list):
            raise ValueError(f"工程记录无效：{field}")
        for record in records:
            if not isinstance(record, dict) or any(not isinstance(record.get(key), str) or not record[key] for key in required):
                raise ValueError(f"工程记录字段无效：{field}")
            if field == "report_bindings" and (
                    type(record.get("identity_version", 1)) is not int
                    or record.get("identity_version", 1) not in (1, 2)):
                raise ValueError("工程报告绑定版本无效。")


def _path_fields(document: dict[str, Any]):
    for stage in ("layer", "layout"):
        yield document[stage], "source_path"
        yield document[stage], "output_path"
    yield document["cdb"], "input_path"
    yield document["cdb"], "output_path"
    if "export" in document:
        yield document["export"], "artifact_path"
    workflow = document.get("workflow", {})
    for template in workflow.get("library", {}).get("templates", []):
        yield template["layer"], "source_path"
        yield template["layer"], "output_path"
    for asset in workflow.get("assets", []):
        yield asset, "mesh_path"
    if workflow.get("package_source"):
        yield workflow["package_source"], "path"


def _layout_fingerprint(document: dict[str, Any]) -> str:
    layout = document["layout"]
    values = [layout["source_text"], layout["far_field_size_text"],
              layout["transition_distance_text"], layout["material_inputs"]]
    return hashlib.sha256(json.dumps(values, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def _refresh_layout_fingerprint(document: dict[str, Any], old: str) -> None:
    new = _layout_fingerprint(document)
    for asset in document.get("workflow", {}).get("assets", []):
        if asset.get("kind") == "layout" and asset.get("input_fingerprint") == old:
            asset["input_fingerprint"] = new


def _rewrite_layout_paths(text: str, templates: dict[str, Path], base: Path) -> str:
    lines = []
    for raw in text.splitlines(keepends=True):
        content = raw.rstrip("\r\n")
        if not content.strip() or content.lstrip().startswith("#") or content.split(",", 1)[0].strip().casefold() == "mesh":
            lines.append(raw)
            continue
        row = next(csv.reader([content], skipinitialspace=True, strict=True))
        alias = row[0].strip() if row else ""
        if len(row) != 2 or alias not in templates:
            lines.append(raw)
            continue
        destination = Path(os.path.relpath(templates[alias], base)).as_posix()
        if row[1].strip() == destination:
            lines.append(raw)
            continue
        stream = io.StringIO(newline="")
        ending = raw[len(content):]
        csv.writer(stream, lineterminator="\n").writerow((alias, destination))
        lines.append(stream.getvalue().rstrip("\n") + ending)
    return "".join(lines)


def _report_identity(document: dict[str, Any], version: int = 1) -> str:
    detached = deepcopy(document)
    detached["mesh_artifact"]["path"] = "<project-mesh>"
    if version >= 2 and isinstance(detached.get("quality"), dict) and "mesh_path" in detached["quality"]:
        detached["quality"]["mesh_path"] = "<project-mesh>"
    return hashlib.sha256(json.dumps(detached, sort_keys=True, ensure_ascii=False,
                                    allow_nan=False).encode()).hexdigest()


class _Preparation:
    def __init__(self, root: Path, workspace: Path):
        self.root, self.workspace = root, workspace
        self.mapped: dict[Path, Path] = {}
        self.names: dict[Path, str] = {}
        self.digest_names: dict[str, set[str]] = {}
        self.sources: dict[tuple[Path | None, str, str], Path] = {}
        self.created: list[Path] = []
        self.created_directories: list[Path] = []
        self.report_bindings: dict[str, dict[str, Any]] = {}
        self.warnings: list[str] = []

    def original(self, value: str) -> Path:
        path = Path(value).expanduser()
        return (path if path.is_absolute() else self.workspace / path).resolve()

    def allocate(self, stage: str, category: str, name: str) -> Path:
        suffix = next((suffix for suffix in (".source.json", ".job.json", PROJECT_SUFFIX)
                       if name.endswith(suffix)), Path(name).suffix)
        stem = readable_name(name[:-len(suffix)] if suffix else name, stage)
        name = stem + suffix
        parent = unique_named_path(self.root / STAGE_DIRECTORIES[stage] / category, stem)
        # The stage directories may already contain user data, never follow a
        # symlink there or replace any pre-existing file.
        if parent.resolve() != parent:
            raise ValueError(f"工程目录不能包含符号链接：{parent}")
        self.mkdir(parent)
        return parent / name

    def reusable(self, source: Path, stage: str, name: str | None = None) -> bool:
        if not source.is_relative_to(self.root / STAGE_DIRECTORIES[stage]):
            return False
        parents = source.relative_to(self.root).parts[:-1]
        if name is not None and parents[-1] == Path(name).stem:
            parents = parents[:-1]  # An explicit collected name may resemble a digest.
        if any(re.fullmatch(r"(?:[0-9]+|[0-9a-fA-F]{12,})", part) for part in parents):
            return False
        return source.name == (name or readable_filename(source.name, stage))

    def mkdir(self, target: Path) -> None:
        pending = []
        parent = target
        while not parent.exists():
            pending.append(parent)
            parent = parent.parent
        target.mkdir(parents=True, exist_ok=True)
        self.created_directories.extend(reversed(pending))

    def write(self, target: Path, data: bytes) -> None:
        if not target.resolve().is_relative_to(self.root):
            raise ValueError(f"工程路径超出工程文件夹：{target}")
        with target.open("xb") as stream:
            self.created.append(target)
            stream.write(data)

    def copy(self, source: Path, target: Path) -> None:
        before = source.stat()
        if not source.is_file():
            raise ValueError(f"工程依赖不是普通文件：{source}")
        # Meshes and exports can legitimately be several GiB and are streamed
        # in fixed-size chunks. Keep the budget for metadata and other files
        # that downstream readers may load into memory in full.
        if source.suffix.lower() not in (".msh", ".cdb") and before.st_size > 512 * 1024 * 1024:
            raise ValueError(f"工程依赖超过大小限制：{source}")
        with source.open("rb") as incoming, target.open("xb") as outgoing:
            self.created.append(target)
            shutil.copyfileobj(incoming, outgoing, 1024 * 1024)
        after = source.stat()
        if (before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (
                after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            raise ValueError(f"保存期间文件发生变化，请重试：{source}")

    def report_binding(self, mesh: Path, report: Path, original: Path) -> None:
        if not report.is_file():
            return
        try:
            payload = _read_json(report)
        except (UnicodeError, ValueError):
            return  # Third-party sidecars are copied intact.
        artifact = payload.get("mesh_artifact")
        if not isinstance(artifact, dict):
            return  # Package reports remain immutable historical evidence.
        # Only genuine mesh evidence is eligible for rebinding on a move.
        reported_path = artifact.get("path")
        if (not isinstance(reported_path, str)
                or Path(reported_path).expanduser().resolve() not in (original, mesh)
                or artifact.get("size_bytes") != mesh.stat().st_size
                or artifact.get("sha256") != sha256_file(mesh)):
            raise ValueError(f"网格报告与网格内容不一致，请重新生成：{mesh}")
        relative = report.relative_to(self.root).as_posix()
        self.report_bindings[relative] = {
            "report": relative,
            "mesh": mesh.relative_to(self.root).as_posix(),
            "identity": _report_identity(payload, 2),
            "identity_version": 2,
        }

    def bundle(self, value: str, stage: str, *, required: bool = False,
               expected: str | None = None, destination: Path | None = None,
               name: str | None = None) -> str:
        if not value:
            return ""
        source = self.original(value)
        if expected is not None and (not source.is_file() or sha256_file(source) != expected):
            raise ValueError(f"工程引用的网格已缺失或与快照不一致：{source}")
        if required and not source.is_file():
            raise ValueError(f"工程引用的文件不存在：{source}")
        if (destination is None and source in self.mapped
                and (name is None or self.mapped[source].stem == readable_name(name, stage))):
            return str(self.mapped[source])
        name = name or self.names.get(source)
        filename = readable_name(name, stage) + source.suffix if name else readable_filename(source.name, stage)
        target = destination or (source if self.reusable(source, stage, filename)
                                 else self.allocate(stage, "results", filename))
        if target != source and source.is_file():
            self.copy(source, target)
        if destination is None:
            self.mapped[source] = target
        if source.suffix.lower() == ".msh":
            sidecars = [(source.with_suffix(suffix), target.with_suffix(suffix)) for suffix in _SIDECARS]
        elif source.suffix.lower() == ".cdb":
            sidecars = [(source.with_name(source.name + suffix),
                         target.with_name(target.name + suffix)) for suffix in (".report.json", ".log")]
        else:
            sidecars = []
        if source.suffix.lower() in (".msh", ".cdb"):
            # Per-export snapshots remain raw historical records; their own
            # embedded paths are never presented as the live folder state.
            sidecars.append((source.with_name(source.name + PROJECT_SUFFIX),
                             target.with_name(target.name + PROJECT_SUFFIX)))
        for old, new in sidecars:
            if old.is_file() and old != new:
                self.copy(old, new)
        if target.is_file() and target.suffix.lower() == ".msh":
            self.report_binding(target, target.with_suffix(".report.json"), source)
        return str(target)

    def archive(self, value: str, *, required: bool = False,
                expected: str | None = None) -> str:
        original = self.original(value)
        history_root = self.root / STAGE_DIRECTORIES["package_v2"] / "history"
        if original.is_relative_to(history_root):
            result = self.bundle(value, "package_v2", required=required,
                                 expected=expected, destination=original)
            self.mapped[original] = original
            return result
        target = self.allocate("package_v2", "history", readable_filename(original.name, "package"))
        result = self.bundle(value, "package_v2", required=required,
                             expected=expected, destination=target)
        self.mapped[original] = target
        return result

    def source(self, section: dict[str, Any], stage: str, default_name: str, *,
               name: str | None = None) -> None:
        old = self.original(section["source_path"]) if section["source_path"] else None
        text = section["source_text"]
        filename = (readable_name(name, stage) + Path(default_name).suffix if name
                    else readable_filename(old.name if old else default_name, stage))
        key = (old, text, filename)
        if key in self.sources:
            target = self.sources[key]
        elif old and self.reusable(old, stage, filename) and old.is_file() and old.read_text(encoding="utf-8") == text:
            target = old
        else:
            target = self.allocate(stage, "sources", filename)
            self.write(target, text.encode("utf-8"))
        self.sources[key] = target
        section["source_path"] = str(target)

    def layout(self, section: dict[str, Any]) -> None:
        old = self.original(section["source_path"]) if section["source_path"] else None
        try:
            layout = parse_bump_layout_text(section["source_text"],
                                            base_directory=old.parent if old else self.workspace)
        except (ValueError, TypeError):
            if section["source_text"].strip():
                self.warnings.append("连接布局尚未完成，已原样保存草稿；未解析的网格引用仍需检查。")
            self.source(section, "layout", "layout.loc")
            return
        templates = {item.alias: Path(self.bundle(str(item.mesh_path), "layer", required=True))
                     for item in layout.templates}
        # Only template CSV records change. Comments, define expressions,
        # original units and mesh controls remain editable exactly as entered.
        candidate = old if old and self.reusable(old, "layout") else None
        rendered = _rewrite_layout_paths(section["source_text"], templates, candidate.parent) if candidate else None
        if candidate and candidate.is_file() and candidate.read_text(encoding="utf-8") == rendered:
            target = candidate
        else:
            target = self.allocate("layout", "sources", readable_filename(old.name if old else "layout.loc", "layout"))
            rendered = _rewrite_layout_paths(section["source_text"], templates, target.parent)
            self.write(target, rendered.encode("utf-8"))
        section["source_path"] = str(target)
        section["source_text"] = rendered

    def package_source(self, source: dict[str, str]) -> None:
        from .package_v2_source import parse_package_v2_json, PackageV2SourceError
        old = self.original(source["path"]) if source["path"] else None
        text = source["text"]
        try:
            parsed = parse_package_v2_json(text.encode("utf-8"), source_name=str(old or "package.source.json"))
        except (PackageV2SourceError, ValueError):
            parsed = None
            self.warnings.append("Package Source 尚未完成，已原样保存草稿；未解析的网格引用仍需检查。")
        def dependency_name(frozen, mesh):
            names = self.digest_names.get(frozen.artifacts.sha256, set())
            collected = next(iter(names)) if len(names) == 1 else frozen.identifier
            return readable_name(self.names.get(mesh, collected), "mesh")

        dependencies_readable = bool(old) and (parsed is None or all(
            self.reusable((old.parent / frozen.artifacts.mesh).resolve(), "package_v2",
                          dependency_name(frozen, (old.parent / frozen.artifacts.mesh).resolve()) + ".msh")
            and not any(part.isdecimal() for part in Path(frozen.artifacts.mesh).parts[:-1])
            for frozen in parsed.document.frozen_sources
        ))
        if (old and old.name.endswith(".source.json") and self.reusable(old, "package_v2")
                and dependencies_readable and old.is_file() and old.read_text(encoding="utf-8") == text):
            target = old
            if parsed:
                for frozen in parsed.document.frozen_sources:
                    mesh = (old.parent / frozen.artifacts.mesh).resolve()
                    self.bundle(str(mesh), "package_v2", required=True, expected=frozen.artifacts.sha256)
        else:
            name = old.name if old else "package.source.json"
            if not name.endswith(".source.json"):
                name = Path(name).stem + ".source.json"
            target = self.allocate("package_v2", "sources", readable_filename(name, "package"))
            if parsed and parsed.document.frozen_sources:
                payload = json.loads(text)
                for index, frozen in enumerate(parsed.document.frozen_sources):
                    mesh = ((old.parent if old else self.workspace) / frozen.artifacts.mesh).resolve()
                    name = dependency_name(frozen, mesh)
                    dependency = unique_named_path(target.parent / "workflow_assets", name) / (name + ".msh")
                    self.mkdir(dependency.parent)
                    copied = Path(self.bundle(str(mesh), "package_v2", required=True,
                                              expected=frozen.artifacts.sha256, destination=dependency))
                    payload["frozen_sources"][index]["artifacts"]["mesh"] = copied.relative_to(target.parent).as_posix()
                text = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
            self.write(target, text.encode("utf-8"))
        source.update(path=str(target), text=text)


def _restore_report_bindings(root: Path, bindings: list[dict[str, Any]], *,
                             strict: bool = True) -> list[str]:
    prepared = []
    warnings = []
    for record in bindings:
        # A malformed manifest must never turn into access outside the folder.
        report, mesh = _child(root, record["report"]), _child(root, record["mesh"])
        try:
            payload = _read_json(report)
            artifact = payload.get("mesh_artifact")
            version = record.get("identity_version", 1)
            if (not isinstance(artifact, dict) or _report_identity(payload, version) != record["identity"]
                    or not mesh.is_file() or artifact.get("size_bytes") != mesh.stat().st_size
                    or artifact.get("sha256") != sha256_file(mesh)):
                raise ValueError(f"工程网格或报告已修改，请重新生成：{mesh}")
        except (OSError, UnicodeError, ValueError) as error:
            if strict:
                raise
            warnings.append(f"已恢复工程编辑状态，但旧的网格报告未重新绑定：{error}")
            continue
        quality = payload.get("quality")
        quality_changed = (version >= 2 and isinstance(quality, dict)
                           and "mesh_path" in quality and quality["mesh_path"] != str(mesh))
        if artifact.get("path") != str(mesh) or quality_changed:
            artifact["path"] = str(mesh)
            if quality_changed:
                quality["mesh_path"] = str(mesh)
            prepared.append((report, json.dumps(payload, ensure_ascii=False, indent=2) + "\n"))
    for report, text in prepared:
        try:
            atomic_write_text(report, text)
        except OSError as error:
            if strict:
                raise
            warnings.append(f"已恢复工程编辑状态，但网格报告路径无法更新：{error}")
    return warnings


def _runtime_document(root: Path, envelope: dict[str, Any]) -> dict[str, Any]:
    _validate_envelope(envelope)
    document = validate_project_document(envelope["document"])
    for section, key in _path_fields(document):
        if section[key]:
            section[key] = str(_child(root, section[key]))
    document["project_folder"] = {"schema": FOLDER_SCHEMA, "active_tab": envelope.get("active_tab", document["active_tab"])}
    document["project_folder"]["package_history"] = [
        {**record, "job": str(_child(root, record["job"])),
         "output": str(_child(root, record["output"]))}
        for record in envelope.get("package_history", [])
    ]
    if envelope.get("warnings"):
        document["project_folder"]["warnings"] = list(envelope["warnings"])
    return document


def load_project_folder(project_path: str | Path) -> dict[str, Any]:
    path = Path(project_path).expanduser().resolve()
    if path.is_dir():
        path = project_file_in_folder(path)
    envelope = _read_json(path)
    if envelope.get("schema") != FOLDER_SCHEMA:
        raise ValueError("不是 EasyMesh 工程文件夹。")
    runtime = _runtime_document(path.parent, envelope)
    warnings = _restore_report_bindings(path.parent, envelope.get("report_bindings", []), strict=False)
    if envelope.get("naming_version") != _NAMING_VERSION:
        try:
            runtime = save_project_folder(path, runtime, workspace_root=path.parent)
        except (OSError, UnicodeError, TypeError, ValueError) as error:
            warnings.append(f"已恢复工程编辑状态，但文件名称暂未迁移；下次打开时将重试：{error}")
    if warnings:
        runtime["project_folder"].setdefault("warnings", []).extend(warnings)
    return runtime


def save_project_folder(project_path: str | Path, document: object, *,
                        workspace_root: str | Path,
                        package_job_path: str | Path | None = None) -> dict[str, Any]:
    """Copy dependencies, publish a portable snapshot, and return runtime paths."""
    if not isinstance(document, dict):
        raise ValueError("工程状态必须是对象。")
    active_tab = document.get("project_folder", {}).get("active_tab", document.get("active_tab"))
    if active_tab not in ("layer", "layout", "package_v2", "cdb"):
        raise ValueError("工程活动页面无效。")
    incoming_history = document.get("project_folder", {}).get("package_history", [])
    canonical = validate_project_document(document)
    section_v2 = canonical.pop("package_v2", None)
    canonical["schema"] = PROJECT_SCHEMA
    if canonical["active_tab"] == "package_v2":
        canonical["active_tab"] = "layout"
    path = project_file_in_folder(project_path)
    root = path.parent
    if path.exists() and not is_project_folder(path):
        raise ValueError(f"目标工程文件已存在，无法覆盖其他文件：{path}")
    root.mkdir(parents=True, exist_ok=True)
    for name in STAGE_DIRECTORIES.values():
        stage = root / name
        if stage.is_symlink():
            raise ValueError(f"工程目录不能是符号链接：{stage}")
        stage.mkdir(exist_ok=True)
    preparation = _Preparation(root, Path(workspace_root).expanduser().resolve())
    previous = _read_json(path) if path.exists() else {}
    history = deepcopy(previous.get("package_history", []))
    old_fingerprint = _layout_fingerprint(canonical)
    try:
        workflow = canonical.setdefault("workflow", empty_workflow_state())
        template_names = {item["id"]: item["name"] for item in workflow["library"]["templates"]}
        for template in workflow["library"]["templates"]:
            value = template["layer"]["output_path"]
            if value:
                preparation.names[preparation.original(value)] = template["name"]
        for asset in workflow["assets"]:
            if asset["kind"] == "layer" and asset.get("template_id") in template_names:
                asset["name"] = template_names[asset["template_id"]]
            preparation.names[preparation.original(asset["mesh_path"])] = asset["name"]
            preparation.digest_names.setdefault(asset["sha256"], set()).add(asset["name"])
        # Archive Package bundles first so a CDB input referencing the same
        # mesh keeps the Package stage's canonical location.
        for record in incoming_history:
            archived_job = preparation.archive(record["job"], required=True)
            archived_output = preparation.archive(record["output"], expected=record.get("output_sha256"))
            relocated = {**record, "job": Path(archived_job).relative_to(root).as_posix(),
                         "output": Path(archived_output).relative_to(root).as_posix()}
            if relocated not in history:
                history.append(relocated)
        if package_job_path:
            from .package_v2_job import parse_package_v2_job_request
            job_path = preparation.original(str(package_job_path))
            job_bytes = job_path.read_bytes()
            request = parse_package_v2_job_request(job_bytes)
            if not workflow.get("package_source"):
                workflow["package_source"] = {"path": str(Path(request.source_root or preparation.workspace) / request.source_name),
                                              "text": request.source_text}
            original_output = Path(request.output_mesh_path)
            output_digest = sha256_file(original_output) if original_output.is_file() else None
            matching = next((record for record in history
                             if record["request_sha256"] == request.sha256
                             and record.get("output_sha256") == output_digest
                             and _child(root, record["job"]).read_bytes() == job_bytes), None)
            if matching:
                preparation.mapped[job_path] = _child(root, matching["job"])
                preparation.mapped[original_output] = _child(root, matching["output"])
            else:
                archived = preparation.archive(str(job_path), required=True)
                output = preparation.archive(request.output_mesh_path)
                record = {"job": Path(archived).relative_to(root).as_posix(),
                          "output": Path(output).relative_to(root).as_posix(), "request_sha256": request.sha256}
                if output_digest is not None:
                    record["output_sha256"] = output_digest
                history.append(record)
        # Assets establish the shared mapping before editor output/input fields.
        for asset in workflow["assets"]:
            stage = asset["kind"] if asset["kind"] in STAGE_DIRECTORIES else "layer"
            asset["mesh_path"] = preparation.bundle(asset["mesh_path"], stage, required=True,
                                                     expected=asset["sha256"], name=asset["name"])
        active = workflow["library"]["active_template_id"]
        active_name = next((item["name"] for item in workflow["library"]["templates"] if item["id"] == active), None)
        for template in workflow["library"]["templates"]:
            layer = template["layer"]
            preparation.source(layer, "layer", "bump.layer", name=template["name"])
            layer["output_path"] = preparation.bundle(layer["output_path"], "layer", name=template["name"])
        preparation.source(canonical["layer"], "layer", "bump.layer", name=active_name)
        canonical["layer"]["output_path"] = preparation.bundle(canonical["layer"]["output_path"], "layer")
        layout = canonical["layout"]
        layout["output_path"] = preparation.bundle(layout["output_path"], "layout")
        preparation.layout(layout)
        cdb = canonical["cdb"]
        cdb["input_path"] = preparation.bundle(cdb["input_path"], "layout")
        cdb["output_path"] = preparation.bundle(cdb["output_path"], "cdb")
        if "export" in canonical:
            export = canonical["export"]
            stage = "cdb" if Path(export["artifact_path"]).suffix.lower() == ".cdb" else "layout"
            export["artifact_path"] = preparation.bundle(export["artifact_path"], stage)
        if section_v2 and not workflow.get("package_source"):
            workflow["package_source"] = {"path": str(preparation.workspace / (section_v2["source"]["path"] or "package.source.json")),
                                          "text": section_v2["source"]["text"]}
        if workflow.get("package_source"):
            preparation.package_source(workflow["package_source"])
        _refresh_layout_fingerprint(canonical, old_fingerprint)
        for container, key in _path_fields(canonical):
            if container[key]:
                container[key] = Path(container[key]).relative_to(root).as_posix()
        canonical = validate_project_document(canonical)
        envelope = {"schema": FOLDER_SCHEMA, "naming_version": _NAMING_VERSION,
                    "active_tab": active_tab, "document": canonical,
                    "package_history": history, "report_bindings": list(preparation.report_bindings.values()),
                    "warnings": preparation.warnings}
        text = json.dumps(envelope, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
        if len(text.encode("utf-8")) > MAX_PROJECT_BYTES:
            raise ValueError("工程文件超过大小限制。")
        runtime = _runtime_document(root, envelope)
        # Only copied reports are changed before publication. Existing reports
        # are already bound on load and never edited during failed saves.
        _restore_report_bindings(root, [record for record in envelope["report_bindings"]
                                       if _child(root, record["report"]) in preparation.created])
        atomic_write_text(path, text)
        # Once the envelope is published, its v2 identities accept either the
        # previous or relocated quality path. Rebind reused reports now, so a
        # failed save never edits evidence belonging to the previous envelope.
        warnings = _restore_report_bindings(root, [
            record for record in envelope["report_bindings"]
            if _child(root, record["report"]) not in preparation.created
        ], strict=False)
        if warnings:
            runtime["project_folder"].setdefault("warnings", []).extend(warnings)
        return runtime
    except BaseException:
        for created in reversed(preparation.created):
            created.unlink(missing_ok=True)
        for directory in reversed(preparation.created_directories):
            try:
                directory.rmdir()
            except OSError:
                pass  # Only remove empty directories created by this save.
        raise


__all__ = ["FOLDER_SCHEMA", "STAGE_DIRECTORIES", "project_file_in_folder", "new_project_path",
           "create_project_folder", "is_project_folder",
           "save_project_folder", "load_project_folder"]
