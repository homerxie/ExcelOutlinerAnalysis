"""Build the Windows source/wheel share ZIP without development data.

First: python -m pip wheel --no-deps --wheel-dir dist/wheels .
Then:  python scripts/build_windows_share.py --wheel dist/wheels/<app>.whl
"""
from __future__ import annotations

import argparse
import ast
from email.parser import BytesParser
import hashlib
from pathlib import Path
import re
import zipfile


ROOT = Path(__file__).resolve().parents[1]
APPLICATION_SUFFIXES = {".py", ".qml", ".layer"}


def _release(root: Path) -> tuple[str, str]:
    """Read literal release constants without importing GUI dependencies."""
    match = re.search(
        r'^version = "([^"]+)"',
        (root / "pyproject.toml").read_text(encoding="utf-8"),
        re.M,
    )
    if match is None:
        raise ValueError("Missing project version in pyproject.toml")
    constants: dict[str, str] = {}
    tree = ast.parse((root / "src/easymesh/version.py").read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in {"__version__", "DISPLAY_VERSION"}:
                    value = ast.literal_eval(node.value)
                    if not isinstance(value, str):
                        raise ValueError(f"{target.id} must be a literal string")
                    constants[target.id] = value
    version = match.group(1)
    if constants.get("__version__") != version:
        raise ValueError("version.py and pyproject.toml versions do not match")
    label = re.sub(r"\s+", "-", constants.get("DISPLAY_VERSION", "").strip())
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", label):
        raise ValueError("DISPLAY_VERSION must provide a safe release filename")
    return version, label


def _application_files(root: Path) -> list[Path]:
    return [
        path
        for path in sorted((root / "src/easymesh").rglob("*"))
        if path.is_file() and path.suffix in APPLICATION_SUFFIXES
    ]


def _validate_wheel(wheel: Path, root: Path, version: str) -> None:
    with zipfile.ZipFile(wheel) as archive:
        metadata_names = [
            name for name in archive.namelist() if name.endswith(".dist-info/METADATA")
        ]
        if len(metadata_names) != 1:
            raise ValueError("Expected exactly one wheel METADATA file")
        metadata_name = metadata_names[0]
        metadata = BytesParser().parsebytes(archive.read(metadata_name))
        if metadata["Name"] != "easymesh-gmsh-demo" or metadata["Version"] != version:
            raise ValueError("Wheel name/version does not match this source tree")
        wheel_info = BytesParser().parsebytes(
            archive.read(metadata_name.replace("/METADATA", "/WHEEL"))
        )
        if wheel_info.get_all("Tag") != ["py3-none-any"]:
            raise ValueError("Expected a platform-independent py3-none-any application wheel")
        # Compare both directions so removed modules cannot survive in a stale wheel.
        sources = {
            source.relative_to(root / "src").as_posix(): source
            for source in _application_files(root)
        }
        bundled = {
            name
            for name in archive.namelist()
            if name.startswith("easymesh/") and Path(name).suffix in APPLICATION_SUFFIXES
        }
        if bundled != sources.keys():
            missing = sorted(sources.keys() - bundled)
            extra = sorted(bundled - sources.keys())
            raise ValueError(f"Rebuild stale wheel: missing files={missing}; extra files={extra}")
        for name, source in sources.items():
            if archive.read(name) != source.read_bytes():
                raise ValueError(f"Rebuild stale wheel: {source}")


def _collect_share_files(root: Path, wheel: Path) -> dict[str, bytes]:
    files: dict[str, bytes] = {}

    def add(path: Path, name: str | None = None) -> None:
        if path.is_symlink():
            raise ValueError(f"Refusing to include a symlink: {path}")
        if not path.is_file():
            raise FileNotFoundError(f"Required packaging file is missing: {path}")
        files[name or path.relative_to(root).as_posix()] = path.read_bytes()

    for name in (
        "pyproject.toml", "MANIFEST.in", "README.md", "requirements.txt",
        "requirements-build.txt", "run_demo.py", "EasyMesh.spec",
    ):
        add(root / name)
    files["requirement.txt"] = b"# Compatibility alias; canonical dependencies are in requirements.txt.\n-r requirements.txt\n"
    for path in _application_files(root):
        add(path)
    windows_dir = root / "packaging/windows"
    for name in ("install_windows.bat", "run_windows.bat", "check_windows.bat", "README_WINDOWS.md"):
        add(windows_dir / name)
    for path in sorted(windows_dir.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        # Keep original paths so an unpacked share can build a new share itself.
        add(path)
        if path.parent == windows_dir and path.suffix == ".bat":
            # ASCII commands + CRLF work without relying on cmd's code page.
            files[path.name] = path.read_text(encoding="ascii").replace("\n", "\r\n").encode("ascii")
        elif path.name == "README_WINDOWS.md":
            add(path, path.name)
    # Use the application's bundled default, not a locally edited user example.
    add(root / "src/easymesh/resources/bumpcell.layer", "examples/bumpcell.layer")
    add(root / "examples/layout_coordinates.csv")
    add(root / "examples/local_template_lid.source.json")
    for path in sorted((root / "examples/package_v2").iterdir()):
        if path.suffix in {".json", ".md"}:
            add(path)
    for name in (
        "benchmark_preview_3d.py", "check_windows_runtime.py", "create_package_v2_demo_job.py",
        "generate_ui.py", "build_windows_share.py",
    ):
        add(root / "scripts" / name)
    add(root / "ui/main_window.ui")
    for path in sorted((root / "ui").glob("*.ui")):
        add(path)
    add(root / "docs/windows-compatibility.md")
    files["tests/__init__.py"] = b""
    for name in (
        "test_app_runtime.py", "test_package_v2_preview_3d.py",
        "package_v2_current_sources.py", "test_windows_share.py",
    ):
        add(root / "tests" / name)
    for path in sorted((root / "tests/fixtures").rglob("*.json")):
        add(path)
    add(wheel, "wheels/" + wheel.name)
    files["SHA256SUMS.txt"] = "".join(
        f"{hashlib.sha256(data).hexdigest()}  {name}\n"
        for name, data in sorted(files.items())
    ).encode("utf-8")
    return files


def build_share(wheel: Path, output_dir: Path, *, root: Path = ROOT) -> Path:
    version, label = _release(root)
    _validate_wheel(wheel, root, version)
    files = _collect_share_files(root, wheel)
    package_name = f"EasyMesh-Windows-{label}"
    output_dir.mkdir(parents=True, exist_ok=True)
    output = output_dir / f"{package_name}.zip"
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            archive.writestr(f"{package_name}/{name}", data)
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix(".zip.sha256").write_text(f"{digest}  {output.name}\n", encoding="ascii")
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--wheel", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "dist")
    args = parser.parse_args()
    output = build_share(args.wheel.resolve(), args.output_dir)
    with zipfile.ZipFile(output) as archive:
        file_count = len(archive.namelist())
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    print(f"Created: {output.resolve()}")
    print(f"Files: {file_count}; ZIP size: {output.stat().st_size:,} bytes")
    print(f"SHA256: {digest}")


if __name__ == "__main__":
    main()
