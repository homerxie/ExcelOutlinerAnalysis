# Easy Outlier GUI Tutorial

这份教程面向日常使用 GUI 的同事，重点讲最常见的操作流程，不讲代码实现。

## 1. 界面分区

左侧是操作区，按 tab 分成几类：

- `Setup`
  - 选择 `Database Folder`
  - 选择 `Template File`
  - 选择 `Input Excel/CSV`
  - 使用旁边的 `Open File` / `Open Folder` 快速定位当前路径
  - 配置数值文本清洗
  - 模板校验、模板导入导出、保存 debug bundle
- `Import`
  - 导入新的 Excel/CSV 数据到当前数据库工作区
  - 查看当前数据库快照
  - 删除误导入的数据行
- `Golden`
  - 配置并生成 built golden
  - 可选择中心值、阈值模式、reference dimensions、filters
- `Analyze`
  - 配置分析范围、golden 来源、outlier criteria、z threshold
  - 运行报表导出

右侧是结果区：

- `Golden Coverage`
  - 显示 built golden 覆盖了多少数据点，哪些点没有匹配到 golden
- `Outlier Summary`
  - 显示本次分析得到的 outlier 汇总和 outlier ratio 统计
- `Log`
  - 显示操作日志和报错信息

## 2. 数据库结构

一个 `Database Folder` 就是一套数据库。

数据库目录下通常会看到：

- `temp/`
  - 当前未保存的工作区
  - 导入、删行、build golden、分析等操作先写到这里
- `result/`
  - 分析导出的 Excel 结果
- `golden/`
  - built golden 文件
- 其他数据库数据文件

日常可以把它理解成：

- 上层目录 = 已保存版本
- `temp/` = 当前编辑中的版本

## 3. 最常用流程

```mermaid
flowchart TD
    A["选择 Database Folder"] --> B["选择 Template File"]
    B --> C["选择 Input Excel/CSV"]
    C --> D["Import Data"]
    D --> E{"是否需要 built golden?"}
    E -- Yes --> F["Build Golden"]
    E -- No --> G["进入 Analyze"]
    F --> G["进入 Analyze"]
    G --> H["选择 Golden Source / Outlier Criteria / Scope"]
    H --> I["Run Analysis"]
    I --> J["查看 Outlier Summary / Golden Coverage"]
    J --> K["Save Database 或 Save Database As"]
```

## 4. 第一次使用建议

### 4.1 选择数据库

先在 `Setup` 里选择 `Database Folder`。

建议：

- 新项目新建一个独立目录作为数据库
- 不要长期使用默认的 `tempDatabase`
- 选好后可以点右侧 `Open Folder`，直接打开当前数据库目录

如果打开数据库时发现：

- `temp/` 和上层已保存数据库不一致

程序会提示你选择：

- `Continue Temp Workspace`
- `Discard Temp And Reload Saved Database`

含义是：

- 继续使用上次未保存的工作区
- 或丢弃未保存改动，回到上次已保存版本

### 4.2 选择模板

`Template File` 支持：

- `.json`
- `.xlsx`

推荐：

- 日常编辑用 Excel template
- 版本管理或 debug 时保留一份 JSON template
- 选好后可以点右侧 `Open File`，直接打开当前模板文件

填写 row 维度、column 层级或筛选字段名时，支持忽略大小写、空格、下划线和连字符的自动匹配，例如 `chain_name`、`CHAIN-NAME`、`ChainName` 都可匹配 `Chain Name`，Group By 也适用。精确 Name 优先；非精确写法有歧义时会提示候选名称。筛选值、样品 ID 值等仍按原有规则处理。完整范围与填写示例见 [GUI Tutorial V2：字段名称自动匹配](GUI_tutorial_v2.md#field-name-matching)和 [Template Help v2：字段名称自动匹配](template_help_v2.md#field-name-matching)。

模板里和本次新增能力最相关的两块是：

- `node_orders`
  - 定义 node sequence
  - 会影响 `Outlier Summary` 的排序和 `New / Existed` 判定
- `row_dimensions` / `numeric_cleanup`
  - 定义行维度怎么拆
  - 定义导入时是否先清洗数值文本

如果只是想快速开始，可以先使用示例模板：

- [chip_reliability_template.json](examples/chip_reliability_template.json)
- [chip_reliability_template.xlsx](examples/chip_reliability_template.xlsx)

`Setup` 页里的 `Template Tools` 现在有两个单向转换按钮：

- `Convert Template: JSON -> XLSX`
  - 把当前选中的 JSON 模板转换成 Excel 模板
- `Convert Template: XLSX -> JSON`
  - 把当前选中的 Excel 模板转换成 JSON 模板

注意：

- 这两个按钮现在不是导出 pair
- 每次只转换成一种目标格式
- 输出文件是否覆盖，仍然按 GUI 的已有覆盖确认流程处理

## 5. 导入数据

### 5.1 基本导入

在 `Setup` 里选择 `Input Excel/CSV` 后，到 `Import` tab 点击导入。

`Input Excel/CSV` 右侧的 `Open File` 可以直接打开当前输入文件。

如果数据库里已经有相同样品属性的数据，GUI 会提示你选择冲突处理方式：

- `Replace Existing`
- `Append And Shift Repeat`
- `Cancel`

含义：

- `Replace Existing`
  - 用新数据替换数据库中相同键的旧数据
- `Append And Shift Repeat`
  - 把新数据追加进去，并把 `repeat index` 往后顺延

### 5.3 数值文本清洗

如果输入文件里的数值列可能长这样：

- `1,234mV`
- `5.1%`
- `10E-3mA`

可以在 `Setup` 里启用：

- `Enable Numeric Text Cleanup`
- `Cleanup Mode`
- `Characters To Remove`

两种模式：

- `Remove All Non-Numeric Characters`
  - 自动去掉大多数单位和杂字符
- `Remove Specified Characters`
  - 只去掉你手工指定的字符或字符串

补充：

- 科学记数法里的 `E/e` 会被保留
- 例如 `10E-3` 会被正确解析成数字，而不是把 `E` 删除

### 5.2 删除误导入数据

如果导入错了，可以在 `Current Database Snapshot` 中选中行，然后删除。

这是数据库级删除，不只是本次分析隐藏。

如果某次 import 的所有数据都被删掉或被完全 replace，对应的 import history 记录也会自动清理。

## 6. Build Golden

如果你要用 built golden：

1. 到 `Golden` tab
2. 选择 reference dimensions
3. 选择 filters
4. 配置：
   - `Golden Center`
   - `Outlier Golden Method`
   - `Relative Limit`
   - `Sigma Multiplier`
   - `Absolute Lower Bound`
   - `Absolute Upper Bound`
5. 点击 `Build Golden`

说明：

- `Outlier Golden Method` 支持任意布尔表达式，只要由 `relative`、`sigma`、`absolute`、`and`、`or`、括号组成
- 下拉框里的内容只是示例，不是完整枚举；例如 `relative or ((sigma and absolute) or (absolute and relative))` 这种也可以
- `Relative Limit` / `Sigma Multiplier` / `Absolute Lower Bound` / `Absolute Upper Bound` 只会在方法里真正用到对应项时生效
- GUI 修改这些值后，如果和 template 不一致，程序会询问你是否回写 template
- `Filters` 建议按一行一个 `key=value` 来写
- 同一个 key 如果要匹配多个值，可以直接逗号分隔，例如：`reliability_node=T0,T1`
- 也可以重复写同一个 key，程序会自动合并，例如两行分别写 `reliability_node=T0` 和 `reliability_node=T1`
- 对同一个 key 来说，多值按“任一值匹配”；不同 key 之间仍然同时生效

## 7. Run Analysis

在 `Analyze` tab 里，最常用的配置有：

- `Golden File`
  - analysis 只读取 built golden `.json`
  - 不再支持 template 内嵌 golden 值
  - 右侧 `Open File` 可以直接打开当前 golden 文件
- `Outlier Criteria`
  - `Modified Z Score`
  - `Golden Deviation`
  - `Modified Z Score And Golden Deviation`
  - `Modified Z Score Or Golden Deviation`
- `Z Threshold`
- `Analysis Scope`
  - `Current Input File`
  - `Entire Database`
  - `Checked Imports`
- `Report Output File`
  - 右侧 `Open Folder` 可以直接打开当前结果文件所在目录

还可以加过滤条件：

- `Include Sample Keys`
- `Include Nodes`
- `Exclude Sample Keys`
- `Exclude Nodes`
- `Include Tests`
- `Exclude Tests`

这些过滤条件会统一作用在当前 scope 上。

这 6 个输入框默认都是空白：

- 空白时不限制
- 靠灰色 placeholder 提示输入格式
- 对 `Include ...` 来说，留空就表示“全部包含”

`Include Sample Keys` 现在会真正按 template 里的 `sample_dimension_names` 过滤，不再默认只看 `sample_id`。

输入格式是：

- 多个 sample key 之间，用 `;` 分隔
- 如果 sample 主键是两层，例如 `lot_id + sample_id`，推荐写成按第一层分组的形式：
  - `LotA:S001,S002,S003;LotB:S001,S002,S004`
- 这表示：
  - `LotA + S001`
  - `LotA + S002`
  - `LotA + S003`
  - `LotB + S001`
  - `LotB + S002`
  - `LotB + S004`
- 显式写法也仍然支持：
  - `LotA,S001;LotB,S002`

例如如果 template 里写的是：

- `sample_dimension_names = lot_id;sample_id`

那么：

- `LotA:S001,S002;LotB:S003,S004`

表示只分析这些样品主键：

- `lot_id = LotA` 且 `sample_id = S001`
- `lot_id = LotA` 且 `sample_id = S002`
- `lot_id = LotB` 且 `sample_id = S003`
- `lot_id = LotB` 且 `sample_id = S004`

对应地：

- `Exclude Sample Keys`

也是同样格式，例如：

- `LotC:S003,S004;LotD:S005`

`Include Tests` 和 `Exclude Tests` 用来在分析一开始就直接筛掉不需要的测试列，不会等到 `Outlier Summary` 再做显示层过滤。

- `Include Tests` 留空，表示不做 include 限制，也就是全部包含

输入格式是：

- 多个字段之间，用 `;` 分隔
- 每个字段写成：
  - `字段=值1,值2,...`
- 不同字段会同时生效

例如：

- `Chain Name=Chain1,Chain2;Test Type=TestType1;id=TestType2_Chain2_1,TestType2_Chain2_2`

这也是 GUI 里 `Include Tests / Exclude Tests` 当前显示的灰色 placeholder 示例。

表示：

- `Chain Name` 只能是 `Chain1` 或 `Chain2`
- `Test Type` 只能是 `TestType1`
- `analysis_groups.id` 只能是 `TestType2_Chain2_1` 或 `TestType2_Chain2_2`

这里可用的字段来自两部分：

- template 的 `column_header_levels`
  - 例如 `Chain Name`、`Test Type`、`Repeat Index`
- template 的 `analysis_groups`
  - 例如 `id`、`display_name`、`raw_column` / `column_name`、`logical_metric`、`unit`

### 7.1 Node Sequence 会影响什么

`Analyze` 本身不需要你每次手工选 sequence，程序会按 template 里的 `node_orders` 工作。

它会影响：

- 结果里的 node 排序
- `Outlier Summary` 里 `New / Existed / Recovered` 的判断

当前 `New / Existed / Recovered` 的规则是：

- 判定粒度是同一个 `sample + chain`
- 先按当前 sequence 往前找前驱节点
- 如果紧邻上一项 node 不存在于当前 sample 的数据里，就继续往前找更早 node
- `New`
  - 当前 node 是 fail
  - 且所有更早、有数据的前驱节点都没 fail 过
- `Existed`
  - 当前 node 是 fail
  - 且任意一个更早、有数据的前驱节点已经 fail 过
- `Recovered`
  - 当前 node 是 pass
  - 且最近一个有数据的前驱节点是 fail

也就是说，中间 node 缺失时，程序不会直接中断，而会继续往前回溯。

### 7.2 模板里的两层 Row 聚合规则怎么理解

如果 template 里配置了：

- `outlier_row_merge_max_dimension`
- `outlier_merged_sample_fail_rule`
- `outlier_node_fail_rule`

可以按下面这个顺序理解：

1. 先固定高优先级 row 维度  
   比如 `lot_id + sample_id + reliability_node`

2. 再看从 `outlier_row_merge_max_dimension` 开始往下的那些 row 维度  
   这些维度会一起进入同一个判断池

3. `outlier_merged_sample_fail_rule`  
   用来判断这个“判断池”本身是否 fail  
   例如：
   - `any_fail`：池子里任意一条 raw row fail，这个池子就 fail
   - `all_fail`：池子里所有 raw row 都 fail，这个池子才 fail

4. `outlier_node_fail_rule`  
   用来判断同一个 `sample + node` 下多个判断池，最后这个 node 算不算 fail  
   例如：
   - `any_fail`：这个 node 下任意一个池子 fail，node 就 fail
   - `all_fail`：这个 node 下所有池子都 fail，node 才 fail

举个最常见的例子，如果 row 优先级是：

- `lot_id`
- `sample_id`
- `reliability_node`
- `site_id`
- `repeat_id`

并且：

- `outlier_row_merge_max_dimension = site_id`

那么程序会这样看：

- `lot_id + sample_id + reliability_node` 先固定
- `site_id + repeat_id` 进入同一个 row merge 规则体系
- 先按 `outlier_merged_sample_fail_rule` 判断每个 site 对应的数据块是否 fail
- 再按 `outlier_node_fail_rule` 判断整个 node 是否 fail

## 8. 结果会输出什么

每次运行分析，都会输出和目标格式一致的结果 Excel，主要包括：

- `Sorted`
- `deviation-zscore`
- `deviation-golden`
- `outliers`
- `Outlier Summary`

如果 built golden 对不同数据点的 golden 不一致，还会额外输出：

- `golden-by-point`

默认结果目录是当前数据库下的：

- `result/`

## 9. 查看 GUI 结果

### 9.1 Golden Coverage

当分析带了 `Golden File` 时，这里会告诉你：

- 总 measurement 数量
- 匹配到 golden 的数量
- 未匹配数量
- 未匹配示例

如果旧 golden 无法覆盖新导入数据，先看这里最方便。

### 9.2 Outlier Summary

这里会显示：

- 哪些 sample 有 fail
- 哪条 chain fail
- 从哪个 node 开始失效
- `New / Existed / Recovered` 状态
- outlier ratio 统计

其中这三种状态可以简单记成：

- `New`
  - 这条 chain 在当前 node 首次出现失效
- `Existed`
  - 这条 chain 在更早的 node 已经失效过
- `Recovered`
  - 这条 chain 在当前 node 已恢复成 pass
  - 且最近一个有数据的前驱 node 是 fail

这里的“更早”不是只看上一项，而是会按对应 sequence 一路往前回溯；但 `Recovered` 只看最近一个有数据的前驱节点。

`Outlier Summary` 上面的统计表里，常见指标含义如下：

- `All Outlier Blocks`
  - 出现任何单个数据点 fail 的样品 + Node 组合数量
- `Merged Outlier Blocks`
  - 按照当前 merge 规则判为 fail 的所有样品 + Node 组合数量
- `New Merged Outliers`
  - 按照当前 merge 规则判为 fail 的新增样品 + Node 组合数量
- `Recovered Blocks`
  - 按照当前 merge 规则判为 pass，且最近一个有数据前驱节点为 fail 的样品 + Node 组合数量
- `Affected Samples`
  - 被判为 fail 的样品数量
- `Raw Failing Test Cells`
  - 被判为 fail 的单个数据点数量

可以用一句话记：

- `Raw Failing Test Cells` 看底层原始 fail 有多少
- `All Outlier Blocks` 看“只要出现过原始 fail 就摆出来”的块有多少
- `Merged Outlier Blocks` 看最终真正成立的 fail 有多少
- `New / Existed / Recovered` 看这些最终结果里是新增、延续失效，还是恢复
- `Affected Samples` 看最终影响到了多少个样品

### 9.3 Log

如果导入失败、模板校验失败、文件被占用、路径不对，先看这里。

## 10. Save Database 和 Save Database As

### 10.1 Save Database

适合保存到当前数据库。

作用：

- 把 `temp/` 工作区内容合并回上层数据库
- 同时保存当前 GUI 设置

### 10.2 Save Database As

适合把当前工作区另存为新的数据库目录。

作用：

- 把当前 `temp/` 内容复制到新目录
- 同时带上 GUI 设置

如果保存过程中发现某些文件被 Excel 占用，程序会提醒你先关闭 Excel 再重试。

## 11. 关闭软件前要注意什么

如果你当前仍在默认的 `tempDatabase` 上工作，而且里面已经有数据，关闭软件时会提醒你：

- 是否另存到一个正式目录

建议：

- 临时测试可以先用 `tempDatabase`
- 正式项目请尽快 `Save Database As`

## 12. Debug Bundle

如果遇到难定位的问题，可以在 `Setup` 里使用 `Save Debug Bundle`。

它会导出：

- 当前 GUI 设置
- 当前结果摘要
- 当前日志
- 当前 template / input / golden / output 文件副本
- 当前数据库快照

这很适合拿来复现问题或做 CLI debug。

## 13. 常见问题

### 13.1 为什么结果里没有某些样品？

先检查：

- `Analysis Scope`
- `Include Sample Keys`
- `Include Nodes`
- `Exclude Sample Keys`
- `Exclude Nodes`
- `Checked Imports`

### 13.2 为什么 built golden 提示有未匹配数据？

通常是因为：

- 新数据的 sample / node / reference key 不在旧 golden 里
- template 改了，logical metric key 发生变化
- reference dimensions 和 filters 变化了

先看右侧 `Golden Coverage`。

### 13.3 为什么我导入后关掉软件，再打开还是上次没保存的状态？

因为当前数据库下的 `temp/` 工作区还在。

打开数据库时可以选择：

- `Continue Temp Workspace`
- `Discard Temp And Reload Saved Database`

### 13.4 为什么结果文件没法覆盖？

如果目标 Excel 文件正被打开，Windows 常见会锁文件。

请先关闭 Excel，再重新导出或保存数据库。

## 14. 建议的团队使用方式

- 每个项目使用独立数据库目录
- template 和 database 放在同一个项目目录下
- 重要改动后及时 `Save Database`
- 定期备份数据库目录
- 遇到异常时先导出 debug bundle

## 15. 相关文件

- 使用说明： [README.md](README.md)
- 模板完整说明： [template_help.md](template_help.md)
- 示例 JSON 模板： [chip_reliability_template.json](examples/chip_reliability_template.json)
- 示例 Excel 模板： [chip_reliability_template.xlsx](examples/chip_reliability_template.xlsx)
