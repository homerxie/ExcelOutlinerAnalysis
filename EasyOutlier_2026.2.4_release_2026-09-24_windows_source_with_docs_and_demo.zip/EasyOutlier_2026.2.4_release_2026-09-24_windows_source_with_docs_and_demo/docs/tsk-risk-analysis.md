# Independent TSK risk analysis

TSK Analysis is a separate workbench tab. It uses the paths in Setup and the current effective Fail rules from Analyze, including unsaved changes in the Analyze controls. You do not need to run Analyze first. TSK keeps its own data source, import selection, node/sample scope, batch grouping and XY/feature selection; it does not provide a separate Fail-method or classification-pool selector. Running Analyze does not run TSK estimation, and TSK Results does not replace existing Analyze results.

完整中文推导、置信区间解释及可复现算例见 [TSK 数学原理（LaTeX Markdown）](tsk-risk-mathematical-principles.md)。适合有高等数学基础、尚未系统学习概率统计的读者。

## Try the hypothetical example

1. In Setup, select `examples/tsk_risk_demo/template.xlsx` (or `template.json`) and `examples/tsk_risk_demo/data.csv` as the input.
2. In Analyze, use the demo's Modified Z-score method and threshold 3.5. Then open **TSK Analysis**, choose **Input · Setup 中的输入文件**, and click **运行 TSK 风险分析**. No prior Analyze run, Golden file or database import is needed for this example.
3. Select T0 or T1 in **TSK Results**. Risk bars show single-instance probabilities; whiskers show 95% intervals. Chain fit compares observed and predicted proportions; the table reports residuals in percentage points.
4. Optionally enable XY or select numeric/categorical attributes and choose the feature model: **Logistic（原有）** or **线性风险（凸）**. Run again after changing the model. Feature-model type risks refer to numeric attributes at their training-layout means and categorical attributes at their reference levels, not an average of the probabilities across the type's actual instances. The existing demo uses numeric attributes only.
5. Export XLSX for type estimates, bounds, chain counts, sample outcomes, topology, diagnostics and the configuration snapshot. Long JSON metadata is split into ordered parts to avoid Excel truncation.

The demo has 12 chains, three TSK types, 400 samples and two nodes. Its topology and values are invented and clearly labelled. The bundled ordinary template contains disabled EXAMPLE placeholders; replace them with real topology before enabling TSK analysis.

## Original batches and parent batches

Choose an existing row dimension such as `lot_id` as the batch field. It must be different from the reliability-node dimension. This field also preserves original-batch identity in mode `none`, so the same sample number in two lots remains two observations. Batch settings determine which final counts are fitted together. They do not rename source data, change the template's sample identity, replace batch values used to match Golden references, or change the shared Fail rules.

| Batch mode | Fit groups |
| --- | --- |
| `none` — no batch split; combine selected lots | Sum final counts from all selected original batches within each node, then fit one common model. |
| `separate` — original batches | Fit each original batch separately within each node. |
| `parent` — parent batches | Map original batches to parent IDs, sum their final chain counts within each node, then run maximum likelihood again. |

The batch controls are the only way to split TSK fits beyond the reliability node. There is no additional temperature, voltage or other condition-grouping control. Legacy `group_by_dimensions` values in templates or saved TSK settings are ignored.

For a runnable example, use [batch_data.csv](../examples/tsk_risk_demo/batch_data.csv) with the same demo template. It contains L001 with 100 samples, L002 with 150, and L003 with 150, at both T0 and T1. Sample numbers restart within each batch. The run settings are also provided in [batch_settings.json](../examples/tsk_risk_demo/batch_settings.json), and expected counts in [batch_expected_counts.csv](../examples/tsk_risk_demo/batch_expected_counts.csv).

To combine L001 and L002 while keeping L003 separate:

1. Select the intended data/imports, nodes and samples in **TSK Analysis**.
2. Select original-batch mode with `lot_id` as the batch field to inspect L001, L002 and L003 separately.
3. To fit parent batches, choose parent-batch mode and enter `L001 → M001`, `L002 → M001`, `L003 → M002`. Every original batch present in the selected analysis scope needs a nonempty parent ID; an unmapped batch is not silently dropped.
4. Check the shared Fail rules in Analyze, run TSK analysis, and inspect **Batch Counts** in the export alongside the parent results. Risk results retain `parent_batch_id` and `source_batches` for traceability.

For this complete-data example, separate mode yields six groups. Parent mode yields four groups: M001 at each node has 250 effective samples per chain, and M002 has 150. Mode `none` combines the three selected batches and yields two node groups, each with 400 effective samples per chain. These files illustrate aggregation and repeated sample numbers across batches; they do not introduce or prove a separate batch-effect model.

The Fail method, empty-value handling, sample identity and merge rules/order come from Analyze's current effective report settings. Analyze's current default Z-score threshold is applied as the run-wide override; old per-item Z-score overrides do not supersede it. Golden references use the shared file in Setup. Modified Z-scores follow Analyze's logical-measurement pooling across the whole selected data scope; they are not recalculated separately for each original batch, parent batch or final fit group. Batch mode changes the fit groups, not the classification rule. Legacy `fail_method` and `classification_pool` values saved inside TSK settings are ignored.

Shared rules do not mean reusing labels from the last Analyze result. TSK recomputes the same classifier for its selected data. Different import, node or sample selections can change the Z-score pool and therefore the labels.

Aggregation happens **after each original batch has merged its repeats and resolved Pass / Fail / Missing**. Sample `S01` from L001 and sample `S01` from L002 remain different observations. Parent mode combines batches with the same parent ID; mode `none` combines all selected lots within each node. For each chain, sum Fail and Pass counts to obtain the effective denominator; sum Missing separately and exclude it from that denominator. The engine fits these summed counts, never an average of fitted TSK probabilities.

Pooling assumes a common TSK probability vector within the parent/node group, or common type and feature coefficients when features are enabled, using the same chain topology. Unequal batches contribute according to their valid counts in the binomial likelihood. A larger batch therefore contributes more information than a smaller batch. The mapping itself neither verifies this common-risk assumption nor removes differences between heterogeneous batches. The mathematical derivation and an unequal-size example are in [§6.6 of the mathematical guide](tsk-risk-mathematical-principles.md#batch-likelihood).

The corresponding runtime settings are:

```python
settings = {
    "batch_mode": "parent",  # none | separate | parent
    "batch_dimension": "lot_id",
    "batch_mapping": {"L001": "M001", "L002": "M001", "L003": "M002"},
}
```

These controls are TSK run settings. Calls without `batch_mode` use `none`: all selected batches are fitted together for each node. Every batch mode uses the shared Analyze classification rules and whole-scope Z-score pool.

## Template

The JSON `tsk_analysis` section corresponds to the Excel `tsk_analysis` settings sheet and `tsk_instances` table. Each instance row contains `CHAIN_ID`, `TSK_instance_ID`, `TSK_ID`, numeric `X`/`Y`, an optional explicit `CHAIN_KEY`, and declared numeric or categorical feature columns. `CHAIN_KEY` is a JSON array containing the complete column header path through the Chain level. A unique Chain name can be resolved automatically; ambiguous names require explicit paths and distinct external IDs.

Repeated TSK types are counted, not deduplicated. An instance ID must be unique within its chain. Coordinates must use a common coordinate system and unit. Density values require a consistent fraction/percentage convention and measurement window. The optional settings are `enabled`, `use_xy`, `coordinate_unit`, `feature_columns`, `categorical_feature_columns` and `feature_model`. `feature_model` accepts `logistic` (the default, including old templates) or `linear_hazard`. The GUI/run settings can override the template choice; settings, fitted diagnostics and exports retain the choice. A legacy TSK `group_by_dimensions` field no longer changes the analysis.

### Numeric and categorical attributes

`feature_columns` lists all optional attributes. `categorical_feature_columns` explicitly identifies the categorical subset; all other listed attributes remain numeric. This preserves existing numeric templates and avoids guessing a model from a column's formatting.

| Bump-size input | Declaration | Model interpretation |
| --- | --- | --- |
| `large`, `small` or `medium`; material labels such as `copper`, `aluminum` | Explicitly categorical | Text labels with no numeric magnitude or equal-spacing assumption. |
| `40`, `60`, `80` | Numeric, not in `categorical_feature_columns` | A continuous size measurement. Equal size changes have equal effects on log-odds in Logistic, or negative log-survival in linear risk, holding other inputs fixed. |
| `40`, `60`, `80` | Explicitly categorical | Three levels with separately estimated contrasts; no size ordering or equal-spacing assumption. |
| `40um`, `60um`, `80um` or `M`, `L` | Explicitly categorical | Category labels. Text is not automatically parsed as a physical size or converted into units. |

For example, these are partial template settings, not a replacement for the topology:

```json
{
  "feature_columns": ["metal_A_density", "bump_size", "material"],
  "categorical_feature_columns": ["bump_size", "material"]
}
```

An instance's `features` can then contain `{"metal_A_density": 0.35, "bump_size": "large", "material": "copper"}`. Other instances can use `"small"` and `"aluminum"`; these labels do not need numeric substitutes. In Excel, declare both setting rows in `tsk_analysis`, and use the corresponding attribute columns in `tsk_instances`. X/Y are always numeric. Missing or invalid selected category values are not silently treated as a baseline category.

Category labels are trimmed nonempty text or finite numbers. Numeric `40` and `40.0` share the label `"40"`; text `"40.0"` remains a different text label. Boolean, null and nonfinite values are rejected. Use a consistent label convention across the entire template.

The runtime `feature_names` selection can contain both kinds of attribute. The service derives the selected categorical subset from the template and passes it as `categorical_feature_names` to the model. Selecting a category does not split observations into additional fit groups: grouping remains node plus the selected lot/parent mode.

## Observation and missing-data rules

- One observation is a unique sample at a node for one chain. Repeats, sites and measurement columns follow Analyze's current effective merge order and any/all definitions; they do not increase the number of independent dies.
- Nodes are always fitted separately. The selected original-batch field preserves batch boundaries while merging repeats; only completed counts are combined for parent fits or for the all-lot fit in mode `none`. Temperature, voltage, site and other row fields do not create additional TSK fit groups; their measurements follow the shared merge rules.
- Fail and Pass use Analyze's current effective rules, including unsaved UI values. TSK's data scope, batch mode and XY/features remain independently selected.
- With `empty_as_fail=True`, an empty numeric cell is directly classified as Fail. With `empty_as_fail=False`, the empty leaf is skipped: it does not take part in any/all merging and does not propagate an unknown state. A known sample/node/chain with no remaining leaf at all is reported as Missing and excluded from the valid denominator.
- For nonempty measurements, Modified Z-score pools with fewer than three values or zero MAD have an effective score of 0 under Analyze's classifier; missing Golden matches produce `golden_fail=False`. Z-score/Golden AND and OR use ordinary Boolean logic. These cases do not become Missing simply because the statistical reference is uninformative or absent.
- Original input files preserve identified all-empty sample rows. Measurement-only databases cannot recover rows with no numeric measurements at import; the result explicitly warns about that exposure limitation.

## Model and intervals

### Choosing a feature model

Both feature modes use standardized numeric columns and reference-category indicators with effects shared across TSK types. With no selected numeric/XY/category features, both choices use the existing convex type-only model.

| Mode | Instance probability | Optimization |
| --- | --- | --- |
| `logistic` — original/default | `p = sigmoid(D θ)` | Three initial points with local optimization; global optimality is not guaranteed. |
| `linear_hazard` — convex linear risk | `h = D θ >= 0`, `p = 1 - exp(-h)` | Convex binomial likelihood with a nonnegative-hazard constraint for every fitted instance. |

Linear risk changes how features affect probability; it is not an equivalent reparameterization of the Logistic feature model. Its coefficients describe additive changes in negative log-survival, not odds ratios. The solver checks feasibility and constrained stationarity. Convexity does not ensure unique parameters, finite maximum-likelihood estimates, or a good match to observed chain rates. Inspect identifiability, intervals and Chain Fit for either mode.

The linear constraints cover the instances on fitted chains. A type's numeric-mean/reference-category point, or a requested unobserved category combination, can lie outside that domain: a negative predicted hazard is withheld (`reference_outside_domain` or `outside_model_domain`), not clamped to a zero probability. Linear-risk intervals profile the hazard contrast under the same instance constraints. Normal-approximation difference intervals are withheld at active hazard boundaries; self-comparison remains exactly zero.

### Likelihood and uncertainty

For each node and configured original or parent batch, or all selected batches together in mode `none`, the type-only model uses `q_i = 1 - product_t((1-p_t)**C_it)`, where C is the instance-count matrix. Nonnegative log-survival parameters are fitted by binomial maximum likelihood. Rank and realized-likelihood checks suppress unidentifiable type estimates.

In the original Logistic feature mode, each instance uses a type intercept, centered/standardized numeric effects, and categorical indicator effects on the logit scale. A category with L levels uses L−1 uncentered indicator columns in both modes. Levels are collected from the complete template topology and sorted consistently; the first is the reference. Its indicators are all zero. The choice is a coding reference, not a claim that this level is smallest, safest or most common. Instance survival probabilities are then multiplied within each chain. Logistic uses multiple starts without a global optimality guarantee; linear risk uses the constrained convex objective described above. Neither mode automatically adds a nonlinear spatial surface.

The original type estimates describe conditional probability at numeric means and every category's reference level. They are not feature-independent risks: for example, with bump and stack features, the reference estimate applies to one stated bump/stack combination. For categorical GUI runs, the first risk chart and its risk details instead show the full Cartesian grid of TSK/category combinations, with no 200-cell limit; the complete condition is part of each row's label. A slice selected in combination analysis does not replace the homepage grid. Neither view represents average risk across category frequencies or actual instances. Diagnostics include `categorical_features`, with levels and references, alongside numeric `feature_scaling`. The same template retains category references across batches; a batch missing a level receives a diagnostic instead of silently changing its reference. Missing support or a category perfectly tied to `TSK_ID` can make reference type probabilities unidentifiable. Encoding categories does not remove these data limitations or establish independence between physical instances.

Intervals are profile-likelihood approximations, with appropriate exact transformations or bounds in supported boundary cases. Parent fits recompute intervals from their summed-count likelihood; the intervals are not averaged from the original batches and do not estimate between-batch variability. Each type row records its interval method. Nonconvergence, boundary estimates and unavailable intervals are explicit. A probability of zero is not evidence that true risk is exactly zero.

### Logistic coefficient limits and zero boundaries

**TSK Analysis → Logistic 系数绝对值上限** controls the initial Logistic coefficient box. Its default is 35; values from 1 to 700 are accepted and saved with the analysis settings. For example, 70 permits a candidate intercept below −35. A larger box does not supply missing information, remove parameter confounding, or establish convergence. The report records the actual box, the coefficients approaching its edges and their raw and projected gradients.

If a profile fit reaches a coefficient limit before a reliable interval is established, the interval stays blank and identifies the affected parameter and limit. A finite coefficient limit is not converted into a probability endpoint of zero or one.

When very low type risks or coefficient limits warrant further checking, the engine refits the same model with nonnegative reference odds, `r_t >= 0`, so an exact zero boundary can be represented without inventing a finite logit intercept. For an instance, `p = r_t * exp(features) / (1 + r_t * exp(features))`. Convergence, feasible parameter directions and each requested probability are checked before publishing a boundary result. Shared feature coefficients still have the selected numerical limit. Logistic optimization remains local; this check is not a proof of the global optimum.

A validated zero estimate is labelled **零边界估计**, with an upper confidence limit where available. Its TSK logit coefficient is blank with `boundary_unbounded`, because the zero boundary corresponds to `alpha_t -> -infinity`; the numerical starting-box value is not published as its coefficient. Other identifiable type risks and finite feature coefficients remain available. Small positive estimates use scientific notation when ordinary percentage formatting would hide them. A zero estimate does not establish permanent immunity to failure.

If all observations in the design-defined supporting chains are Pass, an exact one-sided bound is available from their exposure. A pure matching-design subset gives an exact binomial bound; including chains with other instances gives a conservative bound under the same independence model. Other validated zero-boundary upper limits use a profile-likelihood approximation and are explicitly labelled **近似**. These limits are pointwise, not simultaneous guarantees across all TSKs. An unavailable upper limit retains the point estimate and its boundary label, with a specific `interval_error`. Normal-approximation difference intervals are withheld when the fit has a zero boundary; identical-condition comparison remains exactly zero.

The approximate boundary branch retains the conventional profile-likelihood confidence-set cutoff `chi2.ppf(confidence, 1) / 2` (about 1.9207 at 95%). Its interval has the shape `[0, upper]`, but it has not been separately calibrated as a one-sided 95% bound. It is therefore labelled **近似上限（95% 轮廓似然阈值）**; the exact branch keeps **单侧 95% 上限**. A regular one-sided 95% likelihood threshold would be smaller, but applying that calibration automatically is not justified for every boundary/confounded model. These labels distinguish the methods without changing the computed endpoints.

A zero-boundary error bar spans **zero to a one-sided confidence upper limit**, not a symmetric standard deviation around zero. Zero observed failures do not establish a zero upper limit: for `n` independent direct Bernoulli observations, all Pass, the exact 95% upper bound is `1 - 0.05**(1/n)`. This is about 2.95% at `n=100` and 0.30% at `n=1000` ([NIST exact binomial limits](https://itl.nist.gov/div898/software/dataplot/refman2/auxillar/exacbino.htm)). Those sample counts cannot simply be replaced by the number of distinct chains. When a TSK risk is inferred from mixed chains, profile intervals also allow the other fitted parameters to change; weak separation of their contributions can give a wide upper limit despite a zero optimum. The graph's automatic probability-axis scale can make a small absolute interval look long. Inspect the numeric upper limit, confidence level and interval method in the tooltip before interpreting its visual size.

The inference assumes that a chain's Fail event is the OR of its instance failures, with conditional independence. Multi-instance accumulated drift or correlated defects can violate that assumption. Intervals currently assume independent chain observations; correlations between chains on the same die or between repeated nodes are not corrected by a cluster bootstrap. The data and paired sample outcomes remain available for follow-up validation. Fits estimate risk under these assumptions, not a directly observed root cause.

## Combination probabilities and comparisons

The combination view answers questions such as “For TSK A, what is the predicted risk with a small bump and copper material?” It uses the same fitted main-effects model. It does not fit a separate model for every category combination, add interaction terms, or change the shared Analyze Fail rules or lot groups.

After fitting with the desired categorical features:

1. GUI runs automatically prepare all categorical combinations with **无数据组合留空（不外推）** enabled by default. Select the fitted node/batch group in **TSK Results** to see every TSK × bump × stack combination in the first risk chart and risk details. There is no fixed total-combination count limit; 19 TSKs × 4 bumps × 3 stacks produces all 228 rows. Unsupported or unidentifiable rows retain their positions with blank estimates and explicit status.
2. In **组合分析 → 计算条件**, choose **全部类别组合**, or choose one categorical feature such as `bump_size` and fix each other selected category, such as `material=copper`. X/Y and other numeric values are never expanded into combination dimensions.
3. Show all TSKs or one TSK, and select the horizontal-axis level used as the comparison baseline.
4. Click **计算组合概率**. The probability/profile-interval calculation runs in the background and automatically opens the populated **热力图** page when complete. Click a heatmap cell to inspect its TSK in **类别对比**; **明细** retains the estimates and support table, and **全部提示** shows the full scrollable warnings. Full queries remain available regardless of grid size. Scrolling or display pages keep large charts readable without removing calculated rows from the tables or export.

Numeric features, including X/Y, are held at their fitted group means. Each cell reports a single-instance conditional probability for its TSK and category combination, together with a 95% profile-likelihood interval. The comparison reports `delta_probability = probability - baseline_probability` for the same TSK and fixed other categories, with a covariance-aware, joint-information delta-method interval. The baseline selected here is for comparison only: it does not change the template's coding reference or refit the main model.

Each combination has both a statistical estimation status and a separate support status:

| Support field/status | Meaning |
| --- | --- |
| `layout_instance_count` | Matching TSK/category instances in the complete template topology. |
| `active_instance_count` | Matching instances on chains with valid tests in the fitted group. |
| `chain_count` | Distinct validly tested chains containing those matching instances. |
| `chain_test_exposure` | Sum of valid tested counts over those distinct chains, counting each chain once. This is not a count of independent samples or observed instance outcomes. |
| `observed` | At least one matching layout instance belongs to an actively tested chain. Its individual Fail outcome is still latent; the risk is inferred from chain data. |
| `no_active_support` | Matching layout exists, but none of its chains has valid tests in this fitted group. |
| `extrapolated` | The requested TSK/category combination does not occur in the template layout. An estimable result is a model extrapolation. |

Support matching uses the TSK and all selected categories; it does not assert that any actual instance lies at the numeric mean values. Support and identifiability are different questions. A combination can be estimable through shared effects without direct matching layout, and a supported combination can still be statistically unidentifiable. Unavailable probabilities or intervals remain blank/null, never zero. The engine checks the combination contrast itself, so it can retain an identifiable prediction even when individual coefficients cannot be separated.

With **无数据组合留空（不外推）** selected, both absent-layout and inactive-layout combinations stay in the grid with `status=no_data` and blank probability/interval fields. Differences requiring an unsupported reference are also blank. Unchecking the option allows explicitly labelled model extrapolations. The setting is saved with each query and exported, and does not change the fitted coefficients or classify an unsupported combination as zero risk.

`interval_unavailable` means a point estimate exists but its interval could not be established reliably. Probability-profile failures include nuisance optimization nonconvergence, finding a better optimum than the stored fit, non-finite arithmetic or root-finding failure. The row's `interval_error` gives the specific reason. `delta_interval_error` separately explains a failed probability-difference interval. These statuses differ from `no_data` and `not_identifiable`; the latter can also withhold the probability itself.

Probability intervals are profile-likelihood approximations. Difference intervals, when available, use the joint expected information matrix of the same fit and include covariance between both predictions; they are not obtained by subtracting probability-interval endpoints. Linear-risk fits with active hazard boundaries withhold the normal-approximation difference intervals. Intervals are pointwise, not simultaneous coverage for the whole heatmap. Heatmap intensity is relative to the current view; compare probability values and intervals across queries rather than color strength alone. Large differences between probability-scale deltas across TSKs do not establish interactions: a shared category effect on either model's parameter scale can produce different absolute probability changes at different baseline risks.

Completed queries are cached with their settings, saved with database workspace state and included in XLSX export. Each result belongs to its serializable fitted-model snapshot, allowing several comparisons to be retained without changing the underlying fit. Missing or unsupported legacy model snapshots require a fresh analysis before combination predictions can be computed.

Chain names use natural numeric order, such as `Chain1, Chain2, Chain10`, in results and topology displays. Hover over a chain's failure-rate point to inspect its constituent TSKs, instance counts and inferred single-instance probabilities. These probabilities use each physical instance's actual categorical and numeric conditions; they need not equal the risk grid's probabilities at numeric means. The same TSK appearing with different conditions is listed separately. Unidentifiable contributions are explicitly unavailable even when the chain's combined probability is identifiable. The model combines instance risks as `1 - product(1-p_instance)`; a member probability is not the probability that this member caused a particular observed chain failure. The XLSX **Chain Members** sheet exports these conditional member estimates. **TSK Risk** retains the original reference estimates with explicit `risk_conditions` and `reference_environment`; **Combination Risk** contains the calculated combination rows.

## Feature risks and model coefficients

**特征与系数** reports each categorical feature's levels by TSK, with the other categories fixed at their coding references and numeric features at their training-layout means. It reuses calculated combination rows, preserving blank unsupported cells and interval errors; it never treats an individual coefficient as a probability. These are conditional feature comparisons, not category-wide averages over a mixture of TSK types.

The coefficient table includes identifiable TSK intercepts, numeric coefficients, categorical effects and reference levels. Logistic uses `logit(p) = alpha_t + sum(beta_j * z_j) + category effects`; linear risk uses `h = -log(1-p) = alpha_t + sum(beta_j * z_j) + category effects`, followed by `p = 1-exp(-h)`. Numeric coordinates are standardized as `z_j = (x_j-mean_j)/scale_j`; means and scales are shown alongside their coefficients. A reference category's coefficient of zero is a coding convention. An effect that cannot be independently estimated stays blank. XLSX exports include **Feature Risk** and **Feature Coefficients** when those results are available.

The separate [text-category demo](../examples/tsk_risk_demo/README.md#文本类别与组合预测的独立示例) provides [a template](../examples/tsk_risk_demo/categories/template.xlsx) and [input data](../examples/tsk_risk_demo/categories/data.csv) for `large/small` bumps and `aluminum/copper` materials. It deliberately omits `TSK_C + small + copper` from the layout so an estimable extrapolation can be distinguished from directly supported combinations. The original numeric demo remains unchanged.

## Joint risk for inseparable parameters

**TSK Results → 联合风险** retains the main fit and reports identifiable whole configurations when their individual parameters cannot be separated. Re-run analysis to generate this page for older saved results. The page distinguishes two meanings:

- **Joint conditions on one instance:** a TSK and its selected bump/stack conditions share one instance probability. In Logistic mode this is `sigmoid(alpha_TSK + feature effects)`. The coefficients are not separate components with separate failure events.
- **Multiple instances together:** a bundle fails when at least one member fails. Its probability is `1 - product((1-p_j)**m_j)`, using the displayed member counts and conditions. For `2 × A + 1 × B`, the two copies of A remain part of the definition; the risk is not divided equally among members or averaged into an individual probability.

For example, a chain containing only A and B may identify their combined risk as 10% while leaving both individual probabilities blank. Another example has observed compositions AB and BC: those two configurations can be reported, but their connection through B does not establish the risk of ABC. Merging parameters is not itself evidence of identifiability.

The calculation groups identical observed instance designs into conditional instance types and records their counts in each chain. A candidate bundle must have a verified representation as a linear combination of the observed chain hazard compositions. It also checks whether the observed Fail/Pass counts leave the package risk free to vary along equal-likelihood allocations; a structural certificate alone is insufficient. These checks go beyond a locally insensitive Jacobian direction. Automatic candidates comprise fixed-ratio groups, observed complete-chain compositions reduced to their integer ratios, and supported single-instance conditions with confounded coefficients. They are useful configurations, not a claim that there is one unique or minimal grouping. Unsupported conditions are not filled, and numeric/XY grids are not expanded. A failed or unstable main fit remains unavailable on this page.

Point estimates use the original fitted model. Intervals use the observed chain counts: directly matching compositions can use transformed exact binomial intervals; other cases combine chain intervals conservatively through the verified composition relation. The latter applies a Bonferroni correction within each reported group and can be wide. Suitable all-Pass support supplies a one-sided upper bound. These are pointwise intervals for each displayed group, not simultaneous coverage of every row, and they retain the model's within-chain independence assumption. The interval construction uses [exact binomial limits](https://itl.nist.gov/div898/software/dataplot/refman2/auxillar/exacbino.htm) and the [Bonferroni inequality](https://itl.nist.gov/div898/handbook/prc/section4/prc473.htm).

The main model's estimate can disagree with an interval derived from the directly observed chain evidence; both values are retained with an explicit mismatch status. Incompatible or numerically unavailable intervals stay blank with their reason. A zero estimate remains a boundary estimate, not a guarantee of zero failures.

The detail area records members, ratios, conditions, the probability formula, supporting chains and the composition certificate. Computation limits and omitted groups are reported rather than silently expanding an unbounded search. Results are saved with the workspace. XLSX exports contain **Joint Risk** summaries and the losslessly split full JSON in **Joint Risk Details**, ordered by `group_index` and one-based `part`; concatenate `value` without separators to reconstruct each report.

## Logistic fit debug report

Open **TSK Results → 组合分析 → 全部提示** to inspect the selected group's full Logistic fit report. Use **复制诊断文本** or **保存诊断 TXT** to retain the complete report. It records the parameter definitions, objective and gradient diagnostics, solver status, rank and identifiability checks, and the optimization trajectory. For the main fit, each starting point and optimization phase retains its complete candidate coefficient vector and sampled accepted iterations. It does not record every trial evaluated during a line search. During the fit, the progress message shows the current starting point, phase, iteration and gradient-to-threshold ratio. The report includes numerical details for investigating the fit, without copying the original sample records or complete topology into the text report.

Candidate coefficients in this report can come from failed, nonconverged or unidentifiable fits. They are diagnostic values, not validated feature effects or risk results. Recording them does not relax convergence/identifiability thresholds, add regularization, or change the coefficients and probabilities shown in **特征与系数**.

For a deficient-rank, near-limit or very-low-probability candidate, **参数不敏感与共同变化范围** adds two checks:

- Change one coefficient while holding the others fixed, and report the sampled range over which the observed chain probabilities and likelihood remain within tolerance.
- Move coefficients together along a numerical null direction, listing each parameter and its change per unit of the main parameter. Instance-design null directions and local Chain Jacobian directions are labelled separately. Both are checked by recalculating the nonlinear chain probabilities; a Jacobian direction alone does not establish equivalence over a finite range.

The current diagnostic requires every chain's absolute probability change to be at most `1e-8 + 1e-5 * abs(original_probability)` and absolute NLL change to be at most `1e-4`. Reported ranges contain the current candidate and pass finite sampled checks; they are not confidence intervals or a proof between sample points. The report gives the tolerances, parameter ratios, endpoints and observed changes. Scans respect the selected coefficient box and cover at most 24 parameters and six coupled directions, prioritizing weak and confounded parameters; omitted counts are explicit. These checks describe the original logit candidate before any zero-boundary review, and do not authorize predictions at unsupported combinations.

XLSX exports retain the full text in **Diagnostics**, under `fit_debug_report`, and the structured strict JSON under `fit_debug`. Long values are split into ordered rows to avoid Excel's cell-length limit, including for Chinese text and emoji. Reassemble a value by selecting its zero-based `group_index` and `item`, sorting by the one-based `part`, checking the declared `parts` count, and concatenating `value` without separators. Parse the joined `fit_debug` text as JSON; unavailable/nonfinite numeric diagnostics are represented by `null`. The group index distinguishes groups even when their display labels match. Old results without debug fields remain exportable, and the existing **Prediction Context** snapshot and its export format are unchanged.

## Runtime and development

NumPy and SciPy are declared project dependencies. Install through the existing `pip install -e .` setup. The UI uses PySide6/QPainter and adds no browser/chart runtime. All controls and layouts are defined in `.ui` and checked-in generated modules.

Automated coverage includes known-risk recovery, repeated instances, identifiability, zero/all-failure boundaries, feature scaling, JSON/XLSX round trips, shared Analyze classification and empty-value handling, node/batch separation, independent execution, persistence and export. Native macOS Cocoa geometry and horizontal expansion are checked separately. Windows execution and frozen distributions require validation on Windows; this change does not claim a newly tested Windows executable.
