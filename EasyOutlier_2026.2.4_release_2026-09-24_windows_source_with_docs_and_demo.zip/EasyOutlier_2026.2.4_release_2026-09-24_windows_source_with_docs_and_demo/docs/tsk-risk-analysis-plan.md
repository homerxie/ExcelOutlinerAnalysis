# TSK risk analysis development plan

2026-09-22. Baseline `codex/chunked-sheet-export` (including existing field-name changes) was fast-forwarded into `main` at `12daa7f`. All feature work belongs to `codex/tsk-risk-analysis`.

## Scope and workflow

2026-09-23 simplification: the independent condition-field control has been removed. TSK fit groups now use only the reliability node and the selected batch mode: all selected lots pooled, each original lot, or user-defined parent lots. Retired template and GUI grouping values are ignored and no longer exported. In pooled mode, original-batch identities still protect equal sample numbers in different lots; counts are summed only after each lot merges its repeated measurements.

- Add an independent **TSK Analysis** workbench tab and **TSK Results** result tab. Ordinary Analyze must not start TSK estimation or require topology.
- Reuse workspace paths and the current Analyze classification/merge rules. The separate TSK service has its own import/node/sample scope, batch mode, XY switch and optional numeric or categorical features; its Fail summary is read-only.
- Define topology in JSON and Excel templates: CHAIN_ID, TSK_instance_ID, TSK_ID, numeric X/Y and extensible numeric or explicitly declared categorical attributes. Preserve repeated TSK types as distinct instances; resolve chains using full header paths. Old templates remain valid, with undeclared feature types remaining numeric.
- Supply clearly labelled hypothetical topology and a reproducible standalone demo template/data set. No invented mapping should be presented as real layout information.

## Statistical contract

- Observation unit: unique original-batch sample × node × chain; repeated measurements do not inflate sample size. Reuse Analyze's leaf classification and merge pipeline. Empty cells are Fail when its empty-cell option is enabled; otherwise skip them. A known sample/chain with no retained leaf is Missing and excluded from the effective denominator; incomplete database exposure is disclosed.
- Fit `q_i = 1 - product_t((1-p_t)**C_it)` using nonnegative log-survival parameters and binomial maximum likelihood.
- Optional XY and selected features use a low-complexity logistic instance model, then aggregate instance survival within each chain. Center/scale numeric features; encode a categorical feature with L levels as L−1 uncentered indicators. Use complete-template levels in stable sorted order, with the first as reference, so batch filtering does not silently change the reference. Detect confounding and missing levels; this extension is not guaranteed convex.
- Check structural and numerical identifiability; do not publish arbitrary individual rankings for unidentifiable types.
- Report 95% profile-likelihood approximate intervals, explicit boundary/fitting status, and the independent-observation assumption. For feature models, type risks and intervals refer to numeric features at their training-layout means and categorical features at their template-derived reference levels, stated on screen and in exports. This is not the overall average instance risk.

## Results and UI

- TSK probability bars with interval whiskers; missing/unidentifiable estimates labelled explicitly.
- Observed versus predicted chain probabilities and residuals; detail tables with Fail, Pass, Missing and counts.
- Topology preview, model diagnostics and XLSX export with provenance and actual options.
- Combination analysis from the fitted main-effects model: select a categorical axis, fix other categories, select all or one TSK and a comparison baseline, then calculate conditional probabilities, intervals, probability differences and support in the background. Show a heatmap and comparison details without adding interactions or extra fit groups.
- Define all widgets, static text, defaults, layouts and size policies in `.ui` files; regenerate with `.venv/bin/pyside6-uic`. Controllers handle events and dynamic state only. Use a Qt-painted plot widget declared in `.ui`.

## Implementation ownership

1. Template models, JSON/XLSX round trips, guidance and examples.
2. Independent numeric engine and statistical tests.
3. Dedicated `.ui` panels, generated modules, plots and GUI tests.
4. Independent data service, MainWindow wiring, dependencies, end-to-end tests and documentation.

## Verification

- Baseline: 1,136 tests and 7 subtests passed (`pytest tests`, offscreen).
- Exact synthetic parameter recovery; repeated instances; rank deficiency; zero/all Fail; interval boundary behavior; feature scaling and confounding.
- Template backward compatibility and JSON/XLSX round trips.
- Missing and repeated measurements, node/batch separation, shared Analyze Golden and Z-score classification, separate execution from Analyze, export checks.
- Complete test suite, generated-UI consistency, macOS Cocoa display and horizontal resizing. Windows packaging limitations, if any, reported explicitly.

## Progress

### Batch extension plan (2026-09-23)

- Extend only TSK Analysis/Results on the existing feature branch. Preserve the current behavior when batch mode is disabled.
- Add original-batch and parent-batch modes, a row-dimension selector, scope-aware batch discovery and an editable original-to-parent mapping. Save settings with the database workspace.
- Classify with the shared Analyze rules over the selected scope and merge repeated observations within original batches, then sum chain Fail/Pass/Missing counts inside each parent × node group and refit. Keep original sample identities and per-batch counts for traceability.
- Keep classification independent of batch fitting: all modes use the selected-scope Z-score pool. Never silently combine nodes or introduce additional condition strata that prevent requested pooling.
- Display parent identifiers/members with existing probability bars and confidence intervals; export parent identifiers and original-batch counts. Document the common-risk assumption and pooled likelihood.
- Verify duplicate sample IDs across batches, unequal exposures, incomplete mappings, Missing, source selection, persistence, exports and native macOS layout before delivery.

- [x] Save and verify existing work, merge into main, create feature branch.
- [x] Record development plan before implementation.
- [x] Implement template, engine, service and UI.
- [x] Verify synthetic and existing regression tests, native UI and exports.

## Completed verification

- Latest suite (2026-09-23): **1,376 tests and 7 subtests passed** (`QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m pytest tests -q`, 23.32 seconds).
- The [detailed mathematical guide](tsk-risk-mathematical-principles.md) includes independently checked profile endpoints. This cross-check exposed premature optimizer termination; the engine now verifies stationarity and uses a checked fallback before reporting intervals.
- All three changed/new generated UI modules exactly match `pyside6-uic` output; `git diff --check` and `pip check` pass.
- The demo's 24 node/chain counts match the injected Fail/Tested counts. Type-only and optional XY models converge with ranks 3 and 5 respectively.
- Native macOS Cocoa MainWindow loads the Excel demo template, executes the real background analysis for T0/T1, renders probability bars and intervals, and exports the full result workbook. Panel width expands from 589 to 807 pixels when the window grows from 1080 to 1440 pixels.
- Export includes 9,600 paired sample/chain outcomes. Direct row indexing avoids repeated worksheet scans; large configuration snapshots are split into ordered Excel-safe chunks.
- Windows and frozen executables were not built or executed in this macOS development run.

### Batch extension verification

- Completed the dedicated TSK batch controls, scope-aware discovery, database-state persistence, parent refitting, source traceability, export and mathematical explanation.
- Added 21 service/model regression cases and 5 GUI regression cases. A 1/1 batch plus a 0/9 batch produces pooled probability 1/10, preserving the appropriate sample weighting. Duplicate sample IDs in different original batches remain separate, including templates whose sample key does not include the batch field.
- The three-batch fixture yields six original-batch groups or four parent-batch groups. All 120 node/chain counts across both modes match independently retained injected labels.
- A native Cocoa MainWindow loaded a relocated copy of the demo database, restored mappings and four saved results, scanned batches through the actual button, ran four converged parent fits and six converged original-batch fits, and retained parent IDs when switching modes. Native controls expand correctly from 1080 to 1440 window width.
- The new portable `TSK_Batch_Demo` includes CSV input, topology template, populated database, saved parent settings/results and an XLSX result export. The original single-batch demo remains available.

### Simplified grouping verification

- Removed the independent TSK condition-field UI, runtime grouping parameter, and JSON/XLSX template field. Legacy saved fields are ignored even when they reference dimensions that no longer exist. Ordinary Analyze grouping remains unchanged.
- The three batch modes are now all selected lots pooled, original batches, and parent batches. Pooled mode retains original-batch sample identity while summing final counts per node, and uses the full selected scope for Z-score classification.
- Loaded a relocated legacy demo database in native Cocoa and ran all three modes through the actual GUI: pooled 2 groups, original batches 6 groups, parent batches 4 groups. All 144 node/chain counts matched the retained injected truth; pooled groups each had 400 valid samples per chain. Settings no longer contain the removed field, and the original parent mapping survives mode switches.
- Both edited `.ui` sources match regenerated Python; the Chinese mathematics document still renders with strict Pandoc/MathML validation.
- Batch-field defaults use explicit recognized names shared by the GUI and service. Fields such as `slot_id` and `repeat_id` are not inferred as lots; with no batch field, pooled mode uses the template's unique sample identity. A regression confirms multiple slots remain a single sample.

### Unified Fail rules (2026-09-23)

- Remove independent TSK Fail-method and classification-pool choices, and ignore their obsolete saved values. Display a live read-only summary of Analyze's current method, default Z threshold and empty-cell flag.
- Both Analyze's setting comparison and TSK dispatch use the same current-rule snapshot helper. Identity, merge levels/order, any/all rules, Fail method, empty-cell handling and the GUI's global Z-threshold override are captured before the worker starts. TSK applies no unrelated Analyze scope filters and does not write unsaved settings into the template.
- Directly reuse Analyze's leaf builder and merge pipeline, preserving explicit sample and batch identities around the pipeline. All batch modes classify the selected scope before splitting or pooling. Golden lookup and undefined-Z behavior match Analyze; informational warnings describe these cases without silently changing classifications.
- A relocated legacy demo restored an obsolete independent TSK Golden choice. Native GUI execution ignored it and followed the current Analyze Z rule. An unsaved Z threshold of 1e9 yielded 0/400 Fail for every chain; restoring 3.5 restored all expected chain counts in pooled/original/parent modes. Template bytes remained unchanged.
- Mathematical documentation and source demo settings now describe the shared rule and no-leaf Missing semantics. Regression checks compare all four Fail methods, both empty-cell policies and all six merge orders against Analyze's actual leaf and final merge states.

### Categorical feature extension (2026-09-23)

- Keep `feature_columns` as the list of all optional instance attributes. Add `categorical_feature_columns` as an explicit subset; any feature not listed there remains numeric for backward compatibility. X/Y remain numeric.
- Allow textual attributes directly: bump sizes `large`/`small`/`medium`, materials `copper`/`aluminum`, or other nonempty labels. Bump size may alternatively be a continuous measurement (`40`, `60`, `80`) or an explicitly categorical size label (`40um`, `60um`, `80um`). Categorical encoding must not introduce size ordering or equal spacing. Normalize finite numeric labels consistently, retain text labels and reject empty/invalid category values.
- Keep the runtime `feature_names` selection for both kinds of feature; derive selected `categorical_feature_names` from the template. Category effects are model covariates, never new fit-group or lot-stratification controls.
- Build L−1 indicator columns without centering, record complete-template category levels and the stable first-level reference in diagnostics, and retain the same reference across original and parent batch fits. Diagnose missing levels and category/type confounding rather than inventing reference-risk information.
- Explain type bars and profile intervals at numeric means plus category reference levels, including the bump-size treatment-coding equations and why adding an encoding cannot fix dependence or confounding. Leave existing numeric demo data and results unchanged.
- Verify template round trips, mixed-feature fits, category normalization, reference stability, confounding and numeric-only compatibility; verify changed UI generation/native layout separately. Validate all updated mathematical Markdown through strict Pandoc/MathML conversion.

### Categorical feature verification

- The complete suite passed with 1,344 tests and 7 subtests. Existing numeric-only demo data and assets were not changed to manufacture a category example.
- A native macOS Cocoa MainWindow loaded a temporary copy of the old demo database with a text-valued `bump_size=large/small` template, ran the actual analysis button and exported XLSX. The model rank was 4/4, all three TSK types were identifiable with intervals, and the reference label correctly stated `large`.
- Native resizing from 1080 to 1440 pixels expanded the panel from 479 to 659 pixels, the feature control from 425 to 605, and the reference text from 432 to 612 without horizontal scrolling. The template's bytes remained unchanged.
- All four updated Markdown documents passed strict Pandoc conversion; the detailed guide's numeric/categorical LaTeX formulas converted to MathML without warnings. `git diff --check` passed.

### Combination prediction and comparison plan (2026-09-23)

1. Preserve shared categorical main effects, shared Analyze classification/merge rules, and node/lot fit groups. Do not add TSK × category or category × category interactions in this iteration.
2. Save a serializable fitted-model snapshot sufficient to reconstruct prediction rows and likelihood calculations: parameter/encoding information, numeric scaling, template topology and fitted chain counts. Compute each combination's logit as a linear contrast of the same fitted coefficients. Check the contrast itself for identifiability, because an estimable combination can exist even when individual coefficients are not identifiable.
3. For a combination probability, profile the original likelihood subject to its fixed logit contrast and transform interval endpoints through logistic. For the probability difference against a selected baseline, use the joint-information delta method, preserving covariance between the two predictions. Do not subtract separate interval endpoints or interpret overlapping intervals as a difference test.
4. In TSK Results, let the user choose the categorical horizontal axis, fixed levels of the other selected categories, all TSKs or one TSK, and a comparison baseline. Execute requested predictions in a background worker, then present probability/interval and delta/interval views, support details and a heatmap. Keep each query to at most 200 cells; large requests can be split by TSK.
5. Report layout-instance count, active-instance count, contributing-chain count and chain-test exposure. Count each contributing chain's tested count once rather than once per matching instance; this exposure is not an independent-sample count. Distinguish observed combinations, extrapolated combinations with no matching layout, and layouts with no active test support. Unidentifiable/unavailable estimates remain null, never zero.
6. Retain multiple completed query results with their exact settings, save the cache with database workspace state and export it to XLSX. Predictions belong to their fitted snapshot; changing the selected query does not refit labels or change the model specification.
7. Document pointwise rather than simultaneous intervals, extrapolation, local-information limitations and the absence of interaction effects. Different probability-scale deltas across TSKs do not demonstrate an interaction when the fitted model shares one category odds ratio.
8. Provide a separate small demo with two textual attributes while preserving the original numeric demo. Verify contrast identifiability, profile intervals, covariance-aware deltas, all three support states, null handling, the 200-cell limit, query caching/persistence/export, generated UI and native macOS layout; validate the new mathematics with strict Pandoc/MathML conversion.

### Combination prediction verification

- The complete tests directory passed with 1,376 tests and 7 subtests. Model coverage includes linear-contrast identifiability, constrained profile intervals, shared-fit covariance in probability differences and explicit unavailable estimates/support states. The changed generated UI module exactly matched `pyside6-uic`; `git diff --check` and `pip check` passed.
- Native Cocoa successfully opened a relocated category-demo database and restored eight cached combination views. All 28 node/chain counts matched the retained injected counts.
- Recalculating an existing query through the actual button updated it without duplicating the cached view. Selecting `material` as the comparison axis, fixing bump to `small`, and using `copper` as the baseline created a ninth view. Saving and reopening retained all nine views.
- The combination UI separates query controls into **计算条件**, keeps the heatmap/comparison pages focused on the calculated result, and places full warnings in a scrollable **全部提示** page. No-result state opens the calculation page; completed calculation opens the heatmap.
- All four mathematical/use/demo/plan documents passed strict Pandoc conversion, including LaTeX-to-MathML without warnings; local links and probability-difference examples were checked.
- Final native Cocoa display and geometry checks passed at 1080×1000 and 1440×1000 window sizes. The results panel expanded from 410 to 566 pixels, with heatmap viewport heights of 384 and 416 pixels. Both probability and Δp plots remained fully visible, and the overlapping `copper` label was resolved. Screenshots were visually reviewed, and the complete native functional script passed again.
