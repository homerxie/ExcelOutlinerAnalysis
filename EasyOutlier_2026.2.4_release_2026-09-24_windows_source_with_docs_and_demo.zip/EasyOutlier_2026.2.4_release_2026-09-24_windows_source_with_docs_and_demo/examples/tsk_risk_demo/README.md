# TSK 风险反推示例

这里的拓扑、坐标、测量值和失效概率全部为假设数据，用于演示及回归测试。它们不代表任何真实芯片、版图或 TSK 的可靠性。

1. 在软件中选择 `template.json` 或等价的 `template.xlsx`。
2. 将 `data.csv` 导入一个新的测试数据库。
3. 在 Analyze 中确认使用 Modified Z-score、阈值 3.5，再打开独立的 TSK 分析页运行。TSK 直接使用 Analyze 当前生效的 Fail 规则，未保存的界面修改也生效；无需先执行 Analyze，也不需要 Golden 文件。
4. 默认只拟合 TSK 类型；勾选考虑 XY 后，可使用实例坐标拟合位置影响。每个可靠性节点独立拟合；是否按原批或母批拆分由批次设置控制。

数据包含 400 个唯一样品、T0/T1 两个节点、12 条 Chain 和 3 种 TSK 类型。各 Chain 包含不同的 TSK 数量，`TSK_A/B/C` 是设计类型，`TSK_instance_ID` 是各链中的不同物理实例。同链重复的设计类型必须逐行保留。所有 Chain 的完整键为 `["DemoDesign", "Chain_XX"]`，不能省掉 Design 后将不同设计的同名链混为一条。

测量值为约 100 Ohm 的正常值和约 1000 Ohm 的注入失效值，叠加 [-1, 1] 内的随机噪声。模板使用 modified z-score 3.5 判据；该构造保证正常值与注入失效可以明确分离。真实项目需要另行确认 Fail 判据是否代表物理开路，不能把一般统计离群等同于开路。

`expected_chain_counts.csv` 记录注入模型产生的各节点、各链总样品数 n 和失败样品数 k，可与软件结果核对。T1 沿用 T0 的实例随机阈值并提高风险，因此此例没有恢复，且不包含缺失测量。分母每个样品只计算一次，不是测试点或重复次数。

固定随机种子为 20260922。实例 X/Y 范围约为 -1200 至 1200 um。假设瞬时累计风险为：

```text
h_instance = h_type × node_multiplier × exp(0.30 × X / 1000 - 0.20 × Y / 1000)
p_instance = 1 - exp(-h_instance)
```

`h_type` 分别为 0.006、0.012、0.021；节点系数 T0=1、T1=1.8。链中任一实例失败即为该链失败。有限样本的估计不会精确等于这些参数；忽略 XY 时的类型模型也有意省略了生成过程中的位置因素。

需要重新生成时，在仓库根目录运行：

```bash
./.venv/bin/python examples/tsk_risk_demo/generate_demo.py
```

## 分批与母批示例

`batch_data.csv` 是同一组模拟测量的三批版本，继续使用上面的 `template.xlsx`：L001 有 100 个样品、L002 和 L003 各有 150 个样品，每批都包含 T0/T1。各批的样品编号都从 S0001 重新开始，因此也可核对软件不会跨批合并重号样品。

1. Setup 选择 `batch_data.csv` 和 `template.xlsx`，TSK Analysis 的数据来源选择输入文件；也可导入一个新的测试数据库后选择该导入记录。
2. 批次模式选择“按原批次分别统计”，批次字段选 `lot_id`，读取批次。运行后应有 3 批 × 2 节点共 6 组。
3. 改为母批合并模式，将 L001、L002 的母批编号都填为 M001，L003 填为 M002。Fail 规则继续使用 Analyze 当前设置，Z-score 按所选全部范围计算，不按原批或母批重新分池。
4. 运行后共有 4 组。M001 每节点、每链有效分母是 250，M002 是 150；各组有自己的 TSK 概率和区间。
5. 导出结果的 `Batch Counts` 保留原批计数，可与 `batch_expected_counts.csv` 核对。`batch_settings.json` 是上述运行参数的程序调用示例，不是另一个拓扑模板。

批次模式为 `none`（不分批，所选所有 lot 混合）时，仍保留原批字段 `lot_id`，先在各原批合并重复测量，再把三批的最终计数按节点汇总拟合，不平均原批概率，也不把跨批同号样品合成一个。此时得到 T0/T1 共 2 组，每节点、每链有效分母为 400。TSK 页没有额外的温度、电压等条件分层；分组只由可靠性节点与原批／母批设置决定。旧模板或旧界面设置中的 `group_by_dimensions` 会被忽略。

这是批次操作演示：只改变原示例的批次标签和样品编号，没有人为注入额外的批次风险效应。合并要求使用者判断所选原批是否适合共享一套风险参数。

TSK 页不再单独选择 Fail 方法或分类池；其数据范围、批次和 XY 设置仍然独立。旧 TSK 保存设置中的 `fail_method`、`classification_pool` 会被忽略。Analyze 当前默认 Z-score 阈值会统一覆盖本次各测项，旧逐测项覆盖值不再优先于它；更改此阈值或其他共享规则后，示例计数也可能随之改变。

空数值遵循 Analyze 的 `empty_as_fail`：开启时直接判 Fail；关闭时跳过该测量，只有已知样品在某节点、某 Chain 完全没有剩余测量时才记为 Missing 并排除分母。此示例没有空值。MAD 为零或有效值不足 3 个时，Z-score 判据按有效分数 0 处理；Golden 无匹配时 Golden Fail 为 False，这些情况本身不会产生 Missing。

重新生成三批版本：`./.venv/bin/python examples/tsk_risk_demo/generate_batch_demo.py`。

## 模板字段说明

JSON 顶层 `tsk_analysis` 与 Excel 两张独立工作表对应：

| 字段 | 作用 |
| --- | --- |
| `enabled` | 是否启用当前模板的 TSK 配置。普通 Analyze 不会自动执行本模块。 |
| `use_xy` | 默认是否考虑坐标，运行页可切换。 |
| `coordinate_unit` | 所有 X/Y 的统一长度单位。 |
| `feature_columns` | 所有额外特征列名称，既可包含数值列，也可包含显式声明的类别列。实际参与拟合的特征由运行页选择。 |
| `categorical_feature_columns` | `feature_columns` 的类别子集；未列入此处的特征保持数值含义，兼容原模板。X/Y 始终为数值。 |
| `instances` | 每行一个物理实例，对应 `tsk_instances` 工作表。 |

实例字段为 `chain_id`、`tsk_instance_id`、`tsk_id`、`chain_key`、`x`、`y`、`features`。Excel 表头分别是 `CHAIN_ID`、`TSK_instance_ID`、`TSK_ID`、`CHAIN_KEY`、`X`、`Y`，以及已声明的特征列。`CHAIN_KEY` 使用 JSON 数组，例如 `["DemoDesign", "Chain_01"]`。如果 Chain 名在整个模板中唯一，可以只填 `CHAIN_ID`，完整键会自动补齐；重名时必须填写完整键并给各链不同的 `CHAIN_ID`。

未配置新字段或新工作表的旧模板仍可正常使用，默认关闭 TSK。软件内置普通模板中的 `EXAMPLE_*` 实例也是假设占位，保持关闭；真实分析前必须替换成真实映射并启用。

## 如何增加 bump 尺寸或类别属性

现有 demo 数据没有新增 bump 属性，仍可按原来的步骤核对数值模型。自己的模板可以直接使用文本：`bump_size` 写 `large`、`small` 或 `medium`，`material` 写 `copper`、`aluminum`，都不需要先编成数字。把这些列同时列入 `feature_columns` 与 `categorical_feature_columns` 即可。

若 bump 尺寸也有具体数值，需要明确它的数学含义：

- 想把 `40`、`60`、`80` 当作连续尺寸，加入 `feature_columns` 即可，列中填写统一单位下的数值。模型估计尺寸每增加一个标准差的 log-odds 变化。
- 想分别比较三种规格，则同时把 `bump_size` 加入 `categorical_feature_columns`。这时 `40`、`60`、`80` 只是类别标签，也可明确写成 `40um`、`60um`、`80um` 或使用 `M`、`L` 等文字标签；模型不会假定类别有等距或单调关系。

例如，模板配置片段可以是：

```json
{
  "feature_columns": ["metal_A_density", "bump_size", "material"],
  "categorical_feature_columns": ["bump_size", "material"]
}
```

实例特征对应填写 `{"metal_A_density": 0.35, "bump_size": "large", "material": "copper"}`，其他实例可填写 `small`、`aluminum` 等标签。Excel 中在 `tsk_analysis` 声明两份列名列表，在 `tsk_instances` 添加相应属性列；运行页仍统一选择需要的特征。

类别使用完整模板中按稳定顺序排列的首个标签作为基准，采用不居中的 L−1 指示变量编码。概率条和误差线表示“数值特征取本组均值、类别特征取各自基准”时的条件概率，不是所有 bump 规格混在一起的平均概率。类别基准不会随 lot 筛选改变；若某批缺少需要的类别信息，诊断会提示，相关参数可能无法单独估计。类别是模型输入，不是额外分层条件，批次模式与 Analyze 共享 Fail 规则保持原样。

## 文本类别与组合预测的独立示例

[categories/template.xlsx](categories/template.xlsx)（也有 [JSON 版本](categories/template.json)）与 [categories/data.csv](categories/data.csv) 是单独新增的假设示例，原来的数值 demo 保持不变。新例含三种 TSK、`bump_size=large/small` 和 `material=aluminum/copper`，共 14 条 Chain、17 个实例。T0/T1 每节点各有 600 个样品，分为两批，每批 300 个；批内样品编号重新开始。

1. 在 Setup 选择类别模板和 `categories/data.csv`。在 Analyze 中确认 Modified Z-score、阈值 3.5，并关闭空值判 Fail；不需要先运行 Analyze。
2. 在 TSK Analysis 选择输入文件、批次字段 `lot_id`。要一起使用每节点 600 个样品，选择所有 lot 混合模式；也可按原批分别拟合。
3. 保持 XY 关闭，在特征选择中选中 `bump_size` 与 `material`，运行 TSK 分析。
4. GUI 分析完成后，风险图默认显示 3 种 TSK × 2 种 bump × 2 种材料的 12 个组合；无有效数据的组合保留位置、概率留空。进入 **组合分析 → 计算条件** 可切换“全部类别组合”与单个比较维度，也可选择是否勾选“无数据组合留空（不外推）”。例如横轴选 `bump_size`、材料固定为 `aluminum`，以 `large` 为基线后点击 **计算组合概率**。
5. 计算完成后自动切到 **热力图**。点击某格进入该 TSK 的 **类别对比**，查看 large/small 条件概率、95% 区间及 small 相对 large 的概率差与区间；支持度和完整提示分别见 **明细**、**全部提示**。返回 **计算条件**，把材料改为 `copper` 计算第二个查询；已完成的不同查询可以保留、随数据库状态保存并导出 XLSX。
6. 注意 `TSK_C + small + copper`：此组合刻意没有放入模板布局，默认不外推时概率与区间均留空。取消勾选“无数据组合留空（不外推）”并重新计算后，模型可辨识时才显示标注为 `extrapolated` 的预测值；它不代表该组合已被直接测试过。
7. 在 **特征与系数** 查看各 bump／材料类别的条件风险和拟合系数。风险按 TSK 分别列出、其他类别固定为基准，XY 不展开为组合。系数表注明 Logistic 或线性风险公式，数值系数对应标准化变量；概率和系数分别导出到 `Feature Risk`、`Feature Coefficients` 工作表。`interval_unavailable` 表示概率存在但区间计算失败，明细中的 `interval_error` 可查看具体原因。

本轮模型共享 bump 与材料主效应，没有加入 TSK×类别或 bump×材料交互。热图中的每一格是同一拟合模型下的一个条件预测；切换组合不会单独训练一个新模型。比较基线只用于计算概率差，不会改动模板编码中的类别基准。

支持度同时给出布局实例数、有效链上的匹配实例数、不同有效 Chain 数及 Chain 测试暴露量。最后一项对每条 Chain 的有效样品数只加一次；它不是独立样品总数，也不是逐实例 Fail 的观测数。无对应布局称为 `extrapolated`，有布局但本组没有有效测试支持称为 `no_active_support`，有匹配实例所在 Chain 的有效测试才称为 `observed`。统计上不可估计另行标记，空值不会补成 0% 概率。

每个查询最多 200 格，较大的类型／类别集合可按单 TSK 分次计算。组合概率区间采用轮廓似然近似；概率差区间考虑同一拟合中两项预测的协方差，不能由两条概率区间相减得到。所有这些区间都是逐点区间，不代表整个热图同时具有 95% 覆盖率。颜色强弱只相对于当前视图，跨查询应比较概率数值与区间。

[expected_chain_counts.csv](categories/expected_chain_counts.csv) 提供注入后的链计数，[simulation_truth.json](categories/simulation_truth.json) 记录生成参数：类型截距 A/B/C 为 −4.6/−3.9/−3.4，small 的 log-odds 增量为 0.65、copper 为 0.35、T1 额外增加 0.35。它们是生成真值，不要求有限样品的拟合结果完全相等。可用 `./.venv/bin/python examples/tsk_risk_demo/generate_category_demo.py` 重新生成。
