"""Synthetic text-category fixture; existing TSK demos are left unchanged."""
from __future__ import annotations

import csv
import argparse
import json
import math
from pathlib import Path
import random
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from excel_data_analysis.models import (
    AnalysisColumn, AnalysisGroup, ColumnHeaderLevel, ReportConfig, RowDimension,
    RowDimensionSource, TemplateConfig, ThresholdConfig, TSKAnalysisConfig, TSKInstance,
)
from excel_data_analysis.template import save_template

SEED = 20260923
SAMPLE_COUNT = 600
INTERCEPTS = {"TSK_A": -4.6, "TSK_B": -3.9, "TSK_C": -3.4}


def build_category_demo(directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    layouts = []
    for tsk in INTERCEPTS:
        for size in ("large", "small"):
            for material in ("aluminum", "copper"):
                if (tsk, size, material) != ("TSK_C", "small", "copper"):
                    layouts.append([(tsk, size, material)])
    layouts.extend([
        [("TSK_A", "large", "aluminum"), ("TSK_B", "small", "copper")],
        [("TSK_A", "small", "aluminum"), ("TSK_C", "large", "copper")],
        [("TSK_B", "large", "aluminum"), ("TSK_C", "small", "aluminum")],
    ])
    chains = [f"Category_{index:02d}" for index in range(1, len(layouts) + 1)]
    instances = [TSKInstance(chain, f"{chain}_{index}", tsk,
                            features={"bump_size": size, "material": material},
                            chain_key=["CategoryDemo", chain])
                 for chain, layout in zip(chains, layouts)
                 for index, (tsk, size, material) in enumerate(layout, 1)]
    template = TemplateConfig(
        name="SYNTHETIC_CATEGORY_DEMO_NOT_REAL_TOPOLOGY", schema_version=3,
        test_data_header_row=0, row_header_row=0, test_data_start_row=1,
        column_header_levels=[ColumnHeaderLevel("Design", 1), ColumnHeaderLevel("Chain Name", 2), ColumnHeaderLevel("Test Type", 3)],
        row_dimensions=[
            RowDimension("lot_id", [RowDimensionSource("Lot")], 1),
            RowDimension("sample_id", [RowDimensionSource("Sample")], 2),
            RowDimension("reliability_node", [RowDimensionSource("Node")], 3),
            RowDimension("repeat_id", [RowDimensionSource("Repeat")], 4),
        ],
        analysis_groups=[AnalysisGroup(id=chain, display_name=chain, analysis_mode="per_column", unit="Ohm",
            columns=[AnalysisColumn(f"R_{chain}", ["CategoryDemo", chain, "Resistance"], 1)]) for chain in chains],
        report=ReportConfig(zscore_thresholds=ThresholdConfig(3.5), node_orders=[["T0", "T1"]],
            sample_dimension_names=["lot_id", "sample_id"], reliability_node_dimension="reliability_node",
            chain_column_level="Chain Name", initial_row_merge_level="repeat_id", initial_column_merge_level="Test Type",
            outlier_fail_method="modified_z_score", outlier_treat_empty_cells_as_fail=False),
        tsk_analysis=TSKAnalysisConfig(enabled=True, instances=instances,
            feature_columns=["bump_size", "material"], categorical_feature_columns=["bump_size", "material"]),
    )
    save_template(template, directory / "template.json")
    save_template(template, directory / "template.xlsx")
    rng = random.Random(SEED)
    counts = {(lot, node, chain): [0, 0] for lot in ("L001", "L002") for node in ("T0", "T1") for chain in chains}
    with (directory / "data.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(["Lot", "Sample", "Node", "Repeat", *(f"R_{chain}" for chain in chains)])
        for sample in range(SAMPLE_COUNT):
            lot = "L001" if sample < SAMPLE_COUNT // 2 else "L002"
            local = sample % (SAMPLE_COUNT // 2) + 1
            for node, shift in (("T0", 0.), ("T1", .35)):
                values = []
                for chain, layout in zip(chains, layouts):
                    failures = []
                    for tsk, size, material in layout:
                        logit = INTERCEPTS[tsk] + .65 * (size == "small") + .35 * (material == "copper") + shift
                        failures.append(rng.random() < 1 / (1 + math.exp(-logit)))
                    failed = any(failures)
                    counts[lot, node, chain][0] += 1
                    counts[lot, node, chain][1] += failed
                    values.append(round((1000 if failed else 100) + rng.uniform(-1, 1), 6))
                writer.writerow([lot, f"S{local:04d}", node, "1", *values])
    with (directory / "expected_chain_counts.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(["Lot", "Node", "CHAIN_ID", "n", "k"])
        for (lot, node, chain), (n, k) in sorted(counts.items()):
            writer.writerow([lot, node, chain, n, k])
    truth = {
        "synthetic": True, "seed": SEED, "samples_per_node": SAMPLE_COUNT,
        "type_intercepts": INTERCEPTS, "bump_small_log_odds_effect": .65,
        "material_copper_log_odds_effect": .35, "node_T1_log_odds_effect": .35,
        "category_reference": {"bump_size": "large", "material": "aluminum"},
        "missing_layout_combination": {"tsk_id": "TSK_C", "bump_size": "small", "material": "copper"},
        "note": "Invented layout and measurements; missing combination illustrates model extrapolation, not measured reliability.",
    }
    (directory / "simulation_truth.json").write_text(json.dumps(truth, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def build_category_database(source: Path, output: Path) -> None:
    """Create a portable database with fitted results and computed category slices."""
    from excel_data_analysis.gui_state import save_gui_state
    from excel_data_analysis.service import import_dataset
    from excel_data_analysis.tsk_service import (
        analyze_tsk_combinations, analyze_tsk_workspace, export_tsk_result, store_tsk_combination_view,
    )

    output = output.resolve()
    if output.exists():
        raise FileExistsError(f"Choose a new demo directory: {output}")
    database = output / "Database"
    imports = database / "imports"
    imports.mkdir(parents=True)
    for name in ("template.xlsx", "template.json", "data.csv", "expected_chain_counts.csv", "simulation_truth.json"):
        shutil.copy2(source / name, imports / name)
    import_dataset(str(imports / "template.xlsx"), str(imports / "data.csv"), str(database))
    settings = {"source": "database", "batch_mode": "none", "batch_dimension": "lot_id",
                "feature_names": ["bump_size", "material"], "include_xy": False}
    result = analyze_tsk_workspace(template_path=str(imports / "template.xlsx"), storage_path=str(database), settings=settings)
    for group_index in range(len(result["groups"])):
        for dimension, fixed in (("material", {"bump_size": "large"}), ("material", {"bump_size": "small"}),
                                 ("bump_size", {"material": "aluminum"}), ("bump_size", {"material": "copper"})):
            view = analyze_tsk_combinations(result, group_index=group_index,
                settings={"dimension": dimension, "fixed_categories": fixed})["view"]
            store_tsk_combination_view(result, group_index, view)
    export_tsk_result(result, str(database / "result/category_combinations.xlsx"))
    save_gui_state(database, {
        "version": 2,
        "paths": {"template_path": "imports/template.xlsx", "input_path": "imports/data.csv",
                  "golden_path": "", "output_path": "result/analysis.xlsx"},
        "path_bases": {"template_path": "database", "input_path": "database", "output_path": "database"},
        "analysis": {"outlier_fail_mode": "modified_z_score", "z_threshold": 3.5, "empty_cells_as_fail": False},
        "tsk_analysis": settings,
        "ui_state": {"workbench_tab_index": 4, "result_tab_index": 3},
        "current_results": {"tsk_result": result},
    })
    (output / "README.md").write_text(
        "# TSK 文本类别组合 Demo\n\n"
        "所有拓扑和数据均为模拟。使用含组合分析功能的当前版本打开 Database 文件夹。\n\n"
        "1. TSK Results → 组合分析 → 计算条件：比较维度选择 bump_size，其余类别 material 可选 aluminum/copper。\n"
        "2. 点击计算组合概率，查看热力图；点击某格查看该 TSK 的类别概率、95% 区间和相对基准的差值。\n"
        "3. TSK_C / small / copper 在模板中没有实例，故标记外推；这不是测得的实际失效率。\n"
        "4. T0/T1 各600个样品；L001/L002各300。同批次设置可沿用不分层、分原批或母批。\n\n"
        "Database/imports 含模板、CSV和模拟真值；Database/result/category_combinations.xlsx 含8个已计算视图。\n"
        "概率区间为轮廓似然近似；差值区间为使用联合信息矩阵的delta近似，均为逐点区间。\n"
        "当前仍为共享类别主效应模型，尚无TSK与类别交互。\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--database", type=Path, help="Create a new portable demo directory containing Database")
    args = parser.parse_args()
    directory = Path(__file__).resolve().parent / "categories"
    build_category_demo(directory)
    if args.database:
        build_category_database(directory, args.database)
