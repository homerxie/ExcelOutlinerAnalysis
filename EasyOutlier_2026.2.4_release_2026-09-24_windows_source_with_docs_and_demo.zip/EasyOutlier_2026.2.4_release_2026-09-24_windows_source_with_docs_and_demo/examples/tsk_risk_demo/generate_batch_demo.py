"""Build a reproducible three-batch variant from the synthetic TSK fixture.

Only lot labels and sample IDs change. Injected failure truth is retained;
sample IDs deliberately restart in each lot to exercise batch-safe counting.
"""
from __future__ import annotations

from collections import defaultdict
import csv
import json
from pathlib import Path


def build_batch_demo(directory: Path) -> None:
    with (directory / "data.csv").open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        headers = reader.fieldnames
        rows = list(reader)
    mapping = {"L001": "M001", "L002": "M001", "L003": "M002"}
    counts = defaultdict(lambda: [0, 0])
    for row in rows:
        original = int(row["Sample"][1:])
        lot, offset = ("L001", 0) if original <= 100 else ("L002", 100) if original <= 250 else ("L003", 250)
        row.update(Lot=lot, Sample=f"S{original - offset:04d}")
        for column in headers[4:]:
            count = counts[lot, row["Node"], column.removeprefix("R_")]
            count[0] += 1
            count[1] += int(float(row[column]) > 500)
    with (directory / "batch_data.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)
    with (directory / "batch_expected_counts.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["source_batch", "parent_batch_id", "node", "chain_id", "n_tested", "n_failed", "n_missing"])
        for (lot, node, chain), (tested, failed) in sorted(counts.items()):
            writer.writerow([lot, mapping[lot], node, chain, tested, failed, 0])
    settings = {"batch_mode": "parent", "batch_dimension": "lot_id", "batch_mapping": mapping,
                "include_xy": False, "feature_names": []}
    (directory / "batch_settings.json").write_text(json.dumps(settings, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    build_batch_demo(Path(__file__).resolve().parent)
