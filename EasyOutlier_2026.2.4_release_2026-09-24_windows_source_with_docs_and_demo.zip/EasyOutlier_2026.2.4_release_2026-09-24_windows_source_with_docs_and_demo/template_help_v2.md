# Template Manual v2

文档核对日期：2026-09-21；对应当前源码与 schema_version=3 模板。文件名中的 v2 是手册名称，不代表模板格式版本。

[toc]

## 1. Workbook 总览

### 1.1 支持格式

当前 template 支持两种文件格式：

- `json`
- `xlsx`

程序内部会先把它们解析成同一套 `TemplateConfig`。

需要了解完整操作流程，可查看 [GUI 教程](GUI_tutorial_v2.md)。本手册解释模板字段、填写方法及兼容规则。

### 1.2 `xlsx` Workbook 包含的 sheet

| Sheet | 是否参与解析 | 主要作用 |
| --- | --- | --- |
| `template_info` | 是 | 全局参数入口。决定数据区位置、golden 默认值、outlier 判定方式等。 |
| `row_dimensions` | 是 | 定义左侧行维度如何从原始输入表提取。 |
| `column_header_levels` | 是 | 定义横向测试表头的层级名字和顺序。 |
| `analysis_groups` | 是 | 定义每个测试列属于哪个逻辑 group，以及 group 级规则。 |
| `node_orders` | 是 | 定义 node 的时序关系。 |
| `analysis_dimension_filters` | 是 | 定义分析开始前就生效的行维度过滤。 |
| `analysis_column_filters` | 是 | 定义分析开始前就生效的测试列过滤。 |
| `outlier_ratio_stats` | 是 | 定义 `Outlier Summary` 里的比例统计块。 |
| `README` | 否 | 仅用于说明，不参与配置解析。 |

### 模板编辑锁与保存

GUI 顶部默认显示“模板设置已锁定”。要修改数值清理、Golden 参数或 Analyze 的唯一 ID、节点/Chain 层级、合并规则和筛选条件，先点“解锁编辑”，阅读提示并选择“我已了解，开启编辑”。两个 Template Convert 按钮也受此锁控制：锁定时全部禁用，解锁后按当前模板格式启用对应转换方向。

点击 Import、Build Golden 或 Analyze 会立即锁回；随后取消操作或校验失败，也保持锁定。锁回保留已修改的值，不自动保存模板。路径浏览和运行按钮不受编辑锁影响，任务运行期间仍会禁用工作区操作。

Analyze 设置与模板不同时，可选择“仅本次运行”“保存到模板并运行”“恢复模板配置并运行”或“取消”。Import 和 Build Golden 使用 Yes / No / Cancel 提示，分别表示回写模板、仅本次使用或取消。GUI 的锁只控制程序中的编辑选项；在 Excel 或文本编辑器里修改模板文件时仍需自行检查。

### 1.3 推荐编辑顺序

1. `template_info`
2. `row_dimensions`
3. `column_header_levels`
4. `analysis_groups`
5. `node_orders`
6. `analysis_dimension_filters`
7. `analysis_column_filters`
8. `outlier_ratio_stats`

原因：

- 后面的很多字段都依赖前面已经定义好的名字
- 例如 `analysis_groups` 依赖 `column_header_levels`
- 例如 `sample_dimension_names`、`initial_row_merge_level` 依赖 `row_dimensions`，`outlier_ratio_stats.group_by_dimension` 依赖 `row_dimensions` 或 `column_header_levels`

## 2. 通用填写规则

### 2.1 行号和列号都是零基准

下面这些字段都使用零基准：

- `test_data_header_row`
- `row_header_row`
- `unit_row`
- `test_data_start_row`
- `test_data_start_column`

含义：

- `0` 表示第一行或第一列
- `1` 表示第二行或第二列

例如：

- `test_data_header_row = 0`
  - 表示测试区列名在 Excel 的第一行
- `test_data_start_row = 5`
  - 表示真正的数据从 Excel 的第六行开始

### 2.2 一个单元格内的多值写法

如果一个单元格需要表达多个值，统一使用 `;` 分隔。

常见场景：

- `sample_dimension_names = lot_id;sample_id`
- `golden_reference_dimensions = lot_id;sample_id`
- `group_by_dimension = reliability_node;lot_id`
- `numeric_cleanup_characters = ,;%;mV;ohm`

### 样品唯一 ID 与节点角色（template_info）

| field | 示例 value | 含义 |
| --- | --- | --- |
| `reliability_node_dimension` | `stage` | 指定哪个 `row_dimensions.name` 表示可靠性节点；旧模板未填写时默认 `reliability_node`。 |
| `sample_dimension_names` | `lot_id;sample_id` | 唯一 ID 的字段及顺序。内部按 `(lot_id, sample_id)` 元组匹配，不按字符串拼接匹配。 |
| `chain_column_level` | `Chain Name` | 指定哪个 `column_header_levels.name` 表示 Chain；Final column 保留到此层及其上方层级。 |

例如 `row_dimensions.priority` 定义的层级为 `lot_id → sample_id → stage → site_id → repeat_id`，应填写上述配置。`(LotA, S1)` 与 `(LotB, S1)` 是不同样品；同一个 ID 在不同 stage 的数据关联历史，同一节点下的 site/repeat 按 merge 规则聚合。

ID 字段必须明确包含节点上方全部分组维度，不能包含节点或其下方维度。配置不一致、未知节点字段或数据中的 ID/节点值为空时阻止报表分析，不再自动补齐字段或覆盖重复索引。需要改变分组语义时，同时调整 `row_dimensions.priority` 和 ID 配置。仅修改显示名称请用 `display_name`。

GUI 的 Analyze And Export 顶部提供 Unique Sample ID Fields、Reliability Node Row Level 和 Chain Column Level。编辑前需要通过顶部开关解锁，无需另设身份确认或保存步骤。运行时如果与模板不一致，可统一选择仅本次运行、保存到模板并运行、恢复模板配置并运行或取消。自定义节点名称后，Golden filters/reference dimensions、ratio 分组中的字段名也应使用模板中的实际名称。分析界面的 Nodes 筛选自动对应所选节点维度。

Excel 中的 `reliability_node_dimension` 为普通文本输入，不使用固定下拉列表。可以先填 `template_info`，再定义 `row_dimensions`，也可以反过来。GUI 则从已加载模板的行维度中提供候选项。模板未写完时可继续编辑；启动分析前必须补齐对应定义并通过身份校验。

### 2.3 布尔值写法

Excel / JSON 中布尔字段支持这些写法：

- 真值：
  - `1`
  - `true`
  - `yes`
  - `y`
- 假值：
  - `0`
  - `false`
  - `no`
  - `n`

如果布尔内容不是这些，会报错。

### 2.4 自由输入字段建议

这类字段不是从几个固定选项里选，而是由使用者自由命名或自由填写。

| xlsx 写法 | JSON 写法 | 建议示例 | 说明 |
| --- | --- | --- | --- |
| `Field = name` | `name` | `chip_reliability_template` | 模板名建议稳定、简洁、易区分版本。 |
| `row_dimensions.Name` | `row_dimensions[*].name` | `sample_id`、`reliability_node`、`repeat_id` | 建议使用稳定的 snake_case。 |
| `row_dimensions.Display Name` | `row_dimensions[*].display_name` | `Sample ID`、`Reliability Node` | 报表展示名称，可以更偏业务语言。 |
| `row_dimensions.Source Column` | `row_dimensions[*].sources[*].column` | `recordName`、`Lot`、`Site` | 按[字段名称自动匹配规则](#field-name-matching)匹配输入表中的真实列名，建议沿用原始表头。 |
| `column_header_levels.Name` | `column_header_levels[*].name` | `Chain Name`、`Test Type`、`Repeat Index` | 横向表头层级名。 |
| `analysis_groups.ID` | `analysis_groups[*].id` | `link1_resistance` | 建议使用稳定、短、可读的业务名。 |
| `analysis_groups.Display Name` | `analysis_groups[*].display_name` | `Link1 Resistance` | 最终会直接影响报表显示。 |
| `analysis_groups.Unit` | `analysis_groups[*].unit` | `Ohm`、`uA`、`V`、`f` | 单位字段自由填写。 |
| `analysis_groups.Column Name` | `analysis_groups[*].columns[*].name` | `R_Link1_1V_1` | 按[字段名称自动匹配规则](#field-name-matching)匹配原始测试列，建议沿用原始表头。 |
| `node_orders.Sequence Name` | 不写入 JSON | `Sequence 1`、`T0 to T2 Path` | 仅用于 Excel 阅读；重新导出时自动命名为 Sequence 1、Sequence 2 等。 |
| `outlier_ratio_stats.ID` | `report.outlier_ratio_stats[*].id` | `new_ratio_by_node_all` | 统计项内部标识。 |
| `outlier_ratio_stats.Display Name` | `report.outlier_ratio_stats[*].display_name` | `New Outlier Ratio By Node` | 报表中展示的统计项标题。 |

<a id="field-name-matching"></a>

### 2.5 字段名称自动匹配

引用字段时，程序会忽略**大小写、空格、下划线 `_` 和连字符 `-`**，自动匹配已有名称。row 维度和 column 层级采用同一套规则，中文名称也可以使用。

| 已声明的 Name | 可使用的引用写法 |
| --- | --- |
| `Chain Name` | `chain_name`、`CHAIN-NAME`、`ChainName` |
| `lot_id` | `Lot ID`、`LOT-ID`、`LotID` |
| `reliability_node` | `Reliability Node`、`RELIABILITY-NODE`、`ReliabilityNode` |
| `Test Type` | `test_type`、`TEST-TYPE`、`TestType` |

以下位置都使用这套字段名称规则：

| 填写位置 | 示例 |
| --- | --- |
| 样品 ID 组成、可靠性节点、Chain 层级、Initial 保留层级及旧版合并目标 | `sample_dimension_names` 可填 `Lot ID;Sample ID`；`chain_column_level` 可填 `chain_name`。 |
| 统计 `Group By Dimension` | 可联合填写 row 与 column：`lot_id;chain_name;reliability_node`。 |
| 统计 `Filter Type`、分析筛选的字段名、对比窗口筛选字段与分组 | `Chain Name` 与 `chain_name` 的写法都可用于相应链路字段。 |
| Golden 的参考维度与筛选字段名 | `golden_reference_dimensions` 可填 `Lot ID;Sample ID`；filters 中的 `Reliability Node` 可匹配 `reliability_node`。 |
| 原始数据列引用 | `Source Column`、`Split Position By Column`、测试 `Column Name` 都按本规则匹配输入表头。 |
| 模板设置键和 Excel 配置表头 | JSON 设置键、`template_info.Field`、各配置页表头及 `analysis_groups` 的层级列均支持，例如 `GroupByDimension` 可匹配 `Group By Dimension`。 |

匹配时遵循以下规则：

1. **精确 Name 优先。** 若直接填写已声明的 Name，就采用该字段。模板中声明的 Name 不会因为自动匹配而改名；保存 row/column 维度引用时会使用声明的 Name。
2. **非精确写法必须唯一匹配。** 若同时存在 `Site ID` 和 `site_id`，填写 `SITE-ID` 会提示歧义并列出候选项，此时应使用其中一个精确 Name。
3. **row 维度也支持唯一的 Display Name。** 例如 `lot_id` 的 Display Name 为 `批次` 时，可以用 `批次` 引用。多个维度的显示名称相同时，应使用精确 Name。
4. **只匹配字段名称，字段值仍按原有规则处理。** `Filter Type = Chain Name` 等价于 `chain_name`，但 `Filter Value = Link4` 不会随之改写；样品 ID 值、节点值、group ID 值和数值阈值也不会转换。`column_name` 作为筛选字段时，其 Filter Value 仍是测试列的值，不能套用字段名规则改写。
5. **原有字段范围和层级限制仍然有效。** 名称必须对应已支持或已定义的字段；不会补造维度或猜测拼写错误。节点实际命名为 `stage` 时，Group By 应写 `stage` 或它的可匹配写法，`reliability_node` 不会自动替代任意节点名称。

建议声明字段时保持统一命名习惯，引用时可使用上述写法。每个输入框原有的多值分隔方式仍需遵守；Excel 模板中多个维度用 `;` 分隔。统计的具体填表示例见[第 10.5 节](#105-典型示例)。

<a id="template-info-sheet"></a>
## 3. `template_info` Sheet

### 3.1 作用

`template_info` 是整个模板的控制面板。

它负责定义：

- 输入表中数据区和表头区的位置
- 样品主键如何构成
- outlier 判定使用哪种策略
- 行合并、列合并后保留到哪一层
- golden 默认规则怎么设
- 数字清洗是否启用

通常这是最先填写、也最需要先确认的一页。

### 3.2 表头结构

| 列名 | 作用 |
| --- | --- |
| `Field` | 参数名 |
| `Value` | 参数值 |
| `Notes` | 备注列，仅用于阅读 |

### 3.3 基础定位字段

本节关键词直接使用 `template_info` 里 `Field` 列实际填写的值；对应 JSON 写法如下：

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `name` | `name` |
| `test_data_header_row` | `test_data_header_row` |
| `row_header_row` | `row_header_row` |
| `test_data_start_column` | `test_data_start_column` |
| `unit_row` | `unit_row` |
| `test_data_start_row` | `test_data_start_row` |

- `name`
  - 作用：
    - 给整套 template 起一个唯一、稳定的标识名。
  - 可选值：
    - 任意字符串。
  - 详细说明：
    - 这个字段主要用于标识模板本身，不直接影响分析计算逻辑。
    - 但在多人协作、模板归档、调试记录时，建议保持命名稳定。
  - 示例：
    - `chip_reliability_template`

- `test_data_header_row`
  - 作用：
    - 指定测试区列名所在的行。
  - 可选值：
    - 非负整数。
  - 详细说明：
    - 这一行通常包含横向测试列名，例如 `R_Link1_1V_1`、`V_Link1_1p8V` 这类原始测试列头。
    - 程序会用它来定位测试数据区域的列名。
  - 示例：
    - `0`

- `row_header_row`
  - 作用：
    - 指定样品属性列名所在的行。
  - 可选值：
    - 非负整数。
  - 详细说明：
    - 这一行通常包含左侧属性列名，例如 `recordName`、`Lot`、`Site` 等。
    - 程序会用这行去识别 `row_dimensions` 中引用的源列。
  - 示例：
    - `4`

- `test_data_start_column`
  - 作用：
    - 指定测试数据区域从哪一列开始。
  - 可选值：
    - 非负整数或留空。
  - 详细说明：
    - 如果填写了它，程序从这列开始会优先使用 `test_data_header_row` 的表头作为测试列名。
    - 这样可以避免测试区右半部分继续被 `row_header_row` 覆盖。
    - 如果留空，则程序不会强行用这一列切断区域。
  - 示例：
    - `8`

- `unit_row`
  - 作用：
    - 指定单位行的位置。
  - 可选值：
    - 非负整数或留空。
  - 详细说明：
    - 有些输入表会专门在某一行写单位，如 `V`、`Ohm`、`uA`。
    - 如果你的原始表没有单位行，可以留空。
  - 示例：
    - `3`

- `test_data_start_row`
  - 作用：
    - 指定真正的测试数据从哪一行开始。
  - 可选值：
    - 非负整数。
  - 详细说明：
    - 这是必填字段。
    - 程序不会自动推断数据起始行，如果不写，模板校验会直接报错。
  - 示例：
    - `5`

### 3.4 样品身份与最终合并目标

| xlsx 中 `Field` | JSON 写法 | 含义 |
| --- | --- | --- |
| `sample_dimension_names` | `report.sample_dimension_names` | 构成样品唯一 ID 的字段，用英文分号分隔。必须包含节点上方全部行维度。 |
| `reliability_node_dimension` | `report.reliability_node_dimension` | 哪个行维度是可靠性节点。Final row 固定保留到此层。 |
| `chain_column_level` | `report.chain_column_level` | 哪个列层级代表 Chain。Final column 固定保留到此层。 |

填写内部 Name，不是 Display Name。节点和 Chain 名称可以先填写，再补充维度表；分析前必须与已定义的名称一致。更高层级也会保留，避免不同批次或不同上级分组相互混淆。

新模板不再输出 `template_info.node_order`。节点顺序统一在 `node_orders` 页填写，JSON 使用 `report.node_orders`，即使只有一条序列也使用二维数组。

`schema_version = 3` 是程序维护的格式版本，不是异常算法版本。旧模板仍可读取：GUI 首次选择或使用旧模板时提示升级，备份原文件后刷新格式。已经使用新版 Merge 字段的模板保持其设置不变。更早的“合并起点”转换为它上方一层，即新的“保留层级”。旧列起点若会合掉选定的 Chain，程序报错；点击确定后将旧起点修正为 Chain 的下一层，对应新版“保留 Chain”，取消则不修改文件。

除 `template_info` 和 `README` 外，配置页第 1 行是逐列中文填写说明，第 2 行是原英文表头，第 3 行起填写数据。前两行冻结，滚动时仍可查看。不要改英文表头。程序兼容旧版第 1 行表头；说明行不会参与解析或分析。这不改变原始数据文件的行号设置。

### 3.5 `outlier_fail_method`

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `outlier_fail_method` | `report.outlier_fail_method` |

- `outlier_fail_method`
  - 作用：
    - 定义最终 fail 是根据 zscore、golden，还是两者组合来判定。
  - 可选值：
    - `modified_z_score`
    - `golden_deviation`
    - `zscore_and_golden`
    - `zscore_or_golden`
  - 详细说明：
    - 这是最核心的判 fail 策略之一。
    - 它会影响 `outliers`、`summary` 等结果页中“这条记录是否算 fail”。

各可选项含义：

- `modified_z_score`
  - 含义：
    - 只看 zscore 是否超阈值。
  - 适用理解：
    - 更偏统计异常检测，不依赖 built golden。

- `golden_deviation`
  - 含义：
    - 只看是否偏离 golden 允许范围。
  - 适用理解：
    - 更偏工艺/规范基准判断。

- `zscore_and_golden`
  - 含义：
    - zscore 超 threshold 且 golden 偏差也超范围，才判 fail。
  - 适用理解：
    - 判定更严格，倾向于降低误报。

- `zscore_or_golden`
  - 含义：
    - zscore 或 golden 任意一个超界，就判 fail。
  - 适用理解：
    - 判定更敏感，倾向于不漏掉风险。

### 3.6 四类 fail rule

| xlsx 中 `Field` | 阶段 | 判定对象 |
| --- | --- | --- |
| `initial_column_merge_fail_rule` | Initial column merge | 初次列合并时的子项 |
| `final_column_merge_fail_rule` | Final column merge | 继续汇总到 Chain 时的子组 |
| `initial_row_merge_fail_rule` | Initial row merge | 初次行合并时的子项 |
| `final_row_merge_fail_rule` | Final row merge | 继续汇总到可靠性节点时的子组 |

JSON 中以上字段均位于 `report`。`any_fail` 表示任一子项失败就失败，`all_fail` 表示所有子项失败才失败。

同方向 Initial 与 Final 的保留层级相等时，只执行一次有效合并。GUI 会把 Final 判据置灰并强制跟随 Initial。恢复为不同层级后，Final 判据重新可编辑。

如果模板文件中同方向 Initial 与 Final 已经同层，但 any_fail / all_fail 不一致，Validate Template 会报错。打开或使用模板时，GUI 会列出冲突，要求明确选择统一判据并“保存到当前模板并继续”；未选择时不能保存，取消则保留原文件和原配置。

### 3.7 行合并和列合并边界

| xlsx 中 `Field` | JSON 写法 | 含义 |
| --- | --- | --- |
| `initial_row_merge_level` | `report.initial_row_merge_level` | 初次行合并后保留到哪一层 |
| `initial_column_merge_level` | `report.initial_column_merge_level` | 初次列合并后保留到哪一层 |

层级按 Priority 从小到大排列。所填层级本身与更高层级保留，只合并它下方的层级。

新配置默认：Initial row 保留到选定的可靠性节点，Initial column 保留到选定 Chain 的下一层。如果 Chain 已是最底层，Initial column 默认与 Final column 同层。已有明确设置不重置；旧模板按旧行为等价转换。

例如行层级是 `Lot → Sample → Node → Site → Repeat`：填 `Site`，先合并 Repeat 得到各 Site 结果，再用 Final row 判据汇总到 Node。填 `Node` 则一次合并 Site 和 Repeat，Final 不再进一步合并。不能填在 Node 上方的 Sample 或 Lot。

例如列层级是 `Chain → Test Type → Repeat`：填 `Test Type`，先合并 Repeat，再汇总到 Chain。填 `Chain` 则一次合并 Test Type 和 Repeat，不合并不同 Chain。若 Chain 上方还有其他列层级，这些分组也会保留。

Final 行目标由 `reliability_node_dimension` 决定，Final 列目标由 `chain_column_level` 决定。模板不提供可独立编辑的 `final_row_merge_level` 或 `final_column_merge_level`，GUI 中这两个目标只读。

旧字段兼容读取，保存或升级时改为以下新名称：

| 旧字段 | 新字段 | 转换方式 |
| --- | --- | --- |
| `outlier_merged_test_fail_rule` | `initial_column_merge_fail_rule` | 保留 any_fail / all_fail |
| `outlier_test_group_fail_rule` | `final_column_merge_fail_rule` | 保留 any_fail / all_fail |
| `outlier_merged_sample_fail_rule` | `initial_row_merge_fail_rule` | 保留 any_fail / all_fail |
| `outlier_node_fail_rule` | `final_row_merge_fail_rule` | 保留 any_fail / all_fail |
| `outlier_test_merge_max_level` | `initial_column_merge_level` | 旧“被合掉的起点”转为其紧邻上一级；会合掉 Chain 的配置须按升级提示修正 |
| `outlier_row_merge_max_dimension` | `initial_row_merge_level` | 旧“被合掉的起点”转为其紧邻上一级 |

例如旧列起点为 Repeat Index，则新版保留层级为它上方的 Test Type，不应直接把旧值复制到新字段。转换后若同方向 Initial 与 Final 同层而判据不同，须按上文冲突提示明确选择并保存统一判据，不能直接自动升级。

### 3.7.1 空值 / 非数字测试 cell 的 fail 设置

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `outlier_treat_empty_cells_as_fail` | `report.outlier_treat_empty_cells_as_fail` |

- 默认值：
  - `true`
- 作用：
  - 当某个模板中期望存在的测试 cell 是空白，或经过 `numeric_cleanup` 后仍然不能解析成数字时，是否把这个 raw cell 直接视为 outlier fail。
- 重要说明：
  - 空值 / 非数字值永远不参与 built golden 计算。
  - 这个设置只影响 outlier analysis/report 阶段的 raw cell pass/fail 和后续 merge 传播。
  - 老模板没有这个字段时，程序会按默认 `true` 运行；GUI 运行分析时会提示是否把该设置写回 template。
- 可选值：
  - `true`: 空值 / 非数字测试 cell 直接算 raw fail。
  - `false`: 空值 / 非数字测试 cell 被忽略，不参与 raw fail，也不参与 merge。

### 3.8 `outlier_merge_order`

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `outlier_merge_order` | `report.outlier_merge_order` |

- `outlier_merge_order`
  - 作用：
    - 决定四个 merge 模块执行的先后顺序。
  - 可选值：
    1. `Initial column merge -> Final column merge -> Initial row merge -> Final row merge`
    2. `Initial row merge -> Final row merge -> Initial column merge -> Final column merge`
    3. `Initial column merge -> Initial row merge -> Final column merge -> Final row merge`
    4. `Initial row merge -> Initial column merge -> Final row merge -> Final column merge`
    5. `Initial column merge -> Initial row merge -> Final row merge -> Final column merge`
    6. `Initial row merge -> Initial column merge -> Final column merge -> Final row merge`
  - 详细说明：
    - 这 6 种顺序是固定枚举，不能随意拼写其他字符串。
    - 它决定 column 方向和 row 方向上的聚合是先做还是后做。
    - 这个字段主要影响复杂模板下最终 fail 的传播路径和聚合结果。
    - 同一方向的 Initial 必须在 Final 之前。GUI 按所选顺序排列四列表头，下面两行分别是“保留层级”和“失败判据”；重排位置不会交换各步骤自己的值。

### 3.9 golden 默认字段

这一组字段都写在 `template_info` 的 `Field / Value` 里，但 JSON 会落到 `golden_reference_defaults` 对象下。

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `golden_reference_dimensions` | `golden_reference_defaults.reference_dimensions` |
| `golden_reference_filters` | `golden_reference_defaults.filters` |
| `golden_reference_center_method` | `golden_reference_defaults.center_method` |
| `golden_reference_outlier_golden_method` | `golden_reference_defaults.outlier_golden_method` |
| `golden_reference_relative_limit` | `golden_reference_defaults.relative_limit` |
| `golden_reference_sigma_multiplier` | `golden_reference_defaults.sigma_multiplier` |
| `golden_reference_absolute_lower_bound` | `golden_reference_defaults.absolute_lower_bound` |
| `golden_reference_absolute_upper_bound` | `golden_reference_defaults.absolute_upper_bound` |
| `golden_reference_overwrite_lowerbound` | `golden_reference_defaults.overwrite_lowerbound` |
| `golden_reference_overwrite_upperbound` | `golden_reference_defaults.overwrite_upperbound` |
| `golden_reference_continuous_interval` | `golden_reference_defaults.continuous_interval` |
| `golden_empty_range_fallback_to_absolute` | `golden_reference_defaults.empty_range_fallback_to_absolute` |

#### 3.9.1 `golden_reference_dimensions`

- 作用：
  - 定义 Build Golden 时，reference key 由哪些 row 维度组成。
- 可选值：
  - 一个或多个已定义的 `row_dimensions.name`，使用 `;` 分隔。
- 详细说明：
  - 这个字段决定 golden reference 是按什么粒度建立的。
  - 写得越细，golden reference 的分组越细。
  - 写得越粗，更多数据会被归到同一个 reference key 里。
- 示例：
  - `sample_id`
  - `lot_id;sample_id`

**与 Analyze 唯一 ID 的区别：** `sample_dimension_names` 用于区分样品和关联历史；`golden_reference_dimensions` 用于决定哪些数据共用一套 Golden，二者不会自动同步。即使唯一 ID 填了 `lot_id;sample_id`，Golden 只填 `sample_id` 时，不同 Lot 的同名样品仍可能一起计算基准。需要区分 Lot 时，应另外填写 `lot_id;sample_id` 并重新 Build Golden。

| 设置 | 决定什么 | 不会自动改变什么 |
| --- | --- | --- |
| Unique Sample ID Fields / `sample_dimension_names` | 样品身份、样品筛选、历史关联 | Golden 的 Reference Dims |
| Reliability Node Row Level / `reliability_node_dimension` | 节点筛选目标、Final row 保留层级 | Golden 的 Filters 和基准分组 |
| Chain Column Level / `chain_column_level` | Chain 分组、Final column 保留层级 | Golden 的逻辑测项和允许范围 |

Golden 根据自己的 reference key、逻辑测项和分析组计算，Analyze 匹配时使用 Golden 文件内的 reference_dimensions 和逻辑测项。只改上述三个 Analyze 设置不会重算已有 Golden，但会影响筛选、历史关联或最终合并结果。

**跨节点共用基准时通常不要把节点加入 Reference Dims。** 例如用 T0 为后续 T1、T2 建立基准，应将 `golden_reference_filters` 设为 `reliability_node=T0`，Reference Dims 填 `lot_id;sample_id`。若把节点也放入 reference key，仅用 T0 建出的 Golden 将不能按同一个 key 匹配 T1、T2。节点字段为 `stage` 时，Golden Filters 应写实际字段名 `stage=T0`。

Excel 的 `golden_reference_dimensions` 多字段使用分号；GUI 的 Reference Dims 输入框与 CLI 的 `--reference-dims` 使用逗号，例如 `lot_id,sample_id`。

#### 3.9.2 `golden_reference_filters`

- 作用：
  - 定义 Build Golden 时默认要保留哪些 reference 数据。
- 可选值：
  - `key=value` 形式的过滤条件，多个条件之间使用 `;` 分隔。
  - `key` 必须是 `row_dimensions` 中的实际 `Name`，`value` 填数据中该维度的值
- 详细说明：
  - 这个字段在解析时会被当成一个字典读取。
  - 每一项都必须写成 `key=value`。
  - 不同 key 之间是同时生效的关系。
  - 如果同一个 key 需要匹配多个值，可以在 value 里用 `,`。

标准格式：

```text
reliability_node=T0;site_id=A;temp=25C
```

多值示例：

```text
reliability_node=T0,T1,T2;site_id=A
```

上面的含义是：

- `reliability_node` 只要是 `T0`、`T1`、`T2` 之一就算命中
- 同时 `site_id` 还必须等于 `A`

注意：

- 分隔符必须是 `;`
- 同一个 key 如果需要拆开写，也可以重复出现，程序会自动合并

重复 key 示例：

```text
reliability_node=T0;reliability_node=T1;site_id=A
```

上面的含义与下面这条写法等价：

```text
reliability_node=T0,T1;site_id=A
```

#### 3.9.3 `golden_reference_center_method`

- 作用：
  - 定义 golden center 是用均值还是中位数。
- 可选值：
  - `mean`
  - `median`

各可选项含义：

- `mean`
  - 使用平均值作为 golden center。
  - 适合数据分布比较稳定、极端值影响不大的场景。

- `median`
  - 使用中位数作为 golden center。
  - 适合更稳健地抵抗离群值影响。

#### 3.9.4 `golden_reference_outlier_golden_method`

- 作用：
  - 定义默认的 golden 允许区间规则。
- 可选值：
  - 合法 golden rule 表达式。
- 详细说明：
  - 这是 built golden 的核心规则。
  - 它决定允许区间是按相对偏差、sigma、绝对边界，还是这些规则的组合来构建。

#### 3.9.5 golden rule 表达式可用元素

| 类别 | 可选值 | 作用 |
| --- | --- | --- |
| 基础项 | `relative` | 按相对偏差建范围 |
| 基础项 | `sigma` | 按 sigma 倍数建范围 |
| 基础项 | `absolute` | 按绝对上下界建范围 |
| 逻辑运算 | `and` | 多个条件同时成立 |
| 逻辑运算 | `or` | 满足任一条件即可 |
| 结构 | `(` `)` | 控制表达式优先级 |
| 后缀修饰 | `+ overwrite_lowerbound` | 最终强行覆盖下界 |
| 后缀修饰 | `+ overwrite_upperbound` | 最终强行覆盖上界 |

合法示例：

- `relative`
- `sigma`
- `absolute`
- `relative and sigma`
- `relative or absolute`
- `relative or (sigma and absolute)`
- `absolute or relative + overwrite_upperbound`
- `sigma + overwrite_lowerbound + overwrite_upperbound`

#### 3.9.6 配套参数

- `golden_reference_relative_limit`
  - 作用：
    - 为 `relative` 规则提供相对偏差阈值。
  - 何时必填：
    - 当规则使用 `relative` 时。
  - 示例：
    - `0.2`

- `golden_reference_sigma_multiplier`
  - 作用：
    - 为 `sigma` 规则提供 sigma 倍数。
  - 何时必填：
    - 当规则使用 `sigma` 时。
  - 示例：
    - `3.0`

- `golden_reference_absolute_lower_bound`
  - 作用：
    - 为 `absolute` 规则提供下界。
  - 何时必填：
    - 当规则使用 `absolute` 时。
  - 示例：
    - `80`

- `golden_reference_absolute_upper_bound`
  - 作用：
    - 为 `absolute` 规则提供上界。
  - 何时必填：
    - 当规则使用 `absolute` 时。
  - 示例：
    - `120`

- `golden_reference_overwrite_lowerbound`
  - 作用：
    - 在最终允许区间生成后，强制改写最低下界。
  - 何时必填：
    - 当规则使用 `+ overwrite_lowerbound` 时。
  - 示例：
    - `85`

- `golden_reference_overwrite_upperbound`
  - 作用：
    - 在最终允许区间生成后，强制改写最高上界。
  - 何时必填：
    - 当规则使用 `+ overwrite_upperbound` 时。
  - 示例：
    - `115`

- `golden_reference_continuous_interval`
  - 作用：
    - 如果最终规则会得到多个分段区间，是否把它们强制并成一个连续区间。
  - 可选值：
    - `true`
    - `false`
  - 详细说明：
    - `false` 时保留分段区间。
    - `true` 时会取所有结果区间中的最小下界和最大上界，形成一个连续区间。
    - 这个字段和其他 golden 规则一起生效，analysis group 里的同名字段会覆盖全局默认。

- `golden_empty_range_fallback_to_absolute`
  - 作用：
    - 当 golden rule 通过 `and` 或覆盖边界计算后得到空 allowed range 时，是否自动 fallback 到 absolute 上下界。
  - 可选值：
    - `true`
    - `false`
  - 详细说明：
    - `false` 时，Build Golden 会直接报错，提示用户去 template 设置合理规则。
    - `true` 时，必须同时设置 `golden_reference_absolute_lower_bound` 和 `golden_reference_absolute_upper_bound`。
    - 如果触发 fallback，程序会在 GUI 弹出 warning，并在结果 Excel 的 `Outlier Summary` 第一页写入中文提示：哪些 metric 按 AND/交集标准没有交集，已经 fallback 到 absolute，且提醒检查是否所有样品均失效。
    - analysis group 里的 `Golden Empty Range Fallback To Absolute` 可以覆盖全局默认。

### 3.10 `numeric_cleanup`

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `numeric_cleanup_enabled` | `numeric_cleanup.enabled` |
| `numeric_cleanup_mode` | `numeric_cleanup.mode` |
| `numeric_cleanup_characters` | `numeric_cleanup.characters` |

- `numeric_cleanup_enabled`
  - 作用：
    - 控制在把单元格文本转成数字前，是否先做字符清洗。
  - 可选值：
    - 布尔值。

- `numeric_cleanup_mode`
  - 作用：
    - 定义清洗使用哪种模式。
  - 可选值：
    - `all_non_numeric`
    - `specified_chars`

各可选项含义：

- `all_non_numeric`
  - 含义：
    - 把所有非数字字符都清掉，再尝试解析数字。
  - 适用场景：
    - 原始数据中混有单位、百分号、文本后缀。

- `specified_chars`
  - 含义：
    - 只清掉你在 `numeric_cleanup_characters` 里明确列出的字符。
  - 适用场景：
    - 你不希望“全部非数字字符”都被删掉，只想精确去除几个已知字符。

- `numeric_cleanup_characters`
  - 作用：
    - 定义 `specified_chars` 模式下要删掉哪些字符。
  - 可选值：
    - 使用 `;` 分隔的字符列表。
  - 示例：
    - `,;%;mV;ohm`

<a id="row-dimensions-sheet"></a>
## 4. `row_dimensions` Sheet

### 4.1 作用

`row_dimensions` 用来定义每一行样品数据的业务维度怎么提取。

常见维度包括：

- `sample_id`
- `reliability_node`
- `repeat_id`
- `site_id`
- `temp`

### 4.2 一行代表什么

在 Excel 模板里：

- 一行表示一个 `source`
- 如果同一个维度有多个 `source`，就会出现多行
- 如果同一个 source 需要写多条“匹配值 -> split 位置”的映射，也可能占多行

所以 Excel 里的 `row_dimensions` 是“长表模式”。

### 4.3 字段说明

下面优先使用 `row_dimensions` sheet 的 Excel 列名来说明；右侧给出对应 JSON 写法。

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `Name` | `row_dimensions[*].name` |
| `Display Name` | `row_dimensions[*].display_name` |
| `Priority` | `row_dimensions[*].priority` |
| `Optional` | `row_dimensions[*].optional` |
| `Default Value` | `row_dimensions[*].default_value` |
| `Source Order` | `row_dimensions[*].sources[*]` 的数组顺序，Excel 专用列 |
| `Source Column` | `row_dimensions[*].sources[*].column` |
| `Default Split Position` | `row_dimensions[*].sources[*].default_split_position` |
| `Split Position By Column` | `row_dimensions[*].sources[*].split_position_by_column` |
| `Match Value` | `row_dimensions[*].sources[*].split_position_map` 的 key |
| `Mapped Split Position` | `row_dimensions[*].sources[*].split_position_map` 的 value |
| `Skip Empty Parts` | `row_dimensions[*].sources[*].skip_empty_parts` |
| `Delimiter 1..N` | `row_dimensions[*].sources[*].split_delimiters[*]` |

- `Name`
  - 作用：
    - 定义维度的内部名称。
  - 可选值：
    - 唯一字符串。
  - 详细说明：
    - 后续会作为 `dimensions[name]` 的 key 使用。
    - 不能重复。
  - 示例：
    - `sample_id`
    - `reliability_node`

- `Display Name`
  - 作用：
    - 定义报表里显示的维度标题。
  - 可选值：
    - 任意字符串，或留空。
  - 详细说明：
    - 如果省略，界面或报表通常会退回使用 `Name`。
  - 示例：
    - `Sample ID`
    - `Reliability Node`

- `Priority`
  - 作用：
    - 定义 row 维度的优先级顺序。
  - 可选值：
    - 正整数。
  - 详细说明：
    - 数字越小，优先级越高，越靠前。
    - `initial_row_merge_level` 等规则依赖这个顺序。
  - 示例：
    - `1`
    - `2`
    - `3`

- `Optional`
  - 作用：
    - 定义该维度取不到值时，整行是否仍然允许继续保留。
  - 可选值：
    - 布尔值。

各可选项含义：

- `true`
  - 允许缺失。
  - 如果最终提取不到值，这个维度可以为空，不一定导致整行报废。

- `false`
  - 不允许缺失。
  - 如果最终提取不到值，整行会被视为无效并跳过。

- `Default Value`
  - 作用：
    - 当该维度所有 source 都提取不到值时，提供一个回填值。
  - 可选值：
    - 任意字符串，或留空。
  - 详细说明：
    - 常见用法是给 `repeat_id` 这类维度补默认值。
  - 示例：
    - `1`

- `Source Order`
  - 作用：
    - 定义同一个维度下多个 source 的提取顺序。
  - 可选值：
    - 正整数。
  - 详细说明：
    - JSON 中 `sources` 本身是数组，天然有顺序。
    - Excel 中因为一个维度会拆成多行，所以需要单独写 `Source Order`。

- `Source Column`
  - 作用：
    - 指定从输入表的哪一列取原始文本。
  - 可选值：
    - 输入表中真实存在的列名。
  - 示例：
    - `recordName`
    - `Lot`
    - `Site`

- `Default Split Position`
  - 作用：
    - 指定 split 之后默认取第几个片段。
  - 可选值：
    - 非负整数或留空。
  - 详细说明：
    - 如果填写了它，必须同时定义至少一个 delimiter。
    - 旧字段名 `split_position` 在兼容读取时仍然能工作，但新模板建议统一写 `Default Split Position`。
  - 示例：
    - `0`
    - `1`
    - `2`

- `Split Position By Column`
  - 作用：
    - 指定要参考哪一列，动态决定当前 source 使用哪个 split position。
  - 可选值：
    - 输入表列名或留空。
  - 示例：
    - `Site`

- `Match Value`
  - 作用：
    - 表示另一列的某个匹配值。
  - 可选值：
    - 任意字符串或留空。
  - 示例：
    - `1`
    - `2`
    - `A`

- `Mapped Split Position`
  - 作用：
    - 当命中 `Match Value` 时，改用哪个 split position。
  - 可选值：
    - 非负整数或留空。
  - 示例：
    - `0`
    - `1`
    - `2`

- `Skip Empty Parts`
  - 作用：
    - 控制 split 后是否忽略空片段。
  - 可选值：
    - 布尔值。

各可选项含义：

- `true`
  - 连续分隔符导致的空字符串会被丢掉。
  - 例如 `A__B` 可能被当成 `A`、`B`。

- `false`
  - 空字符串片段会被保留。

- `Delimiter 1..N`
  - 作用：
    - 定义一个 source 可以用哪些分隔符切分。
  - 可选值：
    - 任意普通文本分隔符。
  - 详细说明：
    - 这是普通文本切分，不是正则表达式。
  - 示例：
    - `_`
    - `｜`
    - `-`
    - `:`

### 4.4 程序实际提取行为

程序提取维度时的规则如下：

1. 按 `row_dimensions` 顺序处理每个维度。
2. 对当前维度，按 `sources` 顺序依次提取。
3. 每个 source：
   - 如果配了 `split_position_by_column + split_position_map`：
     - 先读取另一列的值；
     - 如果命中映射，优先用映射得到的 split position；
     - 如果没命中，再回退到普通 `default_split_position`。
   - 如果最终没有可用 split position：
     - 直接取整格文本。
   - 如果最终有 split position：
     - 先按 `split_delimiters` 切分，再取指定位置。
4. 把所有成功提取的 source 结果用 `|` 拼成最终维度值。
5. 如果一个维度所有 source 都没拿到值：
   - 有 `default_value` 就用默认值；
   - 没默认值但 `optional=true` 就允许为空；
   - 否则整行数据无效。

### 4.5 典型示例

#### 4.5.1 从一个列里拆出样品号

| `Name` | `Display Name` | `Priority` | `Optional` | `Default Value` | `Source Order` | `Source Column` | `Default Split Position` | `Split Position By Column` | `Match Value` | `Mapped Split Position` | `Skip Empty Parts` | `Delimiter 1` | `Delimiter 2` |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `sample_id` | `SampleID` | `2` | `false` |  | `1` | `recordName` | `0` |  |  |  | `false` | `_` | `｜` |

这表示：

- 从 `recordName` 列取原始文本
- 先按 `_` 或 `｜` 切分
- 默认取第 `0` 段作为 `sample_id`

#### 4.5.2 一个维度由多个原始列重组

| `Name` | `Display Name` | `Priority` | `Optional` | `Default Value` | `Source Order` | `Source Column` | `Default Split Position` | `Split Position By Column` | `Match Value` | `Mapped Split Position` | `Skip Empty Parts` | `Delimiter 1` | `Delimiter 2` |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `location` | `Location` | `4` | `false` |  | `1` | `Line` |  |  |  |  | `false` |  |  |
| `location` | `Location` | `4` | `false` |  | `2` | `Site` |  |  |  |  | `false` |  |  |

最终结果可能是：

| 输入列 `Line` | 输入列 `Site` | 最终 `location` |
| --- | --- | --- |
| `A` | `03` | `A|03` |

这表示：

- 先取 `Line`
- 再取 `Site`
- 两个 source 的结果按 `Source Order` 顺序用 `|` 拼接

#### 4.5.3 按另一列动态决定 split position

| `Name` | `Display Name` | `Priority` | `Optional` | `Default Value` | `Source Order` | `Source Column` | `Default Split Position` | `Split Position By Column` | `Match Value` | `Mapped Split Position` | `Skip Empty Parts` | `Delimiter 1` | `Delimiter 2` |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `sample_id` | `SampleID` | `2` | `false` |  | `1` | `recordName` | `0` | `Site` | `1` | `0` | `false` | `_` |  |
| `sample_id` | `SampleID` | `2` | `false` |  | `1` | `recordName` | `0` | `Site` | `2` | `1` | `false` | `_` |  |
| `sample_id` | `SampleID` | `2` | `false` |  | `1` | `recordName` | `0` | `Site` | `3` | `2` | `false` | `_` |  |

例如：

| 输入列 `recordName` | 输入列 `Site` | 命中的映射 | 最终取值 |
| --- | --- | --- | --- |
| `S001_T0_3` | `2` | `Match Value = 2 -> Mapped Split Position = 1` | `T0` |

那么程序会优先命中：

- `Site = 2`
- 对应使用 `Mapped Split Position = 1`
- 所以最后取 `recordName` 按 `_` 切分后的第 `1` 段，也就是 `T0`

<a id="column-header-levels-sheet"></a>
## 5. `column_header_levels` Sheet

### 5.1 作用

这一页定义结果横向表头的层级名字和顺序。

例如可以定义为：

- `Chain Name`
- `Test Type`
- `Repeat Index`

程序不会再从原始 `column_name` 自动猜层级值，而是依赖这里和 `analysis_groups` 中的明确配置。

`analysis_groups` 末尾的层级列可以继续向右扩展，不固定为 Chain、Test Type、Repeat Index 三层。新增层级时，先在 `column_header_levels` 增加 Name 和 Priority，再在 `analysis_groups` 第 2 行追加对应层级表头，并为各测试行填写该层级的值。表头支持[字段名称自动匹配](#field-name-matching)，例如声明 `Chain Name` 后，层级列表头也可写 `chain_name`；建议沿用声明的 Name。

### 5.2 字段说明

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `Name` | `column_header_levels[*].name` |
| `Priority` | `column_header_levels[*].priority` |

- `Name`
  - 作用：
    - 定义一个横向表头层级的名称。
  - 可选值：
    - 任意非空字符串。
  - 示例：
    - `Chain Name`
    - `Test Type`
    - `Repeat Index`

- `Priority`
  - 作用：
    - 定义层级顺序。
  - 可选值：
    - 正整数。
  - 详细说明：
    - 数字越小，层级越靠前。
    - `initial_column_merge_level` 会依赖这组顺序。

### 5.3 典型层级示例

| 层级 | 示例 | 说明 |
| --- | --- | --- |
| Level 1 | `Chain Name` | 顶层链路或大类 |
| Level 2 | `Test Type` | 中层测试类型 |
| Level 3 | `Repeat Index` | 最底层重复编号 |

<a id="analysis-groups-sheet"></a>
## 6. `analysis_groups` Sheet

### 6.1 作用

`analysis_groups` 是整个模板的核心页。

它决定：

- 每个 raw test column 属于哪个逻辑 group
- 这些列在报表里如何形成横向层级
- golden / zscore 统计是按组一起算，还是按列分开算
- 组级 built golden 规则是什么

### 6.2 一行代表什么

在 Excel 模板里：

- 一行表示一个 raw column
- 同一个 group 的多列会使用相同的 `ID`

所以这也是长表模式。

### 6.3 字段说明

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `ID` | `analysis_groups[*].id` |
| `Display Name` | `analysis_groups[*].display_name` |
| `Analysis Mode` | `analysis_groups[*].analysis_mode` |
| `Unit` | `analysis_groups[*].unit` |
| `Outlier Golden Method` | `analysis_groups[*].outlier_golden_method` |
| `Golden Relative Limit` | `analysis_groups[*].golden_relative_limit` |
| `Golden Sigma Multiplier` | `analysis_groups[*].golden_sigma_multiplier` |
| `Golden Lower Bound` | `analysis_groups[*].golden_absolute_lower_bound` |
| `Golden Upper Bound` | `analysis_groups[*].golden_absolute_upper_bound` |
| `Golden Overwrite Lower Bound` | `analysis_groups[*].golden_overwrite_lowerbound` |
| `Golden Overwrite Upper Bound` | `analysis_groups[*].golden_overwrite_upperbound` |
| `Golden Continuous Interval` | `analysis_groups[*].golden_continuous_interval` |
| `Golden Empty Range Fallback To Absolute` | `analysis_groups[*].golden_empty_range_fallback_to_absolute` |
| `Column Order` | `analysis_groups[*].columns[*].column_order` |
| `Column Name` | `analysis_groups[*].columns[*].name` |
| `<column_header_levels.Name>` | `analysis_groups[*].columns[*].header_values[*]` |

- `ID`
  - 作用：
    - 作为一组测试列的逻辑分组标识。
  - 可选值：
    - 非空字符串。
  - 详细说明：
    - 如果这些列应该一起参与 golden / zscore 相关计算，就使用同一个 `ID`。
    - 如果这些列不应该一起计算，就不要复用同一个 `ID`。
  - 示例：
    - `link1_resistance`

- `Display Name`
  - 作用：
    - 定义这组测试在报表中的显示名称。
  - 可选值：
    - 任意字符串，或留空。
  - 详细说明：
    - 如果省略，通常会退回使用 `ID`。
  - 示例：
    - `Link1 Resistance`

- `Analysis Mode`
  - 作用：
    - 定义组内多列是合并分析，还是逐列分析。
  - 可选值：
    - `pooled_columns`
    - `per_column`

各可选项含义：

- `pooled_columns`
  - 同一个 `ID` 下的列会一起参与 golden 和 zscore 计算。
  - 更适合同条件重复测量、同质测点。

- `per_column`
  - 同一个 `ID` 下的列不会在 golden 和 zscore 里合并。
  - 每个 raw column 各自单独计算。
  - 但它们仍然共享这一组的 group 级规则配置。

- `Unit`
  - 作用：
    - 定义该组默认单位。
  - 可选值：
    - 任意字符串或留空。
  - 详细说明：
    - 结果报表只使用 template 里定义的单位。
    - 如果留空，通常就按空值保留，不再从输入表猜单位。

- `Outlier Golden Method`
  - 作用：
    - 定义该 analysis group 自己的 built golden 判定方法。
  - 可选值：
    - 合法 golden rule 表达式，或留空。
  - 详细说明：
    - 如果这里显式定义，就不会再读取 GUI / `golden_reference_defaults` 的全局默认。

- `Golden Relative Limit`
  - 作用：
    - 为 group 级 golden 规则提供 `relative` 参数。
  - 可选值：
    - 数字或留空。
  - 规则：
    - 当 `Outlier Golden Method` 用到 `relative` 时必须显式定义。

- `Golden Sigma Multiplier`
  - 作用：
    - 为 group 级 golden 规则提供 `sigma` 参数。
  - 可选值：
    - 数字或留空。
  - 规则：
    - 当 `Outlier Golden Method` 用到 `sigma` 时必须显式定义。

- `Golden Lower Bound` / `Golden Upper Bound`
  - 作用：
    - 为 group 级 golden 规则提供 `absolute` 上下界。
  - 可选值：
    - 数字或留空。
  - 规则：
    - 当 `Outlier Golden Method` 用到 `absolute` 时必须显式定义。

- `Column Order`
  - 作用：
    - 保留 group 内 raw column 的原始顺序。
  - 可选值：
    - 正整数。

- `Column Name`
  - 作用：
    - 指定该行对应的原始测试列名。
  - 可选值：
    - 输入表中真实存在的测试列列名。
  - 示例：
    - `R_Link1_1V_1`

- `<column_header_levels.Name>`
  - 作用：
    - 为当前 raw column 填写每一层横向表头值。
  - 可选值：
    - 任意非空字符串，但必须与业务分组一致。
  - 示例：
    - `Chain Name = Link1`
    - `Test Type = Resistance`
    - `Repeat Index = 1`

### 6.4 同一个 `ID` 下哪些字段应该一致

同一个 `ID` 的多行里，以下字段属于“共享字段”：

- `Display Name`
- `Analysis Mode`
- `Unit`
- `Outlier Golden Method`
- `Golden Relative Limit`
- `Golden Sigma Multiplier`
- `Golden Lower Bound`
- `Golden Upper Bound`

设计意图：

- 同一个 `ID` 表示同一个逻辑 group
- 同一个逻辑 group 的这些共享属性应该保持一致

如果同一个 `ID` 的多行写出了不同共享值：

- 默认严格模式下，`validate-template` 和 `build-golden` 会要求先修正模板
- 如果明确使用兼容策略，程序可能会按“第一个非空值”处理

### 6.5 典型示例

下面示例展示一个 `ID = link1_resistance` 的 group，包含 3 个原始测试列，并且这 3 行共享同一套 group 级规则：

| `ID` | `Display Name` | `Analysis Mode` | `Unit` | `Outlier Golden Method` | `Golden Relative Limit` | `Golden Sigma Multiplier` | `Golden Lower Bound` | `Golden Upper Bound` | `Column Order` | `Column Name` | `Chain Name` | `Test Type` | `Repeat Index` |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `link1_resistance` | `Link1 Resistance` | `pooled_columns` | `Ohm` | `relative or (sigma and absolute)` | `0.20` | `3` | `80` | `120` | `1` | `R_Link1_1V_1` | `Link1` | `Resistance` | `1` |
| `link1_resistance` | `Link1 Resistance` | `pooled_columns` | `Ohm` | `relative or (sigma and absolute)` | `0.20` | `3` | `80` | `120` | `2` | `R_Link1__1V_2` | `Link1` | `Resistance` | `2` |
| `link1_resistance` | `Link1 Resistance` | `pooled_columns` | `Ohm` | `relative or (sigma and absolute)` | `0.20` | `3` | `80` | `120` | `3` | `R_Link1_1V_3` | `Link1` | `Resistance` | `3` |

<a id="node-orders-sheet"></a>
## 7. `node_orders` Sheet

### 7.1 作用

`node_orders` 用来定义 node 的先后顺序。

节点列可以继续向右扩展，不限于模板已有的列数。在第 2 行依次添加 `Node 3`、`Node 4` 等表头，第 3 行起每格填写一个节点值；多个路径仍分行填写。不要把多个节点挤在同一个单元格中。

它会影响：

- 报表行排序
- outlier 的先后判断
- `Outlier Summary` 里 `New / Existed / Recovered` 的判定

### 7.2 一行代表什么

- 一行表示一条 node sequence
- 一个 node 占一个单元格

表头形式通常是：

- `Sequence Name`
- `Node 1`
- `Node 2`
- `Node 3`
- ...

### 7.3 字段说明

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `Sequence Name` | 不写入 JSON，仅用于 Excel 阅读 |
| `Node 1..N` | `report.node_orders[序列索引][节点索引]` |

- `Sequence Name`
  - 作用：
    - 给这条 sequence 起一个便于阅读的名字。
  - 可选值：
    - 任意字符串。

- `Node 1..N`
  - 作用：
    - 依次填写该 sequence 中的 node 顺序。
  - 可选值：
    - 任意 node 名称。
  - 示例：
    - `T0`
    - `T1`
    - `HTOL_168H`

JSON 使用节点数组的数组，不带 name / sequence 对象：

```json
{
  "report": {
    "node_orders": [["T0", "T1", "T2"], ["T0", "T3", "T4"]]
  }
}
```

`Sequence Name` 不影响历史比较，重新导出 Excel 时不会保留自定义序列标题。决定顺序的是各行的 Node 值。

### 7.4 `New / Existed / Recovered` 与 node 顺序的关系

程序会按每个 sample 实际出现的 node 集合，自动匹配最合适的顺序。

`Outlier Summary` 中这些状态的理解如下：

- `New`
  - 当前节点最终判定为 `fail`
  - 且所有更早的已存在前驱节点里，这一条 test group 都没有 fail 过

- `Existed`
  - 当前节点最终判定为 `fail`
  - 且任意一个更早的已存在前驱节点里，这一条 test group 已经 fail 过

- `Recovered`
  - 当前节点最终判定为 `pass`
  - 且最近一个有数据的前驱节点，这一条 test group 是 `fail`

### 7.5 校验规则

- 每条 sequence 不能为空
- 同一条 sequence 内部不能有重复 node
- 多条 sequence 之间，公共节点的相对顺序不能冲突

<a id="analysis-dimension-filters-sheet"></a>
## 8. `analysis_dimension_filters` Sheet

### 8.1 作用

这是分析开始前就直接生效的输入数据过滤。

它不是 `outlier_ratio_stats` 那种统计阶段过滤，而是在分析刚开始时就先筛掉 measurement。

### 8.2 表头结构

| 列名 | 作用 |
| --- | --- |
| `Mode` | 包含或排除 |
| `Dimension` | 过滤的是哪个维度 |
| `Value Order` | 同一字段下的值顺序 |
| `Value` | 过滤值本身 |

### 8.3 支持的字段

这里使用两类固定的筛选名称：

- `sample_key`
- `reliability_node`

这里的 `reliability_node` 是节点筛选的固定名称，程序再根据 `reliability_node_dimension` 找到实际行维度。例如节点角色设为 `stage` 时，本页仍写 `reliability_node`，Value 写 T0 等节点值；不要直接把 Dimension 改为 `stage`。这与 Golden Filters 不同，Golden Filters 使用实际字段名 `stage`。

### 8.4 字段说明

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `Mode` | `report.analysis_dimension_filters.include` / `report.analysis_dimension_filters.exclude` |
| `Dimension` | `report.analysis_dimension_filters.<mode>.<dimension>` |
| `Value Order` | `report.analysis_dimension_filters.<mode>.<dimension>[*]` 的数组顺序 |
| `Value` | `report.analysis_dimension_filters.<mode>.<dimension>[*]` |

- `Mode`
  - 作用：
    - 定义这是白名单过滤还是黑名单过滤。
  - 可选值：
    - `include`
    - `exclude`

各可选项含义：

- `include`
  - 只保留命中的值。

- `exclude`
  - 去掉命中的值。

- `Dimension`
  - 作用：
    - 指定过滤针对哪个维度。
  - 可选值：
    - `sample_key`
    - `reliability_node`

各可选项含义：

- `sample_key`
  - 使用 GUI `Sample Keys / Exclude Sample Keys` 同款写法。
  - 适合按样品主键范围精确筛选。

- `reliability_node`
  - 直接写 node 名称。
  - 适合按阶段筛选。

- `Value Order`
  - 作用：
    - 定义同一字段下多个值的顺序。
  - 可选值：
    - 正整数。

- `Value`
  - 作用：
    - 实际过滤值。
  - 示例：
    - `LOT1:S1,S2,S3`
    - `T0`

### 8.5 典型示例

```text
include | sample_key       | 1 | LOT1:S1,S2,S3,S4,3
include | sample_key       | 2 | LOT2:3
include | reliability_node | 1 | Node1
include | reliability_node | 2 | Node2
exclude | sample_key       | 1 | LOTX:S999
```

<a id="analysis-column-filters-sheet"></a>
## 9. `analysis_column_filters` Sheet

### 9.1 作用

这也是分析开始前的过滤，但它过滤的是测试列，而不是样品行。

它对应 GUI `Analyze` 页里的：

- `Tests`
- `Exclude Tests`

### 9.2 表头结构

| 列名 | 作用 |
| --- | --- |
| `Mode` | 包含或排除 |
| `Field` | 按哪个字段过滤 |
| `Value Order` | 同字段下的值顺序 |
| `Value` | 过滤值本身 |

### 9.3 支持的字段

根据原版 help，这里的字段来自：

- `column_header_levels`
- `analysis_groups` 里的：
  - `id`
  - `display_name`
  - `raw_column(column_name)`
  - `unit`

常见字段示例：

- `Chain Name`
- `Test Type`
- `Repeat Index`
- `id`
- `display_name`
- `column_name`
- `unit`

### 9.4 字段说明

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `Mode` | `report.analysis_column_filters.include` / `report.analysis_column_filters.exclude` |
| `Field` | `report.analysis_column_filters.<mode>.<field>` |
| `Value Order` | `report.analysis_column_filters.<mode>.<field>[*]` 的数组顺序 |
| `Value` | `report.analysis_column_filters.<mode>.<field>[*]` |

- `Mode`
  - 作用：
    - 定义保留命中项还是排除命中项。
  - 可选值：
    - `include`
    - `exclude`

- `Field`
  - 作用：
    - 指定过滤依据是哪一个测试属性。
  - 可选值：
    - 来自 `column_header_levels` 的层级名
    - 或 `analysis_groups` 元数据字段

- `Value Order`
  - 作用：
    - 定义多个过滤值的显示顺序。
  - 可选值：
    - 正整数

- `Value`
  - 作用：
    - 实际命中的字段值。
  - 规则：
    - 必须来自模板里已经定义过的值

### 9.5 典型示例

```text
include | Chain Name | 1 | Chain1
include | Chain Name | 2 | Chain2
include | Test Type  | 1 | TestType1
include | Test Type  | 2 | TestType2
exclude | id         | 1 | TestType2_Chain2_1
```

<a id="outlier-ratio-stats-sheet"></a>
## 10. `outlier_ratio_stats` Sheet

### 10.1 作用

这一页定义 `Outlier Summary` 里的比例统计区域。

它不是决定 fail 的规则，而是决定：

- 按什么维度分组做统计
- 分子统计什么
- 是否只看某一条链、某一个 group、某一个原始列

`Group By Dimension` 只决定最终统计结果怎么分桶；它不会改变 outlier 判定的数据池，也不会改变 merged fail / new / recovered 的计算逻辑。需要改变数据池时，请使用 filter。

### 10.2 一行代表什么

- 一行表示一个 ratio filter 项
- 同一个统计项可以占多行
- 多行会通过相同的 `ID` 聚合成同一个统计配置

### 10.3 表头结构

| 列名 | 作用 |
| --- | --- |
| `ID` | 统计项标识 |
| `Display Name` | 统计项显示名 |
| `Group By Dimension` | 按哪些 row 维度或 column header level 分组 |
| `Numerator` | 分子统计规则 |
| `Filter Type` | 过滤条件类型 |
| `Filter Order` | 过滤条件顺序 |
| `Filter Value` | 过滤条件值 |

### 10.4 字段说明

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `ID` | `report.outlier_ratio_stats[*].id` |
| `Display Name` | `report.outlier_ratio_stats[*].display_name` |
| `Group By Dimension` | `report.outlier_ratio_stats[*].group_by_dimension` / `report.outlier_ratio_stats[*].group_by_dimensions` |
| `Numerator` | `report.outlier_ratio_stats[*].numerator` |
| `Filter Type` | `report.outlier_ratio_stats[*]` 中的 `group_ids / group_display_names / test_types / chain_names / column_names / units` 之一 |
| `Filter Order` | 对应 filter 数组里的顺序 |
| `Filter Value` | 对应 filter 数组里的元素值 |

- `ID`
  - 作用：
    - 标识一个 ratio 统计项。
  - 可选值：
    - 非空字符串。
  - 示例：
    - `new_ratio_by_node_all`

- `Display Name`
  - 作用：
    - 定义该统计项在报表里的标题。
  - 可选值：
    - 任意字符串，或留空。

- `Group By Dimension`
  - 作用：
    - 定义统计时按哪些 row 维度或 column header level 分组。
  - 可选值：
    - 一个或多个已存在的 `row_dimensions.name` 或 `column_header_levels.name`，多个值用 `;` 分隔。
    - 支持[字段名称自动匹配](#field-name-matching)，例如 `chain_name` 可匹配 `Chain Name`；row 维度也可使用唯一的 Display Name。
  - 示例：
    - `reliability_node`
    - `reliability_node;lot_id`
    - `Chain Name`
    - `chain_name`
    - `lot_id;chain_name;reliability_node`（按批次、链路、节点联合分组）

- `Numerator`
  - 作用：
    - 定义分子统计什么。
  - 可选值：
    - `new_outlier_samples`
    - `outlier_samples`
    - `recovered_samples`

各可选项含义：

- `new_outlier_samples`
  - 统计“新增失效样品”数量。
  - 常用于看每个 node 的新失效比例。

- `outlier_samples`
  - 统计“失效样品”总量。
  - 不区分是新增还是已存在。

- `recovered_samples`
  - 统计当前节点恢复为 PASS、最近一个有数据的前驱节点为 FAIL 的样品数量。
  - 对应 Outlier Summary 中的 Recovered 状态。

- `Filter Type`
  - 作用：
    - 定义过滤器是按什么字段筛选。
    - 字段名支持自动匹配，例如 `Chain Name`、`CHAIN-NAME`、`ChainName` 都可写在这里，等价于 `chain_name`；`Filter Value` 仍按原有值匹配规则处理。
  - 可选值：
    - `id`
    - `display_name`
    - `test_type`
    - `chain_name`
    - `column_name`
    - `unit`
    - `chain`
    - `raw_column`

各可选项含义：

- `id`
  - 按 analysis group id 过滤。

- `display_name`
  - 按 analysis group 显示名过滤。

- `test_type`
  - 按测试类型过滤。

- `chain_name`
  - 按链路名过滤。

- `column_name`
  - 按 raw column 过滤。

- `unit`
  - 按单位过滤。

- `chain`
  - `chain_name` 的兼容别名。

- `raw_column`
  - `column_name` 的兼容别名。

- `Filter Order`
  - 作用：
    - 定义同一统计项下多条 filter 的顺序。
  - 可选值：
    - 正整数。

- `Filter Value`
  - 作用：
    - 对应 filter 的具体值。
  - 可选值：
    - 任意已定义值，或留空。

- 同一个 `ID` 下的 filter 组合规则：
  - 同一个 `Filter Type` 下多个 `Filter Value` 是 `OR`
  - 例如两行 `test_type=A` 和 `test_type=B`，表示 `test_type=A or B`
  - 不同 `Filter Type` 之间是 `AND`
  - 例如 `test_type=Voltage` 且 `chain_name=Link4`
  - Excel 长表里如果要表达一个 key 对多个值，请写成多行
  - 当前不是在一个 `Filter Value` 单元格里写 `A,B`

### 10.5 典型示例

下面的示例都按同一套列顺序展开：

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |

示例 1：不加任何 filter，只统计每个 node 的新增 outlier 比例

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |
| `new_ratio_by_node_all` | `New Outlier Ratio By Node` | `reliability_node` | `new_outlier_samples` |  | `1` |  |

示例 2：只统计某一条 chain 的总 outlier 比例

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |
| `total_ratio_by_node_link4` | `Total Outlier Ratio By Node (Link4)` | `reliability_node` | `outlier_samples` | `chain_name` | `1` | `Link4` |

示例 3：只统计某一个原始测试列的总 outlier 比例

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |
| `total_ratio_by_node_v_link1_1p8v` | `Total Outlier Ratio By Node (V_Link1_1p8V)` | `reliability_node` | `outlier_samples` | `column_name` | `1` | `V_Link1_1p8V` |

示例 4：同一个统计项叠加多条 filter

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |
| `link4_voltage_v_ratio` | `Link4 Voltage Ratio` | `reliability_node` | `outlier_samples` | `id` | `1` | `link4_voltage` |
| `link4_voltage_v_ratio` | `Link4 Voltage Ratio` | `reliability_node` | `outlier_samples` | `display_name` | `2` | `Link4 Voltage` |
| `link4_voltage_v_ratio` | `Link4 Voltage Ratio` | `reliability_node` | `outlier_samples` | `test_type` | `3` | `V` |
| `link4_voltage_v_ratio` | `Link4 Voltage Ratio` | `reliability_node` | `outlier_samples` | `unit` | `4` | `V` |

这组写法表示：

- 4 行会按相同的 `ID` 聚合成同一个统计项
- 这个统计项既要求命中 `id=link4_voltage`
- 也要求命中 `display_name=Link4 Voltage`
- 同时还要求 `test_type=V`、`unit=V`

示例 4.1：同一个 `Filter Type` 写多个值，表示 `OR`

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |
| `ab_ratio` | `A Or B Ratio` | `reliability_node` | `outlier_samples` | `test_type` | `1` | `A` |
| `ab_ratio` | `A Or B Ratio` | `reliability_node` | `outlier_samples` | `test_type` | `2` | `B` |

这组写法表示：

- `test_type=A or B`
- 不是 `A and B`

示例 5：按多个 row 维度联合分组

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |
| `new_ratio_by_node_and_lot` | `New Outlier Ratio By Node And Lot` | `reliability_node;lot_id` | `new_outlier_samples` |  | `1` |  |

示例 6：按批次、链路、可靠性节点联合分组，统计总失效率

假设 row 维度已定义 `lot_id`、`sample_id`、`reliability_node`，column 最高层级为 `Chain Name`，可以只写一条统计配置：

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |
| `total_ratio_by_lot_chain_node` | `批次 / 链路 / 节点总失效率` | `lot_id;chain_name;reliability_node` | `outlier_samples` |  | `1` |  |

`chain_name` 自动匹配 `Chain Name`，因此该写法与 `lot_id;Chain Name;reliability_node` 等价。程序按实际数据为各批次、链路、节点组合生成统计行，无需为每条链路单独复制一条 Filter。若只统计 `Link4`，再填写 `Filter Type = Chain Name`、`Filter Value = Link4`；字段名可换写法，链路值仍按原有规则匹配。若节点 Name 是 `stage`，上面的 `reliability_node` 应替换为 `stage`。

### 10.6 使用限制

- 如果一个统计项没有任何 filter，也可以只留一行基础配置，把 `Filter Type / Filter Value` 留空
- `Group By Dimension` 里写的每个维度都必须匹配 `row_dimensions` 或 `column_header_levels` 中已定义的字段；非精确写法有歧义时需改用精确 Name
- `Group By Dimension` 的行维度只能使用所选 Reliability Node Row Level 及更高层级；列表头层级也可以使用。节点字段为 `stage` 时，按节点统计应填写 `stage`，而不是固定写 `reliability_node`
- `Group By Dimension` 不是 filter，不会反过来改变 outlier 判定的数据池或 fail rule 合并边界
- 如果 `Group By Dimension` 使用 column header level 且跳过了上层 level，Excel Summary 会用中文提示：统计结果是把当前 filter 下已经 merged 的 outlier 映射到当前维度上统计；如果需要重新判断，请使用 filter 改变统计数据池

## 11. `README` Sheet

### 11.1 作用

`README` 是模板自带说明页。

它的作用是：

- 给维护者写业务说明
- 记录模板版本信息
- 写字段命名约定
- 写风险提示

### 11.2 注意

- 这一页不参与解析
- 改它不会改变计算逻辑
- 但很适合放团队内部约定

## 12. Excel 与 JSON 的关系

Excel 模板为了方便人工编辑，很多地方会“展开”成长表。

| Excel 结构 | JSON 结构 | 说明 |
| --- | --- | --- |
| `row_dimensions` 一行一个 source | `row_dimensions[*].sources[*]` | Excel 中按 source 展开 |
| `analysis_groups` 一行一个 raw column | `analysis_groups[*].columns[*]` | 同一 `ID` 的多行会聚合成一个 group |
| `node_orders` 一行一条 sequence | `report.node_orders[*]` | 一个节点占一个单元格 |
| `analysis_dimension_filters` 一行一个值 | `report.analysis_dimension_filters` | include/exclude 按长表存储 |
| `analysis_column_filters` 一行一个值 | `report.analysis_column_filters` | include/exclude 按长表存储 |
| `outlier_ratio_stats` 一行一个 filter | `report.outlier_ratio_stats[*]` | 同一 `ID` 的多行会聚合 |

## 13. 主要校验规则

程序会自动校验以下内容：

- `row_dimension.name` 不能重复
- `test_data_start_row` 必须显式定义，不能依赖程序自动推断
- 每个 `row_dimension` 必须至少有一个 source
- 每个 source 必须有 `column`
- 如果 source 使用了任意 split 逻辑，就必须同时有 `split_delimiters`
- 如果 source 配了 `split_position_by_column`，必须同时有 `split_position_map`
- 如果 source 配了 `split_position_map`，必须同时有 `split_position_by_column`
- `split_position_map` 里的位置值不能是负数
- `analysis_group.analysis_mode` 只能是：
  - `pooled_columns`
  - `per_column`
- 同一个 raw column 不能出现在多个 `analysis_groups`
- `report.outlier_fail_method` 只能是：
  - `modified_z_score`
  - `golden_deviation`
  - `zscore_and_golden`
  - `zscore_or_golden`
- 四个 fail rule 都只能是：
  - `any_fail`
  - `all_fail`
- `report.initial_row_merge_level` 必须是已存在的 `row_dimensions.name`
- `report.initial_column_merge_level` 必须是已存在的 `column_header_levels.name`
- `report.outlier_merge_order` 必须是 6 种合法执行顺序之一
- `report.outlier_ratio_stats[*].numerator` 只能是：
  - `new_outlier_samples`
  - `outlier_samples`
  - `recovered_samples`
- `report.outlier_ratio_stats[*].group_by_dimension` 必须是已存在的 `row_dimensions.name` 或 `column_header_levels.name`
- Initial 行保留层级必须等于或低于选定节点；Initial 列保留层级必须等于或低于选定 Chain
- `node_orders` 中每条 sequence 不能为空
- 每条 node sequence 内部不能有重复 node
- 多条 node sequence 之间不能出现公共节点的反向顺序冲突

## 14. 推荐做法

- `row_dimensions`
  - 尽量把一个维度的提取规则写清楚
  - 能直接取整列就不要无必要增加复杂 split

- `analysis_groups`
  - `ID` 建议使用稳定、短、可读的业务名
  - 同一个 `ID` 的共享字段尽量保持完全一致

- `node_orders`
  - 如果业务里确实有多种 node 路径，优先写 `node_orders`
  - 公共节点的相对顺序必须保持一致

- `outlier_ratio_stats`
  - 如果只是想看每个 node 的新增失效比例，可以先从：
    - `group_by_dimension = reliability_node`
    - `numerator = new_outlier_samples`
    开始

- `analysis_dimension_filters` / `analysis_column_filters`
  - 推荐只放最常复用的默认分析范围
  - 临时性的筛选更适合在 GUI 的 `Analyze` 页里改

## 15. Command Reference

安装项目后，在终端使用 `easy-outlier`。源码运行方式为 `python -m excel_data_analysis.cli`；不是旧文档中的 `cli_main`。以下模板路径指向程序内置模板，转换输出使用新文件名。

校验 template：

```bash
easy-outlier validate-template --input src/excel_data_analysis/assets/templates/chip_reliability_template.xlsx
easy-outlier validate-template --input src/excel_data_analysis/assets/templates/chip_reliability_template.json
```

模板互转：

```bash
easy-outlier template-to-json \
  --input src/excel_data_analysis/assets/templates/chip_reliability_template.xlsx \
  --output chip_reliability_template_copy.json

easy-outlier template-to-xlsx \
  --input src/excel_data_analysis/assets/templates/chip_reliability_template.json \
  --output chip_reliability_template_copy.xlsx
```

转换默认遇到同名输出文件会报错；可用 `--if-exists timestamp` 保留原文件并生成带时间戳的新文件。GUI 转换前须解锁编辑；CLI 没有 GUI 编辑锁。
