# Continuous Comparison Demo

这个 demo 演示更贴近当前 Excel Data Analysis 语境的“连续比较画布”：

- `Box Plot`：
  - 左侧数值尺固定
  - 内容带水平滚动
  - `x` 轴标签和 box 一起滚动
- `Ridge Plot`：
  - 内容带纵向滚动
  - 底部数值尺固定
  - 默认 lane 间距更舒适
  - 支持 `Shared Range / Independent Range`

## 运行

```bash
./.venv/bin/python demo/continuous_comparison_demo/app.py
```

## 导出预览

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python demo/continuous_comparison_demo/app.py --export-preview
```
