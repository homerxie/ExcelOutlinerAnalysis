#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
UIC="${REPO_ROOT}/.venv/bin/pyside6-uic"

if [[ ! -x "${UIC}" ]]; then
  UIC="pyside6-uic"
fi

"${UIC}" \
  "${SCRIPT_DIR}/continuous_comparison_demo.ui" \
  -o "${SCRIPT_DIR}/ui_continuous_comparison_demo.py"
