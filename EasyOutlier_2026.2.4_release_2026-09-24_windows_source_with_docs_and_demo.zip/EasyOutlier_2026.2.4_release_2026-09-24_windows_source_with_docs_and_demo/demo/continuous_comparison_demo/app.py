from __future__ import annotations

import argparse
import math
import random
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

from PySide6.QtCore import QObject, QEvent, QPointF, QRectF, QSize, QStringListModel, QThread, Qt, QTimer, Signal, Slot
from PySide6.QtGui import QCursor, QColor, QImage, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QCompleter,
    QLabel,
    QMainWindow,
    QProgressBar,
    QScrollArea,
    QToolTip,
    QWidget,
)

try:
    from .ui_continuous_comparison_demo import Ui_ContinuousComparisonWindow
except ImportError:
    from ui_continuous_comparison_demo import Ui_ContinuousComparisonWindow


def _stable_unit(*parts: object) -> float:
    value = 0
    for char in "|".join(str(part) for part in parts):
        value = (value * 131 + ord(char)) % 1_000_000_007
    return (value % 1_000_000) / 999_999.0


def _quantile(sorted_values: list[float], q: float) -> float:
    if not sorted_values:
        return 0.0
    if len(sorted_values) == 1:
        return sorted_values[0]
    position = (len(sorted_values) - 1) * q
    lower = int(math.floor(position))
    upper = int(math.ceil(position))
    if lower == upper:
        return sorted_values[lower]
    ratio = position - lower
    return sorted_values[lower] * (1.0 - ratio) + sorted_values[upper] * ratio


def _moving_average(values: list[float], radius: int = 2) -> list[float]:
    if not values:
        return []
    result: list[float] = []
    for index in range(len(values)):
        start = max(0, index - radius)
        end = min(len(values), index + radius + 1)
        window = values[start:end]
        result.append(sum(window) / len(window))
    return result


@dataclass(frozen=True, slots=True)
class AggregatePoint:
    aggregate_id: str
    sample_id: str
    dataset_id: str
    row_number: int
    metric: str
    value: float
    outlier: bool = False


@dataclass(frozen=True, slots=True)
class AggregateSeries:
    aggregate_id: str
    label: str
    metric: str
    points: tuple[AggregatePoint, ...]


@dataclass(slots=True)
class HoverPoint:
    point: AggregatePoint
    position: QPointF
    radius: float


@dataclass(slots=True)
class RenderPayload:
    image: QImage
    hover_points: tuple[HoverPoint, ...]
    hover_buckets: dict[tuple[int, int], list[HoverPoint]]
    labels: tuple[str, ...]
    lane_bands: tuple[tuple[float, float], ...]
    label_margin: int
    minimum: float
    maximum: float
    aggregate_count: int
    point_count: int
    outlier_count: int
    clipped_low_count: int = 0
    clipped_high_count: int = 0

    def logical_size(self) -> QSize:
        return self.image.deviceIndependentSize().toSize()


class SyntheticComparisonData:
    def __init__(self) -> None:
        self._box_cache: dict[tuple[int, str], list[AggregateSeries]] = {}
        self._ridge_cache: dict[tuple[int, str], list[AggregateSeries]] = {}

    @staticmethod
    def _aggregate_label(index: int) -> str:
        lot = 1212 + (index % 18) * 7
        node = index % 8 + 1
        return f"Lot{lot} Node{node}"

    def box_series(self, count: int, metric: str) -> list[AggregateSeries]:
        key = (count, 0 if metric.startswith("Leakage") else 1)
        cached = self._box_cache.get(key)
        if cached is not None:
            return cached
        random.seed(100 + key[0] * 7 + key[1])
        base = 5.2 if metric.startswith("Leakage") else 12.0
        spread = 0.42 if metric.startswith("Leakage") else 1.05
        scale = 1.0 if metric.startswith("Leakage") else 2.1
        series: list[AggregateSeries] = []
        row_number = 1
        for index in range(count):
            center = base + scale * (
                math.sin((index + 1) * 0.23) * 0.28
                + (index % 11 - 5) * 0.022
            )
            points: list[AggregatePoint] = []
            for sample_index in range(42):
                value = random.gauss(center, spread)
                if sample_index % 17 == 0:
                    value += spread * (3.4 + (index % 3) * 0.4)
                elif sample_index % 29 == 0:
                    value -= spread * (2.7 + (index % 4) * 0.3)
                if sample_index == 5 and index % 23 == 0:
                    value += spread * 16.0
                elif sample_index == 11 and index % 31 == 0:
                    value -= spread * 14.0
                points.append(
                    AggregatePoint(
                        aggregate_id=f"T{index + 1:03d}",
                        sample_id=f"T{index + 1:03d}-S{sample_index + 1:03d}",
                        dataset_id=f"box-{metric.split()[0].lower()}",
                        row_number=row_number,
                        metric=metric,
                        value=value,
                    )
                )
                row_number += 1
            series.append(
                AggregateSeries(
                    aggregate_id=f"T{index + 1:03d}",
                    label=self._aggregate_label(index),
                    metric=metric,
                    points=tuple(self._mark_outliers(points)),
                )
            )
        self._box_cache[key] = series
        return series

    def ridge_series(self, count: int, metric: str) -> list[AggregateSeries]:
        key = (count, 0 if metric.startswith("Leakage") else 1)
        cached = self._ridge_cache.get(key)
        if cached is not None:
            return cached
        random.seed(700 + key[0] * 11 + key[1])
        base = 5.8 if metric.startswith("Leakage") else 11.2
        spread = 0.34 if metric.startswith("Leakage") else 0.95
        scale = 1.0 if metric.startswith("Leakage") else 2.5
        series: list[AggregateSeries] = []
        row_number = 1
        for index in range(count):
            center = base + scale * (
                math.sin((index + 3) * 0.14) * 0.36
                + (index % 13 - 6) * 0.014
            )
            points: list[AggregatePoint] = []
            for sample_index in range(34):
                value = random.gauss(center, spread)
                if sample_index % 13 == 0:
                    value += spread * (3.0 + (index % 4) * 0.25)
                elif sample_index % 21 == 0:
                    value -= spread * (2.4 + (index % 5) * 0.2)
                if sample_index == 4 and index % 19 == 0:
                    value += spread * 18.0
                elif sample_index == 9 and index % 27 == 0:
                    value -= spread * 15.0
                points.append(
                    AggregatePoint(
                        aggregate_id=f"C{index + 1:03d}",
                        sample_id=f"C{index + 1:03d}-S{sample_index + 1:03d}",
                        dataset_id=f"ridge-{metric.split()[0].lower()}",
                        row_number=row_number,
                        metric=metric,
                        value=value,
                    )
                )
                row_number += 1
            series.append(
                AggregateSeries(
                    aggregate_id=f"C{index + 1:03d}",
                    label=self._aggregate_label(index),
                    metric=metric,
                    points=tuple(self._mark_outliers(points)),
                )
            )
        self._ridge_cache[key] = series
        return series

    @staticmethod
    def _mark_outliers(points: list[AggregatePoint]) -> list[AggregatePoint]:
        sorted_values = sorted(point.value for point in points)
        q1 = _quantile(sorted_values, 0.25)
        q3 = _quantile(sorted_values, 0.75)
        iqr = max(q3 - q1, 1e-9)
        low_limit = q1 - 1.5 * iqr
        high_limit = q3 + 1.5 * iqr
        return [
            AggregatePoint(
                aggregate_id=point.aggregate_id,
                sample_id=point.sample_id,
                dataset_id=point.dataset_id,
                row_number=point.row_number,
                metric=point.metric,
                value=point.value,
                outlier=not (low_limit <= point.value <= high_limit),
            )
            for point in points
        ]


class ComparisonRenderer:
    def __init__(self) -> None:
        self._data = SyntheticComparisonData()
        self._colors = {
            "background": QColor("#fbfaf7"),
            "ink": QColor("#24323d"),
            "muted": QColor("#6b7882"),
            "grid": QColor("#d7dfde"),
            "fill": QColor(86, 112, 126, 20),
            "point_fill": QColor(88, 111, 122, 42),
            "point_edge": QColor(58, 78, 90, 118),
            "outlier_fill": QColor("#d87659"),
            "outlier_edge": QColor("#8e4734"),
        }
        self._label_margin = 156
        self._right_margin = 28
        self._top_margin = 10

    @staticmethod
    def _display_range_mode_key(mode: str) -> str:
        if mode.startswith("Full"):
            return "full"
        if "Edge" in mode:
            return "robust_marked"
        return "robust"

    @staticmethod
    def _make_image(width: int, height: int, dpr: float) -> tuple[QImage, QPainter]:
        physical_width = max(1, int(round(width * dpr)))
        physical_height = max(1, int(round(height * dpr)))
        image = QImage(QSize(physical_width, physical_height), QImage.Format.Format_ARGB32_Premultiplied)
        image.setDevicePixelRatio(dpr)
        painter = QPainter(image)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        return image, painter

    def _safe_canvas_width(self, width: int) -> int:
        # Keep the numeric plot area positive even if the window is squeezed hard.
        return max(int(width), self._label_margin + self._right_margin + 48)

    @staticmethod
    def _image_to_pixmap(image: QImage) -> QPixmap:
        pixmap = QPixmap.fromImage(image)
        pixmap.setDevicePixelRatio(image.devicePixelRatio())
        return pixmap

    def render_box(self, metric: str, count: int, lane_height: int, width: int, dpr: float, display_mode: str) -> RenderPayload:
        return self.render_box_series(
            self._data.box_series(count, metric),
            lane_height=lane_height,
            width=width,
            dpr=dpr,
            display_mode=display_mode,
        )

    def render_box_series(
        self,
        series: list[AggregateSeries],
        lane_height: int,
        width: int,
        dpr: float,
        display_mode: str,
        range_override: tuple[float, float] | None = None,
    ) -> RenderPayload:
        full_minimum, full_maximum = self._global_range(series)
        minimum, maximum = range_override or self._select_display_range(series, display_mode)
        show_edge_markers = self._display_range_mode_key(display_mode) == "robust_marked"
        width = self._safe_canvas_width(width)
        height = self._top_margin * 2 + len(series) * lane_height
        image, painter = self._make_image(width, height, dpr)
        image.fill(self._colors["background"])
        plot_rect = QRectF(
            float(self._label_margin),
            float(self._top_margin),
            float(width - self._label_margin - self._right_margin),
            float(height - self._top_margin * 2),
        )
        hover_points: list[HoverPoint] = []
        lane_bands: list[tuple[float, float]] = []
        clipped_low_count = 0
        clipped_high_count = 0
        self._draw_x_grid(painter, plot_rect, minimum, maximum)
        painter.save()
        painter.setClipRect(plot_rect.adjusted(0, 0, -1, -1))
        for index, item in enumerate(series):
            lane_top = plot_rect.top() + lane_height * index
            lane_bands.append((lane_top, float(lane_height)))
            values = sorted(point.value for point in item.points)
            q1 = _quantile(values, 0.25)
            median = _quantile(values, 0.50)
            q3 = _quantile(values, 0.75)
            iqr = max(q3 - q1, 1e-9)
            low_limit = q1 - 1.5 * iqr
            high_limit = q3 + 1.5 * iqr
            inside = [value for value in values if low_limit <= value <= high_limit]
            whisker_low = min(inside) if inside else min(values)
            whisker_high = max(inside) if inside else max(values)
            center_y = plot_rect.top() + lane_height * index + lane_height * 0.54
            box_height = min(12.0, lane_height * 0.52)
            x_q1 = self._map_x(q1, plot_rect, minimum, maximum)
            x_q3 = self._map_x(q3, plot_rect, minimum, maximum)
            x_median = self._map_x(median, plot_rect, minimum, maximum)
            x_low = self._map_x(whisker_low, plot_rect, minimum, maximum)
            x_high = self._map_x(whisker_high, plot_rect, minimum, maximum)
            painter.setPen(QPen(self._colors["ink"], 0.9))
            painter.setBrush(self._colors["fill"])
            painter.drawLine(QPointF(plot_rect.left(), center_y), QPointF(plot_rect.right(), center_y))
            painter.drawRect(QRectF(min(x_q1, x_q3), center_y - box_height / 2.0, abs(x_q3 - x_q1), box_height))
            painter.drawLine(QPointF(x_low, center_y), QPointF(x_q1, center_y))
            painter.drawLine(QPointF(x_q3, center_y), QPointF(x_high, center_y))
            painter.drawLine(QPointF(x_low, center_y - 4.0), QPointF(x_low, center_y + 4.0))
            painter.drawLine(QPointF(x_high, center_y - 4.0), QPointF(x_high, center_y + 4.0))
            painter.drawLine(QPointF(x_median, center_y - box_height / 2.0), QPointF(x_median, center_y + box_height / 2.0))
            for point in item.points:
                jitter = (_stable_unit(point.sample_id, point.aggregate_id) - 0.5) * lane_height * 0.34
                clipped = False
                display_value = point.value
                if point.value < minimum:
                    clipped_low_count += 1
                    display_value = minimum
                    clipped = True
                elif point.value > maximum:
                    clipped_high_count += 1
                    display_value = maximum
                    clipped = True
                edge_offset = 4.0
                display_x = self._map_x(display_value, plot_rect, minimum, maximum)
                if show_edge_markers and clipped:
                    if point.value < minimum:
                        display_x = plot_rect.left() + edge_offset
                    else:
                        display_x = plot_rect.right() - edge_offset
                position = QPointF(display_x, center_y + jitter)
                radius = 1.4 if not point.outlier else 1.8
                if point.outlier:
                    painter.setPen(QPen(self._colors["outlier_edge"], 0.8))
                    painter.setBrush(self._colors["outlier_fill"])
                else:
                    painter.setPen(QPen(self._colors["point_edge"], 0.7))
                    painter.setBrush(self._colors["point_fill"])
                if show_edge_markers and clipped:
                    direction = -1.0 if point.value < minimum else 1.0
                    path = QPainterPath()
                    path.moveTo(position + QPointF(direction * 4.5, 0.0))
                    path.lineTo(position + QPointF(-direction * 3.2, -2.8))
                    path.lineTo(position + QPointF(-direction * 3.2, 2.8))
                    path.closeSubpath()
                    painter.drawPath(path)
                else:
                    painter.drawEllipse(position, radius, radius)
                hover_points.append(HoverPoint(point=point, position=position, radius=radius))
        painter.restore()
        painter.setPen(self._colors["muted"])
        for index, item in enumerate(series):
            center_y = plot_rect.top() + lane_height * index + lane_height * 0.54
            painter.drawText(
                QRectF(8.0, center_y - 10.0, float(self._label_margin - 16), 20.0),
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                item.label,
            )
        painter.end()
        return RenderPayload(
            image=image,
            hover_points=tuple(hover_points),
            hover_buckets=self._build_hover_buckets(hover_points),
            labels=tuple(item.label for item in series),
            lane_bands=tuple(lane_bands),
            label_margin=self._label_margin,
            minimum=minimum,
            maximum=maximum,
            aggregate_count=len(series),
            point_count=sum(len(item.points) for item in series),
            outlier_count=sum(sum(1 for point in item.points if point.outlier) for item in series),
            clipped_low_count=clipped_low_count if minimum != full_minimum else 0,
            clipped_high_count=clipped_high_count if maximum != full_maximum else 0,
        )

    def render_ridge(self, metric: str, count: int, lane_height: int, width: int, dpr: float, display_mode: str) -> RenderPayload:
        return self.render_ridge_series(
            self._data.ridge_series(count, metric),
            lane_height=lane_height,
            width=width,
            dpr=dpr,
            display_mode=display_mode,
        )

    def render_ridge_series(
        self,
        series: list[AggregateSeries],
        lane_height: int,
        width: int,
        dpr: float,
        display_mode: str,
        range_override: tuple[float, float] | None = None,
    ) -> RenderPayload:
        full_minimum, full_maximum = self._global_range(series)
        global_minimum, global_maximum = range_override or self._select_display_range(series, display_mode)
        show_edge_markers = self._display_range_mode_key(display_mode) == "robust_marked"
        width = self._safe_canvas_width(width)
        height = self._top_margin * 2 + len(series) * lane_height
        image, painter = self._make_image(width, height, dpr)
        image.fill(self._colors["background"])
        plot_rect = QRectF(
            float(self._label_margin),
            float(self._top_margin),
            float(width - self._label_margin - self._right_margin),
            float(height - self._top_margin * 2),
        )
        hover_points: list[HoverPoint] = []
        lane_bands: list[tuple[float, float]] = []
        clipped_low_count = 0
        clipped_high_count = 0
        self._draw_x_grid(painter, plot_rect, global_minimum, global_maximum)
        painter.save()
        painter.setClipRect(plot_rect.adjusted(0, 0, -1, -1))
        bins = 34
        for index, item in enumerate(series):
            lane_top = plot_rect.top() + lane_height * index
            lane_bands.append((lane_top, float(lane_height)))
            baseline_y = plot_rect.top() + lane_height * index + lane_height * 0.66
            current_minimum = global_minimum
            current_maximum = global_maximum
            painter.setPen(QPen(self._colors["grid"], 0.7))
            painter.drawLine(QPointF(plot_rect.left(), baseline_y), QPointF(plot_rect.right(), baseline_y))
            counts = [0.0] * bins
            for point in item.points:
                clipped_value = min(max(point.value, current_minimum), current_maximum)
                ratio = (clipped_value - current_minimum) / max(current_maximum - current_minimum, 1e-9)
                bucket = max(0, min(bins - 1, int(ratio * (bins - 1))))
                counts[bucket] += 1.0
            smoothed = _moving_average(counts, radius=2)
            peak = max(smoothed) or 1.0
            ridge_height = lane_height * 0.52
            polygon: list[QPointF] = [QPointF(plot_rect.left(), baseline_y)]
            for bucket, density in enumerate(smoothed):
                x = plot_rect.left() + plot_rect.width() * bucket / max(bins - 1, 1)
                y = baseline_y - ridge_height * (density / peak)
                polygon.append(QPointF(x, y))
            polygon.append(QPointF(plot_rect.right(), baseline_y))
            path = QPainterPath()
            path.moveTo(polygon[0])
            for point in polygon[1:]:
                path.lineTo(point)
            path.closeSubpath()
            painter.setPen(QPen(self._colors["ink"], 0.85))
            painter.setBrush(self._colors["fill"])
            painter.drawPath(path)
            for point in item.points:
                clipped = False
                display_value = point.value
                if point.value < current_minimum:
                    clipped_low_count += 1
                    display_value = current_minimum
                    clipped = True
                elif point.value > current_maximum:
                    clipped_high_count += 1
                    display_value = current_maximum
                    clipped = True
                display_x = self._map_x(display_value, plot_rect, current_minimum, current_maximum)
                if show_edge_markers and clipped:
                    if point.value < current_minimum:
                        display_x = plot_rect.left() + 4.0
                    else:
                        display_x = plot_rect.right() - 4.0
                position = QPointF(
                    display_x,
                    baseline_y + (_stable_unit(point.sample_id, item.aggregate_id) - 0.5) * lane_height * 0.22,
                )
                radius = 1.2 if not point.outlier else 1.7
                if point.outlier:
                    painter.setPen(QPen(self._colors["outlier_edge"], 0.8))
                    painter.setBrush(self._colors["outlier_fill"])
                else:
                    painter.setPen(QPen(self._colors["point_edge"], 0.6))
                    painter.setBrush(self._colors["point_fill"])
                if show_edge_markers and clipped:
                    direction = -1.0 if point.value < current_minimum else 1.0
                    path = QPainterPath()
                    path.moveTo(position + QPointF(direction * 4.5, 0.0))
                    path.lineTo(position + QPointF(-direction * 3.2, -2.8))
                    path.lineTo(position + QPointF(-direction * 3.2, 2.8))
                    path.closeSubpath()
                    painter.drawPath(path)
                else:
                    painter.drawEllipse(position, radius, radius)
                hover_points.append(HoverPoint(point=point, position=position, radius=radius))
        painter.restore()
        painter.setPen(self._colors["muted"])
        for index, item in enumerate(series):
            baseline_y = plot_rect.top() + lane_height * index + lane_height * 0.66
            painter.drawText(
                QRectF(8.0, baseline_y - 8.0, float(self._label_margin - 16), 16.0),
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                item.label,
            )
        painter.end()
        return RenderPayload(
            image=image,
            hover_points=tuple(hover_points),
            hover_buckets=self._build_hover_buckets(hover_points),
            labels=tuple(item.label for item in series),
            lane_bands=tuple(lane_bands),
            label_margin=self._label_margin,
            minimum=global_minimum,
            maximum=global_maximum,
            aggregate_count=len(series),
            point_count=sum(len(item.points) for item in series),
            outlier_count=sum(sum(1 for point in item.points if point.outlier) for item in series),
            clipped_low_count=clipped_low_count if global_minimum != full_minimum else 0,
            clipped_high_count=clipped_high_count if global_maximum != full_maximum else 0,
        )

    def render_x_ruler(self, width: int, minimum: float, maximum: float, visible_height: int, dpr: float) -> QPixmap:
        width = self._safe_canvas_width(width)
        height = max(40, visible_height)
        image, painter = self._make_image(width, height, dpr)
        image.fill(self._colors["background"])
        axis_rect = QRectF(
            float(self._label_margin),
            22.0,
            float(width - self._label_margin - self._right_margin),
            14.0,
        )
        painter.setPen(QPen(self._colors["ink"], 1.0))
        painter.drawLine(QPointF(axis_rect.left(), axis_rect.top() + axis_rect.height() / 2.0), QPointF(axis_rect.right(), axis_rect.top() + axis_rect.height() / 2.0))
        painter.setPen(self._colors["muted"])
        for index in range(5):
            ratio = index / 4.0
            x = axis_rect.left() + axis_rect.width() * ratio
            painter.setPen(QPen(self._colors["grid"], 0.8))
            axis_y = axis_rect.top() + axis_rect.height() / 2.0
            painter.drawLine(QPointF(x, axis_y - 3.0), QPointF(x, axis_y + 12.0))
            painter.setPen(self._colors["muted"])
            value = minimum + (maximum - minimum) * ratio
            text_width = 56.0
            left = min(max(0.0, x - text_width / 2.0), float(width) - text_width)
            painter.drawText(
                QRectF(left, 2.0, text_width, 18.0),
                Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignBottom,
                f"{value:.1f}",
            )
        painter.end()
        return self._image_to_pixmap(image)

    @staticmethod
    def _global_range(series: list[AggregateSeries]) -> tuple[float, float]:
        values = [point.value for item in series for point in item.points]
        minimum = min(values)
        maximum = max(values)
        if math.isclose(minimum, maximum):
            minimum -= 1.0
            maximum += 1.0
        span = maximum - minimum
        return minimum - span * 0.06, maximum + span * 0.06

    def _select_display_range(self, series: list[AggregateSeries], display_mode: str) -> tuple[float, float]:
        full_minimum, full_maximum = self._global_range(series)
        if self._display_range_mode_key(display_mode) == "full":
            return full_minimum, full_maximum
        values = sorted(point.value for item in series for point in item.points)
        low = _quantile(values, 0.01)
        high = _quantile(values, 0.99)
        if math.isclose(low, high):
            return full_minimum, full_maximum
        span = high - low
        robust_minimum = low - span * 0.08
        robust_maximum = high + span * 0.08
        return robust_minimum, robust_maximum

    @staticmethod
    def _series_range(item: AggregateSeries) -> tuple[float, float]:
        values = [point.value for point in item.points]
        minimum = min(values)
        maximum = max(values)
        if math.isclose(minimum, maximum):
            minimum -= 1.0
            maximum += 1.0
        span = maximum - minimum
        return minimum - span * 0.05, maximum + span * 0.05

    @staticmethod
    def _map_y(value: float, plot_rect: QRectF, minimum: float, maximum: float) -> float:
        ratio = (value - minimum) / max(maximum - minimum, 1e-9)
        return plot_rect.bottom() - plot_rect.height() * ratio

    @staticmethod
    def _map_x(value: float, plot_rect: QRectF, minimum: float, maximum: float) -> float:
        ratio = (value - minimum) / max(maximum - minimum, 1e-9)
        return plot_rect.left() + plot_rect.width() * ratio

    def _draw_x_grid(self, painter: QPainter, plot_rect: QRectF, minimum: float, maximum: float) -> None:
        for index in range(5):
            ratio = index / 4.0
            x = plot_rect.left() + plot_rect.width() * ratio
            painter.setPen(QPen(self._colors["grid"], 0.8))
            painter.drawLine(QPointF(x, plot_rect.top()), QPointF(x, plot_rect.bottom()))

    @staticmethod
    def _build_hover_buckets(points: list[HoverPoint]) -> dict[tuple[int, int], list[HoverPoint]]:
        buckets: dict[tuple[int, int], list[HoverPoint]] = defaultdict(list)
        bucket_size = 24
        for point in points:
            key = (int(point.position.x() // bucket_size), int(point.position.y() // bucket_size))
            buckets[key].append(point)
        return dict(buckets)


class HoverImageLabel(QLabel):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setMouseTracking(True)
        self.setAttribute(Qt.WidgetAttribute.WA_Hover, True)
        self._payload: RenderPayload | None = None
        self._highlight_point: HoverPoint | None = None
        self._search_band: QRectF | None = None

    def bind_payload(self, payload: RenderPayload) -> None:
        self._payload = payload
        self._highlight_point = None
        self._search_band = None
        pixmap = QPixmap.fromImage(payload.image)
        pixmap.setDevicePixelRatio(payload.image.devicePixelRatio())
        self.setPixmap(pixmap)
        self.resize(payload.logical_size())

    def current_payload(self) -> RenderPayload | None:
        return self._payload

    def leaveEvent(self, event) -> None:  # type: ignore[override]
        QToolTip.hideText()
        super().leaveEvent(event)

    def mouseMoveEvent(self, event) -> None:  # type: ignore[override]
        payload = self._payload
        if payload is None:
            super().mouseMoveEvent(event)
            return
        bucket_size = 24
        base_x = int(event.position().x() // bucket_size)
        base_y = int(event.position().y() // bucket_size)
        best_hit: HoverPoint | None = None
        best_distance = 12.0
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for item in payload.hover_buckets.get((base_x + dx, base_y + dy), []):
                    distance = math.hypot(item.position.x() - event.position().x(), item.position.y() - event.position().y())
                    if distance <= item.radius + 5.0 and distance < best_distance:
                        best_hit = item
                        best_distance = distance
        if best_hit is None:
            QToolTip.hideText()
        else:
            point = best_hit.point
            QToolTip.showText(
                event.globalPosition().toPoint(),
                (
                    f"{point.aggregate_id}\n"
                    f"{point.sample_id}\n"
                    f"value: {point.value:.3f}\n"
                    f"metric: {point.metric}\n"
                    f"dataset_id: {point.dataset_id}\n"
                    f"row_number: {point.row_number}\n"
                    f"outlier: {'yes' if point.outlier else 'no'}"
                ),
                self,
            )
        super().mouseMoveEvent(event)

    def set_highlight_point(self, point: HoverPoint | None) -> None:
        if self._highlight_point == point:
            return
        self._highlight_point = point
        self.update()

    def set_search_highlight(self, band: QRectF | None) -> None:
        if self._search_band == band:
            return
        self._search_band = band
        self.update()

    def paintEvent(self, event) -> None:  # type: ignore[override]
        super().paintEvent(event)
        search_band = self._search_band
        if search_band is not None:
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            band = QRectF(search_band)
            painter.fillRect(band, QColor(46, 94, 70, 22))
            painter.fillRect(QRectF(band.left(), band.top(), 4.0, band.height()), QColor("#1f5c4a"))
            painter.end()
        highlight = self._highlight_point
        if highlight is None:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        center = highlight.position
        ring_radius = max(highlight.radius + 4.5, 6.0)
        painter.setPen(QPen(QColor("#1f5c4a"), 2.2))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawEllipse(center, ring_radius, ring_radius)
        painter.end()


class AxisOverlay(QWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._pixmap: QPixmap | None = None

    def bind_pixmap(self, pixmap: QPixmap) -> None:
        self._pixmap = pixmap
        self.update()

    def paintEvent(self, event) -> None:  # type: ignore[override]
        pixmap = self._pixmap
        if pixmap is None:
            return
        painter = QPainter(self)
        painter.drawPixmap(0, 0, pixmap)
        painter.end()


class AdaptiveRenderWorker(QObject):
    finished = Signal(int, object)
    failed = Signal(int, str)

    def __init__(
        self,
        request_id: int,
        mode: str,
        series: list[AggregateSeries],
        lane_height: int,
        width: int,
        dpr: float,
        display_mode: str,
    ) -> None:
        super().__init__()
        self._request_id = request_id
        self._mode = mode
        self._series = series
        self._lane_height = lane_height
        self._width = width
        self._dpr = dpr
        self._display_mode = display_mode

    @Slot()
    def run(self) -> None:
        try:
            renderer = ComparisonRenderer()
            if self._mode == "Box Plot":
                payload = renderer.render_box_series(
                    self._series,
                    lane_height=self._lane_height,
                    width=self._width,
                    dpr=self._dpr,
                    display_mode=self._display_mode,
                )
            else:
                payload = renderer.render_ridge_series(
                    self._series,
                    lane_height=self._lane_height,
                    width=self._width,
                    dpr=self._dpr,
                    display_mode=self._display_mode,
                )
            self.finished.emit(self._request_id, payload)
        except Exception as exc:
            self.failed.emit(self._request_id, str(exc))

class ContinuousComparisonWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self._renderer = ComparisonRenderer()
        self._current_box_payload: RenderPayload | None = None
        self._current_ridge_payload: RenderPayload | None = None
        self._axis_overlay_height = 42
        self._lane_height = 28
        self._search_matches: list[int] = []
        self._search_match_cursor = -1
        self._search_completer_model = QStringListModel(self)
        self._adaptive_render_request_id = 0
        self._adaptive_render_threads: list[QThread] = []
        self._adaptive_render_workers: list[AdaptiveRenderWorker] = []
        self._adaptive_render_apply_scroll: dict[int, bool] = {}
        self._suspend_viewport_resize_refresh = False
        self._startup_render_done = False
        self._startup_attempts = 0
        self._resize_render_timer = QTimer(self)
        self._resize_render_timer.setSingleShot(True)
        self._search_debounce_timer = QTimer(self)
        self._search_debounce_timer.setSingleShot(True)
        self._build_ui()
        self._wire_events()
        self._resize_render_timer.timeout.connect(self._render_if_ready)
        self._search_debounce_timer.timeout.connect(self._run_debounced_search)
        app = QApplication.instance()
        if app is not None:
            app.applicationStateChanged.connect(self._on_application_state_changed)
            app.aboutToQuit.connect(self._stop_adaptive_render_threads)

    def _build_ui(self) -> None:
        self.ui = Ui_ContinuousComparisonWindow()
        self.ui.setupUi(self)
        self.mode_combo = self.ui.mode_combo
        self.metric_combo = self.ui.metric_combo
        self.count_combo = self.ui.count_combo
        self.display_combo = self.ui.display_combo
        self.export_button = self.ui.export_button
        self.search_input = self.ui.search_input
        self.search_input.installEventFilter(self)
        self.search_view_combo = self.ui.search_view_combo
        self.compact_range_checkbox = self.ui.compact_range_checkbox
        self.realtime_render_checkbox = self.ui.realtime_render_checkbox
        self.refresh_search_button = self.ui.refresh_search_button
        self.search_completer = QCompleter(self._search_completer_model, self)
        self.search_completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.search_completer.setFilterMode(Qt.MatchFlag.MatchContains)
        self.search_completer.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        self.search_input.setCompleter(self.search_completer)
        self.search_prev_button = self.ui.search_prev_button
        self.search_next_button = self.ui.search_next_button
        self.search_status_label = self.ui.search_status_label
        status_bar = self.statusBar()
        self.render_status_label = QLabel("Ready", status_bar)
        self.render_status_label.setStyleSheet("padding-left: 8px;")
        self.render_progress = QProgressBar(status_bar)
        self.render_progress.setFixedWidth(180)
        self.render_progress.setFixedHeight(14)
        self.render_progress.setTextVisible(False)
        self.render_progress.setRange(0, 1)
        self.render_progress.setValue(0)
        self.render_progress.setEnabled(False)
        status_bar.addWidget(self.render_status_label, 1)
        status_bar.addPermanentWidget(self.render_progress)
        self.plot_stack = self.ui.plot_stack
        self.box_container = self.ui.box_page
        self.ridge_container = self.ui.ridge_page
        self.box_scroll = self.ui.box_scroll
        self.box_scroll.setViewportMargins(0, self._axis_overlay_height, 0, 0)
        self.box_scroll.viewport().setMouseTracking(True)
        self.box_scroll.viewport().installEventFilter(self)
        old_box_content = self.box_scroll.takeWidget()
        if old_box_content is not None:
            old_box_content.deleteLater()
        self.box_content = HoverImageLabel()
        self.box_content.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.box_scroll.setWidget(self.box_content)
        self.box_axis_overlay = AxisOverlay(self.box_scroll)
        self.ridge_scroll = self.ui.ridge_scroll
        self.ridge_scroll.setViewportMargins(0, self._axis_overlay_height, 0, 0)
        self.ridge_scroll.viewport().setMouseTracking(True)
        self.ridge_scroll.viewport().installEventFilter(self)
        old_ridge_content = self.ridge_scroll.takeWidget()
        if old_ridge_content is not None:
            old_ridge_content.deleteLater()
        self.ridge_content = HoverImageLabel()
        self.ridge_content.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.ridge_scroll.setWidget(self.ridge_content)
        self.ridge_axis_overlay = AxisOverlay(self.ridge_scroll)

    def _wire_events(self) -> None:
        self.mode_combo.currentTextChanged.connect(self._queue_render_refresh)
        self.metric_combo.currentTextChanged.connect(self._queue_render_refresh)
        self.count_combo.currentTextChanged.connect(self._queue_render_refresh)
        self.display_combo.currentTextChanged.connect(self._queue_render_refresh)
        self.search_input.returnPressed.connect(self._refresh_search_results)
        self.search_input.textChanged.connect(self._on_search_text_changed)
        self.search_completer.activated.connect(self._on_search_completion_activated)
        self.search_view_combo.currentTextChanged.connect(self._on_search_view_changed)
        self.compact_range_checkbox.stateChanged.connect(self._on_search_view_changed)
        self.realtime_render_checkbox.stateChanged.connect(self._on_realtime_render_changed)
        self.refresh_search_button.clicked.connect(self._refresh_search_results)
        self.search_prev_button.clicked.connect(self._select_previous_search_match)
        self.search_next_button.clicked.connect(self._select_next_search_match)
        self.export_button.clicked.connect(self._export_preview)

    def _active_scroll_area(self) -> QScrollArea:
        return self.box_scroll if self.mode_combo.currentText() == "Box Plot" else self.ridge_scroll

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        super().resizeEvent(event)
        if self._startup_render_done:
            self._resize_render_timer.start(40)

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)
        QTimer.singleShot(0, self._request_window_activation)
        QTimer.singleShot(120, self._begin_startup_activation)

    def _queue_render_refresh(self) -> None:
        if not self._startup_render_done:
            self._begin_startup_activation()
            return
        self._resize_render_timer.start(20)

    def _render_if_ready(self) -> None:
        if not self.isVisible():
            return
        self._render_current_mode()

    def _render_current_mode(self) -> None:
        mode = self.mode_combo.currentText()
        metric = self.metric_combo.currentText()
        count = int(self.count_combo.currentText())
        display_mode = self.display_combo.currentText()
        dpr = self.devicePixelRatioF()
        source_scroll = self._visible_scroll_area()
        preserved_vertical_value = source_scroll.verticalScrollBar().value() if source_scroll is not None else 0
        if mode == "Box Plot":
            self.plot_stack.setCurrentWidget(self.box_container)
            width = self.box_scroll.viewport().width()
            payload = self._renderer.render_box(
                metric,
                count,
                lane_height=self._lane_height,
                width=width,
                dpr=dpr,
                display_mode=display_mode,
            )
            self._current_box_payload = payload
            self.box_content.bind_payload(payload)
            self.box_content.move(0, 0)
            self._restore_scroll_position(self.box_scroll, preserved_vertical_value)
            ruler = self._renderer.render_x_ruler(
                width=payload.logical_size().width(),
                minimum=payload.minimum,
                maximum=payload.maximum,
                visible_height=self._axis_overlay_height,
                dpr=dpr,
            )
            self.box_axis_overlay.bind_pixmap(ruler)
            self._position_axis_overlay(self.box_scroll, self.box_axis_overlay)
            self._update_search_completions(payload)
            self._sync_search_state(apply_scroll=False)
            self._refresh_hover_under_cursor()
        else:
            self.plot_stack.setCurrentWidget(self.ridge_container)
            width = self.ridge_scroll.viewport().width()
            payload = self._renderer.render_ridge(
                metric,
                count,
                lane_height=self._lane_height,
                width=width,
                dpr=dpr,
                display_mode=display_mode,
            )
            self._current_ridge_payload = payload
            self.ridge_content.bind_payload(payload)
            self.ridge_content.move(0, 0)
            self._restore_scroll_position(self.ridge_scroll, preserved_vertical_value)
            ruler = self._renderer.render_x_ruler(
                width=payload.logical_size().width(),
                minimum=payload.minimum,
                maximum=payload.maximum,
                visible_height=self._axis_overlay_height,
                dpr=dpr,
            )
            self.ridge_axis_overlay.bind_pixmap(ruler)
            self._position_axis_overlay(self.ridge_scroll, self.ridge_axis_overlay)
            self._update_search_completions(payload)
            self._sync_search_state(apply_scroll=False)
            self._refresh_hover_under_cursor()

    def _request_window_activation(self) -> None:
        handle = self.windowHandle()
        if handle is not None:
            handle.requestActivate()
        self.raise_()
        self.activateWindow()
        target_scroll = self.box_scroll if self.mode_combo.currentText() == "Box Plot" else self.ridge_scroll
        target_scroll.viewport().setFocus(Qt.FocusReason.ActiveWindowFocusReason)

    def _begin_startup_activation(self) -> None:
        if self._startup_render_done:
            return
        self._startup_attempts += 1
        self._request_window_activation()
        if self.isActiveWindow() or self._startup_attempts >= 10:
            self._startup_render_done = True
            self._render_current_mode()
            active_content = self.box_content if self.mode_combo.currentText() == "Box Plot" else self.ridge_content
            active_scroll = self.box_scroll if self.mode_combo.currentText() == "Box Plot" else self.ridge_scroll
            active_content.update()
            active_scroll.viewport().update()
            self._refresh_hover_under_cursor()
        else:
            QTimer.singleShot(120, self._begin_startup_activation)

    def _on_application_state_changed(self, state) -> None:
        if state == Qt.ApplicationState.ApplicationActive and not self._startup_render_done:
            self._begin_startup_activation()
        elif state == Qt.ApplicationState.ApplicationActive:
            self._refresh_hover_under_cursor()

    def _visible_scroll_area(self) -> QScrollArea | None:
        if self.plot_stack.currentWidget() == self.box_container:
            return self.box_scroll
        if self.plot_stack.currentWidget() == self.ridge_container:
            return self.ridge_scroll
        return None

    def _active_base_payload(self) -> RenderPayload | None:
        if self.mode_combo.currentText() == "Box Plot":
            return self._current_box_payload
        return self._current_ridge_payload

    def _active_display_payload(self) -> RenderPayload | None:
        return self._active_content().current_payload()

    def _active_content(self) -> HoverImageLabel:
        return self.box_content if self.mode_combo.currentText() == "Box Plot" else self.ridge_content

    @staticmethod
    def _restore_scroll_position(scroll_area: QScrollArea, desired_value: int) -> None:
        scrollbar = scroll_area.verticalScrollBar()
        scrollbar.setValue(max(scrollbar.minimum(), min(desired_value, scrollbar.maximum())))

    def _on_search_text_changed(self) -> None:
        self._cancel_pending_adaptive_render()
        if self.realtime_render_checkbox.isChecked():
            self._search_debounce_timer.start(180)

    def _run_debounced_search(self) -> None:
        self._sync_search_state(apply_scroll=True, reset_to_first=True)

    def _refresh_search_results(self) -> None:
        self._search_debounce_timer.stop()
        self._sync_search_state(apply_scroll=True, reset_to_first=True)

    def _on_realtime_render_changed(self, *args: object) -> None:
        if self.realtime_render_checkbox.isChecked():
            self._refresh_search_results()
        else:
            self._search_debounce_timer.stop()
            self._cancel_pending_adaptive_render()

    def _on_search_completion_activated(self, text: str) -> None:
        self._search_debounce_timer.stop()
        self.search_input.setText(text)
        self._sync_search_state(apply_scroll=True, reset_to_first=True)

    def _on_search_view_changed(self, *args: object) -> None:
        self._sync_search_state(apply_scroll=False, reset_to_first=False)

    def _select_next_search_match(self) -> None:
        self._advance_search_match(1)

    def _select_previous_search_match(self) -> None:
        self._advance_search_match(-1)

    def _advance_search_match(self, step: int) -> None:
        if not self._search_matches:
            self._sync_search_state(apply_scroll=False, reset_to_first=True)
            return
        self._search_match_cursor = (self._search_match_cursor + step) % len(self._search_matches)
        self._apply_search_selection(apply_scroll=True)

    def _sync_search_state(self, apply_scroll: bool, reset_to_first: bool = False) -> None:
        payload = self._active_base_payload()
        query = self.search_input.text().strip().lower()
        if payload is None:
            return
        if not query:
            self._search_matches = []
            self._search_match_cursor = -1
            self._cancel_pending_adaptive_render()
            self._bind_active_display_payload(payload)
            self._update_active_axis_overlay(payload)
            self.box_content.set_search_highlight(None)
            self.ridge_content.set_search_highlight(None)
            self.search_status_label.setText("0 / 0")
            self.search_prev_button.setEnabled(False)
            self.search_next_button.setEnabled(False)
            return
        labels = payload.labels
        self._search_matches = [index for index, label in enumerate(labels) if query in label.lower()]
        if not self._search_matches:
            self._search_match_cursor = -1
            self._cancel_pending_adaptive_render()
            self._bind_active_display_payload(payload)
            self._update_active_axis_overlay(payload)
            self.box_content.set_search_highlight(None)
            self.ridge_content.set_search_highlight(None)
            self.search_status_label.setText("0 / 0")
            self.search_prev_button.setEnabled(False)
            self.search_next_button.setEnabled(False)
            return
        if reset_to_first or self._search_match_cursor < 0 or self._search_match_cursor >= len(self._search_matches):
            self._search_match_cursor = 0
        self.search_prev_button.setEnabled(len(self._search_matches) > 1)
        self.search_next_button.setEnabled(len(self._search_matches) > 1)
        self._apply_search_selection(apply_scroll=apply_scroll)

    def _apply_search_selection(self, apply_scroll: bool) -> None:
        base_payload = self._active_base_payload()
        if base_payload is None or not self._search_matches or self._search_match_cursor < 0:
            self._cancel_pending_adaptive_render()
            self.box_content.set_search_highlight(None)
            self.ridge_content.set_search_highlight(None)
            self.search_status_label.setText("0 / 0")
            return
        compact_mode = self.search_view_combo.currentText() == "Compact Results" and bool(self.search_matches_query())
        adaptive_mode = compact_mode and self.compact_range_checkbox.isChecked()
        if adaptive_mode:
            self.search_status_label.setText(f"{self._search_match_cursor + 1} / {len(self._search_matches)}")
            self.box_content.set_search_highlight(None)
            self.ridge_content.set_search_highlight(None)
            self._request_adaptive_compact_payload(base_payload, self._search_matches, apply_scroll)
            return
        display_payload = self._build_compact_payload(base_payload, self._search_matches) if compact_mode else base_payload
        self._bind_active_display_payload(display_payload)
        self._update_active_axis_overlay(display_payload)
        row_index = self._search_match_cursor if compact_mode else self._search_matches[self._search_match_cursor]
        payload = display_payload
        lane_top, lane_height = payload.lane_bands[row_index]
        band = QRectF(
            0.0,
            lane_top,
            float(payload.logical_size().width()),
            lane_height,
        )
        self.box_content.set_search_highlight(None)
        self.ridge_content.set_search_highlight(None)
        self._active_content().set_search_highlight(band)
        self.search_status_label.setText(f"{self._search_match_cursor + 1} / {len(self._search_matches)}")
        if apply_scroll:
            self._scroll_to_row_index(self._active_scroll_area(), payload, row_index)
        if adaptive_mode:
            self._request_adaptive_compact_payload(base_payload, self._search_matches, apply_scroll)
        else:
            self._cancel_pending_adaptive_render()

    def search_matches_query(self) -> str:
        return self.search_input.text().strip()

    def _scroll_to_row_index(self, scroll_area: QScrollArea, payload: RenderPayload, row_index: int) -> None:
        if row_index < 0 or row_index >= len(payload.lane_bands):
            return
        lane_top, lane_height = payload.lane_bands[row_index]
        target_center = lane_top + lane_height / 2.0
        viewport_height = scroll_area.viewport().height()
        desired_value = int(round(target_center - viewport_height / 2.0))
        self._restore_scroll_position(scroll_area, desired_value)

    def _bind_active_display_payload(self, payload: RenderPayload) -> None:
        content = self._active_content()
        if content.current_payload() is payload:
            return
        scroll_area = self._active_scroll_area()
        preserved_value = scroll_area.verticalScrollBar().value()
        self._suspend_viewport_resize_refresh = True
        content.bind_payload(payload)
        content.move(0, 0)
        self._restore_scroll_position(scroll_area, preserved_value)
        QTimer.singleShot(0, self._resume_viewport_resize_refresh)

    def _resume_viewport_resize_refresh(self) -> None:
        self._suspend_viewport_resize_refresh = False

    def _update_active_axis_overlay(self, payload: RenderPayload) -> None:
        ruler = self._renderer.render_x_ruler(
            width=payload.logical_size().width(),
            minimum=payload.minimum,
            maximum=payload.maximum,
            visible_height=self._axis_overlay_height,
            dpr=self.devicePixelRatioF(),
        )
        if self.mode_combo.currentText() == "Box Plot":
            self.box_axis_overlay.bind_pixmap(ruler)
            self._position_axis_overlay(self.box_scroll, self.box_axis_overlay)
        else:
            self.ridge_axis_overlay.bind_pixmap(ruler)
            self._position_axis_overlay(self.ridge_scroll, self.ridge_axis_overlay)

    def _update_search_completions(self, payload: RenderPayload) -> None:
        ordered_unique: list[str] = []
        seen: set[str] = set()
        for label in payload.labels:
            if label not in seen:
                seen.add(label)
                ordered_unique.append(label)
        self._search_completer_model.setStringList(ordered_unique)

    def _build_compact_payload(self, payload: RenderPayload, matches: list[int]) -> RenderPayload:
        if not matches:
            return payload
        source_size = payload.logical_size()
        dpr = payload.image.devicePixelRatio()
        top_margin = payload.lane_bands[0][0] if payload.lane_bands else 0.0
        lane_height = payload.lane_bands[0][1] if payload.lane_bands else float(self._lane_height)
        width = source_size.width()
        height = int(round(top_margin * 2.0 + lane_height * len(matches)))
        image, painter = self._renderer._make_image(width, height, dpr)
        image.fill(self._renderer._colors["background"])
        new_hover_points: list[HoverPoint] = []
        new_lane_bands: list[tuple[float, float]] = []
        label_list: list[str] = []
        for compact_index, base_index in enumerate(matches):
            old_top, old_height = payload.lane_bands[base_index]
            new_top = top_margin + compact_index * old_height
            painter.drawImage(
                QRectF(0.0, new_top, float(width), old_height),
                payload.image,
                QRectF(0.0, old_top * dpr, float(width) * dpr, old_height * dpr),
            )
            label_list.append(payload.labels[base_index])
            new_lane_bands.append((new_top, old_height))
            y_offset = new_top - old_top
            lane_bottom = old_top + old_height
            for hover_point in payload.hover_points:
                y = hover_point.position.y()
                if old_top <= y < lane_bottom:
                    new_hover_points.append(
                        HoverPoint(
                            point=hover_point.point,
                            position=QPointF(hover_point.position.x(), hover_point.position.y() + y_offset),
                            radius=hover_point.radius,
                        )
                    )
        painter.end()
        clipped_low_count = sum(1 for item in new_hover_points if item.point.value < payload.minimum)
        clipped_high_count = sum(1 for item in new_hover_points if item.point.value > payload.maximum)
        return RenderPayload(
            image=image,
            hover_points=tuple(new_hover_points),
            hover_buckets=self._renderer._build_hover_buckets(new_hover_points),
            labels=tuple(label_list),
            lane_bands=tuple(new_lane_bands),
            label_margin=payload.label_margin,
            minimum=payload.minimum,
            maximum=payload.maximum,
            aggregate_count=len(label_list),
            point_count=len(new_hover_points),
            outlier_count=sum(1 for item in new_hover_points if item.point.outlier),
            clipped_low_count=clipped_low_count,
            clipped_high_count=clipped_high_count,
        )

    def _request_adaptive_compact_payload(self, payload: RenderPayload, matches: list[int], apply_scroll: bool) -> None:
        series = self._series_from_matches(payload, matches)
        if not series:
            self._cancel_pending_adaptive_render()
            return
        self._adaptive_render_request_id += 1
        request_id = self._adaptive_render_request_id
        self._adaptive_render_apply_scroll[request_id] = apply_scroll
        source_size = payload.logical_size()
        lane_height = int(round(payload.lane_bands[0][1])) if payload.lane_bands else self._lane_height
        worker = AdaptiveRenderWorker(
            request_id=request_id,
            mode=self.mode_combo.currentText(),
            series=series,
            lane_height=lane_height,
            width=source_size.width(),
            dpr=payload.image.devicePixelRatio(),
            display_mode=self.display_combo.currentText(),
        )
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.finished.connect(self._on_adaptive_render_finished)
        worker.failed.connect(self._on_adaptive_render_failed)
        worker.finished.connect(worker.deleteLater)
        worker.failed.connect(worker.deleteLater)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(lambda thread=thread: self._adaptive_render_threads.remove(thread) if thread in self._adaptive_render_threads else None)
        thread.finished.connect(lambda worker=worker: self._adaptive_render_workers.remove(worker) if worker in self._adaptive_render_workers else None)
        self._adaptive_render_threads.append(thread)
        self._adaptive_render_workers.append(worker)
        self._set_render_busy(True)
        thread.start()

    def _cancel_pending_adaptive_render(self) -> None:
        self._adaptive_render_request_id += 1
        self._adaptive_render_apply_scroll.clear()
        self._set_render_busy(False)

    def _stop_adaptive_render_threads(self) -> None:
        self._adaptive_render_request_id += 1
        self._adaptive_render_apply_scroll.clear()
        self._set_render_busy(False)
        for thread in list(self._adaptive_render_threads):
            if thread.isRunning():
                thread.quit()
                thread.wait(1500)
        self._adaptive_render_workers.clear()

    def _set_render_busy(self, busy: bool) -> None:
        if busy:
            self.render_status_label.setText("Rendering...")
            self.render_progress.setEnabled(True)
            self.render_progress.setRange(0, 0)
        else:
            self.render_status_label.setText("Ready")
            self.render_progress.setRange(0, 1)
            self.render_progress.setValue(0)
            self.render_progress.setEnabled(False)

    @Slot(int, object)
    def _on_adaptive_render_finished(self, request_id: int, payload: RenderPayload) -> None:
        apply_scroll = self._adaptive_render_apply_scroll.pop(request_id, False)
        if request_id != self._adaptive_render_request_id:
            return
        self._set_render_busy(False)
        if self.search_view_combo.currentText() != "Compact Results" or not self.compact_range_checkbox.isChecked():
            return
        if not self._search_matches or self._search_match_cursor < 0:
            return
        self._bind_active_display_payload(payload)
        self._update_active_axis_overlay(payload)
        row_index = min(self._search_match_cursor, len(payload.lane_bands) - 1)
        if row_index < 0:
            return
        lane_top, lane_height = payload.lane_bands[row_index]
        band = QRectF(0.0, lane_top, float(payload.logical_size().width()), lane_height)
        self.box_content.set_search_highlight(None)
        self.ridge_content.set_search_highlight(None)
        self._active_content().set_search_highlight(band)
        if apply_scroll:
            self._scroll_to_row_index(self._active_scroll_area(), payload, row_index)
        self._refresh_hover_under_cursor()

    @Slot(int, str)
    def _on_adaptive_render_failed(self, request_id: int, message: str) -> None:
        self._adaptive_render_apply_scroll.pop(request_id, None)
        if request_id == self._adaptive_render_request_id:
            self._set_render_busy(False)
            self.render_status_label.setText(f"Render failed: {message}")

    def _series_from_matches(self, payload: RenderPayload, matches: list[int]) -> list[AggregateSeries]:
        series: list[AggregateSeries] = []
        for index in matches:
            lane_top, lane_height = payload.lane_bands[index]
            lane_bottom = lane_top + lane_height
            points = tuple(
                hover_point.point
                for hover_point in payload.hover_points
                if lane_top <= hover_point.position.y() < lane_bottom
            )
            if not points:
                continue
            series.append(
                AggregateSeries(
                    aggregate_id=points[0].aggregate_id,
                    label=payload.labels[index],
                    metric=points[0].metric,
                    points=points,
                )
            )
        return series

    def eventFilter(self, watched: object, event: QEvent) -> bool:
        if watched == getattr(self, "search_input", None) and event.type() == QEvent.Type.KeyPress:
            key = event.key()
            if key == Qt.Key.Key_Up:
                self._select_previous_search_match()
                return True
            if key == Qt.Key.Key_Down:
                self._select_next_search_match()
                return True
        box_viewport = getattr(self, "box_scroll", None)
        ridge_viewport = getattr(self, "ridge_scroll", None)
        watched_viewports = tuple(
            viewport.viewport()
            for viewport in (box_viewport, ridge_viewport)
            if viewport is not None
        )
        if watched in watched_viewports:
            if event.type() == QEvent.Type.Resize:
                if watched == self.box_scroll.viewport():
                    self._position_axis_overlay(self.box_scroll, self.box_axis_overlay)
                elif watched == self.ridge_scroll.viewport():
                    self._position_axis_overlay(self.ridge_scroll, self.ridge_axis_overlay)
                if (
                    self._startup_render_done
                    and not self._suspend_viewport_resize_refresh
                    and watched == self._active_scroll_area().viewport()
                ):
                    self._resize_render_timer.start(0)
            elif event.type() in (QEvent.Type.MouseMove, QEvent.Type.MouseButtonPress):
                self._handle_viewport_hover(watched, event)
            elif event.type() == QEvent.Type.Leave:
                self.box_content.set_highlight_point(None)
                self.ridge_content.set_highlight_point(None)
                QToolTip.hideText()
        return super().eventFilter(watched, event)

    def _handle_viewport_hover(self, watched: object, event: QEvent) -> None:
        if not self._startup_render_done:
            return
        if watched == self.box_scroll.viewport():
            scroll_area = self.box_scroll
            content = self.box_content
        else:
            scroll_area = self.ridge_scroll
            content = self.ridge_content
        payload = content.current_payload()
        if payload is None:
            content.set_highlight_point(None)
            QToolTip.hideText()
            return
        mouse_event = event
        local_x = mouse_event.position().x() + scroll_area.horizontalScrollBar().value()
        local_y = mouse_event.position().y() + scroll_area.verticalScrollBar().value()
        best_hit = self._find_hover_hit(payload, QPointF(local_x, local_y))
        if best_hit is None:
            content.set_highlight_point(None)
            QToolTip.hideText()
            return
        content.set_highlight_point(best_hit)
        point = best_hit.point
        QToolTip.showText(
            mouse_event.globalPosition().toPoint(),
            (
                f"{point.aggregate_id}\n"
                f"{point.sample_id}\n"
                f"value: {point.value:.3f}\n"
                f"metric: {point.metric}\n"
                f"dataset_id: {point.dataset_id}\n"
                f"row_number: {point.row_number}\n"
                f"outlier: {'yes' if point.outlier else 'no'}"
            ),
            scroll_area.viewport(),
        )

    def _refresh_hover_under_cursor(self) -> None:
        if not self._startup_render_done:
            return
        scroll_area = self.box_scroll if self.mode_combo.currentText() == "Box Plot" else self.ridge_scroll
        viewport = scroll_area.viewport()
        local_pos = viewport.mapFromGlobal(QCursor.pos())
        if viewport.rect().contains(local_pos):
            fake_event = type("HoverProxy", (), {})()
            fake_event.position = lambda: QPointF(local_pos)
            fake_event.globalPosition = lambda: QPointF(QCursor.pos())
            self._handle_viewport_hover(viewport, fake_event)
        else:
            self.box_content.set_highlight_point(None)
            self.ridge_content.set_highlight_point(None)
            QToolTip.hideText()

    @staticmethod
    def _find_hover_hit(payload: RenderPayload, position: QPointF) -> HoverPoint | None:
        bucket_size = 24
        base_x = int(position.x() // bucket_size)
        base_y = int(position.y() // bucket_size)
        best_hit: HoverPoint | None = None
        best_distance = 12.0
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for item in payload.hover_buckets.get((base_x + dx, base_y + dy), []):
                    distance = math.hypot(item.position.x() - position.x(), item.position.y() - position.y())
                    if distance <= item.radius + 5.0 and distance < best_distance:
                        best_hit = item
                        best_distance = distance
        return best_hit

    def _position_axis_overlay(self, scroll_area: QScrollArea, overlay: AxisOverlay) -> None:
        viewport_geometry = scroll_area.viewport().geometry()
        overlay.setGeometry(
            viewport_geometry.left(),
            viewport_geometry.top() - self._axis_overlay_height,
            viewport_geometry.width(),
            self._axis_overlay_height,
        )
        overlay.raise_()

    def _export_preview(self) -> None:
        output_dir = Path(__file__).resolve().parent / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        name = "continuous_ridge_preview.png" if self.mode_combo.currentText() == "Ridge Plot" else "continuous_box_preview.png"
        self.grab().save(str(output_dir / name))
        self.render_status_label.setText(f"Saved: {output_dir / name}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Continuous comparison demo.")
    parser.add_argument(
        "--export-preview",
        action="store_true",
        help="Export current window preview into demo/continuous_comparison_demo/output and exit.",
    )
    args = parser.parse_args(argv)

    app = QApplication(sys.argv)
    window = ContinuousComparisonWindow()
    if args.export_preview:
        window.show()
        QTimer.singleShot(0, window._export_preview)
        QTimer.singleShot(0, app.quit)
        app.exec()
        return 0
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
