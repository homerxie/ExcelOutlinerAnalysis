# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'continuous_comparison_demo.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QFrame,
    QGridLayout, QHBoxLayout, QLabel, QLineEdit,
    QMainWindow, QPushButton, QScrollArea, QSizePolicy,
    QStackedWidget, QStatusBar, QVBoxLayout, QWidget)

class Ui_ContinuousComparisonWindow(object):
    def setupUi(self, ContinuousComparisonWindow):
        if not ContinuousComparisonWindow.objectName():
            ContinuousComparisonWindow.setObjectName(u"ContinuousComparisonWindow")
        ContinuousComparisonWindow.resize(771, 548)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(ContinuousComparisonWindow.sizePolicy().hasHeightForWidth())
        ContinuousComparisonWindow.setSizePolicy(sizePolicy)
        self.centralwidget = QWidget(ContinuousComparisonWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.main_layout = QVBoxLayout(self.centralwidget)
        self.main_layout.setObjectName(u"main_layout")
        self.main_layout.setContentsMargins(12, 12, 12, 12)
        self.header = QFrame(self.centralwidget)
        self.header.setObjectName(u"header")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.header.sizePolicy().hasHeightForWidth())
        self.header.setSizePolicy(sizePolicy1)
        self.header.setFrameShape(QFrame.Shape.Box)
        self.header_layout = QVBoxLayout(self.header)
        self.header_layout.setSpacing(0)
        self.header_layout.setObjectName(u"header_layout")
        self.header_layout.setContentsMargins(10, 10, 10, 10)
        self.plot_controls_grid = QGridLayout()
        self.plot_controls_grid.setObjectName(u"plot_controls_grid")
        self.plot_controls_grid.setHorizontalSpacing(10)
        self.plot_controls_grid.setVerticalSpacing(5)
        self.mode_label = QLabel(self.header)
        self.mode_label.setObjectName(u"mode_label")

        self.plot_controls_grid.addWidget(self.mode_label, 0, 0, 1, 1)

        self.mode_combo = QComboBox(self.header)
        self.mode_combo.addItem("")
        self.mode_combo.addItem("")
        self.mode_combo.setObjectName(u"mode_combo")

        self.plot_controls_grid.addWidget(self.mode_combo, 1, 0, 1, 1)

        self.metric_label = QLabel(self.header)
        self.metric_label.setObjectName(u"metric_label")

        self.plot_controls_grid.addWidget(self.metric_label, 0, 1, 1, 1)

        self.metric_combo = QComboBox(self.header)
        self.metric_combo.addItem("")
        self.metric_combo.addItem("")
        self.metric_combo.setObjectName(u"metric_combo")

        self.plot_controls_grid.addWidget(self.metric_combo, 1, 1, 1, 1)

        self.count_label = QLabel(self.header)
        self.count_label.setObjectName(u"count_label")

        self.plot_controls_grid.addWidget(self.count_label, 0, 2, 1, 1)

        self.count_combo = QComboBox(self.header)
        self.count_combo.addItem("")
        self.count_combo.addItem("")
        self.count_combo.addItem("")
        self.count_combo.setObjectName(u"count_combo")

        self.plot_controls_grid.addWidget(self.count_combo, 1, 2, 1, 1)

        self.display_label = QLabel(self.header)
        self.display_label.setObjectName(u"display_label")

        self.plot_controls_grid.addWidget(self.display_label, 0, 3, 1, 1)

        self.display_combo = QComboBox(self.header)
        self.display_combo.addItem("")
        self.display_combo.addItem("")
        self.display_combo.addItem("")
        self.display_combo.setObjectName(u"display_combo")

        self.plot_controls_grid.addWidget(self.display_combo, 1, 3, 1, 1)


        self.header_layout.addLayout(self.plot_controls_grid)

        self.search_controls_grid = QGridLayout()
        self.search_controls_grid.setObjectName(u"search_controls_grid")
        self.search_controls_grid.setHorizontalSpacing(10)
        self.search_controls_grid.setVerticalSpacing(5)
        self.search_label = QLabel(self.header)
        self.search_label.setObjectName(u"search_label")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.search_label.sizePolicy().hasHeightForWidth())
        self.search_label.setSizePolicy(sizePolicy2)

        self.search_controls_grid.addWidget(self.search_label, 1, 0, 1, 1)

        self.search_input = QLineEdit(self.header)
        self.search_input.setObjectName(u"search_input")
        self.search_input.setCursorMoveStyle(Qt.CursorMoveStyle.LogicalMoveStyle)
        self.search_input.setClearButtonEnabled(True)

        self.search_controls_grid.addWidget(self.search_input, 1, 1, 1, 2)

        self.search_view_combo = QComboBox(self.header)
        self.search_view_combo.addItem("")
        self.search_view_combo.addItem("")
        self.search_view_combo.setObjectName(u"search_view_combo")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.search_view_combo.sizePolicy().hasHeightForWidth())
        self.search_view_combo.setSizePolicy(sizePolicy3)

        self.search_controls_grid.addWidget(self.search_view_combo, 1, 4, 1, 1)

        self.search_view_label = QLabel(self.header)
        self.search_view_label.setObjectName(u"search_view_label")
        sizePolicy2.setHeightForWidth(self.search_view_label.sizePolicy().hasHeightForWidth())
        self.search_view_label.setSizePolicy(sizePolicy2)

        self.search_controls_grid.addWidget(self.search_view_label, 1, 3, 1, 1)


        self.header_layout.addLayout(self.search_controls_grid)

        self.search_actions_layout = QHBoxLayout()
        self.search_actions_layout.setSpacing(10)
        self.search_actions_layout.setObjectName(u"search_actions_layout")
        self.compact_range_checkbox = QCheckBox(self.header)
        self.compact_range_checkbox.setObjectName(u"compact_range_checkbox")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.compact_range_checkbox.sizePolicy().hasHeightForWidth())
        self.compact_range_checkbox.setSizePolicy(sizePolicy4)

        self.search_actions_layout.addWidget(self.compact_range_checkbox)

        self.realtime_render_checkbox = QCheckBox(self.header)
        self.realtime_render_checkbox.setObjectName(u"realtime_render_checkbox")
        sizePolicy4.setHeightForWidth(self.realtime_render_checkbox.sizePolicy().hasHeightForWidth())
        self.realtime_render_checkbox.setSizePolicy(sizePolicy4)

        self.search_actions_layout.addWidget(self.realtime_render_checkbox)

        self.refresh_search_button = QPushButton(self.header)
        self.refresh_search_button.setObjectName(u"refresh_search_button")

        self.search_actions_layout.addWidget(self.refresh_search_button)

        self.search_prev_button = QPushButton(self.header)
        self.search_prev_button.setObjectName(u"search_prev_button")

        self.search_actions_layout.addWidget(self.search_prev_button)

        self.search_next_button = QPushButton(self.header)
        self.search_next_button.setObjectName(u"search_next_button")

        self.search_actions_layout.addWidget(self.search_next_button)

        self.search_status_label = QLabel(self.header)
        self.search_status_label.setObjectName(u"search_status_label")
        self.search_status_label.setMinimumSize(QSize(64, 0))
        self.search_status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.search_actions_layout.addWidget(self.search_status_label)

        self.export_button = QPushButton(self.header)
        self.export_button.setObjectName(u"export_button")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.export_button.sizePolicy().hasHeightForWidth())
        self.export_button.setSizePolicy(sizePolicy5)

        self.search_actions_layout.addWidget(self.export_button)


        self.header_layout.addLayout(self.search_actions_layout)


        self.main_layout.addWidget(self.header)

        self.plot_stack = QStackedWidget(self.centralwidget)
        self.plot_stack.setObjectName(u"plot_stack")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy6.setHorizontalStretch(0)
        sizePolicy6.setVerticalStretch(1)
        sizePolicy6.setHeightForWidth(self.plot_stack.sizePolicy().hasHeightForWidth())
        self.plot_stack.setSizePolicy(sizePolicy6)
        self.box_page = QWidget()
        self.box_page.setObjectName(u"box_page")
        self.box_layout = QVBoxLayout(self.box_page)
        self.box_layout.setObjectName(u"box_layout")
        self.box_scroll = QScrollArea(self.box_page)
        self.box_scroll.setObjectName(u"box_scroll")
        sizePolicy7 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy7.setHorizontalStretch(0)
        sizePolicy7.setVerticalStretch(0)
        sizePolicy7.setHeightForWidth(self.box_scroll.sizePolicy().hasHeightForWidth())
        self.box_scroll.setSizePolicy(sizePolicy7)
        self.box_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.box_scroll.setWidgetResizable(False)
        self.box_scroll_content = QWidget()
        self.box_scroll_content.setObjectName(u"box_scroll_content")
        self.box_scroll_content.setGeometry(QRect(0, 0, 760, 500))
        self.box_scroll.setWidget(self.box_scroll_content)

        self.box_layout.addWidget(self.box_scroll)

        self.plot_stack.addWidget(self.box_page)
        self.ridge_page = QWidget()
        self.ridge_page.setObjectName(u"ridge_page")
        self.ridge_layout = QVBoxLayout(self.ridge_page)
        self.ridge_layout.setObjectName(u"ridge_layout")
        self.ridge_scroll = QScrollArea(self.ridge_page)
        self.ridge_scroll.setObjectName(u"ridge_scroll")
        self.ridge_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.ridge_scroll.setWidgetResizable(False)
        self.ridge_scroll_content = QWidget()
        self.ridge_scroll_content.setObjectName(u"ridge_scroll_content")
        self.ridge_scroll_content.setGeometry(QRect(0, 0, 760, 500))
        self.ridge_scroll.setWidget(self.ridge_scroll_content)

        self.ridge_layout.addWidget(self.ridge_scroll)

        self.plot_stack.addWidget(self.ridge_page)

        self.main_layout.addWidget(self.plot_stack)

        ContinuousComparisonWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(ContinuousComparisonWindow)
        self.statusbar.setObjectName(u"statusbar")
        ContinuousComparisonWindow.setStatusBar(self.statusbar)

        self.retranslateUi(ContinuousComparisonWindow)

        self.plot_stack.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(ContinuousComparisonWindow)
    # setupUi

    def retranslateUi(self, ContinuousComparisonWindow):
        ContinuousComparisonWindow.setWindowTitle(QCoreApplication.translate("ContinuousComparisonWindow", u"Continuous Comparison Demo", None))
        self.mode_label.setText(QCoreApplication.translate("ContinuousComparisonWindow", u"Mode", None))
        self.mode_combo.setItemText(0, QCoreApplication.translate("ContinuousComparisonWindow", u"Ridge Plot", None))
        self.mode_combo.setItemText(1, QCoreApplication.translate("ContinuousComparisonWindow", u"Box Plot", None))

        self.metric_label.setText(QCoreApplication.translate("ContinuousComparisonWindow", u"Metric", None))
        self.metric_combo.setItemText(0, QCoreApplication.translate("ContinuousComparisonWindow", u"Leakage (uA)", None))
        self.metric_combo.setItemText(1, QCoreApplication.translate("ContinuousComparisonWindow", u"Vt Shift (mV)", None))

        self.count_label.setText(QCoreApplication.translate("ContinuousComparisonWindow", u"Aggregate Count", None))
        self.count_combo.setItemText(0, QCoreApplication.translate("ContinuousComparisonWindow", u"120", None))
        self.count_combo.setItemText(1, QCoreApplication.translate("ContinuousComparisonWindow", u"240", None))
        self.count_combo.setItemText(2, QCoreApplication.translate("ContinuousComparisonWindow", u"400", None))

        self.display_label.setText(QCoreApplication.translate("ContinuousComparisonWindow", u"Display Range", None))
        self.display_combo.setItemText(0, QCoreApplication.translate("ContinuousComparisonWindow", u"Robust Range + Edge Markers", None))
        self.display_combo.setItemText(1, QCoreApplication.translate("ContinuousComparisonWindow", u"Full Range", None))
        self.display_combo.setItemText(2, QCoreApplication.translate("ContinuousComparisonWindow", u"Robust Range", None))

        self.search_label.setText(QCoreApplication.translate("ContinuousComparisonWindow", u"Search:", None))
        self.search_input.setPlaceholderText(QCoreApplication.translate("ContinuousComparisonWindow", u"Search row label, e.g. Lot1212 Node1", None))
        self.search_view_combo.setItemText(0, QCoreApplication.translate("ContinuousComparisonWindow", u"Compact Results", None))
        self.search_view_combo.setItemText(1, QCoreApplication.translate("ContinuousComparisonWindow", u"In Place", None))

        self.search_view_label.setText(QCoreApplication.translate("ContinuousComparisonWindow", u"Search View:", None))
        self.compact_range_checkbox.setText(QCoreApplication.translate("ContinuousComparisonWindow", u"Adaptive X Range", None))
        self.realtime_render_checkbox.setText(QCoreApplication.translate("ContinuousComparisonWindow", u"Realtime Render", None))
        self.refresh_search_button.setText(QCoreApplication.translate("ContinuousComparisonWindow", u"Refresh", None))
        self.search_prev_button.setText(QCoreApplication.translate("ContinuousComparisonWindow", u"Prev", None))
        self.search_next_button.setText(QCoreApplication.translate("ContinuousComparisonWindow", u"Next", None))
        self.search_status_label.setText(QCoreApplication.translate("ContinuousComparisonWindow", u"0 / 0", None))
        self.export_button.setText(QCoreApplication.translate("ContinuousComparisonWindow", u"Export Preview PNG", None))
    # retranslateUi

