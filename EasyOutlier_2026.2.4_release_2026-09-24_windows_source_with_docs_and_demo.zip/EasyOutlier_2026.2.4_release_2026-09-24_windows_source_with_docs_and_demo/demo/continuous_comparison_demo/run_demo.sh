#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT_DIR"

exec ./.venv/bin/python demo/continuous_comparison_demo/app.py "$@"
