from __future__ import annotations

import os
from pathlib import Path
from threading import BoundedSemaphore, Event, Thread
from typing import Any


# A disconnected drive can block stat indefinitely. Daemon probes cannot block
# application shutdown, and the semaphore bounds outstanding filesystem calls.
_probe_slots = BoundedSemaphore(4)


def absolute_path(value: str | Path, root: Path) -> Path:
    """Resolve relative paths against the application, without touching the disk."""
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = root / path
    return Path(os.path.abspath(path))


def display_path(value: str | Path, root: Path) -> str:
    if not str(value).strip():
        return ""
    path = absolute_path(value, root)
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return str(path)


def available_path(path: Path, *, directory: bool = False, timeout: float = 0.15) -> bool:
    if not _probe_slots.acquire(blocking=False):
        return False
    done = Event()
    result = [False]

    def check() -> None:
        try:
            result[0] = path.is_dir() if directory else path.is_file()
        except (OSError, ValueError):
            pass
        finally:
            _probe_slots.release()
            done.set()

    Thread(target=check, daemon=True, name="browse-path-check").start()
    return result[0] if done.wait(timeout) else False


def dialog_start(value: str, root: Path, *, directory: bool = False, save: bool = False) -> str:
    if not value.strip():
        return str(root)
    path = absolute_path(value, root)
    folder = path if directory else path.parent
    if not available_path(folder, directory=True):
        folder = root
    return str(folder / path.name) if save and not directory else str(folder)


def pack_paths(paths: dict[str, str], *, app: Path, database: Path, package: Path) -> dict[str, Any]:
    values: dict[str, str] = {}
    bases: dict[str, str] = {}
    fallbacks: dict[str, str] = {}
    for key, value in paths.items():
        if not value:
            values[key] = ""
            continue
        path = absolute_path(value, app)
        if key in {"template_path", "input_path", "golden_path", "output_path"}:
            # Bundled resources follow the installed application. User templates
            # follow the database, including siblings such as ../template.xlsx.
            if key == "template_path" and path.is_relative_to(package):
                values[key] = path.relative_to(package).as_posix()
                bases[key] = "package"
            else:
                try:
                    values[key] = Path(os.path.relpath(path, database)).as_posix()
                    bases[key] = "database"
                    if key != "output_path":
                        fallbacks[key] = str(path)
                except ValueError:  # Different Windows drives have no relative path.
                    values[key] = str(path)
            continue
        # Database files should follow a database moved independently of the app.
        for base_name, root in (("database", database), ("app", app), ("package", package)):
            try:
                values[key] = path.relative_to(root).as_posix()
                bases[key] = base_name
                break
            except ValueError:
                continue
        else:
            values[key] = str(path)
    return {"paths": values, "path_bases": bases, "path_fallbacks": fallbacks}


def restore_paths(payload: dict[str, Any], *, app: Path, database: Path, package: Path) -> dict[str, str]:
    values = payload.get("paths", {})
    bases = payload.get("path_bases", {})
    fallbacks = payload.get("path_fallbacks", {})
    if not isinstance(values, dict):
        return {}
    if not isinstance(bases, dict):
        bases = {}
    if not isinstance(fallbacks, dict):
        fallbacks = {}
    roots = {"app": app, "database": database, "package": package}
    restored: dict[str, str] = {}
    for key, value in values.items():
        if not isinstance(value, str):
            continue
        if not value.strip():
            restored[key] = ""
            continue
        path = Path(value).expanduser()
        if not path.is_absolute():
            path = absolute_path(path, roots.get(bases.get(key), app))
            fallback = fallbacks.get(key)
            if key != "output_path" and bases.get(key) == "database" and isinstance(fallback, str) and fallback.strip():
                if not available_path(path):
                    original = Path(fallback).expanduser()
                    if original.is_absolute() and available_path(original):
                        path = original
        elif not bases:
            path = _relocate_legacy_path(path, key, roots)
        restored[key] = display_path(path, app)
    return restored


def _relocate_legacy_path(path: Path, key: str, roots: dict[str, Path]) -> Path:
    # Never probe the old location. Only recover a matching relative suffix in
    # the new local tree, not an unrelated file with the same basename.
    for root in roots.values():
        if path.is_relative_to(root):
            return path
    for root in (roots["database"], roots["app"]):
        for index in range(len(path.parts) - 1, -1, -1):
            if path.parts[index] != root.name:
                continue
            candidate = root.joinpath(*path.parts[index + 1:])
            if available_path(candidate) or (
                key == "output_path" and available_path(candidate.parent, directory=True)
            ):
                return candidate
    # Bundled resources may have lived in a previous PyInstaller extraction dir.
    suffix = ("excel_data_analysis", "assets", "templates", "chip_reliability_template.json")
    if key == "template_path" and path.parts[-len(suffix):] == suffix:
        candidate = roots["package"] / "assets/templates/chip_reliability_template.json"
        if available_path(candidate):
            return candidate
    return path
