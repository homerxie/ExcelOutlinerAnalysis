"""An explicit nonnegative-odds closure of the instance Logistic model.

This path is used only to investigate a low-risk boundary of an existing fit.
It does not equate a large negative logit with zero risk.  Zero odds must satisfy
one-sided stationarity, and estimability is checked separately for every query.
The nonlinear likelihood can have other optima: the checks here are numerical
and local, with an additional positive-profile check for zero estimates.
"""

from __future__ import annotations

import math
from time import monotonic

import numpy as np
from scipy.optimize import brentq, linprog, minimize, nnls
from scipy.special import expit
from scipy.stats import chi2


KKT_TOLERANCE = 1e-8
INTERIOR_METHOD = "profile_likelihood_approximate_odds_contrast"
BOUNDARY_METHOD = "profile_likelihood_approximate_zero_boundary"
EXACT_METHOD = "exact_one_sided_zero_failure_upper_bound_pure_design_subset"
CONSERVATIVE_EXACT_METHOD = "exact_conservative_one_sided_zero_failure_upper_bound_matching_instances"


def _basis(matrix):
    if not matrix.size:
        return np.zeros((matrix.shape[1], 0))
    _, singular, right = np.linalg.svd(matrix, full_matrices=False)
    tolerance = max(matrix.shape) * np.finfo(float).eps * singular[0] * 100
    return right[singular > tolerance].T


def _plain(value):
    if isinstance(value, dict):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_plain(item) for item in value]
    if isinstance(value, np.ndarray):
        return _plain(value.tolist())
    if isinstance(value, np.generic):
        return _plain(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _loss_tolerance(minimum):
    # Never allow a large total NLL to swallow a material LR difference.
    return min(1e-7, max(1e-10, 32 * np.finfo(float).eps * max(abs(minimum), 1.)))


class LogisticBoundaryFit:
    def __init__(self, design, chain_index, n, k, type_count, coefficient_bound=35, progress_callback=None):
        self.design = np.asarray(design, dtype=float)
        self.chain_index = np.asarray(chain_index, dtype=int)
        self.n, self.k = np.asarray(n, dtype=float), np.asarray(k, dtype=float)
        self.type_count = int(type_count)
        self.coefficient_bound = float(coefficient_bound)
        self.progress_callback = progress_callback
        if (self.design.ndim != 2 or not 0 < self.type_count <= self.design.shape[1]
                or self.chain_index.shape != (len(self.design),) or self.n.shape != self.k.shape
                or not len(self.n) or np.any(self.n <= 0) or np.any(self.k < 0) or np.any(self.k > self.n)
                or np.any(self.chain_index < 0) or np.any(self.chain_index >= len(self.n))
                or not all(np.all(np.isfinite(value)) for value in (self.design, self.n, self.k))
                or not math.isfinite(self.coefficient_bound) or self.coefficient_bound <= .1):
            raise ValueError("Invalid Logistic boundary model arrays or coefficient bound.")
        kinds = self.design[:, :self.type_count]
        if not (np.all((kinds == 0) | (kinds == 1)) and np.all(kinds.sum(axis=1) == 1)):
            raise ValueError("The Logistic boundary model requires one TSK indicator per instance.")
        self.width = self.design.shape[1]
        self.type_index = np.argmax(kinds, axis=1)
        self.features = self.design[:, self.type_count:]
        self.design_basis = _basis(self.design)
        self.counts = np.zeros((len(self.n), self.type_count))
        np.add.at(self.counts, self.chain_index, kinds)
        self.odds_scale = np.ones(self.type_count)
        self.state = None
        self._profile_cache = {}
        self._identifiable_cache = {}
        self._last_progress = monotonic()

    def _progress(self, phase, iteration=0, force=False, **values):
        now = monotonic()
        if self.progress_callback is not None and (force or now - self._last_progress >= 1.):
            self._last_progress = now
            self.progress_callback({"phase": phase, "iteration": iteration, **values})

    def _parts(self, params):
        params = np.asarray(params, dtype=float)
        if params.shape != (self.width,) or not np.all(np.isfinite(params)) or np.any(params[:self.type_count] < 0):
            return None
        u = params[self.type_index]
        linear = self.features @ params[self.type_count:]
        log_factor = np.log(self.odds_scale[self.type_index]) + linear
        positive = u > 0
        logits = np.full(len(u), -math.inf)
        logits[positive] = np.log(u[positive]) + log_factor[positive]
        hazard = np.logaddexp(0., logits)
        probability = expit(logits)
        du = np.zeros(len(u))
        du[positive] = probability[positive] / u[positive]
        with np.errstate(over="ignore"):
            du[~positive] = np.exp(log_factor[~positive])
        chain_hazard = np.bincount(self.chain_index, weights=hazard, minlength=len(self.n))
        J = np.zeros((len(self.n), self.width))
        np.add.at(J, (self.chain_index, self.type_index), du)
        if self.features.shape[1]:
            np.add.at(J[:, self.type_count:], self.chain_index, probability[:, None] * self.features)
        return probability, du, chain_hazard, J

    def evaluate(self, params):
        """Return total NLL, its scaled-odds gradient, chain risks and Jacobian."""
        parts = self._parts(params)
        if parts is None:
            return math.inf, np.full(self.width, math.nan), np.full(len(self.n), math.nan), np.full((len(self.n), self.width), math.nan)
        _, _, hazards, J = parts
        positive = self.k > 0
        predicted = -np.expm1(-hazards)
        if np.any(hazards[positive] <= 0) or not np.all(np.isfinite(J)):
            return math.inf, np.full(self.width, math.nan), predicted, J
        loss = float((self.n - self.k) @ hazards)
        slope = (self.n - self.k).copy()
        if np.any(positive):
            q = predicted[positive]
            loss -= float(self.k[positive] @ np.log(q))
            slope[positive] -= self.k[positive] * np.exp(-hazards[positive]) / q
        return loss, J.T @ slope, predicted, J

    def _hessian(self, params):
        probability, du, hazards, J = self._parts(params)
        positive = self.k > 0
        q = -np.expm1(-hazards)
        slope = (self.n - self.k).copy()
        weight = np.zeros(len(self.n))
        slope[positive] -= self.k[positive] * np.exp(-hazards[positive]) / q[positive]
        weight[positive] = self.k[positive] * np.exp(-hazards[positive]) / q[positive] ** 2
        hessian = J.T @ (weight[:, None] * J)
        row_slope = slope[self.chain_index]
        np.add.at(hessian, (self.type_index, self.type_index), -row_slope * du ** 2)
        if self.features.shape[1]:
            cross = np.zeros((self.type_count, self.features.shape[1]))
            np.add.at(cross, self.type_index, (row_slope * du * (1 - probability))[:, None] * self.features)
            hessian[:self.type_count, self.type_count:] += cross
            hessian[self.type_count:, :self.type_count] += cross.T
            hessian[self.type_count:, self.type_count:] += self.features.T @ (
                (row_slope * probability * (1 - probability))[:, None] * self.features)
        return hessian

    def _loss_change(self, candidate, reference):
        """Compare likelihoods without subtracting enormous constant totals."""
        new_parts, old_parts = self._parts(candidate), self._parts(reference)
        if new_parts is None or old_parts is None:
            return math.inf
        new_hazard, old_hazard = new_parts[2], old_parts[2]
        positive = self.k > 0
        if np.any(new_hazard[positive] <= 0):
            return math.inf
        if np.any(old_hazard[positive] <= 0):
            return -math.inf
        difference = new_hazard - old_hazard
        value = float((self.n - self.k) @ difference)
        if np.any(positive):
            old = old_hazard[positive]
            delta = difference[positive]
            with np.errstate(over="ignore", divide="ignore", invalid="ignore"):
                ratio_change = np.exp(-old) * -np.expm1(-delta) / -np.expm1(-old)
                log_ratio = np.log1p(ratio_change)
            bad = ~np.isfinite(log_ratio)
            if np.any(bad):
                log_ratio[bad] = (np.log(-np.expm1(-new_hazard[positive][bad]))
                                  - np.log(-np.expm1(-old[bad])))
            value -= float(self.k[positive] @ log_ratio)
        return value

    def _query(self, vector):
        vector = np.asarray(vector, dtype=float)
        if vector.shape != (self.width,) or not np.all(np.isfinite(vector)):
            raise ValueError("Invalid Logistic probability query.")
        indicators = vector[:self.type_count]
        if np.count_nonzero(indicators) != 1 or np.max(indicators) != 1.:
            raise ValueError("A Logistic probability query must select exactly one TSK.")
        return int(np.argmax(indicators)), vector[self.type_count:]

    def probability(self, params, vector):
        kind, features = self._query(vector)
        u = float(np.asarray(params)[kind])
        return 0. if u == 0 else float(expit(math.log(u) + math.log(self.odds_scale[kind]) + features @ np.asarray(params)[self.type_count:]))

    def probability_gradient(self, params, vector):
        kind, features = self._query(vector)
        params = np.asarray(params)
        probability = self.probability(params, vector)
        gradient = np.zeros(self.width)
        if params[kind] == 0:
            with np.errstate(over="ignore"):
                gradient[kind] = np.exp(math.log(self.odds_scale[kind]) + float(features @ params[self.type_count:]))
        else:
            gradient[kind] = probability * (1 - probability) / params[kind]
        gradient[self.type_count:] = probability * (1 - probability) * features
        return gradient

    def _coordinates(self, start, fixed):
        if fixed is None:
            free = np.arange(self.width)

            def unpack(values):
                return np.asarray(values), np.eye(self.width)
        else:
            vector, probability = fixed
            kind, query_features = self._query(vector)
            free = np.flatnonzero(np.arange(self.width) != kind)

            def unpack(values):
                params = np.asarray(start).copy()
                params[free] = values
                if probability == 0.:
                    params[kind] = 0.
                else:
                    exponent = math.log(probability) - math.log1p(-probability) - math.log(self.odds_scale[kind]) - query_features @ params[self.type_count:]
                    params[kind] = math.exp(exponent) if exponent < 709. else math.inf
                transform = np.eye(self.width)[:, free]
                for column, original in enumerate(free):
                    if original >= self.type_count:
                        transform[kind, column] = -params[kind] * query_features[original - self.type_count]
                return params, transform

        bounds = [(0., None) if index < self.type_count else (-self.coefficient_bound, self.coefficient_bound) for index in free]
        return free, bounds, unpack

    def _kkt(self, values, gradient, derivative, bounds):
        if not np.all(np.isfinite(gradient)) or not np.all(np.isfinite(derivative)):
            return math.inf
        if not len(values):
            return 0.
        try:
            _, _, right = np.linalg.svd(np.sqrt(self.n)[:, None] * derivative, full_matrices=len(self.n) < len(values))
        except np.linalg.LinAlgError:
            return math.inf
        rotation = right.T
        exposure = np.maximum(np.abs(derivative @ rotation).T @ self.n, 1.)
        transform = rotation / exposure[None, :]
        scaled_gradient = transform.T @ gradient
        active = []
        for index, (value, (lower, upper)) in enumerate(zip(values, bounds)):
            if lower is not None and value <= lower + 1e-12:
                active.append(transform[index])
            if upper is not None and value >= upper - 1e-12:
                active.append(-transform[index])
        if active:
            matrix = np.asarray(active).T
            matrix /= np.maximum(np.linalg.norm(matrix, axis=0), 1e-300)[None, :]
            try:
                multipliers, _ = nnls(matrix, scaled_gradient, maxiter=max(1000, 20 * len(active)))
                scaled_gradient -= matrix @ multipliers
            except (RuntimeError, ValueError):
                return math.inf
        return float(np.max(np.abs(scaled_gradient), initial=0.))

    def _optimize(self, start, fixed=None):
        free, bounds, unpack = self._coordinates(start, fixed)

        def evaluate(values):
            params, transform = unpack(values)
            loss, gradient, predicted, J = self.evaluate(params)
            if not math.isfinite(loss) or not np.all(np.isfinite(gradient)) or not np.all(np.isfinite(J)):
                return loss, np.full(len(free), math.nan), np.full((len(self.n), len(free)), math.nan), params, predicted
            return loss, transform.T @ gradient, J @ transform, params, predicted

        def objective(values):
            loss, gradient, _, _, _ = evaluate(values)
            return loss, gradient

        def residual(values):
            loss, gradient, J, _, _ = evaluate(values)
            return self._kkt(values, gradient, J, bounds) if math.isfinite(loss) else math.inf

        initial = np.asarray(start)[free].copy()
        stages = []
        if not len(free):
            loss, _, _, params, predicted = evaluate(initial)
            return {"params": params, "minimum": loss, "predicted": predicted, "kkt_residual": 0., "converged": math.isfinite(loss), "stages": stages}
        current = initial
        for method, phase, settings, scale in (
            ("L-BFGS-B", "odds_lbfgsb", {"ftol": 1e-12, "gtol": 1e-10, "maxiter": 1500, "maxls": 50}, 1.),
            ("SLSQP", "odds_slsqp", {"ftol": 1e-15, "maxiter": 1500}, max(float(self.n.sum()), 1.)),
            ("L-BFGS-B", "odds_polish", {"ftol": 0., "gtol": 1e-10, "maxiter": 1500, "maxls": 50}, 1.),
        ):
            iterations = [0]

            def callback(values):
                iterations[0] += 1
                self._progress(phase, iterations[0])

            def scaled(values):
                loss, gradient = objective(values)
                return loss / scale, gradient / scale

            try:
                with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
                    fit = minimize(scaled, current, jac=True, method=method, bounds=bounds, options=settings, callback=callback)
            except (ValueError, RuntimeError, FloatingPointError, OverflowError, np.linalg.LinAlgError) as error:
                stages.append({"phase": phase, "method": method, "success": False, "status": None,
                               "message": str(error), "reason": "numerical_optimizer_failure",
                               "minimum": objective(current)[0], "kkt_residual": residual(current)})
                continue
            candidate_loss = objective(fit.x)[0]
            current_loss = objective(current)[0]
            if math.isfinite(candidate_loss) and (not math.isfinite(current_loss)
                                                  or self._loss_change(unpack(fit.x)[0], unpack(current)[0]) <= 0):
                current = fit.x.copy()
            kkt = residual(current)
            stages.append({"phase": phase, "method": method, "success": bool(fit.success), "status": int(fit.status),
                           "message": str(fit.message), "nit": int(fit.nit), "nfev": int(fit.nfev),
                           "minimum": objective(current)[0], "kkt_residual": kkt})
            if kkt < KKT_TOLERANCE:
                break
        # Exact active-face Newton corrections resolve floating-point objective
        # stops, while retaining the independent, exposure-scaled KKT check.
        for _ in range(25):
            loss, gradient, J, params, _ = evaluate(current)
            if not math.isfinite(loss) or self._kkt(current, gradient, J, bounds) < KKT_TOLERANCE:
                break
            active = np.array([(lower is not None and value <= lower + 1e-12 and slope >= 0)
                               or (upper is not None and value >= upper - 1e-12 and slope <= 0)
                               for value, slope, (lower, upper) in zip(current, gradient, bounds)])
            selected = ~active
            if not np.any(selected):
                break
            _, transform = unpack(current)
            with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
                hessian = transform.T @ self._hessian(params) @ transform
            if fixed is not None:
                kind, query_features = self._query(fixed[0])
                raw_gradient = self.evaluate(params)[1]
                feature_vector = np.array([query_features[index - self.type_count] if index >= self.type_count else 0. for index in free])
                hessian += raw_gradient[kind] * params[kind] * np.outer(feature_vector, feature_vector)
            block = hessian[np.ix_(selected, selected)]
            if not np.all(np.isfinite(block)):
                break
            # Whiten by exposure before solving, so a huge independent chain
            # cannot suppress the Newton correction for a lightly tested type.
            try:
                _, _, right = np.linalg.svd(np.sqrt(self.n)[:, None] * J[:, selected],
                                            full_matrices=len(self.n) < int(np.sum(selected)))
            except np.linalg.LinAlgError:
                break
            rotation = right.T
            exposure = np.maximum(np.abs(J[:, selected] @ rotation).T @ self.n, 1.)
            precondition = rotation / np.sqrt(exposure)[None, :]
            block = precondition.T @ block @ precondition
            try:
                eigenvalues, eigenvectors = np.linalg.eigh(block)
            except np.linalg.LinAlgError:
                break
            floor = max(float(np.max(np.abs(eigenvalues), initial=0)) * 1e-10, 1e-12)
            direction = np.zeros(len(current))
            direction[selected] = -precondition @ eigenvectors @ (
                (eigenvectors.T @ (precondition.T @ gradient[selected])) / np.maximum(eigenvalues, floor))
            for index, (lower, upper) in enumerate(bounds):
                if lower is not None and current[index] <= lower + 1e-12 and direction[index] < 0:
                    direction[index] = 0.
                if upper is not None and current[index] >= upper - 1e-12 and direction[index] > 0:
                    direction[index] = 0.
            if not np.all(np.isfinite(direction)) or gradient @ direction >= 0:
                break
            step = 1.
            for index, (lower, upper) in enumerate(bounds):
                if lower is not None and direction[index] < 0:
                    step = min(step, (lower - current[index]) / direction[index])
                if upper is not None and direction[index] > 0:
                    step = min(step, (upper - current[index]) / direction[index])
            for _ in range(45):
                candidate = current + step * direction
                for index, (lower, upper) in enumerate(bounds):
                    candidate[index] = np.clip(candidate[index], -math.inf if lower is None else lower, math.inf if upper is None else upper)
                new_loss = objective(candidate)[0]
                if (math.isfinite(new_loss)
                        and self._loss_change(unpack(candidate)[0], params) <= _loss_tolerance(loss)):
                    current = candidate
                    break
                step *= .5
            else:
                break
        loss, gradient, J, params, predicted = evaluate(current)
        kkt = self._kkt(current, gradient, J, bounds) if math.isfinite(loss) else math.inf
        return {"params": params, "minimum": loss, "predicted": predicted, "kkt_residual": kkt,
                "converged": math.isfinite(loss) and kkt < KKT_TOLERANCE, "stages": stages}

    def fit(self, logit_start):
        logit_start = np.asarray(logit_start, dtype=float)
        if logit_start.shape != (self.width,) or not np.all(np.isfinite(logit_start)):
            raise ValueError("Boundary investigation needs a finite full Logistic starting vector.")
        exposure = np.maximum(self.counts.T @ self.n, 1.)
        odds = np.exp(np.clip(logit_start[:self.type_count], -700., 20.))
        self.odds_scale = np.maximum(odds, 1. / exposure)
        initial = np.r_[odds / self.odds_scale, np.clip(logit_start[self.type_count:], -self.coefficient_bound, self.coefficient_bound)]
        rate = np.clip(self.k.sum() / self.n.sum(), 1e-5, .9)
        component = -math.expm1(math.log1p(-rate) / max(float(self.counts.sum(axis=1).mean()), 1.))
        positive = np.r_[np.full(self.type_count, component / (1 - component)) / self.odds_scale,
                         np.zeros(self.width - self.type_count)]
        perturbed = initial.copy()
        perturbed[:self.type_count] = np.maximum(perturbed[:self.type_count], .5)
        starts = [initial, positive, perturbed]
        zero_start = initial.copy()
        zero_start[:self.type_count][logit_start[:self.type_count] <= math.log(1e-9)] = 0.
        if not np.array_equal(zero_start, initial) and math.isfinite(self.evaluate(zero_start)[0]):
            starts.append(zero_start)
        candidates = []
        for index, start in enumerate(starts, 1):
            self._progress("odds_start", force=True, start_index=index)
            candidate = self._optimize(start)
            candidate["start_index"] = index
            candidates.append(candidate)
        best = candidates[0]
        for candidate in candidates[1:]:
            if self._loss_change(candidate["params"], best["params"]) < 0:
                best = candidate
        # A candidate exactly on the feasible face is preferred only at the
        # same numerical objective AND after an independent boundary KKT test.
        equivalent = [item for item in candidates if item["converged"] and
                      self._loss_change(item["params"], best["params"]) <= _loss_tolerance(best["minimum"])]
        if equivalent:
            best = max(equivalent, key=lambda item: int(np.count_nonzero(item["params"][:self.type_count] == 0.)))
        params = best["params"]
        feature_clipped = bool(np.any(np.abs(params[self.type_count:]) >= self.coefficient_bound - .1))
        positive_recession = np.flatnonzero((self.counts.T @ (self.n - self.k) == 0) & (self.counts.sum(axis=0) > 0))
        shared_recession = self._shared_feature_recession(params)
        converged = bool(best["converged"] and not feature_clipped and not len(positive_recession) and not shared_recession)
        reasons = []
        if not best["converged"]:
            reasons.append("odds_kkt_not_established")
        if not math.isfinite(best["minimum"]) or not np.all(np.isfinite(self.evaluate(params)[1])):
            reasons.append("nonfinite_odds_objective_or_gradient")
        if feature_clipped:
            reasons.append("shared_feature_boundary")
        if len(positive_recession):
            reasons.append("unbounded_positive_type_odds")
        if shared_recession:
            reasons.append("shared_feature_separation_direction")
        self.state = _plain({
            "version": 1, "parameterization": "scaled_type_odds", "params": params,
            "odds_scale": self.odds_scale, "type_count": self.type_count,
            "coefficient_bound": self.coefficient_bound, "converged": converged,
            "minimum": best["minimum"], "feature_clipped": feature_clipped,
            "zero_type_indices": np.flatnonzero(params[:self.type_count] == 0.),
            "trace": {"selected_start_index": best["start_index"], "starts": candidates},
            "validation": {"kkt_residual": best["kkt_residual"], "kkt_threshold": KKT_TOLERANCE,
                           "finite_objective": math.isfinite(best["minimum"]),
                           "nonfinite_positive_direction": positive_recession, "reason_codes": reasons,
                           "shared_feature_separation": shared_recession,
                           "identifiability_scope": "local feasible tangent cone plus positive zero-risk profile check"},
        })
        self._profile_cache.clear()
        self._identifiable_cache.clear()
        return self.state

    def _shared_feature_recession(self, params):
        """A sufficient monotone separation certificate, not an existence test.

        Hold every currently positive-odds instance in a Fail-containing chain
        fixed while decreasing at least one all-Pass instance. A direction that
        needs a shared effect to diverge is outside this finite-effect closure.
        Already exact-zero types have no hazard and do not enter this test.
        """
        if not self.features.shape[1]:
            return False
        # Alpha-only recession for a type with exclusively all-Pass support is
        # precisely the zero-odds closure that this engine supports. Exclude it
        # before asking whether shared effects must diverge; otherwise a null
        # feature column can receive an arbitrary LP coefficient and give a
        # spurious shared-feature certificate.
        pass_only = self.counts.T @ self.k == 0
        active = (np.asarray(params)[self.type_index] > 0) & ~pass_only[self.type_index]
        failed = self.design[active & (self.k[self.chain_index] > 0)]
        passed = self.design[active & (self.k[self.chain_index] == 0)]
        if not len(passed):
            return False
        objective = passed.sum(axis=0)
        result = linprog(objective, A_ub=passed, b_ub=np.zeros(len(passed)),
                         A_eq=failed if len(failed) else None, b_eq=np.zeros(len(failed)) if len(failed) else None,
                         bounds=[(-1., 1.)] * self.width, method="highs")
        return bool(result.success and result.fun < -1e-8 * max(np.linalg.norm(objective, ord=1), 1.)
                    and np.max(np.abs(result.x[self.type_count:]), initial=0.) > 1e-7)

    def load_state(self, state):
        if state.get("version") != 1 or state.get("parameterization") != "scaled_type_odds" or state.get("type_count") != self.type_count:
            raise ValueError("Unsupported Logistic boundary state.")
        scales = np.asarray(state.get("odds_scale"), dtype=float)
        params = np.asarray(state.get("params"), dtype=float)
        if scales.shape != (self.type_count,) or np.any(scales <= 0) or not np.all(np.isfinite(scales)):
            raise ValueError("Invalid Logistic boundary odds scales.")
        if params.shape != (self.width,) or not np.all(np.isfinite(params)) or np.any(params[:self.type_count] < 0):
            raise ValueError("Invalid Logistic boundary parameters.")
        self.odds_scale = scales
        bound = float(state.get("coefficient_bound", self.coefficient_bound))
        if not math.isfinite(bound) or bound <= .1 or np.any(np.abs(params[self.type_count:]) > bound + 1e-9):
            raise ValueError("Invalid stored Logistic shared-feature bound.")
        self.coefficient_bound = bound
        self.state = dict(state)
        self._profile_cache.clear()
        self._identifiable_cache.clear()
        return self

    def _profile(self, params, vector, probability):
        key = (tuple(vector), float(probability))
        if key in self._profile_cache:
            return self._profile_cache[key]
        kind, _ = self._query(vector)
        if probability == 0.:
            pure = (self.counts[:, kind] > 0) & (self.counts[:, kind] == self.counts.sum(axis=1))
            if np.any(pure & (self.k > 0)):
                # No nuisance type can explain a Fail in a chain containing
                # only the queried type when that type's risk is exactly zero.
                return math.inf, np.asarray(params)
        if probability == 1.:
            if np.any((self.counts[:, kind] > 0) & (self.n > self.k)):
                return math.inf, np.asarray(params)
            raise RuntimeError("A probability-one profile has no stable finite nuisance fit.")
        starts = [np.asarray(params).copy()]
        # Every other zero type is free to re-enter, including in the first
        # optimization; the second positive start also guards against flat starts.
        positive = starts[0].copy()
        positive[:self.type_count] = np.maximum(positive[:self.type_count], .25)
        starts.append(positive)
        nearby = [(abs(p - probability), value[1]) for (query, p), value in self._profile_cache.items() if query == tuple(vector)]
        if nearby:
            starts.append(min(nearby, key=lambda item: item[0])[1])
        fits = [self._optimize(start, (vector, probability)) for start in starts]
        finite = [fit for fit in fits if fit["converged"]]
        if not finite:
            raise RuntimeError("Boundary profile nuisance fit did not satisfy the odds KKT check.")
        reference = finite[0]["params"]
        best = min(finite, key=lambda fit: self._loss_change(fit["params"], reference))
        if any(self._loss_change(fit["params"], best["params"]) < -_loss_tolerance(best["minimum"]) for fit in fits):
            raise RuntimeError("An unconverged boundary profile candidate has a lower objective.")
        if np.any(np.abs(best["params"][self.type_count:]) >= self.coefficient_bound - .1):
            raise RuntimeError("Boundary profile reached a shared-feature numerical bound.")
        minimum = float(self.state["minimum"])
        if self._loss_change(best["params"], np.asarray(self.state["params"])) < -_loss_tolerance(minimum):
            raise RuntimeError("Boundary profile found a better optimum than the stored fit.")
        self._profile_cache[key] = (best["minimum"], best["params"])
        return self._profile_cache[key]

    def identifiable(self, params, vector):
        self._query(vector)
        if not self.state or not self.state.get("converged") or self.state.get("feature_clipped"):
            return False
        vector = np.asarray(vector)
        if np.linalg.norm(vector - self.design_basis @ (self.design_basis.T @ vector)) > 1e-7 * max(np.linalg.norm(vector), 1e-15):
            return False
        key = tuple(vector)
        if key in self._identifiable_cache:
            return self._identifiable_cache[key]
        params = np.asarray(params)
        _, _, _, J = self.evaluate(params)
        dependence = np.vstack([J[self.k > 0], (self.n - self.k) @ J])
        nonzero = np.max(np.abs(dependence), axis=1) > 0
        equality = dependence[nonzero]
        if len(equality):
            equality = equality / np.max(np.abs(equality), axis=1)[:, None]
        contrast = self.probability_gradient(params, vector)
        # An arbitrary unit box in raw u coordinates can hide a flat direction
        # when two types' odds scales differ by many orders of magnitude.
        column_norm = np.linalg.norm(equality, axis=0) if len(equality) else np.ones(self.width)
        column_scale = np.divide(1., column_norm, out=np.ones(self.width), where=column_norm > 0)
        equality = equality * column_scale[None, :]
        contrast = contrast * column_scale
        if len(equality):
            equality /= np.maximum(np.max(np.abs(equality), axis=1), 1e-300)[:, None]
        norm = np.linalg.norm(contrast)
        if not math.isfinite(norm) or norm == 0:
            self._identifiable_cache[key] = False
            return False
        contrast = contrast / norm
        bounds = [(0., 1.) if index < self.type_count and params[index] == 0 else (-1., 1.) for index in range(self.width)]
        arguments = dict(A_eq=equality if len(equality) else None, b_eq=np.zeros(len(equality)) if len(equality) else None,
                         bounds=bounds, method="highs")
        low, high = linprog(contrast, **arguments), linprog(-contrast, **arguments)
        identified = bool(low.success and high.success and max(abs(low.fun), abs(high.fun)) <= 1e-7)
        kind, _ = self._query(vector)
        if identified and params[kind] == 0:
            related = self.counts[:, kind] > 0
            observed_query = bool(np.any(np.all(np.isclose(self.design, vector, rtol=0., atol=1e-12), axis=1)))
            if np.any(self.k[related] > 0) or not observed_query:
                # Local cone information alone does not rule out a remote flat
                # allocation of mixed-chain risk. Check a positive probability.
                probe = max(1e-5, min(.01, 2. / max(float(self.n[related].sum()), 1.)))
                try:
                    _, profiled_params = self._profile(params, vector, probe)
                    identified = self._loss_change(profiled_params, params) > _loss_tolerance(float(self.state["minimum"]))
                except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError):
                    identified = False
        self._identifiable_cache[key] = identified
        return identified

    def _exact_zero_upper(self, vector, confidence):
        # Select the support from the complete numeric AND categorical design
        # before looking at outcomes. Never cherry-pick all-Pass chains.
        matching = np.all(np.isclose(self.design, vector, rtol=0., atol=1e-12), axis=1)
        copies = np.bincount(self.chain_index, weights=matching.astype(float), minlength=len(self.n))
        selected = copies > 0
        if not np.any(selected) or np.any(self.k[selected] > 0):
            return None
        exposure = float(self.n @ copies)
        all_counts = np.bincount(self.chain_index, minlength=len(self.n))
        pure = bool(np.all(copies[selected] == all_counts[selected]))
        # In mixed chains the remaining hazards are nonnegative, so the chance
        # of this all-Pass event is at most (1-p_query)^exposure. This gives a
        # conservative exact upper bound, without pretending nuisances are known.
        upper = -math.expm1(math.log1p(-confidence) / exposure)
        return 0., upper, EXACT_METHOD if pure else CONSERVATIVE_EXACT_METHOD

    def profile_interval(self, params, vector, confidence):
        if not 0 < confidence < 1:
            raise ValueError("Confidence level must lie strictly between zero and one.")
        if not self.identifiable(params, vector):
            raise RuntimeError("The requested Logistic boundary probability is not independently estimable.")
        params, vector = np.asarray(params), np.asarray(vector)
        estimate = self.probability(params, vector)
        if estimate == 0:
            exact = self._exact_zero_upper(vector, confidence)
            if exact is not None:
                return exact
        minimum = float(self.state["minimum"])
        cutoff = float(chi2.ppf(confidence, 1)) / 2
        self._profile_cache[(tuple(vector), estimate)] = (minimum, params.copy())

        def root(probability):
            value, candidate = self._profile(params, vector, probability)
            return math.inf if math.isinf(value) else self._loss_change(candidate, params) - cutoff

        if estimate == 0:
            lower = 0.
        else:
            zero = root(0.)
            lower = 0. if zero <= 0 else brentq(root, 0., estimate, xtol=1e-11)
        step = max(1e-5, min(.05, max(estimate, 1. / max(float(self.n.sum()), 1.))))
        upper = min(1., estimate + step)
        while upper < 1. and root(upper) < 0:
            step *= 2
            upper = min(1., estimate + step)
        upper = 1. if root(upper) <= 0 else brentq(root, estimate, upper, xtol=1e-11)
        return float(lower), float(upper), BOUNDARY_METHOD if estimate == 0 else INTERIOR_METHOD
