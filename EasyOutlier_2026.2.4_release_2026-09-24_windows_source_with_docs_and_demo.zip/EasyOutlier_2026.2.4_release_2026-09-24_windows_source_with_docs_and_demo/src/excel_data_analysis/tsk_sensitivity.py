"""Bounded, read-only sensitivity diagnostics for a fitted Logistic candidate.

These checks move along specified straight lines without refitting.  Even a
Jacobian null direction is reported only over an actually sampled interval;
the diagnostic is not a confidence interval or a global identifiability proof.
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np
from scipy.special import expit


PROBABILITY_ATOL = 1e-8
PROBABILITY_RTOL = 1e-5
NLL_ATOL = 1e-4
INSENSITIVE_STEP = .1
MAX_PARAMETERS = 24
MAX_SIDE_PROBES = 26


def _null_basis(matrix):
    _, singular, right = np.linalg.svd(matrix, full_matrices=matrix.shape[0] < matrix.shape[1])
    largest = float(singular[0]) if len(singular) else 0.
    tolerance = max(matrix.shape) * np.finfo(float).eps * largest * 100
    rank = int(np.sum(singular > tolerance))
    return rank, right[rank:], largest, tolerance


def _finite(value):
    number = float(value)
    return number if math.isfinite(number) else None


def _bounds(theta, direction, bound):
    lower, upper = -math.inf, math.inf
    for value, coefficient in zip(theta, direction):
        if abs(coefficient) <= 1e-14:
            continue
        endpoints = ((-bound - value) / coefficient, (bound - value) / coefficient)
        lower, upper = max(lower, min(endpoints)), min(upper, max(endpoints))
    return float(min(0., lower)), float(max(0., upper))


def _scan_direction(theta, direction, design, eta, chain_index, n, k, base_hazard,
                    base_probability, base_log_probability, bound):
    """At most 53 cached evaluations, including the shared zero evaluation."""
    projected = design @ direction
    lower, upper = _bounds(theta, direction, bound)
    tolerance = PROBABILITY_ATOL + PROBABILITY_RTOL * np.abs(base_probability)
    cache = {0.: {"delta": 0., "acceptable": True, "delta_nll": 0.,
                  "max_abs_delta_probability": 0., "max_probability_tolerance_ratio": 0.}}

    def evaluate(delta):
        delta = float(delta)
        if delta in cache:
            return cache[delta]
        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            hazard = np.bincount(chain_index, weights=np.logaddexp(0., eta + delta * projected), minlength=len(n))
            probability = -np.expm1(-hazard)
            positive = k > 0
            log_probability = np.log(probability[positive])
            # Difference per chain avoids subtracting two potentially enormous
            # total likelihoods.  Long-double accumulation reduces cancellation.
            changes = ((n - k) * (hazard - base_hazard)).astype(np.longdouble)
            changes[positive] -= (k[positive] * (log_probability - base_log_probability)).astype(np.longdouble)
            delta_nll = float(np.sum(changes, dtype=np.longdouble))
            difference = np.abs(probability - base_probability)
            maximum = float(np.max(difference, initial=0.))
            ratio = float(np.max(difference / tolerance, initial=0.))
        acceptable = bool(math.isfinite(delta_nll) and math.isfinite(ratio)
                          and abs(delta_nll) <= NLL_ATOL and ratio <= 1.)
        record = {"delta": delta, "acceptable": acceptable, "delta_nll": _finite(delta_nll),
                  "max_abs_delta_probability": _finite(maximum),
                  "max_probability_tolerance_ratio": _finite(ratio)}
        cache[delta] = record
        return record

    def side(sign, limit):
        if limit <= 1e-12:
            return 0., None, True
        starting_count = len(cache)

        def probe(distance):
            return evaluate(sign * float(distance))

        distance = min(.1, limit)
        reached = 0.
        while len(cache) - starting_count < 12:
            record = probe(distance)
            reached = distance
            if not record["acceptable"] or distance == limit:
                break
            distance = min(limit, distance * 2.)
        # Check the interior too: matching endpoint predictions never prove
        # that the whole connecting interval has matching predictions.
        for value in np.linspace(0., reached, 9)[1:]:
            if len(cache) - starting_count >= MAX_SIDE_PROBES - 6:
                break
            probe(value)
        points = sorted((abs(delta), record) for delta, record in cache.items()
                        if delta * sign >= 0 and abs(delta) <= reached)
        first_failure = next(((value, record) for value, record in points if not record["acceptable"]), None)
        if first_failure is None:
            return float(sign * reached), None, bool(reached == limit)
        high = first_failure[0]
        low = max(value for value, record in points if value < high and record["acceptable"])
        for _ in range(6):
            if len(cache) - starting_count >= MAX_SIDE_PROBES:
                break
            middle = (low + high) / 2.
            if probe(middle)["acceptable"]:
                low = middle
            else:
                high = middle
        return sign * low, probe(high), False

    verified_lower, failure_lower, lower_at_cap = side(-1., -lower)
    verified_upper, failure_upper, upper_at_cap = side(1., upper)
    verified = [record for delta, record in cache.items() if verified_lower <= delta <= verified_upper]
    return {
        "delta_lower": verified_lower, "delta_upper": verified_upper,
        "permitted_delta_lower": lower, "permitted_delta_upper": upper,
        "lower_at_cap": lower_at_cap, "upper_at_cap": upper_at_cap,
        "lower_endpoint": evaluate(verified_lower), "upper_endpoint": evaluate(verified_upper),
        "nearest_lower_failure": failure_lower, "nearest_upper_failure": failure_upper,
        "probe_count": len(cache), "verified_probe_count": len(verified),
        "sampled_deltas": sorted(cache),
        "max_abs_delta_nll_in_verified_samples": max(abs(record["delta_nll"]) for record in verified),
        "max_abs_delta_probability_in_verified_samples": max(record["max_abs_delta_probability"] for record in verified),
        "verification": "finite_contiguous_sampled_segment_not_mathematical_proof",
    }


def build_sensitivity_report(parameters, names, design, chain_index, n, k, bound=35, max_directions=6) -> dict[str, Any]:
    """Report bounded straight-line changes preserving the observed fit numerically."""
    theta = np.asarray(parameters, dtype=float)
    matrix = np.asarray(design, dtype=float)
    chain = np.asarray(chain_index, dtype=int)
    tested, failed = np.asarray(n, dtype=float), np.asarray(k, dtype=float)
    labels = [str(name) for name in names]
    cap = float(bound)
    if (theta.ndim != 1 or not len(theta) or matrix.ndim != 2 or matrix.shape[1] != len(theta)
            or len(labels) != len(theta) or chain.shape != (len(matrix),)
            or tested.ndim != 1 or failed.shape != tested.shape or not len(tested)
            or np.any(chain < 0) or np.any(chain >= len(tested))
            or np.any(tested <= 0) or np.any(failed < 0) or np.any(failed > tested)
            or not math.isfinite(cap) or cap <= 0
            or any(not np.all(np.isfinite(value)) for value in (theta, matrix, tested, failed))
            or np.any(np.abs(theta) > cap + 1e-8)):
        raise ValueError("Sensitivity diagnostics require finite, valid fitted arrays and parameters within the cap.")
    eta = matrix @ theta
    hazard = np.bincount(chain, weights=np.logaddexp(0., eta), minlength=len(tested))
    probability = -np.expm1(-hazard)
    positive = failed > 0
    with np.errstate(divide="ignore"):
        log_probability = np.log(probability[positive])
    nll = float((tested - failed) @ hazard - failed[positive] @ log_probability)
    if not math.isfinite(nll):
        raise ValueError("The candidate likelihood is not finite; sensitivity ranges are unavailable.")
    report = {
        "status": "ok", "bound": cap,
        "tolerances": {"probability_absolute": PROBABILITY_ATOL, "probability_relative": PROBABILITY_RTOL,
                       "absolute_nll_change": NLL_ATOL},
        "baseline": {"negative_log_likelihood": nll, "chain_count": len(tested), "parameter_count": len(theta)},
        "parameters": [], "directions": [],
        "notes": [
            "Ranges hold all other parameters fixed, or move only along the stated compensation direction; no refitting is performed.",
            "Only the contiguous segment containing zero with passing sampled checks is reported; finite sampling is not a proof between samples.",
            "Numerical insensitivity is not a confidence interval, permanent zero risk, or evidence that every parameter in the model is identifiable.",
            "Equivalence concerns the observed design and chains only; it does not justify predictions at unobserved combinations.",
        ],
    }

    def scan(direction):
        return _scan_direction(theta, direction, matrix, eta, chain, tested, failed, hazard,
                               probability, log_probability, cap)

    design_rank, design_null, design_norm, design_tolerance = _null_basis(matrix)
    derivative = np.zeros((len(tested), len(theta)))
    np.add.at(derivative, chain, expit(eta)[:, None] * matrix)
    chain_rank, chain_null, chain_norm, chain_tolerance = _null_basis(derivative)
    # Prioritize parameters involved in numerical null directions and weak
    # Jacobian columns when a large model exceeds the diagnostic budget.
    null_weight = np.linalg.norm(design_null, axis=0) + np.linalg.norm(chain_null, axis=0)
    column_norm = np.linalg.norm(derivative, axis=0)
    parameter_order = sorted(range(len(theta)), key=lambda index: (
        null_weight[index] <= 1e-7, column_norm[index], -abs(theta[index]), index))[:MAX_PARAMETERS]
    for index in sorted(parameter_order):
        direction = np.zeros(len(theta)); direction[index] = 1.
        item = scan(direction)
        item.update(index=index, name=labels[index], value=float(theta[index]),
                    value_lower=float(theta[index] + item["delta_lower"]),
                    value_upper=float(theta[index] + item["delta_upper"]),
                    near_cap=bool(abs(theta[index]) >= cap - .1),
                    insensitive_over_step=bool(item["delta_lower"] <= -INSENSITIVE_STEP
                                              or item["delta_upper"] >= INSENSITIVE_STEP))
        report["parameters"].append(item)
    report["omitted_parameter_count"] = len(theta) - len(parameter_order)

    local_directions = []
    for raw in chain_null:
        direction = raw - design_null.T @ (design_null @ raw)
        for previous in local_directions:
            direction -= previous * (previous @ direction)
        length = float(np.linalg.norm(direction))
        if length > 1e-7:
            local_directions.append(direction / length)
    maximum = max(0, min(6, int(max_directions)))
    design_limit = min(len(design_null), maximum if not local_directions else (maximum + 1) // 2)
    selected = [("design_null_numeric", row) for row in design_null[:design_limit]]
    selected.extend(("chain_jacobian_local_null", row) for row in local_directions[:maximum - len(selected)])
    if len(selected) < maximum:
        selected.extend(("design_null_numeric", row) for row in design_null[design_limit:design_limit + maximum - len(selected)])
    report["ranks"] = {"design": design_rank, "chain_jacobian": chain_rank,
                       "design_svd_tolerance": design_tolerance, "chain_svd_tolerance": chain_tolerance}
    report["omitted_direction_count"] = len(design_null) + len(local_directions) - len(selected)
    for kind, raw in selected:
        pivot = int(np.argmax(np.abs(raw)))
        direction = raw / raw[pivot]
        item = scan(direction)
        item.update(kind=kind, main_index=pivot, main_parameter=labels[pivot],
                    changes=[{"index": index, "name": labels[index], "per_unit_main": float(value)}
                             for index, value in enumerate(direction) if abs(value) > 1e-8],
                    design_residual_norm=float(np.linalg.norm(matrix @ direction)),
                    design_relative_residual=float(np.linalg.norm(matrix @ direction) /
                                                   max(design_norm * np.linalg.norm(direction), 1e-300)),
                    chain_jacobian_residual_norm=float(np.linalg.norm(derivative @ direction)),
                    chain_jacobian_relative_residual=float(np.linalg.norm(derivative @ direction) /
                                                           max(chain_norm * np.linalg.norm(direction), 1e-300)))
        report["directions"].append(item)
    return report


def format_sensitivity_report(report) -> str:
    """Human-readable debug text; do not present sampled ranges as intervals."""
    tolerance = report["tolerances"]
    lines = ["Logistic 参数敏感性诊断（原始 logit 候选；当前观测数据；不重新拟合）",
             f"每个原始系数的搜索限制为 [{-report['bound']:g}, {report['bound']:g}]；共同变化也同时遵守此限制。",
             f"判据：每条链 |Δp| ≤ {tolerance['probability_absolute']:.3g} + "
             f"{tolerance['probability_relative']:.3g}×|原 p|，且 |ΔNLL| ≤ {tolerance['absolute_nll_change']:.3g}。",
             "以下范围只包含从当前值连续检查通过的采样段；采样点之间不是数学保证，也不是置信区间。",
             f"“参数不敏感”是启发式标签：固定其他参数时，至少单侧 {INSENSITIVE_STEP:g} 个 logit 系数单位的变化通过上述容差。",
             "单个参数变化，其他参数固定："]

    def truncation(row):
        notes = []
        if row["lower_at_cap"]:
            notes.append("下端被系数上限截断")
        elif row["nearest_lower_failure"] is None:
            notes.append("下端受探测预算限制")
        if row["upper_at_cap"]:
            notes.append("上端被系数上限截断")
        elif row["nearest_upper_failure"] is None:
            notes.append("上端受探测预算限制")
        return "；" + "、".join(notes) if notes else ""

    for row in report["parameters"]:
        label = "参数不敏感（在下述容差范围内）" if row["insensitive_over_step"] else "仅很小变化通过容差"
        endpoint = max(abs(row["lower_endpoint"]["delta_nll"]), abs(row["upper_endpoint"]["delta_nll"]))
        probability_change = max(row["lower_endpoint"]["max_abs_delta_probability"],
                                 row["upper_endpoint"]["max_abs_delta_probability"])
        lines.append(f"  {row['name']}={row['value']:.7g}：{label}；可检查范围 "
                     f"[{row['value_lower']:.7g}, {row['value_upper']:.7g}]；"
                     f"{row['probe_count']} 个探测点，端点最大 |Δp|={probability_change:.3g}，|ΔNLL|={endpoint:.3g}"
                     f"{truncation(row)}。")
    if report.get("omitted_parameter_count"):
        lines.append(f"  其余 {report['omitted_parameter_count']} 个参数未扫描（计算量限制）。")
    lines.append("共同变化方向（主参数增加 δ，以下参数按比例一起变化）：")
    if not report["directions"]:
        lines.append("  未发现所用数值秩阈值下的零方向；这不证明全局可识别。")
    for row in report["directions"]:
        ratios = "; ".join(f"{item['name']} += {item['per_unit_main']:.6g}×δ" for item in row["changes"])
        kind = "设计矩阵数值零方向，当前观测设计下的数值补偿（只验证所列范围）" if row["kind"] == "design_null_numeric" else "链 Jacobian 局部零方向，已实际回算，不能推广为全局等价"
        lines.append(f"  {kind}：{ratios}；δ ∈ [{row['delta_lower']:.7g}, {row['delta_upper']:.7g}]；"
                     f"{row['probe_count']} 个探测点；设计残差={row['design_residual_norm']:.3g}，"
                     f"链 Jacobian 残差={row['chain_jacobian_residual_norm']:.3g}；"
                     f"通过区间的采样最大 |Δp|={row['max_abs_delta_probability_in_verified_samples']:.3g}，"
                     f"|ΔNLL|={row['max_abs_delta_nll_in_verified_samples']:.3g}{truncation(row)}。")
    if report.get("omitted_direction_count"):
        lines.append(f"  其余 {report['omitted_direction_count']} 个数值零方向未扫描（计算量限制）。")
    lines.append("极负参数处的数值不敏感不等于永久零风险；范围受当前参数上限、数据和容差约束，不用于无数据组合外推。")
    return "\n".join(lines)
