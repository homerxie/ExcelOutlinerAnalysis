"""Per-chain physical members evaluated at their actual fitted conditions.

This report never substitutes a type's reference-environment probability for
an instance prediction, and never computes a member confidence interval.
Identical fitted designs share one query and one grouped display row.
"""

from __future__ import annotations

from copy import deepcopy
import json
import math
from numbers import Real
from time import monotonic
from typing import Any, Mapping, Sequence

import numpy as np

from .tsk_features import category_label


def _get(item, key, default=None):
    return item.get(key, default) if isinstance(item, Mapping) else getattr(item, key, default)


def _plain(value):
    if isinstance(value, Mapping):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    if isinstance(value, np.generic):
        return _plain(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _number(value):
    return float(value) if isinstance(value, Real) and not isinstance(value, bool) and math.isfinite(value) else None


def build_chain_members(
    instances: Sequence[Any], chain_rows: Sequence[Any], type_rows: Sequence[Any], *,
    context: Mapping[str, Any] | None = None, boundary_engine=None,
    feature_names: Sequence[str] = (), categorical_feature_names: Sequence[str] = (), use_xy: bool = False,
    progress_callback=None,
) -> dict[str, list[dict[str, Any]]]:
    """Return topology members with identified point risks, keyed by chain ID.

    ``context`` uses the frozen fit schema also consumed by ``_FrozenFit``.
    Passing the already-fitted boundary engine reuses its verification cache.
    With no context, baseline type estimates remain usable; selected feature
    models have no member predictions until a complete fitted context exists.
    """
    context = context or {}
    categories = context.get("categorical_features", {})
    categorical_names = list(dict.fromkeys([*categorical_feature_names, *categories]))
    columns = list(context.get("coefficient_columns", []))
    selected_names = list(dict.fromkeys([
        *(("x", "y") if use_xy else ()), *feature_names,
        *(name for name, _ in columns), *categorical_names,
    ]))
    scaling = context.get("numeric_scaling", {})
    model = context.get("model", "instance_features" if selected_names else "type_only")
    baseline = model == "type_only" and not selected_names
    chains = {str(_get(row, "chain_id")): row for row in chain_rows}
    types = {str(_get(row, "tsk_id")): row for row in type_rows}
    type_index = {name: index for index, name in enumerate(context.get("type_ids", []))}
    width = len(context.get("coefficients", []))
    state = context.get("boundary_fit") or {}
    valid = bool(context.get("converged") and not context.get("clipped")
                 and (not state or state.get("converged") and not state.get("feature_clipped")))
    fit = None
    initialization_error = None
    if not baseline and context and valid:
        try:
            if boundary_engine is None:
                from .tsk_prediction import _FrozenFit
                fit = _FrozenFit(context)
                boundary_engine = fit.boundary_engine
            valid = valid and (fit.valid_fit if fit is not None else bool(boundary_engine.state.get("converged")))
        except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
            valid = False
            initialization_error = str(error)
    parameters = np.asarray(state.get("params", []), dtype=float)
    certified_zero_types = set()
    if boundary_engine is not None:
        parameters = np.asarray(boundary_engine.state["params"], dtype=float)
        # With finite shared effects, p=0 for any supported condition of a type
        # means that type's reference odds are zero. Reuse established zero
        # identifiability instead of profiling every category of the same type.
        for query, identified in boundary_engine._identifiable_cache.items():
            index = int(np.argmax(query[:boundary_engine.type_count]))
            if identified and parameters[index] == 0:
                certified_zero_types.add(index)
    cache = {}
    last_progress = monotonic()

    def progress(index, tsk_id):
        nonlocal last_progress
        if progress_callback is not None and (index == 0 or monotonic() - last_progress >= 1.):
            last_progress = monotonic()
            progress_callback(int(100 * index / max(len(instances), 1)),
                              f"Chain 成员：复核 {tsk_id} 在实际实例条件下的风险…")

    def result(probability=None, *, identifiable=False, status="not_identifiable", reason="", estimate_kind="interior"):
        return {"probability": probability, "identifiable": identifiable, "status": status,
                "reason": reason, "estimate_kind": estimate_kind}

    def predict(tsk_id, vector):
        if baseline:
            row = types.get(tsk_id)
            probability = _number(_get(row, "probability"))
            if row is not None and _get(row, "identifiable", False) and probability is not None:
                return result(probability, identifiable=True,
                              status="boundary_low" if probability == 0 else "ok",
                              estimate_kind="boundary_low" if probability == 0 else _get(row, "estimate_kind", "interior"))
            status = "fit_not_converged" if _get(row, "status") == "fit_not_converged" else "not_identifiable"
            return result(status=status, reason="该 TSK 的单独风险尚未得到可识别的有效估计。")
        if not valid:
            return result(status="fit_not_converged" if context else "unavailable",
                          reason=initialization_error or "尚无有效特征模型，不能把 TSK 参考概率当作实际实例风险。")
        if vector is None:
            return result(status="unavailable", reason="实例的实际特征条件无法按当前模型编码。")
        key = tuple(vector)
        if key in cache:
            return deepcopy(cache[key])
        try:
            kind = type_index[tsk_id]
            if boundary_engine is not None:
                if kind in certified_zero_types:
                    outcome = result(0., identifiable=True, status="boundary_low", estimate_kind="boundary_low")
                else:
                    identified = boundary_engine.identifiable(parameters, vector)
                    probability = boundary_engine.probability(parameters, vector) if identified else None
                    boundary = identified and probability == 0.
                    if boundary:
                        certified_zero_types.add(kind)
                    outcome = result(probability, identifiable=identified,
                                     status="boundary_low" if boundary else "ok" if identified else "not_identifiable",
                                     estimate_kind="boundary_low" if boundary else "interior",
                                     reason="" if identified else "链的整体风险可计算，但无法单独确定该实例条件的风险。")
            else:
                identified = fit.identifiable(vector)
                probability = fit.probability(vector) if identified else None
                outcome = result(probability, identifiable=identified and probability is not None,
                                 status="ok" if probability is not None else "outside_model_domain" if identified else "not_identifiable",
                                 reason="" if probability is not None else "实际条件超出非负风险模型的定义域。" if identified else
                                 "链的整体风险可计算，但无法单独确定该实例条件的风险。")
        except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
            outcome = result(status="unavailable", reason=f"该实例条件未能完成风险识别：{error}")
        if outcome["probability"] is not None and (not math.isfinite(outcome["probability"])
                                                    or not 0 <= outcome["probability"] <= 1):
            outcome = result(status="unavailable", reason="该实例条件未得到有限、有效的风险概率。")
        cache[key] = outcome
        return deepcopy(outcome)

    members: dict[str, dict[Any, dict[str, Any]]] = {}
    for instance_index, instance in enumerate(instances):
        chain_id, tsk_id = str(_get(instance, "chain_id")), str(_get(instance, "tsk_id"))
        instance_id = str(_get(instance, "instance_id", _get(instance, "tsk_instance_id", "")))
        features = dict(_get(instance, "features", {}) or {})
        progress(instance_index, tsk_id)
        actual_categories, numeric = {}, {}
        encoded = True
        for name in selected_names:
            value = _get(instance, name) if name in {"x", "y"} else features.get(name)
            if name in categorical_names:
                try:
                    actual_categories[name] = category_label(value, name)
                    if name in categories and actual_categories[name] not in {
                            category_label(level, name) for level in categories[name]["levels"]}:
                        encoded = False
                except ValueError:
                    actual_categories[name] = _plain(value)
                    encoded = False
            else:
                numeric[name] = _number(value)
                encoded = encoded and numeric[name] is not None
        conditions = {name: actual_categories[name] if name in actual_categories else numeric[name] for name in selected_names}
        vector = None
        if not baseline and encoded and tsk_id in type_index:
            vector = np.zeros(width)
            vector[type_index[tsk_id]] = 1.
            for index, (name, level) in enumerate(columns, start=len(type_index)):
                if level is None:
                    values = scaling.get(name, {})
                    mean, scale = _number(values.get("mean")), _number(values.get("scale"))
                    if mean is None or scale is None or scale <= 0:
                        vector = None
                        break
                    vector[index] = (numeric[name] - mean) / scale
                else:
                    vector[index] = float(actual_categories[name] == category_label(level, name))
        # Numeric equality in the fitted design determines aggregation. Keep
        # the selected actual conditions as the display fallback without a fit.
        key = (tsk_id, tuple(vector)) if vector is not None else (
            tsk_id, json.dumps(_plain(conditions), ensure_ascii=False, sort_keys=True))
        grouped = members.setdefault(chain_id, {})
        if key in grouped:
            grouped[key]["instance_ids"].append(instance_id)
            grouped[key]["count"] += 1
            continue
        tested = _get(chains.get(chain_id), "n_tested", 0)
        prediction = predict(tsk_id, vector) if tested else result(status="no_data", reason="该链没有有效测试数据，成员风险留空。")
        grouped[key] = {"tsk_id": tsk_id, "instance_ids": [instance_id], "count": 1,
                        "features": conditions, "categories": actual_categories, "numeric": numeric,
                        "condition_scope": "actual_selected_model_features", **prediction}
    if progress_callback is not None:
        progress_callback(100, "Chain 成员实际条件风险已准备完成。")
    from .tsk_sorting import natural_sort_key
    return _plain({chain_id: sorted(grouped.values(), key=lambda row: natural_sort_key(row["tsk_id"]))
                   for chain_id, grouped in sorted(members.items(), key=lambda item: natural_sort_key(item[0]))})
