"""Compact, lossless in-memory containers for a single filtered analysis scope."""
from __future__ import annotations

from array import array
from collections.abc import Mapping, Sequence

from .models import MeasurementRecord


class ColumnarMeasurements(Sequence):
    """Keep numeric values and metadata IDs in arrays; reconstruct records on demand.

    Row and test metadata are shared within this scope and treated as read-only.
    No filtering, aggregation, rounding, or missing-value filling happens here.
    """

    def __init__(self, records=()):
        self._values = array("d")
        self._exact_values = {}
        self._row_ids = array("I")
        self._test_ids = array("I")
        self._rows = []
        self._tests = []
        self._row_lookup = {}
        self._test_lookup = {}
        self._last_row_id = None
        for record in records:
            self.append(record)

    def append(self, record):
        row_id = self._last_row_id
        identity = (record.dataset_id, record.source_file, record.row_number)
        if row_id is None or self._rows[row_id][:3] != identity or self._rows[row_id][3] != record.dimensions:
            row_key = (*identity, tuple(sorted(record.dimensions.items())))
            row_id = self._row_lookup.get(row_key)
            if row_id is None:
                row_id = len(self._rows)
                self._row_lookup[row_key] = row_id
                self._rows.append((*identity, dict(record.dimensions)))
            self._last_row_id = row_id
        test = (record.logical_metric, record.group_id, record.group_display_name,
                record.presentation_group, record.raw_column)
        test_id = self._test_lookup.get(test)
        if test_id is None:
            test_id = len(self._tests)
            self._test_lookup[test] = test_id
            self._tests.append(test)
        # Normal imported values are doubles. Legacy integer records may exceed
        # the exact range of float64; retain those rare values without rounding.
        try:
            numeric = float(record.value)
        except OverflowError:
            numeric = 0.0
        if isinstance(record.value, int) and numeric != record.value:
            self._exact_values[len(self._values)] = record.value
        self._values.append(numeric)
        self._row_ids.append(row_id)
        self._test_ids.append(test_id)

    def __len__(self):
        return len(self._values)

    def value_at(self, index):
        if index < 0:
            index += len(self)
        return self._exact_values.get(index, self._values[index])

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [self[i] for i in range(*index.indices(len(self)))]
        dataset, source, row_number, dimensions = self._rows[self._row_ids[index]]
        metric, group, display, presentation, raw_column = self._tests[self._test_ids[index]]
        return MeasurementRecord(dataset, source, row_number, metric, group, display,
                                 presentation, raw_column, self.value_at(index), dimensions)

    def __iter__(self):
        for index in range(len(self)):
            yield self[index]


class DenseZScoreMap(Mapping):
    """Dict-compatible score lookup with shared axes and contiguous numeric arrays.

    Callers select this representation only for sufficiently dense data. Missing
    entries, a None threshold and a zero score remain distinct; duplicate keys
    overwrite their old value without changing iteration order, just like dict.
    """

    def __init__(self, row_keys, raw_columns, value_type):
        self._rows = list(dict.fromkeys(row_keys))
        self._columns = list(dict.fromkeys(raw_columns))
        self._row_index = {key: index for index, key in enumerate(self._rows)}
        self._column_index = {key: index for index, key in enumerate(self._columns)}
        self._value_type = value_type
        length = len(self._rows) * len(self._columns)
        self._scores = array("d", [0.0]) * length
        self._thresholds = array("d", [0.0]) * length
        self._flags = bytearray(length)
        self._order = array("Q")

    def _offset(self, key):
        return self._row_index[key[:2]] * len(self._columns) + self._column_index[key[2]]

    def add(self, key, score, threshold, is_fail):
        offset = self._offset(key)
        if not self._flags[offset]:
            self._order.append(offset)
        self._scores[offset] = score
        self._thresholds[offset] = threshold if threshold is not None else 0.0
        self._flags[offset] = 1 | (2 if is_fail else 0) | (4 if threshold is None else 0)

    def __getitem__(self, key):
        offset = self._offset(key)
        flags = self._flags[offset]
        if not flags:
            raise KeyError(key)
        return self._value_type(value=self._scores[offset],
                                threshold=None if flags & 4 else self._thresholds[offset],
                                golden_value=None, is_fail=bool(flags & 2))

    def __iter__(self):
        width = len(self._columns)
        for offset in self._order:
            row, column = divmod(offset, width)
            yield (*self._rows[row], self._columns[column])

    def __len__(self):
        return len(self._order)
