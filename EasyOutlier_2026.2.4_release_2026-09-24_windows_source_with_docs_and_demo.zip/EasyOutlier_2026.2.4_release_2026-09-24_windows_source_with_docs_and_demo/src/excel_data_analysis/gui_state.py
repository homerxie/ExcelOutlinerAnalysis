from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile
from typing import Any


GUI_STATE_FILENAME = ".excel_data_analysis_gui_state.json"


def gui_state_path(storage_path: str | Path) -> Path:
    return Path(storage_path) / GUI_STATE_FILENAME


def save_gui_state(
    storage_path: str | Path,
    payload: dict[str, Any],
) -> Path:
    target = gui_state_path(storage_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=target.parent,
                                         prefix=".gui-state-", suffix=".tmp", delete=False) as handle:
            temporary = Path(handle.name)
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return target


def load_gui_state(
    storage_path: str | Path,
) -> dict[str, Any] | None:
    target = gui_state_path(storage_path)
    if not target.exists():
        return None
    return json.loads(target.read_text(encoding="utf-8"))
