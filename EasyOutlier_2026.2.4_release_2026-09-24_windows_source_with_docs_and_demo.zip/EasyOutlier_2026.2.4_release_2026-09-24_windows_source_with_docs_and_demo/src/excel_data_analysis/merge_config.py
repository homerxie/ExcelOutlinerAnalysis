"""Public merge vocabulary and inclusive (retained-level) boundaries."""
from __future__ import annotations

from .models import TemplateConfig

TEMPLATE_SCHEMA_VERSION = 3
MERGE_RULE_FIELDS = {
    "initial_column_merge_fail_rule": "outlier_merged_test_fail_rule",
    "final_column_merge_fail_rule": "outlier_test_group_fail_rule",
    "initial_row_merge_fail_rule": "outlier_merged_sample_fail_rule",
    "final_row_merge_fail_rule": "outlier_node_fail_rule",
}
MERGE_STEP_LABELS = {
    "column merge": "Initial column merge",
    "column group": "Final column merge",
    "row merge": "Initial row merge",
    "row node": "Final row merge",
}


def normalize_merge_order(value: str) -> str:
    aliases = {**MERGE_STEP_LABELS, **{v.lower(): v for v in MERGE_STEP_LABELS.values()}}
    return " -> ".join(aliases.get(part.strip().lower(), part.strip()) for part in value.split("->"))


def legacy_merge_order(value: str) -> str:
    reverse = {v: k for k, v in MERGE_STEP_LABELS.items()}
    return " -> ".join(reverse.get(part.strip(), part.strip()) for part in normalize_merge_order(value).split("->"))


def row_levels(template: TemplateConfig) -> list[str]:
    return [d.name for d in sorted(template.row_dimensions, key=lambda d: d.priority)]


def column_levels(template: TemplateConfig) -> list[str]:
    return [d.name for d in sorted(template.column_header_levels, key=lambda d: d.priority)]


def chain_level(template: TemplateConfig) -> str:
    names = column_levels(template)
    return template.report.chain_column_level or (names[0] if names else "")


def retained_level(names: list[str], legacy_start: str | None) -> str | None:
    """The old start level itself was removed; retain its immediate parent."""
    if legacy_start not in names:
        return None
    index = names.index(legacy_start)
    return names[index - 1] if index > 0 else None


def initial_row_level(template: TemplateConfig) -> str | None:
    if template.report.initial_row_merge_level:
        return template.report.initial_row_merge_level
    if template.report.outlier_row_merge_max_dimension:
        return retained_level(row_levels(template), template.report.outlier_row_merge_max_dimension)
    return template.report.reliability_node_dimension


def default_initial_column_level(template: TemplateConfig, chain: str | None = None) -> str | None:
    names = column_levels(template)
    final = chain if chain is not None else chain_level(template)
    if final not in names:
        return None
    return names[min(names.index(final) + 1, len(names) - 1)]


def initial_column_level(template: TemplateConfig) -> str | None:
    if template.report.initial_column_merge_level:
        return template.report.initial_column_merge_level
    if template.report.outlier_test_merge_max_level:
        return retained_level(column_levels(template), template.report.outlier_test_merge_max_level)
    return default_initial_column_level(template)


def validate_merge_levels(template: TemplateConfig) -> None:
    for names, initial, final, label in (
        (row_levels(template), initial_row_level(template), template.report.reliability_node_dimension, "row"),
        (column_levels(template), initial_column_level(template), chain_level(template), "column"),
    ):
        if not names:
            continue
        if final not in names:
            raise ValueError(f"Final {label} target {final!r} must name an existing {'node dimension' if label == 'row' else 'Chain column level'}.")
        if initial not in names:
            raise ValueError(f"initial_{label}_merge_level must select the level to retain. The legacy merge start has no parent; select and confirm a level before upgrading or analysing.")
        if names.index(initial) < names.index(final):
            raise ValueError(f"initial_{label}_merge_level={initial} cannot be above the fixed Final target {final}; merged information cannot be restored.")
    validate_same_level_rules(template)


def same_level_rule_conflicts(template: TemplateConfig) -> list[dict[str, str]]:
    conflicts = []
    for axis, initial, final in (
        ("row", initial_row_level(template), template.report.reliability_node_dimension),
        ("column", initial_column_level(template), chain_level(template)),
    ):
        first_field = MERGE_RULE_FIELDS[f"initial_{axis}_merge_fail_rule"]
        final_field = MERGE_RULE_FIELDS[f"final_{axis}_merge_fail_rule"]
        first_rule = getattr(template.report, first_field)
        final_rule = getattr(template.report, final_field)
        if initial and initial == final and first_rule != final_rule:
            conflicts.append(dict(axis=axis, level=initial, initial_rule=first_rule,
                                  final_rule=final_rule, initial_field=first_field,
                                  final_field=final_field))
    return conflicts


def validate_same_level_rules(template: TemplateConfig) -> None:
    conflicts = same_level_rule_conflicts(template)
    if conflicts:
        details = "; ".join(
            f"{c['axis']}={c['level']}: initial_{c['axis']}_merge_fail_rule={c['initial_rule']}, "
            f"final_{c['axis']}_merge_fail_rule={c['final_rule']}" for c in conflicts
        )
        raise ValueError("模板合并判据冲突：Initial 与 Final 保留到同一层级时，必须使用相同判据。"
                         "请选择 any_fail（任一失败）或 all_fail（全部失败），并保存当前模板。 " + details)
