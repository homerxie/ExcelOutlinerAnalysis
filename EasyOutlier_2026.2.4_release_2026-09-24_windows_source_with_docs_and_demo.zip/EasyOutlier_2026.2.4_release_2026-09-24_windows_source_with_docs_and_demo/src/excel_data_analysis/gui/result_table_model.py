"""Lazy display of result rows without allocating objects for empty Lot cells."""
from __future__ import annotations

import re

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt


class OutlierRatioTableModel(QAbstractTableModel):
    FIELDS = (
        "id", "display_name", "group_by_dimension", "group_value", "numerator",
        "outlier_sample_count", "total_sample_count", "outlier_ratio", "filter_summary",
    )
    HEADERS = (
        "ID", "Display Name", "Group By Dimension", "Group Value", "Numerator",
        "Outlier Sample Count", "Total Sample Count", "Outlier Ratio", "Filter Summary",
    )

    def __init__(self, parent=None):
        super().__init__(parent)
        self._rows = []
        self._lot_columns = 0
        self._sort_column = -1
        self._sort_order = Qt.AscendingOrder

    def set_rows(self, rows):
        self.beginResetModel()
        self._rows = list(rows)  # Only row references; cell strings stay lazy.
        self._lot_columns = 2 * max((len(row.get("lot_sample_pairs", [])) for row in rows), default=0)
        if 0 <= self._sort_column < self.columnCount():
            self._rows.sort(key=lambda row: self._sort_key(row, self._sort_column),
                            reverse=self._sort_order == Qt.DescendingOrder)
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self._rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.FIELDS) + self._lot_columns

    def _value(self, row, column):
        if column < len(self.FIELDS):
            return str(row.get(self.FIELDS[column], ""))
        pair_index, member = divmod(column - len(self.FIELDS), 2)
        pairs = row.get("lot_sample_pairs", [])
        if pair_index < len(pairs):
            pair = pairs[pair_index]
            if isinstance(pair, (tuple, list)) and len(pair) >= 2:
                return str(pair[member])
        return ""

    def data(self, index, role=Qt.DisplayRole):
        if index.isValid() and role == Qt.DisplayRole:
            return self._value(self._rows[index.row()], index.column())
        return None

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Vertical:
            return str(section + 1)
        if section < len(self.HEADERS):
            return self.HEADERS[section]
        pair_index, member = divmod(section - len(self.HEADERS), 2)
        return f"{'Lot' if member == 0 else 'Sample IDs'} {pair_index + 1}"

    def _sort_key(self, row, column):
        return tuple((0, int(part)) if part.isdigit() else (1, part.lower())
                     for part in re.split(r"(\d+)", self._value(row, column)) if part)

    def sort(self, column, order=Qt.AscendingOrder):
        self._sort_column, self._sort_order = column, order
        if not 0 <= column < self.columnCount():
            return
        old_indexes = self.persistentIndexList()
        old_rows = [self._rows[index.row()] for index in old_indexes]
        self.layoutAboutToBeChanged.emit()
        self._rows.sort(key=lambda row: self._sort_key(row, column), reverse=order == Qt.DescendingOrder)
        positions = {id(row): i for i, row in enumerate(self._rows)} if old_indexes else {}
        self.changePersistentIndexList(old_indexes, [self.index(positions[id(row)], index.column())
                                                    for row, index in zip(old_rows, old_indexes)])
        self.layoutChanged.emit()
