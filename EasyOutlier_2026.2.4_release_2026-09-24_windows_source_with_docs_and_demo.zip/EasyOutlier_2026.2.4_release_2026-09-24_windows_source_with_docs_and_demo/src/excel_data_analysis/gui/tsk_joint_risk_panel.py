"""Read-only presentation of verified joint risks; form owns static wording."""
from __future__ import annotations

import json
import math

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QSortFilterProxyModel, Qt
from PySide6.QtWidgets import QHeaderView, QWidget

from .tsk_risk_display import (
    boundary_note, percentage, risk_available, risk_interval_kind, risk_interval_text,
    risk_probability_text, valid_probability,
)
from .ui_tsk_joint_risk_panel import Ui_TskJointRiskPanelForm


class _JointRiskTableModel(QAbstractTableModel):
    def __init__(self, headers, parent=None):
        super().__init__(parent)
        self.headers = list(headers)
        self.rows = []

    def set_rows(self, rows):
        self.beginResetModel()
        self.rows = rows
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.headers)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        display, raw, tooltip = self.rows[index.row()][index.column()]
        if role == Qt.DisplayRole:
            return display
        if role == Qt.UserRole:
            return raw
        if role == Qt.ToolTipRole:
            return tooltip or display
        if role == Qt.TextAlignmentRole and isinstance(raw, (int, float)) and not isinstance(raw, bool):
            return int(Qt.AlignRight | Qt.AlignVCenter)
        return None

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role == Qt.DisplayRole and orientation == Qt.Horizontal and 0 <= section < len(self.headers):
            return self.headers[section]
        return super().headerData(section, orientation, role)


class TskJointRiskPanel(QWidget):
    """Display precomputed results without fitting or extrapolating in the UI."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskJointRiskPanelForm()
        self.ui.setupUi(self)
        table = self.ui.risksTableView
        self.risk_model = _JointRiskTableModel(table.property("columnHeaders"), self)
        self.proxy_model = QSortFilterProxyModel(table)
        self.proxy_model.setSourceModel(self.risk_model)
        self.proxy_model.setSortRole(Qt.UserRole)
        table.setModel(self.proxy_model)
        table.sortByColumn(-1, Qt.AscendingOrder)
        table.horizontalHeader().setResizeContentsPrecision(100)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        table.selectionModel().currentRowChanged.connect(self._show_detail)
        self.report = {}
        self._rows = []

    @staticmethod
    def _cell(value, *, tooltip=""):
        return str(value or ""), value, tooltip

    @staticmethod
    def _percent_cell(value, *, tooltip=""):
        return (f"{value * 100:.5g}%", value, tooltip) if valid_probability(value) else ("", None, tooltip)

    @staticmethod
    def _available(row):
        return row.get("status") in {"ok", "boundary_low", "interval_unavailable", "model_interval_mismatch"} and risk_available(row)

    def _status(self, row):
        key = {
            "ok": "okText", "no_data": "noDataText", "not_identifiable": "notIdentifiableText",
            "fit_not_converged": "fitNotConvergedText", "interval_unavailable": "intervalUnavailableText",
            "boundary_low": "boundaryLowText", "unavailable": "unavailableText",
            "computation_limited": "computationLimitedText", "model_interval_mismatch": "modelIntervalMismatchText",
        }.get(row.get("status"), "unavailableText")
        return str(self.ui.risksTableView.property(key))

    def _kind(self, row):
        key = {"multiple_instances": "multipleInstancesText", "joint_conditions": "jointConditionsText"}.get(row.get("kind"))
        return str(self.ui.risksTableView.property(key)) if key else str(row.get("kind", ""))

    @staticmethod
    def _conditions(row):
        value = row.get("conditions", "")
        if not isinstance(value, dict):
            return str(value or "")
        parts = []
        for key, item in value.items():
            if isinstance(item, dict):
                parts.extend(f"{name}={condition}" for name, condition in item.items())
            else:
                parts.append(f"{key}={item}")
        return " · ".join(parts)

    def _members(self, row):
        value = row.get("members", "")
        if isinstance(value, list):
            members = []
            table = self.ui.risksTableView
            for item in value:
                if not isinstance(item, dict):
                    members.append(str(item))
                    continue
                conditions = " · ".join(f"{key}={part}" for definition in (item.get("categories", {}), item.get("numeric", {}))
                    for key, part in definition.items())
                count = item.get("count")
                count_text = f"{count:g}" if isinstance(count, (int, float)) and not isinstance(count, bool) and math.isfinite(count) else ""
                members.append(table.property("memberFormat").format(tsk_id=item.get("tsk_id") or item.get("label", ""), count=count_text,
                    conditions=table.property("memberConditionFormat").format(conditions=conditions) if conditions else ""))
            return " + ".join(members)
        return str(value or "")

    def _interval_kind(self, row):
        if (row.get("interval_method") == "conservative_binomial_chain_bounds" and
                row.get("interval_sidedness") != "upper" and valid_probability(row.get("ci_lower")) and
                valid_probability(row.get("ci_upper"))):
            confidence = row.get("confidence_level") or .95
            return self.ui.risksTableView.property("conservativeIntervalKindFormat").format(confidence=f"{confidence:.0%}")
        return risk_interval_kind(self.ui.risksTableView, row)

    def _interval_text(self, row):
        if (row.get("interval_method") == "conservative_binomial_chain_bounds" and
                row.get("interval_sidedness") != "upper" and valid_probability(row.get("ci_lower")) and
                valid_probability(row.get("ci_upper"))):
            confidence = row.get("confidence_level") or .95
            return self.ui.risksTableView.property("conservativeIntervalFormat").format(confidence=f"{confidence:.0%}",
                lower=percentage(row["ci_lower"]), upper=percentage(row["ci_upper"]))
        return risk_interval_text(self.ui.risksTableView, row)

    def _details(self, row):
        widget = self.ui.detailsTextEdit
        table = self.ui.risksTableView
        available = self._available(row)
        details = [widget.property("detailFormat").format(
            group=row.get("label") or row.get("group_id", ""), kind=self._kind(row), members=self._members(row),
            conditions=self._conditions(row) or widget.property("noneText"),
            probability=risk_probability_text(table, row) if available else "—",
            interval=self._interval_text(row) if available else "—", status=self._status(row), reason=row.get("reason") or "—")]
        if row.get("formula"):
            details.append(widget.property("formulaFormat").format(formula=row["formula"]))
        if row.get("parameter_names"):
            details.append(widget.property("parametersFormat").format(parameters=" · ".join(row["parameter_names"])))
        if row.get("chain_count") is not None or row.get("test_exposure") is not None:
            details.append(widget.property("supportFormat").format(chains=row.get("chain_count", "—"), exposure=row.get("test_exposure", "—")))
        if row.get("certificate"):
            certificate = row["certificate"]
            if not isinstance(certificate, str):
                certificate = json.dumps(certificate, ensure_ascii=False, indent=2)
            details.append(widget.property("certificateFormat").format(certificate=certificate))
        if row.get("interval_method"):
            method = row["interval_method"]
            if method == "conservative_binomial_chain_bounds":
                method = f"{widget.property('conservativeBinomialMethodText')} ({method})"
            details.append(widget.property("methodFormat").format(method=method))
        if row.get("interval_error"):
            details.append(widget.property("intervalErrorFormat").format(error=row["interval_error"]))
        if available and boundary_note(table, row):
            details.append(boundary_note(table, row))
        details.extend(str(item) for item in row.get("notes", []) if item)
        details.extend(str(item) for item in self.report.get("notes", []) if item)
        return "\n\n".join(details)

    def set_group(self, group):
        """Bind a saved group report; unsupported or unidentifiable rows stay blank."""
        self.report = (group or {}).get("joint_risk") or {}
        self._rows = list(self.report.get("rows") or [])
        table = self.ui.risksTableView
        rows = []
        for row in self._rows:
            available = self._available(row)
            tooltip = self._details(row)
            probability = (risk_probability_text(table, row), row.get("probability"), tooltip) if available else ("", None, tooltip)
            rows.append([
                self._cell(row.get("label") or row.get("group_id"), tooltip=tooltip), self._cell(self._kind(row), tooltip=tooltip),
                self._cell(self._members(row), tooltip=tooltip), self._cell(self._conditions(row), tooltip=tooltip),
                probability,
                self._percent_cell(row.get("ci_lower") if available and row.get("interval_sidedness") != "upper" else None, tooltip=tooltip),
                self._percent_cell(row.get("ci_upper") if available else None, tooltip=tooltip),
                self._cell(self._interval_kind(row) if available else "", tooltip=tooltip),
                self._cell(self._status(row), tooltip=tooltip), self._cell(row.get("reason"), tooltip=tooltip),
            ])
        self.risk_model.set_rows(rows)
        if not group:
            text = self.ui.statusLabel.property("emptyText")
        elif not isinstance(group.get("joint_risk"), dict):
            text = self.ui.statusLabel.property("missingReportText")
        elif not rows:
            text = self.report.get("reason") or (self._status(self.report) if self.report.get("status") in {
                "computation_limited", "unavailable", "no_data", "fit_not_converged"} else self.ui.statusLabel.property("noGroupsText"))
        else:
            text = self.ui.statusLabel.property("summaryFormat").format(count=len(rows), available=sum(self._available(row) for row in self._rows))
        if self.report.get("omitted_count"):
            text += "\n" + self.ui.statusLabel.property("omittedFormat").format(count=self.report["omitted_count"])
        self.ui.statusLabel.setText(text)
        self.ui.statusLabel.setToolTip("\n\n".join(str(item) for item in self.report.get("notes", []) if item))
        table.resizeColumnsToContents()
        for column in (0, 1, 2, 3, 8, 9):
            table.setColumnWidth(column, min(int(table.property("textColumnMaximumWidth")),
                max(int(table.property("textColumnMinimumWidth")), table.columnWidth(column))))
        if rows:
            table.setCurrentIndex(self.proxy_model.index(0, 0))
        else:
            self.ui.detailsTextEdit.setPlainText("\n\n".join(str(item) for item in self.report.get("notes", []) if item))

    def _show_detail(self, *_):
        index = self.proxy_model.mapToSource(self.ui.risksTableView.currentIndex())
        self.ui.detailsTextEdit.setPlainText(self._details(self._rows[index.row()])
            if index.isValid() and index.row() < len(self._rows) else "")
