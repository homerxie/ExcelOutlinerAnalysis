"""Metadata-driven risk presentation; translated wording belongs to Qt forms."""
from __future__ import annotations

import math


def valid_probability(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and 0 <= value <= 1


def percentage(value, precision=4):
    if not valid_probability(value):
        return "—"
    scaled = 100 * value
    return f"{scaled:.3g}%" if 0 < scaled < .5 * 10 ** -precision else f"{scaled:.{precision}f}%"


def is_boundary_low(row):
    return row.get("estimate_kind") == "boundary_low" or (
        row.get("estimate_kind") is None and row.get("status") == "boundary_low")


def risk_available(row):
    return row.get("status") != "no_data" and row.get("identifiable") is not False and valid_probability(row.get("probability"))


def boundary_note(widget, row):
    return str(widget.property("boundaryHintText") or "") if risk_available(row) and is_boundary_low(row) else ""


def risk_probability_text(widget, row, precision=4):
    if not risk_available(row):
        return "—"
    if is_boundary_low(row):
        return str(widget.property("boundaryLowText") or "")
    return percentage(row["probability"], precision)


def _confidence(widget, row, confidence):
    value = row.get("confidence_level")
    if value is None:
        value = confidence if confidence is not None else widget.property("confidenceLevel") or .95
    return f"{float(value):.0%}"


def risk_interval_kind(widget, row, confidence=None):
    if not risk_available(row):
        return "—"
    if row.get("interval_sidedness") == "upper":
        if not valid_probability(row.get("ci_upper")):
            return str(widget.property("intervalUnavailableText") or "—")
        key = "upperApproxIntervalKindFormat" if "approximate" in str(row.get("interval_method", "")) else "upperIntervalKindFormat"
    else:
        if not valid_probability(row.get("ci_lower")) or not valid_probability(row.get("ci_upper")):
            return str(widget.property("intervalUnavailableText") or "—")
        key = "twoSidedIntervalKindFormat"
    return str(widget.property(key) or "").format(confidence=_confidence(widget, row, confidence))


def risk_interval_text(widget, row, confidence=None):
    if not risk_available(row):
        return "—"
    if row.get("interval_sidedness") == "upper":
        if not valid_probability(row.get("ci_upper")):
            return str(widget.property("intervalUnavailableText") or "—")
        key = "upperApproxIntervalFormat" if "approximate" in str(row.get("interval_method", "")) else "upperIntervalFormat"
    else:
        if not valid_probability(row.get("ci_lower")) and not valid_probability(row.get("ci_upper")):
            return str(widget.property("intervalUnavailableText") or "—")
        key = "twoSidedIntervalFormat"
    return str(widget.property(key) or "").format(confidence=_confidence(widget, row, confidence),
                                                 lower=percentage(row.get("ci_lower")), upper=percentage(row.get("ci_upper")))
