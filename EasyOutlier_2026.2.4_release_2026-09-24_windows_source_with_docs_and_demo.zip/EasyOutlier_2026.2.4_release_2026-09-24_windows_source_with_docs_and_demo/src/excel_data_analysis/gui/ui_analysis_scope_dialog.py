# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'analysis_scope_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
    QPlainTextEdit, QPushButton, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)

class Ui_AnalysisScopeDialog(object):
    def setupUi(self, AnalysisScopeDialog):
        if not AnalysisScopeDialog.objectName():
            AnalysisScopeDialog.setObjectName(u"AnalysisScopeDialog")
        AnalysisScopeDialog.resize(760, 420)
        AnalysisScopeDialog.setMinimumSize(QSize(560, 360))
        self.verticalLayout = QVBoxLayout(AnalysisScopeDialog)
        self.verticalLayout.setSpacing(12)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.messageLabel = QLabel(AnalysisScopeDialog)
        self.messageLabel.setObjectName(u"messageLabel")
        self.messageLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.messageLabel)

        self.selectedImportsEdit = QPlainTextEdit(AnalysisScopeDialog)
        self.selectedImportsEdit.setObjectName(u"selectedImportsEdit")
        self.selectedImportsEdit.setReadOnly(True)

        self.verticalLayout.addWidget(self.selectedImportsEdit)

        self.warningLabel = QLabel(AnalysisScopeDialog)
        self.warningLabel.setObjectName(u"warningLabel")
        self.warningLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.warningLabel)

        self.buttonLayout = QHBoxLayout()
        self.buttonLayout.setObjectName(u"buttonLayout")
        self.buttonSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.buttonLayout.addItem(self.buttonSpacer)

        self.cancelButton = QPushButton(AnalysisScopeDialog)
        self.cancelButton.setObjectName(u"cancelButton")

        self.buttonLayout.addWidget(self.cancelButton)

        self.confirmButton = QPushButton(AnalysisScopeDialog)
        self.confirmButton.setObjectName(u"confirmButton")
        self.confirmButton.setAutoDefault(False)

        self.buttonLayout.addWidget(self.confirmButton)


        self.verticalLayout.addLayout(self.buttonLayout)


        self.retranslateUi(AnalysisScopeDialog)

        self.cancelButton.setDefault(True)


        QMetaObject.connectSlotsByName(AnalysisScopeDialog)
    # setupUi

    def retranslateUi(self, AnalysisScopeDialog):
        AnalysisScopeDialog.setWindowTitle(QCoreApplication.translate("AnalysisScopeDialog", u"\u786e\u8ba4\u5206\u6790\u6240\u9009\u6570\u636e", None))
        self.messageLabel.setText(QCoreApplication.translate("AnalysisScopeDialog", u"\u672c\u6b21 Analyze \u4ec5\u4f7f\u7528\u4ee5\u4e0b\u52fe\u9009\u7684\u5bfc\u5165\u8bb0\u5f55\uff0c\u5e76\u5e94\u7528\u5f53\u524d\u7b5b\u9009\u6761\u4ef6\u3002\u8bf7\u786e\u8ba4\u5206\u6790\u8303\u56f4\u3002", None))
#if QT_CONFIG(accessibility)
        self.selectedImportsEdit.setAccessibleName(QCoreApplication.translate("AnalysisScopeDialog", u"\u672c\u6b21\u9009\u62e9\u7684\u5bfc\u5165\u8bb0\u5f55", None))
#endif // QT_CONFIG(accessibility)
        self.warningLabel.setText(QCoreApplication.translate("AnalysisScopeDialog", u"\u9009\u62e9\u7684\u6570\u636e\u8303\u56f4\u4f1a\u5f71\u54cd New\uff08\u65b0\u589e\u5f02\u5e38\uff09\u548c Recovered\uff08\u6062\u590d\uff09\u7684\u5224\u65ad\u3002\n"
"\n"
"\u8fd9\u4e9b\u7ed3\u679c\u4f9d\u636e\u53c2\u4e0e\u5206\u6790\u7684\u8282\u70b9\u53ca\u5176\u5148\u540e\u5173\u7cfb\u8ba1\u7b97\u3002\u672a\u9009\u4e2d\u7684\u5386\u53f2\u6570\u636e\u6216\u88ab\u7b5b\u9009\u6389\u7684\u8282\u70b9\u4e0d\u4f1a\u53c2\u4e0e\u6bd4\u8f83\uff0c\u56e0\u6b64\u7ed3\u679c\u53ef\u80fd\u4e0e Entire Database \u4e0d\u540c\u3002\n"
"\n"
"\u5982\u9700\u57fa\u4e8e\u5b8c\u6574\u6570\u636e\u5e93\u5206\u6790\uff0c\u8bf7\u53d6\u6d88\u5e76\u9009\u62e9 Entire Database\uff0c\u540c\u65f6\u68c0\u67e5\u5f53\u524d\u7b5b\u9009\u6761\u4ef6\u3002", None))
        self.cancelButton.setText(QCoreApplication.translate("AnalysisScopeDialog", u"\u53d6\u6d88", None))
        self.confirmButton.setText(QCoreApplication.translate("AnalysisScopeDialog", u"\u786e\u8ba4\u5206\u6790\u6240\u9009\u6570\u636e", None))
    # retranslateUi

