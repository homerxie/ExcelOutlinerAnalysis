# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_joint_risk_panel.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QHeaderView, QLabel,
    QPlainTextEdit, QSizePolicy, QTableView, QVBoxLayout,
    QWidget)

class Ui_TskJointRiskPanelForm(object):
    def setupUi(self, TskJointRiskPanelForm):
        if not TskJointRiskPanelForm.objectName():
            TskJointRiskPanelForm.setObjectName(u"TskJointRiskPanelForm")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(TskJointRiskPanelForm.sizePolicy().hasHeightForWidth())
        TskJointRiskPanelForm.setSizePolicy(sizePolicy)
        self.panelLayout = QVBoxLayout(TskJointRiskPanelForm)
        self.panelLayout.setObjectName(u"panelLayout")
        self.panelLayout.setContentsMargins(0, 0, 0, 0)
        self.explanationLabel = QLabel(TskJointRiskPanelForm)
        self.explanationLabel.setObjectName(u"explanationLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.explanationLabel.sizePolicy().hasHeightForWidth())
        self.explanationLabel.setSizePolicy(sizePolicy1)
        self.explanationLabel.setWordWrap(True)
        self.explanationLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.panelLayout.addWidget(self.explanationLabel)

        self.statusLabel = QLabel(TskJointRiskPanelForm)
        self.statusLabel.setObjectName(u"statusLabel")
        self.statusLabel.setWordWrap(True)
        self.statusLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.panelLayout.addWidget(self.statusLabel)

        self.risksTableView = QTableView(TskJointRiskPanelForm)
        self.risksTableView.setObjectName(u"risksTableView")
        self.risksTableView.setMinimumSize(QSize(0, 160))
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(1)
        sizePolicy2.setHeightForWidth(self.risksTableView.sizePolicy().hasHeightForWidth())
        self.risksTableView.setSizePolicy(sizePolicy2)
        self.risksTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.risksTableView.setAlternatingRowColors(True)
        self.risksTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.risksTableView.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.risksTableView.setSortingEnabled(True)
        self.risksTableView.setWordWrap(False)
        self.risksTableView.setProperty(u"textColumnMaximumWidth", 300)
        self.risksTableView.setProperty(u"textColumnMinimumWidth", 90)
        self.risksTableView.setProperty(u"confidenceLevel", 0.950000000000000)

        self.panelLayout.addWidget(self.risksTableView)

        self.detailsTextEdit = QPlainTextEdit(TskJointRiskPanelForm)
        self.detailsTextEdit.setObjectName(u"detailsTextEdit")
        self.detailsTextEdit.setMinimumSize(QSize(0, 90))
        self.detailsTextEdit.setReadOnly(True)

        self.panelLayout.addWidget(self.detailsTextEdit)

        self.panelLayout.setStretch(2, 3)
        self.panelLayout.setStretch(3, 1)

        self.retranslateUi(TskJointRiskPanelForm)

        QMetaObject.connectSlotsByName(TskJointRiskPanelForm)
    # setupUi

    def retranslateUi(self, TskJointRiskPanelForm):
        self.explanationLabel.setText(QCoreApplication.translate("TskJointRiskPanelForm", u"\u591a\u4e2a\u5b9e\u4f8b\u7ed1\u5b9a\uff1a\u6574\u4f53\u5931\u6548\u6307\u5176\u4e2d\u81f3\u5c11\u4e00\u4e2a\u5931\u6548\uff0c\u6309\u6a21\u578b\u8ba1\u7b97 1\u2212\u220f(1\u2212p\u1d62)\u1d50\u2071\uff1b\u914d\u6bd4 m\u1d62 \u4e0d\u80fd\u7701\u7565\u3002\n"
"\u540c\u5b9e\u4f8b\u8054\u5408\u6761\u4ef6\uff1aTSK\u3001bump\u3001stack \u7b49\u5171\u540c\u786e\u5b9a\u4e00\u4e2a\u5b9e\u4f8b\u7684\u6982\u7387\uff0c\u4e0d\u80fd\u628a\u7c7b\u522b\u7cfb\u6570\u5f53\u6210\u53e6\u4e00\u4ef6\u5143\u4ef6\uff1b\u4e0d\u628a\u6574\u4f53\u98ce\u9669\u5f3a\u884c\u5747\u5206\u7ed9\u6210\u5458\u3002\n"
"\u4ec5\u4f7f\u7528\u539f\u6570\u636e\u5b9e\u9645\u89c2\u6d4b\u7684\u5b8c\u6574\u6761\u4ef6\u3002\u65e0\u6709\u6548\u6570\u636e\u7684\u7ed3\u679c\u7559\u7a7a\uff0c\u4e0d\u5916\u63a8\uff1b\u6570\u503c\u4e0d\u654f\u611f\u4e0d\u4ee3\u8868\u6574\u4f53\u6982\u7387\u53ef\u8bc6\u522b\u3002", None))
        self.statusLabel.setText(QCoreApplication.translate("TskJointRiskPanelForm", u"\u8fd0\u884c TSK \u98ce\u9669\u5206\u6790\u540e\u663e\u793a\u53ef\u68c0\u67e5\u7684\u7ed1\u5b9a\u7ec4\u3002", None))
        self.statusLabel.setProperty(u"emptyText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u8fd0\u884c TSK \u98ce\u9669\u5206\u6790\u540e\u663e\u793a\u53ef\u68c0\u67e5\u7684\u7ed1\u5b9a\u7ec4\u3002", None))
        self.statusLabel.setProperty(u"missingReportText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u8bf7\u91cd\u65b0\u8fd0\u884c\u5206\u6790\u4ee5\u751f\u6210\u8054\u5408\u98ce\u9669\u7ed3\u679c\u3002", None))
        self.statusLabel.setProperty(u"noGroupsText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u672c\u7ec4\u672a\u53d1\u73b0\u9700\u8981\u5408\u5e76\u5c55\u793a\u7684\u7ed1\u5b9a\u5173\u7cfb\uff0c\u6216\u6ca1\u6709\u53ef\u53d1\u5e03\u7684\u7ed1\u5b9a\u7ed3\u679c\u3002", None))
        self.statusLabel.setProperty(u"summaryFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"{count} \u4e2a\u7ed1\u5b9a\u7ed3\u679c \u00b7 {available} \u4e2a\u53ef\u663e\u793a\u6574\u4f53\u6982\u7387\u3002\u9009\u4e2d\u4e00\u884c\u67e5\u770b\u6761\u4ef6\u3001\u4f9d\u636e\u4e0e\u9650\u5236\u3002", None))
        self.statusLabel.setProperty(u"omittedFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"\u53e6\u6709 {count} \u4e2a\u5019\u9009\u7ed3\u679c\u672a\u5c55\u5f00\uff1b\u539f\u56e0\u89c1\u5206\u6790\u63d0\u793a\u3002", None))
        self.risksTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskJointRiskPanelForm", u"\u7ed1\u5b9a\u7ec4", None),
            QCoreApplication.translate("TskJointRiskPanelForm", u"\u6982\u7387\u542b\u4e49", None),
            QCoreApplication.translate("TskJointRiskPanelForm", u"\u6210\u5458 / \u914d\u6bd4", None),
            QCoreApplication.translate("TskJointRiskPanelForm", u"\u6761\u4ef6", None),
            QCoreApplication.translate("TskJointRiskPanelForm", u"\u6574\u4f53\u5931\u6548\u6982\u7387", None),
            QCoreApplication.translate("TskJointRiskPanelForm", u"\u533a\u95f4\u4e0b\u754c", None),
            QCoreApplication.translate("TskJointRiskPanelForm", u"\u533a\u95f4\u4e0a\u754c / \u5355\u4fa7\u4e0a\u9650", None),
            QCoreApplication.translate("TskJointRiskPanelForm", u"\u533a\u95f4\u5f62\u5f0f", None),
            QCoreApplication.translate("TskJointRiskPanelForm", u"\u72b6\u6001", None),
            QCoreApplication.translate("TskJointRiskPanelForm", u"\u539f\u56e0", None)])
        self.risksTableView.setProperty(u"okText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u6574\u4f53\u53ef\u4f30\u8ba1", None))
        self.risksTableView.setProperty(u"noDataText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u65e0\u6709\u6548\u6570\u636e\uff08\u4e0d\u5916\u63a8\uff09", None))
        self.risksTableView.setProperty(u"notIdentifiableText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u6574\u4f53\u4ecd\u4e0d\u53ef\u8bc6\u522b", None))
        self.risksTableView.setProperty(u"fitNotConvergedText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u62df\u5408\u672a\u7a33\u5b9a\u6536\u655b", None))
        self.risksTableView.setProperty(u"intervalUnavailableText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528", None))
        self.risksTableView.setProperty(u"unavailableText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u8054\u5408\u98ce\u9669\u6682\u4e0d\u53ef\u7528", None))
        self.risksTableView.setProperty(u"computationLimitedText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u6570\u636e\u89c4\u6a21\u8d85\u8fc7\u8054\u5408\u98ce\u9669\u8ba1\u7b97\u9650\u5236", None))
        self.risksTableView.setProperty(u"modelIntervalMismatchText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u6a21\u578b\u4f30\u8ba1\u4e0e Chain \u8bc1\u636e\u533a\u95f4\u4e0d\u4e00\u81f4", None))
        self.risksTableView.setProperty(u"multipleInstancesText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u591a\u4e2a\u5b9e\u4f8b\u81f3\u5c11\u4e00\u4e2a\u5931\u6548", None))
        self.risksTableView.setProperty(u"jointConditionsText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u540c\u5b9e\u4f8b\u8054\u5408\u6761\u4ef6", None))
        self.risksTableView.setProperty(u"memberFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"{tsk_id} \u00d7 {count}{conditions}", None))
        self.risksTableView.setProperty(u"memberConditionFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"\uff08{conditions}\uff09", None))
        self.risksTableView.setProperty(u"conservativeIntervalKindFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"{confidence} \u4fdd\u5b88\u533a\u95f4", None))
        self.risksTableView.setProperty(u"conservativeIntervalFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"{confidence} \u4fdd\u5b88\u533a\u95f4\uff1a{lower} \u2013 {upper}", None))
        self.risksTableView.setProperty(u"boundaryLowText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u96f6\u8fb9\u754c\u4f30\u8ba1", None))
        self.risksTableView.setProperty(u"boundaryHintText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u96f6\u8fb9\u754c\u662f\u6a21\u578b\u8fb9\u754c\u5904\u7684\u4f30\u8ba1\uff0c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\uff1b\u98ce\u9669\u4ecd\u53ef\u80fd\u9ad8\u4e8e 0\u3002", None))
        self.risksTableView.setProperty(u"upperIntervalFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"\u4e0a\u9650\uff08\u5355\u4fa7 {confidence}\uff09\uff1a{upper}", None))
        self.risksTableView.setProperty(u"upperApproxIntervalFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09\uff1a{upper}", None))
        self.risksTableView.setProperty(u"twoSidedIntervalFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4\uff1a{lower} \u2013 {upper}", None))
        self.risksTableView.setProperty(u"upperIntervalKindFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"\u5355\u4fa7 {confidence} \u4e0a\u9650", None))
        self.risksTableView.setProperty(u"upperApproxIntervalKindFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09", None))
        self.risksTableView.setProperty(u"twoSidedIntervalKindFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4", None))
        self.detailsTextEdit.setPlaceholderText(QCoreApplication.translate("TskJointRiskPanelForm", u"\u9009\u4e2d\u7ed1\u5b9a\u7ec4\u540e\uff0c\u663e\u793a\u6574\u4f53\u6982\u7387\u7684\u5b9a\u4e49\u3001\u6570\u636e\u652f\u6301\u3001\u8bc6\u522b\u4f9d\u636e\u548c\u4e0d\u80fd\u5355\u72ec\u62c6\u5206\u7684\u539f\u56e0\u3002", None))
        self.detailsTextEdit.setProperty(u"detailFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"\u7ed1\u5b9a\u7ec4\uff1a{group}\n"
"\u542b\u4e49\uff1a{kind}\n"
"\u6210\u5458 / \u914d\u6bd4\uff1a{members}\n"
"\u6761\u4ef6\uff1a{conditions}\n"
"\u6574\u4f53\u6982\u7387\uff1a{probability}\n"
"\u533a\u95f4\uff1a{interval}\n"
"\u72b6\u6001\uff1a{status}\n"
"\u539f\u56e0\uff1a{reason}", None))
        self.detailsTextEdit.setProperty(u"formulaFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"\u516c\u5f0f\uff1a{formula}", None))
        self.detailsTextEdit.setProperty(u"parametersFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"\u6d89\u53ca\u53c2\u6570\uff1a{parameters}", None))
        self.detailsTextEdit.setProperty(u"supportFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"\u8bc1\u636e Chain \u6570\uff1a{chains} \u00b7 \u5b8c\u6574\u5305\u6d4b\u8bd5\u66b4\u9732\uff1a{exposure}", None))
        self.detailsTextEdit.setProperty(u"certificateFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"\u6574\u4f53\u8bc6\u522b\u4f9d\u636e\uff1a{certificate}", None))
        self.detailsTextEdit.setProperty(u"methodFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"\u533a\u95f4\u65b9\u6cd5\uff1a{method}", None))
        self.detailsTextEdit.setProperty(u"conservativeBinomialMethodText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u7531 Chain \u4e8c\u9879\u5206\u5e03\u7cbe\u786e\u533a\u95f4\u5408\u6210\u7684\u4fdd\u5b88\u754c", None))
        self.detailsTextEdit.setProperty(u"intervalErrorFormat", QCoreApplication.translate("TskJointRiskPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0\uff1a{error}", None))
        self.detailsTextEdit.setProperty(u"noneText", QCoreApplication.translate("TskJointRiskPanelForm", u"\u65e0", None))
        pass
    # retranslateUi

