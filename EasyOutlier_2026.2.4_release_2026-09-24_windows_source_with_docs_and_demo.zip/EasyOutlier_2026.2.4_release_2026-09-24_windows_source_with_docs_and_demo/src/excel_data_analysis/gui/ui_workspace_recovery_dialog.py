# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'workspace_recovery_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
    QPushButton, QSizePolicy, QVBoxLayout, QWidget)

class Ui_WorkspaceRecoveryDialog(object):
    def setupUi(self, WorkspaceRecoveryDialog):
        if not WorkspaceRecoveryDialog.objectName():
            WorkspaceRecoveryDialog.setObjectName(u"WorkspaceRecoveryDialog")
        WorkspaceRecoveryDialog.setMinimumSize(QSize(620, 0))
        self.verticalLayout = QVBoxLayout(WorkspaceRecoveryDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.messageLabel = QLabel(WorkspaceRecoveryDialog)
        self.messageLabel.setObjectName(u"messageLabel")
        self.messageLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.messageLabel)

        self.pathsLabel = QLabel(WorkspaceRecoveryDialog)
        self.pathsLabel.setObjectName(u"pathsLabel")
        self.pathsLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.pathsLabel)

        self.buttonLayout = QHBoxLayout()
        self.buttonLayout.setObjectName(u"buttonLayout")
        self.continueButton = QPushButton(WorkspaceRecoveryDialog)
        self.continueButton.setObjectName(u"continueButton")

        self.buttonLayout.addWidget(self.continueButton)

        self.discardButton = QPushButton(WorkspaceRecoveryDialog)
        self.discardButton.setObjectName(u"discardButton")

        self.buttonLayout.addWidget(self.discardButton)

        self.cancelButton = QPushButton(WorkspaceRecoveryDialog)
        self.cancelButton.setObjectName(u"cancelButton")

        self.buttonLayout.addWidget(self.cancelButton)


        self.verticalLayout.addLayout(self.buttonLayout)


        self.retranslateUi(WorkspaceRecoveryDialog)

        self.continueButton.setDefault(True)


        QMetaObject.connectSlotsByName(WorkspaceRecoveryDialog)
    # setupUi

    def retranslateUi(self, WorkspaceRecoveryDialog):
        WorkspaceRecoveryDialog.setWindowTitle(QCoreApplication.translate("WorkspaceRecoveryDialog", u"\u53d1\u73b0\u672a\u4fdd\u5b58\u7684\u6570\u636e\u5e93\u5de5\u4f5c\u533a", None))
        self.messageLabel.setText(QCoreApplication.translate("WorkspaceRecoveryDialog", u"temp \u5de5\u4f5c\u533a\u4e0e\u5df2\u4fdd\u5b58\u6570\u636e\u5e93\u4e0d\u540c\u3002\u53ef\u4ee5\u7ee7\u7eed\u4f7f\u7528\u672a\u4fdd\u5b58\u7684\u6570\u636e\uff0c\u6216\u4e22\u5f03 temp \u6539\u52a8\u5e76\u91cd\u65b0\u8f7d\u5165\u5df2\u4fdd\u5b58\u6570\u636e\u5e93\u3002", None))
        self.continueButton.setText(QCoreApplication.translate("WorkspaceRecoveryDialog", u"\u7ee7\u7eed\u4f7f\u7528 temp \u5de5\u4f5c\u533a", None))
        self.discardButton.setText(QCoreApplication.translate("WorkspaceRecoveryDialog", u"\u4e22\u5f03 temp \u5e76\u8f7d\u5165\u5df2\u4fdd\u5b58\u6570\u636e\u5e93", None))
        self.cancelButton.setText(QCoreApplication.translate("WorkspaceRecoveryDialog", u"\u53d6\u6d88\u6253\u5f00", None))
    # retranslateUi

