from __future__ import annotations

from copy import deepcopy

from PySide6.QtCore import QObject

from ..models import TemplateConfig
from ..template import validate_report_identity
from ..merge_config import chain_level, column_levels


class ReportIdentityControls(QObject):
    """Edit explicit report identity without guessing or changing row dimensions."""

    def __init__(self, parent=None, *, fields) -> None:
        super().__init__(parent)
        self.template: TemplateConfig | None = None
        self.template_path = ""
        self.sample_edit, self.node_combo, self.chain_combo = fields

    def set_template(self, template: TemplateConfig, path: str) -> None:
        self.template = deepcopy(template)
        self.template_path = path
        self.node_combo.blockSignals(True)
        self.chain_combo.blockSignals(True)
        self.sample_edit.blockSignals(True)
        self.node_combo.clear()
        for dimension in sorted(template.row_dimensions, key=lambda item: item.priority):
            label = dimension.display_name or dimension.name
            text = f"{label} ({dimension.name})" if label != dimension.name else dimension.name
            self.node_combo.addItem(text, dimension.name)
        node = template.report.reliability_node_dimension
        index = self.node_combo.findData(node)
        if index < 0:
            self.node_combo.addItem(f"未找到维度: {node}", node)
            index = self.node_combo.count() - 1
        self.node_combo.setCurrentIndex(index)
        self.chain_combo.clear()
        for name in column_levels(template):
            self.chain_combo.addItem(name, name)
        chain = chain_level(template)
        chain_index = self.chain_combo.findData(chain)
        if chain_index < 0:
            self.chain_combo.addItem(f"未找到层级: {chain}", chain)
            chain_index = self.chain_combo.count() - 1
        self.chain_combo.setCurrentIndex(chain_index)
        self.sample_edit.setText(";".join(template.report.sample_dimension_names))
        self.node_combo.blockSignals(False)
        self.chain_combo.blockSignals(False)
        self.sample_edit.blockSignals(False)

    def updated_template(self, template: TemplateConfig | None = None, *, validate=True) -> TemplateConfig:
        if template is None and self.template is None:
            raise ValueError("Load a template before configuring sample identity.")
        template = deepcopy(template if template is not None else self.template)
        template.report.reliability_node_dimension = str(self.node_combo.currentData() or "")
        template.report.chain_column_level = str(self.chain_combo.currentData() or "")
        template.report.sample_dimension_names = [
            item.strip() for item in self.sample_edit.text().split(";") if item.strip()
        ]
        if validate:
            validate_report_identity(template, validate_merge=False)
        return template
