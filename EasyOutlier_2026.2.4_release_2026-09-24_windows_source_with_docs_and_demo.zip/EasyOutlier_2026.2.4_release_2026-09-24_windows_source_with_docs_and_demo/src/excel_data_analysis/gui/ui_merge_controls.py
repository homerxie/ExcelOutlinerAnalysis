# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'merge_controls.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QGridLayout, QLabel,
    QSizePolicy, QWidget)

class Ui_MergeControlsForm(object):
    def setupUi(self, MergeControlsForm):
        if not MergeControlsForm.objectName():
            MergeControlsForm.setObjectName(u"MergeControlsForm")
        self.gridLayout = QGridLayout(MergeControlsForm)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.cornerLabel = QLabel(MergeControlsForm)
        self.cornerLabel.setObjectName(u"cornerLabel")

        self.gridLayout.addWidget(self.cornerLabel, 0, 0, 1, 1)

        self.levelLabel = QLabel(MergeControlsForm)
        self.levelLabel.setObjectName(u"levelLabel")

        self.gridLayout.addWidget(self.levelLabel, 1, 0, 1, 1)

        self.ruleLabel = QLabel(MergeControlsForm)
        self.ruleLabel.setObjectName(u"ruleLabel")

        self.gridLayout.addWidget(self.ruleLabel, 2, 0, 1, 1)

        self.initial_column_mergeLabel = QLabel(MergeControlsForm)
        self.initial_column_mergeLabel.setObjectName(u"initial_column_mergeLabel")
        self.initial_column_mergeLabel.setWordWrap(True)

        self.gridLayout.addWidget(self.initial_column_mergeLabel, 0, 1, 1, 1)

        self.initial_column_mergeLevelComboBox = QComboBox(MergeControlsForm)
        self.initial_column_mergeLevelComboBox.setObjectName(u"initial_column_mergeLevelComboBox")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.initial_column_mergeLevelComboBox.sizePolicy().hasHeightForWidth())
        self.initial_column_mergeLevelComboBox.setSizePolicy(sizePolicy)

        self.gridLayout.addWidget(self.initial_column_mergeLevelComboBox, 1, 1, 1, 1)

        self.initial_column_mergeFailRuleComboBox = QComboBox(MergeControlsForm)
        self.initial_column_mergeFailRuleComboBox.addItem("")
        self.initial_column_mergeFailRuleComboBox.addItem("")
        self.initial_column_mergeFailRuleComboBox.setObjectName(u"initial_column_mergeFailRuleComboBox")
        sizePolicy.setHeightForWidth(self.initial_column_mergeFailRuleComboBox.sizePolicy().hasHeightForWidth())
        self.initial_column_mergeFailRuleComboBox.setSizePolicy(sizePolicy)

        self.gridLayout.addWidget(self.initial_column_mergeFailRuleComboBox, 2, 1, 1, 1)

        self.final_column_mergeLabel = QLabel(MergeControlsForm)
        self.final_column_mergeLabel.setObjectName(u"final_column_mergeLabel")
        self.final_column_mergeLabel.setWordWrap(True)

        self.gridLayout.addWidget(self.final_column_mergeLabel, 0, 2, 1, 1)

        self.final_column_mergeLevelComboBox = QComboBox(MergeControlsForm)
        self.final_column_mergeLevelComboBox.setObjectName(u"final_column_mergeLevelComboBox")
        sizePolicy.setHeightForWidth(self.final_column_mergeLevelComboBox.sizePolicy().hasHeightForWidth())
        self.final_column_mergeLevelComboBox.setSizePolicy(sizePolicy)
        self.final_column_mergeLevelComboBox.setEnabled(False)

        self.gridLayout.addWidget(self.final_column_mergeLevelComboBox, 1, 2, 1, 1)

        self.final_column_mergeFailRuleComboBox = QComboBox(MergeControlsForm)
        self.final_column_mergeFailRuleComboBox.addItem("")
        self.final_column_mergeFailRuleComboBox.addItem("")
        self.final_column_mergeFailRuleComboBox.setObjectName(u"final_column_mergeFailRuleComboBox")
        sizePolicy.setHeightForWidth(self.final_column_mergeFailRuleComboBox.sizePolicy().hasHeightForWidth())
        self.final_column_mergeFailRuleComboBox.setSizePolicy(sizePolicy)

        self.gridLayout.addWidget(self.final_column_mergeFailRuleComboBox, 2, 2, 1, 1)

        self.initial_row_mergeLabel = QLabel(MergeControlsForm)
        self.initial_row_mergeLabel.setObjectName(u"initial_row_mergeLabel")
        self.initial_row_mergeLabel.setWordWrap(True)

        self.gridLayout.addWidget(self.initial_row_mergeLabel, 0, 3, 1, 1)

        self.initial_row_mergeLevelComboBox = QComboBox(MergeControlsForm)
        self.initial_row_mergeLevelComboBox.setObjectName(u"initial_row_mergeLevelComboBox")
        sizePolicy.setHeightForWidth(self.initial_row_mergeLevelComboBox.sizePolicy().hasHeightForWidth())
        self.initial_row_mergeLevelComboBox.setSizePolicy(sizePolicy)

        self.gridLayout.addWidget(self.initial_row_mergeLevelComboBox, 1, 3, 1, 1)

        self.initial_row_mergeFailRuleComboBox = QComboBox(MergeControlsForm)
        self.initial_row_mergeFailRuleComboBox.addItem("")
        self.initial_row_mergeFailRuleComboBox.addItem("")
        self.initial_row_mergeFailRuleComboBox.setObjectName(u"initial_row_mergeFailRuleComboBox")
        sizePolicy.setHeightForWidth(self.initial_row_mergeFailRuleComboBox.sizePolicy().hasHeightForWidth())
        self.initial_row_mergeFailRuleComboBox.setSizePolicy(sizePolicy)

        self.gridLayout.addWidget(self.initial_row_mergeFailRuleComboBox, 2, 3, 1, 1)

        self.final_row_mergeLabel = QLabel(MergeControlsForm)
        self.final_row_mergeLabel.setObjectName(u"final_row_mergeLabel")
        self.final_row_mergeLabel.setWordWrap(True)

        self.gridLayout.addWidget(self.final_row_mergeLabel, 0, 4, 1, 1)

        self.final_row_mergeLevelComboBox = QComboBox(MergeControlsForm)
        self.final_row_mergeLevelComboBox.setObjectName(u"final_row_mergeLevelComboBox")
        sizePolicy.setHeightForWidth(self.final_row_mergeLevelComboBox.sizePolicy().hasHeightForWidth())
        self.final_row_mergeLevelComboBox.setSizePolicy(sizePolicy)
        self.final_row_mergeLevelComboBox.setEnabled(False)

        self.gridLayout.addWidget(self.final_row_mergeLevelComboBox, 1, 4, 1, 1)

        self.final_row_mergeFailRuleComboBox = QComboBox(MergeControlsForm)
        self.final_row_mergeFailRuleComboBox.addItem("")
        self.final_row_mergeFailRuleComboBox.addItem("")
        self.final_row_mergeFailRuleComboBox.setObjectName(u"final_row_mergeFailRuleComboBox")
        sizePolicy.setHeightForWidth(self.final_row_mergeFailRuleComboBox.sizePolicy().hasHeightForWidth())
        self.final_row_mergeFailRuleComboBox.setSizePolicy(sizePolicy)

        self.gridLayout.addWidget(self.final_row_mergeFailRuleComboBox, 2, 4, 1, 1)

        self.gridLayout.setColumnStretch(1, 1)
        self.gridLayout.setColumnStretch(2, 1)
        self.gridLayout.setColumnStretch(3, 1)
        self.gridLayout.setColumnStretch(4, 1)

        self.retranslateUi(MergeControlsForm)

        QMetaObject.connectSlotsByName(MergeControlsForm)
    # setupUi

    def retranslateUi(self, MergeControlsForm):
        self.cornerLabel.setText(QCoreApplication.translate("MergeControlsForm", u"\u5408\u5e76\u6b65\u9aa4", None))
        self.levelLabel.setText(QCoreApplication.translate("MergeControlsForm", u"\u4fdd\u7559\u5c42\u7ea7", None))
        self.ruleLabel.setText(QCoreApplication.translate("MergeControlsForm", u"\u5931\u8d25\u5224\u636e", None))
        self.initial_column_mergeLabel.setText(QCoreApplication.translate("MergeControlsForm", u"Initial column merge", None))
#if QT_CONFIG(tooltip)
        self.initial_column_mergeLevelComboBox.setToolTip(QCoreApplication.translate("MergeControlsForm", u"\u5408\u5e76\u540e\u4fdd\u7559\u5230\u6b64\u5c42\uff0c\u53ea\u5408\u5e76\u4e0b\u65b9\u5c42\u7ea7\u3002Final \u76ee\u6807\u7531\u8282\u70b9\u6216 Chain \u89d2\u8272\u51b3\u5b9a\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.initial_column_mergeFailRuleComboBox.setItemText(0, QCoreApplication.translate("MergeControlsForm", u"any_fail \u00b7 \u4efb\u4e00\u5931\u8d25", None))
        self.initial_column_mergeFailRuleComboBox.setItemText(1, QCoreApplication.translate("MergeControlsForm", u"all_fail \u00b7 \u5168\u90e8\u5931\u8d25", None))

        self.final_column_mergeLabel.setText(QCoreApplication.translate("MergeControlsForm", u"Final column merge", None))
#if QT_CONFIG(tooltip)
        self.final_column_mergeLevelComboBox.setToolTip(QCoreApplication.translate("MergeControlsForm", u"\u5408\u5e76\u540e\u4fdd\u7559\u5230\u6b64\u5c42\uff0c\u53ea\u5408\u5e76\u4e0b\u65b9\u5c42\u7ea7\u3002Final \u76ee\u6807\u7531\u8282\u70b9\u6216 Chain \u89d2\u8272\u51b3\u5b9a\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.final_column_mergeFailRuleComboBox.setItemText(0, QCoreApplication.translate("MergeControlsForm", u"any_fail \u00b7 \u4efb\u4e00\u5931\u8d25", None))
        self.final_column_mergeFailRuleComboBox.setItemText(1, QCoreApplication.translate("MergeControlsForm", u"all_fail \u00b7 \u5168\u90e8\u5931\u8d25", None))

        self.initial_row_mergeLabel.setText(QCoreApplication.translate("MergeControlsForm", u"Initial row merge", None))
#if QT_CONFIG(tooltip)
        self.initial_row_mergeLevelComboBox.setToolTip(QCoreApplication.translate("MergeControlsForm", u"\u5408\u5e76\u540e\u4fdd\u7559\u5230\u6b64\u5c42\uff0c\u53ea\u5408\u5e76\u4e0b\u65b9\u5c42\u7ea7\u3002Final \u76ee\u6807\u7531\u8282\u70b9\u6216 Chain \u89d2\u8272\u51b3\u5b9a\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.initial_row_mergeFailRuleComboBox.setItemText(0, QCoreApplication.translate("MergeControlsForm", u"any_fail \u00b7 \u4efb\u4e00\u5931\u8d25", None))
        self.initial_row_mergeFailRuleComboBox.setItemText(1, QCoreApplication.translate("MergeControlsForm", u"all_fail \u00b7 \u5168\u90e8\u5931\u8d25", None))

        self.final_row_mergeLabel.setText(QCoreApplication.translate("MergeControlsForm", u"Final row merge", None))
#if QT_CONFIG(tooltip)
        self.final_row_mergeLevelComboBox.setToolTip(QCoreApplication.translate("MergeControlsForm", u"\u5408\u5e76\u540e\u4fdd\u7559\u5230\u6b64\u5c42\uff0c\u53ea\u5408\u5e76\u4e0b\u65b9\u5c42\u7ea7\u3002Final \u76ee\u6807\u7531\u8282\u70b9\u6216 Chain \u89d2\u8272\u51b3\u5b9a\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.final_row_mergeFailRuleComboBox.setItemText(0, QCoreApplication.translate("MergeControlsForm", u"any_fail \u00b7 \u4efb\u4e00\u5931\u8d25", None))
        self.final_row_mergeFailRuleComboBox.setItemText(1, QCoreApplication.translate("MergeControlsForm", u"all_fail \u00b7 \u5168\u90e8\u5931\u8d25", None))

        pass
    # retranslateUi

