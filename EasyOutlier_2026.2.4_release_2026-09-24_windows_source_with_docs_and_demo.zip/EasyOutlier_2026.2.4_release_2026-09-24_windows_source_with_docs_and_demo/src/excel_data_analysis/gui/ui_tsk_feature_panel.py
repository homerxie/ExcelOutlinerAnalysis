# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_feature_panel.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QComboBox, QFormLayout,
    QHeaderView, QLabel, QPlainTextEdit, QSizePolicy,
    QTabWidget, QTableView, QVBoxLayout, QWidget)

class Ui_TskFeaturePanelForm(object):
    def setupUi(self, TskFeaturePanelForm):
        if not TskFeaturePanelForm.objectName():
            TskFeaturePanelForm.setObjectName(u"TskFeaturePanelForm")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(TskFeaturePanelForm.sizePolicy().hasHeightForWidth())
        TskFeaturePanelForm.setSizePolicy(sizePolicy)
        self.panelLayout = QVBoxLayout(TskFeaturePanelForm)
        self.panelLayout.setObjectName(u"panelLayout")
        self.panelLayout.setContentsMargins(0, 0, 0, 0)
        self.formulaLabel = QLabel(TskFeaturePanelForm)
        self.formulaLabel.setObjectName(u"formulaLabel")
        self.formulaLabel.setWordWrap(True)
        self.formulaLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.formulaLabel.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.formulaLabel.sizePolicy().hasHeightForWidth())
        self.formulaLabel.setSizePolicy(sizePolicy1)

        self.panelLayout.addWidget(self.formulaLabel)

        self.featureViewsTabWidget = QTabWidget(TskFeaturePanelForm)
        self.featureViewsTabWidget.setObjectName(u"featureViewsTabWidget")
        self.featureRiskTab = QWidget()
        self.featureRiskTab.setObjectName(u"featureRiskTab")
        self.featureRiskLayout = QVBoxLayout(self.featureRiskTab)
        self.featureRiskLayout.setObjectName(u"featureRiskLayout")
        self.riskHintLabel = QLabel(self.featureRiskTab)
        self.riskHintLabel.setObjectName(u"riskHintLabel")
        self.riskHintLabel.setWordWrap(True)
        sizePolicy1.setHeightForWidth(self.riskHintLabel.sizePolicy().hasHeightForWidth())
        self.riskHintLabel.setSizePolicy(sizePolicy1)

        self.featureRiskLayout.addWidget(self.riskHintLabel)

        self.featureSelectorLayout = QFormLayout()
        self.featureSelectorLayout.setObjectName(u"featureSelectorLayout")
        self.featureSelectorLayout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.featureSelectorLabel = QLabel(self.featureRiskTab)
        self.featureSelectorLabel.setObjectName(u"featureSelectorLabel")

        self.featureSelectorLayout.setWidget(0, QFormLayout.ItemRole.LabelRole, self.featureSelectorLabel)

        self.featureComboBox = QComboBox(self.featureRiskTab)
        self.featureComboBox.addItem("")
        self.featureComboBox.setObjectName(u"featureComboBox")
        self.featureComboBox.setEnabled(False)
        self.featureComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.featureComboBox.setMinimumContentsLength(8)

        self.featureSelectorLayout.setWidget(0, QFormLayout.ItemRole.FieldRole, self.featureComboBox)


        self.featureRiskLayout.addLayout(self.featureSelectorLayout)

        self.riskStatusLabel = QLabel(self.featureRiskTab)
        self.riskStatusLabel.setObjectName(u"riskStatusLabel")
        self.riskStatusLabel.setWordWrap(True)
        self.riskStatusLabel.setTextFormat(Qt.TextFormat.PlainText)
        sizePolicy1.setHeightForWidth(self.riskStatusLabel.sizePolicy().hasHeightForWidth())
        self.riskStatusLabel.setSizePolicy(sizePolicy1)

        self.featureRiskLayout.addWidget(self.riskStatusLabel)

        self.risksTableView = QTableView(self.featureRiskTab)
        self.risksTableView.setObjectName(u"risksTableView")
        self.risksTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.risksTableView.setAlternatingRowColors(True)
        self.risksTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.risksTableView.setSortingEnabled(True)
        self.risksTableView.setWordWrap(False)
        self.risksTableView.horizontalHeader().setDefaultSectionSize(110)
        self.risksTableView.horizontalHeader().setStretchLastSection(True)
        self.risksTableView.verticalHeader().setVisible(False)

        self.featureRiskLayout.addWidget(self.risksTableView)

        self.featureViewsTabWidget.addTab(self.featureRiskTab, "")
        self.coefficientsTab = QWidget()
        self.coefficientsTab.setObjectName(u"coefficientsTab")
        self.coefficientsLayout = QVBoxLayout(self.coefficientsTab)
        self.coefficientsLayout.setObjectName(u"coefficientsLayout")
        self.coefficientHintLabel = QLabel(self.coefficientsTab)
        self.coefficientHintLabel.setObjectName(u"coefficientHintLabel")
        self.coefficientHintLabel.setWordWrap(True)
        sizePolicy1.setHeightForWidth(self.coefficientHintLabel.sizePolicy().hasHeightForWidth())
        self.coefficientHintLabel.setSizePolicy(sizePolicy1)

        self.coefficientsLayout.addWidget(self.coefficientHintLabel)

        self.coefficientsTableView = QTableView(self.coefficientsTab)
        self.coefficientsTableView.setObjectName(u"coefficientsTableView")
        self.coefficientsTableView.setProperty(u"termColumnMinimumWidth", 180)
        self.coefficientsTableView.setProperty(u"termColumnMaximumWidth", 280)
        self.coefficientsTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.coefficientsTableView.setAlternatingRowColors(True)
        self.coefficientsTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.coefficientsTableView.setSortingEnabled(True)
        self.coefficientsTableView.setWordWrap(False)
        self.coefficientsTableView.horizontalHeader().setDefaultSectionSize(110)
        self.coefficientsTableView.horizontalHeader().setStretchLastSection(True)
        self.coefficientsTableView.verticalHeader().setVisible(False)

        self.coefficientsLayout.addWidget(self.coefficientsTableView)

        self.featureViewsTabWidget.addTab(self.coefficientsTab, "")
        self.notesTab = QWidget()
        self.notesTab.setObjectName(u"notesTab")
        self.notesLayout = QVBoxLayout(self.notesTab)
        self.notesLayout.setObjectName(u"notesLayout")
        self.notesTextEdit = QPlainTextEdit(self.notesTab)
        self.notesTextEdit.setObjectName(u"notesTextEdit")
        self.notesTextEdit.setReadOnly(True)

        self.notesLayout.addWidget(self.notesTextEdit)

        self.featureViewsTabWidget.addTab(self.notesTab, "")

        self.panelLayout.addWidget(self.featureViewsTabWidget)

#if QT_CONFIG(shortcut)
        self.featureSelectorLabel.setBuddy(self.featureComboBox)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(TskFeaturePanelForm)

        self.featureViewsTabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(TskFeaturePanelForm)
    # setupUi

    def retranslateUi(self, TskFeaturePanelForm):
        self.formulaLabel.setText(QCoreApplication.translate("TskFeaturePanelForm", u"\u8fd0\u884c\u5206\u6790\u540e\u663e\u793a\u6a21\u578b\u516c\u5f0f\u4e0e\u7cfb\u6570\u3002", None))
        self.formulaLabel.setProperty(u"emptyText", QCoreApplication.translate("TskFeaturePanelForm", u"\u8fd0\u884c\u5206\u6790\u540e\u663e\u793a\u6a21\u578b\u516c\u5f0f\u4e0e\u7cfb\u6570\u3002", None))
        self.riskHintLabel.setText(QCoreApplication.translate("TskFeaturePanelForm", u"\u9010\u4e2a\u7c7b\u522b\u7279\u5f81\u6bd4\u8f83\u6761\u4ef6\u98ce\u9669\uff1a\u5176\u4f59\u7c7b\u522b\u56fa\u5b9a\u5728\u57fa\u51c6\uff0c\u6570\u503c\u7279\u5f81\u56fa\u5b9a\u5728\u8bad\u7ec3\u5747\u503c\u3002XY \u4e0d\u5c55\u5f00\u4e3a\u7c7b\u522b\uff1b\u65e0\u6709\u6548\u6570\u636e\u4e14\u4e0d\u5916\u63a8\u7684\u7ec4\u5408\u7559\u7a7a\u3002\u96f6\u8fb9\u754c\u4f30\u8ba1\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\uff0c\u8bf7\u540c\u65f6\u67e5\u770b\u5355\u4fa7\u4e0a\u9650\u3002", None))
        self.featureSelectorLabel.setText(QCoreApplication.translate("TskFeaturePanelForm", u"\u7c7b\u522b\u7279\u5f81", None))
        self.featureComboBox.setItemText(0, QCoreApplication.translate("TskFeaturePanelForm", u"\u5168\u90e8\u7c7b\u522b\u7279\u5f81", None))

        self.featureComboBox.setProperty(u"allFeaturesText", QCoreApplication.translate("TskFeaturePanelForm", u"\u5168\u90e8\u7c7b\u522b\u7279\u5f81", None))
        self.riskStatusLabel.setText(QCoreApplication.translate("TskFeaturePanelForm", u"\u5c1a\u65e0\u53ef\u7528\u7684\u7c7b\u522b\u98ce\u9669\u7ed3\u679c\u3002", None))
        self.riskStatusLabel.setProperty(u"emptyText", QCoreApplication.translate("TskFeaturePanelForm", u"\u5c1a\u65e0\u53ef\u7528\u7684\u7c7b\u522b\u98ce\u9669\u7ed3\u679c\u3002", None))
        self.risksTableView.setProperty(u"boundaryLowText", QCoreApplication.translate("TskFeaturePanelForm", u"\u96f6\u8fb9\u754c\u4f30\u8ba1", None))
        self.risksTableView.setProperty(u"boundaryHintText", QCoreApplication.translate("TskFeaturePanelForm", u"\u96f6\u8fb9\u754c\u662f\u6a21\u578b\u8fb9\u754c\u5904\u7684\u4f30\u8ba1\uff0c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\uff1b\u98ce\u9669\u4ecd\u53ef\u80fd\u9ad8\u4e8e 0\u3002", None))
        self.risksTableView.setProperty(u"upperIntervalFormat", QCoreApplication.translate("TskFeaturePanelForm", u"\u4e0a\u9650\uff08\u5355\u4fa7 {confidence}\uff09\uff1a{upper}", None))
        self.risksTableView.setProperty(u"upperApproxIntervalFormat", QCoreApplication.translate("TskFeaturePanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09\uff1a{upper}", None))
        self.risksTableView.setProperty(u"twoSidedIntervalFormat", QCoreApplication.translate("TskFeaturePanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4\uff1a{lower} \u2013 {upper}", None))
        self.risksTableView.setProperty(u"upperIntervalKindFormat", QCoreApplication.translate("TskFeaturePanelForm", u"\u5355\u4fa7 {confidence} \u4e0a\u9650", None))
        self.risksTableView.setProperty(u"upperApproxIntervalKindFormat", QCoreApplication.translate("TskFeaturePanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09", None))
        self.risksTableView.setProperty(u"twoSidedIntervalKindFormat", QCoreApplication.translate("TskFeaturePanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4", None))
        self.risksTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskFeaturePanelForm", u"\u7279\u5f81", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"\u7c7b\u522b", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"TSK ID", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"P_fail", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"\u533a\u95f4\u4e0b\u754c", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"\u533a\u95f4\u4e0a\u754c / \u5355\u4fa7\u4e0a\u9650", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"\u72b6\u6001", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"\u652f\u6301\u60c5\u51b5", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"\u5176\u4f59\u6761\u4ef6", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"\u533a\u95f4\u5f62\u5f0f", None)])
        self.risksTableView.setProperty(u"okText", QCoreApplication.translate("TskFeaturePanelForm", u"\u53ef\u4f30\u8ba1", None))
        self.risksTableView.setProperty(u"noDataText", QCoreApplication.translate("TskFeaturePanelForm", u"\u65e0\u6570\u636e\uff08\u7559\u7a7a\uff09", None))
        self.risksTableView.setProperty(u"notIdentifiableText", QCoreApplication.translate("TskFeaturePanelForm", u"\u4e0d\u53ef\u5355\u72ec\u8bc6\u522b", None))
        self.risksTableView.setProperty(u"fitNotConvergedText", QCoreApplication.translate("TskFeaturePanelForm", u"\u62df\u5408\u672a\u7a33\u5b9a\u6536\u655b", None))
        self.risksTableView.setProperty(u"intervalUnavailableText", QCoreApplication.translate("TskFeaturePanelForm", u"\u7f6e\u4fe1\u533a\u95f4\u4e0d\u53ef\u7528", None))
        self.risksTableView.setProperty(u"outsideDomainText", QCoreApplication.translate("TskFeaturePanelForm", u"\u8d85\u51fa\u6a21\u578b\u9002\u7528\u8303\u56f4", None))
        self.risksTableView.setProperty(u"observedText", QCoreApplication.translate("TskFeaturePanelForm", u"\u6709\u6709\u6548\u6570\u636e", None))
        self.risksTableView.setProperty(u"noActiveSupportText", QCoreApplication.translate("TskFeaturePanelForm", u"\u65e0\u6709\u6548\u6d4b\u8bd5\u6570\u636e", None))
        self.risksTableView.setProperty(u"extrapolatedText", QCoreApplication.translate("TskFeaturePanelForm", u"\u6a21\u578b\u5916\u63a8", None))
        self.risksTableView.setProperty(u"noneText", QCoreApplication.translate("TskFeaturePanelForm", u"\u65e0", None))
        self.risksTableView.setProperty(u"numericConditionText", QCoreApplication.translate("TskFeaturePanelForm", u"\u6570\u503c\u5747\u503c\uff1a{values}", None))
        self.risksTableView.setProperty(u"categoryConditionText", QCoreApplication.translate("TskFeaturePanelForm", u"\u7c7b\u522b\u57fa\u51c6\uff1a{values}", None))
        self.risksTableView.setProperty(u"intervalErrorText", QCoreApplication.translate("TskFeaturePanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0\uff1a{error}", None))
        self.featureViewsTabWidget.setTabText(self.featureViewsTabWidget.indexOf(self.featureRiskTab), QCoreApplication.translate("TskFeaturePanelForm", u"\u5404\u7279\u5f81\u98ce\u9669", None))
        self.coefficientHintLabel.setText(QCoreApplication.translate("TskFeaturePanelForm", u"\u7cfb\u6570\u5c5e\u4e8e\u516c\u5f0f\u4e2d\u7684\u7ebf\u6027\u90e8\u5206\uff0c\u4e0d\u662f\u5f02\u5e38\u6982\u7387\u3002\u7c7b\u522b\u57fa\u51c6\u7cfb\u6570\u56fa\u5b9a\u4e3a 0\uff1b\u6570\u503c\u7cfb\u6570\u5bf9\u5e94\u6807\u51c6\u5316\u53d8\u91cf z = (x \u2212 \u5747\u503c) / scale\uff1bscale \u901a\u5e38\u4e3a\u6807\u51c6\u5dee\u3002\u4e0d\u53ef\u5355\u72ec\u8bc6\u522b\u7684\u53c2\u6570\u4e0d\u663e\u793a\u4efb\u610f\u62c6\u5206\u503c\u3002\u65e0\u6709\u9650\u7cfb\u6570\u7684\u8fb9\u754c\u53c2\u6570\u7559\u7a7a\uff0c\u4f18\u5316\u4e0a\u9650\u4e0d\u662f\u53ef\u53d1\u5e03\u7684\u7cfb\u6570\u3002", None))
        self.coefficientsTableView.setProperty(u"boundaryUnboundedText", QCoreApplication.translate("TskFeaturePanelForm", u"\u65e0\u6709\u9650\u7cfb\u6570\uff08\u8fb9\u754c\uff09", None))
        self.coefficientsTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskFeaturePanelForm", u"\u53c2\u6570", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"\u7cfb\u6570", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"\u72b6\u6001", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"\u7cfb\u6570\u5c3a\u5ea6", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"\u5747\u503c", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"\u7f29\u653e\u7cfb\u6570", None),
            QCoreApplication.translate("TskFeaturePanelForm", u"\u89e3\u91ca", None)])
        self.coefficientsTableView.setProperty(u"okText", QCoreApplication.translate("TskFeaturePanelForm", u"\u53ef\u4f30\u8ba1", None))
        self.coefficientsTableView.setProperty(u"referenceCodingText", QCoreApplication.translate("TskFeaturePanelForm", u"\u57fa\u51c6\u7f16\u7801\uff08\u56fa\u5b9a 0\uff09", None))
        self.coefficientsTableView.setProperty(u"notIdentifiableText", QCoreApplication.translate("TskFeaturePanelForm", u"\u4e0d\u53ef\u5355\u72ec\u8bc6\u522b", None))
        self.coefficientsTableView.setProperty(u"fitNotConvergedText", QCoreApplication.translate("TskFeaturePanelForm", u"\u62df\u5408\u672a\u7a33\u5b9a\u6536\u655b", None))
        self.coefficientsTableView.setProperty(u"unavailableText", QCoreApplication.translate("TskFeaturePanelForm", u"\u4e0d\u53ef\u7528", None))
        self.featureViewsTabWidget.setTabText(self.featureViewsTabWidget.indexOf(self.coefficientsTab), QCoreApplication.translate("TskFeaturePanelForm", u"\u6a21\u578b\u7cfb\u6570", None))
        self.notesTextEdit.setPlaceholderText(QCoreApplication.translate("TskFeaturePanelForm", u"\u8fd0\u884c\u5206\u6790\u540e\u663e\u793a\u6a21\u578b\u89e3\u91ca\u3001\u7c7b\u522b\u57fa\u51c6\u548c\u6570\u503c\u6807\u51c6\u5316\u4fe1\u606f\u3002", None))
        self.notesTextEdit.setProperty(u"categoryReferencesText", QCoreApplication.translate("TskFeaturePanelForm", u"\u7c7b\u522b\u57fa\u51c6\uff1a{values}", None))
        self.notesTextEdit.setProperty(u"numericScalingText", QCoreApplication.translate("TskFeaturePanelForm", u"\u6570\u503c\u6807\u51c6\u5316\uff1a{feature}\uff0c\u5747\u503c = {mean}\uff0cscale = {scale}", None))
        self.featureViewsTabWidget.setTabText(self.featureViewsTabWidget.indexOf(self.notesTab), QCoreApplication.translate("TskFeaturePanelForm", u"\u89e3\u91ca\u4e0e\u57fa\u51c6", None))
        pass
    # retranslateUi

