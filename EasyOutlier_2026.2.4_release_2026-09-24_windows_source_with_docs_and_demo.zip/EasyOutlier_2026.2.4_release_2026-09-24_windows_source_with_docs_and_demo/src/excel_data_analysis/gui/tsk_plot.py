"""Qt-painted TSK probability intervals and chain fit diagnostics."""
from __future__ import annotations

import math

from PySide6.QtCore import QEvent, QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPalette, QPen, QTextLayout, QTextOption
from PySide6.QtWidgets import QToolTip, QWidget

from .tsk_risk_display import boundary_note, is_boundary_low, percentage, risk_interval_text, risk_probability_text


def _probability(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value) and 0 <= value <= 1


def _percentage(value):
    return percentage(value)


def _single_line(value):
    """Keep distinct names intact while preventing embedded line breaks."""
    return str(value).translate(str.maketrans({"\\": "\\\\", "\n": r"\n", "\r": r"\r", "\t": r"\t"}))


def _axis_maximum(values):
    maximum = max((float(value) for value in values if _probability(value)), default=0)
    return min(1., max(.01, maximum * 1.12))


class _TskPlot(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.rows = []
        self._hit_regions = []

    def _colors(self):
        palette = self.palette()
        muted = QColor(palette.color(QPalette.Text))
        muted.setAlpha(205)
        return {"background": palette.color(QPalette.Base), "ink": palette.color(QPalette.Text),
                "muted": muted, "grid": palette.color(QPalette.Mid),
                "series": palette.color(QPalette.Active, QPalette.Highlight)}

    def _empty(self, painter, colors):
        painter.setPen(colors["muted"])
        painter.drawText(self.rect().adjusted(12, 12, -12, -12), Qt.AlignCenter | Qt.TextWordWrap,
                         str(self.property("emptyText") or ""))

    def event(self, event):
        if event.type() == QEvent.ToolTip:
            for region, text in reversed(self._hit_regions):
                if region.contains(event.pos()):
                    QToolTip.showText(event.globalPos(), text, self)
                    return True
            QToolTip.hideText()
        return super().event(event)


class TskRiskPlot(_TskPlot):
    def set_category_dimensions(self, categories):
        self._category_dimensions = categories

    def _row_label(self, row):
        if self.property("virtualRows") and row.get("categories"):
            categories = "\n".join(str(self.property("categoryLineFormat")).format(name=name, value=value)
                                     for name, value in row["categories"].items())
            return str(self.property("combinationLabelFormat")).format(tsk_id=row["tsk_id"], categories=categories)
        return str(row.get("label", row.get("tsk_id", "")))

    def set_rows(self, rows, *, preserve_order=False):
        def order(row):
            probability = row.get("probability")
            valid = row.get("identifiable", True) and _probability(probability)
            return (0, -float(probability), str(row.get("tsk_id", ""))) if valid else (1, 0, str(row.get("tsk_id", "")))
        self.rows = list(rows) if preserve_order else sorted(rows, key=order)
        self._maximum = _axis_maximum(value for row in self.rows if row.get("identifiable", True)
                                      for value in (row.get("probability"), row.get("ci_upper")))
        self._has_boundary = any(is_boundary_low(row) for row in self.rows)
        self._type_labels = list(dict.fromkeys(str(row.get("tsk_id", "")) for row in self.rows))
        self._update_label_layout()
        self.update()

    def _update_label_layout(self):
        metrics = self.fontMetrics()
        self._virtual = bool(self.property("virtualRows") and self.rows and self.rows[0].get("categories"))
        if self._virtual:
            # Derive one safe row height from the vocabularies, not from every
            # Cartesian row. Text layouts are created only for visible rows.
            dimensions = getattr(self, "_category_dimensions", {})
            groups = [getattr(self, "_type_labels", [])]
            for name, definition in dimensions.items():
                groups.append([str(self.property("categoryLineFormat")).format(name=name, value=value)
                               for value in definition["levels"]])
            width_padding = float(self.property("multilineLabelWidthPadding") or 12)
            desired = max((metrics.horizontalAdvance(line) + width_padding for group in groups for label in group
                           for line in label.splitlines()), default=65)
            self._label_width = max(65., min(desired, float(self.property("multilineLabelMaxWidth") or 260),
                                            self.width() * float(self.property("multilineLabelWidthRatio") or .38)))
            line_width = max(1., self._label_width - 8)
            lines = sum(max((sum(1 if metrics.horizontalAdvance(line) <= line_width else
                                    math.ceil(metrics.horizontalAdvance(line) / line_width) + 1
                                    for line in label.splitlines()) for label in group), default=1) for group in groups)
            height = max(float(self.property("minimumRowHeight") or 50),
                         lines * metrics.lineSpacing() + float(self.property("multilineLabelPadding") or 14))
            self._uniform_row_height = height
            self._row_heights = [height] * len(self.rows)
            self._label_layouts = {}
            self._logical_height = max(190, math.ceil(height * len(self.rows)) + 63)
            self.setMinimumHeight(min(int(self.property("virtualCanvasMaximumHeight") or 16777215), self._logical_height))
            return
        labels = [self._row_label(row) for row in self.rows]
        multiline = any("\n" in label for label in labels)
        if multiline:
            width_padding = float(self.property("multilineLabelWidthPadding") or 12)
            desired = max((metrics.horizontalAdvance(line) + width_padding for label in labels for line in label.splitlines()), default=65)
            self._label_width = max(65., min(desired, float(self.property("multilineLabelMaxWidth") or 260),
                                            self.width() * float(self.property("multilineLabelWidthRatio") or .38)))
        else:
            self._label_width = max(65., min(150., self.width() * .30))
        minimum_height = float(self.property("minimumRowHeight") or 50)
        padding = float(self.property("multilineLabelPadding") or 14)
        self._label_layouts = []
        self._row_heights = []
        for label in labels:
            if "\n" not in label:
                self._label_layouts.append((None, float(metrics.height())))
                self._row_heights.append(max(minimum_height, metrics.height() + padding))
                continue
            layouts, height = [], 0.
            for paragraph in label.split("\n"):
                layout = QTextLayout(paragraph, self.font())
                option = QTextOption(Qt.AlignRight)
                option.setWrapMode(QTextOption.WrapAtWordBoundaryOrAnywhere)
                layout.setTextOption(option)
                layout.beginLayout()
                while True:
                    line = layout.createLine()
                    if not line.isValid():
                        break
                    line.setLineWidth(self._label_width - 8)
                    line.setPosition(QPointF(0, height))
                    height += line.height()
                layout.endLayout()
                layouts.append(layout)
            self._label_layouts.append((layouts, height))
            self._row_heights.append(max(minimum_height, height + padding))
        self.setMinimumHeight(max(190, math.ceil(sum(self._row_heights)) + 63))

    def resizeEvent(self, event):
        self._update_label_layout()
        super().resizeEvent(event)

    def changeEvent(self, event):
        if event.type() == QEvent.FontChange:
            self._update_label_layout()
        super().changeEvent(event)

    def _draw_row_label(self, painter, index, label, center):
        if self._virtual and index not in self._label_layouts:
            layouts, height = [], 0.
            for paragraph in label.split("\n"):
                layout = QTextLayout(paragraph, self.font())
                option = QTextOption(Qt.AlignRight)
                option.setWrapMode(QTextOption.WrapAtWordBoundaryOrAnywhere)
                layout.setTextOption(option)
                layout.beginLayout()
                while True:
                    line = layout.createLine()
                    if not line.isValid():
                        break
                    line.setLineWidth(self._label_width - 8)
                    line.setPosition(QPointF(0, height))
                    height += line.height()
                layout.endLayout()
                layouts.append(layout)
            self._label_layouts[index] = (layouts, height)
        layouts, label_height = self._label_layouts[index]
        label_region = QRectF(5, center - label_height / 2, self._label_width - 8, label_height)
        self._label_regions.append((label_region, label))
        if layouts is not None:
            for layout in layouts:
                layout.draw(painter, label_region.topLeft())
        else:
            painter.drawText(label_region, Qt.AlignRight | Qt.AlignVCenter,
                             painter.fontMetrics().elidedText(label, Qt.ElideRight, int(self._label_width - 8)))

    def _virtual_scroll_offset(self):
        # QWidgets cannot exceed QWIDGETSIZE_MAX. Compress only the scrollbar
        # coordinate beyond that limit, while keeping bars at readable heights.
        # This lets the last row remain reachable without dropping any rows.
        if not self._virtual or self._logical_height <= self.height():
            return 0.
        viewport_height = self.parentWidget().height() if self.parentWidget() else self.height()
        physical_span = max(1., self.height() - viewport_height)
        logical_span = max(1., self._logical_height - viewport_height)
        return max(0., -self.y()) * (logical_span / physical_span - 1.)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        colors = self._colors()
        painter.fillRect(self.rect(), colors["background"])
        self._hit_regions = []
        self._label_regions = []
        if not self.rows:
            self._empty(painter, colors)
            return
        metrics = painter.fontMetrics()
        label_width = self._label_width
        value_width = max(58., metrics.horizontalAdvance("100.000%") + 10)
        if self._has_boundary:
            value_width = max(value_width, metrics.horizontalAdvance(str(self.property("boundaryLowText") or "")) + 10)
        left, right = label_width + 6, self.width() - value_width - 8
        top = 14.
        scroll_offset = self._virtual_scroll_offset()
        bottom = top + (self._uniform_row_height * len(self.rows) if self._virtual else sum(self._row_heights)) - scroll_offset
        plot_width = max(16., right - left)
        maximum = self._maximum
        scale = lambda value: left + value / maximum * plot_width
        ticks = 2 if plot_width < 230 else 4
        painter.setPen(QPen(colors["grid"], 1))
        painter.drawLine(QPointF(left, bottom), QPointF(right, bottom))
        for index in range(ticks + 1):
            value = maximum * index / ticks
            x = scale(value)
            painter.setPen(QPen(colors["grid"], 1))
            painter.drawLine(QPointF(x, top - scroll_offset), QPointF(x, bottom))
            painter.setPen(colors["muted"])
            alignment = Qt.AlignLeft if index == 0 else Qt.AlignRight if index == ticks else Qt.AlignHCenter
            tick_rect = QRectF(x if index == 0 else x - 50 if index == ticks else x - 25, bottom + 4, 50, 17)
            painter.drawText(tick_rect, alignment | Qt.AlignVCenter, f"{100 * value:.2f}")
        painter.setPen(colors["ink"])
        painter.drawText(QRectF(left - 10, bottom + 24, plot_width + 20, 20), Qt.AlignCenter,
                         str(self.property("axisLabel") or ""))
        start, end = 0, len(self.rows)
        if self._virtual:
            start = max(0, int((event.rect().top() + scroll_offset - top) // self._uniform_row_height))
            end = min(len(self.rows), int((event.rect().bottom() + scroll_offset - top) // self._uniform_row_height) + 1)
            self._label_layouts = {}
        row_top = top + (start * self._uniform_row_height if self._virtual else 0) - scroll_offset
        for index in range(start, end):
            row = self.rows[index]
            row_height = self._row_heights[index]
            center = row_top + row_height / 2
            label = self._row_label(row)
            painter.setPen(colors["ink"])
            self._draw_row_label(painter, index, label, center)
            probability = row.get("probability")
            identified = row.get("identifiable", True)
            detail = f"TSK {label}\n状态：{row.get('status', '')}\n实例数：{row.get('layout_instance_count', row.get('instance_count', '—'))}"
            if not identified or not _probability(probability):
                if row.get("status") == "no_data":
                    text = str(self.property("noDataText") or "")
                    detail += "\n" + str(self.property("noDataTooltip") or "")
                elif row.get("status") in {"reference_outside_domain", "outside_model_domain"}:
                    text = str(self.property("outsideDomainText") or "")
                else:
                    text = "不可单独估计" if not identified else "无有效估计"
                painter.setPen(colors["muted"])
                painter.drawText(QRectF(left + 4, center - 11, self.width() - left - 8, 22), Qt.AlignLeft | Qt.AlignVCenter, text)
                detail += "\n" + text
            else:
                bar_width = max(0., scale(probability) - left)
                painter.fillRect(QRectF(left, center - 7, bar_width, 14), colors["series"])
                low, high = row.get("ci_lower"), row.get("ci_upper")
                if row.get("interval_sidedness") == "upper" and _probability(high):
                    painter.setPen(QPen(colors["ink"], 1.5))
                    painter.drawLine(QPointF(scale(probability), center), QPointF(scale(high), center))
                    painter.drawLine(QPointF(scale(high), center - 5), QPointF(scale(high), center + 5))
                elif _probability(low) and _probability(high):
                    painter.setPen(QPen(colors["ink"], 1.5))
                    painter.drawLine(QPointF(scale(low), center), QPointF(scale(high), center))
                    for bound in (low, high):
                        painter.drawLine(QPointF(scale(bound), center - 5), QPointF(scale(bound), center + 5))
                if probability == 0:
                    painter.setPen(QPen(colors["series"], 2))
                    painter.drawLine(QPointF(left, center - 6), QPointF(left, center + 6))
                painter.setPen(colors["ink"])
                painter.drawText(QRectF(right + 6, center - 10, value_width, 20), Qt.AlignLeft | Qt.AlignVCenter,
                                 risk_probability_text(self, row, precision=3))
                detail += f"\nP_fail：{risk_probability_text(self, row)}\n{risk_interval_text(self, row)}"
                note = boundary_note(self, row)
                if note:
                    detail += "\n" + note
            if row.get("interval_error"):
                detail += "\n" + str(self.property("intervalErrorFormat") or "{error}").format(error=row["interval_error"])
            if row.get("interval_method"):
                detail += "\n" + str(self.property("intervalMethodFormat") or "{method}").format(method=row["interval_method"])
            if row.get("categories") and self.property("supportFormat"):
                detail += "\n" + str(self.property("supportFormat")).format(
                    chains=row.get("chain_count", 0), exposure=row.get("chain_test_exposure", 0))
            self._hit_regions.append((QRectF(0, center - row_height / 2, self.width(), row_height), row.get("tooltip", detail)))
            row_top += row_height


class TskChainFitPlot(_TskPlot):
    def set_rows(self, rows):
        self.rows = list(rows)
        self.update()

    def event(self, event):
        if event.type() == QEvent.ToolTip:
            details = [text for region, text in self._hit_regions if region.contains(event.pos())]
            if details:
                QToolTip.showText(event.globalPos(), "\n\n".join(details), self)
                return True
        return super().event(event)

    def _tooltip(self, row):
        detail = str(self.property("tooltipFormat")).format(
            chain_id=row.get("chain_id", ""), observed=_percentage(row.get("observed_probability")),
            predicted=_percentage(row.get("predicted_probability")), failed=row.get("n_failed", "—"),
            tested=row.get("n_tested", "—"), missing=row.get("n_missing", "—"))
        members = row.get("members", [])
        if not members:
            return detail + "\n" + str(self.property("noMembersText"))
        detail += "\n" + str(self.property("membersHeading"))
        notes = {}
        has_boundary = False
        unavailable_properties = {
            "no_data": "memberNoDataText", "not_identifiable": "memberNotIdentifiableText",
            "fit_not_converged": "memberNotConvergedText",
            "outside_model_domain": "memberOutsideDomainText",
        }
        for member in members:
            conditions = member.get("features") or {**member.get("categories", {}), **member.get("numeric", {})}
            description = "; ".join(f"{_single_line(name)}={_single_line(value)}" for name, value in conditions.items())
            probability = (risk_probability_text(self, member) if member.get("identifiable", True)
                           and _probability(member.get("probability")) else str(self.property(
                               unavailable_properties.get(member.get("status"), "memberUnavailableText"))))
            reason = " ".join(str(member.get("reason") or "").split())
            note_reference = ""
            if reason:
                index = notes.setdefault(reason, len(notes) + 1)
                note_reference = str(self.property("memberNoteReferenceFormat")).format(index=index)
            has_boundary = has_boundary or bool(boundary_note(self, member))
            detail += "\n" + str(self.property("memberFormat")).format(
                tsk_id=_single_line(member.get("tsk_id", "")), count=member.get("count", 1),
                conditions=description or self.property("noFeaturesText"), probability=probability,
                reason=note_reference)
        if has_boundary:
            detail += "\n" + str(self.property("boundaryHintText"))
        for note, index in notes.items():
            detail += "\n" + str(self.property("memberNoteFormat")).format(index=index, text=note)
        return detail

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        colors = self._colors()
        painter.fillRect(self.rect(), colors["background"])
        self._hit_regions = []
        points = [row for row in self.rows if _probability(row.get("observed_probability"))
                  and _probability(row.get("predicted_probability"))]
        if not points:
            self._empty(painter, colors)
            return
        left, top, right, bottom = 62., 25., self.width() - 20., self.height() - 48.
        if right <= left or bottom <= top:
            return
        maximum = _axis_maximum(value for row in points for value in
                                (row["observed_probability"], row["predicted_probability"]))
        x = lambda value: left + value / maximum * (right - left)
        y = lambda value: bottom - value / maximum * (bottom - top)
        ticks = 2 if self.width() < 450 else 4
        painter.setPen(QPen(colors["grid"], 1))
        painter.drawRect(QRectF(left, top, right - left, bottom - top))
        for index in range(ticks + 1):
            value = maximum * index / ticks
            px, py = x(value), y(value)
            painter.setPen(QPen(colors["grid"], 1))
            painter.drawLine(QPointF(px, top), QPointF(px, bottom))
            painter.drawLine(QPointF(left, py), QPointF(right, py))
            painter.setPen(colors["muted"])
            painter.drawText(QRectF(20, py - 9, left - 25, 18), Qt.AlignRight | Qt.AlignVCenter, f"{100 * value:.2f}")
            alignment = Qt.AlignLeft if index == 0 else Qt.AlignRight if index == ticks else Qt.AlignHCenter
            tick_rect = QRectF(px if index == 0 else px - 50 if index == ticks else px - 25, bottom + 4, 50, 18)
            painter.drawText(tick_rect, alignment | Qt.AlignVCenter, f"{100 * value:.2f}")
        painter.setPen(QPen(colors["muted"], 1.3, Qt.DashLine))
        painter.drawLine(QPointF(left, bottom), QPointF(right, top))
        painter.setPen(colors["ink"])
        painter.drawText(QRectF(left - 10, bottom + 25, right - left + 20, 20), Qt.AlignCenter,
                         str(self.property("xAxisLabel") or ""))
        painter.save()
        painter.translate(15, (top + bottom) / 2)
        painter.rotate(-90)
        painter.drawText(QRectF(-(bottom - top) / 2 - 15, -10, bottom - top + 30, 20), Qt.AlignCenter,
                         str(self.property("yAxisLabel") or ""))
        painter.restore()
        mark_color = QColor(colors["series"])
        mark_color.setAlpha(185)
        painter.setBrush(mark_color)
        painter.setPen(QPen(colors["background"], 1))
        for row in points:
            point = QPointF(x(row["predicted_probability"]), y(row["observed_probability"]))
            painter.drawEllipse(point, 4.5, 4.5)
            detail = self._tooltip(row)
            self._hit_regions.append((QRectF(point.x() - 9, point.y() - 9, 18, 18), detail))
