from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QWidget

from .ui_merge_controls import Ui_MergeControlsForm

from ..merge_config import (
    MERGE_RULE_FIELDS, normalize_merge_order, row_levels, column_levels,
    chain_level, initial_row_level, initial_column_level, validate_merge_levels, default_initial_column_level,
    validate_same_level_rules,
)
from ..models import TemplateConfig


class MergeControls(QWidget):
    changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_MergeControlsForm()
        self.ui.setupUi(self)
        self.layout = self.ui.gridLayout
        self.template = None
        self.order = []
        self.levels = {}
        self.rules = {}
        self.labels = {}
        self.corner_label = self.ui.cornerLabel
        self.level_label = self.ui.levelLabel
        self.rule_label = self.ui.ruleLabel
        for public in MERGE_RULE_FIELDS:
            step = public.removesuffix("_fail_rule")
            self.labels[step] = getattr(self.ui, step + "Label")
            combo = getattr(self.ui, step + "LevelComboBox")
            combo.currentIndexChanged.connect(self._changed)
            self.levels[step] = combo
            rule = getattr(self.ui, step + "FailRuleComboBox")
            rule.setItemData(0, "any_fail")
            rule.setItemData(1, "all_fail")
            rule.currentIndexChanged.connect(self._changed)
            self.rules[step] = rule
        self.reorder("Initial column merge -> Final column merge -> Initial row merge -> Final row merge")

    def reorder(self, order: str):
        steps = [part.strip().lower().replace(" ", "_") for part in normalize_merge_order(order).split("->")]
        if len(steps) != 4 or set(steps) != set(self.levels):
            return
        self.order = steps
        while self.layout.count():
            self.layout.takeAt(0)
        self.layout.addWidget(self.corner_label, 0, 0)
        self.layout.addWidget(self.level_label, 1, 0)
        self.layout.addWidget(self.rule_label, 2, 0)
        for column, step in enumerate(steps, 1):
            self.layout.addWidget(self.labels[step], 0, column)
            self.layout.addWidget(self.levels[step], 1, column)
            self.layout.addWidget(self.rules[step], 2, column)

    def set_template(self, template: TemplateConfig):
        validate_same_level_rules(template)
        self.template = template
        self.set_roles(template.report.reliability_node_dimension, chain_level(template), reset=True)
        for public, backing in MERGE_RULE_FIELDS.items():
            combo = self.rules[public.removesuffix("_fail_rule")]
            combo.blockSignals(True)
            combo.setCurrentIndex(combo.findData(getattr(template.report, backing)))
            combo.blockSignals(False)
        self.reorder(template.report.outlier_merge_order)
        self._sync_equal_rules()

    def set_roles(self, node: str, chain: str, *, reset=False):
        if self.template is None:
            return
        for axis, names, final, initial in (
            ("row", row_levels(self.template), node, initial_row_level(self.template)),
            ("column", column_levels(self.template), chain, initial_column_level(self.template)),
        ):
            for stage in ("initial", "final"):
                combo = self.levels[f"{stage}_{axis}_merge"]
                selected = final if stage == "final" else (initial if reset else combo.currentData())
                if not reset and stage == "initial" and selected in names and final in names and names.index(selected) < names.index(final):
                    selected = default_initial_column_level(self.template, final) if axis == "column" else final
                combo.blockSignals(True)
                combo.clear()
                combo.addItem("请选择保留层级", "")
                for index, name in enumerate(names):
                    combo.addItem(name, name)
                    if stage == "initial" and final in names and index < names.index(final):
                        combo.model().item(combo.count() - 1).setEnabled(False)
                combo.setCurrentIndex(max(0, combo.findData(selected)))
                combo.blockSignals(False)
        self._sync_equal_rules()

    def _sync_equal_rules(self):
        for axis in ("row", "column"):
            initial = f"initial_{axis}_merge"
            final = f"final_{axis}_merge"
            value = self.levels[initial].currentData()
            same = bool(value) and value == self.levels[final].currentData()
            self.rules[final].setEnabled(not same)
            self.rules[final].setToolTip("Initial 与 Final 同层，只执行一次有效合并，判据跟随 Initial。" if same else "最终汇总的判据。")
            if same:
                self.rules[final].blockSignals(True)
                self.rules[final].setCurrentIndex(self.rules[final].findData(self.rules[initial].currentData()))
                self.rules[final].blockSignals(False)

    def _changed(self, *args):
        self._sync_equal_rules()
        self.changed.emit()

    def apply_to(self, template: TemplateConfig, *, validate=True):
        if validate and (not self.levels["initial_row_merge"].currentData() or not self.levels["initial_column_merge"].currentData()):
            raise ValueError("请选择 Initial row 和 Initial column 的保留层级。")
        template.report.initial_row_merge_level = self.levels["initial_row_merge"].currentData() or None
        template.report.initial_column_merge_level = self.levels["initial_column_merge"].currentData() or None
        # Old boundary fields must never override an explicitly cleared selection.
        template.report.outlier_row_merge_max_dimension = None
        template.report.outlier_test_merge_max_level = None
        for public, backing in MERGE_RULE_FIELDS.items():
            setattr(template.report, backing, self.rules[public.removesuffix("_fail_rule")].currentData())
        if validate:
            validate_merge_levels(template)
