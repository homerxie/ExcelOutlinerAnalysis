# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'template_edit_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
    QPushButton, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)

class Ui_TemplateEditDialog(object):
    def setupUi(self, TemplateEditDialog):
        if not TemplateEditDialog.objectName():
            TemplateEditDialog.setObjectName(u"TemplateEditDialog")
        TemplateEditDialog.setMinimumSize(QSize(480, 0))
        self.verticalLayout = QVBoxLayout(TemplateEditDialog)
        self.verticalLayout.setSpacing(16)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.titleLabel = QLabel(TemplateEditDialog)
        self.titleLabel.setObjectName(u"titleLabel")
        font = QFont()
        font.setBold(True)
        self.titleLabel.setFont(font)

        self.verticalLayout.addWidget(self.titleLabel)

        self.messageLabel = QLabel(TemplateEditDialog)
        self.messageLabel.setObjectName(u"messageLabel")
        self.messageLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.messageLabel)

        self.buttonLayout = QHBoxLayout()
        self.buttonLayout.setObjectName(u"buttonLayout")
        self.buttonSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.buttonLayout.addItem(self.buttonSpacer)

        self.cancelButton = QPushButton(TemplateEditDialog)
        self.cancelButton.setObjectName(u"cancelButton")

        self.buttonLayout.addWidget(self.cancelButton)

        self.unlockButton = QPushButton(TemplateEditDialog)
        self.unlockButton.setObjectName(u"unlockButton")

        self.buttonLayout.addWidget(self.unlockButton)


        self.verticalLayout.addLayout(self.buttonLayout)


        self.retranslateUi(TemplateEditDialog)
        self.cancelButton.clicked.connect(TemplateEditDialog.reject)
        self.unlockButton.clicked.connect(TemplateEditDialog.accept)

        self.cancelButton.setDefault(True)


        QMetaObject.connectSlotsByName(TemplateEditDialog)
    # setupUi

    def retranslateUi(self, TemplateEditDialog):
        TemplateEditDialog.setWindowTitle(QCoreApplication.translate("TemplateEditDialog", u"\u5f00\u542f\u6a21\u677f\u7f16\u8f91", None))
        self.titleLabel.setText(QCoreApplication.translate("TemplateEditDialog", u"\u8bf7\u8c28\u614e\u4fee\u6539\u6a21\u677f\u76f8\u5173\u53c2\u6570", None))
        self.messageLabel.setText(QCoreApplication.translate("TemplateEditDialog", u"\u8fd9\u4e9b\u8bbe\u7f6e\u4f1a\u5f71\u54cd\u6570\u636e\u5bfc\u5165\u3001Golden \u8ba1\u7b97\u548c\u5f02\u5e38\u5224\u5b9a\u3002\u4fee\u6539\u552f\u4e00 ID\u3001\u5c42\u7ea7\u6216\u5408\u5e76\u89c4\u5219\u524d\uff0c\u8bf7\u786e\u8ba4\u542b\u4e49\u3002\n"
"\n"
"\u89e3\u9501\u548c\u9501\u56de\u90fd\u4e0d\u4f1a\u81ea\u52a8\u4fdd\u5b58\u6a21\u677f\u3002\u8fd0\u884c\u65f6\u82e5\u8bbe\u7f6e\u4e0e\u6a21\u677f\u4e0d\u540c\uff0c\u4ecd\u4f1a\u63d0\u793a\u9009\u62e9\u5982\u4f55\u5904\u7406\u3002\n"
"\n"
"\u70b9\u51fb Import\u3001Build Golden \u6216 Analyze \u540e\u4f1a\u81ea\u52a8\u9501\u56de\uff0c\u5e76\u4fdd\u7559\u5f53\u524d\u4fee\u6539\u3002", None))
        self.cancelButton.setText(QCoreApplication.translate("TemplateEditDialog", u"\u4fdd\u6301\u9501\u5b9a", None))
        self.unlockButton.setText(QCoreApplication.translate("TemplateEditDialog", u"\u6211\u5df2\u4e86\u89e3\uff0c\u5f00\u542f\u7f16\u8f91", None))
    # retranslateUi

