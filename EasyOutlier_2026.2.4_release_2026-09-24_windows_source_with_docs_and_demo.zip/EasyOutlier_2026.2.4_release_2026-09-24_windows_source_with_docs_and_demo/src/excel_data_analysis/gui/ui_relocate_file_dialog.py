# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'relocate_file_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QSizePolicy,
    QSpacerItem, QVBoxLayout, QWidget)

class Ui_RelocateFileDialog(object):
    def setupUi(self, RelocateFileDialog):
        if not RelocateFileDialog.objectName():
            RelocateFileDialog.setObjectName(u"RelocateFileDialog")
        RelocateFileDialog.resize(720, 320)
        RelocateFileDialog.setMinimumSize(QSize(560, 0))
        self.verticalLayout = QVBoxLayout(RelocateFileDialog)
        self.verticalLayout.setSpacing(12)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.messageLabel = QLabel(RelocateFileDialog)
        self.messageLabel.setObjectName(u"messageLabel")
        self.messageLabel.setWordWrap(True)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.messageLabel.sizePolicy().hasHeightForWidth())
        self.messageLabel.setSizePolicy(sizePolicy)

        self.verticalLayout.addWidget(self.messageLabel)

        self.fileKindLabel = QLabel(RelocateFileDialog)
        self.fileKindLabel.setObjectName(u"fileKindLabel")
        font = QFont()
        font.setBold(True)
        self.fileKindLabel.setFont(font)

        self.verticalLayout.addWidget(self.fileKindLabel)

        self.pathLayout = QGridLayout()
        self.pathLayout.setObjectName(u"pathLayout")
        self.pathLayout.setHorizontalSpacing(10)
        self.pathLayout.setVerticalSpacing(10)
        self.oldPathLabel = QLabel(RelocateFileDialog)
        self.oldPathLabel.setObjectName(u"oldPathLabel")

        self.pathLayout.addWidget(self.oldPathLabel, 0, 0, 1, 1)

        self.oldPathEdit = QLineEdit(RelocateFileDialog)
        self.oldPathEdit.setObjectName(u"oldPathEdit")
        self.oldPathEdit.setReadOnly(True)
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.oldPathEdit.sizePolicy().hasHeightForWidth())
        self.oldPathEdit.setSizePolicy(sizePolicy1)

        self.pathLayout.addWidget(self.oldPathEdit, 0, 1, 1, 2)

        self.newPathLabel = QLabel(RelocateFileDialog)
        self.newPathLabel.setObjectName(u"newPathLabel")

        self.pathLayout.addWidget(self.newPathLabel, 1, 0, 1, 1)

        self.newPathEdit = QLineEdit(RelocateFileDialog)
        self.newPathEdit.setObjectName(u"newPathEdit")
        self.newPathEdit.setClearButtonEnabled(True)
        sizePolicy1.setHeightForWidth(self.newPathEdit.sizePolicy().hasHeightForWidth())
        self.newPathEdit.setSizePolicy(sizePolicy1)

        self.pathLayout.addWidget(self.newPathEdit, 1, 1, 1, 1)

        self.browseButton = QPushButton(RelocateFileDialog)
        self.browseButton.setObjectName(u"browseButton")
        self.browseButton.setAutoDefault(False)
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.browseButton.sizePolicy().hasHeightForWidth())
        self.browseButton.setSizePolicy(sizePolicy2)

        self.pathLayout.addWidget(self.browseButton, 1, 2, 1, 1)

        self.pathLayout.setColumnStretch(1, 1)

        self.verticalLayout.addLayout(self.pathLayout)

        self.errorLabel = QLabel(RelocateFileDialog)
        self.errorLabel.setObjectName(u"errorLabel")
        self.errorLabel.setVisible(False)
        self.errorLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.errorLabel.setWordWrap(True)
        sizePolicy.setHeightForWidth(self.errorLabel.sizePolicy().hasHeightForWidth())
        self.errorLabel.setSizePolicy(sizePolicy)

        self.verticalLayout.addWidget(self.errorLabel)

        self.optionalHintLabel = QLabel(RelocateFileDialog)
        self.optionalHintLabel.setObjectName(u"optionalHintLabel")
        self.optionalHintLabel.setVisible(False)
        self.optionalHintLabel.setWordWrap(True)
        sizePolicy.setHeightForWidth(self.optionalHintLabel.sizePolicy().hasHeightForWidth())
        self.optionalHintLabel.setSizePolicy(sizePolicy)

        self.verticalLayout.addWidget(self.optionalHintLabel)

        self.verticalSpacer = QSpacerItem(20, 8, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.buttonLayout = QHBoxLayout()
        self.buttonLayout.setSpacing(10)
        self.buttonLayout.setObjectName(u"buttonLayout")
        self.skipButton = QPushButton(RelocateFileDialog)
        self.skipButton.setObjectName(u"skipButton")
        self.skipButton.setVisible(False)
        self.skipButton.setAutoDefault(False)

        self.buttonLayout.addWidget(self.skipButton)

        self.buttonSpacer = QSpacerItem(20, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.buttonLayout.addItem(self.buttonSpacer)

        self.cancelButton = QPushButton(RelocateFileDialog)
        self.cancelButton.setObjectName(u"cancelButton")
        self.cancelButton.setAutoDefault(False)

        self.buttonLayout.addWidget(self.cancelButton)

        self.continueButton = QPushButton(RelocateFileDialog)
        self.continueButton.setObjectName(u"continueButton")
        self.continueButton.setEnabled(False)

        self.buttonLayout.addWidget(self.continueButton)


        self.verticalLayout.addLayout(self.buttonLayout)

#if QT_CONFIG(shortcut)
        self.newPathLabel.setBuddy(self.newPathEdit)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(RelocateFileDialog)

        self.continueButton.setDefault(True)


        QMetaObject.connectSlotsByName(RelocateFileDialog)
    # setupUi

    def retranslateUi(self, RelocateFileDialog):
        RelocateFileDialog.setWindowTitle(QCoreApplication.translate("RelocateFileDialog", u"\u91cd\u65b0\u5b9a\u4f4d\u5173\u8054\u6587\u4ef6", None))
        RelocateFileDialog.setProperty(u"templateName", QCoreApplication.translate("RelocateFileDialog", u"\u6a21\u677f\u6587\u4ef6", None))
        RelocateFileDialog.setProperty(u"inputName", QCoreApplication.translate("RelocateFileDialog", u"\u539f\u59cb\u8f93\u5165\u6587\u4ef6", None))
        RelocateFileDialog.setProperty(u"goldenName", QCoreApplication.translate("RelocateFileDialog", u"Golden \u53c2\u8003\u6587\u4ef6", None))
        RelocateFileDialog.setProperty(u"templateFilter", QCoreApplication.translate("RelocateFileDialog", u"Template Files (*.json *.xlsx *.xlsm)", None))
        RelocateFileDialog.setProperty(u"inputFilter", QCoreApplication.translate("RelocateFileDialog", u"Input Files (*.xlsx *.xlsm *.csv)", None))
        RelocateFileDialog.setProperty(u"goldenFilter", QCoreApplication.translate("RelocateFileDialog", u"JSON Files (*.json)", None))
        RelocateFileDialog.setProperty(u"unavailableText", QCoreApplication.translate("RelocateFileDialog", u"\u65e0\u6cd5\u8bbf\u95ee\u6240\u9009\u6587\u4ef6\uff0c\u8bf7\u68c0\u67e5\u4f4d\u7f6e\u6216\u91cd\u65b0\u9009\u62e9\u3002", None))
        self.messageLabel.setText(QCoreApplication.translate("RelocateFileDialog", u"\u6570\u636e\u5e93\u4e2d\u8bb0\u5f55\u7684\u6587\u4ef6\u4f4d\u7f6e\u5df2\u65e0\u6cd5\u8bbf\u95ee\u3002\u8bf7\u9009\u62e9\u79fb\u52a8\u540e\u7684\u6587\u4ef6\uff0c\u786e\u8ba4\u540e\u7ee7\u7eed\u6253\u5f00\u6570\u636e\u5e93\u3002\u6210\u529f\u6253\u5f00\u540e\uff0c\u65b0\u4f4d\u7f6e\u4f1a\u4fdd\u5b58\u5728\u5f53\u524d\u6570\u636e\u5e93\u4e2d\u3002", None))
        self.fileKindLabel.setText(QCoreApplication.translate("RelocateFileDialog", u"\u5173\u8054\u6587\u4ef6", None))
        self.oldPathLabel.setText(QCoreApplication.translate("RelocateFileDialog", u"\u539f\u4f4d\u7f6e", None))
        self.newPathLabel.setText(QCoreApplication.translate("RelocateFileDialog", u"\u65b0\u4f4d\u7f6e", None))
        self.newPathEdit.setPlaceholderText(QCoreApplication.translate("RelocateFileDialog", u"\u9009\u62e9\u6587\u4ef6\uff0c\u6216\u7c98\u8d34\u65b0\u7684\u6587\u4ef6\u8def\u5f84", None))
        self.browseButton.setText(QCoreApplication.translate("RelocateFileDialog", u"\u9009\u62e9\u6587\u4ef6\u2026", None))
        self.errorLabel.setText("")
        self.optionalHintLabel.setText(QCoreApplication.translate("RelocateFileDialog", u"\u6b64\u6587\u4ef6\u4e0d\u662f\u6253\u5f00\u5df2\u6709\u6570\u636e\u7684\u5fc5\u8981\u6761\u4ef6\u3002\u9009\u62e9\u201c\u6682\u4e0d\u5173\u8054\u201d\u4f1a\u6e05\u7a7a\u8fd9\u9879\u6587\u4ef6\u5173\u8054\uff0c\u6570\u636e\u5e93\u4e2d\u7684\u5df2\u5bfc\u5165\u6570\u636e\u4e0d\u53d7\u5f71\u54cd\u3002", None))
        self.skipButton.setText(QCoreApplication.translate("RelocateFileDialog", u"\u6682\u4e0d\u5173\u8054", None))
        self.cancelButton.setText(QCoreApplication.translate("RelocateFileDialog", u"\u53d6\u6d88\u6253\u5f00", None))
        self.continueButton.setText(QCoreApplication.translate("RelocateFileDialog", u"\u786e\u8ba4\u5e76\u7ee7\u7eed", None))
    # retranslateUi

