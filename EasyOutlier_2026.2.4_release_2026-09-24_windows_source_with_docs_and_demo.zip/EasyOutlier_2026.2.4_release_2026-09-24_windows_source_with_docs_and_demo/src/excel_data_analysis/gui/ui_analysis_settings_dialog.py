# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'analysis_settings_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
    QPlainTextEdit, QPushButton, QSizePolicy, QVBoxLayout,
    QWidget)

class Ui_AnalysisSettingsDialog(object):
    def setupUi(self, AnalysisSettingsDialog):
        if not AnalysisSettingsDialog.objectName():
            AnalysisSettingsDialog.setObjectName(u"AnalysisSettingsDialog")
        AnalysisSettingsDialog.resize(760, 330)
        self.verticalLayout = QVBoxLayout(AnalysisSettingsDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.messageLabel = QLabel(AnalysisSettingsDialog)
        self.messageLabel.setObjectName(u"messageLabel")
        self.messageLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.messageLabel)

        self.differencesEdit = QPlainTextEdit(AnalysisSettingsDialog)
        self.differencesEdit.setObjectName(u"differencesEdit")
        self.differencesEdit.setReadOnly(True)

        self.verticalLayout.addWidget(self.differencesEdit)

        self.buttonLayout = QHBoxLayout()
        self.buttonLayout.setObjectName(u"buttonLayout")
        self.runOnceButton = QPushButton(AnalysisSettingsDialog)
        self.runOnceButton.setObjectName(u"runOnceButton")

        self.buttonLayout.addWidget(self.runOnceButton)

        self.saveRunButton = QPushButton(AnalysisSettingsDialog)
        self.saveRunButton.setObjectName(u"saveRunButton")

        self.buttonLayout.addWidget(self.saveRunButton)

        self.restoreRunButton = QPushButton(AnalysisSettingsDialog)
        self.restoreRunButton.setObjectName(u"restoreRunButton")

        self.buttonLayout.addWidget(self.restoreRunButton)

        self.cancelButton = QPushButton(AnalysisSettingsDialog)
        self.cancelButton.setObjectName(u"cancelButton")

        self.buttonLayout.addWidget(self.cancelButton)


        self.verticalLayout.addLayout(self.buttonLayout)


        self.retranslateUi(AnalysisSettingsDialog)

        self.runOnceButton.setDefault(True)


        QMetaObject.connectSlotsByName(AnalysisSettingsDialog)
    # setupUi

    def retranslateUi(self, AnalysisSettingsDialog):
        AnalysisSettingsDialog.setWindowTitle(QCoreApplication.translate("AnalysisSettingsDialog", u"Analysis Settings", None))
        self.messageLabel.setText(QCoreApplication.translate("AnalysisSettingsDialog", u"\u5f53\u524d Analyze \u8bbe\u7f6e\u4e0e\u6a21\u677f\u4e0d\u540c\uff0c\u8bf7\u9009\u62e9\u672c\u6b21\u8fd0\u884c\u4f7f\u7528\u7684\u914d\u7f6e\u3002", None))
        self.runOnceButton.setText(QCoreApplication.translate("AnalysisSettingsDialog", u"\u4ec5\u672c\u6b21\u8fd0\u884c", None))
        self.saveRunButton.setText(QCoreApplication.translate("AnalysisSettingsDialog", u"\u4fdd\u5b58\u5230\u6a21\u677f\u5e76\u8fd0\u884c", None))
        self.restoreRunButton.setText(QCoreApplication.translate("AnalysisSettingsDialog", u"\u6062\u590d\u6a21\u677f\u914d\u7f6e\u5e76\u8fd0\u884c", None))
        self.cancelButton.setText(QCoreApplication.translate("AnalysisSettingsDialog", u"\u53d6\u6d88", None))
    # retranslateUi

