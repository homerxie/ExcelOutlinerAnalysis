from pathlib import Path

from PySide6.QtWidgets import QDialog, QFileDialog

from ..gui_paths import absolute_path, available_path, dialog_start
from .ui_relocate_file_dialog import Ui_RelocateFileDialog


class RelocateFileDialog(QDialog):
    def __init__(self, parent, key: str, missing_path: str, database_root: str,
                 *, error: str = "", options=QFileDialog.Option(0)):
        super().__init__(parent)
        self.ui = Ui_RelocateFileDialog()
        self.ui.setupUi(self)
        self.file_path: str | None = None
        self._root = Path(database_root)
        self._missing_path = missing_path
        self._options = options
        prefix = {"template_path": "template", "input_path": "input", "golden_path": "golden"}[key]
        self._filter = str(self.property(prefix + "Filter"))
        self.ui.fileKindLabel.setText(str(self.property(prefix + "Name")))
        self.ui.oldPathEdit.setText(missing_path)
        self.ui.oldPathEdit.setToolTip(missing_path)
        self.ui.oldPathEdit.setCursorPosition(0)
        self.ui.optionalHintLabel.setVisible(key != "template_path")
        self.ui.skipButton.setVisible(key != "template_path")
        self.ui.errorLabel.setText(error)
        self.ui.errorLabel.setVisible(bool(error))
        self.ui.newPathEdit.textChanged.connect(self._path_changed)
        self.ui.browseButton.clicked.connect(self._browse)
        self.ui.continueButton.clicked.connect(self._continue)
        self.ui.skipButton.clicked.connect(self._skip)
        self.ui.cancelButton.clicked.connect(self.reject)

    def _path_changed(self, text: str) -> None:
        self.ui.continueButton.setEnabled(bool(text.strip()))
        self.ui.errorLabel.hide()

    def _browse(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, self.ui.fileKindLabel.text(),
            dialog_start(self.ui.newPathEdit.text() or self._missing_path, self._root),
            self._filter, options=self._options,
        )
        if path:
            self.ui.newPathEdit.setText(path)

    def _continue(self) -> None:
        value = self.ui.newPathEdit.text().strip()
        path = absolute_path(value, self._root)
        if not value or not available_path(path):
            self.ui.errorLabel.setText(str(self.property("unavailableText")))
            self.ui.errorLabel.show()
            return
        self.file_path = str(path)
        self.accept()

    def _skip(self) -> None:
        self.file_path = ""
        self.accept()
