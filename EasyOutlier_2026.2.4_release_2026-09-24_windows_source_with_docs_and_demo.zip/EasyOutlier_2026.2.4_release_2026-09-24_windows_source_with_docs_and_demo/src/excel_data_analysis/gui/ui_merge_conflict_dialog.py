# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'merge_conflict_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QDialog, QHBoxLayout,
    QLabel, QPushButton, QSizePolicy, QVBoxLayout,
    QWidget)

class Ui_MergeConflictDialog(object):
    def setupUi(self, MergeConflictDialog):
        if not MergeConflictDialog.objectName():
            MergeConflictDialog.setObjectName(u"MergeConflictDialog")
        MergeConflictDialog.setMinimumSize(QSize(620, 0))
        self.verticalLayout = QVBoxLayout(MergeConflictDialog)
        self.verticalLayout.setSpacing(14)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.messageLabel = QLabel(MergeConflictDialog)
        self.messageLabel.setObjectName(u"messageLabel")
        self.messageLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.messageLabel)

        self.pathLabel = QLabel(MergeConflictDialog)
        self.pathLabel.setObjectName(u"pathLabel")
        self.pathLabel.setWordWrap(True)
        self.pathLabel.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        self.verticalLayout.addWidget(self.pathLabel)

        self.rowPanel = QWidget(MergeConflictDialog)
        self.rowPanel.setObjectName(u"rowPanel")
        self.rowLayout = QVBoxLayout(self.rowPanel)
        self.rowLayout.setObjectName(u"rowLayout")
        self.rowLayout.setContentsMargins(0, 0, 0, 0)
        self.rowDetailsLabel = QLabel(self.rowPanel)
        self.rowDetailsLabel.setObjectName(u"rowDetailsLabel")
        self.rowDetailsLabel.setWordWrap(True)

        self.rowLayout.addWidget(self.rowDetailsLabel)

        self.rowRuleComboBox = QComboBox(self.rowPanel)
        self.rowRuleComboBox.addItem("")
        self.rowRuleComboBox.addItem("")
        self.rowRuleComboBox.addItem("")
        self.rowRuleComboBox.setObjectName(u"rowRuleComboBox")

        self.rowLayout.addWidget(self.rowRuleComboBox)


        self.verticalLayout.addWidget(self.rowPanel)

        self.columnPanel = QWidget(MergeConflictDialog)
        self.columnPanel.setObjectName(u"columnPanel")
        self.columnLayout = QVBoxLayout(self.columnPanel)
        self.columnLayout.setObjectName(u"columnLayout")
        self.columnLayout.setContentsMargins(0, 0, 0, 0)
        self.columnDetailsLabel = QLabel(self.columnPanel)
        self.columnDetailsLabel.setObjectName(u"columnDetailsLabel")
        self.columnDetailsLabel.setWordWrap(True)

        self.columnLayout.addWidget(self.columnDetailsLabel)

        self.columnRuleComboBox = QComboBox(self.columnPanel)
        self.columnRuleComboBox.addItem("")
        self.columnRuleComboBox.addItem("")
        self.columnRuleComboBox.addItem("")
        self.columnRuleComboBox.setObjectName(u"columnRuleComboBox")

        self.columnLayout.addWidget(self.columnRuleComboBox)


        self.verticalLayout.addWidget(self.columnPanel)

        self.buttonLayout = QHBoxLayout()
        self.buttonLayout.setObjectName(u"buttonLayout")
        self.cancelButton = QPushButton(MergeConflictDialog)
        self.cancelButton.setObjectName(u"cancelButton")

        self.buttonLayout.addWidget(self.cancelButton)

        self.saveButton = QPushButton(MergeConflictDialog)
        self.saveButton.setObjectName(u"saveButton")
        self.saveButton.setEnabled(False)

        self.buttonLayout.addWidget(self.saveButton)


        self.verticalLayout.addLayout(self.buttonLayout)


        self.retranslateUi(MergeConflictDialog)
        self.cancelButton.clicked.connect(MergeConflictDialog.reject)
        self.saveButton.clicked.connect(MergeConflictDialog.accept)

        self.cancelButton.setDefault(True)


        QMetaObject.connectSlotsByName(MergeConflictDialog)
    # setupUi

    def retranslateUi(self, MergeConflictDialog):
        MergeConflictDialog.setWindowTitle(QCoreApplication.translate("MergeConflictDialog", u"\u6a21\u677f\u5408\u5e76\u5224\u636e\u51b2\u7a81", None))
        self.messageLabel.setText(QCoreApplication.translate("MergeConflictDialog", u"\u5f53\u524d\u6a21\u677f\u6709\u95ee\u9898\uff1aInitial \u4e0e Final \u4fdd\u7559\u5230\u540c\u4e00\u5c42\u7ea7\uff0c\u5374\u4f7f\u7528\u4e86\u4e0d\u540c\u7684\u5931\u8d25\u5224\u636e\u3002\n"
"\u4e24\u8005\u5fc5\u987b\u4e00\u81f4\u3002\u8bf7\u9009\u62e9\u201c\u4efb\u4e00\u5931\u8d25\u201d\u6216\u201c\u5168\u90e8\u5931\u8d25\u201d\uff0c\u4fdd\u5b58\u5230\u5f53\u524d\u6a21\u677f\u540e\u7ee7\u7eed\u3002", None))
        self.rowRuleComboBox.setItemText(0, QCoreApplication.translate("MergeConflictDialog", u"\u8bf7\u9009\u62e9\u7edf\u4e00\u7684\u884c\u5408\u5e76\u5224\u636e", None))
        self.rowRuleComboBox.setItemText(1, QCoreApplication.translate("MergeConflictDialog", u"any_fail \u00b7 \u4efb\u4e00\u5931\u8d25", None))
        self.rowRuleComboBox.setItemText(2, QCoreApplication.translate("MergeConflictDialog", u"all_fail \u00b7 \u5168\u90e8\u5931\u8d25", None))

        self.columnRuleComboBox.setItemText(0, QCoreApplication.translate("MergeConflictDialog", u"\u8bf7\u9009\u62e9\u7edf\u4e00\u7684\u5217\u5408\u5e76\u5224\u636e", None))
        self.columnRuleComboBox.setItemText(1, QCoreApplication.translate("MergeConflictDialog", u"any_fail \u00b7 \u4efb\u4e00\u5931\u8d25", None))
        self.columnRuleComboBox.setItemText(2, QCoreApplication.translate("MergeConflictDialog", u"all_fail \u00b7 \u5168\u90e8\u5931\u8d25", None))

        self.cancelButton.setText(QCoreApplication.translate("MergeConflictDialog", u"\u53d6\u6d88\uff0c\u4e0d\u4fee\u6539\u6a21\u677f", None))
        self.saveButton.setText(QCoreApplication.translate("MergeConflictDialog", u"\u4fdd\u5b58\u5230\u5f53\u524d\u6a21\u677f\u5e76\u7ee7\u7eed", None))
    # retranslateUi

