"""Convex instance hazard regression with a nonnegative layout domain.

The parameter vector is unrestricted.  It is each *instance* hazard D theta,
not each coefficient, that must be nonnegative.  Chain hazards are their sums.
"""

from __future__ import annotations

import math

import numpy as np
from scipy.linalg import null_space
from scipy.optimize import brentq, linprog, minimize, nnls
from scipy.stats import chi2


def _chain_design(design, chain_index, count):
    matrix = np.zeros((count, design.shape[1]))
    np.add.at(matrix, chain_index, design)
    return matrix


def _loss(hazards, n, k):
    positive = k > 0
    if np.any(hazards[positive] <= 0):
        return math.inf, np.full_like(hazards, math.nan)
    loss = float((n - k) @ hazards)
    slope = (n - k).copy()
    selected = hazards[positive]
    failure = -np.expm1(-selected)
    loss -= float(k[positive] @ np.log(failure))
    slope[positive] -= k[positive] * np.exp(-selected) / failure
    return loss, slope


def linear_hazard_evaluate(design, chain_index, n, k, theta):
    """Return NLL, its gradient, chain probabilities and chain hazard design."""
    design, theta = np.asarray(design, dtype=float), np.asarray(theta, dtype=float)
    n, k = np.asarray(n, dtype=float), np.asarray(k, dtype=float)
    derivative = _chain_design(design, np.asarray(chain_index, dtype=int), len(n))
    instance_hazard = design @ theta
    hazards = derivative @ theta
    if (not np.all(np.isfinite(instance_hazard)) or
            np.min(instance_hazard, initial=0.) < -1e-9):
        return math.inf, np.full(len(theta), math.nan), np.full(len(n), math.nan), derivative
    # Only remove floating-point roundoff at a fitted domain boundary.  A new
    # prediction/reference outside the domain must be withheld by the caller.
    hazards = np.maximum(hazards, 0.)
    loss, slope = _loss(hazards, n, k)
    return loss, derivative.T @ slope, -np.expm1(-hazards), derivative


def linear_hazard_has_finite_mle(design, derivative, n, k, contrast=None):
    """Detect a recession direction that improves all-Fail chains forever."""
    all_fail = (k == n) & (k > 0)
    if not np.any(all_fail):
        return True
    equality = derivative[n > k]
    if contrast is not None:
        equality = np.vstack([equality, contrast[0]])
    objective = -derivative[all_fail].sum(axis=0)
    fit = linprog(objective, A_ub=-design, b_ub=np.zeros(len(design)),
                  A_eq=equality if len(equality) else None,
                  b_eq=np.zeros(len(equality)) if len(equality) else None,
                  bounds=[(-1., 1.)] * design.shape[1], method="highs")
    if not fit.success:
        raise RuntimeError("Could not determine whether a finite hazard maximum likelihood estimate exists.")
    return bool(-fit.fun <= 1e-9 * max(np.linalg.norm(objective, ord=1), 1.))


def _equality(contrast, width):
    if contrast is None:
        return np.empty((0, width)), np.empty(0)
    vector, value = contrast
    vector = np.asarray(vector, dtype=float)
    if vector.shape != (width,) or not np.all(np.isfinite(vector)) or not math.isfinite(value):
        raise ValueError("A hazard contrast requires a finite vector and value.")
    scale = max(float(np.linalg.norm(vector)), 1.)
    return vector[None, :] / scale, np.array([value / scale])


def _kkt_residual(design, theta, gradient, equality, target, transform):
    """Check feasibility and stationarity in the cone of active constraints."""
    hazards = design @ theta
    if (not np.all(np.isfinite(gradient)) or np.min(hazards, initial=0.) < -1e-9 or
            np.max(np.abs(equality @ theta - target), initial=0.) > 1e-9):
        return math.inf
    active = design[hazards <= 1e-9]
    # Normalize orthogonal likelihood directions by their own exposure. This
    # also catches weak contrasts of two heavily exposed coefficients.
    scaled_equality = equality @ transform
    if len(scaled_equality):
        scaled_equality /= np.maximum(np.linalg.norm(scaled_equality, axis=1), 1e-300)[:, None]
    basis = null_space(scaled_equality) if len(equality) else np.eye(len(theta))
    projected_gradient = basis.T @ (transform.T @ gradient)
    if not len(projected_gradient):
        return 0.
    if len(active):
        # For D theta >= 0: gradient = D_active.T lambda + E.T nu,
        # lambda >= 0.  Equality multipliers are removed by projection.
        scaled_active = active @ transform
        scaled_active /= np.maximum(np.linalg.norm(scaled_active, axis=1), 1e-300)[:, None]
        matrix = basis.T @ scaled_active.T
        try:
            multipliers, _ = nnls(matrix, projected_gradient, maxiter=max(1000, 10 * len(active)))
        except (RuntimeError, ValueError):
            return math.inf
        projected_gradient = projected_gradient - matrix @ multipliers
    return float(np.max(np.abs(projected_gradient), initial=0.))


def fit_linear_hazard(design, chain_index, n, k, start=None, contrast=None):
    """Fit a convex hazard model, optionally holding one linear contrast fixed.

    ``converged`` requires primal feasibility, nonnegative KKT multipliers and
    stationarity per likelihood-direction exposure below 1e-8. An infinite profile loss at an
    infeasible contrast is a valid likelihood endpoint.  A model with an
    improving recession direction has no finite MLE and never reports success.
    """
    design = np.asarray(design, dtype=float)
    chain_index = np.asarray(chain_index, dtype=int)
    n, k = np.asarray(n, dtype=float), np.asarray(k, dtype=float)
    width = design.shape[1]
    derivative = _chain_design(design, chain_index, len(n))
    # Weighted design directions reveal both low-exposure individual parameters
    # and contrasts mostly absent from the large chains. Scaling only the raw
    # columns would still falsely accept, e.g., [A+B] with 1e12 tests and [A]
    # with 100 tests while fitting A incorrectly.
    _, _, rotation_t = np.linalg.svd(np.sqrt(n)[:, None] * derivative,
                                      full_matrices=len(n) < width)
    rotation = rotation_t.T
    exposure = np.maximum(np.abs(derivative @ rotation).T @ n, 1.)
    stationarity_transform = rotation / exposure[None, :]
    newton_transform = rotation / np.sqrt(exposure)[None, :]
    # Repeated instance rows do not change the feasible domain.
    domain = np.unique(design, axis=0)
    row_scale = np.maximum(np.linalg.norm(domain, axis=1), 1.)
    domain = domain / row_scale[:, None]
    equality, target = _equality(contrast, width)
    eq_args = {"A_eq": equality if len(equality) else None,
               "b_eq": target if len(equality) else None}
    empty = np.zeros(width)
    if not np.any(k):
        # All-pass is an exact linear program, including a profiled contrast.
        fit = linprog((n - k) @ derivative, A_ub=-domain, b_ub=np.zeros(len(domain)),
                      bounds=[(None, None)] * width, method="highs", **eq_args)
        if fit.status == 2:
            return math.inf, empty, np.zeros(len(n)), True, derivative
        if not fit.success:
            return math.inf, empty, np.zeros(len(n)), False, derivative
        loss, gradient, predicted, _ = linear_hazard_evaluate(design, chain_index, n, k, fit.x)
        converged = math.isfinite(loss) and _kkt_residual(domain, fit.x, gradient, equality, target, stationarity_transform) < 1e-8
        return loss, fit.x, predicted, converged, derivative

    # Find a feasible point with positive probability for every observed Fail.
    # Maximizing a capped common margin also distinguishes impossible p=0
    # profile endpoints from a numerical optimizer failure.
    positive = derivative[k > 0]
    constraints = np.vstack([np.column_stack([-domain, np.zeros(len(domain))]),
                             np.column_stack([-positive, np.ones(len(positive))])])
    feasible = linprog(np.r_[np.zeros(width), -1.], A_ub=constraints,
                       b_ub=np.zeros(len(constraints)),
                       A_eq=np.column_stack([equality, np.zeros(len(equality))]) if len(equality) else None,
                       b_eq=target if len(equality) else None,
                       bounds=[(None, None)] * width + [(0., 1.)], method="highs")
    if feasible.status == 2 or (feasible.success and feasible.x[-1] <= 1e-12):
        return math.inf, empty, np.zeros(len(n)), True, derivative
    if not feasible.success:
        return math.inf, empty, np.zeros(len(n)), False, derivative
    initial = feasible.x[:-1]
    constraints = [{"type": "ineq", "fun": lambda theta: domain @ theta,
                    "jac": lambda theta: domain}]
    if len(equality):
        constraints.append({"type": "eq", "fun": lambda theta: equality @ theta - target,
                            "jac": lambda theta: equality})
    if start is not None:
        candidate = np.asarray(start, dtype=float)
        if candidate.shape == (width,) and np.all(np.isfinite(candidate)):
            candidate = candidate.copy()
            if len(equality):
                candidate += equality.T @ np.linalg.lstsq(
                    equality @ equality.T, target - equality @ candidate, rcond=None)[0]
            if np.min(domain @ candidate, initial=0.) < -1e-10:
                # Preserve a profile's warm start by projecting it to the
                # requested feasible slice. The generic phase-I LP can lie far
                # from the small hazards typical of these layouts.
                anchor = np.asarray(start, dtype=float)
                projection = minimize(lambda value: (.5 * float((value - anchor) @ (value - anchor)), value - anchor),
                                      candidate, jac=True, method="SLSQP", constraints=constraints,
                                      options={"ftol": 1e-15, "maxiter": 500})
                candidate = projection.x
            if (np.min(domain @ candidate, initial=0.) >= -1e-10 and
                    np.max(np.abs(equality @ candidate - target), initial=0.) <= 1e-10):
                # Move just inside any zero-Fail-probability boundary while
                # preserving all linear constraints and the fixed contrast.
                initial = (candidate if np.min(positive @ candidate) > 1e-12 else
                           (1 - 1e-5) * candidate + 1e-5 * initial)
    scale = max(float(n.sum()), 1.)

    def objective(theta):
        hazards = derivative @ theta
        loss, slope = _loss(hazards, n, k)
        if not math.isfinite(loss):
            # SLSQP may test an infeasible step.  A finite gradient from an
            # interior point guides its line search back into the domain.
            _, slope = _loss(np.maximum(hazards, 1e-12), n, k)
        return loss / scale, derivative.T @ slope / scale

    fit = minimize(objective, initial, jac=True, method="SLSQP", constraints=constraints,
                   options={"ftol": 1e-15, "maxiter": 1500})
    theta = fit.x
    # A Newton correction on the active face resolves objective-roundoff stops
    # without relaxing the independent KKT test.
    for _ in range(25):
        loss, gradient = objective(theta)
        if not math.isfinite(loss):
            break
        if _kkt_residual(domain, theta, gradient * scale, equality, target, stationarity_transform) < 1e-8:
            break
        hazards = derivative @ theta
        active = domain[domain @ theta <= 1e-9]
        face = np.vstack([equality, active]) @ newton_transform
        if len(face):
            face /= np.maximum(np.linalg.norm(face, axis=1), 1e-300)[:, None]
        basis = newton_transform @ (null_space(face) if len(face) else np.eye(width))
        if not basis.shape[1]:
            break
        weight = np.zeros(len(n))
        pos = k > 0
        failure = -np.expm1(-hazards[pos])
        weight[pos] = k[pos] * np.exp(-hazards[pos]) / failure ** 2 / scale
        hessian = derivative.T @ (weight[:, None] * derivative)
        reduced = basis.T @ hessian @ basis
        direction = -basis @ np.linalg.lstsq(reduced, basis.T @ gradient, rcond=None)[0]
        if not np.all(np.isfinite(direction)) or gradient @ direction >= 0:
            break
        dh = domain @ direction
        negative = dh < -1e-14
        step = min(1., float(np.min(-(domain @ theta)[negative] / dh[negative]))) if np.any(negative) else 1.
        if step <= 0:
            break
        for _ in range(45):
            candidate = theta + step * direction
            candidate_loss, _ = objective(candidate)
            if math.isfinite(candidate_loss) and candidate_loss <= loss + 8 * np.finfo(float).eps * max(abs(loss), 1.):
                theta = candidate
                break
            step *= .5
        else:
            break
    loss, gradient, predicted, _ = linear_hazard_evaluate(design, chain_index, n, k, theta)
    if not math.isfinite(loss):
        # Preserve a finite diagnostic candidate on numerical failure; callers
        # can freeze the fit without serializing NaN coefficients/probabilities.
        theta = initial.copy()
        loss, gradient, predicted, _ = linear_hazard_evaluate(design, chain_index, n, k, theta)
    converged = (math.isfinite(loss) and
                 _kkt_residual(domain, theta, gradient, equality, target, stationarity_transform) < 1e-8 and
                 linear_hazard_has_finite_mle(domain, derivative, n, k, contrast))
    return loss, theta, predicted, converged, derivative


def linear_hazard_profile_interval(design, chain_index, n, k, theta, contrast,
                                   minimum, confidence):
    """Profile a nonnegative reference hazard and transform endpoints to p."""
    contrast = np.asarray(contrast, dtype=float)
    estimate = float(contrast @ theta)
    if estimate < -1e-9:
        raise ValueError("Reference environment is outside the nonnegative hazard domain.")
    estimate = max(estimate, 0.)
    threshold = minimum + float(chi2.ppf(confidence, 1)) / 2
    cache = {estimate: minimum - threshold}

    def root(value):
        if value not in cache:
            loss, _, _, converged, _ = fit_linear_hazard(
                design, chain_index, n, k, start=theta, contrast=(contrast, value))
            if not converged:
                raise RuntimeError("Profile nuisance optimization did not converge to a finite hazard fit.")
            if loss < minimum - max(1e-5, abs(minimum) * 32 * np.finfo(float).eps):
                raise RuntimeError("Profile likelihood is below the fitted minimum.")
            cache[value] = loss - threshold
        return cache[value]

    low = 0. if root(0.) <= 0 else brentq(root, 0., estimate, xtol=1e-10)
    upper = max(estimate + .05, estimate * 2, .1)
    # h=40 already rounds to p=1; an interval still open there reaches 1 at
    # the probability precision exported by the application.
    while upper < 40. and root(upper) <= 0:
        upper = min(40., upper * 2)
    high = math.inf if root(upper) <= 0 else brentq(root, estimate, upper, xtol=1e-10)
    return -math.expm1(-low), -math.expm1(-high)


def linear_hazard_contrast_identifiable(design, derivative, n, k, theta, vector):
    """Whether a linear contrast is constant across the likelihood's flat set."""
    dependence = np.vstack([derivative[k > 0], (n - k) @ derivative])
    selected = np.max(np.abs(dependence), axis=1) > 0
    equality = dependence[selected]
    if len(equality):
        equality = equality / np.max(np.abs(equality), axis=1)[:, None]
    target = equality @ theta
    arguments = dict(A_ub=-design, b_ub=np.zeros(len(design)),
                     A_eq=equality if len(equality) else None,
                     b_eq=target if len(equality) else None,
                     bounds=[(None, None)] * len(theta), method="highs")
    low, high = linprog(vector, **arguments), linprog(-np.asarray(vector), **arguments)
    return bool(low.success and high.success and -high.fun - low.fun <= 1e-7)


def linear_hazard_identifiable(design, derivative, n, k, theta, structural):
    """Remove coefficients varying across the realized likelihood's flat set."""
    identified = np.asarray(structural, dtype=bool).copy()
    for index in np.flatnonzero(identified):
        vector = np.eye(len(theta))[index]
        identified[index] = linear_hazard_contrast_identifiable(design, derivative, n, k, theta, vector)
    return identified
