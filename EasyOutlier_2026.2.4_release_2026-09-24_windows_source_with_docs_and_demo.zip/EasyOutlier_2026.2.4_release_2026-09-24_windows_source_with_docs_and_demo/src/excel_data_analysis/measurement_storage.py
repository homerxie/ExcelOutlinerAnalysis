"""Versioned, lossless row storage using only Python's standard library.

Each batch stores its source once, interns complete test definitions, and writes
one row with ordered (test ID, value) pairs. Pairs preserve sparse columns and
duplicate measurements. Consecutive gzip members allow imports to be appended
without rebuilding or recompressing the existing database.
"""
from __future__ import annotations

from collections import Counter
from contextlib import closing
from dataclasses import replace
import gzip
import io
from itertools import groupby
import json
import os
from pathlib import Path
import shutil
import tempfile
from typing import Any, Callable, Iterable, Iterator, TextIO

from .models import MeasurementRecord
from .database_paths import database_root_for_storage, pack_source_path, restore_source_path


LEGACY_MEASUREMENTS_FILENAME = "measurements.jsonl"
COMPRESSED_MEASUREMENTS_FILENAME = "measurements.jsonl.gz"
MEASUREMENT_FILENAMES = (LEGACY_MEASUREMENTS_FILENAME, COMPRESSED_MEASUREMENTS_FILENAME)
FORMAT_NAME = "easy-outlier-measurements"
FORMAT_VERSION = 2
TEST_FIELDS = (
    "logical_metric", "group_id", "group_display_name", "presentation_group", "raw_column",
)


def _write_line(handle: TextIO, payload: dict[str, Any]) -> None:
    handle.write(json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n")


def _write_records(handle: TextIO, records: Iterable[MeasurementRecord], database_root: Path) -> None:
    _write_line(handle, {"type": "format", "format": FORMAT_NAME, "version": FORMAT_VERSION})
    # Keep original order, even for interleaved batches or repeated row numbers.
    for (dataset_id, source_file), batch in groupby(
        records, key=lambda item: (item.dataset_id, item.source_file)
    ):
        _write_line(handle, {"type": "batch", "dataset_id": dataset_id,
                             **pack_source_path(source_file, database_root)})
        tests: dict[tuple, int] = {}
        for (row_number, dimensions), row in groupby(
            batch, key=lambda item: (item.row_number, item.dimensions)
        ):
            values = []
            for item in row:
                test = tuple(getattr(item, field) for field in TEST_FIELDS)
                if test not in tests:
                    tests[test] = len(tests)
                    _write_line(handle, {
                        "type": "test", "id": tests[test], **dict(zip(TEST_FIELDS, test)),
                    })
                values.append([tests[test], item.value])
            _write_line(handle, {
                "type": "row", "row_number": row_number, "dimensions": dimensions, "values": values,
            })


def _iter_rows(path: Path) -> Iterator[tuple[str, str, list[dict], dict]]:
    database_root = database_root_for_storage(path.parent)
    seen_format = False
    batch = None
    tests: list[dict] = []
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                entry = json.loads(line)
                kind = entry["type"]
                if kind == "format":
                    if entry["format"] != FORMAT_NAME or entry["version"] not in (1, FORMAT_VERSION):
                        raise ValueError("Unsupported measurement storage format/version")
                    seen_format = True
                    batch = None
                    tests = []
                elif not seen_format:
                    raise ValueError("Missing measurement storage format header")
                elif kind == "batch":
                    batch = (entry["dataset_id"], restore_source_path(entry, database_root))
                    tests = []
                elif batch is None:
                    raise ValueError("Missing measurement batch header")
                elif kind == "test":
                    if type(entry["id"]) is not int or entry["id"] != len(tests):
                        raise ValueError("Invalid test definition ID")
                    tests.append({field: entry[field] for field in TEST_FIELDS})
                elif kind == "row":
                    if not isinstance(entry["dimensions"], dict) or type(entry["row_number"]) is not int:
                        raise ValueError("Invalid measurement row")
                    for test_id, value in entry["values"]:
                        if type(test_id) is not int or not 0 <= test_id < len(tests):
                            raise ValueError("Unknown measurement test ID")
                        if type(value) not in (int, float):
                            raise ValueError("Invalid measurement value")
                    yield batch[0], batch[1], tests, entry
                else:
                    raise ValueError(f"Unknown measurement entry type: {kind}")
            except (KeyError, TypeError, ValueError) as exc:
                raise ValueError(f"Invalid measurement storage {path.name}, line {line_number}: {exc}") from exc
    if not seen_format:
        raise ValueError(f"Missing measurement storage format header: {path}")


class MeasurementStorage:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.path = self.root / COMPRESSED_MEASUREMENTS_FILENAME
        self.legacy_path = self.root / LEGACY_MEASUREMENTS_FILENAME

    def iter_records(self) -> Iterator[MeasurementRecord]:
        # A completed compressed file is authoritative if old-file cleanup was
        # interrupted. Never combine both and accidentally duplicate records.
        if self.path.exists():
            for dataset_id, source_file, tests, row in _iter_rows(self.path):
                for test_id, value in row["values"]:
                    yield MeasurementRecord(
                        dataset_id=dataset_id, source_file=source_file,
                        row_number=row["row_number"], dimensions=dict(row["dimensions"]),
                        value=value, **tests[test_id],
                    )
        elif self.legacy_path.exists():
            with self.legacy_path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    if line.strip():
                        yield MeasurementRecord.from_dict(json.loads(line))

    def counts(self) -> dict[str, int]:
        counts: Counter[str] = Counter()
        if self.path.exists():
            for dataset_id, _, _, row in _iter_rows(self.path):
                counts[dataset_id] += len(row["values"])
        else:
            for item in self.iter_records():
                counts[item.dataset_id] += 1
        return dict(counts)

    def has_records(self) -> bool:
        with closing(self.iter_records()) as records:
            return next(records, None) is not None

    def write(self, records: Iterable[MeasurementRecord], *, append: bool = False) -> None:
        database_root = database_root_for_storage(self.root)

        def write_content(handle):
            if append and not self.path.exists() and self.legacy_path.exists():
                _write_records(handle, self.iter_records(), database_root)
            _write_records(handle, records, database_root)

        self._write_stream(write_content, append=append)

    def _write_stream(self, write_content: Callable[[TextIO], None], *, append=False) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        temporary_path = None
        try:
            with tempfile.NamedTemporaryFile(dir=self.root, prefix=".measurements-", suffix=".tmp", delete=False) as raw:
                temporary_path = Path(raw.name)
                if append and self.path.exists():
                    with self.path.open("rb") as existing:
                        shutil.copyfileobj(existing, raw)
                # Suppress filename and timestamp: identical data produces
                # identical bytes, including after Save As / workspace copying.
                with gzip.GzipFile(filename="", mode="wb", fileobj=raw, compresslevel=6, mtime=0) as compressed:
                    with io.TextIOWrapper(compressed, encoding="utf-8", newline="\n") as handle:
                        write_content(handle)
                raw.flush()
                os.fsync(raw.fileno())
            # Verify schema, references and every gzip member's checksum/trailer
            # before publishing, without allocating all measurement objects.
            for _ in _iter_rows(temporary_path):
                pass
            os.replace(temporary_path, self.path)
        finally:
            if temporary_path is not None:
                temporary_path.unlink(missing_ok=True)
        self.legacy_path.unlink(missing_ok=True)

    def copy_to(self, destination: MeasurementStorage, source_path_map: Callable[[str], str]) -> None:
        """Rebase only batch metadata when saving a copy, without expanding rows."""
        if not self.path.exists():
            if self.legacy_path.exists():
                destination.write(replace(item, source_file=source_path_map(item.source_file))
                                  for item in self.iter_records())
            return
        original_root = database_root_for_storage(self.root)
        target_root = database_root_for_storage(destination.root)

        def write_content(handle):
            with gzip.open(self.path, "rt", encoding="utf-8") as source:
                for line in source:
                    if not line.strip():
                        continue
                    entry = json.loads(line)
                    if entry.get("type") == "format":
                        if entry.get("format") != FORMAT_NAME or entry.get("version") not in (1, FORMAT_VERSION):
                            raise ValueError("Unsupported measurement storage format/version")
                        entry["version"] = FORMAT_VERSION
                        _write_line(handle, entry)
                    elif entry.get("type") == "batch":
                        source_file = source_path_map(restore_source_path(entry, original_root))
                        entry.pop("source_path_base", None)
                        entry.update(pack_source_path(source_file, target_root))
                        _write_line(handle, entry)
                    else:
                        handle.write(line)

        destination._write_stream(write_content)

    def compact(self) -> None:
        """Migrate legacy JSONL / v1 gzip on save; opening remains read-only."""
        if self.path.exists():
            with gzip.open(self.path, "rt", encoding="utf-8") as handle:
                header = json.loads(next(line for line in handle if line.strip()))
            if header.get("version") == 1:
                self.write(self.iter_records())
        if self.legacy_path.exists():
            if not self.path.exists():
                self.write(self.iter_records())
            else:
                self.counts()  # Verify the authoritative file before cleanup.
                self.legacy_path.unlink()
