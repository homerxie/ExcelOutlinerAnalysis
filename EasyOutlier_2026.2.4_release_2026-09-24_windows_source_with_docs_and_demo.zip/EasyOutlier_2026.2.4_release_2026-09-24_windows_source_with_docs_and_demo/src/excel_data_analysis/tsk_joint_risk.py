"""Observed, structurally certified joint TSK risks.

An atom is one *complete* observed instance design row.  If C counts those
atoms in each chain, C.T @ a == g certifies the package hazard g.T @ h from
chain hazards, independently of an arbitrary split of model coefficients.
Intervals use binomial chain evidence, not independent component errors or a
Gaussian approximation at a boundary.  Reported intervals are pointwise.
"""

from __future__ import annotations

import math
from functools import reduce
from typing import Any, Callable, Mapping

import numpy as np
from scipy.optimize import linprog
from scipy.stats import beta


# This supplemental report must not introduce an unbounded dense decomposition
# for layouts containing thousands of distinct numeric coordinates.
MAX_ATOMS = 256
MAX_CHAINS = 1024
MAX_MATRIX_CELLS = 131072
MAX_DESIGN_WIDTH = 128
MAX_INSTANCES = 50000
MAX_DESIGN_CELLS = 1000000
MAX_CANDIDATES = 400
MAX_BOUNDARY_IDENTIFICATION_QUERIES = 64
MAX_REALIZED_FIT_QUERIES = 100

CHAIN_INTERVAL_METHOD = "conservative_binomial_chain_bounds"
EXACT_INTERVAL_METHOD = "exact_binomial_complete_package"
ZERO_INTERVAL_METHOD = "exact_one_sided_zero_failure_package_upper_bound"
CONSERVATIVE_ZERO_INTERVAL_METHOD = "conservative_one_sided_zero_failure_package_upper_bound"


def _plain(value):
    if isinstance(value, Mapping):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, (tuple, list, np.ndarray)):
        return [_plain(item) for item in value]
    if isinstance(value, np.generic):
        return _plain(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _basis(matrix):
    if not matrix.size:
        return np.zeros((matrix.shape[1], 0))
    _, singular, right = np.linalg.svd(matrix, full_matrices=False)
    tolerance = max(matrix.shape) * np.finfo(float).eps * singular[0] * 100
    return right[singular > tolerance].T


def _in_space(vector, basis):
    return bool(np.linalg.norm(vector - basis @ (basis.T @ vector))
                <= 1e-8 * max(1., float(np.linalg.norm(vector))))


def _primitive(values):
    positive = [int(value) for value in values if value]
    divisor = reduce(math.gcd, positive) if positive else 1
    return tuple(int(value) // divisor for value in values)


def _copies(counts, package):
    included = package > 0
    return np.min(counts[:, included] // package[included], axis=1)


def _certificate(counts, package, n, chain_ids, inverse, rank):
    """Prefer complete matching chains; selection never looks at Fail counts."""
    copies = _copies(counts, package)
    complete = (copies > 0) & np.all(counts == copies[:, None] * package, axis=1)
    selected = np.flatnonzero(complete)
    weights = np.zeros(len(counts))
    exact = None
    if selected.size:
        # A common copy count gives a common chain probability, so those
        # binomial observations can be pooled exactly. Choose by tested data
        # and topology, never by outcomes or the resulting interval width.
        multiples = sorted(set(int(copies[index]) for index in selected))
        multiple = max(multiples, key=lambda value: (float(n[complete & (copies == value)].sum()), -value))
        selected = np.flatnonzero(complete & (copies == multiple))
        weights[selected] = n[selected] / n[selected].sum() / multiple
        exact = (selected, multiple)
        method = "complete_matching_chains"
    else:
        weights = inverse @ package
        weights[np.abs(weights) < 1e-12] = 0.
        method = "chain_count_row_space"
    residual = float(np.linalg.norm(counts.T @ weights - package))
    tolerance = 1e-8 * max(1., float(np.linalg.norm(package)))
    if residual > tolerance:
        return None, None, copies
    certificate = {
        "method": method, "atom_counts": [
            {"atom_id": int(index) + 1, "count": int(package[index])}
            for index in np.flatnonzero(package)],
        "chain_weights": [{"chain_id": str(chain_ids[index]), "weight": float(weights[index])}
                          for index in np.flatnonzero(weights)],
        "residual_norm": residual, "tolerance": tolerance, "rank": int(rank),
        "interval_scope": "pointwise", "uses_failure_outcomes": False,
    }
    return (certificate, weights), exact, copies


def _cp(n, k, confidence):
    alpha = 1. - confidence
    lower = 0. if k == 0 else float(beta.ppf(alpha / 2., k, n - k + 1.))
    upper = 1. if k == n else float(beta.ppf(1. - alpha / 2., k + 1., n - k))
    return lower, upper


def _hazard(probability):
    return math.inf if probability >= 1. else -math.log1p(-probability)


def _probability(hazard):
    return -math.expm1(-max(0., hazard))


def _interval(counts, package, n, k, confidence, weights, exact, copies):
    support = copies > 0  # Chosen from the full topology before inspecting k.
    exposure = float(n @ copies)
    if np.any(support) and np.all(k[support] == 0):
        complete = np.all(counts[support] == copies[support, None] * package)
        upper = -math.expm1(math.log1p(-confidence) / exposure)
        method = ZERO_INTERVAL_METHOD if complete else CONSERVATIVE_ZERO_INTERVAL_METHOD
        return 0., upper, method, "upper", None
    if exact is not None:
        selected, multiple = exact
        low, high = _cp(float(n[selected].sum()), float(k[selected].sum()), confidence)
        return (_probability(_hazard(low) / multiple), _probability(_hazard(high) / multiple),
                EXACT_INTERVAL_METHOD, "two_sided", None)
    active = np.flatnonzero(weights)
    per_chain_confidence = 1. - (1. - confidence) / len(active)
    lower, upper = 0., 0.
    for index in active:
        low, high = _cp(float(n[index]), float(k[index]), per_chain_confidence)
        lo_h, hi_h = _hazard(low), _hazard(high)
        weight = float(weights[index])
        if weight > 0:
            lower += weight * lo_h
            upper += weight * hi_h
        else:
            lower += weight * hi_h
            upper += weight * lo_h
    if math.isnan(lower) or math.isnan(upper):
        return None, None, None, None, "链置信界组合出现非有限差值，无法可靠计算区间。"
    if upper < 0:
        return None, None, None, None, "链的联合置信界与该包的非负风险约束不相容。"
    return (_probability(lower), _probability(upper), CHAIN_INTERVAL_METHOD,
            "two_sided", None)


def _parameter_names(context):
    names = [f"TSK {value}" for value in context["type_ids"]]
    names.extend(str(name) if level is None else f"{name}={level}"
                 for name, level in context.get("coefficient_columns", []))
    return names


class _RealizedFitCheck:
    """Conservative uniqueness in the relaxed nonnegative atom-hazard model.

    Positive-Fail chains have strictly convex loss in their chain hazard;
    zero-Fail chains contribute only their total weighted linear hazard.
    Equal-likelihood minimizers must preserve both. The feasible tangent cone
    of this linear, convex set determines whether a package can change.
    Model feature restrictions could identify more; this check never claims
    that an atom-space ambiguity proves nonidentifiability in every submodel.
    """

    def __init__(self, counts, n, k, hazards):
        self.counts, self.n, self.k, self.hazards = counts, n, k, hazards
        self.queries = 0
        self.finite = np.all(np.isfinite(hazards))
        if self.finite:
            dependence = np.vstack((counts[k > 0], (n - k) @ counts))
            nonzero = np.max(np.abs(dependence), axis=1) > 0
            dependence = dependence[nonzero]
            dependence = dependence / np.max(np.abs(dependence), axis=1)[:, None]
            self.basis = _basis(dependence)
            self.column_scale = (np.max(np.abs(dependence), axis=0) if len(dependence)
                                 else np.ones(counts.shape[1]))
            self.column_scale[self.column_scale == 0] = 1.
            self.equality = dependence / self.column_scale
        else:
            self.eligible = counts.T @ (n - k) == 0
            saturated = np.any(counts[:, self.eligible] > 0, axis=1)
            self.finite_checker = (_RealizedFitCheck(
                counts[~saturated][:, ~self.eligible], n[~saturated], k[~saturated], hazards[~self.eligible])
                if np.any(~self.eligible) else None)

    def check(self, package):
        detail = {"method": "relaxed_nonnegative_atom_hazard_likelihood", "passed": False}
        if not self.finite:
            # A saturated package is forced when an all-Fail chain has no
            # possible infinite-hazard atom outside it. Finite atoms cannot
            # provide the exact saturation. Other infinite cases are withheld.
            within = self.eligible & (package > 0)
            outside = self.eligible & (package == 0)
            forced = np.any((self.k == self.n) & np.any(self.counts[:, within] > 0, axis=1)
                            & ~np.any(self.counts[:, outside] > 0, axis=1))
            if np.any(within) and forced:
                detail.update(passed=True, method="forced_saturated_package")
                return True, detail
            if not np.any(within) and self.finite_checker is not None:
                return self.finite_checker.check(package[~self.eligible])
            detail["reason"] = "unverified_infinite_atom_allocation"
            return False, detail
        if _in_space(package, self.basis):
            detail.update(passed=True, method="realized_likelihood_row_space")
            return True, detail
        if self.queries >= MAX_REALIZED_FIT_QUERIES:
            detail["reason"] = "realized_fit_check_limit"
            return False, detail
        self.queries += 1
        objective = package / self.column_scale
        objective /= np.linalg.norm(objective)
        bounds = [(0., 1.) if hazard == 0 else (-1., 1.) for hazard in self.hazards]
        # These coordinates measure directions, not parameter magnitudes. Even
        # an arbitrarily small positive hazard admits both local directions;
        # tiny risks therefore cannot disappear into LP feasibility tolerance.
        low = linprog(objective, A_eq=self.equality, b_eq=np.zeros(len(self.equality)),
                      bounds=bounds, method="highs")
        high = linprog(-objective, A_eq=self.equality, b_eq=np.zeros(len(self.equality)),
                       bounds=bounds, method="highs")
        passed = bool(low.success and high.success and max(abs(low.fun), abs(high.fun)) <= 1e-8)
        detail.update(passed=passed, method="realized_likelihood_nonnegative_cone",
                      reason=None if passed else "equivalent_atom_hazard_allocation")
        return passed, detail


def _member(context, vector, count, atom_id):
    type_count = len(context["type_ids"])
    tsk_id = str(context["type_ids"][int(np.argmax(vector[:type_count]))])
    categories = {str(name): encoding.get("reference")
                  for name, encoding in context.get("categorical_features", {}).items()}
    numeric = {}
    for offset, (name, level) in enumerate(context.get("coefficient_columns", []), type_count):
        if level is not None:
            if vector[offset] != 0:
                categories[str(name)] = level
        else:
            scaling = context.get("numeric_scaling", {}).get(name, {})
            reference = context.get("numeric_reference", {}).get(name, 0.)
            mean, scale = scaling.get("mean", reference), scaling.get("scale", 1.)
            numeric[str(name)] = float(vector[offset] * scale + mean)
    details = [f"{key}={value}" for key, value in categories.items()]
    details.extend(f"{key}={value:g}" for key, value in numeric.items())
    label = f"TSK {tsk_id}" + (" [" + ", ".join(details) + "]" if details else "")
    return {"atom_id": atom_id, "tsk_id": tsk_id, "count": int(count), "categories": categories,
            "numeric": numeric, "label": label}


def build_joint_risk_report(
    context: Mapping[str, Any] | None, diagnostics: Mapping[str, Any] | None = None, *,
    max_groups: int = 100, progress_callback: Callable[[int, str], None] | None = None,
) -> dict[str, Any]:
    """Return bounded, JSON-safe supplemental results for observed packages.

    Parameter aliases help select useful rows, but do not establish package
    identifiability: every published row has a count-matrix certificate.
    Confidence bounds are pointwise and their certificates depend on topology
    and tested counts only. No profile optimization is used for intervals.
    """
    report = {"version": 1, "status": "no_data", "rows": [], "notes": [], "omitted_count": 0}
    if not context or not len(context.get("n_tested", [])) or not len(context.get("design", [])):
        report["notes"].append("没有有效 Chain 观测，无法计算联合风险。")
        return report
    diagnostics = diagnostics or {}
    progress = progress_callback or (lambda value, message: None)
    try:
        design = np.asarray(context["design"], dtype=float)
        chain = np.asarray(context["chain_index"], dtype=int)
        n = np.asarray(context["n_tested"], dtype=float)
        k = np.asarray(context["n_failed"], dtype=float)
        theta = np.asarray(context["coefficients"], dtype=float)
        type_count = len(context["type_ids"])
        chain_ids = list(context["chain_ids"])
        confidence = float(context.get("confidence_level", .95))
        model = context["model"]
        valid = (design.ndim == 2 and design.shape[1] == len(theta) and type_count > 0
                 and len(theta) == type_count + len(context.get("coefficient_columns", []))
                 and chain.shape == (len(design),) and n.shape == k.shape and n.ndim == 1
                 and len(chain_ids) == len(n) and np.all(chain >= 0) and np.all(chain < len(n))
                 and np.all(n > 0) and np.all(k >= 0) and np.all(k <= n)
                 and np.all(n == np.floor(n)) and np.all(k == np.floor(k))
                 and np.all(np.isfinite(design)) and np.all(np.isfinite(n)) and np.all(np.isfinite(k))
                 and np.all(np.isfinite(theta) | ((model == "type_only") & np.isposinf(theta)))
                 and 0 < confidence < 1 and model in {"type_only", "instance_logistic_features",
                                                                    "instance_linear_hazard_features"}
                 and np.all((design[:, :type_count] == 0) | (design[:, :type_count] == 1))
                 and np.all(design[:, :type_count].sum(axis=1) == 1))
        if not valid:
            raise ValueError("拟合快照的设计、计数或参数无效。")
    except (KeyError, ValueError, TypeError, IndexError) as error:
        report.update(status="invalid_context", notes=[str(error)])
        return report
    if max_groups < 1:
        report.update(status="computation_limited", notes=["联合风险显示上限为 0。"])
        return report
    if (len(n) > MAX_CHAINS or design.shape[1] > MAX_DESIGN_WIDTH
            or len(design) > MAX_INSTANCES or design.size > MAX_DESIGN_CELLS):
        report.update(status="computation_limited", notes=["数据规模超过联合风险计算上限；主分析结果不受影响。"])
        return report

    # Exact equality only: nearby X/Y coordinates must remain different atoms.
    atom_lookup, atoms, atom_index = {}, [], []
    for vector in design:
        key = tuple(vector)
        if key not in atom_lookup:
            atom_lookup[key] = len(atoms)
            atoms.append(vector)
            if len(atoms) > MAX_ATOMS or len(atoms) * len(n) > MAX_MATRIX_CELLS:
                report.update(status="computation_limited", notes=[
                    "不同的实际实例条件过多，已跳过联合风险密集矩阵计算；未合并不同数值条件。"])
                return report
        atom_index.append(atom_lookup[key])
    atoms = np.asarray(atoms)
    counts = np.zeros((len(n), len(atoms)), dtype=np.int64)
    np.add.at(counts, (chain, atom_index), 1)
    if np.any(counts.sum(axis=1) == 0):
        report.update(status="invalid_context", notes=["存在有效观测却没有实际实例的 Chain。"])
        return report
    progress(10, "TSK：验证观测实例包的 Chain 计数证书…")
    # One decomposition serves all candidates and individual atom certificates.
    left, singular, right = np.linalg.svd(counts.astype(float), full_matrices=False)
    tolerance = max(counts.shape) * np.finfo(float).eps * singular[0] * 100
    retained = singular > tolerance
    count_basis = right[retained].T
    inverse = (left[:, retained] / singular[retained]) @ right[retained]
    rank = int(retained.sum())
    atom_identified = np.linalg.norm(np.eye(len(atoms)) - count_basis @ count_basis.T, axis=0) <= 1e-8
    design_basis = _basis(atoms)
    coefficient_identified = np.linalg.norm(np.eye(len(theta)) - design_basis @ design_basis.T, axis=0) <= 1e-8
    aliased = [np.flatnonzero((vector != 0) & ~coefficient_identified).tolist() for vector in atoms]

    candidates, seen = [], set()

    def add_candidate(values, source):
        key = _primitive(values)
        if key in seen or not any(key):
            return
        seen.add(key)
        candidates.append((np.asarray(key, dtype=np.int64), source))

    proportional = {}
    for index in range(len(atoms)):
        proportional.setdefault(_primitive(counts[:, index]), []).append(index)
    for indices in proportional.values():
        if len(indices) < 2:
            continue
        package = np.zeros(len(atoms), dtype=np.int64)
        for index in indices:
            package[index] = reduce(math.gcd, (int(value) for value in counts[:, index] if value))
        add_candidate(package, "proportional_instance_counts")
    # Conditions are single physical instances, not extra instances for each
    # nonzero parameter. α_TSK + β_bump belongs inside that instance's link.
    for index in range(len(atoms)):
        if aliased[index] and atom_identified[index]:
            package = np.zeros(len(atoms), dtype=np.int64)
            package[index] = 1
            add_candidate(package, "aliased_instance_conditions")
    for composition in counts:
        add_candidate(composition, "observed_chain_composition")
    if len(candidates) > MAX_CANDIDATES:
        report["omitted_count"] += len(candidates) - MAX_CANDIDATES
        candidates = candidates[:MAX_CANDIDATES]
        report["notes"].append(f"候选包计算最多检查 {MAX_CANDIDATES} 个；其余候选已省略。")

    boundary = context.get("boundary_fit")
    boundary_valid = (isinstance(boundary, Mapping) and boundary.get("converged")
                      and not boundary.get("feature_clipped"))
    stable = bool(context.get("converged") and diagnostics.get("converged", True)
                  and (not context.get("clipped") or boundary_valid)
                  and (diagnostics.get("finite_mle") is not False or boundary_valid)
                  and (boundary is None or boundary_valid))
    fit = None
    baseline_identified = None
    if stable:
        try:
            if model == "type_only":
                from .tsk_analysis import _BaselineModel
                type_counts = np.zeros((len(n), type_count))
                np.add.at(type_counts, chain, design)
                _, baseline_identified = _BaselineModel(type_counts, n, k).identifiability(theta)
                hazards = np.array([theta[int(np.argmax(vector))] for vector in atoms])
                if np.any(hazards < 0):
                    raise ValueError("基准风险参数违反非负约束。")
            else:
                from .tsk_prediction import _FrozenFit
                fit = _FrozenFit(context)
                if not fit.valid_fit:
                    stable = False
                if fit.boundary_engine is not None:
                    # Probability can round to 1 at a finite log-odds. Retain
                    # finite hazards so the special baseline +inf saturation
                    # logic never mistakes rounding for an infinite MLE.
                    engine = fit.boundary_engine
                    hazards = []
                    for vector in atoms:
                        index = int(np.argmax(vector[:type_count]))
                        value = fit.theta[index]
                        eta = (-math.inf if value == 0 else math.log(value) + math.log(engine.odds_scale[index])
                               + float(vector[type_count:] @ fit.theta[type_count:]))
                        hazards.append(float(np.logaddexp(0., eta)))
                    hazards = np.asarray(hazards)
                elif fit.linear_hazard:
                    hazards = atoms @ theta
                    if np.min(hazards) < -1e-8:
                        raise ValueError("实例风险违反非负约束。")
                    hazards = np.maximum(0., hazards)
                else:
                    hazards = np.logaddexp(0., atoms @ theta)
        except (ValueError, RuntimeError, FloatingPointError, np.linalg.LinAlgError) as error:
            stable = False
            report["notes"].append("主拟合无法通过联合风险快照检查：" + str(error))
    boundary_queries = 0
    individual_cache = {}
    realized_check = _RealizedFitCheck(counts, n, k, hazards) if stable else None

    def individual_identified(index):
        nonlocal boundary_queries
        if index in individual_cache:
            return individual_cache[index]
        if baseline_identified is not None:
            result = bool(baseline_identified[int(np.argmax(atoms[index, :type_count]))])
        elif atom_identified[index]:
            vector = np.zeros(len(atoms))
            vector[index] = 1.
            result = realized_check.check(vector)[0]
        elif fit is not None:
            if fit.boundary_engine is not None:
                if boundary_queries >= MAX_BOUNDARY_IDENTIFICATION_QUERIES:
                    return None
                boundary_queries += 1
            result = bool(fit.identifiable(atoms[index]))
        else:
            result = False
        individual_cache[index] = result
        return result

    names = _parameter_names(context)
    for position, (package, source) in enumerate(candidates):
        included = np.flatnonzero(package)
        progress(15 + int(80 * (position + 1) / max(1, len(candidates))),
                 f"TSK：检查联合风险包 {position + 1}/{len(candidates)}…")
        singleton = int(package.sum()) == 1
        if singleton and not aliased[included[0]]:
            continue
        if stable and not singleton and not any(aliased[index] for index in included):
            individual = [individual_identified(index) for index in included]
            if any(value is None for value in individual):
                report["omitted_count"] += 1
                continue
            if all(individual):
                continue
        certified, exact, copies = _certificate(counts, package, n, chain_ids, inverse, rank)
        if certified is None:
            continue
        certificate, weights = certified
        certificate["candidate_source"] = source
        if len(report["rows"]) >= max_groups:
            report["omitted_count"] += 1
            continue
        members = [_member(context, atoms[index], package[index], int(index) + 1) for index in included]
        label = " + ".join((f"{member['count']} × " if member["count"] != 1 else "") + member["label"]
                           for member in members)
        parameters = sorted(set(index for atom in included for index in np.flatnonzero(atoms[atom])))
        conditions = {key: {name: value for name, value in members[0][key].items()
                            if all(member[key].get(name) == value for member in members)}
                      for key in ("categories", "numeric")}
        formula = ("1 - exp(-sum(count × instance_hazard))" if model != "instance_logistic_features"
                   else "1 - product((1 - logistic(instance_logit)) ** count)")
        if singleton and model == "instance_logistic_features":
            formula = "logistic(TSK coefficient + sum(feature coefficient × feature value))"
        row = {
            "group_id": f"joint_{len(report['rows']) + 1}",
            "kind": "joint_conditions" if singleton else "multiple_instances",
            "label": label, "members": members, "conditions": conditions,
            "parameter_names": [names[index] for index in parameters], "formula": formula,
            "probability": None, "ci_lower": None, "ci_upper": None,
            "confidence_level": confidence, "interval_method": None, "interval_sidedness": None,
            "estimate_kind": None, "status": "fit_not_converged", "identifiable": False,
            "reason": "主拟合未稳定收敛或共享特征触界；联合分组不能恢复失败的拟合。",
            "chain_count": int(np.count_nonzero(weights)), "test_exposure": float(n @ copies),
            "certificate": certificate,
        }
        if stable:
            determined, validation = realized_check.check(package)
            certificate["realized_fit_check"] = validation
            if not determined:
                row.update(status="not_identifiable", reason=(
                    "已达到当前观测似然唯一性检查上限，该候选未发布。"
                    if validation.get("reason") == "realized_fit_check_limit" else
                    "保守校验仍存在等价的原子风险分配，尚未确认整体数值唯一，因此留空；"
                    "该检查放宽了原模型的共享特征约束。"))
                report["rows"].append(row)
                continue
            # Select before multiplying so the valid all-Fail baseline case
            # never performs 0 * infinity on unrelated types.
            hazard = float(package[included] @ hazards[included])
            probability = _probability(hazard)
            low, high, method, sidedness, error = _interval(
                counts, package, n, k, confidence, weights, exact, copies)
            status = "ok" if error is None else "interval_unavailable"
            reason = error or (
                "部分参数无法单独拆分，但该实例在所列条件下的整体概率通过了检查。"
                if singleton else
                "相关参数或成员风险无法全部拆开；按所列配比与条件，整体至少一个失效的概率通过了检查。")
            if low is not None and not low - 1e-10 <= probability <= high + 1e-10:
                status = "model_interval_mismatch"
                reason = "主模型点估计不在观测 Chain 的保守置信界内；请检查模型与数据的一致性。"
            row.update(probability=probability, ci_lower=low, ci_upper=high,
                       interval_method=method, interval_sidedness=sidedness,
                       estimate_kind="boundary_low" if probability == 0 else (
                           "boundary_high" if probability == 1 else "interior"),
                       status=status, reason=reason, identifiable=True)
        report["rows"].append(row)
    if boundary_queries >= MAX_BOUNDARY_IDENTIFICATION_QUERIES and report["omitted_count"]:
        report["notes"].append("已达到边界单体可识别性检查上限；尚未验证的候选未发布。")
    report["status"] = "ok" if stable and report["rows"] else ("no_candidates" if stable else "fit_not_converged")
    report["notes"].extend([
        "仅合并完整设计相同的实际实例；包内数量保留最简整数配比。联合风险表示包内至少一个实例失败。",
        "每一组以 Chain 计数行空间证书验证；置信区间按组逐点覆盖，不保证所有显示组同时覆盖。",
        "区间来自 Chain 二项观测的精确界或 Bonferroni 保守组合；未假定各单体估计独立。",
        "另在非负实例风险空间保守验证当前观测似然的唯一性；共享特征约束可能额外识别的组合也可能暂留空。",
        "Chain 数为证书使用的观测链数；测试暴露为完整匹配包副本数乘各链测试次数。",
    ])
    if report["omitted_count"]:
        report["notes"].append(f"受显示或计算上限影响，已省略 {report['omitted_count']} 个候选包。")
    progress(100, "TSK：联合风险检查完成。")
    return _plain(report)
