"""Bounded, JSON-safe diagnostics for an unchanged TSK optimizer run."""

from __future__ import annotations

from collections import OrderedDict
import math
from time import monotonic

import numpy as np


CONVERGENCE_THRESHOLD = 1e-8
HISTORY_LIMIT = 96


def json_safe(value):
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [json_safe(item) for item in value]
    if isinstance(value, np.ndarray):
        return json_safe(value.tolist())
    if isinstance(value, np.generic):
        return json_safe(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def optimization_metrics(coefficients, nll, gradient, sample_count, lower, upper):
    """Use exactly the engine's projected-gradient rule, retaining raw evidence."""
    values = np.asarray(coefficients, dtype=float)
    raw = np.asarray(gradient, dtype=float)
    projected = raw.copy()
    projected[(values <= lower + 1e-10) & (projected > 0)] = 0
    projected[(values >= upper - 1e-10) & (projected < 0)] = 0
    finite = bool(np.all(np.isfinite(projected)))
    norm = float(np.max(np.abs(projected), initial=0)) if finite else math.nan
    scale = max(float(sample_count), 1.)
    worst = (int(np.argmax(np.abs(projected))) if finite and projected.size else
             int(np.flatnonzero(~np.isfinite(projected))[0]) if not finite else None)
    active = (values <= lower + 1e-10) | (values >= upper - 1e-10)
    near_boundary = (values <= lower + .1) | (values >= upper - .1)
    return json_safe({
        "nll": float(nll), "projected_gradient_inf": norm,
        "projected_gradient_norm": norm / scale,
        "raw_gradient_norm": float(np.max(np.abs(raw), initial=0)) / scale,
        "threshold_ratio": norm / scale / CONVERGENCE_THRESHOLD,
        "worst_coefficient_index": worst,
        "boundary_indices": np.flatnonzero(near_boundary),
        "active_bound_indices": np.flatnonzero(active),
        "finite_objective": math.isfinite(nll), "finite_gradient": bool(np.all(np.isfinite(raw))),
        "finite_projected_gradient": finite,
    })


def _reason_codes(solver, metrics, summary):
    reasons = []
    finite = metrics["finite_objective"] and metrics["finite_projected_gradient"]
    converged = finite and metrics["projected_gradient_norm"] < CONVERGENCE_THRESHOLD
    if converged:
        reasons.append("projected_gradient_converged")
    elif finite:
        reasons.append("gradient_tolerance_not_met")
        if solver["success"]:
            reasons.append("solver_success_without_stationarity")
    if not metrics["finite_objective"]:
        reasons.append("nonfinite_objective")
    if not metrics["finite_gradient"]:
        reasons.append("nonfinite_gradient")
    if metrics["boundary_indices"]:
        reasons.append("boundary_reached")
    message = solver["message"].upper()
    if (("ITERATION" in message and ("LIMIT" in message or "EXCEED" in message))
            or solver["method"] == "SLSQP" and solver["status"] == 9):
        reasons.append("iteration_limit")
    if "EVALUATION" in message and ("LIMIT" in message or "EXCEED" in message):
        reasons.append("evaluation_limit")
    if any(word in message for word in ("ABNORMAL", "LNSRCH", "LINE SEARCH", "LINESEARCH", "DIRECTIONAL DERIVATIVE")):
        reasons.append("line_search_failure")
    if any(word in message for word in ("PRECISION", "SINGULAR", "ROUNDING", "NAN", "INF/", "NUMERICAL")):
        reasons.append("numerical_failure")
    if "RELATIVE REDUCTION" in message or "FTOL" in message:
        reasons.append("objective_tolerance_stop")
    if not converged and summary["trailing_stagnant_iterations"] >= 2:
        reasons.append("objective_stagnation")
    return reasons


class OptimizationStageTrace:
    """Observe trial calls and accepted iterates without extra objective calls."""

    def __init__(self, objective, initial, *, method, phase, options, sample_count,
                 lower, upper, objective_scale=1., trace_callback=None, history_limit=HISTORY_LIMIT):
        self.objective = objective
        self.initial = np.asarray(initial, dtype=float).copy()
        self.method, self.phase = method, phase
        self.sample_count, self.lower, self.upper = sample_count, lower, upper
        self.objective_scale = objective_scale
        self.trace_callback = trace_callback
        self.history_limit = max(int(history_limit), 4)
        self.stride = 1
        self.iterations = 0
        self._cache = OrderedDict()
        self._previous_metrics = None
        self._last_sample = None
        self._last_callback_time = monotonic()
        self.data = {
            "method": method, "phase": phase, "selected": False,
            "options": json_safe(options), "objective_scale": json_safe(objective_scale),
            "initial_coefficients": json_safe(self.initial), "initial_metrics": None,
            "final_coefficients": None, "final_metrics": None,
            "objective_evaluations": {"total": 0, "nonfinite_loss": 0, "nonfinite_gradient": 0,
                                      "validation_evaluations": 0},
            "iteration_summary": {"total": 0, "with_metrics": 0, "missing_metrics": 0,
                                  "nll_decreased": 0, "nll_increased": 0, "nll_stagnant": 0,
                                  "trailing_stagnant_iterations": 0, "gradient_decreased": 0,
                                  "gradient_increased": 0, "minimum_nll": None,
                                  "minimum_projected_gradient_norm": None,
                                  "nll_change": None, "projected_gradient_norm_change": None},
            "history": {"limit": self.history_limit, "stride": 1, "total_iterations": 0,
                        "iteration_source": "scipy_optimizer_callback",
                        "samples": [{"iteration": 0, "coefficients": json_safe(self.initial), "metrics": None}]},
        }
        self._emit("stage_start", 0, None)

    def _emit(self, event, iteration, metrics):
        if self.trace_callback is not None:
            self.trace_callback({"event": event, "phase": self.phase, "method": self.method,
                                 "iteration": iteration, "nll": (metrics or {}).get("nll"),
                                 "projected_gradient_norm": (metrics or {}).get("projected_gradient_norm"),
                                 "threshold_ratio": (metrics or {}).get("threshold_ratio")})

    def _metrics(self, values, nll, gradient):
        return optimization_metrics(values, nll, gradient, self.sample_count, self.lower, self.upper)

    def evaluate(self, values):
        nll, gradient = self.objective(values)
        # SLSQP sees a scaled objective; every diagnostic remains in the same
        # original total negative-log-likelihood units as the other stages.
        unscaled_nll = float(nll) * self.objective_scale
        unscaled_gradient = np.asarray(gradient) * self.objective_scale
        counts = self.data["objective_evaluations"]
        counts["total"] += 1
        counts["nonfinite_loss"] += int(not math.isfinite(unscaled_nll))
        counts["nonfinite_gradient"] += int(not np.all(np.isfinite(unscaled_gradient)))
        key = tuple(np.asarray(values, dtype=float))
        metrics = self._metrics(values, unscaled_nll, unscaled_gradient)
        self._cache[key] = metrics
        self._cache.move_to_end(key)
        if len(self._cache) > 16:
            self._cache.popitem(last=False)
        if self.data["initial_metrics"] is None and np.array_equal(values, self.initial):
            self.data["initial_metrics"] = metrics
            self.data["history"]["samples"][0]["metrics"] = metrics
            self._previous_metrics = metrics
        return nll, gradient

    def callback(self, values):
        self.iterations += 1
        metrics = self._cache.get(tuple(np.asarray(values, dtype=float)))
        summary = self.data["iteration_summary"]
        summary["total"] = self.iterations
        if metrics is None:
            summary["missing_metrics"] += 1
        else:
            summary["with_metrics"] += 1
            for source, target in (("nll", "minimum_nll"),
                                   ("projected_gradient_norm", "minimum_projected_gradient_norm")):
                value = metrics[source]
                if value is not None and (summary[target] is None or value < summary[target]):
                    summary[target] = value
            previous = self._previous_metrics
            if previous is not None:
                old, new = previous["nll"], metrics["nll"]
                if old is not None and new is not None:
                    stagnated = abs(new - old) <= 8 * np.finfo(float).eps * max(abs(old), abs(new), 1.)
                    if stagnated:
                        summary["nll_stagnant"] += 1
                        summary["trailing_stagnant_iterations"] += 1
                    else:
                        summary["nll_decreased" if new < old else "nll_increased"] += 1
                        summary["trailing_stagnant_iterations"] = 0
                old, new = previous["projected_gradient_norm"], metrics["projected_gradient_norm"]
                if old is not None and new is not None and old != new:
                    summary["gradient_decreased" if new < old else "gradient_increased"] += 1
            self._previous_metrics = metrics
        sample = {"iteration": self.iterations, "coefficients": json_safe(values), "metrics": metrics}
        self._last_sample = sample
        history = self.data["history"]
        if self.iterations % self.stride == 0:
            history["samples"].append(sample)
        # Leave room for the last accepted iterate even when it misses stride.
        while len(history["samples"]) > self.history_limit - 1:
            self.stride *= 2
            history["samples"] = [item for item in history["samples"] if item["iteration"] % self.stride == 0]
        history.update(stride=self.stride, total_iterations=self.iterations)
        now = monotonic()
        if now - self._last_callback_time >= 1.:
            self._last_callback_time = now
            self._emit("iteration", self.iterations, metrics)

    def finish(self, fit, *, validation_evaluations=0):
        metrics = self._metrics(fit.x, float(fit.fun), fit.jac)
        self.data["final_coefficients"] = json_safe(fit.x)
        self.data["final_metrics"] = metrics
        self.data["objective_evaluations"]["validation_evaluations"] += validation_evaluations
        solver = {"method": self.method, "success": bool(fit.success), "status": int(fit.status),
                  "message": str(fit.message), "nit": int(getattr(fit, "nit", self.iterations)),
                  "nfev": int(getattr(fit, "nfev", self.data["objective_evaluations"]["total"])),
                  "njev": int(fit.njev) if getattr(fit, "njev", None) is not None else None}
        self.data["solver"] = solver
        summary = self.data["iteration_summary"]
        initial = self.data["initial_metrics"] or {}
        for metric, name in (("nll", "nll_change"), ("projected_gradient_norm", "projected_gradient_norm_change")):
            if initial.get(metric) is not None and metrics[metric] is not None:
                summary[name] = json_safe(metrics[metric] - initial[metric])
        self.data["reason_codes"] = _reason_codes(solver, metrics, summary)
        samples = self.data["history"]["samples"]
        if self._last_sample is not None and samples[-1]["iteration"] != self._last_sample["iteration"]:
            samples.append(self._last_sample)
        self.data["history"]["final_sample"] = {
            "iteration": self.iterations, "coefficients": json_safe(fit.x), "metrics": metrics,
        }
        self._emit("stage_end", self.iterations, metrics)


def finish_optimizer_trace(trace, fit, converged, selected_stage, sample_count, lower, upper):
    """Record the actual returned candidate, which need not be the last stage."""
    if trace is None:
        return
    trace.update(final_coefficients=json_safe(fit.x),
                 final_metrics=optimization_metrics(fit.x, fit.fun, fit.jac, sample_count, lower, upper),
                 converged=bool(converged), selected_phase=selected_stage.phase if selected_stage else None)
    for stage in trace["stages"]:
        stage["selected"] = selected_stage is not None and stage is selected_stage.data
