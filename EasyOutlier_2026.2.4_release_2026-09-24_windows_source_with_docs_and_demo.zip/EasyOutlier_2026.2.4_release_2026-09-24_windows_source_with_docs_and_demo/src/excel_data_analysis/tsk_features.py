"""Canonical labels shared by TSK topology parsing and statistical models."""

from __future__ import annotations

import math
from numbers import Integral, Real
from typing import Any, Mapping


ALL_CATEGORY_COMBINATIONS = "__all_categories__"


def category_combination_label(categories: Mapping[str, Any]) -> str:
    """Return a readable full-combination label in categorical feature order."""
    def escaped(value):
        return str(value).replace("\\", "\\\\").replace("·", "\\·").replace("=", "\\=").replace("\n", "\\n")

    # Labels also identify plotted cells and the selected comparison reference;
    # category text containing our separators must not merge distinct cells.
    return " · ".join(f"{escaped(name)}={escaped(value)}" for name, value in categories.items())


def category_label(value: Any, label: str) -> str:
    """Keep categories nominal while normalizing equivalent numeric cells.

    Text is stripped, not parsed as a number: a label such as ``"040"`` can
    carry meaning. Numeric Excel cells containing 40 and 40.0 both become
    ``"40"``. Missing cells and booleans are never implicit categories.
    """
    if isinstance(value, str) and value.strip():
        return value.strip()
    if not isinstance(value, bool) and isinstance(value, Real):
        if isinstance(value, Integral):
            return str(int(value))
        number = float(value)
        if math.isfinite(number):
            return str(int(number)) if number.is_integer() else str(number)
    raise ValueError(f"{label} must be a nonempty category label or a finite number.")
