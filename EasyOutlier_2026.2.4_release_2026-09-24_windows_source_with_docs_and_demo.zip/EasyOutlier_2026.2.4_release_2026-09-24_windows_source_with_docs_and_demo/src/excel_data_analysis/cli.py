from __future__ import annotations

import argparse
import json
from pathlib import Path

from .service import (
    analyze_report_failures,
    build_column_filters,
    build_dimension_filters,
    create_golden_reference,
    describe_storage,
    generate_report,
    generate_report_from_storage,
    import_dataset,
    list_import_history,
    parse_csv_items,
    parse_filters,
    parse_semicolon_items,
    preview_import,
)
from .template import (
    collect_analysis_group_conflicts,
    load_template,
    save_template,
    summarize_template,
    validate_template_file,
)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="easy-outlier",
        description="Easy Outlier: template-driven Excel/CSV anomaly analysis",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    import_parser = subparsers.add_parser("import-data", help="Import a table into storage")
    import_parser.add_argument("--template", required=True)
    import_parser.add_argument("--input", required=True)
    import_parser.add_argument("--storage", required=True)
    import_parser.add_argument(
        "--conflict-mode",
        choices=["error", "replace", "append"],
        default="error",
    )

    preview_import_parser = subparsers.add_parser(
        "preview-import",
        help="Preview import conflicts before writing data into storage",
    )
    preview_import_parser.add_argument("--template", required=True)
    preview_import_parser.add_argument("--input", required=True)
    preview_import_parser.add_argument("--storage", required=True)

    show_storage_parser = subparsers.add_parser(
        "show-storage",
        help="Show current storage/database content summary",
    )
    show_storage_parser.add_argument("--storage", required=True)
    show_storage_parser.add_argument("--template")
    show_storage_parser.add_argument("--limit", type=int, default=200)

    golden_parser = subparsers.add_parser("build-golden", help="Build a golden reference")
    golden_parser.add_argument("--storage", required=True)
    golden_parser.add_argument("--template")
    golden_parser.add_argument("--name", required=True)
    golden_parser.add_argument("--reference-dims", required=True)
    golden_parser.add_argument("--filter", action="append", default=[])
    golden_parser.add_argument(
        "--center-method",
        choices=["mean", "median"],
        default=None,
    )
    golden_parser.add_argument("--outlier-golden-method")
    golden_parser.add_argument("--relative-limit", type=float)
    golden_parser.add_argument("--sigma-multiplier", type=float)
    golden_parser.add_argument("--absolute-lower-bound", type=float)
    golden_parser.add_argument("--absolute-upper-bound", type=float)
    golden_parser.add_argument("--overwrite-lowerbound", "--overwrite-min", dest="overwrite_lowerbound", type=float)
    golden_parser.add_argument("--overwrite-upperbound", "--overwrite-max", dest="overwrite_upperbound", type=float)
    golden_parser.add_argument("--continuous-interval", action="store_true")
    golden_parser.add_argument("--empty-range-fallback-to-absolute", action="store_true")
    golden_parser.add_argument(
        "--analysis-group-conflict-mode",
        choices=["error", "first_non_empty"],
        default="error",
        help=(
            "How to handle conflicting shared fields across multiple analysis_groups rows "
            "with the same id in Excel templates."
        ),
    )
    golden_parser.add_argument(
        "--if-exists",
        choices=["error", "overwrite", "timestamp"],
        default="error",
    )

    show_imports_parser = subparsers.add_parser(
        "show-imports",
        help="Show import history for the current database",
    )
    show_imports_parser.add_argument("--storage", required=True)

    report_parser = subparsers.add_parser(
        "generate-report",
        help="Generate the multi-sheet chip reliability report from an input workbook or a database scope",
    )
    report_parser.add_argument("--template", required=True)
    report_parser.add_argument("--output", required=True)
    report_source = report_parser.add_mutually_exclusive_group(required=True)
    report_source.add_argument("--input")
    report_source.add_argument("--storage")
    report_parser.add_argument("--golden")
    report_parser.add_argument("--dataset-id", action="append", default=[])
    report_parser.add_argument("--sample-ids", default="")
    report_parser.add_argument("--except-sample-ids", default="")
    report_parser.add_argument("--nodes", default="")
    report_parser.add_argument("--except-nodes", default="")
    report_parser.add_argument("--tests", default="")
    report_parser.add_argument("--except-tests", default="")
    report_parser.add_argument(
        "--outlier-fail-mode",
        choices=[
            "modified_z_score",
            "golden_deviation",
            "zscore_and_golden",
            "zscore_or_golden",
        ],
    )
    report_parser.add_argument("--z-threshold", type=float)
    report_parser.add_argument(
        "--empty-cells-pass",
        action="store_true",
        help=(
            "Do not treat blank/non-numeric expected test cells as raw outlier failures. "
            "Empty cells still do not participate in golden calculation."
        ),
    )
    report_parser.add_argument(
        "--if-exists",
        choices=["error", "overwrite", "timestamp"],
        default="error",
    )

    report_check_parser = subparsers.add_parser(
        "report-failures",
        help="List all fail items used by the multi-sheet report",
    )
    report_check_parser.add_argument("--template", required=True)
    report_check_parser.add_argument("--input", required=True)
    report_check_parser.add_argument("--golden")
    report_check_parser.add_argument("--z-threshold", type=float)

    validate_template_parser = subparsers.add_parser(
        "validate-template",
        help="Validate a template file in JSON or Excel format",
    )
    validate_template_parser.add_argument("--input", required=True)
    validate_template_parser.add_argument(
        "--analysis-group-conflict-mode",
        choices=["error", "first_non_empty"],
        default="error",
        help=(
            "How to handle conflicting shared fields across multiple analysis_groups rows "
            "with the same id in Excel templates."
        ),
    )

    template_to_json_parser = subparsers.add_parser(
        "template-to-json",
        help="Convert a template file to JSON format",
    )
    template_to_json_parser.add_argument("--input", required=True)
    template_to_json_parser.add_argument("--output")
    template_to_json_parser.add_argument(
        "--if-exists",
        choices=["error", "overwrite", "timestamp"],
        default="error",
    )

    template_to_xlsx_parser = subparsers.add_parser(
        "template-to-xlsx",
        help="Convert a template file to Excel format",
    )
    template_to_xlsx_parser.add_argument("--input", required=True)
    template_to_xlsx_parser.add_argument("--output")
    template_to_xlsx_parser.add_argument(
        "--if-exists",
        choices=["error", "overwrite", "timestamp"],
        default="error",
    )

    args = parser.parse_args()

    if args.command == "import-data":
        handle_import(args)
        return
    if args.command == "preview-import":
        handle_preview_import(args)
        return
    if args.command == "show-storage":
        handle_show_storage(args)
        return
    if args.command == "build-golden":
        handle_build_golden(args)
        return
    if args.command == "show-imports":
        handle_show_imports(args)
        return
    if args.command == "generate-report":
        handle_generate_report(args)
        return
    if args.command == "report-failures":
        handle_report_failures(args)
        return
    if args.command == "validate-template":
        handle_validate_template(args)
        return
    if args.command == "template-to-json":
        handle_template_to_json(args)
        return
    if args.command == "template-to-xlsx":
        handle_template_to_xlsx(args)
        return


def handle_import(args: argparse.Namespace) -> None:
    payload = import_dataset(
        args.template,
        args.input,
        args.storage,
        conflict_mode=args.conflict_mode,
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def handle_preview_import(args: argparse.Namespace) -> None:
    payload = preview_import(args.template, args.input, args.storage)
    payload = dict(payload)
    payload.pop("conflict_keys", None)
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def handle_show_storage(args: argparse.Namespace) -> None:
    payload = describe_storage(args.storage, template_path=args.template, limit=args.limit)
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def handle_build_golden(args: argparse.Namespace) -> None:
    template = (
        load_template(
            args.template,
            analysis_group_conflict_mode=args.analysis_group_conflict_mode,
        )
        if args.template
        else None
    )
    golden_defaults = template.golden_reference_defaults if template else None
    conflict_warnings = (
        collect_analysis_group_conflicts(args.template)
        if args.template and args.analysis_group_conflict_mode == "first_non_empty"
        else []
    )
    reference, path = create_golden_reference(
        storage_path=args.storage,
        name=args.name,
        reference_dimensions=parse_csv_items(args.reference_dims),
        filters=parse_filters(args.filter),
        center_method=args.center_method or (
            golden_defaults.center_method if golden_defaults else "mean"
        ),
        outlier_golden_method=args.outlier_golden_method or (
            golden_defaults.outlier_golden_method if golden_defaults else "relative"
        ),
        relative_limit=(
            args.relative_limit
            if args.relative_limit is not None
            else (golden_defaults.relative_limit if golden_defaults else None)
        ),
        sigma_multiplier=(
            args.sigma_multiplier
            if args.sigma_multiplier is not None
            else (golden_defaults.sigma_multiplier if golden_defaults else None)
        ),
        absolute_lower_bound=(
            args.absolute_lower_bound
            if args.absolute_lower_bound is not None
            else (golden_defaults.absolute_lower_bound if golden_defaults else None)
        ),
        absolute_upper_bound=(
            args.absolute_upper_bound
            if args.absolute_upper_bound is not None
            else (golden_defaults.absolute_upper_bound if golden_defaults else None)
        ),
        overwrite_lowerbound=(
            args.overwrite_lowerbound
            if args.overwrite_lowerbound is not None
            else (golden_defaults.overwrite_lowerbound if golden_defaults else None)
        ),
        overwrite_upperbound=(
            args.overwrite_upperbound
            if args.overwrite_upperbound is not None
            else (golden_defaults.overwrite_upperbound if golden_defaults else None)
        ),
        continuous_interval=(
            bool(args.continuous_interval)
            if args.continuous_interval
            else (golden_defaults.continuous_interval if golden_defaults else False)
        ),
        empty_range_fallback_to_absolute=(
            bool(args.empty_range_fallback_to_absolute)
            if args.empty_range_fallback_to_absolute
            else (
                golden_defaults.empty_range_fallback_to_absolute
                if golden_defaults
                else False
            )
        ),
        template_path=args.template,
        analysis_group_conflict_mode=args.analysis_group_conflict_mode,
        if_exists=args.if_exists,
    )
    payload = {
        "golden_name": reference.name,
        "metric_count": len(reference.metrics),
        "center_method": reference.center_method,
        "saved_to": path,
        "excel_saved_to": str(Path(path).with_suffix(".xlsx")),
    }
    if conflict_warnings:
        payload["analysis_group_conflicts"] = conflict_warnings
        payload["analysis_group_conflict_mode"] = args.analysis_group_conflict_mode
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def handle_show_imports(args: argparse.Namespace) -> None:
    print(json.dumps(list_import_history(args.storage), ensure_ascii=False, indent=2))


def handle_generate_report(args: argparse.Namespace) -> None:
    template = load_template(args.template)
    column_filters = build_column_filters(
        template,
        include_tests=parse_semicolon_items(args.tests),
        exclude_tests=parse_semicolon_items(args.except_tests),
    )
    dimension_filters = build_dimension_filters(
        sample_keys=parse_semicolon_items(args.sample_ids),
        sample_dimension_names=template.report.sample_dimension_names,
        reliability_node_dimension=template.report.reliability_node_dimension,
        reliability_nodes=parse_csv_items(args.nodes),
        exclude_sample_keys=parse_semicolon_items(args.except_sample_ids),
        exclude_reliability_nodes=parse_csv_items(args.except_nodes),
    )
    if args.input:
        payload = generate_report(
            args.template,
            args.input,
            args.output,
            built_golden_path=args.golden,
            outlier_fail_method_override=args.outlier_fail_mode,
            outlier_treat_empty_cells_as_fail_override=not args.empty_cells_pass,
            zscore_threshold_override=args.z_threshold,
            dimension_filters=dimension_filters,
            column_filters=column_filters,
            if_exists=args.if_exists,
        )
    else:
        payload = generate_report_from_storage(
            template_path=args.template,
            storage_path=args.storage,
            output_path=args.output,
            built_golden_path=args.golden,
            outlier_fail_method_override=args.outlier_fail_mode,
            outlier_treat_empty_cells_as_fail_override=not args.empty_cells_pass,
            zscore_threshold_override=args.z_threshold,
            dataset_ids=args.dataset_id,
            dimension_filters=dimension_filters,
            column_filters=column_filters,
            if_exists=args.if_exists,
        )
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def handle_report_failures(args: argparse.Namespace) -> None:
    payload = [
        item.to_dict()
        for item in analyze_report_failures(
            args.template,
            args.input,
            built_golden_path=args.golden,
            zscore_threshold_override=args.z_threshold,
        )
    ]
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def handle_validate_template(args: argparse.Namespace) -> None:
    template = validate_template_file(
        args.input,
        analysis_group_conflict_mode=args.analysis_group_conflict_mode,
    )
    payload = {
        "input": str(Path(args.input).resolve()),
        "format": Path(args.input).suffix.lower().lstrip("."),
        "valid": True,
        "summary": summarize_template(template),
    }
    if args.analysis_group_conflict_mode == "first_non_empty":
        conflicts = collect_analysis_group_conflicts(args.input)
        if conflicts:
            payload["analysis_group_conflicts"] = conflicts
            payload["analysis_group_conflict_mode"] = args.analysis_group_conflict_mode
    print(
        json.dumps(payload, ensure_ascii=False, indent=2)
    )


def handle_template_to_json(args: argparse.Namespace) -> None:
    template = load_template(args.input)
    output = args.output or str(Path(args.input).with_suffix(".json"))
    resolved = save_template(template, output, if_exists=args.if_exists)
    print(
        json.dumps(
            {
                "input": str(Path(args.input).resolve()),
                "output": str(resolved.resolve()),
                "summary": summarize_template(template),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


def handle_template_to_xlsx(args: argparse.Namespace) -> None:
    template = load_template(args.input)
    output = args.output or str(Path(args.input).with_suffix(".xlsx"))
    resolved = save_template(template, output, if_exists=args.if_exists)
    print(
        json.dumps(
            {
                "input": str(Path(args.input).resolve()),
                "output": str(resolved.resolve()),
                "summary": summarize_template(template),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
if __name__ == "__main__":
    main()
