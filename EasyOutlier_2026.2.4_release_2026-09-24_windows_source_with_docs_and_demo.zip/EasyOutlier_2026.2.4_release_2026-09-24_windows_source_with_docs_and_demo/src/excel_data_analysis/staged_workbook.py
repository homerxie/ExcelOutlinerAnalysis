"""Serialize finished report sheets before constructing the next sheet.

The original openpyxl worksheet writer preserves all existing cell styles and
merges. Only its completed XML is retained until the final XLSX archive is saved.
This adapter is intentionally isolated because it uses openpyxl's writer API.
"""
from datetime import datetime, timezone
from contextlib import ExitStack
from pathlib import Path
import re
from shutil import copyfileobj
from zipfile import ZIP_DEFLATED, ZipFile

from openpyxl import Workbook
from openpyxl.drawing.spreadsheet_drawing import SpreadsheetDrawing
from openpyxl.worksheet._writer import WorksheetWriter, create_temporary_file, ALL_TEMP_FILES
from openpyxl.worksheet.dimensions import SheetDimension
from openpyxl.utils import get_column_letter
from openpyxl.xml.functions import xmlfile
from openpyxl.writer.excel import ExcelWriter


class _StagedExcelWriter(ExcelWriter):
    def write_worksheet(self, worksheet):
        writer = self.workbook._staged_sheets.get(worksheet)
        if writer is None:
            return super().write_worksheet(worksheet)
        worksheet._rels = writer._rels
        self._archive.write(writer.out, worksheet.path[1:])
        self.manifest.append(worksheet)
        writer.cleanup()


class _ChunkedWorksheetWriter(WorksheetWriter):
    """Spool completed rows, then wrap them with the final sheet metadata.

    Column widths and merges can be finalized after rows have been released.
    Only the small metadata document is read back into memory; sheetData is
    copied in bounded buffers. Rows already flushed must never be edited.
    """

    def __init__(self, worksheet):
        super().__init__(worksheet)
        self.body_path = create_temporary_file()
        self._body_stack = ExitStack()
        self._body_xml = self._body_stack.enter_context(xmlfile(self.body_path))
        self._body_stack.enter_context(self._body_xml.element("sheetData"))
        self.last_row = 0
        self.bounds = None
        self.max_lengths = {}
        self.peak_buffered_cells = 0
        self.flush_count = 0

    def flush(self):
        self.peak_buffered_cells = max(self.peak_buffered_cells, len(self.ws._cells))
        cells = self.ws._cells
        if cells:
            min_row = min(row for row, _ in cells)
            if min_row <= self.last_row:
                raise ValueError("Cannot edit rows that have already been flushed")
            bounds = (min(col for _, col in cells), min_row,
                      max(col for _, col in cells), max(row for row, _ in cells))
            if self.bounds:
                bounds = (min(bounds[0], self.bounds[0]), min(bounds[1], self.bounds[1]),
                          max(bounds[2], self.bounds[2]), max(bounds[3], self.bounds[3]))
            self.bounds = bounds
            for (_, column), cell in cells.items():
                if cell.value is not None:
                    self.max_lengths[column] = max(self.max_lengths.get(column, 0), len(str(cell.value)))
        # WorksheetWriter.rows() also returns styled, empty rows. Exclude any
        # already emitted row dimensions, but reject edits to old cells above.
        for index, row in self.rows():
            if index > self.last_row:
                self.write_row(self._body_xml, row, index)
                self.last_row = index
        cells.clear()
        self.flush_count += 1

    def write_dimensions(self):
        if self.bounds:
            left, top, right, bottom = self.bounds
            ref = f"{get_column_letter(left)}{top}:{get_column_letter(right)}{bottom}"
        else:
            ref = "A1:A1"
        self.xf.send(SheetDimension(ref).to_tree())

    def write(self):
        self.flush()
        self._body_stack.close()
        self.write_top()
        xf = self.xf.send(True)
        with xf.element("sheetData"):
            pass
        self.xf.send(None)
        self.write_tail()
        self.close()
        metadata = Path(self.out).read_bytes()
        marker = re.search(rb"<sheetData(?:\s*/>|></sheetData>)", metadata)
        if marker is None:
            raise ValueError("Worksheet writer did not emit the sheetData placeholder")
        with open(self.out, "wb") as destination, open(self.body_path, "rb") as source:
            destination.write(metadata[:marker.start()])
            copyfileobj(source, destination, length=1024 * 1024)
            destination.write(metadata[marker.end():])
        self._cleanup_body()

    def _cleanup_body(self):
        if Path(self.body_path).exists():
            Path(self.body_path).unlink()
            ALL_TEMP_FILES.remove(self.body_path)

    def close(self):
        try:
            self._body_stack.close()
        finally:
            super().close()

    def cleanup(self):
        try:
            self._cleanup_body()
        finally:
            super().cleanup()


class StagedWorkbook(Workbook):
    """Single-save workbook; a staged sheet must not be edited afterwards."""

    def __init__(self):
        super().__init__()
        self._staged_sheets = {}
        self._chunked_sheets = {}

    def flush(self, worksheet):
        """Write and release a completed block; later blocks must use new rows."""
        if worksheet in self._staged_sheets:
            raise ValueError("Worksheet has already been staged")
        writer = self._chunked_sheets.get(worksheet)
        if writer is None:
            writer = _ChunkedWorksheetWriter(worksheet)
            self._chunked_sheets[worksheet] = writer
        writer.flush()

    def stage(self, worksheet):
        if worksheet in self._staged_sheets:
            raise ValueError("Worksheet has already been staged")
        worksheet._drawing = SpreadsheetDrawing()
        worksheet._drawing.charts = worksheet._charts
        worksheet._drawing.images = worksheet._images
        writer = self._chunked_sheets.get(worksheet)
        if writer is None:
            writer = WorksheetWriter(worksheet)
        self._staged_sheets[worksheet] = writer
        writer.write()
        worksheet._cells.clear()

    def save(self, filename):
        self.properties.modified = datetime.now(timezone.utc).replace(tzinfo=None)
        try:
            with ZipFile(filename, "w", ZIP_DEFLATED, allowZip64=True) as archive:
                _StagedExcelWriter(self, archive).save()
        finally:
            self.close()

    def close(self):
        for writer in set(self._staged_sheets.values()) | set(self._chunked_sheets.values()):
            if Path(writer.out).exists():
                try:
                    writer.close()
                finally:
                    writer.cleanup()
        super().close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
