from __future__ import annotations

import json
import re
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

from . import reporting
from .analyzer import evaluate_against_golden, evaluate_modified_zscore
from .field_names import FieldNames, field_key, row_fields
from .comparison_models import (
    MetricDescriptor,
    MetricFilterRule,
    PlotBuildResult,
    PlotPoint,
    PlotSeries,
    ReferenceRange,
)
from .io import build_measurements, load_table
from .models import AnalysisColumn, AnalysisGroup, AnomalyResult, GoldenReference, MeasurementRecord, TemplateConfig
from .repository import Repository
from .service import _filter_measurements
from .template import load_template


FEW_POINTS_PER_LANE_THRESHOLD = 5
ProgressCallback = Callable[[str, int, int], None]
PointMergeKey = tuple[str, int, str]


@dataclass(frozen=True, slots=True)
class _MergedOutlierInfo:
    merged_outlier: bool
    merge_block_key: str
    related_outlier_keys: tuple[PointMergeKey, ...]


def load_measurements_for_plot(
    template_path: str | Path,
    analysis_scope: str,
    input_path: str | Path | None = None,
    storage_path: str | Path | None = None,
    dataset_ids: list[str] | None = None,
    dimension_filters: dict[str, dict[str, list[str]]] | None = None,
    column_filters: dict[str, dict[str, list[str]]] | None = None,
    progress_callback: ProgressCallback | None = None,
) -> tuple[TemplateConfig, list[MeasurementRecord]]:
    _report_progress(progress_callback, "Loading template...", 0, 4)
    template = load_template(template_path)
    if analysis_scope == "current_input_file":
        if not input_path:
            raise ValueError("Input file is required for current input file plotting.")
        _report_progress(progress_callback, "Reading input table...", 1, 4)
        table = load_table(input_path, template=template)
        _report_progress(progress_callback, "Building measurement records...", 2, 4)
        measurements = build_measurements(
            template=template,
            rows=table.rows,
            dataset_id="ad-hoc-report",
            source_file=str(Path(input_path).resolve()),
        )
        _report_progress(progress_callback, "Applying input filters...", 3, 4)
        filtered = _filter_measurements(
            measurements,
            dimension_filters=dimension_filters,
            column_filters=column_filters,
            template=template,
        )
        _report_progress(progress_callback, f"Loaded {len(filtered)} measurement(s).", 4, 4)
        return template, filtered

    if not storage_path:
        raise ValueError("Database folder is required for database plotting.")
    _report_progress(progress_callback, "Opening measurement database...", 1, 4)
    repository = Repository(storage_path)
    _report_progress(progress_callback, "Reading measurement records...", 2, 4)
    measurements = repository.load_measurements()
    _report_progress(progress_callback, "Applying database filters...", 3, 4)
    filtered = _filter_measurements(
        measurements,
        dataset_ids=dataset_ids,
        dimension_filters=dimension_filters,
        column_filters=column_filters,
        template=template,
    )
    _report_progress(progress_callback, f"Loaded {len(filtered)} measurement(s).", 4, 4)
    return template, filtered


def metric_filter_fields(template: TemplateConfig) -> list[str]:
    fields = [
        "Display Label",
        "Logical Metric",
        "Analysis Group ID",
        "Analysis Group Name",
        "Raw Column",
        "Unit",
        "Lane Has Outlier",
        "Metric Has Outlier",
    ]
    fields.extend(_row_dimension_filter_fields(template))
    fields.extend(level.name for level in sorted(template.column_header_levels, key=lambda item: item.priority))
    return _ordered_unique(fields)


def lane_dimension_options(template: TemplateConfig) -> list[str]:
    return [item.name for item in sorted(template.row_dimensions, key=lambda value: value.priority)]


def _row_dimension_filter_fields(template: TemplateConfig) -> list[str]:
    fields: list[str] = []
    for dimension in sorted(template.row_dimensions, key=lambda value: value.priority):
        primary = dimension.display_name or _readable_field_name(dimension.name)
        if primary not in fields:
            fields.append(primary)
    return fields


def _readable_field_name(value: str) -> str:
    text = re.sub(r"[_\-]+", " ", value).strip()
    text = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", text)
    return " ".join(part.upper() if part.lower() in {"id"} else part.capitalize() for part in text.split())


def _field_key(value: str) -> str:
    return field_key(value)


def build_plot_result(
    template: TemplateConfig,
    measurements: list[MeasurementRecord],
    metric_rules: Iterable[MetricFilterRule] | None = None,
    metric_search_query: str = "",
    selected_logical_metrics: Iterable[str] | None = None,
    lane_dimensions: Iterable[str] | None = None,
    golden_path: str | Path | None = None,
    outlier_fail_method: str = "modified_z_score",
    zscore_threshold: float = 3.5,
    progress_callback: ProgressCallback | None = None,
) -> PlotBuildResult:
    total_steps = 8
    _report_progress(progress_callback, "Preparing plot filters...", 0, total_steps)
    fields = row_fields(template)
    lane_dimension_list = tuple(
        fields.resolve(name) for name in (lane_dimensions or (template.report.reliability_node_dimension,))
    )
    metric_rule_list, row_rule_list, lane_rule_list = _split_filter_rules(template, metric_rules or [])
    _report_progress(progress_callback, "Applying row filters...", 1, total_steps)
    measurements = _filter_measurements_by_row_rules(measurements, row_rule_list, template)
    _report_progress(progress_callback, "Evaluating z-score outliers...", 2, total_steps)
    zscore_map = _build_zscore_map(measurements, zscore_threshold)
    _report_progress(progress_callback, "Evaluating golden reference bounds...", 3, total_steps)
    golden_map = _build_golden_map(measurements, golden_path) if golden_path else {}
    _report_progress(progress_callback, "Collecting outlier metrics...", 4, total_steps)
    metric_outliers = _outlier_logical_metrics(
        measurements,
        zscore_map=zscore_map,
        golden_map=golden_map,
        outlier_fail_method=outlier_fail_method,
    )
    merged_outlier_index = _build_merged_outlier_index(
        template,
        measurements,
        zscore_map=zscore_map,
        golden_map=golden_map,
        outlier_fail_method=outlier_fail_method,
    )
    _report_progress(progress_callback, "Building metric catalog...", 5, total_steps)
    catalog = build_metric_catalog(
        template,
        measurements,
        outlier_logical_metrics=metric_outliers,
    )
    _report_progress(progress_callback, "Applying metric filters...", 6, total_steps)
    matched_metrics = tuple(
        descriptor
        for descriptor in catalog
        if metric_matches_rules(descriptor, metric_rule_list)
        and metric_matches_search(descriptor, metric_search_query)
    )
    selected_set = {str(item) for item in selected_logical_metrics or [] if str(item)}
    selected_metrics = tuple(
        descriptor
        for descriptor in matched_metrics
        if not selected_set or descriptor.logical_metric in selected_set
    )
    selected_metric_keys = {item.logical_metric for item in selected_metrics}
    _report_progress(progress_callback, "Building lane series...", 7, total_steps)
    series_by_metric = _build_series_by_metric(
        measurements=[
            item for item in measurements if item.logical_metric in selected_metric_keys
        ],
        metric_by_key={item.logical_metric: item for item in selected_metrics},
        lane_dimensions=lane_dimension_list,
        zscore_map=zscore_map,
        golden_map=golden_map,
        outlier_fail_method=outlier_fail_method,
        merged_outlier_index=merged_outlier_index,
    )
    _report_progress(progress_callback, "Finalizing plot summary...", 8, total_steps)
    if lane_rule_list:
        series_by_metric = _filter_series_by_lane_rules(series_by_metric, lane_rule_list)
        selected_metrics = tuple(
            descriptor for descriptor in selected_metrics if series_by_metric.get(descriptor.logical_metric)
        )
        selected_metric_keys = {item.logical_metric for item in selected_metrics}
        matched_metrics = tuple(
            descriptor for descriptor in matched_metrics if descriptor.logical_metric in selected_metric_keys
        )
    all_series = [
        series
        for series_items in series_by_metric.values()
        for series in series_items
    ]
    return PlotBuildResult(
        metrics=matched_metrics,
        selected_metrics=selected_metrics,
        series_by_metric=series_by_metric,
        point_count=sum(len(series.points) for series in all_series),
        outlier_count=sum(
            1 for series in all_series for point in series.points if point.outlier
        ),
        lane_count=len(all_series),
        lanes_with_few_points=sum(
            1 for series in all_series if len(series.points) < FEW_POINTS_PER_LANE_THRESHOLD
        ),
    )


def _report_progress(callback: ProgressCallback | None, message: str, value: int, total: int) -> None:
    if callback is not None:
        callback(message, value, total)


def build_metric_catalog(
    template: TemplateConfig,
    measurements: list[MeasurementRecord],
    outlier_logical_metrics: set[str] | None = None,
) -> tuple[MetricDescriptor, ...]:
    outlier_logical_metrics = outlier_logical_metrics or set()
    point_counts: dict[str, int] = defaultdict(int)
    for item in measurements:
        point_counts[item.logical_metric] += 1

    descriptors: list[MetricDescriptor] = []
    for group in template.analysis_groups:
        if group.analysis_mode == "pooled_columns":
            logical_metric = group.id
            descriptors.append(
                _descriptor_for_columns(
                    template,
                    group,
                    logical_metric,
                    group.columns,
                    point_counts.get(logical_metric, 0),
                    logical_metric in outlier_logical_metrics,
                )
            )
            continue
        for column in group.columns:
            logical_metric = f"{group.id}::{column.name}"
            descriptors.append(
                _descriptor_for_columns(
                    template,
                    group,
                    logical_metric,
                    [column],
                    point_counts.get(logical_metric, 0),
                    logical_metric in outlier_logical_metrics,
                )
            )
    return tuple(
        sorted(
            descriptors,
            key=lambda item: (
                _natural_key(item.group_display_name),
                _natural_key(item.display_label),
                _natural_key(item.logical_metric),
            ),
        )
    )


def metric_matches_rules(
    descriptor: MetricDescriptor,
    rules: Iterable[MetricFilterRule],
) -> bool:
    result: bool | None = None
    for rule in rules:
        rule_result = _metric_matches_rule(descriptor, rule)
        connector = rule.connector.strip().lower()
        if result is None:
            result = rule_result
        elif connector == "or":
            result = result or rule_result
        elif connector == "and not":
            result = result and not rule_result
        else:
            result = result and rule_result
    return True if result is None else result


def _split_filter_rules(
    template: TemplateConfig,
    rules: Iterable[MetricFilterRule],
) -> tuple[tuple[MetricFilterRule, ...], tuple[MetricFilterRule, ...], tuple[MetricFilterRule, ...]]:
    metric_rules: list[MetricFilterRule] = []
    row_rules: list[MetricFilterRule] = []
    lane_rules: list[MetricFilterRule] = []
    row_aliases = _row_dimension_aliases(template)
    for rule in rules:
        field_name = _field_key(rule.field_name)
        if field_name in {field_key("has_outlier"), field_key("lane_has_outlier")}:
            lane_rules.append(rule)
        elif row_aliases.resolve(rule.field_name) in row_aliases.names:
            row_rules.append(rule)
        else:
            metric_rules.append(rule)
    return tuple(metric_rules), tuple(row_rules), tuple(lane_rules)


def _row_dimension_aliases(template: TemplateConfig) -> FieldNames:
    return row_fields(template)


def _filter_measurements_by_row_rules(
    measurements: list[MeasurementRecord],
    rules: tuple[MetricFilterRule, ...],
    template: TemplateConfig,
) -> list[MeasurementRecord]:
    if not rules:
        return measurements
    aliases = _row_dimension_aliases(template)
    return [
        item
        for item in measurements
        if _measurement_matches_row_rules(item, rules, aliases)
    ]


def _measurement_matches_row_rules(
    item: MeasurementRecord,
    rules: Iterable[MetricFilterRule],
    aliases: FieldNames,
) -> bool:
    result: bool | None = None
    for rule in rules:
        rule_result = _measurement_matches_row_rule(item, rule, aliases)
        connector = rule.connector.strip().lower()
        if result is None:
            result = rule_result
        elif connector == "or":
            result = result or rule_result
        elif connector == "and not":
            result = result and not rule_result
        else:
            result = result and rule_result
    return True if result is None else result


def _measurement_matches_row_rule(
    item: MeasurementRecord,
    rule: MetricFilterRule,
    aliases: FieldNames,
) -> bool:
    dimension_name = aliases.resolve(rule.field_name)
    values = [str(item.dimensions.get(dimension_name, "") or "").strip().lower()]
    return _values_match_operator(values, rule.operator.strip().lower(), rule.value.strip().lower())


def _filter_series_by_lane_rules(
    series_by_metric: dict[str, tuple[PlotSeries, ...]],
    rules: tuple[MetricFilterRule, ...],
) -> dict[str, tuple[PlotSeries, ...]]:
    filtered: dict[str, tuple[PlotSeries, ...]] = {}
    for metric_key, series_items in series_by_metric.items():
        kept = tuple(series for series in series_items if _series_matches_rules(series, rules))
        if kept:
            filtered[metric_key] = kept
    return filtered


def _series_matches_rules(series: PlotSeries, rules: Iterable[MetricFilterRule]) -> bool:
    result: bool | None = None
    for rule in rules:
        rule_result = _series_matches_rule(series, rule)
        connector = rule.connector.strip().lower()
        if result is None:
            result = rule_result
        elif connector == "or":
            result = result or rule_result
        elif connector == "and not":
            result = result and not rule_result
        else:
            result = result and rule_result
    return True if result is None else result


def _series_matches_rule(series: PlotSeries, rule: MetricFilterRule) -> bool:
    operator = rule.operator.strip().lower()
    expected = rule.value.strip().lower()
    has_outlier = any(point.outlier for point in series.points)
    if operator == "has outlier":
        if expected in {"false", "no", "0"}:
            return not has_outlier
        return has_outlier
    values = [("true" if has_outlier else "false")]
    return _values_match_operator(values, operator, expected)


def metric_matches_search(descriptor: MetricDescriptor, query: str) -> bool:
    fields = _metric_search_fields(descriptor)
    if not _has_explicit_space(query):
        return _single_token_matches(fields, query, descriptor)
    tokens = _search_tokens(query)
    if not tokens:
        return True
    compact_fields = [_compact_search_text(value) for value in fields]
    combined = _normalize_search_text(" ".join(fields))
    combined_compact = _compact_search_text(combined)
    return all(
        _search_token_matches(
            token=token,
            compact_fields=compact_fields,
            combined=combined,
            combined_compact=combined_compact,
            descriptor=descriptor,
        )
        for token in tokens
    )


def _single_token_matches(fields: list[str], query: str, descriptor: MetricDescriptor) -> bool:
    normalized_token = _normalize_search_text(query)
    compact_token = _compact_search_text(query)
    if not normalized_token and not compact_token:
        return True
    if normalized_token in {"outlier", "abnormal", "fail", "failed"}:
        return descriptor.has_outlier
    for value in fields:
        normalized_value = _normalize_search_text(value)
        if normalized_token and normalized_token in normalized_value:
            return True
        if compact_token and any(compact_token in segment for segment in _compact_search_segments(value)):
            return True
    return False


def _metric_search_fields(descriptor: MetricDescriptor) -> list[str]:
    fields = [
        descriptor.display_label,
        descriptor.logical_metric,
        descriptor.group_id,
        descriptor.group_display_name,
        descriptor.unit or "",
        "outlier" if descriptor.has_outlier else "",
        "has outlier" if descriptor.has_outlier else "",
    ]
    fields.extend(descriptor.raw_columns)
    for header_name, values in descriptor.header_values.items():
        fields.append(header_name)
        fields.extend(values)
    return [item for item in fields if item]


def _search_tokens(query: str) -> list[str]:
    return [
        token
        for token in _normalize_search_text(query).split()
        if token
    ]


def _normalize_search_text(value: str) -> str:
    normalized = re.sub(r"[^0-9a-zA-Z]+", " ", value.lower())
    return " ".join(normalized.split())


def _compact_search_text(value: str) -> str:
    return re.sub(r"[^0-9a-zA-Z]+", "", value.lower())


def _compact_search_segments(value: str) -> list[str]:
    return [_compact_search_text(segment) for segment in re.findall(r"[0-9a-zA-Z]+", value.lower())]


def _search_token_matches(
    token: str,
    compact_fields: list[str],
    combined: str,
    combined_compact: str,
    descriptor: MetricDescriptor,
) -> bool:
    compact_token = _compact_search_text(token)
    if token in {"outlier", "abnormal", "fail", "failed"}:
        return descriptor.has_outlier
    if token in combined:
        return True
    if compact_token and any(compact_token in field for field in compact_fields):
        return True
    if compact_token and compact_token in combined_compact and not _contains_digit(compact_token):
        return True
    if _contains_digit(compact_token):
        return False
    if len(compact_token) < 2:
        return False
    return any(
        _is_subsequence(compact_token, field)
        for field in compact_fields
        if len(field) >= len(compact_token)
    )


def _is_subsequence(needle: str, haystack: str) -> bool:
    position = 0
    for char in haystack:
        if position < len(needle) and needle[position] == char:
            position += 1
            if position == len(needle):
                return True
    return False


def _contains_digit(value: str) -> bool:
    return any(char.isdigit() for char in value)


def _has_explicit_space(value: str) -> bool:
    return bool(re.search(r"\s", value))


def _descriptor_for_columns(
    template: TemplateConfig,
    group: AnalysisGroup,
    logical_metric: str,
    columns: list[AnalysisColumn],
    point_count: int,
    has_outlier: bool,
) -> MetricDescriptor:
    header_names = [item.name for item in sorted(template.column_header_levels, key=lambda value: value.priority)]
    header_values: dict[str, tuple[str, ...]] = {}
    for index, header_name in enumerate(header_names):
        values = _ordered_unique(
            column.header_values[index]
            for column in columns
            if index < len(column.header_values)
        )
        if values:
            header_values[header_name] = values
    display_parts = _display_metric_parts(group, columns, header_names, header_values)
    return MetricDescriptor(
        logical_metric=logical_metric,
        group_id=group.id,
        group_display_name=group.display_name,
        raw_columns=tuple(column.name for column in columns),
        unit=group.unit,
        header_values=header_values,
        display_label=" | ".join(display_parts) if display_parts else logical_metric,
        has_outlier=has_outlier,
        point_count=point_count,
    )


def _display_metric_parts(
    group: AnalysisGroup,
    columns: list[AnalysisColumn],
    header_names: list[str],
    header_values: dict[str, tuple[str, ...]],
) -> list[str]:
    parts: list[str] = []
    for header_name in header_names:
        values = header_values.get(header_name, ())
        if len(values) == 1:
            parts.append(values[0])
        elif len(values) > 1 and group.analysis_mode != "pooled_columns":
            parts.append(",".join(values))
    if not parts:
        parts.append(group.display_name or group.id)
    if group.analysis_mode != "pooled_columns" and len(columns) == 1:
        raw_column = columns[0].name
        if raw_column not in parts:
            parts.append(raw_column)
    return parts


def _metric_matches_rule(descriptor: MetricDescriptor, rule: MetricFilterRule) -> bool:
    operator = rule.operator.strip().lower()
    expected = rule.value.strip().lower()
    values = [value.strip().lower() for value in descriptor.field_values(rule.field_name)]
    if operator == "has outlier":
        if expected in {"false", "no", "0"}:
            return not descriptor.has_outlier
        return descriptor.has_outlier
    return _values_match_operator(values, operator, expected)


def _values_match_operator(values: list[str], operator: str, expected: str) -> bool:
    if operator in {"is empty", "empty"}:
        return not any(values)
    if operator in {"is not empty", "not empty"}:
        return any(values)
    if not expected:
        return True
    if operator == "is":
        return any(value == expected for value in values)
    if operator == "is not":
        return all(value != expected for value in values)
    if operator == "contains":
        return any(expected in value for value in values)
    if operator == "does not contain":
        return all(expected not in value for value in values)
    if operator == "starts with":
        return any(value.startswith(expected) for value in values)
    if operator == "ends with":
        return any(value.endswith(expected) for value in values)
    if operator == "is in":
        expected_values = {item.strip() for item in expected.split(",") if item.strip()}
        return any(value in expected_values for value in values)
    return any(expected in value for value in values)


def _build_series_by_metric(
    measurements: list[MeasurementRecord],
    metric_by_key: dict[str, MetricDescriptor],
    lane_dimensions: tuple[str, ...],
    zscore_map: dict[tuple[str, str, int, str], AnomalyResult],
    golden_map: dict[tuple[str, str, int, str], AnomalyResult],
    outlier_fail_method: str,
    merged_outlier_index: dict[PointMergeKey, _MergedOutlierInfo],
) -> dict[str, tuple[PlotSeries, ...]]:
    grouped: dict[tuple[str, tuple[tuple[str, str], ...]], list[MeasurementRecord]] = defaultdict(list)
    for item in measurements:
        lane_key = _lane_key(item, lane_dimensions)
        grouped[(item.logical_metric, lane_key)].append(item)

    series_by_metric: dict[str, list[PlotSeries]] = defaultdict(list)
    for (logical_metric, lane_key), items in grouped.items():
        descriptor = metric_by_key.get(logical_metric)
        if descriptor is None:
            continue
        lane_values = _lane_values(lane_key)
        lane_label = _lane_label(lane_key)
        points: list[PlotPoint] = []
        references: dict[tuple[tuple[str, str], ...], ReferenceRange] = {}
        for item in sorted(items, key=_measurement_sort_key):
            point_key = _measurement_key(item)
            z_entry = zscore_map.get(point_key)
            golden_entry = golden_map.get(point_key)
            is_outlier = _is_outlier(
                z_entry,
                golden_entry,
                outlier_fail_method=outlier_fail_method,
            )
            merged_info = merged_outlier_index.get(_measurement_merge_key(item))
            golden_key = tuple(sorted((golden_entry.reference_key or {}).items())) if golden_entry else ()
            if golden_entry and golden_key not in references:
                allowed_ranges = _allowed_range_tuples(golden_entry)
                references[golden_key] = ReferenceRange(
                    center=golden_entry.center,
                    lower_bound=golden_entry.lower_bound,
                    upper_bound=golden_entry.upper_bound,
                    key=golden_key,
                    allowed_ranges=allowed_ranges,
                )
            else:
                allowed_ranges = _allowed_range_tuples(golden_entry) if golden_entry else ()
            points.append(
                PlotPoint(
                    aggregate_id=lane_label,
                    sample_id=_point_identity(item),
                    dataset_id=item.dataset_id,
                    source_file=item.source_file,
                    row_number=item.row_number,
                    metric=descriptor.display_label,
                    logical_metric=item.logical_metric,
                    raw_column=item.raw_column,
                    value=item.value,
                    dimensions=dict(item.dimensions),
                    outlier=is_outlier,
                    z_score=z_entry.score if z_entry else None,
                    golden_center=golden_entry.center if golden_entry else None,
                    golden_lower_bound=golden_entry.lower_bound if golden_entry else None,
                    golden_upper_bound=golden_entry.upper_bound if golden_entry else None,
                    golden_allowed_ranges=allowed_ranges,
                    golden_key=golden_key,
                    merged_outlier=bool(merged_info and merged_info.merged_outlier),
                    merge_block_key=merged_info.merge_block_key if merged_info else "",
                    merge_outlier_keys=merged_info.related_outlier_keys if merged_info else (),
                )
            )
        series_by_metric[logical_metric].append(
            PlotSeries(
                aggregate_id=lane_label,
                label=lane_label,
                metric=descriptor.display_label,
                logical_metric=logical_metric,
                points=tuple(points),
                reference_ranges=tuple(references.values()),
                lane_values=lane_values,
            )
        )
    return {
        metric_key: tuple(sorted(items, key=_series_sort_key))
        for metric_key, items in series_by_metric.items()
    }


def _series_sort_key(item: PlotSeries) -> tuple[tuple[tuple[int, object], ...], ...]:
    return tuple(_natural_key(value) for value in item.lane_values or (item.label,))


def _build_zscore_map(
    measurements: list[MeasurementRecord],
    zscore_threshold: float,
) -> dict[tuple[str, str, int, str], AnomalyResult]:
    payload: dict[tuple[str, str, int, str], AnomalyResult] = {}
    for item in evaluate_modified_zscore(measurements):
        if item.score is not None and abs(item.score) > zscore_threshold:
            item.reason = f"Absolute modified z-score exceeded threshold {zscore_threshold}."
        payload[_anomaly_key(item)] = item
    return payload


def _build_golden_map(
    measurements: list[MeasurementRecord],
    golden_path: str | Path,
) -> dict[tuple[str, str, int, str], AnomalyResult]:
    payload = json.loads(Path(golden_path).read_text(encoding="utf-8"))
    reference = GoldenReference.from_dict(payload)
    return {_anomaly_key(item): item for item in evaluate_against_golden(measurements, reference)}


def _outlier_logical_metrics(
    measurements: list[MeasurementRecord],
    zscore_map: dict[tuple[str, str, int, str], AnomalyResult],
    golden_map: dict[tuple[str, str, int, str], AnomalyResult],
    outlier_fail_method: str,
) -> set[str]:
    outliers: set[str] = set()
    for item in measurements:
        key = _measurement_key(item)
        if _is_outlier(
            zscore_map.get(key),
            golden_map.get(key),
            outlier_fail_method=outlier_fail_method,
        ):
            outliers.add(item.logical_metric)
    return outliers


def _is_outlier(
    z_entry: AnomalyResult | None,
    golden_entry: AnomalyResult | None,
    outlier_fail_method: str,
) -> bool:
    z_failed = bool(z_entry and z_entry.reason)
    golden_failed = bool(golden_entry and golden_entry.reason)
    if outlier_fail_method == "golden_deviation":
        return golden_failed
    if outlier_fail_method == "zscore_and_golden":
        return z_failed and golden_failed
    if outlier_fail_method == "zscore_or_golden":
        return z_failed or golden_failed
    return z_failed


def _build_merged_outlier_index(
    template: TemplateConfig,
    measurements: list[MeasurementRecord],
    zscore_map: dict[tuple[str, str, int, str], AnomalyResult],
    golden_map: dict[tuple[str, str, int, str], AnomalyResult],
    outlier_fail_method: str,
) -> dict[PointMergeKey, _MergedOutlierInfo]:
    if not measurements:
        return {}
    try:
        rows = reporting._build_rows_from_measurements(measurements)
        columns = reporting._build_columns(
            template,
            {},
            sorted({item.raw_column for item in measurements}, key=_natural_key),
        )
        sample_node_orders = reporting._build_sample_node_orders(rows, template)
        rows.sort(key=lambda item: reporting._row_sort_key(item, template, sample_node_orders))
        leaf_records = reporting._build_leaf_records(
            template,
            columns,
            rows,
            _to_reporting_metric_values(zscore_map, score_field="score"),
            _to_reporting_metric_values(golden_map, score_field="value"),
            outlier_fail_method,
        )
        final_records = reporting._execute_outlier_merge_pipeline_from_records(
            template,
            reporting._merge_records_from_leaves(leaf_records),
        )
    except (KeyError, ValueError):
        return {}

    failing_leaf_keys = {
        _leaf_merge_key(leaf)
        for leaf in leaf_records
        if leaf.is_fail
    }
    index: dict[PointMergeKey, _MergedOutlierInfo] = {}
    for record in final_records:
        related_keys = tuple(
            sorted(
                (
                    (str(dataset_id), int(row_number), str(raw_column))
                    for dataset_id, row_number in record.raw_row_keys
                    for raw_column in record.raw_columns
                    if (str(dataset_id), int(row_number), str(raw_column)) in failing_leaf_keys
                ),
                key=lambda item: (_natural_key(item[0]), item[1], _natural_key(item[2])),
            )
        )
        if not related_keys:
            continue
        block_key = _merge_block_key(record.sample_key, record.node_value, record.column_key)
        info = _MergedOutlierInfo(
            merged_outlier=record.is_fail,
            merge_block_key=block_key,
            related_outlier_keys=related_keys,
        )
        for key in related_keys:
            existing = index.get(key)
            if existing is None or (info.merged_outlier and not existing.merged_outlier):
                index[key] = info
    return index


def _to_reporting_metric_values(
    anomaly_map: dict[tuple[str, str, int, str], AnomalyResult],
    *,
    score_field: str,
) -> dict[reporting.MetricKey, reporting.MetricValue]:
    values: dict[reporting.MetricKey, reporting.MetricValue] = {}
    for entry in anomaly_map.values():
        value = getattr(entry, score_field, None)
        values[(entry.dataset_id, entry.row_number, entry.raw_column)] = reporting.MetricValue(
            value=value,
            threshold=None,
            golden_value=entry.center,
            is_fail=bool(entry.reason),
        )
    return values


def _leaf_merge_key(leaf: reporting.LeafRecord) -> PointMergeKey:
    dataset_id, row_number = leaf.raw_row_key
    return (str(dataset_id), int(row_number), str(leaf.raw_column))


def _measurement_merge_key(item: MeasurementRecord) -> PointMergeKey:
    return (str(item.dataset_id), int(item.row_number), str(item.raw_column))


def _merge_block_key(
    sample_key: tuple[str, ...],
    node_value: str,
    column_key: tuple[str, ...],
) -> str:
    return " | ".join(
        [
            "/".join(str(value) for value in sample_key),
            str(node_value),
            "/".join(str(value) for value in column_key),
        ]
    )


def _allowed_range_tuples(golden_entry: AnomalyResult | None) -> tuple[tuple[float, float], ...]:
    if golden_entry is None:
        return ()
    ranges = tuple(
        (item.lower_bound, item.upper_bound)
        for item in golden_entry.allowed_ranges
    )
    if ranges:
        return ranges
    if golden_entry.lower_bound is not None and golden_entry.upper_bound is not None:
        return ((golden_entry.lower_bound, golden_entry.upper_bound),)
    return ()


def _measurement_key(item: MeasurementRecord) -> tuple[str, str, int, str]:
    return (item.dataset_id, item.source_file, item.row_number, item.raw_column)


def _anomaly_key(item: AnomalyResult) -> tuple[str, str, int, str]:
    return (item.dataset_id, item.source_file, item.row_number, item.raw_column)


def _lane_key(item: MeasurementRecord, lane_dimensions: tuple[str, ...]) -> tuple[tuple[str, str], ...]:
    if not lane_dimensions:
        return (("All", "All combined"),)
    return tuple((dimension, str(item.dimensions.get(dimension, "") or "")) for dimension in lane_dimensions)


def _lane_label(lane_key: tuple[tuple[str, str], ...]) -> str:
    return " | ".join(_lane_values(lane_key))


def _lane_values(lane_key: tuple[tuple[str, str], ...]) -> tuple[str, ...]:
    if lane_key == (("All", "All combined"),):
        return ("All combined",)
    return tuple(value or "(blank)" for _key, value in lane_key)


def _point_identity(item: MeasurementRecord) -> str:
    preferred_names = ("lot", "sample_id", "reliability_node", "site", "repeat_id")
    parts = [
        str(item.dimensions.get(name, "") or "")
        for name in preferred_names
        if item.dimensions.get(name)
    ]
    if parts:
        return " | ".join(parts)
    return f"{item.dataset_id}:{item.row_number}:{item.raw_column}"


def _measurement_sort_key(item: MeasurementRecord) -> tuple[object, ...]:
    return (
        tuple((key, _natural_key(value)) for key, value in sorted(item.dimensions.items())),
        item.row_number,
        _natural_key(item.raw_column),
    )


def _ordered_unique(values: Iterable[str]) -> tuple[str, ...]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        text = str(value or "").strip()
        if not text or text in seen:
            continue
        seen.add(text)
        ordered.append(text)
    return tuple(ordered)


def _natural_key(value: str) -> tuple[tuple[int, object], ...]:
    parts: list[tuple[int, object]] = []
    current = ""
    is_digit = False
    for char in str(value):
        char_is_digit = char.isdigit()
        if current and char_is_digit != is_digit:
            parts.append((0, int(current)) if is_digit else (1, current.lower()))
            current = char
        else:
            current += char
        is_digit = char_is_digit
    if current:
        parts.append((0, int(current)) if is_digit else (1, current.lower()))
    return tuple(parts)
