from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator
from uuid import uuid4

from .models import GoldenReference, MeasurementRecord
from .measurement_storage import MeasurementStorage
from .database_paths import database_root_for_storage, pack_source_path, restore_source_path
from .output_paths import resolve_output_path


class Repository:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.import_dir = self.root / "imports"
        self.golden_dir = self.root / "golden"
        self.measurement_storage = MeasurementStorage(self.root)
        self.measurements_path = self.measurement_storage.path
        self.datasets_path = self.root / "datasets.jsonl"
        self.root.mkdir(parents=True, exist_ok=True)
        self.import_dir.mkdir(parents=True, exist_ok=True)
        self.golden_dir.mkdir(parents=True, exist_ok=True)

    def new_dataset_id(self) -> str:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        return f"{stamp}-{uuid4().hex[:8]}"

    def save_import(
        self,
        dataset_id: str,
        source_file: str,
        template_name: str,
        measurements: Iterable[MeasurementRecord],
        metadata: dict[str, Any] | None = None,
    ) -> None:
        measurement_list = list(measurements)
        payload = {
            "dataset_id": dataset_id,
            "source_file": source_file,
            "template_name": template_name,
            "measurement_count": len(measurement_list),
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        if metadata:
            payload.update(metadata)
        self.measurement_storage.write(measurement_list, append=True)
        self.save_dataset_entry(payload)
        self.reconcile_dataset_entries()

    def save_dataset_entry(self, payload: dict[str, Any]) -> None:
        if "created_at_utc" not in payload:
            payload = dict(payload)
            payload["created_at_utc"] = datetime.now(timezone.utc).isoformat()
        with self.datasets_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(self._pack_dataset_entry(payload), ensure_ascii=False) + "\n")

    def load_measurements(self) -> list[MeasurementRecord]:
        return list(self.iter_measurements())

    def iter_measurements(self) -> Iterator[MeasurementRecord]:
        return self.measurement_storage.iter_records()

    def replace_measurements(self, measurements: Iterable[MeasurementRecord]) -> None:
        self.measurement_storage.write(measurements)
        self.reconcile_dataset_entries()

    def delete_measurements(
        self,
        row_selectors: Iterable[tuple[str, str, int]],
    ) -> int:
        selectors = {
            (str(dataset_id), str(source_file), int(row_number))
            for dataset_id, source_file, row_number in row_selectors
        }
        if not selectors:
            return 0
        measurements = self.load_measurements()
        kept_measurements = [
            item
            for item in measurements
            if (item.dataset_id, item.source_file, item.row_number) not in selectors
        ]
        deleted_count = len(measurements) - len(kept_measurements)
        if deleted_count:
            self.replace_measurements(kept_measurements)
        return deleted_count

    def load_dataset_entries(self) -> list[dict[str, Any]]:
        if not self.datasets_path.exists():
            return []
        entries: list[dict[str, Any]] = []
        with self.datasets_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                payload = json.loads(line)
                if "source_file" in payload:
                    payload["source_file"] = restore_source_path(payload, database_root_for_storage(self.root))
                    payload.pop("source_path_base", None)
                entries.append(payload)
        return entries

    def replace_dataset_entries(self, entries: Iterable[dict[str, Any]]) -> None:
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=self.root,
                                             prefix=".datasets-", suffix=".tmp", delete=False) as handle:
                temporary = Path(handle.name)
                for item in entries:
                    handle.write(json.dumps(self._pack_dataset_entry(item), ensure_ascii=False) + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.datasets_path)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)

    def copy_source_data_to(self, destination: Repository, source_path_map: Callable[[str], str]) -> None:
        self.measurement_storage.copy_to(destination.measurement_storage, source_path_map)
        if self.datasets_path.exists():
            entries = self.load_dataset_entries()
            for entry in entries:
                if "source_file" in entry:
                    entry["source_file"] = source_path_map(entry["source_file"])
            destination.replace_dataset_entries(entries)

    def _pack_dataset_entry(self, payload: dict[str, Any]) -> dict[str, Any]:
        packed = dict(payload)
        packed.pop("source_path_base", None)
        if "source_file" in packed:
            packed.update(pack_source_path(packed["source_file"], database_root_for_storage(self.root)))
        return packed

    def compact(self) -> None:
        self.measurement_storage.compact()
        if self.datasets_path.exists():
            self.replace_dataset_entries(self.load_dataset_entries())

    def reconcile_dataset_entries(self) -> None:
        measurement_counts = self.measurement_storage.counts()

        entries = self.load_dataset_entries()
        if not entries:
            return

        reconciled_entries: list[dict[str, Any]] = []
        for entry in entries:
            dataset_id = str(entry.get("dataset_id", "")).strip()
            if not dataset_id or dataset_id not in measurement_counts:
                continue
            updated_entry = dict(entry)
            updated_entry["measurement_count"] = measurement_counts[dataset_id]
            reconciled_entries.append(updated_entry)
        self.replace_dataset_entries(reconciled_entries)

    def save_golden(
        self,
        reference: GoldenReference,
        if_exists: str = "overwrite",
    ) -> Path:
        path = resolve_output_path(
            self.golden_dir / f"{reference.name}.json",
            if_exists=if_exists,
        )
        if path.stem != reference.name:
            reference.name = path.stem
        path.write_text(
            json.dumps(reference.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return path

    def load_golden(self, path: str | Path) -> GoldenReference:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        return GoldenReference.from_dict(payload)
