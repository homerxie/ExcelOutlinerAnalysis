"""Stable display ordering for names containing numbers, such as Chain2/Chain10."""

from functools import lru_cache
import re
from typing import Any


_NUMBER_PARTS = re.compile(r"(\d+)")


@lru_cache(maxsize=8192)
def _text_key(value: str) -> tuple:
    return tuple((0, int(part)) if part.isdecimal() else (1, part.casefold())
                 for part in _NUMBER_PARTS.split(value) if part)


def natural_sort_key(value: Any) -> tuple:
    """Compare numeric name parts by value without mixing strings and integers."""
    return _text_key("" if value is None else str(value))
