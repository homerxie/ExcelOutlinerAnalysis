"""Portable source references shared by database metadata and measurements."""
from __future__ import annotations

import os
from pathlib import Path


WORKSPACE_MARKER_FILENAME = ".database-workspace"


def database_root_for_storage(storage: str | Path) -> Path:
    root = Path(os.path.abspath(storage))
    # Only a marked temp workspace uses its parent. A user database is allowed
    # to be called 'temp', too. The marker is never copied into a saved database.
    if (root / WORKSPACE_MARKER_FILENAME).is_file():
        return root.parent
    return root


def pack_source_path(source_file: str, database_root: Path) -> dict[str, str]:
    path = Path(source_file)
    if path.is_absolute():
        try:
            return {
                "source_file": Path(os.path.relpath(path, database_root)).as_posix(),
                "source_path_base": "database",
            }
        except ValueError:  # Windows volumes may differ.
            pass
    # Older callers may pass a literal relative path or a foreign-platform path.
    # Preserve it rather than guessing where the original file lived.
    return {"source_file": source_file}


def restore_source_path(payload: dict, database_root: Path) -> str:
    if payload.get("source_path_base") == "database":
        return os.path.abspath(database_root / payload["source_file"])
    if payload.get("source_path_base") is not None:
        raise ValueError("Unsupported source path base")
    return payload["source_file"]
