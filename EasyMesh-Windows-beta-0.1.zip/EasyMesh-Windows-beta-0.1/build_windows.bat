@echo off
setlocal
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "EASYMESH_ROOT=%~dp0"
if exist "%EASYMESH_ROOT%EasyMesh.spec" goto root_found
set "EASYMESH_ROOT=%~dp0..\..\"
if not exist "%EASYMESH_ROOT%EasyMesh.spec" goto missing_source
:root_found
cd /d "%EASYMESH_ROOT%"
if not exist "src\easymesh\entrypoint.py" goto missing_source
if not exist "run_demo.py" goto missing_source
if not exist "requirements-build.txt" goto missing_source
if not exist "packaging\windows\hook-gmsh.py" goto missing_source

rem Use a separate environment so source installs cannot affect EXE builds.
if exist ".venv-build\Scripts\python.exe" goto install
py -3.12 -c "import platform, struct; assert struct.calcsize('P') == 8 and platform.machine().lower() in ('amd64', 'x86_64')" >nul 2>&1
if not errorlevel 1 goto python312
py -3.10 -c "import platform, struct; assert struct.calcsize('P') == 8 and platform.machine().lower() in ('amd64', 'x86_64')" >nul 2>&1
if not errorlevel 1 goto python310
python -c "import platform, struct, sys; assert sys.version_info >= (3, 10) and struct.calcsize('P') == 8 and platform.machine().lower() in ('amd64', 'x86_64')" >nul 2>&1
if errorlevel 1 goto missing_python
python -m venv .venv-build
goto venv_ready
:python312
py -3.12 -m venv .venv-build
goto venv_ready
:python310
py -3.10 -m venv .venv-build
:venv_ready
if errorlevel 1 goto failed
if not exist ".venv-build\Scripts\python.exe" goto failed
:install
".venv-build\Scripts\python.exe" -c "import platform, struct, sys; assert sys.platform == 'win32' and sys.version_info >= (3, 10), 'Windows Python 3.10+ required'; assert struct.calcsize('P') == 8 and platform.machine().lower() in ('amd64', 'x86_64'), 'x86-64 Python required'"
if errorlevel 1 goto failed
".venv-build\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed
".venv-build\Scripts\python.exe" -m pip install --only-binary=:all: -r requirements-build.txt
if errorlevel 1 goto failed
".venv-build\Scripts\python.exe" -m pip check
if errorlevel 1 goto failed
".venv-build\Scripts\python.exe" -m PyInstaller --clean --noconfirm EasyMesh.spec
if errorlevel 1 goto failed
if not exist "dist\EasyMesh\EasyMesh.exe" goto failed
if not exist "dist\EasyMesh\EasyMesh-worker.exe" goto failed
if not exist "dist\EasyMesh\_internal\gmsh-4.15.dll" goto failed
rem Verify the console worker boots and preserves its pipe output.
"dist\EasyMesh\EasyMesh-worker.exe" --help >"build\worker-help.txt" 2>&1
if errorlevel 1 goto failed
findstr /c:"--package-v2-job" "build\worker-help.txt" >nul
if errorlevel 1 goto failed
set "PYTHONPATH=%CD%\src"
".venv-build\Scripts\python.exe" scripts\check_windows_runtime.py --worker-executable dist\EasyMesh\EasyMesh-worker.exe
if errorlevel 1 goto failed
echo.
echo Build complete: dist\EasyMesh\EasyMesh.exe
echo Version: beta 0.1
echo Distribute the ENTIRE dist\EasyMesh folder, including the worker and _internal.
echo Check GUI startup, 3D preview, and mesh generation on a Windows test machine.
pause
exit /b 0
:missing_python
echo Install x86-64 Python 3.12 with the Python launcher or Add Python to PATH.
echo Python 3.10 x64 is also supported.
pause
exit /b 1
:missing_source
echo Cannot find the complete EasyMesh source package beside this build script.
echo Extract the full ZIP before running build_windows.bat.
pause
exit /b 1
:failed
echo.
echo Build failed. Review the error above and build\worker-help.txt if present.
pause
exit /b 1
