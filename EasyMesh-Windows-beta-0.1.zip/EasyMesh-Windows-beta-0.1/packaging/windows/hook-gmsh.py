"""Collect Gmsh's ctypes DLL and fail the build when it cannot be loaded."""

from pathlib import Path

from PyInstaller.compat import is_win
from PyInstaller.utils.hooks import get_module_attribute

# Import in PyInstaller's isolated subprocess: gmsh's own discovery logic knows
# the wheel's DLL location, which is outside a conventional Python package.
try:
    library_path = get_module_attribute("gmsh", "libpath")
except Exception as error:
    raise RuntimeError(
        "Cannot load Gmsh. Install requirements-build.txt in the build environment."
    ) from error

if not library_path or not Path(library_path).is_file():
    raise RuntimeError(f"Gmsh shared library does not exist: {library_path!r}")
if is_win and Path(library_path).name.lower() != "gmsh-4.15.dll":
    raise RuntimeError(
        f"Expected gmsh-4.15.dll from gmsh==4.15.2, found {library_path!r}."
    )

# gmsh.py searches beside its bundled __file__; "." becomes _internal in onedir.
binaries = [(str(Path(library_path).resolve()), ".")]
