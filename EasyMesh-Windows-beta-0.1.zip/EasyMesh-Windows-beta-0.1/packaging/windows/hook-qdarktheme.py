"""Include themes and resources for pyqtdarktheme and pyqtdarktheme-fork."""

from PyInstaller.utils.hooks import collect_data_files, collect_submodules

datas = collect_data_files("qdarktheme")
hiddenimports = collect_submodules(
    "qdarktheme",
    filter=lambda name: not name.startswith("qdarktheme.widget_gallery"),
)
