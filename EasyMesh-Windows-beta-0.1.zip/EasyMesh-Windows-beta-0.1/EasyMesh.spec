# -*- mode: python ; coding: utf-8 -*-
"""Build on Windows x64: python -m PyInstaller --clean EasyMesh.spec.

The GUI and console worker share the same Analysis/PYZ and onedir dependencies.
Keep the entire dist/EasyMesh directory when distributing the application.
"""

from pathlib import Path
import platform
import struct
import sys

if sys.platform != "win32":
    raise SystemExit("Build EasyMesh.exe on Windows; PyInstaller is not a cross-compiler.")
if struct.calcsize("P") != 8 or platform.machine().lower() not in {"amd64", "x86_64"}:
    raise SystemExit("Use x86-64 Python on Windows (Python 3.12 recommended).")

from PyInstaller.utils.win32.versioninfo import (
    FixedFileInfo,
    StringFileInfo,
    StringStruct,
    StringTable,
    VarFileInfo,
    VarStruct,
    VSVersionInfo,
)

ROOT = Path(SPECPATH).resolve()
HOOKS = ROOT / "packaging" / "windows"


def version_info(executable_name):
    return VSVersionInfo(
        ffi=FixedFileInfo(
            filevers=(0, 1, 0, 1),
            prodvers=(0, 1, 0, 1),
            mask=0x3F,
            flags=0x02,  # VS_FF_PRERELEASE
            OS=0x40004,
            fileType=0x01,
            subtype=0,
            date=(0, 0),
        ),
        kids=[
            StringFileInfo([
                StringTable("040904B0", [
                    StringStruct("FileDescription", "EasyMesh beta 0.1"),
                    StringStruct("FileVersion", "0.1.0b1"),
                    StringStruct("InternalName", executable_name),
                    StringStruct("OriginalFilename", executable_name + ".exe"),
                    StringStruct("ProductName", "EasyMesh"),
                    StringStruct("ProductVersion", "beta 0.1"),
                ])
            ]),
            VarFileInfo([VarStruct("Translation", [0x0409, 1200])]),
        ],
    )


a = Analysis(
    [str(ROOT / "run_demo.py")],
    pathex=[str(ROOT / "src")],
    binaries=[],
    datas=[(str(ROOT / "src" / "easymesh" / "resources"), "easymesh/resources")],
    hiddenimports=[
        "gmsh",
        "qdarktheme",
        # QtQml's official hook collects the QML tree and native QML plugins.
        # QtQuick3D is also imported by QML, so retain it explicitly.
        "PySide6.QtQml",
        "PySide6.QtQuick",
        "PySide6.QtQuick3D",
        "PySide6.QtQuickWidgets",
        "PySide6.QtSvg",
    ],
    hookspath=[str(HOOKS)],
    hooksconfig={},
    runtime_hooks=[],
    # qdarktheme supports these bindings, but this application uses PySide6.
    excludes=["PyQt5", "PyQt6", "PySide2"],
    noarchive=False,
)
pyz = PYZ(a.pure)

gui = EXE(
    pyz,
    a.scripts,
    [("X utf8", None, "OPTION")],
    exclude_binaries=True,
    name="EasyMesh",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    contents_directory="_internal",
    version=version_info("EasyMesh"),
)
worker = EXE(
    pyz,
    a.scripts,
    [
        ("X utf8", None, "OPTION"),
        ("u", None, "OPTION"),  # Flush worker progress and JSON output promptly.
    ],
    exclude_binaries=True,
    name="EasyMesh-worker",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=True,  # QProcess/subprocess must receive real stdout and stderr.
    contents_directory="_internal",
    version=version_info("EasyMesh-worker"),
)
coll = COLLECT(
    gui,
    worker,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="EasyMesh",
)
