"""Bounded, job-bound progress records in the CDB worker's ordinary log."""

from __future__ import annotations

import json
import os
import re
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, TextIO


PROGRESS_PREFIX = "EASYMESH_CDB_PROGRESS "
_MAX_RECORD_BYTES = 8192
_MAX_POLL_BYTES = 1024 * 1024
_MESSAGE_STAGE = re.compile(r"\s+(?=[0-9])|：")


@dataclass(frozen=True)
class CdbProgressEvent:
    percent: int | None
    message: str


def parse_cdb_progress(line: str, job_id: str) -> CdbProgressEvent | None:
    if not line.startswith(PROGRESS_PREFIX) or len(line) > _MAX_RECORD_BYTES:
        return None
    try:
        data = json.loads(line[len(PROGRESS_PREFIX):])
    except (ValueError, TypeError):
        return None
    if not isinstance(data, dict) or data.get("job_id") != job_id or "percent" not in data:
        return None
    percent, message = data.get("percent"), data.get("message")
    if percent is not None and (type(percent) is not int or not 0 <= percent <= 100):
        return None
    if not isinstance(message, str) or not message.strip() or len(message) > 512:
        return None
    return CdbProgressEvent(percent, message.strip())


def cdb_progress_reporter(
    job_id: str | None, *, stream: TextIO | None = None,
) -> Callable[[int | None, str], None]:
    """Flush stage changes and bounded count updates through redirected logs."""
    target = sys.stdout if stream is None else stream
    last: tuple[int | None, str] | None = None
    emitted_at = 0.0

    def report(percent: int | None, message: str) -> None:
        nonlocal last, emitted_at
        if isinstance(message, str) and len(message) > 512:
            message = message[:511] + "…"
        data = {"job_id": job_id or "standalone", "percent": percent, "message": message}
        line = PROGRESS_PREFIX + json.dumps(data, ensure_ascii=False, separators=(",", ":"))
        if parse_cdb_progress(line, data["job_id"]) is None:
            raise ValueError("invalid CDB progress record")
        # Large meshes can report thousands of chunks within one percentage.
        # Keep stage/percentage transitions and at most five count updates per
        # second; strip the conventional trailing count/details for stage keys.
        stage = _MESSAGE_STAGE.split(message, maxsplit=1)[0]
        now = time.monotonic()
        if last == (percent, stage) and percent != 100 and now - emitted_at < 0.2:
            return
        print(line, file=target, flush=True)
        last, emitted_at = (percent, stage), now

    return report


@dataclass
class CdbProgressRun:
    job_id: str
    started: float = field(default_factory=time.monotonic)
    percent: int | None = None
    message: str = "正在启动 CDB 转换…"
    completed: bool = False
    offset: int = 0
    pending: bytes = b""
    file_identity: tuple[int, int] | None = None
    discarding_line: bool = False

    def read(self, path: Path) -> list[CdbProgressEvent]:
        """Tail bounded chunks and preserve split UTF-8 and JSON across polls."""
        try:
            with path.open("rb") as stream:
                info = os.fstat(stream.fileno())
                identity = (info.st_dev, info.st_ino)
                if self.file_identity != identity or info.st_size < self.offset:
                    self.offset, self.pending, self.discarding_line = 0, b"", False
                self.file_identity = identity
                stream.seek(self.offset)
                chunk = stream.read(_MAX_POLL_BYTES)
                self.offset += len(chunk)
        except OSError:
            return []
        lines = (self.pending + chunk).split(b"\n")
        self.pending = lines.pop()
        events = []
        for raw in lines:
            if self.discarding_line:
                self.discarding_line = False
                continue
            if len(raw) > _MAX_RECORD_BYTES:
                continue
            event = parse_cdb_progress(raw.decode("utf-8", errors="replace"), self.job_id)
            if event is not None:
                events.append(event)
        if len(self.pending) > _MAX_RECORD_BYTES:
            self.pending = b""
            self.discarding_line = True
        return events
