# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'draft_geometry_preview.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLabel, QSizePolicy, QVBoxLayout,
    QWidget)

from easymesh.package_v2_preview_3d import CompactPackageV2Preview3D

class Ui_DraftGeometryPreviewForm(object):
    def setupUi(self, DraftGeometryPreviewForm):
        if not DraftGeometryPreviewForm.objectName():
            DraftGeometryPreviewForm.setObjectName(u"DraftGeometryPreviewForm")
        self.root_layout = QVBoxLayout(DraftGeometryPreviewForm)
        self.root_layout.setObjectName(u"root_layout")
        self.root_layout.setContentsMargins(0, 0, 0, 0)
        self.caption_label = QLabel(DraftGeometryPreviewForm)
        self.caption_label.setObjectName(u"caption_label")
        self.caption_label.setWordWrap(True)
        self.caption_label.setTextFormat(Qt.PlainText)

        self.root_layout.addWidget(self.caption_label)

        self.preview = CompactPackageV2Preview3D(DraftGeometryPreviewForm)
        self.preview.setObjectName(u"preview")

        self.root_layout.addWidget(self.preview)

        self.status_label = QLabel(DraftGeometryPreviewForm)
        self.status_label.setObjectName(u"status_label")
        self.status_label.setWordWrap(True)
        self.status_label.setTextFormat(Qt.PlainText)

        self.root_layout.addWidget(self.status_label)

        self.root_layout.setStretch(1, 1)

        self.retranslateUi(DraftGeometryPreviewForm)

        QMetaObject.connectSlotsByName(DraftGeometryPreviewForm)
    # setupUi

    def retranslateUi(self, DraftGeometryPreviewForm):
        self.caption_label.setText("")
        self.status_label.setText("")
        pass
    # retranslateUi
