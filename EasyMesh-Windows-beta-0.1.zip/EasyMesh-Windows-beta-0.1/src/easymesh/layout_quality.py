"""Bounded process parallelism for read-only layout element quality checks.

The caller alone reads its Gmsh model. Each spawned worker receives only one
small cell block with locally numbered nodes and owns a separate Gmsh runtime.
"""

from __future__ import annotations

from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
import multiprocessing
from multiprocessing.connection import wait as wait_for_process
import os
import threading
from typing import Any, Iterator, Sequence

import numpy as np


QUALITY_NAMES = ("minSJ", "minSICN", "minSIGE", "minDetJac")
_MAX_WORKERS = 4
_MAX_CHUNK_SIZE = 65_536
_NODE_INDEX_CHUNK = 65_536


def _exit_when_parent_stops(parent_sentinel: int) -> None:
    # The GUI may forcibly terminate its generating CLI process. Pool workers
    # must not remain blocked on their task queue after their owner disappears.
    wait_for_process([parent_sentinel])
    os._exit(1)


def _initialize_quality_worker() -> None:
    parent = multiprocessing.parent_process()
    if parent is not None:
        threading.Thread(
            target=_exit_when_parent_stops, args=(parent.sentinel,),
            name="easymesh-quality-parent-watch", daemon=True,
        ).start()
    import gmsh

    gmsh.initialize(interruptible=False)
    gmsh.option.setNumber("General.Terminal", 0)
    # Process-level parallelism owns the CPU budget; do not nest native pools.
    gmsh.option.setNumber("General.NumThreads", 1)


def _evaluate_quality_chunk(
    element_type: int,
    coordinates: np.ndarray,
    connectivity: np.ndarray,
) -> tuple[np.ndarray, ...]:
    import gmsh

    gmsh.model.add("__easymesh_quality_chunk")
    try:
        entity = gmsh.model.addDiscreteEntity(3, 1)
        tags = np.arange(1, len(connectivity) + 1, dtype=np.uintp)
        gmsh.model.mesh.addNodes(
            3, entity, np.arange(1, len(coordinates) + 1, dtype=np.uintp),
            coordinates.ravel(),
        )
        gmsh.model.mesh.addElementsByType(
            entity, element_type, tags, connectivity.ravel(),
        )
        results = []
        for name in QUALITY_NAMES:
            values = np.asarray(
                gmsh.model.mesh.getElementQualities(tags, name), dtype=np.float64,
            )
            if values.ndim != 1 or len(values) != len(tags):
                raise RuntimeError("Gmsh returned incomplete element quality values")
            if not np.isfinite(values).all():
                raise RuntimeError(f"Gmsh returned a non-finite {name} value")
            results.append(values)
        return tuple(results)
    finally:
        gmsh.model.remove()


def iter_element_quality_chunks(
    gmsh: Any,
    element_types: Sequence[int],
    element_tag_blocks: Sequence[np.ndarray],
    connectivity_blocks: Sequence[np.ndarray],
    *,
    workers: int,
    chunk_size: int = 32_768,
) -> Iterator[tuple[np.ndarray, tuple[np.ndarray, ...]]]:
    """Yield original EIDs and four full quality arrays in completion order.

    Arrays in each result follow its EID order and ``QUALITY_NAMES`` order.
    The input blocks are the already-read result of ``getElements(3)``. At most
    four tasks are outstanding, each containing at most 65,536 cells. Worker
    errors propagate; callers retain their existing atomic publication policy.
    """

    if isinstance(workers, bool) or not isinstance(workers, int) or workers < 1:
        raise ValueError("quality workers must be a positive integer")
    if (isinstance(chunk_size, bool) or not isinstance(chunk_size, int)
            or not 1 <= chunk_size <= _MAX_CHUNK_SIZE):
        raise ValueError(f"quality chunk_size must be in 1..{_MAX_CHUNK_SIZE}")
    if not (len(element_types) == len(element_tag_blocks) == len(connectivity_blocks)):
        raise ValueError("quality element blocks have inconsistent lengths")

    blocks = []
    for kind, tags, connectivity in zip(
        element_types, element_tag_blocks, connectivity_blocks, strict=True,
    ):
        arity = {5: 8, 6: 6}.get(int(kind))
        if arity is None:
            raise ValueError("layout quality only supports HEX8/WEDGE6 cells")
        tags = np.asarray(tags, dtype=np.uintp)
        connectivity = np.asarray(connectivity, dtype=np.uintp)
        if tags.ndim != 1 or connectivity.ndim != 1 or connectivity.size != tags.size * arity:
            raise ValueError("quality element block has malformed connectivity")
        blocks.append((int(kind), tags, connectivity.reshape(-1, arity)))
    if not any(len(tags) for _, tags, _ in blocks):
        return

    node_tags, coordinates, _ = gmsh.model.mesh.getNodes()
    node_tags = np.asarray(node_tags, dtype=np.uintp)
    coordinates = np.asarray(coordinates, dtype=np.float64)
    if node_tags.ndim != 1 or coordinates.size != 3 * len(node_tags) or not len(node_tags):
        raise RuntimeError("Gmsh returned incomplete node coordinates")
    coordinates = coordinates.reshape(-1, 3)
    # Dense layout IDs need one integer lookup array. Imported sparse tags use
    # sorted IDs plus row indices; never allocate up to an unbounded tag value.
    maximum_tag = int(node_tags.max())
    dense_index = None
    sorted_tags = order = None
    if maximum_tag <= 2 * len(node_tags):
        dense_index = np.full(maximum_tag + 1, -1, dtype=np.intp)
        for start in range(0, len(node_tags), _NODE_INDEX_CHUNK):
            end = min(len(node_tags), start + _NODE_INDEX_CHUNK)
            dense_index[node_tags[start:end]] = np.arange(start, end, dtype=np.intp)
    else:
        order = np.argsort(node_tags)
        sorted_tags = node_tags[order]

    def tasks():
        for kind, tags, connectivity in blocks:
            for start in range(0, len(tags), chunk_size):
                end = min(len(tags), start + chunk_size)
                unique_nodes, inverse = np.unique(
                    connectivity[start:end], return_inverse=True,
                )
                if dense_index is not None:
                    if int(unique_nodes[-1]) > maximum_tag:
                        raise RuntimeError("element connectivity references a missing node")
                    rows = dense_index[unique_nodes]
                    if (rows < 0).any():
                        raise RuntimeError("element connectivity references a missing node")
                else:
                    positions = np.searchsorted(sorted_tags, unique_nodes)
                    if ((positions >= len(node_tags)).any()
                            or not np.array_equal(sorted_tags[positions], unique_nodes)):
                        raise RuntimeError("element connectivity references a missing node")
                    rows = order[positions]
                yield (
                    tags[start:end], kind, coordinates[rows],
                    (inverse.reshape(end - start, connectivity.shape[1]) + 1).astype(np.uintp),
                )

    worker_count = min(workers, _MAX_WORKERS, os.cpu_count() or 1)
    task_iterator = iter(tasks())
    with ProcessPoolExecutor(
        max_workers=worker_count,
        mp_context=multiprocessing.get_context("spawn"),
        initializer=_initialize_quality_worker,
    ) as executor:
        pending = {}

        def submit_next() -> bool:
            task = next(task_iterator, None)
            if task is None:
                return False
            tags, kind, xyz, connectivity = task
            future = executor.submit(_evaluate_quality_chunk, kind, xyz, connectivity)
            pending[future] = tags
            return True

        try:
            for _ in range(worker_count):
                if not submit_next():
                    break
            while pending:
                completed, _ = wait(pending, return_when=FIRST_COMPLETED)
                for future in completed:
                    tags = pending.pop(future)
                    values = future.result()
                    # Queue the replacement only after the consumer handles the
                    # previous block, keeping tasks and result memory bounded.
                    yield tags, values
                    submit_next()
        finally:
            for future in pending:
                future.cancel()


__all__ = ["QUALITY_NAMES", "iter_element_quality_chunks"]
