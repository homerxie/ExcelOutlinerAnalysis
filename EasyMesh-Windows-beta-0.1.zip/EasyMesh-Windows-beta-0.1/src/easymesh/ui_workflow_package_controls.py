# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'workflow_package_controls.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QMenu, QPushButton,
    QSizePolicy, QSpacerItem, QToolButton, QWidget)

class Ui_WorkflowPackageControls(object):
    def setupUi(self, WorkflowPackageControls):
        if not WorkflowPackageControls.objectName():
            WorkflowPackageControls.setObjectName(u"WorkflowPackageControls")
        self.job_browse_action = QAction(WorkflowPackageControls)
        self.job_browse_action.setObjectName(u"job_browse_action")
        self.job_create_action = QAction(WorkflowPackageControls)
        self.job_create_action.setObjectName(u"job_create_action")
        self.job_inspect_action = QAction(WorkflowPackageControls)
        self.job_inspect_action.setObjectName(u"job_inspect_action")
        self.job_execute_action = QAction(WorkflowPackageControls)
        self.job_execute_action.setObjectName(u"job_execute_action")
        self.open_mesh_action = QAction(WorkflowPackageControls)
        self.open_mesh_action.setObjectName(u"open_mesh_action")
        self.show_details_action = QAction(WorkflowPackageControls)
        self.show_details_action.setObjectName(u"show_details_action")
        self.show_details_action.setCheckable(True)
        self.copy_instance_action = QAction(WorkflowPackageControls)
        self.copy_instance_action.setObjectName(u"copy_instance_action")
        self.delete_instance_action = QAction(WorkflowPackageControls)
        self.delete_instance_action.setObjectName(u"delete_instance_action")
        self.create_template_action = QAction(WorkflowPackageControls)
        self.create_template_action.setObjectName(u"create_template_action")
        self.edit_template_action = QAction(WorkflowPackageControls)
        self.edit_template_action.setObjectName(u"edit_template_action")
        self.import_template_action = QAction(WorkflowPackageControls)
        self.import_template_action.setObjectName(u"import_template_action")
        self.export_template_action = QAction(WorkflowPackageControls)
        self.export_template_action.setObjectName(u"export_template_action")
        self.delete_component_action = QAction(WorkflowPackageControls)
        self.delete_component_action.setObjectName(u"delete_component_action")
        self.geometry_more_button = QToolButton(WorkflowPackageControls)
        self.geometry_more_button.setObjectName(u"geometry_more_button")
        self.geometry_more_button.setPopupMode(QToolButton.InstantPopup)
        self.more_menu = QMenu(WorkflowPackageControls)
        self.more_menu.setObjectName(u"more_menu")
        self.geometry_menu = QMenu(WorkflowPackageControls)
        self.geometry_menu.setObjectName(u"geometry_menu")
        self.actions_layout = QHBoxLayout(WorkflowPackageControls)
        self.actions_layout.setObjectName(u"actions_layout")
        self.actions_layout.setContentsMargins(0, 0, 0, 0)
        self.resources_button = QPushButton(WorkflowPackageControls)
        self.resources_button.setObjectName(u"resources_button")
        self.resources_button.setAutoDefault(False)

        self.actions_layout.addWidget(self.resources_button)

        self.generate_button = QPushButton(WorkflowPackageControls)
        self.generate_button.setObjectName(u"generate_button")
        self.generate_button.setAutoDefault(False)

        self.actions_layout.addWidget(self.generate_button)

        self.cdb_button = QPushButton(WorkflowPackageControls)
        self.cdb_button.setObjectName(u"cdb_button")
        self.cdb_button.setAutoDefault(False)
        self.cdb_button.setEnabled(False)

        self.actions_layout.addWidget(self.cdb_button)

        self.more_button = QToolButton(WorkflowPackageControls)
        self.more_button.setObjectName(u"more_button")
        self.more_button.setPopupMode(QToolButton.InstantPopup)

        self.actions_layout.addWidget(self.more_button)

        self.actions_spacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.actions_layout.addItem(self.actions_spacer)


        self.more_menu.addAction(self.job_browse_action)
        self.more_menu.addAction(self.job_create_action)
        self.more_menu.addAction(self.job_inspect_action)
        self.more_menu.addAction(self.job_execute_action)
        self.more_menu.addAction(self.open_mesh_action)
        self.more_menu.addSeparator()
        self.more_menu.addAction(self.show_details_action)
        self.geometry_menu.addAction(self.copy_instance_action)
        self.geometry_menu.addAction(self.delete_instance_action)
        self.geometry_menu.addSeparator()
        self.geometry_menu.addAction(self.create_template_action)
        self.geometry_menu.addAction(self.edit_template_action)
        self.geometry_menu.addAction(self.import_template_action)
        self.geometry_menu.addAction(self.export_template_action)
        self.geometry_menu.addSeparator()
        self.geometry_menu.addAction(self.delete_component_action)

        self.retranslateUi(WorkflowPackageControls)

        QMetaObject.connectSlotsByName(WorkflowPackageControls)
    # setupUi

    def retranslateUi(self, WorkflowPackageControls):
        self.job_browse_action.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u6253\u5f00\u4efb\u52a1\u6587\u4ef6", None))
        self.job_create_action.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u521b\u5efa\u4efb\u52a1\u6587\u4ef6", None))
        self.job_inspect_action.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u68c0\u67e5\u4efb\u52a1", None))
        self.job_execute_action.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u6267\u884c\u5df2\u7ed1\u5b9a\u4efb\u52a1", None))
        self.open_mesh_action.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u6253\u5f00\u7f51\u683c\u9884\u89c8", None))
        self.show_details_action.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u663e\u793a\u4efb\u52a1\u7ec6\u8282", None))
        self.copy_instance_action.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u590d\u5236\u5b9e\u4f8b", None))
        self.delete_instance_action.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u5220\u9664\u5b9e\u4f8b", None))
        self.create_template_action.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u521b\u5efa\u6a21\u677f", None))
        self.edit_template_action.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u7f16\u8f91\u6a21\u677f", None))
        self.import_template_action.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u5bfc\u5165\u6a21\u677f", None))
        self.export_template_action.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u5bfc\u51fa\u6a21\u677f", None))
        self.delete_component_action.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u5220\u9664 Component", None))
        self.geometry_more_button.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u66f4\u591a", None))
        self.resources_button.setText(QCoreApplication.translate("WorkflowPackageControls", u"Connected Bumps \u5e93", None))
        self.generate_button.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u751f\u6210\u7f51\u683c", None))
        self.generate_button.setProperty(u"appearance", QCoreApplication.translate("WorkflowPackageControls", u"primary", None))
        self.cdb_button.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u5bfc\u51fa CDB", None))
        self.more_button.setText(QCoreApplication.translate("WorkflowPackageControls", u"\u66f4\u591a", None))
        pass
    # retranslateUi
