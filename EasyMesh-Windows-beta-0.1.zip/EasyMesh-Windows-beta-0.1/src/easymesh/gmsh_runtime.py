"""Shared, non-destructive access to Gmsh's process-global Python runtime."""

from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
import threading
import uuid
from typing import Any, Iterator, Mapping


GMSH_LOCK = threading.RLock()

_SYSTEM_VOLUME_GROUPS = {
    "ALL_SOLID_VOLUMES",
    "TRANSITION_SOLID_VOLUMES",
}
_SYSTEM_VOLUME_PREFIXES = (
    "BUMP_",
    "COMPONENT_",
    "HM_",
    "TEMPLATE_",
    "TRANSITION_",
)
_MATERIAL_PALETTE = (
    (226, 93, 93),
    (244, 162, 97),
    (233, 196, 106),
    (42, 157, 143),
    (69, 123, 157),
    (106, 76, 147),
)


def _load_gmsh() -> Any:
    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:  # pragma: no cover - dependency failure
        raise RuntimeError("Gmsh is required to preview a mesh") from error
    return gmsh


def _finalize_owned_gmsh(gmsh: Any) -> None:
    """Avoid restoring an old Python signal handler from a background thread.

    Gmsh 4.15 retains ``prev_interrupt_handler`` even after finalize restores
    it. A later non-interruptible session must not restore that stale handler
    on a worker thread. This helper runs only while holding ``GMSH_LOCK``.
    """
    previous_handler = getattr(gmsh, "prev_interrupt_handler", None)
    if threading.current_thread() is threading.main_thread() or previous_handler is None:
        gmsh.finalize()
        return
    gmsh.prev_interrupt_handler = None
    try:
        gmsh.finalize()
    finally:
        gmsh.prev_interrupt_handler = previous_handler


def _apply_material_palette(gmsh: Any) -> None:
    """Restore one stable color per material after reopening an MSH file.

    MSH 4.1 stores Physical Group membership but not the entity colors assigned
    by the builder.  Gmsh otherwise falls back to its entity-tag color carousel,
    which can make template and transition entities in one material look like
    different materials (especially during interactive element picking).
    """

    model = getattr(gmsh, "model", None)
    if model is None:
        return
    material_groups: list[tuple[str, tuple[int, ...]]] = []
    for dimension, physical_tag in model.getPhysicalGroups(3):
        if int(dimension) != 3:
            continue
        name = str(model.getPhysicalName(3, int(physical_tag)))
        normalized = name.upper()
        if (
            not name
            or normalized in _SYSTEM_VOLUME_GROUPS
            or normalized.startswith(_SYSTEM_VOLUME_PREFIXES)
        ):
            continue
        entities = tuple(
            int(tag)
            for tag in model.getEntitiesForPhysicalGroup(3, int(physical_tag))
        )
        if entities:
            material_groups.append((name, entities))
    for index, (_name, entities) in enumerate(sorted(material_groups)):
        model.setColor(
            [(3, entity_tag) for entity_tag in entities],
            *_MATERIAL_PALETTE[index % len(_MATERIAL_PALETTE)],
            255,
        )


def preview_mesh_file(
    mesh_path: str | Path,
    *,
    verbose: bool = False,
) -> None:
    """Open an already-published mesh in Gmsh's read-only FLTK viewer.

    Preview deliberately runs in a fresh Gmsh session after a builder has
    published its complete artifact bundle.  Consequently the interactive
    FLTK window never keeps an output lock held.  The mesh is only reopened;
    this helper does not write it or any companion artifacts.
    """

    published_mesh = Path(mesh_path).expanduser().resolve()
    if not published_mesh.is_file():
        raise FileNotFoundError(f"published mesh does not exist: {published_mesh}")

    gmsh = _load_gmsh()
    with GMSH_LOCK:
        if bool(gmsh.isInitialized()):
            raise RuntimeError(
                "mesh preview requires a fresh Gmsh session; "
                "finalize the existing session first"
            )

        initialized = False
        try:
            gmsh.initialize()
            initialized = True
            gmsh.option.setNumber("General.Terminal", 1 if verbose else 0)
            # The GUI launches this viewer in its worker process. Show the
            # native window before the potentially long MSH read, rather than
            # keeping it invisible until loading and first rendering finish.
            # FLTK and model reads stay on this process's main thread: moving
            # gmsh.open to a Python thread would race native model/render state.
            gmsh.fltk.initialize()
            loading = (f"Loading {published_mesh.name} "
                       f"({published_mesh.stat().st_size / (1024 * 1024):,.0f} MiB)...")
            gmsh.fltk.setStatusMessage(loading, True)
            gmsh.fltk.update()
            gmsh.fltk.wait(0)
            gmsh.open(str(published_mesh))
            _apply_material_palette(gmsh)
            gmsh.option.setNumber("Mesh.VolumeEdges", 1)
            gmsh.option.setNumber("Mesh.VolumeFaces", 1)
            gmsh.option.setNumber("General.Axes", 1)
            gmsh.fltk.setStatusMessage("", True)
            gmsh.fltk.setStatusMessage(f"Loaded {published_mesh.name}")
            gmsh.fltk.run()
        finally:
            if initialized and bool(gmsh.isInitialized()):
                gmsh.finalize()


@contextmanager
def isolated_gmsh_model(
    gmsh: Any,
    prefix: str,
    *,
    number_options: Mapping[str, float] | None = None,
) -> Iterator[str]:
    """Yield a unique current model without damaging an existing Gmsh session.

    Gmsh's Python API is process-global.  This context serializes access, owns
    initialization only when necessary, restores the caller's current model
    and numeric options, and removes the temporary model on exit.
    """

    options = dict(number_options or {})
    with GMSH_LOCK:
        owns_gmsh = not bool(gmsh.isInitialized())
        previous_model = ""
        previous_options: dict[str, float] = {}
        model_name = f"{prefix}_{uuid.uuid4().hex}"
        try:
            if owns_gmsh:
                if threading.current_thread() is threading.main_thread():
                    gmsh.initialize()
                else:
                    # Python signal handlers can only be installed on the
                    # main thread. Background readers still own/finalize the
                    # same serialized Gmsh session, without a SIGINT handler.
                    gmsh.initialize(interruptible=False)
            else:
                previous_model = str(gmsh.model.getCurrent())
                previous_options = {
                    name: float(gmsh.option.getNumber(name)) for name in options
                }
            for name, value in options.items():
                gmsh.option.setNumber(name, float(value))
            gmsh.model.add(model_name)
            gmsh.model.setCurrent(model_name)
            yield model_name
        finally:
            if owns_gmsh:
                if gmsh.isInitialized():
                    _finalize_owned_gmsh(gmsh)
            elif gmsh.isInitialized():
                try:
                    model_names = tuple(str(name) for name in gmsh.model.list())
                    if model_name in model_names:
                        gmsh.model.setCurrent(model_name)
                        gmsh.model.remove()
                    for name, value in previous_options.items():
                        gmsh.option.setNumber(name, value)
                    model_names = tuple(str(name) for name in gmsh.model.list())
                    if previous_model and previous_model in model_names:
                        gmsh.model.setCurrent(previous_model)
                except Exception:
                    # Cleanup must never mask the original mesh/validation error.
                    pass


__all__ = ["GMSH_LOCK", "isolated_gmsh_model", "preview_mesh_file"]
