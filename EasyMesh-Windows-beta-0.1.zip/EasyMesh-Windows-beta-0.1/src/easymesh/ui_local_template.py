# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'local_template.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QAbstractItemView, QApplication, QComboBox,
    QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QPushButton, QScrollArea, QSizePolicy,
    QSpacerItem, QSplitter, QTabWidget, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget)

from easymesh.package_v2_draft_preview import DraftGeometryPreview

class Ui_LocalTemplateForm(object):
    def setupUi(self, LocalTemplateForm):
        if not LocalTemplateForm.objectName():
            LocalTemplateForm.setObjectName(u"LocalTemplateForm")
        LocalTemplateForm.resize(1250, 760)
        self.root_layout = QVBoxLayout(LocalTemplateForm)
        self.root_layout.setObjectName(u"root_layout")
        self.preview_splitter = QSplitter(LocalTemplateForm)
        self.preview_splitter.setObjectName(u"preview_splitter")
        self.preview_splitter.setChildrenCollapsible(False)
        self.preview_splitter.setOrientation(Qt.Horizontal)
        self.editor_page = QWidget(self.preview_splitter)
        self.editor_page.setObjectName(u"editor_page")
        self.editor_layout = QVBoxLayout(self.editor_page)
        self.editor_layout.setObjectName(u"editor_layout")
        self.editor_layout.setContentsMargins(0, 0, 0, 0)
        self.help_label = QLabel(self.editor_page)
        self.help_label.setObjectName(u"help_label")
        self.help_label.setWordWrap(True)
        self.help_label.setTextFormat(Qt.PlainText)

        self.editor_layout.addWidget(self.help_label)

        self.template_form = QFormLayout()
        self.template_form.setObjectName(u"template_form")
        self.template_form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        self.name_label = QLabel(self.editor_page)
        self.name_label.setObjectName(u"name_label")
        self.name_label.setWordWrap(True)
        self.name_label.setTextFormat(Qt.PlainText)

        self.template_form.setWidget(0, QFormLayout.ItemRole.LabelRole, self.name_label)

        self.name_edit = QLineEdit(self.editor_page)
        self.name_edit.setObjectName(u"name_edit")

        self.template_form.setWidget(0, QFormLayout.ItemRole.FieldRole, self.name_edit)


        self.editor_layout.addLayout(self.template_form)

        self.origin_note = QLabel(self.editor_page)
        self.origin_note.setObjectName(u"origin_note")
        self.origin_note.setWordWrap(True)
        self.origin_note.setTextFormat(Qt.PlainText)

        self.editor_layout.addWidget(self.origin_note)

        self.tabs = QTabWidget(self.editor_page)
        self.tabs.setObjectName(u"tabs")
        self.locals_page = QWidget()
        self.locals_page.setObjectName(u"locals_page")
        self.locals_page_layout = QVBoxLayout(self.locals_page)
        self.locals_page_layout.setObjectName(u"locals_page_layout")
        self.local_usage_label = QLabel(self.locals_page)
        self.local_usage_label.setObjectName(u"local_usage_label")
        self.local_usage_label.setWordWrap(True)
        self.local_usage_label.setTextFormat(Qt.PlainText)

        self.locals_page_layout.addWidget(self.local_usage_label)

        self.parameter_heading = QLabel(self.locals_page)
        self.parameter_heading.setObjectName(u"parameter_heading")
        self.parameter_heading.setWordWrap(True)
        self.parameter_heading.setTextFormat(Qt.PlainText)

        self.locals_page_layout.addWidget(self.parameter_heading)

        self.parameter_table = QTableWidget(self.locals_page)
        if (self.parameter_table.columnCount() < 5):
            self.parameter_table.setColumnCount(5)
        __qtablewidgetitem = QTableWidgetItem()
        self.parameter_table.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.parameter_table.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.parameter_table.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.parameter_table.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.parameter_table.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        self.parameter_table.setObjectName(u"parameter_table")
        self.parameter_table.setWordWrap(False)
        self.parameter_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.parameter_table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.parameter_table.setProperty(u"autoFitMinimumWidth", 80)
        self.parameter_table.setProperty(u"autoFitMaximumWidth", 480)
        self.parameter_table.horizontalHeader().setMinimumSectionSize(48)
        self.parameter_table.horizontalHeader().setDefaultSectionSize(140)
        self.parameter_table.horizontalHeader().setStretchLastSection(False)
        self.parameter_table.verticalHeader().setMinimumSectionSize(24)
        self.parameter_table.verticalHeader().setDefaultSectionSize(24)

        self.locals_page_layout.addWidget(self.parameter_table)

        self.parameter_actions = QHBoxLayout()
        self.parameter_actions.setObjectName(u"parameter_actions")
        self.add_parameter_button = QPushButton(self.locals_page)
        self.add_parameter_button.setObjectName(u"add_parameter_button")

        self.parameter_actions.addWidget(self.add_parameter_button)

        self.delete_parameter_button = QPushButton(self.locals_page)
        self.delete_parameter_button.setObjectName(u"delete_parameter_button")

        self.parameter_actions.addWidget(self.delete_parameter_button)

        self.parameter_spacer = QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.parameter_actions.addItem(self.parameter_spacer)


        self.locals_page_layout.addLayout(self.parameter_actions)

        self.derived_heading = QLabel(self.locals_page)
        self.derived_heading.setObjectName(u"derived_heading")
        self.derived_heading.setWordWrap(True)
        self.derived_heading.setTextFormat(Qt.PlainText)

        self.locals_page_layout.addWidget(self.derived_heading)

        self.derived_table = QTableWidget(self.locals_page)
        if (self.derived_table.columnCount() < 4):
            self.derived_table.setColumnCount(4)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.derived_table.setHorizontalHeaderItem(0, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.derived_table.setHorizontalHeaderItem(1, __qtablewidgetitem6)
        __qtablewidgetitem7 = QTableWidgetItem()
        self.derived_table.setHorizontalHeaderItem(2, __qtablewidgetitem7)
        __qtablewidgetitem8 = QTableWidgetItem()
        self.derived_table.setHorizontalHeaderItem(3, __qtablewidgetitem8)
        self.derived_table.setObjectName(u"derived_table")
        self.derived_table.setWordWrap(False)
        self.derived_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.derived_table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.derived_table.setProperty(u"autoFitMinimumWidth", 80)
        self.derived_table.setProperty(u"autoFitMaximumWidth", 480)
        self.derived_table.horizontalHeader().setMinimumSectionSize(48)
        self.derived_table.horizontalHeader().setDefaultSectionSize(140)
        self.derived_table.horizontalHeader().setStretchLastSection(False)
        self.derived_table.verticalHeader().setMinimumSectionSize(24)
        self.derived_table.verticalHeader().setDefaultSectionSize(24)

        self.locals_page_layout.addWidget(self.derived_table)

        self.derived_actions = QHBoxLayout()
        self.derived_actions.setObjectName(u"derived_actions")
        self.add_derived_button = QPushButton(self.locals_page)
        self.add_derived_button.setObjectName(u"add_derived_button")

        self.derived_actions.addWidget(self.add_derived_button)

        self.delete_derived_button = QPushButton(self.locals_page)
        self.delete_derived_button.setObjectName(u"delete_derived_button")

        self.derived_actions.addWidget(self.delete_derived_button)

        self.derived_spacer = QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.derived_actions.addItem(self.derived_spacer)


        self.locals_page_layout.addLayout(self.derived_actions)

        self.locals_page_layout.setStretch(2, 1)
        self.locals_page_layout.setStretch(5, 1)
        self.tabs.addTab(self.locals_page, "")
        self.solids_page = QWidget()
        self.solids_page.setObjectName(u"solids_page")
        self.solids_page_layout = QVBoxLayout(self.solids_page)
        self.solids_page_layout.setObjectName(u"solids_page_layout")
        self.solid_splitter = QSplitter(self.solids_page)
        self.solid_splitter.setObjectName(u"solid_splitter")
        self.solid_splitter.setOrientation(Qt.Horizontal)
        self.solid_list = QListWidget(self.solid_splitter)
        self.solid_list.setObjectName(u"solid_list")
        self.solid_splitter.addWidget(self.solid_list)
        self.solid_scroll = QScrollArea(self.solid_splitter)
        self.solid_scroll.setObjectName(u"solid_scroll")
        self.solid_scroll.setWidgetResizable(True)
        self.solid_page = QWidget()
        self.solid_page.setObjectName(u"solid_page")
        self.solid_form = QFormLayout(self.solid_page)
        self.solid_form.setObjectName(u"solid_form")
        self.solid_form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        self.solid_scroll.setWidget(self.solid_page)
        self.solid_splitter.addWidget(self.solid_scroll)

        self.solids_page_layout.addWidget(self.solid_splitter)

        self.solid_actions = QHBoxLayout()
        self.solid_actions.setObjectName(u"solid_actions")
        self.shape_combo = QComboBox(self.solids_page)
        self.shape_combo.setObjectName(u"shape_combo")

        self.solid_actions.addWidget(self.shape_combo)

        self.add_solid_button = QPushButton(self.solids_page)
        self.add_solid_button.setObjectName(u"add_solid_button")

        self.solid_actions.addWidget(self.add_solid_button)

        self.remove_solid_button = QPushButton(self.solids_page)
        self.remove_solid_button.setObjectName(u"remove_solid_button")

        self.solid_actions.addWidget(self.remove_solid_button)


        self.solids_page_layout.addLayout(self.solid_actions)

        self.solids_page_layout.setStretch(0, 1)
        self.tabs.addTab(self.solids_page, "")
        self.children_page = QWidget()
        self.children_page.setObjectName(u"children_page")
        self.children_page_layout = QVBoxLayout(self.children_page)
        self.children_page_layout.setObjectName(u"children_page_layout")
        self.child_list = QListWidget(self.children_page)
        self.child_list.setObjectName(u"child_list")

        self.children_page_layout.addWidget(self.child_list)

        self.child_actions = QHBoxLayout()
        self.child_actions.setObjectName(u"child_actions")
        self.add_child_button = QPushButton(self.children_page)
        self.add_child_button.setObjectName(u"add_child_button")

        self.child_actions.addWidget(self.add_child_button)

        self.edit_child_button = QPushButton(self.children_page)
        self.edit_child_button.setObjectName(u"edit_child_button")

        self.child_actions.addWidget(self.edit_child_button)

        self.remove_child_button = QPushButton(self.children_page)
        self.remove_child_button.setObjectName(u"remove_child_button")

        self.child_actions.addWidget(self.remove_child_button)


        self.children_page_layout.addLayout(self.child_actions)

        self.children_page_layout.setStretch(0, 1)
        self.tabs.addTab(self.children_page, "")

        self.editor_layout.addWidget(self.tabs)

        self.status_label = QLabel(self.editor_page)
        self.status_label.setObjectName(u"status_label")
        self.status_label.setWordWrap(True)
        self.status_label.setTextFormat(Qt.PlainText)

        self.editor_layout.addWidget(self.status_label)

        self.buttons = QDialogButtonBox(self.editor_page)
        self.buttons.setObjectName(u"buttons")
        self.buttons.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.editor_layout.addWidget(self.buttons)

        self.editor_layout.setStretch(3, 1)
        self.preview_splitter.addWidget(self.editor_page)
        self.preview_panel = DraftGeometryPreview(self.preview_splitter)
        self.preview_panel.setObjectName(u"preview_panel")
        self.preview_splitter.addWidget(self.preview_panel)

        self.root_layout.addWidget(self.preview_splitter)


        self.retranslateUi(LocalTemplateForm)

        QMetaObject.connectSlotsByName(LocalTemplateForm)
    # setupUi

    def retranslateUi(self, LocalTemplateForm):
        LocalTemplateForm.setWindowTitle(QCoreApplication.translate("LocalTemplateForm", u"\u521b\u5efa\u6a21\u677f", None))
        LocalTemplateForm.setProperty(u"editTitle", QCoreApplication.translate("LocalTemplateForm", u"\u7f16\u8f91\u6a21\u677f", None))
        self.help_label.setText(QCoreApplication.translate("LocalTemplateForm", u"\u6a21\u677f\u4f7f\u7528\u72ec\u7acb\u5c40\u90e8\u5750\u6807\u7cfb\u3002\u516c\u5f00\u53c2\u6570\u663e\u793a\u5728\u5b9e\u4f8b\u4e2d\uff1b\u5185\u90e8\u53d8\u91cf\u3001\u57fa\u672c\u56fe\u5f62\u548c\u5b50\u5b9e\u4f8b\u53ea\u5728\u8fd9\u91cc\u7f16\u8f91\u3002\u4fee\u6539\u5df2\u6709\u6a21\u677f\u4f1a\u66f4\u65b0\u5f15\u7528\u5b83\u7684\u5b9e\u4f8b\uff1b\u65b0\u589e\u516c\u5f00\u53c2\u6570\u4f7f\u7528\u9ed8\u8ba4\u503c\uff0c\u91cd\u547d\u540d\u4fdd\u7559\u539f\u7ed1\u5b9a\u3002", None))
        self.name_label.setText(QCoreApplication.translate("LocalTemplateForm", u"\u6a21\u677f\u540d\u79f0", None))
        self.origin_note.setText(QCoreApplication.translate("LocalTemplateForm", u"\u5c40\u90e8\u539f\u70b9\u56fa\u5b9a\u4e3a (0, 0, 0)\u3002\u6240\u6709\u56fe\u5f62\u5750\u6807\u5747\u76f8\u5bf9\u6b64\u539f\u70b9\uff1b\u6a21\u677f\u5728\u5de5\u7a0b\u4e2d\u7684\u4f4d\u7f6e\u7531 Instance \u8bbe\u7f6e\u3002", None))
        self.local_usage_label.setText("")
        self.parameter_heading.setText(QCoreApplication.translate("LocalTemplateForm", u"\u516c\u5f00 Local variables", None))
        ___qtablewidgetitem = self.parameter_table.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("LocalTemplateForm", u"\u540d\u79f0", None))
        ___qtablewidgetitem1 = self.parameter_table.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("LocalTemplateForm", u"\u7c7b\u578b", None))
        ___qtablewidgetitem2 = self.parameter_table.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("LocalTemplateForm", u"\u5355\u4f4d", None))
        ___qtablewidgetitem3 = self.parameter_table.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("LocalTemplateForm", u"\u9ed8\u8ba4\u503c", None))
        ___qtablewidgetitem4 = self.parameter_table.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("LocalTemplateForm", u"\u5f15\u7528\u60c5\u51b5", None))
        self.add_parameter_button.setText(QCoreApplication.translate("LocalTemplateForm", u"\u6dfb\u52a0\u516c\u5f00\u53c2\u6570", None))
        self.delete_parameter_button.setText(QCoreApplication.translate("LocalTemplateForm", u"\u5220\u9664\u9009\u4e2d\u53d8\u91cf", None))
        self.derived_heading.setText(QCoreApplication.translate("LocalTemplateForm", u"\u5185\u90e8\u53d8\u91cf / \u516c\u5f0f\uff08\u5b9e\u4f8b\u4e2d\u9690\u85cf\uff1b\u56fa\u5b9a\u503c\u4e5f\u53ef\u586b\u5728\u8fd9\u91cc\uff09", None))
        ___qtablewidgetitem5 = self.derived_table.horizontalHeaderItem(0)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("LocalTemplateForm", u"\u540d\u79f0", None))
        ___qtablewidgetitem6 = self.derived_table.horizontalHeaderItem(1)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("LocalTemplateForm", u"\u7c7b\u578b", None))
        ___qtablewidgetitem7 = self.derived_table.horizontalHeaderItem(2)
        ___qtablewidgetitem7.setText(QCoreApplication.translate("LocalTemplateForm", u"\u8868\u8fbe\u5f0f", None))
        ___qtablewidgetitem8 = self.derived_table.horizontalHeaderItem(3)
        ___qtablewidgetitem8.setText(QCoreApplication.translate("LocalTemplateForm", u"\u5f15\u7528\u60c5\u51b5", None))
        self.add_derived_button.setText(QCoreApplication.translate("LocalTemplateForm", u"\u6dfb\u52a0\u5185\u90e8\u53d8\u91cf", None))
        self.delete_derived_button.setText(QCoreApplication.translate("LocalTemplateForm", u"\u5220\u9664\u9009\u4e2d\u53d8\u91cf", None))
        self.tabs.setTabText(self.tabs.indexOf(self.locals_page), QCoreApplication.translate("LocalTemplateForm", u"Local variables", None))
        self.add_solid_button.setText(QCoreApplication.translate("LocalTemplateForm", u"\u6dfb\u52a0\u57fa\u672c\u56fe\u5f62", None))
        self.remove_solid_button.setText(QCoreApplication.translate("LocalTemplateForm", u"\u5220\u9664\u9009\u4e2d\u56fe\u5f62", None))
        self.tabs.setTabText(self.tabs.indexOf(self.solids_page), QCoreApplication.translate("LocalTemplateForm", u"\u57fa\u672c\u56fe\u5f62", None))
        self.add_child_button.setText(QCoreApplication.translate("LocalTemplateForm", u"\u4ece\u6a21\u677f\u521b\u5efa\u5b50\u5b9e\u4f8b", None))
        self.edit_child_button.setText(QCoreApplication.translate("LocalTemplateForm", u"\u7f16\u8f91\u5b50\u5b9e\u4f8b", None))
        self.remove_child_button.setText(QCoreApplication.translate("LocalTemplateForm", u"\u5220\u9664\u5b50\u5b9e\u4f8b", None))
        self.tabs.setTabText(self.tabs.indexOf(self.children_page), QCoreApplication.translate("LocalTemplateForm", u"\u5b50\u5b9e\u4f8b", None))
        self.status_label.setText("")
        self.buttons.setProperty(u"acceptText", QCoreApplication.translate("LocalTemplateForm", u"\u521b\u5efa\u6a21\u677f", None))
        self.buttons.setProperty(u"cancelText", QCoreApplication.translate("LocalTemplateForm", u"\u53d6\u6d88", None))
        self.buttons.setProperty(u"editText", QCoreApplication.translate("LocalTemplateForm", u"\u4fdd\u5b58\u6a21\u677f\u5230\u5de5\u7a0b", None))
        self.preview_panel.setProperty(u"caption", QCoreApplication.translate("LocalTemplateForm", u"\u6a21\u677f\u9884\u89c8 \u00b7 \u4f7f\u7528\u516c\u5f00\u53c2\u6570\u9ed8\u8ba4\u503c\uff0c\u5750\u6807\u8f74\u6807\u8bb0\u5c40\u90e8\u539f\u70b9", None))
    # retranslateUi
