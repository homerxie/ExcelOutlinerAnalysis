# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'section_preview.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QLabel, QSizePolicy,
    QWidget)

class Ui_SectionPreviewForm(object):
    def setupUi(self, SectionPreviewForm):
        if not SectionPreviewForm.objectName():
            SectionPreviewForm.setObjectName(u"SectionPreviewForm")
        SectionPreviewForm.setMinimumSize(QSize(240, 160))
        SectionPreviewForm.setMouseTracking(True)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(SectionPreviewForm.sizePolicy().hasHeightForWidth())
        SectionPreviewForm.setSizePolicy(sizePolicy)
        self._mesh_tooltip_label = QLabel(SectionPreviewForm)
        self._mesh_tooltip_label.setObjectName(u"_mesh_tooltip_label")
        self._mesh_tooltip_label.setTextFormat(Qt.PlainText)
        self._mesh_tooltip_label.setWordWrap(False)
        self._mesh_tooltip_label.setFocusPolicy(Qt.NoFocus)
        self._mesh_tooltip_label.setAutoFillBackground(True)
        self._mesh_tooltip_label.setFrameShape(QFrame.Box)
        self._mesh_tooltip_label.setMargin(6)

        self.retranslateUi(SectionPreviewForm)

        QMetaObject.connectSlotsByName(SectionPreviewForm)
    # setupUi

    def retranslateUi(self, SectionPreviewForm):
#if QT_CONFIG(tooltip)
        SectionPreviewForm.setToolTip(QCoreApplication.translate("SectionPreviewForm", u"\u5355\u51fb\u622a\u9762\u6216 Z \u7f16\u53f7\u5b9a\u4f4d\u533a\u95f4\uff1b\u6eda\u8f6e\u4ee5\u6307\u9488\u4e3a\u4e2d\u5fc3\u7f29\u653e\uff0c\u62d6\u62fd\u5e73\u79fb\uff0c\u53cc\u51fb\u7a7a\u767d\u5904\u6062\u590d\u5168\u56fe\uff1b\u52fe\u9009\u201cZ \u7f51\u683c\u201d\u663e\u793a\u5b9e\u9645\u539a\u5ea6\u5206\u5c42\uff0c\u60ac\u505c\u663e\u793a\u5355\u5143\u539a\u5ea6\uff0c\u653e\u5927\u53ef\u67e5\u770b\u7ec6\u5c0f\u5355\u5143", None))
#endif // QT_CONFIG(tooltip)
        self._mesh_tooltip_label.setText("")
    # retranslateUi
