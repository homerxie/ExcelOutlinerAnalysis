"""Managed mesh snapshots and small, Qt-free transfers between workflow stages.

Passing a mesh to the next stage never moves or overwrites the producer's
output.  Its sidecars travel with it, including the lossless air-gap geometry
which cannot be recovered from the volume mesh alone.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass, replace
import hashlib
import io
import json
import os
from pathlib import Path
import re
import tempfile
from typing import Callable, Sequence

from .bump_layout import BumpInstance, BumpLayout, BumpMeshTemplate
from .output_artifacts import exclusive_artifact_lock, sha256_file
from .package_v2_mesh_groups import read_mesh_volume_groups


_SIDECAR_SUFFIXES = (".parameters.json", ".report.json")
_RESERVED_ALIASES = {"xsize", "ysize", "define", "mesh"}


@dataclass(frozen=True, slots=True)
class MeshAssetSnapshot:
    mesh_path: Path
    sha256: str
    sidecar_paths: tuple[Path, ...]


def _signature(path: Path) -> tuple[int, ...] | None:
    try:
        info = path.stat()
    except FileNotFoundError:
        return None
    if not path.is_file():
        raise ValueError(f"网格资源必须是普通文件：{path}")
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns


class MeshSnapshotCancelled(RuntimeError):
    """The owner closed or switched projects while a snapshot was copying."""


def _copy_bounded(source: Path, target: Path, maximum_bytes: int, *,
                  cancelled: Callable[[], bool] | None = None) -> str:
    digest = hashlib.sha256()
    copied = 0
    with source.open("rb") as incoming, target.open("wb") as outgoing:
        while block := incoming.read(1024 * 1024):
            if cancelled is not None and cancelled():
                raise MeshSnapshotCancelled("已取消保存网格资源。")
            copied += len(block)
            if copied > maximum_bytes:
                raise ValueError(f"网格资源超过 {maximum_bytes} 字节限制：{source}")
            digest.update(block)
            outgoing.write(block)
    return digest.hexdigest()


def _snapshot_file_digest(path: Path, cancelled: Callable[[], bool] | None) -> str:
    if cancelled is None:
        return sha256_file(path)
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            if cancelled():
                raise MeshSnapshotCancelled("已取消保存网格资源。")
            digest.update(block)
    return digest.hexdigest()


def _relocate_report(report: Path, source: Path, target: Path, mesh_sha256: str,
                     size_bytes: int) -> None:
    """Rebind only a report whose mesh identity was valid before copying."""
    try:
        document = json.loads(report.read_text(encoding="utf-8"))
    except (UnicodeError, ValueError):
        # Unrecognized third-party metadata remains byte-for-byte intact.
        return
    if not isinstance(document, dict) or "mesh_artifact" not in document:
        return
    artifact = document["mesh_artifact"]
    if (not isinstance(artifact, dict)
            or not isinstance(artifact.get("path"), str)
            or Path(artifact["path"]).expanduser().resolve() != source
            or type(artifact.get("size_bytes")) is not int
            or artifact["size_bytes"] != size_bytes
            or str(artifact.get("sha256", "")).lower() != mesh_sha256):
        raise ValueError(f"网格报告与当前网格不一致，请重新生成：{source}")
    artifact["path"] = str(target)
    report.write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\n",
                      encoding="utf-8")


def snapshot_mesh_asset(mesh_path: str | Path, asset_root: str | Path, *,
                        cancelled: Callable[[], bool] | None = None,
                        expected_signatures: tuple[tuple[int, ...] | None, ...] | None = None,
                        ) -> MeshAssetSnapshot:
    """Copy one stable bundle into a content-addressed managed directory.

    The bundle key includes metadata, so templates with identical MSH bytes
    but different terminal air gaps remain distinct.  Existing managed assets
    are verified and reused; they are never silently repaired or overwritten.
    """
    source = Path(mesh_path).expanduser().resolve(strict=True)
    if source.suffix.lower() != ".msh" or not source.is_file():
        raise ValueError(f"请选择 MSH 网格文件：{source}")
    root = Path(asset_root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    inputs = (source, *(source.with_suffix(suffix) for suffix in _SIDECAR_SUFFIXES))
    with exclusive_artifact_lock(source), tempfile.TemporaryDirectory(
            prefix=".mesh-transfer-", dir=root) as temporary:
        stage = Path(temporary) / "bundle"
        stage.mkdir()
        before = tuple(_signature(path) for path in inputs)
        if before[0] is None:
            raise ValueError(f"网格文件已不存在：{source}")
        if expected_signatures is not None and before != expected_signatures:
            raise ValueError("网格或参数在后台保存开始前发生变化，请重新生成。")
        records: list[tuple[Path, str]] = []
        bundle_digest = hashlib.sha256()
        for index, (path, signature) in enumerate(zip(inputs, before)):
            if cancelled is not None and cancelled():
                raise MeshSnapshotCancelled("已取消保存网格资源。")
            suffix = ".msh" if index == 0 else _SIDECAR_SUFFIXES[index - 1]
            bundle_digest.update(suffix.encode("ascii") + b"\0")
            if signature is None:
                bundle_digest.update(b"missing\0")
                continue
            target = stage / f"mesh{suffix}"
            # Meshes can legitimately exceed 512 MiB. Bound their copy by the
            # captured source size instead, then reject any source mutation.
            # Metadata retains its separate, deliberately small size budget.
            maximum_bytes = signature[2] if index == 0 else 32 * 1024 * 1024
            if signature[2] > maximum_bytes:
                raise ValueError(f"网格元数据超过 {maximum_bytes} 字节限制：{path}")
            copy_options = {} if cancelled is None else {"cancelled": cancelled}
            digest = _copy_bounded(path, target, maximum_bytes, **copy_options)
            bundle_digest.update(digest.encode("ascii") + b"\0")
            records.append((target, digest))
        if tuple(_signature(path) for path in inputs) != before:
            raise ValueError("传递期间网格或参数发生变化，请重试。")
        mesh_sha256 = records[0][1]
        destination = root / bundle_digest.hexdigest()
        final_mesh = destination / "mesh.msh"
        report = stage / "mesh.report.json"
        if report.exists():
            _relocate_report(report, source, final_mesh, mesh_sha256, (stage / "mesh.msh").stat().st_size)
        with exclusive_artifact_lock(destination):
            if destination.exists():
                if not destination.is_dir() or destination.is_symlink():
                    raise ValueError(f"工作流网格资源目录无效：{destination}")
                for path, copied_digest in records:
                    existing = destination / path.name
                    # The copy already hashed mesh/parameters bytes. Only the
                    # report changes when its artifact path is relocated.
                    expected_digest = (_snapshot_file_digest(path, cancelled)
                                       if path == report else copied_digest)
                    if (not existing.is_file() or existing.is_symlink()
                            or _snapshot_file_digest(existing, cancelled) != expected_digest):
                        raise ValueError(f"工作流网格资源已被修改：{existing}")
                expected = {path.name for path, _ in records}
                if {path.name for path in destination.iterdir()
                    if path.name == "mesh.msh" or path.name in {"mesh" + suffix for suffix in _SIDECAR_SUFFIXES}} != expected:
                    raise ValueError(f"工作流网格元数据已被修改：{destination}")
            else:
                if cancelled is not None and cancelled():
                    raise MeshSnapshotCancelled("已取消保存网格资源。")
                os.replace(stage, destination)
        return MeshAssetSnapshot(final_mesh, mesh_sha256,
                                 tuple(destination / path.name for path, _ in records[1:]))


def _layout_alias(alias: str) -> str:
    alias = alias.strip()
    if (not alias or alias.startswith("#") or alias.casefold() in _RESERVED_ALIASES
            or any(c in alias for c in "\r\n")):
        raise ValueError("模板名称不能为空、包含换行，或使用 Xsize/Ysize/define/mesh 保留字。")
    return alias


def add_template_to_layout(layout: BumpLayout, mesh_path: str | Path, *,
                           alias: str | None = None,
                           position_mm: tuple[float, float] | None = None) -> BumpLayout:
    """Append a reusable template, optionally adding a placement in millimetres."""
    mesh = Path(mesh_path).expanduser().resolve(strict=True)
    aliases = set(layout.template_by_alias)
    if alias is None:
        base = re.sub(r"[^A-Za-z0-9_]", "_", mesh.stem).strip("_") or "template"
        if base.casefold() in _RESERVED_ALIASES:
            base = "template_" + base
        alias = base
        suffix = 2
        while alias in aliases:
            alias = f"{base}_{suffix}"
            suffix += 1
    alias = _layout_alias(alias)
    if alias in aliases:
        raise ValueError(f"连接中已存在模板名称：{alias}")
    instances = layout.instances
    if position_mm is not None:
        if len(position_mm) != 2:
            raise ValueError("模板位置需要 X 和 Y 两个坐标。")
        instances += (BumpInstance(position_mm[0], position_mm[1], alias),)
    return replace(layout, templates=layout.templates + (BumpMeshTemplate(alias, mesh),),
                   instances=instances)


def serialize_bump_layout(layout: BumpLayout, *, relative_to: str | Path | None = None) -> str:
    """Write resolved layout values without losing anisotropic mesh regions."""
    stream = io.StringIO(newline="")
    writer = csv.writer(stream, lineterminator="\n")
    length = lambda value: f"{value:.17g}mm"
    bounds = layout.bounds
    writer.writerow(("Xsize", length(bounds.x_min_mm), length(bounds.x_max_mm)))
    writer.writerow(("Ysize", length(bounds.y_min_mm), length(bounds.y_max_mm)))
    for template in layout.templates:
        alias = _layout_alias(template.alias)
        path = template.mesh_path.expanduser().resolve()
        rendered = str(path) if relative_to is None else Path(os.path.relpath(path, Path(relative_to).resolve())).as_posix()
        if "\n" in rendered or "\r" in rendered:
            raise ValueError("模板路径不能包含换行。")
        writer.writerow((alias, rendered))
    for instance in layout.instances:
        row = (length(instance.x_mm), length(instance.y_mm), instance.template_alias)
        if instance.rotation_deg != 0.0:
            row += (f"{instance.rotation_deg:.17g}",)
        writer.writerow(row)
    for region in layout.mesh_regions:
        corners = ((region.x_min_mm, region.y_min_mm), (region.x_max_mm, region.y_min_mm),
                   (region.x_max_mm, region.y_max_mm), (region.x_min_mm, region.y_max_mm))
        polygon = "[" + ",".join(f"({length(x)},{length(y)})" for x, y in corners) + "]"
        for axis, size in (("x", region.size_x_mm), ("y", region.size_y_mm)):
            stream.write(f"mesh, HEX, size, {polygon}, {axis}, {length(size)}\n")
    return stream.getvalue()


def prepare_package_frozen_source(mesh_path: str | Path, source_path: str | Path, *,
                                  source_id: str = "connected",
                                  components: Sequence[str] | None = None) -> dict[str, object]:
    """Prepare a portable declaration accepted by ``editor.add_frozen_source``.

    Group selection uses the same bounded metadata reader as the existing
    external mesh dialog.  Full volume validation remains the Package worker's
    responsibility, matching that dialog's behavior.
    """
    root = Path(source_path).expanduser().resolve().parent
    asset_root = root / "workflow_assets"
    if asset_root.is_symlink():
        raise ValueError("工作流资源目录不能是符号链接。")
    snapshot = snapshot_mesh_asset(mesh_path, asset_root)
    groups = read_mesh_volume_groups(snapshot.mesh_path)
    selected = tuple(groups.default_selection() if components is None else components)
    if error := groups.selection_error(selected):
        raise ValueError(error)
    return {"id": source_id,
            "artifacts": {"mesh": snapshot.mesh_path.relative_to(root).as_posix(),
                          "sha256": snapshot.sha256},
            "components": list(selected),
            "placement": {"translation": ["0mm", "0mm", "0mm"],
                          "rotation_matrix": [[1, 0, 0], [0, 1, 0], [0, 0, 1]]}}


__all__ = ["MeshAssetSnapshot", "snapshot_mesh_asset", "add_template_to_layout",
           "serialize_bump_layout", "prepare_package_frozen_source"]
