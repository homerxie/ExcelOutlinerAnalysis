# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'preview_3d.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QLabel, QMenu,
    QPushButton, QSizePolicy, QToolButton, QVBoxLayout,
    QWidget)

class Ui_Preview3DForm(object):
    def setupUi(self, Preview3DForm):
        if not Preview3DForm.objectName():
            Preview3DForm.setObjectName(u"Preview3DForm")
        Preview3DForm.setMinimumSize(QSize(300, 240))
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Preview3DForm.sizePolicy().hasHeightForWidth())
        Preview3DForm.setSizePolicy(sizePolicy)
        self.root_layout = QVBoxLayout(Preview3DForm)
        self.root_layout.setObjectName(u"root_layout")
        self.root_layout.setContentsMargins(8, 8, 8, 8)
        self.toolbar_layout = QHBoxLayout()
        self.toolbar_layout.setObjectName(u"toolbar_layout")
        self.summary_label = QLabel(Preview3DForm)
        self.summary_label.setObjectName(u"summary_label")
        self.summary_label.setTextFormat(Qt.PlainText)
        self.summary_label.setWordWrap(False)
        self.summary_label.setTextInteractionFlags(Qt.TextSelectableByMouse)

        self.toolbar_layout.addWidget(self.summary_label)

        self.visibility_button = QToolButton(Preview3DForm)
        self.visibility_button.setObjectName(u"visibility_button")
        self.visibility_button.setPopupMode(QToolButton.InstantPopup)
        self.visibility_menu = QMenu(self.visibility_button)
        self.visibility_menu.setObjectName(u"visibility_menu")

        self.toolbar_layout.addWidget(self.visibility_button)

        self.translucent_button = QToolButton(Preview3DForm)
        self.translucent_button.setObjectName(u"translucent_button")
        self.translucent_button.setCheckable(True)

        self.toolbar_layout.addWidget(self.translucent_button)

        self.x_view_button = QToolButton(Preview3DForm)
        self.x_view_button.setObjectName(u"x_view_button")

        self.toolbar_layout.addWidget(self.x_view_button)

        self.y_view_button = QToolButton(Preview3DForm)
        self.y_view_button.setObjectName(u"y_view_button")

        self.toolbar_layout.addWidget(self.y_view_button)

        self.z_view_button = QToolButton(Preview3DForm)
        self.z_view_button.setObjectName(u"z_view_button")

        self.toolbar_layout.addWidget(self.z_view_button)

        self.reset_button = QPushButton(Preview3DForm)
        self.reset_button.setObjectName(u"reset_button")
        self.reset_button.setAutoDefault(False)

        self.toolbar_layout.addWidget(self.reset_button)

        self.toolbar_layout.setStretch(0, 1)

        self.root_layout.addLayout(self.toolbar_layout)

        self.canvas_host = QWidget(Preview3DForm)
        self.canvas_host.setObjectName(u"canvas_host")
        self.canvas_layout = QVBoxLayout(self.canvas_host)
        self.canvas_layout.setObjectName(u"canvas_layout")
        self.canvas_layout.setContentsMargins(0, 0, 0, 0)

        self.root_layout.addWidget(self.canvas_host)

        self.selection_bounds_label = QLabel(Preview3DForm)
        self.selection_bounds_label.setObjectName(u"selection_bounds_label")
        self.selection_bounds_label.setWordWrap(True)
        self.selection_bounds_label.setTextFormat(Qt.PlainText)
        self.selection_bounds_label.setTextInteractionFlags(Qt.TextSelectableByMouse|Qt.TextSelectableByKeyboard)

        self.root_layout.addWidget(self.selection_bounds_label)

        self.hint_label = QLabel(Preview3DForm)
        self.hint_label.setObjectName(u"hint_label")
        self.hint_label.setWordWrap(True)
        self.hint_label.setTextFormat(Qt.PlainText)
        self.hint_label.setAlignment(Qt.AlignCenter)

        self.root_layout.addWidget(self.hint_label)

        self.root_layout.setStretch(1, 1)

        self.retranslateUi(Preview3DForm)

        QMetaObject.connectSlotsByName(Preview3DForm)
    # setupUi

    def retranslateUi(self, Preview3DForm):
        self.summary_label.setText(QCoreApplication.translate("Preview3DForm", u"\u5c1a\u65e0\u53ef\u9884\u89c8\u51e0\u4f55", None))
        self.visibility_button.setText(QCoreApplication.translate("Preview3DForm", u"\u7ec4\u4ef6\u663e\u9690", None))
        self.translucent_button.setText(QCoreApplication.translate("Preview3DForm", u"\u534a\u900f\u660e", None))
        self.x_view_button.setText(QCoreApplication.translate("Preview3DForm", u"X", None))
#if QT_CONFIG(tooltip)
        self.x_view_button.setToolTip(QCoreApplication.translate("Preview3DForm", u"\u4ece +X \u65b9\u5411\u671d\u539f\u70b9\u89c2\u5bdf\uff08YZ \u9762\uff09", None))
#endif // QT_CONFIG(tooltip)
        self.y_view_button.setText(QCoreApplication.translate("Preview3DForm", u"Y", None))
#if QT_CONFIG(tooltip)
        self.y_view_button.setToolTip(QCoreApplication.translate("Preview3DForm", u"\u4ece +Y \u65b9\u5411\u671d\u539f\u70b9\u89c2\u5bdf\uff08XZ \u9762\uff09", None))
#endif // QT_CONFIG(tooltip)
        self.z_view_button.setText(QCoreApplication.translate("Preview3DForm", u"Z", None))
#if QT_CONFIG(tooltip)
        self.z_view_button.setToolTip(QCoreApplication.translate("Preview3DForm", u"\u4ece +Z \u65b9\u5411\u671d\u539f\u70b9\u89c2\u5bdf\uff08XY \u9762\u4fef\u89c6\uff09", None))
#endif // QT_CONFIG(tooltip)
        self.reset_button.setText(QCoreApplication.translate("Preview3DForm", u"\u6062\u590d\u89c6\u56fe", None))
        self.selection_bounds_label.setText(QCoreApplication.translate("Preview3DForm", u"\u9009\u62e9\u5bf9\u8c61\u540e\u663e\u793a X/Y/Z \u8303\u56f4\uff08mm\uff09", None))
        self.hint_label.setText(QCoreApplication.translate("Preview3DForm", u"\u5de6\u952e\u65cb\u8f6c \u00b7 Shift+\u5de6\u952e/\u4e2d\u952e/\u53f3\u952e\u5e73\u79fb \u00b7 \u6eda\u8f6e\u7f29\u653e \u00b7 \u6b63\u4ea4\u6700\u9ad8 100,000\u00d7 \u00b7 Frozen \u663e\u793a\u8303\u56f4\u6846", None))
        pass
    # retranslateUi
