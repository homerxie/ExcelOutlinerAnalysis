"""Shared-node meshes for nested, concentric, X-aligned stadia.

The circular planner remains the source of semicircle sector topology. Equal
cap-centre bands retain that topology exactly and are joined by horizontal
strips. A band whose cap centres move extends the original circular rings
until they meet the outer contour; triangles close their ordered endings.
All construction is performed in one quadrant and reflected, except for the
unchanged circular cap topology, which uses four or eight sectors according
to the selected symmetry. Public coordinates are in mm.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import replace
import functools
import math
from typing import Iterable, Sequence

from .contours import StadiumContour, stadium_cell_spans_um
from .layer_sweep import RadialSeedPolicy
from .oblong_seed_optimization import uniformize_terminal_seeds
from .parameters import (
    MAX_NUMERICAL_LENGTH_UM, MIN_NUMERICAL_SEPARATION_UM,
    MeshParameters, SymmetryMode, UM_TO_MM,
)
from .topology import (
    AreaStatistics, EdgeStatistics, Face2D, Ring, TopologyPlan,
    _polygon_area_um2, _topology_is_reflection_symmetric,
    _unique_edge_lengths_um, _validated_radial_target_sizes,
    build_topology_with_radial_targets, _add_ring, _connect_rings, _independent_plane_requests,
)

_Point = tuple[float, float]


def _cross(a: _Point, b: _Point) -> float:
    return a[0] * b[1] - a[1] * b[0]


def _sub(a: _Point, b: _Point) -> _Point:
    return a[0] - b[0], a[1] - b[1]


def _dot(a: _Point, b: _Point) -> float:
    return a[0] * b[0] + a[1] * b[1]


def _twice_area(points: Sequence[_Point], face: Sequence[int]) -> float:
    origin = points[face[0]]
    return sum(_cross(_sub(points[a], origin), _sub(points[b], origin)) for a, b in
               zip(face, (*face[1:], face[0])))


class _Mesh:
    def __init__(self, scale: float):
        self.points: list[_Point] = []
        self.faces: list[Face2D] = []
        self.keys: dict[tuple[int, int], int] = {}
        # Relative precision also accommodates the supported tiny/large models.
        self.tolerance = max(min(scale * 1.e-12, MIN_NUMERICAL_SEPARATION_UM * .01),
                             MIN_NUMERICAL_SEPARATION_UM * 1.e-5)
        self.area_tolerance = self.tolerance * self.tolerance

    def node(self, point: _Point) -> int:
        key = tuple(round(v / self.tolerance) for v in point)
        if key not in self.keys:
            self.keys[key] = len(self.points)
            self.points.append(tuple(0. if abs(v) < self.tolerance else v for v in point))
        return self.keys[key]

    def oriented(self, nodes: Sequence[int]) -> tuple[int, ...]:
        ids = tuple(nodes)
        if len(ids) != len(set(ids)):
            raise ValueError("stadium mesh contains a collapsed face")
        area = _twice_area(self.points, ids)
        if abs(area) <= self.area_tolerance:
            raise ValueError("stadium mesh contains a zero-area face")
        return ids if area > 0. else tuple(reversed(ids))

    def quality(self, nodes: Sequence[int]) -> float:
        ids = self.oriented(nodes)
        values = []
        for j in range(len(ids)):
            a = _sub(self.points[ids[(j + 1) % len(ids)]], self.points[ids[j]])
            b = _sub(self.points[ids[(j + 2) % len(ids)]], self.points[ids[(j + 1) % len(ids)]])
            denominator = math.hypot(*a) * math.hypot(*b)
            values.append(_cross(a, b) / denominator if denominator else -1.)
        return min(values)

    def add(self, nodes: Sequence[int], region: int) -> None:
        face = self.oriented(nodes)
        if self.quality(face) <= 1.e-10:
            raise ValueError("stadium mesh contains a concave or collapsed cell")
        self.faces.append(Face2D(face, region))

    def mirror(self, faces: Iterable[Sequence[int]], region: int) -> None:
        for face in faces:
            for sx, sy in ((1., 1.), (-1., 1.), (1., -1.), (-1., -1.)):
                self.add([self.node((sx * self.points[i][0], sy * self.points[i][1]))
                          for i in face], region)


def _triangulate(mesh: _Mesh, polygon: Sequence[int]) -> list[tuple[int, ...]]:
    """Constrained ear clipping used only for a failed local closure/fallback.

    Collinear physical-boundary vertices are retained. Strict interior tests
    also prevent a diagonal from passing through another boundary vertex.
    """
    remaining = list(mesh.oriented(polygon))
    result: list[tuple[int, ...]] = []
    while len(remaining) > 3:
        ears = []
        for j, b in enumerate(remaining):
            a, c = remaining[j - 1], remaining[(j + 1) % len(remaining)]
            pa, pb, pc = (mesh.points[i] for i in (a, b, c))
            if _cross(_sub(pb, pa), _sub(pc, pb)) <= mesh.area_tolerance:
                continue
            blocked = False
            for v in remaining:
                if v in (a, b, c):
                    continue
                pv = mesh.points[v]
                signs = (_cross(_sub(pb, pa), _sub(pv, pa)),
                         _cross(_sub(pc, pb), _sub(pv, pb)),
                         _cross(_sub(pa, pc), _sub(pv, pc)))
                if min(signs) >= -mesh.area_tolerance:
                    blocked = True
                    break
            if not blocked:
                ears.append((mesh.quality((a, b, c)), j, (a, b, c)))
        if not ears:
            raise ValueError("无法为当前嵌套轮廓建立无交叉连接；请细化环向尺寸。")
        _, j, triangle = max(ears)
        result.append(triangle)
        remaining.pop(j)
    result.append(mesh.oriented(remaining))
    return result


def _patch(mesh: _Mesh, polygon: Sequence[int]) -> list[tuple[int, ...]]:
    ids = mesh.oriented(polygon)
    if len(ids) <= 4 and mesh.quality(ids) > 1.e-10:
        return [ids]
    # Test all fans with one quadrilateral. This retains the boundary's extra
    # vertices without converting the surrounding rail mesh to triangles.
    candidates = []
    rotations = (range(len(ids)) if len(ids) <= 12 else
                 sorted({0, len(ids) - 1, *(round(k * (len(ids) - 1) / 7) for k in range(8))}))
    for shift in rotations:
        p = ids[shift:] + ids[:shift]
        candidate = [(p[0], p[i], p[i + 1])
                     for i in range(1, len(p) - 3)]
        candidate.append((p[0], p[-3], p[-2], p[-1]))
        if any(_twice_area(mesh.points, f) <= mesh.area_tolerance for f in candidate):
            continue
        score = min(mesh.quality(f) for f in candidate)
        if score > 1.e-8:
            candidates.append((score, candidate))
    if candidates:
        return max(candidates, key=lambda item: item[0])[1]
    return _triangulate(mesh, ids)


def _connect_chains(mesh: _Mesh, left: Sequence[int], right: Sequence[int]) -> list[tuple[int, ...]]:
    """Connect rails of differing layer counts with explicit layer endings."""
    if len(left) > len(right):
        return _connect_chains(mesh, right, left)
    n, m = len(left) - 1, len(right) - 1
    if n <= 0:
        raise ValueError("a transverse rail needs at least one layer")
    if m <= 2 * n:
        extra = m - n
        splits = {min(n - 1, math.floor((k + .5) * n / extra)) for k in range(extra)}
        result = []
        k = 0
        for j in range(n):
            if j in splits:
                triangle = mesh.oriented((left[j], right[k], right[k + 1]))
                quad = mesh.oriented((left[j], right[k + 1], right[k + 2], left[j + 1]))
                if mesh.quality(quad) > 1.e-10:
                    result.extend((triangle, quad))
                else:
                    result.extend(_patch(mesh, (left[j], *right[k:k + 3], left[j + 1])))
                k += 2
            else:
                result.extend(_patch(mesh, (left[j], right[k], right[k + 1], left[j + 1])))
                k += 1
        return result
    # Distribute the extra intervals like the circular planner. Ratios above
    # 2:1 create more triangles in a local polygon, not an invalid quad.
    ends = [math.floor(j * m / n + .5) for j in range(n + 1)]
    result = []
    for j, (a, b) in enumerate(zip(ends, ends[1:])):
        result.extend(_patch(mesh, [left[j], *right[a:b + 1], left[j + 1]]))
    return result


def _replace_boundary_side(mesh: _Mesh, faces: list[tuple[int, ...]], path: Sequence[int]) -> None:
    if len(path) <= 2:
        return
    first, last = path[0], path[-1]
    for index, face in enumerate(faces):
        for j, (a, b) in enumerate(zip(face, (*face[1:], face[0]))):
            if {a, b} == {first, last}:
                insert = tuple(path if a == first else reversed(path))
                polygon = (*face[:j], *insert, *face[j + 2:])
                # A closing side needs different splice bookkeeping.
                if j == len(face) - 1:
                    polygon = (*face[:-1], *insert[:-1])
                faces[index:index + 1] = _patch(mesh, polygon)
                return
    raise ValueError("a boundary closure did not find its shared side")


def _clip_to_convex_polygon(points: Sequence[_Point], boundary: Sequence[_Point],
                            tolerance: float) -> list[_Point]:
    """Clip a source cell to the fixed polygonal contour without remeshing it."""
    polygon = list(points)
    for a, b in zip(boundary, (*boundary[1:], boundary[0])):
        if not polygon:
            break
        direction = _sub(b, a)
        epsilon = tolerance * math.hypot(*direction)
        updated = []
        for p, q in zip(polygon, (*polygon[1:], polygon[0])):
            hp = _cross(direction, _sub(p, a))
            hq = _cross(direction, _sub(q, a))
            pin, qin = hp >= -epsilon, hq >= -epsilon
            if pin:
                updated.append(p)
            if pin != qin:
                fraction = max(0., min(1., hp / (hp - hq)))
                updated.append((p[0] + fraction * (q[0] - p[0]),
                                p[1] + fraction * (q[1] - p[1])))
        polygon = updated
    return polygon


def _difference_cross(a,b): return a[0]*b[1]-a[1]*b[0]
def _difference_sub(a,b): return a[0]-b[0],a[1]-b[1]
def _difference_area(poly): return .5*sum(_difference_cross(a,b) for a,b in zip(poly,poly[1:]+poly[:1]))

def _difference_half(poly,a,b,inside,tol):
    if not poly:return []
    d=_difference_sub(b,a); epsilon=tol*math.hypot(*d)
    out=[]
    for p,q in zip(poly,poly[1:]+poly[:1]):
        hp,hq=_difference_cross(d,_difference_sub(p,a)),_difference_cross(d,_difference_sub(q,a))
        if not inside:hp,hq=-hp,-hq
        pin,qin=hp>=-epsilon,hq>=-epsilon
        if pin:out.append(p)
        if pin!=qin:
            f=max(0.,min(1.,hp/(hp-hq)))
            out.append((p[0]+f*(q[0]-p[0]),p[1]+f*(q[1]-p[1])))
    return _difference_clean(out,tol)

def _difference_clean(poly,tol):
    result=[]
    for p in poly:
        if not result or math.dist(result[-1],p)>tol:result.append(p)
    if len(result)>1 and math.dist(result[0],result[-1])<=tol:result.pop()
    return result

def _difference_edge_fraction(p,a,b,tol):
    d=_difference_sub(b,a);length=math.hypot(*d)
    if length<=tol:return None
    v=_difference_sub(p,a);u=(d[0]*v[0]+d[1]*v[1])/length**2
    if -tol/length<=u<=1+tol/length and abs(_difference_cross(d,v))<=tol*length:return max(0.,min(1.,u))
    return None

def _subtract_convex_polygon(source,inner,tolerance=1.e-9):
    """Subtract a convex contour without support-line cuts on shared edges.

    Source cells and the clipping contour are convex and counterclockwise.
    Returned boundary loops can be concave and are patched only after their
    physical boundary intersections have been mapped onto existing nodes.
    """
    source=list(source);inner=list(inner);tol=tolerance
    intersection=source
    for a,b in zip(inner,inner[1:]+inner[:1]):
        intersection=_difference_half(intersection,a,b,True,tol)
        if len(intersection)<3 or _difference_area(intersection)<=tol*tol:return [source]
    if abs(_difference_area(source)-_difference_area(intersection))<=tol*tol:return []
    pieces=[]; remaining=source
    for a,b in zip(inner,inner[1:]+inner[:1]):
        outside=_difference_half(remaining,a,b,False,tol)
        if len(outside)>=3 and _difference_area(outside)>tol*tol:pieces.append(outside)
        remaining=_difference_half(remaining,a,b,True,tol)
        if len(remaining)<3:break
    # Normalize all partition edges at shared vertices before cancelling
    # reverse edges. There are usually only a handful of terminal pieces.
    nodes=[]
    def node(p):
        for i,q in enumerate(nodes):
            if math.dist(p,q)<=tol:return i
        nodes.append(p);return len(nodes)-1
    ids=[[node(p) for p in piece] for piece in pieces]
    directed=Counter()
    for poly in ids:
        for a,b in zip(poly,poly[1:]+poly[:1]):
            chain=sorted((u,i) for i,p in enumerate(nodes)
                         if (u:=_difference_edge_fraction(p,nodes[a],nodes[b],tol)) is not None)
            for (_,i),(_,j) in zip(chain,chain[1:]):
                if i!=j:directed[i,j]+=1
    boundary={edge for edge,count in directed.items() if count>directed[edge[::-1]]}
    if any(count-directed[edge[::-1]]>1 for edge,count in directed.items()):
        raise ValueError('polygon difference overlaps')
    next_nodes={}
    for a,b in boundary:next_nodes.setdefault(a,[]).append(b)
    if any(len(v)!=1 for v in next_nodes.values()):
        raise ValueError('polygon difference has a non-manifold terminal vertex')
    loops=[]
    while boundary:
        start=min(boundary)[0]; loop=[start];current=start
        while True:
            following=next_nodes[current][0]
            boundary.remove((current,following))
            if following==start:break
            loop.append(following);current=following
        points=[nodes[i] for i in loop]
        # Delete collinear support-line intersections on source edges. A
        # neighboring cell that did not meet inner must remain unchanged.
        changed=True
        while changed and len(points)>3:
            changed=False
            for i,p in enumerate(points):
                a,b=points[i-1],points[(i+1)%len(points)]
                if _difference_edge_fraction(p,a,b,tol) is not None and not any(math.dist(p,q)<=tol for q in source):
                    points.pop(i);changed=True;break
        if _difference_area(points)<0:
            raise ValueError('polygon difference encloses a hole; split source before clipping')
        if len(points)>=3 and _difference_area(points)>tol*tol:loops.append(points)
    expected=_difference_area(source)-_difference_area(intersection)
    if abs(sum(_difference_area(p) for p in loops)-expected)>max(tol*tol,1.e-9*_difference_area(source)):
        raise ValueError('polygon difference area mismatch')
    return loops



def _boundary_location(point: _Point, path: Sequence[_Point], tolerance: float) -> float | None:
    """Return the ordered edge coordinate of a point on a frozen contour."""
    for index, (a, b) in enumerate(zip(path, path[1:])):
        direction = _sub(b, a)
        length = math.hypot(*direction)
        relative = _sub(point, a)
        fraction = _dot(relative, direction) / length**2
        if (-tolerance / length <= fraction <= 1. + tolerance / length
                and abs(_cross(direction, relative)) <= tolerance * length):
            return index + max(0., min(1., fraction))
    return None


def _circular_band_cells(mesh: _Mesh, inner: StadiumContour, outer: StadiumContour,
                         inside: Sequence[int], radial: float, angular: float,
                         sectors: int, policy: RadialSeedPolicy
                         ) -> tuple[list[list[_Point]], list[float]]:
    """Extend the original circular planner about the inner cap centres.

    Its angular transitions, including soft 2:1 transition rings, are reused
    verbatim. Only the first count is fixed by the already shared inner ring.
    The temporary outside circle encloses the destination stadium; clipping
    later terminates its regular R layers at that stadium's existing nodes.
    """
    c, lower = inner.half_straight_um, inner.radius_um
    upper = outer.radius_um + max(0., outer.half_straight_um - c)
    cap_count = sum(mesh.points[i][0] >= c - mesh.tolerance for i in inside) - 1
    first_count = cap_count // (sectors // 4)
    if first_count < 1 or first_count * (sectors // 4) != cap_count:
        raise ValueError("内侧半圆边界与原圆形扇区分段不一致。")
    parameters = MeshParameters(diameters_um=(2. * lower, 2. * upper),
                                target_xy_um=max(radial, angular),
                                symmetry_mode=SymmetryMode.XY if sectors == 4 else SymmetryMode.XY_45)
    # The tiny count offset avoids ceil(integer + roundoff). Local overrides
    # may have made this physical ring denser than the current band's target.
    first_arc = 2. * math.pi * lower / (sectors * (first_count - .25))
    requests, _ = _independent_plane_requests(
        parameters, (lower, radial), (first_arc, angular),
        (RadialSeedPolicy(), policy), sectors)
    start = next(request for request in requests if request.region == 0
                 and abs(request.radius_um - lower) <= mesh.tolerance)
    planned = [replace(start, elements_per_sector=first_count)]
    for request in (request for request in requests if request.region == 1):
        if policy.constraint == "hard":
            planned.append(request)
            continue
        previous = planned[-1]
        # Legacy circular seeds can round one count below the modern ceil
        # rule. Retain that exact boundary and use the same soft 2:1 bridge.
        steps = max(1, math.ceil(math.log2(max(request.elements_per_sector / previous.elements_per_sector,
                                              previous.elements_per_sector / request.elements_per_sector))))
        count = previous.elements_per_sector
        for step in range(1, steps):
            radius = previous.radius_um + (request.radius_um - previous.radius_um) * step / steps
            remaining = steps - step
            low = max(1, math.ceil(count / 2), math.ceil(request.elements_per_sector / 2**remaining))
            high = min(count * 2, request.elements_per_sector * 2**remaining)
            count = max(low, min(high, math.ceil(2. * math.pi * radius / (sectors * angular))))
            planned.append(replace(request, radius_um=radius, elements_per_sector=count))
        planned.append(request)
    coordinates = []
    rings = [_add_ring(coordinates, request.radius_um, request.elements_per_sector, sectors)
             for request in planned]
    source = []
    for a, b in zip(rings, rings[1:]):
        if max(a.elements_per_sector, b.elements_per_sector) <= 2 * min(a.elements_per_sector, b.elements_per_sector):
            for face in _connect_rings(a, b, 0):
                points = [(coordinates[i][0] / UM_TO_MM + c, coordinates[i][1] / UM_TO_MM)
                          for i in face.node_ids]
                if all(x >= c - mesh.tolerance and y >= -mesh.tolerance for x, y in points):
                    source.append(points)
        else:
            # A fixed hard R jump cannot acquire extra intermediate rings.
            # Retain its prescribed angular counts and use the existing
            # ordered multi-triangle connection for this exceptional closure.
            work = _Mesh(outer.long_diameter_um)
            chains = [[work.node((coordinates[i][0] / UM_TO_MM + c, coordinates[i][1] / UM_TO_MM))
                       for i in ring.node_ids[:ring.angular_node_count // 4 + 1]] for ring in (a, b)]
            source.extend([[work.points[i] for i in face] for face in _connect_chains(work, *chains)])
    radii = [request.radius_um for request in planned]
    if c > mesh.tolerance:
        # The straight rows extend those same circles. Their first row reuses
        # every existing physical vertex, including a finer adjacent override.
        work = _Mesh(outer.long_diameter_um)
        rows = [[work.node(mesh.points[i]) for i in inside if mesh.points[i][0] <= c + mesh.tolerance]]
        count = max(1, math.ceil(c / angular))
        rows.extend([work.node((c * j / count, radius)) for j in range(count + 1)] for radius in radii[1:])
        for a, b in zip(rows, rows[1:]):
            source.extend([[work.points[i] for i in face] for face in _connect_chains(work, a, b)])
    return source, radii


def _outer_circular_band_cells(mesh: _Mesh, inner: StadiumContour, outer: StadiumContour,
                               outside: Sequence[int], radial: float, angular: float,
                               sectors: int, policy: RadialSeedPolicy
                               ) -> tuple[list[list[_Point]], list[float]]:
    """Build actual outside-in seed fronts about the outer cap centres."""
    c, radius = outer.half_straight_um, outer.radius_um
    count = (sum(mesh.points[i][0] >= c - mesh.tolerance for i in outside) - 1) // (sectors // 4)
    lower = min(inner.radius_um, max(inner.long_radius_um - c, 0.))
    has_core = lower > MIN_NUMERICAL_SEPARATION_UM
    parameters = MeshParameters(diameters_um=(2. * lower, 2. * radius) if has_core else (2. * radius,),
                                target_xy_um=max(radial, angular),
                                symmetry_mode=SymmetryMode.XY if sectors == 4 else SymmetryMode.XY_45)
    requests, _ = _independent_plane_requests(parameters, (lower, radial) if has_core else (radial,),
                                              (angular, angular) if has_core else (angular,),
                                              (RadialSeedPolicy(), policy) if has_core else (policy,), sectors)
    requests[-1] = replace(requests[-1], elements_per_sector=count)
    # This is the original hard-ring angular propagation, anchored to the
    # already frozen outside boundary. It changes counts, never hard R seeds.
    for index in range(len(requests) - 2, -1, -1):
        requests[index] = replace(requests[index], elements_per_sector=max(
            requests[index].elements_per_sector, math.ceil(requests[index + 1].elements_per_sector / 2)))
    # Extremely thin hard layers cannot safely change polygonal circle
    # counts: their chords can cross even though the analytic circles nest.
    # Coordinate counts inward, keeping every R seed and the true outside
    # boundary fixed. Ordinary source-ring transitions remain unchanged.
    for index in range(len(requests) - 2, -1, -1):
        a, b = requests[index:index + 2]
        if max(a.elements_per_sector, b.elements_per_sector) > 2 * min(a.elements_per_sector, b.elements_per_sector):
            requests[index] = replace(a, elements_per_sector=b.elements_per_sector)
            continue
        probe_coordinates = []
        probe_inner = _add_ring(probe_coordinates, a.radius_um, a.elements_per_sector, sectors)
        probe_outer = _add_ring(probe_coordinates, b.radius_um, b.elements_per_sector, sectors)
        probe = _Mesh(outer.long_diameter_um)
        for point in probe_coordinates:
            probe.node((point[0] / UM_TO_MM, point[1] / UM_TO_MM))
        if any(probe.quality(face.node_ids) <= 1.e-10
               for face in _connect_rings(probe_inner, probe_outer, 0)):
            requests[index] = replace(a, elements_per_sector=b.elements_per_sector)
    coordinates = [(0., 0.)]
    rings = [_add_ring(coordinates, request.radius_um, request.elements_per_sector, sectors) for request in requests]
    source = []
    first = rings[0]
    all_faces = [Face2D((0, first.node_ids[i], first.node_ids[(i + 1) % first.angular_node_count]), 0)
                 for i in range(first.angular_node_count)]
    all_faces.extend(face for a, b in zip(rings, rings[1:]) for face in _connect_rings(a, b, 0))
    for face in all_faces:
        points = [(coordinates[i][0] / UM_TO_MM + c, coordinates[i][1] / UM_TO_MM) for i in face.node_ids]
        if all(x >= c - mesh.tolerance and y >= -mesh.tolerance for x, y in points):
            source.append(points)
    radii = [0., *(request.radius_um for request in requests)]
    if c > mesh.tolerance:
        work = _Mesh(outer.long_diameter_um)
        count = max(1, math.ceil(c / angular))
        rows = [[work.node((c * j / count, r)) for j in range(count + 1)] for r in radii[:-1]]
        rows.append([work.node(mesh.points[i]) for i in outside if mesh.points[i][0] <= c + mesh.tolerance])
        for a, b in zip(rows, rows[1:]):
            source.extend([[work.points[i] for i in face] for face in _connect_chains(work, a, b)])
    return source, radii


def _restore_contour_vertices(mesh: _Mesh, faces: list[tuple[int, ...]],
                              paths: Sequence[Sequence[int]]) -> None:
    """Clipping may elide collinear vertices; retain them in the final closure."""
    for path in paths:
        positions = {node: index for index, node in enumerate(path)}
        incidence = Counter(tuple(sorted((a, b))) for face in faces
                            for a, b in zip(face, (*face[1:], face[0])))
        for (a, b), count in incidence.items():
            if count == 1 and a in positions and b in positions and abs(positions[a] - positions[b]) > 1:
                low, high = sorted((positions[a], positions[b]))
                _replace_boundary_side(mesh, faces, path[low:high + 1])
            elif count == 1 and (a not in positions or b not in positions):
                # An exact hard front can continue a physical straight edge
                # beyond its cap tangent. One endpoint is then a source seed,
                # yet any physical vertices along the edge must still survive.
                pa, pb = mesh.points[a], mesh.points[b]
                dx, dy = _sub(pb, pa)
                length_squared = dx * dx + dy * dy
                if length_squared <= mesh.tolerance * mesh.tolerance:
                    continue
                interior = []
                for node in path:
                    offset = _sub(mesh.points[node], pa)
                    fraction = (offset[0] * dx + offset[1] * dy) / length_squared
                    if (mesh.tolerance < fraction < 1. - mesh.tolerance
                            and abs(_cross((dx, dy), offset)) <= mesh.tolerance * math.sqrt(length_squared)):
                        interior.append((fraction, node))
                if interior:
                    _replace_boundary_side(mesh, faces, [a, *(node for _, node in sorted(interior)), b])


def _band_boundary(mesh: _Mesh, faces: Sequence[Sequence[int]],
                   inside: Sequence[int], outside: Sequence[int]) -> list[int]:
    used = {i for face in faces for i in face}
    x_axis = sorted((i for i in used if abs(mesh.points[i][1]) <= mesh.tolerance
                     and mesh.points[inside[-1]][0] - mesh.tolerance <= mesh.points[i][0]
                     <= mesh.points[outside[-1]][0] + mesh.tolerance), key=lambda i: mesh.points[i][0])
    y_axis = sorted((i for i in used if abs(mesh.points[i][0]) <= mesh.tolerance
                     and mesh.points[inside[0]][1] - mesh.tolerance <= mesh.points[i][1]
                     <= mesh.points[outside[0]][1] + mesh.tolerance), key=lambda i: -mesh.points[i][1])
    return [*inside, *x_axis[1:], *list(reversed(outside))[1:], *y_axis[1:-1]]


def _contract_terminal_nodes(mesh, faces, inside, outside, terminal, angular_target_um,
                            *, poor_quality=.18, max_distance_fraction=.5,
                            radial_target=None, reference=None, remainder_ratio=None):
    """Return (faces, contractions); the coordinate array is never moved.

    `terminal` is the clipped physical contour (outside for an inner reference,
    inside for an outer reference). Faces can initially have a folded boundary
    star, but the caller must validate the complete result before accepting it.
    """
    faces=list(faces)
    used={node for face in faces for node in face}
    protected=set(inside)|set(outside)
    targets=set(terminal)
    physical_boundary={tuple(sorted((a,b))) for path in (inside,outside) for a,b in zip(path,path[1:])}
    def expected_boundary(candidate):
        boundary=set(physical_boundary)
        candidate_used={node for face in candidate for node in face}|protected
        for fixed_axis,sort_axis in ((0,1),(1,0)):
            axis=sorted((node for node in candidate_used
                         if abs(mesh.points[node][fixed_axis])<=mesh.tolerance),
                        key=lambda node:mesh.points[node][sort_axis])
            boundary.update(tuple(sorted((a,b))) for a,b in zip(axis,axis[1:]))
        return boundary

    residual_limit=(float(radial_target)*float(remainder_ratio)
                    if radial_target is not None and reference is not None
                    and remainder_ratio is not None else 0.)
    direction=-1. if targets==set(inside) else 1.
    def residual_candidate(node,target):
        if residual_limit<=mesh.tolerance:return False
        p,q=mesh.points[node],mesh.points[target]
        c=reference.half_straight_um
        rp=math.hypot(max(p[0]-c,0.),p[1]);rq=math.hypot(max(q[0]-c,0.),q[1])
        residual=direction*(rq-rp)
        if residual < -mesh.tolerance or residual >= residual_limit-mesh.tolerance:return False
        # The terminal node must close the same local front, not another
        # physical segment reached by a long circumferential contraction.
        x=(p[0]+q[0])*.5;y=(p[1]+q[1])*.5
        nx=max(x-c,0.);norm=math.hypot(nx,y)
        if norm<=mesh.tolerance:return False
        tangent=abs((q[0]-p[0])*(-y/norm)+(q[1]-p[1])*(nx/norm))
        return tangent<=max_distance_fraction*angular_target_um+mesh.tolerance

    def defects(candidate):
        boundary=expected_boundary(candidate)
        directed=Counter((a,b) for face in candidate for a,b in zip(face,(*face[1:],face[0])))
        edges=Counter()
        for edge,count in directed.items():edges[tuple(sorted(edge))]+=count
        bad=sum(count not in (1,2) or count==2 and
                (directed[edge]!=1 or directed[edge[::-1]]!=1) for edge,count in edges.items())
        bad+=len(boundary^{edge for edge,count in edges.items() if count==1})
        vertices={node for face in candidate for node in face}
        bad+=abs(len(vertices)-len(edges)+len(candidate)-1)
        return bad

    changes=[]
    for _ in range(len(used-protected)):
        current_bad=defects(faces)
        adjacency=defaultdict(list)
        for index,face in enumerate(faces):
            for node in face:adjacency[node].append(index)
        best=None
        for node in sorted(adjacency.keys()-protected):
            incident=adjacency[node]
            old_quality=min(mesh.quality(faces[index]) for index in incident)
            neighbors={target for index in incident for target in faces[index] if target in targets}
            for target in sorted(neighbors,key=lambda other:(math.dist(mesh.points[node],mesh.points[other]),other)):
                axis=[j for j in (0,1) if abs(mesh.points[node][j])<=mesh.tolerance]
                if axis and any(abs(mesh.points[target][j])>mesh.tolerance for j in axis):continue
                remainder=residual_candidate(node,target)
                if axis and not remainder:continue
                if not remainder:
                    if old_quality>=poor_quality and not current_bad:continue
                    if math.dist(mesh.points[node],mesh.points[target])>max_distance_fraction*angular_target_um:continue
                updates={};qualities=[]
                for index in incident:
                    replacement=[]
                    for vertex in faces[index]:
                        vertex=target if vertex==node else vertex
                        if not replacement or replacement[-1]!=vertex:replacement.append(vertex)
                    if len(replacement)>1 and replacement[0]==replacement[-1]:replacement.pop()
                    if len(replacement)<3:
                        updates[index]=None
                        continue
                    if len(set(replacement))!=len(replacement):break
                    points=[mesh.points[vertex] for vertex in replacement]
                    origin=points[0]
                    shifted=[(x-origin[0],y-origin[1]) for x,y in points]
                    area=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(shifted,shifted[1:]+shifted[:1]))
                    # Never reorient a flipped face to make it look valid.
                    if area<=mesh.area_tolerance:break
                    quality=mesh.quality(replacement)
                    if quality<=1.e-10:break
                    updates[index]=tuple(replacement);qualities.append(quality)
                else:
                    candidate=[updates.get(index,face) for index,face in enumerate(faces)
                               if updates.get(index,face) is not None]
                    bad=defects(candidate)
                    quality=min(qualities,default=1.)
                    if bad>current_bad:continue
                    if bad==current_bad:
                        if remainder:
                            # A geometric merge may sacrifice some angle, but
                            # never turn a usable patch into a sliver.
                            if quality<min(old_quality,poor_quality)-1.e-10:continue
                        elif quality<=old_quality*1.1:continue
                    score=(current_bad-bad,int(remainder),quality,-node,-target)
                    if best is None or score>best[0]:best=(score,node,target,candidate)
        if best is None:break
        _,node,target,faces=best
        changes.append((node,target))
    return faces,changes



def _relax_terminal_tangents(mesh, faces, inside, outside, terminal, reference,
                             angular_target_um, *, max_move_fraction=.25, passes=3):
    """Slide only terminal seeds on unchanged source fronts; return moves.

    Use for soft mode after a valid contraction result. Every trial retains
    positive face orientation and convexity and improves the local worst corner.
    All movement remains within 25% of the angular target from the original
    seed, regardless of the number of passes. Symmetry seams stay fixed.
    """
    used={node for face in faces for node in face}
    protected=set(inside)|set(outside)
    protected.update(node for node in used if min(abs(value) for value in mesh.points[node])<=mesh.tolerance)
    boundary=set(terminal)
    incident=defaultdict(list);eligible=set()
    for index,face in enumerate(faces):
        for node in face:incident[node].append(index)
        if boundary.intersection(face):eligible.update(face)
    eligible=sorted(eligible-protected)
    c=reference.half_straight_um
    original={node:mesh.points[node] for node in used}
    radii={node:math.hypot(max(point[0]-c,0.),point[1]) for node,point in original.items()}
    def position(point,radius):
        x,y=point
        return x if x<=c else c+radius*math.atan2(x-c,y)
    original_s={node:position(point,radii[node]) for node,point in original.items()}
    groups=[];level_tolerance=max(mesh.tolerance*20,1.e-9)
    for node in sorted(used-protected,key=lambda node:radii[node]):
        if not groups or abs(radii[node]-radii[groups[-1][0]])>level_tolerance:groups.append([node])
        else:groups[-1].append(node)
    neighbors={}
    for group in groups:
        group.sort(key=lambda node:original_s[node])
        for index,node in enumerate(group):
            neighbors[node]=(group[index-1] if index else None,
                             group[index+1] if index+1<len(group) else None)
    max_shift=max_move_fraction*angular_target_um;moves=[]
    for _ in range(passes):
        accepted=0
        for node in eligible:
            local=[faces[index] for index in incident[node]]
            old_quality=min(mesh.quality(face) for face in local)
            if old_quality>=.5:continue
            old_point=mesh.points[node];radius=radii[node]
            old_tangent=max(stadium_cell_spans_um(reference,[mesh.points[i] for i in face])[1] for face in local)
            previous,next_=neighbors.get(node,(None,None))
            low=0. if previous is None else position(mesh.points[previous],radii[previous])+mesh.tolerance*10
            high=c+radius*math.pi*.5 if next_ is None else position(mesh.points[next_],radii[next_])-mesh.tolerance*10
            best=(old_quality,0.,old_point)
            for fraction in (-1.,-.5,-.25,.25,.5,1.):
                s=original_s[node]+max_shift*fraction
                if not low<s<high:continue
                if s<=c:point=(s,radius)
                else:
                    theta=(s-c)/radius
                    point=(c+radius*math.sin(theta),radius*math.cos(theta))
                key=tuple(round(value/mesh.tolerance) for value in point)
                if key in mesh.keys and mesh.keys[key]!=node:continue
                mesh.points[node]=point;qualities=[]
                for face in local:
                    pts=[mesh.points[i] for i in face];origin=pts[0]
                    shifted=[(x-origin[0],y-origin[1]) for x,y in pts]
                    area=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(shifted,shifted[1:]+shifted[:1]))
                    if area<=mesh.area_tolerance:qualities=[];break
                    quality=mesh.quality(face)
                    if quality<=1.e-10:qualities=[];break
                    span=stadium_cell_spans_um(reference,pts)[1]
                    if span>max(old_tangent+0.1*angular_target_um,1.5*angular_target_um):qualities=[];break
                    front_edges = [(a,b) for a,b in zip(face,(*face[1:],face[0]))
                                   if abs(radii[a]-radii[b]) <= level_tolerance]
                    if any(abs(position(mesh.points[a],radii[a])-position(mesh.points[b],radii[b]))
                           > max(abs(original_s[a]-original_s[b]),1.25*angular_target_um)*(1.+1.e-10)
                           for a,b in front_edges):
                        qualities=[];break
                    qualities.append(quality)
                if qualities:
                    value=(min(qualities),-abs(s-original_s[node]),point)
                    if value[:2]>best[:2]:best=value
                mesh.points[node]=old_point
            if best[0]>old_quality+1.e-8:
                old_key=tuple(round(value/mesh.tolerance) for value in old_point)
                if mesh.keys.get(old_key)==node:del mesh.keys[old_key]
                mesh.points[node]=best[2]
                mesh.keys[tuple(round(value/mesh.tolerance) for value in best[2])]=node
                moves.append((node,old_point,best[2]));accepted+=1
        if not accepted:break
    return moves


def _optimize_terminal_seeds(mesh, faces, inside, outside, terminal, reference,
                            angular_target_um, *, radial_target_um):
    """Improve soft cells and propagate their displacement along source rows.

    Tangential relaxation supplies a valid starting mesh. The bounded second
    pass coordinates normal and tangential motion along the original circle
    connections. It preserves physical nodes and front order, keeps axis seeds
    on their axes, and fades into unchanged distant cells. Hard seeds never
    enter this path.
    """
    original = {node: mesh.points[node] for face in faces for node in face}
    _relax_terminal_tangents(mesh, faces, inside, outside, terminal, reference,
                             angular_target_um)
    uniformize_terminal_seeds(mesh, faces, inside, outside, terminal, reference,
                              radial_target_um, angular_target_um,
                              reference_points=original)
    return [(node, point, mesh.points[node]) for node, point in sorted(original.items())
            if math.dist(point, mesh.points[node]) > mesh.tolerance]


def _merge_center_seam(mesh: _Mesh, faces: list[tuple[int, ...]], inside: Sequence[int],
                       outside: Sequence[int], seam: Sequence[int], inner: StadiumContour,
                       outer: StadiumContour, target: float, policy: RadialSeedPolicy
                       ) -> list[tuple[int, ...]]:
    """Remove only virtual centre seeds selected by the two-front policy.

    The first threshold has already merged each half's small terminal layer.
    Centre merging contracts virtual seam vertices onto surviving hard front
    vertices; it never moves a hard seed or a physical boundary node.
    """
    candidates = []
    for node in seam:
        p = mesh.points[node]
        ratios = (inner.signed_distance_um(*p) / target, -outer.signed_distance_um(*p) / target)
        if any(math.isclose(r, round(r), rel_tol=1.e-10, abs_tol=1.e-10) for r in ratios):
            continue  # this centre vertex is itself an exact hard front
        remainders = tuple(r - math.floor(r) for r in ratios)
        if any(r < policy.remainder_ratio - 1.e-10 and math.floor(total) > 0
               for r, total in zip(remainders, ratios)):
            continue  # a terminal layer was absorbed into its preceding layer
        if all(r <= policy.center_merge_ratio + 1.e-10 for r in remainders):
            candidates.append(node)
    physical = set(inside) | set(outside)
    seam_nodes = set(seam)
    for node in candidates:
        if node in physical:
            continue
        incident = [index for index, face in enumerate(faces) if node in face]
        if not incident:
            continue
        neighbors = set()
        for index in incident:
            face = faces[index]
            position = face.index(node)
            neighbors.update((face[position - 1], face[(position + 1) % len(face)]))
        neighbors -= seam_nodes
        point = mesh.points[node]
        axis = next((axis for axis in (0, 1) if abs(point[axis]) <= mesh.tolerance), None)
        if axis is not None:
            neighbors = {other for other in neighbors if abs(mesh.points[other][axis]) <= mesh.tolerance}
        best = None
        for other in sorted(neighbors, key=lambda i: (math.dist(mesh.points[i], point), i))[:4]:
            updates = {}
            quality = 1.
            for index in incident:
                replacement = []
                for vertex in faces[index]:
                    vertex = other if vertex == node else vertex
                    if not replacement or vertex != replacement[-1]:
                        replacement.append(vertex)
                if len(replacement) > 1 and replacement[0] == replacement[-1]:
                    replacement.pop()
                if len(replacement) < 3:
                    updates[index] = ()
                    continue
                if len(set(replacement)) != len(replacement) or _twice_area(mesh.points, replacement) <= mesh.area_tolerance:
                    break
                if mesh.quality(replacement) <= 1.e-10:
                    break
                updates[index] = (tuple(replacement),)
                quality = min(quality, mesh.quality(replacement))
            else:
                candidate = [part for index, face in enumerate(faces) for part in updates.get(index, (face,))]
                try:
                    _validate_patch(candidate, _band_boundary(mesh, candidate, inside, outside))
                except ValueError:
                    continue
                score = (quality, -math.dist(point, mesh.points[other]), -other)
                if best is None or score > best[0]:
                    best = score, candidate
        if best is not None:
            faces = best[1]
    return faces


def _recombine_terminal_triangles(mesh: _Mesh, faces: Sequence[tuple[int, ...]],
                                  terminal: Sequence[int], reference: StadiumContour,
                                  radial_target: float, angular_target: float
                                  ) -> list[tuple[int, ...]]:
    """Remove an unnecessary diagonal between two terminal triangles.

    A candidate must touch the clipped contour. Its nodes and four outside
    edges already exist; only their shared diagonal is removed. Sorting valid
    candidates by corner quality makes the matching deterministic and keeps a
    thin terminal triangle from consuming a better neighboring quadrilateral.
    """
    terminal_nodes = set(terminal)
    edges: dict[tuple[int, int], list[int]] = defaultdict(list)
    for index, face in enumerate(faces):
        for a, b in zip(face, (*face[1:], face[0])):
            edges[tuple(sorted((a, b)))].append(index)
    candidates = []
    for adjacent in edges.values():
        if len(adjacent) != 2:
            continue
        first, second = adjacent
        pair = faces[first], faces[second]
        if (any(len(face) != 3 for face in pair)
                or not any(terminal_nodes.intersection(face) for face in pair)):
            continue
        directed = [(a, b) for face in pair for a, b in zip(face, (*face[1:], face[0]))]
        boundary = [(a, b) for a, b in directed if (b, a) not in directed]
        following = dict(boundary)
        if len(boundary) != 4 or len(following) != 4:
            continue
        quad = [min(following)]
        for _ in range(3):
            quad.append(following[quad[-1]])
        if len(set(quad)) != 4 or following[quad[-1]] != quad[0]:
            continue
        quad = tuple(quad)
        area = _twice_area(mesh.points, quad) * .5
        if area <= mesh.area_tolerance:
            continue
        quality = mesh.quality(quad)
        old_quality = min(mesh.quality(face) for face in pair)
        if quality < max(.2, min(old_quality, .5)):
            continue
        old_spans = [stadium_cell_spans_um(reference, [mesh.points[i] for i in face]) for face in pair]
        spans = stadium_cell_spans_um(reference, [mesh.points[i] for i in quad])
        # Existing circular transitions can legitimately span more than one
        # angular segment. Keep that envelope, but do not combine two R layers
        # or two full circumferential cells merely to reduce triangle counts.
        if (spans[0] > 1.5 * radial_target + mesh.tolerance
                or spans[1] > max(1.5 * angular_target, *(old[1] for old in old_spans)) + mesh.tolerance):
            continue
        old_areas = [_twice_area(mesh.points, face) * .5 for face in pair]
        nominal_area = radial_target * angular_target
        if (area > max(1.5 * nominal_area, *old_areas) + mesh.area_tolerance
                or abs(area - sum(old_areas)) > max(area * 1.e-10, mesh.area_tolerance * 8)):
            continue
        candidates.append((-quality, abs(area / nominal_area - 1.), first, second, quad))
    replacements = {}
    removed = set()
    for _, _, first, second, quad in sorted(candidates):
        if first in replacements or second in replacements or first in removed or second in removed:
            continue
        replacements[first] = quad
        removed.add(second)
    return [replacements.get(index, face) for index, face in enumerate(faces) if index not in removed]


def _two_front_band(mesh: _Mesh, inner: StadiumContour, outer: StadiumContour,
                    inside: Sequence[int], outside: Sequence[int], target: float,
                    angular_target: float, sectors: int, policy: RadialSeedPolicy
                    ) -> tuple[list[tuple[int, ...]], list[float], int]:
    middle = StadiumContour((inner.long_diameter_um + outer.long_diameter_um) * .5,
                            (inner.short_diameter_um + outer.short_diameter_um) * .5)
    c, radius = middle.half_straight_um, middle.radius_um
    count = max(1, math.ceil(2. * math.pi * radius / (sectors * angular_target))) * (sectors // 4)
    straight = max(1, math.ceil(c / angular_target)) if c > mesh.tolerance else 0
    seam = [mesh.node((c * j / straight, radius)) for j in range(straight)]
    seam.extend(mesh.node((c + radius * math.sin(math.pi * j / (2 * count)),
                           radius * math.cos(math.pi * j / (2 * count)))) for j in range(count + 1))
    first, _, first_layers = _adaptive_band(mesh, inner, middle, inside, seam, target, angular_target,
                                           sectors, replace(policy, direction="inner"))
    second, _, second_layers = _adaptive_band(mesh, middle, outer, seam, outside, target, angular_target,
                                             sectors, replace(policy, direction="outer"))
    faces = first + second
    if policy.constraint == "hard":
        faces = _merge_center_seam(mesh, faces, inside, outside, seam, inner, outer, target, policy)
    _validate_patch(faces, _band_boundary(mesh, faces, inside, outside))
    widths = [stadium_cell_spans_um(inner, [mesh.points[i] for i in face])[0] for face in faces]
    return faces, widths, first_layers + second_layers


def _adaptive_band(mesh: _Mesh, inner: StadiumContour, outer: StadiumContour,
                   inside: Sequence[int], outside: Sequence[int], target: float, angular_target: float,
                   sectors: int = 8, policy: RadialSeedPolicy = RadialSeedPolicy()
                   ) -> tuple[list[tuple[int, ...]], list[float], int]:
    """Terminate ordered original-circle layers at the fixed outer boundary.

    Complete source cells remain unchanged. Boundary intersections are
    monotonically contracted onto existing contour nodes; only those terminal
    cells use local triangle closures. No interior subdivision is performed.
    """
    if policy.direction == "both_r":
        return _two_front_band(mesh, inner, outer, inside, outside, target, angular_target, sectors, policy)
    from_outer = policy.direction == "outer"
    source, radii = (_outer_circular_band_cells(mesh, inner, outer, outside, target, angular_target, sectors, policy)
                     if from_outer else _circular_band_cells(mesh, inner, outer, inside, target, angular_target, sectors, policy))
    outer_points = [mesh.points[i] for i in outside]
    inner_points = [mesh.points[i] for i in inside]
    terminal = inside if from_outer else outside
    terminal_points = inner_points if from_outer else outer_points
    boundary = [(0., 0.), *reversed(outer_points)]
    inner_boundary = [(0., 0.), *reversed(inner_points)]
    clipped = []
    locations = {}
    physical = set(inside) | set(outside)
    for cell in source:
        pieces = (_subtract_convex_polygon(cell, inner_boundary, mesh.tolerance)
                  if from_outer else [_clip_to_convex_polygon(cell, boundary, mesh.tolerance)])
        for points in pieces:
            if len(points) < 3:
                continue
            nodes = []
            for point in points:
                node = mesh.node(point)
                if not nodes or node != nodes[-1]:
                    nodes.append(node)
                if node not in physical:
                    location = _boundary_location(point, terminal_points, mesh.tolerance * 8)
                    if location is not None:
                        locations[node] = location
            if len(nodes) > 1 and nodes[0] == nodes[-1]:
                nodes.pop()
            if len(nodes) >= 3 and abs(_twice_area(mesh.points, nodes)) > mesh.area_tolerance:
                clipped.append(tuple(nodes))
    expected_area = (_polygon_area_um2(boundary)
                     - _polygon_area_um2([(0., 0.), *(mesh.points[i] for i in reversed(inside))]))

    def close_at_boundary(bias):
        mapping = {node: terminal[min(len(terminal) - 1, math.floor(location + bias))]
                   for node, location in locations.items()}
        faces = []
        for cell in clipped:
            nodes = []
            for node in cell:
                node = mapping.get(node, node)
                if not nodes or node != nodes[-1]:
                    nodes.append(node)
            if len(nodes) > 1 and nodes[0] == nodes[-1]:
                nodes.pop()
            if len(set(nodes)) < 3:
                continue
            if len(nodes) != len(set(nodes)):
                raise ValueError("外轮廓终止单元折叠；请细化环向尺寸。")
            area = _twice_area(mesh.points, nodes)
            if abs(area) <= mesh.area_tolerance:
                continue
            if area < 0.:
                faces.append(tuple(nodes))  # a terminal star may contract away this sliver
            else:
                faces.extend(_patch(mesh, nodes))
        _restore_contour_vertices(mesh, faces, (inside, outside))
        faces, _ = _contract_terminal_nodes(
            mesh, faces, inside, outside, terminal, angular_target,
            radial_target=target,
            reference=outer if from_outer else inner,
            remainder_ratio=policy.remainder_ratio if policy.constraint == "hard" else .25)
        if any(_twice_area(mesh.points, face) <= mesh.area_tolerance or mesh.quality(face) <= 1.e-10 for face in faces):
            raise ValueError("外轮廓终止单元无法在保留硬种子时消除折叠；请细化环向尺寸。")
        _validate_patch(faces, _band_boundary(mesh, faces, inside, outside))
        actual_area = sum(_twice_area(mesh.points, face) * .5 for face in faces)
        if abs(actual_area - expected_area) > max(expected_area * 1.e-9, mesh.area_tolerance * len(faces) * 8):
            raise ValueError("原圆形终止网格发生重叠或缺口；请细化环向尺寸。")
        return faces

    failure = None
    # Ordered bias alternatives address a cut passing extremely close to a
    # source vertex. They change only terminal contractions, never the source
    # layers, physical boundary positions, or any neighboring physical band.
    for bias in (.5, .25, .75, 0., 1.):
        try:
            faces = close_at_boundary(bias)
            break
        except ValueError as error:
            failure = error
    else:
        raise ValueError("固定外轮廓无法收束原圆形环带；请细化环向尺寸。") from failure
    faces = _recombine_terminal_triangles(mesh, faces, terminal, outer if from_outer else inner,
                                          target, angular_target)
    if policy.constraint == "soft":
        _optimize_terminal_seeds(mesh, faces, inside, outside, terminal,
                                 outer if from_outer else inner, angular_target,
                                 radial_target_um=target)
        _validate_patch(faces, _band_boundary(mesh, faces, inside, outside))
    _validate_patch(faces, _band_boundary(mesh, faces, inside, outside))
    widths = [stadium_cell_spans_um(inner, [mesh.points[i] for i in face])[0] for face in faces]
    return faces, widths, len(radii) - 1

def _quarter(mesh: _Mesh, nodes: Sequence[int]) -> list[int]:
    return sorted((i for i in nodes if mesh.points[i][0] >= -mesh.tolerance
                   and mesh.points[i][1] >= -mesh.tolerance),
                  key=lambda i: math.atan2(mesh.points[i][0], mesh.points[i][1]))


def _validate_patch(faces: Iterable[Sequence[int]], outer: Sequence[int]) -> None:
    faces = tuple(tuple(face) for face in faces)
    directed = Counter((a, b) for face in faces
                       for a, b in zip(face, (*face[1:], face[0])))
    edges = Counter()
    for edge, count in directed.items():
        edges[tuple(sorted(edge))] += count
    boundary = {tuple(sorted((a, b))) for a, b in zip(outer, (*outer[1:], outer[0]))}
    if any(n not in (1, 2) for n in edges.values()) or {e for e, n in edges.items() if n == 1} != boundary:
        raise ValueError("单 bump 网格存在未共享的内部边界。")
    if any(n == 2 and (directed[a, b] != 1 or directed[b, a] != 1)
           for (a, b), n in edges.items()):
        raise ValueError("单 bump 网格连接发生折叠。")
    used = {i for face in faces for i in face}
    if len(used) - len(edges) + len(faces) != 1:
        raise ValueError("单 bump 网格拓扑未形成连续平面。")


def _check_disk(mesh: _Mesh, outer: Sequence[int]) -> None:
    _validate_patch((face.node_ids for face in mesh.faces), outer)


@functools.lru_cache(maxsize=16)
def _build_cached(parameters: MeshParameters, contours: tuple[StadiumContour, ...],
                  radial: tuple[float, ...], angular: tuple[float, ...],
                  policies: tuple[RadialSeedPolicy, ...],
                  canonical_angular_target_um: float | None = None,
                  legacy_circular_source: bool = False) -> TopologyPlan:
    circle_parameters = replace(parameters, diameters_um=tuple(c.short_diameter_um for c in contours))
    circle = build_topology_with_radial_targets(circle_parameters, radial,
                                                policies, angular_target_sizes_um=None if legacy_circular_source else angular,
                                                canonical_ring_mesh=canonical_angular_target_um is not None,
                                                canonical_angular_target_um=canonical_angular_target_um)
    if all(c.is_circle for c in contours):
        # Honour the caller's circular symmetry choice and exact old path.
        return build_topology_with_radial_targets(parameters, radial, policies,
                                                  angular_target_sizes_um=angular,
                                                  canonical_ring_mesh=canonical_angular_target_um is not None,
                                                  canonical_angular_target_um=canonical_angular_target_um)
    mesh = _Mesh(max(c.long_diameter_um for c in contours))
    source = tuple((x / UM_TO_MM, y / UM_TO_MM) for x, y in circle.coordinates_mm)
    physical = []
    boundary_n = []
    for region, contour in enumerate(contours):
        ring = next(r for r in circle.rings if math.isclose(r.radius_um, contour.radius_um,
                                                          rel_tol=1.e-10, abs_tol=mesh.tolerance))
        c = contour.half_straight_um
        arc_target = min(angular[region:region + 2])
        n = math.ceil(c / arc_target) if c > mesh.tolerance else 0
        boundary_n.append(n)
        ids = set()
        for old in ring.node_ids:
            x, y = source[old]
            for side in ((-1., 1.) if abs(x) <= mesh.tolerance else ((1.,) if x > 0. else (-1.,))):
                ids.add(mesh.node((x + side * c, y)))
        for j in range(-n, n + 1) if n else ():
            for sy in (-1., 1.):
                ids.add(mesh.node((c * j / n, sy * contour.radius_um)))
        physical.append(tuple(sorted(ids, key=lambda i: math.atan2(mesh.points[i][1], mesh.points[i][0]))))
    region_widths = []
    outer_layers = []
    for region, contour in enumerate(contours):
        lower = contours[region - 1] if region else None
        changed = lower is not None and abs(contour.half_straight_um - lower.half_straight_um) > mesh.tolerance
        if changed:
            inside, outside = _quarter(mesh, physical[region - 1]), _quarter(mesh, physical[region])
            try:
                quarter, widths, layers = _adaptive_band(mesh, lower, contour, inside, outside, radial[region], angular[region],
                                                         circle.sector_count, policies[region])
            except ValueError as error:
                # Do not silently turn a wide band into a one-layer triangle
                # mesh and report its full width as the requested R spacing.
                raise ValueError(
                    f"Oblong 区间 {lower} → {contour} 无法在保留物理边界时建立有效局部 R 层；"
                    "请细化该区间的环向尺寸。"
                ) from error
            mesh.mirror(quarter, region)
        else:
            c = contour.half_straight_um
            for face in circle.faces:
                if face.region != region:
                    continue
                side = 1. if sum(source[i][0] for i in face.node_ids) > 0. else -1.
                mesh.add([mesh.node((source[i][0] + side * c, source[i][1]))
                          for i in face.node_ids], region)
            bottom = lower.radius_um if lower else 0.
            radii = [bottom] + [r.radius_um for r in circle.rings
                                if bottom + mesh.tolerance < r.radius_um <= contour.radius_um + mesh.tolerance]
            widths = [b - a for a, b in zip(radii, radii[1:])]
            layers = len(widths)
            if c > mesh.tolerance:
                rows = []
                for row, r in enumerate(radii):
                    n = (boundary_n[region - 1] if lower and row == 0 else
                         boundary_n[region] if row == len(radii) - 1 else max(1, math.ceil(c / angular[region])))
                    rows.append([mesh.node((c * j / n, r)) for j in range(n + 1)])
                for a, b in zip(rows, rows[1:]):
                    mesh.mirror(_connect_chains(mesh, a, b), region)
        region_widths.append((min(widths), max(widths)))
        if region:
            outer_layers.append(layers)
    _check_disk(mesh, physical[-1])
    # Remove construction nodes from failed local attempts. Face/contour nodes
    # are remapped together, so every physical boundary remains shared.
    used = sorted({i for f in mesh.faces for i in f.node_ids})
    remap = {old: new for new, old in enumerate(used)}
    coordinates = tuple((mesh.points[i][0] * UM_TO_MM, mesh.points[i][1] * UM_TO_MM) for i in used)
    faces = tuple(Face2D(tuple(remap[i] for i in f.node_ids), f.region) for f in mesh.faces)
    physical = [tuple(remap[i] for i in ids) for ids in physical]
    edges = _unique_edge_lengths_um(coordinates, faces)
    region_edges = [set() for _ in contours]
    quads = [[] for _ in contours]
    triangles = []
    for face in faces:
        ids = face.node_ids
        region_edges[face.region].update(tuple(sorted((a, b))) for a, b in zip(ids, (*ids[1:], ids[0])))
        area = _polygon_area_um2(coordinates[i] for i in ids) / UM_TO_MM**2
        if len(ids) == 4:
            quads[face.region].append(area)
        else:
            triangles.append(area)
    return TopologyPlan(
        coordinates_mm=coordinates, faces=faces,
        rings=tuple(Ring(c.radius_um, len(ids) // 4, ids, 4) for c, ids in zip(contours, physical)),
        outer_node_ids=physical[-1], center_count_path=circle.center_count_path,
        outer_radial_layers=tuple(outer_layers), target_quad_area_um2=parameters.target_xy_um**2,
        edge_length=EdgeStatistics.from_values(edges.values(), parameters.target_xy_um),
        edge_length_by_region={i: EdgeStatistics.from_values((edges[e] for e in ee), parameters.target_xy_um)
                               for i, ee in enumerate(region_edges)},
        quad_area=AreaStatistics.from_values(v for region in quads for v in region),
        triangle_area=AreaStatistics.from_values(triangles),
        quad_area_by_region={i: AreaStatistics.from_values(values) for i, values in enumerate(quads)},
        symmetry_ok=_topology_is_reflection_symmetric(coordinates, faces, (0, 90)),
        radial_target_sizes_um=radial, angular_target_sizes_um=angular,
        sector_count=4, symmetry_axes_deg=(0, 90),
        contours_um=tuple(c.dimensions_um for c in contours), region_radial_widths_um=tuple(region_widths),
        canonical_ring_mesh=canonical_angular_target_um is not None,
        canonical_angular_target_um=canonical_angular_target_um,
        cap_symmetry_axes_deg=circle.symmetry_axes_deg,
    )


def build_oblong_topology(parameters: MeshParameters, contours: Sequence[StadiumContour],
                         radial_target_sizes_um: Iterable[float], *,
                         angular_target_sizes_um: Iterable[float] | None = None,
                         radial_policies: Iterable[RadialSeedPolicy] | None = None,
                         canonical_ring_mesh: bool = False,
                         canonical_angular_target_um: float | None = None) -> TopologyPlan:
    """Build a conforming projected topology with full physical contour edges.

    Inputs are ordered from the centre outwards. Targets are in microns and
    refer to local transverse spacing and physical boundary edge spacing.
    Strict nesting is required; touching contours have zero-width bands and
    are rejected. Hard radial seeds retain every surviving front position;
    variable-centre bands also retain hard seed fronts, with boundary-only
    contractions for small remainders. Inner, outer and two-front policies
    start at their actual reference contours.

    Consistency uses the original circular mesh for the entire short-axis
    contour stack, then translates its equal-centre cap cells unchanged. The
    source circle shares all R/angular settings, seed policies and the caller's
    independently selected X/Y or additional local 45-degree symmetry. The
    legacy canonical angular target is retained as metadata only.
    """
    contours = tuple(contours)
    if not contours or any(not isinstance(c, StadiumContour) for c in contours):
        raise ValueError("contours must contain StadiumContour objects")
    if len(contours) != len(parameters.diameters_um):
        raise ValueError("contour count must match the radial region count")
    if any(c.long_diameter_um > MAX_NUMERICAL_LENGTH_UM for c in contours):
        raise ValueError("Oblong 长轴尺寸超过数值建模上限。")
    if any(not outer.contains_contour(inner, strict=True) for inner, outer in zip(contours, contours[1:])):
        raise ValueError("Oblong 轮廓必须严格嵌套，暂不支持相交或相切。")
    if any(outer.long_radius_um - inner.long_radius_um < MIN_NUMERICAL_SEPARATION_UM
           for inner, outer in zip(contours, contours[1:])):
        raise ValueError("相邻 Oblong 长半轴差小于数值建模下限。")
    cp = replace(parameters, diameters_um=tuple(c.short_diameter_um for c in contours))
    radial = _validated_radial_target_sizes(cp, radial_target_sizes_um)
    angular = (_validated_radial_target_sizes(cp, angular_target_sizes_um)
               if angular_target_sizes_um is not None else (parameters.target_xy_um,) * len(contours))
    policies = tuple(radial_policies) if radial_policies is not None else (RadialSeedPolicy(),) * len(contours)
    if len(policies) != len(contours) or any(not isinstance(p, RadialSeedPolicy) for p in policies):
        raise ValueError("radial seed policies must match the contour regions")
    if not isinstance(canonical_ring_mesh, bool):
        raise ValueError("canonical_ring_mesh must be a boolean")
    canonical_target = None
    if canonical_ring_mesh:
        target = parameters.target_xy_um if canonical_angular_target_um is None else canonical_angular_target_um
        canonical_target = _validated_radial_target_sizes(cp, (target,) * len(contours))[0]
    if all(c.is_circle for c in contours):
        return build_topology_with_radial_targets(
            cp, radial, policies,
            angular_target_sizes_um=angular if angular_target_sizes_um is not None else None,
            canonical_ring_mesh=canonical_ring_mesh,
            canonical_angular_target_um=canonical_target,
        )
    return _build_cached(cp, contours, radial, angular, policies, canonical_target,
                         canonical_ring_mesh and angular_target_sizes_um is None)


__all__ = ["build_oblong_topology"]
