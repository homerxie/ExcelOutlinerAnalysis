"""Prepare connection layouts off the GUI thread before an atomic UI commit.

Preparation does not modify the current managed layout. The worker publishes
only a disposable staging file; its owner decides whether the result still
belongs to the active project before replacing the managed file.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib
from pathlib import Path
import re
import threading
from types import MappingProxyType
from typing import Callable, Iterable, Mapping
import uuid

from PySide6.QtCore import QObject, QThread, Signal

from .bump_layout import BumpLayout
from .layout_builder import normalize_material_name
from .layout_spatial import minimum_point_distance
from .output_artifacts import atomic_write_text
from .sample_mesh import (
    SampleMesh,
    load_sample_mesh_cached,
    validate_compatible_outer_boundaries,
)
from .workflow_handoff import serialize_bump_layout


DependencySignature = tuple[int, int, int]
MISSING_DEPENDENCY_SIGNATURE: DependencySignature = (-1, -1, -1)


class LayoutApplyCancelled(Exception):
    """The caller cancelled before the prepared layout was committed."""


@dataclass(frozen=True, slots=True)
class PreparedLayout:
    layout: BumpLayout
    text: str
    meshes: Mapping[str, SampleMesh]
    pitch_um: float | None
    dependency_signatures: Mapping[Path, DependencySignature]


def layout_material_name(names: Iterable[str]) -> str:
    """Resolve the single material used by the connection inspector."""
    unique = tuple(sorted(set(str(name) for name in names if str(name))))
    candidates = tuple(
        name for name in unique
        if name not in {"ALL_SOLID_VOLUMES", "TRANSITION_SOLID_VOLUMES"}
        and not name.startswith(("COMPONENT_", "HM_", "TEMPLATE_"))
        and not name.startswith("TRANSITION_")
    )
    if len(candidates) == 1:
        candidate = candidates[0]
        return normalize_material_name(candidate) if candidate.startswith("MATERIAL_") else candidate
    rendered = ", ".join(unique) or "<none>"
    raise ValueError(
        "模板单元/边缘 slab 必须恰好映射到一个材料 Physical Group，"
        f"实际为：{rendered}"
    )


def layout_component_name(names: Iterable[str]) -> str:
    """Resolve one component while retaining the legacy material fallback."""
    unique = tuple(sorted(set(str(name) for name in names if str(name))))
    explicit = tuple(
        name.removeprefix("COMPONENT_") for name in unique
        if name.startswith("COMPONENT_")
    )
    if len(explicit) == 1 and explicit[0]:
        return explicit[0]
    if not explicit:
        material = layout_material_name(unique)
        token = re.sub(r"[^A-Za-z0-9]+", "_", material).strip("_").upper()
        return token or "COMPONENT"
    rendered = ", ".join(unique) or "<none>"
    raise ValueError(
        "模板单元/边缘 slab 必须恰好映射到一个 COMPONENT_* Physical Group，"
        f"实际为：{rendered}"
    )


def _dependency_signature(path: Path) -> tuple[int, int, int, int, int] | None:
    try:
        info = path.stat()
    except FileNotFoundError:
        return None
    if not path.is_file():
        raise ValueError(f"模板资源必须是普通文件：{path}")
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns


def prepare_layout(
    layout: BumpLayout,
    *,
    path: str | Path,
    expected_digests: Mapping[str, str] | None = None,
    progress: Callable[[int, str], None] = lambda _percent, _text: None,
    cancelled: Callable[[], bool] = lambda: False,
) -> PreparedLayout:
    """Validate, read and summarize a layout without writing its target file.

    Progress describes completed phases, reserving 96–100 for staging and the
    GUI commit. Cancellation is cooperative between phases/templates and hash
    blocks; an in-flight Gmsh read is allowed to release its global lock first.
    """
    def check_cancelled() -> None:
        if cancelled():
            raise LayoutApplyCancelled()

    def report(percent: int, message: str) -> None:
        check_cancelled()
        progress(percent, message)
        check_cancelled()

    report(0, "校验连接布局…")
    target = Path(path).expanduser().resolve()
    prepared_layout = replace(layout, source_path=target)
    report(8, f"已校验 {len(layout.instances):,} 个 bump，正在序列化布局…")
    text = serialize_bump_layout(prepared_layout)
    report(15, "正在检查模板文件和元数据…")
    paths_by_alias = {
        template.alias: template.mesh_path.expanduser().resolve()
        for template in prepared_layout.templates
    }
    dependencies = tuple(dict.fromkeys(
        dependency
        for mesh_path in paths_by_alias.values()
        for dependency in (
            mesh_path,
            mesh_path.with_suffix(".parameters.json"),
            mesh_path.with_suffix(".report.json"),
        )
    ))
    before = {dependency: _dependency_signature(dependency) for dependency in dependencies}
    meshes: dict[str, SampleMesh] = {}
    digests = dict(expected_digests or {})
    hashes_by_path: dict[Path, str] = {}
    for index, (alias, mesh_path) in enumerate(paths_by_alias.items()):
        report(15 + 55 * index // len(paths_by_alias),
               f"读取模板 {index + 1}/{len(paths_by_alias)}：{alias}…")
        if before[mesh_path] is None:
            raise ValueError(f"模板 {alias!r} 不存在：{mesh_path}")
        expected = digests.get(alias)
        if expected is not None:
            if mesh_path not in hashes_by_path:
                digest = hashlib.sha256()
                with mesh_path.open("rb") as stream:
                    while block := stream.read(1024 * 1024):
                        check_cancelled()
                        digest.update(block)
                hashes_by_path[mesh_path] = digest.hexdigest()
            if hashes_by_path[mesh_path] != expected:
                raise ValueError(f"模板 {alias} 的网格已被修改，请重新导入。")
        check_cancelled()
        meshes[alias] = load_sample_mesh_cached(mesh_path)

    report(70, "校验模板外缘、Z surfaces 和材料/component stack…")
    validate_compatible_outer_boundaries(tuple(meshes.values()), require_identical_radius=False)
    reference_identities: set[tuple[str, str]] | None = None
    for alias, mesh in meshes.items():
        check_cancelled()
        physical_names = {element.physical_names for element in mesh.elements}
        identities = {
            (layout_component_name(names), layout_material_name(names))
            for names in physical_names
        }
        # The GUI also renders the union of names on each outer slab. A slab
        # can touch several otherwise valid entities, so element identities
        # alone do not prove its component/material names are unambiguous.
        for names in {interval.physical_names for interval in mesh.outer_boundary.surface_intervals}:
            layout_component_name(names)
            layout_material_name(names)
        if reference_identities is None:
            reference_identities = identities
        elif identities != reference_identities:
            raise ValueError(f"模板 {alias} 的内部 material/component 集合与首个模板不一致")

    report(82, "计算最小 bump 间距…")
    minimum_mm = minimum_point_distance((row.x_mm, row.y_mm) for row in prepared_layout.instances)
    pitch_um = None if minimum_mm is None else minimum_mm * 1000.0
    report(92, "复核模板文件在处理期间没有变化…")
    after = {dependency: _dependency_signature(dependency) for dependency in dependencies}
    if after != before:
        raise ValueError("处理期间模板网格或元数据发生变化，请重试。")
    signatures = {
        dependency: (MISSING_DEPENDENCY_SIGNATURE if signature is None
                     else (signature[1], signature[3], signature[2]))
        for dependency, signature in after.items()
    }
    report(95, "连接布局准备完成…")
    return PreparedLayout(prepared_layout, text, MappingProxyType(meshes), pitch_um,
                          MappingProxyType(signatures))


class LayoutApplyTask(QThread):
    """Prepare and stage a layout; consume result only after ``finished``."""

    progressChanged = Signal(int, str)

    def __init__(self, layout: BumpLayout, *, path: str | Path,
                 expected_digests: Mapping[str, str] | None = None,
                 parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._layout = layout
        self._path = Path(path).expanduser().resolve()
        self._expected_digests = dict(expected_digests or {})
        self._cancelled = threading.Event()
        self.result: PreparedLayout | None = None
        self.error: str | None = None
        self.was_cancelled = False
        self.staged_path: Path | None = None

    def cancel(self) -> None:
        self._cancelled.set()
        # A cancellation can arrive after run() prepared its result but before
        # the queued finished signal reaches the GUI. It must still veto commit.
        self.was_cancelled = True

    def cleanup(self) -> None:
        """Remove disposable output once the worker has finished."""
        if self.staged_path is not None:
            self.staged_path.unlink(missing_ok=True)
            self.staged_path = None

    def run(self) -> None:
        try:
            prepared = prepare_layout(
                self._layout, path=self._path,
                expected_digests=self._expected_digests,
                progress=self.progressChanged.emit,
                cancelled=self._cancelled.is_set,
            )
            if self._cancelled.is_set():
                raise LayoutApplyCancelled()
            self.progressChanged.emit(96, "写入连接布局暂存文件…")
            self.staged_path = self._path.with_name(f".layout-apply-{uuid.uuid4().hex}.loc")
            atomic_write_text(self.staged_path, prepared.text)
            if self._cancelled.is_set():
                raise LayoutApplyCancelled()
            self.result = prepared
            self.progressChanged.emit(99, "布局已就绪，正在更新主窗口…")
        except LayoutApplyCancelled:
            self.was_cancelled = True
            self.cleanup()
        except Exception as error:
            self.error = str(error) or type(error).__name__
            self.cleanup()


__all__ = [
    "LayoutApplyCancelled", "LayoutApplyTask", "PreparedLayout",
    "layout_component_name", "layout_material_name", "prepare_layout",
]
