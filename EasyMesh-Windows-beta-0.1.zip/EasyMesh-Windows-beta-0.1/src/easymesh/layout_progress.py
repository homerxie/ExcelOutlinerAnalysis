"""Small, job-bound progress records carried by the layout worker's log."""

from __future__ import annotations

import json
import os
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, TextIO


PROGRESS_PREFIX = "EASYMESH_LAYOUT_PROGRESS "
_MAX_RECORD_BYTES = 8192
_MAX_POLL_BYTES = 1024 * 1024


@dataclass(frozen=True)
class LayoutProgressEvent:
    percent: int | None
    message: str


def parse_layout_progress(line: str, job_id: str) -> LayoutProgressEvent | None:
    if not line.startswith(PROGRESS_PREFIX) or len(line) > _MAX_RECORD_BYTES:
        return None
    try:
        data = json.loads(line[len(PROGRESS_PREFIX):])
    except (ValueError, TypeError):
        return None
    if not isinstance(data, dict) or data.get("job_id") != job_id or "percent" not in data:
        return None
    percent, message = data.get("percent"), data.get("message")
    if percent is not None and (type(percent) is not int or not 0 <= percent <= 100):
        return None
    if not isinstance(message, str) or not message.strip() or len(message) > 512:
        return None
    return LayoutProgressEvent(percent, message.strip())


def layout_progress_reporter(
    job_id: str | None, *, stream: TextIO | None = None,
) -> Callable[[int | None, str], None]:
    """Flush each event so redirected subprocess output is visible immediately."""
    target = sys.stdout if stream is None else stream

    def report(percent: int | None, message: str) -> None:
        # A long user-supplied template alias must not turn an otherwise valid
        # mesh generation into a progress-transport error.
        if isinstance(message, str) and len(message) > 512:
            message = message[:511] + "…"
        data = {"job_id": job_id or "standalone", "percent": percent, "message": message}
        line = PROGRESS_PREFIX + json.dumps(data, ensure_ascii=False, separators=(",", ":"))
        if parse_layout_progress(line, data["job_id"]) is None:
            raise ValueError("invalid layout progress record")
        print(line, file=target, flush=True)

    return report


@dataclass
class LayoutProgressRun:
    job_id: str
    started: float = field(default_factory=time.monotonic)
    percent: int | None = None
    message: str = "正在启动连接网格生成…"
    completed: bool = False
    offset: int = 0
    pending: bytes = b""
    file_identity: tuple[int, int] | None = None
    discarding_line: bool = False

    def read(self, path: Path) -> list[LayoutProgressEvent]:
        """Tail bounded chunks; retain split UTF-8/JSON records between polls."""
        try:
            with path.open("rb") as stream:
                info = os.fstat(stream.fileno())
                identity = (info.st_dev, info.st_ino)
                if self.file_identity != identity or info.st_size < self.offset:
                    self.offset, self.pending, self.discarding_line = 0, b"", False
                self.file_identity = identity
                stream.seek(self.offset)
                chunk = stream.read(_MAX_POLL_BYTES)
                self.offset += len(chunk)
        except OSError:
            return []
        lines = (self.pending + chunk).split(b"\n")
        self.pending = lines.pop()
        events = []
        for raw in lines:
            if self.discarding_line:
                self.discarding_line = False
                continue
            if len(raw) > _MAX_RECORD_BYTES:
                continue
            event = parse_layout_progress(raw.decode("utf-8", errors="replace"), self.job_id)
            if event is not None:
                events.append(event)
        if len(self.pending) > _MAX_RECORD_BYTES:
            self.pending = b""
            self.discarding_line = True
        return events
