"""Coordinate ranges for the objects currently selected in a Package preview."""
from PySide6.QtCore import QObject

from .package_v2_geometry_bounds import generated_component_bounds
from .package_v2_mesh_bounds import format_mesh_bounds
from .package_v2_mesh_bounds_controller import MeshBoundsController


class PreviewSelectionBounds(QObject):
    def __init__(self, label, parent=None):
        super().__init__(parent)
        self.label = label
        self.bounds = None
        self.loading = False
        self._components = {}
        self._generated = {}
        self._frozen = {}
        self._public_instances = {}
        self._generated_cache = {}
        self._controllers = {}
        self._selected = ()
        self._selected_generated = []
        self._selected_frozen = {}
        self._instance_id = None
        self._updating = False
        self._render()

    def cancel(self):
        for controller in self._controllers.values():
            controller.cancel()
        self.loading = False

    def clear(self):
        self.cancel()
        for controller in self._controllers.values():
            controller.deleteLater()
        self._controllers.clear()
        self._components.clear()
        self._generated.clear()
        self._frozen.clear()
        self._public_instances.clear()
        self._generated_cache.clear()
        self._selected = ()
        self._selected_generated = []
        self._selected_frozen = {}
        self._instance_id = None
        self._render()

    def set_scene(self, compiled, scene):
        self.clear()
        self._components = {component.key: component for component in scene.components}
        self._generated = {instance.instance_id: instance for instance in compiled.generated_instances}
        self._frozen = {source.source_id: source for source in compiled.frozen_sources}
        for frame in scene.local_frames:
            self._public_instances.setdefault(frame.component_key, []).append(frame.instance_id)

    def set_selection(self, keys, *, instance_id=None):
        keys = set(keys)
        self._selected = tuple(component for key, component in self._components.items() if key in keys)
        self._instance_id = instance_id
        self._selected_generated = []
        self._selected_frozen = {}
        for component in self._selected:
            if component.frozen:
                self._selected_frozen.setdefault(component.owner_id, []).append(component.component_id)
            else:
                cache_key = component.key, instance_id
                if cache_key not in self._generated_cache:
                    try:
                        instance = self._generated[component.owner_id]
                        fragment_ids = None
                        members = self._public_instances.get(component.key, ())
                        if instance_id is not None and len(members) > 1:
                            if instance_id not in members:
                                raise ValueError("所选实例不属于当前 Component。")
                            prefix = f"i_{len(instance_id)}_{instance_id}_"
                            fragment_ids = tuple(
                                fragment.fragment_id
                                for geometry in instance.geometry_result.geometry.components
                                if geometry.component_id == component.component_id
                                for fragment in geometry.fragments
                                if fragment.fragment_id.startswith(prefix)
                            )
                        bounds = generated_component_bounds(instance, component.component_id,
                                                            fragment_ids=fragment_ids)
                        self._generated_cache[cache_key] = bounds, ""
                    except (KeyError, ValueError, ArithmeticError) as error:
                        self._generated_cache[cache_key] = None, f"范围不可用：{error}"
                self._selected_generated.append(self._generated_cache[cache_key])

        self._updating = True
        try:
            for source_id, controller in self._controllers.items():
                if source_id not in self._selected_frozen:
                    controller.cancel()
            for source_id, components in self._selected_frozen.items():
                if source_id not in self._controllers:
                    controller = MeshBoundsController(self)
                    controller.changed.connect(self._render)
                    self._controllers[source_id] = controller
                source = self._frozen[source_id]
                self._controllers[source_id].request(
                    source.artifacts.mesh_runtime_path, components,
                    source.placement.translation_xyz_mm, source.placement.rotation_matrix,
                )
        finally:
            self._updating = False
        self._render()

    def _render(self, *_args):
        if self._updating:
            return
        self.bounds = None
        self.loading = False
        if not self._selected:
            self.label.setText("选择对象后显示 X/Y/Z 范围（mm）")
            return
        if self._instance_id is not None:
            name = self._instance_id
        elif len(self._selected) == 1:
            component = self._selected[0]
            name = (component.owner_id if component.owner_id == component.component_id
                    else f"{component.owner_id} / {component.component_id}")
        else:
            name = f"已选 {len(self._selected)} 个对象（整体范围）"
        title = f"{name} · 全局坐标范围（mm）"
        values = list(self._selected_generated)
        for source_id in self._selected_frozen:
            controller = self._controllers[source_id]
            self.loading |= controller.loading
            values.append((controller.bounds, "" if controller.loading else controller.message))
        error = next((message for bounds, message in values if bounds is None and message), "")
        if error or self.loading:
            self.label.setText(title + "\n" + (error or "正在计算范围…"))
            return
        if not values or any(bounds is None for bounds, _message in values):
            self.label.setText(title + "\n范围不可用。")
            return
        self.bounds = (
            tuple(min(bounds[0][axis] for bounds, _message in values) for axis in range(3)),
            tuple(max(bounds[1][axis] for bounds, _message in values) for axis in range(3)),
        )
        ranges = format_mesh_bounds(self.bounds)
        self.label.setText(title + "\n" + "    ".join(
            f"{axis}：{value}" for axis, value in zip("XYZ", ranges)))


__all__ = ["PreviewSelectionBounds"]
