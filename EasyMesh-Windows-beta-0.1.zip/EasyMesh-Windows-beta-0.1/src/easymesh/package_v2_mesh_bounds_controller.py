"""Debounced, cancellable mesh coordinate ranges for Package editors."""
from pathlib import Path
from threading import Event

from PySide6.QtCore import QObject, QRunnable, QThreadPool, QTimer, Signal, QSignalBlocker

from .package_v2_mesh_bounds import read_mesh_bounds, format_mesh_bounds
from .package_v2_mesh_groups import mesh_file_signature


# A large file must not be parsed concurrently for every instance of that file.
_pool = QThreadPool()
_pool.setMaxThreadCount(1)


class _BoundsSignals(QObject):
    finished = Signal(int, object, str)


class _BoundsTask(QRunnable):
    def __init__(self, generation, request, lifetime):
        super().__init__()
        self.generation, self.request = generation, request
        self.cancelled = Event()
        self.lifetime = lifetime
        self.signals = _BoundsSignals()

    def run(self):
        cancelled = lambda: self.cancelled.is_set() or self.lifetime.is_set()
        if cancelled():
            return
        path, components, translation, rotation, _signature = self.request
        try:
            bounds = read_mesh_bounds(path, components, rotation_matrix=rotation,
                                      translation_xyz_mm=translation, cancelled=cancelled)
            message = ""
        except (OSError, ValueError, RuntimeError, OverflowError, MemoryError) as error:
            bounds, message = None, f"范围不可用：{error}"
        if not cancelled():
            self.signals.finished.emit(self.generation, bounds, message)


class MeshBoundsController(QObject):
    changed = Signal(object, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.bounds = None
        self.message = self.error = ""
        self.loading = False
        self._request = self._task = None
        self._generation = 0
        self._lifetime = Event()
        self.destroyed.connect(self._lifetime.set)
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(180)
        self.timer.timeout.connect(self._start)

    def cancel(self):
        self.timer.stop()
        self._generation += 1
        if self._task is not None:
            self._task.cancelled.set()
            self._task = None
        self._request = None
        self.loading = False

    def clear(self, message=""):
        self.cancel()
        self.bounds = None
        self.message = self.error = message
        self.changed.emit(None, message)

    def request(self, path, components, translation_xyz_mm, rotation_matrix):
        path = Path(path)
        try:
            signature = mesh_file_signature(path)
        except OSError as error:
            self.clear(f"范围不可用：{error}")
            return
        request = (path, tuple(components), tuple(translation_xyz_mm),
                   tuple(tuple(row) for row in rotation_matrix), signature)
        if request == self._request:
            self.changed.emit(self.bounds, self.message)
            return
        self.cancel()
        self._request = request
        self.bounds = None
        self.error = ""
        self.loading = True
        self.message = "正在计算范围…"
        self.changed.emit(None, self.message)
        self.timer.start()

    def _start(self):
        task = _BoundsTask(self._generation, self._request, self._lifetime)
        task.signals.finished.connect(self._loaded)
        self._task = task
        _pool.start(task)

    def _loaded(self, generation, bounds, message):
        if generation != self._generation:
            return
        self._task = None
        self.loading = False
        self.bounds, self.message, self.error = bounds, message, message
        self.changed.emit(bounds, message)


class MeshBoundsTableController(QObject):
    """Keep each row bound to its current source even after a table rebuild."""

    def __init__(self, table):
        super().__init__(table)
        self.table = table
        self.controllers = {}
        self.rows = {}

    def clear(self):
        self.rows = {}
        for controller in self.controllers.values():
            controller.cancel()
            controller.deleteLater()
        self.controllers.clear()

    def update(self, compiled):
        self.rows = {self.table.item(row, 0).text(): row
                     for row in range(self.table.rowCount())}
        sources = {source.source_id: source for source in compiled.frozen_sources}
        for source_id in tuple(self.controllers):
            if source_id not in sources:
                controller = self.controllers.pop(source_id)
                controller.cancel()
                controller.deleteLater()
        for source_id, source in sources.items():
            if source_id not in self.controllers:
                controller = MeshBoundsController(self)
                controller.changed.connect(
                    lambda bounds, message, key=source_id: self._render(key, bounds, message))
                self.controllers[source_id] = controller
            self.controllers[source_id].request(
                source.artifacts.mesh_runtime_path,
                tuple(binding.local_id for binding in source.components),
                source.placement.translation_xyz_mm, source.placement.rotation_matrix,
            )

    def _render(self, source_id, bounds, message):
        row = self.rows.get(source_id)
        if row is None:
            return
        status = "计算中…" if self.controllers[source_id].loading else "不可用"
        values = format_mesh_bounds(bounds) if bounds is not None else (status,) * 3
        tooltip = "Package 全局坐标；所选体分组的轴对齐最小外接长方体。范围为 [最小值, 最大值]，单位 mm。"
        with QSignalBlocker(self.table):
            for column, value in enumerate(values, start=3):
                item = self.table.item(row, column)
                if item is not None:
                    item.setText(value)
                    item.setToolTip(tooltip if bounds is not None else message)
