"""Validated editable workflow state shared by the four GUI modules.

Mesh paths are references, not embedded artifacts.  Their recorded digests let
the GUI check freshness before handing a result to another module.  Source
drafts deliberately remain text so saving a project never depends on having
already created a Package Job.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


WORKFLOW_SCHEMA = "easymesh-workflow-v1"
_KINDS = frozenset(("layer", "layout", "package_v2", "external"))
_SHA256_CHARACTERS = frozenset("0123456789abcdef")
_REQUIRED_KEYS = frozenset(("schema", "library", "assets", "managed_layout"))
_OPTIONAL_KEYS = frozenset(("package_source",))
_ASSET_REQUIRED_KEYS = frozenset(("id", "name", "kind", "mesh_path", "sha256"))
_ASSET_OPTIONAL_KEYS = frozenset(
    ("template_id", "layer_fingerprint", "input_fingerprint", "upstream_asset_ids")
)


def _object(value: object, label: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise ValueError(f"workflow field {label!r} must be an object")
    return value


def _keys(
    value: Mapping[str, object],
    required: frozenset[str],
    optional: frozenset[str],
    label: str,
) -> None:
    actual = set(value)
    if not required.issubset(actual) or not actual.issubset(required | optional):
        raise ValueError(f"workflow field {label!r} has invalid keys")


def _text(value: object, label: str, *, nonempty: bool = False) -> str:
    if not isinstance(value, str) or (nonempty and not value.strip()):
        qualifier = "non-empty " if nonempty else ""
        raise ValueError(f"workflow field {label!r} must be {qualifier}text")
    if "\x00" in value:
        raise ValueError(f"workflow field {label!r} must not contain NUL")
    try:
        value.encode("utf-8")
    except UnicodeEncodeError as error:
        raise ValueError(f"workflow field {label!r} must be valid Unicode") from error
    return value


def _sha256(value: object, label: str) -> str:
    digest = _text(value, label)
    if len(digest) != 64 or any(char not in _SHA256_CHARACTERS for char in digest):
        raise ValueError(f"workflow field {label!r} must be a lower-case SHA-256")
    return digest


def empty_workflow_state() -> dict[str, Any]:
    """Return a fresh workflow for projects created before the library existed."""

    from .workflow_library import empty_workflow_library

    return {
        "schema": WORKFLOW_SCHEMA,
        "library": empty_workflow_library(),
        "assets": [],
        "managed_layout": False,
        "package_source": None,
    }


def validate_workflow_state(value: object) -> dict[str, Any]:
    """Return a detached canonical snapshot without reading external mesh files."""

    # The library validates Layer state using project_file; defer the import to
    # keep both modules usable independently of their import order.
    from .workflow_library import validate_workflow_library

    workflow = _object(value, "<root>")
    _keys(workflow, _REQUIRED_KEYS, _OPTIONAL_KEYS, "<root>")
    if workflow.get("schema") != WORKFLOW_SCHEMA:
        raise ValueError("unsupported EasyMesh workflow schema")
    library = validate_workflow_library(workflow.get("library"))
    raw_assets = workflow.get("assets")
    if not isinstance(raw_assets, list):
        raise ValueError("workflow field 'assets' must be an array")
    assets: list[dict[str, object]] = []
    seen_ids: set[str] = set()
    for index, raw_asset in enumerate(raw_assets):
        label = f"assets[{index}]"
        asset = _object(raw_asset, label)
        _keys(asset, _ASSET_REQUIRED_KEYS, _ASSET_OPTIONAL_KEYS, label)
        identifier = _text(asset.get("id"), f"{label}.id", nonempty=True)
        if identifier in seen_ids:
            raise ValueError(f"duplicate workflow asset id: {identifier!r}")
        seen_ids.add(identifier)
        kind = _text(asset.get("kind"), f"{label}.kind")
        if kind not in _KINDS:
            raise ValueError(f"unsupported workflow asset kind: {kind!r}")
        canonical: dict[str, object] = {
            "id": identifier,
            "name": _text(asset.get("name"), f"{label}.name", nonempty=True),
            "kind": kind,
            "mesh_path": _text(
                asset.get("mesh_path"), f"{label}.mesh_path", nonempty=True
            ),
            "sha256": _sha256(asset.get("sha256"), f"{label}.sha256"),
        }
        if "template_id" in asset:
            template_id = asset["template_id"]
            canonical["template_id"] = (
                None
                if template_id is None
                else _text(template_id, f"{label}.template_id", nonempty=True)
            )
        for field in ("layer_fingerprint", "input_fingerprint"):
            if field in asset:
                fingerprint = asset[field]
                canonical[field] = (
                    None if fingerprint is None else _sha256(fingerprint, f"{label}.{field}")
                )
        if "upstream_asset_ids" in asset:
            raw_upstream = asset["upstream_asset_ids"]
            if not isinstance(raw_upstream, list):
                raise ValueError(f"workflow field {label + '.upstream_asset_ids'!r} must be an array")
            upstream = [
                _text(value, f"{label}.upstream_asset_ids[{index}]", nonempty=True)
                for index, value in enumerate(raw_upstream)
            ]
            if len(set(upstream)) != len(upstream) or identifier in upstream:
                raise ValueError("workflow upstream asset ids must be distinct and not include the asset itself")
            canonical["upstream_asset_ids"] = upstream
        assets.append(canonical)

    managed_layout = workflow.get("managed_layout")
    if not isinstance(managed_layout, bool):
        raise ValueError("workflow field 'managed_layout' must be a boolean")
    raw_source = workflow.get("package_source")
    package_source: dict[str, str] | None = None
    if raw_source is not None:
        source = _object(raw_source, "package_source")
        _keys(source, frozenset(("path", "text")), frozenset(), "package_source")
        package_source = {
            "path": _text(source.get("path"), "package_source.path"),
            "text": _text(source.get("text"), "package_source.text"),
        }
    return {
        "schema": WORKFLOW_SCHEMA,
        "library": library,
        "assets": assets,
        "managed_layout": managed_layout,
        "package_source": package_source,
    }
