"""Layer-file parsing and construction over nested planar contours.

Columns use the non-negative short-axis half-section as their reference
coordinate.  For circles this is the familiar radial section.  For oblongs the
full planar boundary is retained separately; a radius alone does not define it.

This module deliberately describes geometry only.  It contains no decisions
about how the section should be meshed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import math
from pathlib import Path
import re
from typing import Iterable

from .contours import StadiumContour


class LayerMode(str, Enum):
    """How a new layer follows the current top surface."""

    WATER = "water"
    TAPE = "tape"


class WaterReference(str, Enum):
    """Surface used to calculate a water layer's target elevation."""

    TOP = "top"
    BOTTOM = "bottom"


@dataclass(frozen=True, slots=True)
class LayerDefinition:
    """One layer instruction, with all dimensions expressed in microns.

    ``thickness_um`` is a signed target-elevation offset for water layers.  It
    remains a strictly positive physical thickness for tape layers.  The
    special air-gap record has no component or material: both fields are
    represented as ``None`` and its reserved volume never becomes a mesh span.
    ``outer_diameter_um`` and ``inner_diameter_um`` retain the full long-axis
    dimensions.  Optional short diameters normalize to the corresponding long
    diameters, preserving the original circular constructor and file syntax.
    """

    component: str | None
    material: str | None
    thickness_um: float
    outer_diameter_um: float
    inner_diameter_um: float
    mode: LayerMode
    sidewall_thickness_um: float | None = None
    reference: WaterReference | None = None
    outer_short_diameter_um: float | None = None
    inner_short_diameter_um: float | None = None
    source_line_number: int | None = field(default=None, compare=False, repr=False)

    def __post_init__(self) -> None:
        if (self.component is None) != (self.material is None):
            raise ValueError(
                "component and material must either both be present or both be None"
            )
        if self.component is not None:
            if not isinstance(self.component, str):
                raise ValueError("component must be a string")
            component = self.component.strip()
            if not component:
                raise ValueError("component must not be empty")
            object.__setattr__(self, "component", component)

            if not isinstance(self.material, str):
                raise ValueError("material must be a string")
            material = self.material.strip()
            if not material:
                raise ValueError("material must not be empty")
            object.__setattr__(self, "material", material)

        if isinstance(self.mode, str) and not isinstance(self.mode, LayerMode):
            try:
                object.__setattr__(self, "mode", LayerMode(self.mode))
            except ValueError as error:
                raise ValueError("mode must be 'water' or 'tape'") from error
        if not isinstance(self.mode, LayerMode):
            raise ValueError("mode must be a LayerMode")

        if isinstance(self.reference, str) and not isinstance(
            self.reference, WaterReference
        ):
            try:
                object.__setattr__(
                    self, "reference", WaterReference(self.reference)
                )
            except ValueError as error:
                raise ValueError("reference must be 'top' or 'bottom'") from error
        if self.reference is not None and not isinstance(
            self.reference, WaterReference
        ):
            raise ValueError("reference must be a WaterReference")

        for name in ("thickness_um", "outer_diameter_um", "inner_diameter_um"):
            value = float(getattr(self, name))
            if not math.isfinite(value):
                raise ValueError(f"{name} must be finite")
            object.__setattr__(self, name, value)

        if self.outer_diameter_um <= 0.0:
            raise ValueError("outer_diameter_um must be greater than zero")
        if self.inner_diameter_um < 0.0:
            raise ValueError("inner_diameter_um must not be negative")
        for name, fallback in (
            ("outer_short_diameter_um", self.outer_diameter_um),
            ("inner_short_diameter_um", self.inner_diameter_um),
        ):
            supplied = getattr(self, name)
            value = fallback if supplied is None else float(supplied)
            if not math.isfinite(value):
                raise ValueError(f"{name} must be finite")
            object.__setattr__(self, name, value)
        outer_contour = self.outer_contour
        if (self.inner_diameter_um == 0.0) != (self.inner_short_diameter_um == 0.0):
            raise ValueError("a solid footprint requires both inner diameters to be zero")
        inner_contour = self.inner_contour
        if inner_contour is not None and not outer_contour.contains_contour(
            inner_contour, strict=True
        ):
            raise ValueError(
                f"inner contour {inner_contour} must be strictly inside outer "
                f"contour {outer_contour}; touching or crossing contours are unsupported"
            )

        if self.mode is LayerMode.WATER:
            if self.sidewall_thickness_um is not None:
                raise ValueError("water mode does not accept a sidewall thickness")
            if self.reference is None:
                raise ValueError("water mode requires a top or bottom reference")
        else:
            if self.is_air_gap:
                raise ValueError("an air gap must use water mode")
            if self.reference is not None:
                raise ValueError("tape mode does not accept a water reference")
            if self.thickness_um <= 0.0:
                raise ValueError("tape thickness_um must be greater than zero")
            if self.sidewall_thickness_um is None:
                raise ValueError("tape mode requires a sidewall thickness")
            sidewall = float(self.sidewall_thickness_um)
            if not math.isfinite(sidewall) or sidewall <= 0.0:
                raise ValueError("sidewall_thickness_um must be finite and greater than zero")
            object.__setattr__(self, "sidewall_thickness_um", sidewall)

    @property
    def is_air_gap(self) -> bool:
        """Whether this instruction reserves void instead of adding material."""

        return self.component is None

    @property
    def inner_radius_um(self) -> float:
        assert self.inner_short_diameter_um is not None
        return self.inner_short_diameter_um * 0.5

    @property
    def outer_radius_um(self) -> float:
        assert self.outer_short_diameter_um is not None
        return self.outer_short_diameter_um * 0.5

    @property
    def outer_contour(self) -> StadiumContour:
        short = self.outer_short_diameter_um
        return StadiumContour(
            self.outer_diameter_um,
            self.outer_diameter_um if short is None else short,
        )

    @property
    def inner_contour(self) -> StadiumContour | None:
        if self.inner_diameter_um == 0.0:
            return None
        short = self.inner_short_diameter_um
        return StadiumContour(
            self.inner_diameter_um,
            self.inner_diameter_um if short is None else short,
        )

    @property
    def is_oblong(self) -> bool:
        inner = self.inner_contour
        return self.outer_contour.is_oblong or (inner is not None and inner.is_oblong)

    # Concise aliases are useful to renderers while the stored names keep units
    # explicit at file/API boundaries.
    @property
    def thickness(self) -> float:
        return self.thickness_um

    @property
    def inner_radius(self) -> float:
        return self.inner_radius_um

    @property
    def outer_radius(self) -> float:
        return self.outer_radius_um


_MICRON_VALUE = re.compile(
    r"(?P<number>[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)um\Z"
)


def _parse_microns(value: str, *, line_number: int, field_name: str) -> float:
    match = _MICRON_VALUE.fullmatch(value)
    if match is None:
        raise ValueError(
            f"line {line_number}: {field_name} must be a number followed by 'um'"
        )
    parsed = float(match.group("number"))
    if not math.isfinite(parsed):
        raise ValueError(f"line {line_number}: {field_name} must be finite")
    return parsed


def parse_layer_text(text: str) -> tuple[LayerDefinition, ...]:
    """Parse eight-field circular or ten-field stadium instructions.

    Blank lines and text from ``#`` to the end of a line are ignored.  Every
    record has eight or ten comma-separated fields.  The original OD/ID are
    full long-axis diameters; omitted short diameters default to the matching
    long diameters.  An air gap leaves component and material empty::

        +,component,material,t,OD,ID,water,top|bottom
        +,component,material,t,OD,ID,tape,ts
        +,,,t,OD,ID,water,top|bottom
        +,component,material,t,outer_long,inner_long,outer_short,inner_short,water,top|bottom
        +,component,material,t,outer_long,inner_long,outer_short,inner_short,tape,ts

    Neither former seven-field solid syntax nor the former seven-field air-gap
    syntax is accepted.
    """

    layers: list[LayerDefinition] = []
    for line_number, source_line in enumerate(text.splitlines(), start=1):
        line = source_line.split("#", 1)[0].strip()
        if line_number == 1:
            line = line.lstrip("\ufeff")
        if not line:
            continue

        fields = [field.strip() for field in line.split(",")]
        if len(fields) not in (8, 10):
            raise ValueError(f"line {line_number}: expected exactly 8 or 10 fields")
        if fields[0] != "+":
            raise ValueError(f"line {line_number}: only the '+' add operation is supported")

        is_air_gap = not fields[1] and not fields[2]
        if is_air_gap:
            component = None
            material = None
            thickness_text, outer_text, inner_text = fields[3:6]
            mode_text = fields[-2]
            terminal_text = fields[-1]
            if mode_text != LayerMode.WATER.value:
                raise ValueError(
                    f"line {line_number}: an air gap must use water mode"
                )
        else:
            if bool(fields[1]) != bool(fields[2]):
                raise ValueError(
                    f"line {line_number}: component and material must either both "
                    "be present or both be empty for an air gap"
                )
            if not fields[1]:
                raise ValueError(f"line {line_number}: component must not be empty")
            if not fields[2]:
                raise ValueError(f"line {line_number}: material must not be empty")
            component = fields[1]
            material = fields[2]
            thickness_text, outer_text, inner_text = fields[3:6]
            mode_text = fields[-2]
            terminal_text = fields[-1]

        if mode_text == LayerMode.WATER.value:
            mode = LayerMode.WATER
            sidewall = None
            try:
                reference = WaterReference(terminal_text)
            except ValueError as error:
                raise ValueError(
                    f"line {line_number}: water reference must be exactly "
                    "'top' or 'bottom'"
                ) from error
        elif mode_text == LayerMode.TAPE.value:
            mode = LayerMode.TAPE
            reference = None
            sidewall = _parse_microns(
                terminal_text,
                line_number=line_number,
                field_name="sidewall thickness",
            )
        else:
            raise ValueError(f"line {line_number}: mode must be exactly 'water' or 'tape'")

        try:
            layers.append(
                LayerDefinition(
                    component=component,
                    material=material,
                    thickness_um=_parse_microns(
                        thickness_text,
                        line_number=line_number,
                        field_name="thickness",
                    ),
                    outer_diameter_um=_parse_microns(
                        outer_text,
                        line_number=line_number,
                        field_name="outer diameter",
                    ),
                    inner_diameter_um=_parse_microns(
                        inner_text,
                        line_number=line_number,
                        field_name="inner diameter",
                    ),
                    mode=mode,
                    sidewall_thickness_um=sidewall,
                    reference=reference,
                    outer_short_diameter_um=(
                        _parse_microns(
                            fields[6], line_number=line_number,
                            field_name="outer short diameter",
                        )
                        if len(fields) == 10 else None
                    ),
                    inner_short_diameter_um=(
                        _parse_microns(
                            fields[7], line_number=line_number,
                            field_name="inner short diameter",
                        )
                        if len(fields) == 10 else None
                    ),
                    source_line_number=line_number,
                )
            )
        except ValueError as error:
            message = str(error)
            if message.startswith(f"line {line_number}:"):
                raise
            raise ValueError(f"line {line_number}: {message}") from error

    result = tuple(layers)
    _collect_layer_contours(result)
    return result


def _check_contour_chain(
    sources: dict[StadiumContour, str],
) -> tuple[StadiumContour, ...]:
    """Validate and order distinct boundaries; exact duplicates share a band edge."""

    ordered = tuple(
        sorted(sources, key=lambda contour: contour.dimensions_um[::-1])
    )
    for inner, outer in zip(ordered, ordered[1:]):
        if not outer.contains_contour(inner, strict=True):
            relation = (
                "touch"
                if outer.long_diameter_um == inner.long_diameter_um
                or outer.short_diameter_um == inner.short_diameter_um
                else "cross"
            )
            raise ValueError(
                f"{sources[inner]} contour {inner} and {sources[outer]} "
                f"contour {outer} {relation}; all distinct contours must be "
                "strictly nested in both long and short diameters"
            )
    return ordered


def _layer_source(layer: LayerDefinition, index: int) -> str:
    location = (
        f"line {layer.source_line_number}"
        if layer.source_line_number is not None else f"layer {index + 1}"
    )
    return f"{location} ({layer.component or 'air gap'})"


def _collect_layer_contours(
    layers: tuple[LayerDefinition, ...],
) -> tuple[dict[StadiumContour, str], tuple[StadiumContour, ...]]:
    sources: dict[StadiumContour, str] = {}
    for index, layer in enumerate(layers):
        source = _layer_source(layer, index)
        sources.setdefault(layer.outer_contour, f"{source} outer")
        if layer.inner_contour is not None:
            sources.setdefault(layer.inner_contour, f"{source} inner")
    return sources, _check_contour_chain(sources)


def load_layer_file(path: str | Path) -> tuple[LayerDefinition, ...]:
    """Read and parse a UTF-8 ``.layer`` file."""

    return parse_layer_text(Path(path).read_text(encoding="utf-8-sig"))


@dataclass(frozen=True, slots=True)
class SectionSpan:
    """A material-filled vertical interval in one radial column."""

    component: str
    material: str
    z_bottom_um: float
    z_top_um: float
    layer_index: int | None = None

    def __post_init__(self) -> None:
        component = self.component.strip()
        material = self.material.strip()
        if not component:
            raise ValueError("span component must not be empty")
        if not material:
            raise ValueError("span material must not be empty")
        object.__setattr__(self, "component", component)
        object.__setattr__(self, "material", material)
        if not math.isfinite(self.z_bottom_um) or not math.isfinite(self.z_top_um):
            raise ValueError("span elevations must be finite")
        if self.z_top_um <= self.z_bottom_um:
            raise ValueError("span top must be above its bottom")

    @property
    def bottom_um(self) -> float:
        return self.z_bottom_um

    @property
    def top_um(self) -> float:
        return self.z_top_um

    @property
    def thickness_um(self) -> float:
        return self.z_top_um - self.z_bottom_um


@dataclass(frozen=True, slots=True)
class AirGapSpan:
    """A persistent reserved-void interval which emits no mesh element."""

    z_bottom_um: float
    z_top_um: float
    layer_index: int | None = None

    def __post_init__(self) -> None:
        if not math.isfinite(self.z_bottom_um) or not math.isfinite(self.z_top_um):
            raise ValueError("air-gap elevations must be finite")
        if self.z_top_um <= self.z_bottom_um:
            raise ValueError("air-gap top must be above its bottom")

    @property
    def bottom_um(self) -> float:
        return self.z_bottom_um

    @property
    def top_um(self) -> float:
        return self.z_top_um

    @property
    def thickness_um(self) -> float:
        return self.z_top_um - self.z_bottom_um


@dataclass(frozen=True, slots=True)
class RadialColumn:
    """Solid and reserved-void spans over ``[inner, outer)``."""

    inner_radius_um: float
    outer_radius_um: float
    spans: tuple[SectionSpan, ...] = ()
    air_gaps: tuple[AirGapSpan, ...] = ()

    def __post_init__(self) -> None:
        if not math.isfinite(self.inner_radius_um) or not math.isfinite(self.outer_radius_um):
            raise ValueError("column radii must be finite")
        if self.inner_radius_um < 0.0 or self.outer_radius_um <= self.inner_radius_um:
            raise ValueError("column radii must define a positive interval")
        intervals = sorted(
            (*self.spans, *self.air_gaps),
            key=lambda interval: (interval.z_bottom_um, interval.z_top_um),
        )
        previous_top = 0.0
        for interval in intervals:
            if interval.z_bottom_um < previous_top:
                raise ValueError(
                    "column solid and air-gap spans must not overlap"
                )
            previous_top = interval.z_top_um

    @property
    def width_um(self) -> float:
        return self.outer_radius_um - self.inner_radius_um

    @property
    def top_um(self) -> float:
        """Top construction surface, including persistent air-gap keepouts."""

        return max(self.solid_top_um, self.air_gap_top_um)

    @property
    def solid_top_um(self) -> float:
        return max((span.z_top_um for span in self.spans), default=0.0)

    @property
    def air_gap_top_um(self) -> float:
        return max((gap.z_top_um for gap in self.air_gaps), default=0.0)

    @property
    def radius_min_um(self) -> float:
        return self.inner_radius_um

    @property
    def radius_max_um(self) -> float:
        return self.outer_radius_um


@dataclass(frozen=True, slots=True)
class SectionPlan:
    """Piecewise-constant geometry for the non-negative half-section."""

    layers: tuple[LayerDefinition, ...]
    columns: tuple[RadialColumn, ...]
    contours: tuple[StadiumContour, ...] = ()

    def __post_init__(self) -> None:
        for left, right in zip(self.columns, self.columns[1:]):
            if left.outer_radius_um != right.inner_radius_um:
                raise ValueError("section columns must be contiguous")
        contours = tuple(self.contours)
        if not contours and self.columns:
            if any(layer.is_oblong for layer in self.layers):
                raise ValueError(
                    "an oblong section requires explicit contours; short-axis "
                    "columns alone cannot recover the long diameters"
                )
            contours = tuple(
                StadiumContour(2.0 * radius, 2.0 * radius)
                for radius in self.radius_breakpoints_um if radius > 0.0
            )
        ordered = _check_contour_chain({contour: "section" for contour in contours})
        if contours != ordered:
            raise ValueError("section contours must be unique and ordered from inner to outer")
        expected_radii = tuple(
            radius for radius in self.radius_breakpoints_um if radius > 0.0
        )
        if tuple(contour.radius_um for contour in contours) != expected_radii:
            raise ValueError("section contours must match the short-axis column boundaries")
        if any(layer.is_oblong for layer in self.layers):
            declared = {
                contour
                for layer in self.layers
                for contour in (layer.inner_contour, layer.outer_contour)
                if contour is not None
            }
            if not declared.issubset(contours):
                raise ValueError(
                    "section contours must retain every declared long and short diameter"
                )
        object.__setattr__(self, "contours", contours)

    @property
    def contours_um(self) -> tuple[StadiumContour, ...]:
        """Nonzero boundaries in inner-to-outer order, with both diameters retained."""

        return self.contours

    @property
    def is_oblong(self) -> bool:
        return any(contour.is_oblong for contour in self.contours)

    def axis_breakpoints_um(self, axis: str = "short") -> tuple[float, ...]:
        """Positions in the selected centre-crossing half-section."""

        if axis not in ("short", "long"):
            raise ValueError("section axis must be 'short' or 'long'")
        if axis == "short" or not self.columns:
            return self.radius_breakpoints_um
        radii = {0.0: 0.0}
        radii.update({
            contour.radius_um: contour.long_radius_um for contour in self.contours
        })
        return tuple(radii[radius] for radius in self.radius_breakpoints_um)

    def projected_columns(self, axis: str = "short") -> tuple[RadialColumn, ...]:
        """Material/void stacks projected onto a long- or short-axis section.

        Returned columns are for section display and area integration, not a
        replacement planar contour model.
        """

        edges = self.axis_breakpoints_um(axis)
        if axis == "short":
            return self.columns
        return tuple(
            RadialColumn(left, right, column.spans, column.air_gaps)
            for left, right, column in zip(edges, edges[1:], self.columns)
        )

    def contains_xy(self, x_um: float, y_um: float) -> bool:
        """Whether the point belongs to the template's construction footprint."""

        return bool(self.contours) and self.contours[-1].contains_xy(x_um, y_um)

    def column_at_point(self, x_um: float, y_um: float) -> RadialColumn:
        """Find a planar material/void stack using the actual stadium boundaries.

        An internal boundary belongs to its outer band, matching
        :meth:`column_at_radius`.  The outermost boundary belongs to the last
        column, as for circular hit testing.
        """

        x, y = float(x_um), float(y_um)
        if not math.isfinite(x) or not math.isfinite(y):
            raise ValueError("point coordinates must be finite")
        by_radius = {contour.radius_um: contour for contour in self.contours}
        for column in self.columns:
            contour = by_radius[column.outer_radius_um]
            if contour.signed_distance_um(x, y) < 0.0:
                return column
        if self.contains_xy(x, y):
            return self.columns[-1]
        raise ValueError(f"point ({x_um!r}, {y_um!r}) is outside the section footprint")

    @property
    def radius_breakpoints_um(self) -> tuple[float, ...]:
        if not self.columns:
            return ()
        return (self.columns[0].inner_radius_um,) + tuple(
            column.outer_radius_um for column in self.columns
        )

    @property
    def radial_breakpoints_um(self) -> tuple[float, ...]:
        return self.radius_breakpoints_um

    @property
    def diameters_um(self) -> tuple[float, ...]:
        """Nonzero short-axis reference diameters in outer-to-inner order."""

        return tuple(
            radius_um * 2.0
            for radius_um in sorted(self.radius_breakpoints_um, reverse=True)
            if radius_um > 0.0
        )

    @property
    def max_radius_um(self) -> float:
        return self.columns[-1].outer_radius_um if self.columns else 0.0

    @property
    def max_height_um(self) -> float:
        """Highest solid elevation; reserved air alone has no mesh extent."""

        return max((column.solid_top_um for column in self.columns), default=0.0)

    @property
    def construction_height_um(self) -> float:
        """Highest solid or air-gap keepout used by subsequent instructions."""

        return max((column.top_um for column in self.columns), default=0.0)

    @property
    def materials(self) -> tuple[str, ...]:
        """Unique material names in layer-file construction order."""

        return tuple(
            dict.fromkeys(
                layer.material
                for layer in self.layers
                if layer.material is not None
            )
        )

    @property
    def components(self) -> tuple[str, ...]:
        """Unique component names in layer-file construction order."""

        return tuple(
            dict.fromkeys(
                layer.component
                for layer in self.layers
                if layer.component is not None
            )
        )

    @property
    def highest_z_um(self) -> float:
        return self.max_height_um

    @property
    def z_breakpoints_um(self) -> tuple[float, ...]:
        """Solid mesh boundaries, intentionally excluding air-only caps."""

        values = {0.0}
        for column in self.columns:
            for span in column.spans:
                values.add(span.z_bottom_um)
                values.add(span.z_top_um)
        return tuple(sorted(values))

    @property
    def air_gap_z_breakpoints_um(self) -> tuple[float, ...]:
        """All exact lower and upper elevations of reserved air gaps."""

        values: set[float] = set()
        for column in self.columns:
            for gap in column.air_gaps:
                values.add(gap.z_bottom_um)
                values.add(gap.z_top_um)
        return tuple(sorted(values))

    @property
    def construction_z_breakpoints_um(self) -> tuple[float, ...]:
        """Combined solid and keepout boundaries used for visualization."""

        return tuple(
            sorted({*self.z_breakpoints_um, *self.air_gap_z_breakpoints_um})
        )

    @property
    def half_section_material_areas_um2(self) -> dict[str, float]:
        areas: dict[str, float] = {}
        for column in self.columns:
            for span in column.spans:
                areas[span.material] = areas.get(span.material, 0.0) + (
                    column.width_um * span.thickness_um
                )
        return areas

    @property
    def material_areas_um2(self) -> dict[str, float]:
        """Material areas in the complete centre-crossing section."""

        return {
            material: 2.0 * area
            for material, area in self.half_section_material_areas_um2.items()
        }

    @property
    def full_section_material_areas_um2(self) -> dict[str, float]:
        return self.material_areas_um2

    @property
    def half_section_component_areas_um2(self) -> dict[str, float]:
        areas: dict[str, float] = {}
        for column in self.columns:
            for span in column.spans:
                areas[span.component] = areas.get(span.component, 0.0) + (
                    column.width_um * span.thickness_um
                )
        return areas

    @property
    def component_areas_um2(self) -> dict[str, float]:
        """Component areas in the complete centre-crossing section."""

        return {
            component: 2.0 * area
            for component, area in self.half_section_component_areas_um2.items()
        }

    @property
    def full_section_component_areas_um2(self) -> dict[str, float]:
        return self.component_areas_um2

    @property
    def half_section_air_gap_area_um2(self) -> float:
        return sum(
            column.width_um * gap.thickness_um
            for column in self.columns
            for gap in column.air_gaps
        )

    @property
    def air_gap_area_um2(self) -> float:
        """Reserved air-gap area in the complete centre-crossing section."""

        return 2.0 * self.half_section_air_gap_area_um2

    @property
    def full_section_air_gap_area_um2(self) -> float:
        return self.air_gap_area_um2

    def column_at_radius(self, radius_um: float) -> RadialColumn:
        """Return the column containing ``abs(radius_um)``.

        The outermost boundary belongs to the last column, which is convenient
        for preview hit-testing even though boundaries have zero geometric area.
        """

        radius = abs(float(radius_um))
        if not math.isfinite(radius):
            raise ValueError("radius must be finite")
        for column in self.columns:
            if column.inner_radius_um <= radius < column.outer_radius_um:
                return column
        if self.columns and radius == self.columns[-1].outer_radius_um:
            return self.columns[-1]
        raise ValueError(f"radius {radius_um!r} is outside the section")


def _split_columns(
    columns: list[RadialColumn], breakpoints: Iterable[float]
) -> list[RadialColumn]:
    points = sorted(set(float(point) for point in breakpoints))
    if not points:
        return columns
    result: list[RadialColumn] = []
    for column in columns:
        interior = [
            point
            for point in points
            if column.inner_radius_um < point < column.outer_radius_um
        ]
        edges = [column.inner_radius_um, *interior, column.outer_radius_um]
        result.extend(
            RadialColumn(left, right, column.spans, column.air_gaps)
            for left, right in zip(edges, edges[1:])
        )
    return result


def _append_span(
    column: RadialColumn,
    *,
    component: str,
    material: str,
    target_top_um: float,
    layer_index: int,
) -> RadialColumn:
    old_top = column.top_um
    if target_top_um <= old_top:
        return column
    return RadialColumn(
        column.inner_radius_um,
        column.outer_radius_um,
        column.spans
        + (
            SectionSpan(
                component,
                material,
                old_top,
                target_top_um,
                layer_index,
            ),
        ),
        column.air_gaps,
    )


def _append_air_gap(
    column: RadialColumn,
    *,
    target_top_um: float,
    layer_index: int,
) -> RadialColumn:
    old_top = column.top_um
    if target_top_um <= old_top:
        return column
    return RadialColumn(
        column.inner_radius_um,
        column.outer_radius_um,
        column.spans,
        column.air_gaps + (AirGapSpan(old_top, target_top_um, layer_index),),
    )


def build_section_plan(layers: Iterable[LayerDefinition]) -> SectionPlan:
    """Apply layers in file order over a chain of nested planar contours.

    ``water,top`` fills empty volume up to ``max(old_top) + t``;
    ``water,bottom`` uses ``min(old_top) + t`` instead.  The signed water
    offset may place the target below some existing surfaces, which remain
    untouched.  Thus water instructions never overwrite existing material.
    A nameless water instruction reserves the same prospective volume as an
    air gap.  Its keepout participates in later surface calculations, but it
    never becomes a :class:`SectionSpan`; subsequent water and tape layers are
    appended above it.
    ``tape`` follows each old horizontal surface with thickness ``t``.  At an
    old step it extends by ``ts`` over the lower side, clipped to the tape
    footprint.  The low-side band rises to ``old_high + t``, so its top is level
    with the tape surface on the old high side.
    """

    layer_tuple = tuple(layers)
    if not layer_tuple:
        return SectionPlan((), ())
    if not all(isinstance(layer, LayerDefinition) for layer in layer_tuple):
        raise TypeError("layers must contain LayerDefinition objects")

    contour_sources, initial_contours = _collect_layer_contours(layer_tuple)
    contours_by_radius = {
        contour.radius_um: contour for contour in initial_contours
    }

    max_radius = max(layer.outer_radius_um for layer in layer_tuple)
    base_breakpoints = {0.0, max_radius}
    for layer in layer_tuple:
        base_breakpoints.add(layer.inner_radius_um)
        base_breakpoints.add(layer.outer_radius_um)
    ordered = sorted(base_breakpoints)
    columns = [
        RadialColumn(inner, outer)
        for inner, outer in zip(ordered, ordered[1:])
        if outer > inner
    ]

    for layer_index, layer in enumerate(layer_tuple):
        inner = layer.inner_radius_um
        outer = layer.outer_radius_um
        columns = _split_columns(columns, (inner, outer))

        if layer.mode is LayerMode.WATER:
            covered = [
                column
                for column in columns
                if column.inner_radius_um >= inner and column.outer_radius_um <= outer
            ]
            if layer.reference is WaterReference.TOP:
                reference_top = max(column.top_um for column in covered)
            else:
                assert layer.reference is WaterReference.BOTTOM
                reference_top = min(column.top_um for column in covered)
            target_top = reference_top + layer.thickness_um
            if layer.is_air_gap:
                columns = [
                    _append_air_gap(
                        column,
                        target_top_um=target_top,
                        layer_index=layer_index,
                    )
                    if column.inner_radius_um >= inner
                    and column.outer_radius_um <= outer
                    else column
                    for column in columns
                ]
                continue

            assert layer.component is not None and layer.material is not None
            columns = [
                _append_span(
                    column,
                    component=layer.component,
                    material=layer.material,
                    target_top_um=target_top,
                    layer_index=layer_index,
                )
                if column.inner_radius_um >= inner and column.outer_radius_um <= outer
                else column
                for column in columns
            ]
            continue

        # Detect steps before applying this tape layer.  A sidewall extension is
        # placed only on the lower side and later clipped to the layer footprint.
        sidewall = layer.sidewall_thickness_um
        assert sidewall is not None  # guaranteed by LayerDefinition validation
        assert layer.component is not None and layer.material is not None
        extensions: list[tuple[float, float, float]] = []
        for left, right in zip(columns, columns[1:]):
            boundary = left.outer_radius_um
            left_top = left.top_um
            right_top = right.top_um
            if left_top < right_top:
                start = max(inner, boundary - sidewall)
                end = min(outer, boundary)
                sidewall_top = right_top + layer.thickness_um
                offset_distance = -sidewall
            elif right_top < left_top:
                start = max(inner, boundary)
                end = min(outer, boundary + sidewall)
                sidewall_top = left_top + layer.thickness_um
                offset_distance = sidewall
            else:
                continue

            # An offset remains a stadium, with both diameters changed by
            # twice the sidewall thickness.  Its short radius orders it, but
            # is insufficient to establish inclusion when cap centres differ.
            boundary_contour = contours_by_radius[boundary]
            offset_contour = (
                boundary_contour.offset(offset_distance)
                if boundary + offset_distance > 0.0 else None
            )
            if offset_contour is not None:
                source = (
                    f"{_layer_source(layer, layer_index)} tape offset "
                    f"{offset_distance:g} um from {boundary_contour}"
                )
                # Even if the short-axis intervals do not overlap, a crossing
                # offset can reach only the tips of the footprint.  Check both
                # footprint boundaries before relying on scalar clipping.
                for footprint_contour in (layer.inner_contour, layer.outer_contour):
                    if footprint_contour is None:
                        continue
                    _check_contour_chain({
                        footprint_contour: contour_sources[footprint_contour],
                        offset_contour: source,
                    })
                if end > start and inner < offset_contour.radius_um < outer:
                    prospective = dict(contour_sources)
                    prospective.setdefault(offset_contour, source)
                    _check_contour_chain(prospective)
                    contour_sources = prospective
                    contours_by_radius[offset_contour.radius_um] = offset_contour
            if end > start:
                extensions.append((start, end, sidewall_top))

        columns = _split_columns(
            columns,
            (point for start, end, _ in extensions for point in (start, end)),
        )
        updated: list[RadialColumn] = []
        for column in columns:
            midpoint = 0.5 * (column.inner_radius_um + column.outer_radius_um)
            if not (inner < midpoint < outer):
                updated.append(column)
                continue
            target_top = column.top_um + layer.thickness_um
            for start, end, sidewall_top in extensions:
                if start < midpoint < end:
                    target_top = max(target_top, sidewall_top)
            updated.append(
                _append_span(
                    column,
                    component=layer.component,
                    material=layer.material,
                    target_top_um=target_top,
                    layer_index=layer_index,
                )
            )
        columns = updated

    return SectionPlan(
        layer_tuple, tuple(columns), _check_contour_chain(contour_sources)
    )


__all__ = [
    "AirGapSpan",
    "LayerDefinition",
    "LayerMode",
    "WaterReference",
    "RadialColumn",
    "SectionPlan",
    "SectionSpan",
    "StadiumContour",
    "build_section_plan",
    "load_layer_file",
    "parse_layer_text",
]
