"""Choose mesh density for a rectangle drawn in the layout canvas."""
from __future__ import annotations

import math

from PySide6.QtWidgets import QDialog, QDialogButtonBox

from .bump_layout import LayoutBounds, StructuredHexRegion
from .designer_widgets import setup_form, dialog_button_texts
from .ui_workflow_region import Ui_WorkflowRegionForm


class WorkflowRegionDialog(QDialog):
    def __init__(self, parent, bounds_um):
        super().__init__(parent)
        self.result_region = None
        self._bounds = LayoutBounds(*(value * .001 for value in bounds_um))
        setup_form(self, Ui_WorkflowRegionForm)
        x_min, x_max, y_min, y_max = bounds_um
        self.bounds_label.setText(
            f"框选范围：X {x_min:.9g} ～ {x_max:.9g} µm\n"
            f"　　　　　Y {y_min:.9g} ～ {y_max:.9g} µm")
        self.target_x_spin.valueChanged.connect(self._update_spacing)
        self.target_y_spin.valueChanged.connect(self._update_spacing)
        dialog_button_texts(self.buttons)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        self._update_spacing()

    def _region(self):
        bounds = self._bounds
        # Derive sizes from the mm extents used by the mesher. Do not round the
        # resulting recurring decimals back to the spin box's display precision.
        counts = []
        for extent, spin in ((bounds.width_mm, self.target_x_spin),
                             (bounds.height_mm, self.target_y_spin)):
            ratio = extent / (spin.value() * .001)
            # Avoid an extra division due solely to binary roundoff at an
            # integer ratio (e.g. (0.08 - 0.06) / 0.01).
            nearest = round(ratio)
            count = nearest if math.isclose(ratio, nearest, rel_tol=1e-12, abs_tol=1e-12) else math.ceil(ratio)
            counts.append(max(1, count))
        return StructuredHexRegion(bounds.x_min_mm, bounds.x_max_mm,
                                   bounds.y_min_mm, bounds.y_max_mm,
                                   bounds.width_mm / counts[0], bounds.height_mm / counts[1])

    def _update_spacing(self, *_args):
        try:
            region = self._region()
        except ValueError as error:
            self.error_label.setText(str(error))
            self.spacing_label.clear()
            self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(False)
            return
        self.error_label.clear()
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(True)
        self.spacing_label.setText(
            f"实际网格尺寸：X {region.size_x_mm * 1000:.9g} µm，Y {region.size_y_mm * 1000:.9g} µm\n"
            f"分段：{region.x_cell_count:,} × {region.y_cell_count:,}")

    def accept(self):
        self.target_x_spin.interpretText()
        self.target_y_spin.interpretText()
        self._update_spacing()
        if self.error_label.text():
            return
        self.result_region = self._region()
        super().accept()
