"""Add/edit Frozen mesh instances with absolute, persistent placement controls."""
from copy import deepcopy

from PySide6.QtWidgets import QWidget

from .designer_widgets import setup_form
from .ui_mesh_placement import Ui_MeshPlacementForm
from .package_v2_instance_transform import IDENTITY, discrete_matrix, frozen_placement_controls
from .package_v2_instances import transform_values


class MeshPlacementWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        setup_form(self, Ui_MeshPlacementForm)
        self.translation_edits = [getattr(self, "translation_" + axis) for axis in "xyz"]
        self.rotation_combos = [getattr(self, "rotation_" + axis) for axis in "xyz"]
        self.mirror_checks = [getattr(self, "mirror_" + axis) for axis in "xyz"]
        self._preserved_placement = None
        for edit in self.translation_edits:
            edit.set_completion_candidates(("mm", "um"))
        self.replace_orientation_button.clicked.connect(self._replace_orientation)
        self.load_placement({"translation": ["0mm"] * 3, "rotation_matrix": IDENTITY})

    def _controls(self):
        return (tuple(combo.currentData() for combo in self.rotation_combos),
                tuple(check.isChecked() for check in self.mirror_checks))

    def load_placement(self, placement):
        controls = frozen_placement_controls(placement)
        self._preserved_placement = deepcopy(placement)
        self._preserved_placement["rotation_matrix"] = [list(row) for row in placement["rotation_matrix"]]
        self._original_controls = controls
        for edit, value in zip(self.translation_edits, placement["translation"]):
            edit.setText(str(value))
        for index, (combo, check) in enumerate(zip(self.rotation_combos, self.mirror_checks)):
            combo.clear()
            if controls is None:
                combo.addItem("保留当前自定义姿态", None)
            else:
                for angle in (0, 90, 180, 270):
                    combo.addItem(f"{angle}°", angle)
                combo.setCurrentIndex(combo.findData(controls[0][index]))
            check.setChecked(controls[1][index] if controls is not None else False)
            combo.setEnabled(controls is not None)
            check.setEnabled(controls is not None)
        self.custom_label.setVisible(controls is None)
        self.replace_orientation_button.setVisible(controls is None)
        if controls is None:
            matrix = placement["rotation_matrix"]
            self.custom_label.setText("当前姿态含非直角变换，将原样保留，可直接修改位置。当前矩阵：\n" +
                                      "\n".join("  ".join(f"{v:.6g}" for v in row) for row in matrix))

    def _replace_orientation(self):
        self.load_placement({"translation": [edit.text() for edit in self.translation_edits],
                             "rotation_matrix": [list(row) for row in IDENTITY]})

    def placement(self):
        translations = [edit.text().strip() for edit in self.translation_edits]
        rotations, mirrors = self._controls()
        # Validate coordinates before submission, including units/formulas.
        transform_values(translations, (0, 0, 0), (False, False, False), ("0mm",) * 3)
        if self._original_controls is None:
            result = deepcopy(self._preserved_placement)
        else:
            # Opening/saving or editing position alone must not change the
            # existing matrix, including any accepted floating-point precision.
            if (rotations, mirrors) == self._original_controls:
                result = deepcopy(self._preserved_placement)
            else:
                result = {"rotation_matrix": [list(row) for row in discrete_matrix(rotations, mirrors)]}
                result["rotation"], result["mirrors"] = list(rotations), list(mirrors)
        result["translation"] = translations
        return result
