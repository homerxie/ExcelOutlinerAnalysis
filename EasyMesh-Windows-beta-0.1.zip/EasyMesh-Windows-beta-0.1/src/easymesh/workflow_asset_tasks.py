"""Bounded background I/O for immutable workflow mesh snapshots."""

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import threading

from PySide6.QtCore import QObject, Signal


_COPY_POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix="mesh-asset-copy")


class MeshAssetCopyTask(QObject):
    finished = Signal(object)

    def __init__(self, path: Path, asset_root: Path, expected_signatures, *, parent=None):
        super().__init__(parent)
        self.path = path
        self.asset_root = asset_root
        self.expected_signatures = expected_signatures
        self.cancel_event = threading.Event()
        self.future = None
        # QObject teardown must never wait for file I/O on the UI thread.
        self.destroyed.connect(self.cancel_event.set)

    def start(self):
        self.future = _COPY_POOL.submit(self._copy)
        self.future.add_done_callback(self._completed)

    def cancel(self):
        self.cancel_event.set()

    def _copy(self):
        from .workflow_handoff import snapshot_mesh_asset
        return snapshot_mesh_asset(
            self.path, self.asset_root, cancelled=self.cancel_event.is_set,
            expected_signatures=self.expected_signatures,
        )

    def _completed(self, _future):
        try:
            self.finished.emit(self)
        except RuntimeError:
            # The owning Qt window may already have been destroyed.
            pass
