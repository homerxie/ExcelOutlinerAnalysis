"""Single Bump templates and Connected Bumps for the assembly workflow.

The shelf owns editable recipes and immutable result snapshots; existing workers
remain the sole authority for mesh generation and report verification.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import uuid

from PySide6.QtCore import QItemSelectionModel, QObject, QSignalBlocker, Qt, QTimer, Slot
from PySide6.QtWidgets import (
    QDialog, QDockWidget, QInputDialog, QMessageBox, QTreeWidgetItem, QWidget, QFileDialog,
)

from .output_artifacts import atomic_write_text
from .workflow_library import (
    add_layer_template, batch_set_template_z_size, duplicate_layer_template,
    empty_workflow_library, remove_layer_templates, rename_layer_template,
    template_z_levels_um, update_layer_template, validate_layer_mesh_z_compatibility,
)
from .workflow_state import validate_workflow_state


def layer_fingerprint(layer):
    from .workflow_dependencies import layer_recipe_fingerprint
    return layer_recipe_fingerprint(layer)


class WorkflowController(QObject):
    def __init__(self, window):
        super().__init__(window)
        self.window = window
        self.library = empty_workflow_library()
        self.assets = []
        self.managed_layout = False
        self._refreshing = False
        self._jobs = {}
        self._recorded_jobs = set()
        self._asset_snapshot_attempts = set()
        self._asset_snapshot_jobs = {}
        self._asset_snapshot_epoch = 0
        self._unrestored_package_source = None
        self._layout_apply_task = None
        self._layout_apply_context = None
        self._layout_apply_cancel_requested = False
        self._layout_apply_disabled_controls = []
        self._close_after_layout_apply = False
        self._root = window._workspace_root / "output" / "workflow" / uuid.uuid4().hex
        self._build_panel()
        from .workflow_package_controls import install_package_controls
        self.package_controls = install_package_controls(window, self)
        window.section_preview_box.setToolTip(window.section_explanation_label.text())
        window.section_explanation_label.setText("点击截面 Z 编号或 XY 网格可定位尺寸；双击显示边界。")
        self.refresh_actions()

    def stage_directory(self, kind):
        """Return the stage directory in the current project or draft workspace."""
        from .project_folder import STAGE_DIRECTORIES

        return self._root / STAGE_DIRECTORIES[kind]

    def _button(self, control, slot):
        from PySide6.QtGui import QAction

        # QToolButton also exposes triggered(QAction*), but that signal is
        # reserved for its menu actions. The primary half uses clicked().
        signal = control.triggered if isinstance(control, QAction) else control.clicked
        signal.connect(lambda _checked=False: self._run(slot))
        return control

    def _run(self, action):
        try:
            action()
        except (OSError, RuntimeError, TypeError, ValueError) as error:
            QMessageBox.warning(self.window, "工作流", str(error))

    def _build_panel(self):
        from .designer_widgets import setup_form
        from .ui_workflow_panel import Ui_WorkflowPanel
        from .ui_workflow_layer_actions import Ui_WorkflowLayerActions
        from .ui_workflow_layout_actions import Ui_WorkflowLayoutActions

        w = self.window
        dock = QDockWidget(w)
        setup_form(dock, Ui_WorkflowPanel)
        for name in ("template_tree", "asset_tree", "resource_tabs", "template_hint", "asset_hint",
                     "asset_to_cdb_action", "single_to_layout_action", "single_to_cdb_action",
                     "connected_rename_action", "connected_remove_action"):
            setattr(self, name, getattr(dock, name))
        self.use_connected_button = dock.use_asset_button
        self.template_tree.setColumnWidth(0, 150)
        self.asset_tree.setColumnWidth(0, 150)
        dock.batch_templates_button.setMenu(dock.batch_templates_menu)
        dock.template_more_button.setMenu(dock.template_more_menu)
        dock.use_asset_button.setMenu(dock.use_asset_menu)
        for control, slot in (
                (dock.add_template_button, self.add_current_template),
                (dock.duplicate_template_action, self.duplicate_template),
                (dock.rename_template_action, self.rename_template),
                (dock.remove_templates_action, self.remove_templates),
                (dock.batch_z_action, self.batch_z_dialog),
                (dock.generate_templates_action, self.generate_selected),
                (dock.scale_xy_action, self.scale_xy_dialog),
                (dock.single_to_layout_action, self.current_layer_to_layout),
                (dock.single_to_cdb_action, lambda: self.current_to_cdb("layer")),
                (dock.edit_template_action, self.edit_selected),
                (dock.use_asset_button, self.add_selected_to_package),
                (dock.asset_to_cdb_action, self.export_selected_cdb),
                (dock.connected_rename_action, self.rename_connected),
                (dock.connected_remove_action, self.remove_connected),
                (dock.import_mesh_button, self.import_connected),
                (dock.import_scheme_action, self.import_schemes),
                (dock.save_scheme_action, w.layer_mesh_save_button.click),
                (dock.save_scheme_as_action, w.layer_mesh_save_as_button.click)):
            self._button(control, slot)
        for button in (w.layer_mesh_open_button, w.layer_mesh_save_button, w.layer_mesh_save_as_button):
            button.hide()

        def update_template_actions():
            count = len(self.selected_template_ids())
            dock.batch_templates_button.setVisible(count > 1)
            dock.duplicate_template_action.setEnabled(count == 1)
            dock.rename_template_action.setEnabled(count == 1)
            dock.scale_xy_action.setEnabled(count == 1)
            dock.remove_templates_action.setEnabled(count > 0)
            self.refresh_actions()

        self.template_tree.itemSelectionChanged.connect(update_template_actions)
        update_template_actions()
        w.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, dock)
        w.menuBar().addAction(dock.toggleViewAction())
        w.resizeDocks([dock], [285], Qt.Orientation.Horizontal)
        dock.hide()
        self.dock = dock
        self.template_tree.itemDoubleClicked.connect(lambda *_: self._run(self.edit_selected))
        self.template_tree.currentItemChanged.connect(self._template_changed)
        self.asset_tree.currentItemChanged.connect(lambda *_: self._asset_selection_changed())
        for tab, name in ((w.layer_tab, "单 Bump 模板"), (w.layout_tab, "Bump 布局连接"),
                          (w.package_v2_tab, "Package拼接"), (w.cdb_tab, "MSH → CDB")):
            w.main_tabs.setTabText(w.main_tabs.indexOf(tab), name)
        w.main_tabs.tabBar().moveTab(w.main_tabs.indexOf(w.package_v2_tab), 2)
        w.app_subtitle_label.setText("Single Bump 模板 → Connected Bumps → Package 装配 → CDB")
        layer_actions = QWidget(w.layer_tab)
        setup_form(layer_actions, Ui_WorkflowLayerActions)
        layer_actions.next_stage_button.setMenu(layer_actions.next_stage_menu)
        self.layer_next_button = layer_actions.next_stage_button
        self.layer_cdb_action = layer_actions.layer_to_cdb_action
        for control, slot in (
                (layer_actions.show_resources_button, lambda: self.show_templates()),
                (layer_actions.next_stage_button, self.current_layer_to_layout),
                (layer_actions.layer_to_cdb_action, lambda: self.current_to_cdb("layer"))):
            self._button(control, slot)
        w.layer_tab_layout.insertWidget(0, layer_actions)
        self.layer_actions = layer_actions
        layout_actions = QWidget(w.layout_tab)
        setup_form(layout_actions, Ui_WorkflowLayoutActions)
        layout_actions.next_stage_button.setMenu(layout_actions.next_stage_menu)
        self.layout_next_button = layout_actions.next_stage_button
        self.layout_cdb_action = layout_actions.layout_to_cdb_action
        for control, slot in (
                (layout_actions.edit_layout_button, self.edit_layout),
                (layout_actions.show_resources_button, self.show_templates),
                (layout_actions.next_stage_button, self.current_layout_to_package),
                (layout_actions.layout_to_cdb_action, lambda: self.current_to_cdb("layout"))):
            self._button(control, slot)
        w.layout_tab_layout.insertWidget(0, layout_actions)
        self.layout_actions = layout_actions
        for container in (layout_actions.progress_container, layout_actions.mesh_progress_container):
            w.status_bar.addPermanentWidget(container, 1)
            container.hide()
        layout_actions.cancel_apply_button.clicked.connect(self._cancel_layout_apply)

    def _template(self, identifier=None):
        identifier = identifier or self.library["active_template_id"]
        return next((item for item in self.library["templates"] if item["id"] == identifier), None)

    def _capture_active(self):
        if self._refreshing or self.library["active_template_id"] is None:
            return
        self.library = update_layer_template(self.library, self.library["active_template_id"],
                                             self.window._current_layer_mesh_state())

    def snapshot(self):
        self._capture_active()
        editor = self.window._package_v2_source_editor
        source = self._unrestored_package_source
        if editor is not None and not editor.read_only:
            source = {"path": str(editor.path), "text": editor.raw_text}
        return validate_workflow_state({"schema": "easymesh-workflow-v1", "library": self.library,
                                        "assets": [asset for asset in self.assets if asset["kind"] != "package_v2"],
                                        "managed_layout": self.managed_layout,
                                        "package_source": source})

    def restore(self, document):
        self.cancel_pending_asset_copies()
        self._asset_snapshot_epoch += 1
        state = document.get("workflow")
        self.library = empty_workflow_library() if state is None else deepcopy(state["library"])
        # Previously saved generic result shelves may include terminal Package
        # outputs. Those remain on disk, but are no longer reusable library items.
        self.assets = [] if state is None else [deepcopy(asset) for asset in state["assets"]
                                               if asset["kind"] != "package_v2"]
        self.managed_layout = bool(state and state["managed_layout"])
        # A live preview can keep polling an old worker after a project switch.
        # Its result must never be re-enqueued into the newly restored library.
        self._asset_snapshot_attempts.update(self._jobs)
        self._jobs.clear()
        self._recorded_jobs.clear()
        self._unrestored_package_source = None
        self.refresh()
        if state and state.get("package_source"):
            try:
                self._restore_package_source(state["package_source"])
            except (OSError, RuntimeError, TypeError, ValueError) as error:
                self._unrestored_package_source = deepcopy(state["package_source"])
                self.window._set_package_v2_source_state(
                    f"工程保留了 Package 草稿，但暂时无法恢复：{error}", tone="error")

    def prepare_restore(self, document):
        """Recreate an embedded managed LOC without overwriting a user file."""
        state = document.get("workflow")
        if state and state["managed_layout"] and document["layout"]["source_text"]:
            from .bump_layout import parse_bump_layout_text
            layout = document["layout"]
            path = self.stage_directory("layout") / "layout.loc"
            parse_bump_layout_text(layout["source_text"], source_path=path)
            atomic_write_text(path, layout["source_text"])
            layout["source_path"] = str(path)

    def _restore_package_source(self, source):
        from .workflow_source import restore_source_snapshot
        w = self.window
        editor = restore_source_snapshot(source, self.stage_directory("package_v2"))
        w._install_package_v2_source_editor(editor)
        w._reconcile_package_v2_editor_with_job()

    def refresh(self):
        selected = set(self.selected_template_ids())
        self._refreshing = True
        try:
            self.template_tree.clear()
            for template in self.library["templates"]:
                try:
                    levels = template_z_levels_um(template)
                    summary = f"{len(levels) - 1} 层"
                    detail = ", ".join(f"{value:g}" for value in levels) + " µm"
                except (TypeError, ValueError) as error:
                    summary, detail = "待修正", str(error)
                item = QTreeWidgetItem([template["name"], summary, self.template_mesh_status(template)])
                item.setData(0, Qt.ItemDataRole.UserRole, template["id"])
                item.setToolTip(1, detail)
                self.template_tree.addTopLevelItem(item)
                if template["id"] == self.library["active_template_id"]:
                    self.template_tree.setCurrentItem(item, 0, QItemSelectionModel.SelectionFlag.NoUpdate)
                item.setSelected(template["id"] in selected or (not selected and template["id"] == self.library["active_template_id"]))
            current_asset = self.selected_asset()
            self.asset_tree.clear()
            for asset in self.connected_assets():
                status = self.asset_status(asset)
                item = QTreeWidgetItem([asset["name"], status])
                item.setData(0, Qt.ItemDataRole.UserRole, asset["id"])
                item.setToolTip(0, asset["mesh_path"])
                self.asset_tree.addTopLevelItem(item)
                if current_asset and current_asset["id"] == asset["id"]:
                    self.asset_tree.setCurrentItem(item)
            if self.asset_tree.currentItem() is None and self.asset_tree.topLevelItemCount():
                self.asset_tree.setCurrentItem(self.asset_tree.topLevelItem(self.asset_tree.topLevelItemCount() - 1))
        finally:
            self._refreshing = False

    def _changed(self):
        self.refresh()
        self.window._refresh_project_modified()

    def refresh_actions(self):
        """Keep the next step obvious and unavailable until its input is ready."""
        w = self.window
        template = self._template()
        if template is not None:
            w.layer_mesh_file_label.setText(f"当前模板：{template['name']} · 随工程保存")
        for kind in ("layer", "layout"):
            candidates = [asset for asset in self.assets if asset["kind"] == kind]
            if kind == "layer":
                fingerprint = layer_fingerprint(w._current_layer_mesh_state())
                candidates = [asset for asset in candidates
                              if asset.get("template_id") == self.library["active_template_id"]
                              and asset.get("layer_fingerprint") == fingerprint]
            else:
                candidates = [asset for asset in candidates
                              if asset.get("input_fingerprint") == self.layout_fingerprint()]
            available = bool(candidates and self.asset_status(candidates[-1]) == "可用")
            for suffix in ("next_button", "cdb_action"):
                control = getattr(self, f"{kind}_{suffix}", None)
                if control is not None:
                    control.setEnabled(available)
                    control.setToolTip("使用当前已校验的网格结果" if available else "请先生成当前方案的网格")
        asset = self.selected_asset()
        available = bool(asset and self.asset_status(asset) == "可用")
        self.use_connected_button.setEnabled(available)
        assets_by_id = {item["id"]: item for item in self.assets}
        for row in range(self.asset_tree.topLevelItemCount()):
            item = self.asset_tree.topLevelItem(row)
            record = assets_by_id.get(item.data(0, Qt.ItemDataRole.UserRole))
            if record is not None:
                item.setText(1, self.asset_status(record))
        self.asset_to_cdb_action.setEnabled(available)
        self.connected_rename_action.setEnabled(asset is not None)
        self.connected_remove_action.setEnabled(asset is not None)
        selected = self.selected_template_ids()
        single = self._template(selected[0]) if len(selected) == 1 else None
        ready = single is not None and self.template_mesh_status(single) == "可用于连接"
        self.single_to_layout_action.setEnabled(ready and not self.layout_apply_busy)
        self.single_to_cdb_action.setEnabled(ready)
        for row in range(self.template_tree.topLevelItemCount()):
            item = self.template_tree.topLevelItem(row)
            template = self._template(item.data(0, Qt.ItemDataRole.UserRole))
            if template is not None:
                item.setText(2, self.template_mesh_status(template))
        controls = getattr(self, "package_controls", None)
        if controls is not None:
            editor = w._package_v2_source_editor
            controls.refresh()
            controls.generate_button.setEnabled(
                "package_v2" not in w._active_job_kinds and not w._package_v2_pending_source_edits
                and bool((editor and not editor.read_only) or w.package_v2_generate_button.isEnabled()))
            controls.cdb_button.setEnabled(w.package_v2_cdb_button.isEnabled())

    def selected_template_ids(self):
        return [item.data(0, Qt.ItemDataRole.UserRole) for item in self.template_tree.selectedItems()]

    def _template_changed(self, current, _previous):
        if self._refreshing or current is None:
            return
        identifier = current.data(0, Qt.ItemDataRole.UserRole)
        self._run(lambda: self.activate_template(identifier))

    def activate_template(self, identifier):
        if identifier == self.library["active_template_id"]:
            return
        self._capture_active()
        template = self._template(identifier)
        if template is None:
            raise ValueError("模板不存在。")
        self._refreshing = True
        try:
            self.library["active_template_id"] = identifier
            # A standalone scheme belongs to the previously edited recipe.
            # Exporting another template must choose its own destination.
            self.window._layer_mesh_path = None
            self.window._clean_layer_mesh_state = None
            self.window._apply_layer_mesh_state(template["layer"])
        finally:
            self._refreshing = False
        self.template_hint.setText(f"正在编辑：{template['name']}。平面网格和几何修改仅影响此模板。")
        self.window._refresh_project_modified()

    def edit_selected(self):
        ids = self.selected_template_ids()
        if not ids:
            raise ValueError("请先选择模板。")
        self.activate_template(ids[0])
        self.window.main_tabs.setCurrentWidget(self.window.layer_tab)

    def import_schemes(self, paths=None):
        """Append standalone recipes without replacing existing templates or drafts."""
        from .layer_mesh_file import LAYER_MESH_FILTER, LAYER_MESH_SUFFIX, load_layer_mesh_state

        w = self.window
        if paths is None:
            initial = w._layer_mesh_path or w._workspace_path(w.layer_path_edit.text() or ".")
            paths, _ = QFileDialog.getOpenFileNames(
                w, "追加 Layer 网格方案到模板库", str(initial), LAYER_MESH_FILTER)
        if not paths:
            return False
        # Read the entire batch before capturing edits or changing selection.
        imported = [(Path(path), load_layer_mesh_state(path)) for path in paths]
        library = deepcopy(self.library)
        current = w._current_layer_mesh_state()
        active = library["active_template_id"]
        if active is not None:
            library = update_layer_template(library, active, current)
        validate_layer_mesh_z_compatibility([
            *((item["name"], item["layer"]) for item in library["templates"]),
            *((path.name, state) for path, state in imported),
        ])

        def append(name, state):
            nonlocal library
            base = name.strip() or "导入方案"
            names = {item["name"] for item in library["templates"]}
            name = base
            suffix = 2
            while name in names:
                name = f"{base}（{suffix}）"
                suffix += 1
            library = add_layer_template(library, name, state)
            return library["templates"][-1]

        for path, state in imported:
            name = (path.name[:-len(LAYER_MESH_SUFFIX)]
                    if path.name.lower().endswith(LAYER_MESH_SUFFIX) else path.stem)
            template = append(name, state)
            template["layer"]["output_path"] = str(self.stage_directory("layer") / "meshes" / f"{template['id']}.msh")
        # Keep the old recipe active until the guarded editor switch captures it.
        library["active_template_id"] = active
        self.library = library
        if active is not None:
            self.activate_template(template["id"])
            self.template_tree.clearSelection()
        self._changed()
        self.show_templates()
        w.main_tabs.setCurrentWidget(w.layer_tab)
        w.layer_config_tabs.setCurrentWidget(w.mesh_settings_tab)
        # An unshelved draft stays in the editor (and the project's layer
        # snapshot); it is not silently added to the compatible template set.
        detail = (f"当前编辑：{template['name']}。" if active is not None
                  else "当前草稿保留在编辑器中，可从模板库选择方案。")
        message = f"高度网格兼容检查通过，已追加 {len(imported)} 个方案；{detail}"
        self.template_hint.setText(message)
        w.statusBar().showMessage(message, 6000)
        return True

    def add_current_template(self, name=None):
        if name is None:
            name, accepted = QInputDialog.getText(self.window, "收录当前模板", "模板名称：")
            if not accepted:
                return
        self._capture_active()
        state = self.window._current_layer_mesh_state()
        library = add_layer_template(self.library, name, state)
        template = library["templates"][-1]
        template["layer"]["output_path"] = str(self.stage_directory("layer") / "meshes" / f"{template['id']}.msh")
        library["active_template_id"] = template["id"]
        self.library = library
        self.window._layer_mesh_path = None
        self.window._clean_layer_mesh_state = None
        self.window.output_edit.setText(template["layer"]["output_path"])
        self.template_tree.clearSelection()
        self._changed()

    def duplicate_template(self):
        self._capture_active()
        ids = self.selected_template_ids()
        if not ids:
            raise ValueError("请先选择模板。")
        active = self.library["active_template_id"]
        self.library = duplicate_layer_template(self.library, ids[0])
        template = self.library["templates"][-1]
        template["layer"]["output_path"] = str(self.stage_directory("layer") / "meshes" / f"{template['id']}.msh")
        self.library["active_template_id"] = active
        self.activate_template(template["id"])
        self.template_tree.clearSelection()
        self._changed()

    def rename_template(self):
        ids = self.selected_template_ids()
        if not ids:
            raise ValueError("请先选择模板。")
        name, accepted = QInputDialog.getText(self.window, "重命名模板", "名称：", text=self._template(ids[0])["name"])
        if accepted:
            self._capture_active()
            self.library = rename_layer_template(self.library, ids[0], name)
            self._changed()

    def remove_templates(self):
        self._capture_active()
        ids = self.selected_template_ids()
        if not ids:
            return
        active = self.library["active_template_id"]
        self.library = remove_layer_templates(self.library, ids)
        if active in ids:
            # Leave the editor intact as an unregistered draft.
            self.library["active_template_id"] = None
        self._changed()

    def batch_z_dialog(self):
        ids = self.selected_template_ids()
        if not ids:
            raise ValueError("请多选需要统一厚度网格的模板。")
        value, accepted = QInputDialog.getDouble(self.window, "统一厚度方向网格",
            f"统一 {len(ids)} 个模板的 Z 目标尺寸（µm）。\n会统一局部 Z 覆写与布种策略；几何厚度保持不变：", 1.0, 0.000001, 1e9, 6)
        if accepted:
            self.set_selected_z(ids, value)

    def set_selected_z(self, ids, value):
        self._capture_active()
        self.library = batch_set_template_z_size(self.library, ids, value)
        template = self._template()
        if template and template["id"] in ids:
            self.window._apply_layer_mesh_state(template["layer"])
        self._changed()
        self.template_hint.setText(f"已统一 {len(ids)} 个模板的 Z 网格；请重新生成受影响模板。")

    def scale_xy_dialog(self):
        from .workflow_library import scale_template_xy_geometry
        self._capture_active()
        template = self._template()
        if template is None:
            raise ValueError("请先选择模板。")
        value, accepted = QInputDialog.getDouble(self.window, "平面几何尺寸",
            "XY 几何缩放倍数（厚度和 Z 网格保持不变）：", 1.0, 0.001, 1000, 4)
        if accepted:
            self.library = scale_template_xy_geometry(self.library, template["id"], value)
            self.window._apply_layer_mesh_state(self._template()["layer"])
            self._changed()

    def generate_selected(self):
        self._capture_active()
        ids = self.selected_template_ids()
        if not ids:
            raise ValueError("请先选择要生成的模板。")
        from .workflow_library import layer_state_parameters
        states = [deepcopy(self._template(identifier)["layer"]) for identifier in ids]
        for state in states:
            layer_state_parameters(state)
        saved = self.window._current_layer_mesh_state()
        active = self.library["active_template_id"]
        self._refreshing = True
        try:
            for identifier, state in zip(ids, states):
                self.library["active_template_id"] = identifier
                self.window._apply_layer_mesh_state(state)
                self.window._launch(preview=False)
        finally:
            self.library["active_template_id"] = active
            self.window._apply_layer_mesh_state(saved)
            self._refreshing = False
        self.show_templates()

    def track_job(self, process, kind):
        if kind not in {"layer", "layout"}:
            return
        self._recorded_jobs.discard(id(process))
        self._asset_snapshot_attempts.discard(id(process))
        template = self._template() if kind == "layer" else None
        self._jobs[id(process)] = {
            "workflow_epoch": self._asset_snapshot_epoch,
            "workflow_root": self._root,
            "project_path": self.window._project_path,
            "name": template["name"] if template else ("Connected Bumps" if kind == "layout" else "Single Bump"),
            "template_id": None if template is None else template["id"],
            "layer_fingerprint": layer_fingerprint(self.window._current_layer_mesh_state()) if kind == "layer" else None,
            "input_fingerprint": self.layout_fingerprint() if kind == "layout" else None,
            "upstream_asset_ids": self.layout_asset_ids() if kind == "layout" else [],
        }

    def accept_job(self, process_id, kind, path):
        if kind not in {"layer", "layout"}:
            return
        if process_id in self._recorded_jobs or process_id in self._asset_snapshot_attempts:
            return
        from .workflow_asset_tasks import MeshAssetCopyTask
        from .workflow_handoff import _signature
        self._asset_snapshot_attempts.add(process_id)
        context = deepcopy(self._jobs.get(process_id, {}))
        if context and (
                context.get("workflow_epoch", self._asset_snapshot_epoch) != self._asset_snapshot_epoch
                or context.get("workflow_root", self._root) != self._root
                or context.get("project_path", self.window._project_path) != self.window._project_path):
            return
        path = Path(path).expanduser().resolve()
        template_id = context.get("template_id")
        asset_root = self._asset_root(kind, template_id)
        try:
            signatures = tuple(_signature(source) for source in (
                path, path.with_suffix(".parameters.json"), path.with_suffix(".report.json")))
            task = MeshAssetCopyTask(path, asset_root, signatures, parent=self)
            task.process_id = process_id
            previous = self._asset_snapshot_jobs.get(process_id)
            if previous is not None:
                previous[0].cancel()
            self._asset_snapshot_jobs[process_id] = (
                task, kind, context, self._root, self.window._project_path,
                self._asset_snapshot_epoch,
            )
            task.finished.connect(self._finish_asset_snapshot, Qt.ConnectionType.QueuedConnection)
            self._set_asset_snapshot_status(kind, "网格已生成，正在后台保存到网格库…")
            task.start()
        except (OSError, RuntimeError, ValueError) as error:
            pending = self._asset_snapshot_jobs.pop(process_id, None)
            if pending is not None:
                pending[0].cancel()
                pending[0].deleteLater()
            self._set_asset_snapshot_status(kind, f"网格生成成功，但库内网格保存失败：{error}")

    def _set_asset_snapshot_status(self, kind, message):
        label = self.template_hint if kind == "layer" else self.asset_hint
        label.setText(message)
        if kind == "layout":
            self.dock.show()
            self.resource_tabs.setCurrentIndex(1)
        self.window.statusBar().showMessage(message, 12000)

    def cancel_pending_asset_copies(self):
        for task, *_context in self._asset_snapshot_jobs.values():
            task.cancel()

    @Slot(object)
    def _finish_asset_snapshot(self, task):
        pending = self._asset_snapshot_jobs.get(task.process_id)
        try:
            if pending is None or pending[0] is not task:
                return
            self._asset_snapshot_jobs.pop(task.process_id, None)
            _, kind, context, root, project_path, epoch = pending
            if (task.cancel_event.is_set() or root != self._root
                    or project_path != self.window._project_path
                    or epoch != self._asset_snapshot_epoch):
                return
            snapshot = task.future.result()
            self._register_asset(
                snapshot, kind=kind,
                name=context.get("name", "Connected Bumps" if kind == "layout" else "Single Bump"),
                template_id=context.get("template_id"), fingerprint=context.get("layer_fingerprint"),
                input_fingerprint=context.get("input_fingerprint"),
                upstream_asset_ids=context.get("upstream_asset_ids", []),
            )
            self._recorded_jobs.add(task.process_id)
            self._set_asset_snapshot_status(kind, "网格已保存到库，可继续下一步。")
        except Exception as error:
            self._set_asset_snapshot_status(pending[1], f"网格生成成功，但库内网格保存失败：{error}")
        finally:
            task.deleteLater()

    def _asset_root(self, kind, template_id):
        asset_root = self.stage_directory(kind) / "assets"
        if template_id is not None:
            asset_root = asset_root / hashlib.sha256(template_id.encode()).hexdigest()
        return asset_root

    def add_asset(self, path, *, kind="layout", name=None, template_id=None, fingerprint=None,
                  input_fingerprint=None, upstream_asset_ids=()):
        from .workflow_handoff import snapshot_mesh_asset
        if kind not in {"layer", "layout"}:
            raise ValueError("库中仅保存 Single Bump 模板网格和 Connected Bumps。Package 请直接导出。")
        asset_root = self._asset_root(kind, template_id)
        snapshot = snapshot_mesh_asset(path, asset_root)
        return self._register_asset(
            snapshot, kind=kind, name=name or Path(path).stem, template_id=template_id,
            fingerprint=fingerprint, input_fingerprint=input_fingerprint,
            upstream_asset_ids=upstream_asset_ids,
        )

    def _register_asset(self, snapshot, *, kind, name, template_id=None,
                        fingerprint=None, input_fingerprint=None, upstream_asset_ids=()):
        if kind == "layout":
            base, index = name, 2
            existing = {asset["name"] for asset in self.connected_assets()}
            while name in existing:
                name, index = f"{base} {index}", index + 1
        record = {"id": uuid.uuid4().hex, "name": name, "kind": kind,
                  "mesh_path": str(snapshot.mesh_path), "sha256": snapshot.sha256}
        if template_id is not None:
            record["template_id"] = template_id
        if fingerprint is not None:
            record["layer_fingerprint"] = fingerprint
        if input_fingerprint is not None:
            record["input_fingerprint"] = input_fingerprint
        if upstream_asset_ids:
            record["upstream_asset_ids"] = list(upstream_asset_ids)
        self.assets.append(record)
        self._changed()
        if kind == "layout":
            self.asset_tree.setCurrentItem(self.asset_tree.topLevelItem(self.asset_tree.topLevelItemCount() - 1))
        return record

    def connected_assets(self):
        return [asset for asset in self.assets if asset["kind"] == "layout"]

    def template_mesh_status(self, template):
        assets = [asset for asset in self.assets if asset["kind"] == "layer"
                  and asset.get("template_id") == template["id"]]
        fingerprint = layer_fingerprint(template["layer"])
        matching = [asset for asset in assets if asset.get("layer_fingerprint") == fingerprint]
        if matching:
            status = self.asset_status(matching[-1])
            return "可用于连接" if status == "可用" else status
        return "需重新生成" if assets else "未生成"

    def asset_status(self, asset, seen=None):
        seen = set() if seen is None else seen
        if asset["id"] in seen:
            return "依赖循环"
        seen = {*seen, asset["id"]}
        if not Path(asset["mesh_path"]).is_file():
            return "文件缺失"
        template = self._template(asset.get("template_id")) if asset.get("template_id") else None
        if template and asset.get("layer_fingerprint") != layer_fingerprint(template["layer"]):
            return "需重新生成"
        for identifier in asset.get("upstream_asset_ids", []):
            upstream = next((item for item in self.assets if item["id"] == identifier), None)
            if upstream is None or self.asset_status(upstream, seen) != "可用":
                return "上游已修改"
        return "可用"

    def _require_asset(self, asset):
        self._capture_active()
        if asset is None:
            raise ValueError("请先选择 Single Bump 模板或 Connected Bumps，并生成网格。")
        status = self.asset_status(asset)
        if status != "可用":
            raise ValueError(f"{asset['name']}：{status}。请重新生成模板。")
        path = Path(asset["mesh_path"])
        if self.window._sha256_file(path) != asset["sha256"]:
            raise ValueError("结果网格已被外部修改，请重新生成或重新导入。")
        return path

    def selected_asset(self):
        item = self.asset_tree.currentItem()
        identifier = None if item is None else item.data(0, Qt.ItemDataRole.UserRole)
        return next((asset for asset in self.connected_assets() if asset["id"] == identifier), None)

    def _asset_selection_changed(self):
        asset = self.selected_asset()
        if asset:
            self.asset_hint.setText(f"{asset['name']} · {self.asset_status(asset)}")
            self.asset_hint.setToolTip(asset["mesh_path"])
        else:
            self.asset_hint.setText("选择 Connected Bumps 后可加入 Package 或导出 CDB。")
            self.asset_hint.setToolTip("")
        if not self._refreshing:
            self.refresh_actions()

    def show_connected(self):
        self._capture_active()
        self.refresh()
        self.dock.show()
        self.resource_tabs.setCurrentIndex(1)

    def show_templates(self):
        self._capture_active()
        self.refresh()
        self.dock.show()
        self.resource_tabs.setCurrentIndex(0)

    def import_connected(self):
        path, _ = QFileDialog.getOpenFileName(self.window, "导入 Connected Bumps", str(self.window._workspace_root), "Gmsh 网格 (*.msh)")
        if path:
            from .package_v2_mesh_groups import read_mesh_volume_groups
            read_mesh_volume_groups(path)
            self.add_asset(path, kind="layout")

    def rename_connected(self):
        asset = self.selected_asset()
        if asset is None:
            return
        name, accepted = QInputDialog.getText(self.window, "重命名 Connected Bumps", "名称：", text=asset["name"])
        if accepted:
            name = name.strip()
            if not name or any(item["id"] != asset["id"] and item["name"] == name for item in self.connected_assets()):
                raise ValueError("请使用非空且不重复的名称。")
            asset["name"] = name
            self._changed()

    def remove_connected(self):
        asset = self.selected_asset()
        if asset is not None:
            self.assets = [item for item in self.assets if item["id"] != asset["id"]]
            self._changed()

    def current_asset(self, kind):
        self._capture_active()
        candidates = [asset for asset in self.assets if asset["kind"] == kind]
        if kind == "layer":
            candidates = [asset for asset in candidates if asset.get("template_id") == self.library["active_template_id"]
                          and asset.get("layer_fingerprint") == layer_fingerprint(self.window._current_layer_mesh_state())]
        if kind == "layout":
            candidates = [asset for asset in candidates if asset.get("input_fingerprint") == self.layout_fingerprint()]
        if not candidates:
            raise ValueError("当前方案尚无已校验的生成结果，请先生成网格。")
        self._require_asset(candidates[-1])
        return candidates[-1]

    def layout_fingerprint(self):
        w = self.window
        data = [w.layout_source_view.toPlainText(), w.far_field_size_edit.text(),
                w.transition_distance_edit.text(), w._layout_material_inputs]
        return hashlib.sha256(json.dumps(data, sort_keys=True, ensure_ascii=False).encode()).hexdigest()

    def layout_asset_ids(self):
        layout = self.window._bump_layout
        paths = set() if layout is None else {str(t.mesh_path.resolve()) for t in layout.templates}
        return [asset["id"] for asset in self.assets if str(Path(asset["mesh_path"]).resolve()) in paths]

    def current_layer_to_layout(self):
        self.add_to_layout(self.current_asset("layer"))

    def current_layout_to_package(self):
        self.add_to_package(self.current_asset("layout"))

    def current_to_cdb(self, kind):
        self.export_cdb(self.current_asset(kind))

    @property
    def layout_apply_busy(self):
        # Keep ownership until the queued finished handler has consumed output.
        return self._layout_apply_task is not None

    def _require_layout_apply_idle(self):
        if self.layout_apply_busy:
            raise ValueError("正在后台应用连接布局，请等待完成或取消。")

    def _set_layout_apply_controls(self, busy):
        w = self.window
        if busy:
            controls = [self.layout_actions.edit_layout_button, self.single_to_layout_action]
            controls.extend(getattr(w, name) for name in (
                "layout_path_edit", "layout_browse_button", "layout_reload_button",
                "layout_generate_button", "layout_preview_button", "new_project_action",
                "open_project_action", "open_project_folder_action", "save_project_action",
                "save_project_as_action",
            ))
            self._layout_apply_disabled_controls = [(control, control.isEnabled()) for control in controls]
            for control, _enabled in self._layout_apply_disabled_controls:
                control.setEnabled(False)
        else:
            for control, enabled in self._layout_apply_disabled_controls:
                control.setEnabled(enabled)
            self._layout_apply_disabled_controls = []

    def _start_layout_apply(self, layout, *, expected_digests=None):
        """Prepare immutable results on a worker and commit only the current draft."""
        from .layout_apply import LayoutApplyTask

        self._require_layout_apply_idle()
        w = self.window
        if "layout" in w._active_job_kinds:
            raise ValueError("请等待当前连接网格生成结束后再应用布局。")
        path = (self.stage_directory("layout") / "layout.loc").resolve()
        self._layout_apply_context = (
            self._root, w._project_path, w._layout_source_revision,
            path, w._layout_dependency_snapshot_signature(path),
        )
        task = LayoutApplyTask(layout, path=path, expected_digests=expected_digests, parent=self)
        self._layout_apply_task = task
        self._layout_apply_cancel_requested = False
        self._set_layout_apply_controls(True)
        actions = self.layout_actions
        actions.apply_progress_bar.setValue(0)
        actions.apply_progress_label.setText("正在后台准备连接布局…")
        actions.apply_progress_label.setToolTip(actions.apply_progress_label.text())
        actions.cancel_apply_button.setEnabled(True)
        actions.mesh_progress_container.hide()
        actions.progress_container.show()
        w.layout_status_label.setStyleSheet(w._semantic_style("muted"))
        w.layout_status_label.setText("正在后台应用连接布局，可以继续查看其他页面。")
        w.main_tabs.setCurrentWidget(w.layout_tab)
        task.progressChanged.connect(self._on_layout_apply_progress, Qt.ConnectionType.QueuedConnection)
        task.finished.connect(self._finish_layout_apply, Qt.ConnectionType.QueuedConnection)
        task.start()
        return task

    @Slot(int, str)
    def _on_layout_apply_progress(self, percent, message):
        if self.sender() is not self._layout_apply_task or self._layout_apply_cancel_requested:
            return
        self.layout_actions.apply_progress_bar.setValue(percent)
        self.layout_actions.apply_progress_label.setText(message)
        self.layout_actions.apply_progress_label.setToolTip(message)

    @Slot()
    def _cancel_layout_apply(self):
        task = self._layout_apply_task
        if task is None:
            return
        self._layout_apply_cancel_requested = True
        task.cancel()
        self.layout_actions.cancel_apply_button.setEnabled(False)
        self.layout_actions.apply_progress_label.setText("正在取消，等待当前模板读取结束…")
        self.layout_actions.apply_progress_label.setToolTip(self.layout_actions.apply_progress_label.text())

    @Slot()
    def _finish_layout_apply(self):
        task = self.sender()
        if task is not self._layout_apply_task:
            return
        w = self.window
        message, style, succeeded = "已取消应用，原布局保持不变。", "muted", False
        try:
            if not (task.was_cancelled or self._layout_apply_cancel_requested):
                if task.error is not None:
                    raise ValueError(task.error)
                root, project_path, revision, path, signature = self._layout_apply_context
                if (root != self._root or project_path != w._project_path
                        or revision != w._layout_source_revision
                        or path != (self.stage_directory("layout") / "layout.loc").resolve()
                        or signature != w._layout_dependency_snapshot_signature(path)):
                    raise ValueError("工程或布局已变化，已丢弃过期的应用结果。")
                prepared = task.result
                if prepared is None or task.staged_path is None:
                    raise ValueError("后台任务未返回完整布局。")
                if any(w._layout_dependency_snapshot_signature(dependency) != expected
                       for dependency, expected in prepared.dependency_signatures.items()):
                    raise ValueError("模板资源已变化，请重新应用布局。")
                # All reads, validation and disk staging have finished. The UI
                # only swaps the file and installs the prepared view models.
                os.replace(task.staged_path, path)
                task.staged_path = None
                if not self.managed_layout:
                    with QSignalBlocker(w.layout_output_edit):
                        w.layout_output_edit.setText(str(self.stage_directory("layout") / "meshes" / "connected.msh"))
                self.managed_layout = True
                w._install_layout_source(prepared.layout, path, prepared.text, prepared=prepared)
                message = f"已应用 {len(prepared.layout.instances):,} 个 bump 的连接布局。"
                style, succeeded = "success", True
        except Exception as error:
            message, style = f"应用连接布局失败：{error}", "error"
        finally:
            try:
                task.cleanup()
            except OSError as error:
                message += f" 暂存文件清理失败：{error}"
            self._layout_apply_task = None
            self._layout_apply_context = None
            task.deleteLater()
            self._set_layout_apply_controls(False)
            w._refresh_layout_launch_state(preserve_status=True)
            self.refresh_actions()
            self.layout_actions.cancel_apply_button.setEnabled(False)
            self.layout_actions.apply_progress_bar.setValue(100 if succeeded else 0)
            self.layout_actions.apply_progress_label.setText(message)
            self.layout_actions.apply_progress_label.setToolTip(message)
            w.layout_status_label.setStyleSheet(w._semantic_style(style))
            w.layout_status_label.setText(message)
            if self._close_after_layout_apply:
                self._close_after_layout_apply = False
                QTimer.singleShot(0, w.close)

    def _save_managed_layout(self, layout):
        self._require_layout_apply_idle()
        from .workflow_handoff import serialize_bump_layout
        path = (self.stage_directory("layout") / "layout.loc").resolve()
        text = serialize_bump_layout(layout)
        atomic_write_text(path, text)
        was_managed = self.managed_layout
        self.managed_layout = True
        w = self.window
        if not was_managed:
            with QSignalBlocker(w.layout_output_edit):
                w.layout_output_edit.setText(str(self.stage_directory("layout") / "meshes" / "connected.msh"))
        w._install_layout_source(replace(layout, source_path=path), path, text,
                                 show_error=False, inspect_templates=True)
        w.main_tabs.setCurrentWidget(w.layout_tab)
        w._refresh_project_modified()

    def refresh_layout_inputs(self):
        self._require_layout_apply_idle()
        from .workflow_dependencies import refresh_layout_template_assets
        self._capture_active()
        layout = self.window._bump_layout
        if layout is not None:
            updated = refresh_layout_template_assets(layout, self.assets, self.library)
            if updated is not layout:
                self._save_managed_layout(updated)
        return self.window._bump_layout

    def add_to_layout(self, asset):
        self._require_layout_apply_idle()
        from .bump_layout import BumpLayout, LayoutBounds, BumpInstance, BumpMeshTemplate
        from .workflow_handoff import add_template_to_layout
        from .sample_mesh import load_sample_mesh_cached as load_sample_mesh, validate_compatible_outer_boundaries
        path = self._require_asset(asset)
        mesh = load_sample_mesh(path)
        w = self.window
        layout = self.refresh_layout_inputs()
        if layout and any(template.mesh_path.resolve() == path.resolve() for template in layout.templates):
            w.main_tabs.setCurrentWidget(w.layout_tab)
            w.layout_status_label.setText("布局已使用当前模板网格，已有放置位置保持不变。")
            return
        if layout:
            validate_compatible_outer_boundaries([*(load_sample_mesh(t.mesh_path) for t in layout.templates), mesh],
                                                require_identical_radius=False)
        dialog = QDialog(w)
        from .designer_widgets import setup_form
        from .ui_workflow_placement import Ui_WorkflowPlacementForm
        setup_form(dialog, Ui_WorkflowPlacementForm)
        alias = dialog.alias_edit
        base = asset["name"].strip().replace("\n", " ").replace("\r", " ") or "模板"
        if base.startswith("#") or base.casefold() in {"xsize", "ysize", "define", "mesh"}:
            base = "模板_" + base.lstrip("#")
        existing = set() if layout is None else {item.alias for item in layout.templates}
        name, index = base, 2
        while name in existing:
            name, index = f"{base}_{index}", index + 1
        alias.setText(name)
        x, y = dialog.x_spin, dialog.y_spin
        bounds_edits = (dialog.xmin_spin, dialog.xmax_spin, dialog.ymin_spin, dialog.ymax_spin)
        dialog.bounds_box.setVisible(layout is None)
        if layout is None:
            center_x, center_y = mesh.outer_boundary.center_xy
            radius = max(max(abs(point.x - center_x), abs(point.y - center_y)) for point in mesh.nodes) * 1500
            for edit, value in zip(bounds_edits, (-radius, radius, -radius, radius)):
                edit.setValue(value)
        dialog.buttons.accepted.connect(dialog.accept)
        dialog.buttons.rejected.connect(dialog.reject)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        position = (x.value() * .001, y.value() * .001)
        if layout is None:
            layout = BumpLayout(bounds=LayoutBounds(*(edit.value() * .001 for edit in bounds_edits)),
                                templates=(BumpMeshTemplate(alias.text(), path),),
                                instances=(BumpInstance(*position, alias.text()),))
        else:
            layout = add_template_to_layout(layout, path, alias=alias.text(), position_mm=position)
        self._start_layout_apply(layout)

    def edit_layout(self):
        self._require_layout_apply_idle()
        from .workflow_layout_dialog import WorkflowLayoutDialog
        self._capture_active()
        ready = [asset for asset in self.assets if self.asset_status(asset) == "可用"
                 and asset["kind"] in {"layer", "external"}]
        dialog = WorkflowLayoutDialog(self.window, self.window._bump_layout, ready,
                                      asset_root=self.stage_directory("layer") / "assets",
                                      defer_mesh_validation=True)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self._start_layout_apply(dialog.result_layout, expected_digests=dialog.result_digests)

    def add_selected_to_package(self):
        self.add_to_package(self.selected_asset())

    def add_to_package(self, asset):
        from .package_v2_local_templates import new_document
        from .package_v2_source_editor import open_package_v2_source_editor
        from .workflow_handoff import prepare_package_frozen_source
        path = self._require_asset(asset)
        w = self.window
        if "package_v2" in w._active_job_kinds or w._package_v2_pending_blocks_structural_edit():
            raise ValueError("请等待 Package 任务结束，并完成尚未通过校验的修改。")
        editor = w._package_v2_source_editor
        if editor is None:
            source_path = self.stage_directory("package_v2") / "package.source.json"
            atomic_write_text(source_path, json.dumps(new_document("package"), ensure_ascii=False, indent=2) + "\n")
            editor = open_package_v2_source_editor(source_path)
            w._install_package_v2_source_editor(editor)
        if editor.read_only:
            raise ValueError("当前 Package 为只读任务快照，请先打开可编辑 Source。")
        identifiers = {item["id"] for item in editor.document["frozen_sources"] + editor.document["instances"]}
        base = "connected" if asset["kind"] == "layout" else "mesh"
        index = 1
        while f"{base}_{index}" in identifiers:
            index += 1
        source = prepare_package_frozen_source(path, editor.path, source_id=f"{base}_{index}")
        result = editor.add_frozen_source(source)
        w._finish_package_v2_source_edit(result.pointer)
        w.main_tabs.setCurrentWidget(w.package_v2_tab)
        self._changed()

    def export_selected_cdb(self):
        self.export_cdb(self.selected_asset())

    def generate_package(self):
        """Freeze the editable draft and launch the existing verified Job path."""
        from .workflow_source import restore_source_snapshot
        from .package_v2_authoring import materialize_package_v2_job
        w = self.window
        if "package_v2" in w._active_job_kinds:
            return
        if w._package_v2_pending_blocks_structural_edit():
            return
        editor = w._package_v2_source_editor
        if editor is None or editor.read_only:
            w._launch_package_v2()
            return
        snapshot = {"path": str(editor.path), "text": editor.raw_text}
        source = restore_source_snapshot(snapshot, self.stage_directory("package_v2"))
        output = self.stage_directory("package_v2") / "meshes" / "package.msh"
        job = output.with_suffix(".job.json")
        output.parent.mkdir(parents=True, exist_ok=True)
        materialize_package_v2_job(source.path, job, output, job_id="workflow-" + uuid.uuid4().hex)
        w._install_package_v2_source_editor(source)
        w.package_v2_job_path_edit.setText(str(job))
        w._package_v2_job_stale = False
        if w._inspect_package_v2_job(show_error=True) is not None:
            w._launch_package_v2()

    def export_cdb(self, asset):
        path = self._require_asset(asset)
        w = self.window
        w.cdb_input_edit.setText(str(path))
        # Put final deliverables outside the immutable asset cache.
        w.cdb_output_edit.setText(str(self.stage_directory("cdb") / f"{asset['id']}.cdb"))
        w.main_tabs.setCurrentWidget(w.cdb_tab)
        w._refresh_cdb_launch_state()
        w._refresh_project_modified()
