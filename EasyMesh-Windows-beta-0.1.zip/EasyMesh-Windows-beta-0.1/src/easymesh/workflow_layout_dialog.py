"""Coordinate import and visual authoring for large connection layouts."""
from __future__ import annotations

from pathlib import Path
from html import escape
import uuid

from PySide6.QtCore import QItemSelection, QItemSelectionModel, QSignalBlocker, Qt
from PySide6.QtWidgets import (
    QDialog, QDialogButtonBox, QFileDialog, QHeaderView, QTableWidgetItem,
)

from .bump_layout import (
    BumpInstance, BumpLayout, BumpMeshTemplate, LayoutBounds, StructuredHexRegion,
    validate_structured_hex_regions,
)
from .designer_widgets import setup_form, dialog_button_texts
from .layout_coordinates import read_layout_coordinates
from .layout_instance_model import LayoutInstanceDelegate, LayoutInstanceModel, LayoutInstanceRow
from .layout_region_model import LayoutRegionDelegate, LayoutRegionModel, LayoutRegionRow
from .ui_workflow_layout import Ui_WorkflowLayoutForm
from .output_artifacts import sha256_file
from .sample_mesh import load_sample_mesh_cached as load_sample_mesh, validate_compatible_outer_boundaries
from .workflow_handoff import serialize_bump_layout, snapshot_mesh_asset
from .workflow_region_dialog import WorkflowRegionDialog


class WorkflowLayoutDialog(QDialog):
    """Edit a draft; publish ``result_layout`` only after complete validation."""

    def __init__(self, parent, current_layout, assets, *, asset_root=None,
                 defer_mesh_validation=False):
        super().__init__(parent)
        self.result_layout = None
        self.result_digests = {}
        self._defer_mesh_validation = defer_mesh_validation
        self._original = current_layout
        self._digests = {}
        self._meshes = {}
        self._selected = set()
        self._region_target_sizes = (10., 10.)
        self._asset_root = Path(asset_root) if asset_root is not None else None
        if self._asset_root is None and hasattr(parent, "_workspace_root"):
            self._asset_root = Path(parent._workspace_root) / "output" / "workflow" / "imports"
        self._build_ui(assets)
        if current_layout is not None:
            for key, spin in self.bounds_spins.items():
                spin.setValue(getattr(current_layout.bounds, key) * 1000)
            for template in current_layout.templates:
                self._append_template(template.alias, template.mesh_path)
            keys = {self.template_table.item(row, 0).text(): self.template_table.item(row, 0).data(Qt.ItemDataRole.UserRole)
                    for row in range(self.template_table.rowCount())}
            self.instance_model.replace_rows(LayoutInstanceRow(
                instance.x_mm * 1000, instance.y_mm * 1000,
                keys[instance.template_alias], instance.rotation_deg)
                for instance in current_layout.instances)
            self.region_model.replace_rows(LayoutRegionRow.from_region(region)
                                           for region in current_layout.mesh_regions)
        self._update_template_choices()
        self._update_bounds()
        self.canvas.fit_all()

    def _build_ui(self, assets):
        setup_form(self, Ui_WorkflowLayoutForm)
        self.layout_splitter.setStretchFactor(0, 2)
        self.layout_splitter.setStretchFactor(1, 3)
        self.layout_splitter.setSizes([470, 760])
        self.instance_model = LayoutInstanceModel(self)
        self.instance_table.setModel(self.instance_model)
        self.instance_table.setItemDelegate(LayoutInstanceDelegate(self.instance_table))
        self.region_model = LayoutRegionModel(self)
        self.region_table.setModel(self.region_model)
        self.region_table.setItemDelegate(LayoutRegionDelegate(self.region_table))
        self.region_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.region_model.rowsChanged.connect(self._refresh_regions)
        self.region_table.selectionModel().selectionChanged.connect(self._region_selection_changed)
        self.add_region_button.clicked.connect(lambda: self._guard(self._add_region))
        self.remove_region_button.clicked.connect(self._remove_regions)
        self.instance_model.rowsChanged.connect(self._refresh_instances)
        self.instance_model.modelReset.connect(lambda: self._set_selection(set()))
        self.instance_table.selectionModel().selectionChanged.connect(self._table_selection_changed)
        self.canvas.selectionChanged.connect(self._set_selection)
        self.draw_region_button.toggled.connect(self._set_region_draw_mode)
        self.canvas.regionDrawModeChanged.connect(self.draw_region_button.setChecked)
        self.canvas.regionDrawn.connect(lambda bounds: self._guard(lambda: self._create_drawn_region(bounds)))
        self.canvas.cursorPositionChanged.connect(self._update_cursor_position)
        self.fit_view_button.clicked.connect(self.canvas.fit_all)
        self.select_all_button.clicked.connect(lambda: self._set_selection(set(range(self.instance_model.rowCount()))))
        self.clear_selection_button.clicked.connect(lambda: self._set_selection(set()))
        self.apply_template_button.clicked.connect(lambda: self._guard(self._apply_selected_template))
        self.import_coordinates_button.clicked.connect(self._browse_coordinates)
        self.bounds_spins = {"x_min_mm": self.x_min_spin, "x_max_mm": self.x_max_spin,
                             "y_min_mm": self.y_min_spin, "y_max_mm": self.y_max_spin}
        for spin in self.bounds_spins.values():
            spin.valueChanged.connect(self._update_bounds)
        for asset in assets:
            if asset.get("mesh_path"):
                self.asset_combo.addItem(asset.get("name", Path(asset["mesh_path"]).stem), dict(asset))
        self.add_asset_button.setMenu(self.template_add_menu)
        self.add_asset_button.clicked.connect(lambda: self._guard(self._add_asset))
        self.import_mesh_action.triggered.connect(self._browse_mesh)
        self.remove_template_button.clicked.connect(lambda: self._guard(self._remove_templates))
        self.template_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.template_table.itemChanged.connect(self._update_template_choices)
        self.add_instance_button.clicked.connect(lambda: self._guard(self._add_instance))
        self.remove_instance_button.clicked.connect(self._remove_instances)
        self.instance_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self._refresh_regions()
        self.new_layout_button = self.buttons.button(QDialogButtonBox.StandardButton.Reset)
        self.new_layout_button.setText(self.buttons.property("resetText"))
        self.new_layout_button.setToolTip(self.buttons.property("resetToolTip"))
        self.new_layout_button.clicked.connect(self._new_layout)
        dialog_button_texts(self.buttons)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        self._update_selection_label()

    def _new_layout(self):
        self.draw_region_button.setChecked(False)
        self._original = None
        self.result_layout = None
        self.result_digests = {}
        self.instance_model.replace_rows([])
        self.region_model.replace_rows([])
        self.template_table.setRowCount(0)
        self._digests.clear()
        self._meshes.clear()
        self.canvas.set_templates({})
        for name, spin in self.bounds_spins.items():
            spin.setValue(-500 if "min" in name else 500)
        self.error_label.clear()
        self._update_template_choices()
        self.canvas.fit_all()

    def _guard(self, action):
        try:
            action()
        except (ValueError, TypeError, OSError, RuntimeError) as error:
            self.error_label.setText(self._error_message(error))
        else:
            self.error_label.clear()

    @staticmethod
    def _error_message(error):
        return {
            "structured HEX region must lie within layout bounds": "局部加密区必须位于连接区域范围内。",
            "structured HEX regions must not touch or overlap": "局部加密区之间不能接触或重叠，请调整区域。",
        }.get(str(error), str(error))

    def _unique_alias(self, proposed):
        base = proposed.strip().replace("\n", " ").replace("\r", " ") or "template"
        if base.startswith("#") or base.casefold() in {"mesh", "define", "xsize", "ysize"}:
            base = "template_" + base.lstrip("#")
        existing = {self.template_table.item(row, 0).text().strip()
                    for row in range(self.template_table.rowCount())}
        alias, index = base, 2
        while alias in existing:
            alias, index = f"{base}_{index}", index + 1
        return alias

    def _append_template(self, alias, path, *, sha256=None, mesh=None):
        key = uuid.uuid4().hex
        row = self.template_table.rowCount()
        with QSignalBlocker(self.template_table):
            self.template_table.insertRow(row)
            name = QTableWidgetItem(alias)
            name.setData(Qt.ItemDataRole.UserRole, key)
            self.template_table.setItem(row, 0, name)
            item = QTableWidgetItem(str(Path(path).resolve()))
            item.setToolTip(item.text())
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.template_table.setItem(row, 1, item)
        if sha256 is not None:
            self._digests[key] = sha256
        try:
            self._meshes[key] = mesh if mesh is not None else load_sample_mesh(path)
        except (ValueError, OSError, RuntimeError) as error:
            self.error_label.setText(f"模板 {alias} 预览不可用：{error}")
        self.canvas.set_templates(self._meshes)
        self._update_template_choices()
        return key

    def _add_mesh(self, path, *, name=None, sha256=None, external=False):
        path = Path(path).expanduser().resolve(strict=True)
        if sha256 is not None and sha256_file(path) != sha256:
            raise ValueError("结果网格已被修改，请重新生成或重新导入。")
        mesh = load_sample_mesh(path)
        if external and self._asset_root is not None:
            snapshot = snapshot_mesh_asset(path, self._asset_root)
            path, sha256 = snapshot.mesh_path, snapshot.sha256
        key = self._append_template(self._unique_alias(name or path.stem), path, sha256=sha256, mesh=mesh)
        if self.instance_model.rowCount() == 0:
            self._append_instance(0, 0, key)
            if self._original is None and self.template_table.rowCount() == 1:
                center_x, center_y = mesh.outer_boundary.center_xy
                half_x = max(abs(node.x - center_x) for node in mesh.nodes) * 1500
                half_y = max(abs(node.y - center_y) for node in mesh.nodes) * 1500
                for axis, half in (("x", half_x), ("y", half_y)):
                    self.bounds_spins[f"{axis}_min_mm"].setValue(-max(half, .001))
                    self.bounds_spins[f"{axis}_max_mm"].setValue(max(half, .001))
        self.template_table.selectRow(self.template_table.rowCount() - 1)
        self.canvas.fit_all()

    def _add_asset(self):
        asset = self.asset_combo.currentData()
        if asset is None:
            self._browse_mesh()
            return
        self._add_mesh(asset["mesh_path"], name=asset.get("name"), sha256=asset.get("sha256"))

    def _browse_mesh(self):
        selected, _ = QFileDialog.getOpenFileName(self, "添加外部连接模板", "", "Gmsh 网格 (*.msh)")
        if selected:
            self._guard(lambda: self._add_mesh(selected, name=Path(selected).stem, external=True))

    def _template_choices(self):
        return [(self.template_table.item(row, 0).text().strip(),
                 self.template_table.item(row, 0).data(Qt.ItemDataRole.UserRole))
                for row in range(self.template_table.rowCount())]

    def _update_template_choices(self, *_args):
        if not hasattr(self, "instance_model"):
            return
        choices = self._template_choices()
        self.add_instance_button.setEnabled(bool(choices))
        self.instance_model.set_choices(choices)
        self.template_legend_label.setText("　".join(
            f'<span style="color:{self.canvas.template_color(key).name()}">●</span> {escape(alias)}'
            for alias, key in choices))
        for combo in (self.default_template_combo, self.batch_template_combo):
            selected = combo.currentData()
            with QSignalBlocker(combo):
                combo.clear()
                for alias, key in choices:
                    combo.addItem(alias, key)
                combo.setCurrentIndex(max(0, combo.findData(selected)))
        self._update_selection_label()

    def _append_instance(self, x_um, y_um, key, rotation_deg=0):
        self.instance_model.append_rows([LayoutInstanceRow(x_um, y_um, key, rotation_deg)])

    def _add_instance(self):
        if not self.template_table.rowCount():
            raise ValueError("请先添加模板。")
        key = self.default_template_combo.currentData()
        row = self.instance_model.rowCount()
        x, y = 0.0, 0.0
        if row:
            x = self.instance_model.rows[-1].x_um
            y = self.instance_model.rows[-1].y_um
            x += max(1, (self.bounds_spins["x_max_mm"].value() - self.bounds_spins["x_min_mm"].value()) / 10)
        self._append_instance(x, y, key)
        self.instance_table.selectRow(row)

    def _remove_instances(self):
        self.instance_model.remove_rows(self._selected)

    def _remove_templates(self):
        rows = {index.row() for index in self.template_table.selectedIndexes()}
        keys = {self.template_table.item(row, 0).data(Qt.ItemDataRole.UserRole) for row in rows}
        if any(row.template_key in keys for row in self.instance_model.rows):
            raise ValueError("选中的模板仍有放置实例，请先删除对应放置或选择其他模板。")
        with QSignalBlocker(self.template_table):
            for row in sorted(rows, reverse=True):
                key = self.template_table.item(row, 0).data(Qt.ItemDataRole.UserRole)
                self._digests.pop(key, None)
                self._meshes.pop(key, None)
                self.template_table.removeRow(row)
        self.canvas.set_templates(self._meshes)
        self._update_template_choices()

    def _update_bounds(self, *_args):
        self.canvas.set_bounds(tuple(spin.value() for spin in self.bounds_spins.values()))

    def _update_cursor_position(self, point):
        if point is None:
            self.cursor_position_label.setText("鼠标坐标：—（µm）")
        else:
            self.cursor_position_label.setText(f"鼠标坐标：X {point.x():.9g} µm，Y {point.y():.9g} µm")

    def _set_region_draw_mode(self, enabled):
        self.canvas.set_region_draw_mode(enabled)
        if enabled:
            self.editor_tabs.setCurrentWidget(self.regions_tab)
            self.canvas.setFocus()

    def _create_drawn_region(self, bounds_um):
        self.region_table.itemDelegate().commit_active_editor()
        bounds = LayoutBounds(*(value * .001 for value in bounds_um))
        layout_bounds = LayoutBounds(*(spin.value() * .001 for spin in self.bounds_spins.values()))
        # Validate before opening the density dialog: changing mesh sizes
        # cannot fix a rectangle outside the layout or touching another patch.
        rectangle = StructuredHexRegion(bounds.x_min_mm, bounds.x_max_mm,
                                        bounds.y_min_mm, bounds.y_max_mm,
                                        bounds.width_mm, bounds.height_mm)
        regions = self.region_model.regions()
        validate_structured_hex_regions(layout_bounds, (*regions, rectangle))
        dialog = WorkflowRegionDialog(self, bounds_um)
        dialog.target_x_spin.setValue(self._region_target_sizes[0])
        dialog.target_y_spin.setValue(self._region_target_sizes[1])
        self.canvas.set_mesh_regions((*regions, rectangle))
        self.canvas.set_region_selection({len(regions)})
        try:
            if dialog.exec() != QDialog.DialogCode.Accepted:
                return
            self._region_target_sizes = (dialog.target_x_spin.value(), dialog.target_y_spin.value())
            region = dialog.result_region
            # Keep the canvas's original µm endpoints. A mm -> µm -> mm round
            # trip can change the span of a tiny patch at a large coordinate.
            self.region_model.append_row(LayoutRegionRow(
                *bounds_um, region.size_x_mm * 1000, region.size_y_mm * 1000))
            self.editor_tabs.setCurrentWidget(self.regions_tab)
            self.region_table.selectRow(self.region_model.rowCount() - 1)
            self.region_table.scrollTo(self.region_model.index(self.region_model.rowCount() - 1, 0))
        finally:
            self._refresh_regions()
            dialog.deleteLater()

    def _add_region(self):
        self.region_table.itemDelegate().commit_active_editor()
        bounds = LayoutBounds(*(spin.value() * .001 for spin in self.bounds_spins.values()))
        # Start with a small patch at the lower-left corner, away from the
        # usual central bump. The draft can then be moved/resized in the table.
        size_um = min(bounds.width_mm, bounds.height_mm) * 100
        x_min, y_min = bounds.x_min_mm * 1000, bounds.y_min_mm * 1000
        self.region_model.append_row(LayoutRegionRow(
            x_min, x_min + size_um, y_min, y_min + size_um, size_um / 4, size_um / 4))
        self.region_table.selectRow(self.region_model.rowCount() - 1)

    def _remove_regions(self):
        selected = {index.row() for index in self.region_table.selectionModel().selectedRows()}
        self.region_model.remove_rows(selected)

    def _region_selection_changed(self, *_args):
        selected = {index.row() for index in self.region_table.selectionModel().selectedRows()}
        self.canvas.set_region_selection(selected)
        self.remove_region_button.setEnabled(bool(selected))

    def _refresh_regions(self):
        preview, errors = [], []
        for index, row in enumerate(self.region_model.rows):
            try:
                preview.append(row.to_region())
            except ValueError as error:
                preview.append(None)
                errors.append(f"第 {index + 1} 个局部加密区：{error}")
        self.canvas.set_mesh_regions(preview)
        self.region_status_label.setText(errors[0] if errors else
                                        f"共 {len(preview)} 个局部加密区 · 绿色框显示区域位置")
        self._region_selection_changed()

    def _refresh_instances(self):
        self._selected.intersection_update(range(self.instance_model.rowCount()))
        self.canvas.set_instances(self.instance_model.rows)
        self.canvas.set_selection(self._selected)
        self._update_selection_label()

    def _update_selection_label(self):
        self.selection_label.setText(f"共 {self.instance_model.rowCount():,} 个 bump · 已选 {len(self._selected):,} 个")
        self.apply_template_button.setEnabled(bool(self._selected) and bool(self._template_choices()))
        self.remove_instance_button.setEnabled(bool(self._selected))

    def _table_selection_changed(self, *_args):
        # The table selects entire rows. Expanding its disjoint ranges is linear;
        # selectedRows() repeatedly checks range containment and becomes costly
        # for thousands of alternating selected rows.
        self._selected = {row for selected in self.instance_table.selectionModel().selection()
                          for row in range(selected.top(), selected.bottom() + 1)}
        self.canvas.set_selection(self._selected)
        self._update_selection_label()

    def _set_selection(self, selected):
        model = self.instance_model
        row_count = model.rowCount()
        self._selected = {index for index in selected if 0 <= index < row_count}
        selection = QItemSelection()
        ordered = sorted(self._selected)
        # Indices are already validated above. createIndex avoids repeated
        # Python row/column-count callbacks for thousands of disjoint ranges.
        if ordered:
            first = last = ordered[0]
            for index in ordered[1:] + [None]:
                if index is not None and index == last + 1:
                    last = index
                    continue
                selection.select(model.createIndex(first, 0), model.createIndex(last, 3))
                first = last = index
        selection_model = self.instance_table.selectionModel()
        with QSignalBlocker(selection_model):
            # ClearAndSelect computes an expensive difference between old and
            # new ranges even when signals are blocked (e.g. all -> 5k odd rows).
            # Clearing first preserves the current cell and avoids that work.
            selection_model.clearSelection()
            selection_model.select(selection, QItemSelectionModel.SelectionFlag.Select)
        self.instance_table.viewport().update()
        self.canvas.set_selection(self._selected)
        self._update_selection_label()

    def _apply_selected_template(self):
        key = self.batch_template_combo.currentData()
        if key is None:
            raise ValueError("请先添加模板。")
        self.instance_model.assign_template(self._selected, key)
        if self.expand_bounds_check.isChecked():
            self._expand_bounds_to_instances()

    def _browse_coordinates(self):
        selected, _ = QFileDialog.getOpenFileName(
            self, "导入 Bump 坐标", "", "坐标表格 (*.xlsx *.xls *.csv *.tsv);;Excel (*.xlsx *.xls);;CSV (*.csv *.tsv)")
        if selected:
            self._guard(lambda: self._import_coordinates(selected))

    def _import_coordinates(self, path):
        key = self.default_template_combo.currentData()
        if key is None:
            raise ValueError("请先添加模板并设置默认模板，再导入坐标。")
        coordinates = read_layout_coordinates(path, unit="mm" if self.coordinate_unit_combo.currentIndex() == 1 else "um")
        if any(max(abs(point.x_um), abs(point.y_um)) > 1e12 for point in coordinates):
            raise ValueError("坐标超出支持范围（±10¹² µm）。")
        rows = [LayoutInstanceRow(point.x_um, point.y_um, key, point.rotation_deg) for point in coordinates]
        if self.import_mode_combo.currentIndex() == 1:
            rows = self.instance_model.rows + rows
        # Validate duplicates before replacing the draft, including appended rows.
        template_paths = {self.template_table.item(index, 0).data(Qt.ItemDataRole.UserRole):
                          Path(self.template_table.item(index, 1).text())
                          for index in range(self.template_table.rowCount())}
        BumpLayout(LayoutBounds(-1, 1, -1, 1),
                   tuple(BumpMeshTemplate(key, template_paths[key]) for key in dict.fromkeys(row.template_key for row in rows)),
                   tuple(BumpInstance(row.x_um * .001, row.y_um * .001, row.template_key, row.rotation_deg) for row in rows))
        self.instance_model.replace_rows(rows)
        if self.expand_bounds_check.isChecked():
            self._expand_bounds_to_instances()
        self.canvas.fit_all()

    def _expand_bounds_to_instances(self):
        # A circumscribed radius contains every rotation of a template.
        radii = {}
        for key, mesh in self._meshes.items():
            cx, cy = mesh.outer_boundary.center_xy
            radii[key] = max(((node.x - cx) ** 2 + (node.y - cy) ** 2) ** .5 for node in mesh.nodes) * 1000
        extents = [spin.value() for spin in self.bounds_spins.values()]
        for row in self.instance_model.rows:
            radius = max(radii.get(row.template_key, 1) * 1.1, .001)
            extents[0] = min(extents[0], row.x_um - radius)
            extents[1] = max(extents[1], row.x_um + radius)
            extents[2] = min(extents[2], row.y_um - radius)
            extents[3] = max(extents[3], row.y_um + radius)
        for spin, value in zip(self.bounds_spins.values(), extents):
            spin.setValue(value)

    def accept(self):
        self.instance_table.itemDelegate().commit_active_editor()
        self.region_table.itemDelegate().commit_active_editor()
        try:
            regions = self.region_model.regions()
            templates, meshes, digests = [], [], {}
            choices = dict((key, alias) for alias, key in self._template_choices())
            for row in range(self.template_table.rowCount()):
                item = self.template_table.item(row, 0)
                path = Path(self.template_table.item(row, 1).text())
                digest = self._digests.get(item.data(Qt.ItemDataRole.UserRole))
                if digest is not None:
                    digests[item.text()] = digest
                if (not self._defer_mesh_validation and digest is not None
                        and sha256_file(path) != digest):
                    raise ValueError(f"模板 {item.text()} 的网格已被修改，请重新导入。")
                templates.append(BumpMeshTemplate(item.text(), path))
                if not self._defer_mesh_validation:
                    meshes.append(load_sample_mesh(path))
            instances = []
            for index, row in enumerate(self.instance_model.rows):
                key = row.template_key
                if key not in choices:
                    raise ValueError(f"第 {index + 1} 个放置尚未选择模板。")
                instances.append(BumpInstance(row.x_um * .001, row.y_um * .001,
                                               choices[key], row.rotation_deg))
            layout = BumpLayout(LayoutBounds(*(spin.value() * .001 for spin in self.bounds_spins.values())),
                                tuple(templates), tuple(instances),
                                source_path=None if self._original is None else self._original.source_path,
                                mesh_regions=regions)
            serialize_bump_layout(layout)
            if not self._defer_mesh_validation:
                validate_compatible_outer_boundaries(meshes, require_identical_radius=False)
        except (ValueError, TypeError, OSError, RuntimeError) as error:
            self.error_label.setText(self._error_message(error))
            return
        self.result_layout = layout
        self.result_digests = digests
        super().accept()


__all__ = ["WorkflowLayoutDialog"]
