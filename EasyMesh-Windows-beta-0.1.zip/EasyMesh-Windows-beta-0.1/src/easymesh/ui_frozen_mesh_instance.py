# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'frozen_mesh_instance.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QComboBox, QDialog,
    QDialogButtonBox, QFormLayout, QFrame, QGroupBox,
    QHBoxLayout, QLabel, QLayout, QLineEdit,
    QPushButton, QScrollArea, QSizePolicy, QVBoxLayout,
    QWidget)

from easymesh.package_v2_mesh_fingerprint import MeshFingerprintWidget
from easymesh.package_v2_mesh_group_selector import MeshGroupSelector
from easymesh.package_v2_mesh_placement import MeshPlacementWidget

class Ui_FrozenMeshInstanceForm(object):
    def setupUi(self, FrozenMeshInstanceForm):
        if not FrozenMeshInstanceForm.objectName():
            FrozenMeshInstanceForm.setObjectName(u"FrozenMeshInstanceForm")
        FrozenMeshInstanceForm.resize(780, 700)
        self.root_layout = QVBoxLayout(FrozenMeshInstanceForm)
        self.root_layout.setObjectName(u"root_layout")
        self.content_scroll = QScrollArea(FrozenMeshInstanceForm)
        self.content_scroll.setObjectName(u"content_scroll")
        self.content_scroll.setWidgetResizable(True)
        self.content_scroll.setFrameShape(QFrame.NoFrame)
        self.content_page = QWidget()
        self.content_page.setObjectName(u"content_page")
        self.content_layout = QVBoxLayout(self.content_page)
        self.content_layout.setObjectName(u"content_layout")
        self.content_layout.setSizeConstraint(QLayout.SetMinimumSize)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.help_label = QLabel(self.content_page)
        self.help_label.setObjectName(u"help_label")
        self.help_label.setWordWrap(True)
        self.help_label.setTextFormat(Qt.PlainText)

        self.content_layout.addWidget(self.help_label)

        self.source_form = QFormLayout()
        self.source_form.setObjectName(u"source_form")
        self.source_form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        self.reuse_label = QLabel(self.content_page)
        self.reuse_label.setObjectName(u"reuse_label")
        self.reuse_label.setWordWrap(True)
        self.reuse_label.setTextFormat(Qt.PlainText)

        self.source_form.setWidget(0, QFormLayout.ItemRole.LabelRole, self.reuse_label)

        self.reuse_combo = QComboBox(self.content_page)
        self.reuse_combo.addItem("")
        self.reuse_combo.setObjectName(u"reuse_combo")

        self.source_form.setWidget(0, QFormLayout.ItemRole.FieldRole, self.reuse_combo)

        self.source_id_label = QLabel(self.content_page)
        self.source_id_label.setObjectName(u"source_id_label")
        self.source_id_label.setWordWrap(True)
        self.source_id_label.setTextFormat(Qt.PlainText)

        self.source_form.setWidget(1, QFormLayout.ItemRole.LabelRole, self.source_id_label)

        self.source_id_edit = QLineEdit(self.content_page)
        self.source_id_edit.setObjectName(u"source_id_edit")

        self.source_form.setWidget(1, QFormLayout.ItemRole.FieldRole, self.source_id_edit)

        self.mesh_path_label = QLabel(self.content_page)
        self.mesh_path_label.setObjectName(u"mesh_path_label")
        self.mesh_path_label.setWordWrap(True)
        self.mesh_path_label.setTextFormat(Qt.PlainText)

        self.source_form.setWidget(2, QFormLayout.ItemRole.LabelRole, self.mesh_path_label)

        self.mesh_path_layout = QHBoxLayout()
        self.mesh_path_layout.setObjectName(u"mesh_path_layout")
        self.mesh_path_edit = QLineEdit(self.content_page)
        self.mesh_path_edit.setObjectName(u"mesh_path_edit")

        self.mesh_path_layout.addWidget(self.mesh_path_edit)

        self.browse_button = QPushButton(self.content_page)
        self.browse_button.setObjectName(u"browse_button")

        self.mesh_path_layout.addWidget(self.browse_button)

        self.mesh_path_layout.setStretch(0, 1)

        self.source_form.setLayout(2, QFormLayout.ItemRole.FieldRole, self.mesh_path_layout)

        self.group_label = QLabel(self.content_page)
        self.group_label.setObjectName(u"group_label")
        self.group_label.setWordWrap(True)
        self.group_label.setTextFormat(Qt.PlainText)

        self.source_form.setWidget(3, QFormLayout.ItemRole.LabelRole, self.group_label)

        self.group_selector = MeshGroupSelector(self.content_page)
        self.group_selector.setObjectName(u"group_selector")

        self.source_form.setWidget(3, QFormLayout.ItemRole.FieldRole, self.group_selector)

        self.fingerprint_label = QLabel(self.content_page)
        self.fingerprint_label.setObjectName(u"fingerprint_label")
        self.fingerprint_label.setWordWrap(True)
        self.fingerprint_label.setTextFormat(Qt.PlainText)

        self.source_form.setWidget(4, QFormLayout.ItemRole.LabelRole, self.fingerprint_label)

        self.fingerprint_widget = MeshFingerprintWidget(self.content_page)
        self.fingerprint_widget.setObjectName(u"fingerprint_widget")

        self.source_form.setWidget(4, QFormLayout.ItemRole.FieldRole, self.fingerprint_widget)


        self.content_layout.addLayout(self.source_form)

        self.transform = MeshPlacementWidget(self.content_page)
        self.transform.setObjectName(u"transform")

        self.content_layout.addWidget(self.transform)

        self.bounds_group = QGroupBox(self.content_page)
        self.bounds_group.setObjectName(u"bounds_group")
        self.bounds_layout = QVBoxLayout(self.bounds_group)
        self.bounds_layout.setObjectName(u"bounds_layout")
        self.bounds_help_label = QLabel(self.bounds_group)
        self.bounds_help_label.setObjectName(u"bounds_help_label")
        self.bounds_help_label.setWordWrap(True)
        self.bounds_help_label.setTextFormat(Qt.PlainText)

        self.bounds_layout.addWidget(self.bounds_help_label)

        self.bounds_label = QLabel(self.bounds_group)
        self.bounds_label.setObjectName(u"bounds_label")
        self.bounds_label.setWordWrap(True)
        self.bounds_label.setTextFormat(Qt.PlainText)
        self.bounds_label.setTextInteractionFlags(Qt.TextSelectableByMouse|Qt.TextSelectableByKeyboard)

        self.bounds_layout.addWidget(self.bounds_label)


        self.content_layout.addWidget(self.bounds_group)

        self.error_label = QLabel(self.content_page)
        self.error_label.setObjectName(u"error_label")
        self.error_label.setWordWrap(True)
        self.error_label.setTextFormat(Qt.PlainText)

        self.content_layout.addWidget(self.error_label)

        self.content_scroll.setWidget(self.content_page)

        self.root_layout.addWidget(self.content_scroll)

        self.buttons = QDialogButtonBox(FrozenMeshInstanceForm)
        self.buttons.setObjectName(u"buttons")
        self.buttons.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.root_layout.addWidget(self.buttons)

        self.root_layout.setStretch(0, 1)

        self.retranslateUi(FrozenMeshInstanceForm)

        QMetaObject.connectSlotsByName(FrozenMeshInstanceForm)
    # setupUi

    def retranslateUi(self, FrozenMeshInstanceForm):
        FrozenMeshInstanceForm.setWindowTitle(QCoreApplication.translate("FrozenMeshInstanceForm", u"\u6dfb\u52a0\u7f51\u683c\u5b9e\u4f8b", None))
        FrozenMeshInstanceForm.setProperty(u"editTitle", QCoreApplication.translate("FrozenMeshInstanceForm", u"\u7f16\u8f91\u7f51\u683c\u5b9e\u4f8b", None))
        self.help_label.setText(QCoreApplication.translate("FrozenMeshInstanceForm", u"\u9009\u62e9 .msh \u7f51\u683c\u6587\u4ef6\uff1b\u6587\u4ef6\u8def\u5f84\u76f8\u5bf9\u4e8e Source \u76ee\u5f55\u3002\u4f4d\u7f6e\u3001\u65cb\u8f6c\u548c\u955c\u50cf\u8868\u793a\u6b64\u5b9e\u4f8b\u7684\u5f53\u524d\u6446\u653e\uff0c\u4fdd\u5b58\u65f6\u6574\u4f53\u66ff\u6362\u3002", None))
        self.reuse_label.setText(QCoreApplication.translate("FrozenMeshInstanceForm", u"\u7f51\u683c\u6765\u6e90", None))
        self.reuse_combo.setItemText(0, QCoreApplication.translate("FrozenMeshInstanceForm", u"\u9009\u62e9\u7f51\u683c\u6587\u4ef6", None))

        self.source_id_label.setText(QCoreApplication.translate("FrozenMeshInstanceForm", u"\u5b9e\u4f8b\u540d\u79f0", None))
        self.source_id_edit.setProperty(u"variableNameToolTip", QCoreApplication.translate("FrozenMeshInstanceForm", u"\u53d8\u91cf\u540d\u53ea\u80fd\u5305\u542b\u82f1\u6587\u5b57\u6bcd\u3001\u6570\u5b57\u548c\u4e0b\u5212\u7ebf\uff0c\u4e0d\u80fd\u542b\u7a7a\u683c\uff0c\u4e14\u4e0d\u80fd\u4ee5\u6570\u5b57\u5f00\u5934\u3002", None))
        self.mesh_path_label.setText(QCoreApplication.translate("FrozenMeshInstanceForm", u"\u7f51\u683c (.msh)", None))
        self.mesh_path_edit.setPlaceholderText(QCoreApplication.translate("FrozenMeshInstanceForm", u"\u76f8\u5bf9\u4e8e Source \u76ee\u5f55\u7684\u6587\u4ef6\u8def\u5f84", None))
        self.browse_button.setText(QCoreApplication.translate("FrozenMeshInstanceForm", u"\u6d4f\u89c8", None))
        self.group_label.setText(QCoreApplication.translate("FrozenMeshInstanceForm", u"\u7f51\u683c\u5185\u4f53\u5206\u7ec4", None))
        self.fingerprint_label.setText(QCoreApplication.translate("FrozenMeshInstanceForm", u"\u6587\u4ef6\u68c0\u67e5", None))
        self.bounds_group.setTitle(QCoreApplication.translate("FrozenMeshInstanceForm", u"\u5f53\u524d\u7f51\u683c\u5750\u6807\u8303\u56f4 (mm)", None))
        self.bounds_help_label.setText(QCoreApplication.translate("FrozenMeshInstanceForm", u"\u6240\u9009\u4f53\u5206\u7ec4\u5728\u5f53\u524d\u6446\u653e\u4e0b\u7684\u8f74\u5bf9\u9f50\u5305\u56f4\u76d2\uff1b\u6bcf\u8f74\u663e\u793a [\u6700\u5c0f\u503c, \u6700\u5927\u503c]\u3002", None))
        self.bounds_label.setText(QCoreApplication.translate("FrozenMeshInstanceForm", u"\u8bf7\u5148\u9009\u62e9\u7f51\u683c\u6587\u4ef6\u3002", None))
        self.error_label.setText("")
        self.buttons.setProperty(u"acceptText", QCoreApplication.translate("FrozenMeshInstanceForm", u"\u6dfb\u52a0\u5b9e\u4f8b", None))
        self.buttons.setProperty(u"cancelText", QCoreApplication.translate("FrozenMeshInstanceForm", u"\u53d6\u6d88", None))
        self.buttons.setProperty(u"editText", QCoreApplication.translate("FrozenMeshInstanceForm", u"\u4fdd\u5b58\u4fee\u6539", None))
    # retranslateUi
