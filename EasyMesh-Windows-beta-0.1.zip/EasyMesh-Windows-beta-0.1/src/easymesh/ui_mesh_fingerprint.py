# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mesh_fingerprint.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QLabel, QPushButton,
    QSizePolicy, QWidget)

class Ui_MeshFingerprintForm(object):
    def setupUi(self, MeshFingerprintForm):
        if not MeshFingerprintForm.objectName():
            MeshFingerprintForm.setObjectName(u"MeshFingerprintForm")
        self.root_layout = QHBoxLayout(MeshFingerprintForm)
        self.root_layout.setObjectName(u"root_layout")
        self.root_layout.setContentsMargins(0, 0, 0, 0)
        self.status = QLabel(MeshFingerprintForm)
        self.status.setObjectName(u"status")
        self.status.setWordWrap(True)
        self.status.setTextFormat(Qt.PlainText)

        self.root_layout.addWidget(self.status)

        self.update_button = QPushButton(MeshFingerprintForm)
        self.update_button.setObjectName(u"update_button")

        self.root_layout.addWidget(self.update_button)

        self.root_layout.setStretch(0, 1)

        self.retranslateUi(MeshFingerprintForm)

        QMetaObject.connectSlotsByName(MeshFingerprintForm)
    # setupUi

    def retranslateUi(self, MeshFingerprintForm):
        self.status.setText(QCoreApplication.translate("MeshFingerprintForm", u"\u8bf7\u5148\u9009\u62e9\u7f51\u683c\u6587\u4ef6\u3002", None))
        self.update_button.setText(QCoreApplication.translate("MeshFingerprintForm", u"\u66f4\u65b0\u7f51\u683c\u5f15\u7528", None))
#if QT_CONFIG(tooltip)
        self.update_button.setToolTip(QCoreApplication.translate("MeshFingerprintForm", u"\u786e\u8ba4\u4f7f\u7528\u6587\u4ef6\u5f53\u524d\u5185\u5bb9\uff0c\u91cd\u65b0\u8ba1\u7b97\u5e76\u8bb0\u5f55\u7f51\u683c\u6307\u7eb9\uff1b\u4fdd\u5b58\u5b9e\u4f8b\u540e\u751f\u6548\u3002", None))
#endif // QT_CONFIG(tooltip)
        pass
    # retranslateUi
