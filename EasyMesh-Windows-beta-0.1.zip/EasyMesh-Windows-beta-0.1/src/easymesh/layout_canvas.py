"""Batched, level-of-detail XY preview for large connection layouts.

Instances are numeric arrays, not QGraphicsItems or child widgets.  A template's
actual top-face edges are cached once and reused after translation/rotation.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import math
from typing import Mapping, Sequence

import numpy as np
from PySide6.QtCore import QPointF, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen, QPolygonF, QTransform
from PySide6.QtWidgets import QWidget

from .bump_layout import StructuredHexRegion
from .sample_mesh import SampleMesh


@dataclass(slots=True)
class _TemplateDrawing:
    outline: QPainterPath
    edges: QPainterPath
    radius: float
    edge_count: int


def _template_drawing(mesh: SampleMesh) -> _TemplateDrawing:
    """Project the upper surface of the original volume mesh, in local µm."""
    center_x, center_y = mesh.outer_boundary.center_xy
    nodes = mesh.node_map()
    z_top = max(node.z for node in mesh.nodes)
    tolerance = max(1.e-10, abs(z_top) * 1.e-9)
    edges: Counter[tuple[int, int]] = Counter()
    for face in mesh.boundary_faces:
        if not all(abs(nodes[tag].z - z_top) <= tolerance for tag in face.node_tags):
            continue
        for left, right in zip(face.node_tags, face.node_tags[1:] + face.node_tags[:1]):
            edges[tuple(sorted((left, right)))] += 1
    path = QPainterPath()
    for left, right in edges:
        a, b = nodes[left], nodes[right]
        path.moveTo((a.x - center_x) * 1000., (a.y - center_y) * 1000.)
        path.lineTo((b.x - center_x) * 1000., (b.y - center_y) * 1000.)
    outline = QPainterPath()
    boundary = mesh.outer_boundary
    if boundary.contour_dimensions_mm is not None:
        width, height = (value * 1000. for value in boundary.contour_dimensions_mm)
        outline.addRoundedRect(QRectF(-width / 2., -height / 2., width, height),
                               height / 2., height / 2.)
    else:
        radius = boundary.radius * 1000.
        outline.addEllipse(QPointF(), radius, radius)
    radius = max(math.hypot(node.x - center_x, node.y - center_y)
                 for node in mesh.nodes) * 1000.
    return _TemplateDrawing(outline, path, max(radius, .001), len(edges))


class LayoutCanvas(QWidget):
    """Select and inspect bump placements, with coordinates measured in µm.

    ``set_instances`` accepts rows exposing ``x_um``, ``y_um``, ``template_key``
    and optionally ``rotation_deg``.  Selections contain zero-based row indices.
    """

    selectionChanged = Signal(object)
    regionDrawModeChanged = Signal(bool)
    regionDrawn = Signal(object)
    cursorPositionChanged = Signal(object)
    _COLORS = ("#2786bd", "#22a699", "#a16cce", "#db8952", "#668fbd", "#c66b99")

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(300, 260)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMouseTracking(True)
        self.setAccessibleName("连接布局 XY 视图")
        self.setToolTip("左键点选或框选；Ctrl + 左键追加；Ctrl + 右键取消选中。\n"
                        "滚轮缩放；中键或右键拖动平移；双击显示全部。放大后显示模板顶面网格。")
        self._positions = np.empty((0, 2), dtype=float)
        self._rotations = np.empty(0, dtype=float)
        self._keys: list[str] = []
        self._groups: dict[str, np.ndarray] = {}
        self._group_points: dict[str, QPolygonF] = {}
        self._templates: dict[str, _TemplateDrawing] = {}
        self._source_templates: dict[str, SampleMesh] = {}
        self._template_colors: dict[str, QColor] = {}
        self._selection: set[int] = set()
        self._selected_mask = np.zeros(0, dtype=bool)
        self._selected_groups: dict[str, np.ndarray] = {}
        self._selected_points: dict[str, QPolygonF] = {}
        self._radii = np.empty(0, dtype=float)
        self._mesh_region_rects: tuple[QRectF | None, ...] = ()
        self._region_selection: set[int] = set()
        self._bounds: tuple[float, float, float, float] | None = None
        self._center = QPointF()
        self._scale = 1.
        self._fit_mode = True
        self._drag_start: QPointF | None = None
        self._drag_current: QPointF | None = None
        self._drag_mode: str | None = None
        self._drag_button: Qt.MouseButton | None = None
        self._drag_world_start: QPointF | None = None
        self._region_draw_mode = False
        self._cursor_screen_position: QPointF | None = None
        self._cursor_position: QPointF | None = None
        self._pan_center = QPointF()
        self._last_render_stats = {"visible": 0, "dots": 0, "outlines": 0, "meshes": 0, "regions": 0}

    def sizeHint(self):
        return QSize(640, 580)

    @property
    def selection(self) -> set[int]:
        return set(self._selection)

    @property
    def region_selection(self) -> set[int]:
        return set(self._region_selection)

    @property
    def region_draw_mode(self) -> bool:
        return self._region_draw_mode

    @property
    def cursor_position(self) -> QPointF | None:
        """Current pointer coordinates in µm, or None outside the preview."""
        return QPointF(self._cursor_position) if self._cursor_position is not None else None

    @property
    def render_stats(self) -> dict[str, int]:
        """Numbers drawn in the latest paint (also useful for diagnostics)."""
        return dict(self._last_render_stats)

    def template_edge_count(self, key: str) -> int:
        drawing = self._templates.get(key)
        return drawing.edge_count if drawing is not None else 0

    def template_color(self, key: str) -> QColor:
        """A stable color for this template, shared with an external legend."""
        if key not in self._template_colors:
            self._template_colors[key] = QColor(self._COLORS[len(self._template_colors) % len(self._COLORS)])
        return QColor(self._template_colors[key])

    @staticmethod
    def _polygon(points: np.ndarray) -> QPolygonF:
        return QPolygonF([QPointF(float(x), float(y)) for x, y in points])

    def set_instances(self, rows: Sequence):
        self._positions = np.array([(row.x_um, row.y_um) for row in rows], dtype=float).reshape(-1, 2)
        self._rotations = np.array([getattr(row, "rotation_deg", 0.) % 360. for row in rows], dtype=float)
        self._keys = [row.template_key for row in rows]
        grouped: dict[str, list[int]] = {}
        for index, key in enumerate(self._keys):
            grouped.setdefault(key, []).append(index)
        self._groups = {key: np.array(indices, dtype=np.intp) for key, indices in grouped.items()}
        self._group_points = {key: self._polygon(self._positions[indices])
                              for key, indices in self._groups.items()}
        self._update_radii()
        self.set_selection(self._selection)
        if self._fit_mode:
            self.fit_all()
        else:
            self.update()

    def set_templates(self, templates: Mapping[str, SampleMesh]):
        for key in templates:
            self.template_color(key)
        self._templates = {
            key: self._templates[key] if self._source_templates.get(key) is mesh
            else _template_drawing(mesh)
            for key, mesh in templates.items()
        }
        self._source_templates = dict(templates)
        self._update_radii()
        if self._fit_mode:
            self.fit_all()
        else:
            self.update()

    def set_mesh_regions(self, regions: Sequence[StructuredHexRegion | None]):
        """Preview mm rectangles in µm, preserving row numbers for invalid rows.

        ``None`` skips a row whose edit is incomplete without renumbering the
        remaining regions or changing the table's selection indices.
        """
        self._mesh_region_rects = tuple(
            QRectF(region.x_min_mm * 1000., region.y_min_mm * 1000.,
                   region.width_mm * 1000., region.height_mm * 1000.)
            if region is not None else None
            for region in regions
        )
        self.set_region_selection(self._region_selection)
        if self._fit_mode:
            self.fit_all()
        else:
            self.update()

    def set_region_selection(self, indices: set[int]):
        """Highlight zero-based region rows independently of bump selection."""
        self._region_selection = {
            int(index) for index in indices if 0 <= index < len(self._mesh_region_rects)
        }
        self.update()

    def set_region_draw_mode(self, enabled: bool):
        """Use the next left-button rectangle to draw a mesh refinement region."""
        enabled = bool(enabled)
        if enabled == self._region_draw_mode:
            return
        self._region_draw_mode = enabled
        self._clear_drag()
        if enabled:
            self.setFocus()
        self.regionDrawModeChanged.emit(enabled)

    def _clear_drag(self):
        self._drag_mode = self._drag_button = None
        self._drag_start = self._drag_current = self._drag_world_start = None
        self._pan_center = QPointF()
        if self._region_draw_mode:
            self.setCursor(Qt.CursorShape.CrossCursor)
        else:
            self.unsetCursor()
        self.update()

    def _track_cursor(self, point: QPointF | None):
        self._cursor_screen_position = (
            QPointF(point) if point is not None and QRectF(self.rect()).contains(point) else None
        )
        self._refresh_cursor_position()

    def _refresh_cursor_position(self):
        point = self._cursor_screen_position
        position = (self.screen_to_world(point)
                    if point is not None and QRectF(self.rect()).contains(point) else None)
        if position != self._cursor_position:
            self._cursor_position = position
            self.cursorPositionChanged.emit(self.cursor_position)
            self.update()

    def _update_radii(self):
        self._radii = np.full(len(self._keys), 5., dtype=float)
        for key, indices in self._groups.items():
            if key in self._templates:
                self._radii[indices] = self._templates[key].radius

    def set_selection(self, indices: set[int]):
        """Update highlighting without emitting or rebuilding instance geometry."""
        self._selection = {int(index) for index in indices if 0 <= index < len(self._positions)}
        self._selected_mask = np.zeros(len(self._positions), dtype=bool)
        if self._selection:
            self._selected_mask[list(self._selection)] = True
        self._selected_groups = {key: indices[self._selected_mask[indices]]
                                 for key, indices in self._groups.items()}
        self._selected_points = {key: self._polygon(self._positions[indices])
                                 for key, indices in self._selected_groups.items() if len(indices)}
        self.update()

    def set_bounds(self, bounds: tuple[float, float, float, float]):
        self._bounds = tuple(float(value) for value in bounds)
        if self._fit_mode:
            self.fit_all()
        else:
            self.update()

    def fit_all(self):
        self._fit_mode = True
        limits = []
        if self._bounds is not None:
            x_min, x_max, y_min, y_max = self._bounds
            if x_max > x_min and y_max > y_min:
                limits.append(self._bounds)
        if len(self._positions):
            low = np.min(self._positions - self._radii[:, None], axis=0)
            high = np.max(self._positions + self._radii[:, None], axis=0)
            limits.append((low[0], high[0], low[1], high[1]))
        limits.extend((rect.left(), rect.right(), rect.top(), rect.bottom())
                      for rect in self._mesh_region_rects if rect is not None)
        if not limits:
            limits = [(-100., 100., -100., 100.)]
        x_min, x_max = min(box[0] for box in limits), max(box[1] for box in limits)
        y_min, y_max = min(box[2] for box in limits), max(box[3] for box in limits)
        self._center = QPointF((x_min + x_max) / 2., (y_min + y_max) / 2.)
        self._scale = min(max(self.width() - 64., 1.) / max(x_max - x_min, .001),
                          max(self.height() - 76., 1.) / max(y_max - y_min, .001))
        self._refresh_cursor_position()
        self.update()

    def world_to_screen(self, x_um: float, y_um: float) -> QPointF:
        return QPointF(self.width() / 2. + (x_um - self._center.x()) * self._scale,
                       self.height() / 2. - (y_um - self._center.y()) * self._scale)

    def screen_to_world(self, point: QPointF) -> QPointF:
        return QPointF(self._center.x() + (point.x() - self.width() / 2.) / self._scale,
                       self._center.y() - (point.y() - self.height() / 2.) / self._scale)

    def _world_transform(self) -> QTransform:
        transform = QTransform()
        transform.translate(self.width() / 2., self.height() / 2.)
        transform.scale(self._scale, -self._scale)
        transform.translate(-self._center.x(), -self._center.y())
        return transform

    def _visible_mask(self) -> np.ndarray:
        low = self.screen_to_world(QPointF(-8., self.height() + 8.))
        high = self.screen_to_world(QPointF(self.width() + 8., -8.))
        x, y = self._positions.T
        return ((x + self._radii >= low.x()) & (x - self._radii <= high.x()) &
                (y + self._radii >= low.y()) & (y - self._radii <= high.y()))

    @staticmethod
    def _pen(color, width=1.):
        pen = QPen(QColor(color), width)
        pen.setCosmetic(True)
        return pen

    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), self.palette().base())
        foreground = self.palette().text().color()
        world = self._world_transform()
        painter.setTransform(world)
        if self._bounds is not None:
            x_min, x_max, y_min, y_max = self._bounds
            pen = self._pen(self.palette().mid().color())
            pen.setStyle(Qt.PenStyle.DashLine)
            painter.setPen(pen)
            painter.drawRect(QRectF(x_min, y_min, x_max - x_min, y_max - y_min))
        region_labels = []
        viewport = QRectF(self.rect())
        for index, rect in enumerate(self._mesh_region_rects):
            if rect is None:
                continue
            screen_rect = world.mapRect(rect)
            if not viewport.intersects(screen_rect):
                continue
            selected = index in self._region_selection
            color = QColor("#24985b")
            fill = QColor(color)
            fill.setAlpha(48 if selected else 20)
            painter.setBrush(fill)
            painter.setPen(self._pen(color, 2.8 if selected else 1.3))
            painter.drawRect(rect)
            region_labels.append((index, screen_rect.intersected(viewport).topLeft()))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        visible = self._visible_mask()
        stats = {"visible": int(visible.sum()), "dots": 0, "outlines": 0, "meshes": 0,
                 "regions": len(region_labels)}
        for key, group in self._groups.items():
            indices = group[visible[group]]
            if not len(indices):
                continue
            drawing = self._templates.get(key)
            radius_px = (drawing.radius if drawing else 5.) * self._scale
            color = self.template_color(key)
            # Thousands of paths are unnecessary at overview scale.  A single
            # drawPoints call per template keeps navigation independent of N.
            if radius_px < 7. or drawing is None or stats["visible"] > 2500:
                selected = indices[self._selected_mask[indices]]
                if len(selected) != len(indices):
                    points = self._group_points[key] if len(indices) == len(group) else self._polygon(self._positions[indices])
                    pen = self._pen(color, max(2., min(7., radius_px * 1.3)))
                    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
                    painter.setPen(pen)
                    painter.drawPoints(points)
                if len(selected):
                    highlight = self._pen("#f5b429", max(4., min(9., radius_px * 1.3 + 2.)))
                    highlight.setCapStyle(Qt.PenCapStyle.RoundCap)
                    painter.setPen(highlight)
                    points = (self._selected_points[key] if len(selected) == len(self._selected_groups[key])
                              else self._polygon(self._positions[selected]))
                    painter.drawPoints(points)
                stats["dots"] += len(indices)
                continue
            show_mesh = radius_px >= 35. and drawing.edge_count > 0
            # Mesh detail is only meaningful when it fits on screen. Bound the
            # edge work for pathological overlapping layouts as well.
            show_mesh = show_mesh and drawing.edge_count * stats["visible"] <= 300_000
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            for index in indices:
                transform = QTransform(world)
                x, y = self._positions[index]
                transform.translate(float(x), float(y))
                transform.rotate(float(self._rotations[index]))
                painter.setTransform(transform)
                selected = bool(self._selected_mask[index])
                fill = QColor("#f5b429") if selected else QColor(color)
                fill.setAlpha(60 if selected else 24)
                painter.setBrush(fill)
                painter.setPen(self._pen("#f5b429" if selected else color, 2.2 if selected else 1.2))
                painter.drawPath(drawing.outline)
                if show_mesh:
                    painter.setBrush(Qt.BrushStyle.NoBrush)
                    painter.setPen(self._pen(color, .8))
                    painter.drawPath(drawing.edges)
                    stats["meshes"] += 1
                stats["outlines"] += 1
            painter.setTransform(world)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        painter.resetTransform()
        painter.setPen(QColor("#24985b"))
        for index, corner in region_labels:
            painter.drawText(corner + QPointF(5., 16.), f"区 {index + 1}")
        if self._drag_mode in {"replace", "add", "subtract"} and self._drag_start is not None:
            painter.setPen(self._pen("#f5b429", 1.))
            painter.setBrush(QColor(245, 180, 41, 35))
            painter.drawRect(QRectF(self._drag_start, self._drag_current).normalized())
        elif self._drag_mode == "region" and self._drag_world_start is not None:
            start = self.world_to_screen(self._drag_world_start.x(), self._drag_world_start.y())
            painter.setPen(self._pen("#24985b", 1.5))
            painter.setBrush(QColor(36, 152, 91, 35))
            painter.drawRect(QRectF(start, self._drag_current).normalized())
        painter.setPen(foreground)
        region_count = sum(rect is not None for rect in self._mesh_region_rects)
        if not len(self._positions) and not region_count:
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "导入坐标或添加 bump 后显示布局")
        else:
            detail = (" · 顶面网格" if stats["meshes"] else " · 放大查看顶面网格") if len(self._positions) else ""
            regions = f" · {region_count} 个局部加密区" if region_count else ""
            painter.drawText(12, 21, f"{len(self._positions):,} bumps · 已选 {len(self._selection):,}{detail}{regions}")
            # A labelled scale makes imported coordinate units unambiguous.
            span = 95. / self._scale
            magnitude = 10. ** math.floor(math.log10(max(span, 1.e-12)))
            length = max(1., math.floor(span / magnitude)) * magnitude
            pixels = length * self._scale
            bottom = self.height() - 15
            painter.drawLine(QPointF(12., bottom), QPointF(12. + pixels, bottom))
            painter.drawText(QPointF(12., bottom - 6.), f"{length:.6g} µm")
        if self._cursor_position is not None:
            point = self._cursor_position
            label = f"X: {point.x():.6g} µm   Y: {point.y():.6g} µm"
            text_rect = painter.fontMetrics().boundingRect(label)
            box = QRectF(self.width() - text_rect.width() - 20.,
                         self.height() - text_rect.height() - 16.,
                         text_rect.width() + 12., text_rect.height() + 8.)
            if box.left() < 125.:
                box.moveBottom(self.height() - 42.)
            painter.fillRect(box, self.palette().base())
            painter.setPen(foreground)
            painter.drawText(box, Qt.AlignmentFlag.AlignCenter, label)
        self._last_render_stats = stats
        painter.end()

    def _hit(self, point: QPointF) -> set[int]:
        if not len(self._positions):
            return set()
        location = self.screen_to_world(point)
        delta = self._positions - (location.x(), location.y())
        distances = np.einsum("ij,ij->i", delta, delta)
        candidates = np.flatnonzero(distances <= np.maximum(self._radii, 6. / self._scale) ** 2)
        for index in candidates[np.argsort(distances[candidates])]:
            drawing = self._templates.get(self._keys[index])
            if drawing is None or self._radii[index] * self._scale < 7.:
                return {int(index)}
            angle = math.radians(float(self._rotations[index]))
            dx, dy = -delta[index]
            local = QPointF(dx * math.cos(angle) + dy * math.sin(angle),
                            -dx * math.sin(angle) + dy * math.cos(angle))
            if drawing.outline.contains(local):
                return {int(index)}
        return set()

    def _select_drag(self, start: QPointF, end: QPointF, mode: str):
        if (end - start).manhattanLength() < 5.:
            selected = self._hit(end)
        else:
            a, b = self.screen_to_world(start), self.screen_to_world(end)
            x, y = self._positions.T
            selected = set(np.flatnonzero((x >= min(a.x(), b.x())) & (x <= max(a.x(), b.x())) &
                                         (y >= min(a.y(), b.y())) & (y <= max(a.y(), b.y()))).tolist())
        if mode == "add":
            selected |= self._selection
        elif mode == "subtract":
            selected = self._selection - selected
        if selected != self._selection:
            self.set_selection(selected)
            self.selectionChanged.emit(set(selected))

    def mousePressEvent(self, event):
        self._track_cursor(event.position())
        if self._drag_mode is not None:
            event.accept()
            return
        modified = bool(event.modifiers() & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
        button = event.button()
        if button == Qt.MouseButton.LeftButton:
            mode = "region" if self._region_draw_mode else "add" if modified else "replace"
        elif button == Qt.MouseButton.RightButton and modified and not self._region_draw_mode:
            mode = "subtract"
        elif button in (Qt.MouseButton.RightButton, Qt.MouseButton.MiddleButton):
            mode = "pan"
        else:
            super().mousePressEvent(event)
            return
        self.setFocus()
        self._drag_mode = mode
        self._drag_button = button
        self._drag_start = QPointF(event.position())
        self._drag_current = QPointF(event.position())
        self._drag_world_start = self.screen_to_world(event.position()) if mode == "region" else None
        self._pan_center = QPointF(self._center)
        if mode == "pan":
            self._fit_mode = False
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
        event.accept()

    def mouseMoveEvent(self, event):
        if self._drag_mode is None:
            self._track_cursor(event.position())
            super().mouseMoveEvent(event)
            return
        self._drag_current = QPointF(event.position())
        if self._drag_mode == "pan":
            delta = self._drag_current - self._drag_start
            self._center = self._pan_center + QPointF(-delta.x() / self._scale, delta.y() / self._scale)
        self._track_cursor(event.position())
        self.update()
        event.accept()

    def mouseReleaseEvent(self, event):
        self._track_cursor(event.position())
        if self._drag_mode is None or event.button() != self._drag_button:
            super().mouseReleaseEvent(event)
            return
        mode, start = self._drag_mode, self._drag_start
        end = QPointF(event.position())
        region = None
        if mode == "region":
            a = self._drag_world_start
            screen_start = self.world_to_screen(a.x(), a.y())
            # A click or a line is not a usable rectangle. Keep the tool active
            # so the user can retry without changing the existing selection.
            if abs(end.x() - screen_start.x()) >= 3. and abs(end.y() - screen_start.y()) >= 3.:
                b = self.screen_to_world(end)
                region = (min(a.x(), b.x()), max(a.x(), b.x()),
                          min(a.y(), b.y()), max(a.y(), b.y()))
        elif mode == "pan":
            delta = end - start
            self._center = self._pan_center + QPointF(-delta.x() / self._scale, delta.y() / self._scale)
            self._refresh_cursor_position()
        # Slots may change the layout, fit the view, or start another operation.
        # Finish this interaction completely before calling any of them.
        self._clear_drag()
        if region is not None:
            self.set_region_draw_mode(False)
            self.regionDrawn.emit(region)
        elif mode in {"replace", "add", "subtract"}:
            self._select_drag(start, end, mode)
        event.accept()

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._clear_drag()
            if not self._region_draw_mode:
                self.fit_all()
            event.accept()
        else:
            super().mouseDoubleClickEvent(event)

    def wheelEvent(self, event):
        self._track_cursor(event.position())
        if self._drag_mode == "region":
            event.accept()
            return
        amount = event.angleDelta().y() or event.pixelDelta().y()
        if not amount:
            return
        before = self.screen_to_world(event.position())
        self._scale = min(1.e6, max(1.e-9, self._scale * (1.2 ** (amount / 120.))))
        after = self.screen_to_world(event.position())
        self._center += before - after
        self._fit_mode = False
        self._refresh_cursor_position()
        self.update()
        event.accept()

    def resizeEvent(self, event):
        if self._fit_mode:
            self.fit_all()
        else:
            self._refresh_cursor_position()
        super().resizeEvent(event)

    def enterEvent(self, event):
        self._track_cursor(event.position())
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._track_cursor(None)
        super().leaveEvent(event)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self._clear_drag()
            self.set_region_draw_mode(False)
            event.accept()
        elif event.key() == Qt.Key.Key_F:
            self.fit_all()
            event.accept()
        else:
            super().keyPressEvent(event)
