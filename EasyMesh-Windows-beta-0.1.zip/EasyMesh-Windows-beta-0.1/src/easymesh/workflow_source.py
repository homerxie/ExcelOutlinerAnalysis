"""Recover editable Package Source snapshots without changing external files."""

from __future__ import annotations

from collections.abc import Mapping
import json
from pathlib import Path
import shutil
import tempfile

from .output_artifacts import atomic_write_text, sha256_file
from .package_v2_compile import compile_package_v2
from .package_v2_source import MAX_SOURCE_BYTES
from .package_v2_source_editor import (
    PackageV2SourceEditor,
    open_package_v2_source_editor,
)
from .workflow_handoff import prepare_package_frozen_source


def _check_mesh(path: Path, expected: str | None) -> None:
    if not path.is_file():
        raise ValueError(f"无法恢复 Package Source，所引用网格已不存在：{path}")
    if expected is not None and sha256_file(path) != expected:
        raise ValueError(f"无法恢复 Package Source，网格内容与工程快照不一致：{path}")


def restore_source_snapshot(
    snapshot: object,
    managed_root: str | Path,
) -> PackageV2SourceEditor:
    """Reopen matching Source bytes or restore a private, editable copy.

    A matching original keeps its exact path and raw bytes, preserving its Job
    identity.  Otherwise only Frozen artifact references are relocated; source
    placement, component selections and all other authoring fields survive.
    Failure never modifies an original Source and leaves no partial private
    Source; callers can retain the embedded text as a recoverable draft.
    """

    if not isinstance(snapshot, Mapping):
        raise ValueError("Package Source 快照必须是对象。")
    raw_path, text = snapshot.get("path"), snapshot.get("text")
    if not isinstance(raw_path, str) or not isinstance(text, str):
        raise ValueError("Package Source 快照路径和内容必须为文本。")
    raw = text.encode("utf-8")
    if len(raw) > MAX_SOURCE_BYTES:
        raise ValueError("Package Source 快照超过大小限制。")
    root = Path(managed_root).expanduser().resolve()
    original = Path(raw_path).expanduser().resolve() if raw_path else None
    source_root = original.parent if original is not None else root
    compiled = compile_package_v2(
        raw,
        source_name=original.name if original is not None else "package.source.json",
        source_root=source_root,
    )
    # Compile validates relative declarations before any path is accessed.  A
    # saved fingerprint must never be silently replaced with a newer mesh hash.
    for frozen in compiled.frozen_sources:
        _check_mesh(frozen.artifacts.mesh_runtime_path, frozen.artifacts.sha256)

    if original is not None:
        try:
            matches = original.is_file() and original.stat().st_size == len(raw)
            if matches and original.read_bytes() == raw:
                editor = open_package_v2_source_editor(original)
                if editor.raw_bytes == raw:
                    return editor
        except (OSError, ValueError):
            # A changed, missing, renamed or unreadable external Source must
            # not stop recovery of the project-owned snapshot.
            pass

    root.mkdir(parents=True, exist_ok=True)
    private = Path(tempfile.mkdtemp(prefix="restored-source-", dir=root))
    target = private / "package.source.json"
    try:
        if compiled.frozen_sources:
            document = json.loads(text)
            by_id = {item.source_id: item for item in compiled.frozen_sources}
            for declaration in document["frozen_sources"]:
                frozen = by_id[declaration["id"]]
                prepared = prepare_package_frozen_source(
                    frozen.artifacts.mesh_runtime_path,
                    target,
                    source_id=frozen.source_id,
                    components=declaration["components"],
                )
                artifacts = prepared["artifacts"]
                expected = frozen.artifacts.sha256
                if expected is not None and artifacts["sha256"] != expected:
                    raise ValueError(
                        "恢复期间网格发生变化，请重试："
                        f"{frozen.artifacts.mesh_runtime_path}"
                    )
                declaration["artifacts"] = artifacts
            text = json.dumps(document, ensure_ascii=False, indent=2) + "\n"
        atomic_write_text(target, text)
        return open_package_v2_source_editor(target)
    except Exception:
        shutil.rmtree(private)
        raise
