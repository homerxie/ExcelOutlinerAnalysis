"""Load EasyMesh's solver-independent first-order Gmsh volume mesh.

This module contains only the information required by downstream exporters:
nodes, volume-element connectivity, and the complete (possibly overlapping)
set of three-dimensional Physical Groups attached to each element entity.
Template-specific skin and docking-boundary extraction intentionally lives in
``sample_mesh`` so large export jobs do not build millions of temporary faces.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from types import MappingProxyType
from typing import Any, Callable, Mapping

import numpy as np

from .gmsh_runtime import isolated_gmsh_model


class VolumeMeshError(ValueError):
    """Raised when an MSH file cannot be represented by the supported IR."""


class ElementKind(str, Enum):
    """Supported first-order volume element kinds."""

    TET4 = "TET4"
    HEX8 = "HEX8"
    WEDGE6 = "WEDGE6"
    PYRAMID5 = "PYRAMID5"


@dataclass(frozen=True, slots=True, order=True)
class PhysicalGroup:
    """A named three-dimensional Gmsh Physical Group."""

    tag: int
    name: str
    explicitly_named: bool = True


@dataclass(frozen=True, slots=True)
class MeshNode:
    """A mesh node in the coordinate system and units of the source MSH."""

    tag: int
    x: float
    y: float
    z: float

    @property
    def coordinates(self) -> tuple[float, float, float]:
        return (self.x, self.y, self.z)


@dataclass(frozen=True, slots=True)
class VolumeElement:
    """A volume element with entity and overlapping Physical-Group provenance."""

    tag: int
    kind: ElementKind
    gmsh_type: int
    node_tags: tuple[int, ...]
    entity_tag: int
    physical_groups: tuple[PhysicalGroup, ...]
    min_jacobian_determinant: float

    @property
    def physical_names(self) -> tuple[str, ...]:
        return tuple(group.name for group in self.physical_groups)


@dataclass(frozen=True, slots=True)
class VolumeMesh:
    """Immutable Gmsh MSH 4.1 volume mesh used by solver exporters."""

    source_path: Path
    nodes: tuple[MeshNode, ...]
    elements: tuple[VolumeElement, ...]
    entity_physical_groups: Mapping[int, tuple[PhysicalGroup, ...]]
    dimensional_element_counts: tuple[int, int, int, int]
    min_jacobian_determinant: float

    def node_map(self) -> dict[int, MeshNode]:
        return {node.tag: node for node in self.nodes}


@dataclass(frozen=True, slots=True)
class CompactElementBlock:
    """One entity/type block without a Python object for every volume cell."""

    entity_tag: int
    gmsh_type: int
    kind: ElementKind
    tags: np.ndarray
    connectivity: np.ndarray


@dataclass(frozen=True, slots=True)
class CompactVolumeMesh:
    """Read-only numeric mesh storage for very large solver exports.

    Node tags and the tags within each element block are increasing. Blocks
    retain their entity provenance; their tag ranges may overlap or interleave.
    The arrays own their storage independently of the Gmsh model lifetime.
    """

    source_path: Path
    node_tags: np.ndarray
    coordinates: np.ndarray
    element_blocks: tuple[CompactElementBlock, ...]
    entity_physical_groups: Mapping[int, tuple[PhysicalGroup, ...]]
    dimensional_element_counts: tuple[int, int, int, int]
    min_jacobian_determinant: float

    @property
    def node_count(self) -> int:
        return len(self.node_tags)

    @property
    def element_count(self) -> int:
        return sum(len(block.tags) for block in self.element_blocks)


_COMPACT_CHUNK_SIZE = 65_536
VolumeProgressCallback = Callable[[int | None, str], None]


# kind, node count, local boundary faces.  The face data is also reused by the
# sample-template loader, while exporters need only kind and node count.
ELEMENT_SPECS: Mapping[
    int,
    tuple[ElementKind, int, tuple[tuple[int, ...], ...]],
] = MappingProxyType(
    {
        # Gmsh first-order Tetrahedron 4.
        4: (
            ElementKind.TET4,
            4,
            (
                (0, 1, 2),
                (0, 1, 3),
                (1, 2, 3),
                (2, 0, 3),
            ),
        ),
        # Gmsh first-order Hexahedron 8.
        5: (
            ElementKind.HEX8,
            8,
            (
                (0, 1, 2, 3),
                (4, 5, 6, 7),
                (0, 1, 5, 4),
                (1, 2, 6, 5),
                (2, 3, 7, 6),
                (3, 0, 4, 7),
            ),
        ),
        # Gmsh first-order Prism 6 (WEDGE6).
        6: (
            ElementKind.WEDGE6,
            6,
            (
                (0, 1, 2),
                (3, 4, 5),
                (0, 1, 4, 3),
                (1, 2, 5, 4),
                (2, 0, 3, 5),
            ),
        ),
        # Gmsh first-order Pyramid 5: QUAD4 base followed by the apex.
        7: (
            ElementKind.PYRAMID5,
            5,
            (
                (0, 1, 2, 3),
                (0, 1, 4),
                (1, 2, 4),
                (2, 3, 4),
                (3, 0, 4),
            ),
        ),
    }
)


def _load_gmsh() -> Any:
    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as exc:  # pragma: no cover - dependency failure
        raise RuntimeError("Gmsh is required to read an MSH volume mesh") from exc
    return gmsh


def _validate_msh_41(path: Path) -> None:
    try:
        with path.open("rb") as stream:
            marker = stream.readline().strip()
            format_line = stream.readline().decode("ascii", errors="strict").split()
    except (OSError, UnicodeError) as exc:
        raise VolumeMeshError(f"无法读取 MSH 文件：{path}") from exc
    if marker != b"$MeshFormat" or not format_line or format_line[0] != "4.1":
        version = format_line[0] if format_line else "unknown"
        raise VolumeMeshError(
            f"当前体网格读取器要求 Gmsh MSH 4.1，实际版本为 {version}：{path}"
        )
    if len(format_line) < 3 or format_line[1] != "0" or format_line[2] != "8":
        raise VolumeMeshError(
            "当前体网格读取器要求 ASCII Gmsh MSH 4.1"
            "（file-type=0, data-size=8）："
            f"{path}"
        )


def _physical_groups_by_entity(
    gmsh: Any,
) -> Mapping[int, tuple[PhysicalGroup, ...]]:
    groups_by_entity: dict[int, list[PhysicalGroup]] = {
        int(entity_tag): [] for _, entity_tag in gmsh.model.getEntities(3)
    }
    for dimension, physical_tag_value in gmsh.model.getPhysicalGroups(3):
        if int(dimension) != 3:
            continue
        physical_tag = int(physical_tag_value)
        raw_name = str(gmsh.model.getPhysicalName(3, physical_tag))
        name = raw_name or f"PHYSICAL_3_{physical_tag}"
        group = PhysicalGroup(
            physical_tag,
            name,
            explicitly_named=bool(raw_name),
        )
        for entity_tag in gmsh.model.getEntitiesForPhysicalGroup(3, physical_tag):
            groups_by_entity.setdefault(int(entity_tag), []).append(group)
    return MappingProxyType(
        {
            entity_tag: tuple(sorted(groups))
            for entity_tag, groups in sorted(groups_by_entity.items())
        }
    )


def _read_nodes(gmsh: Any) -> tuple[MeshNode, ...]:
    node_tags, coordinates, _ = gmsh.model.mesh.getNodes()
    tags = tuple(int(tag) for tag in node_tags)
    if len(tags) != len(set(tags)):
        raise VolumeMeshError("MSH 包含重复的 node tag")
    flat_coordinates = tuple(float(value) for value in coordinates)
    if len(flat_coordinates) != 3 * len(tags):
        raise VolumeMeshError("Gmsh 返回的节点坐标长度不一致")
    nodes = tuple(
        MeshNode(
            tag=tag,
            x=flat_coordinates[3 * index],
            y=flat_coordinates[3 * index + 1],
            z=flat_coordinates[3 * index + 2],
        )
        for index, tag in enumerate(tags)
    )
    if any(
        not math.isfinite(value)
        for node in nodes
        for value in node.coordinates
    ):
        raise VolumeMeshError("MSH 包含非有限节点坐标")
    return tuple(sorted(nodes, key=lambda node: node.tag))


def _read_elements(
    gmsh: Any,
    physical_groups: Mapping[int, tuple[PhysicalGroup, ...]],
) -> tuple[VolumeElement, ...]:
    raw_elements: list[
        tuple[int, ElementKind, int, tuple[int, ...], int]
    ] = []
    unsupported: set[str] = set()
    for dimension, entity_tag_value in sorted(gmsh.model.getEntities(3)):
        if int(dimension) != 3:
            continue
        entity_tag = int(entity_tag_value)
        element_types, tag_blocks, connectivity_blocks = (
            gmsh.model.mesh.getElements(3, entity_tag)
        )
        for element_type_value, tags, flat_connectivity in zip(
            element_types,
            tag_blocks,
            connectivity_blocks,
        ):
            element_type = int(element_type_value)
            name, element_dimension, order, node_count, _, primary_node_count = (
                gmsh.model.mesh.getElementProperties(element_type)
            )
            spec = ELEMENT_SPECS.get(element_type)
            if (
                spec is None
                or int(element_dimension) != 3
                or int(order) != 1
                or int(node_count) != spec[1]
                or int(primary_node_count) != spec[1]
            ):
                unsupported.add(str(name))
                continue
            kind, expected_nodes, _ = spec
            connectivity = tuple(int(tag) for tag in flat_connectivity)
            if len(connectivity) != expected_nodes * len(tags):
                raise VolumeMeshError(
                    f"实体 {entity_tag} 的 {name} connectivity 长度不一致"
                )
            for index, element_tag in enumerate(tags):
                start = index * expected_nodes
                raw_elements.append(
                    (
                        int(element_tag),
                        kind,
                        element_type,
                        connectivity[start : start + expected_nodes],
                        entity_tag,
                    )
                )
    if unsupported:
        rendered = ", ".join(sorted(unsupported))
        raise VolumeMeshError(
            "当前体网格数据模型只支持一阶 "
            "TET4/HEX8/WEDGE6/PYRAMID5；"
            f"发现不支持的三维单元：{rendered}"
        )
    if not raw_elements:
        raise VolumeMeshError(
            "MSH 不包含一阶 TET4/HEX8/WEDGE6/PYRAMID5 三维单元"
        )

    raw_elements.sort(key=lambda item: item[0])
    tags = tuple(item[0] for item in raw_elements)
    if len(tags) != len(set(tags)):
        raise VolumeMeshError("MSH 包含重复的三维 element tag")
    determinants = tuple(
        float(value)
        for value in gmsh.model.mesh.getElementQualities(tags, "minDetJac")
    )
    if len(determinants) != len(raw_elements):
        raise VolumeMeshError("Gmsh 返回的 Jacobian 数量与三维单元数量不一致")

    elements: list[VolumeElement] = []
    for raw, determinant in zip(raw_elements, determinants):
        if not math.isfinite(determinant) or determinant <= 0.0:
            raise VolumeMeshError(
                f"element {raw[0]} 的 Jacobian 必须为正，实际为 {determinant:g}"
            )
        element_tag, kind, element_type, node_tags, entity_tag = raw
        elements.append(
            VolumeElement(
                tag=element_tag,
                kind=kind,
                gmsh_type=element_type,
                node_tags=node_tags,
                entity_tag=entity_tag,
                physical_groups=physical_groups.get(entity_tag, ()),
                min_jacobian_determinant=determinant,
            )
        )
    return tuple(elements)


def _dimensional_element_counts(gmsh: Any) -> tuple[int, int, int, int]:
    counts: list[int] = []
    for dimension in range(4):
        _, tag_blocks, _ = gmsh.model.mesh.getElements(dimension)
        counts.append(sum(len(tags) for tags in tag_blocks))
    return tuple(counts)  # type: ignore[return-value]


def _extract_current_model(gmsh: Any, source_path: Path) -> VolumeMesh:
    physical_groups = _physical_groups_by_entity(gmsh)
    nodes = _read_nodes(gmsh)
    elements = _read_elements(gmsh, physical_groups)
    node_tags = {node.tag for node in nodes}
    referenced_tags = {tag for element in elements for tag in element.node_tags}
    missing_tags = sorted(referenced_tags.difference(node_tags))
    if missing_tags:
        raise VolumeMeshError(
            f"三维 connectivity 引用了不存在的节点 {missing_tags[0]}"
        )
    return VolumeMesh(
        source_path=source_path,
        nodes=nodes,
        elements=elements,
        entity_physical_groups=physical_groups,
        dimensional_element_counts=_dimensional_element_counts(gmsh),
        min_jacobian_determinant=min(
            element.min_jacobian_determinant for element in elements
        ),
    )


def load_volume_mesh(path: str | Path) -> VolumeMesh:
    """Load a Gmsh MSH 4.1 file without template-boundary processing."""

    source_path = Path(path).expanduser().resolve()
    if not source_path.is_file():
        raise VolumeMeshError(f"MSH 文件不存在：{source_path}")
    _validate_msh_41(source_path)
    gmsh = _load_gmsh()
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_volume",
        number_options={"General.Terminal": 0.0},
    ):
        try:
            gmsh.merge(str(source_path))
            return _extract_current_model(gmsh, source_path)
        except VolumeMeshError:
            raise
        except Exception as exc:
            raise VolumeMeshError(f"Gmsh 无法读取 MSH：{source_path}") from exc


def _compact_unsigned(values: np.ndarray) -> np.ndarray:
    # The usual connected-layout IDs fit in 32 bits. Keep arbitrary imported
    # 64-bit tags exact, while halving connectivity storage for dense layouts.
    if values.size and int(values.max()) <= np.iinfo(np.uint32).max:
        return values.astype(np.uint32, copy=False)
    return values


def _read_compact_nodes(gmsh: Any) -> tuple[np.ndarray, np.ndarray]:
    tags, coordinates, _ = gmsh.model.mesh.getNodes()
    tags = np.asarray(tags, dtype=np.uintp)
    coordinates = np.asarray(coordinates, dtype=np.float64)
    if tags.ndim != 1 or coordinates.ndim != 1 or coordinates.size != 3 * tags.size:
        raise VolumeMeshError("Gmsh 返回的节点坐标长度不一致")
    coordinates = coordinates.reshape(-1, 3)
    for start in range(0, len(tags), _COMPACT_CHUNK_SIZE):
        if not np.isfinite(coordinates[start:start + _COMPACT_CHUNK_SIZE]).all():
            raise VolumeMeshError("MSH 包含非有限节点坐标")
    if len(tags) > 1 and not np.all(tags[1:] > tags[:-1]):
        order = np.argsort(tags)
        tags = tags[order]
        coordinates = coordinates[order]
        if np.any(tags[1:] == tags[:-1]):
            raise VolumeMeshError("MSH 包含重复的 node tag")
    tags = _compact_unsigned(tags)
    tags.flags.writeable = False
    coordinates.flags.writeable = False
    return tags, coordinates


def _read_compact_element_blocks(
    gmsh: Any,
    physical_groups: Mapping[int, tuple[PhysicalGroup, ...]],
    report: VolumeProgressCallback,
) -> tuple[CompactElementBlock, ...]:
    blocks: list[CompactElementBlock] = []
    unsupported: set[str] = set()
    properties: dict[int, tuple[Any, ...]] = {}
    entities = tuple(physical_groups)
    last_percent = -1
    for index, entity_tag in enumerate(entities):
        element_types, tag_blocks, connectivity_blocks = gmsh.model.mesh.getElements(
            3, entity_tag,
        )
        if not len(element_types) == len(tag_blocks) == len(connectivity_blocks):
            raise VolumeMeshError(f"实体 {entity_tag} 的单元数据块数量不一致")
        for element_type_value, tags, connectivity in zip(
            element_types, tag_blocks, connectivity_blocks,
        ):
            element_type = int(element_type_value)
            if element_type not in properties:
                properties[element_type] = tuple(
                    gmsh.model.mesh.getElementProperties(element_type)
                )
            name, dimension, order, node_count, _, primary_count = properties[element_type]
            spec = ELEMENT_SPECS.get(element_type)
            if (spec is None or int(dimension) != 3 or int(order) != 1
                    or int(node_count) != spec[1] or int(primary_count) != spec[1]):
                unsupported.add(str(name))
                continue
            tags = np.asarray(tags, dtype=np.uintp)
            connectivity = np.asarray(connectivity, dtype=np.uintp)
            if (tags.ndim != 1 or connectivity.ndim != 1
                    or connectivity.size != spec[1] * tags.size):
                raise VolumeMeshError(
                    f"实体 {entity_tag} 的 {name} connectivity 长度不一致"
                )
            if not len(tags):
                continue
            connectivity = connectivity.reshape(-1, spec[1])
            if len(tags) > 1 and not np.all(tags[1:] > tags[:-1]):
                tag_order = np.argsort(tags)
                tags = tags[tag_order]
                connectivity = connectivity[tag_order]
                if np.any(tags[1:] == tags[:-1]):
                    raise VolumeMeshError("MSH 包含重复的三维 element tag")
            tags = _compact_unsigned(tags)
            connectivity = _compact_unsigned(connectivity)
            tags.flags.writeable = False
            connectivity.flags.writeable = False
            blocks.append(CompactElementBlock(
                entity_tag, element_type, spec[0], tags, connectivity,
            ))
        percent = 20 + 20 * (index + 1) // max(1, len(entities))
        if percent != last_percent:
            report(percent, f"读取三维单元：{index + 1:,}/{len(entities):,} 个实体")
            last_percent = percent
    if unsupported:
        raise VolumeMeshError(
            "当前体网格数据模型只支持一阶 TET4/HEX8/WEDGE6/PYRAMID5；"
            f"发现不支持的三维单元：{', '.join(sorted(unsupported))}"
        )
    if not blocks:
        raise VolumeMeshError("MSH 不包含一阶 TET4/HEX8/WEDGE6/PYRAMID5 三维单元")
    return tuple(blocks)


def _validate_compact_element_tags(blocks: tuple[CompactElementBlock, ...]) -> None:
    count = sum(len(block.tags) for block in blocks)
    maximum_tag = max(int(block.tags[-1]) for block in blocks)
    if maximum_tag <= 2 * count:
        # Connected layouts normally have dense tags. A byte per possible tag
        # avoids both Python sets and concatenating/sorting every EID again.
        seen = np.zeros(maximum_tag + 1, dtype=np.bool_)
        for block in blocks:
            for start in range(0, len(block.tags), _COMPACT_CHUNK_SIZE):
                tags = block.tags[start:start + _COMPACT_CHUNK_SIZE]
                if seen[tags].any():
                    raise VolumeMeshError("MSH 包含重复的三维 element tag")
                seen[tags] = True
    else:
        # Sparse imported IDs must never allocate an array indexed by max tag.
        tags = np.concatenate([block.tags for block in blocks])
        tags.sort()
        if np.any(tags[1:] == tags[:-1]):
            raise VolumeMeshError("MSH 包含重复的三维 element tag")


def _validate_compact_elements(
    gmsh: Any,
    node_tags: np.ndarray,
    blocks: tuple[CompactElementBlock, ...],
    report: VolumeProgressCallback,
) -> float:
    _validate_compact_element_tags(blocks)
    # Fast membership checks are exact, including dense IDs with holes. Keep
    # the sparse fallback bounded to a single connectivity chunk.
    first_node = int(node_tags[0]) if len(node_tags) else 0
    last_node = int(node_tags[-1]) if len(node_tags) else 0
    contiguous_nodes = bool(len(node_tags)) and last_node - first_node + 1 == len(node_tags)
    present = None
    if not contiguous_nodes and len(node_tags) and last_node <= 2 * len(node_tags):
        present = np.zeros(last_node + 1, dtype=np.bool_)
        present[node_tags] = True
    total = sum(len(block.tags) for block in blocks)
    completed = 0
    last_percent = -1
    minimum = math.inf
    for block in blocks:
        for start in range(0, len(block.tags), _COMPACT_CHUNK_SIZE):
            tags = block.tags[start:start + _COMPACT_CHUNK_SIZE]
            connectivity = block.connectivity[start:start + _COMPACT_CHUNK_SIZE].ravel()
            missing = (connectivity < first_node) | (connectivity > last_node)
            if not len(node_tags):
                missing[:] = True
            elif not contiguous_nodes:
                in_range = ~missing
                if present is not None:
                    missing[in_range] = ~present[connectivity[in_range]]
                else:
                    positions = np.searchsorted(node_tags, connectivity[in_range])
                    missing[in_range] = node_tags[positions] != connectivity[in_range]
            if missing.any():
                raise VolumeMeshError(
                    f"三维 connectivity 引用了不存在的节点 {int(connectivity[missing].min())}"
                )
            determinants = np.asarray(
                gmsh.model.mesh.getElementQualities(tags, "minDetJac"), dtype=np.float64,
            )
            if determinants.ndim != 1 or len(determinants) != len(tags):
                raise VolumeMeshError("Gmsh 返回的 Jacobian 数量与三维单元数量不一致")
            invalid = (~np.isfinite(determinants)) | (determinants <= 0.0)
            if invalid.any():
                index = int(np.flatnonzero(invalid)[0])
                raise VolumeMeshError(
                    f"element {int(tags[index])} 的 Jacobian 必须为正，"
                    f"实际为 {float(determinants[index]):g}"
                )
            minimum = min(minimum, float(determinants.min()))
            completed += len(tags)
            percent = 40 + 55 * completed // total
            if percent != last_percent:
                report(percent, f"校验 Jacobian：{completed:,}/{total:,} 个单元")
                last_percent = percent
    return minimum


def load_compact_volume_mesh(
    path: str | Path,
    *,
    progress_callback: VolumeProgressCallback | None = None,
) -> CompactVolumeMesh:
    """Load and strictly validate a large mesh without per-cell Python objects.

    All volume elements still receive Gmsh's adaptive ``minDetJac`` validation.
    Only the storage and validation batch sizes differ from ``load_volume_mesh``.
    The optional callback receives a percent (or ``None`` for Gmsh's opaque
    file-reading phase) and a short description. Gmsh is released before return.
    """

    def report(percent: int | None, message: str) -> None:
        if progress_callback is not None:
            progress_callback(percent, message)

    source_path = Path(path).expanduser().resolve()
    if not source_path.is_file():
        raise VolumeMeshError(f"MSH 文件不存在：{source_path}")
    _validate_msh_41(source_path)
    gmsh = _load_gmsh()
    with isolated_gmsh_model(
        gmsh, "__easymesh_compact_volume",
        number_options={"General.Terminal": 0.0},
    ):
        try:
            report(None, "正在读取 MSH 体网格…")
            gmsh.merge(str(source_path))
            report(10, "正在读取节点坐标…")
            node_tags, coordinates = _read_compact_nodes(gmsh)
            report(18, f"已读取 {len(node_tags):,} 个节点，正在读取材料分组…")
            physical_groups = _physical_groups_by_entity(gmsh)
            blocks = _read_compact_element_blocks(gmsh, physical_groups, report)
            report(40, "正在校验单元编号、节点引用和 Jacobian…")
            minimum = _validate_compact_elements(gmsh, node_tags, blocks, report)
            counts = []
            for dimension in range(3):
                # Do not retrieve all 3D connectivity a second time just to count it.
                _, tag_blocks, _ = gmsh.model.mesh.getElements(dimension)
                counts.append(sum(len(tags) for tags in tag_blocks))
            counts.append(sum(len(block.tags) for block in blocks))
            mesh = CompactVolumeMesh(
                source_path, node_tags, coordinates, blocks, physical_groups,
                tuple(counts), minimum,  # type: ignore[arg-type]
            )
            report(98, "体网格校验完成，正在释放读取缓存…")
        except VolumeMeshError:
            raise
        except Exception as exc:
            raise VolumeMeshError(f"Gmsh 无法读取 MSH：{source_path}") from exc
    report(100, f"体网格已就绪：{mesh.node_count:,} 个节点，{mesh.element_count:,} 个单元")
    return mesh


__all__ = [
    "CompactElementBlock",
    "CompactVolumeMesh",
    "ELEMENT_SPECS",
    "ElementKind",
    "MeshNode",
    "PhysicalGroup",
    "VolumeElement",
    "VolumeMesh",
    "VolumeMeshError",
    "VolumeProgressCallback",
    "load_compact_volume_mesh",
    "load_volume_mesh",
]
