# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mesh_options.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QComboBox, QDialog,
    QDialogButtonBox, QDoubleSpinBox, QFormLayout, QLabel,
    QSizePolicy, QVBoxLayout, QWidget)

from easymesh.package_v2_expression_edit import ExpressionEdit

class Ui_MeshOptionsForm(object):
    def setupUi(self, MeshOptionsForm):
        if not MeshOptionsForm.objectName():
            MeshOptionsForm.setObjectName(u"MeshOptionsForm")
        MeshOptionsForm.resize(560, 400)
        self.root_layout = QVBoxLayout(MeshOptionsForm)
        self.root_layout.setObjectName(u"root_layout")
        self._form = QFormLayout()
        self._form.setObjectName(u"_form")
        self._form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        self.target_label = QLabel(MeshOptionsForm)
        self.target_label.setObjectName(u"target_label")
        self.target_label.setWordWrap(True)
        self.target_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(0, QFormLayout.ItemRole.LabelRole, self.target_label)

        self.target_edit = ExpressionEdit(MeshOptionsForm)
        self.target_edit.setObjectName(u"target_edit")

        self._form.setWidget(0, QFormLayout.ItemRole.FieldRole, self.target_edit)

        self.transition_label = QLabel(MeshOptionsForm)
        self.transition_label.setObjectName(u"transition_label")
        self.transition_label.setWordWrap(True)
        self.transition_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(1, QFormLayout.ItemRole.LabelRole, self.transition_label)

        self.transition_edit = ExpressionEdit(MeshOptionsForm)
        self.transition_edit.setObjectName(u"transition_edit")

        self._form.setWidget(1, QFormLayout.ItemRole.FieldRole, self.transition_edit)

        self.negative_x_label = QLabel(MeshOptionsForm)
        self.negative_x_label.setObjectName(u"negative_x_label")
        self.negative_x_label.setWordWrap(True)
        self.negative_x_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(2, QFormLayout.ItemRole.LabelRole, self.negative_x_label)

        self.negative_x_edit = ExpressionEdit(MeshOptionsForm)
        self.negative_x_edit.setObjectName(u"negative_x_edit")

        self._form.setWidget(2, QFormLayout.ItemRole.FieldRole, self.negative_x_edit)

        self.positive_x_label = QLabel(MeshOptionsForm)
        self.positive_x_label.setObjectName(u"positive_x_label")
        self.positive_x_label.setWordWrap(True)
        self.positive_x_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(3, QFormLayout.ItemRole.LabelRole, self.positive_x_label)

        self.positive_x_edit = ExpressionEdit(MeshOptionsForm)
        self.positive_x_edit.setObjectName(u"positive_x_edit")

        self._form.setWidget(3, QFormLayout.ItemRole.FieldRole, self.positive_x_edit)

        self.negative_y_label = QLabel(MeshOptionsForm)
        self.negative_y_label.setObjectName(u"negative_y_label")
        self.negative_y_label.setWordWrap(True)
        self.negative_y_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(4, QFormLayout.ItemRole.LabelRole, self.negative_y_label)

        self.negative_y_edit = ExpressionEdit(MeshOptionsForm)
        self.negative_y_edit.setObjectName(u"negative_y_edit")

        self._form.setWidget(4, QFormLayout.ItemRole.FieldRole, self.negative_y_edit)

        self.positive_y_label = QLabel(MeshOptionsForm)
        self.positive_y_label.setObjectName(u"positive_y_label")
        self.positive_y_label.setWordWrap(True)
        self.positive_y_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(5, QFormLayout.ItemRole.LabelRole, self.positive_y_label)

        self.positive_y_edit = ExpressionEdit(MeshOptionsForm)
        self.positive_y_edit.setObjectName(u"positive_y_edit")

        self._form.setWidget(5, QFormLayout.ItemRole.FieldRole, self.positive_y_edit)

        self.negative_z_label = QLabel(MeshOptionsForm)
        self.negative_z_label.setObjectName(u"negative_z_label")
        self.negative_z_label.setWordWrap(True)
        self.negative_z_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(6, QFormLayout.ItemRole.LabelRole, self.negative_z_label)

        self.negative_z_edit = ExpressionEdit(MeshOptionsForm)
        self.negative_z_edit.setObjectName(u"negative_z_edit")

        self._form.setWidget(6, QFormLayout.ItemRole.FieldRole, self.negative_z_edit)

        self.positive_z_label = QLabel(MeshOptionsForm)
        self.positive_z_label.setObjectName(u"positive_z_label")
        self.positive_z_label.setWordWrap(True)
        self.positive_z_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(7, QFormLayout.ItemRole.LabelRole, self.positive_z_label)

        self.positive_z_edit = ExpressionEdit(MeshOptionsForm)
        self.positive_z_edit.setObjectName(u"positive_z_edit")

        self._form.setWidget(7, QFormLayout.ItemRole.FieldRole, self.positive_z_edit)

        self.sweep_label = QLabel(MeshOptionsForm)
        self.sweep_label.setObjectName(u"sweep_label")
        self.sweep_label.setWordWrap(True)
        self.sweep_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(8, QFormLayout.ItemRole.LabelRole, self.sweep_label)

        self.sweep_combo = QComboBox(MeshOptionsForm)
        self.sweep_combo.addItem("")
        self.sweep_combo.addItem("")
        self.sweep_combo.addItem("")
        self.sweep_combo.addItem("")
        self.sweep_combo.addItem("")
        self.sweep_combo.addItem("")
        self.sweep_combo.setObjectName(u"sweep_combo")

        self._form.setWidget(8, QFormLayout.ItemRole.FieldRole, self.sweep_combo)

        self.layer_label = QLabel(MeshOptionsForm)
        self.layer_label.setObjectName(u"layer_label")
        self.layer_label.setWordWrap(True)
        self.layer_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(9, QFormLayout.ItemRole.LabelRole, self.layer_label)

        self.layer_edit = ExpressionEdit(MeshOptionsForm)
        self.layer_edit.setObjectName(u"layer_edit")

        self._form.setWidget(9, QFormLayout.ItemRole.FieldRole, self.layer_edit)

        self.plane_label = QLabel(MeshOptionsForm)
        self.plane_label.setObjectName(u"plane_label")
        self.plane_label.setWordWrap(True)
        self.plane_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(10, QFormLayout.ItemRole.LabelRole, self.plane_label)

        self.plane_edit = ExpressionEdit(MeshOptionsForm)
        self.plane_edit.setObjectName(u"plane_edit")

        self._form.setWidget(10, QFormLayout.ItemRole.FieldRole, self.plane_edit)

        self.plane_transition_label = QLabel(MeshOptionsForm)
        self.plane_transition_label.setObjectName(u"plane_transition_label")
        self.plane_transition_label.setWordWrap(True)
        self.plane_transition_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(11, QFormLayout.ItemRole.LabelRole, self.plane_transition_label)

        self.plane_transition_edit = ExpressionEdit(MeshOptionsForm)
        self.plane_transition_edit.setObjectName(u"plane_transition_edit")

        self._form.setWidget(11, QFormLayout.ItemRole.FieldRole, self.plane_transition_edit)

        self.surface_label = QLabel(MeshOptionsForm)
        self.surface_label.setObjectName(u"surface_label")
        self.surface_label.setWordWrap(True)
        self.surface_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(12, QFormLayout.ItemRole.LabelRole, self.surface_label)

        self.surface_edit = ExpressionEdit(MeshOptionsForm)
        self.surface_edit.setObjectName(u"surface_edit")

        self._form.setWidget(12, QFormLayout.ItemRole.FieldRole, self.surface_edit)

        self.constraint_label = QLabel(MeshOptionsForm)
        self.constraint_label.setObjectName(u"constraint_label")
        self.constraint_label.setWordWrap(True)
        self.constraint_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(13, QFormLayout.ItemRole.LabelRole, self.constraint_label)

        self.constraint_combo = QComboBox(MeshOptionsForm)
        self.constraint_combo.addItem("")
        self.constraint_combo.addItem("")
        self.constraint_combo.setObjectName(u"constraint_combo")

        self._form.setWidget(13, QFormLayout.ItemRole.FieldRole, self.constraint_combo)

        self.ratio_label = QLabel(MeshOptionsForm)
        self.ratio_label.setObjectName(u"ratio_label")
        self.ratio_label.setWordWrap(True)
        self.ratio_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(14, QFormLayout.ItemRole.LabelRole, self.ratio_label)

        self.ratio_spin = QDoubleSpinBox(MeshOptionsForm)
        self.ratio_spin.setObjectName(u"ratio_spin")
        self.ratio_spin.setDecimals(3)
        self.ratio_spin.setMinimum(0.001000000000000)
        self.ratio_spin.setMaximum(1.000000000000000)
        self.ratio_spin.setSingleStep(0.050000000000000)
        self.ratio_spin.setValue(0.250000000000000)

        self._form.setWidget(14, QFormLayout.ItemRole.FieldRole, self.ratio_spin)

        self.origin_label = QLabel(MeshOptionsForm)
        self.origin_label.setObjectName(u"origin_label")
        self.origin_label.setWordWrap(True)
        self.origin_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(15, QFormLayout.ItemRole.LabelRole, self.origin_label)

        self.origin_combo = QComboBox(MeshOptionsForm)
        self.origin_combo.setObjectName(u"origin_combo")

        self._form.setWidget(15, QFormLayout.ItemRole.FieldRole, self.origin_combo)

        self.origin_X_label = QLabel(MeshOptionsForm)
        self.origin_X_label.setObjectName(u"origin_X_label")
        self.origin_X_label.setWordWrap(True)
        self.origin_X_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(16, QFormLayout.ItemRole.LabelRole, self.origin_X_label)

        self.origin_x = ExpressionEdit(MeshOptionsForm)
        self.origin_x.setObjectName(u"origin_x")

        self._form.setWidget(16, QFormLayout.ItemRole.FieldRole, self.origin_x)

        self.origin_Y_label = QLabel(MeshOptionsForm)
        self.origin_Y_label.setObjectName(u"origin_Y_label")
        self.origin_Y_label.setWordWrap(True)
        self.origin_Y_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(17, QFormLayout.ItemRole.LabelRole, self.origin_Y_label)

        self.origin_y = ExpressionEdit(MeshOptionsForm)
        self.origin_y.setObjectName(u"origin_y")

        self._form.setWidget(17, QFormLayout.ItemRole.FieldRole, self.origin_y)

        self.origin_Z_label = QLabel(MeshOptionsForm)
        self.origin_Z_label.setObjectName(u"origin_Z_label")
        self.origin_Z_label.setWordWrap(True)
        self.origin_Z_label.setTextFormat(Qt.PlainText)

        self._form.setWidget(18, QFormLayout.ItemRole.LabelRole, self.origin_Z_label)

        self.origin_z = ExpressionEdit(MeshOptionsForm)
        self.origin_z.setObjectName(u"origin_z")

        self._form.setWidget(18, QFormLayout.ItemRole.FieldRole, self.origin_z)


        self.root_layout.addLayout(self._form)

        self.status = QLabel(MeshOptionsForm)
        self.status.setObjectName(u"status")
        self.status.setWordWrap(True)
        self.status.setTextFormat(Qt.PlainText)

        self.root_layout.addWidget(self.status)

        self.buttons = QDialogButtonBox(MeshOptionsForm)
        self.buttons.setObjectName(u"buttons")
        self.buttons.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.root_layout.addWidget(self.buttons)


        self.retranslateUi(MeshOptionsForm)

        QMetaObject.connectSlotsByName(MeshOptionsForm)
    # setupUi

    def retranslateUi(self, MeshOptionsForm):
        MeshOptionsForm.setWindowTitle(QCoreApplication.translate("MeshOptionsForm", u"\u9ad8\u7ea7\u7f51\u683c\u8bbe\u7f6e", None))
        self.target_label.setText(QCoreApplication.translate("MeshOptionsForm", u"\u57fa\u7840\u5c3a\u5bf8", None))
        self.target_edit.setPlaceholderText("")
        self.transition_label.setText(QCoreApplication.translate("MeshOptionsForm", u"\u8fc7\u6e21\u8ddd\u79bb", None))
        self.transition_edit.setPlaceholderText("")
        self.negative_x_label.setText(QCoreApplication.translate("MeshOptionsForm", u"\u2212X \u5c3a\u5bf8", None))
        self.negative_x_edit.setPlaceholderText(QCoreApplication.translate("MeshOptionsForm", u"\u7559\u7a7a\u4f7f\u7528\u57fa\u7840\u5c3a\u5bf8", None))
        self.positive_x_label.setText(QCoreApplication.translate("MeshOptionsForm", u"+X \u5c3a\u5bf8", None))
        self.positive_x_edit.setPlaceholderText(QCoreApplication.translate("MeshOptionsForm", u"\u7559\u7a7a\u4f7f\u7528\u57fa\u7840\u5c3a\u5bf8", None))
        self.negative_y_label.setText(QCoreApplication.translate("MeshOptionsForm", u"\u2212Y \u5c3a\u5bf8", None))
        self.negative_y_edit.setPlaceholderText(QCoreApplication.translate("MeshOptionsForm", u"\u7559\u7a7a\u4f7f\u7528\u57fa\u7840\u5c3a\u5bf8", None))
        self.positive_y_label.setText(QCoreApplication.translate("MeshOptionsForm", u"+Y \u5c3a\u5bf8", None))
        self.positive_y_edit.setPlaceholderText(QCoreApplication.translate("MeshOptionsForm", u"\u7559\u7a7a\u4f7f\u7528\u57fa\u7840\u5c3a\u5bf8", None))
        self.negative_z_label.setText(QCoreApplication.translate("MeshOptionsForm", u"\u2212Z \u5c3a\u5bf8", None))
        self.negative_z_edit.setPlaceholderText(QCoreApplication.translate("MeshOptionsForm", u"\u7559\u7a7a\u4f7f\u7528\u57fa\u7840\u5c3a\u5bf8", None))
        self.positive_z_label.setText(QCoreApplication.translate("MeshOptionsForm", u"+Z \u5c3a\u5bf8", None))
        self.positive_z_edit.setPlaceholderText(QCoreApplication.translate("MeshOptionsForm", u"\u7559\u7a7a\u4f7f\u7528\u57fa\u7840\u5c3a\u5bf8", None))
        self.sweep_label.setText(QCoreApplication.translate("MeshOptionsForm", u"\u626b\u63a0\u65b9\u5411", None))
        self.sweep_combo.setItemText(0, QCoreApplication.translate("MeshOptionsForm", u"\u2212X", None))
        self.sweep_combo.setItemText(1, QCoreApplication.translate("MeshOptionsForm", u"+X", None))
        self.sweep_combo.setItemText(2, QCoreApplication.translate("MeshOptionsForm", u"\u2212Y", None))
        self.sweep_combo.setItemText(3, QCoreApplication.translate("MeshOptionsForm", u"+Y", None))
        self.sweep_combo.setItemText(4, QCoreApplication.translate("MeshOptionsForm", u"\u2212Z", None))
        self.sweep_combo.setItemText(5, QCoreApplication.translate("MeshOptionsForm", u"+Z", None))

        self.layer_label.setText(QCoreApplication.translate("MeshOptionsForm", u"\u626b\u63a0\u5c42\u539a", None))
        self.layer_edit.setPlaceholderText(QCoreApplication.translate("MeshOptionsForm", u"\u7559\u7a7a\u4f7f\u7528\u57fa\u7840\u5c3a\u5bf8", None))
        self.plane_label.setText(QCoreApplication.translate("MeshOptionsForm", u"\u9762\u5185\u76ee\u6807\u5c3a\u5bf8", None))
        self.plane_edit.setPlaceholderText(QCoreApplication.translate("MeshOptionsForm", u"\u7559\u7a7a\uff1a\u5728\u7ee7\u627f\u8fb9\u5c3a\u5bf8\u4e4b\u95f4\u81ea\u52a8\u8fc7\u6e21\uff1b\u65e0\u7ee7\u627f\u8fb9\u65f6\u4f7f\u7528\u57fa\u7840\u5c3a\u5bf8", None))
        self.plane_transition_label.setText(QCoreApplication.translate("MeshOptionsForm", u"\u9762\u5185\u8fc7\u6e21\u8ddd\u79bb", None))
        self.plane_transition_edit.setPlaceholderText(QCoreApplication.translate("MeshOptionsForm", u"\u7559\u7a7a\uff1a\u81ea\u52a8\uff1b\u7a7a\u95f4\u4e0d\u8db3\u65f6\u53ef\u80fd\u8fbe\u4e0d\u5230\u76ee\u6807\u5c3a\u5bf8", None))
#if QT_CONFIG(tooltip)
        self.plane_transition_edit.setToolTip(QCoreApplication.translate("MeshOptionsForm", u"\u4ec5\u586b\u5199\u9762\u5185\u76ee\u6807\u5c3a\u5bf8\u65f6\u751f\u6548\uff1b\u53ea\u5f71\u54cd\u81ea\u7531\u622a\u9762\uff0c\u4e0d\u6539\u53d8\u7ee7\u627f\u8282\u70b9\u6216\u626b\u63a0\u5c42\u539a\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.surface_label.setText(QCoreApplication.translate("MeshOptionsForm", u"\u81ea\u7531\u8868\u9762\u76ee\u6807\u5c3a\u5bf8", None))
        self.surface_edit.setPlaceholderText(QCoreApplication.translate("MeshOptionsForm", u"\u7559\u7a7a\u4f7f\u7528\u57fa\u7840\u5c3a\u5bf8", None))
        self.constraint_label.setText(QCoreApplication.translate("MeshOptionsForm", u"\u7ea6\u675f\u5f3a\u5ea6", None))
        self.constraint_combo.setItemText(0, QCoreApplication.translate("MeshOptionsForm", u"\u5f31\u7ea6\u675f\uff1a\u5141\u8bb8\u8c03\u6574", None))
        self.constraint_combo.setItemText(1, QCoreApplication.translate("MeshOptionsForm", u"\u5f3a\u7ea6\u675f\uff1a\u56fa\u5b9a\u6b65\u957f\uff0c\u8fb9\u754c\u6536\u5c3e", None))

        self.ratio_label.setText(QCoreApplication.translate("MeshOptionsForm", u"\u4f59\u91cf\u4fdd\u7559\u6bd4\u4f8b", None))
        self.origin_label.setText(QCoreApplication.translate("MeshOptionsForm", u"\u5e03\u79cd Origin", None))
        self.origin_X_label.setText(QCoreApplication.translate("MeshOptionsForm", u"Origin X", None))
        self.origin_x.setPlaceholderText("")
        self.origin_Y_label.setText(QCoreApplication.translate("MeshOptionsForm", u"Origin Y", None))
        self.origin_y.setPlaceholderText("")
        self.origin_Z_label.setText(QCoreApplication.translate("MeshOptionsForm", u"Origin Z", None))
        self.origin_z.setPlaceholderText("")
        self.status.setText(QCoreApplication.translate("MeshOptionsForm", u"\u5c3a\u5bf8\u4e0e Origin \u7528\u4e8e\u5404\u65b9\u5411\u5c1a\u65e0\u63a5\u53e3\u7ea6\u675f\u7684\u90e8\u5206\u3002", None))
        self.buttons.setProperty(u"acceptText", QCoreApplication.translate("MeshOptionsForm", u"\u786e\u5b9a", None))
        self.buttons.setProperty(u"cancelText", QCoreApplication.translate("MeshOptionsForm", u"\u53d6\u6d88", None))
    # retranslateUi
