"""Small spatial operations used while displaying large layouts."""
from __future__ import annotations

import math
from heapq import merge


def minimum_point_distance(points) -> float | None:
    """Exact closest pair in O(n log n), without a dense distance matrix."""
    points = sorted(points)
    if len(points) < 2:
        return None

    def closest(ordered):
        size = len(ordered)
        if size <= 3:
            distance = min((math.hypot(a[0] - b[0], a[1] - b[1])
                            for i, a in enumerate(ordered) for b in ordered[i + 1:]),
                           default=math.inf)
            return distance, sorted(ordered, key=lambda p: p[1])
        middle = size // 2
        split_x = ordered[middle][0]
        left_distance, left = closest(ordered[:middle])
        right_distance, right = closest(ordered[middle:])
        distance = min(left_distance, right_distance)
        by_y = list(merge(left, right, key=lambda p: p[1]))
        strip = [point for point in by_y if abs(point[0] - split_x) < distance]
        for i, first in enumerate(strip):
            for second in strip[i + 1:i + 8]:
                if second[1] - first[1] >= distance:
                    break
                distance = min(distance, math.hypot(first[0] - second[0], first[1] - second[1]))
        return distance, by_y

    return closest(points)[0]
