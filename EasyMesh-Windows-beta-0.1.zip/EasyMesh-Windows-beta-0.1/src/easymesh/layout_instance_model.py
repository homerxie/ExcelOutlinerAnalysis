"""Virtual placement table: editors exist only for the cell being edited."""
from __future__ import annotations

from dataclasses import dataclass
import math

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QPersistentModelIndex, Qt, Signal
from PySide6.QtWidgets import QStyledItemDelegate

from .designer_widgets import CellCombo, CoordinateSpin


@dataclass
class LayoutInstanceRow:
    x_um: float
    y_um: float
    template_key: str | None
    rotation_deg: float = 0.0


class LayoutInstanceModel(QAbstractTableModel):
    rowsChanged = Signal()
    HEADERS = ("中心 X / µm", "中心 Y / µm", "使用模板", "旋转 / °")

    def __init__(self, parent=None):
        super().__init__(parent)
        self.rows: list[LayoutInstanceRow] = []
        self.choices: list[tuple[str, str]] = []
        self._aliases = {}

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else 4

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < len(self.rows):
            return None
        row = self.rows[index.row()]
        value = (row.x_um, row.y_um, row.template_key, row.rotation_deg)[index.column()]
        if role == Qt.ItemDataRole.EditRole:
            return value
        if role == Qt.ItemDataRole.DisplayRole:
            return self._aliases.get(value, "请选择模板") if index.column() == 2 else f"{value:.9g}"
        if role == Qt.ItemDataRole.TextAlignmentRole and index.column() != 2:
            return int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        return None

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role != Qt.ItemDataRole.DisplayRole:
            return None
        return self.HEADERS[section] if orientation == Qt.Orientation.Horizontal else str(section + 1)

    def flags(self, index):
        return super().flags(index) | Qt.ItemFlag.ItemIsEditable if index.isValid() else Qt.ItemFlag.NoItemFlags

    def setData(self, index, value, role=Qt.ItemDataRole.EditRole):
        if role != Qt.ItemDataRole.EditRole or not index.isValid():
            return False
        column = index.column()
        if column == 2:
            if value not in self._aliases:
                return False
        else:
            try:
                value = float(value)
            except (TypeError, ValueError):
                return False
            if not math.isfinite(value) or (column != 3 and abs(value) > 1e12):
                return False
        setattr(self.rows[index.row()], ("x_um", "y_um", "template_key", "rotation_deg")[column], value)
        self.dataChanged.emit(index, index)
        self.rowsChanged.emit()
        return True

    def set_choices(self, choices):
        self.choices = list(choices)
        self._aliases = {key: alias for alias, key in choices}
        if self.rows:
            self.dataChanged.emit(self.index(0, 2), self.index(len(self.rows) - 1, 2))

    def replace_rows(self, rows):
        self.beginResetModel()
        self.rows = list(rows)
        self.endResetModel()
        self.rowsChanged.emit()

    def append_rows(self, rows):
        rows = list(rows)
        if not rows:
            return
        start = len(self.rows)
        self.beginInsertRows(QModelIndex(), start, start + len(rows) - 1)
        self.rows.extend(rows)
        self.endInsertRows()
        self.rowsChanged.emit()

    def remove_rows(self, selected):
        self.replace_rows(row for index, row in enumerate(self.rows) if index not in selected)

    def assign_template(self, selected, key):
        selected = sorted(index for index in selected if 0 <= index < len(self.rows))
        if not selected or key not in self._aliases:
            return
        for index in selected:
            self.rows[index].template_key = key
        self.dataChanged.emit(self.index(selected[0], 2), self.index(selected[-1], 2))
        self.rowsChanged.emit()


class LayoutInstanceDelegate(QStyledItemDelegate):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._editor = None
        self._index = QPersistentModelIndex()

    def createEditor(self, parent, option, index):
        if index.column() == 2:
            editor = CellCombo(parent)
            for alias, key in index.model().choices:
                editor.addItem(alias, key)
        else:
            editor = CoordinateSpin(parent)
            if index.column() == 3:
                editor.setSuffix(" °")
        self._editor = editor
        self._index = QPersistentModelIndex(index)
        editor.destroyed.connect(lambda: self._forget_editor(editor))
        return editor

    def _forget_editor(self, editor):
        if self._editor is editor:
            self._editor = None
            self._index = QPersistentModelIndex()

    def commit_active_editor(self):
        if self._editor is not None and self._index.isValid():
            editor = self._editor
            self.setModelData(editor, self._index.model(), QModelIndex(self._index))
            self.closeEditor.emit(editor, QStyledItemDelegate.EndEditHint.NoHint)
            self._forget_editor(editor)

    def setEditorData(self, editor, index):
        value = index.data(Qt.ItemDataRole.EditRole)
        if index.column() == 2:
            editor.setCurrentIndex(editor.findData(value))
        else:
            editor.setValue(value)

    def setModelData(self, editor, model, index):
        if index.column() == 2:
            model.setData(index, editor.currentData())
        else:
            editor.interpretText()
            model.setData(index, editor.value())
