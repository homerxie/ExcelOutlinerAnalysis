# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mesh_group_selector.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QHBoxLayout, QHeaderView,
    QLabel, QLayout, QLineEdit, QPushButton,
    QSizePolicy, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
    QWidget)

class Ui_MeshGroupSelectorForm(object):
    def setupUi(self, MeshGroupSelectorForm):
        if not MeshGroupSelectorForm.objectName():
            MeshGroupSelectorForm.setObjectName(u"MeshGroupSelectorForm")
        self.root_layout = QVBoxLayout(MeshGroupSelectorForm)
        self.root_layout.setObjectName(u"root_layout")
        self.root_layout.setSizeConstraint(QLayout.SetMinimumSize)
        self.root_layout.setContentsMargins(0, 0, 0, 0)
        self.search_layout = QHBoxLayout()
        self.search_layout.setObjectName(u"search_layout")
        self.search = QLineEdit(MeshGroupSelectorForm)
        self.search.setObjectName(u"search")

        self.search_layout.addWidget(self.search)

        self.reload_button = QPushButton(MeshGroupSelectorForm)
        self.reload_button.setObjectName(u"reload_button")

        self.search_layout.addWidget(self.reload_button)

        self.search_layout.setStretch(0, 1)

        self.root_layout.addLayout(self.search_layout)

        self.tree = QTreeWidget(MeshGroupSelectorForm)
        self.tree.setObjectName(u"tree")
        self.tree.setRootIsDecorated(False)
        self.tree.setMinimumSize(QSize(0, 100))
        self.tree.setMaximumSize(QSize(16777215, 145))
        self.tree.setSelectionMode(QAbstractItemView.NoSelection)
        self.tree.setWordWrap(False)
        self.tree.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.tree.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.tree.setProperty(u"autoFitMinimumWidth", 80)
        self.tree.setProperty(u"autoFitMaximumWidth", 480)
        self.tree.header().setMinimumSectionSize(48)
        self.tree.header().setDefaultSectionSize(140)
        self.tree.header().setStretchLastSection(False)

        self.root_layout.addWidget(self.tree)

        self.status = QLabel(MeshGroupSelectorForm)
        self.status.setObjectName(u"status")
        self.status.setWordWrap(True)
        self.status.setTextFormat(Qt.PlainText)

        self.root_layout.addWidget(self.status)


        self.retranslateUi(MeshGroupSelectorForm)

        QMetaObject.connectSlotsByName(MeshGroupSelectorForm)
    # setupUi

    def retranslateUi(self, MeshGroupSelectorForm):
        self.search.setPlaceholderText(QCoreApplication.translate("MeshGroupSelectorForm", u"\u7b5b\u9009\u4f53\u5206\u7ec4\u540d\u79f0", None))
        self.reload_button.setText(QCoreApplication.translate("MeshGroupSelectorForm", u"\u91cd\u65b0\u8bfb\u53d6", None))
        ___qtreewidgetitem = self.tree.headerItem()
        ___qtreewidgetitem.setText(0, QCoreApplication.translate("MeshGroupSelectorForm", u"\u7f51\u683c\u5206\u7ec4", None))
        self.status.setText(QCoreApplication.translate("MeshGroupSelectorForm", u"\u8bf7\u5148\u9009\u62e9\u7f51\u683c\u6587\u4ef6\u3002", None))
        pass
    # retranslateUi
