# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'text_edit.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLineEdit, QSizePolicy, QWidget)

class Ui_TextEdit(object):
    def setupUi(self, TextEdit):
        if not TextEdit.objectName():
            TextEdit.setObjectName(u"TextEdit")

        self.retranslateUi(TextEdit)

        QMetaObject.connectSlotsByName(TextEdit)
    # setupUi

    def retranslateUi(self, TextEdit):
        TextEdit.setProperty(u"variableNameToolTip", QCoreApplication.translate("TextEdit", u"\u53d8\u91cf\u540d\u53ea\u80fd\u5305\u542b\u82f1\u6587\u5b57\u6bcd\u3001\u6570\u5b57\u548c\u4e0b\u5212\u7ebf\uff0c\u4e0d\u80fd\u542b\u7a7a\u683c\uff0c\u4e14\u4e0d\u80fd\u4ee5\u6570\u5b57\u5f00\u5934\u3002", None))
    # retranslateUi
