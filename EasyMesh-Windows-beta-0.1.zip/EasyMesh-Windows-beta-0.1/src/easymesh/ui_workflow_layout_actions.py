# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'workflow_layout_actions.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QLabel, QMenu,
    QProgressBar, QPushButton, QSizePolicy, QSpacerItem,
    QToolButton, QVBoxLayout, QWidget)

class Ui_WorkflowLayoutActions(object):
    def setupUi(self, workflow_layout_actions):
        if not workflow_layout_actions.objectName():
            workflow_layout_actions.setObjectName(u"workflow_layout_actions")
        self.layout_to_cdb_action = QAction(workflow_layout_actions)
        self.layout_to_cdb_action.setObjectName(u"layout_to_cdb_action")
        self.progress_container = QWidget(workflow_layout_actions)
        self.progress_container.setObjectName(u"progress_container")
        self.progress_layout = QHBoxLayout(self.progress_container)
        self.progress_layout.setObjectName(u"progress_layout")
        self.progress_layout.setContentsMargins(0, 0, 0, 0)
        self.apply_progress_label = QLabel(self.progress_container)
        self.apply_progress_label.setObjectName(u"apply_progress_label")
        self.apply_progress_label.setMinimumSize(QSize(120, 0))
        self.apply_progress_label.setWordWrap(False)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.apply_progress_label.sizePolicy().hasHeightForWidth())
        self.apply_progress_label.setSizePolicy(sizePolicy)

        self.progress_layout.addWidget(self.apply_progress_label)

        self.apply_progress_bar = QProgressBar(self.progress_container)
        self.apply_progress_bar.setObjectName(u"apply_progress_bar")
        self.apply_progress_bar.setMinimumSize(QSize(180, 0))
        self.apply_progress_bar.setMaximumSize(QSize(180, 20))
        self.apply_progress_bar.setMinimum(0)
        self.apply_progress_bar.setMaximum(100)
        self.apply_progress_bar.setValue(0)
        self.apply_progress_bar.setTextVisible(True)

        self.progress_layout.addWidget(self.apply_progress_bar)

        self.cancel_apply_button = QPushButton(self.progress_container)
        self.cancel_apply_button.setObjectName(u"cancel_apply_button")

        self.progress_layout.addWidget(self.cancel_apply_button)

        self.progress_layout.setStretch(0, 1)
        self.mesh_progress_container = QWidget(workflow_layout_actions)
        self.mesh_progress_container.setObjectName(u"mesh_progress_container")
        self.mesh_progress_layout = QHBoxLayout(self.mesh_progress_container)
        self.mesh_progress_layout.setObjectName(u"mesh_progress_layout")
        self.mesh_progress_layout.setContentsMargins(0, 0, 0, 0)
        self.mesh_progress_label = QLabel(self.mesh_progress_container)
        self.mesh_progress_label.setObjectName(u"mesh_progress_label")
        self.mesh_progress_label.setMinimumSize(QSize(120, 0))
        self.mesh_progress_label.setWordWrap(False)
        sizePolicy.setHeightForWidth(self.mesh_progress_label.sizePolicy().hasHeightForWidth())
        self.mesh_progress_label.setSizePolicy(sizePolicy)

        self.mesh_progress_layout.addWidget(self.mesh_progress_label)

        self.mesh_size_label = QLabel(self.mesh_progress_container)
        self.mesh_size_label.setObjectName(u"mesh_size_label")
        self.mesh_size_label.setWordWrap(False)
        sizePolicy.setHeightForWidth(self.mesh_size_label.sizePolicy().hasHeightForWidth())
        self.mesh_size_label.setSizePolicy(sizePolicy)

        self.mesh_progress_layout.addWidget(self.mesh_size_label)

        self.mesh_progress_bar = QProgressBar(self.mesh_progress_container)
        self.mesh_progress_bar.setObjectName(u"mesh_progress_bar")
        self.mesh_progress_bar.setMinimumSize(QSize(180, 0))
        self.mesh_progress_bar.setMaximumSize(QSize(180, 20))
        self.mesh_progress_bar.setMinimum(0)
        self.mesh_progress_bar.setMaximum(100)
        self.mesh_progress_bar.setValue(0)

        self.mesh_progress_layout.addWidget(self.mesh_progress_bar)

        self.mesh_elapsed_label = QLabel(self.mesh_progress_container)
        self.mesh_elapsed_label.setObjectName(u"mesh_elapsed_label")
        self.mesh_elapsed_label.setAlignment(Qt.AlignRight|Qt.AlignVCenter)

        self.mesh_progress_layout.addWidget(self.mesh_elapsed_label)

        self.mesh_progress_layout.setStretch(0, 2)
        self.mesh_progress_layout.setStretch(1, 1)
        self.next_stage_menu = QMenu(workflow_layout_actions)
        self.next_stage_menu.setObjectName(u"next_stage_menu")
        self.layout_actions_layout = QVBoxLayout(workflow_layout_actions)
        self.layout_actions_layout.setObjectName(u"layout_actions_layout")
        self.layout_actions_layout.setContentsMargins(0, 0, 0, 0)
        self.actions_layout = QHBoxLayout()
        self.actions_layout.setObjectName(u"actions_layout")
        self.edit_layout_button = QPushButton(workflow_layout_actions)
        self.edit_layout_button.setObjectName(u"edit_layout_button")

        self.actions_layout.addWidget(self.edit_layout_button)

        self.show_resources_button = QPushButton(workflow_layout_actions)
        self.show_resources_button.setObjectName(u"show_resources_button")

        self.actions_layout.addWidget(self.show_resources_button)

        self.next_stage_button = QToolButton(workflow_layout_actions)
        self.next_stage_button.setObjectName(u"next_stage_button")
        self.next_stage_button.setPopupMode(QToolButton.MenuButtonPopup)
        self.next_stage_button.setAutoRaise(True)

        self.actions_layout.addWidget(self.next_stage_button)

        self.actions_spacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.actions_layout.addItem(self.actions_spacer)


        self.layout_actions_layout.addLayout(self.actions_layout)


        self.next_stage_menu.addAction(self.layout_to_cdb_action)

        self.retranslateUi(workflow_layout_actions)

        QMetaObject.connectSlotsByName(workflow_layout_actions)
    # setupUi

    def retranslateUi(self, workflow_layout_actions):
        self.layout_to_cdb_action.setText(QCoreApplication.translate("WorkflowLayoutActions", u"\u5bfc\u51fa CDB", None))
        self.apply_progress_label.setText(QCoreApplication.translate("WorkflowLayoutActions", u"\u51c6\u5907\u5e94\u7528\u8fde\u63a5\u5e03\u5c40\u2026", None))
        self.cancel_apply_button.setText(QCoreApplication.translate("WorkflowLayoutActions", u"\u53d6\u6d88", None))
        self.mesh_progress_label.setText(QCoreApplication.translate("WorkflowLayoutActions", u"\u6b63\u5728\u542f\u52a8\u8fde\u63a5\u7f51\u683c\u751f\u6210\u2026", None))
        self.mesh_size_label.setText("")
        self.mesh_progress_bar.setFormat(QCoreApplication.translate("WorkflowLayoutActions", u"\u751f\u6210\u6b65\u9aa4 %p%", None))
        self.mesh_elapsed_label.setText(QCoreApplication.translate("WorkflowLayoutActions", u"\u5df2\u7528\u65f6 00:00", None))
        self.edit_layout_button.setText(QCoreApplication.translate("WorkflowLayoutActions", u"\u7f16\u8f91\u5e03\u5c40", None))
        self.show_resources_button.setText(QCoreApplication.translate("WorkflowLayoutActions", u"Single Bump \u6a21\u677f\u5e93", None))
        self.next_stage_button.setText(QCoreApplication.translate("WorkflowLayoutActions", u"\u4e0b\u4e00\u6b65\uff1aPackage", None))
        pass
    # retranslateUi
