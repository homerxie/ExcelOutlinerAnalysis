"""Editable local HEX patches, kept as a draft until the layout is applied."""
from __future__ import annotations

from dataclasses import dataclass, astuple
import math

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QPersistentModelIndex, Qt, Signal
from PySide6.QtWidgets import QStyledItemDelegate

from .bump_layout import StructuredHexRegion
from .designer_widgets import CoordinateSpin


@dataclass
class LayoutRegionRow:
    x_min_um: float
    x_max_um: float
    y_min_um: float
    y_max_um: float
    size_x_um: float
    size_y_um: float

    @classmethod
    def from_region(cls, region):
        return cls(*(value * 1000 for value in (
            region.x_min_mm, region.x_max_mm, region.y_min_mm, region.y_max_mm,
            region.size_x_mm, region.size_y_mm)))

    def to_region(self):
        if self.x_max_um <= self.x_min_um or self.y_max_um <= self.y_min_um:
            raise ValueError("X / Y 最大值必须大于最小值。")
        if self.size_x_um <= 0 or self.size_y_um <= 0:
            raise ValueError("X / Y 网格尺寸必须大于 0。")
        try:
            return StructuredHexRegion(*(value * .001 for value in astuple(self)))
        except ValueError as error:
            raise ValueError("X / Y 范围必须分别是对应网格尺寸的整数倍。") from error


class LayoutRegionModel(QAbstractTableModel):
    rowsChanged = Signal()
    HEADERS = ("X 最小 / µm", "X 最大 / µm", "Y 最小 / µm", "Y 最大 / µm",
               "X 网格 / µm", "Y 网格 / µm")
    FIELDS = ("x_min_um", "x_max_um", "y_min_um", "y_max_um", "size_x_um", "size_y_um")

    def __init__(self, parent=None):
        super().__init__(parent)
        self.rows: list[LayoutRegionRow] = []

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.FIELDS)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < len(self.rows):
            return None
        value = getattr(self.rows[index.row()], self.FIELDS[index.column()])
        if role == Qt.ItemDataRole.EditRole:
            return value
        if role == Qt.ItemDataRole.DisplayRole:
            return f"{value:.9g}"
        if role == Qt.ItemDataRole.TextAlignmentRole:
            return int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        return None

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role == Qt.ItemDataRole.DisplayRole:
            return self.HEADERS[section] if orientation == Qt.Orientation.Horizontal else str(section + 1)
        return None

    def flags(self, index):
        return super().flags(index) | Qt.ItemFlag.ItemIsEditable if index.isValid() else Qt.ItemFlag.NoItemFlags

    def setData(self, index, value, role=Qt.ItemDataRole.EditRole):
        if role != Qt.ItemDataRole.EditRole or not index.isValid():
            return False
        try:
            value = float(value)
        except (TypeError, ValueError):
            return False
        if not math.isfinite(value) or abs(value) > 1e12:
            return False
        setattr(self.rows[index.row()], self.FIELDS[index.column()], value)
        self.dataChanged.emit(index, index)
        self.rowsChanged.emit()
        return True

    def replace_rows(self, rows):
        self.beginResetModel()
        self.rows = list(rows)
        self.endResetModel()
        self.rowsChanged.emit()

    def append_row(self, row):
        index = len(self.rows)
        self.beginInsertRows(QModelIndex(), index, index)
        self.rows.append(row)
        self.endInsertRows()
        self.rowsChanged.emit()

    def remove_rows(self, selected):
        self.replace_rows(row for index, row in enumerate(self.rows) if index not in selected)

    def regions(self):
        result = []
        for index, row in enumerate(self.rows):
            try:
                result.append(row.to_region())
            except ValueError as error:
                raise ValueError(f"第 {index + 1} 个局部加密区：{error}") from error
        return tuple(result)


class LayoutRegionDelegate(QStyledItemDelegate):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._editor = None
        self._index = QPersistentModelIndex()

    def createEditor(self, parent, option, index):
        editor = CoordinateSpin(parent)
        self._editor = editor
        self._index = QPersistentModelIndex(index)
        editor.destroyed.connect(lambda: self._forget_editor(editor))
        return editor

    def _forget_editor(self, editor):
        if self._editor is editor:
            self._editor = None
            self._index = QPersistentModelIndex()

    def commit_active_editor(self):
        if self._editor is not None and self._index.isValid():
            editor = self._editor
            self.setModelData(editor, self._index.model(), QModelIndex(self._index))
            self.closeEditor.emit(editor, QStyledItemDelegate.EndEditHint.NoHint)
            self._forget_editor(editor)

    def setEditorData(self, editor, index):
        editor.setValue(index.data(Qt.ItemDataRole.EditRole))
        # Imported spacings may be recurring decimals (e.g. 20 / 3 µm).
        # Merely visiting their cell must not replace the exact draft value
        # with the spin box's rounded display value.
        editor.setProperty("initialValue", editor.value())

    def setModelData(self, editor, model, index):
        editor.interpretText()
        if editor.value() != editor.property("initialValue"):
            model.setData(index, editor.value())
