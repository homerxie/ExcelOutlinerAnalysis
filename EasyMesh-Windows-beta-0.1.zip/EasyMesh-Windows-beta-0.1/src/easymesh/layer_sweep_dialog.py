"""Advanced seed options shared by Layer Z and radial interval editors."""

from PySide6.QtWidgets import QDialog


from .designer_widgets import setup_form, dialog_button_texts
from .ui_layer_sweep import Ui_LayerSweepForm
from .layer_sweep import LayerSweepPolicy, RadialSeedPolicy


class LayerSweepDialog(QDialog):
    def __init__(self, interval, inherited, override=None, parent=None):
        super().__init__(parent)
        radial = interval.axis.value == "radial"
        self.policy_type = RadialSeedPolicy if radial else LayerSweepPolicy
        policy = override or inherited
        self.setWindowTitle(f"{interval.identifier} 高级网格选项 · {interval.display_position} µm")
        title = self.windowTitle()
        setup_form(self, Ui_LayerSweepForm)
        self.setWindowTitle(title)
        if radial:
            self.note.setText(self.note.property("radialText"))
            self.inherit_checkbox.setText(self.inherit_checkbox.property("radialText"))
            if interval.contour_dimensions_um is not None and interval.start_um > 0:
                inner, outer = interval.contour_dimensions_um
                if inner[0] - inner[1] != outer[0] - outer[1]:
                    self.help_label.setText(self.help_label.text() + "\n\n" +
                                            self.help_label.property("movingCapText"))
        self.inherit_checkbox.setChecked(override is None)
        for index, value in enumerate(("soft", "hard")):
            self.constraint_combo.setItemData(index, value)
        self.constraint_combo.setCurrentIndex(self.constraint_combo.findData(policy.constraint))
        directions = ("inner", "outer", "both_r") if radial else ("negative_z", "positive_z", "both_z")
        for index, value in enumerate(directions):
            self.direction_combo.setItemData(index, value)
            if radial:
                self.direction_combo.setItemText(index, self.direction_combo.property(f"radialText{index}"))
        self.direction_combo.setCurrentIndex(self.direction_combo.findData(policy.direction))
        self.merge_spin.setValue(policy.remainder_ratio)
        self.center_spin.setValue(policy.center_merge_ratio)
        self.center_spin.setMinimum(self.merge_spin.value())
        self.merge_spin.valueChanged.connect(self.center_spin.setMinimum)
        dialog_button_texts(self.buttons)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        self.inherit_checkbox.toggled.connect(self._update_fields)
        self.constraint_combo.currentIndexChanged.connect(self._update_fields)
        self.direction_combo.currentIndexChanged.connect(self._update_fields)
        self._update_fields()
        self.resize(self.width(), self.sizeHint().height())

    def _update_fields(self, *_args):
        custom = not self.inherit_checkbox.isChecked()
        hard = custom and self.constraint_combo.currentData() == "hard"
        self.constraint_combo.setEnabled(custom)
        self.direction_combo.setEnabled(hard)
        self.merge_spin.setEnabled(hard)
        self.center_spin.setEnabled(hard and self.direction_combo.currentData() in {"both_z", "both_r"})

    def policy(self):
        if self.inherit_checkbox.isChecked():
            return None
        return self.policy_type(self.constraint_combo.currentData(), self.direction_combo.currentData(),
                                self.merge_spin.value(), self.center_spin.value())
