# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'application_theme.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QSizePolicy, QWidget)

class Ui_ApplicationThemeForm(object):
    def setupUi(self, ApplicationThemeForm):
        if not ApplicationThemeForm.objectName():
            ApplicationThemeForm.setObjectName(u"ApplicationThemeForm")

        self.retranslateUi(ApplicationThemeForm)

        QMetaObject.connectSlotsByName(ApplicationThemeForm)
    # setupUi

    def retranslateUi(self, ApplicationThemeForm):
        ApplicationThemeForm.setStyleSheet(QCoreApplication.translate("ApplicationThemeForm", u"\n"
"QTabWidget#main_tabs > QTabBar::tab {\n"
"    min-width: 100px;\n"
"    padding: 10px 18px;\n"
"    font-weight: 600;\n"
"}\n"
"QGroupBox {\n"
"    font-weight: 600;\n"
"}\n"
"QHeaderView::section {\n"
"    padding: 4px 8px;\n"
"    font-weight: 600;\n"
"}\n"
"QPushButton, QPushButton:default, QPushButton:flat, QToolButton,\n"
"QStatusBar QPushButton, QAbstractItemView QPushButton, QAbstractItemView QToolButton {\n"
"    min-height: 28px;\n"
"    max-height: 28px;\n"
"    padding: 0px 10px;\n"
"    margin: 0px;\n"
"    border-width: 1px;\n"
"    border-style: solid;\n"
"}\n"
"QToolButton {\n"
"    border: 1px solid transparent;\n"
"}\n"
"QAbstractItemView QPushButton, QAbstractItemView QToolButton {\n"
"    min-height: 18px;\n"
"    max-height: 18px;\n"
"    margin: 1px 3px;\n"
"}\n"
"QAbstractItemView QComboBox {\n"
"    min-height: 18px;\n"
"    max-height: 18px;\n"
"    padding: 0px 24px 0px 6px;\n"
"    margin: 1px 3px;\n"
"}\n"
"QPushButton[appearance=\"primary\"] {\n"
"    color: #202124;\n"
"    ba"
                        "ckground-color: #8ab4f8;\n"
"    border: 1px solid #8ab4f8;\n"
"}\n"
"QPushButton[appearance=\"primary\"]:hover {\n"
"    background-color: #aecbfa;\n"
"    border-color: #aecbfa;\n"
"}\n"
"QPushButton[appearance=\"primary\"]:pressed {\n"
"    background-color: #669df6;\n"
"    border-color: #669df6;\n"
"}\n"
"QPushButton[appearance=\"primary\"]:focus {\n"
"    border-color: #e8f0fe;\n"
"}\n"
"QPushButton[appearance=\"primary\"]:disabled {\n"
"    color: #9aa0a6;\n"
"    background-color: #30343b;\n"
"    border-color: #42464d;\n"
"}\n"
"QLabel[appearance=\"notice\"] {\n"
"    color: #ffd166;\n"
"    background-color: #3b3322;\n"
"    border: 1px solid #665536;\n"
"    border-radius: 5px;\n"
"    padding: 7px;\n"
"}\n"
"QStatusBar {\n"
"    border-top: 1px solid #3c4043;\n"
"}\n"
"", None))
        ApplicationThemeForm.setProperty(u"accentColor", QCoreApplication.translate("ApplicationThemeForm", u"#8ab4f8", None))
        ApplicationThemeForm.setProperty(u"errorLightForeground", QCoreApplication.translate("ApplicationThemeForm", u"#b42318", None))
        ApplicationThemeForm.setProperty(u"errorLightBackground", QCoreApplication.translate("ApplicationThemeForm", u"#ffe2df", None))
        ApplicationThemeForm.setProperty(u"errorDarkForeground", QCoreApplication.translate("ApplicationThemeForm", u"#ff8a80", None))
        ApplicationThemeForm.setProperty(u"errorDarkBackground", QCoreApplication.translate("ApplicationThemeForm", u"#452b2e", None))
        ApplicationThemeForm.setProperty(u"successLightForeground", QCoreApplication.translate("ApplicationThemeForm", u"#287a3d", None))
        ApplicationThemeForm.setProperty(u"successLightBackground", QCoreApplication.translate("ApplicationThemeForm", u"#e4f3e8", None))
        ApplicationThemeForm.setProperty(u"successDarkForeground", QCoreApplication.translate("ApplicationThemeForm", u"#7ee787", None))
        ApplicationThemeForm.setProperty(u"successDarkBackground", QCoreApplication.translate("ApplicationThemeForm", u"#243d30", None))
        ApplicationThemeForm.setProperty(u"warningLightForeground", QCoreApplication.translate("ApplicationThemeForm", u"#805500", None))
        ApplicationThemeForm.setProperty(u"warningLightBackground", QCoreApplication.translate("ApplicationThemeForm", u"#fff0b8", None))
        ApplicationThemeForm.setProperty(u"warningDarkForeground", QCoreApplication.translate("ApplicationThemeForm", u"#ffd166", None))
        ApplicationThemeForm.setProperty(u"warningDarkBackground", QCoreApplication.translate("ApplicationThemeForm", u"#3b3322", None))
        ApplicationThemeForm.setProperty(u"unusedLightForeground", QCoreApplication.translate("ApplicationThemeForm", u"#654b00", None))
        ApplicationThemeForm.setProperty(u"unusedLightBackground", QCoreApplication.translate("ApplicationThemeForm", u"#fff1c2", None))
        ApplicationThemeForm.setProperty(u"unusedDarkForeground", QCoreApplication.translate("ApplicationThemeForm", u"#ffd166", None))
        ApplicationThemeForm.setProperty(u"unusedDarkBackground", QCoreApplication.translate("ApplicationThemeForm", u"#3b3322", None))
        ApplicationThemeForm.setProperty(u"mutedLightForeground", QCoreApplication.translate("ApplicationThemeForm", u"#52606d", None))
        ApplicationThemeForm.setProperty(u"mutedLightBackground", QCoreApplication.translate("ApplicationThemeForm", u"#edf0f3", None))
        ApplicationThemeForm.setProperty(u"mutedDarkForeground", QCoreApplication.translate("ApplicationThemeForm", u"#b7c4ce", None))
        ApplicationThemeForm.setProperty(u"mutedDarkBackground", QCoreApplication.translate("ApplicationThemeForm", u"#30343b", None))
    # retranslateUi
