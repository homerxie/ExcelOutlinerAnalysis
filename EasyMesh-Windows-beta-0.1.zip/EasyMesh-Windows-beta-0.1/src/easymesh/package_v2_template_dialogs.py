"""GUI authoring for closed local templates and explicitly bound instances."""
from __future__ import annotations

from copy import deepcopy
import re

from PySide6.QtCore import Qt, Signal, QSignalBlocker
from PySide6.QtWidgets import QComboBox, QDialog, QLineEdit, QTableWidgetItem

from .designer_widgets import setup_form, dialog_button_texts, CellCombo, FieldLabel, TextEdit
from .ui_bound_instance import Ui_BoundInstanceForm
from .ui_local_template import Ui_LocalTemplateForm
from .package_v2_local_templates import literal
from .package_v2_local_templates import component_id, component_instances
from .package_v2_local_tables import local_references
from .package_v2_basic_shapes import PARTIAL_FILLET_AXES, SHAPE_LABELS, new_basic_shape
from .package_v2_geometry_library import rewrite_scope_references
from .package_v2_expression_edit import ExpressionEdit, ExpressionDelegate
from .package_v2_draft_preview import compile_draft_preview
from .theme import semantic_colors
from .table_layout import configure_item_view


def _expression(value, candidates=()):
    edit = ExpressionEdit(None, tuple(dict.fromkeys((*candidates, "mm", "um"))))
    edit.setText(str(value))
    return edit


def _length_text(edit, unit="mm"):
    text = edit.text().strip()
    if re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", text):
        text += unit
    return text


def _unique(name, names):
    result, n = name, 2
    while result in names:
        result, n = f"{name}_{n}", n + 1
    return result


def _templates_with_draft(templates, request):
    """Install the unsaved template into a private dependency registry."""
    values = deepcopy(list(templates))
    draft, original_id = request["template"], request["original_id"]
    values = [value for value in values if value["id"] != original_id]
    if any(value["id"] == draft["id"] for value in values):
        raise ValueError(f"模板名称重复：{draft['id']}")
    values.append(deepcopy(draft))
    if original_id and original_id != draft["id"]:
        for template in values:
            for child in template["instances"]:
                if child["template"] == original_id:
                    child["template"] = draft["id"]
    return values


def _configure_preview(dialog, compiler, *, child=False):
    panel = dialog.preview_panel
    panel.configure(compiler, panel.property("childCaption" if child else "caption"), dialog)
    dialog.preview = panel.preview
    dialog.preview_splitter.setStretchFactor(0, 3)
    dialog.preview_splitter.setStretchFactor(1, 2)
    dialog.preview_splitter.setSizes([650, 450])


class BoundInstanceDialog(QDialog):
    submitRequested = Signal(object)

    def __init__(self, parent, editor, *, instance=None, duplicate=False, templates=None,
                 candidates=None, child=False, preview_context=None):
        super().__init__(parent)
        self.source_editor = editor
        self.opened_raw_sha256 = editor.raw_sha256
        self.child = child
        self.preview_context = preview_context
        self.original = deepcopy(instance)
        self.original_id = instance["id"] if instance and not duplicate else None
        self.registry = {t["id"]: deepcopy(t) for t in (templates or editor.document["templates"])}
        self.candidates = tuple(candidates if candidates is not None else
            (v["name"] for key in ("parameters", "derived") for v in editor.document["globals"][key]))
        setup_form(self, Ui_BoundInstanceForm)
        if self.original_id or duplicate:
            self.setWindowTitle(self.property("editTitle" if self.original_id else "duplicateTitle"))
        if child:
            self.help_label.setText(self.help_label.property("childText"))
        existing = {i["id"] for i in editor.document["instances"]}
        proposed = instance["id"] if self.original_id else _unique((instance["id"] + "_copy") if instance else "instance", existing)
        self.name_edit.setText(proposed)
        self.template_combo.addItems(list(self.registry))
        if instance:
            self.template_combo.setCurrentText(instance["template"])
        self.parameter_edits = {}
        self.template_combo.currentTextChanged.connect(self._load_template)
        self._load_template(self.template_combo.currentText())
        self.origin_edits = [getattr(self, "origin_" + axis) for axis in "xyz"]
        self.rotation_combos = [getattr(self, "rotation_" + axis) for axis in "xyz"]
        self.mirror_checks = [getattr(self, "mirror_" + axis) for axis in "xyz"]
        for axis, (edit, combo, mirror) in enumerate(zip(self.origin_edits, self.rotation_combos, self.mirror_checks)):
            edit.set_completion_candidates((*self.candidates, "mm", "um"))
            edit.setText(str(instance["origin"][axis] if instance else "0mm"))
            edit.returnPressed.connect(self._submit)
            for index, angle in enumerate((0, 90, 180, 270)):
                combo.setItemData(index, angle)
            angle = instance.get("rotation", [0] * 3)[axis] if instance else 0
            matched = combo.findData(angle)
            if matched < 0:
                combo.addItem(f"{angle}°（当前）", angle)
                matched = combo.count() - 1
            combo.setCurrentIndex(matched)
            mirror.setChecked(instance.get("mirrors", [False] * 3)[axis] if instance else False)
        for field in (self.component_combo, self.component_name_edit, self.material_edit):
            self.pose_form.setRowVisible(field, not child)
        if not child:
            self.material_edit.setText(instance["material"] if instance else "solid")
            self.components = component_instances(editor.document)
            for name in self.components:
                self.component_combo.addItem(name, name)
            def change_component():
                owner = self.component_combo.currentData()
                self.pose_form.setRowVisible(self.component_name_edit, owner is None)
                self.material_edit.setEnabled(owner is None)
                if owner is not None:
                    self.material_edit.setText(self.components[owner][0]["material"])
            self.component_combo.currentIndexChanged.connect(change_component)
            if self.original_id:
                self.component_combo.setCurrentIndex(self.component_combo.findData(component_id(instance)))
            change_component()
        dialog_button_texts(self.buttons, "editText" if self.original_id else "acceptText")
        self.buttons.accepted.connect(self._submit)
        self.buttons.rejected.connect(self.reject)
        _configure_preview(self, self._compile_preview, child=child)
        for edit in self.editor_page.findChildren(QLineEdit):
            if edit not in self.parameter_edits.values():
                edit.textChanged.connect(self._schedule_preview)
        for combo in self.editor_page.findChildren(QComboBox):
            combo.currentIndexChanged.connect(self._schedule_preview)
        for check in self.mirror_checks:
            check.toggled.connect(self._schedule_preview)

    def _schedule_preview(self, *_args):
        if hasattr(self, "preview_panel"):
            self.preview_panel.schedule()

    def _compile_preview(self):
        templates = list(self.registry.values())
        scope = self.source_editor.document["globals"]
        if self.child:
            if self.preview_context is None:
                raise ValueError("子实例预览需要父模板的局部变量")
            context = self.preview_context()
            scope = context["template"]
            templates = _templates_with_draft(templates, context)
        return compile_draft_preview(templates, self.request(), scope=scope)

    def _load_template(self, name):
        while self.parameter_form.rowCount():
            self.parameter_form.removeRow(0)
        self.parameter_edits = {}
        if name not in self.registry:
            return
        for p in self.registry[name]["parameters"]:
            value = (self.original["bindings"].get(p["name"], p["default"])
                     if self.original and self.original["template"] == name else p["default"])
            if isinstance(value, (int, float)):
                value = literal(value, p["kind"])
            edit = _expression(value, self.candidates)
            edit.returnPressed.connect(self._submit)
            edit.textChanged.connect(self._schedule_preview)
            self.parameter_edits[p["name"]] = edit
            self.parameter_form.addRow(FieldLabel(f"{p['name']} ({p['unit']})"), edit)

    def request(self):
        name = self.template_combo.currentText()
        if name not in self.registry:
            raise ValueError("请先创建或导入模板")
        bindings = {p["name"]: _length_text(self.parameter_edits[p["name"]], p["unit"])
                    if p["kind"] == "length" else self.parameter_edits[p["name"]].text().strip()
                    for p in self.registry[name]["parameters"]}
        result = {"id": self.name_edit.text().strip(), "template": name, "bindings": bindings,
                  "origin": [_length_text(edit) for edit in self.origin_edits],
                  "rotation": [combo.currentData() for combo in self.rotation_combos],
                  "mirrors": [check.isChecked() for check in self.mirror_checks]}
        if not self.child:
            result["material"] = self.material_edit.text().strip()
            owner = self.component_combo.currentData()
            if owner is None:
                owner = self.component_name_edit.text().strip() or result["id"]
                if owner in self.components:
                    raise ValueError("Component 名称已存在，请从“所属 Component”选择它，或使用新名称")
            result["component_id"] = owner
        return result

    def _submit(self):
        try:
            self.submitRequested.emit(self.request())
        except (ValueError, KeyError, TypeError) as error:
            self.show_compilation_error(error)

    def show_compilation_error(self, error):
        self.status_label.setText(str(error))


class LocalTemplateDialog(QDialog):
    submitRequested = Signal(object)

    def __init__(self, parent, editor, *, template=None, duplicate=False):
        super().__init__(parent)
        self._local_tables_ready = False
        self.source_editor = editor
        self.opened_raw_sha256 = editor.raw_sha256
        self.original_id = template["id"] if template and not duplicate else None
        self.working = deepcopy(template or {"id": "geometry", "parameters": [], "derived": [],
                                                             "solids": [], "instances": []})
        self.child_dialog = None
        setup_form(self, Ui_LocalTemplateForm)
        if self.original_id:
            self.setWindowTitle(self.property("editTitle"))
        names = {t["id"] for t in editor.document["templates"]}
        name = self.working["id"] if self.original_id else _unique(self.working["id"], names)
        self.name_edit.setText(name)
        self._configure_variable_table(self.parameter_table, self.working["parameters"], False)
        self._configure_variable_table(self.derived_table, self.working["derived"], True)
        self._table_actions(self.parameter_table, False, self.add_parameter_button, self.delete_parameter_button)
        self._table_actions(self.derived_table, True, self.add_derived_button, self.delete_derived_button)
        self.solid_splitter.setStretchFactor(1, 2)
        for kind, label in SHAPE_LABELS.items():
            self.shape_combo.addItem(label, kind)
        self.add_solid_button.clicked.connect(self._add_solid)
        self.remove_solid_button.clicked.connect(self._remove_solid)
        self.solid_fields, self.active_solid = [], -1
        for table in (self.parameter_table, self.derived_table):
            table.itemChanged.connect(self._refresh_local_variables)
            table.model().rowsRemoved.connect(self._refresh_local_variables)
        self.solid_list.currentRowChanged.connect(self._show_solid)
        self._refresh_solids()
        self.add_child_button.clicked.connect(lambda: self._edit_child(False))
        self.edit_child_button.clicked.connect(lambda: self._edit_child(True))
        self.remove_child_button.clicked.connect(self._remove_child)
        self._refresh_children()
        dialog_button_texts(self.buttons, "editText" if self.original_id else "acceptText")
        self.buttons.accepted.connect(self._submit)
        self.buttons.rejected.connect(self.reject)
        self.finished.connect(lambda: self.child_dialog.reject() if self.child_dialog else None)
        _configure_preview(self, self._compile_preview)
        self.name_edit.textChanged.connect(self.preview_panel.schedule)
        self._local_tables_ready = True
        self._refresh_local_variables()

    def _compile_preview(self):
        request = self.request()
        template = request["template"]
        templates = _templates_with_draft(self.source_editor.document["templates"], request)
        instance = {"id": "preview", "template": template["id"],
                    "bindings": {p["name"]: p["default"] for p in template["parameters"]},
                    "origin": ["0mm"] * 3}
        return compile_draft_preview(templates, instance)

    def _configure_variable_table(self, table, values, derived):
        table.setItemDelegate(ExpressionDelegate(table, expression_columns=(2 if derived else 3,),
                                                 candidates=self.local_names if derived else lambda: (),
                                                 name_columns=(0,)))
        configure_item_view(table)
        for value in values:
            self._append_variable(table, value, derived)
        return table

    def _append_variable(self, table, value, derived):
        with QSignalBlocker(table):
            index = table.rowCount(); table.insertRow(index)
            name = QTableWidgetItem(value["name"])
            name.setData(Qt.ItemDataRole.UserRole, deepcopy(value))
            name.setData(Qt.ItemDataRole.UserRole + 1, value["name"])
            table.setItem(index, 0, name)
            kind = CellCombo(); kind.addItems(("length", "dimensionless")); kind.setCurrentText(value["kind"])
            kind.currentTextChanged.connect(self._refresh_local_variables)
            table.setCellWidget(index, 1, kind)
            if not derived:
                table.setItem(index, 2, QTableWidgetItem(value["unit"]))
            scalar = value["expression" if derived else "default"]
            table.setItem(index, 2 if derived else 3, QTableWidgetItem(
                literal(scalar, value["kind"]) if isinstance(scalar, (int, float)) else str(scalar)))
            usage = QTableWidgetItem()
            usage.setFlags(usage.flags() & ~Qt.ItemFlag.ItemIsEditable)
            table.setItem(index, table.columnCount() - 1, usage)
        self._refresh_local_variables()

    def _table_actions(self, table, derived, add, delete):
        def append():
            names = self.local_names()
            value = {"name": _unique("local_value", names), "kind": "length"}
            value.update({"expression": "1mm"} if derived else {"unit": "mm", "default": "1mm"})
            self._append_variable(table, value, derived)
        add.clicked.connect(append)
        delete.clicked.connect(lambda: table.removeRow(table.currentRow()) if table.currentRow() >= 0 else None)

    def local_names(self):
        return tuple(table.item(row, 0).text().strip() for table in (self.parameter_table, self.derived_table)
                     for row in range(table.rowCount()))

    def _refresh_completions(self, *_args):
        candidates = list(dict.fromkeys((*self.local_names(), "mm", "um")))
        for _path, edit in self.solid_fields:
            if isinstance(edit, ExpressionEdit):
                edit.set_completion_candidates(candidates)

    def _refresh_local_variables(self, *_args):
        if not self._local_tables_ready:
            return
        if _args and isinstance(_args[0], QTableWidgetItem) and _args[0].column() == 0:
            self._rename_local_variable(_args[0])
        self._refresh_completions()
        self._refresh_local_usage()

    def _rename_local_variable(self, item):
        """Update visible draft references immediately; parent bindings change on save."""
        from .package_v2_source import _variable_identifier

        old_name = item.data(Qt.ItemDataRole.UserRole + 1)
        name = item.text()
        if name == old_name:
            return
        try:
            _variable_identifier(name, "/locals/name", field_name="局部变量名称")
            if self.local_names().count(name) > 1:
                raise ValueError(f"局部变量名称 {name!r} 已存在。")
        except ValueError as error:
            with QSignalBlocker(item.tableWidget()):
                item.setText(old_name)
            self.show_compilation_error(error)
            return
        self._save_solid_fields()
        derived, _ = self._read_variables(self.derived_table, True)
        scope = {"derived": derived, "solids": self.working["solids"],
                 "instances": self.working["instances"]}
        rewrite_scope_references(scope, {old_name: name}, allow_incomplete=True)
        self.working["solids"] = scope["solids"]
        with QSignalBlocker(self.derived_table):
            for row, variable in enumerate(derived):
                self.derived_table.item(row, 2).setText(str(variable["expression"]))
        if 0 <= self.active_solid < len(self.working["solids"]):
            for path, edit in self.solid_fields:
                value = self.working["solids"][self.active_solid]
                for key in path:
                    value = value[key]
                with QSignalBlocker(edit):
                    edit.setText(str(value))
        with QSignalBlocker(item.tableWidget()):
            item.setText(name)
            item.setData(Qt.ItemDataRole.UserRole + 1, name)
        self.status_label.setText(f"已更新局部变量 {old_name} → {name} 的引用；保存模板时统一校验。")

    def _refresh_local_usage(self, *_args):
        if not self._local_tables_ready:
            return
        self.preview_panel.schedule()
        self._save_solid_fields()
        template = dict(self.working)
        template["parameters"], _ = self._read_variables(self.parameter_table, False)
        template["derived"], _ = self._read_variables(self.derived_table, True)
        references = local_references(template)
        unused = 0
        for table in (self.parameter_table, self.derived_table):
            with QSignalBlocker(table):
                for row in range(table.rowCount()):
                    owners = references[table.item(row, 0).text().strip()]
                    unused += not owners
                    usage = table.item(row, table.columnCount() - 1)
                    usage.setText("已引用" if owners else "未引用")
                    usage.setData(Qt.ItemDataRole.UserRole, owners)
                    tooltip = ("引用位置：\n" + "\n".join(owners) if owners else
                               "此局部变量未被本模板的基本图形、内部公式或子实例引用。")
                    for column in range(table.columnCount()):
                        item = table.item(row, column)
                        if item is not None:
                            item.setToolTip(tooltip)
                            foreground, background = semantic_colors(self, "unused")
                            item.setData(Qt.ItemDataRole.BackgroundRole, background if not owners else None)
                            item.setData(Qt.ItemDataRole.ForegroundRole, foreground if not owners else None)
        self.local_usage_label.setText(
            f"黄色 / 未引用：{unused} 个。统计本模板内的引用；悬停查看引用位置。")

    def _read_variables(self, table, derived):
        values, renames = [], {}
        for row in range(table.rowCount()):
            name = table.item(row, 0).text()
            original = table.item(row, 0).data(Qt.ItemDataRole.UserRole)
            value = deepcopy(original)
            value.update(name=name, kind=table.cellWidget(row, 1).currentText())
            if name != original["name"]:
                renames[original["name"]] = name
            expression = table.item(row, 2 if derived else 3).text().strip()
            if value["kind"] == "length" and re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", expression):
                expression += "mm" if derived else table.item(row, 2).text().strip()
            value["expression" if derived else "default"] = expression
            if not derived:
                value["unit"] = table.item(row, 2).text().strip()
            values.append(value)
        return values, renames

    def _save_solid_fields(self):
        if self.active_solid < 0 or self.active_solid >= len(self.working["solids"]):
            return
        solid = self.working["solids"][self.active_solid]
        for path, edit in self.solid_fields:
            target = solid
            for key in path[:-1]:
                target = target[key]
            target[path[-1]] = edit.text().strip() if path == ("id",) else _length_text(edit)

    def _show_solid(self, index):
        self._save_solid_fields()
        self.active_solid = index
        while self.solid_form.rowCount():
            self.solid_form.removeRow(0)
        self.solid_fields = []
        if index < 0:
            self._refresh_local_usage()
            return
        solid = self.working["solids"][index]
        descriptions = {
            "bounds_box": "solid：用局部坐标定义长方体。",
            "bounds_ring": "ring：外框与内框定义矩形环，共用 zmin / zmax。",
            "bounds_fillet": "fillet：外框定义底部轮廓，内框定义开口。顶部 X−、X＋、Y−、Y＋宽度分别设置；每侧都可为 0，转角按相邻两侧宽度自动扫掠。",
            "bounds_quarter_fillet": "1/4 fillet：仅填写外框、内框的 xmax / ymax、顶部 X＋ / Y＋宽度及 zmin / zmax；沿局部 x=0、y=0 截取，保留 +X、+Y 部分。",
            "bounds_half_fillet": "1/2 fillet：仅填写外框、内框的 xmax / ymin / ymax、顶部 X＋ / Y− / Y＋宽度及 zmin / zmax；沿局部 x=0 截取，Y 两侧独立设置。",
        }
        omitted = {axis + "min" for axis in PARTIAL_FILLET_AXES.get(solid["kind"], ())}
        description = descriptions.get(solid["kind"], "组合基本图形")
        if any(key in solid.get("bounds", {}) for key in omitted):
            description = (f"{SHAPE_LABELS[solid['kind']]}：仅显示保留部分的坐标、顶部宽度和高度；"
                           "裁切基准沿用原模板。")
        note = FieldLabel(description)
        self.solid_form.addRow(note)
        def visit(value, path=()):
            if isinstance(value, dict):
                for key, child in value.items():
                    if key == "kind" or (key == "id" and path):
                        continue
                    if path in (("bounds",), ("inner_bounds",), ("top_widths",)) and key in omitted:
                        continue
                    visit(child, (*path, key))
            elif isinstance(value, list):
                for i, child in enumerate(value):
                    visit(child, (*path, i))
            else:
                edit = TextEdit(str(value)) if path == ("id",) else _expression(value, self.local_names())
                if isinstance(edit, ExpressionEdit):
                    edit.returnPressed.connect(self._submit)
                label = "名称" if path == ("id",) else " / ".join(map(str, path))
                if path[0] == "bounds":
                    label = ("外框 " if solid["kind"] != "bounds_box" and path[-1][0] != "z" else "") + path[-1]
                elif path[0] == "inner_bounds":
                    label = "内框 " + path[-1]
                elif path[0] == "top_widths":
                    side = {"xmin": "X−", "xmax": "X＋", "ymin": "Y−", "ymax": "Y＋"}[path[-1]]
                    label = f"顶部 {side} 宽度（≥ 0）"
                edit.setToolTip("相对局部原点 (0, 0, 0) 的坐标，可填写 Local variable 或带单位数值。"
                                if path[0] in ("bounds", "inner_bounds") else "")
                if path[0] == "top_widths":
                    edit.setToolTip("该侧顶部从内框向外延伸的宽度，可填写局部变量或带单位数值；0 表示该侧顶部收尖。")
                self.solid_form.addRow(FieldLabel(label), edit)
                self.solid_fields.append((path, edit))
                edit.textChanged.connect(self._refresh_local_usage)
        visit(solid)
        self._refresh_local_usage()

    def _refresh_solids(self):
        self.solid_list.blockSignals(True)
        self.solid_list.clear()
        self.solid_list.addItems([f"{s['id']} · {SHAPE_LABELS.get(s['kind'], '组合图形')}" for s in self.working["solids"]])
        self.solid_list.blockSignals(False)
        if self.working["solids"]:
            self.solid_list.setCurrentRow(0)
        else:
            self._show_solid(-1)

    def _add_solid(self):
        self._save_solid_fields(); self.active_solid = -1
        ids = [v["id"] for key in ("solids", "instances") for v in self.working[key]]
        kind = self.shape_combo.currentData()
        name = {"bounds_quarter_fillet": "quarter_fillet", "bounds_half_fillet": "half_fillet"}.get(kind, SHAPE_LABELS[kind])
        self.working["solids"].append(new_basic_shape(kind, _unique(name, ids)))
        self._refresh_solids(); self.solid_list.setCurrentRow(len(self.working["solids"]) - 1)

    def _remove_solid(self):
        index = self.solid_list.currentRow()
        if index >= 0:
            self.active_solid = -1; self.working["solids"].pop(index); self._refresh_solids()

    def _refresh_children(self):
        self.child_list.clear()
        self.child_list.addItems([f"{v['id']} → {v['template']}" for v in self.working["instances"]])
        self._refresh_local_usage()

    def _edit_child(self, editing):
        index = self.child_list.currentRow() if editing else -1
        if editing and index < 0:
            return
        dialog = BoundInstanceDialog(self, self.source_editor, child=True, candidates=self.local_names(),
            instance=self.working["instances"][index] if editing else None,
            preview_context=self.request)
        self.child_dialog = dialog
        def submit(value):
            used = [v["id"] for i, v in enumerate(self.working["instances"]) if i != index] + [v["id"] for v in self.working["solids"]]
            if value["id"] in used:
                dialog.show_compilation_error("子对象名称重复")
                return
            if index < 0:
                self.working["instances"].append(value)
            else:
                self.working["instances"][index] = value
            self._refresh_children(); dialog.accept()
        dialog.submitRequested.connect(submit)
        dialog.finished.connect(lambda: setattr(self, "child_dialog", None))
        dialog.setModal(True); dialog.show()

    def _remove_child(self):
        index = self.child_list.currentRow()
        if index >= 0:
            self.working["instances"].pop(index); self._refresh_children()

    def request(self):
        self._save_solid_fields()
        template = deepcopy(self.working)
        template["id"] = self.name_edit.text().strip()
        template["parameters"], renames = self._read_variables(self.parameter_table, False)
        template["derived"], _ = self._read_variables(self.derived_table, True)
        return {"template": template, "original_id": self.original_id, "renames": renames}

    def _submit(self):
        try:
            self.submitRequested.emit(self.request())
        except (ValueError, KeyError, TypeError, AttributeError) as error:
            self.show_compilation_error(error)

    def show_compilation_error(self, error):
        self.status_label.setText(str(error))
