# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'workflow_coordinate.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDoubleSpinBox, QSizePolicy, QWidget)

class Ui_WorkflowCoordinate(object):
    def setupUi(self, WorkflowCoordinate):
        if not WorkflowCoordinate.objectName():
            WorkflowCoordinate.setObjectName(u"WorkflowCoordinate")
        WorkflowCoordinate.setMinimum(-1000000000000.000000000000000)
        WorkflowCoordinate.setMaximum(1000000000000.000000000000000)
        WorkflowCoordinate.setValue(0.000000000000000)
        WorkflowCoordinate.setDecimals(6)
        WorkflowCoordinate.setKeyboardTracking(False)

        self.retranslateUi(WorkflowCoordinate)

        QMetaObject.connectSlotsByName(WorkflowCoordinate)
    # setupUi

    def retranslateUi(self, WorkflowCoordinate):
        WorkflowCoordinate.setSuffix(QCoreApplication.translate("WorkflowCoordinate", u" \u00b5m", None))
    # retranslateUi
