"""Bind generated Designer forms and reuse them for model-driven controls.

Appearance, labels and layout belong in ui/*.ui. Controllers only supply data,
connect signals and decide which fields are relevant to the current model.
"""
from PySide6.QtWidgets import QComboBox, QDialogButtonBox, QDoubleSpinBox, QLabel, QLineEdit, QPushButton

from .ui_cell_button import Ui_CellButton
from .ui_cell_combo import Ui_CellCombo
from .ui_field_label import Ui_FieldLabel
from .ui_text_edit import Ui_TextEdit
from .ui_workflow_coordinate import Ui_WorkflowCoordinate


def setup_form(widget, form_type):
    form = form_type()
    form.setupUi(widget)
    for name, value in vars(form).items():
        setattr(widget, name, value)
    widget._designer_form = form


def dialog_button_texts(box, accept_property="acceptText"):
    box.button(QDialogButtonBox.StandardButton.Ok).setText(box.property(accept_property))
    box.button(QDialogButtonBox.StandardButton.Cancel).setText(box.property("cancelText"))


class CellCombo(QComboBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        Ui_CellCombo().setupUi(self)


class CoordinateSpin(QDoubleSpinBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        Ui_WorkflowCoordinate().setupUi(self)


class CellButton(QPushButton):
    def __init__(self, parent=None):
        super().__init__(parent)
        Ui_CellButton().setupUi(self)


class TextEdit(QLineEdit):
    def __init__(self, text="", parent=None):
        super().__init__(parent)
        Ui_TextEdit().setupUi(self)
        self.setText(str(text))


class FieldLabel(QLabel):
    def __init__(self, text="", parent=None):
        super().__init__(parent)
        Ui_FieldLabel().setupUi(self)
        self.setText(str(text))
