# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'cell_combo.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QSizePolicy, QWidget)

class Ui_CellCombo(object):
    def setupUi(self, CellCombo):
        if not CellCombo.objectName():
            CellCombo.setObjectName(u"CellCombo")
        CellCombo.setSizeAdjustPolicy(QComboBox.AdjustToContents)

        self.retranslateUi(CellCombo)

        QMetaObject.connectSlotsByName(CellCombo)
    # setupUi

    def retranslateUi(self, CellCombo):
        pass
    # retranslateUi
