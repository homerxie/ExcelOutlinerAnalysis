# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'cell_button.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QPushButton, QSizePolicy, QWidget)

class Ui_CellButton(object):
    def setupUi(self, CellButton):
        if not CellButton.objectName():
            CellButton.setObjectName(u"CellButton")
        CellButton.setAutoDefault(False)

        self.retranslateUi(CellButton)

        QMetaObject.connectSlotsByName(CellButton)
    # setupUi

    def retranslateUi(self, CellButton):
        CellButton.setText(QCoreApplication.translate("CellButton", u"\u9ad8\u7ea7", None))
        CellButton.setProperty(u"hardText", QCoreApplication.translate("CellButton", u"\u5f3a\u7ea6\u675f", None))
        CellButton.setProperty(u"softText", QCoreApplication.translate("CellButton", u"\u5f31\u7ea6\u675f", None))
    # retranslateUi
