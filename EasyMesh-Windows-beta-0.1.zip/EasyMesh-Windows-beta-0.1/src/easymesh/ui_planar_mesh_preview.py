# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'planar_mesh_preview.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QSizePolicy, QWidget)

class Ui_PlanarMeshPreviewForm(object):
    def setupUi(self, PlanarMeshPreviewForm):
        if not PlanarMeshPreviewForm.objectName():
            PlanarMeshPreviewForm.setObjectName(u"PlanarMeshPreviewForm")

        self.retranslateUi(PlanarMeshPreviewForm)

        QMetaObject.connectSlotsByName(PlanarMeshPreviewForm)
    # setupUi

    def retranslateUi(self, PlanarMeshPreviewForm):
#if QT_CONFIG(tooltip)
        PlanarMeshPreviewForm.setToolTip(QCoreApplication.translate("PlanarMeshPreviewForm", u"\u5355\u51fb\u7f51\u683c\u5b9a\u4f4d\u5bf9\u5e94 R \u533a\u95f4\uff1b\u663e\u793a\u9009\u4e2d\u9ad8\u5ea6\u7684\u5b9e\u9645 XY \u7f51\u683c\uff0c\u6750\u6599\u989c\u8272\u4e0e\u5de6\u4fa7\u622a\u9762\u4e00\u81f4\u3002\u6df1\u7c97\u7ebf\u4e3a component \u8fb9\u754c\uff0c\u6d45\u7ec6\u7ebf\u4e3a\u5185\u90e8\u7f51\u683c\u3002\u6eda\u8f6e\u7f29\u653e\u3001\u62d6\u62fd\u5e73\u79fb\uff0c\u53cc\u51fb\u9002\u914d\u7a97\u53e3\u3002", None))
#endif // QT_CONFIG(tooltip)
    # retranslateUi
