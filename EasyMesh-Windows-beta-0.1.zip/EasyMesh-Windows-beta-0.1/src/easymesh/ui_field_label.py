# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'field_label.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLabel, QSizePolicy, QWidget)

class Ui_FieldLabel(object):
    def setupUi(self, FieldLabel):
        if not FieldLabel.objectName():
            FieldLabel.setObjectName(u"FieldLabel")
        FieldLabel.setWordWrap(True)
        FieldLabel.setTextFormat(Qt.PlainText)

        self.retranslateUi(FieldLabel)

        QMetaObject.connectSlotsByName(FieldLabel)
    # setupUi

    def retranslateUi(self, FieldLabel):
        pass
    # retranslateUi
