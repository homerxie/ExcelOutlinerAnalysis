# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'workflow_layer_actions.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QMenu, QPushButton,
    QSizePolicy, QSpacerItem, QToolButton, QWidget)

class Ui_WorkflowLayerActions(object):
    def setupUi(self, workflow_layer_actions):
        if not workflow_layer_actions.objectName():
            workflow_layer_actions.setObjectName(u"workflow_layer_actions")
        self.layer_to_cdb_action = QAction(workflow_layer_actions)
        self.layer_to_cdb_action.setObjectName(u"layer_to_cdb_action")
        self.next_stage_menu = QMenu(workflow_layer_actions)
        self.next_stage_menu.setObjectName(u"next_stage_menu")
        self.actions_layout = QHBoxLayout(workflow_layer_actions)
        self.actions_layout.setObjectName(u"actions_layout")
        self.actions_layout.setContentsMargins(0, 0, 0, 0)
        self.show_resources_button = QPushButton(workflow_layer_actions)
        self.show_resources_button.setObjectName(u"show_resources_button")

        self.actions_layout.addWidget(self.show_resources_button)

        self.next_stage_button = QToolButton(workflow_layer_actions)
        self.next_stage_button.setObjectName(u"next_stage_button")
        self.next_stage_button.setPopupMode(QToolButton.MenuButtonPopup)
        self.next_stage_button.setAutoRaise(True)

        self.actions_layout.addWidget(self.next_stage_button)

        self.actions_spacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.actions_layout.addItem(self.actions_spacer)


        self.next_stage_menu.addAction(self.layer_to_cdb_action)

        self.retranslateUi(workflow_layer_actions)

        QMetaObject.connectSlotsByName(workflow_layer_actions)
    # setupUi

    def retranslateUi(self, workflow_layer_actions):
        self.layer_to_cdb_action.setText(QCoreApplication.translate("WorkflowLayerActions", u"\u5bfc\u51fa CDB", None))
        self.show_resources_button.setText(QCoreApplication.translate("WorkflowLayerActions", u"Single Bump \u6a21\u677f\u5e93", None))
        self.next_stage_button.setText(QCoreApplication.translate("WorkflowLayerActions", u"\u4e0b\u4e00\u6b65\uff1a\u8fde\u63a5", None))
        pass
    # retranslateUi
