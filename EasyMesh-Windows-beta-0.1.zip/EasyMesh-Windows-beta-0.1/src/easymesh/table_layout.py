"""Readable item views with content-sized columns that remain user-resizable."""

from __future__ import annotations

from PySide6.QtCore import QObject, QTimer
from PySide6.QtWidgets import QHeaderView, QTableView, QTableWidget, QTreeWidget


class _ItemViewLayout(QObject):
    def __init__(self, view: QTableView | QTreeWidget) -> None:
        super().__init__(view)
        self.view = view
        self.header = view.horizontalHeader() if isinstance(view, QTableView) else view.header()
        self._adjusting = False
        self._user_widths: dict[int, int] = {}
        # Static sizing and scroll properties come from each Designer form.
        # Interactive resizing and remembering user choices are runtime behavior.
        self.header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        if isinstance(view, QTableView) and not isinstance(view, QTableWidget):
            self.header.setResizeContentsPrecision(100)

        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._fit_contents)
        self.header.sectionResized.connect(self._remember_width)
        model = view.model()
        for signal in (model.rowsInserted, model.modelReset, model.dataChanged,
                       model.headerDataChanged, model.layoutChanged):
            signal.connect(self._schedule)
        if isinstance(view, QTreeWidget):
            view.itemExpanded.connect(self._schedule)
        self._schedule()

    def _schedule(self, *_args) -> None:
        # Populate routines install cell widgets after inserting their rows.
        # Wait for the batch to finish before measuring their Qt size hints.
        self._timer.start(0)

    def _remember_width(self, column: int, _old: int, width: int) -> None:
        if not self._adjusting and width > 0:
            self._user_widths[column] = width

    def _fit_contents(self) -> None:
        self._adjusting = True
        try:
            for column in range(self.header.count()):
                if self.header.isSectionHidden(column):
                    continue
                if column in self._user_widths:
                    self.header.resizeSection(column, self._user_widths[column])
                    continue
                self.view.resizeColumnToContents(column)
                minimum = self.view.property("autoFitMinimumWidth") or self.header.minimumSectionSize()
                maximum = self.view.property("autoFitMaximumWidth") or self.header.maximumSectionSize()
                width = max(minimum, min(maximum, self.header.sectionSize(column)))
                self.header.resizeSection(column, width)
            if isinstance(self.view, QTableView):
                # Designer sets the uniform default row height. Resizing every
                # row separately defeats the model view's lazy geometry.
                self.view.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Fixed)
            self.view.doItemsLayout()
        finally:
            self._adjusting = False


def configure_item_view(view: QTableView | QTreeWidget) -> None:
    """Auto-fit untouched columns, retaining manual widths across data refreshes."""

    if not hasattr(view, "_easymesh_item_layout"):
        view._easymesh_item_layout = _ItemViewLayout(view)
