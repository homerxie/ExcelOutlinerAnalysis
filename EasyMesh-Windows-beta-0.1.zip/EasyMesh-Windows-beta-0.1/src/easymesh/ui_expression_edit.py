# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'expression_edit.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLineEdit, QSizePolicy, QWidget)

class Ui_ExpressionEditForm(object):
    def setupUi(self, ExpressionEditForm):
        if not ExpressionEditForm.objectName():
            ExpressionEditForm.setObjectName(u"ExpressionEditForm")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(ExpressionEditForm.sizePolicy().hasHeightForWidth())
        ExpressionEditForm.setSizePolicy(sizePolicy)

        self.retranslateUi(ExpressionEditForm)

        QMetaObject.connectSlotsByName(ExpressionEditForm)
    # setupUi

    def retranslateUi(self, ExpressionEditForm):
#if QT_CONFIG(tooltip)
        ExpressionEditForm.setToolTip(QCoreApplication.translate("ExpressionEditForm", u"\u6309\u7a7a\u683c\u3001\u8fd0\u7b97\u7b26\u548c\u62ec\u53f7\u5206\u9694\u8865\u5168\u5f53\u524d\u53d8\u91cf\uff1b\u2191/\u2193\u9009\u62e9\uff0cTab \u586b\u5165\uff0cEnter \u63d0\u4ea4\uff0cCtrl+Space \u663e\u793a\u5168\u90e8\u3002", None))
#endif // QT_CONFIG(tooltip)
    # retranslateUi
