# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'workflow_region.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog, QDialogButtonBox,
    QDoubleSpinBox, QFormLayout, QLabel, QSizePolicy,
    QVBoxLayout, QWidget)

class Ui_WorkflowRegionForm(object):
    def setupUi(self, WorkflowRegionForm):
        if not WorkflowRegionForm.objectName():
            WorkflowRegionForm.setObjectName(u"WorkflowRegionForm")
        WorkflowRegionForm.resize(560, 300)
        self.root_layout = QVBoxLayout(WorkflowRegionForm)
        self.root_layout.setObjectName(u"root_layout")
        self.bounds_label = QLabel(WorkflowRegionForm)
        self.bounds_label.setObjectName(u"bounds_label")
        self.bounds_label.setWordWrap(True)

        self.root_layout.addWidget(self.bounds_label)

        self.hint_label = QLabel(WorkflowRegionForm)
        self.hint_label.setObjectName(u"hint_label")
        self.hint_label.setWordWrap(True)

        self.root_layout.addWidget(self.hint_label)

        self.target_layout = QFormLayout()
        self.target_layout.setObjectName(u"target_layout")
        self.target_x_label = QLabel(WorkflowRegionForm)
        self.target_x_label.setObjectName(u"target_x_label")

        self.target_layout.setWidget(0, QFormLayout.ItemRole.LabelRole, self.target_x_label)

        self.target_x_spin = QDoubleSpinBox(WorkflowRegionForm)
        self.target_x_spin.setObjectName(u"target_x_spin")
        self.target_x_spin.setDecimals(6)
        self.target_x_spin.setMinimum(0.000001000000000)
        self.target_x_spin.setMaximum(1000000000000.000000000000000)
        self.target_x_spin.setValue(10.000000000000000)
        self.target_x_spin.setKeyboardTracking(False)

        self.target_layout.setWidget(0, QFormLayout.ItemRole.FieldRole, self.target_x_spin)

        self.target_y_label = QLabel(WorkflowRegionForm)
        self.target_y_label.setObjectName(u"target_y_label")

        self.target_layout.setWidget(1, QFormLayout.ItemRole.LabelRole, self.target_y_label)

        self.target_y_spin = QDoubleSpinBox(WorkflowRegionForm)
        self.target_y_spin.setObjectName(u"target_y_spin")
        self.target_y_spin.setDecimals(6)
        self.target_y_spin.setMinimum(0.000001000000000)
        self.target_y_spin.setMaximum(1000000000000.000000000000000)
        self.target_y_spin.setValue(10.000000000000000)
        self.target_y_spin.setKeyboardTracking(False)

        self.target_layout.setWidget(1, QFormLayout.ItemRole.FieldRole, self.target_y_spin)


        self.root_layout.addLayout(self.target_layout)

        self.spacing_label = QLabel(WorkflowRegionForm)
        self.spacing_label.setObjectName(u"spacing_label")
        self.spacing_label.setWordWrap(True)

        self.root_layout.addWidget(self.spacing_label)

        self.error_label = QLabel(WorkflowRegionForm)
        self.error_label.setObjectName(u"error_label")
        self.error_label.setWordWrap(True)

        self.root_layout.addWidget(self.error_label)

        self.buttons = QDialogButtonBox(WorkflowRegionForm)
        self.buttons.setObjectName(u"buttons")
        self.buttons.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.root_layout.addWidget(self.buttons)


        self.retranslateUi(WorkflowRegionForm)

        QMetaObject.connectSlotsByName(WorkflowRegionForm)
    # setupUi

    def retranslateUi(self, WorkflowRegionForm):
        WorkflowRegionForm.setWindowTitle(QCoreApplication.translate("WorkflowRegionForm", u"\u8bbe\u7f6e\u5c40\u90e8\u52a0\u5bc6\u533a", None))
        self.bounds_label.setText("")
        self.hint_label.setText(QCoreApplication.translate("WorkflowRegionForm", u"\u4fdd\u6301\u6846\u9009\u8303\u56f4\uff1b\u6309\u76ee\u6807\u5c3a\u5bf8\u5747\u5206 X / Y\uff0c\u5b9e\u9645\u7f51\u683c\u5c3a\u5bf8\u4e0d\u5927\u4e8e\u76ee\u6807\u503c\u3002", None))
        self.target_x_label.setText(QCoreApplication.translate("WorkflowRegionForm", u"X \u76ee\u6807\u7f51\u683c\u5c3a\u5bf8", None))
        self.target_x_spin.setSuffix(QCoreApplication.translate("WorkflowRegionForm", u" \u00b5m", None))
        self.target_y_label.setText(QCoreApplication.translate("WorkflowRegionForm", u"Y \u76ee\u6807\u7f51\u683c\u5c3a\u5bf8", None))
        self.target_y_spin.setSuffix(QCoreApplication.translate("WorkflowRegionForm", u" \u00b5m", None))
        self.spacing_label.setText("")
        self.error_label.setText("")
        self.error_label.setStyleSheet(QCoreApplication.translate("WorkflowRegionForm", u"color: #d9534f;", None))
        self.buttons.setProperty(u"acceptText", QCoreApplication.translate("WorkflowRegionForm", u"\u8bbe\u4e3a\u52a0\u5bc6\u533a", None))
        self.buttons.setProperty(u"cancelText", QCoreApplication.translate("WorkflowRegionForm", u"\u53d6\u6d88", None))
    # retranslateUi
