# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'workflow_placement.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog, QDialogButtonBox,
    QDoubleSpinBox, QFormLayout, QGroupBox, QLabel,
    QLineEdit, QSizePolicy, QVBoxLayout, QWidget)

class Ui_WorkflowPlacementForm(object):
    def setupUi(self, WorkflowPlacementForm):
        if not WorkflowPlacementForm.objectName():
            WorkflowPlacementForm.setObjectName(u"WorkflowPlacementForm")
        WorkflowPlacementForm.setMinimumSize(QSize(420, 0))
        self.outer = QVBoxLayout(WorkflowPlacementForm)
        self.outer.setObjectName(u"outer")
        self.hint = QLabel(WorkflowPlacementForm)
        self.hint.setObjectName(u"hint")
        self.hint.setWordWrap(True)

        self.outer.addWidget(self.hint)

        self.form = QFormLayout()
        self.form.setObjectName(u"form")
        self.form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        self.alias_label = QLabel(WorkflowPlacementForm)
        self.alias_label.setObjectName(u"alias_label")

        self.form.setWidget(0, QFormLayout.ItemRole.LabelRole, self.alias_label)

        self.alias_edit = QLineEdit(WorkflowPlacementForm)
        self.alias_edit.setObjectName(u"alias_edit")

        self.form.setWidget(0, QFormLayout.ItemRole.FieldRole, self.alias_edit)

        self.x_label = QLabel(WorkflowPlacementForm)
        self.x_label.setObjectName(u"x_label")

        self.form.setWidget(1, QFormLayout.ItemRole.LabelRole, self.x_label)

        self.x_spin = QDoubleSpinBox(WorkflowPlacementForm)
        self.x_spin.setObjectName(u"x_spin")
        self.x_spin.setDecimals(6)
        self.x_spin.setMinimum(-1000000000.000000000000000)
        self.x_spin.setMaximum(1000000000.000000000000000)

        self.form.setWidget(1, QFormLayout.ItemRole.FieldRole, self.x_spin)

        self.y_label = QLabel(WorkflowPlacementForm)
        self.y_label.setObjectName(u"y_label")

        self.form.setWidget(2, QFormLayout.ItemRole.LabelRole, self.y_label)

        self.y_spin = QDoubleSpinBox(WorkflowPlacementForm)
        self.y_spin.setObjectName(u"y_spin")
        self.y_spin.setDecimals(6)
        self.y_spin.setMinimum(-1000000000.000000000000000)
        self.y_spin.setMaximum(1000000000.000000000000000)

        self.form.setWidget(2, QFormLayout.ItemRole.FieldRole, self.y_spin)


        self.outer.addLayout(self.form)

        self.bounds_box = QGroupBox(WorkflowPlacementForm)
        self.bounds_box.setObjectName(u"bounds_box")
        self.bounds_form = QFormLayout(self.bounds_box)
        self.bounds_form.setObjectName(u"bounds_form")
        self.bounds_form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        self.xmin_label = QLabel(self.bounds_box)
        self.xmin_label.setObjectName(u"xmin_label")

        self.bounds_form.setWidget(0, QFormLayout.ItemRole.LabelRole, self.xmin_label)

        self.xmin_spin = QDoubleSpinBox(self.bounds_box)
        self.xmin_spin.setObjectName(u"xmin_spin")
        self.xmin_spin.setDecimals(6)
        self.xmin_spin.setMinimum(-1000000000.000000000000000)
        self.xmin_spin.setMaximum(1000000000.000000000000000)

        self.bounds_form.setWidget(0, QFormLayout.ItemRole.FieldRole, self.xmin_spin)

        self.xmax_label = QLabel(self.bounds_box)
        self.xmax_label.setObjectName(u"xmax_label")

        self.bounds_form.setWidget(1, QFormLayout.ItemRole.LabelRole, self.xmax_label)

        self.xmax_spin = QDoubleSpinBox(self.bounds_box)
        self.xmax_spin.setObjectName(u"xmax_spin")
        self.xmax_spin.setDecimals(6)
        self.xmax_spin.setMinimum(-1000000000.000000000000000)
        self.xmax_spin.setMaximum(1000000000.000000000000000)

        self.bounds_form.setWidget(1, QFormLayout.ItemRole.FieldRole, self.xmax_spin)

        self.ymin_label = QLabel(self.bounds_box)
        self.ymin_label.setObjectName(u"ymin_label")

        self.bounds_form.setWidget(2, QFormLayout.ItemRole.LabelRole, self.ymin_label)

        self.ymin_spin = QDoubleSpinBox(self.bounds_box)
        self.ymin_spin.setObjectName(u"ymin_spin")
        self.ymin_spin.setDecimals(6)
        self.ymin_spin.setMinimum(-1000000000.000000000000000)
        self.ymin_spin.setMaximum(1000000000.000000000000000)

        self.bounds_form.setWidget(2, QFormLayout.ItemRole.FieldRole, self.ymin_spin)

        self.ymax_label = QLabel(self.bounds_box)
        self.ymax_label.setObjectName(u"ymax_label")

        self.bounds_form.setWidget(3, QFormLayout.ItemRole.LabelRole, self.ymax_label)

        self.ymax_spin = QDoubleSpinBox(self.bounds_box)
        self.ymax_spin.setObjectName(u"ymax_spin")
        self.ymax_spin.setDecimals(6)
        self.ymax_spin.setMinimum(-1000000000.000000000000000)
        self.ymax_spin.setMaximum(1000000000.000000000000000)

        self.bounds_form.setWidget(3, QFormLayout.ItemRole.FieldRole, self.ymax_spin)


        self.outer.addWidget(self.bounds_box)

        self.buttons = QDialogButtonBox(WorkflowPlacementForm)
        self.buttons.setObjectName(u"buttons")
        self.buttons.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.outer.addWidget(self.buttons)


        self.retranslateUi(WorkflowPlacementForm)

        QMetaObject.connectSlotsByName(WorkflowPlacementForm)
    # setupUi

    def retranslateUi(self, WorkflowPlacementForm):
        WorkflowPlacementForm.setWindowTitle(QCoreApplication.translate("WorkflowPlacementForm", u"\u5c06\u6a21\u677f\u653e\u5165\u8fde\u63a5\u5e03\u5c40", None))
        self.hint.setText(QCoreApplication.translate("WorkflowPlacementForm", u"\u8bbe\u7f6e\u6a21\u677f\u522b\u540d\u4e0e\u4e2d\u5fc3\u4f4d\u7f6e\uff0c\u6240\u6709\u5c3a\u5bf8\u5355\u4f4d\u4e3a \u00b5m\u3002", None))
        self.alias_label.setText(QCoreApplication.translate("WorkflowPlacementForm", u"\u6a21\u677f\u522b\u540d", None))
        self.x_label.setText(QCoreApplication.translate("WorkflowPlacementForm", u"\u4e2d\u5fc3 X", None))
        self.y_label.setText(QCoreApplication.translate("WorkflowPlacementForm", u"\u4e2d\u5fc3 Y", None))
        self.bounds_box.setTitle(QCoreApplication.translate("WorkflowPlacementForm", u"\u65b0\u5e03\u5c40\u8303\u56f4\uff08\u00b5m\uff09", None))
        self.xmin_label.setText(QCoreApplication.translate("WorkflowPlacementForm", u"X \u6700\u5c0f", None))
        self.xmax_label.setText(QCoreApplication.translate("WorkflowPlacementForm", u"X \u6700\u5927", None))
        self.ymin_label.setText(QCoreApplication.translate("WorkflowPlacementForm", u"Y \u6700\u5c0f", None))
        self.ymax_label.setText(QCoreApplication.translate("WorkflowPlacementForm", u"Y \u6700\u5927", None))
    # retranslateUi
