"""Read-only placement summary with no per-bump Qt item allocation."""
from __future__ import annotations

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt
from PySide6.QtWidgets import QTableView


class LayoutPlacementModel(QAbstractTableModel):
    HEADERS = ("#", "X（µm）", "Y（µm）", "模板", "原生 ring 节点")

    def __init__(self, parent=None):
        super().__init__(parent)
        self._instances = ()
        self._ring_counts = {}

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self._instances)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.HEADERS)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role == Qt.ItemDataRole.DisplayRole:
            return self.HEADERS[section] if orientation == Qt.Orientation.Horizontal else str(section + 1)
        return None

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < len(self._instances):
            return None
        column = index.column()
        if role == Qt.ItemDataRole.TextAlignmentRole:
            return int(Qt.AlignmentFlag.AlignVCenter | (Qt.AlignmentFlag.AlignLeft
                       if column == 3 else Qt.AlignmentFlag.AlignHCenter))
        if role != Qt.ItemDataRole.DisplayRole:
            return None
        instance = self._instances[index.row()]
        if column == 0:
            return str(index.row() + 1)
        if column == 1:
            return f"{instance.x_mm * 1000:g}"
        if column == 2:
            return f"{instance.y_mm * 1000:g}"
        if column == 3:
            return instance.template_alias
        return str(self._ring_counts.get(instance.template_alias, "待读取"))

    def set_layout(self, layout):
        self.beginResetModel()
        self._instances = () if layout is None else layout.instances
        self._ring_counts = {}
        self.endResetModel()

    def set_ring_counts(self, counts):
        self._ring_counts = dict(counts)
        if self._instances:
            self.dataChanged.emit(self.index(0, 4), self.index(len(self._instances) - 1, 4))


class LayoutPlacementView(QTableView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setModel(LayoutPlacementModel(self))
