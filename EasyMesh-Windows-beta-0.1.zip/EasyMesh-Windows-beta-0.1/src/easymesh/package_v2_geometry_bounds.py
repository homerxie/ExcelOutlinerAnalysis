"""Package-axis bounds of canonical solids, without meshing or preview samples."""
from itertools import combinations, product
from math import hypot, isfinite

import numpy as np
from numpy.polynomial import Polynomial

from .package_v2_geometry import (
    CanonicalBox, CanonicalDifference, CanonicalRectangularFrameExtrusion,
    CanonicalRectangularUnderfillFillet, CanonicalRoundedRectangleExtrusion,
    CanonicalUnion,
)
from .package_v2_instance_transform import matvec, rotation_matrix
from .package_v2_orthogonal_domain_planning import root_boxes
from .package_v2_swept_fillet import clip_planes, widths_at


def _merge(bounds):
    bounds = tuple(bounds)
    if not bounds:
        raise ValueError("所选几何没有可计算坐标范围的实体。")
    return (tuple(min(box[0][axis] for box in bounds) for axis in range(3)),
            tuple(max(box[1][axis] for box in bounds) for axis in range(3)))


def _point_bounds(points, matrix):
    points = tuple(matvec(matrix, point) for point in points)
    if not points:
        raise ValueError("所选几何截取后没有可计算坐标范围的实体。")
    return (tuple(min(point[axis] for point in points) for axis in range(3)),
            tuple(max(point[axis] for point in points) for axis in range(3)))


def _polytope_vertices(planes):
    """Vertices of the small clipped straight rails and corner enclosing prisms."""
    normals = np.asarray([plane[0] for plane in planes], dtype=float)
    limits = np.asarray([plane[1] for plane in planes], dtype=float)
    scales = np.linalg.norm(normals, axis=1)
    normals, limits = normals / scales[:, None], limits / scales
    tolerance = 128 * np.finfo(float).eps * max(1., float(np.abs(limits).max()))
    for indices in combinations(range(len(planes)), 3):
        try:
            point = np.linalg.solve(normals[list(indices)], limits[list(indices)])
        except np.linalg.LinAlgError:
            continue
        if np.isfinite(point).all() and np.all(normals @ point <= limits + tolerance):
            yield tuple(point)


def _unit_roots(polynomial):
    coefficients = np.asarray(polynomial.coef)
    scale = float(np.abs(coefficients).max())
    if scale == 0.:
        return ()
    normalized = Polynomial(coefficients / scale).trim(tol=1.e-13)
    return tuple(min(1., max(0., float(root.real))) for root in normalized.roots()
                 if abs(root.imag) < 1.e-8 and -1.e-10 <= root.real <= 1. + 1.e-10)


def _corner_points(center, signs, bottom, top, z0, height, clips, directions):
    """Exact extrema candidates of one linearly swept quarter ellipse.

    cos(theta)=(1-u²)/(1+u²), sin(theta)=2u/(1+u²), 0<=u<=1.
    Coordinates are rational in u and linear in height fraction t. A linear
    objective reaches an endpoint of its feasible t interval: t=0/1 or an XY
    cut. On each such curve we include every stationary point and boundary.
    """
    cx, cy = center
    sx, sy = signs
    rx, ry = bottom
    dx, dy = top[0] - rx, top[1] - ry
    q, cosine, sine = Polynomial((1., 0., 1.)), Polynomial((1., 0., -1.)), Polynomial((0., 2.))
    base = (cx*q + sx*rx*cosine, cy*q + sy*ry*sine, z0*q)
    delta = (sx*dx*cosine, sy*dy*sine, height*q)
    scale = max(1., abs(cx), abs(cy), rx, ry, *top)
    tolerance = 256 * np.finfo(float).eps * scale
    candidates = []

    def add(u, t):
        if not isfinite(t) or t < -1.e-10 or t > 1. + 1.e-10:
            return
        t = min(1., max(0., t))
        point = tuple(float((a(u) + t*b(u)) / q(u)) for a, b in zip(base, delta))
        if all(sign * (point[axis] - coordinate) >= -tolerance for axis, coordinate, sign in clips):
            candidates.append(point)

    # A cut-plane cap can have vertices inside the ellipse (two cuts meeting
    # a horizontal cap). Include these in addition to the curved shell.
    planes = [((-1., 0., 0.), 0.), ((0., -1., 0.), 0.),
              ((1., 0., -dx), rx), ((0., 1., -dy), ry),
              ((0., 0., -1.), 0.), ((0., 0., 1.), 1.)]
    for axis, coordinate, sign in clips:
        normal = [0., 0., 0.]
        normal[axis] = -sign * signs[axis]
        planes.append((normal, sign * (center[axis] - coordinate)))
    for x, y, t in _polytope_vertices(planes):
        wx, wy = rx + t*dx, ry + t*dy
        def ratio(value, width):
            return value / width if width > 0. else (0. if abs(value) <= tolerance else float("inf"))
        if hypot(ratio(x, wx), ratio(y, wy)) <= 1. + 1.e-12:
            candidates.append((cx + sx*x, cy + sy*y, z0 + height*t))

    # Each curve stores t=N(u)/D(u), including the horizontal end caps.
    curves = [(Polynomial((t,)), Polynomial((1.,))) for t in (0., 1.)]
    for axis, coordinate, _ in clips:
        if np.any(delta[axis].coef):
            curves.append((coordinate*q - base[axis], delta[axis]))
    for numerator, denominator in curves:
        roots = {0., 1., *_unit_roots(numerator), *_unit_roots(numerator - denominator)}
        numerators = tuple(a*denominator + b*numerator for a, b in zip(base, delta))
        divisor = q * denominator
        for axis, coordinate, _ in clips:
            roots.update(_unit_roots(numerators[axis] - coordinate*divisor))
        for direction in directions:
            objective = sum((value*coefficient for value, coefficient in zip(numerators, direction)), Polynomial((0.,)))
            roots.update(_unit_roots(objective.deriv()*divisor - objective*divisor.deriv()))
        for u in roots:
            value = denominator(u)
            if value != 0.:
                add(u, float(numerator(u) / value))
    return candidates


def _fillet_points(root, directions):
    x0, y0 = root.die_origin_xy_mm
    x1, y1 = x0 + root.die_size_xy_mm[0], y0 + root.die_size_xy_mm[1]
    bottom, top = widths_at(root), widths_at(root, 1.)
    clips = clip_planes(root)
    z0, height = root.base_z_mm, root.wall_height_mm
    fixed = [((0., 0., -1.), 0.), ((0., 0., 1.), 1.)]
    for axis, coordinate, sign in clips:
        normal = [0., 0., 0.]
        normal[axis] = -sign
        fixed.append((normal, -sign*coordinate))
    points = []
    # Four straight side prisms; only their outer plane slopes with t.
    for axis, side, index in ((0, x0, 0), (0, x1, 1), (1, y0, 2), (1, y1, 3)):
        tangent = 1 - axis
        sign = -1 if index % 2 == 0 else 1
        limits = (y0, y1) if axis == 0 else (x0, x1)
        inner, outer, near, far = ([0., 0., 0.] for _ in range(4))
        inner[axis], outer[axis] = -sign, sign
        outer[2] = -(top[index] - bottom[index])
        near[tangent], far[tangent] = -1., 1.
        planes = [*fixed, (inner, -sign*side), (outer, sign*side + bottom[index]),
                  (near, -limits[0]), (far, limits[1])]
        points.extend((x, y, z0 + height*t) for x, y, t in _polytope_vertices(planes))
    for center, signs, indices in (((x0, y0), (-1, -1), (0, 2)),
                                    ((x1, y0), (1, -1), (1, 2)),
                                    ((x1, y1), (1, 1), (1, 3)),
                                    ((x0, y1), (-1, 1), (0, 3))):
        points.extend(_corner_points(center, signs, tuple(bottom[i] for i in indices),
                                     tuple(top[i] for i in indices), z0, height, clips, directions))
    return points


def _root_bounds(root, matrix):
    if isinstance(root, CanonicalUnion):
        return _merge(_root_bounds(child, matrix) for child in root.children)
    if isinstance(root, (CanonicalBox, CanonicalRectangularFrameExtrusion, CanonicalDifference)):
        def orthogonal(node):
            if isinstance(node, (CanonicalBox, CanonicalRectangularFrameExtrusion)):
                return True
            if isinstance(node, CanonicalUnion):
                return all(orthogonal(child) for child in node.children)
            if isinstance(node, CanonicalDifference):
                return all(orthogonal(child) for child in (node.base, *node.cutters))
            return False
        if not orthogonal(root):
            raise ValueError("含曲面布尔差集的精确坐标范围暂不可用。")
        try:
            boxes = root_boxes(root)
        except ValueError as error:
            raise ValueError("含曲面布尔差集的精确坐标范围暂不可用。") from error
        return _point_bounds((point for box in boxes for point in product(*box)), matrix)
    if isinstance(root, CanonicalRoundedRectangleExtrusion):
        x, y, z = root.origin_xyz_mm
        width, depth = root.size_xy_mm
        radius = root.corner_radius_mm
        center = (x + width/2, y + depth/2, z + root.height_mm/2)
        placed = matvec(matrix, center)
        extents = tuple(abs(row[0])*(width/2-radius) + abs(row[1])*(depth/2-radius)
                        + radius*hypot(row[0], row[1]) + abs(row[2])*root.height_mm/2
                        for row in matrix)
        return tuple(tuple(value + sign*extent for value, extent in zip(placed, extents))
                     for sign in (-1, 1))
    if isinstance(root, CanonicalRectangularUnderfillFillet):
        # A coordinate and its negative have the same stationary points.
        return _point_bounds(_fillet_points(root, matrix), matrix)
    raise ValueError(f"暂不支持此几何的精确坐标范围：{type(root).__name__}。")


def generated_component_bounds(instance, component_id, *, fragment_ids=None):
    """Bounds of a compiled component, or an exact subset of its fragments.

    Fragment placements already contain nested instance transforms. Apply them
    once, using the compiler's T + P + Rz Ry Rx (point - P) convention.
    """
    components = instance.geometry_result.geometry.components
    component = next((value for value in components if value.component_id == component_id), None)
    if component is None:
        raise ValueError(f"未找到 Component：{component_id}。")
    requested = None if fragment_ids is None else frozenset(fragment_ids)
    fragments = tuple(fragment for fragment in component.fragments
                      if requested is None or fragment.fragment_id in requested)
    if not fragments or (requested is not None and requested != {value.fragment_id for value in fragments}):
        raise ValueError("未找到所选实例的完整几何片段。")
    bounds = []
    for fragment in fragments:
        placement = fragment.placement
        matrix = rotation_matrix(placement.rotation_deg_xyz)
        pivot = placement.pivot_xyz_mm
        rotated_pivot = matvec(matrix, pivot)
        offset = tuple(placement.translation_xyz_mm[i] + pivot[i] - rotated_pivot[i] for i in range(3))
        local = _root_bounds(fragment.root, matrix)
        bounds.append(tuple(tuple(point[i] + offset[i] for i in range(3)) for point in local))
    result = _merge(bounds)
    if not all(isfinite(value) for point in result for value in point):
        raise ValueError("几何坐标范围超出可表示的数值范围。")
    return tuple(tuple(float(value) for value in point) for point in result)
