"""A compact Package action bar preserving the existing controller APIs."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget

from .designer_widgets import setup_form
from .ui_workflow_package_controls import Ui_WorkflowPackageControls


_JOB_ACTIONS = {
    "job_browse_action": "package_v2_job_browse_button",
    "job_create_action": "package_v2_create_job_button",
    "job_inspect_action": "package_v2_inspect_button",
    "job_execute_action": "package_v2_generate_button",
    "open_mesh_action": "package_v2_open_msh_button",
}
_GEOMETRY_ACTIONS = {
    "copy_instance_action": "package_v2_geometry_instance_button",
    "delete_instance_action": "package_v2_geometry_delete_button",
    "create_template_action": "package_v2_geometry_save_preset_button",
    "edit_template_action": "package_v2_template_edit_button",
    "import_template_action": "package_v2_geometry_insert_preset_button",
    "export_template_action": "package_v2_template_export_button",
    "delete_component_action": "package_v2_component_delete_button",
}


class WorkflowPackageControls(QWidget):
    def __init__(self, window, workflow):
        super().__init__(window.package_v2_tab)
        setup_form(self, Ui_WorkflowPackageControls)
        self.window = window
        self.workflow = workflow
        self._action_buttons = {}
        for action_name, button_name in {**_JOB_ACTIONS, **_GEOMETRY_ACTIONS}.items():
            action, button = getattr(self, action_name), getattr(window, button_name)
            action.triggered.connect(lambda _checked=False, target=button: target.click())
            self._action_buttons[action] = button
        self.resources_button.clicked.connect(lambda: self._invoke(workflow.show_connected))
        self.generate_button.clicked.connect(lambda: self._invoke(workflow.generate_package))
        self.cdb_button.clicked.connect(window.package_v2_cdb_button.click)
        self.more_button.setMenu(self.more_menu)
        self.geometry_more_button.setMenu(self.geometry_menu)
        self.more_menu.aboutToShow.connect(self.refresh)
        self.geometry_menu.aboutToShow.connect(self.refresh)
        self.show_details_action.toggled.connect(self.refresh)
        window.package_v2_tab_layout.insertWidget(0, self)
        geometry_layout = window.package_v2_geometry_actions_layout
        geometry_layout.addWidget(self.geometry_more_button, 0, 2, 1, 2, Qt.AlignmentFlag.AlignLeft)
        for column, stretch in enumerate((0, 0, 1, 0)):
            geometry_layout.setColumnStretch(column, stretch)
        self.refresh()

    def _invoke(self, callback):
        runner = getattr(self.workflow, "_run", None)
        runner(callback) if runner is not None else callback()

    def refresh(self, *_args):
        """Mirror existing enablement and keep advanced actions out of the form."""
        for action, button in self._action_buttons.items():
            action.setEnabled(button.isEnabled())
            action.setToolTip(button.toolTip())
            button.hide()
        self.window.package_v2_cdb_button.hide()
        self.cdb_button.setEnabled(self.window.package_v2_cdb_button.isEnabled())
        details = self.show_details_action.isChecked()
        for name in ("package_v2_job_path_label", "package_v2_job_path_edit",
                     "package_v2_identity_note_label"):
            getattr(self.window, name).setVisible(details)
        # Core refresh code can restore the original buttons' visibility; this
        # public hook runs after it and does not change their enabled state.
        self.geometry_more_button.setVisible(True)


def install_package_controls(window, workflow):
    existing = getattr(window, "_workflow_package_controls", None)
    if existing is not None:
        return existing
    controls = WorkflowPackageControls(window, workflow)
    window._workflow_package_controls = controls
    return controls


__all__ = ["WorkflowPackageControls", "install_package_controls"]
