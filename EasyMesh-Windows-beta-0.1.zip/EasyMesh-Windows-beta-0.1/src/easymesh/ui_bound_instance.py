# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'bound_instance.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QCheckBox, QComboBox,
    QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout,
    QLabel, QLineEdit, QScrollArea, QSizePolicy,
    QSplitter, QVBoxLayout, QWidget)

from easymesh.package_v2_draft_preview import DraftGeometryPreview
from easymesh.package_v2_expression_edit import ExpressionEdit

class Ui_BoundInstanceForm(object):
    def setupUi(self, BoundInstanceForm):
        if not BoundInstanceForm.objectName():
            BoundInstanceForm.setObjectName(u"BoundInstanceForm")
        BoundInstanceForm.resize(1150, 650)
        self.root_layout = QVBoxLayout(BoundInstanceForm)
        self.root_layout.setObjectName(u"root_layout")
        self.preview_splitter = QSplitter(BoundInstanceForm)
        self.preview_splitter.setObjectName(u"preview_splitter")
        self.preview_splitter.setChildrenCollapsible(False)
        self.preview_splitter.setOrientation(Qt.Horizontal)
        self.editor_page = QWidget(self.preview_splitter)
        self.editor_page.setObjectName(u"editor_page")
        self.editor_layout = QVBoxLayout(self.editor_page)
        self.editor_layout.setObjectName(u"editor_layout")
        self.editor_layout.setContentsMargins(0, 0, 0, 0)
        self.help_label = QLabel(self.editor_page)
        self.help_label.setObjectName(u"help_label")
        self.help_label.setWordWrap(True)
        self.help_label.setTextFormat(Qt.PlainText)

        self.editor_layout.addWidget(self.help_label)

        self.instance_form = QFormLayout()
        self.instance_form.setObjectName(u"instance_form")
        self.instance_form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        self.name_label = QLabel(self.editor_page)
        self.name_label.setObjectName(u"name_label")
        self.name_label.setWordWrap(True)
        self.name_label.setTextFormat(Qt.PlainText)

        self.instance_form.setWidget(0, QFormLayout.ItemRole.LabelRole, self.name_label)

        self.name_edit = QLineEdit(self.editor_page)
        self.name_edit.setObjectName(u"name_edit")

        self.instance_form.setWidget(0, QFormLayout.ItemRole.FieldRole, self.name_edit)

        self.template_label = QLabel(self.editor_page)
        self.template_label.setObjectName(u"template_label")
        self.template_label.setWordWrap(True)
        self.template_label.setTextFormat(Qt.PlainText)

        self.instance_form.setWidget(1, QFormLayout.ItemRole.LabelRole, self.template_label)

        self.template_combo = QComboBox(self.editor_page)
        self.template_combo.setObjectName(u"template_combo")

        self.instance_form.setWidget(1, QFormLayout.ItemRole.FieldRole, self.template_combo)


        self.editor_layout.addLayout(self.instance_form)

        self.parameter_scroll = QScrollArea(self.editor_page)
        self.parameter_scroll.setObjectName(u"parameter_scroll")
        self.parameter_scroll.setWidgetResizable(True)
        self.parameter_page = QWidget()
        self.parameter_page.setObjectName(u"parameter_page")
        self.parameter_form = QFormLayout(self.parameter_page)
        self.parameter_form.setObjectName(u"parameter_form")
        self.parameter_form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        self.parameter_scroll.setWidget(self.parameter_page)

        self.editor_layout.addWidget(self.parameter_scroll)

        self.pose_form = QFormLayout()
        self.pose_form.setObjectName(u"pose_form")
        self.pose_form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        self.origin_X_label = QLabel(self.editor_page)
        self.origin_X_label.setObjectName(u"origin_X_label")
        self.origin_X_label.setWordWrap(True)
        self.origin_X_label.setTextFormat(Qt.PlainText)

        self.pose_form.setWidget(0, QFormLayout.ItemRole.LabelRole, self.origin_X_label)

        self.origin_X_layout = QHBoxLayout()
        self.origin_X_layout.setObjectName(u"origin_X_layout")
        self.origin_x = ExpressionEdit(self.editor_page)
        self.origin_x.setObjectName(u"origin_x")

        self.origin_X_layout.addWidget(self.origin_x)

        self.rotation_X_label = QLabel(self.editor_page)
        self.rotation_X_label.setObjectName(u"rotation_X_label")
        self.rotation_X_label.setWordWrap(True)
        self.rotation_X_label.setTextFormat(Qt.PlainText)

        self.origin_X_layout.addWidget(self.rotation_X_label)

        self.rotation_x = QComboBox(self.editor_page)
        self.rotation_x.addItem("")
        self.rotation_x.addItem("")
        self.rotation_x.addItem("")
        self.rotation_x.addItem("")
        self.rotation_x.setObjectName(u"rotation_x")

        self.origin_X_layout.addWidget(self.rotation_x)

        self.mirror_x = QCheckBox(self.editor_page)
        self.mirror_x.setObjectName(u"mirror_x")

        self.origin_X_layout.addWidget(self.mirror_x)

        self.origin_X_layout.setStretch(0, 1)

        self.pose_form.setLayout(0, QFormLayout.ItemRole.FieldRole, self.origin_X_layout)

        self.origin_Y_label = QLabel(self.editor_page)
        self.origin_Y_label.setObjectName(u"origin_Y_label")
        self.origin_Y_label.setWordWrap(True)
        self.origin_Y_label.setTextFormat(Qt.PlainText)

        self.pose_form.setWidget(1, QFormLayout.ItemRole.LabelRole, self.origin_Y_label)

        self.origin_Y_layout = QHBoxLayout()
        self.origin_Y_layout.setObjectName(u"origin_Y_layout")
        self.origin_y = ExpressionEdit(self.editor_page)
        self.origin_y.setObjectName(u"origin_y")

        self.origin_Y_layout.addWidget(self.origin_y)

        self.rotation_Y_label = QLabel(self.editor_page)
        self.rotation_Y_label.setObjectName(u"rotation_Y_label")
        self.rotation_Y_label.setWordWrap(True)
        self.rotation_Y_label.setTextFormat(Qt.PlainText)

        self.origin_Y_layout.addWidget(self.rotation_Y_label)

        self.rotation_y = QComboBox(self.editor_page)
        self.rotation_y.addItem("")
        self.rotation_y.addItem("")
        self.rotation_y.addItem("")
        self.rotation_y.addItem("")
        self.rotation_y.setObjectName(u"rotation_y")

        self.origin_Y_layout.addWidget(self.rotation_y)

        self.mirror_y = QCheckBox(self.editor_page)
        self.mirror_y.setObjectName(u"mirror_y")

        self.origin_Y_layout.addWidget(self.mirror_y)

        self.origin_Y_layout.setStretch(0, 1)

        self.pose_form.setLayout(1, QFormLayout.ItemRole.FieldRole, self.origin_Y_layout)

        self.origin_Z_label = QLabel(self.editor_page)
        self.origin_Z_label.setObjectName(u"origin_Z_label")
        self.origin_Z_label.setWordWrap(True)
        self.origin_Z_label.setTextFormat(Qt.PlainText)

        self.pose_form.setWidget(2, QFormLayout.ItemRole.LabelRole, self.origin_Z_label)

        self.origin_Z_layout = QHBoxLayout()
        self.origin_Z_layout.setObjectName(u"origin_Z_layout")
        self.origin_z = ExpressionEdit(self.editor_page)
        self.origin_z.setObjectName(u"origin_z")

        self.origin_Z_layout.addWidget(self.origin_z)

        self.rotation_Z_label = QLabel(self.editor_page)
        self.rotation_Z_label.setObjectName(u"rotation_Z_label")
        self.rotation_Z_label.setWordWrap(True)
        self.rotation_Z_label.setTextFormat(Qt.PlainText)

        self.origin_Z_layout.addWidget(self.rotation_Z_label)

        self.rotation_z = QComboBox(self.editor_page)
        self.rotation_z.addItem("")
        self.rotation_z.addItem("")
        self.rotation_z.addItem("")
        self.rotation_z.addItem("")
        self.rotation_z.setObjectName(u"rotation_z")

        self.origin_Z_layout.addWidget(self.rotation_z)

        self.mirror_z = QCheckBox(self.editor_page)
        self.mirror_z.setObjectName(u"mirror_z")

        self.origin_Z_layout.addWidget(self.mirror_z)

        self.origin_Z_layout.setStretch(0, 1)

        self.pose_form.setLayout(2, QFormLayout.ItemRole.FieldRole, self.origin_Z_layout)

        self.component_label = QLabel(self.editor_page)
        self.component_label.setObjectName(u"component_label")
        self.component_label.setWordWrap(True)
        self.component_label.setTextFormat(Qt.PlainText)

        self.pose_form.setWidget(3, QFormLayout.ItemRole.LabelRole, self.component_label)

        self.component_combo = QComboBox(self.editor_page)
        self.component_combo.addItem("")
        self.component_combo.setObjectName(u"component_combo")

        self.pose_form.setWidget(3, QFormLayout.ItemRole.FieldRole, self.component_combo)

        self.component_name_label = QLabel(self.editor_page)
        self.component_name_label.setObjectName(u"component_name_label")
        self.component_name_label.setWordWrap(True)
        self.component_name_label.setTextFormat(Qt.PlainText)

        self.pose_form.setWidget(4, QFormLayout.ItemRole.LabelRole, self.component_name_label)

        self.component_name_edit = QLineEdit(self.editor_page)
        self.component_name_edit.setObjectName(u"component_name_edit")

        self.pose_form.setWidget(4, QFormLayout.ItemRole.FieldRole, self.component_name_edit)

        self.material_label = QLabel(self.editor_page)
        self.material_label.setObjectName(u"material_label")
        self.material_label.setWordWrap(True)
        self.material_label.setTextFormat(Qt.PlainText)

        self.pose_form.setWidget(5, QFormLayout.ItemRole.LabelRole, self.material_label)

        self.material_edit = QLineEdit(self.editor_page)
        self.material_edit.setObjectName(u"material_edit")

        self.pose_form.setWidget(5, QFormLayout.ItemRole.FieldRole, self.material_edit)


        self.editor_layout.addLayout(self.pose_form)

        self.status_label = QLabel(self.editor_page)
        self.status_label.setObjectName(u"status_label")
        self.status_label.setWordWrap(True)
        self.status_label.setTextFormat(Qt.PlainText)

        self.editor_layout.addWidget(self.status_label)

        self.buttons = QDialogButtonBox(self.editor_page)
        self.buttons.setObjectName(u"buttons")
        self.buttons.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.editor_layout.addWidget(self.buttons)

        self.editor_layout.setStretch(2, 1)
        self.preview_splitter.addWidget(self.editor_page)
        self.preview_panel = DraftGeometryPreview(self.preview_splitter)
        self.preview_panel.setObjectName(u"preview_panel")
        self.preview_splitter.addWidget(self.preview_panel)

        self.root_layout.addWidget(self.preview_splitter)


        self.retranslateUi(BoundInstanceForm)

        QMetaObject.connectSlotsByName(BoundInstanceForm)
    # setupUi

    def retranslateUi(self, BoundInstanceForm):
        BoundInstanceForm.setWindowTitle(QCoreApplication.translate("BoundInstanceForm", u"\u521b\u5efa\u5b9e\u4f8b", None))
        BoundInstanceForm.setProperty(u"editTitle", QCoreApplication.translate("BoundInstanceForm", u"\u7f16\u8f91\u5b9e\u4f8b", None))
        BoundInstanceForm.setProperty(u"duplicateTitle", QCoreApplication.translate("BoundInstanceForm", u"\u590d\u5236\u5b9e\u4f8b", None))
        self.help_label.setText(QCoreApplication.translate("BoundInstanceForm", u"\u4e3a\u6a21\u677f\u7684\u516c\u5f00 Local variables \u8d4b\u503c\u3002\u53ef\u586b\u5199\u6570\u503c\u6216 Global variable\u3002Origin \u662f\u6a21\u677f\u539f\u70b9\u5728\u5de5\u7a0b\u5750\u6807\u7cfb\u4e2d\u7684\u4f4d\u7f6e\u3002", None))
        self.help_label.setProperty(u"childText", QCoreApplication.translate("BoundInstanceForm", u"\u4e3a\u6a21\u677f\u7684\u516c\u5f00 Local variables \u8d4b\u503c\u3002\u53ef\u586b\u5199\u6570\u503c\u6216\u7236\u6a21\u677f\u7684 Local variable\u3002Origin \u4f7f\u7528\u7236\u6a21\u677f\u5c40\u90e8\u5750\u6807\u3002", None))
        self.name_label.setText(QCoreApplication.translate("BoundInstanceForm", u"\u5b9e\u4f8b\u540d\u79f0", None))
        self.template_label.setText(QCoreApplication.translate("BoundInstanceForm", u"\u4f7f\u7528\u6a21\u677f", None))
        self.origin_X_label.setText(QCoreApplication.translate("BoundInstanceForm", u"Origin X", None))
        self.origin_x.setPlaceholderText("")
        self.rotation_X_label.setText(QCoreApplication.translate("BoundInstanceForm", u"\u7ed5 X", None))
        self.rotation_x.setItemText(0, QCoreApplication.translate("BoundInstanceForm", u"0\u00b0", None))
        self.rotation_x.setItemText(1, QCoreApplication.translate("BoundInstanceForm", u"90\u00b0", None))
        self.rotation_x.setItemText(2, QCoreApplication.translate("BoundInstanceForm", u"180\u00b0", None))
        self.rotation_x.setItemText(3, QCoreApplication.translate("BoundInstanceForm", u"270\u00b0", None))

        self.mirror_x.setText(QCoreApplication.translate("BoundInstanceForm", u"\u955c\u50cf X", None))
#if QT_CONFIG(tooltip)
        self.mirror_x.setToolTip(QCoreApplication.translate("BoundInstanceForm", u"X \u5750\u6807\u53d6\u53cd\uff1b\u5148\u955c\u50cf\uff0c\u518d\u6309 X \u2192 Y \u2192 Z \u65cb\u8f6c\uff0c\u6700\u540e\u653e\u5230 Origin\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.origin_Y_label.setText(QCoreApplication.translate("BoundInstanceForm", u"Origin Y", None))
        self.origin_y.setPlaceholderText("")
        self.rotation_Y_label.setText(QCoreApplication.translate("BoundInstanceForm", u"\u7ed5 Y", None))
        self.rotation_y.setItemText(0, QCoreApplication.translate("BoundInstanceForm", u"0\u00b0", None))
        self.rotation_y.setItemText(1, QCoreApplication.translate("BoundInstanceForm", u"90\u00b0", None))
        self.rotation_y.setItemText(2, QCoreApplication.translate("BoundInstanceForm", u"180\u00b0", None))
        self.rotation_y.setItemText(3, QCoreApplication.translate("BoundInstanceForm", u"270\u00b0", None))

        self.mirror_y.setText(QCoreApplication.translate("BoundInstanceForm", u"\u955c\u50cf Y", None))
#if QT_CONFIG(tooltip)
        self.mirror_y.setToolTip(QCoreApplication.translate("BoundInstanceForm", u"Y \u5750\u6807\u53d6\u53cd\uff1b\u5148\u955c\u50cf\uff0c\u518d\u6309 X \u2192 Y \u2192 Z \u65cb\u8f6c\uff0c\u6700\u540e\u653e\u5230 Origin\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.origin_Z_label.setText(QCoreApplication.translate("BoundInstanceForm", u"Origin Z", None))
        self.origin_z.setPlaceholderText("")
        self.rotation_Z_label.setText(QCoreApplication.translate("BoundInstanceForm", u"\u7ed5 Z", None))
        self.rotation_z.setItemText(0, QCoreApplication.translate("BoundInstanceForm", u"0\u00b0", None))
        self.rotation_z.setItemText(1, QCoreApplication.translate("BoundInstanceForm", u"90\u00b0", None))
        self.rotation_z.setItemText(2, QCoreApplication.translate("BoundInstanceForm", u"180\u00b0", None))
        self.rotation_z.setItemText(3, QCoreApplication.translate("BoundInstanceForm", u"270\u00b0", None))

        self.mirror_z.setText(QCoreApplication.translate("BoundInstanceForm", u"\u955c\u50cf Z", None))
#if QT_CONFIG(tooltip)
        self.mirror_z.setToolTip(QCoreApplication.translate("BoundInstanceForm", u"Z \u5750\u6807\u53d6\u53cd\uff1b\u5148\u955c\u50cf\uff0c\u518d\u6309 X \u2192 Y \u2192 Z \u65cb\u8f6c\uff0c\u6700\u540e\u653e\u5230 Origin\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.component_label.setText(QCoreApplication.translate("BoundInstanceForm", u"\u6240\u5c5e Component", None))
        self.component_combo.setItemText(0, QCoreApplication.translate("BoundInstanceForm", u"\u65b0\u5efa Component", None))

        self.component_name_label.setText(QCoreApplication.translate("BoundInstanceForm", u"\u65b0 Component \u540d\u79f0", None))
        self.component_name_edit.setPlaceholderText(QCoreApplication.translate("BoundInstanceForm", u"\u7559\u7a7a\u5219\u4f7f\u7528\u5b9e\u4f8b\u540d\u79f0", None))
        self.material_label.setText(QCoreApplication.translate("BoundInstanceForm", u"\u6750\u6599", None))
        self.status_label.setText("")
        self.buttons.setProperty(u"acceptText", QCoreApplication.translate("BoundInstanceForm", u"\u521b\u5efa\u5b9e\u4f8b", None))
        self.buttons.setProperty(u"cancelText", QCoreApplication.translate("BoundInstanceForm", u"\u53d6\u6d88", None))
        self.buttons.setProperty(u"editText", QCoreApplication.translate("BoundInstanceForm", u"\u5e94\u7528", None))
        self.preview_panel.setProperty(u"caption", QCoreApplication.translate("BoundInstanceForm", u"\u5b9e\u4f8b\u9884\u89c8 \u00b7 \u4f7f\u7528\u5f53\u524d\u53c2\u6570\u7ed1\u5b9a\uff0c\u5750\u6807\u8f74\u8ddf\u968f\u5b9e\u4f8b\u5c40\u90e8\u539f\u70b9", None))
        self.preview_panel.setProperty(u"childCaption", QCoreApplication.translate("BoundInstanceForm", u"\u5b50\u5b9e\u4f8b\u9884\u89c8 \u00b7 \u4f7f\u7528\u7236\u6a21\u677f\u9ed8\u8ba4\u53c2\u6570\uff0c\u5750\u6807\u8f74\u8ddf\u968f\u5b50\u5b9e\u4f8b\u5c40\u90e8\u539f\u70b9", None))
    # retranslateUi
