"""Refresh layout references when their editable Layer recipes are regenerated."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import replace
import hashlib
import json
from pathlib import Path
from typing import Any

from .bump_layout import BumpLayout, BumpMeshTemplate
from .output_artifacts import sha256_file
from .sample_mesh import load_sample_mesh, validate_compatible_outer_boundaries
from .workflow_library import validate_workflow_library


def layer_recipe_fingerprint(layer: Mapping[str, Any]) -> str:
    """Match worker recipe identity while excluding source/output locations."""
    recipe = {key: value for key, value in layer.items()
              if key not in {"source_path", "output_path"}}
    return hashlib.sha256(json.dumps(recipe, sort_keys=True, ensure_ascii=False,
                                     allow_nan=False).encode()).hexdigest()


def _asset_path(asset: Mapping[str, Any]) -> Path:
    return Path(asset["mesh_path"]).expanduser().resolve()


def _valid_mesh(asset: Mapping[str, Any]) -> bool:
    try:
        path = _asset_path(asset)
        return path.is_file() and sha256_file(path) == asset["sha256"]
    except (OSError, ValueError):
        return False


def refresh_layout_template_assets(
    layout: BumpLayout,
    assets: Iterable[Mapping[str, Any]],
    library: object,
) -> BumpLayout:
    """Return an atomically refreshed layout, preserving all placement intent.

    Only references associated with a currently registered Layer template are
    advanced to that template's latest valid generated recipe. External meshes
    and removed templates remain independent historical inputs. No files are
    rewritten, and the original immutable layout survives every failed batch.

    Asset order is publication order. Matching mesh digests are checked before
    selecting a result; full outer-boundary validation runs only when paths
    change, with differing planar diameters explicitly allowed.
    """
    if not isinstance(layout, BumpLayout):
        raise TypeError("layout must be a BumpLayout")
    current_library = validate_workflow_library(library)
    recipes = {item["id"]: item for item in current_library["templates"]}
    records = tuple(assets)
    by_path: dict[Path, list[Mapping[str, Any]]] = {}
    for asset in records:
        by_path.setdefault(_asset_path(asset), []).append(asset)

    updated = []
    changed = False
    for declaration in layout.templates:
        original_path = declaration.mesh_path.expanduser().resolve()
        associated = by_path.get(original_path, [])
        identifiers = {item["template_id"] for item in associated if item.get("template_id")}
        if not identifiers:
            updated.append(declaration)
            continue
        if not identifiers.intersection(recipes):
            if not any(_valid_mesh(item) for item in associated):
                raise ValueError(f"布局模板“{declaration.alias}”的历史网格已缺失或被修改，请重新导入。")
            updated.append(declaration)
            continue
        if len(identifiers) > 1:
            names = "、".join(sorted(recipes[key]["name"] if key in recipes else key for key in identifiers))
            raise ValueError(
                f"布局模板“{declaration.alias}”同时对应多个模板（{names}）；"
                "请重新生成这些模板，并在布局中选择需要的模板后重试。"
            )
        template_id = next(iter(identifiers))
        template = recipes[template_id]
        fingerprint = layer_recipe_fingerprint(template["layer"])
        candidates = [item for item in reversed(records)
                      if item.get("template_id") == template_id
                      and item.get("kind") == "layer"
                      and item.get("layer_fingerprint") == fingerprint]
        selected = next((item for item in candidates if _valid_mesh(item)), None)
        if selected is None:
            raise ValueError(
                f"布局引用的模板“{template['name']}”（{declaration.alias}）尚无当前方案的有效网格；"
                "请在模板库生成此模板，再继续连接。"
            )
        path = _asset_path(selected)
        if path == original_path:
            updated.append(declaration)
        else:
            updated.append(BumpMeshTemplate(declaration.alias, path))
            changed = True
    if not changed:
        return layout
    candidate = replace(layout, templates=tuple(updated))
    try:
        validate_compatible_outer_boundaries(
            [load_sample_mesh(item.mesh_path) for item in candidate.templates],
            require_identical_radius=False,
        )
    except (OSError, ValueError) as error:
        raise ValueError(f"更新模板后的连接边界不兼容，请统一 Z 网格和外缘材料分层后重试：{error}") from error
    return candidate
