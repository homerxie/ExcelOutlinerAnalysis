if __name__ == "__main__":
    import multiprocessing

    multiprocessing.freeze_support()

from .entrypoint import main


if __name__ == "__main__":
    raise SystemExit(main())

