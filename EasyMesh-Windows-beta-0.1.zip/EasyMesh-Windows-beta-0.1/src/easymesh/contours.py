"""Concentric, X-aligned circular and stadium-shaped planar boundaries.

A stadium is the Minkowski sum of a horizontal segment and a disk.  Its
dimensions are full diameters, including both semicircular ends.  A circle is
the special case with equal long and short diameters.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Sequence


@dataclass(frozen=True, slots=True)
class StadiumContour:
    """A nondegenerate boundary centred at the origin, in microns."""

    long_diameter_um: float
    short_diameter_um: float

    def __post_init__(self) -> None:
        for name in ("long_diameter_um", "short_diameter_um"):
            value = float(getattr(self, name))
            if not math.isfinite(value):
                raise ValueError(f"{name} must be finite")
            object.__setattr__(self, name, value)
        if self.short_diameter_um <= 0.0:
            raise ValueError("short diameter must be greater than zero")
        if self.long_diameter_um < self.short_diameter_um:
            raise ValueError("long diameter must be at least the short diameter")

    @property
    def radius_um(self) -> float:
        """Radius of each end cap, also the short-axis reference radius."""

        return self.short_diameter_um * 0.5

    @property
    def long_radius_um(self) -> float:
        return self.long_diameter_um * 0.5

    @property
    def half_straight_um(self) -> float:
        return (self.long_diameter_um - self.short_diameter_um) * 0.5

    @property
    def is_circle(self) -> bool:
        return self.long_diameter_um == self.short_diameter_um

    @property
    def is_oblong(self) -> bool:
        return not self.is_circle

    @property
    def dimensions_um(self) -> tuple[float, float]:
        return self.long_diameter_um, self.short_diameter_um

    @property
    def area_um2(self) -> float:
        return (
            self.short_diameter_um
            * (self.long_diameter_um - self.short_diameter_um)
            + math.pi * self.radius_um**2
        )

    def contains_xy(
        self, x_um: float, y_um: float, *, tolerance_um: float = 0.0
    ) -> bool:
        """Whether a point lies inside or on this boundary.

        ``tolerance_um`` expands the distance test, rather than separately
        inflating a bounding box; circular ends therefore remain exact.
        """

        x, y, tolerance = float(x_um), float(y_um), float(tolerance_um)
        if not all(math.isfinite(value) for value in (x, y, tolerance)):
            raise ValueError("point coordinates and tolerance must be finite")
        if tolerance < 0.0:
            raise ValueError("tolerance_um must not be negative")
        return self.signed_distance_um(x, y) <= tolerance

    def signed_distance_um(self, x_um: float, y_um: float) -> float:
        """Signed Euclidean distance to the boundary, negative inside."""

        x, y = float(x_um), float(y_um)
        if not math.isfinite(x) or not math.isfinite(y):
            raise ValueError("point coordinates must be finite")
        dx = max(abs(x) - self.half_straight_um, 0.0)
        return math.hypot(dx, y) - self.radius_um

    def contains_point(
        self, point_um: Sequence[float], *, tolerance_um: float = 0.0
    ) -> bool:
        if len(point_um) != 2:
            raise ValueError("a planar point must have exactly two coordinates")
        return self.contains_xy(*point_um, tolerance_um=tolerance_um)

    def contains_contour(self, other: StadiumContour, *, strict: bool = False) -> bool:
        """Exact inclusion test for concentric, equally oriented stadia.

        The difference of their support functions is linear in |cos(theta)|.
        Checking its two endpoints is consequently sufficient; equal cap
        centres or equal increments in the two diameters are not required.
        """

        if strict:
            return (
                self.long_diameter_um > other.long_diameter_um
                and self.short_diameter_um > other.short_diameter_um
            )
        return (
            self.long_diameter_um >= other.long_diameter_um
            and self.short_diameter_um >= other.short_diameter_um
        )

    def offset(self, distance_um: float) -> StadiumContour:
        """Return a constant outward normal offset; negative values erode.

        An erosion that collapses the short diameter has no positive-area
        contour and is rejected.  A caller clipping a fully consumed band can
        represent that case without constructing a boundary.
        """

        distance = float(distance_um)
        if not math.isfinite(distance):
            raise ValueError("offset distance must be finite")
        if self.radius_um + distance <= 0.0:
            raise ValueError(
                f"offset {distance:g} um collapses contour {self}"
            )
        return StadiumContour(
            self.long_diameter_um + 2.0 * distance,
            self.short_diameter_um + 2.0 * distance,
        )

    def __str__(self) -> str:
        return f"{self.long_diameter_um:g} x {self.short_diameter_um:g} um"


def stadium_cell_spans_um(
    reference: StadiumContour, points_um: Sequence[Sequence[float]]
) -> tuple[float, float]:
    """Return a cell's normal and tangent spans relative to a stadium.

    Normal span is the range of vertex distances to the reference centreline
    segment. Tangent span projects every vertex onto the tangent evaluated at
    the vertex centroid. These are directional cell extents, not edge lengths
    or the layer builder's rail steps. Use the inner contour for an annulus
    and the current outer contour for its centre region.
    """
    points = tuple((float(point[0]), float(point[1])) for point in points_um)
    if len(points) < 3 or not all(math.isfinite(v) for point in points for v in point):
        raise ValueError("a cell requires at least three finite planar points")
    c = reference.half_straight_um
    distances = [math.hypot(max(abs(x) - c, 0.), y) for x, y in points]
    cx = sum(x for x, _y in points) / len(points)
    cy = sum(y for _x, y in points) / len(points)
    dx = cx - max(-c, min(c, cx))
    length = math.hypot(dx, cy)
    # The normal on the centreline itself is not unique. The Y direction
    # provides the natural frame for a centred rectangular cell.
    nx, ny = (dx / length, cy / length) if length else (0., 1.)
    projections = [-ny * x + nx * y for x, y in points]
    return max(distances) - min(distances), max(projections) - min(projections)


__all__ = ["StadiumContour", "stadium_cell_spans_um"]
