"""Read tabular bump coordinates without creating any mesh or GUI objects.

The first non-empty row is a header. Coordinates are returned in micrometres;
an explicit column unit (``x_mm``, ``Y (um)``) overrides the selected unit.
Excel imports read the first worksheet, including cached formula values, and
never evaluate a formula or load workbook macros.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
import io
import math
from pathlib import Path
import re
from typing import Iterable, Iterator, Sequence
import unicodedata
from xml.etree.ElementTree import ParseError
from zipfile import BadZipFile


_UNIT_TO_UM = {"nm": 0.001, "um": 1.0, "mm": 1000.0, "cm": 10000.0, "m": 1000000.0}
_AXIS_ALIASES = {
    "x": {"x", "xcoordinate", "xcoord", "x坐标", "坐标x", "横坐标"},
    "y": {"y", "ycoordinate", "ycoord", "y坐标", "坐标y", "纵坐标"},
}
_ANGLE_ALIASES = {
    "rotation", "rotationdeg", "rotationangle", "rotationangledeg",
    "angle", "angledeg", "theta", "thetadeg", "θ", "θdeg",
    "旋转", "旋转角度", "旋转角", "角度", "转角",
}


@dataclass(frozen=True, slots=True)
class CoordinateRow:
    """One imported bump centre in micrometres and rotation in degrees."""

    x_um: float
    y_um: float
    rotation_deg: float = 0.0


def _normalized(value: object) -> str:
    text = unicodedata.normalize("NFKC", str(value or "")).casefold()
    return text.replace("μ", "u").replace("微米", "um").replace("毫米", "mm").strip()


def _column_kind(value: object) -> tuple[str, str | None] | None:
    text = re.sub(r"[\s_\-()\[\]{}°/]+", "", _normalized(value))
    if text in _ANGLE_ALIASES:
        return "rotation", None
    # Longest unit first so "mm" is not mistaken for the suffix "m".
    for axis, aliases in _AXIS_ALIASES.items():
        if text in aliases:
            return axis, None
        for unit in sorted(_UNIT_TO_UM, key=len, reverse=True):
            if text.endswith(unit) and text[:-len(unit)] in aliases:
                return axis, unit
    return None


def _empty(value: object) -> bool:
    return value is None or (isinstance(value, str) and not value.strip())


def _finite_number(value: object, *, row: int, column: str) -> float:
    if _empty(value):
        raise ValueError(f"第 {row} 行：{column} 不能为空")
    try:
        if isinstance(value, bool):
            raise ValueError
        result = float(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise ValueError(f"第 {row} 行：{column} 必须是有限数值，当前为 {value!r}") from error
    if not math.isfinite(result):
        raise ValueError(f"第 {row} 行：{column} 必须是有限数值，当前为 {value!r}")
    return result


def _parse_rows(
    rows: Iterable[tuple[int, Sequence[object]]], *, unit: str,
) -> tuple[CoordinateRow, ...]:
    iterator = iter(rows)
    for header_row, header in iterator:
        if any(not _empty(value) for value in header):
            break
    else:
        raise ValueError("坐标文件为空；首行需要 x、y 列名")

    columns: dict[str, tuple[int, str | None]] = {}
    for index, value in enumerate(header):
        kind = _column_kind(value)
        if kind is None:
            continue
        name, column_unit = kind
        if name in columns:
            raise ValueError(f"第 {header_row} 行：重复的 {name} 列")
        columns[name] = (index, column_unit)
    missing = [axis for axis in ("x", "y") if axis not in columns]
    if missing:
        raise ValueError(f"第 {header_row} 行：缺少坐标列 {', '.join(missing)}；首行需要 x、y 列名")

    coordinates: list[CoordinateRow] = []
    for row_number, row in iterator:
        if all(_empty(value) for value in row):
            continue
        values: dict[str, float] = {"rotation": 0.0}
        for name, (index, column_unit) in columns.items():
            value = row[index] if index < len(row) else None
            if name == "rotation" and _empty(value):
                continue
            number = _finite_number(value, row=row_number, column=name)
            if name in {"x", "y"}:
                number *= _UNIT_TO_UM[column_unit or unit]
                if not math.isfinite(number):
                    raise ValueError(f"第 {row_number} 行：{name} 单位换算后超出有限数值范围")
            values[name] = number
        coordinates.append(CoordinateRow(values["x"], values["y"], values["rotation"]))
    if not coordinates:
        raise ValueError("坐标文件中没有 bump 数据行")
    return tuple(coordinates)


def _csv_rows(path: Path) -> Iterator[tuple[int, Sequence[object]]]:
    raw = path.read_bytes()
    encodings = ("utf-16",) if raw.startswith((b"\xff\xfe", b"\xfe\xff")) else (
        "utf-8-sig", "gb18030", "cp1252",
    )
    for encoding in encodings:
        try:
            text = raw.decode(encoding)
            break
        except UnicodeError:
            continue
    else:
        raise ValueError("无法解码 CSV；请使用 UTF-8、UTF-16 或 GB18030 编码")
    # Excel's locale-dependent CSV export can declare its delimiter explicitly.
    lines = text.splitlines(keepends=True)
    delimiter = "\t" if path.suffix.lower() == ".tsv" else ","
    offset = 0
    if lines and re.fullmatch(r"sep=([,;\t|])\s*", lines[0], re.IGNORECASE):
        delimiter = lines.pop(0)[4]
        text = "".join(lines)
        offset = 1
    else:
        # Use only the header for sniffing: optional trailing columns and blank
        # rows otherwise make csv.Sniffer reject perfectly usable exports.
        first = next((line for line in lines if line.strip()), "")
        try:
            delimiter = csv.Sniffer().sniff(first, delimiters=",;\t|").delimiter
        except csv.Error:
            pass
    reader = csv.reader(io.StringIO(text, newline=""), delimiter=delimiter,
                        skipinitialspace=True, strict=True)
    try:
        for row in reader:
            yield reader.line_num + offset, row
    except csv.Error as error:
        raise ValueError(f"第 {reader.line_num + offset} 行：CSV 格式错误：{error}") from error


def _xlsx_coordinates(path: Path, *, unit: str) -> tuple[CoordinateRow, ...]:
    try:
        from openpyxl import load_workbook
    except ImportError as error:
        raise ValueError("读取 .xlsx 需要 openpyxl；请安装项目 requirements.txt 中的依赖") from error
    try:
        workbook = load_workbook(path, read_only=True, data_only=True, keep_links=False)
    except (OSError, ValueError, KeyError, EOFError, BadZipFile, ParseError) as error:
        raise ValueError(f"无法读取 Excel 文件：{error}") from error
    try:
        if not workbook.worksheets:
            raise ValueError("Excel 文件中没有工作表")
        return _parse_rows(enumerate(workbook.worksheets[0].iter_rows(values_only=True), 1), unit=unit)
    finally:
        workbook.close()


def _xls_coordinates(path: Path, *, unit: str) -> tuple[CoordinateRow, ...]:
    try:
        import xlrd
    except ImportError as error:
        raise ValueError("读取 .xls 需要 xlrd；请安装项目 requirements.txt 中的依赖") from error
    try:
        workbook = xlrd.open_workbook(path, on_demand=True, logfile=io.StringIO())
    except (OSError, ValueError, xlrd.XLRDError) as error:
        raise ValueError(f"无法读取 Excel 文件：{error}") from error
    try:
        if not workbook.nsheets:
            raise ValueError("Excel 文件中没有工作表")
        sheet = workbook.sheet_by_index(0)

        def rows() -> Iterator[tuple[int, Sequence[object]]]:
            for index in range(sheet.nrows):
                values: list[object] = []
                for cell in sheet.row(index):
                    if cell.ctype == xlrd.XL_CELL_BOOLEAN:
                        values.append(bool(cell.value))
                    elif cell.ctype in {xlrd.XL_CELL_ERROR, xlrd.XL_CELL_DATE}:
                        # xlrd represents dates and formula errors as numbers;
                        # they must not silently become bump coordinates.
                        values.append(f"Excel {'日期' if cell.ctype == xlrd.XL_CELL_DATE else '错误'}")
                    else:
                        values.append(cell.value)
                yield index + 1, values

        return _parse_rows(rows(), unit=unit)
    finally:
        workbook.release_resources()


def read_layout_coordinates(path: str | Path, *, unit: str = "um") -> tuple[CoordinateRow, ...]:
    """Read CSV/TSV or the first XLSX/XLS worksheet into validated coordinates.

    Required headers are x/y (case insensitive); rotation, angle, theta and
    their degree/Chinese variants are optional. Missing angles default to 0.
    Extra columns and wholly empty rows are ignored. Invalid data raises
    ``ValueError`` with its source row, before returning any partial result.
    """

    normalized_unit = _normalized(unit)
    if normalized_unit not in _UNIT_TO_UM:
        raise ValueError(f"不支持坐标单位 {unit!r}；可用 nm、um、mm、cm、m")
    source = Path(path).expanduser()
    suffix = source.suffix.lower()
    if suffix in {".csv", ".tsv"}:
        return _parse_rows(_csv_rows(source), unit=normalized_unit)
    if suffix == ".xlsx":
        return _xlsx_coordinates(source, unit=normalized_unit)
    if suffix == ".xls":
        return _xls_coordinates(source, unit=normalized_unit)
    raise ValueError("请选择 .csv、.tsv、.xlsx 或 .xls 坐标文件")
