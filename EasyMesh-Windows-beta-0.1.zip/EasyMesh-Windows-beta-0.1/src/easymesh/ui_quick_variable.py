# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'quick_variable.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QComboBox, QDialog,
    QDialogButtonBox, QFormLayout, QLabel, QLineEdit,
    QSizePolicy, QVBoxLayout, QWidget)

from easymesh.package_v2_expression_edit import ExpressionEdit

class Ui_QuickVariableForm(object):
    def setupUi(self, QuickVariableForm):
        if not QuickVariableForm.objectName():
            QuickVariableForm.setObjectName(u"QuickVariableForm")
        QuickVariableForm.setMinimumSize(QSize(520, 0))
        self.root_layout = QVBoxLayout(QuickVariableForm)
        self.root_layout.setObjectName(u"root_layout")
        self.variable_form = QFormLayout()
        self.variable_form.setObjectName(u"variable_form")
        self.variable_form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        self.name_label = QLabel(QuickVariableForm)
        self.name_label.setObjectName(u"name_label")
        self.name_label.setWordWrap(True)
        self.name_label.setTextFormat(Qt.PlainText)

        self.variable_form.setWidget(0, QFormLayout.ItemRole.LabelRole, self.name_label)

        self.name_edit = QLineEdit(QuickVariableForm)
        self.name_edit.setObjectName(u"name_edit")

        self.variable_form.setWidget(0, QFormLayout.ItemRole.FieldRole, self.name_edit)

        self.dimension_label = QLabel(QuickVariableForm)
        self.dimension_label.setObjectName(u"dimension_label")
        self.dimension_label.setWordWrap(True)
        self.dimension_label.setTextFormat(Qt.PlainText)

        self.variable_form.setWidget(1, QFormLayout.ItemRole.LabelRole, self.dimension_label)

        self.dimension_combo = QComboBox(QuickVariableForm)
        self.dimension_combo.addItem("")
        self.dimension_combo.addItem("")
        self.dimension_combo.setObjectName(u"dimension_combo")

        self.variable_form.setWidget(1, QFormLayout.ItemRole.FieldRole, self.dimension_combo)

        self.unit_label = QLabel(QuickVariableForm)
        self.unit_label.setObjectName(u"unit_label")
        self.unit_label.setWordWrap(True)
        self.unit_label.setTextFormat(Qt.PlainText)

        self.variable_form.setWidget(2, QFormLayout.ItemRole.LabelRole, self.unit_label)

        self.unit_field = QComboBox(QuickVariableForm)
        self.unit_field.setObjectName(u"unit_field")

        self.variable_form.setWidget(2, QFormLayout.ItemRole.FieldRole, self.unit_field)

        self.value_label = QLabel(QuickVariableForm)
        self.value_label.setObjectName(u"value_label")
        self.value_label.setWordWrap(True)
        self.value_label.setTextFormat(Qt.PlainText)

        self.variable_form.setWidget(3, QFormLayout.ItemRole.LabelRole, self.value_label)

        self.value_edit = ExpressionEdit(QuickVariableForm)
        self.value_edit.setObjectName(u"value_edit")

        self.variable_form.setWidget(3, QFormLayout.ItemRole.FieldRole, self.value_edit)


        self.root_layout.addLayout(self.variable_form)

        self.status_label = QLabel(QuickVariableForm)
        self.status_label.setObjectName(u"status_label")
        self.status_label.setWordWrap(True)
        self.status_label.setTextFormat(Qt.PlainText)

        self.root_layout.addWidget(self.status_label)

        self.buttons = QDialogButtonBox(QuickVariableForm)
        self.buttons.setObjectName(u"buttons")
        self.buttons.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.root_layout.addWidget(self.buttons)


        self.retranslateUi(QuickVariableForm)

        QMetaObject.connectSlotsByName(QuickVariableForm)
    # setupUi

    def retranslateUi(self, QuickVariableForm):
        QuickVariableForm.setWindowTitle(QCoreApplication.translate("QuickVariableForm", u"\u5feb\u901f\u65b0\u589e Variable", None))
        QuickVariableForm.setProperty(u"derivedTitle", QCoreApplication.translate("QuickVariableForm", u"\u5feb\u901f\u65b0\u589e Derived Variable", None))
        self.name_label.setText(QCoreApplication.translate("QuickVariableForm", u"Name", None))
        self.name_edit.setPlaceholderText(QCoreApplication.translate("QuickVariableForm", u"\u4f8b\u5982 lid_width \u6216 half_lid_width", None))
        self.name_edit.setProperty(u"variableNameToolTip", QCoreApplication.translate("QuickVariableForm", u"\u53d8\u91cf\u540d\u53ea\u80fd\u5305\u542b\u82f1\u6587\u5b57\u6bcd\u3001\u6570\u5b57\u548c\u4e0b\u5212\u7ebf\uff0c\u4e0d\u80fd\u542b\u7a7a\u683c\uff0c\u4e14\u4e0d\u80fd\u4ee5\u6570\u5b57\u5f00\u5934\u3002", None))
        self.dimension_label.setText(QCoreApplication.translate("QuickVariableForm", u"Kind", None))
        self.dimension_combo.setItemText(0, QCoreApplication.translate("QuickVariableForm", u"Length\uff08\u957f\u5ea6\uff09", None))
        self.dimension_combo.setItemText(1, QCoreApplication.translate("QuickVariableForm", u"Dimensionless\uff08\u65e0\u91cf\u7eb2\uff09", None))

        self.unit_label.setText(QCoreApplication.translate("QuickVariableForm", u"Unit", None))
        self.value_label.setText(QCoreApplication.translate("QuickVariableForm", u"Default", None))
        self.value_label.setProperty(u"derivedText", QCoreApplication.translate("QuickVariableForm", u"Expression", None))
        self.value_edit.setPlaceholderText("")
        self.value_edit.setProperty(u"parameterToolTip", QCoreApplication.translate("QuickVariableForm", u"Length \u7684\u88f8\u6570\u5b57\u6309\u6240\u9009 Unit \u89e3\u91ca\uff1bParameter default \u4e0d\u80fd\u5f15\u7528\u53d8\u91cf\u3002", None))
        self.status_label.setText(QCoreApplication.translate("QuickVariableForm", u"\u8be5\u53d8\u91cf\u4f1a\u5148\u6682\u5b58\u5728 Geometry \u8868\u5355\u4e2d\uff0c\u6700\u7ec8\u4e0e Geometry \u4e00\u8d77\u7f16\u8bd1\u63d0\u4ea4\u3002", None))
        self.status_label.setProperty(u"commitText", QCoreApplication.translate("QuickVariableForm", u"\u53d8\u91cf\u6821\u9a8c\u901a\u8fc7\u540e\u52a0\u5165\u5de5\u7a0b\u8349\u7a3f\uff1b\u8bf7\u4fdd\u5b58 Source\u3002", None))
        self.buttons.setProperty(u"acceptText", QCoreApplication.translate("QuickVariableForm", u"\u6682\u5b58", None))
        self.buttons.setProperty(u"cancelText", QCoreApplication.translate("QuickVariableForm", u"\u53d6\u6d88", None))
        self.buttons.setProperty(u"commitText", QCoreApplication.translate("QuickVariableForm", u"\u6dfb\u52a0", None))
    # retranslateUi
