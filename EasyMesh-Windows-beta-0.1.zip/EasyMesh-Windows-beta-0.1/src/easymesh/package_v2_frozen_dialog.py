"""Add/edit Frozen mesh instances with absolute, persistent placement controls."""
from copy import deepcopy
from pathlib import Path

from PySide6.QtCore import QSignalBlocker, Signal
from PySide6.QtWidgets import QDialog, QDialogButtonBox, QFileDialog

from .designer_widgets import setup_form, dialog_button_texts
from .ui_frozen_mesh_instance import Ui_FrozenMeshInstanceForm
from .package_v2_expression_edit import configure_variable_name_edit
from .package_v2_instance_transform import IDENTITY, frozen_placement_controls
from .package_v2_instances import transform_values
from .package_v2_mesh_bounds import format_mesh_bounds
from .package_v2_mesh_bounds_controller import MeshBoundsController


from .package_v2_mesh_placement import MeshPlacementWidget  # Re-export for existing callers.


class FrozenMeshInstanceDialog(QDialog):
    submitRequested = Signal(object)

    def __init__(self, parent, editor, *, source_id=None):
        super().__init__(parent)
        self.source_editor = editor
        self.opened_raw_sha256 = editor.raw_sha256
        self.frozen_source_id = source_id
        self._sources = {source["id"]: source for source in editor.document["frozen_sources"]}
        self._original = deepcopy(self._sources[source_id]) if source_id is not None else None
        self._loading_source = False
        setup_form(self, Ui_FrozenMeshInstanceForm)
        self.bounds_controller = MeshBoundsController(self)
        self.bounds_controller.changed.connect(self._show_bounds)
        self.group_selector.changed.connect(self._request_bounds)
        if source_id is not None:
            self.setWindowTitle(self.property("editTitle"))
        for name in self._sources:
            self.reuse_combo.addItem(f"复用网格实例：{name}", name)
        self.reuse_combo.setVisible(source_id is None)
        self.reuse_label.setVisible(source_id is None)
        configure_variable_name_edit(self.source_id_edit)
        self.source_id_edit.setText(self._unique_name())
        self.artifact_edits = {"mesh": self.mesh_path_edit}
        self.browse_button.clicked.connect(lambda: self._choose_artifact("mesh"))
        self.fingerprint_widget.updateRequested.connect(self.group_selector.reload)
        self.mesh_path_edit.textChanged.connect(self._mesh_path_changed)
        self.finished.connect(self.group_selector.cancel)
        self.finished.connect(self.fingerprint_widget.cancel)
        self.finished.connect(self.bounds_controller.cancel)
        self.translation_edits = self.transform.translation_edits
        for edit in self.translation_edits:
            edit.textChanged.connect(self._request_bounds)
        for combo in self.transform.rotation_combos:
            combo.currentIndexChanged.connect(self._request_bounds)
        for check in self.transform.mirror_checks:
            check.toggled.connect(self._request_bounds)
        self.transform.replace_orientation_button.clicked.connect(self._request_bounds)
        dialog_button_texts(self.buttons, "editText" if source_id is not None else "acceptText")
        self.buttons.accepted.connect(self._submit)
        self.buttons.rejected.connect(self.reject)
        for edit in self.translation_edits:
            edit.returnPressed.connect(self._submit)
        self.reuse_combo.currentIndexChanged.connect(self._reuse_source)
        if self._original is not None:
            self._load_source(self._original)

    def _unique_name(self, base="frozen"):
        existing = set(self._sources) | {source["id"] for source in self.source_editor.document["instances"]}
        index = 1
        while f"{base}_{index}" in existing:
            index += 1
        return f"{base}_{index}"

    def _load_source(self, source):
        self._loading_source = True
        try:
            self.source_id_edit.setText(source["id"])
            for key, edit in self.artifact_edits.items():
                with QSignalBlocker(edit):
                    edit.setText(source["artifacts"][key])
            self._set_group_mesh(preferred=source["components"], immediate=True)
            self.transform.load_placement(source["placement"])
        finally:
            self._loading_source = False
        self._request_bounds()

    def _request_bounds(self, *_args):
        if self._loading_source:
            return
        selector = self.group_selector
        if selector.path is None:
            self.bounds_controller.clear("请先选择网格文件。")
            return
        if selector.loading:
            self.bounds_controller.clear("正在读取网格体分组…")
            return
        if selector.catalog is None:
            self.bounds_controller.clear("坐标范围暂不可用：无法读取网格体分组。")
            return
        try:
            components = selector.selected_components()
            placement = self.transform.placement()
            translation = transform_values(placement["translation"], (0, 0, 0),
                                           (False, False, False), ("0mm",) * 3)[0]
        except ValueError as error:
            self.bounds_controller.clear(f"坐标范围暂不可用：{error}")
            return
        self.bounds_controller.request(selector.path, components, translation,
                                       placement["rotation_matrix"])

    def _show_bounds(self, bounds, message):
        if bounds is None:
            self.bounds_label.setText(message or "坐标范围暂不可用。")
            return
        ranges = format_mesh_bounds(bounds)
        self.bounds_label.setText("\n".join(f"{axis}：{value}" for axis, value in zip("XYZ", ranges)))

    def _set_group_mesh(self, *, preferred=(), immediate=False):
        text = self.artifact_edits["mesh"].text().strip()
        root = self.source_editor.path.parent.resolve()
        path = (root / text).resolve() if text else None
        if path is not None and not path.is_relative_to(root):
            path = None
        reference = self._original or self._sources.get(self.reuse_combo.currentData())
        unchanged = bool(reference and text == reference["artifacts"]["mesh"])
        self.group_selector.set_mesh(path, preferred=preferred,
                                     preserve_unread=unchanged, immediate=immediate)
        self.fingerprint_widget.set_mesh(path,
            sha256=reference["artifacts"].get("sha256") if unchanged else None,
            immediate=immediate)

    def _mesh_path_changed(self):
        self._set_group_mesh()

    def _reuse_source(self):
        name = self.reuse_combo.currentData()
        if name is None:
            self._load_source({"id": self._unique_name(), "artifacts": dict.fromkeys(self.artifact_edits, ""),
                               "components": [],
                               "placement": {"translation": ["0mm"] * 3, "rotation_matrix": IDENTITY}})
        else:
            self._load_source(self._sources[name])
            self.source_id_edit.setText(self._unique_name(f"{name}_copy"))

    def _relative_artifact_path(self, text):
        root = self.source_editor.path.parent.resolve()
        path = (root / Path(text.strip())).resolve()
        try:
            relative = path.relative_to(root).as_posix()
        except ValueError:
            raise ValueError("文件必须位于 Source 所在目录或其子目录。请打开位于网格目录或其上级目录的 Source。")
        if not path.is_file():
            raise ValueError(f"文件不存在：{path}")
        return relative

    def _choose_artifact(self, key):
        selected, _ = QFileDialog.getOpenFileName(
            self, f"选择网格实例 {key}", str(self.source_editor.path.parent),
            "Gmsh mesh (*.msh)",
        )
        if not selected:
            return
        try:
            relative = self._relative_artifact_path(selected)
        except ValueError as error:
            self.show_compilation_error(error)
            return
        self.artifact_edits[key].setText(relative)
        if key == "mesh":
            self.group_selector.reload()
        self.error_label.clear()

    def show_compilation_error(self, error):
        self.error_label.setText(str(error))
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(True)

    def _submit(self):
        try:
            reference = self._original or self._sources.get(self.reuse_combo.currentData())
            artifacts = {}
            for key, edit in self.artifact_edits.items():
                # Existing immutable references can remain offline while users
                # edit placement; a changed/new file must exist on disk.
                text = edit.text().strip()
                artifacts[key] = text if reference and text == reference["artifacts"][key] else self._relative_artifact_path(text)
            offline = bool(self._original and artifacts["mesh"] == self._original["artifacts"]["mesh"]
                           and not (self.source_editor.path.parent / artifacts["mesh"]).exists())
            digest = self.fingerprint_widget.selected_sha256(allow_offline=offline)
            if digest is not None:
                artifacts["sha256"] = digest
            source = {"id": self.source_id_edit.text(), "artifacts": artifacts,
                      "components": self.group_selector.selected_components(),
                      "placement": self.transform.placement()}
            if self._original is None and "rotation" not in source["placement"]:
                controls = frozen_placement_controls(source["placement"])
                if controls is not None:
                    source["placement"]["rotation"], source["placement"]["mirrors"] = map(list, controls)
        except ValueError as error:
            self.show_compilation_error(error)
            return
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(False)
        self.submitRequested.emit(source)
