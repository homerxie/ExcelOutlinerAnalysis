# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mesh_placement.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QFormLayout,
    QHBoxLayout, QLabel, QPushButton, QSizePolicy,
    QVBoxLayout, QWidget)

from easymesh.package_v2_expression_edit import ExpressionEdit

class Ui_MeshPlacementForm(object):
    def setupUi(self, MeshPlacementForm):
        if not MeshPlacementForm.objectName():
            MeshPlacementForm.setObjectName(u"MeshPlacementForm")
        self.root_layout = QVBoxLayout(MeshPlacementForm)
        self.root_layout.setObjectName(u"root_layout")
        self.root_layout.setContentsMargins(0, 0, 0, 0)
        self.help_label = QLabel(MeshPlacementForm)
        self.help_label.setObjectName(u"help_label")
        self.help_label.setWordWrap(True)
        self.help_label.setTextFormat(Qt.PlainText)

        self.root_layout.addWidget(self.help_label)

        self.placement_form = QFormLayout()
        self.placement_form.setObjectName(u"placement_form")
        self.placement_form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        self.position_X_label = QLabel(MeshPlacementForm)
        self.position_X_label.setObjectName(u"position_X_label")
        self.position_X_label.setWordWrap(True)
        self.position_X_label.setTextFormat(Qt.PlainText)

        self.placement_form.setWidget(0, QFormLayout.ItemRole.LabelRole, self.position_X_label)

        self.translation_x = ExpressionEdit(MeshPlacementForm)
        self.translation_x.setObjectName(u"translation_x")

        self.placement_form.setWidget(0, QFormLayout.ItemRole.FieldRole, self.translation_x)

        self.rotation_X_label = QLabel(MeshPlacementForm)
        self.rotation_X_label.setObjectName(u"rotation_X_label")
        self.rotation_X_label.setWordWrap(True)
        self.rotation_X_label.setTextFormat(Qt.PlainText)

        self.placement_form.setWidget(1, QFormLayout.ItemRole.LabelRole, self.rotation_X_label)

        self.rotation_X_layout = QHBoxLayout()
        self.rotation_X_layout.setObjectName(u"rotation_X_layout")
        self.rotation_x = QComboBox(MeshPlacementForm)
        self.rotation_x.addItem("")
        self.rotation_x.addItem("")
        self.rotation_x.addItem("")
        self.rotation_x.addItem("")
        self.rotation_x.setObjectName(u"rotation_x")

        self.rotation_X_layout.addWidget(self.rotation_x)

        self.mirror_x = QCheckBox(MeshPlacementForm)
        self.mirror_x.setObjectName(u"mirror_x")

        self.rotation_X_layout.addWidget(self.mirror_x)

        self.rotation_X_layout.setStretch(0, 1)

        self.placement_form.setLayout(1, QFormLayout.ItemRole.FieldRole, self.rotation_X_layout)

        self.position_Y_label = QLabel(MeshPlacementForm)
        self.position_Y_label.setObjectName(u"position_Y_label")
        self.position_Y_label.setWordWrap(True)
        self.position_Y_label.setTextFormat(Qt.PlainText)

        self.placement_form.setWidget(2, QFormLayout.ItemRole.LabelRole, self.position_Y_label)

        self.translation_y = ExpressionEdit(MeshPlacementForm)
        self.translation_y.setObjectName(u"translation_y")

        self.placement_form.setWidget(2, QFormLayout.ItemRole.FieldRole, self.translation_y)

        self.rotation_Y_label = QLabel(MeshPlacementForm)
        self.rotation_Y_label.setObjectName(u"rotation_Y_label")
        self.rotation_Y_label.setWordWrap(True)
        self.rotation_Y_label.setTextFormat(Qt.PlainText)

        self.placement_form.setWidget(3, QFormLayout.ItemRole.LabelRole, self.rotation_Y_label)

        self.rotation_Y_layout = QHBoxLayout()
        self.rotation_Y_layout.setObjectName(u"rotation_Y_layout")
        self.rotation_y = QComboBox(MeshPlacementForm)
        self.rotation_y.addItem("")
        self.rotation_y.addItem("")
        self.rotation_y.addItem("")
        self.rotation_y.addItem("")
        self.rotation_y.setObjectName(u"rotation_y")

        self.rotation_Y_layout.addWidget(self.rotation_y)

        self.mirror_y = QCheckBox(MeshPlacementForm)
        self.mirror_y.setObjectName(u"mirror_y")

        self.rotation_Y_layout.addWidget(self.mirror_y)

        self.rotation_Y_layout.setStretch(0, 1)

        self.placement_form.setLayout(3, QFormLayout.ItemRole.FieldRole, self.rotation_Y_layout)

        self.position_Z_label = QLabel(MeshPlacementForm)
        self.position_Z_label.setObjectName(u"position_Z_label")
        self.position_Z_label.setWordWrap(True)
        self.position_Z_label.setTextFormat(Qt.PlainText)

        self.placement_form.setWidget(4, QFormLayout.ItemRole.LabelRole, self.position_Z_label)

        self.translation_z = ExpressionEdit(MeshPlacementForm)
        self.translation_z.setObjectName(u"translation_z")

        self.placement_form.setWidget(4, QFormLayout.ItemRole.FieldRole, self.translation_z)

        self.rotation_Z_label = QLabel(MeshPlacementForm)
        self.rotation_Z_label.setObjectName(u"rotation_Z_label")
        self.rotation_Z_label.setWordWrap(True)
        self.rotation_Z_label.setTextFormat(Qt.PlainText)

        self.placement_form.setWidget(5, QFormLayout.ItemRole.LabelRole, self.rotation_Z_label)

        self.rotation_Z_layout = QHBoxLayout()
        self.rotation_Z_layout.setObjectName(u"rotation_Z_layout")
        self.rotation_z = QComboBox(MeshPlacementForm)
        self.rotation_z.addItem("")
        self.rotation_z.addItem("")
        self.rotation_z.addItem("")
        self.rotation_z.addItem("")
        self.rotation_z.setObjectName(u"rotation_z")

        self.rotation_Z_layout.addWidget(self.rotation_z)

        self.mirror_z = QCheckBox(MeshPlacementForm)
        self.mirror_z.setObjectName(u"mirror_z")

        self.rotation_Z_layout.addWidget(self.mirror_z)

        self.rotation_Z_layout.setStretch(0, 1)

        self.placement_form.setLayout(5, QFormLayout.ItemRole.FieldRole, self.rotation_Z_layout)


        self.root_layout.addLayout(self.placement_form)

        self.custom_label = QLabel(MeshPlacementForm)
        self.custom_label.setObjectName(u"custom_label")
        self.custom_label.setWordWrap(True)
        self.custom_label.setTextFormat(Qt.PlainText)

        self.root_layout.addWidget(self.custom_label)

        self.replace_orientation_button = QPushButton(MeshPlacementForm)
        self.replace_orientation_button.setObjectName(u"replace_orientation_button")

        self.root_layout.addWidget(self.replace_orientation_button)


        self.retranslateUi(MeshPlacementForm)

        QMetaObject.connectSlotsByName(MeshPlacementForm)
    # setupUi

    def retranslateUi(self, MeshPlacementForm):
        self.help_label.setText(QCoreApplication.translate("MeshPlacementForm", u"\u7f51\u683c\u539f\u70b9\u5728\u5168\u5c40\u5750\u6807\u4e2d\u7684\u4f4d\u7f6e\u3002\u5148\u5173\u4e8e\u7f51\u683c\u5c40\u90e8\u539f\u70b9\u955c\u50cf\uff0c\u518d\u7ed5\u5c40\u90e8 X \u2192 Y \u2192 Z \u65cb\u8f6c\uff0c\u6700\u540e\u653e\u5230\u6307\u5b9a\u4f4d\u7f6e\uff1b\u6b63\u89d2\u5ea6\u9075\u5faa\u53f3\u624b\u89c4\u5219\u3002", None))
        self.position_X_label.setText(QCoreApplication.translate("MeshPlacementForm", u"\u4f4d\u7f6e X", None))
        self.translation_x.setPlaceholderText("")
        self.translation_x.setText(QCoreApplication.translate("MeshPlacementForm", u"0mm", None))
#if QT_CONFIG(tooltip)
        self.translation_x.setToolTip(QCoreApplication.translate("MeshPlacementForm", u"\u7f51\u683c\u5c40\u90e8\u539f\u70b9\u5728\u5168\u5c40 X \u8f74\u4e0a\u7684\u5750\u6807\uff1b\u652f\u6301 mm\u3001um \u548c\u5e38\u91cf\u516c\u5f0f\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.rotation_X_label.setText(QCoreApplication.translate("MeshPlacementForm", u"\u7ed5 X \u65cb\u8f6c", None))
        self.rotation_x.setItemText(0, QCoreApplication.translate("MeshPlacementForm", u"0\u00b0", None))
        self.rotation_x.setItemText(1, QCoreApplication.translate("MeshPlacementForm", u"90\u00b0", None))
        self.rotation_x.setItemText(2, QCoreApplication.translate("MeshPlacementForm", u"180\u00b0", None))
        self.rotation_x.setItemText(3, QCoreApplication.translate("MeshPlacementForm", u"270\u00b0", None))

        self.mirror_x.setText(QCoreApplication.translate("MeshPlacementForm", u"\u955c\u50cf X", None))
#if QT_CONFIG(tooltip)
        self.mirror_x.setToolTip(QCoreApplication.translate("MeshPlacementForm", u"\u5173\u4e8e\u7f51\u683c\u5c40\u90e8 YZ \u5e73\u9762\u955c\u50cf\uff0c\u5373\u5c40\u90e8 X \u5750\u6807\u53d6\u53cd\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.position_Y_label.setText(QCoreApplication.translate("MeshPlacementForm", u"\u4f4d\u7f6e Y", None))
        self.translation_y.setPlaceholderText("")
        self.translation_y.setText(QCoreApplication.translate("MeshPlacementForm", u"0mm", None))
#if QT_CONFIG(tooltip)
        self.translation_y.setToolTip(QCoreApplication.translate("MeshPlacementForm", u"\u7f51\u683c\u5c40\u90e8\u539f\u70b9\u5728\u5168\u5c40 Y \u8f74\u4e0a\u7684\u5750\u6807\uff1b\u652f\u6301 mm\u3001um \u548c\u5e38\u91cf\u516c\u5f0f\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.rotation_Y_label.setText(QCoreApplication.translate("MeshPlacementForm", u"\u7ed5 Y \u65cb\u8f6c", None))
        self.rotation_y.setItemText(0, QCoreApplication.translate("MeshPlacementForm", u"0\u00b0", None))
        self.rotation_y.setItemText(1, QCoreApplication.translate("MeshPlacementForm", u"90\u00b0", None))
        self.rotation_y.setItemText(2, QCoreApplication.translate("MeshPlacementForm", u"180\u00b0", None))
        self.rotation_y.setItemText(3, QCoreApplication.translate("MeshPlacementForm", u"270\u00b0", None))

        self.mirror_y.setText(QCoreApplication.translate("MeshPlacementForm", u"\u955c\u50cf Y", None))
#if QT_CONFIG(tooltip)
        self.mirror_y.setToolTip(QCoreApplication.translate("MeshPlacementForm", u"\u5173\u4e8e\u7f51\u683c\u5c40\u90e8 XZ \u5e73\u9762\u955c\u50cf\uff0c\u5373\u5c40\u90e8 Y \u5750\u6807\u53d6\u53cd\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.position_Z_label.setText(QCoreApplication.translate("MeshPlacementForm", u"\u4f4d\u7f6e Z", None))
        self.translation_z.setPlaceholderText("")
        self.translation_z.setText(QCoreApplication.translate("MeshPlacementForm", u"0mm", None))
#if QT_CONFIG(tooltip)
        self.translation_z.setToolTip(QCoreApplication.translate("MeshPlacementForm", u"\u7f51\u683c\u5c40\u90e8\u539f\u70b9\u5728\u5168\u5c40 Z \u8f74\u4e0a\u7684\u5750\u6807\uff1b\u652f\u6301 mm\u3001um \u548c\u5e38\u91cf\u516c\u5f0f\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.rotation_Z_label.setText(QCoreApplication.translate("MeshPlacementForm", u"\u7ed5 Z \u65cb\u8f6c", None))
        self.rotation_z.setItemText(0, QCoreApplication.translate("MeshPlacementForm", u"0\u00b0", None))
        self.rotation_z.setItemText(1, QCoreApplication.translate("MeshPlacementForm", u"90\u00b0", None))
        self.rotation_z.setItemText(2, QCoreApplication.translate("MeshPlacementForm", u"180\u00b0", None))
        self.rotation_z.setItemText(3, QCoreApplication.translate("MeshPlacementForm", u"270\u00b0", None))

        self.mirror_z.setText(QCoreApplication.translate("MeshPlacementForm", u"\u955c\u50cf Z", None))
#if QT_CONFIG(tooltip)
        self.mirror_z.setToolTip(QCoreApplication.translate("MeshPlacementForm", u"\u5173\u4e8e\u7f51\u683c\u5c40\u90e8 XY \u5e73\u9762\u955c\u50cf\uff0c\u5373\u5c40\u90e8 Z \u5750\u6807\u53d6\u53cd\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.custom_label.setText("")
        self.replace_orientation_button.setText(QCoreApplication.translate("MeshPlacementForm", u"\u6539\u7528\u76f4\u89d2\u65cb\u8f6c / \u955c\u50cf\u8bbe\u7f6e", None))
        pass
    # retranslateUi
