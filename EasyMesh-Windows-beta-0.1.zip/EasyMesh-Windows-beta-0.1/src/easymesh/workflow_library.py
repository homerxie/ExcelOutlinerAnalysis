"""Editable Layer templates shared by the sequential GUI workflow.

The library embeds source text and all mesh controls, so a template does not
depend on an exported mesh or an external ``.layer`` file.  Drafts can be saved;
operations which promise a usable mesh validate through the existing Layer
parameter implementation.  All edits return new values and leave their input
untouched, including when validation fails part way through a batch.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
import math
from typing import Any
from uuid import uuid4

from .axisymmetric import AxisymmetricMeshParameters
from .layer_sweep import LayerSweepPolicy
from .parameters import MAX_NUMERICAL_LENGTH_UM
from .section import LayerMode


WORKFLOW_LIBRARY_SCHEMA = "easymesh-workflow-library-v1"


def _layer_state(value: object) -> dict[str, Any]:
    # Project snapshots also embed a library. Keep this dependency lazy so
    # project validation can call our validator without an import cycle.
    from .project_file import validate_layer_mesh_state

    return validate_layer_mesh_state(value)


def _nonempty_text(value: object, label: str) -> str:
    if not isinstance(value, str) or not value.strip() or "\x00" in value:
        raise ValueError(f"{label}不能为空")
    return value.strip()


def _positive_number(value: object, label: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{label}必须是有限的正数") from error
    if isinstance(value, bool) or not math.isfinite(result) or result <= 0:
        raise ValueError(f"{label}必须是有限的正数")
    return result


def empty_workflow_library() -> dict[str, Any]:
    return {
        "schema": WORKFLOW_LIBRARY_SCHEMA,
        "templates": [],
        "active_template_id": None,
    }


def validate_workflow_library(value: object) -> dict[str, Any]:
    """Return a canonical independent snapshot, retaining incomplete drafts."""
    if not isinstance(value, Mapping) or set(value) != {
        "schema", "templates", "active_template_id",
    }:
        raise ValueError("模板库字段不完整或包含不支持的字段")
    if value["schema"] != WORKFLOW_LIBRARY_SCHEMA:
        raise ValueError("不支持的模板库版本")
    if not isinstance(value["templates"], list):
        raise ValueError("模板库 templates 必须是列表")
    templates = []
    identifiers: set[str] = set()
    names: set[str] = set()
    for item in value["templates"]:
        if not isinstance(item, Mapping) or set(item) != {"id", "name", "layer"}:
            raise ValueError("模板必须包含 id、name 和 layer")
        identifier = _nonempty_text(item["id"], "模板标识")
        name = _nonempty_text(item["name"], "模板名称")
        if identifier in identifiers:
            raise ValueError(f"重复的模板标识：{identifier}")
        if name in names:
            raise ValueError(f"重复的模板名称：{name}")
        identifiers.add(identifier)
        names.add(name)
        templates.append({"id": identifier, "name": name, "layer": _layer_state(item["layer"])})
    active = value["active_template_id"]
    if active is not None and (not isinstance(active, str) or active not in identifiers):
        raise ValueError("当前模板不在模板库中")
    return {"schema": WORKFLOW_LIBRARY_SCHEMA, "templates": templates, "active_template_id": active}


def _template(library: dict[str, Any], template_id: str) -> dict[str, Any]:
    for item in library["templates"]:
        if item["id"] == template_id:
            return item
    raise ValueError(f"找不到模板：{template_id}")


def _selected(library: dict[str, Any], template_ids: Iterable[str]) -> list[dict[str, Any]]:
    if isinstance(template_ids, (str, bytes)):
        raise ValueError("请选择模板列表")
    identifiers = list(dict.fromkeys(template_ids))
    if not identifiers:
        raise ValueError("请至少选择一个模板")
    return [_template(library, identifier) for identifier in identifiers]


def add_layer_template(library: object, name: str, layer_state: object) -> dict[str, Any]:
    result = validate_workflow_library(library)
    identifier = uuid4().hex
    result["templates"].append({"id": identifier, "name": name, "layer": _layer_state(layer_state)})
    result["active_template_id"] = identifier
    return validate_workflow_library(result)


def update_layer_template(library: object, template_id: str, layer_state: object) -> dict[str, Any]:
    """Save one template's independent geometry, controls and draft text."""
    result = validate_workflow_library(library)
    _template(result, template_id)["layer"] = _layer_state(layer_state)
    return result


def duplicate_layer_template(library: object, template_id: str, name: str | None = None) -> dict[str, Any]:
    result = validate_workflow_library(library)
    source = _template(result, template_id)
    if name is None:
        base = f"{source['name']}（副本）"
        names = {item["name"] for item in result["templates"]}
        name = base
        suffix = 2
        while name in names:
            name = f"{base} {suffix}"
            suffix += 1
    return add_layer_template(result, name, source["layer"])


def rename_layer_template(library: object, template_id: str, name: str) -> dict[str, Any]:
    result = validate_workflow_library(library)
    _template(result, template_id)["name"] = name
    return validate_workflow_library(result)


def remove_layer_templates(library: object, template_ids: Iterable[str]) -> dict[str, Any]:
    result = validate_workflow_library(library)
    identifiers = {item["id"] for item in _selected(result, template_ids)}
    result["templates"] = [item for item in result["templates"] if item["id"] not in identifiers]
    if result["active_template_id"] in identifiers:
        result["active_template_id"] = result["templates"][0]["id"] if result["templates"] else None
    return result


def layer_state_parameters(state: object) -> AxisymmetricMeshParameters:
    """Compile an editable state through the same validator as mesh generation."""
    state = _layer_state(state)
    return AxisymmetricMeshParameters.from_dict({
        "layer_text": state["source_text"],
        "target_xy_um": state["target_xy_text"],
        "target_angular_um": state["target_angular_text"],
        "target_z_um": state["target_z_text"],
        "symmetry_mode": state["symmetry_mode"],
        "canonical_ring_mesh": state["canonical_ring_mesh"],
        "z_sweep": state["z_sweep"],
        "z_sweep_overrides": state["z_sweep_overrides"],
        "radial_sweep_overrides": state["radial_sweep_overrides"],
        "overrides": [
            {
                "axis": item["axis"], "start_um": item["start_um"],
                "end_um": item["end_um"], "size_um": item["text"],
            }
            for item in state["local_size_inputs"] if item["text"].strip()
        ],
    })


def template_z_levels_um(template: Mapping[str, Any]) -> tuple[float, ...]:
    return layer_state_parameters(template["layer"]).z_levels_um


def _matching_levels(schedules: Iterable[tuple[float, ...]]) -> bool:
    schedules = list(schedules)
    if not schedules:
        return False
    reference = schedules[0]
    return all(
        len(levels) == len(reference)
        and all(math.isclose(a, b, rel_tol=0.0, abs_tol=1e-9) for a, b in zip(reference, levels))
        for levels in schedules[1:]
    )


def templates_have_matching_z(templates: Iterable[Mapping[str, Any]]) -> bool:
    """Compare actual sweep levels; equal total thickness alone is insufficient."""
    try:
        return _matching_levels(template_z_levels_um(item) for item in templates)
    except (TypeError, ValueError, KeyError):
        return False


def validate_layer_mesh_z_compatibility(named_states: Iterable[tuple[str, object]]) -> None:
    """Check actual Z nodes, including local sizing and sweep policies, before import."""
    reference_name = None
    reference = None
    for name, state in named_states:
        try:
            # Run the existing Z planner with coarse planar placeholders. XY
            # sizing drafts and local planar controls do not affect Z nodes;
            # the original recipe and its planar values remain untouched.
            height_state = _layer_state(state)
            height_state["target_xy_text"] = str(MAX_NUMERICAL_LENGTH_UM)
            height_state["target_angular_text"] = str(MAX_NUMERICAL_LENGTH_UM)
            height_state["radial_sweep_overrides"] = []
            height_state["local_size_inputs"] = [
                item for item in height_state["local_size_inputs"] if item["axis"] == "z"]
            levels = layer_state_parameters(height_state).z_levels_um
        except (TypeError, ValueError) as error:
            raise ValueError(f"方案“{name}”无法检查高度网格：{error}") from error
        if reference is None:
            reference_name, reference = name, levels
            continue
        if _matching_levels((reference, levels)):
            continue
        if not math.isclose(reference[-1], levels[-1], rel_tol=0.0, abs_tol=1e-9):
            detail = f"总高度分别为 {reference[-1]:.12g} / {levels[-1]:.12g} µm"
        elif len(reference) != len(levels):
            detail = f"Z 节点数分别为 {len(reference)} / {len(levels)}"
        else:
            index = next(index for index, (a, b) in enumerate(zip(reference, levels))
                         if not math.isclose(a, b, rel_tol=0.0, abs_tol=1e-9))
            detail = f"第 {index + 1} 个 Z 节点分别为 {reference[index]:.12g} / {levels[index]:.12g} µm"
        raise ValueError(
            f"高度网格不兼容：“{reference_name}”与“{name}”的{detail}。"
            "请统一模板库与导入方案的高度分层和 Z 网格后重试；本次未追加任何方案。")


def batch_set_template_z_size(library: object, template_ids: Iterable[str], target_z_um: float) -> dict[str, Any]:
    """Apply a common uniform Z policy, or reject the entire incompatible batch.

    Existing local Z sizes and sweep directions are replaced intentionally.
    Each template retains its material boundaries, planar controls and geometry.
    Compatibility is checked on the resulting levels, not merely target size or
    overall height, so interior boundaries cannot silently produce mismatches.
    """
    target = _positive_number(target_z_um, "Z 网格尺寸")
    result = validate_workflow_library(library)
    selected = _selected(result, template_ids)
    schedules = []
    for item in selected:
        state = item["layer"]
        state["target_z_text"] = format(target, ".17g")
        state["z_sweep"] = LayerSweepPolicy().to_dict()
        state["z_sweep_overrides"] = []
        state["local_size_inputs"] = [entry for entry in state["local_size_inputs"] if entry["axis"] != "z"]
        try:
            schedules.append(layer_state_parameters(state).z_levels_um)
        except (TypeError, ValueError) as error:
            raise ValueError(f"模板“{item['name']}”无法设置 Z 网格：{error}") from error
    if not _matching_levels(schedules):
        raise ValueError("所选模板的厚度或材料分界不同，统一尺寸后 Z 节点仍不一致；请先调整厚度分界，或分组修改。")
    return result


def scale_template_xy_geometry(library: object, template_id: str, factor: float) -> dict[str, Any]:
    """Scale all in-plane diameters/sidewalls while retaining exact Z geometry.

    Planar interval bounds follow the scaled geometry. Their target sizes, all
    thickness fields, Z controls, comments and non-geometry fields are retained.
    Both circular and explicit long/short-diameter Layer syntax are supported.
    """
    scale = _positive_number(factor, "平面缩放倍数")
    result = validate_workflow_library(library)
    template = _template(result, template_id)
    state = template["layer"]
    before = layer_state_parameters(state)
    if scale == 1.0:
        return result
    lines = state["source_text"].splitlines(keepends=True)
    for layer in before.layers:
        assert layer.source_line_number is not None
        index = layer.source_line_number - 1
        original = lines[index]
        ending = "\r\n" if original.endswith("\r\n") else "\n" if original.endswith("\n") else ""
        content = original[:-len(ending)] if ending else original
        code, marker, comment = content.partition("#")
        fields = code.split(",")
        dimensions = {4: layer.outer_diameter_um, 5: layer.inner_diameter_um}
        if len(fields) == 10:
            dimensions.update({6: layer.outer_short_diameter_um, 7: layer.inner_short_diameter_um})
        if layer.mode is LayerMode.TAPE:
            dimensions[len(fields) - 1] = layer.sidewall_thickness_um
        for field_index, value in dimensions.items():
            token = fields[field_index]
            prefix = token[:len(token) - len(token.lstrip())]
            suffix = token[len(token.rstrip()):]
            fields[field_index] = f"{prefix}{float(value) * scale:.17g}um{suffix}"
        lines[index] = ",".join(fields) + marker + comment + ending
    state["source_text"] = "".join(lines)
    for entry in state["local_size_inputs"]:
        if entry["axis"] in {"radial", "angular"}:
            entry["start_um"] *= scale
            entry["end_um"] *= scale
    for entry in state["radial_sweep_overrides"]:
        entry["start_um"] *= scale
        entry["end_um"] *= scale
    state = _layer_state(state)
    after = layer_state_parameters(state)
    if before.section_plan.z_breakpoints_um != after.section_plan.z_breakpoints_um or before.z_levels_um != after.z_levels_um:
        raise ValueError("平面缩放改变了厚度分层，操作已取消")
    template["layer"] = state
    return result
