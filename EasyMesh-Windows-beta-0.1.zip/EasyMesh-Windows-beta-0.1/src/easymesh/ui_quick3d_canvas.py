# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'quick3d_canvas.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QSizePolicy, QWidget)

class Ui_Quick3DCanvasForm(object):
    def setupUi(self, Quick3DCanvasForm):
        if not Quick3DCanvasForm.objectName():
            Quick3DCanvasForm.setObjectName(u"Quick3DCanvasForm")
        Quick3DCanvasForm.setMinimumSize(QSize(280, 210))
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Quick3DCanvasForm.sizePolicy().hasHeightForWidth())
        Quick3DCanvasForm.setSizePolicy(sizePolicy)
        Quick3DCanvasForm.setMouseTracking(True)
        Quick3DCanvasForm.setFocusPolicy(Qt.StrongFocus)

        self.retranslateUi(Quick3DCanvasForm)

        QMetaObject.connectSlotsByName(Quick3DCanvasForm)
    # setupUi

    def retranslateUi(self, Quick3DCanvasForm):
#if QT_CONFIG(tooltip)
        Quick3DCanvasForm.setToolTip(QCoreApplication.translate("Quick3DCanvasForm", u"\u5de6\u952e\u62d6\u52a8\u65cb\u8f6c\uff1bShift+\u5de6\u952e\u3001\u4e2d\u952e\u6216\u53f3\u952e\u62d6\u52a8\u5e73\u79fb\uff1b\u6eda\u8f6e\u56f4\u7ed5\u6307\u9488\u7f29\u653e\uff1b\u6b63\u4ea4\u6a21\u5f0f\u6700\u9ad8 100,000\u00d7\uff1b\u53cc\u51fb\u6062\u590d\u89c6\u56fe", None))
#endif // QT_CONFIG(tooltip)
    # retranslateUi
