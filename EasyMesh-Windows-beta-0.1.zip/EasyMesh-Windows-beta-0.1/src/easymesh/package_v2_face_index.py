"""Exact exterior ownership using compact numeric keys, never face hashes.

Four sorted node tags identify a QUAD; a TRI has a zero fourth slot (valid
node tags are positive). Numeric sorting keeps the volume-scale working set
out of Python dictionaries. Returned face references retain input ordering.
"""
from __future__ import annotations

import numpy as np

from .volume_mesh import ELEMENT_SPECS


def exterior_face_indices(blocks):
    """Return global face ordinals for (connectivity, local_faces) blocks.

    Within a block the ordinal is cell_index * face_count + local_face_index.
    Every face, including internal faces, participates in nonmanifold checks.
    """
    count = sum(len(connectivity) * len(faces) for connectivity, faces in blocks)
    if not count:
        return np.empty(0, dtype=np.int64)
    largest = max(int(connectivity.max()) for connectivity, _ in blocks if len(connectivity))
    dtype = np.uint32 if largest <= np.iinfo(np.uint32).max else np.uint64
    keys = np.zeros((count, 4), dtype=dtype)
    offset = 0
    for connectivity, faces in blocks:
        length = len(connectivity) * len(faces)
        target = keys[offset:offset + length].reshape((len(connectivity), len(faces), 4))
        for face_index, face in enumerate(faces):
            target[:, face_index, :len(face)] = np.sort(connectivity[:, face], axis=1)
        offset += length
    order = np.lexsort(tuple(keys[:, axis] for axis in (3, 2, 1, 0)))
    same = np.ones(max(0, count - 1), dtype=bool)
    for axis in range(4):
        same &= keys[order[1:], axis] == keys[order[:-1], axis]
    del keys
    starts = np.r_[0, np.flatnonzero(~same) + 1]
    lengths = np.diff(np.r_[starts, count])
    if np.any(lengths > 2):
        raise ValueError("volume mesh contains a non-manifold face")
    exterior = order[starts[lengths == 1]]
    exterior.sort()
    return exterior


def exterior_element_faces(elements):
    """Yield (element, local_face_index, ordered_cycle), preserving cell order."""
    positions = {}
    for index, element in enumerate(elements):
        if (element.gmsh_type not in ELEMENT_SPECS
                or ELEMENT_SPECS[element.gmsh_type][0] != element.kind):
            raise ValueError("volume mesh contains an unsupported element kind")
        positions.setdefault(element.gmsh_type, []).append(index)
    blocks = []
    block_positions = []
    for kind, indices in positions.items():
        connectivity = np.asarray([elements[index].node_tags for index in indices], dtype=np.uint64)
        blocks.append((connectivity, ELEMENT_SPECS[kind][2]))
        block_positions.append(indices)
    exterior = exterior_face_indices(blocks)
    references = []
    offset = 0
    for (connectivity, faces), indices in zip(blocks, block_positions):
        end = offset + len(connectivity) * len(faces)
        selected = exterior[np.searchsorted(exterior, offset):np.searchsorted(exterior, end)] - offset
        for ordinal in selected:
            local_cell, local_face = divmod(int(ordinal), len(faces))
            references.append((indices[local_cell], local_face))
        offset = end
    references.sort()
    for index, face_index in references:
        element = elements[index]
        face = ELEMENT_SPECS[element.gmsh_type][2][face_index]
        yield element, face_index, tuple(element.node_tags[index] for index in face)
