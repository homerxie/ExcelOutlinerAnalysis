"""Cancellable large-file verification without blocking the Qt event loop."""
from __future__ import annotations

from concurrent.futures import Future
from dataclasses import dataclass
import hashlib
from pathlib import Path
import threading


FileSignature = tuple[int, int, int, int, int, int]


def file_signature(path: Path) -> FileSignature:
    info = path.stat()
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


@dataclass(frozen=True, slots=True)
class FileDigest:
    signature: FileSignature
    sha256: str


class FileDigestTask:
    """Read/hash only; the owning GUI consumes the Future during its next poll."""

    def __init__(self, path: Path, signature: FileSignature) -> None:
        self.path = path
        self.signature = signature
        self.bytes_read = 0
        self.future: Future[FileDigest] = Future()
        self._cancelled = threading.Event()
        self._thread = threading.Thread(target=self._run, name="EasyMesh mesh verification", daemon=True)

    def start(self) -> None:
        self._thread.start()

    def cancel(self) -> None:
        self._cancelled.set()
        self.future.cancel()

    def _run(self) -> None:
        if not self.future.set_running_or_notify_cancel():
            return
        try:
            if file_signature(self.path) != self.signature:
                raise ValueError("最终 MSH 在复核期间发生变化，请重新生成。")
            digest = hashlib.sha256()
            with self.path.open("rb") as stream:
                while block := stream.read(1024 * 1024):
                    if self._cancelled.is_set():
                        raise ValueError("网格复核已取消。")
                    digest.update(block)
                    self.bytes_read += len(block)
            if self._cancelled.is_set():
                raise ValueError("网格复核已取消。")
            if file_signature(self.path) != self.signature:
                raise ValueError("最终 MSH 在复核期间发生变化，请重新生成。")
            self.future.set_result(FileDigest(self.signature, digest.hexdigest()))
        except Exception as exc:
            self.future.set_exception(exc)
