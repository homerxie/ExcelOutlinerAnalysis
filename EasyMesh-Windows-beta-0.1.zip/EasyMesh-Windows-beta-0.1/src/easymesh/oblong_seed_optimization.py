"""Redistribute soft seeds near a clipped Oblong front without changing cells."""

from __future__ import annotations

from bisect import bisect_left
from collections import defaultdict
import math
from typing import Mapping, Protocol, Sequence

from .contours import StadiumContour, stadium_cell_spans_um

Point = tuple[float, float]
SeedMove = tuple[int, Point, Point]
OptimizationPass = tuple[int, int, float]


class _MutableMesh(Protocol):
    points: list[Point]
    keys: dict[tuple[int, int], int]
    tolerance: float
    area_tolerance: float

    def quality(self, nodes: Sequence[int]) -> float: ...


def uniformize_terminal_seeds(
    mesh: _MutableMesh,
    faces: Sequence[Sequence[int]],
    inside: Sequence[int],
    outside: Sequence[int],
    terminal: Sequence[int],
    reference: StadiumContour,
    radial_target: float,
    angular_target: float,
    *,
    layers: int = 6,
    passes: int = 30,
    reference_points: Mapping[int, Point] | Sequence[Point] | None = None,
    bending_weight: float = 8.,
) -> tuple[list[SeedMove], list[OptimizationPass]]:
    """Redistribute sizes while propagating a smooth displacement field.

    Physical vertices and distant source cells stay fixed. A cosine envelope
    fades movement over nearby layers instead of abruptly ending it. Nodes may
    move normally and tangentially, while their original front's radial slot
    and circumferential order remain intact. Every accepted position preserves
    positive convex cells and the input mesh's minimum corner quality.

    Reference points are the source coordinates before tangential relaxation.
    Bending terms couple actual circular and radial edge chains; reflected
    neighbors keep those chains smooth across the X/Y symmetry seams. Axis
    seeds move along their axis only. Zero-radius source fronts remain fixed.
    """
    if (not math.isfinite(radial_target) or radial_target <= 0.
            or not math.isfinite(angular_target) or angular_target <= 0.):
        raise ValueError("soft seed targets must be finite and positive")
    if not math.isfinite(bending_weight) or bending_weight < 0.:
        raise ValueError("soft seed bending weight must be finite and nonnegative")
    if layers < 1 or passes < 1 or not faces:
        return [], []
    faces = tuple(tuple(face) for face in faces)
    used = {node for face in faces for node in face}
    physical = set(inside) | set(outside)
    original = {node: mesh.points[node] for node in used}
    source_points = {node: reference_points[node] if reference_points is not None else original[node]
                     for node in used}
    incident: dict[int, list[int]] = defaultdict(list)
    adjacency: dict[int, set[int]] = defaultdict(set)
    for index, face in enumerate(faces):
        for node in face:
            incident[node].append(index)
            adjacency[node].update(face)

    distance = dict.fromkeys(terminal, 0)
    front = set(terminal)
    for step in range(1, layers + 1):
        front = {other for node in front for other in adjacency[node]} - distance.keys()
        distance.update((node, step) for node in front)
    c = reference.half_straight_um

    def radius(point: Point) -> float:
        return math.hypot(max(point[0] - c, 0.), point[1])

    original_radii = {node: radius(point) for node, point in source_points.items()}
    eligible = sorted(node for node in distance.keys() - physical
                      if original_radii[node] > mesh.tolerance)
    if not eligible:
        return [], []
    radii: list[float] = []
    for value in sorted(original_radii[node] for node in used - physical):
        if not radii or value - radii[-1] > 1.e-8:
            radii.append(value)

    def front_index(value: float) -> int:
        index = bisect_left(radii, value)
        if index == len(radii):
            return index - 1
        if index and value - radii[index - 1] < radii[index] - value:
            return index - 1
        return index

    bounds: dict[int, tuple[float, float]] = {}
    basis: dict[int, tuple[Point, Point]] = {}
    influence = {node: math.cos(math.pi * (distance[node] - 1) / (2 * layers)) ** 2
                 for node in eligible}
    for node in eligible:
        point, r = source_points[node], original_radii[node]
        index = front_index(r)
        lower = (radii[index - 1] + r) * .5 if index else max(0., r - .5 * radial_target)
        upper = (radii[index + 1] + r) * .5 if index + 1 < len(radii) else r + .5 * radial_target
        bounds[node] = (max(lower + mesh.tolerance * 20, r - .49 * radial_target * influence[node]),
                        min(upper - mesh.tolerance * 20, r + .49 * radial_target * influence[node]))
        normal = (max(point[0] - c, 0.) / r, point[1] / r)
        basis[node] = normal, (normal[1], -normal[0])

    quality_floor = min(mesh.quality(face) for face in faces)
    original_spans = [stadium_cell_spans_um(reference, [mesh.points[node] for node in face])
                      for face in faces]

    def key(point: Point) -> tuple[int, int]:
        return round(point[0] / mesh.tolerance), round(point[1] / mesh.tolerance)

    def available(node: int, point: Point) -> bool:
        return key(point) not in mesh.keys or mesh.keys[key(point)] == node

    def set_point(node: int, point: Point) -> None:
        old_key = key(mesh.points[node])
        if mesh.keys.get(old_key) == node:
            del mesh.keys[old_key]
        mesh.points[node] = point
        mesh.keys[key(point)] = node

    def cell_data(index: int) -> tuple[float, float, float, float] | None:
        face = faces[index]
        points = [mesh.points[node] for node in face]
        origin = points[0]
        shifted = [(x - origin[0], y - origin[1]) for x, y in points]
        area = .5 * sum(a[0] * b[1] - a[1] * b[0]
                        for a, b in zip(shifted, shifted[1:] + shifted[:1]))
        if area <= mesh.area_tolerance:
            return None
        quality = mesh.quality(face)
        if quality < quality_floor - 1.e-10:
            return None
        normal, tangent = stadium_cell_spans_um(reference, points)
        old_normal, old_tangent = original_spans[index]
        if (min(normal, tangent) <= mesh.tolerance
                or normal > max(old_normal, 1.25 * radial_target) + 1.e-9
                or tangent > max(old_tangent, 1.25 * angular_target) + 1.e-9):
            return None
        return area, quality, normal, tangent

    def valid_local(indices: Sequence[int] | set[int]) -> bool:
        return all(cell_data(index) is not None for index in indices)

    # A symmetry seam supplies an unambiguous one-dimensional soft schedule.
    axis_locks: set[int] = set()
    axis_targets: dict[int, Point] = {}
    for axis in (0, 1):
        chain = sorted((node for node in used if abs(original[node][1 - axis]) <= mesh.tolerance),
                       key=lambda node: (original[node][axis], node))
        run: list[tuple[int, int]] = []
        for position, node in enumerate(chain):
            if node in eligible:
                run.append((position, node))
                continue
            if not run:
                continue
            begin = run[0][0] - 1
            if begin >= 0:
                lower, upper = original[chain[begin]][axis], original[node][axis]
                proposed = {
                    other: tuple(lower + (upper - lower) * (index + 1) / (len(run) + 1)
                                 if dimension == axis else 0. for dimension in (0, 1))
                    for index, (_, other) in enumerate(run)
                }
                axis_targets.update(proposed)
                if all(available(other, point) for other, point in proposed.items()):
                    for other, point in proposed.items():
                        set_point(other, point)
                    affected = {index for other in proposed for index in incident[other]}
                    if (all(bounds[other][0] < radius(point) < bounds[other][1]
                            for other, point in proposed.items()) and valid_local(affected)):
                        axis_locks.update(proposed)
                    else:
                        for other in proposed:
                            set_point(other, original[other])
            run = []
    eligible = [node for node in eligible if node not in axis_locks]

    def cell_energy(index: int) -> float | None:
        data = cell_data(index)
        if data is None:
            return None
        area, quality, normal, tangent = data
        weight = .5 if len(faces[index]) == 3 else 1.
        return (math.log(area / (weight * radial_target * angular_target)) ** 2
                + .8 * (math.log(normal / radial_target) ** 2 + math.log(tangent / angular_target) ** 2)
                + .06 * math.log(max(quality, 1.e-12)) ** 2)

    energy = [cell_energy(index) for index in range(len(faces))]
    if any(value is None for value in energy):
        # An optional optimization must not invalidate a previously accepted
        # mesh when its geometry is outside the optimizer's supported range.
        for node in sorted(used):
            set_point(node, original[node])
        return [], []

    def front_position(node: int, point: Point) -> float:
        return (point[0] if point[0] <= c
                else c + original_radii[node] * math.atan2(point[0] - c, point[1]))

    groups: dict[int, list[int]] = defaultdict(list)
    for node in sorted(used - physical):
        groups[front_index(original_radii[node])].append(node)
    front_neighbors: dict[int, list[int]] = {node: [] for node in eligible}
    for group in groups.values():
        group.sort(key=lambda node: (front_position(node, source_points[node]), node))
        for index, node in enumerate(group):
            if node in front_neighbors:
                front_neighbors[node] = group[max(index - 1, 0):index] + group[index + 1:index + 2]

    def ordered_front(node: int, point: Point) -> bool:
        position = front_position(node, point)
        old_position = front_position(node, source_points[node])
        return all((old_position - front_position(other, source_points[other]))
                   * (position - front_position(other, mesh.points[other])) > 0.
                   for other in front_neighbors[node])

    edges = {tuple(sorted((a, b))) for face in faces for a, b in zip(face, (*face[1:], face[0]))}
    edge_neighbors: dict[int, set[int]] = defaultdict(set)
    for a, b in edges:
        edge_neighbors[a].add(b)
        edge_neighbors[b].add(a)
    # Only actual mesh edges form chains. Their original curvature is kept;
    # the energy penalizes additional bending of the displacement field.
    triple_set: set[tuple[int, int, int]] = set()
    for group in groups.values():
        for a, b, d in zip(group, group[1:], group[2:]):
            if tuple(sorted((a, b))) in edges and tuple(sorted((b, d))) in edges:
                triple_set.add((a, b, d))
    front_triples = set(triple_set)
    for b in sorted(used - physical):
        lower = [a for a in edge_neighbors[b] if original_radii[a] < original_radii[b] - 1.e-8]
        upper = [d for d in edge_neighbors[b] if original_radii[d] > original_radii[b] + 1.e-8]
        choices = []
        for a in lower:
            for d in upper:
                u = source_points[b][0] - source_points[a][0], source_points[b][1] - source_points[a][1]
                v = source_points[d][0] - source_points[b][0], source_points[d][1] - source_points[b][1]
                cosine = (u[0] * v[0] + u[1] * v[1]) / (math.hypot(*u) * math.hypot(*v))
                if cosine > .95:
                    choices.append((cosine, -a, -d, a, d))
        if choices:
            _, _, _, a, d = max(choices)
            triple_set.add((a, b, d))
    triples = sorted(triple_set)
    triple_lengths = [(math.dist(source_points[a], source_points[b]), math.dist(source_points[b], source_points[d]))
                      for a, b, d in triples]
    triple_incident: dict[int, list[int]] = defaultdict(list)
    for index, triple in enumerate(triples):
        for node in triple:
            triple_incident[node].append(index)

    # Reflect the neighboring point across each symmetry axis. Without these
    # ghost triples a quarter can look smooth while its mirrored half has a V.
    ghosts: list[tuple[int, int, int, float]] = []
    ghost_incident: dict[int, list[int]] = defaultdict(list)
    for group in groups.values():
        for axis, center, neighbor in ((0, group[0], group[1] if len(group) > 1 else group[0]),
                                      (1, group[-1], group[-2] if len(group) > 1 else group[-1])):
            if (center != neighbor and abs(source_points[center][axis]) <= mesh.tolerance
                    and tuple(sorted((center, neighbor))) in edges):
                index = len(ghosts)
                ghosts.append((center, neighbor, axis, math.dist(source_points[center], source_points[neighbor])))
                ghost_incident[center].append(index)
                ghost_incident[neighbor].append(index)

    def ghost_energy(index: int) -> float:
        center, neighbor, axis, length = ghosts[index]
        center_shift = mesh.points[center][1 - axis] - source_points[center][1 - axis]
        neighbor_shift = mesh.points[neighbor][1 - axis] - source_points[neighbor][1 - axis]
        return (2 * (neighbor_shift - center_shift) / length) ** 2

    def bending_energy(index: int) -> float:
        a, b, d = triples[index]
        l1, l2 = triple_lengths[index]
        delta = [(mesh.points[node][0] - source_points[node][0], mesh.points[node][1] - source_points[node][1])
                 for node in (a, b, d)]
        return sum(((delta[2][axis] - delta[1][axis]) / l2
                    - (delta[1][axis] - delta[0][axis]) / l1) ** 2 for axis in (0, 1))

    def convex_front_energy(index: int) -> float:
        a, b, d = triples[index]
        if (a, b, d) not in front_triples:
            return 0.
        pa, pb, pd = mesh.points[a], mesh.points[b], mesh.points[d]
        u = pb[0] - pa[0], pb[1] - pa[1]
        v = pd[0] - pb[0], pd[1] - pb[1]
        turn = math.atan2(u[0] * v[1] - u[1] * v[0], u[0] * v[0] + u[1] * v[1])
        return max(0., turn) ** 2

    def regularizer(node: int) -> float:
        cost = (5000. * (math.dist(mesh.points[node], axis_targets[node]) / radial_target) ** 2
                if node in axis_targets else 0.)
        r = radius(mesh.points[node])
        cost += bending_weight * sum(bending_energy(index) for index in triple_incident[node])
        cost += 32 * bending_weight * sum(ghost_energy(index) for index in ghost_incident[node])
        cost += 128. * sum(convex_front_energy(index) for index in triple_incident[node])
        return cost + .15 * sum(((r - radius(mesh.points[other])) / radial_target) ** 2
                              for other in front_neighbors[node])

    history: list[OptimizationPass] = []
    directions = ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1))
    for turn in range(passes):
        improvement, count = 0., 0
        step = .12 if turn < 4 else .05 if turn < 9 else .02 if turn < 16 else .0075 if turn < 23 else .0025
        for node in eligible:
            old = mesh.points[node]
            local = incident[node]
            before = sum(energy[index] for index in local) + regularizer(node)
            best_cost, best_point, best_values = before, old, None
            normal, tangent = basis[node]
            for radial_direction, angular_direction in directions:
                dr, ds = radial_direction * step * radial_target, angular_direction * step * angular_target
                point = (old[0] + dr * normal[0] + ds * tangent[0],
                         old[1] + dr * normal[1] + ds * tangent[1])
                if abs(original[node][0]) <= mesh.tolerance:
                    point = 0., point[1]
                if abs(original[node][1]) <= mesh.tolerance:
                    point = point[0], 0.
                if min(point) < 0. or not bounds[node][0] < radius(point) < bounds[node][1]:
                    continue
                delta = point[0] - source_points[node][0], point[1] - source_points[node][1]
                if abs(delta[0] * tangent[0] + delta[1] * tangent[1]) > .5 * angular_target * influence[node]:
                    continue
                if not available(node, point) or not ordered_front(node, point):
                    continue
                set_point(node, point)
                values = [cell_energy(index) for index in local]
                if all(value is not None for value in values):
                    cost = sum(values) + regularizer(node)
                    if cost < best_cost - 1.e-10:
                        best_cost, best_point, best_values = cost, point, values
                set_point(node, old)
            if best_values is not None:
                set_point(node, best_point)
                for index, value in zip(local, best_values):
                    energy[index] = value
                improvement += before - best_cost
                count += 1
        history.append((turn, count, improvement))
        if improvement < 1.e-8 and turn >= 23:
            break

    # Neighboring seeds can make an initially blocked regular axis schedule
    # valid. Recheck every movement constraint before finishing that schedule.
    for node, point in axis_targets.items():
        if not bounds[node][0] < radius(point) < bounds[node][1] or not available(node, point):
            continue
        if node in front_neighbors and not ordered_front(node, point):
            continue
        old = mesh.points[node]
        set_point(node, point)
        if not valid_local(incident[node]):
            set_point(node, old)
    changed = sorted(set(eligible) | axis_locks)
    moves = [(node, original[node], mesh.points[node]) for node in changed
             if math.dist(original[node], mesh.points[node]) > mesh.tolerance]
    return moves, history
