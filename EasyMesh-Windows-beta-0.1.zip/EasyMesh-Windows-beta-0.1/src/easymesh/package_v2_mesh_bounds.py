"""Exact, cancellable bounds of selected imported volume meshes in package axes.

Unlike the MSH entity boxes, these bounds use the actual element nodes.  The
reader keeps compact numeric arrays and never loads Gmsh or audits Jacobians.
"""
from __future__ import annotations

from array import array
from collections import OrderedDict
from math import isfinite
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import RLock

import numpy as np

from .package_v2_instance_transform import IDENTITY
from .package_v2_mesh_groups import mesh_file_signature, read_mesh_volume_groups


_CHUNK_SIZE = 65536
_MAX_LINE_BYTES = 1024 * 1024
_MAX_TAG = 2**63 - 1
_POINT_CACHE_BYTES = 32 * 1024 * 1024
_MEMORY_NODE_BYTES = 32 * 1024 * 1024
_point_cache = OrderedDict()
_orientation_cache = OrderedDict()
_cache_lock = RLock()
_NODE_COUNTS = {4: 4, 5: 8, 6: 6, 7: 5}


class _PointStorage:
    """Disk-backed large selections, reduced in chunks and closed after use."""
    def __init__(self):
        self.directory = None
        self.arrays = []

    def allocate(self, shape, dtype, disk):
        if not disk:
            return np.empty(shape, dtype=dtype)
        if self.directory is None:
            self.directory = TemporaryDirectory(prefix="easymesh-bounds-")
        result = np.memmap(Path(self.directory.name) / str(len(self.arrays)), mode="w+", dtype=dtype, shape=shape)
        self.arrays.append(result)
        return result

    def release(self, value):
        if isinstance(value, np.memmap):
            value._mmap.close()
            # Keep its slot so a subsequent allocation cannot reuse its file.

    def __len__(self):
        return len(self.points)

    def __getitem__(self, item):
        return self.points[item][self.selected[item]]

    def close(self):
        for value in self.arrays:
            value._mmap.close()
        self.arrays.clear()
        if self.directory is not None:
            self.directory.cleanup()
            self.directory = None

    __del__ = close


def _check_cancelled(cancelled):
    if cancelled():
        raise InterruptedError("已取消网格坐标范围读取。")


def _read_points(path, catalog, components, cancelled):
    """Select connectivity nodes, including nodes classified on surfaces/edges."""
    storage = _PointStorage()
    try:
        return _read_points_with_storage(path, catalog, components, cancelled, storage)
    except BaseException:
        storage.close()
        raise


def _read_points_with_storage(path, catalog, components, cancelled, storage):
    entities = {entity for group in catalog.groups if group.name in components
                for entity in group.entities}
    with path.open("rb") as stream:
        stream.seek(catalog.metadata_bytes)

        def line():
            _check_cancelled(cancelled)
            value = stream.readline(_MAX_LINE_BYTES + 1)
            if not value or len(value) > _MAX_LINE_BYTES:
                raise ValueError("网格数据不完整或单行过长，无法读取坐标范围。")
            return value.strip()

        def integers(count):
            try:
                values = tuple(int(value) for value in line().split())
            except ValueError as error:
                raise ValueError("网格计数或编号格式不正确。") from error
            if len(values) != count:
                raise ValueError("网格计数或编号格式不正确。")
            return values

        def header():
            blocks, count, low, high = integers(4)
            # Every record needs at least one byte. Reject impossible declared
            # allocations before allocating numeric storage for malformed files.
            if not (0 < blocks <= count <= catalog.signature[2]
                    and 0 < low <= high <= _MAX_TAG):
                raise ValueError("网格数据区段的计数或编号范围不正确。")
            return blocks, count, low, high

        nodes = points = order = selected = None
        node_count = 0
        seen = set()
        while seen != {b"$Nodes", b"$Elements"}:
            marker = line()
            if not marker:
                continue
            if marker in seen:
                raise ValueError("网格包含重复的节点或单元区段。")
            if marker == b"$Nodes":
                seen.add(marker)
                blocks, node_count, low, high = header()
                disk = node_count * 32 > _MEMORY_NODE_BYTES
                nodes = storage.allocate(node_count, np.int64, disk)
                points = storage.allocate((node_count, 3), np.float64, disk)
                dense = high - low + 1 == node_count
                node_low = low
                offset = 0
                for _ in range(blocks):
                    dimension, entity, parametric, count = integers(4)
                    if (dimension not in range(4) or entity < 1
                            or parametric not in (0, 1) or count < 1
                            or offset + count > node_count):
                        raise ValueError("网格节点块格式不正确。")
                    for index in range(offset, offset + count):
                        tag, = integers(1)
                        if not low <= tag <= high:
                            raise ValueError("网格节点编号超出声明范围。")
                        nodes[index] = tag
                        dense = dense and tag == low + index
                    width = 3 + (dimension if parametric else 0)
                    for index in range(offset, offset + count):
                        try:
                            values = tuple(float(value) for value in line().split())
                        except ValueError as error:
                            raise ValueError("网格节点坐标格式不正确。") from error
                        if len(values) != width or not all(isfinite(value) for value in values):
                            raise ValueError("网格节点坐标格式不正确或包含非有限数值。")
                        points[index] = values[:3]
                    offset += count
                if offset != node_count or line() != b"$EndNodes":
                    raise ValueError("网格节点区段不完整。")
                _check_cancelled(cancelled)
                if dense:
                    order = None
                    storage.release(nodes)
                    nodes = None
                else:
                    order = np.argsort(nodes)
                    sorted_nodes = storage.allocate(node_count, np.int64, disk)
                    for start in range(0, node_count, _CHUNK_SIZE):
                        _check_cancelled(cancelled)
                        sorted_nodes[start:start + _CHUNK_SIZE] = nodes[order[start:start + _CHUNK_SIZE]]
                    storage.release(nodes)
                    nodes = sorted_nodes
                    if nodes[0] != low or nodes[-1] != high or any(
                            np.any(nodes[start + 1:min(start + _CHUNK_SIZE + 1, node_count)]
                                   == nodes[start:min(start + _CHUNK_SIZE, node_count - 1)])
                            for start in range(0, node_count - 1, _CHUNK_SIZE)):
                        raise ValueError("网格节点编号重复或与声明范围不一致。")
                selected = np.zeros(node_count, dtype=np.bool_)
            elif marker == b"$Elements":
                if b"$Nodes" not in seen:
                    raise ValueError("网格节点区段必须位于单元区段之前。")
                seen.add(marker)
                blocks, total, low, high = header()
                parsed = 0
                minimum, maximum = high, low
                pending = array("q")

                def select_pending():
                    if not pending:
                        return
                    _check_cancelled(cancelled)
                    tags = np.frombuffer(pending, dtype=np.int64)
                    if dense:
                        indices = tags - node_low
                        if np.any(indices < 0) or np.any(indices >= node_count):
                            raise ValueError("所选网格单元引用了不存在的节点。")
                        selected[indices] = True
                    else:
                        indices = np.searchsorted(nodes, tags)
                        if np.any(indices >= node_count) or np.any(nodes[indices] != tags):
                            raise ValueError("所选网格单元引用了不存在的节点。")
                        selected[order[indices]] = True

                for _ in range(blocks):
                    dimension, entity, element_type, count = integers(4)
                    if dimension not in range(4) or entity < 1 or count < 1 or parsed + count > total:
                        raise ValueError("网格单元块格式不正确。")
                    keep = dimension == 3 and entity in entities
                    width = _NODE_COUNTS.get(element_type)
                    if keep and width is None:
                        raise ValueError("坐标范围仅支持一阶 TET4/HEX8/WEDGE6/PYRAMID5 体网格。")
                    for _ in range(count):
                        try:
                            values = tuple(int(value) for value in line().split())
                        except ValueError as error:
                            raise ValueError("网格单元连接信息格式不正确。") from error
                        if (not values or not low <= values[0] <= high
                                or any(not 0 < tag <= _MAX_TAG for tag in values[1:])
                                or (keep and len(values) != width + 1)):
                            raise ValueError("网格单元连接信息格式不正确。")
                        minimum, maximum = min(minimum, values[0]), max(maximum, values[0])
                        if keep:
                            pending.extend(values[1:])
                            if len(pending) >= _CHUNK_SIZE:
                                select_pending()
                                pending = array("q")
                    parsed += count
                select_pending()
                if parsed != total or (minimum, maximum) != (low, high) or line() != b"$EndElements":
                    raise ValueError("网格单元区段不完整或编号范围不一致。")
            else:
                raise ValueError("网格数据包含无法读取坐标范围的区段。")
    _check_cancelled(cancelled)
    if not selected.any():
        raise ValueError("所选体分组没有可读取坐标的体单元。")
    if disk:
        storage.points, storage.selected = points, selected
        return storage
    result = points[selected]
    result.flags.writeable = False
    return result


def _oriented_bounds(points, matrix, cancelled):
    minimum = np.full(3, np.inf)
    maximum = np.full(3, -np.inf)
    for offset in range(0, len(points), _CHUNK_SIZE):
        _check_cancelled(cancelled)
        chunk = points[offset:offset + _CHUNK_SIZE]
        if not len(chunk):
            continue
        with np.errstate(over="ignore", invalid="ignore"):
            transformed = chunk @ matrix.T
        if not np.isfinite(transformed).all():
            raise ValueError("摆放后的网格坐标超出可表示的数值范围。")
        minimum = np.minimum(minimum, transformed.min(axis=0))
        maximum = np.maximum(maximum, transformed.max(axis=0))
    return tuple(minimum), tuple(maximum)


def read_mesh_bounds(path, components, rotation_matrix=IDENTITY,
                     translation_xyz_mm=(0., 0., 0.), *, cancelled=lambda: False):
    """Return (minimum_xyz, maximum_xyz) in millimetres after current placement.

    Call off the UI thread. File identity, chosen volume groups and orientation
    key the cache; changing only translation does not scan or transform nodes.
    Cancellation and a file-change check also apply to cached results.
    """
    _check_cancelled(cancelled)
    matrix = np.asarray(rotation_matrix, dtype=np.float64)
    translation = np.asarray(translation_xyz_mm, dtype=np.float64)
    if (matrix.shape != (3, 3) or translation.shape != (3,)
            or not np.isfinite(matrix).all() or not np.isfinite(translation).all()):
        raise ValueError("网格摆放必须包含有效的三维变换矩阵和 XYZ 坐标。")
    path = Path(path).resolve()
    catalog = read_mesh_volume_groups(path, cancelled=cancelled)
    components = tuple(components)
    error = catalog.selection_error(components)
    if error:
        raise ValueError(error)
    key = path, catalog.signature, tuple(sorted(components))
    orientation_key = key, tuple(matrix.flat)
    with _cache_lock:
        bounds = _orientation_cache.get(orientation_key)
        if bounds is not None:
            _orientation_cache.move_to_end(orientation_key)
        points = _point_cache.get(key)
        if points is not None:
            _point_cache.move_to_end(key)
    if bounds is None:
        if points is None:
            points = _read_points(path, catalog, components, cancelled)
        try:
            bounds = _oriented_bounds(points, matrix, cancelled)
        finally:
            if isinstance(points, _PointStorage):
                points.close()
                points = None
    _check_cancelled(cancelled)
    if mesh_file_signature(path) != catalog.signature:
        raise ValueError("读取期间网格文件发生变化，请重新读取坐标范围。")
    with _cache_lock:
        if points is not None and points.nbytes <= _POINT_CACHE_BYTES:
            _point_cache[key] = points
            _point_cache.move_to_end(key)
            while (len(_point_cache) > 8
                   or sum(value.nbytes for value in _point_cache.values()) > _POINT_CACHE_BYTES):
                _point_cache.popitem(last=False)
        _orientation_cache[orientation_key] = bounds
        _orientation_cache.move_to_end(orientation_key)
        while len(_orientation_cache) > 128:
            _orientation_cache.popitem(last=False)
    with np.errstate(over="ignore", invalid="ignore"):
        placed = np.asarray(bounds) + translation
    if not np.isfinite(placed).all():
        raise ValueError("摆放后的网格坐标超出可表示的数值范围。")
    return tuple(tuple(float(value) for value in point) for point in placed)


def format_mesh_bounds(bounds):
    """Three copyable coordinate ranges; the containing UI supplies the unit."""
    def number(value):
        return format(0. if value == 0. else value, ".12g")
    return tuple(f"[{number(low)}, {number(high)}]" for low, high in zip(*bounds))
