"""Application-wide PyQtDarkTheme styling and palette-aware status colors."""

from __future__ import annotations

from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import QApplication, QWidget

from .ui_application_theme import Ui_ApplicationThemeForm


def _theme_settings() -> QWidget:
    app = QApplication.instance()
    if not hasattr(app, "_easymesh_theme_settings"):
        theme = QWidget()
        Ui_ApplicationThemeForm().setupUi(theme)
        app._easymesh_theme_settings = theme
    return app._easymesh_theme_settings


def setup_application_theme(app: QApplication) -> None:
    """Style Qt widgets and give custom QPainter/Quick previews a full palette."""

    import qdarktheme

    theme = _theme_settings()
    colors = {"primary": theme.property("accentColor")}
    qdarktheme.setup_theme(
        "dark", custom_colors=colors, additional_qss=theme.styleSheet(),
    )
    # setup_theme supplies only the roles needed by its stylesheet. Our custom
    # preview canvases also read Window/WindowText directly from QPalette.
    app.setPalette(qdarktheme.load_palette("dark", custom_colors=colors))


def semantic_colors(widget: QWidget, tone: str) -> tuple[QColor, QColor]:
    """Return readable foreground/background colors for status text or cells."""

    dark = widget.palette().color(QPalette.ColorRole.Window).lightness() < 128
    prefix = tone + ("Dark" if dark else "Light")
    theme = _theme_settings()
    foreground, background = (theme.property(prefix + role) for role in ("Foreground", "Background"))
    if foreground is None or background is None:
        raise ValueError(f"unknown semantic color: {tone}")
    return QColor(foreground), QColor(background)


def semantic_style(widget: QWidget, tone: str) -> str:
    foreground, _ = semantic_colors(widget, tone)
    return f"color: {foreground.name()};"
