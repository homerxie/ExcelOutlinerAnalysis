"""Bounded-buffer SOLID185 writer for meshes with millions of cells.

Physical groups belong to Gmsh entities. Validate the existing classification
contract on one representative per nonempty entity, then expand counts using
numeric connectivity blocks, without per-cell Python dictionaries or sets.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import replace
from typing import TextIO

import numpy as np

from .cdb_exporter import (
    CdbExportError, CdbExportOptions, ProgressCallback, _ANSYS_INTEGER_MAX,
    _ExportPlan, _build_export_plan, _format_ansys_real,
)
from .volume_mesh import VolumeElement, VolumeMesh

_CHUNK_SIZE = 8192
_SLOTS = {
    4: (0, 1, 2, 2, 3, 3, 3, 3),
    5: (0, 1, 2, 3, 4, 5, 6, 7),
    6: (0, 1, 2, 2, 3, 4, 5, 5),
    7: (0, 1, 2, 3, 4, 4, 4, 4),
}


def _entity_plan(mesh, options):
    blocks_by_entity = {}
    for block in mesh.element_blocks:
        if len(block.tags):
            blocks_by_entity.setdefault(block.entity_tag, []).append(block)
    blocks_by_id = {
        index: blocks_by_entity[entity]
        for index, entity in enumerate(sorted(blocks_by_entity), 1)
    }
    representatives = tuple(
        VolumeElement(index, blocks[0].kind, blocks[0].gmsh_type,
                      (), blocks[0].entity_tag,
                      mesh.entity_physical_groups.get(blocks[0].entity_tag, ()),
                      mesh.min_jacobian_determinant)
        for index, blocks in blocks_by_id.items()
    )
    proxy = VolumeMesh(mesh.source_path, (), representatives,
                       mesh.entity_physical_groups, mesh.dimensional_element_counts,
                       mesh.min_jacobian_determinant)
    plan = _build_export_plan(proxy, options)
    weights = {index: sum(len(block.tags) for block in blocks)
               for index, blocks in blocks_by_id.items()}
    count = lambda members: sum(weights[index] for index in members)
    memberships = Counter(index for members in plan.component_members.values()
                          for index in members)
    material_counts = Counter()
    for index, material in plan.material_by_element.items():
        material_counts[material] += weights[index]
    plan = replace(
        plan,
        component_mappings=tuple(replace(item, element_count=count(
            plan.component_members[item.component_name])) for item in plan.component_mappings),
        primary_partition=tuple(replace(item, element_count=material_counts[item.material_id])
                                for item in plan.primary_partition),
        hypermesh_components=tuple(replace(item, element_count=count(
            plan.hypermesh_component_members[item.component_name])) for item in plan.hypermesh_components),
        overlapping_element_count=sum(weights[index] for index, n in memberships.items() if n > 1),
    )
    return plan, blocks_by_id


def _sorted_tags(blocks):
    if len(blocks) == 1:
        return blocks[0].tags
    tags = np.concatenate([block.tags for block in blocks])
    tags.sort()
    return tags


def _element_chunks(blocks):
    """Yield globally EID-ordered records with only bounded connectivity copies."""
    blocks = sorted(blocks, key=lambda block: int(block.tags[0]))
    if all(blocks[index - 1].tags[-1] < blocks[index].tags[0]
           for index in range(1, len(blocks))):
        for block in blocks:
            for start in range(0, len(block.tags), _CHUNK_SIZE):
                yield (block.tags[start:start + _CHUNK_SIZE],
                       block.connectivity[start:start + _CHUNK_SIZE][:, _SLOTS[block.gmsh_type]])
        return
    # Mixed-kind/entity blocks may interleave EIDs. Sort a numeric index once;
    # do not allocate an element object or a dict entry for each record.
    ends = np.cumsum([len(block.tags) for block in blocks])
    starts = np.concatenate(([0], ends[:-1]))
    tags = np.concatenate([block.tags for block in blocks])
    order = np.argsort(tags)
    for start in range(0, len(order), _CHUNK_SIZE):
        indices = order[start:start + _CHUNK_SIZE]
        owners = np.searchsorted(ends, indices, side="right")
        connectivity = np.empty((len(indices), 8), dtype=tags.dtype)
        for owner in np.unique(owners):
            mask = owners == owner
            block = blocks[owner]
            rows = indices[mask] - starts[owner]
            connectivity[mask] = block.connectivity[rows][:, _SLOTS[block.gmsh_type]]
        yield tags[indices], connectivity


def write_compact_cdb(mesh, stream: TextIO, *, options: CdbExportOptions,
                      progress: ProgressCallback | None = None) -> _ExportPlan:
    options.validate()
    if options.element_type != 185:
        raise CdbExportError("紧凑导出只支持 SOLID185")
    report = progress or (lambda percent, message: None)
    report(47, "校验材料分区和 Component 分类（按实体处理）")
    for label, arrays in (("node", (mesh.node_tags,)),
                          ("element", (block.tags for block in mesh.element_blocks))):
        for tags in arrays:
            if len(tags) and (tags.min() < 1 or tags.max() > _ANSYS_INTEGER_MAX):
                raise CdbExportError(f"{label} tag 超出 CDB i9 支持范围 1..{_ANSYS_INTEGER_MAX}")
    plan, blocks_by_id = _entity_plan(mesh, options)
    node_count = len(mesh.node_tags)
    element_count = sum(len(block.tags) for block in mesh.element_blocks)
    stream.write("/COM,EasyMesh Gmsh MSH 4.1 to ANSYS blocked CDB\n"
                 "/COM,Coordinates are copied from the MSH with the reported scale\n/PREP7\n")
    if options.units_label is not None:
        stream.write(f"/UNITS,{options.units_label.strip().upper()}\n")
    stream.write(f"NBLOCK,6,SOLID,{int(mesh.node_tags[-1]):9d},{node_count:9d}\n(3i9,6e21.13e3)\n")
    report(50, f"写出节点 0 / {node_count:,}")
    for start in range(0, node_count, _CHUNK_SIZE):
        end = min(start + _CHUNK_SIZE, node_count)
        coordinates = mesh.coordinates[start:end] * options.coordinate_scale
        lines = [f"{tag:9d}{0:9d}{0:9d}" + "".join(_format_ansys_real(value) for value in xyz) + "\n"
                 for tag, xyz in zip(mesh.node_tags[start:end].tolist(), coordinates.tolist())]
        stream.write("".join(lines))
        report(50 + 14 * end // node_count, f"写出节点 {end:,} / {node_count:,}")
    stream.write("N,R5.3,LOC,       -1,\n")
    materials = {item.material_id: item.material_name for item in plan.hypermesh_components}
    for material in plan.primary_partition:
        stream.write(f'!!HMNAME MAT\n!!{material.material_id:10d} "{materials[material.material_id]}"\n'
                     "MPTEMP,R5.0,1,1\n\n")
    types = {item.element_type_id for item in plan.hypermesh_components}
    for type_id, origin in ((1, "TEMPLATE"), (2, "TRANSITION")):
        if type_id in types:
            stream.write(f'!!HMNAME ET\n!!{type_id:10d} "{origin}_SOLID185"\nET,{type_id},185\n')
    written = 0
    report(64, f"写出单元 0 / {element_count:,}")
    for component in plan.hypermesh_components:
        blocks = [block for index in plan.hypermesh_component_members[component.component_name]
                  for block in blocks_by_id[index]]
        property_key = f"{component.element_type_id}-{component.material_id}-{component.real_constant_id}"
        color = 3 + ((component.component_id - 1) % 12)
        stream.write(f'!!HMNAME COMP\n!!   {property_key} {component.component_id} "{component.component_name}"\n'
                     f"!!HWCOLOR COMP\n!!   {property_key} {color}\n"
                     f"TYPE,{component.element_type_id} $ MAT,{component.material_id} $ REAL,{component.real_constant_id}\n"
                     f"EBLOCK,19,SOLID,{max(int(block.tags[-1]) for block in blocks):9d},{component.element_count:9d}\n(19i9)\n")
        # The property prefix is constant for this entire component.
        prefix = "".join(f"{value:9d}" for value in (
            component.material_id, component.element_type_id, component.real_constant_id,
            component.section_id, 0, 0, 0, 0, 8, 0))
        row_format = prefix + "%9d" * 9 + "\n"
        for tags, connectivity in _element_chunks(blocks):
            rows = np.column_stack((tags, connectivity)).tolist()
            stream.write("".join(row_format % tuple(row) for row in rows))
            written += len(tags)
            report(64 + 23 * written // element_count, f"写出单元 {written:,} / {element_count:,}")
        stream.write(f"{ -1:9d}\n")
        stream.write(f"CM, {component.component_name}, ELEM\nESEL, NONE\n")
    stream.write("ESEL, ALL\n")
    total_members = sum(item.element_count for item in plan.component_mappings)
    written_members = 0
    for mapping in plan.component_mappings:
        blocks = [block for index in plan.component_members[mapping.component_name]
                  for block in blocks_by_id[index]]
        tags = _sorted_tags(blocks)
        stream.write(f"CMBLOCK,{mapping.component_name},ELEM,{len(tags)}\n(8i10)\n")
        for start in range(0, len(tags), _CHUNK_SIZE):
            chunk = tags[start:start + _CHUNK_SIZE]
            full = len(chunk) // 8 * 8
            rows = chunk[:full].reshape((-1, 8)).tolist()
            stream.write("".join(("%10d" * 8 + "\n") % tuple(row) for row in rows))
            if full < len(chunk):
                stream.write("".join(f"{tag:10d}" for tag in chunk[full:].tolist()) + "\n")
            written_members += len(chunk)
            report(87 + 9 * written_members // max(1, total_members),
                   f"写出选择集 {mapping.component_name}：{min(start + len(chunk), len(tags)):,} / {len(tags):,}")
        del tags
    stream.write("ALLSEL,ALL\nFINISH\n")
    return plan
