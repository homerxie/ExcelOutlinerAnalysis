# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'workflow_layout.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QAbstractButton, QAbstractItemView, QApplication, QCheckBox,
    QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox,
    QGridLayout, QGroupBox, QHBoxLayout, QHeaderView,
    QLabel, QMenu, QPushButton, QSizePolicy,
    QSplitter, QTabWidget, QTableView, QTableWidget,
    QTableWidgetItem, QToolButton, QVBoxLayout, QWidget)

from easymesh.layout_canvas import LayoutCanvas

class Ui_WorkflowLayoutForm(object):
    def setupUi(self, WorkflowLayoutForm):
        if not WorkflowLayoutForm.objectName():
            WorkflowLayoutForm.setObjectName(u"WorkflowLayoutForm")
        WorkflowLayoutForm.resize(1280, 820)
        self.import_mesh_action = QAction(WorkflowLayoutForm)
        self.import_mesh_action.setObjectName(u"import_mesh_action")
        self.template_add_menu = QMenu(WorkflowLayoutForm)
        self.template_add_menu.setObjectName(u"template_add_menu")
        self.root_layout = QVBoxLayout(WorkflowLayoutForm)
        self.root_layout.setObjectName(u"root_layout")
        self.hint_label = QLabel(WorkflowLayoutForm)
        self.hint_label.setObjectName(u"hint_label")
        self.hint_label.setWordWrap(True)

        self.root_layout.addWidget(self.hint_label)

        self.layout_splitter = QSplitter(WorkflowLayoutForm)
        self.layout_splitter.setObjectName(u"layout_splitter")
        self.layout_splitter.setOrientation(Qt.Horizontal)
        self.layout_splitter.setChildrenCollapsible(False)
        self.editor_panel = QWidget(self.layout_splitter)
        self.editor_panel.setObjectName(u"editor_panel")
        self.editor_layout = QVBoxLayout(self.editor_panel)
        self.editor_layout.setObjectName(u"editor_layout")
        self.editor_layout.setContentsMargins(0, 0, 0, 0)
        self.bounds_group = QGroupBox(self.editor_panel)
        self.bounds_group.setObjectName(u"bounds_group")
        self.bounds_grid = QGridLayout(self.bounds_group)
        self.bounds_grid.setObjectName(u"bounds_grid")
        self.x_min_label = QLabel(self.bounds_group)
        self.x_min_label.setObjectName(u"x_min_label")

        self.bounds_grid.addWidget(self.x_min_label, 0, 0, 1, 1)

        self.x_min_spin = QDoubleSpinBox(self.bounds_group)
        self.x_min_spin.setObjectName(u"x_min_spin")
        self.x_min_spin.setMinimum(-1000000000000.000000000000000)
        self.x_min_spin.setMaximum(1000000000000.000000000000000)
        self.x_min_spin.setValue(-500.000000000000000)
        self.x_min_spin.setDecimals(6)
        self.x_min_spin.setKeyboardTracking(False)

        self.bounds_grid.addWidget(self.x_min_spin, 0, 1, 1, 1)

        self.x_max_label = QLabel(self.bounds_group)
        self.x_max_label.setObjectName(u"x_max_label")

        self.bounds_grid.addWidget(self.x_max_label, 0, 2, 1, 1)

        self.x_max_spin = QDoubleSpinBox(self.bounds_group)
        self.x_max_spin.setObjectName(u"x_max_spin")
        self.x_max_spin.setMinimum(-1000000000000.000000000000000)
        self.x_max_spin.setMaximum(1000000000000.000000000000000)
        self.x_max_spin.setValue(500.000000000000000)
        self.x_max_spin.setDecimals(6)
        self.x_max_spin.setKeyboardTracking(False)

        self.bounds_grid.addWidget(self.x_max_spin, 0, 3, 1, 1)

        self.y_min_label = QLabel(self.bounds_group)
        self.y_min_label.setObjectName(u"y_min_label")

        self.bounds_grid.addWidget(self.y_min_label, 1, 0, 1, 1)

        self.y_min_spin = QDoubleSpinBox(self.bounds_group)
        self.y_min_spin.setObjectName(u"y_min_spin")
        self.y_min_spin.setMinimum(-1000000000000.000000000000000)
        self.y_min_spin.setMaximum(1000000000000.000000000000000)
        self.y_min_spin.setValue(-500.000000000000000)
        self.y_min_spin.setDecimals(6)
        self.y_min_spin.setKeyboardTracking(False)

        self.bounds_grid.addWidget(self.y_min_spin, 1, 1, 1, 1)

        self.y_max_label = QLabel(self.bounds_group)
        self.y_max_label.setObjectName(u"y_max_label")

        self.bounds_grid.addWidget(self.y_max_label, 1, 2, 1, 1)

        self.y_max_spin = QDoubleSpinBox(self.bounds_group)
        self.y_max_spin.setObjectName(u"y_max_spin")
        self.y_max_spin.setMinimum(-1000000000000.000000000000000)
        self.y_max_spin.setMaximum(1000000000000.000000000000000)
        self.y_max_spin.setValue(500.000000000000000)
        self.y_max_spin.setDecimals(6)
        self.y_max_spin.setKeyboardTracking(False)

        self.bounds_grid.addWidget(self.y_max_spin, 1, 3, 1, 1)


        self.editor_layout.addWidget(self.bounds_group)

        self.editor_tabs = QTabWidget(self.editor_panel)
        self.editor_tabs.setObjectName(u"editor_tabs")
        self.placements_tab = QWidget()
        self.placements_tab.setObjectName(u"placements_tab")
        self.placements_layout = QVBoxLayout(self.placements_tab)
        self.placements_layout.setObjectName(u"placements_layout")
        self.templates_label = QLabel(self.placements_tab)
        self.templates_label.setObjectName(u"templates_label")

        self.placements_layout.addWidget(self.templates_label)

        self.template_actions = QHBoxLayout()
        self.template_actions.setObjectName(u"template_actions")
        self.asset_combo = QComboBox(self.placements_tab)
        self.asset_combo.setObjectName(u"asset_combo")

        self.template_actions.addWidget(self.asset_combo)

        self.add_asset_button = QToolButton(self.placements_tab)
        self.add_asset_button.setObjectName(u"add_asset_button")
        self.add_asset_button.setMinimumSize(QSize(32, 28))
        self.add_asset_button.setMaximumSize(QSize(48, 28))
        self.add_asset_button.setPopupMode(QToolButton.MenuButtonPopup)

        self.template_actions.addWidget(self.add_asset_button)

        self.remove_template_button = QToolButton(self.placements_tab)
        self.remove_template_button.setObjectName(u"remove_template_button")
        self.remove_template_button.setMinimumSize(QSize(32, 28))
        self.remove_template_button.setMaximumSize(QSize(32, 28))

        self.template_actions.addWidget(self.remove_template_button)


        self.placements_layout.addLayout(self.template_actions)

        self.template_table = QTableWidget(self.placements_tab)
        if (self.template_table.columnCount() < 2):
            self.template_table.setColumnCount(2)
        __qtablewidgetitem = QTableWidgetItem()
        self.template_table.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.template_table.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        self.template_table.setObjectName(u"template_table")
        self.template_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.template_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.template_table.setAlternatingRowColors(True)
        self.template_table.setColumnCount(2)
        self.template_table.setMaximumSize(QSize(16777215, 135))
        self.template_table.verticalHeader().setDefaultSectionSize(24)

        self.placements_layout.addWidget(self.template_table)

        self.default_template_actions = QHBoxLayout()
        self.default_template_actions.setObjectName(u"default_template_actions")
        self.default_template_label = QLabel(self.placements_tab)
        self.default_template_label.setObjectName(u"default_template_label")

        self.default_template_actions.addWidget(self.default_template_label)

        self.default_template_combo = QComboBox(self.placements_tab)
        self.default_template_combo.setObjectName(u"default_template_combo")

        self.default_template_actions.addWidget(self.default_template_combo)


        self.placements_layout.addLayout(self.default_template_actions)

        self.coordinate_import_actions = QHBoxLayout()
        self.coordinate_import_actions.setObjectName(u"coordinate_import_actions")
        self.import_coordinates_button = QPushButton(self.placements_tab)
        self.import_coordinates_button.setObjectName(u"import_coordinates_button")

        self.coordinate_import_actions.addWidget(self.import_coordinates_button)

        self.coordinate_unit_combo = QComboBox(self.placements_tab)
        self.coordinate_unit_combo.addItem("")
        self.coordinate_unit_combo.addItem("")
        self.coordinate_unit_combo.setObjectName(u"coordinate_unit_combo")

        self.coordinate_import_actions.addWidget(self.coordinate_unit_combo)

        self.import_mode_combo = QComboBox(self.placements_tab)
        self.import_mode_combo.addItem("")
        self.import_mode_combo.addItem("")
        self.import_mode_combo.setObjectName(u"import_mode_combo")

        self.coordinate_import_actions.addWidget(self.import_mode_combo)


        self.placements_layout.addLayout(self.coordinate_import_actions)

        self.expand_bounds_check = QCheckBox(self.placements_tab)
        self.expand_bounds_check.setObjectName(u"expand_bounds_check")
        self.expand_bounds_check.setChecked(True)

        self.placements_layout.addWidget(self.expand_bounds_check)

        self.import_hint_label = QLabel(self.placements_tab)
        self.import_hint_label.setObjectName(u"import_hint_label")
        self.import_hint_label.setWordWrap(True)

        self.placements_layout.addWidget(self.import_hint_label)

        self.instance_actions = QHBoxLayout()
        self.instance_actions.setObjectName(u"instance_actions")
        self.instances_label = QLabel(self.placements_tab)
        self.instances_label.setObjectName(u"instances_label")

        self.instance_actions.addWidget(self.instances_label)

        self.add_instance_button = QToolButton(self.placements_tab)
        self.add_instance_button.setObjectName(u"add_instance_button")
        self.add_instance_button.setMinimumSize(QSize(32, 28))
        self.add_instance_button.setMaximumSize(QSize(32, 28))

        self.instance_actions.addWidget(self.add_instance_button)

        self.remove_instance_button = QToolButton(self.placements_tab)
        self.remove_instance_button.setObjectName(u"remove_instance_button")
        self.remove_instance_button.setMinimumSize(QSize(32, 28))
        self.remove_instance_button.setMaximumSize(QSize(32, 28))

        self.instance_actions.addWidget(self.remove_instance_button)


        self.placements_layout.addLayout(self.instance_actions)

        self.instance_table = QTableView(self.placements_tab)
        self.instance_table.setObjectName(u"instance_table")
        self.instance_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.instance_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.instance_table.setAlternatingRowColors(True)
        self.instance_table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.instance_table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.instance_table.verticalHeader().setDefaultSectionSize(24)

        self.placements_layout.addWidget(self.instance_table)

        self.batch_template_actions = QHBoxLayout()
        self.batch_template_actions.setObjectName(u"batch_template_actions")
        self.batch_template_label = QLabel(self.placements_tab)
        self.batch_template_label.setObjectName(u"batch_template_label")

        self.batch_template_actions.addWidget(self.batch_template_label)

        self.batch_template_combo = QComboBox(self.placements_tab)
        self.batch_template_combo.setObjectName(u"batch_template_combo")

        self.batch_template_actions.addWidget(self.batch_template_combo)

        self.apply_template_button = QPushButton(self.placements_tab)
        self.apply_template_button.setObjectName(u"apply_template_button")

        self.batch_template_actions.addWidget(self.apply_template_button)


        self.placements_layout.addLayout(self.batch_template_actions)

        self.editor_tabs.addTab(self.placements_tab, "")
        self.regions_tab = QWidget()
        self.regions_tab.setObjectName(u"regions_tab")
        self.regions_layout = QVBoxLayout(self.regions_tab)
        self.regions_layout.setObjectName(u"regions_layout")
        self.regions_hint_label = QLabel(self.regions_tab)
        self.regions_hint_label.setObjectName(u"regions_hint_label")
        self.regions_hint_label.setWordWrap(True)

        self.regions_layout.addWidget(self.regions_hint_label)

        self.region_actions = QHBoxLayout()
        self.region_actions.setObjectName(u"region_actions")
        self.regions_label = QLabel(self.regions_tab)
        self.regions_label.setObjectName(u"regions_label")

        self.region_actions.addWidget(self.regions_label)

        self.add_region_button = QToolButton(self.regions_tab)
        self.add_region_button.setObjectName(u"add_region_button")
        self.add_region_button.setMinimumSize(QSize(32, 28))
        self.add_region_button.setMaximumSize(QSize(32, 28))

        self.region_actions.addWidget(self.add_region_button)

        self.remove_region_button = QToolButton(self.regions_tab)
        self.remove_region_button.setObjectName(u"remove_region_button")
        self.remove_region_button.setMinimumSize(QSize(32, 28))
        self.remove_region_button.setMaximumSize(QSize(32, 28))

        self.region_actions.addWidget(self.remove_region_button)


        self.regions_layout.addLayout(self.region_actions)

        self.region_table = QTableView(self.regions_tab)
        self.region_table.setObjectName(u"region_table")
        self.region_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.region_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.region_table.setAlternatingRowColors(True)
        self.region_table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.region_table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.region_table.verticalHeader().setDefaultSectionSize(24)

        self.regions_layout.addWidget(self.region_table)

        self.region_status_label = QLabel(self.regions_tab)
        self.region_status_label.setObjectName(u"region_status_label")
        self.region_status_label.setWordWrap(True)

        self.regions_layout.addWidget(self.region_status_label)

        self.editor_tabs.addTab(self.regions_tab, "")

        self.editor_layout.addWidget(self.editor_tabs)

        self.layout_splitter.addWidget(self.editor_panel)
        self.preview_panel = QWidget(self.layout_splitter)
        self.preview_panel.setObjectName(u"preview_panel")
        self.preview_layout = QVBoxLayout(self.preview_panel)
        self.preview_layout.setObjectName(u"preview_layout")
        self.preview_layout.setContentsMargins(0, 0, 0, 0)
        self.view_actions = QHBoxLayout()
        self.view_actions.setObjectName(u"view_actions")
        self.view_title_label = QLabel(self.preview_panel)
        self.view_title_label.setObjectName(u"view_title_label")

        self.view_actions.addWidget(self.view_title_label)

        self.draw_region_button = QPushButton(self.preview_panel)
        self.draw_region_button.setObjectName(u"draw_region_button")
        self.draw_region_button.setCheckable(True)

        self.view_actions.addWidget(self.draw_region_button)

        self.fit_view_button = QPushButton(self.preview_panel)
        self.fit_view_button.setObjectName(u"fit_view_button")

        self.view_actions.addWidget(self.fit_view_button)

        self.select_all_button = QPushButton(self.preview_panel)
        self.select_all_button.setObjectName(u"select_all_button")

        self.view_actions.addWidget(self.select_all_button)

        self.clear_selection_button = QPushButton(self.preview_panel)
        self.clear_selection_button.setObjectName(u"clear_selection_button")

        self.view_actions.addWidget(self.clear_selection_button)


        self.preview_layout.addLayout(self.view_actions)

        self.template_legend_label = QLabel(self.preview_panel)
        self.template_legend_label.setObjectName(u"template_legend_label")
        self.template_legend_label.setWordWrap(True)

        self.preview_layout.addWidget(self.template_legend_label)

        self.canvas = LayoutCanvas(self.preview_panel)
        self.canvas.setObjectName(u"canvas")
        self.canvas.setMinimumSize(QSize(380, 300))

        self.preview_layout.addWidget(self.canvas)

        self.selection_label = QLabel(self.preview_panel)
        self.selection_label.setObjectName(u"selection_label")

        self.preview_layout.addWidget(self.selection_label)

        self.cursor_position_label = QLabel(self.preview_panel)
        self.cursor_position_label.setObjectName(u"cursor_position_label")

        self.preview_layout.addWidget(self.cursor_position_label)

        self.view_hint_label = QLabel(self.preview_panel)
        self.view_hint_label.setObjectName(u"view_hint_label")
        self.view_hint_label.setWordWrap(True)

        self.preview_layout.addWidget(self.view_hint_label)

        self.layout_splitter.addWidget(self.preview_panel)

        self.root_layout.addWidget(self.layout_splitter)

        self.error_label = QLabel(WorkflowLayoutForm)
        self.error_label.setObjectName(u"error_label")
        self.error_label.setWordWrap(True)

        self.root_layout.addWidget(self.error_label)

        self.buttons = QDialogButtonBox(WorkflowLayoutForm)
        self.buttons.setObjectName(u"buttons")
        self.buttons.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok|QDialogButtonBox.Reset)

        self.root_layout.addWidget(self.buttons)


        self.template_add_menu.addAction(self.import_mesh_action)

        self.retranslateUi(WorkflowLayoutForm)

        QMetaObject.connectSlotsByName(WorkflowLayoutForm)
    # setupUi

    def retranslateUi(self, WorkflowLayoutForm):
        WorkflowLayoutForm.setWindowTitle(QCoreApplication.translate("WorkflowLayoutForm", u"\u7f16\u8f91\u8fde\u63a5\u5e03\u5c40", None))
        self.import_mesh_action.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u5bfc\u5165\u5916\u90e8\u7f51\u683c", None))
        self.hint_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u5bfc\u5165 X / Y \u5750\u6807\u5e76\u5206\u914d\u6a21\u677f\uff1b\u53ef\u9009\u65cb\u8f6c\u89d2\u5ea6\u4ee5 \u00b0 \u8868\u793a\uff0c\u9006\u65f6\u9488\u4e3a\u6b63\u3002\u6a21\u677f\u5e73\u9762\u5c3a\u5bf8\u53ef\u4e0d\u540c\uff0c\u539a\u5ea6\u65b9\u5411\u7f51\u683c\u987b\u4e00\u81f4\u3002", None))
        self.bounds_group.setTitle(QCoreApplication.translate("WorkflowLayoutForm", u"\u8fde\u63a5\u533a\u57df", None))
        self.x_min_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"X \u6700\u5c0f", None))
        self.x_min_spin.setSuffix(QCoreApplication.translate("WorkflowLayoutForm", u" \u00b5m", None))
        self.x_max_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"X \u6700\u5927", None))
        self.x_max_spin.setSuffix(QCoreApplication.translate("WorkflowLayoutForm", u" \u00b5m", None))
        self.y_min_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"Y \u6700\u5c0f", None))
        self.y_min_spin.setSuffix(QCoreApplication.translate("WorkflowLayoutForm", u" \u00b5m", None))
        self.y_max_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"Y \u6700\u5927", None))
        self.y_max_spin.setSuffix(QCoreApplication.translate("WorkflowLayoutForm", u" \u00b5m", None))
        self.templates_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u6a21\u677f\uff08\u53ef\u53cc\u51fb\u4fee\u6539\u522b\u540d\uff09", None))
        self.add_asset_button.setText(QCoreApplication.translate("WorkflowLayoutForm", u"+", None))
#if QT_CONFIG(tooltip)
        self.add_asset_button.setToolTip(QCoreApplication.translate("WorkflowLayoutForm", u"\u6dfb\u52a0\u5f53\u524d\u9009\u4e2d\u7684\u6a21\u677f\uff1b\u5c55\u5f00\u83dc\u5355\u53ef\u5bfc\u5165\u5916\u90e8\u7f51\u683c", None))
#endif // QT_CONFIG(tooltip)
        self.remove_template_button.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u2212", None))
#if QT_CONFIG(tooltip)
        self.remove_template_button.setToolTip(QCoreApplication.translate("WorkflowLayoutForm", u"\u79fb\u9664\u9009\u4e2d\u7684\u6a21\u677f", None))
#endif // QT_CONFIG(tooltip)
        ___qtablewidgetitem = self.template_table.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u6a21\u677f\u522b\u540d", None))
        ___qtablewidgetitem1 = self.template_table.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u7f51\u683c\u6587\u4ef6", None))
        self.default_template_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u9ed8\u8ba4\u6a21\u677f", None))
        self.import_coordinates_button.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u5bfc\u5165 Excel / CSV", None))
        self.coordinate_unit_combo.setItemText(0, QCoreApplication.translate("WorkflowLayoutForm", u"\u00b5m", None))
        self.coordinate_unit_combo.setItemText(1, QCoreApplication.translate("WorkflowLayoutForm", u"mm", None))

        self.import_mode_combo.setItemText(0, QCoreApplication.translate("WorkflowLayoutForm", u"\u66ff\u6362\u5168\u90e8\u4f4d\u7f6e", None))
        self.import_mode_combo.setItemText(1, QCoreApplication.translate("WorkflowLayoutForm", u"\u8ffd\u52a0\u4f4d\u7f6e", None))

        self.expand_bounds_check.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u81ea\u52a8\u6269\u5927\u8fde\u63a5\u533a\u57df\u4ee5\u5bb9\u7eb3 bump", None))
        self.import_hint_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u9996\u884c\u4e3a x\u3001y\uff0c\u53ef\u9009 rotation\uff08\u5ea6\uff09\uff1b\u65e0\u5355\u4f4d\u6570\u503c\u4f7f\u7528\u4e0a\u65b9\u5355\u4f4d\u3002", None))
        self.instances_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u6a21\u677f\u653e\u7f6e\uff08\u4e2d\u5fc3\u5750\u6807\uff09", None))
        self.add_instance_button.setText(QCoreApplication.translate("WorkflowLayoutForm", u"+", None))
#if QT_CONFIG(tooltip)
        self.add_instance_button.setToolTip(QCoreApplication.translate("WorkflowLayoutForm", u"\u6dfb\u52a0\u4e00\u5904\u6a21\u677f\u653e\u7f6e", None))
#endif // QT_CONFIG(tooltip)
        self.remove_instance_button.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u2212", None))
#if QT_CONFIG(tooltip)
        self.remove_instance_button.setToolTip(QCoreApplication.translate("WorkflowLayoutForm", u"\u5220\u9664\u9009\u4e2d\u7684\u653e\u7f6e", None))
#endif // QT_CONFIG(tooltip)
        self.batch_template_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u9009\u4e2d\u9879\u6a21\u677f", None))
        self.apply_template_button.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u5e94\u7528\u5230\u9009\u4e2d", None))
        self.editor_tabs.setTabText(self.editor_tabs.indexOf(self.placements_tab), QCoreApplication.translate("WorkflowLayoutForm", u"\u6a21\u677f\u4e0e\u653e\u7f6e", None))
        self.regions_hint_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u70b9\u51fb\u201c\u6846\u9009\u52a0\u5bc6\u533a\u201d\uff0c\u5728\u9884\u89c8\u4e2d\u62d6\u52a8\u6846\u9009\u540e\u8bbe\u7f6e\u76ee\u6807\u5c3a\u5bf8\u3002\u5750\u6807\u4e0e\u7f51\u683c\u5c3a\u5bf8\u5355\u4f4d\u5747\u4e3a \u00b5m\u3002\u533a\u57df\u987b\u4f4d\u4e8e\u8fde\u63a5\u8303\u56f4\u5185\uff0c\u5f7c\u6b64\u4e0d\u80fd\u63a5\u89e6\u6216\u91cd\u53e0\uff0c\u5e76\u907f\u5f00 bump\uff1b\u624b\u52a8\u7f16\u8f91\u65f6\uff0cX / Y \u8303\u56f4\u987b\u5206\u522b\u4e3a\u5bf9\u5e94\u7f51\u683c\u5c3a\u5bf8\u7684\u6574\u6570\u500d\u3002", None))
        self.regions_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u52a0\u5bc6\u533a\u57df\uff08\u53cc\u51fb\u6570\u503c\u7f16\u8f91\uff09", None))
        self.add_region_button.setText(QCoreApplication.translate("WorkflowLayoutForm", u"+", None))
#if QT_CONFIG(tooltip)
        self.add_region_button.setToolTip(QCoreApplication.translate("WorkflowLayoutForm", u"\u6dfb\u52a0\u4e00\u5904\u5c40\u90e8\u52a0\u5bc6\u533a", None))
#endif // QT_CONFIG(tooltip)
        self.remove_region_button.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u2212", None))
#if QT_CONFIG(tooltip)
        self.remove_region_button.setToolTip(QCoreApplication.translate("WorkflowLayoutForm", u"\u5220\u9664\u9009\u4e2d\u7684\u5c40\u90e8\u52a0\u5bc6\u533a", None))
#endif // QT_CONFIG(tooltip)
        self.region_status_label.setText("")
        self.editor_tabs.setTabText(self.editor_tabs.indexOf(self.regions_tab), QCoreApplication.translate("WorkflowLayoutForm", u"\u5c40\u90e8\u52a0\u5bc6\u533a", None))
        self.view_title_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"Bump \u5e73\u9762\u89c6\u56fe", None))
        self.draw_region_button.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u6846\u9009\u52a0\u5bc6\u533a", None))
#if QT_CONFIG(tooltip)
        self.draw_region_button.setToolTip(QCoreApplication.translate("WorkflowLayoutForm", u"\u5de6\u952e\u62d6\u52a8\u77e9\u5f62\u8bbe\u7f6e\u5c40\u90e8\u52a0\u5bc6\u533a\uff0cEsc \u53d6\u6d88", None))
#endif // QT_CONFIG(tooltip)
        self.fit_view_button.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u9002\u5e94\u5168\u90e8", None))
        self.select_all_button.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u5168\u9009", None))
        self.clear_selection_button.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u6e05\u7a7a\u9009\u62e9", None))
        self.template_legend_label.setText("")
        self.selection_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u5171 0 \u4e2a bump \u00b7 \u5df2\u9009 0 \u4e2a", None))
        self.cursor_position_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u9f20\u6807\u5750\u6807\uff1a\u2014\uff08\u00b5m\uff09", None))
        self.view_hint_label.setText(QCoreApplication.translate("WorkflowLayoutForm", u"\u5de6\u952e\u70b9\u9009 / \u6846\u9009 \u00b7 Ctrl + \u5de6\u952e\u8ffd\u52a0 \u00b7 Ctrl + \u53f3\u952e\u53d6\u6d88\u9009\u4e2d\n"
"\u6eda\u8f6e\u7f29\u653e \u00b7 \u4e2d\u952e / \u53f3\u952e\u62d6\u52a8\u5e73\u79fb \u00b7 \u653e\u5927\u81ea\u52a8\u663e\u793a\u6a21\u677f\u5e73\u9762\u7f51\u683c \u00b7 \u7eff\u8272\u6846\u4e3a\u5c40\u90e8\u52a0\u5bc6\u533a\n"
"\u70b9\u51fb\u201c\u6846\u9009\u52a0\u5bc6\u533a\u201d\u540e\u5de6\u952e\u62d6\u52a8\uff0c\u677e\u5f00\u8bbe\u7f6e\u76ee\u6807\u5c3a\u5bf8\uff1bEsc \u53d6\u6d88\u6846\u9009\u3002", None))
        self.error_label.setText("")
        self.error_label.setStyleSheet(QCoreApplication.translate("WorkflowLayoutForm", u"color: #d9534f;", None))
        self.buttons.setProperty(u"acceptText", QCoreApplication.translate("WorkflowLayoutForm", u"\u5e94\u7528\u8fde\u63a5\u5e03\u5c40", None))
        self.buttons.setProperty(u"cancelText", QCoreApplication.translate("WorkflowLayoutForm", u"\u53d6\u6d88", None))
        self.buttons.setProperty(u"resetText", QCoreApplication.translate("WorkflowLayoutForm", u"\u65b0\u5efa\u7a7a\u5e03\u5c40", None))
        self.buttons.setProperty(u"resetToolTip", QCoreApplication.translate("WorkflowLayoutForm", u"\u6e05\u7a7a\u672c\u6b21\u7f16\u8f91\u7684\u5e03\u5c40\u5e76\u91cd\u65b0\u653e\u7f6e\uff1b\u53d6\u6d88\u53ef\u4fdd\u7559\u539f\u5e03\u5c40\u3002", None))
    # retranslateUi
