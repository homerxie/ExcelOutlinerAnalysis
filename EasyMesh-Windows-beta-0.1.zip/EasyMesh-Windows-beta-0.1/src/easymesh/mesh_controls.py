"""Stable section intervals for local mesh-size overrides.

The section geometry supplies every radial and vertical boundary.  This module
turns each pair of adjacent boundaries into an interval suitable for a GUI
table or a saved override mapping; it deliberately makes no meshing-strategy
decisions.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import math
from typing import TypeAlias

from .section import SectionPlan


_POSITION_DECIMALS = 10
SizeValue: TypeAlias = float | int | str


class ControlAxis(str, Enum):
    """Supported local-size directions: radial and vertical.

    ``RADIAL`` controls only the radius direction within the xy plane.  It does
    not represent, imply, or override an azimuthal/circumferential mesh size.
    """

    RADIAL = "radial"
    ANGULAR = "angular"
    Z = "z"


def _canonical_position(position_um: float) -> float:
    """Remove insignificant construction noise from a position in microns."""

    value = round(float(position_um), _POSITION_DECIMALS)
    # Do not leak a negative zero into persisted keys or labels.
    return 0.0 if value == 0.0 else value


def _format_number(value: float) -> str:
    return f"{_canonical_position(value):g}"


@dataclass(frozen=True, slots=True)
class MeshControlInterval:
    """A named radial or vertical interval with one optional target size."""

    identifier: str
    axis: ControlAxis
    start_um: float
    end_um: float
    contour_dimensions_um: tuple[tuple[float, float], tuple[float, float]] | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.identifier, str):
            raise ValueError("identifier must be a non-empty string")
        identifier = self.identifier.strip()
        if not identifier:
            raise ValueError("identifier must not be empty")
        object.__setattr__(self, "identifier", identifier)

        if isinstance(self.axis, str) and not isinstance(self.axis, ControlAxis):
            try:
                object.__setattr__(self, "axis", ControlAxis(self.axis))
            except ValueError as error:
                raise ValueError("axis must be 'radial', 'angular', or 'z'") from error
        if not isinstance(self.axis, ControlAxis):
            raise ValueError("axis must be a ControlAxis")

        positions: list[float] = []
        for field_name in ("start_um", "end_um"):
            source = getattr(self, field_name)
            if isinstance(source, bool):
                raise ValueError(f"{field_name} must be finite")
            try:
                position = float(source)
            except (TypeError, ValueError) as error:
                raise ValueError(f"{field_name} must be finite") from error
            if not math.isfinite(position):
                raise ValueError(f"{field_name} must be finite")
            positions.append(_canonical_position(position))

        start, end = positions
        if self.axis in (ControlAxis.RADIAL, ControlAxis.ANGULAR) and start < 0.0:
            raise ValueError("a radial interval must not start below zero")
        if end <= start:
            raise ValueError("end_um must be greater than start_um")
        object.__setattr__(self, "start_um", start)
        object.__setattr__(self, "end_um", end)

    @property
    def key(self) -> tuple[str, float, float]:
        """Stable key for an override mapping or serialized table row."""

        return (
            self.axis.value,
            _canonical_position(self.start_um),
            _canonical_position(self.end_um),
        )

    @property
    def midpoint_um(self) -> float:
        """Midpoint used to place the interval label in a preview."""

        return _canonical_position(0.5 * (self.start_um + self.end_um))

    @property
    def midpoint(self) -> float:
        """Concise alias for renderers; the value is expressed in microns."""

        return self.midpoint_um

    @property
    def display_position(self) -> str:
        """Compact range used by the control tables, without repeated units."""

        if self.contour_dimensions_um is not None:
            inner, outer = self.contour_dimensions_um
            label = lambda pair: "×".join(_format_number(value) for value in pair)
            return f"{'中心' if inner == (0.0, 0.0) else label(inner)} → {label(outer)}"
        if self.axis is ControlAxis.RADIAL:
            return (
                f"{_format_number(2.0 * self.start_um)}–"
                f"{_format_number(2.0 * self.end_um)}"
            )
        return f"{_format_number(self.start_um)}–{_format_number(self.end_um)}"

    @property
    def display_position_tooltip(self) -> str:
        """Expanded position description retained for hover help."""

        if self.contour_dimensions_um is not None:
            core = self.contour_dimensions_um[0] == (0.0, 0.0)
            return (
                f"内轮廓 → 外轮廓（长轴×短轴）：{self.display_position} µm；"
                f"{'中心线至轮廓距离' if core else '局部法向宽度'} {self.display_width} µm。"
                "R 与轮廓边尺寸独立设置。"
            )
        if self.axis is ControlAxis.RADIAL:
            return (
                f"半径 {_format_number(self.start_um)}–{_format_number(self.end_um)} µm；"
                f"直径 d={self.display_position} µm"
            )
        return f"高度 z={self.display_position} µm"

    @property
    def width_range_um(self) -> tuple[float, float]:
        if self.contour_dimensions_um is not None:
            inner, outer = self.contour_dimensions_um
            if inner == (0.0, 0.0):
                return outer[1] * .5, outer[1] * .5
            gaps = tuple((b - a) * 0.5 for a, b in zip(inner, outer))
            return min(gaps), max(gaps)
        width = self.end_um - self.start_um
        return width, width

    @property
    def display_width(self) -> str:
        lower, upper = self.width_range_um
        return (_format_number(lower) if lower == upper else
                f"{_format_number(lower)}–{_format_number(upper)}")

    def effective_size(
        self,
        global_size_um: SizeValue,
        override_size_um: SizeValue | None = None,
    ) -> float:
        """Resolve this interval's size using the same validation as the GUI."""

        return effective_size(global_size_um, override_size_um)


def _ordered_canonical_positions(values: tuple[float, ...]) -> tuple[float, ...]:
    """Sort and deduplicate boundary values at persisted-key precision."""

    return tuple(sorted({_canonical_position(value) for value in values}))


def build_section_control_intervals(plan: SectionPlan) -> tuple[MeshControlInterval, ...]:
    """Turn adjacent section boundaries into stable radial and vertical rows.

    Radial intervals start at the centre and are numbered from the inside out as
    ``R01``, ``R02``, ... .  Vertical intervals are numbered bottom-to-top as
    ``Z01``, ``Z02``, ... .  Radial rows precede vertical rows in the returned
    tuple so the two directions form deterministic table groups.
    """

    if not isinstance(plan, SectionPlan):
        raise TypeError("plan must be a SectionPlan")

    radial_positions = _ordered_canonical_positions(plan.radius_breakpoints_um)
    z_positions = _ordered_canonical_positions(plan.z_breakpoints_um)
    contours = tuple(getattr(plan, "contours", ()))
    dimensions = (((0.0, 0.0),) + tuple(
        (contour.long_diameter_um, contour.short_diameter_um) for contour in contours
    )) if getattr(plan, "is_oblong", False) else ()

    radial = tuple(
        MeshControlInterval(
            f"R{index:02d}", ControlAxis.RADIAL, start, end,
            (dimensions[index - 1], dimensions[index]) if dimensions else None,
        )
        for index, (start, end) in enumerate(
            zip(radial_positions, radial_positions[1:]), start=1
        )
    )
    vertical = tuple(
        MeshControlInterval(f"Z{index:02d}", ControlAxis.Z, start, end)
        for index, (start, end) in enumerate(
            zip(z_positions, z_positions[1:]), start=1
        )
    )
    return radial + vertical


def _positive_finite_size(value: SizeValue, *, field_name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{field_name} must be a positive finite number")
    try:
        parsed = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{field_name} must be a positive finite number") from error
    if not math.isfinite(parsed) or parsed <= 0.0:
        raise ValueError(f"{field_name} must be a positive finite number")
    return parsed


def validate_size_override(value: SizeValue | None) -> float | None:
    """Validate an optional local size in microns.

    ``None`` and blank strings mean "use the global size".  Any supplied value
    must be finite and strictly positive.
    """

    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    return _positive_finite_size(value, field_name="override size")


def effective_size(
    global_size_um: SizeValue,
    override_size_um: SizeValue | None = None,
) -> float:
    """Return a validated local override, or the validated global target size."""

    global_size = _positive_finite_size(global_size_um, field_name="global size")
    override_size = validate_size_override(override_size_um)
    return global_size if override_size is None else override_size


__all__ = [
    "ControlAxis",
    "MeshControlInterval",
    "build_section_control_intervals",
    "effective_size",
    "validate_size_override",
]
