# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'layer_sweep.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QCheckBox, QComboBox,
    QDialog, QDialogButtonBox, QDoubleSpinBox, QFormLayout,
    QLabel, QSizePolicy, QVBoxLayout, QWidget)

class Ui_LayerSweepForm(object):
    def setupUi(self, LayerSweepForm):
        if not LayerSweepForm.objectName():
            LayerSweepForm.setObjectName(u"LayerSweepForm")
        LayerSweepForm.resize(480, 380)
        self.root_layout = QVBoxLayout(LayerSweepForm)
        self.root_layout.setObjectName(u"root_layout")
        self.note = QLabel(LayerSweepForm)
        self.note.setObjectName(u"note")
        self.note.setWordWrap(True)
        self.note.setTextFormat(Qt.PlainText)

        self.root_layout.addWidget(self.note)

        self.inherit_checkbox = QCheckBox(LayerSweepForm)
        self.inherit_checkbox.setObjectName(u"inherit_checkbox")

        self.root_layout.addWidget(self.inherit_checkbox)

        self.policy_form = QFormLayout()
        self.policy_form.setObjectName(u"policy_form")
        self.policy_form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        self.constraint_label = QLabel(LayerSweepForm)
        self.constraint_label.setObjectName(u"constraint_label")
        self.constraint_label.setWordWrap(True)
        self.constraint_label.setTextFormat(Qt.PlainText)

        self.policy_form.setWidget(0, QFormLayout.ItemRole.LabelRole, self.constraint_label)

        self.constraint_combo = QComboBox(LayerSweepForm)
        self.constraint_combo.addItem("")
        self.constraint_combo.addItem("")
        self.constraint_combo.setObjectName(u"constraint_combo")

        self.policy_form.setWidget(0, QFormLayout.ItemRole.FieldRole, self.constraint_combo)

        self.direction_label = QLabel(LayerSweepForm)
        self.direction_label.setObjectName(u"direction_label")
        self.direction_label.setWordWrap(True)
        self.direction_label.setTextFormat(Qt.PlainText)

        self.policy_form.setWidget(1, QFormLayout.ItemRole.LabelRole, self.direction_label)

        self.direction_combo = QComboBox(LayerSweepForm)
        self.direction_combo.addItem("")
        self.direction_combo.addItem("")
        self.direction_combo.addItem("")
        self.direction_combo.setObjectName(u"direction_combo")

        self.policy_form.setWidget(1, QFormLayout.ItemRole.FieldRole, self.direction_combo)

        self.merge_label = QLabel(LayerSweepForm)
        self.merge_label.setObjectName(u"merge_label")
        self.merge_label.setWordWrap(True)
        self.merge_label.setTextFormat(Qt.PlainText)

        self.policy_form.setWidget(2, QFormLayout.ItemRole.LabelRole, self.merge_label)

        self.merge_spin = QDoubleSpinBox(LayerSweepForm)
        self.merge_spin.setObjectName(u"merge_spin")
        self.merge_spin.setDecimals(3)
        self.merge_spin.setMinimum(0.001000000000000)
        self.merge_spin.setMaximum(1.000000000000000)
        self.merge_spin.setSingleStep(0.050000000000000)
        self.merge_spin.setValue(0.250000000000000)

        self.policy_form.setWidget(2, QFormLayout.ItemRole.FieldRole, self.merge_spin)

        self.center_label = QLabel(LayerSweepForm)
        self.center_label.setObjectName(u"center_label")
        self.center_label.setWordWrap(True)
        self.center_label.setTextFormat(Qt.PlainText)

        self.policy_form.setWidget(3, QFormLayout.ItemRole.LabelRole, self.center_label)

        self.center_spin = QDoubleSpinBox(LayerSweepForm)
        self.center_spin.setObjectName(u"center_spin")
        self.center_spin.setDecimals(3)
        self.center_spin.setMinimum(0.001000000000000)
        self.center_spin.setMaximum(1.000000000000000)
        self.center_spin.setSingleStep(0.050000000000000)
        self.center_spin.setValue(0.250000000000000)

        self.policy_form.setWidget(3, QFormLayout.ItemRole.FieldRole, self.center_spin)


        self.root_layout.addLayout(self.policy_form)

        self.help_label = QLabel(LayerSweepForm)
        self.help_label.setObjectName(u"help_label")
        self.help_label.setWordWrap(True)
        self.help_label.setTextFormat(Qt.PlainText)

        self.root_layout.addWidget(self.help_label)

        self.buttons = QDialogButtonBox(LayerSweepForm)
        self.buttons.setObjectName(u"buttons")
        self.buttons.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.root_layout.addWidget(self.buttons)


        self.retranslateUi(LayerSweepForm)

        QMetaObject.connectSlotsByName(LayerSweepForm)
    # setupUi

    def retranslateUi(self, LayerSweepForm):
        LayerSweepForm.setWindowTitle(QCoreApplication.translate("LayerSweepForm", u"\u9ad8\u7ea7\u7f51\u683c\u9009\u9879", None))
        self.note.setText(QCoreApplication.translate("LayerSweepForm", u"\u5728\u6b64 Z \u533a\u95f4\u5185\u5e03\u79cd\uff0c\u6750\u6599\u9ad8\u5ea6\u8fb9\u754c\u56fa\u5b9a\uff0c\u5c40\u90e8 Z \u5c3a\u5bf8\u4f18\u5148\u3002", None))
        self.note.setProperty(u"radialText", QCoreApplication.translate("LayerSweepForm", u"\u5c3a\u5bf8\u6309\u534a\u5f84\u65b9\u5411\u7684\u5b9e\u9645\u95f4\u8ddd\u8ba1\u7b97\uff1b\u8868\u4e2d d \u4e3a\u76f4\u5f84\u3002\u6750\u6599\u5706\u73af\u8fb9\u754c\u56fa\u5b9a\uff0c\u73af\u5411\u5c3a\u5bf8\u7531\u5168\u5c40 XY \u63a7\u5236\u3002", None))
        self.inherit_checkbox.setText(QCoreApplication.translate("LayerSweepForm", u"\u7ee7\u627f\u5168\u5c40 Z sweep \u7b56\u7565", None))
        self.inherit_checkbox.setProperty(u"radialText", QCoreApplication.translate("LayerSweepForm", u"\u4f7f\u7528\u9ed8\u8ba4\u5f84\u5411\u7b56\u7565\uff08\u5f31\u7ea6\u675f\uff09", None))
        self.constraint_label.setText(QCoreApplication.translate("LayerSweepForm", u"\u7ea6\u675f\u5f3a\u5ea6", None))
        self.constraint_combo.setItemText(0, QCoreApplication.translate("LayerSweepForm", u"\u5f31\u7ea6\u675f\uff1a\u5141\u8bb8\u8c03\u6574\u6b65\u957f", None))
        self.constraint_combo.setItemText(1, QCoreApplication.translate("LayerSweepForm", u"\u5f3a\u7ea6\u675f\uff1a\u56fa\u5b9a seed\uff0c\u4f59\u91cf\u6536\u5c3e", None))

        self.direction_label.setText(QCoreApplication.translate("LayerSweepForm", u"Seed \u65b9\u5411", None))
        self.direction_combo.setItemText(0, QCoreApplication.translate("LayerSweepForm", u"\u2212Z \u9762 \u2192 +Z\uff08\u4ece\u4e0b\u5f80\u4e0a\uff09", None))
        self.direction_combo.setItemText(1, QCoreApplication.translate("LayerSweepForm", u"+Z \u9762 \u2192 \u2212Z\uff08\u4ece\u4e0a\u5f80\u4e0b\uff09", None))
        self.direction_combo.setItemText(2, QCoreApplication.translate("LayerSweepForm", u"\u2212Z / +Z \u4e24\u9762 \u2192 \u4e2d\u95f4", None))

        self.direction_combo.setProperty(u"radialText0", QCoreApplication.translate("LayerSweepForm", u"\u7531\u5185\u5411\u5916", None))
        self.direction_combo.setProperty(u"radialText1", QCoreApplication.translate("LayerSweepForm", u"\u7531\u5916\u5411\u5185", None))
        self.direction_combo.setProperty(u"radialText2", QCoreApplication.translate("LayerSweepForm", u"\u5185\u5916\u4e24\u7aef \u2192 \u4e2d\u95f4", None))
        self.merge_label.setText(QCoreApplication.translate("LayerSweepForm", u"Merge \u8fb9\u754c\u6bd4\u4f8b", None))
        self.center_label.setText(QCoreApplication.translate("LayerSweepForm", u"\u4e2d\u5fc3\u5408\u5e76\u6bd4\u4f8b", None))
        self.help_label.setProperty(u"movingCapText", QCoreApplication.translate("LayerSweepForm", u"\u53d8\u5706\u5fc3 Oblong\uff1a\u5f31\u7ea6\u675f\u4ee5\u9ed8\u8ba4 0.25 \u6bd4\u4f8b\u6e05\u7406\u7ec6\u5c0f\u672b\u7aef\u4f59\u91cf\uff0c\u518d\u91cd\u5e03 R \u4e0e\u73af\u5411 seed\uff0c\u5e76\u5c06\u4f4d\u79fb\u5e73\u7f13\u4f20\u64ad\u81f3\u5468\u8fb9\uff0c\u517c\u987e\u5c3a\u5bf8\u5747\u5300\u4e0e\u5c42\u7ebf\u6d41\u7545\uff1b\u4e0a\u9762\u7684\u6bd4\u4f8b\u4ec5\u63a7\u5236\u5f3a\u7ea6\u675f\u3002\u9002\u5408\u7684\u76f8\u90bb\u4e09\u89d2\u5f62\u4f18\u5148\u5408\u6210\u56db\u8fb9\u5f62\uff0c\u5408\u5e76\u4e0e\u91cd\u5e03\u5747\u987b\u4fdd\u6301\u5355\u5143\u51f8\u6027\u3001\u5c42\u5e8f\u548c\u8fb9\u754c\u5171\u5f62\u3002", None))
        self.help_label.setText(QCoreApplication.translate("LayerSweepForm", u"\u6bd4\u4f8b = \u5269\u4f59\u5355\u5143\u5c3a\u5bf8 / \u5f53\u524d seed \u5c3a\u5bf8\u3002\n"
"\u5355\u5411\uff1a\u4f4e\u4e8e Merge \u8fb9\u754c\u6bd4\u4f8b\uff0c\u5408\u5e76\u5230\u524d\u4e00\u5355\u5143\u3002\n"
"\u53cc\u5411\uff1a\u4f4e\u4e8e Merge \u8fb9\u754c\u6bd4\u4f8b\uff0c\u5404\u81ea\u5408\u5e76\u5230\u672c\u4fa7\u524d\u4e00\u5355\u5143\uff1b\u5426\u5219\u4e0d\u8d85\u8fc7\u4e2d\u5fc3\u5408\u5e76\u6bd4\u4f8b\u65f6\u5408\u6210\u4e00\u4e2a\u4e2d\u5fc3\u5355\u5143\uff0c\u8d85\u8fc7\u65f6\u4fdd\u7559\u4e24\u4e2a\u3002\n"
"\u6ca1\u6709\u524d\u4e00\u5355\u5143\u65f6\u4fdd\u7559\u533a\u95f4\u8fb9\u754c\u3002\u9ed8\u8ba4\u6bd4\u4f8b\u4e3a 0.25 / 0.5\u3002", None))
        self.buttons.setProperty(u"acceptText", QCoreApplication.translate("LayerSweepForm", u"\u786e\u5b9a", None))
        self.buttons.setProperty(u"cancelText", QCoreApplication.translate("LayerSweepForm", u"\u53d6\u6d88", None))
    # retranslateUi
