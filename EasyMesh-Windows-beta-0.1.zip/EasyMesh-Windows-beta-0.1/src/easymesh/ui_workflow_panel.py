# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'workflow_panel.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QDockWidget, QHBoxLayout,
    QHeaderView, QLabel, QMenu, QPushButton,
    QSizePolicy, QTabWidget, QToolButton, QTreeWidget,
    QTreeWidgetItem, QVBoxLayout, QWidget)

class Ui_WorkflowPanel(object):
    def setupUi(self, workflow_resources_dock):
        if not workflow_resources_dock.objectName():
            workflow_resources_dock.setObjectName(u"workflow_resources_dock")
        workflow_resources_dock.setMinimumSize(QSize(360, 0))
        workflow_resources_dock.setAllowedAreas(Qt.LeftDockWidgetArea|Qt.RightDockWidgetArea)
        self.batch_z_action = QAction(workflow_resources_dock)
        self.batch_z_action.setObjectName(u"batch_z_action")
        self.generate_templates_action = QAction(workflow_resources_dock)
        self.generate_templates_action.setObjectName(u"generate_templates_action")
        self.duplicate_template_action = QAction(workflow_resources_dock)
        self.duplicate_template_action.setObjectName(u"duplicate_template_action")
        self.rename_template_action = QAction(workflow_resources_dock)
        self.rename_template_action.setObjectName(u"rename_template_action")
        self.scale_xy_action = QAction(workflow_resources_dock)
        self.scale_xy_action.setObjectName(u"scale_xy_action")
        self.remove_templates_action = QAction(workflow_resources_dock)
        self.remove_templates_action.setObjectName(u"remove_templates_action")
        self.asset_to_cdb_action = QAction(workflow_resources_dock)
        self.asset_to_cdb_action.setObjectName(u"asset_to_cdb_action")
        self.import_scheme_action = QAction(workflow_resources_dock)
        self.import_scheme_action.setObjectName(u"import_scheme_action")
        self.save_scheme_action = QAction(workflow_resources_dock)
        self.save_scheme_action.setObjectName(u"save_scheme_action")
        self.save_scheme_as_action = QAction(workflow_resources_dock)
        self.save_scheme_as_action.setObjectName(u"save_scheme_as_action")
        self.edit_template_action = QAction(workflow_resources_dock)
        self.edit_template_action.setObjectName(u"edit_template_action")
        self.single_to_layout_action = QAction(workflow_resources_dock)
        self.single_to_layout_action.setObjectName(u"single_to_layout_action")
        self.single_to_cdb_action = QAction(workflow_resources_dock)
        self.single_to_cdb_action.setObjectName(u"single_to_cdb_action")
        self.connected_rename_action = QAction(workflow_resources_dock)
        self.connected_rename_action.setObjectName(u"connected_rename_action")
        self.connected_remove_action = QAction(workflow_resources_dock)
        self.connected_remove_action.setObjectName(u"connected_remove_action")
        self.dock_content = QWidget()
        self.dock_content.setObjectName(u"dock_content")
        self.batch_templates_menu = QMenu(self.dock_content)
        self.batch_templates_menu.setObjectName(u"batch_templates_menu")
        self.template_more_menu = QMenu(self.dock_content)
        self.template_more_menu.setObjectName(u"template_more_menu")
        self.use_asset_menu = QMenu(self.dock_content)
        self.use_asset_menu.setObjectName(u"use_asset_menu")
        self.root_layout = QVBoxLayout(self.dock_content)
        self.root_layout.setObjectName(u"root_layout")
        self.root_layout.setContentsMargins(0, 0, 0, 0)
        self.resource_tabs = QTabWidget(self.dock_content)
        self.resource_tabs.setObjectName(u"resource_tabs")
        self.templates_tab = QWidget()
        self.templates_tab.setObjectName(u"templates_tab")
        self.templates_layout = QVBoxLayout(self.templates_tab)
        self.templates_layout.setObjectName(u"templates_layout")
        self.templates_intro = QLabel(self.templates_tab)
        self.templates_intro.setObjectName(u"templates_intro")
        self.templates_intro.setWordWrap(True)
        self.templates_intro.setTextFormat(Qt.PlainText)

        self.templates_layout.addWidget(self.templates_intro)

        self.template_tree = QTreeWidget(self.templates_tab)
        self.template_tree.setObjectName(u"template_tree")
        self.template_tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.template_tree.setRootIsDecorated(False)

        self.templates_layout.addWidget(self.template_tree)

        self.template_actions_layout = QHBoxLayout()
        self.template_actions_layout.setObjectName(u"template_actions_layout")
        self.add_template_button = QPushButton(self.templates_tab)
        self.add_template_button.setObjectName(u"add_template_button")

        self.template_actions_layout.addWidget(self.add_template_button)

        self.batch_templates_button = QToolButton(self.templates_tab)
        self.batch_templates_button.setObjectName(u"batch_templates_button")
        self.batch_templates_button.setPopupMode(QToolButton.InstantPopup)
        self.batch_templates_button.setAutoRaise(True)

        self.template_actions_layout.addWidget(self.batch_templates_button)

        self.template_more_button = QToolButton(self.templates_tab)
        self.template_more_button.setObjectName(u"template_more_button")
        self.template_more_button.setPopupMode(QToolButton.InstantPopup)
        self.template_more_button.setAutoRaise(True)

        self.template_actions_layout.addWidget(self.template_more_button)


        self.templates_layout.addLayout(self.template_actions_layout)

        self.template_hint = QLabel(self.templates_tab)
        self.template_hint.setObjectName(u"template_hint")
        self.template_hint.setWordWrap(True)
        self.template_hint.setTextFormat(Qt.PlainText)

        self.templates_layout.addWidget(self.template_hint)

        self.templates_layout.setStretch(1, 1)
        self.resource_tabs.addTab(self.templates_tab, "")
        self.results_tab = QWidget()
        self.results_tab.setObjectName(u"results_tab")
        self.results_layout = QVBoxLayout(self.results_tab)
        self.results_layout.setObjectName(u"results_layout")
        self.results_intro = QLabel(self.results_tab)
        self.results_intro.setObjectName(u"results_intro")
        self.results_intro.setWordWrap(True)
        self.results_intro.setTextFormat(Qt.PlainText)

        self.results_layout.addWidget(self.results_intro)

        self.asset_tree = QTreeWidget(self.results_tab)
        self.asset_tree.setObjectName(u"asset_tree")
        self.asset_tree.setRootIsDecorated(False)

        self.results_layout.addWidget(self.asset_tree)

        self.asset_actions_layout = QHBoxLayout()
        self.asset_actions_layout.setObjectName(u"asset_actions_layout")
        self.use_asset_button = QToolButton(self.results_tab)
        self.use_asset_button.setObjectName(u"use_asset_button")
        self.use_asset_button.setPopupMode(QToolButton.MenuButtonPopup)
        self.use_asset_button.setAutoRaise(True)

        self.asset_actions_layout.addWidget(self.use_asset_button)

        self.import_mesh_button = QPushButton(self.results_tab)
        self.import_mesh_button.setObjectName(u"import_mesh_button")

        self.asset_actions_layout.addWidget(self.import_mesh_button)


        self.results_layout.addLayout(self.asset_actions_layout)

        self.asset_hint = QLabel(self.results_tab)
        self.asset_hint.setObjectName(u"asset_hint")
        self.asset_hint.setWordWrap(True)
        self.asset_hint.setTextFormat(Qt.PlainText)

        self.results_layout.addWidget(self.asset_hint)

        self.results_layout.setStretch(1, 1)
        self.resource_tabs.addTab(self.results_tab, "")

        self.root_layout.addWidget(self.resource_tabs)

        workflow_resources_dock.setWidget(self.dock_content)

        self.batch_templates_menu.addAction(self.batch_z_action)
        self.batch_templates_menu.addAction(self.generate_templates_action)
        self.template_more_menu.addAction(self.edit_template_action)
        self.template_more_menu.addAction(self.single_to_layout_action)
        self.template_more_menu.addAction(self.single_to_cdb_action)
        self.template_more_menu.addSeparator()
        self.template_more_menu.addAction(self.duplicate_template_action)
        self.template_more_menu.addAction(self.rename_template_action)
        self.template_more_menu.addAction(self.scale_xy_action)
        self.template_more_menu.addAction(self.remove_templates_action)
        self.template_more_menu.addSeparator()
        self.template_more_menu.addAction(self.import_scheme_action)
        self.template_more_menu.addAction(self.save_scheme_action)
        self.template_more_menu.addAction(self.save_scheme_as_action)
        self.use_asset_menu.addAction(self.asset_to_cdb_action)
        self.use_asset_menu.addSeparator()
        self.use_asset_menu.addAction(self.connected_rename_action)
        self.use_asset_menu.addAction(self.connected_remove_action)

        self.retranslateUi(workflow_resources_dock)

        QMetaObject.connectSlotsByName(workflow_resources_dock)
    # setupUi

    def retranslateUi(self, workflow_resources_dock):
        workflow_resources_dock.setWindowTitle(QCoreApplication.translate("WorkflowPanel", u"\u5e93", None))
        self.batch_z_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u7edf\u4e00 Z \u5c3a\u5bf8", None))
        self.generate_templates_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u751f\u6210\u6240\u9009\u6a21\u677f", None))
        self.duplicate_template_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u590d\u5236\u6a21\u677f", None))
        self.rename_template_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u91cd\u547d\u540d", None))
        self.scale_xy_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u5e73\u9762\u51e0\u4f55\u7f29\u653e", None))
        self.remove_templates_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u79fb\u51fa\u6a21\u677f\u5e93", None))
        self.asset_to_cdb_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u5bfc\u51fa CDB", None))
        self.import_scheme_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u5bfc\u5165\u7f51\u683c\u65b9\u6848\uff08\u8ffd\u52a0\uff09", None))
#if QT_CONFIG(tooltip)
        self.import_scheme_action.setToolTip(QCoreApplication.translate("WorkflowPanel", u"\u53ef\u591a\u9009\u65b9\u6848\u6587\u4ef6\uff0c\u6240\u6709\u5e93\u5185\u6a21\u677f\u4e0e\u5bfc\u5165\u65b9\u6848\u7684\u9ad8\u5ea6\u7f51\u683c\u517c\u5bb9\u540e\u8ffd\u52a0\uff1b\u4fdd\u7559\u5f53\u524d\u6a21\u677f\u548c\u7f16\u8f91\u8349\u7a3f\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.save_scheme_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u5bfc\u51fa\u5f53\u524d\u65b9\u6848", None))
        self.save_scheme_as_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u65b9\u6848\u53e6\u5b58\u4e3a", None))
        self.edit_template_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u7f16\u8f91\u6a21\u677f", None))
        self.single_to_layout_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u7528\u4e8e\u8fde\u63a5", None))
        self.single_to_cdb_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u5bfc\u51fa CDB", None))
        self.connected_rename_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u91cd\u547d\u540d", None))
        self.connected_remove_action.setText(QCoreApplication.translate("WorkflowPanel", u"\u79fb\u51fa Connected Bumps \u5e93", None))
        self.templates_intro.setText(QCoreApplication.translate("WorkflowPanel", u"\u72ec\u7acb\u4fdd\u5b58 Single Bump \u6a21\u677f\uff1b\u53cc\u51fb\u7f16\u8f91\u3002\n"
"Ctrl / \u2318 \u591a\u9009\u540e\u53ef\u7edf\u4e00 Z \u7f51\u683c\u3002", None))
        ___qtreewidgetitem = self.template_tree.headerItem()
        ___qtreewidgetitem.setText(2, QCoreApplication.translate("WorkflowPanel", u"\u72b6\u6001", None))
        ___qtreewidgetitem.setText(1, QCoreApplication.translate("WorkflowPanel", u"Z \u7f51\u683c", None))
        ___qtreewidgetitem.setText(0, QCoreApplication.translate("WorkflowPanel", u"\u6a21\u677f", None))
        self.add_template_button.setText(QCoreApplication.translate("WorkflowPanel", u"\u6536\u5f55\u5f53\u524d\u6a21\u677f", None))
        self.batch_templates_button.setText(QCoreApplication.translate("WorkflowPanel", u"\u6279\u91cf\u64cd\u4f5c", None))
        self.template_more_button.setText(QCoreApplication.translate("WorkflowPanel", u"\u66f4\u591a", None))
        self.template_hint.setText(QCoreApplication.translate("WorkflowPanel", u"\u6a21\u677f\u7684\u51e0\u4f55\u4e0e\u7f51\u683c\u8bbe\u7f6e\u72ec\u7acb\u4fdd\u5b58\uff1b\u751f\u6210\u540e\u53ef\u76f4\u63a5\u7528\u4e8e\u8fde\u63a5\u6216\u5bfc\u51fa CDB\u3002", None))
        self.resource_tabs.setTabText(self.resource_tabs.indexOf(self.templates_tab), QCoreApplication.translate("WorkflowPanel", u"Single Bump \u6a21\u677f\u5e93", None))
        self.results_intro.setText(QCoreApplication.translate("WorkflowPanel", u"\u8fde\u63a5\u5b8c\u6210\u7684 Bumps \u53ef\u76f4\u63a5\u52a0\u5165 Package\uff0c\n"
"\u4e5f\u53ef\u5355\u72ec\u5bfc\u51fa CDB\u3002", None))
        ___qtreewidgetitem1 = self.asset_tree.headerItem()
        ___qtreewidgetitem1.setText(1, QCoreApplication.translate("WorkflowPanel", u"\u72b6\u6001", None))
        ___qtreewidgetitem1.setText(0, QCoreApplication.translate("WorkflowPanel", u"Connected Bumps", None))
        self.use_asset_button.setText(QCoreApplication.translate("WorkflowPanel", u"\u52a0\u5165 Package", None))
        self.import_mesh_button.setText(QCoreApplication.translate("WorkflowPanel", u"\u5bfc\u5165 Connected Bumps", None))
        self.asset_hint.setText(QCoreApplication.translate("WorkflowPanel", u"\u9009\u62e9 Connected Bumps \u52a0\u5165 Package\uff1b\u4e5f\u53ef\u5bfc\u5165\u5916\u90e8\u8fde\u63a5\u7f51\u683c\u3002", None))
        self.resource_tabs.setTabText(self.resource_tabs.indexOf(self.results_tab), QCoreApplication.translate("WorkflowPanel", u"Connected Bumps \u5e93", None))
    # retranslateUi
