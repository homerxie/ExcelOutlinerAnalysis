from __future__ import annotations

import sys
from pathlib import Path


if __name__ == "__main__":
    # PyInstaller replaces freeze_support to dispatch spawn workers before
    # application imports or argparse see --multiprocessing-fork.
    import multiprocessing

    multiprocessing.freeze_support()
    if getattr(sys, "frozen", False):
        # Frozen Python does not honor every PYTHON* environment setting.
        # The console worker's JSON pipes and log files always use UTF-8.
        for stream in (sys.stdin, sys.stdout, sys.stderr):
            if stream is not None and hasattr(stream, "reconfigure"):
                stream.reconfigure(encoding="utf-8")

PROJECT_ROOT = Path(__file__).resolve().parent
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from easymesh.entrypoint import main  # noqa: E402


if __name__ == "__main__":
    raise SystemExit(main())

