"""Generate the committed PySide6 binding from Qt Designer sources."""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
UI_DIRECTORY = Path("ui")
GENERATED_DIRECTORY = Path("src/easymesh")


def _uic_executable() -> Path:
    executable_name = "pyside6-uic.exe" if os.name == "nt" else "pyside6-uic"
    adjacent = Path(sys.executable).with_name(executable_name)
    if adjacent.is_file():
        return adjacent
    discovered = shutil.which("pyside6-uic")
    if discovered:
        return Path(discovered)
    raise RuntimeError(
        "pyside6-uic was not found next to the active Python or on PATH; "
        "install the project's PySide6 dependency first"
    )


def _generate(source: Path, output: Path) -> None:
    subprocess.run(
        [
            str(_uic_executable()),
            str(source),
            "-o",
            str(output),
        ],
        cwd=PROJECT_ROOT,
        check=True,
    )
    # Keep the committed binding byte-for-byte stable when generated on
    # Windows (CRLF) or macOS/Linux (LF).
    generated = output.read_text(encoding="utf-8").rstrip() + "\n"
    with output.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write(generated)


def _portable_source_text(path: Path) -> str:
    """Read generated source with universal newline normalization."""

    with path.open("r", encoding="utf-8", newline=None) as stream:
        return stream.read()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Generate all src/easymesh/ui_*.py modules from ui/*.ui"
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="fail when the committed generated module is not up to date",
    )
    args = parser.parse_args(argv)

    sources = sorted((PROJECT_ROOT / UI_DIRECTORY).glob("*.ui"))
    stale = []
    with tempfile.TemporaryDirectory() as directory:
        for source in sources:
            module = GENERATED_DIRECTORY / f"ui_{source.stem}.py"
            target = PROJECT_ROOT / module
            output = Path(directory) / module.name if args.check else target
            _generate(source.relative_to(PROJECT_ROOT), output)
            if args.check:
                if not target.is_file() or _portable_source_text(output) != _portable_source_text(target):
                    stale.append(str(module))
            else:
                print(f"generated {module} from {source.relative_to(PROJECT_ROOT)}")
    if stale:
        print("generated UI modules are stale: " + ", ".join(stale)
              + f"; run: {sys.executable} scripts/generate_ui.py", file=sys.stderr)
        return 1
    print(f"{len(sources)} generated UI modules are up to date")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
