"""Portable dependency, worker and Gmsh smoke check for the Windows share ZIP."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import platform
import struct
import subprocess
import sys
import tempfile

import gmsh
import numpy
from PySide6.QtCore import qVersion
from PySide6.QtQuick3D import QQuick3DGeometry

from easymesh.app_runtime import worker_command_prefix, worker_environment
from easymesh.package_v2_compile import compile_package_v2
from easymesh.version import DISPLAY_VERSION, __version__


def check_worker(command: list[str], root: Path) -> None:
    """Exercise the actual Python or frozen worker, including its UTF-8 pipes."""

    def run(*arguments: str, input_text: str | None = None):
        result = subprocess.run(
            [*command, *arguments], env=worker_environment(),
            input=input_text, capture_output=True, text=True, encoding="utf-8",
            timeout=120,
            **({"creationflags": subprocess.CREATE_NO_WINDOW}
               if sys.platform == "win32" else {}),
        )
        if result.returncode:
            raise RuntimeError(
                f"Worker failed ({result.returncode}): {arguments}\n"
                f"{result.stdout}\n{result.stderr}"
            )
        return result.stdout

    assert "--package-v2-job" in run("--help")
    assert f"EasyMesh {DISPLAY_VERSION} ({__version__})" in run("--version")
    source = root / "examples/package_v2/generated_box.source.json"
    generation = "中文 管道 beta 0.1"
    payload = json.loads(run(
        "--package-v2-contact-preview",
        input_text=json.dumps({
            "source_text": source.read_text(encoding="utf-8"),
            "source_root": str(source.parent),
            "generation": generation,
        }, ensure_ascii=False),
    ))
    assert payload["generation"] == generation, payload
    assert not payload.get("error"), payload
    with tempfile.TemporaryDirectory(prefix="EasyMesh worker 中文 ") as directory:
        mesh = Path(directory) / "测试 mesh.msh"
        cdb = Path(directory) / "测试 mesh.cdb"
        run("--layer", str(root / "examples/bumpcell.layer"),
            "--xy-size", "20", "--z-size", "50", "--output", str(mesh))
        assert mesh.is_file() and mesh.stat().st_size > 0
        run("--convert-msh", str(mesh), "--output", str(cdb))
        assert cdb.is_file() and cdb.stat().st_size > 0
    print("Worker UTF-8 contact pipes, Layer meshing and CDB conversion: PASS")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--worker-executable", type=Path,
        help="Also verify a PyInstaller EasyMesh-worker.exe from the built folder",
    )
    args = parser.parse_args()
    assert sys.version_info >= (3, 10), "Python 3.10+ required"
    assert struct.calcsize("P") == 8, "64-bit Python required"
    print(f"Python {platform.python_version()} ({platform.machine()})")
    print(f"Gmsh {gmsh.__version__}; NumPy {numpy.__version__}; Qt {qVersion()}")
    print(f"Qt Quick 3D: {QQuick3DGeometry.__name__}")
    root = Path(__file__).resolve().parents[1]
    sources = [*sorted((root / "examples/package_v2").glob("*.source.json")),
               root / "examples/local_template_lid.source.json"]
    for source in sources:
        compile_package_v2(source.read_bytes(), source_root=source.parent, source_name=source.name)
        print(f"Source compiled: {source.name}")
    command = worker_command_prefix()
    if args.worker_executable is not None:
        executable = args.worker_executable.resolve(strict=True)
        command = [str(executable), "--worker"]
        print(f"Frozen worker: {executable}")
    check_worker(command, root)
    with tempfile.TemporaryDirectory(prefix="EasyMesh 中文 ") as directory:
        mesh = Path(directory) / "检查 mesh.msh"
        gmsh.initialize()
        try:
            gmsh.option.setNumber("General.Terminal", 0)
            gmsh.model.add("smoke")
            gmsh.model.occ.addBox(0, 0, 0, 1, 1, 1)
            gmsh.model.occ.synchronize()
            gmsh.option.setNumber("Mesh.MeshSizeMin", 0.5)
            gmsh.option.setNumber("Mesh.MeshSizeMax", 0.5)
            gmsh.model.mesh.generate(3)
            gmsh.write(str(mesh))
            assert mesh.stat().st_size > 0
            gmsh.clear()
            gmsh.open(str(mesh))
            element_count = sum(len(tags) for tags in gmsh.model.mesh.getElements(3)[1])
            assert element_count > 0, "No volume elements after reopening MSH"
            print(f"Native meshing and Unicode path round-trip: {element_count} volume elements")
        finally:
            gmsh.finalize()
    print("PASS: dependencies, source compilation, worker and native meshing")


if __name__ == "__main__":
    main()
