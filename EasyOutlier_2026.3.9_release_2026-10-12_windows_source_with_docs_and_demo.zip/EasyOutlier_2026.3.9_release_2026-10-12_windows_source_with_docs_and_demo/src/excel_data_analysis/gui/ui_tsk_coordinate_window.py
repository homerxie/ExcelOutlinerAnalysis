# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_coordinate_window.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog,
    QGridLayout, QHBoxLayout, QLabel, QPushButton,
    QSizePolicy, QSpacerItem, QVBoxLayout, QWidget)

from excel_data_analysis.gui.tsk_coordinate_plot import TskCoordinatePlot

class Ui_TskCoordinateWindowForm(object):
    def setupUi(self, TskCoordinateWindowForm):
        if not TskCoordinateWindowForm.objectName():
            TskCoordinateWindowForm.setObjectName(u"TskCoordinateWindowForm")
        TskCoordinateWindowForm.resize(1120, 800)
        TskCoordinateWindowForm.setMinimumSize(QSize(760, 540))
        TskCoordinateWindowForm.setModal(False)
        self.windowLayout = QVBoxLayout(TskCoordinateWindowForm)
        self.windowLayout.setSpacing(8)
        self.windowLayout.setObjectName(u"windowLayout")
        self.windowLayout.setContentsMargins(12, 12, 12, 12)
        self.contextLayout = QHBoxLayout()
        self.contextLayout.setObjectName(u"contextLayout")
        self.groupLabel = QLabel(TskCoordinateWindowForm)
        self.groupLabel.setObjectName(u"groupLabel")

        self.contextLayout.addWidget(self.groupLabel)

        self.groupComboBox = QComboBox(TskCoordinateWindowForm)
        self.groupComboBox.setObjectName(u"groupComboBox")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.groupComboBox.sizePolicy().hasHeightForWidth())
        self.groupComboBox.setSizePolicy(sizePolicy)
        self.groupComboBox.setMinimumContentsLength(10)
        self.groupComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)

        self.contextLayout.addWidget(self.groupComboBox)

        self.contextLabel = QLabel(TskCoordinateWindowForm)
        self.contextLabel.setObjectName(u"contextLabel")
        self.contextLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.contextLabel.setWordWrap(False)

        self.contextLayout.addWidget(self.contextLabel)


        self.windowLayout.addLayout(self.contextLayout)

        self.selectionLayout = QHBoxLayout()
        self.selectionLayout.setObjectName(u"selectionLayout")
        self.chainLabel = QLabel(TskCoordinateWindowForm)
        self.chainLabel.setObjectName(u"chainLabel")

        self.selectionLayout.addWidget(self.chainLabel)

        self.chainComboBox = QComboBox(TskCoordinateWindowForm)
        self.chainComboBox.setObjectName(u"chainComboBox")
        sizePolicy.setHeightForWidth(self.chainComboBox.sizePolicy().hasHeightForWidth())
        self.chainComboBox.setSizePolicy(sizePolicy)
        self.chainComboBox.setMinimumContentsLength(10)
        self.chainComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)

        self.selectionLayout.addWidget(self.chainComboBox)

        self.followCheckBox = QCheckBox(TskCoordinateWindowForm)
        self.followCheckBox.setObjectName(u"followCheckBox")
        self.followCheckBox.setChecked(True)

        self.selectionLayout.addWidget(self.followCheckBox)

        self.focusButton = QPushButton(TskCoordinateWindowForm)
        self.focusButton.setObjectName(u"focusButton")
        self.focusButton.setEnabled(False)

        self.selectionLayout.addWidget(self.focusButton)


        self.windowLayout.addLayout(self.selectionLayout)

        self.viewLayout = QHBoxLayout()
        self.viewLayout.setObjectName(u"viewLayout")
        self.outlineLabel = QLabel(TskCoordinateWindowForm)
        self.outlineLabel.setObjectName(u"outlineLabel")

        self.viewLayout.addWidget(self.outlineLabel)

        self.outlineComboBox = QComboBox(TskCoordinateWindowForm)
        self.outlineComboBox.addItem("")
        self.outlineComboBox.addItem("")
        self.outlineComboBox.addItem("")
        self.outlineComboBox.setObjectName(u"outlineComboBox")

        self.viewLayout.addWidget(self.outlineComboBox)

        self.labelsCheckBox = QCheckBox(TskCoordinateWindowForm)
        self.labelsCheckBox.setObjectName(u"labelsCheckBox")
        self.labelsCheckBox.setChecked(True)

        self.viewLayout.addWidget(self.labelsCheckBox)

        self.labelLayoutButton = QPushButton(TskCoordinateWindowForm)
        self.labelLayoutButton.setObjectName(u"labelLayoutButton")

        self.viewLayout.addWidget(self.labelLayoutButton)

        self.toolbarSpacer = QSpacerItem(16, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.viewLayout.addItem(self.toolbarSpacer)

        self.zoomOutButton = QPushButton(TskCoordinateWindowForm)
        self.zoomOutButton.setObjectName(u"zoomOutButton")

        self.viewLayout.addWidget(self.zoomOutButton)

        self.zoomInButton = QPushButton(TskCoordinateWindowForm)
        self.zoomInButton.setObjectName(u"zoomInButton")

        self.viewLayout.addWidget(self.zoomInButton)

        self.resetButton = QPushButton(TskCoordinateWindowForm)
        self.resetButton.setObjectName(u"resetButton")

        self.viewLayout.addWidget(self.resetButton)


        self.windowLayout.addLayout(self.viewLayout)

        self.selectionLabel = QLabel(TskCoordinateWindowForm)
        self.selectionLabel.setObjectName(u"selectionLabel")
        self.selectionLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.selectionLabel.setWordWrap(True)

        self.windowLayout.addWidget(self.selectionLabel)

        self.legendWidget = QWidget(TskCoordinateWindowForm)
        self.legendWidget.setObjectName(u"legendWidget")
        self.legendLayout = QGridLayout(self.legendWidget)
        self.legendLayout.setObjectName(u"legendLayout")
        self.legendLayout.setHorizontalSpacing(8)
        self.legendLayout.setContentsMargins(0, 0, 0, 0)
        self.pointLegendTitle = QLabel(self.legendWidget)
        self.pointLegendTitle.setObjectName(u"pointLegendTitle")

        self.legendLayout.addWidget(self.pointLegendTitle, 0, 0, 1, 1)

        self.pointGradient = QLabel(self.legendWidget)
        self.pointGradient.setObjectName(u"pointGradient")
        self.pointGradient.setMinimumSize(QSize(90, 10))
        self.pointGradient.setMaximumSize(QSize(90, 10))

        self.legendLayout.addWidget(self.pointGradient, 0, 1, 1, 1)

        self.pointLegendLabel = QLabel(self.legendWidget)
        self.pointLegendLabel.setObjectName(u"pointLegendLabel")

        self.legendLayout.addWidget(self.pointLegendLabel, 0, 2, 1, 1)

        self.selectionLegend = QLabel(self.legendWidget)
        self.selectionLegend.setObjectName(u"selectionLegend")

        self.legendLayout.addWidget(self.selectionLegend, 0, 3, 1, 1)

        self.ringLegendTitle = QLabel(self.legendWidget)
        self.ringLegendTitle.setObjectName(u"ringLegendTitle")

        self.legendLayout.addWidget(self.ringLegendTitle, 1, 0, 1, 1)

        self.ringGradient = QLabel(self.legendWidget)
        self.ringGradient.setObjectName(u"ringGradient")
        self.ringGradient.setMinimumSize(QSize(90, 10))
        self.ringGradient.setMaximumSize(QSize(90, 10))

        self.legendLayout.addWidget(self.ringGradient, 1, 1, 1, 1)

        self.ringLegendLabel = QLabel(self.legendWidget)
        self.ringLegendLabel.setObjectName(u"ringLegendLabel")

        self.legendLayout.addWidget(self.ringLegendLabel, 1, 2, 1, 1)

        self.missingLegend = QLabel(self.legendWidget)
        self.missingLegend.setObjectName(u"missingLegend")

        self.legendLayout.addWidget(self.missingLegend, 1, 3, 1, 1)

        self.interactionHint = QLabel(self.legendWidget)
        self.interactionHint.setObjectName(u"interactionHint")
        self.interactionHint.setWordWrap(True)

        self.legendLayout.addWidget(self.interactionHint, 2, 0, 1, 4)


        self.windowLayout.addWidget(self.legendWidget)

        self.coordinatePlot = TskCoordinatePlot(TskCoordinateWindowForm)
        self.coordinatePlot.setObjectName(u"coordinatePlot")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(1)
        sizePolicy1.setHeightForWidth(self.coordinatePlot.sizePolicy().hasHeightForWidth())
        self.coordinatePlot.setSizePolicy(sizePolicy1)
        self.coordinatePlot.setMinimumSize(QSize(320, 220))
        font = QFont()
        font.setPointSize(10)
        self.coordinatePlot.setFont(font)
        self.coordinatePlot.setMouseTracking(True)
        self.coordinatePlot.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.coordinatePlot.setProperty(u"labelZoomThreshold", 1.500000000000000)
        self.coordinatePlot.setProperty(u"maximumLabelWidth", 260)

        self.windowLayout.addWidget(self.coordinatePlot)

        self.statusLabel = QLabel(TskCoordinateWindowForm)
        self.statusLabel.setObjectName(u"statusLabel")
        self.statusLabel.setWordWrap(True)

        self.windowLayout.addWidget(self.statusLabel)

        self.windowLayout.setStretch(5, 1)
#if QT_CONFIG(shortcut)
        self.groupLabel.setBuddy(self.groupComboBox)
        self.chainLabel.setBuddy(self.chainComboBox)
        self.outlineLabel.setBuddy(self.outlineComboBox)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(TskCoordinateWindowForm)

        QMetaObject.connectSlotsByName(TskCoordinateWindowForm)
    # setupUi

    def retranslateUi(self, TskCoordinateWindowForm):
        TskCoordinateWindowForm.setWindowTitle(QCoreApplication.translate("TskCoordinateWindowForm", u"TSK \u5750\u6807\u56fe", None))
        TskCoordinateWindowForm.setProperty(u"contextFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"{mode} \u00b7 \u5750\u6807\u5355\u4f4d\uff1a{unit}", None))
        TskCoordinateWindowForm.setProperty(u"layoutModeText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u6a21\u677f\u5e03\u5c40\uff08\u6682\u65e0 Analyze \u89c2\u6d4b\uff09", None))
        TskCoordinateWindowForm.setProperty(u"observedModeText", QCoreApplication.translate("TskCoordinateWindowForm", u"Analyze \u89c2\u6d4b\uff08\u5c1a\u672a\u62df\u5408 TSK\uff09", None))
        TskCoordinateWindowForm.setProperty(u"fittedModeText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5df2\u4fdd\u5b58 TSK \u5206\u6790", None))
        TskCoordinateWindowForm.setProperty(u"emptyGroupText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5c1a\u65e0\u5206\u6790\u7ed3\u679c", None))
        TskCoordinateWindowForm.setProperty(u"unknownUnitText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u672a\u6307\u5b9a", None))
        TskCoordinateWindowForm.setProperty(u"allChainsText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5168\u90e8\u94fe\u8def\uff08\u6e05\u9664\u9ad8\u4eae\uff09", None))
        TskCoordinateWindowForm.setProperty(u"selectionFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"Chain {chain} \u00b7 \u5df2\u5b9a\u4f4d {shown}/{total} \u4e2a\u5b9e\u4f8b \u00b7 \u89c2\u6d4b {observed} \u00b7 \u9884\u6d4b {predicted}", None))
        TskCoordinateWindowForm.setProperty(u"noSelectionText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u70b9\u51fb\u5206\u6790\u4e2d\u7684 Chain \u540d\u79f0\u6216\u56fe\u4e2d\u7684\u70b9\u53ef\u9ad8\u4eae\u6574\u6761\u94fe\u3002", None))
        TskCoordinateWindowForm.setProperty(u"legendFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"{low} \u2192 {high}", None))
        TskCoordinateWindowForm.setProperty(u"unavailableText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u6682\u65e0\u6709\u6548\u98ce\u9669", None))
        TskCoordinateWindowForm.setProperty(u"statusFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5df2\u7ed8\u5236 {shown}/{total} \u4e2a\u5b9e\u4f8b \u00b7 \u7f3a\u5c11\u6709\u6548 XY\uff1a{missing} \u00b7 \u540c\u5750\u6807\u989d\u5916\u5b9e\u4f8b\uff1a{coincident} \u00b7 \u7f29\u653e {zoom}\u00d7 \u00b7 \u6807\u7b7e {labels}/{visible}", None))
        self.groupLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u8282\u70b9 / \u6279\u6b21", None))
        self.contextLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5c1a\u65e0\u5206\u6790\u7ed3\u679c", None))
        self.chainLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"Chain", None))
#if QT_CONFIG(tooltip)
        self.chainComboBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u9009\u62e9\u94fe\u8def\uff0c\u9ad8\u4eae\u5b83\u5728\u5e03\u5c40\u4e2d\u7684\u6240\u6709\u5b9e\u4f8b\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.followCheckBox.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u9009\u62e9\u65f6\u81ea\u52a8\u5b9a\u4f4d", None))
        self.focusButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5b9a\u4f4d\u9009\u4e2d\u94fe", None))
        self.outlineLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5916\u5708", None))
        self.outlineComboBox.setItemText(0, QCoreApplication.translate("TskCoordinateWindowForm", u"\u94fe\u8def\u89c2\u6d4b\u5931\u6548\u7387", None))
        self.outlineComboBox.setItemText(1, QCoreApplication.translate("TskCoordinateWindowForm", u"\u94fe\u8def\u9884\u6d4b\u5931\u6548\u7387", None))
        self.outlineComboBox.setItemText(2, QCoreApplication.translate("TskCoordinateWindowForm", u"\u4e0d\u663e\u793a", None))

        self.labelsCheckBox.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u653e\u5927\u663e\u793a\u5c5e\u6027", None))
        self.labelLayoutButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6807\u7b7e\u6392\u7248", None))
#if QT_CONFIG(tooltip)
        self.labelLayoutButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u62d6\u52a8\u5b57\u6bb5\u6807\u7b7e\uff0c\u5b89\u6392\u663e\u793a\u884c\u3001\u540c\u884c\u987a\u5e8f\u6216\u9690\u85cf\u5b57\u6bb5\u3002\u4fee\u6539\u4f1a\u7acb\u5373\u66f4\u65b0\u5750\u6807\u56fe\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.zoomOutButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u2212", None))
#if QT_CONFIG(tooltip)
        self.zoomOutButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u7f29\u5c0f", None))
#endif // QT_CONFIG(tooltip)
        self.zoomInButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\uff0b", None))
#if QT_CONFIG(tooltip)
        self.zoomInButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u653e\u5927", None))
#endif // QT_CONFIG(tooltip)
        self.resetButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u663e\u793a\u5168\u90e8", None))
        self.selectionLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u70b9\u51fb\u5206\u6790\u4e2d\u7684 Chain \u540d\u79f0\u6216\u56fe\u4e2d\u7684\u70b9\u53ef\u9ad8\u4eae\u6574\u6761\u94fe\u3002", None))
        self.pointLegendTitle.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u70b9\u8272 \u00b7 \u5b9e\u4f8b\u9884\u4f30\u5931\u6548\u7387", None))
        self.pointGradient.setStyleSheet(QCoreApplication.translate("TskCoordinateWindowForm", u"background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #23a5a0, stop:0.5 #edc65a, stop:1 #d1495b); border-radius: 3px;", None))
        self.pointLegendLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6682\u65e0\u6709\u6548\u98ce\u9669", None))
        self.selectionLegend.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u84dd\u8272\u5149\u5708\uff1a\u9009\u4e2d\u94fe\u8def", None))
        self.ringLegendTitle.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5916\u5708 \u00b7 \u94fe\u8def\u89c2\u6d4b\u5931\u6548\u7387", None))
        self.ringLegendTitle.setProperty(u"formatText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5916\u5708 \u00b7 {metric}", None))
        self.ringGradient.setStyleSheet(QCoreApplication.translate("TskCoordinateWindowForm", u"background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #23a5a0, stop:0.5 #edc65a, stop:1 #d1495b); border-radius: 3px;", None))
        self.ringLegendLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6682\u65e0\u6709\u6548\u98ce\u9669", None))
        self.missingLegend.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u7070\u8272\uff1a\u65e0\u6709\u6548\u4f30\u8ba1 / \u6d4b\u8bd5", None))
        self.interactionHint.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6eda\u8f6e\u7f29\u653e \u00b7 \u62d6\u52a8\u5e73\u79fb \u00b7 \u53cc\u51fb\u663e\u793a\u5168\u90e8 \u00b7 \u6807\u7b7e\u81ea\u52a8\u907f\u8ba9\uff0c\u60ac\u505c\u67e5\u770b\u5b8c\u6574\u5c5e\u6027\uff1b\u540c\u5750\u6807\u70b9\u53ef\u91cd\u590d\u70b9\u51fb\u5207\u6362\u94fe\u8def\u3002\u4e24\u79cd\u8272\u9636\u5206\u522b\u6309\u5f53\u524d\u7ec4\u6709\u6548\u503c\u7ebf\u6027\u7f29\u653e\u3002", None))
        self.coordinatePlot.setProperty(u"emptyText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u6ca1\u6709\u53ef\u7ed8\u5236\u7684\u6709\u6548 XY \u5750\u6807\u3002\u8bf7\u5728\u6a21\u677f\u4e2d\u63d0\u4f9b\u5b9e\u4f8b\u5750\u6807\u540e\u91cd\u65b0\u5206\u6790\u3002", None))
        self.coordinatePlot.setProperty(u"labelValueSeparator", QCoreApplication.translate("TskCoordinateWindowForm", u" \u00b7 ", None))
        self.coordinatePlot.setProperty(u"lowColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#23a5a0", None))
        self.coordinatePlot.setProperty(u"middleColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#edc65a", None))
        self.coordinatePlot.setProperty(u"highColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#d1495b", None))
        self.coordinatePlot.setProperty(u"missingColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#8c939e", None))
        self.coordinatePlot.setProperty(u"selectionColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#4285ff", None))
        self.coordinatePlot.setProperty(u"identityFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"TSK {tsk} \u00b7 {instance}", None))
        self.coordinatePlot.setProperty(u"chainFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"Chain {chain}", None))
        self.coordinatePlot.setProperty(u"attributeFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"{name}\uff1a{value}", None))
        self.coordinatePlot.setProperty(u"riskFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u9884\u4f30\u5931\u6548\uff1a{risk}", None))
        self.coordinatePlot.setProperty(u"observedFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u94fe\u8def\u89c2\u6d4b\uff1a{risk}", None))
        self.coordinatePlot.setProperty(u"predictedFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u94fe\u8def\u9884\u6d4b\uff1a{risk}", None))
        self.coordinatePlot.setProperty(u"overlapFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u6b64\u5904\u5171 {count} \u4e2a\u5b9e\u4f8b\uff1b\u91cd\u590d\u70b9\u51fb\u53ef\u5207\u6362\u94fe\u8def\u3002", None))
        self.coordinatePlot.setProperty(u"moreFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u53e6\u6709 {count} \u4e2a\u5b9e\u4f8b\uff1b\u9009\u62e9 Chain \u53ef\u5b9a\u4f4d\u3002", None))
        self.statusLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5c1a\u65e0\u5750\u6807\u6570\u636e", None))
    # retranslateUi

