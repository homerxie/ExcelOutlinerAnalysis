"""Coordinate-space TSK instances with screen-space labels and saved risks."""
from __future__ import annotations

from dataclasses import dataclass
from html import escape
import math

from PySide6.QtCore import QEvent, QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFontMetricsF, QPainter, QPalette, QPen
from PySide6.QtWidgets import QApplication, QToolTip, QWidget

from .tsk_risk_display import percentage, risk_available, valid_probability
from .tsk_coordinate_labels import available_field_keys, default_label_rows, normalize_label_rows, render_label_lines


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def chain_probability(chain, metric):
    value = chain.get(metric)
    tested = chain.get("n_tested")
    return value if finite(tested) and tested > 0 and valid_probability(value) else None


@dataclass(frozen=True)
class CoordinateInstance:
    chain_id: str
    instance_id: str
    tsk_id: str
    x: float
    y: float
    features: dict
    probability: float | None
    observed: float | None
    predicted: float | None
    reason: str


def coordinate_instances(payload, group):
    """Join by chain, type and instance, never substitute reference-model risk."""
    chains = {str(row.get("chain_id")): row for row in group.get("chains", [])}
    members = {}
    for chain_id, chain in chains.items():
        for member in chain.get("members") or group.get("chain_members", {}).get(chain_id, []):
            for instance_id in member.get("instance_ids", []):
                members[(chain_id, str(member.get("tsk_id")), str(instance_id))] = member
    topology = payload.get("topology") or (group.get("prediction_context") or {}).get("topology", [])
    points = []
    for row in topology:
        if not (finite(row.get("x")) and finite(row.get("y"))):
            continue
        chain_id, tsk_id = str(row.get("chain_id", "")), str(row.get("tsk_id", ""))
        instance_id = str(row.get("tsk_instance_id", row.get("instance_id", "")))
        chain = chains.get(chain_id, {})
        member = members.get((chain_id, tsk_id, instance_id), {})
        tested = chain.get("n_tested")
        probability = (member.get("probability") if finite(tested) and tested > 0 and risk_available(member)
                       and member.get("status") not in {"fit_not_converged", "unavailable", "not_identifiable"} else None)
        points.append(CoordinateInstance(chain_id, instance_id, tsk_id, float(row["x"]), float(row["y"]),
            dict(row.get("features") or {}), probability,
            chain_probability(chain, "observed_probability"), chain_probability(chain, "predicted_probability"),
            str(member.get("reason") or "")))
    return points, topology


def probability_range(values):
    values = [value for value in values if valid_probability(value)]
    return (min(values), max(values)) if values else None


class _RectIndex:
    """Small screen-space buckets keep decluttering independent of label count."""
    def __init__(self):
        self.buckets = {}

    @staticmethod
    def cells(rect):
        for x in range(math.floor(rect.left() / 64), math.floor(rect.right() / 64) + 1):
            for y in range(math.floor(rect.top() / 64), math.floor(rect.bottom() / 64) + 1):
                yield x, y

    def add(self, rect):
        for key in self.cells(rect):
            self.buckets.setdefault(key, []).append(rect)

    def intersects(self, rect):
        return any(rect.intersects(other) for key in self.cells(rect) for other in self.buckets.get(key, ()))


class TskCoordinatePlot(QWidget):
    chain_selected = Signal(str)
    view_changed = Signal(int, int, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.points = []
        self.selected_chain = None
        self.outline_metric = "observed"
        self.labels_enabled = True
        self.point_range = None
        self.ring_range = None
        self._center = QPointF()
        self._zoom = 1.
        self._bounds = QRectF(-.5, -.5, 1., 1.)
        self._screen_points = []
        self._label_regions = []
        self._label_cache = {}
        self._layout_dirty = True
        self._press = None
        self._dragged = False
        self._last_stats = None
        self.label_rows = None
        self._default_label_rows = []
        self._label_field_keys = []

    def _text(self, key, **values):
        return str(self.property(key) or "").format(**values)

    def set_points(self, points):
        self.points = list(points)
        features = list(dict.fromkeys(name for point in self.points for name in point.features))
        self._label_field_keys = available_field_keys(features)
        self._default_label_rows = default_label_rows(features)
        self.selected_chain = None
        self.point_range = probability_range(point.probability for point in self.points)
        self.set_outline_metric(self.outline_metric)
        self._label_cache.clear()
        self._bounds = self._point_bounds(self.points)
        self.reset_view()

    @staticmethod
    def _point_bounds(points):
        if not points:
            return QRectF(-.5, -.5, 1., 1.)
        xs, ys = [p.x for p in points], [p.y for p in points]
        x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
        # Preserve equal X/Y scale even when all coordinates lie on one axis.
        span = max(x1 - x0, y1 - y0) or 1.
        return QRectF(x0 - (span if x0 == x1 else 0) / 2,
                      y0 - (span if y0 == y1 else 0) / 2,
                      x1 - x0 or span, y1 - y0 or span)

    def plot_rect(self):
        return QRectF(self.rect()).adjusted(62, 20, -22, -42)

    def _base_scale(self):
        rect = self.plot_rect()
        return max(1e-12, min(rect.width() / self._bounds.width(), rect.height() / self._bounds.height()) * .8)

    def world_to_screen(self, x, y):
        scale, center = self._base_scale() * self._zoom, self.plot_rect().center()
        return QPointF(center.x() + (x - self._center.x()) * scale,
                       center.y() - (y - self._center.y()) * scale)

    def screen_to_world(self, point):
        scale, center = self._base_scale() * self._zoom, self.plot_rect().center()
        return QPointF(self._center.x() + (point.x() - center.x()) / scale,
                       self._center.y() - (point.y() - center.y()) / scale)

    def _invalidate(self):
        self._layout_dirty = True
        self.update()

    def reset_view(self):
        self._center = self._bounds.center()
        self._zoom = 1.
        self._invalidate()

    def zoom(self, factor, anchor=None):
        anchor = anchor if anchor is not None else self.plot_rect().center()
        before = self.screen_to_world(anchor)
        self._zoom = max(.2, min(100000., self._zoom * factor))
        self._center += before - self.screen_to_world(anchor)
        self._invalidate()

    def focus_selection(self):
        selected = [p for p in self.points if p.chain_id == self.selected_chain]
        if not selected:
            return
        bounds, rect = self._point_bounds(selected), self.plot_rect()
        self._center = bounds.center()
        if all(p.x == selected[0].x and p.y == selected[0].y for p in selected):
            self._zoom = max(3., self._zoom)
        else:
            scale = min(rect.width() / bounds.width(), rect.height() / bounds.height()) * .65
            self._zoom = max(.2, min(100000., scale / self._base_scale()))
        self._invalidate()

    def set_selected_chain(self, chain_id, *, focus=False):
        self.selected_chain = str(chain_id) if chain_id is not None else None
        if focus:
            self.focus_selection()
        self._invalidate()

    def set_outline_metric(self, metric):
        self.outline_metric = metric
        self.ring_range = probability_range(getattr(p, metric) for p in self.points) if metric else None
        self._invalidate()

    def set_labels_enabled(self, enabled):
        self.labels_enabled = enabled
        self._invalidate()

    def _color(self, value, bounds):
        if not valid_probability(value) or bounds is None:
            return QColor(self.property("missingColor"))
        low, high = bounds
        fraction = (value - low) / (high - low) if high > low else 0.
        first, second = ("lowColor", "middleColor") if fraction <= .5 else ("middleColor", "highColor")
        a, b = QColor(self.property(first)), QColor(self.property(second))
        t = fraction * 2 if fraction <= .5 else (fraction - .5) * 2
        return QColor.fromRgbF(*(a.getRgbF()[i] * (1 - t) + b.getRgbF()[i] * t for i in range(3)))

    @staticmethod
    def _value(value):
        if value is None:
            return "—"
        # Each attribute stays on one line; tooltips retain the full value.
        return str(value).replace("\n", " ↵ ").replace("\r", " ").replace("\t", " ")

    def label_lines(self, point):
        rows = self._default_label_rows if self.label_rows is None else self.label_rows
        return render_label_lines(point, rows, str(self.property("labelValueSeparator") or " · "))

    def set_label_rows(self, rows, feature_names=None):
        available = self._label_field_keys if feature_names is None else available_field_keys(feature_names)
        self.label_rows = normalize_label_rows(rows, available)
        self._label_cache.clear()
        self._invalidate()

    def _detail_lines(self, point):
        """Hover retains named, complete attributes regardless of hidden labels."""
        return [self._text("identityFormat", tsk=self._value(point.tsk_id), instance=self._value(point.instance_id)),
                *[self._text("attributeFormat", name=self._value(name), value=self._value(value))
                  for name, value in point.features.items()],
                self._text("riskFormat", risk=percentage(point.probability))]

    def _label_geometry(self, index, metrics):
        if index not in self._label_cache:
            lines = [metrics.elidedText(line, Qt.ElideRight, int(self.property("maximumLabelWidth")))
                     for line in self.label_lines(self.points[index])]
            width = max((metrics.horizontalAdvance(line) for line in lines), default=0) + 12
            self._label_cache[index] = lines, width, len(lines) * metrics.height() + 10
        return self._label_cache[index]

    def _layout(self):
        if not self._layout_dirty:
            return
        self._layout_dirty = False
        area = self.plot_rect()
        self._screen_points = [(index, self.world_to_screen(point.x, point.y))
                               for index, point in enumerate(self.points)]
        self._screen_points = [(index, pos) for index, pos in self._screen_points if area.contains(pos)]
        self._label_regions = []
        if not self.labels_enabled or self._zoom < float(self.property("labelZoomThreshold")):
            return
        metrics, occupied = QFontMetricsF(self.font()), _RectIndex()
        for _, pos in self._screen_points:
            occupied.add(QRectF(pos.x() - 10, pos.y() - 10, 20, 20))
        ordered = sorted(self._screen_points, key=lambda item: self.points[item[0]].chain_id != self.selected_chain)
        for index, pos in ordered:
            lines, width, height = self._label_geometry(index, metrics)
            if not lines:
                continue
            candidates = [(14, -height / 2), (-width - 14, -height / 2),
                          (14, 14), (-width - 14, 14), (14, -height - 14),
                          (-width - 14, -height - 14), (-width / 2, -height - 14), (-width / 2, 14)]
            for dx, dy in candidates:
                region = QRectF(pos.x() + dx, pos.y() + dy, width, height)
                padded = region.adjusted(-3, -3, 3, 3)
                if area.contains(padded) and not occupied.intersects(padded):
                    self._label_regions.append((region, index, lines))
                    occupied.add(padded)
                    break

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        palette = self.palette()
        painter.fillRect(self.rect(), palette.color(QPalette.Base))
        area = self.plot_rect()
        self._layout()
        if not self.points:
            painter.setPen(palette.color(QPalette.Text))
            painter.drawText(area, Qt.AlignCenter | Qt.TextWordWrap, self._text("emptyText"))
        else:
            self._draw_axes(painter, area)
            painter.save()
            painter.setClipRect(area)
            selected_color = QColor(self.property("selectionColor"))
            metrics = QFontMetricsF(self.font())
            for region, index, lines in self._label_regions:
                point = self.points[index]
                pos = self.world_to_screen(point.x, point.y)
                selected = point.chain_id == self.selected_chain
                painter.setPen(QPen(selected_color if selected else palette.color(QPalette.Mid), 1))
                end = QPointF(max(region.left(), min(region.right(), pos.x())),
                              max(region.top(), min(region.bottom(), pos.y())))
                painter.drawLine(pos, end)
                painter.setBrush(palette.color(QPalette.Base))
                painter.drawRoundedRect(region, 4, 4)
                painter.setPen(palette.color(QPalette.Text))
                for line_number, line in enumerate(lines):
                    painter.drawText(QPointF(region.left() + 6, region.top() + 5 + metrics.ascent() + line_number * metrics.height()), line)
            # Draw selected points last, so coincident instances remain findable.
            for index, pos in sorted(self._screen_points, key=lambda item: self.points[item[0]].chain_id == self.selected_chain):
                point = self.points[index]
                selected = point.chain_id == self.selected_chain
                painter.setOpacity(.28 if self.selected_chain is not None and not selected else 1.)
                if selected:
                    halo = QColor(selected_color)
                    halo.setAlpha(55)
                    painter.setBrush(halo)
                    painter.setPen(QPen(selected_color, 2.5))
                    painter.drawEllipse(pos, 11, 11)
                if self.outline_metric:
                    painter.setBrush(Qt.NoBrush)
                    painter.setPen(QPen(self._color(getattr(point, self.outline_metric), self.ring_range), 2.5))
                    painter.drawEllipse(pos, 7, 7)
                painter.setPen(QPen(palette.color(QPalette.Base), 1))
                painter.setBrush(self._color(point.probability, self.point_range))
                painter.drawEllipse(pos, 4, 4)
            painter.restore()
        painter.end()
        stats = (len(self._label_regions), len(self._screen_points), self._zoom)
        if stats != self._last_stats:
            self._last_stats = stats
            self.view_changed.emit(*stats)

    def _draw_axes(self, painter, area):
        palette, metrics = self.palette(), QFontMetricsF(self.font())
        grid = QColor(palette.color(QPalette.Mid))
        grid.setAlpha(80)
        for step in range(6):
            x, y = area.left() + step * area.width() / 5, area.bottom() - step * area.height() / 5
            painter.setPen(QPen(grid, 1))
            painter.drawLine(QPointF(x, area.top()), QPointF(x, area.bottom()))
            painter.drawLine(QPointF(area.left(), y), QPointF(area.right(), y))
            world = self.screen_to_world(QPointF(x, y))
            painter.setPen(palette.color(QPalette.Text))
            xt, yt = f"{world.x():.4g}", f"{world.y():.4g}"
            painter.drawText(QPointF(x - metrics.horizontalAdvance(xt) / 2, area.bottom() + metrics.height() + 3), xt)
            painter.drawText(QRectF(0, y - metrics.height() / 2, area.left() - 6, metrics.height()), Qt.AlignRight | Qt.AlignVCenter, yt)
        painter.drawText(QPointF(area.center().x(), area.bottom() + 36), "X")
        painter.drawText(QPointF(area.left() - 15, area.top() - 5), "Y")

    def _hits(self, pos):
        self._layout()
        hits = [(index, (point - pos).manhattanLength()) for index, point in self._screen_points
                if (point - pos).manhattanLength() <= 14]
        if hits:
            return [index for index, _ in sorted(hits, key=lambda pair: pair[1])]
        return [index for rect, index, _ in self._label_regions if rect.contains(pos)]

    def tooltip_text(self, indexes):
        blocks = []
        if len(indexes) > 1:
            blocks.append(self._text("overlapFormat", count=len(indexes)))
        # Bound dense hover documents while retaining access through Chain selection.
        for index in indexes[:12]:
            p = self.points[index]
            blocks.append("\n".join([self._text("chainFormat", chain=p.chain_id), *self._detail_lines(p),
                f"X: {p.x:g}", f"Y: {p.y:g}", self._text("observedFormat", risk=percentage(p.observed)),
                self._text("predictedFormat", risk=percentage(p.predicted)), *([p.reason] if p.reason else [])]))
        if len(indexes) > 12:
            blocks.append(self._text("moreFormat", count=len(indexes) - 12))
        return "<qt>" + "<br/><br/>".join(escape(block).replace("\n", "<br/>") for block in blocks) + "</qt>"

    def event(self, event):
        if event.type() == QEvent.ToolTip:
            hits = self._hits(QPointF(event.pos()))
            if hits:
                hits.sort(key=lambda i: self.points[i].chain_id != self.selected_chain)
                QToolTip.showText(event.globalPos(), self.tooltip_text(hits), self)
            else:
                QToolTip.hideText()
            return True
        if event.type() in (QEvent.FontChange, QEvent.StyleChange) and hasattr(self, "_label_cache"):
            self._label_cache.clear()
            self._invalidate()
        return super().event(event)

    def resizeEvent(self, event):
        self._invalidate()
        super().resizeEvent(event)

    def wheelEvent(self, event):
        delta = event.angleDelta().y() or event.pixelDelta().y()
        if delta:
            self.zoom(1.25 ** max(-8., min(8., delta / 120)), event.position())
            event.accept()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._press = event.position()
            self._press_center = QPointF(self._center)
            self._dragged = False
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._press is not None:
            delta = event.position() - self._press
            if delta.manhattanLength() >= QApplication.startDragDistance():
                self._dragged = True
            if self._dragged:
                scale = self._base_scale() * self._zoom
                self._center = self._press_center + QPointF(-delta.x() / scale, delta.y() / scale)
                self.setCursor(Qt.ClosedHandCursor)
                QToolTip.hideText()
                self._invalidate()
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self._press is not None:
            if not self._dragged:
                hits = self._hits(event.position())
                if hits:
                    chains = list(dict.fromkeys(self.points[i].chain_id for i in hits))
                    index = (chains.index(self.selected_chain) + 1) % len(chains) if self.selected_chain in chains else 0
                    self.set_selected_chain(chains[index])
                    self.chain_selected.emit(chains[index])
            self._press = None
            self.unsetCursor()
            event.accept()
        else:
            super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._press = None
            self.reset_view()
            event.accept()
        else:
            super().mouseDoubleClickEvent(event)
