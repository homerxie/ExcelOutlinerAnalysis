"""Lossless display snapshots with optional frozen fits for later deletion analysis."""
from __future__ import annotations

import base64
from copy import deepcopy
import gzip
import hashlib
import json
import zlib


TSK_DISPLAY_FORMAT = "tsk-display-v1"
GROUP_FIELDS = (
    "label", "node", "stratum", "batch_mode", "batch_dimension", "parent_batch_id",
    "source_batches", "batch_counts", "types", "chains", "options", "joint_risk",
    "combination_views", "feature_effects", "node_mode", "source_nodes", "denominator_node", "node_group_index",
    "completed_modules", "analysis_status",
)
CONTEXT_FIELDS = (
    "version", "model", "confidence_level", "converged", "partial_fit", "clipped", "type_ids",
    "all_type_ids", "coefficients", "categorical_features", "numeric_reference",
    "numeric_scaling", "xy_model", "spatial_transform", "feature_groups",
)
DIAGNOSTIC_FIELDS = (
    "model", "converged", "rank", "parameter_count", "chain_count", "confidence_level",
    "interval_method", "reference_environment", "warnings", "finite_mle",
    "feature_scaling", "feature_coefficients", "feature_coefficient_identifiable",
    "categorical_features", "fit_debug_report", "deviance", "identifiable_type_count",
    "xy_model", "spatial_transform", "feature_groups", "parallel_execution",
    "type_coefficient_identifiable", "rank_parameterization", "partial_fit",
)


def _select(value: dict, fields: tuple[str, ...]) -> dict:
    return {key: deepcopy(value[key]) for key in fields if key in value}


def _boundary_summary(value) -> dict | None:
    return _select(value, ("version", "converged", "feature_clipped")) if isinstance(value, dict) else None


def _joint_boundary_summary(value) -> dict | None:
    return _select(value, ("version", "parameterization", "converged", "usable", "partial_fit", "validation")) if isinstance(value, dict) else None


def compact_tsk_result(payload: dict) -> dict:
    """Preserve displayed estimates exactly, without sample outcomes or fit matrices."""
    groups = payload.get("groups", [])
    if not isinstance(groups, list) or not all(isinstance(group, dict) for group in groups):
        raise ValueError("Invalid saved TSK groups")
    result = _select(payload, ("topology", "warnings", "analysis_status", "interruption_reason", "fit_invalidated"))
    raw_provenance = payload.get("provenance") or {}
    provenance = _select(raw_provenance, tuple(key for key in raw_provenance if key != "template_snapshot"))
    provenance["saved_display_only"] = True
    result["provenance"] = provenance
    template = raw_provenance.get("template_snapshot", {})
    if isinstance(template, dict) and isinstance(template.get("tsk_analysis"), dict):
        # The topology table needs category declarations, not a duplicate of
        # every template instance, parser option and Analyze configuration.
        provenance["template_snapshot"] = {"tsk_analysis": _select(template["tsk_analysis"], (
            "categorical_feature_columns", "feature_columns", "feature_model", "use_xy", "xy_model"))}
    result.update(groups=[], saved_display_only=True)
    for group in groups:
        saved = _select(group, GROUP_FIELDS)
        saved["saved_display_only"] = True
        saved["diagnostics"] = _select(group.get("diagnostics") or {}, DIAGNOSTIC_FIELDS)
        context = group.get("prediction_context")
        if isinstance(context, dict):
            saved["prediction_context"] = _select(context, CONTEXT_FIELDS)
            saved["prediction_context"]["boundary_fit"] = _boundary_summary(context.get("boundary_fit"))
            joint = _joint_boundary_summary(context.get("joint_boundary_fit"))
            if joint is not None:
                saved["prediction_context"]["joint_boundary_fit"] = joint
        boundary = _boundary_summary((group.get("diagnostics") or {}).get("boundary_fit"))
        if boundary is not None:
            saved["diagnostics"]["boundary_fit"] = boundary
        joint = _joint_boundary_summary((group.get("diagnostics") or {}).get("joint_boundary_fit"))
        if joint is not None:
            saved["diagnostics"]["joint_boundary_fit"] = joint
        # Older results stored this mapping separately from chain rows.
        members = group.get("chain_members", {})
        for chain in saved.get("chains", []):
            if "members" not in chain and chain.get("chain_id") in members:
                chain["members"] = deepcopy(members[chain["chain_id"]])
        result["groups"].append(saved)
    # Exported analysis variants are independent display snapshots. Strip
    # nested histories before compacting so results can never contain cycles
    # or recursively duplicate all earlier analyses.
    if isinstance(payload.get("saved_analyses"), list):
        variants = []
        for entry in payload["saved_analyses"]:
            if not isinstance(entry, dict) or not isinstance(entry.get("result"), dict):
                continue
            variant = _select(entry, ("key", "context_key", "mode", "settings", "created_at"))
            source = {key: value for key, value in entry["result"].items()
                      if key not in ("saved_analyses", "active_analysis_key")}
            variant["result"] = compact_tsk_result(source)
            variants.append(variant)
        result["saved_analyses"] = variants
        result["active_analysis_key"] = payload.get("active_analysis_key")
    return result


def encode_tsk_result(payload: dict, *, include_fit_context: bool = False) -> dict:
    data = json.dumps(compact_tsk_result(payload), ensure_ascii=False,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")
    encoded = {"format": TSK_DISPLAY_FORMAT,
               "data": base64.b64encode(gzip.compress(data, compresslevel=6, mtime=0)).decode("ascii")}
    if include_fit_context:
        contexts = []
        for group in payload.get("groups", []):
            context = group.get("feature_effects_context") or group.get("prediction_context")
            valid = (isinstance(context, dict) and (group.get("feature_effects") or {}).get("features")
                     and all(context.get(key) is not None for key in ("design", "chain_index", "n_tested", "n_failed")))
            contexts.append(context if valid else None)
        if any(context is not None for context in contexts):
            fit_data = json.dumps(contexts, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")
            encoded["feature_effects_fit"] = {
                "format": "tsk-feature-effects-fit-v1", "display_digest": hashlib.sha256(data).hexdigest(),
                "data": base64.b64encode(gzip.compress(fit_data, compresslevel=6, mtime=0)).decode("ascii")}
    return encoded


def decode_tsk_result(payload: dict, *, include_fit_context: bool = False) -> dict:
    fit_snapshot = payload.get("feature_effects_fit") if include_fit_context else None
    display_digest = None
    if "format" in payload and payload["format"] != TSK_DISPLAY_FORMAT:
        raise ValueError("Unsupported saved TSK result format")
    if payload.get("format") == TSK_DISPLAY_FORMAT:
        data = gzip.decompress(base64.b64decode(payload["data"], validate=True))
        display_digest = hashlib.sha256(data).hexdigest()
        payload = json.loads(data.decode("utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("Invalid saved TSK result")
    # Compact legacy inline results as well: reopening is a display operation.
    result = compact_tsk_result(payload)
    if result.get("analysis_status") == "running":
        result.update(analysis_status="interrupted",
                      interruption_reason="保存时分析尚未全部完成；当前展示已保存的模块结果。")
        for group in result["groups"]:
            if group.get("analysis_status") in {"running", "pending", "queued"}:
                group["analysis_status"] = "interrupted"
    if fit_snapshot is not None:
        try:
            if (not isinstance(fit_snapshot, dict) or fit_snapshot.get("format") != "tsk-feature-effects-fit-v1"
                    or fit_snapshot.get("display_digest") != display_digest):
                raise ValueError("Invalid or mismatched feature effects fit snapshot")
            contexts = json.loads(gzip.decompress(base64.b64decode(fit_snapshot["data"], validate=True)))
            if not isinstance(contexts, list) or len(contexts) != len(result["groups"]):
                raise ValueError("Feature effects fit groups do not match the saved result")
            for context in contexts:
                if context is not None and (not isinstance(context, dict) or any(
                        context.get(key) is None for key in ("design", "chain_index", "n_tested", "n_failed"))):
                    raise ValueError("Incomplete feature effects fit snapshot")
            for group, context in zip(result["groups"], contexts):
                if context is not None:
                    group["feature_effects_context"] = context
        except (ValueError, OSError, EOFError, KeyError, TypeError, zlib.error) as exc:
            result["feature_effects_context_restore_error"] = str(exc)
            result.setdefault("warnings", []).append("删组分析拟合快照无法恢复，已保留展示结果。")
    return result
