"""Portable, atomic storage for compressed Analyze export snapshots.

Snapshot IDs belong to one immutable analysis. GUI settings keep only a small
relative reference; copying or moving a database keeps the snapshot portable.
The snapshot codec owns gzip and payload validation.
"""
from __future__ import annotations

import os
from pathlib import Path
import re
import shutil
import tempfile
from typing import Any
from uuid import UUID


SNAPSHOT_FORMAT = "analyze-snapshot-v1"
SNAPSHOT_DIRECTORY = Path("result") / "analysis"
_OWNED_FILENAME = re.compile(r"[0-9a-f]{32}\.json\.gz\Z")


class SnapshotReferenceError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def _reference_path(reference: Any) -> str:
    if not isinstance(reference, dict) or reference.get("format") != SNAPSHOT_FORMAT:
        raise SnapshotReferenceError("unsupported_format", "Unsupported Analyze snapshot reference format")
    path = reference.get("path")
    if not isinstance(path, str) or not path:
        raise SnapshotReferenceError("invalid_path", "Missing Analyze snapshot path")
    return path


def _result_identifier(result_id: Any) -> str:
    try:
        return UUID(str(result_id)).hex
    except (ValueError, AttributeError, TypeError) as exc:
        raise SnapshotReferenceError("invalid_result_id", "Analyze snapshot has no valid result ID") from exc


def _snapshot_directory(root: str | Path, *, create: bool = False) -> Path:
    root = Path(root).resolve()
    directory = root
    for part in SNAPSHOT_DIRECTORY.parts:
        directory /= part
        # Reject links even when they currently point inside the database: this
        # directory belongs to the app and must not alias unrelated files.
        if directory.is_symlink():
            raise SnapshotReferenceError("unsafe_path", "Analyze snapshot directory must not be a symbolic link")
        if create:
            directory.mkdir(exist_ok=True)
        if directory.exists() and not directory.is_dir():
            raise SnapshotReferenceError("invalid_path", "Analyze snapshot directory is not a directory")
    return directory


def resolve_reference(root: str | Path, reference: Any, *, result_id: Any = None) -> dict[str, str]:
    """Validate a saved relative reference and resolve it within this database."""
    value = _reference_path(reference)
    name = value.rsplit("/", 1)[-1]
    if not _OWNED_FILENAME.fullmatch(name) or value != f"result/analysis/{name}":
        raise SnapshotReferenceError("unsafe_path", "Analyze snapshot path is outside its database directory")
    if result_id is not None and name != f"{_result_identifier(result_id)}.json.gz":
        raise SnapshotReferenceError("result_mismatch", "Analyze snapshot belongs to a different analysis result")
    path = _snapshot_directory(root) / name
    if path.is_symlink():
        raise SnapshotReferenceError("unsafe_path", "Analyze snapshot must not be a symbolic link")
    if not path.is_file():
        raise SnapshotReferenceError("missing_snapshot", "Saved Analyze snapshot is missing")
    return {"format": SNAPSHOT_FORMAT, "path": str(path)}


def _same_content(source: Path, target: Path) -> bool:
    if not target.exists() or target.stat().st_size != source.stat().st_size:
        return False
    if source.samefile(target):
        return True
    with source.open("rb") as original, target.open("rb") as saved:
        while True:
            chunk = original.read(1024 * 1024)
            if chunk != saved.read(1024 * 1024):
                return False
            if not chunk:
                return True


def persist_reference(root: str | Path, reference: Any, result_id: Any) -> dict[str, str]:
    """Copy a private snapshot atomically, returning its portable reference.

    An existing destination is reused only when its bytes match the immutable
    live snapshot. Damaged copies are replaced without recompression.
    """
    value = _reference_path(reference)
    source = Path(value)
    if not source.is_absolute():
        source = Path(resolve_reference(root, reference, result_id=result_id)["path"])
    if source.is_symlink() or not source.is_file():
        raise SnapshotReferenceError("missing_snapshot", "Analyze snapshot source is missing or is a symbolic link")
    identifier = _result_identifier(result_id)

    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    directory = _snapshot_directory(root, create=True)
    target = directory / f"{identifier}.json.gz"
    if target.is_symlink() or (target.exists() and not target.is_file()):
        raise SnapshotReferenceError("unsafe_path", "Analyze snapshot destination is not a regular file")
    if not _same_content(source, target):
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(mode="wb", dir=directory, prefix=".analysis-", suffix=".tmp",
                                             delete=False) as output:
                temporary = Path(output.name)
                with source.open("rb") as original:
                    shutil.copyfileobj(original, output, length=1024 * 1024)
                output.flush()
                os.fsync(output.fileno())
            os.replace(temporary, target)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
    return {"format": SNAPSHOT_FORMAT, "path": (SNAPSHOT_DIRECTORY / target.name).as_posix()}


def cleanup_after_commit(root: str | Path, reference: dict[str, str] | None) -> None:
    """Prune stale app snapshots only after GUI settings commit successfully.

    Cleanup is best effort. Its failure must not turn a successful save into an
    error, and symlinks or files outside our UUID naming convention are untouched.
    A missing active reference can indicate a restore failure, so its artifacts
    are retained until another valid Analyze snapshot is committed.
    """
    if reference is None:
        return
    try:
        directory = _snapshot_directory(root)
        retained = Path(reference["path"]).name
        for path in directory.iterdir():
            if path.name != retained and _OWNED_FILENAME.fullmatch(path.name) and not path.is_symlink():
                try:
                    if path.is_file():
                        path.unlink()
                except OSError:
                    pass
    except (OSError, SnapshotReferenceError):
        pass
