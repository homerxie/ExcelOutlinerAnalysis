"""Independent TSK workflow: observations, estimation and reproducible export.

Analyze's leaf classification and merge pipeline are reused directly, without
running Analyze or creating an ordinary report. Missing means that no leaf
remains after applying Analyze's configured empty-cell policy.
"""
from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Callable

from .field_names import preferred_batch_field, row_fields
from .compact_analysis import ColumnarMeasurements
from .io import build_measurements, load_table
from .models import TemplateConfig
from .repository import Repository
from .reporting import (
    _build_columns, _build_rows, _build_rows_from_measurements,
    _build_zscore_map, _build_report_golden_values, _load_built_golden_reference,
    _build_leaf_records, _execute_outlier_merge_pipeline, _fail_mode_requires_golden,
    _sample_key_display, _sample_key_from_dimensions,
    _validate_report_row_identities,
)
from .merge_config import chain_level, column_levels
from .template import load_template, template_to_payload, validate_report_identity


_AUTO_BATCH_FIELD = object()


def _unscorable_z_metrics(measurements, z_values):
    counts = defaultdict(int)
    informative = set()
    for measurement in measurements:
        counts[measurement.logical_metric] += 1
        entry = z_values.get((measurement.dataset_id, measurement.row_number, measurement.raw_column))
        if entry is not None and entry.value is not None and abs(entry.value) > 0:
            informative.add(measurement.logical_metric)
    # Informational only: Analyze's actual leaf state remains authoritative.
    return {metric: "样本不足 3" if count < 3 else "MAD 为 0"
            for metric, count in counts.items() if count < 3 or metric not in informative}


def _batch_settings(template, *, batch_mode="none", batch_dimension=_AUTO_BATCH_FIELD, batch_mapping=None):
    if batch_mode not in {"none", "separate", "parent"}:
        raise ValueError(f"不支持的 TSK 批次模式：{batch_mode}")
    # Legacy callers can omit the batch field. Recognize a declared lot field
    # when possible; otherwise their explicitly defined sample key is the identity.
    if batch_dimension is _AUTO_BATCH_FIELD:
        batch_dimension = (preferred_batch_field(d.name for d in template.row_dimensions
                           if d.name != template.report.reliability_node_dimension)
                           if batch_mode == "none" else None)
    dimension = (row_fields(template).resolve(batch_dimension, strict=True)
                 if batch_dimension is not None or batch_mode != "none" else None)
    if dimension == template.report.reliability_node_dimension:
        raise ValueError("批次字段不能使用可靠性节点；各节点始终分别分析。")
    if batch_mode == "none":
        return {"batch_mode": "none", "batch_dimension": dimension, "batch_mapping": {}}
    if batch_mapping is not None and not isinstance(batch_mapping, dict):
        raise ValueError("原批次到母批编号的对应关系必须为字典。")
    mapping = {}
    for source, parent in (batch_mapping or {}).items():
        if not isinstance(source, str) or not isinstance(parent, str):
            raise ValueError("原批次和母批编号必须是文本。")
        mapping[source] = parent.strip()
    return {"batch_mode": batch_mode, "batch_dimension": dimension, "batch_mapping": mapping}


def _batch_value(dimensions, dimension):
    value = dimensions.get(dimension)
    if value is None or not str(value).strip():
        raise ValueError(f"TSK 批次字段 {dimension!r} 存在空值，请先补全批次信息。")
    return str(value)


def _pool_batch_groups(groups, batch):
    """Pool sufficient counts, never type estimates or cross-batch sample IDs."""
    output = {}
    for group in groups:
        source = group.pop("source_batch")
        parent = (batch["batch_mapping"][source] if batch["batch_mode"] == "parent" else
                  source if batch["batch_mode"] == "separate" else "")
        key = (group["node"], parent)
        if key not in output:
            description = "母批" if batch["batch_mode"] == "parent" else batch["batch_dimension"]
            label = group["label"] if batch["batch_mode"] == "none" else f"{group['label']} | {description}={parent}"
            output[key] = {**group, "label": label,
                           "batch_mode": batch["batch_mode"], "batch_dimension": batch["batch_dimension"],
                           "parent_batch_id": parent if batch["batch_mode"] == "parent" else None,
                           "source_batches": [], "batch_counts": [], "counts": {},
                           "sample_outcomes": [], "classification_warnings": []}
        target = output[key]
        target["source_batches"].append(source)
        target["classification_warnings"].extend(group["classification_warnings"])
        target["sample_outcomes"].extend({**row, "source_batch": source} for row in group["sample_outcomes"])
        target["batch_counts"].extend({"source_batch": source, **row} for row in group["counts"])
        for row in group["counts"]:
            total = target["counts"].setdefault(row["chain_id"], {"chain_id": row["chain_id"],
                "n_tested": 0, "n_failed": 0, "n_passed": 0, "n_missing": 0})
            for name in ("n_tested", "n_failed", "n_passed", "n_missing"):
                total[name] += row[name]
    for group in output.values():
        group["counts"] = list(group["counts"].values())
        group["classification_warnings"] = list(dict.fromkeys(group["classification_warnings"]))
    return [output[key] for key in sorted(output)]


def collect_tsk_observations(template, measurements, rows, *, golden_path=None,
                             batch_mode="none", batch_dimension=_AUTO_BATCH_FIELD,
                             batch_mapping=None, progress_callback=None):
    """Classify the selected scope with Analyze's rules, then count unique samples.

    Empty cells follow ``outlier_treat_empty_cells_as_fail`` exactly. A known
    sample/chain with no retained leaf is Missing. The same sample ID in different
    original batches remains distinct, even when all batches are pooled later.
    """
    from .template import validate_tsk_analysis_config

    validate_report_identity(template)
    validate_tsk_analysis_config(template, require_instances=True)
    _validate_report_row_identities(template, rows)
    fail_method = template.report.outlier_fail_method
    if fail_method not in {"modified_z_score", "golden_deviation", "zscore_and_golden", "zscore_or_golden"}:
        raise ValueError(f"Unsupported Analyze Fail criterion: {fail_method}")
    if _fail_mode_requires_golden(fail_method) and not golden_path:
        raise ValueError("Analyze 当前规则包含 Golden 判据，请在 Setup 中选择 Golden 文件。")
    columns = _build_columns(template, {}, [])
    prefix_length = column_levels(template).index(chain_level(template)) + 1
    chain_keys = {tuple(item.chain_key): item.chain_id for item in template.tsk_analysis.instances}
    selected_columns = [c for c in columns if tuple(c.header_values[:prefix_length]) in chain_keys]
    if not selected_columns:
        raise ValueError("TSK 实例表未匹配到测量列。请检查完整 Chain 键。")
    node_name = template.report.reliability_node_dimension
    batch = _batch_settings(template, batch_mode=batch_mode, batch_dimension=batch_dimension,
                            batch_mapping=batch_mapping)
    dimension = batch["batch_dimension"]
    batched = dimension is not None
    source_batches = sorted({_batch_value(row.dimensions, dimension) for row in rows}) if batched else []
    if batch["batch_mode"] == "parent":
        unmapped = [source for source in source_batches if not batch["batch_mapping"].get(source)]
        if unmapped:
            raise ValueError("请为所有所选原批次填写母批编号：" + ", ".join(unmapped))
    if progress_callback:
        progress_callback(18, "TSK：按 Analyze 规则计算所选范围的测量判据…")
    # Match _run_analysis's effective default threshold override, including its
    # precedence over template per-metric overrides. Pool before any batch split.
    z_values = _build_zscore_map(measurements, template.report.zscore_thresholds, columns,
                                zscore_threshold_override=template.report.zscore_thresholds.default)
    unscorable = _unscorable_z_metrics(measurements, z_values)
    affected = len(set(unscorable) & {column.logical_metric for column in selected_columns})
    classification_warnings = ([f"Modified Z Score 有 {affected} 个测项样本不足 3 或 MAD 为 0；遵循 Analyze 的现有输出（Z 分数为 0），不在 TSK 中改判 Missing。"]
                               if affected and fail_method != "golden_deviation" else [])
    golden = _load_built_golden_reference(golden_path) if golden_path else None
    golden_values = _build_report_golden_values(measurements, template, columns, golden_reference=golden)
    if _fail_mode_requires_golden(fail_method):
        selected_raw_columns = {column.raw_column for column in selected_columns}
        unmatched = sum(row.raw_column in selected_raw_columns and
                        (row.dataset_id, row.row_number, row.raw_column) not in golden_values
                        for row in measurements)
        if unmatched:
            classification_warnings.append(f"有 {unmatched} 个数值测量未匹配 Golden；遵循 Analyze，将对应 Golden Fail 项视为 False 后组合判据，不在 TSK 中改判 Missing。")
    grouped = defaultdict(list)
    for row in rows:
        source_batch = _batch_value(row.dimensions, dimension) if batched else ""
        grouped[(row.dimensions[node_name], source_batch)].append(row)
    output = []
    for (node, source_batch), group_rows in sorted(grouped.items()):
        # Seed the observation universe before empty leaves are skipped. Partition
        # by identity before calling the shared pipeline to prevent accidental
        # cross-sample merges even with unusual row ordering/merge order.
        outcomes = {(_sample_key_from_dimensions(row.dimensions, template.report.sample_dimension_names), chain): None
                    for row in group_rows for chain in chain_keys.values()}
        leaves_by_sample = defaultdict(list)
        for leaf in _build_leaf_records(template, selected_columns, group_rows, z_values, golden_values, fail_method):
            leaves_by_sample[leaf.sample_key].append(leaf)
        seen = set()
        for sample, leaves in leaves_by_sample.items():
            for record in _execute_outlier_merge_pipeline(template, leaves):
                identity = (sample, chain_keys[record.column_key])
                if identity in seen:
                    raise ValueError("一个样品/节点/Chain 合并后仍有多个状态，请检查模板行层级、唯一 Sample ID 和原批次字段。")
                seen.add(identity)
                outcomes[identity] = "Fail" if record.is_fail else "Pass"
        counts = {chain: {"chain_id": chain, "n_tested": 0, "n_failed": 0, "n_passed": 0, "n_missing": 0} for chain in chain_keys.values()}
        paired = []
        for (sample, chain), resolved_status in sorted(outcomes.items()):
            status = resolved_status or "Missing"
            count = counts[chain]
            count[{"Missing": "n_missing", "Fail": "n_failed", "Pass": "n_passed"}[status]] += 1
            count["n_tested"] += int(status != "Missing")
            paired.append({"sample_key": list(sample), "chain_id": chain, "status": status})
        label = f"{node_name}={node}"
        output.append({"label": label, "node": node, "stratum": {}, "counts": list(counts.values()),
                       "sample_outcomes": paired, "classification_warnings": classification_warnings,
                       **({"source_batch": source_batch} if batched else {})})
    return _pool_batch_groups(output, batch) if batched else output


def _load_tsk_selection(template, *, source, storage_path, input_path, options):
    """Use identical import/node/sample scopes for discovery and estimation."""
    warnings = []
    dataset_ids = set(options.get("dataset_ids", []))
    if source == "input":
        if not input_path:
            raise ValueError("请在 Setup 中选择 Input Excel/CSV。")
        table = load_table(input_path, template=template)
        rows = _build_rows(template, table.rows, input_path)
        measurements = ColumnarMeasurements(build_measurements(template, table.rows, "ad-hoc-report", str(Path(input_path).resolve())))
        del table
    elif source == "database":
        if not storage_path:
            raise ValueError("请先打开数据库。")
        if options.get("analysis_scope") == "checked_imports" and not dataset_ids:
            raise ValueError("请在 TSK Analysis 页勾选至少一个导入记录。")
        measurements = ColumnarMeasurements(m for m in Repository(storage_path).iter_measurements()
                        if options.get("analysis_scope") != "checked_imports" or m.dataset_id in dataset_ids)
        rows = _build_rows_from_measurements(measurements)
        warnings.append("数据库只保留可解析的数值测量；导入时整行没有数值的样品无法恢复。Missing 计数仅覆盖已知样品/节点，完整曝光数请使用原始输入文件核对。")
    else:
        raise ValueError(f"Unsupported TSK source: {source}")
    nodes, sample_ids = set(options.get("nodes", [])), set(options.get("sample_ids", []))
    def included(row):
        sample = _sample_key_from_dimensions(row.dimensions, template.report.sample_dimension_names)
        return ((not nodes or row.dimensions.get(template.report.reliability_node_dimension) in nodes)
                and (not sample_ids or _sample_key_display(sample) in sample_ids or (sample and sample[-1] in sample_ids)))
    rows = [row for row in rows if included(row)]
    selected_rows = {(row.dataset_id, row.row_number) for row in rows}
    measurements = ColumnarMeasurements(m for m in measurements if (m.dataset_id, m.row_number) in selected_rows)
    if not rows:
        raise ValueError("所选 TSK 分析范围没有样品数据。")
    return measurements, rows, warnings


def discover_tsk_batches(*, template_path: str, source: str = "database", storage_path: str | None = None,
                         input_path: str | None = None, settings: dict | None = None,
                         analysis_template: TemplateConfig | None = None,
                         progress_callback: Callable | None = None) -> list[str]:
    """Read the current TSK scope, without fitting or modifying the database."""
    options = dict(settings or {})
    # Retired controls from saved workspaces must never silently split new fits.
    for retired in ("group_by_dimensions", "fail_method", "classification_pool"):
        options.pop(retired, None)
    template = deepcopy(analysis_template) if analysis_template is not None else load_template(template_path)
    batch = _batch_settings(template, batch_mode="separate", batch_dimension=options.get("batch_dimension"))
    progress = progress_callback or (lambda value, message: None)
    progress(5, "TSK：读取所选范围的原批次…")
    _, rows, _ = _load_tsk_selection(template, source=source, storage_path=storage_path,
                                     input_path=input_path, options=options)
    values = sorted({_batch_value(row.dimensions, batch["batch_dimension"]) for row in rows})
    progress(100, f"TSK：发现 {len(values)} 个原批次。")
    return values


def analyze_tsk_workspace(*, template_path: str, source: str = "database", storage_path: str | None = None,
                          input_path: str | None = None, golden_path: str | None = None,
                          analysis_template: TemplateConfig | None = None,
                          include_all_combinations: bool = False,
                          settings: dict | None = None, progress_callback: Callable | None = None) -> dict:
    """Execute a complete independent run; no ordinary reports or workspace writes."""
    from .tsk_analysis import TskInstance, TskChainObservation, TskAnalysisOptions, analyze_tsk
    from .template import validate_tsk_analysis_config

    options = dict(settings or {})
    # Ignore retired controls, including stale or invalid fields in saved workspaces.
    for retired in ("group_by_dimensions", "fail_method", "classification_pool"):
        options.pop(retired, None)
    template = deepcopy(analysis_template) if analysis_template is not None else load_template(template_path)
    if not template.tsk_analysis.enabled:
        raise ValueError("请先在模板 tsk_analysis 设置中启用 TSK 分析并填写真实实例对应表；可先使用 examples/tsk_risk_demo 示例。")
    validate_tsk_analysis_config(template, require_instances=True)
    feature_model = options.get("feature_model", template.tsk_analysis.feature_model)
    if feature_model not in ("logistic", "linear_hazard"):
        raise ValueError("TSK feature_model must be 'logistic' or 'linear_hazard'.")
    progress = progress_callback or (lambda value, message: None)
    progress(3, "TSK：读取模板与测量数据…")
    measurements, rows, warnings = _load_tsk_selection(template, source=source, storage_path=storage_path,
                                                      input_path=input_path, options=options)
    batch = _batch_settings(template, **{name: options[name] for name in
                            ("batch_mode", "batch_dimension", "batch_mapping") if name in options})
    observations = collect_tsk_observations(template, measurements, rows, golden_path=golden_path,
                                          progress_callback=progress, **batch)
    include_xy = bool(options.get("include_xy", template.tsk_analysis.use_xy))
    features = tuple(options.get("feature_names", template.tsk_analysis.feature_columns))
    undeclared = set(features) - set(template.tsk_analysis.feature_columns)
    if undeclared:
        raise ValueError("所选 TSK 特征未在模板 feature_columns 中声明：" + ", ".join(sorted(undeclared)))
    categorical_features = tuple(name for name in features if name in template.tsk_analysis.categorical_feature_columns)
    instances = [TskInstance(chain_id=i.chain_id, instance_id=i.tsk_instance_id, tsk_id=i.tsk_id,
                             x=i.x, y=i.y, features=dict(i.features)) for i in template.tsk_analysis.instances]
    fit_options = TskAnalysisOptions(use_xy=include_xy, feature_names=features,
                                    confidence_level=float(options.get("confidence_level", .95)),
                                    categorical_feature_names=categorical_features,
                                    feature_model=feature_model)
    results = []
    fit_progress_span = 45 if include_all_combinations else 65
    for index, observation in enumerate(observations):
        progress(30 + int(fit_progress_span * index / max(1, len(observations))), f"TSK：拟合 {observation['label']}…")
        counts = observation.pop("counts")
        warnings.extend(observation.pop("classification_warnings", []))
        effective = [TskChainObservation(c["chain_id"], c["n_tested"], c["n_failed"]) for c in counts if c["n_tested"]]
        if effective:
            result = analyze_tsk(instances, effective, fit_options,
                progress_callback=lambda value, message: progress(
                    30 + int(fit_progress_span * (index + value / 100) / max(1, len(observations))), message)).to_dict()
        else:
            type_names = sorted({item.tsk_id for item in instances})
            result = {"types": [{"tsk_id": name, "probability": None, "ci_lower": None, "ci_upper": None,
                                  "identifiable": False, "status": "no_data", "interval_method": None,
                                  "instance_count": sum(item.tsk_id == name for item in instances), "test_exposure": 0}
                                 for name in type_names],
                      "chains": [], "options": asdict(fit_options),
                      "diagnostics": {"converged": False, "rank": 0, "parameter_count": len(type_names),
                                      "chain_count": 0, "confidence_level": fit_options.confidence_level,
                                      "interval_method": None, "reference_environment": None,
                                      "model": f"instance_{feature_model}_features" if include_xy or features else "type_only",
                                      "warnings": ["本组所有 Chain 状态均为 Missing，未拟合。"]}}
        fitted = {c["chain_id"]: c for c in result["chains"]}
        result["chains"] = [{**c, **fitted.get(c["chain_id"], {
            "status": "no_data", "observed_probability": None, "predicted_probability": None,
            "residual": None, "deviance_residual": None,
        })} for c in counts]
        results.append({**observation, **result})
    import numpy, scipy
    snapshot = template_to_payload(template)
    snapshot_hash = hashlib.sha256(json.dumps(snapshot, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    provenance = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(), "source": source,
        "template_path": str(Path(template_path).resolve()),
        "template_sha256": hashlib.sha256(Path(template_path).read_bytes()).hexdigest() if Path(template_path).is_file() else None,
        "template_snapshot_sha256": snapshot_hash,
        "input_path": input_path, "storage_path": storage_path, "golden_path": golden_path,
        "settings": {**options, **batch, "include_xy": include_xy, "feature_names": list(features),
                     "categorical_feature_names": list(categorical_features), "feature_model": feature_model},
        "analysis_rule_source": "analyze_ui_snapshot" if analysis_template is not None else "template_report",
        "analysis_rules": {
            "outlier_fail_method": template.report.outlier_fail_method,
            "zscore_threshold_override": template.report.zscore_thresholds.default,
            "outlier_treat_empty_cells_as_fail": template.report.outlier_treat_empty_cells_as_fail,
            "initial_column_merge_fail_rule": template.report.outlier_merged_test_fail_rule,
            "final_column_merge_fail_rule": template.report.outlier_test_group_fail_rule,
            "initial_row_merge_fail_rule": template.report.outlier_merged_sample_fail_rule,
            "final_row_merge_fail_rule": template.report.outlier_node_fail_rule,
        },
        "merge_order": template.report.outlier_merge_order,
        "missing_policy": "遵循 Analyze 空值规则：启用空值为 Fail 时直接计 Fail；关闭时跳过空单元格。有剩余测量按相同合并规则判定，样品/节点/Chain 无剩余 leaf 才为 Missing 并排除有效分母。",
        "classification_scope": "TSK 所选节点、样品和导入范围的全部测量，按 Analyze 逻辑测项分池；不按原批或母批重新计算。范围不同可能使 Modified Z Score 与另一次 Analyze 运行不同。",
        "numpy_version": numpy.__version__, "scipy_version": scipy.__version__,
        "template_snapshot": snapshot,
    }
    if batch["batch_mode"] == "parent":
        warnings.append("母批将成员原批的有效 Fail/Pass 计数合并后重新拟合，假设同一母批、节点下共享 TSK 风险；合并本身不会消除批间风险差异。")
    elif batch["batch_mode"] == "none" and any(len(group.get("source_batches", [])) > 1 for group in results):
        warnings.append("不分层：所有所选原批按节点汇总有效 Fail/Pass 计数后拟合，假设该节点下共享 TSK 风险；混合本身不会消除批间风险差异。")
    warnings.append("区间按模型中的独立观测假设计算；同一 die 多链共同异常可能使区间偏窄。结果是基于串联假设的风险估计。")
    payload = {"groups": results, "topology": [asdict(i) for i in template.tsk_analysis.instances],
               "warnings": list(dict.fromkeys(warnings)), "provenance": provenance}
    if include_all_combinations:
        from .tsk_prediction import ALL_CATEGORY_COMBINATIONS, MAX_COMBINATION_CELLS

        for index, group in enumerate(results):
            context = group.get("prediction_context")
            categories = (context or {}).get("categorical_features", {})
            if not categories:
                continue
            count = len(context["all_type_ids"]) * math.prod(len(item["levels"]) for item in categories.values())
            if count > MAX_COMBINATION_CELLS:
                group["diagnostics"]["warnings"].append(
                    f"全部类别组合共 {count} 格，超过单次 {MAX_COMBINATION_CELLS} 格上限；"
                    "请在组合分析中选择单个 TSK 或固定部分类别后计算。")
                continue
            response = analyze_tsk_combinations(payload, group_index=index,
                settings={"dimension": ALL_CATEGORY_COMBINATIONS, "extrapolate": False},
                progress_callback=lambda value, message: progress(
                    75 + int(24 * (index + value / 100) / max(1, len(results))), message))
            store_tsk_combination_view(payload, index, response["view"])
    progress(100, "TSK 独立分析完成。")
    return payload


def analyze_tsk_combinations(payload: dict, *, group_index: int, settings: dict,
                             progress_callback: Callable | None = None) -> dict:
    """Query a frozen fit without re-reading input, labels, or Analyze controls."""
    from .tsk_prediction import predict_tsk_combinations

    groups = payload.get("groups", [])
    if isinstance(group_index, bool) or not isinstance(group_index, int) or not 0 <= group_index < len(groups):
        raise ValueError("请选择有效的 TSK 节点 / 批次结果。")
    context = groups[group_index].get("prediction_context")
    if not context:
        raise ValueError("该结果没有类别组合拟合快照，请选中类别特征后重新运行 TSK 分析。")
    options = deepcopy(settings)
    view = predict_tsk_combinations(
        deepcopy(context), dimension=options.get("dimension"),
        fixed_categories=options.get("fixed_categories"), reference_level=options.get("reference_level"),
        tsk_ids=options.get("tsk_ids"), extrapolate=options.get("extrapolate", True),
        progress_callback=progress_callback,
    )
    query = {key: view.get(key) for key in ("dimension", "fixed_categories", "reference_level", "extrapolate")}
    query["tsk_ids"] = sorted({row["tsk_id"] for row in view["rows"]})
    view["query_key"] = hashlib.sha256(json.dumps(query, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    view["fit_snapshot_sha256"] = hashlib.sha256(json.dumps(context, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    view["created_at_utc"] = datetime.now(timezone.utc).isoformat()
    return {"group_index": group_index, "view": view}


def store_tsk_combination_view(payload: dict, group_index: int, view: dict) -> None:
    """Keep each computed slice once; put the latest slice last for restoration."""
    group = payload["groups"][group_index]
    views = [item for item in group.get("combination_views", []) if item.get("query_key") != view.get("query_key")]
    group["combination_views"] = [*views, deepcopy(view)]


def export_tsk_result(payload: dict, output_path: str) -> str:
    """Export fitted results, missing counts, paired observations and provenance."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    import os
    import tempfile

    target = Path(output_path)
    if target.suffix.lower() != ".xlsx":
        target = target.with_suffix(".xlsx")
    target.parent.mkdir(parents=True, exist_ok=True)
    workbook = Workbook()
    workbook.remove(workbook.active)
    def sheet(name, records, columns=None):
        ws = workbook.create_sheet(name)
        columns = columns or list(dict.fromkeys(key for row in records for key in row))
        ws.append(columns or ["No data"])
        for row_index, record in enumerate(records, 2):
            for column_index, key in enumerate(columns, 1):
                value = record.get(key)
                if isinstance(value, (dict, list, tuple)):
                    value = json.dumps(value, ensure_ascii=False, allow_nan=False)
                if isinstance(value, float) and not math.isfinite(value):
                    value = None
                cell = ws.cell(row_index, column_index, value)
                if isinstance(value, str):
                    cell.data_type = "s"
                if key in {"probability", "ci_lower", "ci_upper", "observed_probability", "predicted_probability", "residual",
                           "delta_probability", "delta_ci_lower", "delta_ci_upper", "reference_probability"}:
                    cell.number_format = "0.00%"
        for cell in ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="355C7D")
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        for column in ws.columns:
            ws.column_dimensions[column[0].column_letter].width = min(65, max(15, max(len(str(c.value or "")) for c in column) + 2))
    type_rows, chain_rows, diagnostic_rows, sample_rows, batch_rows = [], [], [], [], []
    combination_rows, contrast_rows, view_rows, fit_rows = [], [], [], []
    feature_coefficient_rows, feature_risk_rows = [], []
    from .tsk_feature_summary import summarize_tsk_features

    for group_index, group in enumerate(payload.get("groups", [])):
        prefix = {"group": group["label"], "node": group["node"], "stratum": group.get("stratum", {})}
        if group.get("source_batches"):
            prefix.update({key: group.get(key) for key in
                           ("batch_mode", "batch_dimension", "parent_batch_id", "source_batches")})
        type_rows.extend({**prefix, **row} for row in group.get("types", []))
        feature_summary = summarize_tsk_features(group)
        feature_prefix = {**prefix, "model": feature_summary["model"], "formula": feature_summary["formula"]}
        feature_coefficient_rows.extend({**feature_prefix, **row} for row in feature_summary["coefficients"])
        feature_risk_rows.extend({**feature_prefix, **row} for row in feature_summary["risks"])
        chain_rows.extend({**prefix, **row} for row in group.get("chains", []))
        diagnostic_rows.extend({**prefix, "item": key, "value": value} for key, value in group.get("diagnostics", {}).items())
        sample_rows.extend({**prefix, **row} for row in group.get("sample_outcomes", []))
        batch_rows.extend({**prefix, **row} for row in group.get("batch_counts", []))
        for view_index, view in enumerate(group.get("combination_views", []), 1):
            view_prefix = {**prefix, "view_id": view_index,
                           **{key: view.get(key) for key in ("dimension", "reference_level", "fixed_categories",
                                                            "numeric_reference", "confidence_level", "extrapolate")}}
            view_rows.append({**view_prefix, **{key: value for key, value in view.items() if key != "rows"}})
            for row in view.get("rows", []):
                combination_rows.append({**view_prefix, **{key: value for key, value in row.items()
                                                          if not key.startswith("delta_") and key != "reference_probability"}})
                contrast_rows.append({**view_prefix, **{key: value for key, value in row.items()
                    if key.startswith("delta_") or key in {"tsk_id", "level", "categories", "reference_probability",
                                                           "support_status", "chain_count", "chain_test_exposure"}}})
        context = group.get("prediction_context")
        if context:
            text = json.dumps(context, ensure_ascii=False, allow_nan=False)
            pieces = [text[start:start + 30000] for start in range(0, len(text), 30000)]
            fit_rows.extend({"group_index": group_index, **prefix, "part": index + 1, "parts": len(pieces), "value": piece}
                            for index, piece in enumerate(pieces))
    sheet("TSK Risk", type_rows)
    sheet("Chain Fit", chain_rows)
    sheet("Diagnostics", diagnostic_rows)
    sheet("Topology", payload.get("topology", []))
    sheet("Sample Outcomes", sample_rows)
    if batch_rows:
        sheet("Batch Counts", batch_rows)
    if view_rows:
        sheet("Combination Risk", combination_rows)
        sheet("Category Contrasts", contrast_rows)
        sheet("Combination Views", view_rows)
    if feature_coefficient_rows:
        sheet("Feature Coefficients", feature_coefficient_rows)
    if feature_risk_rows:
        sheet("Feature Risk", feature_risk_rows)
    if fit_rows:
        sheet("Prediction Context", fit_rows)
    metadata = []
    for key, value in payload.get("provenance", {}).items():
        if isinstance(value, (dict, list, tuple)):
            value = json.dumps(value, ensure_ascii=False, allow_nan=False)
        if isinstance(value, str) and len(value) > 30000:
            # Excel truncates strings after 32767 characters. Ordered chunks
            # preserve large topology/template snapshots exactly for replay.
            pieces = [value[start:start + 30000] for start in range(0, len(value), 30000)]
            metadata.extend({"item": key, "part": i + 1, "parts": len(pieces), "value": piece}
                            for i, piece in enumerate(pieces))
        else:
            metadata.append({"item": key, "part": 1, "parts": 1, "value": value})
    sheet("Run Settings", metadata + [{"item": "warning", "part": 1, "parts": 1, "value": w} for w in payload.get("warnings", [])],
          ["item", "part", "parts", "value"])
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent, suffix=".xlsx", delete=False) as handle:
            temporary = Path(handle.name)
        workbook.save(temporary)
        os.replace(temporary, target)
    finally:
        if temporary:
            temporary.unlink(missing_ok=True)
        workbook.close()
    return str(target.resolve())
