"""Independent TSK controls and result binding; form geometry lives in .ui files."""
from __future__ import annotations

from dataclasses import asdict, is_dataclass
import json
from itertools import product
import math
from pathlib import Path
import re

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt, Signal
from PySide6.QtWidgets import QApplication, QAbstractItemView, QComboBox, QHeaderView, QLineEdit, QListWidgetItem, QStyledItemDelegate, QTableWidgetItem, QWidget

from ..field_names import preferred_batch_field
from ..tsk_features import ALL_CATEGORY_COMBINATIONS, category_combination_label

from .ui_tsk_analysis_panel import Ui_TskAnalysisPanelForm
from .ui_tsk_results_panel import Ui_TskResultsPanelForm


def _mapping(value):
    if isinstance(value, dict):
        return value
    return asdict(value) if is_dataclass(value) else {}


def _values(text):
    return list(dict.fromkeys(part.strip() for part in re.split(r"[,，\n]+", text) if part.strip()))


def _finite(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)


class TskAnalysisPanel(QWidget):
    run_requested = Signal(object)
    refresh_requested = Signal()
    batch_scan_requested = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskAnalysisPanelForm()
        self.ui.setupUi(self)
        self.template = None
        self._template_ready = False
        self._ready_override = None
        self._pending_dataset_ids = set()
        self._pending_feature_names = None
        self._batch_mode = "none"
        self._batch_dimension = ""
        self._batch_mappings = {}
        self._batch_values = {}
        for combo, codes in (
            (self.ui.sourceComboBox, ("database", "input")),
            (self.ui.scopeComboBox, ("entire_database", "checked_imports")),
            (self.ui.batchModeComboBox, ("none", "separate", "parent")),
            (self.ui.featureModelComboBox, ("logistic", "linear_hazard")),
        ):
            for index, code in enumerate(codes):
                combo.setItemData(index, code)
        self.ui.sourceComboBox.currentIndexChanged.connect(self._update_state)
        self.ui.scopeComboBox.currentIndexChanged.connect(self._update_state)
        self.ui.featureModelComboBox.currentIndexChanged.connect(self._update_state)
        self.ui.importsListWidget.itemChanged.connect(self._imports_changed)
        self.ui.featuresListWidget.itemChanged.connect(self._features_changed)
        self.ui.batchModeComboBox.currentIndexChanged.connect(self._batch_mode_changed)
        self.ui.batchDimensionComboBox.currentIndexChanged.connect(self._batch_dimension_changed)
        self.ui.batchMappingTableWidget.itemChanged.connect(self._batch_mapping_changed)
        self.ui.scanBatchesButton.clicked.connect(lambda: self.batch_scan_requested.emit(self.settings()))
        self.ui.refreshButton.clicked.connect(self.refresh_requested)
        self.ui.runButton.clicked.connect(lambda: self.run_requested.emit(self.settings()))

    @staticmethod
    def _checked_values(widget):
        return [str(widget.item(index).data(Qt.UserRole)) for index in range(widget.count())
                if widget.item(index).checkState() == Qt.Checked]

    @staticmethod
    def _select_code(combo, code):
        index = combo.findData(code)
        if index >= 0:
            combo.setCurrentIndex(index)

    def _imports_changed(self, *_args):
        self._pending_dataset_ids = set(self._checked_values(self.ui.importsListWidget))

    def _features_changed(self, *_args):
        self._pending_feature_names = self._checked_values(self.ui.featuresListWidget)

    def set_template(self, template):
        self.template = template
        config = _mapping(getattr(template, "tsk_analysis", None))
        instances = [_mapping(item) for item in config.get("instances", [])]
        self._template_ready = bool(config.get("enabled") and instances)
        self._ready_override = None
        complete_xy = sum(_finite(item.get("x")) and _finite(item.get("y")) for item in instances)
        if not instances:
            summary = self.ui.topologySummaryLabel.property("emptyText")
        else:
            chains = {tuple(item.get("chain_key") or [item.get("chain_id", "")]) for item in instances}
            types = {item.get("tsk_id") for item in instances}
            summary = (f"{len(chains)} Chains · {len(types)} TSK types · {len(instances)} instances\n"
                       f"有效 XY：{complete_xy}/{len(instances)} · 坐标单位：{config.get('coordinate_unit') or '未指定'}")
        if not config.get("enabled"):
            summary = f"{self.ui.topologySummaryLabel.property('disabledText')}\n{summary}"
        self.ui.topologySummaryLabel.setText(str(summary))
        self.ui.includeXYCheckBox.setEnabled(bool(complete_xy))
        self.ui.includeXYCheckBox.setChecked(bool(config.get("use_xy")))
        self._select_code(self.ui.featureModelComboBox, config.get("feature_model", "logistic"))
        self.set_shared_fail_rules(getattr(template, "report", None))
        features = sorted(set(config.get("feature_columns", [])) |
                          {key for item in instances for key in item.get("features", {})}, key=str.casefold)
        selected = set(config.get("feature_columns", []))
        categorical = set(config.get("categorical_feature_columns", []))
        self.ui.featuresListWidget.blockSignals(True)
        self.ui.featuresListWidget.clear()
        for name in features:
            text = self.ui.featuresListWidget.property("categoricalItemText").format(name=name) if name in categorical else name
            item = QListWidgetItem(text)
            item.setData(Qt.UserRole, name)
            hint = "categoricalHintText" if name in categorical else "numericHintText"
            item.setToolTip(self.ui.featuresListWidget.property(hint))
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if name in selected else Qt.Unchecked)
            self.ui.featuresListWidget.addItem(item)
        self.ui.featuresListWidget.blockSignals(False)
        self._pending_feature_names = None
        self.ui.featuresListWidget.setEnabled(bool(features))
        dimensions = [dimension.name for dimension in getattr(template, "row_dimensions", [])]
        node = getattr(getattr(template, "report", None), "reliability_node_dimension", "")
        available = [name for name in dimensions if name != node]
        self._reset_batch_dimensions(available)
        self._update_state()

    def set_shared_fail_rules(self, report):
        """Display the Analyze rule snapshot without maintaining a TSK override."""
        report = _mapping(report)
        label = self.ui.sharedFailRulesLabel
        if not report:
            label.setText(label.property("emptyText"))
            return
        method = report.get("outlier_fail_method")
        method_property = {
            "modified_z_score": "modifiedZScoreText", "golden_deviation": "goldenDeviationText",
            "zscore_and_golden": "combinedAndText", "zscore_or_golden": "combinedOrText",
        }.get(method)
        method_name = label.property(method_property) if method_property else str(method or label.property("unknownText"))
        threshold = _mapping(report.get("zscore_thresholds")).get("default")
        threshold_text = f"{threshold:g}" if _finite(threshold) else label.property("unknownText")
        empty = report.get("outlier_treat_empty_cells_as_fail")
        empty_property = "emptyEnabledText" if empty is True else "emptyDisabledText" if empty is False else "unknownText"
        label.setText(label.property("summaryFormat").format(method=method_name, threshold=threshold_text,
                                                            empty=label.property(empty_property)))

    def _reset_batch_dimensions(self, dimensions):
        self.ui.batchModeComboBox.blockSignals(True)
        self.ui.batchDimensionComboBox.blockSignals(True)
        self.ui.batchModeComboBox.setCurrentIndex(0)
        self.ui.batchDimensionComboBox.clear()
        self.ui.batchDimensionComboBox.addItem(self.ui.batchDimensionComboBox.property("noBatchFieldText"), None)
        for name in dimensions:
            self.ui.batchDimensionComboBox.addItem(name, name)
        self._select_code(self.ui.batchDimensionComboBox, preferred_batch_field(dimensions))
        self.ui.batchModeComboBox.blockSignals(False)
        self.ui.batchDimensionComboBox.blockSignals(False)
        self._batch_mode = "none"
        self._batch_dimension = str(self.ui.batchDimensionComboBox.currentData() or "")
        self._batch_mappings.clear()
        self._batch_values.clear()
        self._render_batch_values()

    def _commit_batch_editor(self):
        """Read the current editor before run, scan, persistence or hiding rows."""
        table = self.ui.batchMappingTableWidget
        editor = QApplication.focusWidget()
        if isinstance(editor, QLineEdit) and table.isAncestorOf(editor):
            index = table.currentIndex()
            if index.isValid() and index.column() == 1:
                table.itemDelegateForIndex(index).setModelData(editor, table.model(), index)

    def _remember_batch_mapping(self):
        self._commit_batch_editor()
        if not self._batch_dimension:
            return
        mapping = self._batch_mappings.setdefault(self._batch_dimension, {})
        table = self.ui.batchMappingTableWidget
        for row in range(table.rowCount()):
            source, parent = table.item(row, 0), table.item(row, 1)
            if source is not None and parent is not None:
                mapping[str(source.data(Qt.UserRole))] = parent.text().strip()

    def _batch_mode_changed(self, *_args):
        self._remember_batch_mapping()
        self._batch_mode = str(self.ui.batchModeComboBox.currentData() or "none")
        self._update_state()

    def _batch_dimension_changed(self, *_args):
        self._remember_batch_mapping()
        self._batch_dimension = str(self.ui.batchDimensionComboBox.currentData() or "")
        self._render_batch_values()
        self._update_state()

    def _batch_mapping_changed(self, item):
        if item.column() == 1 and self._batch_dimension:
            source = self.ui.batchMappingTableWidget.item(item.row(), 0)
            if source is not None:
                self._batch_mappings.setdefault(self._batch_dimension, {})[str(source.data(Qt.UserRole))] = item.text().strip()

    def _render_batch_values(self):
        table = self.ui.batchMappingTableWidget
        values = self._batch_values.get(self._batch_dimension, [])
        mapping = self._batch_mappings.get(self._batch_dimension, {})
        table.blockSignals(True)
        table.setRowCount(0)
        table.setRowCount(len(values))
        for row, value in enumerate(values):
            source = QTableWidgetItem(value)
            source.setData(Qt.UserRole, value)
            source.setFlags(source.flags() & ~Qt.ItemIsEditable)
            parent = QTableWidgetItem(mapping.get(value, value))
            if self._batch_mode != "parent":
                parent.setFlags(parent.flags() & ~Qt.ItemIsEditable)
            table.setItem(row, 0, source)
            table.setItem(row, 1, parent)
        table.blockSignals(False)

    def set_batch_values(self, values: list[str]):
        self._remember_batch_mapping()
        if not self._batch_dimension:
            return
        values = list(dict.fromkeys(str(value) for value in values))
        mapping = self._batch_mappings.setdefault(self._batch_dimension, {})
        for value in values:
            mapping.setdefault(value, value)
        self._batch_values[self._batch_dimension] = values
        self._render_batch_values()
        self._update_state()

    def set_import_entries(self, entries):
        selected = self._pending_dataset_ids | set(self._checked_values(self.ui.importsListWidget))
        self.ui.importsListWidget.blockSignals(True)
        self.ui.importsListWidget.clear()
        for entry in entries or []:
            dataset_id = str(entry.get("dataset_id", ""))
            if not dataset_id:
                continue
            label = (f"{entry.get('created_at_utc', '')} | {dataset_id} | "
                     f"{Path(str(entry.get('source_file') or '')).name} | {entry.get('measurement_count', '')} measurements")
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, dataset_id)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if dataset_id in selected else Qt.Unchecked)
            self.ui.importsListWidget.addItem(item)
        self.ui.importsListWidget.blockSignals(False)
        self._pending_dataset_ids = selected
        self._update_state()

    def set_context(self, mapping_summary: str = "", *, ready: bool | None = None):
        if mapping_summary:
            self.ui.contextLabel.setText(mapping_summary)
        self._ready_override = ready
        self._update_state()

    def _update_state(self, *_args):
        model_hint = self.ui.featureModelHintLabel
        hint_property = "linearHazardText" if self.ui.featureModelComboBox.currentData() == "linear_hazard" else "logisticText"
        model_hint.setText(model_hint.property(hint_property))
        database = self.ui.sourceComboBox.currentData() == "database"
        self.ui.scopeComboBox.setEnabled(database)
        self.ui.refreshButton.setEnabled(database)
        self.ui.importsListWidget.setEnabled(database and self.ui.scopeComboBox.currentData() == "checked_imports")
        self.ui.runButton.setEnabled(self._template_ready if self._ready_override is None else self._ready_override)
        batch_enabled = self._batch_mode != "none"
        parent_mode = self._batch_mode == "parent"
        self.ui.batchDimensionComboBox.setEnabled(self.ui.batchDimensionComboBox.count() > 0)
        self.ui.scanBatchesButton.setEnabled(batch_enabled and bool(self._batch_dimension))
        for widget in (self.ui.batchMappingHintLabel, self.ui.batchMappingTableWidget, self.ui.batchScanHintLabel):
            widget.setVisible(batch_enabled)
        self.ui.batchMappingHintLabel.setText(self.ui.batchMappingHintLabel.property("parentText" if parent_mode else "separateText"))
        table = self.ui.batchMappingTableWidget
        table.setEnabled(batch_enabled)
        table.setColumnHidden(1, not parent_mode)
        table.setEditTriggers((QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed | QAbstractItemView.SelectedClicked)
                              if parent_mode else QAbstractItemView.NoEditTriggers)
        table.blockSignals(True)
        for row in range(table.rowCount()):
            item = table.item(row, 1)
            item.setFlags((item.flags() | Qt.ItemIsEditable) if parent_mode else (item.flags() & ~Qt.ItemIsEditable))
        table.blockSignals(False)

    def settings(self):
        self._remember_batch_mapping()
        return {
            "source": self.ui.sourceComboBox.currentData(),
            "analysis_scope": self.ui.scopeComboBox.currentData(),
            "dataset_ids": self._checked_values(self.ui.importsListWidget),
            "nodes": _values(self.ui.nodesEdit.text()),
            "sample_ids": _values(self.ui.samplesEdit.text()),
            "batch_mode": self._batch_mode,
            "batch_dimension": self.ui.batchDimensionComboBox.currentData() if self.ui.batchDimensionComboBox.currentIndex() >= 0 else "",
            "batch_mapping": dict(self._batch_mappings.get(self._batch_dimension, {})),
            "include_xy": self.ui.includeXYCheckBox.isChecked(),
            "feature_model": self.ui.featureModelComboBox.currentData(),
            "feature_names": self._checked_values(self.ui.featuresListWidget),
            "confidence_level": .95,
        }

    def restore_settings(self, settings):
        if not isinstance(settings, dict):
            return
        for name, combo in (("source", self.ui.sourceComboBox), ("analysis_scope", self.ui.scopeComboBox),
                            ("feature_model", self.ui.featureModelComboBox)):
            if name in settings:
                self._select_code(combo, settings[name])
        for name, edit in (("nodes", self.ui.nodesEdit), ("sample_ids", self.ui.samplesEdit)):
            if isinstance(settings.get(name), list):
                edit.setText(", ".join(str(value) for value in settings[name]))
        if "include_xy" in settings:
            self.ui.includeXYCheckBox.setChecked(bool(settings["include_xy"]))
        for name, widget in (("dataset_ids", self.ui.importsListWidget), ("feature_names", self.ui.featuresListWidget)):
            if not isinstance(settings.get(name), list):
                continue
            selected = set(str(value) for value in settings[name])
            widget.blockSignals(True)
            for index in range(widget.count()):
                item = widget.item(index)
                item.setCheckState(Qt.Checked if str(item.data(Qt.UserRole)) in selected else Qt.Unchecked)
            widget.blockSignals(False)
            if name == "dataset_ids":
                self._pending_dataset_ids = selected
            else:
                self._pending_feature_names = list(selected)
        if "batch_dimension" in settings:
            # A removed field must be chosen again, never silently mapped to another dimension.
            self.ui.batchDimensionComboBox.setCurrentIndex(self.ui.batchDimensionComboBox.findData(settings["batch_dimension"]))
        if "batch_mode" in settings:
            self._select_code(self.ui.batchModeComboBox, settings["batch_mode"])
        if isinstance(settings.get("batch_mapping"), dict) and self._batch_dimension:
            mapping = {str(source): "" if parent is None else str(parent) for source, parent in settings["batch_mapping"].items()}
            self._batch_mappings[self._batch_dimension] = mapping
            self._batch_values[self._batch_dimension] = list(mapping)
            self._render_batch_values()
        self._update_state()


class _ResultTableModel(QAbstractTableModel):
    """Numeric sorting and lazy cells for compact results and larger topologies."""

    def __init__(self, columns, headers, parent=None):
        super().__init__(parent)
        self.columns = list(columns)
        self.headers = list(headers)
        self.rows = []
        self._sort_column = -1
        self._sort_order = Qt.AscendingOrder

    def set_rows(self, rows, *, columns=None, headers=None):
        self.beginResetModel()
        self.rows = list(rows)
        if columns is not None:
            self.columns = list(columns)
        if headers is not None:
            self.headers = list(headers)
        if 0 <= self._sort_column < len(self.columns):
            self._sort()
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.columns)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role == Qt.DisplayRole:
            return self.headers[section] if orientation == Qt.Horizontal else str(section + 1)
        return None

    def _raw(self, row, key):
        if key == "n_passed":
            return max(0, int(row.get("n_tested", 0)) - int(row.get("n_failed", 0)))
        if key == "identifiable" and row.get("status") == "no_data":
            return None
        if key == "support_status" and row.get("status") == "no_data":
            return self.parent().property("noDataSupportText") or row.get(key)
        if key in {"probability", "ci_lower", "ci_upper"} and row.get("identifiable") is False:
            return None
        if key.startswith("features."):
            return row.get("features", {}).get(key.removeprefix("features."))
        return row.get(key)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        key, kind = self.columns[index.column()]
        value = self._raw(self.rows[index.row()], key)
        if role == Qt.TextAlignmentRole and kind in {"percent", "pp", "number", "integer"}:
            return int(Qt.AlignRight | Qt.AlignVCenter)
        if role not in {Qt.DisplayRole, Qt.ToolTipRole}:
            return None
        if value is None or isinstance(value, float) and not math.isfinite(value):
            return "—"
        if kind == "bool":
            return "是" if value else "否"
        if kind == "percent":
            return f"{float(value):.4%}"
        if kind == "pp":
            return f"{float(value) * 100:+.4f}"
        if kind == "number" and _finite(value):
            return f"{value:.6g}"
        if kind == "path" and isinstance(value, (list, tuple)):
            return " / ".join(str(part) for part in value)
        return str(value)

    def _sort(self):
        key = self.columns[self._sort_column][0]
        def sort_key(row):
            value = self._raw(row, key)
            if value is None:
                return (2, "")
            return (0, float(value)) if _finite(value) else (1, str(value).casefold())
        self.rows.sort(key=sort_key, reverse=self._sort_order == Qt.DescendingOrder)

    def sort(self, column, order=Qt.AscendingOrder):
        if not 0 <= column < len(self.columns):
            return
        self.beginResetModel()
        self._sort_column, self._sort_order = column, order
        self._sort()
        self.endResetModel()


class _CategoryValueDelegate(QStyledItemDelegate):
    """Bind each fixed-category cell to the fitted vocabulary for that row."""
    def createEditor(self, parent, option, index):
        editor = QComboBox(parent)
        editor.addItems(list(index.data(Qt.UserRole) or []))
        editor.currentIndexChanged.connect(lambda *_: self.commitData.emit(editor))
        return editor

    def setEditorData(self, editor, index):
        editor.blockSignals(True)
        editor.setCurrentText(str(index.data(Qt.EditRole) or ""))
        editor.blockSignals(False)

    def setModelData(self, editor, model, index):
        model.setData(index, editor.currentText(), Qt.EditRole)

    def initStyleOption(self, option, index):
        super().initStyleOption(option, index)
        # Native macOS comboboxes have transparent margins. The persistent
        # editor owns the text, so the underlying item must not draw it twice.
        option.text = ""


class TskResultsPanel(QWidget):
    export_requested = Signal()
    combination_requested = Signal(dict)
    TYPE_COLUMNS = [("tsk_id", "text"), ("level", "text"), ("probability", "percent"), ("ci_lower", "percent"),
                    ("ci_upper", "percent"), ("identifiable", "bool"), ("status", "text"),
                    ("instance_count", "integer"), ("interval_method", "text"), ("interval_error", "text")]
    CHAIN_COLUMNS = [("chain_id", "text"), ("n_tested", "integer"), ("n_failed", "integer"),
                     ("n_passed", "integer"), ("n_missing", "integer"), ("observed_probability", "percent"),
                     ("predicted_probability", "percent"), ("residual", "pp"), ("deviance_residual", "number")]
    TOPOLOGY_COLUMNS = [("chain_id", "text"), ("tsk_instance_id", "text"), ("tsk_id", "text"),
                        ("x", "number"), ("y", "number"), ("chain_key", "path")]
    COMBINATION_COLUMNS = [("tsk_id", "text"), ("level", "text"), ("probability", "percent"),
                           ("ci_lower", "percent"), ("ci_upper", "percent"),
                           ("delta_probability", "pp"), ("delta_ci_lower", "pp"), ("delta_ci_upper", "pp"),
                           ("support_status", "text"), ("layout_instance_count", "integer"),
                           ("active_instance_count", "integer"), ("chain_count", "integer"),
                           ("chain_test_exposure", "integer"), ("status", "text"), ("delta_status", "text"),
                           ("interval_error", "text"), ("delta_interval_error", "text")]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskResultsPanelForm()
        self.ui.setupUi(self)
        self.result = {}
        self.types_model = self._table_model(self.ui.typesTableView, self.TYPE_COLUMNS)
        self.chains_model = self._table_model(self.ui.chainsTableView, self.CHAIN_COLUMNS)
        self.topology_model = self._table_model(self.ui.topologyTableView, self.TOPOLOGY_COLUMNS)
        self.combination_model = self._table_model(self.ui.combinationTableView, self.COMBINATION_COLUMNS)
        self._combination_view = None
        self._combination_busy = False
        self._combination_categories = {}
        self.ui.combinationFixedTableWidget.setItemDelegateForColumn(
            1, _CategoryValueDelegate(self.ui.combinationFixedTableWidget))
        self.ui.combinationFixedTableWidget.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.ui.combinationDimensionComboBox.currentIndexChanged.connect(self._combination_dimension_changed)
        self.ui.combinationTypeComboBox.currentIndexChanged.connect(self._update_combination_request_state)
        self.ui.calculateCombinationButton.clicked.connect(self._request_combination)
        self.ui.combinationHeatmapMetricComboBox.currentIndexChanged.connect(
            lambda index: self.ui.combinationHeatmap.set_metric("support" if index else "probability"))
        self.ui.combinationCompareTypeComboBox.currentIndexChanged.connect(self._show_combination_type)
        self.ui.combinationHeatmap.cell_selected.connect(self._combination_cell_selected)
        self.ui.groupComboBox.currentIndexChanged.connect(self._show_group)
        self.ui.exportButton.clicked.connect(self.export_requested)
        self._reset_combination_group()

    @staticmethod
    def _table_model(table, columns):
        model = _ResultTableModel(columns, table.property("columnHeaders") or [], table)
        table.setModel(model)
        table.horizontalHeader().setResizeContentsPrecision(100)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        table.horizontalHeader().setStretchLastSection(True)
        return model

    @property
    def current_group(self):
        index = self.ui.groupComboBox.currentIndex()
        groups = self.result.get("groups", [])
        return groups[index] if 0 <= index < len(groups) else None

    def set_result(self, payload):
        self.result = _mapping(payload)
        self.ui.groupComboBox.blockSignals(True)
        self.ui.groupComboBox.clear()
        for index, group in enumerate(self.result.get("groups", [])):
            self.ui.groupComboBox.addItem(str(group.get("label") or group.get("node") or f"Group {index + 1}"), index)
        self.ui.groupComboBox.blockSignals(False)
        groups = self.result.get("groups", [])
        self.ui.groupComboBox.setEnabled(bool(groups))
        self.ui.exportButton.setEnabled(bool(groups))
        topology = [_mapping(row) for row in self.result.get("topology", [])]
        features = sorted({name for row in topology for name in row.get("features", {})}, key=str.casefold)
        config = self.result.get("provenance", {}).get("template_snapshot", {}).get("tsk_analysis", {})
        categorical = set(config.get("categorical_feature_columns", []))
        columns = self.TOPOLOGY_COLUMNS + [("features." + name, "text" if name in categorical else "number") for name in features]
        headers = list(self.ui.topologyTableView.property("columnHeaders") or []) + features
        self.topology_model.set_rows(topology, columns=columns, headers=headers)
        self._show_group()

    def clear_result(self, message: str = ""):
        self.set_result({})
        self.ui.summaryLabel.setText(message or self.ui.summaryLabel.property("emptyText"))

    def _show_group(self, *_args):
        group = self.current_group or {}
        types = list(group.get("types", []))
        chains = list(group.get("chains", []))
        self.types_model.set_rows(types)
        self.chains_model.set_rows(chains)
        self.ui.riskPlot.setProperty("axisLabel", self.ui.riskPlot.property("typeAxisLabel"))
        self.ui.riskPlot.set_rows(types)
        self.ui.chainPlot.set_rows(chains)
        diagnostics = group.get("diagnostics", {})
        confidence = float((group.get("prediction_context") or {}).get("confidence_level",
                           diagnostics.get("confidence_level", group.get("options", {}).get("confidence_level", .95))))
        self.ui.riskPlot.setProperty("confidenceLevel", confidence)
        self.ui.riskLegendLabel.setText(self.ui.riskLegendLabel.property("formatText").format(confidence=f"{confidence:.0%}"))
        warnings = list(self.result.get("warnings", [])) + list(diagnostics.get("warnings", []))
        unique_warnings = list(dict.fromkeys(str(item) for item in warnings if item))
        self.ui.warningsLabel.setVisible(bool(unique_warnings))
        self.ui.warningsLabel.setText(self.ui.warningsLabel.property("summaryText").format(count=len(unique_warnings)))
        self.ui.warningsLabel.setToolTip("\n".join(unique_warnings))
        if not group:
            self.ui.summaryLabel.setText(self.ui.summaryLabel.property("emptyText"))
            self.ui.summaryLabel.setToolTip("")
            self.ui.referenceLabel.clear()
            self.ui.referenceLabel.setToolTip("")
            self.ui.riskLegendLabel.setToolTip("")
            self._reset_combination_group()
            return
        convergence = "已收敛" if diagnostics.get("converged") else "未确认收敛"
        rank = diagnostics.get("rank", "—")
        parameters = diagnostics.get("parameter_count", "—")
        summary = f"{len(types)} TSK types · {len(chains)} Chains · {convergence} · 秩 {rank}/{parameters}"
        model = diagnostics.get("model")
        options = group.get("options", {})
        feature_model = options.get("feature_model", "logistic")
        if model == "instance_linear_hazard_features":
            feature_model = "linear_hazard"
        elif model == "instance_logistic_features":
            feature_model = "logistic"
        model_property = "linearHazardModelText" if feature_model == "linear_hazard" else "logisticModelText"
        summary += "\n" + self.ui.summaryLabel.property("modelSummaryFormat").format(
            model=self.ui.summaryLabel.property(model_property),
            details=self.ui.summaryLabel.property("typeOnlyModelSuffix") if model == "type_only" else "")
        source_batches = [str(value) for value in group.get("source_batches", [])]
        batch_mode = group.get("batch_mode", "none")
        if source_batches:
            members = ", ".join(source_batches[:6]) + (f" 等 {len(source_batches)} 批" if len(source_batches) > 6 else "")
            if batch_mode == "none":
                summary += f"\n混合全部原批：{members}"
            else:
                summary += (f"\n母批：{group.get('parent_batch_id', '')} · 原批：{members}" if batch_mode == "parent" else f"\n原批：{members}")
        details = [f"原批次字段：{group.get('batch_dimension', '')}", f"原批次成员：{', '.join(source_batches)}"] if source_batches else []
        details.extend(f"{row.get('source_batch', '')} / {row.get('chain_id', '')}: "
                       f"Tested={row.get('n_tested', 0)}, Fail={row.get('n_failed', 0)}, "
                       f"Pass={row.get('n_passed', 0)}, Missing={row.get('n_missing', 0)}"
                       for row in group.get("batch_counts", []))
        self.ui.summaryLabel.setText(summary)
        self.ui.summaryLabel.setToolTip("\n".join(details))
        reference = diagnostics.get("reference_environment")
        reference_text = json.dumps(reference, ensure_ascii=False) if isinstance(reference, (list, dict)) else str(reference or "")
        self.ui.referenceLabel.setToolTip(reference_text)
        categories = diagnostics.get("categorical_features", {})
        if categories:
            references = "; ".join(f"{name}={info['reference']}" for name, info in categories.items())
            self.ui.referenceLabel.setText(self.ui.referenceLabel.property("categoricalText").format(categories=references))
        elif options.get("categorical_feature_names"):
            self.ui.referenceLabel.setText(self.ui.referenceLabel.property("categoricalNoFitText"))
        elif model in {"instance_logistic_features", "instance_linear_hazard_features"} or (model != "type_only" and (
                options.get("include_xy") or options.get("use_xy") or options.get("feature_names"))):
            self.ui.referenceLabel.setText(self.ui.referenceLabel.property("featureText"))
        elif model == "type_only" or not reference:
            self.ui.referenceLabel.setText(self.ui.referenceLabel.property("typeOnlyText"))
        else:
            self.ui.referenceLabel.setText(f"概率参照环境：{reference_text}")
        self.ui.riskLegendLabel.setToolTip(str(diagnostics.get("interval_method", "")))
        self._reset_combination_group()

    def _fixed_categories(self):
        table = self.ui.combinationFixedTableWidget
        return {table.item(row, 0).text(): table.item(row, 1).text() for row in range(table.rowCount())}

    def _reset_combination_group(self):
        group = self.current_group or {}
        names = group.get("options", {}).get("categorical_feature_names", [])
        definitions = group.get("diagnostics", {}).get("categorical_features", {})
        fitted_order = (group.get("prediction_context") or {}).get("categorical_features", {})
        names = [name for name in fitted_order if name in names] + [name for name in names if name not in fitted_order]
        self._combination_categories = {name: definitions[name] for name in names
                                        if name in definitions and definitions[name].get("levels")}
        views = group.get("combination_views", [])
        latest = views[-1] if views else None
        dimension = self.ui.combinationDimensionComboBox
        dimension.blockSignals(True)
        dimension.clear()
        if self._combination_categories:
            dimension.addItem(dimension.property("allCategoriesText"), ALL_CATEGORY_COMBINATIONS)
        for name in self._combination_categories:
            dimension.addItem(name, name)
        if latest:
            dimension.setCurrentIndex(max(0, dimension.findData(latest.get("dimension"))))
        dimension.blockSignals(False)
        types = self.ui.combinationTypeComboBox
        types.blockSignals(True)
        types.clear()
        types.addItem(types.property("allText"), None)
        for row in group.get("types", []):
            types.addItem(str(row["tsk_id"]), str(row["tsk_id"]))
        if latest:
            fitted_types = set(row["tsk_id"] for row in latest.get("rows", []))
            if len(fitted_types) == 1:
                types.setCurrentIndex(max(0, types.findData(next(iter(fitted_types)))))
        types.blockSignals(False)
        self.ui.combinationNoExtrapolationCheckBox.setChecked(not latest.get("extrapolate", True) if latest else True)
        self._combination_dimension_changed(fixed=(latest or {}).get("fixed_categories", {}),
                                            reference=(latest or {}).get("reference_level"))
        self.set_combination_result(latest)

    def _combination_dimension_changed(self, *_args, fixed=None, reference=None):
        name = self.ui.combinationDimensionComboBox.currentData()
        selected = self._combination_categories.get(name, {})
        fixed = self._fixed_categories() if fixed is None else fixed
        combo = self.ui.combinationReferenceComboBox
        combo.clear()
        all_categories = name == ALL_CATEGORY_COMBINATIONS
        if all_categories:
            names = list(self._combination_categories)
            definitions = list(self._combination_categories.values())
            level_count = math.prod(len(definition["levels"]) for definition in definitions)
            levels = [category_combination_label(dict(zip(names, values)))
                      for values in product(*(definition["levels"] for definition in definitions))] if level_count <= 200 else []
            default_reference = category_combination_label({key: definition["reference"]
                                                          for key, definition in self._combination_categories.items()})
        else:
            levels = selected.get("levels", [])
            default_reference = selected.get("reference")
        for level in levels:
            combo.addItem(str(level), str(level))
        combo.setCurrentIndex(max(0, combo.findData(reference or default_reference)))
        table = self.ui.combinationFixedTableWidget
        others = [] if all_categories else [(key, definition) for key, definition in self._combination_categories.items() if key != name]
        table.setRowCount(0)
        table.setRowCount(len(others))
        for row, (key, definition) in enumerate(others):
            name_item = QTableWidgetItem(key)
            name_item.setFlags(name_item.flags() & ~Qt.ItemIsEditable)
            table.setItem(row, 0, name_item)
            value = fixed.get(key, definition.get("reference"))
            if value not in definition["levels"]:
                value = definition["reference"]
            value_item = QTableWidgetItem(str(value))
            value_item.setData(Qt.UserRole, list(definition["levels"]))
            table.setItem(row, 1, value_item)
            table.openPersistentEditor(value_item)
        table.setVisible(bool(others))
        self._update_combination_request_state()

    def set_combination_busy(self, busy):
        self._combination_busy = bool(busy)
        self._update_combination_request_state()

    def _update_combination_request_state(self, *_args):
        group = self.current_group or {}
        name = self.ui.combinationDimensionComboBox.currentData()
        valid = bool(self._combination_categories and group.get("prediction_context"))
        selected_type = self.ui.combinationTypeComboBox.currentData()
        type_count = 1 if selected_type is not None else len(group.get("types", []))
        level_count = (math.prod(len(definition["levels"]) for definition in self._combination_categories.values())
                       if name == ALL_CATEGORY_COMBINATIONS else len(self._combination_categories.get(name, {}).get("levels", [])))
        count = type_count * level_count
        status = self.ui.combinationStatusLabel
        if self._combination_busy:
            text = status.property("busyText")
        elif not group.get("options", {}).get("categorical_feature_names"):
            text = status.property("noCategoriesText")
        elif not valid:
            text = status.property("noContextText")
        else:
            text = status.property("limitText" if count > 200 else "readyText").format(count=count)
        status.setText(str(text))
        for widget in (self.ui.combinationDimensionComboBox, self.ui.combinationTypeComboBox,
                       self.ui.combinationReferenceComboBox, self.ui.combinationFixedTableWidget,
                       self.ui.combinationNoExtrapolationCheckBox):
            widget.setEnabled(valid and not self._combination_busy)
        self.ui.calculateCombinationButton.setEnabled(valid and 0 < count <= 200 and not self._combination_busy)

    def _request_combination(self):
        if not self.ui.calculateCombinationButton.isEnabled():
            return
        tsk_id = self.ui.combinationTypeComboBox.currentData()
        self.combination_requested.emit({
            "dimension": self.ui.combinationDimensionComboBox.currentData(),
            "reference_level": self.ui.combinationReferenceComboBox.currentData(),
            "fixed_categories": self._fixed_categories(),
            "tsk_ids": None if tsk_id is None else [tsk_id],
            "extrapolate": not self.ui.combinationNoExtrapolationCheckBox.isChecked(),
        })

    def set_combination_result(self, view):
        """Show one calculated view; the window owns its group cache."""
        self._combination_view = view
        legend = self.ui.combinationCompareLegendLabel
        legend.setText(legend.property("formatText").format(confidence=f"{float((view or {}).get('confidence_level', .95)):.0%}"))
        rows = list((view or {}).get("rows", []))
        self.combination_model.set_rows(rows)
        self.ui.combinationHeatmap.set_view(view)
        label = self.ui.combinationConditionsLabel
        if view:
            fixed = "; ".join(f"{key}={value}" for key, value in view.get("fixed_categories", {}).items())
            numeric = "; ".join(f"{key}={value:.5g}" for key, value in view.get("numeric_reference", {}).items())
            dimension = (self.ui.combinationDimensionComboBox.property("allCategoriesText")
                         if view["dimension"] == ALL_CATEGORY_COMBINATIONS else view["dimension"])
            conditions = label.property("formatText").format(dimension=dimension, reference=view["reference_level"],
                          fixed=fixed or label.property("noneText"), numeric=numeric or label.property("noneText"),
                          missing=self.ui.referenceLabel.property("extrapolationText" if view.get("extrapolate", True) else "noExtrapolationText"))
            label.setText(conditions if len(conditions) <= 85 else conditions[:82] + "…")
            label.setToolTip(conditions)
        else:
            label.setText(label.property("emptyText"))
            label.setToolTip("")
        warnings = list((view or {}).get("warnings", []))
        self.ui.combinationWarningsLabel.setText(self.ui.combinationWarningsLabel.property("summaryText").format(count=len(warnings)))
        self.ui.combinationWarningsLabel.setToolTip("\n".join(str(item) for item in warnings))
        self.ui.combinationWarningsLabel.setVisible(bool(warnings))
        group_warnings = list(self.result.get("warnings", [])) + list((self.current_group or {}).get("diagnostics", {}).get("warnings", []))
        details = self.ui.combinationWarningsTextEdit
        sections = [str(details.property("modelScopeText"))] if view else []
        if group_warnings:
            sections.append(str(details.property("groupHeading")) + "\n" + "\n\n".join(dict.fromkeys(str(item) for item in group_warnings)))
        if warnings:
            sections.append(str(details.property("viewHeading")) + "\n" + "\n\n".join(str(item) for item in warnings))
        details.setPlainText("\n\n".join(sections))
        combo = self.ui.combinationCompareTypeComboBox
        current = combo.currentData()
        combo.blockSignals(True)
        combo.clear()
        for tsk_id in dict.fromkeys(row["tsk_id"] for row in rows):
            combo.addItem(str(tsk_id), str(tsk_id))
        combo.setCurrentIndex(max(0, combo.findData(current)))
        combo.setEnabled(bool(rows))
        combo.blockSignals(False)
        self._show_combination_type()
        self._show_all_combination_risk(view)
        views = self.ui.combinationViewsTabWidget
        if not view:
            views.setCurrentWidget(self.ui.combinationSettingsTab)
        elif views.currentWidget() == self.ui.combinationSettingsTab:
            views.setCurrentWidget(self.ui.combinationHeatmapTab)

    def _probability_plot_rows(self, rows, view, *, full_labels=False):
        confidence = float(view.get("confidence_level", .95))
        plotted = []
        for row in rows:
            probability = f"{row['probability']:.4%}" if _finite(row.get("probability")) and row.get("identifiable", True) else "—"
            low = f"{row['ci_lower']:.4%}" if _finite(row.get("ci_lower")) else "—"
            high = f"{row['ci_upper']:.4%}" if _finite(row.get("ci_upper")) else "—"
            tooltip = self.ui.combinationProbabilityPlot.property("tooltipFormat").format(
                tsk_id=row["tsk_id"], level=row["level"], probability=probability, confidence=f"{confidence:.0%}",
                lower=low, upper=high,
                support=self.ui.combinationProbabilityPlot.property("noDataSupportText") if row.get("status") == "no_data" else row.get("support_status", ""),
                status=row.get("status", ""),
                interval_error=row.get("interval_error") or "—")
            if row.get("status") == "no_data":
                tooltip += "\n" + self.ui.combinationProbabilityPlot.property("noDataTooltip")
            if view.get("dimension") == ALL_CATEGORY_COMBINATIONS:
                categories = "\n".join(self.ui.riskPlot.property("categoryLineFormat").format(name=name, value=value)
                                       for name, value in row.get("categories", {}).items()) or row["level"]
                label = self.ui.riskPlot.property("combinationLabelFormat").format(
                    tsk_id=row["tsk_id"], categories=categories) if full_labels else categories
            else:
                label = row["level"]
            plotted.append({**row, "label": label, "tooltip": tooltip})
        return plotted

    def _show_all_combination_risk(self, view):
        if not view or view.get("dimension") != ALL_CATEGORY_COMBINATIONS:
            view = next((item for item in reversed((self.current_group or {}).get("combination_views", []))
                         if item.get("dimension") == ALL_CATEGORY_COMBINATIONS), None)
        self.ui.featurePanel.set_group(self.current_group or {}, view=view)
        if not view:
            return
        self.types_model.set_rows([{**row, "instance_count": row.get("layout_instance_count", 0)}
                                   for row in view.get("rows", [])])
        self.ui.riskPlot.setProperty("axisLabel", self.ui.riskPlot.property("combinationAxisLabel"))
        self.ui.riskPlot.set_rows(self._probability_plot_rows(view.get("rows", []), view, full_labels=True),
                                 preserve_order=True)
        self.ui.riskLegendLabel.setText(self.ui.riskLegendLabel.property("formatText").format(
            confidence=f"{float(view.get('confidence_level', .95)):.0%}"))
        self.ui.riskPlot.setProperty("confidenceLevel", float(view.get("confidence_level", .95)))
        reference = self.ui.referenceLabel
        reference.setText(reference.property("allCombinationsText").format(
            dimensions="、".join(view.get("categorical_dimensions", self._combination_categories)),
            missing=reference.property("extrapolationText" if view.get("extrapolate", True) else "noExtrapolationText")))
        reference.setToolTip(json.dumps(view.get("numeric_reference", {}), ensure_ascii=False))

    def _show_combination_type(self, *_args):
        view = self._combination_view or {}
        selected = self.ui.combinationCompareTypeComboBox.currentData()
        rows = [row for row in view.get("rows", []) if row["tsk_id"] == selected]
        plotted = self._probability_plot_rows(rows, view)
        self.ui.combinationProbabilityPlot.set_rows(plotted, preserve_order=True)
        self.ui.combinationDifferencePlot.set_rows(plotted)

    def _combination_cell_selected(self, tsk_id, level):
        combo = self.ui.combinationCompareTypeComboBox
        index = combo.findData(tsk_id)
        if index >= 0:
            combo.setCurrentIndex(index)
            self.ui.combinationViewsTabWidget.setCurrentWidget(self.ui.combinationCompareTab)
        for index, row in enumerate(self.combination_model.rows):
            if row.get("tsk_id") == tsk_id and row.get("level") == level:
                self.ui.combinationTableView.selectRow(index)
                break
