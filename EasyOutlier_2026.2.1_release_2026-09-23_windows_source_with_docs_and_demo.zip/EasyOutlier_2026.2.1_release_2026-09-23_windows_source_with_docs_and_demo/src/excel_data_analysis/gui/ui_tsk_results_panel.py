# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_results_panel.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QComboBox, QFormLayout,
    QFrame, QHBoxLayout, QHeaderView, QLabel,
    QPlainTextEdit, QPushButton, QScrollArea, QSizePolicy,
    QSpacerItem, QTabWidget, QTableView, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget)

from excel_data_analysis.gui.tsk_combination_plot import (TskCombinationHeatmap, TskDifferencePlot)
from excel_data_analysis.gui.tsk_plot import (TskChainFitPlot, TskRiskPlot)

class Ui_TskResultsPanelForm(object):
    def setupUi(self, TskResultsPanelForm):
        if not TskResultsPanelForm.objectName():
            TskResultsPanelForm.setObjectName(u"TskResultsPanelForm")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(TskResultsPanelForm.sizePolicy().hasHeightForWidth())
        TskResultsPanelForm.setSizePolicy(sizePolicy)
        self.panelLayout = QVBoxLayout(TskResultsPanelForm)
        self.panelLayout.setObjectName(u"panelLayout")
        self.panelLayout.setContentsMargins(0, 0, 0, 0)
        self.selectionLayout = QHBoxLayout()
        self.selectionLayout.setObjectName(u"selectionLayout")
        self.groupLabel = QLabel(TskResultsPanelForm)
        self.groupLabel.setObjectName(u"groupLabel")

        self.selectionLayout.addWidget(self.groupLabel)

        self.groupComboBox = QComboBox(TskResultsPanelForm)
        self.groupComboBox.setObjectName(u"groupComboBox")
        self.groupComboBox.setEnabled(False)
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.groupComboBox.sizePolicy().hasHeightForWidth())
        self.groupComboBox.setSizePolicy(sizePolicy1)
        self.groupComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.groupComboBox.setMinimumContentsLength(8)

        self.selectionLayout.addWidget(self.groupComboBox)

        self.exportButton = QPushButton(TskResultsPanelForm)
        self.exportButton.setObjectName(u"exportButton")
        self.exportButton.setEnabled(False)

        self.selectionLayout.addWidget(self.exportButton)


        self.panelLayout.addLayout(self.selectionLayout)

        self.summaryLabel = QLabel(TskResultsPanelForm)
        self.summaryLabel.setObjectName(u"summaryLabel")
        self.summaryLabel.setWordWrap(True)

        self.panelLayout.addWidget(self.summaryLabel)

        self.warningsLabel = QLabel(TskResultsPanelForm)
        self.warningsLabel.setObjectName(u"warningsLabel")
        self.warningsLabel.setVisible(False)
        self.warningsLabel.setWordWrap(True)
        self.warningsLabel.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        self.panelLayout.addWidget(self.warningsLabel)

        self.detailsTabWidget = QTabWidget(TskResultsPanelForm)
        self.detailsTabWidget.setObjectName(u"detailsTabWidget")
        self.riskTab = QWidget()
        self.riskTab.setObjectName(u"riskTab")
        self.riskLayout = QVBoxLayout(self.riskTab)
        self.riskLayout.setObjectName(u"riskLayout")
        self.riskLegendLabel = QLabel(self.riskTab)
        self.riskLegendLabel.setObjectName(u"riskLegendLabel")
        self.riskLegendLabel.setWordWrap(True)

        self.riskLayout.addWidget(self.riskLegendLabel)

        self.referenceLabel = QLabel(self.riskTab)
        self.referenceLabel.setObjectName(u"referenceLabel")
        self.referenceLabel.setWordWrap(True)
        self.referenceLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.riskLayout.addWidget(self.referenceLabel)

        self.riskScrollArea = QScrollArea(self.riskTab)
        self.riskScrollArea.setObjectName(u"riskScrollArea")
        self.riskScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.riskScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.riskScrollArea.setWidgetResizable(True)
        self.riskPlot = TskRiskPlot()
        self.riskPlot.setObjectName(u"riskPlot")
        self.riskPlot.setMinimumSize(QSize(0, 190))
        sizePolicy.setHeightForWidth(self.riskPlot.sizePolicy().hasHeightForWidth())
        self.riskPlot.setSizePolicy(sizePolicy)
        self.riskScrollArea.setWidget(self.riskPlot)

        self.riskLayout.addWidget(self.riskScrollArea)

        self.detailsTabWidget.addTab(self.riskTab, "")
        self.chainFitTab = QWidget()
        self.chainFitTab.setObjectName(u"chainFitTab")
        self.chainFitLayout = QVBoxLayout(self.chainFitTab)
        self.chainFitLayout.setObjectName(u"chainFitLayout")
        self.chainLegendLabel = QLabel(self.chainFitTab)
        self.chainLegendLabel.setObjectName(u"chainLegendLabel")
        self.chainLegendLabel.setWordWrap(True)

        self.chainFitLayout.addWidget(self.chainLegendLabel)

        self.chainPlot = TskChainFitPlot(self.chainFitTab)
        self.chainPlot.setObjectName(u"chainPlot")
        self.chainPlot.setMinimumSize(QSize(0, 210))
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(1)
        sizePolicy2.setHeightForWidth(self.chainPlot.sizePolicy().hasHeightForWidth())
        self.chainPlot.setSizePolicy(sizePolicy2)

        self.chainFitLayout.addWidget(self.chainPlot)

        self.chainsTableView = QTableView(self.chainFitTab)
        self.chainsTableView.setObjectName(u"chainsTableView")
        self.chainsTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.chainsTableView.setAlternatingRowColors(True)
        self.chainsTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.chainsTableView.setSortingEnabled(True)

        self.chainFitLayout.addWidget(self.chainsTableView)

        self.chainFitLayout.setStretch(1, 3)
        self.chainFitLayout.setStretch(2, 2)
        self.detailsTabWidget.addTab(self.chainFitTab, "")
        self.riskDetailsTab = QWidget()
        self.riskDetailsTab.setObjectName(u"riskDetailsTab")
        self.riskDetailsLayout = QVBoxLayout(self.riskDetailsTab)
        self.riskDetailsLayout.setObjectName(u"riskDetailsLayout")
        self.typesTableView = QTableView(self.riskDetailsTab)
        self.typesTableView.setObjectName(u"typesTableView")
        self.typesTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.typesTableView.setAlternatingRowColors(True)
        self.typesTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.typesTableView.setSortingEnabled(True)

        self.riskDetailsLayout.addWidget(self.typesTableView)

        self.detailsTabWidget.addTab(self.riskDetailsTab, "")
        self.combinationTab = QWidget()
        self.combinationTab.setObjectName(u"combinationTab")
        self.combinationLayout = QVBoxLayout(self.combinationTab)
        self.combinationLayout.setObjectName(u"combinationLayout")
        self.combinationConditionsLabel = QLabel(self.combinationTab)
        self.combinationConditionsLabel.setObjectName(u"combinationConditionsLabel")
        self.combinationConditionsLabel.setMaximumSize(QSize(16777215, 48))
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.combinationConditionsLabel.sizePolicy().hasHeightForWidth())
        self.combinationConditionsLabel.setSizePolicy(sizePolicy3)
        self.combinationConditionsLabel.setWordWrap(True)
        self.combinationConditionsLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.combinationLayout.addWidget(self.combinationConditionsLabel)

        self.combinationWarningsLabel = QLabel(self.combinationTab)
        self.combinationWarningsLabel.setObjectName(u"combinationWarningsLabel")
        self.combinationWarningsLabel.setVisible(False)
        self.combinationWarningsLabel.setWordWrap(True)
        self.combinationWarningsLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.combinationLayout.addWidget(self.combinationWarningsLabel)

        self.combinationViewsTabWidget = QTabWidget(self.combinationTab)
        self.combinationViewsTabWidget.setObjectName(u"combinationViewsTabWidget")
        self.combinationViewsTabWidget.setMinimumSize(QSize(0, 360))
        self.combinationHeatmapTab = QWidget()
        self.combinationHeatmapTab.setObjectName(u"combinationHeatmapTab")
        self.combinationHeatmapLayout = QVBoxLayout(self.combinationHeatmapTab)
        self.combinationHeatmapLayout.setObjectName(u"combinationHeatmapLayout")
        self.combinationHeatmapMetricComboBox = QComboBox(self.combinationHeatmapTab)
        self.combinationHeatmapMetricComboBox.addItem("")
        self.combinationHeatmapMetricComboBox.addItem("")
        self.combinationHeatmapMetricComboBox.setObjectName(u"combinationHeatmapMetricComboBox")

        self.combinationHeatmapLayout.addWidget(self.combinationHeatmapMetricComboBox)

        self.combinationHeatmapLegendLabel = QLabel(self.combinationHeatmapTab)
        self.combinationHeatmapLegendLabel.setObjectName(u"combinationHeatmapLegendLabel")
        self.combinationHeatmapLegendLabel.setWordWrap(True)

        self.combinationHeatmapLayout.addWidget(self.combinationHeatmapLegendLabel)

        self.combinationHeatmapScrollArea = QScrollArea(self.combinationHeatmapTab)
        self.combinationHeatmapScrollArea.setObjectName(u"combinationHeatmapScrollArea")
        self.combinationHeatmapScrollArea.setMinimumSize(QSize(0, 300))
        self.combinationHeatmapScrollArea.setWidgetResizable(True)
        self.combinationHeatmapScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.combinationHeatmap = TskCombinationHeatmap()
        self.combinationHeatmap.setObjectName(u"combinationHeatmap")
        self.combinationHeatmap.setMinimumSize(QSize(0, 160))
        self.combinationHeatmapScrollArea.setWidget(self.combinationHeatmap)

        self.combinationHeatmapLayout.addWidget(self.combinationHeatmapScrollArea)

        self.combinationViewsTabWidget.addTab(self.combinationHeatmapTab, "")
        self.combinationCompareTab = QWidget()
        self.combinationCompareTab.setObjectName(u"combinationCompareTab")
        self.combinationCompareLayout = QVBoxLayout(self.combinationCompareTab)
        self.combinationCompareLayout.setObjectName(u"combinationCompareLayout")
        self.combinationCompareTypeComboBox = QComboBox(self.combinationCompareTab)
        self.combinationCompareTypeComboBox.setObjectName(u"combinationCompareTypeComboBox")
        self.combinationCompareTypeComboBox.setEnabled(False)

        self.combinationCompareLayout.addWidget(self.combinationCompareTypeComboBox)

        self.combinationCompareLegendLabel = QLabel(self.combinationCompareTab)
        self.combinationCompareLegendLabel.setObjectName(u"combinationCompareLegendLabel")
        self.combinationCompareLegendLabel.setWordWrap(True)

        self.combinationCompareLayout.addWidget(self.combinationCompareLegendLabel)

        self.combinationCompareScrollArea = QScrollArea(self.combinationCompareTab)
        self.combinationCompareScrollArea.setObjectName(u"combinationCompareScrollArea")
        self.combinationCompareScrollArea.setMinimumSize(QSize(0, 300))
        self.combinationCompareScrollArea.setWidgetResizable(True)
        self.combinationCompareScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.combinationCompareScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.combinationCompareContents = QWidget()
        self.combinationCompareContents.setObjectName(u"combinationCompareContents")
        self.combinationCompareContentsLayout = QVBoxLayout(self.combinationCompareContents)
        self.combinationCompareContentsLayout.setObjectName(u"combinationCompareContentsLayout")
        self.combinationProbabilityPlot = TskRiskPlot(self.combinationCompareContents)
        self.combinationProbabilityPlot.setObjectName(u"combinationProbabilityPlot")
        self.combinationProbabilityPlot.setMinimumSize(QSize(0, 190))

        self.combinationCompareContentsLayout.addWidget(self.combinationProbabilityPlot)

        self.combinationDifferencePlot = TskDifferencePlot(self.combinationCompareContents)
        self.combinationDifferencePlot.setObjectName(u"combinationDifferencePlot")
        self.combinationDifferencePlot.setMinimumSize(QSize(0, 190))

        self.combinationCompareContentsLayout.addWidget(self.combinationDifferencePlot)

        self.combinationCompareScrollArea.setWidget(self.combinationCompareContents)

        self.combinationCompareLayout.addWidget(self.combinationCompareScrollArea)

        self.combinationViewsTabWidget.addTab(self.combinationCompareTab, "")
        self.combinationDetailsTab = QWidget()
        self.combinationDetailsTab.setObjectName(u"combinationDetailsTab")
        self.combinationDetailsLayout = QVBoxLayout(self.combinationDetailsTab)
        self.combinationDetailsLayout.setObjectName(u"combinationDetailsLayout")
        self.combinationTableView = QTableView(self.combinationDetailsTab)
        self.combinationTableView.setObjectName(u"combinationTableView")
        self.combinationTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.combinationTableView.setAlternatingRowColors(True)
        self.combinationTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.combinationTableView.setSortingEnabled(True)

        self.combinationDetailsLayout.addWidget(self.combinationTableView)

        self.combinationViewsTabWidget.addTab(self.combinationDetailsTab, "")
        self.combinationSettingsTab = QWidget()
        self.combinationSettingsTab.setObjectName(u"combinationSettingsTab")
        self.combinationSettingsLayout = QVBoxLayout(self.combinationSettingsTab)
        self.combinationSettingsLayout.setObjectName(u"combinationSettingsLayout")
        self.combinationSettingsScrollArea = QScrollArea(self.combinationSettingsTab)
        self.combinationSettingsScrollArea.setObjectName(u"combinationSettingsScrollArea")
        self.combinationSettingsScrollArea.setWidgetResizable(True)
        self.combinationSettingsScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.combinationSettingsScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.combinationSettingsContents = QWidget()
        self.combinationSettingsContents.setObjectName(u"combinationSettingsContents")
        self.combinationSettingsContentsLayout = QVBoxLayout(self.combinationSettingsContents)
        self.combinationSettingsContentsLayout.setObjectName(u"combinationSettingsContentsLayout")
        self.combinationHintLabel = QLabel(self.combinationSettingsContents)
        self.combinationHintLabel.setObjectName(u"combinationHintLabel")
        self.combinationHintLabel.setWordWrap(True)

        self.combinationSettingsContentsLayout.addWidget(self.combinationHintLabel)

        self.combinationControlsLayout = QFormLayout()
        self.combinationControlsLayout.setObjectName(u"combinationControlsLayout")
        self.combinationControlsLayout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.combinationDimensionLabel = QLabel(self.combinationSettingsContents)
        self.combinationDimensionLabel.setObjectName(u"combinationDimensionLabel")

        self.combinationControlsLayout.setWidget(0, QFormLayout.ItemRole.LabelRole, self.combinationDimensionLabel)

        self.combinationDimensionComboBox = QComboBox(self.combinationSettingsContents)
        self.combinationDimensionComboBox.setObjectName(u"combinationDimensionComboBox")
        self.combinationDimensionComboBox.setEnabled(False)
        self.combinationDimensionComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.combinationDimensionComboBox.setMinimumContentsLength(8)

        self.combinationControlsLayout.setWidget(0, QFormLayout.ItemRole.FieldRole, self.combinationDimensionComboBox)

        self.combinationTypeLabel = QLabel(self.combinationSettingsContents)
        self.combinationTypeLabel.setObjectName(u"combinationTypeLabel")

        self.combinationControlsLayout.setWidget(1, QFormLayout.ItemRole.LabelRole, self.combinationTypeLabel)

        self.combinationTypeComboBox = QComboBox(self.combinationSettingsContents)
        self.combinationTypeComboBox.setObjectName(u"combinationTypeComboBox")
        self.combinationTypeComboBox.setEnabled(False)
        self.combinationTypeComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.combinationTypeComboBox.setMinimumContentsLength(8)

        self.combinationControlsLayout.setWidget(1, QFormLayout.ItemRole.FieldRole, self.combinationTypeComboBox)

        self.combinationReferenceLabel = QLabel(self.combinationSettingsContents)
        self.combinationReferenceLabel.setObjectName(u"combinationReferenceLabel")

        self.combinationControlsLayout.setWidget(2, QFormLayout.ItemRole.LabelRole, self.combinationReferenceLabel)

        self.combinationReferenceComboBox = QComboBox(self.combinationSettingsContents)
        self.combinationReferenceComboBox.setObjectName(u"combinationReferenceComboBox")
        self.combinationReferenceComboBox.setEnabled(False)
        self.combinationReferenceComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.combinationReferenceComboBox.setMinimumContentsLength(8)

        self.combinationControlsLayout.setWidget(2, QFormLayout.ItemRole.FieldRole, self.combinationReferenceComboBox)


        self.combinationSettingsContentsLayout.addLayout(self.combinationControlsLayout)

        self.combinationFixedTableWidget = QTableWidget(self.combinationSettingsContents)
        if (self.combinationFixedTableWidget.columnCount() < 2):
            self.combinationFixedTableWidget.setColumnCount(2)
        __qtablewidgetitem = QTableWidgetItem()
        self.combinationFixedTableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.combinationFixedTableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        self.combinationFixedTableWidget.setObjectName(u"combinationFixedTableWidget")
        self.combinationFixedTableWidget.setEnabled(False)
        self.combinationFixedTableWidget.setMaximumSize(QSize(16777215, 112))
        self.combinationFixedTableWidget.setMinimumSize(QSize(0, 65))
        self.combinationFixedTableWidget.setAlternatingRowColors(True)
        self.combinationFixedTableWidget.setColumnCount(2)
        self.combinationFixedTableWidget.horizontalHeader().setStretchLastSection(True)
        self.combinationFixedTableWidget.verticalHeader().setVisible(False)

        self.combinationSettingsContentsLayout.addWidget(self.combinationFixedTableWidget)

        self.combinationActionLayout = QHBoxLayout()
        self.combinationActionLayout.setObjectName(u"combinationActionLayout")
        self.combinationStatusLabel = QLabel(self.combinationSettingsContents)
        self.combinationStatusLabel.setObjectName(u"combinationStatusLabel")
        self.combinationStatusLabel.setWordWrap(True)
        self.combinationStatusLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.combinationActionLayout.addWidget(self.combinationStatusLabel)

        self.calculateCombinationButton = QPushButton(self.combinationSettingsContents)
        self.calculateCombinationButton.setObjectName(u"calculateCombinationButton")
        self.calculateCombinationButton.setEnabled(False)

        self.combinationActionLayout.addWidget(self.calculateCombinationButton)


        self.combinationSettingsContentsLayout.addLayout(self.combinationActionLayout)

        self.combinationSettingsBottomSpacer = QSpacerItem(20, 20, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.combinationSettingsContentsLayout.addItem(self.combinationSettingsBottomSpacer)

        self.combinationSettingsScrollArea.setWidget(self.combinationSettingsContents)

        self.combinationSettingsLayout.addWidget(self.combinationSettingsScrollArea)

        self.combinationViewsTabWidget.addTab(self.combinationSettingsTab, "")
        self.combinationWarningsTab = QWidget()
        self.combinationWarningsTab.setObjectName(u"combinationWarningsTab")
        self.combinationWarningsLayout = QVBoxLayout(self.combinationWarningsTab)
        self.combinationWarningsLayout.setObjectName(u"combinationWarningsLayout")
        self.combinationWarningsTextEdit = QPlainTextEdit(self.combinationWarningsTab)
        self.combinationWarningsTextEdit.setObjectName(u"combinationWarningsTextEdit")
        self.combinationWarningsTextEdit.setReadOnly(True)

        self.combinationWarningsLayout.addWidget(self.combinationWarningsTextEdit)

        self.combinationViewsTabWidget.addTab(self.combinationWarningsTab, "")

        self.combinationLayout.addWidget(self.combinationViewsTabWidget)

        self.detailsTabWidget.addTab(self.combinationTab, "")
        self.topologyTab = QWidget()
        self.topologyTab.setObjectName(u"topologyTab")
        self.topologyLayout = QVBoxLayout(self.topologyTab)
        self.topologyLayout.setObjectName(u"topologyLayout")
        self.topologyHintLabel = QLabel(self.topologyTab)
        self.topologyHintLabel.setObjectName(u"topologyHintLabel")
        self.topologyHintLabel.setWordWrap(True)

        self.topologyLayout.addWidget(self.topologyHintLabel)

        self.topologyTableView = QTableView(self.topologyTab)
        self.topologyTableView.setObjectName(u"topologyTableView")
        self.topologyTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.topologyTableView.setAlternatingRowColors(True)
        self.topologyTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.topologyTableView.setSortingEnabled(True)

        self.topologyLayout.addWidget(self.topologyTableView)

        self.detailsTabWidget.addTab(self.topologyTab, "")

        self.panelLayout.addWidget(self.detailsTabWidget)

#if QT_CONFIG(shortcut)
        self.groupLabel.setBuddy(self.groupComboBox)
        self.combinationDimensionLabel.setBuddy(self.combinationDimensionComboBox)
        self.combinationTypeLabel.setBuddy(self.combinationTypeComboBox)
        self.combinationReferenceLabel.setBuddy(self.combinationReferenceComboBox)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(TskResultsPanelForm)

        self.detailsTabWidget.setCurrentIndex(0)
        self.combinationViewsTabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(TskResultsPanelForm)
    # setupUi

    def retranslateUi(self, TskResultsPanelForm):
        self.groupLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u8282\u70b9 / \u6279\u6b21", None))
        self.exportButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5bfc\u51fa XLSX", None))
        self.summaryLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u672a\u8fd0\u884c TSK \u98ce\u9669\u5206\u6790\u3002", None))
        self.summaryLabel.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u672a\u8fd0\u884c TSK \u98ce\u9669\u5206\u6790\u3002", None))
        self.summaryLabel.setProperty(u"modelSummaryFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u6a21\u578b\uff1a{model}{details}", None))
        self.summaryLabel.setProperty(u"logisticModelText", QCoreApplication.translate("TskResultsPanelForm", u"Logistic\uff08\u539f\u6709\uff09", None))
        self.summaryLabel.setProperty(u"linearHazardModelText", QCoreApplication.translate("TskResultsPanelForm", u"\u7ebf\u6027\u98ce\u9669\uff08\u51f8\uff09", None))
        self.summaryLabel.setProperty(u"typeOnlyModelSuffix", QCoreApplication.translate("TskResultsPanelForm", u" \u00b7 \u672a\u4f7f\u7528\u7279\u5f81\uff0c\u91c7\u7528\u57fa\u7840\u7c7b\u578b\u6a21\u578b", None))
        self.warningsLabel.setText("")
        self.warningsLabel.setProperty(u"summaryText", QCoreApplication.translate("TskResultsPanelForm", u"{count} \u6761\u5206\u6790\u63d0\u793a\uff1b\u60ac\u505c\u67e5\u770b\uff0c\u6216\u6253\u5f00\u201c\u7ec4\u5408\u5206\u6790 \u2192 \u5168\u90e8\u63d0\u793a\u201d\u3002", None))
        self.riskLegendLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6761\u5f62\uff1a\u5355\u5b9e\u4f8b P_fail \u00b7 \u8bef\u5dee\u7ebf\uff1a95% \u7f6e\u4fe1\u533a\u95f4\u3002\n"
"\u901a\u5e38\u4e3a\u8f6e\u5ed3\u4f3c\u7136\u8fd1\u4f3c\uff1b\u8fb9\u754c\u91c7\u7528\u9002\u7528\u7684\u7cbe\u786e\u65b9\u6cd5\u3002", None))
        self.referenceLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u53ef\u663e\u793a\u7684\u62df\u5408\u7ed3\u679c\u3002", None))
        self.referenceLabel.setProperty(u"typeOnlyText", QCoreApplication.translate("TskResultsPanelForm", u"\u7c7b\u578b\u6a21\u578b\uff1a\u540c\u4e00 TSK_ID \u7684\u5404\u5b9e\u4f8b\u5171\u4eab\u5f02\u5e38\u6982\u7387\u3002", None))
        self.referenceLabel.setProperty(u"featureText", QCoreApplication.translate("TskResultsPanelForm", u"\u7279\u5f81\u6a21\u578b\uff1a\u56fa\u5b9a\u6240\u6709\u6570\u503c\u7279\u5f81\u5728\u8be5\u7ec4\u8bad\u7ec3\u5747\u503c\uff0c\u6bd4\u8f83 TSK \u6761\u4ef6\u6982\u7387\u3002", None))
        self.referenceLabel.setProperty(u"categoricalText", QCoreApplication.translate("TskResultsPanelForm", u"\u7279\u5f81\u6a21\u578b\uff1a\u6570\u503c\u7279\u5f81\u53d6\u8bad\u7ec3\u5747\u503c\uff0c\u7c7b\u522b\u53d6 {categories}\uff0c\u6bd4\u8f83 TSK \u6761\u4ef6\u6982\u7387\uff1b\u4e0d\u662f\u6240\u6709\u5b9e\u4f8b\u7684\u5e73\u5747\u98ce\u9669\u3002", None))
        self.referenceLabel.setProperty(u"categoricalNoFitText", QCoreApplication.translate("TskResultsPanelForm", u"\u7279\u5f81\u6a21\u578b\uff1a\u6570\u503c\u7279\u5f81\u53d6\u8bad\u7ec3\u5747\u503c\u3001\u7c7b\u522b\u7279\u5f81\u53d6\u57fa\u51c6\u7c7b\u522b\uff1b\u672c\u7ec4\u5c1a\u65e0\u53ef\u7528\u62df\u5408\u7ed3\u679c\u3002", None))
        self.riskPlot.setProperty(u"axisLabel", QCoreApplication.translate("TskResultsPanelForm", u"P_fail(TSK_ID)\uff08%\uff09", None))
        self.riskPlot.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd0\u884c\u5206\u6790\u540e\u663e\u793a TSK \u6982\u7387\u4e0e\u533a\u95f4\u3002", None))
        self.riskPlot.setProperty(u"outsideDomainText", QCoreApplication.translate("TskResultsPanelForm", u"\u53c2\u8003\u6761\u4ef6\u4e0d\u9002\u7528", None))
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.riskTab), QCoreApplication.translate("TskResultsPanelForm", u"\u98ce\u9669\u56fe", None))
        self.chainLegendLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6bcf\u70b9\u4ee3\u8868\u4e00\u6761 Chain\uff1b\u5bf9\u89d2\u7ebf\u8868\u793a\u89c2\u5bdf\u4e0e\u9884\u6d4b\u4e00\u81f4\u3002\u6b8b\u5dee = \u89c2\u5bdf \u2212 \u9884\u6d4b\u3002", None))
        self.chainPlot.setProperty(u"xAxisLabel", QCoreApplication.translate("TskResultsPanelForm", u"\u9884\u6d4b Chain \u5f02\u5e38\u7387\uff08%\uff09", None))
        self.chainPlot.setProperty(u"yAxisLabel", QCoreApplication.translate("TskResultsPanelForm", u"\u89c2\u5bdf\u5f02\u5e38\u7387\uff08%\uff09", None))
        self.chainPlot.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd0\u884c\u5206\u6790\u540e\u663e\u793a Chain \u62df\u5408\u504f\u5dee\u3002", None))
        self.chainsTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskResultsPanelForm", u"Chain ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u6709\u6548\u6837\u54c1\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Fail", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Pass", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Missing", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u89c2\u5bdf\u6982\u7387", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u9884\u6d4b\u6982\u7387", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u6b8b\u5dee (pp)", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Deviance residual", None)])
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.chainFitTab), QCoreApplication.translate("TskResultsPanelForm", u"Chain \u62df\u5408", None))
        self.typesTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskResultsPanelForm", u"TSK ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u5355\u5b9e\u4f8b\u6982\u7387", None),
            QCoreApplication.translate("TskResultsPanelForm", u"95% \u4e0b\u754c", None),
            QCoreApplication.translate("TskResultsPanelForm", u"95% \u4e0a\u754c", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u53ef\u5355\u72ec\u8bc6\u522b", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u62df\u5408\u72b6\u6001", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u5b9e\u4f8b\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u65b9\u6cd5", None)])
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.riskDetailsTab), QCoreApplication.translate("TskResultsPanelForm", u"\u98ce\u9669\u660e\u7ec6", None))
        self.combinationConditionsLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u672a\u8ba1\u7b97\u7ec4\u5408\u7ed3\u679c\u3002", None))
        self.combinationConditionsLabel.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u672a\u8ba1\u7b97\u7ec4\u5408\u7ed3\u679c\u3002", None))
        self.combinationConditionsLabel.setProperty(u"formatText", QCoreApplication.translate("TskResultsPanelForm", u"\u5df2\u8ba1\u7b97\uff1a{dimension} \u00b7 \u5dee\u503c\u57fa\u51c6 {reference} \u00b7 \u56fa\u5b9a\u7c7b\u522b\uff1a{fixed} \u00b7 \u6570\u503c\u5747\u503c\uff1a{numeric}", None))
        self.combinationConditionsLabel.setProperty(u"noneText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0", None))
        self.combinationWarningsLabel.setText("")
        self.combinationWarningsLabel.setProperty(u"summaryText", QCoreApplication.translate("TskResultsPanelForm", u"{count} \u6761\u7ec4\u5408\u63d0\u793a\uff08\u60ac\u505c\u6216\u6253\u5f00\u201c\u5168\u90e8\u63d0\u793a\u201d\uff09\u3002", None))
        self.combinationHeatmapMetricComboBox.setItemText(0, QCoreApplication.translate("TskResultsPanelForm", u"\u6982\u7387\u70ed\u529b\u56fe", None))
        self.combinationHeatmapMetricComboBox.setItemText(1, QCoreApplication.translate("TskResultsPanelForm", u"\u652f\u6301\u5ea6\u70ed\u529b\u56fe\uff08\u6709\u6548\u5e03\u5c40\u5b9e\u4f8b\u6570\uff09", None))

        self.combinationHeatmapLegendLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u7070\u683c = \u4e0d\u53ef\u4f30\u8ba1\uff1b\u659c\u7eb9 = \u5916\u63a8\u6216\u65e0\u6709\u6548\u652f\u6301\u3002\u652f\u6301\u5ea6\u662f\u5e03\u5c40\u5b9e\u4f8b\u6570\uff0c\u4e0d\u662f\u72ec\u7acb\u6837\u672c\u91cf\u3002\u70b9\u51fb\u683c\u5b50\u67e5\u770b\u8be5 TSK \u7684\u7c7b\u522b\u5bf9\u6bd4\u3002", None))
        self.combinationHeatmap.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u70b9\u51fb\u201c\u8ba1\u7b97\u7ec4\u5408\u6982\u7387\u201d\u751f\u6210\u70ed\u529b\u56fe\u3002", None))
        self.combinationHeatmap.setProperty(u"tooltipFormat", QCoreApplication.translate("TskResultsPanelForm", u"{tsk_id} \u00b7 {level}\n"
"P_fail\uff1a{probability}\n"
"\u533a\u95f4\uff1a{interval}\n"
"\u652f\u6301\u72b6\u6001\uff1a{support}\n"
"\u5e03\u5c40\u5b9e\u4f8b\uff1a{layout} \u00b7 \u6709\u6548\u5b9e\u4f8b\uff1a{active}\n"
"\u6709\u6548\u94fe\uff1a{chains} \u00b7 \u94fe\u6d4b\u8bd5\u66b4\u9732\uff1a{exposure}", None))
        self.combinationViewsTabWidget.setTabText(self.combinationViewsTabWidget.indexOf(self.combinationHeatmapTab), QCoreApplication.translate("TskResultsPanelForm", u"\u70ed\u529b\u56fe", None))
        self.combinationCompareLegendLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u4e0a\u56fe\uff1a\u6761\u4ef6 P_fail \u4e0e 95% \u7f6e\u4fe1\u533a\u95f4\u3002\u4e0b\u56fe\uff1a\u76f8\u5bf9\u57fa\u51c6\u7c7b\u522b\u7684 \u0394p\uff08\u767e\u5206\u70b9\uff09\u4e0e\u5355\u72ec\u8ba1\u7b97\u7684\u5dee\u503c\u533a\u95f4\uff1b\u4e0d\u7531\u4e24\u6761\u6982\u7387\u533a\u95f4\u76f8\u51cf\u3002", None))
        self.combinationCompareLegendLabel.setProperty(u"formatText", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0a\u56fe\uff1a\u6761\u4ef6 P_fail \u4e0e {confidence} \u7f6e\u4fe1\u533a\u95f4\u3002\u4e0b\u56fe\uff1a\u76f8\u5bf9\u57fa\u51c6\u7c7b\u522b\u7684 \u0394p\uff08\u767e\u5206\u70b9\uff09\u4e0e\u5355\u72ec\u8ba1\u7b97\u7684\u5dee\u503c\u533a\u95f4\uff1b\u4e0d\u7531\u4e24\u6761\u6982\u7387\u533a\u95f4\u76f8\u51cf\u3002", None))
        self.combinationProbabilityPlot.setProperty(u"axisLabel", QCoreApplication.translate("TskResultsPanelForm", u"\u7c7b\u522b\u6761\u4ef6 P_fail\uff08%\uff09", None))
        self.combinationProbabilityPlot.setProperty(u"tooltipFormat", QCoreApplication.translate("TskResultsPanelForm", u"{tsk_id} \u00b7 {level}\n"
"P_fail\uff1a{probability}\n"
"{confidence} \u533a\u95f4\uff1a{lower} \u2013 {upper}\n"
"\u652f\u6301\u72b6\u6001\uff1a{support}\n"
"\u62df\u5408\u72b6\u6001\uff1a{status}", None))
        self.combinationProbabilityPlot.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u8ba1\u7b97\u540e\u9009\u62e9 TSK \u67e5\u770b\u7c7b\u522b\u6982\u7387\u3002", None))
        self.combinationProbabilityPlot.setProperty(u"outsideDomainText", QCoreApplication.translate("TskResultsPanelForm", u"\u53c2\u8003\u6761\u4ef6\u4e0d\u9002\u7528", None))
        self.combinationDifferencePlot.setProperty(u"axisLabel", QCoreApplication.translate("TskResultsPanelForm", u"\u76f8\u5bf9\u57fa\u51c6\u7c7b\u522b \u0394p\uff08\u767e\u5206\u70b9\uff09", None))
        self.combinationDifferencePlot.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u8ba1\u7b97\u540e\u663e\u793a\u5dee\u503c\u53ca\u5176\u7f6e\u4fe1\u533a\u95f4\u3002", None))
        self.combinationDifferencePlot.setProperty(u"unavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u5dee\u503c\u4e0d\u53ef\u4f30\u8ba1", None))
        self.combinationDifferencePlot.setProperty(u"tooltipFormat", QCoreApplication.translate("TskResultsPanelForm", u"{level}\n"
"\u0394p\uff1a{delta}\n"
"\u5dee\u503c\u533a\u95f4\uff1a{interval}\n"
"\u72b6\u6001\uff1a{status}", None))
        self.combinationViewsTabWidget.setTabText(self.combinationViewsTabWidget.indexOf(self.combinationCompareTab), QCoreApplication.translate("TskResultsPanelForm", u"\u7c7b\u522b\u5bf9\u6bd4", None))
        self.combinationTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskResultsPanelForm", u"TSK ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u7c7b\u522b", None),
            QCoreApplication.translate("TskResultsPanelForm", u"P_fail", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0b\u754c", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0a\u754c", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u0394p (pp)", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u0394p \u4e0b\u754c (pp)", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u0394p \u4e0a\u754c (pp)", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u652f\u6301\u72b6\u6001", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u5e03\u5c40\u5b9e\u4f8b\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u6709\u6548\u5b9e\u4f8b\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u6709\u6548\u94fe\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u94fe\u6d4b\u8bd5\u66b4\u9732", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u62df\u5408\u72b6\u6001", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u5dee\u503c\u72b6\u6001", None)])
        self.combinationViewsTabWidget.setTabText(self.combinationViewsTabWidget.indexOf(self.combinationDetailsTab), QCoreApplication.translate("TskResultsPanelForm", u"\u660e\u7ec6", None))
        self.combinationHintLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u9009\u62e9\u4e00\u4e2a\u7c7b\u522b\u7ef4\u5ea6\u9010\u9879\u6bd4\u8f83\uff0c\u5176\u4f59\u7c7b\u522b\u56fa\u5b9a\u4e3a\u6307\u5b9a\u503c\uff0c\u6570\u503c\u7279\u5f81\u4fdd\u6301\u8be5\u7ec4\u8bad\u7ec3\u5747\u503c\u3002\u4fee\u6539\u6761\u4ef6\u540e\u70b9\u51fb\u8ba1\u7b97\u3002", None))
        self.combinationDimensionLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6bd4\u8f83\u7ef4\u5ea6", None))
        self.combinationTypeLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"TSK \u8303\u56f4", None))
        self.combinationTypeComboBox.setProperty(u"allText", QCoreApplication.translate("TskResultsPanelForm", u"\u5168\u90e8 TSK", None))
        self.combinationReferenceLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5dee\u503c\u6bd4\u8f83\u57fa\u51c6", None))
        ___qtablewidgetitem = self.combinationFixedTableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5176\u4f59\u7c7b\u522b\u7ef4\u5ea6", None))
        ___qtablewidgetitem1 = self.combinationFixedTableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u56fa\u5b9a\u7c7b\u522b", None))
        self.combinationStatusLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u8bf7\u5148\u8fd0\u884c\u5305\u542b\u7c7b\u522b\u7279\u5f81\u7684 TSK \u5206\u6790\u3002", None))
        self.combinationStatusLabel.setProperty(u"noContextText", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u7ec4\u65e0\u7ec4\u5408\u9884\u6d4b\u6240\u9700\u7684\u62df\u5408\u4fe1\u606f\uff0c\u8bf7\u91cd\u65b0\u8fd0\u884c TSK \u5206\u6790\u3002", None))
        self.combinationStatusLabel.setProperty(u"noCategoriesText", QCoreApplication.translate("TskResultsPanelForm", u"\u8bf7\u5728 TSK \u5206\u6790\u4e2d\u9009\u62e9\u81f3\u5c11\u4e00\u4e2a\u7c7b\u522b\u7279\u5f81\u540e\u91cd\u65b0\u8fd0\u884c\u3002", None))
        self.combinationStatusLabel.setProperty(u"readyText", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u6b21 {count} \u4e2a\u7ec4\u5408\uff1b\u6700\u591a 200 \u4e2a\u3002", None))
        self.combinationStatusLabel.setProperty(u"limitText", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u6b21 {count} \u4e2a\u7ec4\u5408\u8d85\u8fc7 200 \u4e2a\uff0c\u8bf7\u9009\u62e9\u5355\u4e2a TSK \u6216\u66f4\u5c11\u7c7b\u522b\u7684\u7ef4\u5ea6\u3002", None))
        self.combinationStatusLabel.setProperty(u"busyText", QCoreApplication.translate("TskResultsPanelForm", u"\u6b63\u5728\u8ba1\u7b97\u7ec4\u5408\u6982\u7387\u4e0e\u5dee\u503c\u533a\u95f4\u2026", None))
        self.calculateCombinationButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u8ba1\u7b97\u7ec4\u5408\u6982\u7387", None))
        self.combinationViewsTabWidget.setTabText(self.combinationViewsTabWidget.indexOf(self.combinationSettingsTab), QCoreApplication.translate("TskResultsPanelForm", u"\u8ba1\u7b97\u6761\u4ef6", None))
        self.combinationWarningsTextEdit.setPlaceholderText(QCoreApplication.translate("TskResultsPanelForm", u"\u6682\u65e0\u5206\u6790\u63d0\u793a\u3002", None))
        self.combinationWarningsTextEdit.setProperty(u"groupHeading", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u7ec4\u5206\u6790\u63d0\u793a", None))
        self.combinationWarningsTextEdit.setProperty(u"viewHeading", QCoreApplication.translate("TskResultsPanelForm", u"\u5f53\u524d\u7ec4\u5408\u63d0\u793a", None))
        self.combinationWarningsTextEdit.setProperty(u"modelScopeText", QCoreApplication.translate("TskResultsPanelForm", u"\u7ec4\u5408\u9884\u6d4b\u6cbf\u7528\u5171\u4eab\u7c7b\u522b\u4e3b\u6548\u5e94\u6a21\u578b\uff0c\u672a\u62df\u5408\u7c7b\u522b\u95f4\u6216\u7c7b\u522b\u4e0e TSK \u7684\u4ea4\u4e92\u3002\u4e0d\u540c TSK \u7684\u6982\u7387\u5dee\u4e0d\u540c\uff0c\u4e0d\u8868\u793a\u5df2\u8bc6\u522b\u4ea4\u4e92\u4f5c\u7528\u3002", None))
        self.combinationViewsTabWidget.setTabText(self.combinationViewsTabWidget.indexOf(self.combinationWarningsTab), QCoreApplication.translate("TskResultsPanelForm", u"\u5168\u90e8\u63d0\u793a", None))
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.combinationTab), QCoreApplication.translate("TskResultsPanelForm", u"\u7ec4\u5408\u5206\u6790", None))
        self.topologyHintLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6bcf\u884c\u8868\u793a\u4e00\u4e2a\u7269\u7406\u5b9e\u4f8b\uff1b\u9644\u52a0\u7279\u5f81\u5217\u6765\u81ea\u6a21\u677f\u3002Chain \u5b8c\u6574\u8def\u5f84\u7528\u4e8e\u533a\u5206\u540c\u540d\u94fe\u8def\u3002", None))
        self.topologyTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskResultsPanelForm", u"CHAIN_ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"TSK_instance_ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"TSK_ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"X", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Y", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Chain \u5b8c\u6574\u8def\u5f84", None)])
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.topologyTab), QCoreApplication.translate("TskResultsPanelForm", u"\u5b9e\u4f8b\u7ec4\u6210", None))
        pass
    # retranslateUi

