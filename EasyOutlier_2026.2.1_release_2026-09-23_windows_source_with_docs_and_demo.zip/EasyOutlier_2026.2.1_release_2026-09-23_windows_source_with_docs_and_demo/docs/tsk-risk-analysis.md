# Independent TSK risk analysis

TSK Analysis is a separate workbench tab. It uses the paths in Setup and the current effective Fail rules from Analyze, including unsaved changes in the Analyze controls. You do not need to run Analyze first. TSK keeps its own data source, import selection, node/sample scope, batch grouping and XY/feature selection; it does not provide a separate Fail-method or classification-pool selector. Running Analyze does not run TSK estimation, and TSK Results does not replace existing Analyze results.

完整中文推导、置信区间解释及可复现算例见 [TSK 数学原理（LaTeX Markdown）](tsk-risk-mathematical-principles.md)。适合有高等数学基础、尚未系统学习概率统计的读者。

## Try the hypothetical example

1. In Setup, select `examples/tsk_risk_demo/template.xlsx` (or `template.json`) and `examples/tsk_risk_demo/data.csv` as the input.
2. In Analyze, use the demo's Modified Z-score method and threshold 3.5. Then open **TSK Analysis**, choose **Input · Setup 中的输入文件**, and click **运行 TSK 风险分析**. No prior Analyze run, Golden file or database import is needed for this example.
3. Select T0 or T1 in **TSK Results**. Risk bars show single-instance probabilities; whiskers show 95% intervals. Chain fit compares observed and predicted proportions; the table reports residuals in percentage points.
4. Optionally enable XY or select numeric/categorical attributes and choose the feature model: **Logistic（原有）** or **线性风险（凸）**. Run again after changing the model. Feature-model type risks refer to numeric attributes at their training-layout means and categorical attributes at their reference levels, not an average of the probabilities across the type's actual instances. The existing demo uses numeric attributes only.
5. Export XLSX for type estimates, bounds, chain counts, sample outcomes, topology, diagnostics and the configuration snapshot. Long JSON metadata is split into ordered parts to avoid Excel truncation.

The demo has 12 chains, three TSK types, 400 samples and two nodes. Its topology and values are invented and clearly labelled. The bundled ordinary template contains disabled EXAMPLE placeholders; replace them with real topology before enabling TSK analysis.

## Original batches and parent batches

Choose an existing row dimension such as `lot_id` as the batch field. It must be different from the reliability-node dimension. This field also preserves original-batch identity in mode `none`, so the same sample number in two lots remains two observations. Batch settings determine which final counts are fitted together. They do not rename source data, change the template's sample identity, replace batch values used to match Golden references, or change the shared Fail rules.

| Batch mode | Fit groups |
| --- | --- |
| `none` — no batch split; combine selected lots | Sum final counts from all selected original batches within each node, then fit one common model. |
| `separate` — original batches | Fit each original batch separately within each node. |
| `parent` — parent batches | Map original batches to parent IDs, sum their final chain counts within each node, then run maximum likelihood again. |

The batch controls are the only way to split TSK fits beyond the reliability node. There is no additional temperature, voltage or other condition-grouping control. Legacy `group_by_dimensions` values in templates or saved TSK settings are ignored.

For a runnable example, use [batch_data.csv](../examples/tsk_risk_demo/batch_data.csv) with the same demo template. It contains L001 with 100 samples, L002 with 150, and L003 with 150, at both T0 and T1. Sample numbers restart within each batch. The run settings are also provided in [batch_settings.json](../examples/tsk_risk_demo/batch_settings.json), and expected counts in [batch_expected_counts.csv](../examples/tsk_risk_demo/batch_expected_counts.csv).

To combine L001 and L002 while keeping L003 separate:

1. Select the intended data/imports, nodes and samples in **TSK Analysis**.
2. Select original-batch mode with `lot_id` as the batch field to inspect L001, L002 and L003 separately.
3. To fit parent batches, choose parent-batch mode and enter `L001 → M001`, `L002 → M001`, `L003 → M002`. Every original batch present in the selected analysis scope needs a nonempty parent ID; an unmapped batch is not silently dropped.
4. Check the shared Fail rules in Analyze, run TSK analysis, and inspect **Batch Counts** in the export alongside the parent results. Risk results retain `parent_batch_id` and `source_batches` for traceability.

For this complete-data example, separate mode yields six groups. Parent mode yields four groups: M001 at each node has 250 effective samples per chain, and M002 has 150. Mode `none` combines the three selected batches and yields two node groups, each with 400 effective samples per chain. These files illustrate aggregation and repeated sample numbers across batches; they do not introduce or prove a separate batch-effect model.

The Fail method, empty-value handling, sample identity and merge rules/order come from Analyze's current effective report settings. Analyze's current default Z-score threshold is applied as the run-wide override; old per-item Z-score overrides do not supersede it. Golden references use the shared file in Setup. Modified Z-scores follow Analyze's logical-measurement pooling across the whole selected data scope; they are not recalculated separately for each original batch, parent batch or final fit group. Batch mode changes the fit groups, not the classification rule. Legacy `fail_method` and `classification_pool` values saved inside TSK settings are ignored.

Shared rules do not mean reusing labels from the last Analyze result. TSK recomputes the same classifier for its selected data. Different import, node or sample selections can change the Z-score pool and therefore the labels.

Aggregation happens **after each original batch has merged its repeats and resolved Pass / Fail / Missing**. Sample `S01` from L001 and sample `S01` from L002 remain different observations. Parent mode combines batches with the same parent ID; mode `none` combines all selected lots within each node. For each chain, sum Fail and Pass counts to obtain the effective denominator; sum Missing separately and exclude it from that denominator. The engine fits these summed counts, never an average of fitted TSK probabilities.

Pooling assumes a common TSK probability vector within the parent/node group, or common type and feature coefficients when features are enabled, using the same chain topology. Unequal batches contribute according to their valid counts in the binomial likelihood. A larger batch therefore contributes more information than a smaller batch. The mapping itself neither verifies this common-risk assumption nor removes differences between heterogeneous batches. The mathematical derivation and an unequal-size example are in [§6.6 of the mathematical guide](tsk-risk-mathematical-principles.md#batch-likelihood).

The corresponding runtime settings are:

```python
settings = {
    "batch_mode": "parent",  # none | separate | parent
    "batch_dimension": "lot_id",
    "batch_mapping": {"L001": "M001", "L002": "M001", "L003": "M002"},
}
```

These controls are TSK run settings. Calls without `batch_mode` use `none`: all selected batches are fitted together for each node. Every batch mode uses the shared Analyze classification rules and whole-scope Z-score pool.

## Template

The JSON `tsk_analysis` section corresponds to the Excel `tsk_analysis` settings sheet and `tsk_instances` table. Each instance row contains `CHAIN_ID`, `TSK_instance_ID`, `TSK_ID`, numeric `X`/`Y`, an optional explicit `CHAIN_KEY`, and declared numeric or categorical feature columns. `CHAIN_KEY` is a JSON array containing the complete column header path through the Chain level. A unique Chain name can be resolved automatically; ambiguous names require explicit paths and distinct external IDs.

Repeated TSK types are counted, not deduplicated. An instance ID must be unique within its chain. Coordinates must use a common coordinate system and unit. Density values require a consistent fraction/percentage convention and measurement window. The optional settings are `enabled`, `use_xy`, `coordinate_unit`, `feature_columns`, `categorical_feature_columns` and `feature_model`. `feature_model` accepts `logistic` (the default, including old templates) or `linear_hazard`. The GUI/run settings can override the template choice; settings, fitted diagnostics and exports retain the choice. A legacy TSK `group_by_dimensions` field no longer changes the analysis.

### Numeric and categorical attributes

`feature_columns` lists all optional attributes. `categorical_feature_columns` explicitly identifies the categorical subset; all other listed attributes remain numeric. This preserves existing numeric templates and avoids guessing a model from a column's formatting.

| Bump-size input | Declaration | Model interpretation |
| --- | --- | --- |
| `large`, `small` or `medium`; material labels such as `copper`, `aluminum` | Explicitly categorical | Text labels with no numeric magnitude or equal-spacing assumption. |
| `40`, `60`, `80` | Numeric, not in `categorical_feature_columns` | A continuous size measurement. Equal size changes have equal effects on log-odds in Logistic, or negative log-survival in linear risk, holding other inputs fixed. |
| `40`, `60`, `80` | Explicitly categorical | Three levels with separately estimated contrasts; no size ordering or equal-spacing assumption. |
| `40um`, `60um`, `80um` or `M`, `L` | Explicitly categorical | Category labels. Text is not automatically parsed as a physical size or converted into units. |

For example, these are partial template settings, not a replacement for the topology:

```json
{
  "feature_columns": ["metal_A_density", "bump_size", "material"],
  "categorical_feature_columns": ["bump_size", "material"]
}
```

An instance's `features` can then contain `{"metal_A_density": 0.35, "bump_size": "large", "material": "copper"}`. Other instances can use `"small"` and `"aluminum"`; these labels do not need numeric substitutes. In Excel, declare both setting rows in `tsk_analysis`, and use the corresponding attribute columns in `tsk_instances`. X/Y are always numeric. Missing or invalid selected category values are not silently treated as a baseline category.

Category labels are trimmed nonempty text or finite numbers. Numeric `40` and `40.0` share the label `"40"`; text `"40.0"` remains a different text label. Boolean, null and nonfinite values are rejected. Use a consistent label convention across the entire template.

The runtime `feature_names` selection can contain both kinds of attribute. The service derives the selected categorical subset from the template and passes it as `categorical_feature_names` to the model. Selecting a category does not split observations into additional fit groups: grouping remains node plus the selected lot/parent mode.

## Observation and missing-data rules

- One observation is a unique sample at a node for one chain. Repeats, sites and measurement columns follow Analyze's current effective merge order and any/all definitions; they do not increase the number of independent dies.
- Nodes are always fitted separately. The selected original-batch field preserves batch boundaries while merging repeats; only completed counts are combined for parent fits or for the all-lot fit in mode `none`. Temperature, voltage, site and other row fields do not create additional TSK fit groups; their measurements follow the shared merge rules.
- Fail and Pass use Analyze's current effective rules, including unsaved UI values. TSK's data scope, batch mode and XY/features remain independently selected.
- With `empty_as_fail=True`, an empty numeric cell is directly classified as Fail. With `empty_as_fail=False`, the empty leaf is skipped: it does not take part in any/all merging and does not propagate an unknown state. A known sample/node/chain with no remaining leaf at all is reported as Missing and excluded from the valid denominator.
- For nonempty measurements, Modified Z-score pools with fewer than three values or zero MAD have an effective score of 0 under Analyze's classifier; missing Golden matches produce `golden_fail=False`. Z-score/Golden AND and OR use ordinary Boolean logic. These cases do not become Missing simply because the statistical reference is uninformative or absent.
- Original input files preserve identified all-empty sample rows. Measurement-only databases cannot recover rows with no numeric measurements at import; the result explicitly warns about that exposure limitation.

## Model and intervals

### Choosing a feature model

Both feature modes use standardized numeric columns and reference-category indicators with effects shared across TSK types. With no selected numeric/XY/category features, both choices use the existing convex type-only model.

| Mode | Instance probability | Optimization |
| --- | --- | --- |
| `logistic` — original/default | `p = sigmoid(D θ)` | Three initial points with local optimization; global optimality is not guaranteed. |
| `linear_hazard` — convex linear risk | `h = D θ >= 0`, `p = 1 - exp(-h)` | Convex binomial likelihood with a nonnegative-hazard constraint for every fitted instance. |

Linear risk changes how features affect probability; it is not an equivalent reparameterization of the Logistic feature model. Its coefficients describe additive changes in negative log-survival, not odds ratios. The solver checks feasibility and constrained stationarity. Convexity does not ensure unique parameters, finite maximum-likelihood estimates, or a good match to observed chain rates. Inspect identifiability, intervals and Chain Fit for either mode.

The linear constraints cover the instances on fitted chains. A type's numeric-mean/reference-category point, or a requested unobserved category combination, can lie outside that domain: a negative predicted hazard is withheld (`reference_outside_domain` or `outside_model_domain`), not clamped to a zero probability. Linear-risk intervals profile the hazard contrast under the same instance constraints. Normal-approximation difference intervals are withheld at active hazard boundaries; self-comparison remains exactly zero.

### Likelihood and uncertainty

For each node and configured original or parent batch, or all selected batches together in mode `none`, the type-only model uses `q_i = 1 - product_t((1-p_t)**C_it)`, where C is the instance-count matrix. Nonnegative log-survival parameters are fitted by binomial maximum likelihood. Rank and realized-likelihood checks suppress unidentifiable type estimates.

In the original Logistic feature mode, each instance uses a type intercept, centered/standardized numeric effects, and categorical indicator effects on the logit scale. A category with L levels uses L−1 uncentered indicator columns in both modes. Levels are collected from the complete template topology and sorted consistently; the first is the reference. Its indicators are all zero. The choice is a coding reference, not a claim that this level is smallest, safest or most common. Instance survival probabilities are then multiplied within each chain. Logistic uses multiple starts without a global optimality guarantee; linear risk uses the constrained convex objective described above. Neither mode automatically adds a nonlinear spatial surface.

Type bars and their profile intervals describe the conditional probability at numeric means and every category's reference level. They do not describe average risk across category frequencies or the type's actual instances. Diagnostics include `categorical_features`, with levels and references, alongside numeric `feature_scaling`. The same template retains category references across batches; a batch missing a level receives a diagnostic instead of silently changing its reference. Missing support or a category perfectly tied to `TSK_ID` can make reference type probabilities unidentifiable. Encoding categories does not remove these data limitations or establish independence between physical instances.

Intervals are profile-likelihood approximations, with appropriate exact transformations or bounds in supported boundary cases. Parent fits recompute intervals from their summed-count likelihood; the intervals are not averaged from the original batches and do not estimate between-batch variability. Each type row records its interval method. Nonconvergence, boundary estimates and unavailable intervals are explicit. A probability of zero is not evidence that true risk is exactly zero.

The inference assumes that a chain's Fail event is the OR of its instance failures, with conditional independence. Multi-instance accumulated drift or correlated defects can violate that assumption. Intervals currently assume independent chain observations; correlations between chains on the same die or between repeated nodes are not corrected by a cluster bootstrap. The data and paired sample outcomes remain available for follow-up validation. Fits estimate risk under these assumptions, not a directly observed root cause.

## Combination probabilities and comparisons

The combination view answers questions such as “For TSK A, what is the predicted risk with a small bump and copper material?” It uses the same fitted main-effects model. It does not fit a separate model for every category combination, add interaction terms, or change the shared Analyze Fail rules or lot groups.

After fitting with the desired categorical features:

1. Select the fitted node/batch group in **TSK Results**, open **组合分析**, and select its **计算条件** page. With no calculated result, this page opens by default.
2. Choose a categorical feature for the horizontal axis, such as `bump_size`, and fix each other selected category, such as `material=copper`.
3. Show all TSKs or one TSK, and select the horizontal-axis level used as the comparison baseline.
4. Click **计算组合概率**. The probability/profile-interval calculation runs in the background and automatically opens the populated **热力图** page when complete. Click a heatmap cell to inspect its TSK in **类别对比**; **明细** retains the estimates and support table, and **全部提示** shows the full scrollable warnings. Each query is limited to 200 cells; return to **计算条件**, select one TSK and run separate queries when needed.

Numeric features, including X/Y, are held at their fitted group means. Each cell reports a single-instance conditional probability for its TSK and category combination, together with a 95% profile-likelihood interval. The comparison reports `delta_probability = probability - baseline_probability` for the same TSK and fixed other categories, with a covariance-aware, joint-information delta-method interval. The baseline selected here is for comparison only: it does not change the template's coding reference or refit the main model.

Each combination has both a statistical estimation status and a separate support status:

| Support field/status | Meaning |
| --- | --- |
| `layout_instance_count` | Matching TSK/category instances in the complete template topology. |
| `active_instance_count` | Matching instances on chains with valid tests in the fitted group. |
| `chain_count` | Distinct validly tested chains containing those matching instances. |
| `chain_test_exposure` | Sum of valid tested counts over those distinct chains, counting each chain once. This is not a count of independent samples or observed instance outcomes. |
| `observed` | At least one matching layout instance belongs to an actively tested chain. Its individual Fail outcome is still latent; the risk is inferred from chain data. |
| `no_active_support` | Matching layout exists, but none of its chains has valid tests in this fitted group. |
| `extrapolated` | The requested TSK/category combination does not occur in the template layout. An estimable result is a model extrapolation. |

Support matching uses the TSK and all selected categories; it does not assert that any actual instance lies at the numeric mean values. Support and identifiability are different questions. A combination can be estimable through shared effects without direct matching layout, and a supported combination can still be statistically unidentifiable. Unavailable probabilities or intervals remain blank/null, never zero. The engine checks the combination contrast itself, so it can retain an identifiable prediction even when individual coefficients cannot be separated.

Probability intervals are profile-likelihood approximations. Difference intervals, when available, use the joint expected information matrix of the same fit and include covariance between both predictions; they are not obtained by subtracting probability-interval endpoints. Linear-risk fits with active hazard boundaries withhold the normal-approximation difference intervals. Intervals are pointwise, not simultaneous coverage for the whole heatmap. Heatmap intensity is relative to the current view; compare probability values and intervals across queries rather than color strength alone. Large differences between probability-scale deltas across TSKs do not establish interactions: a shared category effect on either model's parameter scale can produce different absolute probability changes at different baseline risks.

Completed queries are cached with their settings, saved with database workspace state and included in XLSX export. Each result belongs to its serializable fitted-model snapshot, allowing several comparisons to be retained without changing the underlying fit. Missing or unsupported legacy model snapshots require a fresh analysis before combination predictions can be computed.

The separate [text-category demo](../examples/tsk_risk_demo/README.md#文本类别与组合预测的独立示例) provides [a template](../examples/tsk_risk_demo/categories/template.xlsx) and [input data](../examples/tsk_risk_demo/categories/data.csv) for `large/small` bumps and `aluminum/copper` materials. It deliberately omits `TSK_C + small + copper` from the layout so an estimable extrapolation can be distinguished from directly supported combinations. The original numeric demo remains unchanged.

## Runtime and development

NumPy and SciPy are declared project dependencies. Install through the existing `pip install -e .` setup. The UI uses PySide6/QPainter and adds no browser/chart runtime. All controls and layouts are defined in `.ui` and checked-in generated modules.

Automated coverage includes known-risk recovery, repeated instances, identifiability, zero/all-failure boundaries, feature scaling, JSON/XLSX round trips, shared Analyze classification and empty-value handling, node/batch separation, independent execution, persistence and export. Native macOS Cocoa geometry and horizontal expansion are checked separately. Windows execution and frozen distributions require validation on Windows; this change does not claim a newly tested Windows executable.
