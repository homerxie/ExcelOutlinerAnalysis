from __future__ import annotations

from excel_data_analysis.gui.app import launch


if __name__ == "__main__":
    launch()
