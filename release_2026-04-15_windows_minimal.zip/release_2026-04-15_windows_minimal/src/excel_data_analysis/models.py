from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class RowDimensionSource:
    column: str
    split_delimiters: list[str] = field(default_factory=list)
    split_position: int | None = None
    split_position_by_column: str | None = None
    split_position_map: dict[str, int] = field(default_factory=dict)
    skip_empty_parts: bool = False


@dataclass(slots=True)
class RowDimension:
    name: str
    sources: list[RowDimensionSource]
    priority: int
    optional: bool = False
    display_name: str | None = None
    default_value: str | None = None


@dataclass(slots=True)
class AnalysisColumn:
    name: str
    header_values: list[str] = field(default_factory=list)
    column_order: int | None = None


@dataclass(slots=True)
class GoldenRuleConfig:
    outlier_golden_method: str = "relative"
    relative_limit: float | None = 0.2
    sigma_multiplier: float | None = 3.0
    absolute_lower_bound: float | None = None
    absolute_upper_bound: float | None = None
    overwrite_min: float | None = None
    overwrite_max: float | None = None


@dataclass(slots=True)
class GoldenAllowedRange:
    lower_bound: float
    upper_bound: float


@dataclass(slots=True)
class ColumnHeaderLevel:
    name: str
    priority: int


@dataclass(slots=True)
class AnalysisGroup:
    id: str
    display_name: str
    columns: list[AnalysisColumn]
    analysis_mode: str
    unit: str | None = None
    outlier_golden_method: str | None = None
    golden_relative_limit: float | None = None
    golden_sigma_multiplier: float | None = None
    golden_absolute_lower_bound: float | None = None
    golden_absolute_upper_bound: float | None = None
    golden_overwrite_min: float | None = None
    golden_overwrite_max: float | None = None


@dataclass(slots=True)
class ThresholdConfig:
    default: float
    overrides: dict[str, float] = field(default_factory=dict)


@dataclass(slots=True)
class GoldenReferenceDefaults:
    reference_dimensions: list[str] = field(default_factory=list)
    filters: dict[str, str] = field(default_factory=dict)
    center_method: str = "mean"
    outlier_golden_method: str = "relative"
    relative_limit: float | None = 0.2
    sigma_multiplier: float | None = 3.0
    absolute_lower_bound: float | None = None
    absolute_upper_bound: float | None = None
    overwrite_min: float | None = None
    overwrite_max: float | None = None


@dataclass(slots=True)
class NumericCleanupConfig:
    enabled: bool = False
    mode: str = "all_non_numeric"
    characters: list[str] = field(default_factory=list)


@dataclass(slots=True)
class OutlierRatioStatConfig:
    id: str
    display_name: str | None = None
    group_by_dimension: str = "reliability_node"
    group_by_dimensions: list[str] = field(default_factory=list)
    numerator: str = "new_outlier_samples"
    group_ids: list[str] = field(default_factory=list)
    group_display_names: list[str] = field(default_factory=list)
    test_types: list[str] = field(default_factory=list)
    chain_names: list[str] = field(default_factory=list)
    column_names: list[str] = field(default_factory=list)
    units: list[str] = field(default_factory=list)
    chains: list[str] = field(default_factory=list)
    raw_columns: list[str] = field(default_factory=list)
    logical_metrics: list[str] = field(default_factory=list)


@dataclass(slots=True)
class AnalysisColumnFilterConfig:
    include: dict[str, list[str]] = field(default_factory=dict)
    exclude: dict[str, list[str]] = field(default_factory=dict)


@dataclass(slots=True)
class AnalysisDimensionFilterConfig:
    include: dict[str, list[str]] = field(default_factory=dict)
    exclude: dict[str, list[str]] = field(default_factory=dict)


@dataclass(slots=True)
class ReportConfig:
    zscore_thresholds: ThresholdConfig = field(
        default_factory=lambda: ThresholdConfig(default=3.5)
    )
    node_order: list[str] = field(default_factory=list)
    node_orders: list[list[str]] = field(default_factory=list)
    sample_dimension_names: list[str] = field(default_factory=list)
    outlier_fail_method: str = "modified_z_score"
    outlier_merged_test_fail_rule: str = "any_fail"
    outlier_test_group_fail_rule: str = "any_fail"
    outlier_merged_sample_fail_rule: str = "any_fail"
    outlier_node_fail_rule: str = "any_fail"
    outlier_row_merge_max_dimension: str | None = None
    outlier_test_merge_max_level: str | None = None
    outlier_merge_order: str = (
        "column merge -> column group -> row merge -> row node"
    )
    analysis_dimension_filters: AnalysisDimensionFilterConfig = field(
        default_factory=AnalysisDimensionFilterConfig
    )
    analysis_column_filters: AnalysisColumnFilterConfig = field(
        default_factory=AnalysisColumnFilterConfig
    )
    outlier_ratio_stats: list[OutlierRatioStatConfig] = field(default_factory=list)


@dataclass(slots=True)
class TemplateConfig:
    name: str
    test_data_header_row: int = 0
    row_header_row: int = 0
    test_data_start_column: int | None = None
    unit_row: int | None = None
    test_data_start_row: int | None = None
    column_header_levels: list[ColumnHeaderLevel] = field(default_factory=list)
    numeric_cleanup: NumericCleanupConfig = field(default_factory=NumericCleanupConfig)
    row_dimensions: list[RowDimension] = field(default_factory=list)
    analysis_groups: list[AnalysisGroup] = field(default_factory=list)
    golden_reference_defaults: GoldenReferenceDefaults = field(
        default_factory=GoldenReferenceDefaults
    )
    report: ReportConfig = field(default_factory=ReportConfig)


@dataclass(slots=True)
class LoadedTable:
    headers: list[str]
    rows: list[dict[str, Any]]
    units: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class MeasurementRecord:
    dataset_id: str
    source_file: str
    row_number: int
    logical_metric: str
    group_id: str
    group_display_name: str
    presentation_group: str | None
    raw_column: str
    value: float
    dimensions: dict[str, str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "MeasurementRecord":
        return cls(**payload)


@dataclass(slots=True)
class GoldenMetricRange:
    reference_key: dict[str, str]
    logical_metric: str
    sample_size: int
    center: float
    stdev: float
    lower_bound: float | None
    upper_bound: float | None
    outlier_golden_method: str
    relative_limit: float | None = None
    sigma_multiplier: float | None = None
    absolute_lower_bound: float | None = None
    absolute_upper_bound: float | None = None
    overwrite_min: float | None = None
    overwrite_max: float | None = None
    allowed_ranges: list[GoldenAllowedRange] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "GoldenMetricRange":
        payload = dict(payload)
        payload["allowed_ranges"] = [
            item if isinstance(item, GoldenAllowedRange) else GoldenAllowedRange(**item)
            for item in payload.get("allowed_ranges", [])
        ]
        return cls(**payload)


@dataclass(slots=True)
class GoldenReference:
    name: str
    reference_dimensions: list[str]
    filters: dict[str, str]
    outlier_golden_method: str
    relative_limit: float | None
    sigma_multiplier: float | None
    absolute_lower_bound: float | None
    absolute_upper_bound: float | None
    overwrite_min: float | None
    overwrite_max: float | None
    metrics: list[GoldenMetricRange]
    center_method: str = "mean"
    group_rule_overrides: dict[str, GoldenRuleConfig] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "reference_dimensions": list(self.reference_dimensions),
            "filters": dict(self.filters),
            "default_rule": {
                "outlier_golden_method": self.outlier_golden_method,
                "relative_limit": self.relative_limit,
                "sigma_multiplier": self.sigma_multiplier,
                "absolute_lower_bound": self.absolute_lower_bound,
                "absolute_upper_bound": self.absolute_upper_bound,
                "overwrite_min": self.overwrite_min,
                "overwrite_max": self.overwrite_max,
            },
            "metrics": [item.to_dict() for item in self.metrics],
            "center_method": self.center_method,
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "GoldenReference":
        payload = dict(payload)
        default_rule = payload.pop("default_rule", None)
        if default_rule is not None:
            payload.setdefault("outlier_golden_method", default_rule.get("outlier_golden_method"))
            payload.setdefault("relative_limit", default_rule.get("relative_limit"))
            payload.setdefault("sigma_multiplier", default_rule.get("sigma_multiplier"))
            payload.setdefault("absolute_lower_bound", default_rule.get("absolute_lower_bound"))
            payload.setdefault("absolute_upper_bound", default_rule.get("absolute_upper_bound"))
            payload.setdefault("overwrite_min", default_rule.get("overwrite_min"))
            payload.setdefault("overwrite_max", default_rule.get("overwrite_max"))
        payload["metrics"] = [
            GoldenMetricRange.from_dict(item) for item in payload.get("metrics", [])
        ]
        payload.setdefault("center_method", "mean")
        payload["group_rule_overrides"] = {
            key: value if isinstance(value, GoldenRuleConfig) else GoldenRuleConfig(**value)
            for key, value in payload.get("group_rule_overrides", {}).items()
        }
        return cls(**payload)


@dataclass(slots=True)
class AnomalyResult:
    method: str
    dataset_id: str
    source_file: str
    row_number: int
    logical_metric: str
    raw_column: str
    value: float
    dimensions: dict[str, str]
    lower_bound: float | None = None
    upper_bound: float | None = None
    center: float | None = None
    stdev: float | None = None
    score: float | None = None
    outlier_golden_method: str | None = None
    relative_limit: float | None = None
    sigma_multiplier: float | None = None
    absolute_lower_bound: float | None = None
    absolute_upper_bound: float | None = None
    overwrite_min: float | None = None
    overwrite_max: float | None = None
    allowed_ranges: list[GoldenAllowedRange] = field(default_factory=list)
    reference_key: dict[str, str] | None = None
    reason: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
