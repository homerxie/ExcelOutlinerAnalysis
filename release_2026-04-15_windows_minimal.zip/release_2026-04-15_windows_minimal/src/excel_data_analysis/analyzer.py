from __future__ import annotations

from collections import defaultdict
from statistics import mean, median, pstdev

from .golden_rules import (
    compute_outlier_golden_allowed_ranges,
    compute_outlier_golden_display_bounds,
    evaluate_outlier_golden_rule,
    validate_golden_rule_config,
)
from .models import (
    AnomalyResult,
    GoldenMetricRange,
    GoldenReference,
    GoldenRuleConfig,
    MeasurementRecord,
)


def build_golden_reference(
    name: str,
    measurements: list[MeasurementRecord],
    reference_dimensions: list[str],
    filters: dict[str, str] | None = None,
    center_method: str = "mean",
    outlier_golden_method: str = "relative",
    relative_limit: float | None = 0.2,
    sigma_multiplier: float | None = 3.0,
    absolute_lower_bound: float | None = None,
    absolute_upper_bound: float | None = None,
    overwrite_min: float | None = None,
    overwrite_max: float | None = None,
    group_rule_overrides: dict[str, GoldenRuleConfig] | None = None,
) -> GoldenReference:
    filters = filters or {}
    if center_method not in {"mean", "median"}:
        raise ValueError(f"Unsupported center_method: {center_method}")
    normalized_default_method = validate_golden_rule_config(
        "Global golden rule",
        outlier_golden_method,
        relative_limit,
        sigma_multiplier,
        absolute_lower_bound,
        absolute_upper_bound,
        overwrite_min,
        overwrite_max,
    )
    grouped: dict[tuple[tuple[str, str], str, str], list[float]] = defaultdict(list)

    for record in measurements:
        if not _match_dimensions(record.dimensions, filters):
            continue
        reference_key = tuple(
            (dimension, record.dimensions.get(dimension, ""))
            for dimension in reference_dimensions
        )
        grouped[(reference_key, record.logical_metric, record.group_id)].append(record.value)

    metrics: list[GoldenMetricRange] = []
    default_rule = GoldenRuleConfig(
        outlier_golden_method=normalized_default_method,
        relative_limit=relative_limit,
        sigma_multiplier=sigma_multiplier,
        absolute_lower_bound=absolute_lower_bound,
        absolute_upper_bound=absolute_upper_bound,
        overwrite_min=overwrite_min,
        overwrite_max=overwrite_max,
    )
    for (reference_key, logical_metric, group_id), values in grouped.items():
        center = _resolve_center(values, center_method)
        stdev = pstdev(values, mu=center) if len(values) > 1 else 0.0
        rule = _resolve_group_rule(group_id, default_rule, group_rule_overrides or {})
        allowed_ranges = compute_outlier_golden_allowed_ranges(
            center=center,
            stdev=stdev,
            outlier_golden_method=rule.outlier_golden_method,
            relative_limit=rule.relative_limit,
            sigma_multiplier=rule.sigma_multiplier,
            absolute_lower_bound=rule.absolute_lower_bound,
            absolute_upper_bound=rule.absolute_upper_bound,
            overwrite_min=rule.overwrite_min,
            overwrite_max=rule.overwrite_max,
        )
        lower_bound, upper_bound = compute_outlier_golden_display_bounds(
            center=center,
            stdev=stdev,
            outlier_golden_method=rule.outlier_golden_method,
            relative_limit=rule.relative_limit,
            sigma_multiplier=rule.sigma_multiplier,
            absolute_lower_bound=rule.absolute_lower_bound,
            absolute_upper_bound=rule.absolute_upper_bound,
            overwrite_min=rule.overwrite_min,
            overwrite_max=rule.overwrite_max,
        )
        metrics.append(
            GoldenMetricRange(
                reference_key=dict(reference_key),
                logical_metric=logical_metric,
                sample_size=len(values),
                center=center,
                stdev=stdev,
                lower_bound=lower_bound,
                upper_bound=upper_bound,
                outlier_golden_method=rule.outlier_golden_method,
                relative_limit=rule.relative_limit,
                sigma_multiplier=rule.sigma_multiplier,
                absolute_lower_bound=rule.absolute_lower_bound,
                absolute_upper_bound=rule.absolute_upper_bound,
                overwrite_min=rule.overwrite_min,
                overwrite_max=rule.overwrite_max,
                allowed_ranges=allowed_ranges,
            )
        )

    return GoldenReference(
        name=name,
        reference_dimensions=reference_dimensions,
        filters=filters,
        outlier_golden_method=normalized_default_method,
        relative_limit=relative_limit,
        sigma_multiplier=sigma_multiplier,
        absolute_lower_bound=absolute_lower_bound,
        absolute_upper_bound=absolute_upper_bound,
        overwrite_min=overwrite_min,
        overwrite_max=overwrite_max,
        metrics=sorted(
            metrics,
            key=lambda item: (
                tuple(sorted(item.reference_key.items())),
                item.logical_metric,
            ),
        ),
        center_method=center_method,
        group_rule_overrides={
            group_id: _resolve_group_rule(group_id, default_rule, group_rule_overrides or {})
            for group_id in sorted((group_rule_overrides or {}).keys())
        },
    )


def detect_against_golden(
    measurements: list[MeasurementRecord],
    reference: GoldenReference,
) -> list[AnomalyResult]:
    evaluations = evaluate_against_golden(measurements, reference)
    return [item for item in evaluations if item.reason]


def evaluate_against_golden(
    measurements: list[MeasurementRecord],
    reference: GoldenReference,
) -> list[AnomalyResult]:
    index = _build_golden_index(reference)

    evaluations: list[AnomalyResult] = []
    for record in measurements:
        reference_key = tuple(
            (dimension, record.dimensions.get(dimension, ""))
            for dimension in reference.reference_dimensions
        )
        metric = index.get((reference_key, record.logical_metric))
        if metric is None:
            continue
        is_within = evaluate_outlier_golden_rule(
            value=record.value,
            center=metric.center,
            stdev=metric.stdev,
            outlier_golden_method=metric.outlier_golden_method,
            relative_limit=metric.relative_limit,
            sigma_multiplier=metric.sigma_multiplier,
            absolute_lower_bound=metric.absolute_lower_bound,
            absolute_upper_bound=metric.absolute_upper_bound,
            overwrite_min=metric.overwrite_min,
            overwrite_max=metric.overwrite_max,
        )
        evaluations.append(
            AnomalyResult(
                method="golden_reference",
                dataset_id=record.dataset_id,
                source_file=record.source_file,
                row_number=record.row_number,
                logical_metric=record.logical_metric,
                raw_column=record.raw_column,
                value=record.value,
                dimensions=record.dimensions,
                lower_bound=metric.lower_bound,
                upper_bound=metric.upper_bound,
                center=metric.center,
                stdev=metric.stdev,
                outlier_golden_method=metric.outlier_golden_method,
                relative_limit=metric.relative_limit,
                sigma_multiplier=metric.sigma_multiplier,
                absolute_lower_bound=metric.absolute_lower_bound,
                absolute_upper_bound=metric.absolute_upper_bound,
                overwrite_min=metric.overwrite_min,
                overwrite_max=metric.overwrite_max,
                allowed_ranges=list(metric.allowed_ranges),
                reference_key=metric.reference_key,
                reason="Value is outside configured golden rule." if not is_within else None,
            )
        )
    return evaluations


def summarize_golden_coverage(
    measurements: list[MeasurementRecord],
    reference: GoldenReference,
) -> dict[str, object]:
    index = _build_golden_index(reference)
    matched_measurement_count = 0
    unmatched_measurement_count = 0
    matched_rows: set[tuple[str, str, int]] = set()
    unmatched_rows: set[tuple[str, str, int]] = set()
    unmatched_examples: list[dict[str, object]] = []

    for record in measurements:
        reference_key = tuple(
            (dimension, record.dimensions.get(dimension, ""))
            for dimension in reference.reference_dimensions
        )
        metric = index.get((reference_key, record.logical_metric))
        row_key = (record.dataset_id, record.source_file, record.row_number)
        if metric is None:
            unmatched_measurement_count += 1
            unmatched_rows.add(row_key)
            if len(unmatched_examples) < 5:
                unmatched_examples.append(
                    {
                        "dataset_id": record.dataset_id,
                        "row_number": record.row_number,
                        "logical_metric": record.logical_metric,
                        "raw_column": record.raw_column,
                        "dimensions": dict(record.dimensions),
                    }
                )
            continue
        matched_measurement_count += 1
        matched_rows.add(row_key)

    total_measurement_count = len(measurements)
    return {
        "total_measurement_count": total_measurement_count,
        "matched_measurement_count": matched_measurement_count,
        "unmatched_measurement_count": unmatched_measurement_count,
        "matched_row_count": len(matched_rows),
        "unmatched_row_count": len(unmatched_rows),
        "unmatched_examples": unmatched_examples,
    }


def detect_by_modified_zscore(
    measurements: list[MeasurementRecord],
    population_dimensions: list[str] | None = None,
    z_threshold: float = 3.5,
) -> list[AnomalyResult]:
    evaluations = evaluate_modified_zscore(
        measurements=measurements,
        population_dimensions=population_dimensions,
    )
    anomalies: list[AnomalyResult] = []
    for item in evaluations:
        if item.score is None or abs(item.score) <= z_threshold:
            continue
        item.reason = f"Absolute modified z-score exceeded threshold {z_threshold}."
        anomalies.append(item)
    return anomalies


def evaluate_modified_zscore(
    measurements: list[MeasurementRecord],
    population_dimensions: list[str] | None = None,
) -> list[AnomalyResult]:
    population_dimensions = population_dimensions or []
    grouped: dict[tuple[tuple[str, str], str], list[MeasurementRecord]] = defaultdict(list)

    for record in measurements:
        population_key = tuple(
            (dimension, record.dimensions.get(dimension, ""))
            for dimension in population_dimensions
        )
        grouped[(population_key, record.logical_metric)].append(record)

    evaluations: list[AnomalyResult] = []
    for (population_key, logical_metric), records in grouped.items():
        values = [record.value for record in records]
        if len(values) < 3:
            for record in records:
                evaluations.append(
                    AnomalyResult(
                        method="modified_z_score",
                        dataset_id=record.dataset_id,
                        source_file=record.source_file,
                        row_number=record.row_number,
                        logical_metric=logical_metric,
                        raw_column=record.raw_column,
                        value=record.value,
                        dimensions=record.dimensions,
                        center=None,
                        score=None,
                        reason=None,
                    )
                )
            continue
        med = median(values)
        deviations = [abs(value - med) for value in values]
        mad = median(deviations)
        if mad == 0:
            for record in records:
                evaluations.append(
                    AnomalyResult(
                        method="modified_z_score",
                        dataset_id=record.dataset_id,
                        source_file=record.source_file,
                        row_number=record.row_number,
                        logical_metric=logical_metric,
                        raw_column=record.raw_column,
                        value=record.value,
                        dimensions=record.dimensions,
                        center=med,
                        score=0.0,
                        reason=None,
                    )
                )
            continue
        for record in records:
            score = 0.6745 * (record.value - med) / mad
            evaluations.append(
                AnomalyResult(
                    method="modified_z_score",
                    dataset_id=record.dataset_id,
                    source_file=record.source_file,
                    row_number=record.row_number,
                    logical_metric=logical_metric,
                    raw_column=record.raw_column,
                    value=record.value,
                    dimensions=record.dimensions,
                    center=med,
                    score=score,
                    reason=None,
                )
            )
    return evaluations


def _match_dimensions(dimensions: dict[str, str], expected: dict[str, str]) -> bool:
    for key, value in expected.items():
        expected_values = [item.strip() for item in str(value).split(",") if item.strip()]
        if not expected_values:
            expected_values = [str(value).strip()]
        if dimensions.get(key) not in expected_values:
            return False
    return True


def _build_golden_index(
    reference: GoldenReference,
) -> dict[tuple[tuple[tuple[str, str], ...], str], GoldenMetricRange]:
    return {
        (
            tuple(
                (dimension, metric.reference_key.get(dimension, ""))
                for dimension in reference.reference_dimensions
            ),
            metric.logical_metric,
        ): metric
        for metric in reference.metrics
    }


def _resolve_center(values: list[float], center_method: str) -> float:
    if center_method == "median":
        return median(values)
    return mean(values)


def _resolve_group_rule(
    group_id: str,
    defaults: GoldenRuleConfig,
    overrides: dict[str, GoldenRuleConfig],
) -> GoldenRuleConfig:
    override = overrides.get(group_id)
    if override is None:
        return defaults
    normalized = validate_golden_rule_config(
        f"Analysis group {group_id} golden rule",
        override.outlier_golden_method,
        override.relative_limit,
        override.sigma_multiplier,
        override.absolute_lower_bound,
        override.absolute_upper_bound,
        override.overwrite_min,
        override.overwrite_max,
    )
    return GoldenRuleConfig(
        outlier_golden_method=normalized,
        relative_limit=override.relative_limit,
        sigma_multiplier=override.sigma_multiplier,
        absolute_lower_bound=override.absolute_lower_bound,
        absolute_upper_bound=override.absolute_upper_bound,
        overwrite_min=override.overwrite_min,
        overwrite_max=override.overwrite_max,
    )
