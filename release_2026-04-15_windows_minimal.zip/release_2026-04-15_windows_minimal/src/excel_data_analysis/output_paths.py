from __future__ import annotations

from datetime import datetime
from pathlib import Path
import shutil

REPORT_SPLIT_OUTPUT_LABELS = ("data", "outlier")


def resolve_output_path(
    path: str | Path,
    if_exists: str = "overwrite",
) -> Path:
    output_path = Path(path)
    if if_exists not in {"overwrite", "timestamp", "error"}:
        raise ValueError(
            f"Unsupported if_exists mode: {if_exists}. Expected overwrite, timestamp, or error."
        )
    if not output_path.exists() or if_exists == "overwrite":
        return output_path
    if if_exists == "error":
        raise FileExistsError(f"Output file already exists: {output_path}")
    return _timestamped_output_path(output_path)


def prepare_output_directory(
    path: str | Path,
    if_exists: str = "overwrite",
) -> Path:
    directory_path = Path(path)
    if if_exists not in {"overwrite", "timestamp", "error"}:
        raise ValueError(
            f"Unsupported if_exists mode: {if_exists}. Expected overwrite, timestamp, or error."
        )
    if directory_path.exists():
        if if_exists == "error":
            raise FileExistsError(f"Output directory already exists: {directory_path}")
        if if_exists == "timestamp":
            directory_path = _timestamped_output_path(directory_path)
        else:
            if directory_path.is_dir():
                shutil.rmtree(directory_path)
            else:
                directory_path.unlink()
    directory_path.mkdir(parents=True, exist_ok=True)
    return directory_path


def derive_split_output_paths(
    path: str | Path,
    labels: tuple[str, ...] = REPORT_SPLIT_OUTPUT_LABELS,
) -> dict[str, Path]:
    base_path = Path(path)
    return {
        label: base_path.with_name(f"{base_path.stem}_{label}{base_path.suffix}")
        for label in labels
    }


def resolve_split_output_base_path(
    path: str | Path,
    if_exists: str = "overwrite",
    labels: tuple[str, ...] = REPORT_SPLIT_OUTPUT_LABELS,
) -> Path:
    base_path = Path(path)
    split_paths = derive_split_output_paths(base_path, labels=labels)
    if if_exists not in {"overwrite", "timestamp", "error"}:
        raise ValueError(
            f"Unsupported if_exists mode: {if_exists}. Expected overwrite, timestamp, or error."
        )
    if if_exists == "overwrite" or not any(item.exists() for item in split_paths.values()):
        return base_path
    if if_exists == "error":
        existing = [str(item) for item in split_paths.values() if item.exists()]
        raise FileExistsError(
            "Output file already exists: " + ", ".join(existing)
        )
    return _timestamped_output_path(base_path)


def resolve_split_output_paths(
    path: str | Path,
    if_exists: str = "overwrite",
    labels: tuple[str, ...] = REPORT_SPLIT_OUTPUT_LABELS,
) -> dict[str, Path]:
    resolved_base = resolve_split_output_base_path(path, if_exists=if_exists, labels=labels)
    return derive_split_output_paths(resolved_base, labels=labels)


def _timestamped_output_path(path: Path) -> Path:
    timestamp = datetime.now().strftime("%Y%m%dT%H%M%S")
    candidate = path.with_name(f"{path.stem}_{timestamp}{path.suffix}")
    index = 1
    while candidate.exists():
        candidate = path.with_name(f"{path.stem}_{timestamp}_{index}{path.suffix}")
        index += 1
    return candidate
