from __future__ import annotations

import csv
import re
from pathlib import Path
from typing import Any

from .models import (
    LoadedTable,
    MeasurementRecord,
    NumericCleanupConfig,
    RowDimensionSource,
    TemplateConfig,
)

REPEAT_DIMENSION_NAME = "repeat_id"


def load_table(
    input_path: str | Path,
    template: TemplateConfig | None = None,
) -> LoadedTable:
    path = Path(input_path)
    suffix = path.suffix.lower()
    test_data_header_row = 0
    row_header_row = 0
    test_data_start_column: int | None = None
    test_data_start_row: int | None = None
    if template is not None:
        test_data_header_row = template.test_data_header_row
        row_header_row = template.row_header_row
        test_data_start_column = template.test_data_start_column
        test_data_start_row = template.test_data_start_row
        if test_data_start_row is None:
            raise ValueError(
                "Template must define test_data_start_row explicitly before loading data."
            )
    if suffix == ".csv":
        return _load_csv(
            path,
            test_data_header_row=test_data_header_row,
            row_header_row=row_header_row,
            test_data_start_column=test_data_start_column,
            test_data_start_row=test_data_start_row,
        )
    if suffix in {".xlsx", ".xlsm"}:
        return _load_xlsx(
            path,
            test_data_header_row=test_data_header_row,
            row_header_row=row_header_row,
            test_data_start_column=test_data_start_column,
            unit_row=None,
            test_data_start_row=test_data_start_row,
        )
    raise ValueError(f"Unsupported file type: {suffix}")


def load_rows(
    input_path: str | Path,
    template: TemplateConfig | None = None,
) -> list[dict[str, Any]]:
    return load_table(input_path, template=template).rows


def build_measurements(
    template: TemplateConfig,
    rows: list[dict[str, Any]],
    dataset_id: str,
    source_file: str,
) -> list[MeasurementRecord]:
    measurements: list[MeasurementRecord] = []
    for row_index, row, dimensions in extract_dimension_rows(template, rows):
        for group in template.analysis_groups:
            for column in group.columns:
                if column.name not in row:
                    continue
                value = to_float(row[column.name], template.numeric_cleanup)
                if value is None:
                    continue
                logical_metric = (
                    group.id
                    if group.analysis_mode == "pooled_columns"
                    else f"{group.id}::{column.name}"
                )
                measurements.append(
                    MeasurementRecord(
                        dataset_id=dataset_id,
                        source_file=source_file,
                        row_number=row_index,
                        logical_metric=logical_metric,
                        group_id=group.id,
                        group_display_name=group.display_name,
                        presentation_group=column.header_values[0] if column.header_values else None,
                        raw_column=column.name,
                        value=value,
                        dimensions=dimensions,
                    )
                )
    return measurements


def extract_dimension_rows(
    template: TemplateConfig,
    rows: list[dict[str, Any]],
) -> list[tuple[int, dict[str, Any], dict[str, str]]]:
    extracted: list[tuple[int, dict[str, Any], dict[str, str]]] = []
    for row_index, row in enumerate(rows, start=1):
        dimensions = extract_dimensions(template, row)
        if dimensions is None:
            continue
        extracted.append((row_index, row, dimensions))
    _normalize_repeat_dimensions(extracted)
    return extracted


def extract_dimensions(
    template: TemplateConfig, row: dict[str, Any]
) -> dict[str, str] | None:
    dimensions: dict[str, str] = {}
    for dimension in sorted(template.row_dimensions, key=lambda item: item.priority):
        parts: list[str] = []
        for source in dimension.sources:
            raw_value = row.get(source.column)
            if raw_value is None or str(raw_value).strip() == "":
                continue
            text = str(raw_value).strip()
            split_position = _resolve_split_position(source, row)
            if split_position is None:
                parts.append(text)
                continue
            split_parts = _split_by_delimiters(text, source.split_delimiters)
            if source.skip_empty_parts:
                split_parts = [item for item in split_parts if item != ""]
            if split_position >= len(split_parts):
                continue
            part = split_parts[split_position].strip()
            if part:
                parts.append(part)
        if not parts:
            if dimension.default_value is not None:
                dimensions[dimension.name] = dimension.default_value
                continue
            if dimension.optional:
                continue
            return None
        dimensions[dimension.name] = "|".join(parts)
    return dimensions


def _split_by_delimiters(value: str, delimiters: list[str]) -> list[str]:
    if not delimiters:
        return [value]
    pattern = "|".join(re.escape(item) for item in sorted(delimiters, key=len, reverse=True))
    if not pattern:
        return [value]
    return re.split(pattern, value)


def _resolve_split_position(
    source: RowDimensionSource,
    row: dict[str, Any],
) -> int | None:
    if source.split_position_by_column:
        match_value = row.get(source.split_position_by_column)
        if match_value is not None:
            normalized = str(match_value).strip()
            if normalized in source.split_position_map:
                return source.split_position_map[normalized]
    return source.split_position


def _normalize_repeat_dimensions(
    extracted_rows: list[tuple[int, dict[str, Any], dict[str, str]]],
) -> None:
    grouped: dict[tuple[tuple[str, str], ...], list[tuple[int, dict[str, Any], dict[str, str]]]] = {}
    for row_entry in extracted_rows:
        _row_index, _row, dimensions = row_entry
        if REPEAT_DIMENSION_NAME not in dimensions:
            continue
        base_key = tuple(
            sorted(
                (key, value)
                for key, value in dimensions.items()
                if key != REPEAT_DIMENSION_NAME
            )
        )
        grouped.setdefault(base_key, []).append(row_entry)

    for group_rows in grouped.values():
        if _repeat_group_is_valid(group_rows):
            continue
        for repeat_index, (_row_number, _row, dimensions) in enumerate(
            sorted(group_rows, key=lambda item: item[0]),
            start=1,
        ):
            dimensions[REPEAT_DIMENSION_NAME] = str(repeat_index)


def _repeat_group_is_valid(
    group_rows: list[tuple[int, dict[str, Any], dict[str, str]]],
) -> bool:
    parsed_values: list[int] = []
    seen: set[int] = set()
    for _row_number, _row, dimensions in group_rows:
        parsed = _parse_repeat_text(dimensions.get(REPEAT_DIMENSION_NAME))
        if parsed is None:
            return False
        if parsed in seen:
            return False
        seen.add(parsed)
        parsed_values.append(parsed)
    return sorted(parsed_values) == list(range(1, len(group_rows) + 1))


def _parse_repeat_text(value: str | None) -> int | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    if re.fullmatch(r"[+-]?\d+", text):
        return int(text)
    return None


def _load_csv(
    path: Path,
    test_data_header_row: int = 0,
    row_header_row: int = 0,
    test_data_start_column: int | None = None,
    test_data_start_row: int | None = None,
) -> LoadedTable:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        sample = handle.read(4096)
        handle.seek(0)
        dialect: csv.Dialect | type[csv.Dialect] = csv.excel
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
        except csv.Error:
            if ";" in sample and "," not in sample:
                class _SemicolonDialect(csv.excel):
                    delimiter = ";"

                dialect = _SemicolonDialect
        rows = list(csv.reader(handle, dialect=dialect))
    return _rows_to_loaded_table(
        rows,
        test_data_header_row=test_data_header_row,
        row_header_row=row_header_row,
        test_data_start_column=test_data_start_column,
        unit_row=None,
        test_data_start_row=test_data_start_row if test_data_start_row is not None else 1,
    )


def _load_xlsx(
    path: Path,
    test_data_header_row: int = 0,
    row_header_row: int = 0,
    test_data_start_column: int | None = None,
    unit_row: int | None = None,
    test_data_start_row: int | None = None,
) -> LoadedTable:
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise RuntimeError(
            "Reading xlsx requires openpyxl. Run `pip3 install -e .` first."
        ) from exc

    workbook = load_workbook(path, data_only=True, read_only=True)
    sheet = workbook.active
    rows = list(sheet.iter_rows(values_only=True))
    return _rows_to_loaded_table(
        rows,
        test_data_header_row=test_data_header_row,
        row_header_row=row_header_row,
        test_data_start_column=test_data_start_column,
        unit_row=unit_row,
        test_data_start_row=test_data_start_row,
    )


def _rows_to_loaded_table(
    rows: list[tuple[Any, ...]] | list[list[Any]],
    test_data_header_row: int = 0,
    row_header_row: int = 0,
    test_data_start_column: int | None = None,
    unit_row: int | None = None,
    test_data_start_row: int | None = None,
) -> LoadedTable:
    if not rows:
        return LoadedTable(headers=[], rows=[], units={})

    normalized_matrix = [tuple(row) for row in rows]
    test_headers = _normalize_header_row(normalized_matrix, test_data_header_row)
    row_headers = _normalize_header_row(normalized_matrix, row_header_row)
    units = (
        _normalize_header_row(normalized_matrix, unit_row)
        if unit_row is not None
        else [""] * max(len(test_headers), len(row_headers))
    )
    headers = _combine_headers(
        test_headers,
        row_headers,
        test_data_start_column=test_data_start_column,
    )
    if test_data_start_row is None:
        candidate_rows = [test_data_header_row, row_header_row]
        if unit_row is not None:
            candidate_rows.append(unit_row)
        test_data_start_row = max(candidate_rows) + 1
    data_rows = normalized_matrix[test_data_start_row:]
    normalized_rows: list[dict[str, Any]] = []
    for values in data_rows:
        payload = {
            headers[index]: values[index] if index < len(values) else None
            for index in range(len(headers))
            if headers[index]
        }
        if any(value is not None and str(value).strip() != "" for value in payload.values()):
            normalized_rows.append(payload)
    unit_map = {
        headers[index]: units[index]
        for index in range(len(headers))
        if headers[index] and index < len(units) and units[index]
    }
    return LoadedTable(headers=headers, rows=normalized_rows, units=unit_map)


def to_float(
    value: Any,
    numeric_cleanup: NumericCleanupConfig | None = None,
) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if not text:
        return None
    text = _cleanup_numeric_text(text, numeric_cleanup)
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        scientific_token = _extract_scientific_number(text)
        if scientific_token is not None:
            try:
                return float(scientific_token)
            except ValueError:
                return None
        return None


def _cleanup_numeric_text(
    text: str,
    config: NumericCleanupConfig | None,
) -> str:
    if config is None or not config.enabled:
        return text
    if config.mode == "specified_chars":
        cleaned = text
        for item in sorted(config.characters, key=len, reverse=True):
            if item:
                cleaned = cleaned.replace(item, "")
        return cleaned.strip()
    return re.sub(r"[^0-9eE+\-\.]", "", text).strip()


def _extract_scientific_number(text: str) -> str | None:
    match = re.search(
        r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)",
        text,
    )
    if match is None:
        return None
    return match.group(0)


def _normalize_header_row(rows: list[tuple[Any, ...]], row_index: int | None) -> list[str]:
    if row_index is None or row_index >= len(rows):
        return []
    return [str(item).strip() if item is not None else "" for item in rows[row_index]]


def _combine_headers(
    measurement_headers: list[str],
    row_headers: list[str],
    test_data_start_column: int | None = None,
) -> list[str]:
    size = max(len(measurement_headers), len(row_headers))
    headers: list[str] = []
    used: dict[str, int] = {}
    for index in range(size):
        header = ""
        if test_data_start_column is not None and index >= test_data_start_column:
            if index < len(measurement_headers) and measurement_headers[index]:
                header = measurement_headers[index]
        elif index < len(row_headers) and row_headers[index]:
            header = row_headers[index]
        elif index < len(measurement_headers) and measurement_headers[index]:
            header = measurement_headers[index]
        if header and header in used:
            used[header] += 1
            header = f"{header}__{used[header]}"
        elif header:
            used[header] = 1
        headers.append(header)
    return headers
