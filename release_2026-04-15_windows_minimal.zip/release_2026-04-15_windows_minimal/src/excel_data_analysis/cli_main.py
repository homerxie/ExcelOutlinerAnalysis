from __future__ import annotations

from excel_data_analysis.cli import main


if __name__ == "__main__":
    main()
