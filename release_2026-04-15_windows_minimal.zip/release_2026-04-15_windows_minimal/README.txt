Easy Outlier Windows package

This package is prepared for Windows users who want to build and run Easy Outlier locally.

Included:
- application source code
- Windows setup/build scripts
- PyInstaller spec files
- icon files

Intentionally excluded:
- help manuals
- GUI tutorials
- examples and template_example folders

Build on Windows:
1. Double-click setup_windows.bat
2. After setup completes, double-click build_windows.bat
3. GUI output will be created under dist\EasyOutlier
4. CLI output will be created under dist\easy-outlier

Notes:
- Build this package on Windows. PyInstaller does not generate a Windows executable from macOS.
- The application still includes the built-in JSON template under src\excel_data_analysis\assets\templates.
