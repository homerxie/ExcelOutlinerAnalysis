# -*- mode: python ; coding: utf-8 -*-

from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files, collect_submodules


spec_file = globals().get("__file__")
if spec_file:
    project_root = Path(spec_file).resolve().parent
else:
    project_root = Path.cwd().resolve()
src_root = project_root / "src"

datas = collect_data_files(
    "excel_data_analysis",
    includes=["assets/templates/*.json"],
)
hiddenimports = collect_submodules("openpyxl")


a = Analysis(
    [str(src_root / "excel_data_analysis" / "cli_main.py")],
    pathex=[str(src_root)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="easy-outlier",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
)
