from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from openpyxl import Workbook

from excel_data_analysis.io import build_measurements, load_table
from excel_data_analysis.models import (
    AnalysisColumn,
    AnalysisGroup,
    ColumnHeaderLevel,
    RowDimension,
    RowDimensionSource,
    TemplateConfig,
)


class HeaderOverrideTests(unittest.TestCase):
    def test_test_data_start_column_preserves_measurement_headers(self) -> None:
        workbook = Workbook()
        sheet = workbook.active
        sheet.cell(1, 3).value = "OS_PPMU_FIMV:A_CORE_ELK47_IN@A_CORE_ELK47_IN[1]"
        sheet.cell(4, 3).value = "ohm"
        sheet.cell(5, 1).value = "File"
        sheet.cell(5, 2).value = "SITE"
        sheet.cell(5, 3).value = 29999912
        sheet.cell(6, 1).value = "HiMIMCapV100_JTT8U4B0_PCMSL4_25C_FT1_25C_H2_1"
        sheet.cell(6, 2).value = 1
        sheet.cell(6, 3).value = 381210

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "input.xlsx"
            workbook.save(path)
            template = TemplateConfig(
                name="test-template",
                test_data_header_row=0,
                row_header_row=4,
                test_data_start_column=2,
                unit_row=3,
                test_data_start_row=5,
                column_header_levels=[
                    ColumnHeaderLevel(name="Chain Name", priority=1),
                    ColumnHeaderLevel(name="Test Type", priority=2),
                    ColumnHeaderLevel(name="Repeat Index", priority=3),
                ],
                row_dimensions=[
                    RowDimension(
                        name="sample_id",
                        priority=1,
                        display_name="SampleID",
                        sources=[
                            RowDimensionSource(
                                column="File",
                                split_delimiters=["_"],
                                split_position=7,
                            )
                        ],
                    ),
                    RowDimension(
                        name="site_id",
                        priority=2,
                        display_name="Site",
                        optional=True,
                        sources=[RowDimensionSource(column="SITE")],
                    ),
                ],
                analysis_groups=[
                    AnalysisGroup(
                        id="R-CORE_ELK47_IN",
                        display_name="R CORE_ELK47_IN",
                        columns=[
                            AnalysisColumn(
                                name="OS_PPMU_FIMV:A_CORE_ELK47_IN@A_CORE_ELK47_IN[1]",
                                header_values=["CORE_ELK47_IN", "R", "1"],
                            )
                        ],
                        analysis_mode="per_column",
                        unit="Ohm",
                    )
                ],
            )
            table = load_table(path, template=template)
            measurements = build_measurements(
                template,
                table.rows,
                dataset_id="dataset-1",
                source_file=str(path),
            )

        self.assertIn("OS_PPMU_FIMV:A_CORE_ELK47_IN@A_CORE_ELK47_IN[1]", table.headers)
        self.assertEqual(len(measurements), 1)
        self.assertEqual(
            measurements[0].raw_column,
            "OS_PPMU_FIMV:A_CORE_ELK47_IN@A_CORE_ELK47_IN[1]",
        )


if __name__ == "__main__":
    unittest.main()
