"""Persist the completed Analyze inputs needed for TSK, without reclassification.

The database stores compressed JSON, never executable pickle data. Numeric
measurements and export-only artifacts are omitted; row identities, scoped
columns, topology, rules and final chain states are retained exactly.
"""
from __future__ import annotations

import base64
from dataclasses import asdict
import gzip
import json
from pathlib import Path

from .reporting import ColumnMeta, RowData
from .template import _parse_template, template_to_payload


FORMAT = "tsk-analyze-input-v1"


def encode_analysis_snapshot(snapshot: dict) -> dict:
    payload = {
        "format": FORMAT,
        "template": template_to_payload(snapshot["template"]),
        "columns": [asdict(column) for column in snapshot["columns"]],
        "rows": [dict(dataset_id=row.dataset_id, source_file=row.source_file,
                      row_number=row.row_number, dimensions=row.dimensions)
                 for row in snapshot["rows"]],
        "final_status_rows": [
            {key: row[key] for key in ("sample_key", "node", "test_group_key", "is_fail", "status")
             if key in row}
            for row in snapshot["summary_artifacts"]["final_status_rows"]
        ],
        "fail_mode": snapshot["fail_mode"],
        "result": snapshot["result"],
    }
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")
    return {"format": FORMAT,
            "data": base64.b64encode(gzip.compress(raw, compresslevel=6, mtime=0)).decode("ascii")}


def snapshot_bytes(payload: dict) -> bytes:
    if not isinstance(payload, dict) or payload.get("format") != FORMAT:
        raise ValueError("Unsupported saved Analyze input format")
    return base64.b64decode(payload["data"], validate=True)


def decode_analysis_snapshot(data: bytes) -> dict:
    payload = json.loads(gzip.decompress(data).decode("utf-8"))
    if not isinstance(payload, dict) or payload.get("format") != FORMAT:
        raise ValueError("Unsupported saved Analyze input format")
    states = payload["final_status_rows"]
    if not isinstance(states, list) or any(
        not isinstance(row, dict)
        or not all(key in row for key in ("sample_key", "node", "test_group_key", "is_fail"))
        or not isinstance(row["is_fail"], bool)
        for row in states
    ):
        raise ValueError("Incomplete saved Analyze chain states")
    return {
        "template": _parse_template(payload["template"]),
        "columns": [ColumnMeta(**column) for column in payload["columns"]],
        "rows": [RowData(**row, values={}) for row in payload["rows"]],
        "summary_artifacts": {"final_status_rows": states},
        "fail_mode": payload["fail_mode"],
        "result": payload["result"],
    }


def write_analysis_snapshot(payload: dict, path: str | Path) -> None:
    Path(path).write_bytes(snapshot_bytes(payload))
