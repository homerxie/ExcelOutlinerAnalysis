"""Frozen, origin-symmetric XY basis shared by fitting and prediction.

Axis scales are numerical units, not fitted die dimensions or peak radii.
The five free coefficients include elliptical radial quadratics without
requiring a peak in the observed layout or identifiable ellipse parameters.
"""

from __future__ import annotations

import math
from numbers import Real
from typing import Any, Mapping, Sequence

import numpy as np


DEFAULT_XY_MODEL = "origin_even_quartic"
XY_MODELS = (DEFAULT_XY_MODEL, "linear")
SPATIAL_TERMS = (
    ("__xy_x2", (2, 0), "X²"),
    ("__xy_y2", (0, 2), "Y²"),
    ("__xy_x4", (4, 0), "X⁴"),
    ("__xy_x2y2", (2, 2), "X²Y²"),
    ("__xy_y4", (0, 4), "Y⁴"),
)


def validate_xy_model(value: Any) -> str:
    if value not in XY_MODELS:
        raise ValueError("xy_model must be 'origin_even_quartic' or 'linear'.")
    return str(value)


def _finite_number(value: Any) -> bool:
    return isinstance(value, Real) and not isinstance(value, bool) and math.isfinite(value)


def build_spatial_transform(instances: Sequence[Any]) -> dict[str, Any]:
    coordinates = np.asarray([[row.x, row.y] for row in instances], dtype=float)
    if coordinates.shape != (len(instances), 2) or not len(instances) or not np.all(np.isfinite(coordinates)):
        raise ValueError("The XY spatial model requires finite X and Y for every training instance.")
    scales = np.max(np.abs(coordinates), axis=0)
    scales[scales == 0] = 1.
    reference = (coordinates / scales).mean(axis=0) * scales
    return {
        "version": 1, "model": DEFAULT_XY_MODEL,
        "coordinate_scales": dict(zip(("x", "y"), map(float, scales))),
        "reference": dict(zip(("x", "y"), map(float, reference))),
        "terms": [{"name": name, "powers": list(powers), "label": label}
                  for name, powers, label in SPATIAL_TERMS],
        "reference_method": "basis_at_mean_raw_coordinates",
        "symmetry_center": {"x": 0., "y": 0.},
        "scope": "Observed-coordinate risk; no peak location, monotonicity or global minimum is imposed.",
    }


def validate_spatial_transform(transform: Mapping[str, Any]) -> None:
    if not isinstance(transform, Mapping) or transform.get("version") != 1 or transform.get("model") != DEFAULT_XY_MODEL:
        raise ValueError("Unsupported frozen XY transform; rerun the TSK analysis.")
    terms = transform.get("terms", [])
    expected = [(name, list(powers)) for name, powers, _ in SPATIAL_TERMS]
    if (not isinstance(terms, list) or any(not isinstance(term, Mapping) for term in terms)
            or [(term.get("name"), term.get("powers")) for term in terms] != expected):
        raise ValueError("Invalid frozen XY basis definition.")
    scales, reference = transform.get("coordinate_scales", {}), transform.get("reference", {})
    if (not isinstance(scales, Mapping) or not isinstance(reference, Mapping)
            or any(not _finite_number(scales.get(axis)) or scales[axis] <= 0
                   or not _finite_number(reference.get(axis)) for axis in ("x", "y"))):
        raise ValueError("Invalid frozen XY scale or reference coordinate.")


def spatial_values(transform: Mapping[str, Any], x: float, y: float) -> dict[str, float]:
    """Evaluate raw basis values; apply the saved centering/scaling afterwards."""
    if not _finite_number(x) or not _finite_number(y):
        raise ValueError("The XY spatial model requires finite X and Y coordinates.")
    u, v = float(x) / transform["coordinate_scales"]["x"], float(y) / transform["coordinate_scales"]["y"]
    try:
        values = {name: u ** powers[0] * v ** powers[1] for name, powers, _ in SPATIAL_TERMS}
    except OverflowError as error:
        raise ValueError("Coordinates exceed the finite range of the frozen XY basis.") from error
    if not all(math.isfinite(value) for value in values.values()):
        raise ValueError("Coordinates exceed the finite range of the frozen XY basis.")
    return values


def spatial_feature_groups(transform: Mapping[str, Any] | None) -> dict[str, Any]:
    if not transform:
        return {}
    return {"XY": {"kind": "spatial", "label": "XY 位置",
                   "columns": [term["name"] for term in transform["terms"]],
                   "labels": {term["name"]: term["label"] for term in transform["terms"]}}}
