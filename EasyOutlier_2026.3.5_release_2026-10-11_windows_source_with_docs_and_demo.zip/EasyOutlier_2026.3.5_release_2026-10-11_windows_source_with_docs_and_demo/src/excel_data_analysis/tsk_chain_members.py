"""Per-chain physical members evaluated at their actual fitted conditions.

This report never substitutes a type's reference-environment probability for
an instance prediction, and never computes a member confidence interval.
Identical fitted designs share one query and one grouped display row.
"""

from __future__ import annotations

from copy import deepcopy
import json
import math
from numbers import Real
from time import monotonic
from typing import Any, Mapping, Sequence

import numpy as np

from .tsk_features import category_label
from .tsk_parallel import ordered_parallel_map, validate_analysis_workers, worker_count
from .tsk_progress import joint_progress_message
from .tsk_spatial import spatial_values


def _get(item, key, default=None):
    return item.get(key, default) if isinstance(item, Mapping) else getattr(item, key, default)


def _plain(value):
    if isinstance(value, Mapping):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    if isinstance(value, np.generic):
        return _plain(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _number(value):
    return float(value) if isinstance(value, Real) and not isinstance(value, bool) and math.isfinite(value) else None


def _risk_result(probability=None, *, identifiable=False, status="not_identifiable", reason="", estimate_kind="interior"):
    return {"probability": probability, "identifiable": identifiable, "status": status,
            "reason": reason, "estimate_kind": estimate_kind}


def _prepare_member_queries(context):
    """Construct and validate the immutable fitted model once per worker."""
    from .tsk_prediction import _FrozenFit
    fit = _FrozenFit(context)
    if fit.joint_engine is not None:
        fit.joint_engine.analysis_workers = 1
        for component in getattr(fit.joint_engine, "components", []):
            component["engine"].analysis_workers = 1
    return fit, fit.boundary_engine, fit.joint_engine, fit.theta, set()


def _member_query_task(common, key, heartbeat, detail_progress=None):
    """Check one complete instance condition; member intervals are never fitted."""
    fit, boundary_engine, joint_engine, parameters, certified_zero_types = common
    vector = np.asarray(key, dtype=float)
    engine = joint_engine if joint_engine is not None else boundary_engine
    previous_progress = getattr(engine, "progress_callback", None)
    if engine is not None:
        def forward_progress(event):
            if previous_progress is not None:
                previous_progress(event)
            if detail_progress is not None:
                detail_progress(event)
            elif previous_progress is None:
                heartbeat()
        engine.progress_callback = forward_progress
    try:
        heartbeat()
        if fit is not None and not fit.valid_fit:
            return _risk_result(status="fit_not_converged", reason="保存的拟合未通过实际条件风险复核。")
        if joint_engine is not None:
            identified = joint_engine.identifiable(parameters, vector)
            probability = joint_engine.probability(parameters, vector) if identified else None
            estimate_kind = joint_engine.estimate_kind(vector) if identified else "interior"
            query_validated = (not joint_engine.state.get("partial_fit") or joint_engine.query_validated(vector))
            outcome = _risk_result(probability, identifiable=identified,
                status="boundary_low" if estimate_kind == "boundary_low" else "ok" if identified else
                "not_identifiable" if query_validated else "fit_not_converged", estimate_kind=estimate_kind,
                reason="" if identified else "联合系数仍可变化，该实例条件的风险尚未被观测独立确定。"
                if query_validated else "该条件涉及尚未通过联合边界验证的子模型。")
        elif boundary_engine is not None:
            kind = int(np.argmax(vector[:boundary_engine.type_count]))
            if kind in certified_zero_types:
                outcome = _risk_result(0., identifiable=True, status="boundary_low", estimate_kind="boundary_low")
            else:
                identified = boundary_engine.identifiable(parameters, vector)
                probability = boundary_engine.probability(parameters, vector) if identified else None
                boundary = identified and probability == 0.
                if boundary:
                    certified_zero_types.add(kind)
                outcome = _risk_result(probability, identifiable=identified,
                    status="boundary_low" if boundary else "ok" if identified else "not_identifiable",
                    estimate_kind="boundary_low" if boundary else "interior",
                    reason="" if identified else "链的整体风险可计算，但无法单独确定该实例条件的风险。")
        else:
            identified = fit.identifiable(vector)
            probability = fit.probability(vector) if identified else None
            outcome = _risk_result(probability, identifiable=identified and probability is not None,
                status="ok" if probability is not None else "not_identifiable",
                reason="" if probability is not None else "链的整体风险可计算，但无法单独确定该实例条件的风险。")
    except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
        if getattr(error, "invalidates_fit", False):
            raise
        outcome = _risk_result(status="unavailable", reason=f"该实例条件未能完成风险识别：{error}")
    finally:
        if engine is not None:
            engine.progress_callback = previous_progress
    if outcome["probability"] is not None and (not math.isfinite(outcome["probability"])
                                                or not 0 <= outcome["probability"] <= 1):
        outcome = _risk_result(status="unavailable", reason="该实例条件未得到有限、有效的风险概率。")
    return outcome


def _query_already_checked(common, key):
    fit, boundary_engine, joint_engine, _, certified_zero_types = common
    if joint_engine is not None:
        engine = joint_engine
        if hasattr(engine, "_component"):
            engine = engine._component(np.asarray(key))
            if engine is None:
                return True  # The independent-block certificate rejects this query without profiling.
        return key in engine._identified_cache
    if boundary_engine is not None:
        kind = int(np.argmax(key[:boundary_engine.type_count]))
        return kind in certified_zero_types or key in boundary_engine._identifiable_cache
    return fit is not None and key in fit._identified_queries


def _invalidate_member_fit(engine):
    """A worker's better optimum invalidates every result from this shared fit."""
    if engine is None:
        return
    if engine.state is not None:
        engine.state["converged"] = False
        if "usable" in engine.state:
            engine.state["usable"] = False
        reasons = engine.state.setdefault("validation", {}).setdefault("reason_codes", [])
        if "joint_profile_found_better_optimum" not in reasons:
            reasons.append("joint_profile_found_better_optimum")
    for name in ("_identified_cache", "_identifiable_cache", "_profile_cache", "_kind_cache"):
        getattr(engine, name, {}).clear()
    for component in getattr(engine, "components", []):
        _invalidate_member_fit(component["engine"])


def build_chain_members(
    instances: Sequence[Any], chain_rows: Sequence[Any], type_rows: Sequence[Any], *,
    context: Mapping[str, Any] | None = None, boundary_engine=None, joint_engine=None,
    feature_names: Sequence[str] = (), categorical_feature_names: Sequence[str] = (), use_xy: bool = False,
    progress_callback=None, analysis_workers: int = 0, execution: dict | None = None,
) -> dict[str, list[dict[str, Any]]]:
    """Return topology members with identified point risks, keyed by chain ID.

    ``context`` uses the frozen fit schema also consumed by ``_FrozenFit``.
    Passing the already-fitted boundary engine reuses its verification cache.
    Unique actual conditions may run in bounded workers. ``execution`` records
    scheduling details without changing the report shape or fitting intervals.
    With no context, baseline type estimates remain usable; selected feature
    models have no member predictions until a complete fitted context exists.
    """
    validate_analysis_workers(analysis_workers)
    context = context or {}
    categories = context.get("categorical_features", {})
    categorical_names = list(dict.fromkeys([*categorical_feature_names, *categories]))
    columns = list(context.get("coefficient_columns", []))
    spatial_transform = context.get("spatial_transform")
    spatial_names = {term["name"] for term in spatial_transform["terms"]} if spatial_transform else set()
    selected_names = list(dict.fromkeys([
        *(("x", "y") if use_xy or spatial_transform else ()), *feature_names,
        *(name for name, _ in columns if name not in spatial_names), *categorical_names,
    ]))
    scaling = context.get("numeric_scaling", {})
    model = context.get("model", "instance_features" if selected_names else "type_only")
    baseline = model == "type_only" and not selected_names
    chains = {str(_get(row, "chain_id")): row for row in chain_rows}
    types = {str(_get(row, "tsk_id")): row for row in type_rows}
    type_index = {name: index for index, name in enumerate(context.get("type_ids", []))}
    width = len(context.get("coefficients", []))
    state = context.get("boundary_fit") or {}
    valid = bool(model == "instance_logistic_features"
                 and (context.get("converged") or context.get("partial_fit")) and not context.get("clipped")
                 and (not state or state.get("converged") and not state.get("feature_clipped")))
    fit = None
    initialization_error = (None if model in {"type_only", "instance_logistic_features", "instance_features"}
                            else "该模型已停用，请使用 Logistic 重新运行。")
    if not baseline and context and valid:
        try:
            if boundary_engine is None and joint_engine is None:
                from .tsk_prediction import _FrozenFit
                fit = _FrozenFit(context)
                boundary_engine = fit.boundary_engine
                joint_engine = fit.joint_engine
            engine = joint_engine if joint_engine is not None else boundary_engine
            valid = valid and (fit.valid_fit if fit is not None else bool(
                engine.state.get("converged") or engine.state.get("usable")))
        except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
            if getattr(error, "invalidates_fit", False):
                raise
            valid = False
            initialization_error = str(error)
    parameters = np.asarray(state.get("params", []), dtype=float)
    if joint_engine is not None:
        parameters = np.asarray(joint_engine.state["coefficients"], dtype=float)
    certified_zero_types = set()
    if boundary_engine is not None:
        parameters = np.asarray(boundary_engine.state["params"], dtype=float)
        # With finite shared effects, p=0 for any supported condition of a type
        # means that type's reference odds are zero. Reuse established zero
        # identifiability instead of profiling every category of the same type.
        for query, identified in boundary_engine._identifiable_cache.items():
            index = int(np.argmax(query[:boundary_engine.type_count]))
            if identified and parameters[index] == 0:
                certified_zero_types.add(index)
    cache = {}
    local_common = (fit, boundary_engine, joint_engine, parameters, certified_zero_types)
    started = last_progress = monotonic()
    current_progress = 0
    current_message = "Chain 成员：整理实际实例条件…"
    execution = execution if execution is not None else {}
    execution.update(workers_requested=int(analysis_workers), workers_used=1,
                     execution_backend="serial", execution_warnings=[], worker_pids=[], workers_observed=0,
                     unique_queries=0, cached_queries=0, pilot_queries=0, completed_queries=0)

    def emit(percent, message, *, force=False):
        nonlocal last_progress, current_progress, current_message
        current_progress = max(current_progress, int(percent))
        current_message = message
        now = monotonic()
        if progress_callback is not None and (force or now - last_progress >= 1.):
            last_progress = now
            progress_callback(current_progress, message)

    emit(0, current_message, force=True)
    result = _risk_result

    def predict(tsk_id, vector):
        if baseline:
            row = types.get(tsk_id)
            probability = _number(_get(row, "probability"))
            if row is not None and _get(row, "identifiable", False) and probability is not None:
                return result(probability, identifiable=True,
                              status="boundary_low" if probability == 0 else "ok",
                              estimate_kind="boundary_low" if probability == 0 else _get(row, "estimate_kind", "interior"))
            status = "fit_not_converged" if _get(row, "status") == "fit_not_converged" else "not_identifiable"
            return result(status=status, reason="该 TSK 的单独风险尚未得到可识别的有效估计。")
        if not valid:
            return result(status="fit_not_converged" if context else "unavailable",
                          reason=initialization_error or "尚无有效特征模型，不能把 TSK 参考概率当作实际实例风险。")
        if vector is None:
            return result(status="unavailable", reason="实例的实际特征条件无法按当前模型编码。")
        key = tuple(vector)
        if key not in cache:
            cache[key] = _member_query_task(local_common, key, lambda: emit(current_progress, current_message),
                detail_progress=lambda event: emit(current_progress, joint_progress_message(
                    event, prefix=f"Chain 成员实际条件风险 · {tsk_id} · 条件 {execution['completed_queries'] + 1}/{execution['unique_queries']}"), force=True))
        return deepcopy(cache[key])

    jobs, waiting = {}, []
    members: dict[str, dict[Any, dict[str, Any]]] = {}
    for instance_index, instance in enumerate(instances):
        chain_id, tsk_id = str(_get(instance, "chain_id")), str(_get(instance, "tsk_id"))
        instance_id = str(_get(instance, "instance_id", _get(instance, "tsk_instance_id", "")))
        features = dict(_get(instance, "features", {}) or {})
        emit(5 * instance_index / max(len(instances), 1), f"Chain 成员：整理 {tsk_id} 的实际条件…")
        actual_categories, numeric = {}, {}
        encoded = True
        for name in selected_names:
            value = _get(instance, name) if name in {"x", "y"} else features.get(name)
            if name in categorical_names:
                try:
                    actual_categories[name] = category_label(value, name)
                    if name in categories and actual_categories[name] not in {
                            category_label(level, name) for level in categories[name]["levels"]}:
                        encoded = False
                except ValueError:
                    actual_categories[name] = _plain(value)
                    encoded = False
            else:
                numeric[name] = _number(value)
                encoded = encoded and numeric[name] is not None
        conditions = {name: actual_categories[name] if name in actual_categories else numeric[name] for name in selected_names}
        vector = None
        if not baseline and encoded and tsk_id in type_index:
            derived = {}
            if spatial_transform:
                try:
                    derived = spatial_values(spatial_transform, numeric["x"], numeric["y"])
                except (ValueError, OverflowError):
                    encoded = False
            vector = np.zeros(width)
            vector[type_index[tsk_id]] = 1.
            for index, (name, level) in enumerate(columns, start=len(type_index)):
                if level is None:
                    values = scaling.get(name, {})
                    mean, scale = _number(values.get("mean")), _number(values.get("scale"))
                    raw = derived.get(name) if name in spatial_names else numeric.get(name)
                    if not encoded or mean is None or scale is None or scale <= 0 or raw is None:
                        vector = None
                        break
                    vector[index] = (raw - mean) / scale
                else:
                    vector[index] = float(actual_categories[name] == category_label(level, name))
        # Numeric equality in the fitted design determines aggregation. Keep
        # the selected actual conditions as the display fallback without a fit.
        key = (tsk_id, tuple(vector)) if vector is not None else (
            tsk_id, json.dumps(_plain(conditions), ensure_ascii=False, sort_keys=True))
        if spatial_transform and vector is not None:
            # Symmetric coordinates have equal designs but different actual
            # locations. Do not label both locations with the first one's XY.
            key = (*key, json.dumps(_plain(conditions), ensure_ascii=False, sort_keys=True))
        grouped = members.setdefault(chain_id, {})
        if key in grouped:
            grouped[key]["instance_ids"].append(instance_id)
            grouped[key]["count"] += 1
            continue
        tested = _get(chains.get(chain_id), "n_tested", 0)
        member = {"tsk_id": tsk_id, "instance_ids": [instance_id], "count": 1,
                  "features": conditions, "categories": actual_categories, "numeric": numeric,
                  "condition_scope": "actual_selected_model_features"}
        grouped[key] = member
        if tested and not baseline and valid and vector is not None:
            query_key = tuple(vector)
            jobs.setdefault(query_key, (tsk_id, vector))
            waiting.append((member, query_key))
        else:
            member.update(predict(tsk_id, vector) if tested else result(
                status="no_data", reason="该链没有有效测试数据，成员风险留空。"))

    execution["unique_queries"] = len(jobs)
    emit(5, f"Chain 成员：已整理 {len(instances)} 个实例、{len(jobs)} 个不同实际条件。", force=True)
    try:
        pending = []
        for key, (tsk_id, vector) in jobs.items():
            if _query_already_checked(local_common, key):
                cache[key] = predict(tsk_id, vector)
                execution["cached_queries"] += 1
                execution["completed_queries"] += 1
                emit(5 + 90 * execution["completed_queries"] / max(len(jobs), 1),
                     f"Chain 成员：复用已验证条件 {execution['completed_queries']}/{len(jobs)}。")
            else:
                pending.append(key)
        selected_workers = worker_count(analysis_workers, len(pending))
        # Supplied live engines can also accompany a minimal local context.
        # Workers require the full frozen schema to validate the shared fit.
        frozen_fields = {"version", "design", "chain_index", "chain_ids", "n_tested", "n_failed",
                         "coefficients", "type_ids", "negative_log_likelihood"}
        if not frozen_fields.issubset(context):
            selected_workers = 1
        completed = 0
        pilot_started = monotonic()
        while completed < len(pending):
            if analysis_workers and selected_workers > 1:
                break
            key = pending[completed]
            tsk_id, vector = jobs[key]
            emit(5 + 90 * execution["completed_queries"] / max(len(jobs), 1),
                 f"Chain 成员：复核 {tsk_id} 的实际条件；已完成 {execution['completed_queries']}/{len(jobs)}。", force=True)
            cache[key] = predict(tsk_id, vector)
            completed += 1
            execution["completed_queries"] += 1
            remaining = len(pending) - completed
            elapsed = monotonic() - pilot_started
            if (analysis_workers == 0 and selected_workers > 1 and remaining >= 8
                    and elapsed >= .25 and elapsed * remaining / completed >= 2.):
                selected_workers = min(4, worker_count(0, remaining))
                break
        if completed < len(pending):
            parallel_execution = {}
            prior_state = None
            previously_completed = execution["completed_queries"]

            def parallel_progress(done, total):
                nonlocal prior_state
                backend = parallel_execution.get("execution_backend")
                workers = parallel_execution.get("workers_used", selected_workers)
                if backend == "serial_after_process_failure":
                    state = "子进程失败，剩余条件串行复核"
                elif backend == "serial":
                    state = "串行复核"
                elif parallel_execution.get("phase") == "starting":
                    state = f"启动 {workers} 个进程／等待首个结果"
                else:
                    state = f"{workers} 进程并行复核"
                execution["completed_queries"] = previously_completed + done
                emit(5 + 90 * execution["completed_queries"] / max(len(jobs), 1),
                     f"Chain 成员：{state}；实际条件已完成 {execution['completed_queries']}/{len(jobs)}；"
                     f"已用 {monotonic() - started:.1f}s。", force=state != prior_state)
                prior_state = state

            fitted_context = {key: value for key, value in context.items() if key != "topology"}
            computed = ordered_parallel_map(_member_query_task, pending[completed:],
                common=fitted_context, prepare_common=_prepare_member_queries,
                workers=selected_workers, execution=parallel_execution, progress_callback=parallel_progress)
            cache.update(zip(pending[completed:], computed))
            execution.update(parallel_execution, workers_requested=int(analysis_workers), pilot_queries=completed,
                             completed_queries=len(jobs))
        for member, key in waiting:
            member.update(deepcopy(cache[key]))
    except BaseException as error:
        if getattr(error, "invalidates_fit", False):
            cache.clear()
            _invalidate_member_fit(joint_engine)
            if fit is not None:
                fit.valid_fit = False
                fit._identified_queries.clear()
        raise
    execution.update(completed_queries=len(jobs), elapsed_seconds=monotonic() - started)
    emit(100, f"Chain 成员实际条件风险已准备完成：{len(jobs)} 个不同条件。", force=True)
    from .tsk_sorting import natural_sort_key
    return _plain({chain_id: sorted(grouped.values(), key=lambda row: natural_sort_key(row["tsk_id"]))
                   for chain_id, grouped in sorted(members.items(), key=lambda item: natural_sort_key(item[0]))})
