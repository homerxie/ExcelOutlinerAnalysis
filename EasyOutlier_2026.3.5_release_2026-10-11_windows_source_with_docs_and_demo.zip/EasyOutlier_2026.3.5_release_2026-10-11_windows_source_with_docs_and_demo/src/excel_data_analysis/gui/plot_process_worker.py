"""Spawn-safe tile renderer and compact, shared-memory result transport.

Workers create a QGuiApplication for font rasterization only, never widgets or
the main application. Parent-owned image slots remain leased until the parent
copies (or discards) a completed result. Original parent points are recovered
from numeric lane/point IDs; they never make the return trip through pickle.
"""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from multiprocessing import shared_memory
import os
import struct
import sys
from time import perf_counter
from typing import Any

from PySide6.QtCore import QByteArray, QDataStream, QIODevice, QSize
from PySide6.QtGui import QFont, QGuiApplication, QImage, QPainter

from excel_data_analysis.comparison_models import PlotSeries
from excel_data_analysis.gui.comparison_renderer import (
    ComparisonRenderer,
    PreparedMetric,
    RenderPayload,
)

_HOVER = struct.Struct("<IIddd")
_PIXEL_FORMAT = QImage.Format.Format_RGBA8888_Premultiplied
_PAYLOAD_FIELDS = (
    "labels", "lane_bands", "label_margin", "minimum", "maximum",
    "aggregate_count", "point_count", "outlier_count", "reference_hidden_count",
    "clipped_low_count", "clipped_high_count", "pinned_point_key",
)
_APP: QGuiApplication | None = None
_FONT_DESCRIPTION: str | None = None
_FONT_DATA: bytes | None = None
_FONT_RESOLVE_MASK: int | None = None


def serialize_font(font: QFont) -> bytes:
    """Retain QFont attributes omitted by its human-readable toString form."""
    buffer = QByteArray()
    stream = QDataStream(buffer, QIODevice.OpenModeFlag.WriteOnly)
    stream << font
    return bytes(buffer)


def transport_canvas_width_floor() -> int:
    """Reserve enough shared pixels for the renderer's widest minimum canvas.

    A narrow viewport still needs the complete label margin plus plot area.
    Derive this bound from the renderer so transport cannot silently regress
    to bytes when its layout limits change (currently 420 + 48 + 48 pixels).
    """
    renderer = ComparisonRenderer()
    label_margin = max(renderer._base_label_margin, renderer._max_label_margin)
    return renderer._safe_canvas_width(1, label_margin)


@dataclass(slots=True)
class _MetricEntry:
    series: tuple[PlotSeries, ...]
    prepared: PreparedMetric | None = None


class _ProcessRenderer(ComparisonRenderer):
    """Preserve the native parent's raster-device DPI in the child."""

    def __init__(self, image_dpm: tuple[int, int] | None = None) -> None:
        super().__init__()
        self.image_dpm = image_dpm

    def _make_image(self, width: int, height: int, dpr: float) -> tuple[QImage, QPainter]:
        image = QImage(
            QSize(max(1, int(round(width * dpr))), max(1, int(round(height * dpr)))),
            QImage.Format.Format_ARGB32_Premultiplied,
        )
        image.setDevicePixelRatio(dpr)
        if self.image_dpm is not None:
            image.setDotsPerMeterX(self.image_dpm[0])
            image.setDotsPerMeterY(self.image_dpm[1])
        painter = QPainter(image)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        return image, painter


class RenderState:
    """Bounded raw-series and prepared-statistics cache inside one child."""

    def __init__(self, capacity: int = 32) -> None:
        self.capacity = max(1, capacity)
        self.renderer = ComparisonRenderer()
        self.metrics: OrderedDict[tuple[Any, Any, tuple[str, ...]], _MetricEntry] = OrderedDict()

    def key(self, request: dict[str, Any]) -> tuple[Any, Any, tuple[str, ...]]:
        return request["metric_id"], request.get("generation", 0), tuple(request.get("lane_headers", ()))

    def entry(self, request: dict[str, Any], *, replace: bool = False) -> _MetricEntry:
        key = self.key(request)
        if replace or key not in self.metrics:
            if "series" not in request:
                raise KeyError(f"Metric {key!r} is not cached; include series or prime it first")
            self.metrics[key] = _MetricEntry(tuple(request["series"]))
        self.metrics.move_to_end(key)
        while len(self.metrics) > self.capacity:
            self.metrics.popitem(last=False)
        return self.metrics[key]


_PROCESS_STATE: RenderState | None = None


def _diagnostics(state: RenderState) -> dict[str, Any]:
    return {
        "pid": os.getpid(),
        "cached_metrics": len(state.metrics),
        "prepared_metrics": sum(entry.prepared is not None for entry in state.metrics.values()),
    }


def _ensure_process_qt(platform: str = "offscreen") -> None:
    global _APP
    if QGuiApplication.instance() is None:
        # Set before constructing the application, not at module import: the
        # same module is imported by the native Qt parent for unpacking.
        os.environ["QT_QPA_PLATFORM"] = platform
        if sys.platform == "darwin":
            # Cocoa otherwise promotes each windowless renderer to a foreground
            # application, adding a Python Dock icon and task-switcher entry.
            # Keep native font rendering while leaving these processes hidden.
            os.environ["QT_MAC_DISABLE_FOREGROUND_APPLICATION_TRANSFORM"] = "1"
        _APP = QGuiApplication(["plot-inspector-render-worker"])


def _render(request: dict[str, Any], state: RenderState) -> dict[str, Any]:
    """Prepare and rasterize one request inside its assigned worker."""
    started = perf_counter()
    if QGuiApplication.instance() is None:
        raise RuntimeError("The rendering worker needs a QGuiApplication")
    op = request.get("op", "render")
    if op == "clear":
        state.metrics.clear()
        return {"op": op, **_diagnostics(state), "worker_ms": (perf_counter() - started) * 1000}
    if op == "warmup":
        if request.get("reset", False):
            state.metrics.clear()
        # Actually touch the font database and raster path before reporting
        # warmup complete, while measuring process startup separately outside.
        prepared = state.renderer.prepare_series([], ())
        state.renderer.render_prepared_header(prepared, title="Warmup", width=640, dpr=1.0)
        return {"op": op, **_diagnostics(state), "worker_ms": (perf_counter() - started) * 1000}
    if op == "prime":
        state.entry(request, replace=True)
        return {"op": op, **_diagnostics(state), "worker_ms": (perf_counter() - started) * 1000}
    if op != "render":
        raise ValueError(f"Unknown operation: {op}")

    entry = state.entry(request)
    prepare_started = perf_counter()
    prepared_hit = entry.prepared is not None
    if entry.prepared is None:
        entry.prepared = state.renderer.prepare_series(list(entry.series), tuple(request.get("lane_headers", ())))
    prepare_ms = (perf_counter() - prepare_started) * 1000
    prepared = entry.prepared
    draw_started = perf_counter()
    payload = state.renderer.render_prepared_tile(
        prepared,
        tuple(request.get("lane_indices", range(len(entry.series)))),
        plot_type=request.get("plot_type", "Ridge Plot"),
        lane_height=request.get("lane_height", 30),
        width=request.get("width", 957),
        dpr=request.get("dpr", 2.0),
        range_override=request.get("range_override"),
        pinned_point_key=request.get("pinned_point_key"),
    )
    header = None
    if request.get("include_header", True):
        header = state.renderer.render_prepared_header(
            prepared,
            title=request.get("title", str(request["metric_id"])),
            width=request.get("width", 957),
            dpr=request.get("dpr", 2.0),
            lane_headers=tuple(request.get("lane_headers", ())),
            range_override=request.get("range_override"),
        )
    return {
        "op": op, "payload": payload, "header": header,
        "prepare_ms": prepare_ms,
        "draw_ms": (perf_counter() - draw_started) * 1000,
        "pack_ms": 0.0, "prepared_hit": prepared_hit,
        "base_range": (prepared.minimum, prepared.maximum),
        "worker_ms": (perf_counter() - started) * 1000,
        **_diagnostics(state),
    }


def _pack_hover(payload: RenderPayload, series: tuple[PlotSeries, ...], lane_indices: tuple[int, ...]) -> bytes:
    # References stay in each process. The parent reconnects compact source
    # indices to its own immutable PlotPoint objects instead of unpickling a
    # duplicate graph (and dictionaries) for every repaint.
    locations = {
        id(point): (lane_index, point_index)
        for lane_index in lane_indices
        for point_index, point in enumerate(series[lane_index].points)
    }
    packed = bytearray(_HOVER.size * len(payload.hover_points))
    for index, hover in enumerate(payload.hover_points):
        lane_index, point_index = locations[id(hover.point)]
        _HOVER.pack_into(packed, index * _HOVER.size, lane_index, point_index,
                         hover.position.x(), hover.position.y(), hover.radius)
    return bytes(packed)


def _pack_image(image: QImage, slot: shared_memory.SharedMemory | None, offset: int) -> tuple[dict[str, Any], int]:
    rgba = image.convertToFormat(_PIXEL_FORMAT)
    size = rgba.sizeInBytes()
    meta = {
        "width": rgba.width(), "height": rgba.height(),
        "stride": rgba.bytesPerLine(), "dpr": image.devicePixelRatio(),
        "dpm": (image.dotsPerMeterX(), image.dotsPerMeterY()),
        "size": size, "format": "RGBA8888_Premultiplied",
    }
    if slot is None:
        meta["data"] = bytes(rgba.constBits())
    else:
        if offset + size > slot.size:
            raise ValueError(f"Shared-memory slot needs {offset + size} bytes, has {slot.size}")
        slot.buf[offset:offset + size] = rgba.constBits()
        meta["offset"] = offset
    return meta, offset + size


def process_request(request: dict[str, Any]) -> dict[str, Any]:
    """Entry point submitted to an executor using multiprocessing spawn."""
    global _PROCESS_STATE, _FONT_DESCRIPTION, _FONT_DATA, _FONT_RESOLVE_MASK
    started = perf_counter()
    _ensure_process_qt(request.get("qt_platform", "offscreen"))
    if _PROCESS_STATE is None:
        _PROCESS_STATE = RenderState(request.get("cache_capacity", 32))
        _PROCESS_STATE.renderer = _ProcessRenderer()
    if request.get("reset_cache"):
        _PROCESS_STATE.metrics.clear()
    image_dpm = request.get("image_dpm")
    if image_dpm is not None and tuple(image_dpm) != _PROCESS_STATE.renderer.image_dpm:
        _PROCESS_STATE.renderer.image_dpm = tuple(image_dpm)
        for entry in _PROCESS_STATE.metrics.values():
            entry.prepared = None
    font_description = request.get("font_description")
    font_data = request.get("font_data")
    font_resolve_mask = request.get("font_resolve_mask")
    if font_data is not None and (font_data != _FONT_DATA or font_resolve_mask != _FONT_RESOLVE_MASK):
        font_buffer = QByteArray(font_data)
        stream = QDataStream(font_buffer, QIODevice.OpenModeFlag.ReadOnly)
        font = QFont()
        stream >> font
        if font_resolve_mask is not None:
            # QDataStream restores values but marks every attribute explicit.
            # Preserve which values inherited the platform/application font.
            font.setResolveMask(font_resolve_mask)
        QGuiApplication.setFont(font)
        _FONT_DATA = font_data
        _FONT_RESOLVE_MASK = font_resolve_mask
        for entry in _PROCESS_STATE.metrics.values():
            entry.prepared = None
    elif font_data is None and font_description and font_description != _FONT_DESCRIPTION:
        font = QFont()
        if not font.fromString(font_description):
            raise ValueError("Invalid font_description")
        QGuiApplication.setFont(font)
        _FONT_DESCRIPTION = font_description
        # Font metrics affect label widths and column layout.
        for entry in _PROCESS_STATE.metrics.values():
            entry.prepared = None
    result = _render(request, _PROCESS_STATE)
    if result["op"] != "render":
        result["worker_ms"] = (perf_counter() - started) * 1000
        return result

    pack_started = perf_counter()
    payload: RenderPayload = result.pop("payload")
    header: QImage | None = result.pop("header")
    entry = _PROCESS_STATE.entry(request)
    lane_indices = tuple(request.get("lane_indices", range(len(entry.series))))
    result["hover"] = _pack_hover(payload, entry.series, lane_indices)
    result["payload_meta"] = {field: getattr(payload, field) for field in _PAYLOAD_FIELDS}
    slot = None
    try:
        if request.get("shm_name"):
            slot = shared_memory.SharedMemory(name=request["shm_name"])
            capacity = request.get("shm_capacity", slot.size)
            expected_size = payload.image.sizeInBytes() + (header.sizeInBytes() if header else 0)
            if expected_size > min(capacity, slot.size):
                # Unusual device sizes must not turn into a retry loop. The
                # normal path sizes the slot exactly; bytes remain a fallback.
                slot.close()
                slot = None
            else:
                result["shm_name"] = slot.name
        result["image"], offset = _pack_image(payload.image, slot, 0)
        result["header"] = None
        if header is not None:
            result["header"], offset = _pack_image(header, slot, offset)
        result["image_bytes"] = offset
        result["hover_bytes"] = len(result["hover"])
    finally:
        if slot is not None:
            slot.close()
    result["pack_ms"] = (perf_counter() - pack_started) * 1000
    result["worker_ms"] = (perf_counter() - started) * 1000
    result.update(_diagnostics(_PROCESS_STATE))
    return result


def _unpack_image(meta: dict[str, Any], slot: shared_memory.SharedMemory | None) -> QImage:
    if slot is None:
        buffer = meta["data"]
    else:
        offset = meta["offset"]
        buffer = slot.buf[offset:offset + meta["size"]]
    # Detach before the slot is reused or bytes dictionaries are discarded.
    try:
        image = QImage(buffer, meta["width"], meta["height"], meta["stride"], _PIXEL_FORMAT).copy()
        image.setDevicePixelRatio(meta["dpr"])
        image.setDotsPerMeterX(meta["dpm"][0])
        image.setDotsPerMeterY(meta["dpm"][1])
    finally:
        if isinstance(buffer, memoryview):
            buffer.release()
    return image


def unpack_compact_result(wire: dict[str, Any], series: tuple[PlotSeries, ...]):
    """Detach shared pixels and build numeric hover arrays in the GUI process."""
    from .plot_hover_index import CompactHoverIndex, CompactPayload

    if wire["op"] != "render":
        raise ValueError("Only render results contain a payload")
    slot = None
    try:
        if wire.get("shm_name"):
            slot = shared_memory.SharedMemory(name=wire["shm_name"])
        image = _unpack_image(wire["image"], slot)
        header = _unpack_image(wire["header"], slot) if wire["header"] is not None else None
    finally:
        if slot is not None:
            slot.close()
    payload = CompactPayload(image, CompactHoverIndex(wire["hover"], series), wire["payload_meta"])
    return payload, header


decode_result = unpack_compact_result
