# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'outlier_export_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QDialog,
    QGroupBox, QHBoxLayout, QLabel, QListWidget,
    QListWidgetItem, QPushButton, QRadioButton, QSizePolicy,
    QSpacerItem, QVBoxLayout, QWidget)

class Ui_OutlierExportDialog(object):
    def setupUi(self, OutlierExportDialog):
        if not OutlierExportDialog.objectName():
            OutlierExportDialog.setObjectName(u"OutlierExportDialog")
        OutlierExportDialog.resize(720, 580)
        OutlierExportDialog.setMinimumSize(QSize(620, 500))
        self.verticalLayout = QVBoxLayout(OutlierExportDialog)
        self.verticalLayout.setSpacing(12)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(18, 18, 18, 18)
        self.descriptionLabel = QLabel(OutlierExportDialog)
        self.descriptionLabel.setObjectName(u"descriptionLabel")
        self.descriptionLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.descriptionLabel)

        self.scopeGroupBox = QGroupBox(OutlierExportDialog)
        self.scopeGroupBox.setObjectName(u"scopeGroupBox")
        self.scopeLayout = QVBoxLayout(self.scopeGroupBox)
        self.scopeLayout.setSpacing(10)
        self.scopeLayout.setObjectName(u"scopeLayout")
        self.allResultsRadioButton = QRadioButton(self.scopeGroupBox)
        self.allResultsRadioButton.setObjectName(u"allResultsRadioButton")
        self.allResultsRadioButton.setChecked(True)

        self.scopeLayout.addWidget(self.allResultsRadioButton)

        self.newChainsRadioButton = QRadioButton(self.scopeGroupBox)
        self.newChainsRadioButton.setObjectName(u"newChainsRadioButton")

        self.scopeLayout.addWidget(self.newChainsRadioButton)

        self.newSamplesRadioButton = QRadioButton(self.scopeGroupBox)
        self.newSamplesRadioButton.setObjectName(u"newSamplesRadioButton")

        self.scopeLayout.addWidget(self.newSamplesRadioButton)


        self.verticalLayout.addWidget(self.scopeGroupBox)

        self.nodesGroupBox = QGroupBox(OutlierExportDialog)
        self.nodesGroupBox.setObjectName(u"nodesGroupBox")
        self.nodesGroupBox.setEnabled(False)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        sizePolicy.setHeightForWidth(self.nodesGroupBox.sizePolicy().hasHeightForWidth())
        self.nodesGroupBox.setSizePolicy(sizePolicy)
        self.nodesLayout = QVBoxLayout(self.nodesGroupBox)
        self.nodesLayout.setSpacing(8)
        self.nodesLayout.setObjectName(u"nodesLayout")
        self.selectAllCheckBox = QCheckBox(self.nodesGroupBox)
        self.selectAllCheckBox.setObjectName(u"selectAllCheckBox")
        self.selectAllCheckBox.setChecked(True)
        self.selectAllCheckBox.setTristate(True)

        self.nodesLayout.addWidget(self.selectAllCheckBox)

        self.nodesListWidget = QListWidget(self.nodesGroupBox)
        self.nodesListWidget.setObjectName(u"nodesListWidget")
        sizePolicy.setHeightForWidth(self.nodesListWidget.sizePolicy().hasHeightForWidth())
        self.nodesListWidget.setSizePolicy(sizePolicy)
        self.nodesListWidget.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.nodesListWidget.setAlternatingRowColors(True)
        self.nodesListWidget.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        self.nodesLayout.addWidget(self.nodesListWidget)


        self.verticalLayout.addWidget(self.nodesGroupBox)

        self.historyLabel = QLabel(OutlierExportDialog)
        self.historyLabel.setObjectName(u"historyLabel")
        self.historyLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.historyLabel)

        self.selectionSummaryLabel = QLabel(OutlierExportDialog)
        self.selectionSummaryLabel.setObjectName(u"selectionSummaryLabel")
        self.selectionSummaryLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.selectionSummaryLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.selectionSummaryLabel)

        self.buttonLayout = QHBoxLayout()
        self.buttonLayout.setSpacing(8)
        self.buttonLayout.setObjectName(u"buttonLayout")
        self.buttonSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.buttonLayout.addItem(self.buttonSpacer)

        self.cancelButton = QPushButton(OutlierExportDialog)
        self.cancelButton.setObjectName(u"cancelButton")
        self.cancelButton.setAutoDefault(False)

        self.buttonLayout.addWidget(self.cancelButton)

        self.exportButton = QPushButton(OutlierExportDialog)
        self.exportButton.setObjectName(u"exportButton")

        self.buttonLayout.addWidget(self.exportButton)


        self.verticalLayout.addLayout(self.buttonLayout)

        QWidget.setTabOrder(self.allResultsRadioButton, self.newChainsRadioButton)
        QWidget.setTabOrder(self.newChainsRadioButton, self.newSamplesRadioButton)
        QWidget.setTabOrder(self.newSamplesRadioButton, self.selectAllCheckBox)
        QWidget.setTabOrder(self.selectAllCheckBox, self.nodesListWidget)
        QWidget.setTabOrder(self.nodesListWidget, self.exportButton)
        QWidget.setTabOrder(self.exportButton, self.cancelButton)

        self.retranslateUi(OutlierExportDialog)

        self.exportButton.setDefault(True)


        QMetaObject.connectSlotsByName(OutlierExportDialog)
    # setupUi

    def retranslateUi(self, OutlierExportDialog):
        OutlierExportDialog.setWindowTitle(QCoreApplication.translate("OutlierExportDialog", u"Export Outlier Excel", None))
        OutlierExportDialog.setProperty(u"beforeAnalysisWindowTitle", QCoreApplication.translate("OutlierExportDialog", u"Run Analysis - Outlier Export Scope", None))
        OutlierExportDialog.setProperty(u"beforeAnalysisConfirmText", QCoreApplication.translate("OutlierExportDialog", u"Run Analysis", None))
        OutlierExportDialog.setProperty(u"beforeAnalysisDescriptionText", QCoreApplication.translate("OutlierExportDialog", u"Analysis has not started. Choose the results to include in Outlier Excel, then run analysis. Export choices do not filter the analysis or change its scope and settings.", None))
        OutlierExportDialog.setProperty(u"allSummaryText", QCoreApplication.translate("OutlierExportDialog", u"Export all outlier results with their full node history.", None))
        OutlierExportDialog.setProperty(u"chainsSummaryText", QCoreApplication.translate("OutlierExportDialog", u"{count} node(s) selected. Export only sample + chain pairs with New failures at these nodes, including every earlier and later node for those pairs.", None))
        OutlierExportDialog.setProperty(u"samplesSummaryText", QCoreApplication.translate("OutlierExportDialog", u"{count} node(s) selected. For samples with New failures at these nodes, export all their failing chains, including every earlier and later node.", None))
        OutlierExportDialog.setProperty(u"missingNodesText", QCoreApplication.translate("OutlierExportDialog", u"Select at least one node to export the focused results.", None))
        OutlierExportDialog.setProperty(u"emptyNodesText", QCoreApplication.translate("OutlierExportDialog", u"No analysis nodes are available. Select All outlier results to export.", None))
        self.descriptionLabel.setText(QCoreApplication.translate("OutlierExportDialog", u"Choose which results to include in the Excel file. This only changes the export; the completed analysis and its summary statistics stay unchanged.", None))
        self.scopeGroupBox.setTitle(QCoreApplication.translate("OutlierExportDialog", u"Export scope", None))
        self.allResultsRadioButton.setText(QCoreApplication.translate("OutlierExportDialog", u"All outlier results", None))
        self.newChainsRadioButton.setText(QCoreApplication.translate("OutlierExportDialog", u"Only sample + chain pairs with New at selected nodes", None))
        self.newSamplesRadioButton.setText(QCoreApplication.translate("OutlierExportDialog", u"Samples with New at selected nodes: all their failing chains", None))
        self.nodesGroupBox.setTitle(QCoreApplication.translate("OutlierExportDialog", u"Nodes to check for New failures", None))
        self.selectAllCheckBox.setText(QCoreApplication.translate("OutlierExportDialog", u"Select All Nodes", None))
#if QT_CONFIG(accessibility)
        self.nodesListWidget.setAccessibleName(QCoreApplication.translate("OutlierExportDialog", u"Nodes to check for New failures", None))
#endif // QT_CONFIG(accessibility)
        self.historyLabel.setText(QCoreApplication.translate("OutlierExportDialog", u"The selected nodes identify the samples and chains to include. Their full before/after node history is retained in the export.", None))
        self.selectionSummaryLabel.setText(QCoreApplication.translate("OutlierExportDialog", u"Export all outlier results with their full node history.", None))
        self.cancelButton.setText(QCoreApplication.translate("OutlierExportDialog", u"Cancel", None))
        self.exportButton.setText(QCoreApplication.translate("OutlierExportDialog", u"Export Excel", None))
    # retranslateUi

