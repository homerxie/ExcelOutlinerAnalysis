# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'analysis_output_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QDialog, QGroupBox,
    QHBoxLayout, QLabel, QPushButton, QSizePolicy,
    QSpacerItem, QVBoxLayout, QWidget)

class Ui_AnalysisOutputDialog(object):
    def setupUi(self, AnalysisOutputDialog):
        if not AnalysisOutputDialog.objectName():
            AnalysisOutputDialog.setObjectName(u"AnalysisOutputDialog")
        AnalysisOutputDialog.resize(600, 350)
        AnalysisOutputDialog.setMinimumSize(QSize(520, 340))
        self.verticalLayout = QVBoxLayout(AnalysisOutputDialog)
        self.verticalLayout.setSpacing(12)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(18, 18, 18, 18)
        self.descriptionLabel = QLabel(AnalysisOutputDialog)
        self.descriptionLabel.setObjectName(u"descriptionLabel")
        self.descriptionLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.descriptionLabel)

        self.exportsGroupBox = QGroupBox(AnalysisOutputDialog)
        self.exportsGroupBox.setObjectName(u"exportsGroupBox")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.exportsGroupBox.sizePolicy().hasHeightForWidth())
        self.exportsGroupBox.setSizePolicy(sizePolicy)
        self.exportsLayout = QVBoxLayout(self.exportsGroupBox)
        self.exportsLayout.setSpacing(10)
        self.exportsLayout.setObjectName(u"exportsLayout")
        self.outlierCheckBox = QCheckBox(self.exportsGroupBox)
        self.outlierCheckBox.setObjectName(u"outlierCheckBox")
        self.outlierCheckBox.setChecked(True)

        self.exportsLayout.addWidget(self.outlierCheckBox)

        self.dataCheckBox = QCheckBox(self.exportsGroupBox)
        self.dataCheckBox.setObjectName(u"dataCheckBox")
        self.dataCheckBox.setChecked(True)

        self.exportsLayout.addWidget(self.dataCheckBox)


        self.verticalLayout.addWidget(self.exportsGroupBox)

        self.analysisScopeLabel = QLabel(AnalysisOutputDialog)
        self.analysisScopeLabel.setObjectName(u"analysisScopeLabel")
        self.analysisScopeLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.analysisScopeLabel)

        self.outlierScopeLabel = QLabel(AnalysisOutputDialog)
        self.outlierScopeLabel.setObjectName(u"outlierScopeLabel")
        self.outlierScopeLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.outlierScopeLabel)

        self.verticalSpacer = QSpacerItem(20, 12, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.buttonLayout = QHBoxLayout()
        self.buttonLayout.setSpacing(8)
        self.buttonLayout.setObjectName(u"buttonLayout")
        self.buttonSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.buttonLayout.addItem(self.buttonSpacer)

        self.cancelButton = QPushButton(AnalysisOutputDialog)
        self.cancelButton.setObjectName(u"cancelButton")
        self.cancelButton.setAutoDefault(False)

        self.buttonLayout.addWidget(self.cancelButton)

        self.runButton = QPushButton(AnalysisOutputDialog)
        self.runButton.setObjectName(u"runButton")

        self.buttonLayout.addWidget(self.runButton)


        self.verticalLayout.addLayout(self.buttonLayout)

        QWidget.setTabOrder(self.outlierCheckBox, self.dataCheckBox)
        QWidget.setTabOrder(self.dataCheckBox, self.runButton)
        QWidget.setTabOrder(self.runButton, self.cancelButton)

        self.retranslateUi(AnalysisOutputDialog)
        self.runButton.clicked.connect(AnalysisOutputDialog.accept)
        self.cancelButton.clicked.connect(AnalysisOutputDialog.reject)

        self.runButton.setDefault(True)


        QMetaObject.connectSlotsByName(AnalysisOutputDialog)
    # setupUi

    def retranslateUi(self, AnalysisOutputDialog):
        AnalysisOutputDialog.setWindowTitle(QCoreApplication.translate("AnalysisOutputDialog", u"Run Analysis", None))
        self.descriptionLabel.setText(QCoreApplication.translate("AnalysisOutputDialog", u"Both Excel exports are selected by default. Clear either option to skip that export, or clear both to run analysis only. You can export later from the results.", None))
        self.exportsGroupBox.setTitle(QCoreApplication.translate("AnalysisOutputDialog", u"Export after analysis", None))
        self.outlierCheckBox.setText(QCoreApplication.translate("AnalysisOutputDialog", u"Outlier Excel", None))
        self.dataCheckBox.setText(QCoreApplication.translate("AnalysisOutputDialog", u"Data Excel", None))
        self.analysisScopeLabel.setText(QCoreApplication.translate("AnalysisOutputDialog", u"Analysis uses your current analysis scope and settings in full. These output choices do not filter or change the analysis.", None))
        self.outlierScopeLabel.setText(QCoreApplication.translate("AnalysisOutputDialog", u"Before analysis starts, confirm the Outlier export scope (if selected) and any existing-file conflicts. After analysis finishes, the selected Excel files are exported automatically.", None))
        self.cancelButton.setText(QCoreApplication.translate("AnalysisOutputDialog", u"Cancel", None))
        self.runButton.setText(QCoreApplication.translate("AnalysisOutputDialog", u"Run Analysis", None))
    # retranslateUi

