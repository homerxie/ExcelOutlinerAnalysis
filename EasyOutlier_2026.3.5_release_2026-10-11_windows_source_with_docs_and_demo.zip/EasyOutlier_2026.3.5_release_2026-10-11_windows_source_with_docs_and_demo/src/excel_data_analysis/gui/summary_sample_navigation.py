"""Individually painted sample links, without a widget per cell or a picker."""
from __future__ import annotations

from collections import OrderedDict
from bisect import bisect_right
from dataclasses import dataclass

from PySide6.QtCore import QEvent, QItemSelectionModel, QObject, QPointF, QPersistentModelIndex, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QCursor, QFontMetrics, QPalette, QTextCharFormat, QTextLayout, QTextOption
from PySide6.QtWidgets import QStyle, QStyledItemDelegate, QStyleOptionViewItem, QToolTip


@dataclass(slots=True)
class _LinkText:
    layout: QTextLayout
    regions: tuple[tuple[QRectF, dict], ...]
    width: float
    height: float
    parts: tuple
    starts: tuple[float, ...]


def _utf16_length(text):
    return len(text.encode("utf-16-le")) // 2


class SampleLinkDelegate(QStyledItemDelegate):
    """Use the same shaped text for painting, cursor feedback and hit testing."""

    def __init__(self, table, model):
        super().__init__(table)
        self.table, self.model = table, model
        self._layouts = OrderedDict()
        model.modelReset.connect(self._layouts.clear)
        model.dataChanged.connect(lambda *_: self._layouts.clear())

    def _option(self, index):
        option = QStyleOptionViewItem()
        option.initFrom(self.table)
        option.font = self.table.font()
        option.fontMetrics = QFontMetrics(option.font, self.table.viewport())
        option.widget = self.table
        option.rect = self.table.visualRect(index)
        self.initStyleOption(option, index)
        if self.table.selectionModel().isSelected(index):
            option.state |= QStyle.State_Selected
        return option

    def _text(self, index, option):
        resolved = self.model.sample_links(index)
        if not resolved:
            return None
        _, parts = resolved
        selected = bool(option.state & QStyle.State_Selected)
        underline = bool(self.table.property("sampleLinkUnderline"))
        key = (id(parts), index.column(), option.font.key(), self.table.viewport().devicePixelRatioF(), option.palette.cacheKey(), selected,
               bool(option.state & QStyle.State_Enabled), option.direction, underline)
        if key in self._layouts:
            self._layouts.move_to_end(key)
            return self._layouts[key]
        segments, spans = [], []
        position = 0
        for part in parts:
            if segments:
                segments.append(";")
                position += 1
            label = part["label"]
            size = _utf16_length(label)
            if part["target"] is not None:
                spans.append((position, size, part["target"]))
            segments.extend((label, part["plain_suffix"]))
            position += size + _utf16_length(part["plain_suffix"])
        text = "".join(segments)
        layout = QTextLayout(text, option.font, self.table.viewport())
        text_option = QTextOption()
        text_option.setWrapMode(QTextOption.NoWrap)
        text_option.setTextDirection(option.direction)
        layout.setTextOption(text_option)
        group = QPalette.Normal if option.state & QStyle.State_Enabled else QPalette.Disabled
        ordinary = option.palette.color(group, QPalette.HighlightedText if selected else QPalette.Text)
        link = option.palette.color(group, QPalette.HighlightedText if selected else QPalette.Link)
        plain_format = QTextCharFormat()
        plain_format.setFontUnderline(False)
        plain_format.setForeground(ordinary)
        whole = QTextLayout.FormatRange()
        whole.start, whole.length, whole.format = 0, position, plain_format
        formats = [whole]
        for start, size, _ in spans:
            fmt = QTextCharFormat()
            fmt.setForeground(link)
            fmt.setFontUnderline(underline)
            span = QTextLayout.FormatRange()
            span.start, span.length, span.format = start, size, fmt
            formats.append(span)
        layout.setFormats(formats)
        layout.setCacheEnabled(True)
        layout.beginLayout()
        line = layout.createLine()
        line.setLineWidth(max(1., option.fontMetrics.horizontalAdvance(text) + 1.))
        layout.endLayout()
        regions = []
        for start, size, target in spans:
            left, right = line.cursorToX(start)[0], line.cursorToX(start + size)[0]
            regions.append((QRectF(min(left, right), 0, abs(right - left), line.height()), target))
        regions.sort(key=lambda item: item[0].left())
        result = _LinkText(layout, tuple(regions), line.naturalTextWidth(), line.height(), parts,
                           tuple(rect.left() for rect, _ in regions))
        self._layouts[key] = result
        while len(self._layouts) > 128:
            self._layouts.popitem(last=False)
        return result

    def _origin(self, option, text):
        margin = int(self.table.property("sampleLinkTextMargin") or 0)
        return QPointF(option.rect.left() + margin, option.rect.top() + max(0., (option.rect.height() - text.height) / 2))

    def link_regions(self, index):
        """Return visible link rectangles in viewport coordinates and exact targets."""
        if not index.isValid():
            return ()
        option = self._option(index)
        text = self._text(index, option)
        if text is None:
            return ()
        origin = self._origin(option, text)
        clip = QRectF(option.rect).intersected(QRectF(self.table.viewport().rect()))
        return tuple((rect.translated(origin).intersected(clip), target) for rect, target in text.regions
                     if rect.translated(origin).intersects(clip))

    def target_at(self, index, position):
        if not index.isValid():
            return None
        option = self._option(index)
        text = self._text(index, option)
        if text is None or not QRectF(option.rect).contains(position):
            return None
        local = position - self._origin(option, text)
        offset = bisect_right(text.starts, local.x()) - 1
        if offset >= 0:
            rect, target = text.regions[offset]
            if rect.contains(local) and local.x() < rect.right():
                return target
        return None

    def paint(self, painter, option, index):
        prepared = QStyleOptionViewItem(option)
        self.initStyleOption(prepared, index)
        text = self._text(index, prepared)
        if text is None:
            super().paint(painter, option, index)
            return
        prepared.text = ""
        self.table.style().drawControl(QStyle.CE_ItemViewItem, prepared, painter, self.table)
        painter.save()
        painter.setClipRect(option.rect)
        text.layout.draw(painter, self._origin(prepared, text))
        painter.restore()

    def sizeHint(self, option, index):
        prepared = QStyleOptionViewItem(option)
        self.initStyleOption(prepared, index)
        text = self._text(index, prepared)
        size = super().sizeHint(option, index)
        if text is not None:
            margin = int(self.table.property("sampleLinkTextMargin") or 0)
            size = QSize(max(size.width(), int(text.width + 2 * margin + 1)), max(size.height(), int(text.height + 1)))
        return size


class OutlierSampleNavigator(QObject):
    sampleActivated = Signal(object, object)

    def __init__(self, table, model, parent=None):
        super().__init__(parent or table)
        self.table, self.model = table, model
        self.viewport = table.viewport()
        self.delegate = SampleLinkDelegate(table, model)
        table.setItemDelegate(self.delegate)
        self._disposed = False
        self._pressed = None
        table.destroyed.connect(self._dispose)
        self.viewport.installEventFilter(self)
        table.installEventFilter(self)
        table.verticalScrollBar().valueChanged.connect(self._refresh_cursor)
        table.horizontalScrollBar().valueChanged.connect(self._refresh_cursor)
        table.horizontalHeader().sectionResized.connect(self._refresh_cursor)
        model.modelReset.connect(self._reset)
        model.layoutChanged.connect(self._refresh_cursor)
        model.dataChanged.connect(self._refresh_cursor)

    def link_at(self, position):
        index = self.table.indexAt(position.toPoint() if isinstance(position, QPointF) else position)
        target = self.delegate.target_at(index, QPointF(position))
        if target is not None:
            resolved = self.model.sample_links(index)
            if resolved:
                return index, resolved[0], target
        return None

    def _refresh_cursor(self, *args):
        if self._disposed:
            return
        position = self.viewport.mapFromGlobal(QCursor.pos())
        actionable = self.viewport.rect().contains(position) and self.link_at(position)
        self.viewport.setCursor(Qt.PointingHandCursor if actionable else Qt.ArrowCursor)

    def _reset(self):
        self._pressed = None
        self._refresh_cursor()

    def eventFilter(self, watched, event):
        if self._disposed:
            return False
        if watched is self.viewport:
            kind = event.type()
            if kind == QEvent.MouseMove:
                watched.setCursor(Qt.PointingHandCursor if self.link_at(event.position()) else Qt.ArrowCursor)
            elif kind == QEvent.Leave:
                watched.setCursor(Qt.ArrowCursor)
            elif kind == QEvent.MouseButtonPress:
                link = self.link_at(event.position()) if event.button() == Qt.LeftButton else None
                self._pressed = (QPersistentModelIndex(link[0]), link[2]) if link else None
                if link:
                    # QTableView can auto-scroll a wide cell on selection and
                    # move a different identifier under the release position.
                    # Select the row without changing the current cell/scroll.
                    self.table.selectionModel().select(link[0], QItemSelectionModel.ClearAndSelect | QItemSelectionModel.Rows)
                    event.accept()
                    return True
            elif kind == QEvent.MouseButtonRelease:
                link = self.link_at(event.position()) if event.button() == Qt.LeftButton else None
                pressed, self._pressed = self._pressed, None
                if pressed:
                    if link and pressed[0] == link[0] and pressed[1] is link[2]:
                        self.activate(link[0], link[2])
                    event.accept()
                    return True
            elif kind == QEvent.ToolTip:
                link = self.link_at(event.pos())
                if link:
                    details = " | ".join(f"{key}: {value}" for key, value in link[2]["conditions"].items())
                    QToolTip.showText(event.globalPos(), f"{self.table.property('sampleLinkToolTip')}\n{details}", self.viewport)
                    return True
                if self.model.sample_links(self.table.indexAt(event.pos())):
                    QToolTip.hideText()
                    return True
        if watched is self.table:
            if event.type() == QEvent.KeyPress and event.key() in (Qt.Key_Return, Qt.Key_Enter):
                if self.activate(self.table.currentIndex()):
                    return True
            elif event.type() in (QEvent.FontChange, QEvent.StyleChange, QEvent.PaletteChange, QEvent.DevicePixelRatioChange):
                self.delegate._layouts.clear()
                self._refresh_cursor()
        return super().eventFilter(watched, event)

    def _dispose(self, *args):
        self._disposed = True
        self._pressed = None

    def activate(self, index, target=None):
        resolved = self.model.sample_links(index)
        if not resolved:
            return False
        navigation, parts = resolved
        targets = [part["target"] for part in parts if part["target"] is not None]
        if target is None:
            if len(targets) != 1:
                return False
            target = targets[0]
        if not any(item is target for item in targets):
            return False
        self.sampleActivated.emit(navigation, target)
        return True
