# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ratio_column_filter_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QAbstractItemView, QApplication, QCheckBox,
    QDialog, QDialogButtonBox, QHBoxLayout, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QPushButton,
    QSizePolicy, QVBoxLayout, QWidget)

class Ui_RatioColumnFilterDialog(object):
    def setupUi(self, RatioColumnFilterDialog):
        if not RatioColumnFilterDialog.objectName():
            RatioColumnFilterDialog.setObjectName(u"RatioColumnFilterDialog")
        RatioColumnFilterDialog.resize(340, 420)
        RatioColumnFilterDialog.setMinimumSize(QSize(320, 340))
        RatioColumnFilterDialog.setWindowFlags(Qt.WindowType.Popup)
        self.filterLayout = QVBoxLayout(RatioColumnFilterDialog)
        self.filterLayout.setSpacing(8)
        self.filterLayout.setObjectName(u"filterLayout")
        self.filterLayout.setContentsMargins(12, 12, 12, 12)
        self.columnNameLabel = QLabel(RatioColumnFilterDialog)
        self.columnNameLabel.setObjectName(u"columnNameLabel")
        self.columnNameLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.columnNameLabel.setWordWrap(True)

        self.filterLayout.addWidget(self.columnNameLabel)

        self.sortLayout = QHBoxLayout()
        self.sortLayout.setSpacing(8)
        self.sortLayout.setObjectName(u"sortLayout")
        self.sortAscendingButton = QPushButton(RatioColumnFilterDialog)
        self.sortAscendingButton.setObjectName(u"sortAscendingButton")
        self.sortAscendingButton.setAutoDefault(False)

        self.sortLayout.addWidget(self.sortAscendingButton)

        self.sortDescendingButton = QPushButton(RatioColumnFilterDialog)
        self.sortDescendingButton.setObjectName(u"sortDescendingButton")
        self.sortDescendingButton.setAutoDefault(False)

        self.sortLayout.addWidget(self.sortDescendingButton)


        self.filterLayout.addLayout(self.sortLayout)

        self.clearColumnButton = QPushButton(RatioColumnFilterDialog)
        self.clearColumnButton.setObjectName(u"clearColumnButton")
        self.clearColumnButton.setAutoDefault(False)

        self.filterLayout.addWidget(self.clearColumnButton)

        self.searchLineEdit = QLineEdit(RatioColumnFilterDialog)
        self.searchLineEdit.setObjectName(u"searchLineEdit")
        self.searchLineEdit.setClearButtonEnabled(True)

        self.filterLayout.addWidget(self.searchLineEdit)

        self.selectAllCheckBox = QCheckBox(RatioColumnFilterDialog)
        self.selectAllCheckBox.setObjectName(u"selectAllCheckBox")
        self.selectAllCheckBox.setChecked(True)
        self.selectAllCheckBox.setTristate(True)

        self.filterLayout.addWidget(self.selectAllCheckBox)

        self.valuesListWidget = QListWidget(RatioColumnFilterDialog)
        self.valuesListWidget.setObjectName(u"valuesListWidget")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        sizePolicy.setHeightForWidth(self.valuesListWidget.sizePolicy().hasHeightForWidth())
        self.valuesListWidget.setSizePolicy(sizePolicy)
        self.valuesListWidget.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.valuesListWidget.setAlternatingRowColors(True)
        self.valuesListWidget.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        self.filterLayout.addWidget(self.valuesListWidget)

        self.noResultsLabel = QLabel(RatioColumnFilterDialog)
        self.noResultsLabel.setObjectName(u"noResultsLabel")
        self.noResultsLabel.setVisible(False)
        self.noResultsLabel.setWordWrap(True)

        self.filterLayout.addWidget(self.noResultsLabel)

        self.buttonBox = QDialogButtonBox(RatioColumnFilterDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setOrientation(Qt.Orientation.Horizontal)
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)

        self.filterLayout.addWidget(self.buttonBox)

        QWidget.setTabOrder(self.searchLineEdit, self.selectAllCheckBox)
        QWidget.setTabOrder(self.selectAllCheckBox, self.valuesListWidget)
        QWidget.setTabOrder(self.valuesListWidget, self.sortAscendingButton)
        QWidget.setTabOrder(self.sortAscendingButton, self.sortDescendingButton)
        QWidget.setTabOrder(self.sortDescendingButton, self.clearColumnButton)

        self.retranslateUi(RatioColumnFilterDialog)
        self.buttonBox.accepted.connect(RatioColumnFilterDialog.accept)
        self.buttonBox.rejected.connect(RatioColumnFilterDialog.reject)

        QMetaObject.connectSlotsByName(RatioColumnFilterDialog)
    # setupUi

    def retranslateUi(self, RatioColumnFilterDialog):
        RatioColumnFilterDialog.setWindowTitle(QCoreApplication.translate("RatioColumnFilterDialog", u"Column Filter", None))
        RatioColumnFilterDialog.setProperty(u"blankText", QCoreApplication.translate("RatioColumnFilterDialog", u"(Blanks)", None))
        self.columnNameLabel.setText(QCoreApplication.translate("RatioColumnFilterDialog", u"Column", None))
        self.sortAscendingButton.setText(QCoreApplication.translate("RatioColumnFilterDialog", u"Sort Ascending", None))
        self.sortDescendingButton.setText(QCoreApplication.translate("RatioColumnFilterDialog", u"Sort Descending", None))
        self.clearColumnButton.setText(QCoreApplication.translate("RatioColumnFilterDialog", u"Clear Column Filter", None))
        self.searchLineEdit.setPlaceholderText(QCoreApplication.translate("RatioColumnFilterDialog", u"Search values", None))
        self.selectAllCheckBox.setText(QCoreApplication.translate("RatioColumnFilterDialog", u"Select All", None))
        self.noResultsLabel.setText(QCoreApplication.translate("RatioColumnFilterDialog", u"No matching values", None))
    # retranslateUi

