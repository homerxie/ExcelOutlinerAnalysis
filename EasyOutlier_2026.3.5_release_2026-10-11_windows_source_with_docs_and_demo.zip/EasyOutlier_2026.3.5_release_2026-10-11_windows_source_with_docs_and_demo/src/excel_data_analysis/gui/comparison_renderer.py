from __future__ import annotations

import math
import sys
from bisect import bisect_left, bisect_right
from collections import defaultdict
from dataclasses import dataclass

from PySide6.QtCore import QPointF, QRectF, QSize, Qt
from PySide6.QtGui import QColor, QImage, QPainter, QPainterPath, QPen, QPixmap

from ..comparison_models import PlotPoint, PlotSeries


def _axis_tick_labels(minimum: float, maximum: float) -> tuple[str, ...]:
    """Keep the familiar short labels until zoom needs additional precision."""
    if not math.isfinite(minimum) or not math.isfinite(maximum) or minimum > maximum:
        raise ValueError("Axis bounds must be finite and ordered.")
    span = maximum - minimum
    if math.isfinite(span):
        values = [minimum + span * (index / 4.0) for index in range(5)]
    else:
        # Opposite, finite bounds near the float limit can overflow subtraction.
        values = [minimum * (1 - index / 4.0) + maximum * (index / 4.0) for index in range(5)]
    values[0], values[-1] = minimum, maximum
    values = [0.0 if value == 0 else value for value in values]
    distinguishable = len(set(values))
    for precision in range(3, 18):
        labels = tuple(f"{value:.{precision}g}" for value in values)
        if len(set(labels)) == distinguishable:
            break
    # At a span of only one or two ULPs, five distinct numerical ticks do not
    # exist. Leave redundant labels blank instead of implying false precision.
    seen = set()
    unique_labels = []
    for label in labels:
        unique_labels.append("" if label in seen else label)
        seen.add(label)
    return tuple(unique_labels)


def _stable_unit(*parts: object) -> float:
    value = 0
    for char in "|".join(str(part) for part in parts):
        value = (value * 131 + ord(char)) % 1_000_000_007
    return (value % 1_000_000) / 999_999.0


def _quantile(sorted_values: list[float], q: float) -> float:
    if not sorted_values:
        return 0.0
    if len(sorted_values) == 1:
        return sorted_values[0]
    position = (len(sorted_values) - 1) * q
    lower = int(math.floor(position))
    upper = int(math.ceil(position))
    if lower == upper:
        return sorted_values[lower]
    ratio = position - lower
    return sorted_values[lower] * (1.0 - ratio) + sorted_values[upper] * ratio


def _range_ratio(value: float, minimum: float, maximum: float) -> float:
    span = maximum - minimum
    if math.isfinite(span):
        return (value - minimum) / max(span, 1e-9)
    scale = max(abs(minimum), abs(maximum))
    return (value / scale - minimum / scale) / (maximum / scale - minimum / scale)


@dataclass(slots=True)
class HoverPoint:
    point: PlotPoint
    position: QPointF
    radius: float


@dataclass(slots=True)
class RenderPayload:
    image: QImage
    hover_points: tuple[HoverPoint, ...]
    hover_buckets: dict[tuple[int, int], list[HoverPoint]]
    labels: tuple[str, ...]
    lane_bands: tuple[tuple[float, float], ...]
    label_margin: int
    minimum: float
    maximum: float
    aggregate_count: int
    point_count: int
    outlier_count: int
    reference_hidden_count: int = 0
    clipped_low_count: int = 0
    clipped_high_count: int = 0
    pinned_point_key: tuple[str, str, int, str] | None = None

    def logical_size(self) -> QSize:
        return self.image.deviceIndependentSize().toSize()


@dataclass(frozen=True, slots=True)
class LaneColumnLayout:
    widths: tuple[float, ...]
    separator_width: float
    total_width: float


@dataclass(frozen=True, slots=True)
class PreparedLane:
    """Width-independent work shared by every rendering of a lane."""

    box: tuple[float, float, float, float, float] | None
    ridge_xs: tuple[float, ...]
    ridge: tuple[float, ...]
    jitters: tuple[float, ...]


@dataclass(frozen=True, slots=True)
class PreparedMetric:
    """A read-only rendering snapshot; images are created only for requested lanes."""

    series: tuple[PlotSeries, ...]
    minimum: float
    maximum: float
    label_margin: int
    lane_headers: tuple[str, ...]
    column_layout: LaneColumnLayout
    lanes: tuple[PreparedLane, ...]


class ComparisonRenderer:
    def __init__(self) -> None:
        self._colors = {
            "background": QColor("#ffffff"),
            "ink": QColor("#24323d"),
            "muted": QColor("#6b7882"),
            "grid": QColor("#d7dfde"),
            "fill": QColor(86, 112, 126, 20),
            "point_fill": QColor(88, 111, 122, 42),
            "point_edge": QColor(58, 78, 90, 118),
            "outlier_fill": QColor("#ff0000"),
            "outlier_edge": QColor("#b00000"),
            "raw_outlier_fill": QColor("#9c0006"),
            "raw_outlier_edge": QColor("#5f0004"),
            "reference": QColor(49, 111, 88, 52),
            "reference_line": QColor("#2f6f58"),
            "zscore_range": QColor("#2563eb"),
        }
        self._base_label_margin = 178
        self._max_label_margin = 420
        self._min_plot_width = 48
        self._right_margin = 48
        self._top_margin = 0

    @staticmethod
    def _make_image(width: int, height: int, dpr: float) -> tuple[QImage, QPainter]:
        physical_width = max(1, int(round(width * dpr)))
        physical_height = max(1, int(round(height * dpr)))
        image = QImage(QSize(physical_width, physical_height), QImage.Format.Format_ARGB32_Premultiplied)
        image.setDevicePixelRatio(dpr)
        painter = QPainter(image)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        return image, painter

    def prepare_series(
        self,
        series: list[PlotSeries],
        lane_headers: tuple[str, ...] = (),
    ) -> PreparedMetric:
        """Compute global scales, label widths and distributions once per dataset.

        No QPixmap is created, so both preparation and tile rendering may run in
        a worker. The application must have initialized Qt's font database.
        """
        minimum, maximum = self._global_range(series)
        _, painter = self._make_image(1, 1, 1.0)
        try:
            label_margin = self._adaptive_label_margin(painter, series, lane_headers)
            column_layout = self._lane_column_layout(painter, series, lane_headers, label_margin)
        finally:
            painter.end()
        lanes: list[PreparedLane] = []
        for item in series:
            values = sorted(point.value for point in item.points)
            box = None
            if values:
                q1 = _quantile(values, 0.25)
                median = _quantile(values, 0.50)
                q3 = _quantile(values, 0.75)
                iqr = max(q3 - q1, 1e-9)
                inside = [value for value in values if q1 - 1.5 * iqr <= value <= q3 + 1.5 * iqr]
                box = (q1, median, q3, min(inside) if inside else values[0], max(inside) if inside else values[-1])
            ridge_xs, ridge = self._prepare_ridge(values)
            lanes.append(PreparedLane(
                box=box,
                ridge_xs=ridge_xs,
                ridge=ridge,
                jitters=tuple(_stable_unit(point.sample_id, item.aggregate_id, point.raw_column) - 0.5 for point in item.points),
            ))
        return PreparedMetric(
            series=tuple(series), minimum=minimum, maximum=maximum,
            label_margin=label_margin, lane_headers=lane_headers,
            column_layout=column_layout, lanes=tuple(lanes),
        )

    @staticmethod
    def _prepare_ridge(values: list[float]) -> tuple[tuple[float, ...], tuple[float, ...]]:
        """Cache exact triangular-kernel breakpoints, not a fixed-bin image.

        Every finite raw value contributes at its actual coordinate. The robust
        bandwidth depends on the data, never the viewport or outlier labels.
        Keeping the piecewise-linear function's knots means zoom cannot expose
        a low-resolution histogram: any visible portion can be drawn exactly
        without recomputing density for every wheel/drag event.
        """
        values = [value for value in values if math.isfinite(value)]
        if not values:
            return (), ()
        # Half the IQR gives a smooth centre without letting a distant tail
        # stretch the bin width. Divide first to handle opposite float limits.
        bandwidth = _quantile(values, .75) * .5 - _quantile(values, .25) * .5
        if not math.isfinite(bandwidth) or bandwidth <= 0:
            center = _quantile(values, .5)
            bandwidth = max(abs(center) * .01, math.ulp(center) * 8) if center else .01

        clusters: list[list[float]] = [[]]
        for value in values:
            if clusters[-1]:
                previous = clusters[-1][-1]
                resolvable = max(bandwidth, math.ulp(previous) * 8, math.ulp(value) * 8)
                if value * .5 - previous * .5 > resolvable:
                    clusters.append([])
            clusters[-1].append(value)

        coordinates: list[float] = []
        heights: list[float] = []
        limit = sys.float_info.max
        for cluster in clusters:
            origin = cluster[0]
            step = max(bandwidth, *(math.ulp(value) * 8 for value in (cluster[0], cluster[-1])))
            events: dict[float, int] = defaultdict(int)
            for value in cluster:
                difference = value - origin
                center = difference / step if math.isfinite(difference) else value / step - origin / step
                # Slopes are integer counts in local bandwidth units. Far
                # clusters get their own origin, avoiding enormous bin indices
                # and arrays across empty spans (e.g. 100 versus 1e12).
                events[center - 1.0] += 1
                events[center] -= 2
                events[center + 1.0] += 1
            slope = 0
            height = 0.0
            positions = sorted(events)
            previous = positions[0]
            for index, position in enumerate(positions):
                height = math.fsum((height, slope * (position - previous)))
                slope += events[position]
                previous = position
                x = origin + step * position
                if not math.isfinite(x):
                    x = (origin * .5 + (step * .5) * position) * 2
                    if not math.isfinite(x):
                        x = math.copysign(limit, x)
                y = 0.0 if index in (0, len(positions) - 1) else max(0.0, height) * (bandwidth / step)
                if coordinates and x <= coordinates[-1]:
                    # Adjacent knots can coincide at floating-point limits.
                    # Preserve the peak instead of introducing duplicate x's.
                    heights[-1] = max(heights[-1], y)
                else:
                    coordinates.append(x)
                    heights.append(y)
        peak = max(heights, default=0.0) or 1.0
        return tuple(coordinates), tuple(height / peak for height in heights)

    def _draw_ridge(self, painter, xs, heights, plot_rect, minimum, maximum, baseline, ridge_height):
        """Clip in data coordinates before mapping to the current zoom pixels.

        Retain every visible knot, including subpixel peaks: a narrow remote
        cluster must not vanish between a fixed number of viewport samples.
        Only the visible interval and its two boundary interpolations reach Qt.
        """
        if not xs or maximum <= xs[0] or minimum >= xs[-1]:
            return
        left, right = max(minimum, xs[0]), min(maximum, xs[-1])

        def height_at(value):
            index = bisect_right(xs, value) - 1
            if index < 0 or index >= len(xs) - 1:
                return heights[max(0, min(index, len(xs) - 1))]
            span = xs[index + 1] - xs[index]
            if math.isfinite(span):
                ratio = (value - xs[index]) / span
            else:
                scale = max(abs(xs[index]), abs(xs[index + 1]))
                ratio = (value / scale - xs[index] / scale) / (xs[index + 1] / scale - xs[index] / scale)
            return heights[index] * (1 - ratio) + heights[index + 1] * ratio

        start, end = bisect_right(xs, left), bisect_left(xs, right)
        path = QPainterPath()
        x_left = self._map_x(left, plot_rect, minimum, maximum)
        x_right = self._map_x(right, plot_rect, minimum, maximum)
        path.moveTo(x_left, baseline - ridge_height * height_at(left))
        for index in range(start, end):
            path.lineTo(self._map_x(xs[index], plot_rect, minimum, maximum),
                        baseline - ridge_height * heights[index])
        path.lineTo(x_right, baseline - ridge_height * height_at(right))
        fill = QPainterPath(path)
        fill.lineTo(x_right, baseline)
        fill.lineTo(x_left, baseline)
        fill.closeSubpath()
        painter.fillPath(fill, self._colors["fill"])
        # Stroke only the density, not artificial vertical edges at viewport
        # clipping boundaries. Real kernel tails already return to zero.
        painter.setPen(QPen(self._colors["ink"], 0.85))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(path)

    def render_prepared_tile(
        self,
        prepared: PreparedMetric,
        lane_indices: tuple[int, ...],
        *,
        plot_type: str,
        lane_height: int,
        width: int,
        dpr: float,
        range_override: tuple[float, float] | None = None,
        pinned_point_key: tuple[str, str, int, str] | None = None,
    ) -> RenderPayload:
        """Render a bounded tile with local hover coordinates and global scales."""
        if any(index < 0 or index >= len(prepared.series) for index in lane_indices):
            raise IndexError("Tile lane index is outside the prepared metric")
        normalized_plot_type = plot_type.strip().lower().removesuffix(" plot")
        if normalized_plot_type not in {"box", "ridge"}:
            raise ValueError(f"Unsupported plot type: {plot_type}")
        series = [prepared.series[index] for index in lane_indices]
        minimum, maximum = range_override or (prepared.minimum, prepared.maximum)
        width = self._safe_canvas_width(width, prepared.label_margin)
        height = max(1, len(series)) * lane_height
        image, painter = self._make_image(width, height, dpr)
        image.fill(self._colors["background"])
        plot_rect = self._plot_rect(width, height, prepared.label_margin)
        hover_points: list[HoverPoint] = []
        lane_bands: list[tuple[float, float]] = []
        box_mode = normalized_plot_type == "box"
        y_ratio = 0.54 if box_mode else 0.66
        draw_lanes = list(enumerate(lane_indices))
        if lane_indices and all(right == left + 1 for left, right in zip(lane_indices, lane_indices[1:])):
            # Strokes and font descenders can cross a lane boundary. Include
            # neighboring lanes as clipped guards so tiles join without seams.
            if lane_indices[0] > 0:
                draw_lanes.insert(0, (-1, lane_indices[0] - 1))
            if lane_indices[-1] + 1 < len(prepared.series):
                draw_lanes.append((len(lane_indices), lane_indices[-1] + 1))
        try:
            self._draw_x_grid(painter, plot_rect, minimum, maximum)
            painter.save()
            # Preserve the full plot's right/bottom clipping. Interior tiles may
            # paint to their bottom edge, which is not the full plot's edge.
            bottom_inset = -1 if lane_indices and lane_indices[-1] == len(prepared.series) - 1 else 0
            painter.setClipRect(plot_rect.adjusted(0, 0, -1, bottom_inset))
            for local_index, source_index in draw_lanes:
                item = prepared.series[source_index]
                lane = prepared.lanes[source_index]
                lane_top = plot_rect.top() + lane_height * local_index
                is_requested_lane = 0 <= local_index < len(lane_indices)
                if is_requested_lane:
                    lane_bands.append((lane_top, float(lane_height)))
                # Use the same source coordinates as a full image, then move
                # them into the tile. This also keeps raster rounding stable.
                offset_y = (local_index - source_index) * lane_height
                painter.save()
                painter.translate(0, offset_y)
                center_y = plot_rect.top() + lane_height * source_index + lane_height * y_ratio
                self._draw_reference(painter, item, plot_rect, center_y, lane_height, minimum, maximum)
                if box_mode:
                    if lane.box is None:
                        self._draw_zscore_ranges(painter, item, plot_rect, center_y, lane_height, minimum, maximum)
                        painter.restore()
                        continue
                    q1, median, q3, whisker_low, whisker_high = lane.box
                    box_height = min(12.0, lane_height * 0.52)
                    x_q1 = self._map_x(q1, plot_rect, minimum, maximum)
                    x_q3 = self._map_x(q3, plot_rect, minimum, maximum)
                    x_median = self._map_x(median, plot_rect, minimum, maximum)
                    x_low = self._map_x(whisker_low, plot_rect, minimum, maximum)
                    x_high = self._map_x(whisker_high, plot_rect, minimum, maximum)
                    painter.setPen(QPen(self._colors["ink"], 0.9))
                    painter.setBrush(self._colors["fill"])
                    painter.drawLine(QPointF(plot_rect.left(), center_y), QPointF(plot_rect.right(), center_y))
                    painter.drawRect(QRectF(min(x_q1, x_q3), center_y - box_height / 2.0, abs(x_q3 - x_q1), box_height))
                    painter.drawLine(QPointF(x_low, center_y), QPointF(x_q1, center_y))
                    painter.drawLine(QPointF(x_q3, center_y), QPointF(x_high, center_y))
                    painter.drawLine(QPointF(x_low, center_y - 4.0), QPointF(x_low, center_y + 4.0))
                    painter.drawLine(QPointF(x_high, center_y - 4.0), QPointF(x_high, center_y + 4.0))
                    painter.drawLine(QPointF(x_median, center_y - box_height / 2.0), QPointF(x_median, center_y + box_height / 2.0))
                else:
                    painter.setPen(QPen(self._colors["grid"], 0.7))
                    painter.drawLine(QPointF(plot_rect.left(), center_y), QPointF(plot_rect.right(), center_y))
                    self._draw_ridge(painter, lane.ridge_xs, lane.ridge, plot_rect,
                                     minimum, maximum, center_y, lane_height * 0.52)
                self._draw_zscore_ranges(painter, item, plot_rect, center_y, lane_height, minimum, maximum)
                lane_hover_points = self._draw_points(
                    painter, item, plot_rect, center_y, lane_height, minimum, maximum,
                    radius=1.4 if box_mode else 1.2,
                    jitter_scale=0.34 if box_mode else 0.22,
                    jitters=lane.jitters,
                )
                painter.restore()
                if is_requested_lane:
                    for point in lane_hover_points:
                        point.position.setY(point.position.y() + offset_y)
                    hover_points.extend(lane_hover_points)
            painter.restore()
            for local_index, source_index in draw_lanes:
                item = prepared.series[source_index]
                center_y = plot_rect.top() + lane_height * local_index + lane_height * y_ratio
                self._draw_label_columns(
                    painter, self._lane_values(item), series, prepared.label_margin,
                    top=center_y - 10.0, height=20.0,
                    lane_headers=prepared.lane_headers, layout=prepared.column_layout,
                )
        finally:
            painter.end()
        return self._payload(
            series, image, hover_points, lane_bands, minimum, maximum,
            sum(len(item.reference_ranges) > 1 for item in series), prepared.label_margin,
            pinned_point_key=pinned_point_key,
        )

    def render_prepared_header(
        self,
        prepared: PreparedMetric,
        *,
        title: str,
        width: int,
        dpr: float,
        lane_headers: tuple[str, ...] = (),
        range_override: tuple[float, float] | None = None,
    ) -> QImage:
        """Render the fixed 24 px title and 42 px ruler without using QPixmap."""
        width = self._safe_canvas_width(width, prepared.label_margin)
        minimum, maximum = range_override or (prepared.minimum, prepared.maximum)
        headers = lane_headers or prepared.lane_headers
        axis = self._render_x_ruler_image(
            width, minimum, maximum, 42, dpr, prepared.label_margin,
            headers, list(prepared.series), prepared.column_layout if headers == prepared.lane_headers else None,
        )
        image, painter = self._make_image(width, 66, dpr)
        try:
            image.fill(self._colors["background"])
            painter.setPen(self._colors["muted"])
            painter.drawText(
                QRectF(8.0, 0.0, float(max(1, width - 16)), 24.0),
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, title,
            )
            painter.drawImage(0, 24, axis)
        finally:
            painter.end()
        return image

    def render_box_series(
        self,
        series: list[PlotSeries],
        lane_height: int,
        width: int,
        dpr: float,
        lane_headers: tuple[str, ...] = (),
        range_override: tuple[float, float] | None = None,
        pinned_point_key: tuple[str, str, int, str] | None = None,
    ) -> RenderPayload:
        minimum, maximum = range_override or self._global_range(series)
        requested_width = width
        width = self._safe_canvas_width(requested_width, self._base_label_margin)
        height = self._top_margin * 2 + max(1, len(series)) * lane_height
        image, painter = self._make_image(width, height, dpr)
        label_margin = self._adaptive_label_margin(painter, series, lane_headers)
        if label_margin != self._base_label_margin:
            painter.end()
            width = self._safe_canvas_width(requested_width, label_margin)
            image, painter = self._make_image(width, height, dpr)
        image.fill(self._colors["background"])
        plot_rect = self._plot_rect(width, height, label_margin)
        hover_points: list[HoverPoint] = []
        lane_bands: list[tuple[float, float]] = []
        reference_hidden_count = 0
        self._draw_x_grid(painter, plot_rect, minimum, maximum)
        painter.save()
        painter.setClipRect(plot_rect.adjusted(0, 0, -1, -1))
        for index, item in enumerate(series):
            lane_top = plot_rect.top() + lane_height * index
            lane_bands.append((lane_top, float(lane_height)))
            center_y = lane_top + lane_height * 0.54
            self._draw_reference(painter, item, plot_rect, center_y, lane_height, minimum, maximum)
            if len(item.reference_ranges) > 1:
                reference_hidden_count += 1
            values = sorted(point.value for point in item.points)
            if not values:
                self._draw_zscore_ranges(painter, item, plot_rect, center_y, lane_height, minimum, maximum)
                continue
            q1 = _quantile(values, 0.25)
            median = _quantile(values, 0.50)
            q3 = _quantile(values, 0.75)
            iqr = max(q3 - q1, 1e-9)
            low_limit = q1 - 1.5 * iqr
            high_limit = q3 + 1.5 * iqr
            inside = [value for value in values if low_limit <= value <= high_limit]
            whisker_low = min(inside) if inside else min(values)
            whisker_high = max(inside) if inside else max(values)
            box_height = min(12.0, lane_height * 0.52)
            x_q1 = self._map_x(q1, plot_rect, minimum, maximum)
            x_q3 = self._map_x(q3, plot_rect, minimum, maximum)
            x_median = self._map_x(median, plot_rect, minimum, maximum)
            x_low = self._map_x(whisker_low, plot_rect, minimum, maximum)
            x_high = self._map_x(whisker_high, plot_rect, minimum, maximum)
            painter.setPen(QPen(self._colors["ink"], 0.9))
            painter.setBrush(self._colors["fill"])
            painter.drawLine(QPointF(plot_rect.left(), center_y), QPointF(plot_rect.right(), center_y))
            painter.drawRect(QRectF(min(x_q1, x_q3), center_y - box_height / 2.0, abs(x_q3 - x_q1), box_height))
            painter.drawLine(QPointF(x_low, center_y), QPointF(x_q1, center_y))
            painter.drawLine(QPointF(x_q3, center_y), QPointF(x_high, center_y))
            painter.drawLine(QPointF(x_low, center_y - 4.0), QPointF(x_low, center_y + 4.0))
            painter.drawLine(QPointF(x_high, center_y - 4.0), QPointF(x_high, center_y + 4.0))
            painter.drawLine(QPointF(x_median, center_y - box_height / 2.0), QPointF(x_median, center_y + box_height / 2.0))
            self._draw_zscore_ranges(painter, item, plot_rect, center_y, lane_height, minimum, maximum)
            hover_points.extend(
                self._draw_points(
                    painter,
                    item,
                    plot_rect,
                    center_y,
                    lane_height,
                    minimum,
                    maximum,
                    radius=1.4,
                    jitter_scale=0.34,
                )
            )
        painter.restore()
        self._draw_labels(painter, series, plot_rect, lane_height, y_ratio=0.54, label_margin=label_margin, lane_headers=lane_headers)
        painter.end()
        return self._payload(
            series,
            image,
            hover_points,
            lane_bands,
            minimum,
            maximum,
            reference_hidden_count,
            label_margin,
            pinned_point_key=pinned_point_key,
        )

    def render_ridge_series(
        self,
        series: list[PlotSeries],
        lane_height: int,
        width: int,
        dpr: float,
        lane_headers: tuple[str, ...] = (),
        range_override: tuple[float, float] | None = None,
        pinned_point_key: tuple[str, str, int, str] | None = None,
    ) -> RenderPayload:
        minimum, maximum = range_override or self._global_range(series)
        requested_width = width
        width = self._safe_canvas_width(requested_width, self._base_label_margin)
        height = self._top_margin * 2 + max(1, len(series)) * lane_height
        image, painter = self._make_image(width, height, dpr)
        label_margin = self._adaptive_label_margin(painter, series, lane_headers)
        if label_margin != self._base_label_margin:
            painter.end()
            width = self._safe_canvas_width(requested_width, label_margin)
            image, painter = self._make_image(width, height, dpr)
        image.fill(self._colors["background"])
        plot_rect = self._plot_rect(width, height, label_margin)
        hover_points: list[HoverPoint] = []
        lane_bands: list[tuple[float, float]] = []
        reference_hidden_count = 0
        self._draw_x_grid(painter, plot_rect, minimum, maximum)
        painter.save()
        painter.setClipRect(plot_rect.adjusted(0, 0, -1, -1))
        for index, item in enumerate(series):
            lane_top = plot_rect.top() + lane_height * index
            lane_bands.append((lane_top, float(lane_height)))
            baseline_y = lane_top + lane_height * 0.66
            self._draw_reference(painter, item, plot_rect, baseline_y, lane_height, minimum, maximum)
            if len(item.reference_ranges) > 1:
                reference_hidden_count += 1
            painter.setPen(QPen(self._colors["grid"], 0.7))
            painter.drawLine(QPointF(plot_rect.left(), baseline_y), QPointF(plot_rect.right(), baseline_y))
            xs, heights = self._prepare_ridge(sorted(point.value for point in item.points))
            self._draw_ridge(painter, xs, heights, plot_rect, minimum, maximum,
                             baseline_y, lane_height * 0.52)
            self._draw_zscore_ranges(painter, item, plot_rect, baseline_y, lane_height, minimum, maximum)
            hover_points.extend(
                self._draw_points(
                    painter,
                    item,
                    plot_rect,
                    baseline_y,
                    lane_height,
                    minimum,
                    maximum,
                    radius=1.2,
                    jitter_scale=0.22,
                )
            )
        painter.restore()
        self._draw_labels(painter, series, plot_rect, lane_height, y_ratio=0.66, label_margin=label_margin, lane_headers=lane_headers)
        painter.end()
        return self._payload(
            series,
            image,
            hover_points,
            lane_bands,
            minimum,
            maximum,
            reference_hidden_count,
            label_margin,
            pinned_point_key=pinned_point_key,
        )

    def render_x_ruler(
        self,
        width: int,
        minimum: float,
        maximum: float,
        visible_height: int,
        dpr: float,
        label_margin: int | None = None,
        lane_headers: tuple[str, ...] = (),
        series: list[PlotSeries] | None = None,
    ) -> QPixmap:
        image = self._render_x_ruler_image(
            width, minimum, maximum, visible_height, dpr,
            label_margin, lane_headers, series,
        )
        pixmap = QPixmap.fromImage(image)
        pixmap.setDevicePixelRatio(image.devicePixelRatio())
        return pixmap

    def _render_x_ruler_image(
        self,
        width: int,
        minimum: float,
        maximum: float,
        visible_height: int,
        dpr: float,
        label_margin: int | None = None,
        lane_headers: tuple[str, ...] = (),
        series: list[PlotSeries] | None = None,
        column_layout: LaneColumnLayout | None = None,
    ) -> QImage:
        resolved_label_margin = label_margin or self._base_label_margin
        width = self._safe_canvas_width(width, resolved_label_margin)
        height = max(42, visible_height)
        image, painter = self._make_image(width, height, dpr)
        try:
            image.fill(self._colors["background"])
            self._draw_lane_header(painter, lane_headers, series or [], resolved_label_margin, column_layout)
            axis_rect = QRectF(
                float(resolved_label_margin),
                22.0,
                float(width - resolved_label_margin - self._right_margin),
                14.0,
            )
            painter.setPen(QPen(self._colors["ink"], 1.0))
            painter.drawLine(QPointF(axis_rect.left(), axis_rect.top() + axis_rect.height() / 2.0), QPointF(axis_rect.right(), axis_rect.top() + axis_rect.height() / 2.0))
            painter.setPen(QPen(self._colors["grid"], 0.8))
            painter.drawLine(QPointF(axis_rect.left(), 6.0), QPointF(axis_rect.left(), 46.0))
            labels = _axis_tick_labels(minimum, maximum)
            label_rects = []
            label_ink_rects = []
            for index in range(5):
                ratio = index / 4.0
                x = axis_rect.left() + axis_rect.width() * ratio
                painter.setPen(QPen(self._colors["grid"], 0.8))
                axis_y = axis_rect.top() + axis_rect.height() / 2.0
                painter.drawLine(QPointF(x, axis_y - 3.0), QPointF(x, axis_y + 12.0))
                ink_width = painter.fontMetrics().horizontalAdvance(labels[index])
                text_width = max(64.0, ink_width + 8.0)
                text_left = min(max(0.0, x - text_width / 2.0), max(0.0, float(width) - text_width))
                label_rects.append(QRectF(text_left, 2.0, text_width, 18.0))
                label_ink_rects.append(QRectF(text_left + (text_width - ink_width) / 2.0, 2.0, ink_width, 18.0))
            painter.setPen(self._colors["muted"])
            drawn_rects = []
            # Give endpoints priority, then the midpoint. A tight or extremely
            # precise scale may have fewer labels; never clip a numeric string
            # into a misleading prefix or overprint neighboring tick labels.
            for index in (0, 4, 2, 1, 3):
                rect = label_rects[index]
                ink = label_ink_rects[index]
                if not labels[index] or any(ink.adjusted(-2, 0, 2, 0).intersects(previous) for previous in drawn_rects):
                    continue
                painter.drawText(
                    rect,
                    Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignBottom,
                    labels[index],
                )
                drawn_rects.append(ink)
        finally:
            if painter.isActive():
                painter.end()
        return image

    def render_header_ruler(
        self,
        title: str,
        width: int,
        minimum: float,
        maximum: float,
        visible_height: int,
        dpr: float,
        label_margin: int | None = None,
        lane_headers: tuple[str, ...] = (),
        series: list[PlotSeries] | None = None,
    ) -> QPixmap:
        resolved_label_margin = label_margin or self._base_label_margin
        width = self._safe_canvas_width(width, resolved_label_margin)
        title_height = 24
        axis_pixmap = self.render_x_ruler(
            width=width,
            minimum=minimum,
            maximum=maximum,
            visible_height=visible_height,
            dpr=dpr,
            label_margin=resolved_label_margin,
            lane_headers=lane_headers,
            series=series,
        )
        axis_size = axis_pixmap.deviceIndependentSize().toSize()
        image, painter = self._make_image(width, title_height + axis_size.height(), dpr)
        try:
            image.fill(self._colors["background"])
            painter.setPen(self._colors["muted"])
            painter.drawText(
                QRectF(8.0, 0.0, float(max(1, width - 16)), float(title_height)),
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                title,
            )
            painter.drawPixmap(0, title_height, axis_pixmap)
        finally:
            if painter.isActive():
                painter.end()
        pixmap = QPixmap.fromImage(image)
        pixmap.setDevicePixelRatio(image.devicePixelRatio())
        return pixmap

    def _draw_lane_header(
        self,
        painter: QPainter,
        lane_headers: tuple[str, ...],
        series: list[PlotSeries],
        label_margin: int,
        column_layout: LaneColumnLayout | None = None,
    ) -> None:
        if not lane_headers:
            return
        self._draw_label_columns(
            painter=painter,
            values=lane_headers,
            series=series,
            label_margin=label_margin,
            top=24.0,
            height=18.0,
            layout=column_layout,
        )

    def _draw_points(
        self,
        painter: QPainter,
        item: PlotSeries,
        plot_rect: QRectF,
        baseline_y: float,
        lane_height: int,
        minimum: float,
        maximum: float,
        radius: float,
        jitter_scale: float,
        jitters: tuple[float, ...] | None = None,
    ) -> list[HoverPoint]:
        hover_points: list[HoverPoint] = []
        for point_index, point in enumerate(item.points):
            clipped = False
            display_value = point.value
            if point.value < minimum:
                display_value = minimum
                clipped = True
            elif point.value > maximum:
                display_value = maximum
                clipped = True
            display_x = self._map_x(display_value, plot_rect, minimum, maximum)
            if clipped:
                display_x = plot_rect.left() + 4.0 if point.value < minimum else plot_rect.right() - 4.0
            position = QPointF(
                display_x,
                baseline_y + (
                    jitters[point_index] if jitters is not None
                    else _stable_unit(point.sample_id, item.aggregate_id, point.raw_column) - 0.5
                ) * lane_height * jitter_scale,
            )
            point_radius = radius if not point.outlier else radius + 0.45
            if point.outlier:
                if point.merged_outlier:
                    painter.setPen(QPen(self._colors["outlier_edge"], 0.8))
                    painter.setBrush(self._colors["outlier_fill"])
                else:
                    painter.setPen(QPen(self._colors["raw_outlier_edge"], 0.8))
                    painter.setBrush(self._colors["raw_outlier_fill"])
            else:
                painter.setPen(QPen(self._colors["point_edge"], 0.7))
                painter.setBrush(self._colors["point_fill"])
            if clipped:
                direction = -1.0 if point.value < minimum else 1.0
                path = QPainterPath()
                path.moveTo(position + QPointF(direction * 4.5, 0.0))
                path.lineTo(position + QPointF(-direction * 3.2, -2.8))
                path.lineTo(position + QPointF(-direction * 3.2, 2.8))
                path.closeSubpath()
                painter.drawPath(path)
            else:
                painter.drawEllipse(position, point_radius, point_radius)
            hover_points.append(HoverPoint(point=point, position=position, radius=point_radius))
        return hover_points

    def _draw_reference(
        self,
        painter: QPainter,
        item: PlotSeries,
        plot_rect: QRectF,
        center_y: float,
        lane_height: int,
        minimum: float,
        maximum: float,
    ) -> None:
        if not item.reference_overlay_allowed:
            return
        reference = item.reference_ranges[0] if item.reference_ranges else None
        if reference is None:
            return
        ranges = reference.allowed_ranges
        if not ranges and reference.lower_bound is not None and reference.upper_bound is not None:
            ranges = ((reference.lower_bound, reference.upper_bound),)
        for lower_bound, upper_bound in ranges:
            left = self._map_x(lower_bound, plot_rect, minimum, maximum)
            right = self._map_x(upper_bound, plot_rect, minimum, maximum)
            clipped_left = max(plot_rect.left(), min(plot_rect.right(), min(left, right)))
            clipped_right = max(plot_rect.left(), min(plot_rect.right(), max(left, right)))
            if clipped_right <= clipped_left:
                continue
            painter.fillRect(
                QRectF(clipped_left, center_y - lane_height * 0.34, clipped_right - clipped_left, lane_height * 0.68),
                self._colors["reference"],
            )
        if reference.center is not None:
            x = self._map_x(reference.center, plot_rect, minimum, maximum)
            painter.setPen(QPen(self._colors["reference_line"], 1.0))
            painter.drawLine(QPointF(x, center_y - lane_height * 0.34), QPointF(x, center_y + lane_height * 0.34))

    def _draw_zscore_ranges(
        self,
        painter: QPainter,
        item: PlotSeries,
        plot_rect: QRectF,
        center_y: float,
        lane_height: int,
        minimum: float,
        maximum: float,
    ) -> None:
        if not item.zscore_ranges:
            return
        painter.save()
        painter.setPen(QPen(self._colors["zscore_range"], 1.5))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        # Inset from the Golden band so the lower ridge edge stays visible
        # within its lane instead of being clipped at the next lane boundary.
        top = center_y - lane_height * 0.30
        bottom = center_y + lane_height * 0.30
        for reference in item.zscore_ranges:
            lower = reference.lower_bound if reference.lower_bound is not None else -math.inf
            upper = reference.upper_bound if reference.upper_bound is not None else math.inf
            if math.isnan(lower) or math.isnan(upper) or lower > upper or upper < minimum or lower > maximum:
                continue
            left = self._map_x(max(lower, minimum), plot_rect, minimum, maximum)
            right = self._map_x(min(upper, maximum), plot_rect, minimum, maximum)
            painter.drawLine(QPointF(left, top), QPointF(right, top))
            painter.drawLine(QPointF(left, bottom), QPointF(right, bottom))
            # Only actual finite bounds get vertical edges. Cropped/unbounded
            # intervals continue through the viewport instead of ending there.
            if math.isfinite(lower) and minimum <= lower <= maximum:
                painter.drawLine(QPointF(left, top), QPointF(left, bottom))
            if math.isfinite(upper) and minimum <= upper <= maximum:
                painter.drawLine(QPointF(right, top), QPointF(right, bottom))
        painter.restore()

    def _draw_labels(
        self,
        painter: QPainter,
        series: list[PlotSeries],
        plot_rect: QRectF,
        lane_height: int,
        y_ratio: float,
        label_margin: int,
        lane_headers: tuple[str, ...],
    ) -> None:
        for index, item in enumerate(series):
            center_y = plot_rect.top() + lane_height * index + lane_height * y_ratio
            self._draw_label_columns(
                painter=painter,
                values=self._lane_values(item),
                series=series,
                label_margin=label_margin,
                top=center_y - 10.0,
                height=20.0,
                lane_headers=lane_headers,
            )

    def _payload(
        self,
        series: list[PlotSeries],
        image: QImage,
        hover_points: list[HoverPoint],
        lane_bands: list[tuple[float, float]],
        minimum: float,
        maximum: float,
        reference_hidden_count: int,
        label_margin: int,
        pinned_point_key: tuple[str, str, int, str] | None = None,
    ) -> RenderPayload:
        full_minimum, full_maximum = self._full_point_range(series)
        clipped_low_count = 0 if math.isclose(minimum, full_minimum) else sum(
            1 for item in series for point in item.points if point.value < minimum
        )
        clipped_high_count = 0 if math.isclose(maximum, full_maximum) else sum(
            1 for item in series for point in item.points if point.value > maximum
        )
        return RenderPayload(
            image=image,
            hover_points=tuple(hover_points),
            hover_buckets=self._build_hover_buckets(hover_points),
            labels=tuple(item.label for item in series),
            lane_bands=tuple(lane_bands),
            label_margin=label_margin,
            minimum=minimum,
            maximum=maximum,
            aggregate_count=len(series),
            point_count=sum(len(item.points) for item in series),
            outlier_count=sum(sum(1 for point in item.points if point.outlier) for item in series),
            reference_hidden_count=reference_hidden_count,
            clipped_low_count=clipped_low_count,
            clipped_high_count=clipped_high_count,
            pinned_point_key=pinned_point_key,
        )

    def _plot_rect(self, width: int, height: int, label_margin: int) -> QRectF:
        return QRectF(
            float(label_margin),
            float(self._top_margin),
            float(width - label_margin - self._right_margin),
            float(height - self._top_margin * 2),
        )

    def _safe_canvas_width(self, width: int, label_margin: int) -> int:
        return max(int(width), label_margin + self._right_margin + self._min_plot_width)

    def _adaptive_label_margin(self, painter: QPainter, series: list[PlotSeries], lane_headers: tuple[str, ...] = ()) -> int:
        if not series and not lane_headers:
            return self._base_label_margin
        required = self._raw_lane_layout_width(painter, series, lane_headers) + 16
        return max(
            self._base_label_margin,
            min(self._max_label_margin, int(required)),
        )

    def _draw_label_columns(
        self,
        painter: QPainter,
        values: tuple[str, ...],
        series: list[PlotSeries],
        label_margin: int,
        top: float,
        height: float,
        lane_headers: tuple[str, ...] = (),
        layout: LaneColumnLayout | None = None,
    ) -> None:
        layout = layout or self._lane_column_layout(painter, series, lane_headers or values, label_margin)
        block_left = max(8.0, float(label_margin) - 8.0 - layout.total_width)
        x = block_left
        painter.setPen(self._colors["muted"])
        for index, width in enumerate(layout.widths):
            value = values[index] if index < len(values) else ""
            label = painter.fontMetrics().elidedText(
                value,
                Qt.TextElideMode.ElideMiddle,
                max(1, int(width - 4)),
            )
            painter.drawText(
                QRectF(x, top, width, height),
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                label,
            )
            x += width
            if index < len(layout.widths) - 1:
                painter.drawText(
                    QRectF(x, top, layout.separator_width, height),
                    Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter,
                    "|",
                )
                x += layout.separator_width

    def _lane_column_layout(
        self,
        painter: QPainter,
        series: list[PlotSeries],
        lane_headers: tuple[str, ...],
        label_margin: int,
    ) -> LaneColumnLayout:
        metrics = painter.fontMetrics()
        column_count = self._lane_column_count(series, lane_headers)
        separator_width = float(metrics.horizontalAdvance(" | "))
        widths: list[float] = []
        for column_index in range(column_count):
            candidates = [
                lane_headers[column_index]
                if column_index < len(lane_headers)
                else ""
            ]
            candidates.extend(
                values[column_index] if column_index < len(values) else ""
                for values in (self._lane_values(item) for item in series)
            )
            widths.append(float(max(metrics.horizontalAdvance(value) for value in candidates) + 8))
        available = max(8.0, float(label_margin - 16))
        separator_total = separator_width * max(0, column_count - 1)
        available_for_columns = max(float(column_count * 24), available - separator_total)
        raw_width_sum = sum(widths)
        if raw_width_sum > available_for_columns and raw_width_sum > 0:
            scale = available_for_columns / raw_width_sum
            widths = [max(24.0, width * scale) for width in widths]
            overflow = sum(widths) - available_for_columns
            while overflow > 0.1 and any(width > 24.0 for width in widths):
                shrinkable = [index for index, width in enumerate(widths) if width > 24.0]
                shrink = overflow / len(shrinkable)
                for index in shrinkable:
                    old_width = widths[index]
                    widths[index] = max(24.0, old_width - shrink)
                    overflow -= old_width - widths[index]
        total_width = sum(widths) + separator_total
        return LaneColumnLayout(
            widths=tuple(widths),
            separator_width=separator_width,
            total_width=total_width,
        )

    def _raw_lane_layout_width(
        self,
        painter: QPainter,
        series: list[PlotSeries],
        lane_headers: tuple[str, ...],
    ) -> int:
        metrics = painter.fontMetrics()
        column_count = self._lane_column_count(series, lane_headers)
        if column_count == 0:
            return 0
        separator_total = metrics.horizontalAdvance(" | ") * max(0, column_count - 1)
        width = separator_total
        for column_index in range(column_count):
            candidates = [
                lane_headers[column_index]
                if column_index < len(lane_headers)
                else ""
            ]
            candidates.extend(
                values[column_index] if column_index < len(values) else ""
                for values in (self._lane_values(item) for item in series)
            )
            width += max(metrics.horizontalAdvance(value) for value in candidates) + 8
        return width

    @staticmethod
    def _lane_values(item: PlotSeries) -> tuple[str, ...]:
        return item.lane_values or tuple(item.label.split(" | "))

    def _lane_column_count(self, series: list[PlotSeries], lane_headers: tuple[str, ...]) -> int:
        return max(
            [len(lane_headers), *(len(self._lane_values(item)) for item in series)],
            default=0,
        )

    @staticmethod
    def _point_values(series: list[PlotSeries]) -> list[float]:
        return [point.value for item in series for point in item.points]

    @staticmethod
    def _normal_point_values(series: list[PlotSeries]) -> list[float]:
        return [point.value for item in series for point in item.points if not point.outlier]

    def _full_point_range(self, series: list[PlotSeries]) -> tuple[float, float]:
        values = self._point_values(series)
        if not values:
            return 0.0, 1.0
        minimum = min(values)
        maximum = max(values)
        if math.isclose(minimum, maximum):
            minimum -= 1.0
            maximum += 1.0
        span = maximum - minimum
        return minimum - span * 0.06, maximum + span * 0.06

    def _global_range(self, series: list[PlotSeries]) -> tuple[float, float]:
        minimum, maximum = self._default_point_range(series)
        bounds = [
            bound
            for item in series
            for reference in item.zscore_ranges
            for bound in (reference.lower_bound, reference.upper_bound)
            if bound is not None and math.isfinite(bound)
        ]
        if not bounds:
            return minimum, maximum
        finite_values = [value for value in (minimum, maximum, *bounds) if math.isfinite(value)]
        low, high = min(finite_values), max(finite_values)
        if (low, high) == (minimum, maximum):
            return minimum, maximum
        # Scale before subtracting so opposite finite float limits remain a
        # usable axis even when their span itself cannot fit in a float.
        margin = high * 0.04 - low * 0.04
        padded_low, padded_high = low - margin, high + margin
        return (padded_low if math.isfinite(padded_low) else low,
                padded_high if math.isfinite(padded_high) else high)

    def _default_point_range(self, series: list[PlotSeries]) -> tuple[float, float]:
        values = sorted(self._point_values(series))
        if not values:
            return 0.0, 1.0
        full_minimum, full_maximum = self._full_point_range(series)
        normal_values = sorted(self._normal_point_values(series))
        range_values = normal_values or values
        low = _quantile(range_values, 0.01)
        high = _quantile(range_values, 0.99)
        if math.isclose(low, high):
            return full_minimum, full_maximum
        span = high - low
        minimum = low - span * 0.08
        maximum = high + span * 0.08
        if normal_values:
            minimum = min(minimum, min(normal_values))
            maximum = max(maximum, max(normal_values))
        final_span = maximum - minimum
        if math.isclose(final_span, 0.0):
            final_span = 1.0
        minimum -= final_span * 0.04
        maximum += final_span * 0.04
        return minimum, maximum

    @staticmethod
    def _map_x(value: float, plot_rect: QRectF, minimum: float, maximum: float) -> float:
        ratio = _range_ratio(value, minimum, maximum)
        return plot_rect.left() + plot_rect.width() * ratio

    def _draw_x_grid(self, painter: QPainter, plot_rect: QRectF, minimum: float, maximum: float) -> None:
        del minimum, maximum
        for index in range(5):
            ratio = index / 4.0
            x = plot_rect.left() + plot_rect.width() * ratio
            painter.setPen(QPen(self._colors["grid"], 0.8))
            painter.drawLine(QPointF(x, plot_rect.top()), QPointF(x, plot_rect.bottom()))

    @staticmethod
    def _build_hover_buckets(points: list[HoverPoint]) -> dict[tuple[int, int], list[HoverPoint]]:
        buckets: dict[tuple[int, int], list[HoverPoint]] = defaultdict(list)
        bucket_size = 24
        for point in points:
            key = (int(point.position.x() // bucket_size), int(point.position.y() // bucket_size))
            buckets[key].append(point)
        return dict(buckets)
