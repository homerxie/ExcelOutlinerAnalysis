"""Tab pages keep their Qt forms while only the current page requests height."""
from __future__ import annotations

from PySide6.QtCore import QEvent, QSize, Qt
from PySide6.QtWidgets import QStackedWidget, QStyle, QStyleOptionTabWidgetFrame, QTabWidget, QWidgetItem


class CurrentPageTabWidget(QTabWidget):
    """Use the current page's vertical hints without changing page policies.

    QTabWidget normally combines the size hints of every page. That lets a
    hidden chart or form enlarge an unrelated result page. QWidgetItem applies
    each current page's original minimum, maximum and size policy; the Qt style
    supplies tab/frame dimensions. Horizontal hints retain Qt's normal behavior.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.currentChanged.connect(self._current_page_changed)
        self._page_stack = self.findChild(QStackedWidget, options=Qt.FindDirectChildrenOnly)
        if self._page_stack is not None:
            self._page_stack.installEventFilter(self)

    def _current_page_changed(self, *_args):
        self.updateGeometry()

    def tabInserted(self, index):
        super().tabInserted(index)
        self.widget(index).installEventFilter(self)
        self.updateGeometry()

    def tabRemoved(self, index):
        super().tabRemoved(index)
        self.updateGeometry()

    def eventFilter(self, watched, event):
        if (event.type() in (QEvent.LayoutRequest, QEvent.FontChange, QEvent.StyleChange)
                and (watched is self.currentWidget() or watched is self._page_stack)):
            self.updateGeometry()
        return super().eventFilter(watched, event)

    def _style_option(self):
        option = QStyleOptionTabWidgetFrame()
        self.initStyleOption(option)
        option.state = QStyle.State_None
        return option

    def _header_size(self, minimum=False):
        bar = self.tabBar()
        bar_size = (QSize(0, 0) if bar.autoHide() and bar.count() <= 1 else
                    bar.minimumSizeHint() if minimum else bar.sizeHint())
        corners = []
        for position in (Qt.TopLeftCorner, Qt.TopRightCorner):
            widget = self.cornerWidget(position)
            corners.append((widget.minimumSizeHint() if minimum else widget.sizeHint())
                           if widget is not None and widget.isVisible() else QSize(0, 0))
        if self.tabPosition() in (QTabWidget.North, QTabWidget.South):
            return QSize(bar_size.width() + sum(size.width() for size in corners),
                         max(bar_size.height(), *(size.height() for size in corners)))
        return QSize(max(bar_size.width(), *(size.width() for size in corners)),
                     bar_size.height() + sum(size.height() for size in corners))

    def _with_chrome(self, page_size, minimum=False):
        header = self._header_size(minimum)
        if self.tabPosition() in (QTabWidget.North, QTabWidget.South):
            contents = QSize(max(page_size.width(), header.width()), page_size.height() + header.height())
        else:
            contents = QSize(page_size.width() + header.width(), max(page_size.height(), header.height()))
        return self.style().sizeFromContents(QStyle.CT_TabWidget, self._style_option(), contents, self)

    def sizeHint(self):
        native = super().sizeHint()
        page = self.currentWidget()
        if page is not None:
            native.setHeight(self._with_chrome(QWidgetItem(page).sizeHint()).height())
        return native

    def minimumSizeHint(self):
        native = super().minimumSizeHint()
        page = self.currentWidget()
        if page is not None:
            native.setHeight(self._with_chrome(QWidgetItem(page).minimumSize(), minimum=True).height())
        return native

    def hasHeightForWidth(self):
        page = self.currentWidget()
        return bool(page is not None and page.hasHeightForWidth())

    def heightForWidth(self, width):
        page = self.currentWidget()
        if page is None or not page.hasHeightForWidth():
            return -1
        padding = self.style().sizeFromContents(QStyle.CT_TabWidget, self._style_option(), QSize(0, 0), self)
        page_width = width - padding.width()
        if self.tabPosition() in (QTabWidget.West, QTabWidget.East):
            page_width -= self._header_size().width()
        page_width = max(0, page_width)
        height = QWidgetItem(page).heightForWidth(page_width)
        return self._with_chrome(QSize(page_width, height)).height()
