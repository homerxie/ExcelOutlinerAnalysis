# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_risk_help_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog, QDialogButtonBox,
    QSizePolicy, QTextBrowser, QVBoxLayout, QWidget)

class Ui_TskRiskHelpDialogForm(object):
    def setupUi(self, TskRiskHelpDialogForm):
        if not TskRiskHelpDialogForm.objectName():
            TskRiskHelpDialogForm.setObjectName(u"TskRiskHelpDialogForm")
        TskRiskHelpDialogForm.resize(640, 520)
        TskRiskHelpDialogForm.setMinimumSize(QSize(360, 260))
        self.dialogLayout = QVBoxLayout(TskRiskHelpDialogForm)
        self.dialogLayout.setSpacing(8)
        self.dialogLayout.setObjectName(u"dialogLayout")
        self.dialogLayout.setContentsMargins(12, 12, 12, 12)
        self.helpTextBrowser = QTextBrowser(TskRiskHelpDialogForm)
        self.helpTextBrowser.setObjectName(u"helpTextBrowser")

        self.dialogLayout.addWidget(self.helpTextBrowser)

        self.buttonBox = QDialogButtonBox(TskRiskHelpDialogForm)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Close)

        self.dialogLayout.addWidget(self.buttonBox)


        self.retranslateUi(TskRiskHelpDialogForm)
        self.buttonBox.rejected.connect(TskRiskHelpDialogForm.reject)

        QMetaObject.connectSlotsByName(TskRiskHelpDialogForm)
    # setupUi

    def retranslateUi(self, TskRiskHelpDialogForm):
        TskRiskHelpDialogForm.setWindowTitle(QCoreApplication.translate("TskRiskHelpDialogForm", u"\u98ce\u9669\u7ed3\u679c\u8bf4\u660e", None))
        self.helpTextBrowser.setProperty(u"summaryHeading", QCoreApplication.translate("TskRiskHelpDialogForm", u"\u5f53\u524d\u7ed3\u679c", None))
        self.helpTextBrowser.setProperty(u"referenceHeading", QCoreApplication.translate("TskRiskHelpDialogForm", u"\u6982\u7387\u53e3\u5f84", None))
        self.helpTextBrowser.setProperty(u"intervalHeading", QCoreApplication.translate("TskRiskHelpDialogForm", u"\u6761\u5f62\u56fe\u4e0e\u7f6e\u4fe1\u533a\u95f4", None))
        self.helpTextBrowser.setProperty(u"heatmapHeading", QCoreApplication.translate("TskRiskHelpDialogForm", u"\u70ed\u529b\u56fe", None))
        self.helpTextBrowser.setProperty(u"axesHeading", QCoreApplication.translate("TskRiskHelpDialogForm", u"\u8f74\u9009\u62e9\u4e0e\u7ec4\u5408\u987a\u5e8f", None))
        self.helpTextBrowser.setProperty(u"filterHeading", QCoreApplication.translate("TskRiskHelpDialogForm", u"\u7b5b\u9009\u4e0e\u6392\u5e8f", None))
        self.helpTextBrowser.setProperty(u"filterText", QCoreApplication.translate("TskRiskHelpDialogForm", u"\u7b5b\u9009\u540c\u6b65\u5230\u6761\u5f62\u56fe\u3001\u70ed\u529b\u56fe\u4e0e\u660e\u7ec6\u8868\u3002\u6392\u5e8f\u8bbe\u7f6e\u7528\u4e8e\u6761\u5f62\u56fe\u4e0e\u660e\u7ec6\u8868\uff1b\u70ed\u529b\u56fe\u6309\u6240\u9009\u8f74\u7ef4\u5ea6\u53ca\u987a\u5e8f\u5c55\u793a\u3002X\u3001Y \u8f74\u5305\u542b\u4e92\u8865\u7684\u7ef4\u5ea6\u96c6\u5408\uff0c\u6bcf\u4e2a\u683c\u5b50\u59cb\u7ec8\u5bf9\u5e94\u539f\u6765\u7684\u5b8c\u6574\u6761\u4ef6\u7ec4\u5408\uff0c\u8c03\u6574\u8f74\u4e0d\u4f1a\u91cd\u65b0\u8ba1\u7b97\u6216\u6c47\u603b\u6982\u7387\u3002", None))
    # retranslateUi

