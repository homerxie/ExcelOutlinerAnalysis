from PySide6.QtWidgets import QDialog, QWidget

from .ui_analysis_output_dialog import Ui_AnalysisOutputDialog


class AnalysisOutputDialog(QDialog):
    """Choose optional exports to run after successful analysis."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.ui = Ui_AnalysisOutputDialog()
        self.ui.setupUi(self)

    def export_kinds(self) -> list[str]:
        return [
            kind
            for kind, checkbox in (
                ("outlier", self.ui.outlierCheckBox),
                ("data", self.ui.dataCheckBox),
            )
            if checkbox.isChecked()
        ]
