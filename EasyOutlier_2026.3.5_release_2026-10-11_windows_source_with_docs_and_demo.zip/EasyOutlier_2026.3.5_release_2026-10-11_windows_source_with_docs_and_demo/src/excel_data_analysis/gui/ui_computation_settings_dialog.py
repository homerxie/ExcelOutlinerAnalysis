# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'computation_settings_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog, QDialogButtonBox,
    QHBoxLayout, QLabel, QRadioButton, QSizePolicy,
    QSpacerItem, QSpinBox, QVBoxLayout, QWidget)

class Ui_ComputationSettingsDialog(object):
    def setupUi(self, ComputationSettingsDialog):
        if not ComputationSettingsDialog.objectName():
            ComputationSettingsDialog.setObjectName(u"ComputationSettingsDialog")
        ComputationSettingsDialog.resize(580, 350)
        ComputationSettingsDialog.setMinimumSize(QSize(500, 320))
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(ComputationSettingsDialog.sizePolicy().hasHeightForWidth())
        ComputationSettingsDialog.setSizePolicy(sizePolicy)
        ComputationSettingsDialog.setSizeGripEnabled(True)
        self.dialogLayout = QVBoxLayout(ComputationSettingsDialog)
        self.dialogLayout.setSpacing(12)
        self.dialogLayout.setObjectName(u"dialogLayout")
        self.dialogLayout.setContentsMargins(20, 20, 20, 20)
        self.descriptionLabel = QLabel(ComputationSettingsDialog)
        self.descriptionLabel.setObjectName(u"descriptionLabel")
        sizePolicy.setHeightForWidth(self.descriptionLabel.sizePolicy().hasHeightForWidth())
        self.descriptionLabel.setSizePolicy(sizePolicy)
        self.descriptionLabel.setWordWrap(True)

        self.dialogLayout.addWidget(self.descriptionLabel)

        self.detectedCoresLabel = QLabel(ComputationSettingsDialog)
        self.detectedCoresLabel.setObjectName(u"detectedCoresLabel")
        sizePolicy.setHeightForWidth(self.detectedCoresLabel.sizePolicy().hasHeightForWidth())
        self.detectedCoresLabel.setSizePolicy(sizePolicy)
        self.detectedCoresLabel.setWordWrap(True)

        self.dialogLayout.addWidget(self.detectedCoresLabel)

        self.autoWorkersLayout = QHBoxLayout()
        self.autoWorkersLayout.setSpacing(12)
        self.autoWorkersLayout.setObjectName(u"autoWorkersLayout")
        self.autoWorkersRadioButton = QRadioButton(ComputationSettingsDialog)
        self.autoWorkersRadioButton.setObjectName(u"autoWorkersRadioButton")
        self.autoWorkersRadioButton.setChecked(True)

        self.autoWorkersLayout.addWidget(self.autoWorkersRadioButton)

        self.autoWorkersSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.autoWorkersLayout.addItem(self.autoWorkersSpacer)


        self.dialogLayout.addLayout(self.autoWorkersLayout)

        self.autoWorkersDescriptionLabel = QLabel(ComputationSettingsDialog)
        self.autoWorkersDescriptionLabel.setObjectName(u"autoWorkersDescriptionLabel")
        sizePolicy.setHeightForWidth(self.autoWorkersDescriptionLabel.sizePolicy().hasHeightForWidth())
        self.autoWorkersDescriptionLabel.setSizePolicy(sizePolicy)
        self.autoWorkersDescriptionLabel.setWordWrap(True)
        self.autoWorkersDescriptionLabel.setIndent(22)

        self.dialogLayout.addWidget(self.autoWorkersDescriptionLabel)

        self.customWorkersLayout = QHBoxLayout()
        self.customWorkersLayout.setSpacing(12)
        self.customWorkersLayout.setObjectName(u"customWorkersLayout")
        self.customWorkersRadioButton = QRadioButton(ComputationSettingsDialog)
        self.customWorkersRadioButton.setObjectName(u"customWorkersRadioButton")

        self.customWorkersLayout.addWidget(self.customWorkersRadioButton)

        self.workerCountSpinBox = QSpinBox(ComputationSettingsDialog)
        self.workerCountSpinBox.setObjectName(u"workerCountSpinBox")
        self.workerCountSpinBox.setEnabled(False)
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.workerCountSpinBox.sizePolicy().hasHeightForWidth())
        self.workerCountSpinBox.setSizePolicy(sizePolicy1)
        self.workerCountSpinBox.setMinimumSize(QSize(120, 0))
        self.workerCountSpinBox.setMinimum(1)
        self.workerCountSpinBox.setMaximum(64)
        self.workerCountSpinBox.setValue(1)

        self.customWorkersLayout.addWidget(self.workerCountSpinBox)


        self.dialogLayout.addLayout(self.customWorkersLayout)

        self.customWorkersDescriptionLabel = QLabel(ComputationSettingsDialog)
        self.customWorkersDescriptionLabel.setObjectName(u"customWorkersDescriptionLabel")
        sizePolicy.setHeightForWidth(self.customWorkersDescriptionLabel.sizePolicy().hasHeightForWidth())
        self.customWorkersDescriptionLabel.setSizePolicy(sizePolicy)
        self.customWorkersDescriptionLabel.setWordWrap(True)
        self.customWorkersDescriptionLabel.setIndent(22)

        self.dialogLayout.addWidget(self.customWorkersDescriptionLabel)

        self.verticalSpacer = QSpacerItem(20, 12, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.dialogLayout.addItem(self.verticalSpacer)

        self.persistenceLabel = QLabel(ComputationSettingsDialog)
        self.persistenceLabel.setObjectName(u"persistenceLabel")
        sizePolicy.setHeightForWidth(self.persistenceLabel.sizePolicy().hasHeightForWidth())
        self.persistenceLabel.setSizePolicy(sizePolicy)
        self.persistenceLabel.setWordWrap(True)

        self.dialogLayout.addWidget(self.persistenceLabel)

        self.buttonBox = QDialogButtonBox(ComputationSettingsDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setOrientation(Qt.Orientation.Horizontal)
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)

        self.dialogLayout.addWidget(self.buttonBox)


        self.retranslateUi(ComputationSettingsDialog)
        self.buttonBox.accepted.connect(ComputationSettingsDialog.accept)
        self.buttonBox.rejected.connect(ComputationSettingsDialog.reject)

        QMetaObject.connectSlotsByName(ComputationSettingsDialog)
    # setupUi

    def retranslateUi(self, ComputationSettingsDialog):
        ComputationSettingsDialog.setWindowTitle(QCoreApplication.translate("ComputationSettingsDialog", u"\u8ba1\u7b97\u8d44\u6e90\u8bbe\u7f6e", None))
        self.descriptionLabel.setText(QCoreApplication.translate("ComputationSettingsDialog", u"\u7edf\u4e00\u8bbe\u7f6e\u5404\u9879\u4efb\u52a1\u7684\u591a\u8fdb\u7a0b\u8ba1\u7b97\u6838\u5fc3\u6570\u4e0a\u9650\u3002", None))
        self.detectedCoresLabel.setText(QCoreApplication.translate("ComputationSettingsDialog", u"\u68c0\u6d4b\u5230\u7684\u903b\u8f91\u6838\u5fc3\u6570\uff1a\u2014", None))
        self.detectedCoresLabel.setProperty(u"formatText", QCoreApplication.translate("ComputationSettingsDialog", u"\u68c0\u6d4b\u5230 {cores} \u4e2a\u903b\u8f91\u6838\u5fc3\uff0c\u53ef\u8bbe\u7f6e 1\uff5e{maximum} \u6838\u3002", None))
        self.autoWorkersRadioButton.setText(QCoreApplication.translate("ComputationSettingsDialog", u"\u81ea\u52a8\uff08\u63a8\u8350\uff09", None))
        self.autoWorkersDescriptionLabel.setText(QCoreApplication.translate("ComputationSettingsDialog", u"\u4fdd\u7559\u5404\u8ba1\u7b97\u9636\u6bb5\u7684\u81ea\u52a8\u7b56\u7565\uff0c\u6839\u636e\u4efb\u52a1\u89c4\u6a21\u9009\u62e9\u5e76\u884c\u6570\u91cf\u3002", None))
        self.customWorkersRadioButton.setText(QCoreApplication.translate("ComputationSettingsDialog", u"\u81ea\u5b9a\u4e49\u6700\u5927\u6838\u5fc3\u6570\uff1a", None))
        self.workerCountSpinBox.setSuffix(QCoreApplication.translate("ComputationSettingsDialog", u" \u6838", None))
        self.customWorkersDescriptionLabel.setText(QCoreApplication.translate("ComputationSettingsDialog", u"\u8bbe\u4e3a 1 \u65f6\u987a\u5e8f\u8ba1\u7b97\uff1b\u5b9e\u9645\u8fdb\u7a0b\u6570\u7531\u4efb\u52a1\u89c4\u6a21\u548c\u81ea\u52a8\u7b56\u7565\u51b3\u5b9a\uff0c\u4e14\u4e0d\u8d85\u8fc7\u6b64\u4e0a\u9650\u3002", None))
        self.persistenceLabel.setText(QCoreApplication.translate("ComputationSettingsDialog", u"\u8bbe\u7f6e\u81ea\u52a8\u4fdd\u5b58\uff0c\u5bf9\u540e\u7eed\u5206\u6790\u4efb\u52a1\u53ca\u65b0\u6253\u5f00\u7684\u7ed8\u56fe\u7a97\u53e3\u751f\u6548\u3002\n"
"\u6b63\u5728\u8fd0\u884c\u7684\u4efb\u52a1\u4fdd\u6301\u539f\u8bbe\u7f6e\u3002", None))
    # retranslateUi

