# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_detail_panel.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTextOption,
    QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QLineEdit, QSizePolicy, QTextBrowser, QTextEdit,
    QToolButton, QVBoxLayout, QWidget)

class Ui_TskDetailPanelForm(object):
    def setupUi(self, TskDetailPanelForm):
        if not TskDetailPanelForm.objectName():
            TskDetailPanelForm.setObjectName(u"TskDetailPanelForm")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(TskDetailPanelForm.sizePolicy().hasHeightForWidth())
        TskDetailPanelForm.setSizePolicy(sizePolicy)
        TskDetailPanelForm.setMinimumSize(QSize(240, 0))
        TskDetailPanelForm.setProperty(u"preferredWidth", 350)
        TskDetailPanelForm.setProperty(u"pageSize", 15)
        self.panelLayout = QVBoxLayout(TskDetailPanelForm)
        self.panelLayout.setSpacing(8)
        self.panelLayout.setObjectName(u"panelLayout")
        self.panelLayout.setContentsMargins(10, 8, 8, 8)
        self.headerLayout = QHBoxLayout()
        self.headerLayout.setObjectName(u"headerLayout")
        self.titleLabel = QLabel(TskDetailPanelForm)
        self.titleLabel.setObjectName(u"titleLabel")
        font = QFont()
        font.setBold(True)
        self.titleLabel.setFont(font)
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.titleLabel.sizePolicy().hasHeightForWidth())
        self.titleLabel.setSizePolicy(sizePolicy1)

        self.headerLayout.addWidget(self.titleLabel)

        self.closeButton = QToolButton(TskDetailPanelForm)
        self.closeButton.setObjectName(u"closeButton")
        self.closeButton.setAutoRaise(True)

        self.headerLayout.addWidget(self.closeButton)


        self.panelLayout.addLayout(self.headerLayout)

        self.searchLineEdit = QLineEdit(TskDetailPanelForm)
        self.searchLineEdit.setObjectName(u"searchLineEdit")
        self.searchLineEdit.setClearButtonEnabled(True)
        self.searchLineEdit.setEnabled(False)

        self.panelLayout.addWidget(self.searchLineEdit)

        self.detailsBrowser = QTextBrowser(TskDetailPanelForm)
        self.detailsBrowser.setObjectName(u"detailsBrowser")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy2.setHorizontalStretch(1)
        sizePolicy2.setVerticalStretch(1)
        sizePolicy2.setHeightForWidth(self.detailsBrowser.sizePolicy().hasHeightForWidth())
        self.detailsBrowser.setSizePolicy(sizePolicy2)
        self.detailsBrowser.setFrameShape(QFrame.Shape.NoFrame)
        self.detailsBrowser.setOpenLinks(False)
        self.detailsBrowser.setOpenExternalLinks(False)
        self.detailsBrowser.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.detailsBrowser.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth)
        self.detailsBrowser.setWordWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)

        self.panelLayout.addWidget(self.detailsBrowser)


        self.retranslateUi(TskDetailPanelForm)

        QMetaObject.connectSlotsByName(TskDetailPanelForm)
    # setupUi

    def retranslateUi(self, TskDetailPanelForm):
        TskDetailPanelForm.setProperty(u"emptyText", QCoreApplication.translate("TskDetailPanelForm", u"\u9009\u62e9 TSK \u6216 Chain\uff0c\u5728\u8fd9\u91cc\u67e5\u770b\u8be6\u60c5\u3002", None))
        TskDetailPanelForm.setProperty(u"riskTitleText", QCoreApplication.translate("TskDetailPanelForm", u"TSK \u8be6\u60c5", None))
        TskDetailPanelForm.setProperty(u"chainTitleText", QCoreApplication.translate("TskDetailPanelForm", u"Chain \u8be6\u60c5", None))
        TskDetailPanelForm.setProperty(u"riskSearchText", QCoreApplication.translate("TskDetailPanelForm", u"\u641c\u7d22\u76f8\u5173 Chain \u6216\u6210\u5458\u6761\u4ef6", None))
        TskDetailPanelForm.setProperty(u"chainSearchText", QCoreApplication.translate("TskDetailPanelForm", u"\u641c\u7d22 TSK \u6216\u6210\u5458\u6761\u4ef6", None))
        TskDetailPanelForm.setProperty(u"identityFormat", QCoreApplication.translate("TskDetailPanelForm", u"TSK {tsk_id}{count}{values}", None))
        TskDetailPanelForm.setProperty(u"countFormat", QCoreApplication.translate("TskDetailPanelForm", u" \u00d7 {count}", None))
        TskDetailPanelForm.setProperty(u"chainFormat", QCoreApplication.translate("TskDetailPanelForm", u"Chain {chain_id}", None))
        TskDetailPanelForm.setProperty(u"noFeaturesText", QCoreApplication.translate("TskDetailPanelForm", u"\u65e0\u989d\u5916\u7279\u5f81", None))
        TskDetailPanelForm.setProperty(u"coordinatesFormat", QCoreApplication.translate("TskDetailPanelForm", u"\u5750\u6807\uff1a{values}", None))
        TskDetailPanelForm.setProperty(u"instanceIdsFormat", QCoreApplication.translate("TskDetailPanelForm", u"\u5b9e\u4f8b\u7f16\u53f7\uff1a{values}", None))
        TskDetailPanelForm.setProperty(u"relatedChainsFormat", QCoreApplication.translate("TskDetailPanelForm", u"\u76f8\u5173 Chain \u00b7 {count} \u6761", None))
        TskDetailPanelForm.setProperty(u"membersTitleText", QCoreApplication.translate("TskDetailPanelForm", u"\u94fe\u4e0a TSK \u6210\u5458", None))
        TskDetailPanelForm.setProperty(u"relationHintText", QCoreApplication.translate("TskDetailPanelForm", u"\u4ee5\u4e0b\u4e3a\u6574\u6761\u94fe\u7684\u89c2\u5bdf\u4e0e\u9884\u6d4b\u5931\u6548\u7387\uff1b\u4e0d\u662f\u6240\u9009 TSK \u5bf9\u672c\u6b21\u5931\u6548\u7684\u5f52\u56e0\u3002\u98ce\u9669\u9875\u4f7f\u7528\u6570\u503c\u8bad\u7ec3\u5747\u503c\uff0c\u94fe\u6210\u5458\u4f7f\u7528\u5b9e\u4f8b\u5b9e\u9645\u6761\u4ef6\u3002", None))
        TskDetailPanelForm.setProperty(u"memberHintText", QCoreApplication.translate("TskDetailPanelForm", u"\u5355\u5b9e\u4f8b\u6982\u7387\u4f7f\u7528\u6210\u5458\u5b9e\u9645\u6761\u4ef6\uff1b\u540c\u4e00 TSK \u7684\u4e0d\u540c\u6761\u4ef6\u5206\u522b\u5217\u51fa\u3002\u94fe\u6574\u4f53\u98ce\u9669\u4e3a 1 \u2212 \u220f(1 \u2212 p_member)^count\uff0ccount \u4e3a\u540c\u6761\u4ef6\u6210\u5458\u5b9e\u4f8b\u6570\u3002\u6210\u5458\u6982\u7387\u4e0d\u8868\u793a\u67d0\u6b21\u89c2\u6d4b\u5931\u6548\u7531\u8be5\u6210\u5458\u9020\u6210\u3002", None))
        TskDetailPanelForm.setProperty(u"noRelationsText", QCoreApplication.translate("TskDetailPanelForm", u"\u672c\u7ed3\u679c\u6ca1\u6709\u53ef\u7528\u7684\u5173\u8054\u94fe\u4fe1\u606f\u3002", None))
        TskDetailPanelForm.setProperty(u"incompleteRelationsText", QCoreApplication.translate("TskDetailPanelForm", u"\u8be5 TSK \u7684\u5173\u8054\u4fe1\u606f\u4e0d\u5b8c\u6574\uff0c\u65e0\u6cd5\u786e\u5b9a\u76f8\u5173 Chain\u3002", None))
        TskDetailPanelForm.setProperty(u"noMatchingRelationsText", QCoreApplication.translate("TskDetailPanelForm", u"\u5b8c\u6574\u6a21\u677f\u4e2d\u6ca1\u6709\u5339\u914d\u8be5\u6761\u4ef6\u7684 Chain\u3002", None))
        TskDetailPanelForm.setProperty(u"noMembersText", QCoreApplication.translate("TskDetailPanelForm", u"\u672c\u7ed3\u679c\u672a\u4fdd\u5b58\u94fe\u6210\u5458\u98ce\u9669\u660e\u7ec6\u3002", None))
        TskDetailPanelForm.setProperty(u"noMatchesText", QCoreApplication.translate("TskDetailPanelForm", u"\u6ca1\u6709\u5339\u914d\u7684\u8bb0\u5f55\u3002", None))
        TskDetailPanelForm.setProperty(u"noPointFormat", QCoreApplication.translate("TskDetailPanelForm", u"{reason}\uff0c\u65e0\u6cd5\u5728\u62df\u5408\u6563\u70b9\u56fe\u4e2d\u6807\u51fa\uff1b\u53ef\u67e5\u770b\u8ba1\u6570\u4e0e\u6210\u5458\u8be6\u60c5\u3002", None))
        TskDetailPanelForm.setProperty(u"noTestsDetailText", QCoreApplication.translate("TskDetailPanelForm", u"\u6ca1\u6709\u6709\u6548\u6d4b\u8bd5", None))
        TskDetailPanelForm.setProperty(u"invalidPairText", QCoreApplication.translate("TskDetailPanelForm", u"\u7f3a\u5c11\u6709\u6548\u7684\u89c2\u5bdf\u6216\u9884\u6d4b\u6982\u7387", None))
        TskDetailPanelForm.setProperty(u"noTestsText", QCoreApplication.translate("TskDetailPanelForm", u"\u65e0\u6709\u6548\u6d4b\u8bd5", None))
        TskDetailPanelForm.setProperty(u"expandMembersFormat", QCoreApplication.translate("TskDetailPanelForm", u"\u5c55\u5f00\u94fe\u4e0a TSK\uff08{count} \u9879\uff09", None))
        TskDetailPanelForm.setProperty(u"collapseMembersFormat", QCoreApplication.translate("TskDetailPanelForm", u"\u6536\u8d77\u94fe\u4e0a TSK\uff08{count} \u9879\uff09", None))
        TskDetailPanelForm.setProperty(u"fitLinkText", QCoreApplication.translate("TskDetailPanelForm", u"\u67e5\u770b\u62df\u5408\u7ed3\u679c", None))
        TskDetailPanelForm.setProperty(u"riskStatisticsText", QCoreApplication.translate("TskDetailPanelForm", u"\u98ce\u9669\u7edf\u8ba1\u4e0e\u533a\u95f4\u8bf4\u660e", None))
        TskDetailPanelForm.setProperty(u"chainStatisticsText", QCoreApplication.translate("TskDetailPanelForm", u"Chain \u7edf\u8ba1\u4e0e\u6b8b\u5dee", None))
        TskDetailPanelForm.setProperty(u"riskRecordText", QCoreApplication.translate("TskDetailPanelForm", u"TSK \u5b8c\u6574\u8bb0\u5f55", None))
        TskDetailPanelForm.setProperty(u"chainRecordText", QCoreApplication.translate("TskDetailPanelForm", u"Chain \u5b8c\u6574\u8bb0\u5f55", None))
        TskDetailPanelForm.setProperty(u"memberRecordText", QCoreApplication.translate("TskDetailPanelForm", u"\u6210\u5458\u5b8c\u6574\u8bb0\u5f55", None))
        TskDetailPanelForm.setProperty(u"exposureHintText", QCoreApplication.translate("TskDetailPanelForm", u"\u94fe\u6d4b\u8bd5\u66b4\u9732\u4e0d\u662f\u72ec\u7acb\u6837\u672c\u91cf\u3002", None))
        TskDetailPanelForm.setProperty(u"intervalErrorFormat", QCoreApplication.translate("TskDetailPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0\uff1a{error}", None))
        TskDetailPanelForm.setProperty(u"probabilityText", QCoreApplication.translate("TskDetailPanelForm", u"\u5355\u5b9e\u4f8b\u6982\u7387", None))
        TskDetailPanelForm.setProperty(u"intervalText", QCoreApplication.translate("TskDetailPanelForm", u"\u7f6e\u4fe1\u533a\u95f4", None))
        TskDetailPanelForm.setProperty(u"statusText", QCoreApplication.translate("TskDetailPanelForm", u"\u72b6\u6001", None))
        TskDetailPanelForm.setProperty(u"fitStatusText", QCoreApplication.translate("TskDetailPanelForm", u"\u62df\u5408\u72b6\u6001", None))
        TskDetailPanelForm.setProperty(u"supportText", QCoreApplication.translate("TskDetailPanelForm", u"\u652f\u6301\u72b6\u6001", None))
        TskDetailPanelForm.setProperty(u"observedText", QCoreApplication.translate("TskDetailPanelForm", u"\u89c2\u5bdf\u5931\u6548\u7387", None))
        TskDetailPanelForm.setProperty(u"predictedText", QCoreApplication.translate("TskDetailPanelForm", u"\u9884\u6d4b\u5931\u6548\u7387", None))
        TskDetailPanelForm.setProperty(u"testedText", QCoreApplication.translate("TskDetailPanelForm", u"\u6709\u6548\u6d4b\u8bd5\u6570", None))
        TskDetailPanelForm.setProperty(u"layoutCountText", QCoreApplication.translate("TskDetailPanelForm", u"\u6a21\u677f\u5b9e\u4f8b\u6570", None))
        TskDetailPanelForm.setProperty(u"activeCountText", QCoreApplication.translate("TskDetailPanelForm", u"\u6709\u6548\u5b9e\u4f8b\u6570", None))
        TskDetailPanelForm.setProperty(u"chainCountText", QCoreApplication.translate("TskDetailPanelForm", u"\u6709\u6548 Chain \u6570", None))
        TskDetailPanelForm.setProperty(u"exposureText", QCoreApplication.translate("TskDetailPanelForm", u"\u94fe\u6d4b\u8bd5\u66b4\u9732", None))
        TskDetailPanelForm.setProperty(u"intervalMethodText", QCoreApplication.translate("TskDetailPanelForm", u"\u533a\u95f4\u65b9\u6cd5", None))
        TskDetailPanelForm.setProperty(u"intervalErrorText", QCoreApplication.translate("TskDetailPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0", None))
        TskDetailPanelForm.setProperty(u"reasonText", QCoreApplication.translate("TskDetailPanelForm", u"\u8bf4\u660e", None))
        TskDetailPanelForm.setProperty(u"failedText", QCoreApplication.translate("TskDetailPanelForm", u"Fail", None))
        TskDetailPanelForm.setProperty(u"passedText", QCoreApplication.translate("TskDetailPanelForm", u"Pass", None))
        TskDetailPanelForm.setProperty(u"missingText", QCoreApplication.translate("TskDetailPanelForm", u"Missing", None))
        TskDetailPanelForm.setProperty(u"residualText", QCoreApplication.translate("TskDetailPanelForm", u"\u6b8b\u5dee\uff08\u89c2\u5bdf \u2212 \u9884\u6d4b\uff09", None))
        TskDetailPanelForm.setProperty(u"devianceText", QCoreApplication.translate("TskDetailPanelForm", u"Deviance residual", None))
        TskDetailPanelForm.setProperty(u"boundaryLowText", QCoreApplication.translate("TskDetailPanelForm", u"\u96f6\u8fb9\u754c\u4f30\u8ba1", None))
        TskDetailPanelForm.setProperty(u"boundaryHintText", QCoreApplication.translate("TskDetailPanelForm", u"\u96f6\u8fb9\u754c\u662f\u5f53\u524d\u6a21\u578b\u4e0e\u6570\u636e\u4e0b\u7684\u8fb9\u754c\u4f30\u8ba1\uff0c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002\u8bf7\u7ed3\u5408\u4e0a\u9650\u9605\u8bfb\u3002", None))
        TskDetailPanelForm.setProperty(u"intervalUnavailableText", QCoreApplication.translate("TskDetailPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528", None))
        TskDetailPanelForm.setProperty(u"noDataSupportText", QCoreApplication.translate("TskDetailPanelForm", u"\u65e0\u6709\u6548\u6570\u636e\uff08\u4e0d\u5916\u63a8\uff09", None))
        TskDetailPanelForm.setProperty(u"upperIntervalFormat", QCoreApplication.translate("TskDetailPanelForm", u"\u5355\u4fa7 {confidence} \u4e0a\u9650\uff1a{upper}", None))
        TskDetailPanelForm.setProperty(u"upperApproxIntervalFormat", QCoreApplication.translate("TskDetailPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09\uff1a{upper}", None))
        TskDetailPanelForm.setProperty(u"twoSidedIntervalFormat", QCoreApplication.translate("TskDetailPanelForm", u"{confidence} \u533a\u95f4\uff1a{lower} \u2013 {upper}", None))
        TskDetailPanelForm.setProperty(u"conservativeIntervalFormat", QCoreApplication.translate("TskDetailPanelForm", u"{confidence} \u4fdd\u5b88\u533a\u95f4\uff1a{lower} \u2013 {upper}", None))
        TskDetailPanelForm.setProperty(u"pageFormat", QCoreApplication.translate("TskDetailPanelForm", u"\u7b2c {page} / {pages} \u9875 \u00b7 {count} \u9879", None))
        TskDetailPanelForm.setProperty(u"previousText", QCoreApplication.translate("TskDetailPanelForm", u"\u4e0a\u4e00\u9875", None))
        TskDetailPanelForm.setProperty(u"nextText", QCoreApplication.translate("TskDetailPanelForm", u"\u4e0b\u4e00\u9875", None))
        TskDetailPanelForm.setProperty(u"statusTranslations", QCoreApplication.translate("TskDetailPanelForm", u"ok=\u53ef\u7528\n"
"no_data=\u65e0\u6570\u636e\n"
"not_identifiable=\u4e0d\u53ef\u5355\u72ec\u8bc6\u522b\n"
"unidentifiable=\u4e0d\u53ef\u5355\u72ec\u8bc6\u522b\n"
"interval_unavailable=\u533a\u95f4\u4e0d\u53ef\u7528\n"
"fit_not_converged=\u672a\u6536\u655b\n"
"not_converged=\u672a\u6536\u655b\n"
"boundary_low=\u96f6\u8fb9\u754c\u4f30\u8ba1\n"
"boundary_unbounded=\u7cfb\u6570\u8d8b\u5411\u65e0\u7a77\u8fb9\u754c\n"
"unavailable=\u4e0d\u53ef\u7528\n"
"outside_model_domain=\u5b9a\u4e49\u57df\u5916\n"
"observed=\u6709\u6709\u6548\u6570\u636e\u652f\u6301\n"
"no_active_support=\u672c\u7ec4\u65e0\u6709\u6548\u652f\u6301\n"
"extrapolated=\u6a21\u677f\u5916\u7ec4\u5408\n"
"reference_coding=\u53c2\u8003\u7c7b\u522b\u7f16\u7801\n"
"computation_limited=\u8ba1\u7b97\u53d7\u9650\n"
"model_interval_mismatch=\u4f30\u8ba1\u4e0e\u533a\u95f4\u4e0d\u4e00\u81f4", None))
        TskDetailPanelForm.setProperty(u"documentStyle", QCoreApplication.translate("TskDetailPanelForm", u"body { color: @text@; font-size: 12px; } h3 { font-size: 15px; margin-top: 12px; margin-bottom: 5px; } h4 { font-size: 13px; margin-top: 9px; margin-bottom: 4px; } p { margin-top: 5px; margin-bottom: 6px; } .conditions, .coordinates { font-size: 11px; color: @text@; } .caption { font-size: 11px; color: @text@; } td { padding: 3px 4px; } .card { background-color: @card@; } a { color: @link@; text-decoration: none; } .raw-record { font-family: monospace; font-size: 10px; }", None))
        self.titleLabel.setText(QCoreApplication.translate("TskDetailPanelForm", u"\u7ed3\u679c\u8be6\u60c5", None))
        self.closeButton.setText(QCoreApplication.translate("TskDetailPanelForm", u"\u00d7", None))
#if QT_CONFIG(tooltip)
        self.closeButton.setToolTip(QCoreApplication.translate("TskDetailPanelForm", u"\u5173\u95ed\u8be6\u60c5\u4fa7\u680f", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(accessibility)
        self.closeButton.setAccessibleName(QCoreApplication.translate("TskDetailPanelForm", u"\u5173\u95ed\u8be6\u60c5\u4fa7\u680f", None))
#endif // QT_CONFIG(accessibility)
        self.searchLineEdit.setPlaceholderText(QCoreApplication.translate("TskDetailPanelForm", u"\u641c\u7d22\u76f8\u5173 Chain \u6216\u6210\u5458\u6761\u4ef6", None))
#if QT_CONFIG(accessibility)
        self.searchLineEdit.setAccessibleName(QCoreApplication.translate("TskDetailPanelForm", u"\u641c\u7d22\u8be6\u60c5", None))
#endif // QT_CONFIG(accessibility)
        self.detailsBrowser.setHtml(QCoreApplication.translate("TskDetailPanelForm", u"<p>\u9009\u62e9 TSK \u6216 Chain\uff0c\u5728\u8fd9\u91cc\u67e5\u770b\u8be6\u60c5\u3002</p>", None))
    # retranslateUi

