# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_fixed_zero_assumption_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QCheckBox, QDialog,
    QDialogButtonBox, QPlainTextEdit, QSizePolicy, QVBoxLayout,
    QWidget)

class Ui_TskFixedZeroAssumptionDialogForm(object):
    def setupUi(self, TskFixedZeroAssumptionDialogForm):
        if not TskFixedZeroAssumptionDialogForm.objectName():
            TskFixedZeroAssumptionDialogForm.setObjectName(u"TskFixedZeroAssumptionDialogForm")
        TskFixedZeroAssumptionDialogForm.resize(540, 350)
        TskFixedZeroAssumptionDialogForm.setMinimumSize(QSize(320, 220))
        TskFixedZeroAssumptionDialogForm.setSizeGripEnabled(True)
        self.dialogLayout = QVBoxLayout(TskFixedZeroAssumptionDialogForm)
        self.dialogLayout.setSpacing(8)
        self.dialogLayout.setObjectName(u"dialogLayout")
        self.dialogLayout.setContentsMargins(12, 12, 12, 12)
        self.detailsTextEdit = QPlainTextEdit(TskFixedZeroAssumptionDialogForm)
        self.detailsTextEdit.setObjectName(u"detailsTextEdit")
        self.detailsTextEdit.setReadOnly(True)

        self.dialogLayout.addWidget(self.detailsTextEdit)

        self.simulationDiagnosticsCheckBox = QCheckBox(TskFixedZeroAssumptionDialogForm)
        self.simulationDiagnosticsCheckBox.setObjectName(u"simulationDiagnosticsCheckBox")
        self.simulationDiagnosticsCheckBox.setVisible(False)
        self.simulationDiagnosticsCheckBox.setChecked(False)

        self.dialogLayout.addWidget(self.simulationDiagnosticsCheckBox)

        self.simulationDiagnosticsTextEdit = QPlainTextEdit(TskFixedZeroAssumptionDialogForm)
        self.simulationDiagnosticsTextEdit.setObjectName(u"simulationDiagnosticsTextEdit")
        self.simulationDiagnosticsTextEdit.setVisible(False)
        self.simulationDiagnosticsTextEdit.setReadOnly(True)
        self.simulationDiagnosticsTextEdit.setMinimumSize(QSize(0, 100))
        self.simulationDiagnosticsTextEdit.setMaximumSize(QSize(16777215, 220))

        self.dialogLayout.addWidget(self.simulationDiagnosticsTextEdit)

        self.buttonBox = QDialogButtonBox(TskFixedZeroAssumptionDialogForm)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Close)

        self.dialogLayout.addWidget(self.buttonBox)


        self.retranslateUi(TskFixedZeroAssumptionDialogForm)
        self.buttonBox.rejected.connect(TskFixedZeroAssumptionDialogForm.reject)

        QMetaObject.connectSlotsByName(TskFixedZeroAssumptionDialogForm)
    # setupUi

    def retranslateUi(self, TskFixedZeroAssumptionDialogForm):
        TskFixedZeroAssumptionDialogForm.setProperty(u"simulationTitle", QCoreApplication.translate("TskFixedZeroAssumptionDialogForm", u"\u81ea\u7531\u8fb9\u754c\u6a21\u62df\u68c0\u9a8c\u8be6\u60c5\uff08\u5b9e\u9a8c\u6027\uff09", None))
        TskFixedZeroAssumptionDialogForm.setWindowTitle(QCoreApplication.translate("TskFixedZeroAssumptionDialogForm", u"\u56fa\u5b9a\u96f6\u5904\u7406\u8be6\u60c5", None))
        self.detailsTextEdit.setProperty(u"simulationFormat", QCoreApplication.translate("TskFixedZeroAssumptionDialogForm", u"\u81ea\u7531\u8fb9\u754c\u6a21\u62df\u68c0\u9a8c\uff08\u5b9e\u9a8c\u6027\uff09\n"
"\n"
"{warning}\n"
"\n"
"\u6a21\u62df\u8bbe\u7f6e\uff1a\u6bcf\u4e2a\u7279\u5f81\u8bf7\u6c42 {replicates} \u6b21\uff1b\u968f\u673a\u79cd\u5b50 {seed}\u3002\n"
"\u6bcf\u6b21\u91cd\u62df\u5408\u5b8c\u6574\u4e0e\u5220\u7279\u5f81\u6a21\u578b\uff0c\u96f6\u98ce\u9669\u4fdd\u6301\u81ea\u7531\u3002\n"
"{scope}\n"
"\n"
"{summary}", None))
        self.detailsTextEdit.setProperty(u"simulationFeatureFormat", QCoreApplication.translate("TskFixedZeroAssumptionDialogForm", u"{feature}\uff1a{decision}\n"
"\u6a21\u62df p\uff1a{p_value}\uff1bHolm \u6a21\u62df p\uff1a{p_adjusted}\n"
"\u5b8c\u6210 {completed} / {requested}\uff1b\u5931\u8d25 {failed}\uff1b\u8d85\u8d8a\u6b21\u6570 {exceedances}\n"
"MC \u533a\u95f4\uff1a{mc_interval}\uff1bMC \u6807\u51c6\u8bef\uff1a{mc_se}\n"
"\u89c2\u6d4b\u5b8c\u6574\u6a21\u578b\u96f6\u98ce\u9669 TSK\uff1a{full_zero}\uff1b\u5220\u7279\u5f81\u6a21\u578b\uff1a{reduced_zero}\n"
"\u6a21\u62df\u96f6\u96c6\u5408\u53d8\u5316\u6b21\u6570\uff1a\u5b8c\u6574\u6a21\u578b {full_changes}\uff0c\u5220\u7279\u5f81\u6a21\u578b {reduced_changes}\n"
"{reason}", None))
        self.detailsTextEdit.setProperty(u"displayFormat", QCoreApplication.translate("TskFixedZeroAssumptionDialogForm", u"\u56fa\u5b9a\u96f6\u5904\u7406\u6761\u4ef6\u5206\u6790\n"
"\n"
"\u5f3a\u5236\u5f52\u96f6\u7684 TSK\uff1a{tsk_ids}\n"
"\n"
"{warning}\n"
"\n"
"{scope}", None))
        self.detailsTextEdit.setProperty(u"defaultWarning", QCoreApplication.translate("TskFixedZeroAssumptionDialogForm", u"\u8fd9\u4e9b TSK \u7684\u98ce\u9669\u89e6\u53ca\u8ba1\u7b97\u4e0b\u8fb9\u754c\uff0c\u672c\u6b21\u6761\u4ef6\u5206\u6790\u5c06\u5176\u98ce\u9669\u8d21\u732e\u5f3a\u5236\u56fa\u5b9a\u4e3a 0\u3002\u82e5\u5b9e\u9645\u98ce\u9669\u975e\u96f6\uff0c\u53ea\u662f\u6837\u672c\u4e0d\u8db3\u800c\u672a\u89c2\u6d4b\u5230\u5931\u6548\uff0c\u5176\u4ed6\u56e0\u7d20\u7684\u6548\u5e94\u53ca\u533a\u95f4\u53ef\u80fd\u6709\u504f\u5dee\uff1b\u533a\u95f4\u4f9d\u8d56\u56fa\u5b9a\u7ea6\u675f\uff0c\u4e0d\u5305\u542b\u89e3\u9664\u8be5\u7ea6\u675f\u7684\u4e0d\u786e\u5b9a\u6027\u3002", None))
        self.simulationDiagnosticsCheckBox.setText(QCoreApplication.translate("TskFixedZeroAssumptionDialogForm", u"\u663e\u793a\u5b8c\u6574\u6a21\u62df\u8bca\u65ad\u4e0e\u8f68\u8ff9", None))
    # retranslateUi

