"""Compact, local hover lookup for process-rendered Plot Inspector tiles.

Workers send ``<IIddd`` records (source lane, source point index, x, y, radius).
The parent retains those numeric records and a stable nine-bucket grid instead
of allocating a HoverPoint, QPointF, and lookup keys for every rendered point.
Original PlotPoints remain in the parent's series; a successful query resolves
that original object and materializes only its one lightweight CompactHit.

The numeric arrays are not cyclic-GC tracked. The index, its bounded lazy key
caches, and the original source data still are. This reduces allocations; it
does not disable garbage collection or promise the absence of GC pauses.
"""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
import gc
import math
import sys
from typing import Any
import weakref

import numpy as np

from excel_data_analysis.comparison_models import PlotPoint, PlotSeries
from PySide6.QtCore import QPointF, QSize
from PySide6.QtGui import QImage


HOVER_DTYPE = np.dtype([
    ("lane", "<u4"), ("point_index", "<u4"),
    ("x", "<f8"), ("y", "<f8"), ("radius", "<f8"),
])
_BUCKET_SIZE = 24
_KEY_CACHE_LIMIT = 16
_KEY_CACHE_BYTES = 64 * 1024


@dataclass(frozen=True, slots=True)
class CompactHit:
    point: PlotPoint
    x: float
    y: float
    radius: float
    record_index: int

    @property
    def position(self) -> QPointF:
        """Create Qt coordinates only for a requested hit or overlay."""
        return QPointF(self.x, self.y)


class CompactHoverIndex:
    """Store one numeric row per visible point and a stable local grid index.

    The ``series`` argument is retained by identity, without copying its tuple
    or points.  Records may reference a non-contiguous subset of original
    lanes.  Dense bucket offsets handle normal plot dimensions; a sparse
    numeric fallback bounds memory when points are unusually far apart.
    """

    __slots__ = (
        "records", "series", "_order", "_offsets", "_occupied",
        "_min_x", "_min_y", "_width", "_height", "_point_keys", "_merge_keys",
        "_merge_query_keys", "_merge_query_indices",
    )

    def __init__(self, hover_bytes: bytes, series: tuple[PlotSeries, ...]) -> None:
        if not isinstance(hover_bytes, (bytes, bytearray, memoryview)):
            raise TypeError("Hover wire data must be bytes-like")
        # A caller-owned mutable buffer must not invalidate the spatial index.
        if not isinstance(hover_bytes, bytes):
            hover_bytes = bytes(hover_bytes)
        if len(hover_bytes) % HOVER_DTYPE.itemsize:
            raise ValueError("Hover wire data must contain complete 32-byte records")
        self.records = np.frombuffer(hover_bytes, dtype=HOVER_DTYPE)
        self.records.flags.writeable = False
        self.series = series
        self._point_keys: OrderedDict[tuple[str, str, int, str], int | None] = OrderedDict()
        self._merge_keys: OrderedDict[tuple[str, int, str], np.ndarray] = OrderedDict()
        self._merge_query_keys: weakref.ReferenceType | None = None
        self._merge_query_indices: np.ndarray | None = None
        self._min_x = self._min_y = self._width = self._height = 0
        self._occupied: np.ndarray | None = None
        if not len(self.records):
            self._order = np.empty(0, dtype=np.int32)
            self._offsets = np.zeros(1, dtype=np.int64)
            self._make_readonly()
            return

        # Bounds checks visit numerical arrays and a handful of lanes, never
        # materializing per-point Python coordinates, keys, or wrappers.
        for field in ("x", "y", "radius"):
            if not np.isfinite(self.records[field]).all():
                raise ValueError(f"Hover {field} values must be finite")
        if (self.records["radius"] < 0).any():
            raise ValueError("Hover radius values must be nonnegative")
        lanes = self.records["lane"]
        if int(lanes.max()) >= len(series):
            raise IndexError("Hover record refers to an unavailable source lane")
        for lane in np.unique(lanes):
            lane_index = int(lane)
            if int(self.records["point_index"][lanes == lane].max()) >= len(series[lane_index].points):
                raise IndexError("Hover record refers to an unavailable source point")

        bucket_x = np.floor(self.records["x"] / _BUCKET_SIZE)
        bucket_y = np.floor(self.records["y"] / _BUCKET_SIZE)
        # Far beyond usable Qt coordinates; this also keeps linear bucket IDs
        # safely within int64 before converting or multiplying their arrays.
        if max(float(np.abs(bucket_x).max()), float(np.abs(bucket_y).max())) >= 2**30:
            raise ValueError("Hover coordinates exceed the numeric grid range")
        bucket_x = bucket_x.astype(np.int64)
        bucket_y = bucket_y.astype(np.int64)
        self._min_x, self._min_y = int(bucket_x.min()), int(bucket_y.min())
        self._width = int(bucket_x.max()) - self._min_x + 1
        self._height = int(bucket_y.max()) - self._min_y + 1
        bucket_ids = (bucket_x - self._min_x) * self._height + bucket_y - self._min_y
        order = np.argsort(bucket_ids, kind="stable")
        self._order = order.astype(np.int32) if len(order) < 2**31 else order
        grid_count = self._width * self._height
        if grid_count <= min(1_000_000, max(4096, len(self.records) * 8)):
            counts = np.bincount(bucket_ids, minlength=grid_count)
        else:
            self._occupied, counts = np.unique(bucket_ids, return_counts=True)
        self._offsets = np.empty(len(counts) + 1, dtype=np.int64)
        self._offsets[0] = 0
        np.cumsum(counts, out=self._offsets[1:])
        self._make_readonly()

    def _make_readonly(self) -> None:
        for array in (self._order, self._offsets, self._occupied):
            if array is not None:
                array.flags.writeable = False

    @property
    def record_count(self) -> int:
        return len(self.records)

    @property
    def array_nbytes(self) -> int:
        return sum(array.nbytes for array in self.numeric_arrays())

    @property
    def cache_nbytes(self) -> int:
        """Conservative retained size of lazy pin and merge-query caches.

        Keys refer to existing strings in normal use. Counting their referenced
        sizes as well keeps the estimate safe for keys constructed by callers.
        OrderedDict's reported size includes its table and linked-list nodes.
        """
        size = sys.getsizeof(self._point_keys) + sys.getsizeof(self._merge_keys)
        for key, index in self._point_keys.items():
            size += self._key_nbytes(key) + sys.getsizeof(index)
        for key, indices in self._merge_keys.items():
            size += self._key_nbytes(key) + sys.getsizeof(indices)
        if self._merge_query_indices is not None:
            size += sys.getsizeof(self._merge_query_keys) + sys.getsizeof(self._merge_query_indices)
        return size

    @staticmethod
    def _key_nbytes(key: tuple) -> int:
        return sys.getsizeof(key) + sum(sys.getsizeof(value) for value in key)

    @property
    def _base_nbytes(self) -> int:
        size = sys.getsizeof(self)
        for array in self.numeric_arrays():
            size += sys.getsizeof(array)
            if not array.flags.owndata:
                size += array.nbytes
        # The records retain their immutable wire bytes as the NumPy base.
        size += sys.getsizeof(self.records.base) - self.records.nbytes
        return size

    @property
    def estimated_nbytes(self) -> int:
        """Current index storage, excluding shared source series and images."""
        return self._base_nbytes + self.cache_nbytes

    @property
    def cache_budget_nbytes(self) -> int:
        return _KEY_CACHE_BYTES

    @property
    def reserved_nbytes(self) -> int:
        """Index size plus its maximum lazy-cache growth for tile LRU budgets."""
        return self._base_nbytes + _KEY_CACHE_BYTES

    def _trim_key_cache(self, active: OrderedDict) -> None:
        # An unusually large merge match is returned to its caller but is not
        # retained. Other entries can therefore never multiply its size.
        while active and (len(active) > _KEY_CACHE_LIMIT or self.cache_nbytes > _KEY_CACHE_BYTES):
            active.popitem(last=False)

    def numeric_arrays(self) -> tuple[np.ndarray, ...]:
        """Persistent numeric arrays, with no duplicate storage views."""
        arrays = (self.records, self._order, self._offsets)
        return arrays if self._occupied is None else (*arrays, self._occupied)

    def storage_info(self) -> dict[str, Any]:
        arrays = self.numeric_arrays()
        return {
            "record_count": self.record_count,
            "array_nbytes": self.array_nbytes,
            "cache_nbytes": self.cache_nbytes,
            "estimated_nbytes": self.estimated_nbytes,
            "reserved_nbytes": self.reserved_nbytes,
            "numeric_array_count": len(arrays),
            "gc_tracked_array_count": sum(gc.is_tracked(array) for array in arrays),
            "contains_object_dtype": any(array.dtype.hasobject for array in arrays),
            "index_gc_tracked": gc.is_tracked(self),
            "sparse_buckets": self._occupied is not None,
        }

    def candidate_indices(self, x: float, y: float) -> np.ndarray:
        """Return nearby original record indices in production hit order.

        Within each of the three x buckets the three adjacent y buckets are
        contiguous.  Their offsets let us read three short slices instead of
        scanning any other point.  Stable sorting preserves original record
        order inside a bucket and therefore the production tie-breaking rule.
        """
        if not self.record_count or not (math.isfinite(x) and math.isfinite(y)):
            return self._order[:0]
        base_x, base_y = math.floor(x / _BUCKET_SIZE), math.floor(y / _BUCKET_SIZE)
        low_y = max(0, base_y - 1 - self._min_y)
        high_y = min(self._height, base_y + 2 - self._min_y)
        if low_y >= high_y:
            return self._order[:0]
        pieces = []
        for dx in (-1, 0, 1):
            column = base_x + dx - self._min_x
            if not 0 <= column < self._width:
                continue
            low = column * self._height + low_y
            high = column * self._height + high_y
            if self._occupied is not None:
                low, high = np.searchsorted(self._occupied, (low, high))
            start, end = int(self._offsets[low]), int(self._offsets[high])
            if start != end:
                pieces.append(self._order[start:end])
        if not pieces:
            return self._order[:0]
        return pieces[0] if len(pieces) == 1 else np.concatenate(pieces)

    def hit_index(self, x: float, y: float) -> int | None:
        """Find the nearest eligible point without creating a Python wrapper."""
        candidates = self.candidate_indices(x, y)
        if not len(candidates):
            return None
        delta_x = self.records["x"][candidates] - x
        delta_y = self.records["y"][candidates] - y
        distances = np.hypot(delta_x, delta_y)
        limits = self.records["radius"][candidates] + 5.0
        # np.hypot and math.hypot can differ by one ULP. Correct only values
        # close to acceptance boundaries or a nearest-distance tie, retaining
        # the original viewport's inclusive radius and strict 12-pixel limit.
        epsilon = 1e-12
        boundary = np.flatnonzero((np.abs(distances - 12.0) <= epsilon)
                                  | (np.abs(distances - limits) <= epsilon))
        for offset in boundary:
            distances[offset] = math.hypot(float(delta_x[offset]), float(delta_y[offset]))
        valid = (distances < 12.0) & (distances <= limits)
        distances[~valid] = np.inf
        best = int(np.argmin(distances))
        distance = float(distances[best])
        if not distance < 12.0:
            return None
        if distance:
            close = np.flatnonzero(np.abs(distances - distance) <= epsilon)
            if len(close) > 1:
                nearest = 12.0
                for offset in close:
                    delta = math.hypot(float(delta_x[offset]), float(delta_y[offset]))
                    if delta <= limits[offset] and delta < nearest:
                        best, nearest = int(offset), delta
        return int(candidates[best])

    def point_at(self, record_index: int) -> PlotPoint:
        record = self.records[record_index]
        return self.series[int(record["lane"])].points[int(record["point_index"])]

    def record_hit(self, record_index: int) -> CompactHit:
        record = self.records[record_index]
        return CompactHit(
            self.point_at(record_index), float(record["x"]), float(record["y"]),
            float(record["radius"]), int(record_index),
        )

    def hit_test(self, x: float, y: float) -> CompactHit | None:
        index = self.hit_index(x, y)
        return self.record_hit(index) if index is not None else None

    def point_key_index(self, key: tuple[str, str, int, str]) -> int | None:
        """Resolve a pin lazily; duplicate keys use the production last match.

        This scan happens only on the first request for a key in this tile.
        It creates neither a tuple key nor a persistent wrapper per point.
        """
        if key in self._point_keys:
            self._point_keys.move_to_end(key)
            return self._point_keys[key]
        dataset, source_file, row, raw_column = key
        match = None
        for index in range(self.record_count - 1, -1, -1):
            point = self.point_at(index)
            if (point.dataset_id == dataset and point.source_file == source_file
                    and point.row_number == row and point.raw_column == raw_column):
                match = index
                break
        self._point_keys[key] = match
        self._trim_key_cache(self._point_keys)
        return match

    def merge_key_indices(self, key: tuple[str, int, str]) -> np.ndarray:
        """Lazily resolve the same outlier-only merge overlay as production."""
        if key in self._merge_keys:
            self._merge_keys.move_to_end(key)
            return self._merge_keys[key]
        dataset, row, raw_column = key

        def matches():
            for index in range(self.record_count):
                point = self.point_at(index)
                if (point.outlier and point.dataset_id == dataset
                        and point.row_number == row and point.raw_column == raw_column):
                    yield index

        result = np.fromiter(matches(), dtype=self._order.dtype)
        result.flags.writeable = False
        self._merge_keys[key] = result
        self._trim_key_cache(self._merge_keys)
        return result


    def merge_keys_indices(self, keys: frozenset[tuple[str, int, str]]) -> np.ndarray:
        """Resolve a whole highlighted block with one scan of this tile.

        Merge blocks can contain many keys belonging to other metrics. Scanning
        once per key would turn a hover repaint into O(keys * tile points) work
        and thrash the small single-key cache. Membership checks here are local
        to raw outliers, and no per-point identity keys are retained.

        The viewport keeps its immutable key set while a hover is active. A weak
        identity reference lets repeated paints reuse the numeric result without
        retaining a potentially large set beyond that hover's lifetime. Query
        results share the same byte budget as the pin and single-key caches.
        """
        if not isinstance(keys, frozenset):
            raise TypeError("Merged hover keys must be an immutable frozenset")
        if self._merge_query_keys is not None and self._merge_query_keys() is keys:
            return self._merge_query_indices

        def matches():
            if not keys:
                return
            for index in range(self.record_count):
                point = self.point_at(index)
                if point.outlier and (point.dataset_id, point.row_number, point.raw_column) in keys:
                    yield index

        result = np.fromiter(matches(), dtype=self._order.dtype)
        result.flags.writeable = False
        self._merge_query_keys = None
        self._merge_query_indices = None
        key_reference = weakref.ref(keys)
        result_cost = sys.getsizeof(key_reference) + sys.getsizeof(result)
        # Give the current block priority over older single-key lookups. A very
        # large result is still returned, but will not be retained by the tile.
        minimum_cache_cost = sys.getsizeof(OrderedDict()) * 2
        if result_cost + minimum_cache_cost <= _KEY_CACHE_BYTES:
            while self.cache_nbytes + result_cost > _KEY_CACHE_BYTES:
                if self._merge_keys:
                    self._merge_keys.popitem(last=False)
                elif self._point_keys:
                    self._point_keys.popitem(last=False)
                else:
                    break
            if self.cache_nbytes + result_cost <= _KEY_CACHE_BYTES:
                self._merge_query_keys = key_reference
                self._merge_query_indices = result
        return result


@dataclass(slots=True)
class CompactPayload:
    image: QImage
    index: CompactHoverIndex
    metadata: dict[str, Any]

    def logical_size(self) -> QSize:
        return self.image.deviceIndependentSize().toSize()

    def __getattr__(self, name: str) -> Any:
        try:
            return self.metadata[name]
        except KeyError as error:
            raise AttributeError(name) from error

