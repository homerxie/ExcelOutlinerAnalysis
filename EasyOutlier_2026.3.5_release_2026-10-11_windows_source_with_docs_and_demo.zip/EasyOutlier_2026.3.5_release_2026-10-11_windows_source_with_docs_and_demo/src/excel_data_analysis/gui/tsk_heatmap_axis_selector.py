"""Ordered axis dimensions; the selector and popup layouts live in Qt forms."""
from __future__ import annotations

from PySide6.QtCore import QPoint, Property, QSignalBlocker, Qt, Signal
from PySide6.QtWidgets import QFrame, QListWidgetItem, QWidget

from .ui_tsk_heatmap_axis_popup import Ui_TskHeatmapAxisPopupForm
from .ui_tsk_heatmap_axis_selector import Ui_TskHeatmapAxisSelectorForm


class TskHeatmapAxisPopup(QFrame):
    dimensions_changed = Signal(list)

    def __init__(self, parent=None):
        super().__init__(parent, Qt.Popup)
        self.ui = Ui_TskHeatmapAxisPopupForm()
        self.ui.setupUi(self)
        self._dimensions = {}
        self.ui.dimensionsListWidget.itemChanged.connect(self._item_changed)
        self.ui.dimensionsListWidget.currentRowChanged.connect(self._update_buttons)
        self.ui.moveUpButton.clicked.connect(lambda: self._move(-1))
        self.ui.moveDownButton.clicked.connect(lambda: self._move(1))

    @property
    def selected_dimensions(self):
        items = self.ui.dimensionsListWidget
        return [items.item(index).data(Qt.UserRole) for index in range(items.count())
                if items.item(index).checkState() == Qt.Checked]

    def set_dimensions(self, dimensions, selected):
        """Silently bind the ordered selection, retaining the active list item."""
        self._dimensions = dict(dimensions)
        selected = list(dict.fromkeys(key for key in selected if key in self._dimensions))
        items = self.ui.dimensionsListWidget
        current = items.currentItem()
        current_key = current.data(Qt.UserRole) if current is not None else None
        selected_set = set(selected)
        keys = selected + [key for key in self._dimensions if key not in selected_set]
        with QSignalBlocker(items):
            items.clear()
            for key in keys:
                item = QListWidgetItem(str(self._dimensions[key]), items)
                item.setData(Qt.UserRole, key)
                item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
                item.setCheckState(Qt.Checked if key in selected_set else Qt.Unchecked)
                item.setToolTip(str(self._dimensions[key]))
            if current_key in keys:
                items.setCurrentRow(keys.index(current_key))
            elif keys:
                items.setCurrentRow(0)
        self._update_buttons()

    def _update_buttons(self, *_args):
        current = self.ui.dimensionsListWidget.currentItem()
        selected = self.selected_dimensions
        key = current.data(Qt.UserRole) if current is not None else None
        index = selected.index(key) if key in selected else -1
        self.ui.moveUpButton.setEnabled(index > 0)
        self.ui.moveDownButton.setEnabled(0 <= index < len(selected) - 1)

    def _item_changed(self, item):
        with QSignalBlocker(self.ui.dimensionsListWidget):
            self.ui.dimensionsListWidget.setCurrentItem(item)
        selected = self.selected_dimensions
        self.set_dimensions(self._dimensions, selected)
        self.dimensions_changed.emit(selected)

    def _move(self, direction):
        current = self.ui.dimensionsListWidget.currentItem()
        selected = self.selected_dimensions
        key = current.data(Qt.UserRole) if current is not None else None
        if key not in selected:
            return
        index = selected.index(key)
        target = index + direction
        if not 0 <= target < len(selected):
            return
        selected[index], selected[target] = selected[target], selected[index]
        self.set_dimensions(self._dimensions, selected)
        self.dimensions_changed.emit(selected)


class TskHeatmapAxisSelector(QWidget):
    dimensions_changed = Signal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskHeatmapAxisSelectorForm()
        self.ui.setupUi(self)
        self.popup = TskHeatmapAxisPopup(self)
        self._dimensions = {}
        self.ui.axisButton.clicked.connect(self._show_popup)
        self.popup.dimensions_changed.connect(self._dimensions_changed)

    def _get_axis_label(self):
        return self.ui.axisLabel.text()

    def _set_axis_label(self, label):
        self.ui.axisLabel.setText(label)
        self.popup.ui.axisLabel.setText(label)

    axisLabel = Property(str, _get_axis_label, _set_axis_label)

    @property
    def selected_dimensions(self):
        return self.popup.selected_dimensions

    def set_dimensions(self, dimensions, selected):
        self._dimensions = dict(dimensions)
        self.popup.set_dimensions(self._dimensions, selected)
        self.ui.axisButton.setEnabled(bool(self._dimensions))
        self._update_text()

    def _dimensions_changed(self, selected):
        self._update_text()
        self.dimensions_changed.emit(list(selected))

    def _update_text(self):
        button = self.ui.axisButton
        selected = self.selected_dimensions
        separator = str(button.property("dimensionSeparator"))
        summary = separator.join(str(self._dimensions[key]) for key in selected)
        summary = summary or str(button.property("emptyText"))
        width = max(1, button.width() - int(button.property("summaryPadding")))
        button.setText(button.fontMetrics().elidedText(summary, Qt.ElideRight, width))
        button.setToolTip(summary)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_text()

    def showEvent(self, event):
        super().showEvent(event)
        self._update_text()

    def _show_popup(self):
        popup = self.popup
        button = self.ui.axisButton
        popup.ui.axisLabel.setText(self.ui.axisLabel.text())
        origin = button.mapToGlobal(QPoint(0, button.height()))
        screen = self.screen().availableGeometry()
        x = max(screen.left(), min(origin.x(), screen.right() - popup.width() + 1))
        y = origin.y()
        if y + popup.height() > screen.bottom() + 1:
            y = button.mapToGlobal(QPoint()).y() - popup.height()
        popup.move(x, max(screen.top(), y))
        popup.show()
        popup.ui.dimensionsListWidget.setFocus()
