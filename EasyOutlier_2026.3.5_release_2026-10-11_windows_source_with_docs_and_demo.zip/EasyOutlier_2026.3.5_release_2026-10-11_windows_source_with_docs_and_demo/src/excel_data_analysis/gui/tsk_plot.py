"""Qt-painted TSK probability intervals and chain fit diagnostics."""
from __future__ import annotations

import math

from PySide6.QtCore import QEvent, QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFontMetricsF, QPainter, QPalette, QPen, QTextLayout, QTextOption
from PySide6.QtWidgets import QToolTip, QWidget

from ..tsk_sorting import natural_sort_key
from .tsk_risk_display import boundary_note, is_boundary_low, percentage, risk_interval_text, risk_probability_text


def _probability(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value) and 0 <= value <= 1


def _percentage(value):
    return percentage(value)


def _single_line(value):
    """Keep distinct names intact while preventing embedded line breaks."""
    return str(value).translate(str.maketrans({"\\": "\\\\", "\n": r"\n", "\r": r"\r", "\t": r"\t"}))


def _axis_maximum(values):
    maximum = max((float(value) for value in values if _probability(value)), default=0)
    return min(1., max(.01, maximum * 1.12))


class _TskPlot(QWidget):
    row_selected = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.rows = []
        self._hit_regions = []
        self._selection_regions = []
        self._selected_key = None
        self._selected_row = None

    @staticmethod
    def _row_key(row):
        return (str(row.get("tsk_id", "")),
                tuple(sorted((str(name), value) for name, value in (row.get("categories") or {}).items())))

    @property
    def selected_row(self):
        return self._selected_row

    def set_selected_row(self, row):
        self._selected_key = self._row_key(row) if row is not None else None
        self._rebind_selection()
        self.update()

    def _rebind_selection(self):
        if self._selected_key is None:
            self._selected_row = None
            return
        self._selected_row = next((row for row in self.rows
                                   if self._row_key(row) == self._selected_key), None)
        if self._selected_row is None:
            self._selected_key = None

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            candidates = [(region, row) for region, row in reversed(self._selection_regions)
                          if region.contains(event.position())]
            if candidates:
                # Prefer the nearest point; preserve the chosen chain when several
                # chains occupy exactly the same coordinates.
                _, row = min(candidates, key=lambda item: (
                    (item[0].center() - event.position()).manhattanLength(),
                    0 if self._row_key(item[1]) == self._selected_key else 1))
                self.set_selected_row(row)
                self.row_selected.emit(row)
                event.accept()
                return
        super().mousePressEvent(event)

    def _colors(self):
        palette = self.palette()
        muted = QColor(palette.color(QPalette.Text))
        muted.setAlpha(205)
        return {"background": palette.color(QPalette.Base), "ink": palette.color(QPalette.Text),
                "muted": muted, "grid": palette.color(QPalette.Mid),
                "series": palette.color(QPalette.Active, QPalette.Highlight)}

    def _empty(self, painter, colors):
        painter.setPen(colors["muted"])
        painter.drawText(self.rect().adjusted(12, 12, -12, -12), Qt.AlignCenter | Qt.TextWordWrap,
                         str(self.property("emptyText") or ""))

    def event(self, event):
        if event.type() == QEvent.ToolTip:
            for region, text in reversed(self._hit_regions):
                if region.contains(event.pos()):
                    QToolTip.showText(event.globalPos(), text, self)
                    return True
            QToolTip.hideText()
        return super().event(event)


class TskRiskPlot(_TskPlot):
    def set_category_dimensions(self, categories):
        self._category_dimensions = categories

    def _row_label(self, row):
        if self.property("virtualRows") and row.get("categories"):
            categories = "\n".join(str(self.property("categoryLineFormat")).format(name=name, value=value)
                                     for name, value in row["categories"].items())
            return str(self.property("combinationLabelFormat")).format(tsk_id=row["tsk_id"], categories=categories)
        return str(row.get("label", row.get("tsk_id", "")))

    def set_rows(self, rows, *, preserve_order=False):
        def order(row):
            probability = row.get("probability")
            valid = row.get("identifiable", True) and _probability(probability)
            type_order = natural_sort_key(row.get("tsk_id", ""))
            return (0, -float(probability), type_order) if valid else (1, 0, type_order)
        self.rows = list(rows) if preserve_order else sorted(rows, key=order)
        self._selection_regions = []
        self._rebind_selection()
        self._maximum = _axis_maximum(value for row in self.rows if row.get("identifiable", True)
                                      for value in (row.get("probability"), row.get("ci_upper")))
        self._has_boundary = any(is_boundary_low(row) for row in self.rows)
        self._type_labels = list(dict.fromkeys(str(row.get("tsk_id", "")) for row in self.rows))
        self._update_label_layout()
        self.update()

    def _update_label_layout(self):
        metrics = self.fontMetrics()
        self._virtual = bool(self.property("virtualRows") and self.rows and self.rows[0].get("categories"))
        if self._virtual:
            # Derive one safe row height from the vocabularies, not from every
            # Cartesian row. Text layouts are created only for visible rows.
            dimensions = getattr(self, "_category_dimensions", {})
            groups = [getattr(self, "_type_labels", [])]
            for name, definition in dimensions.items():
                groups.append([str(self.property("categoryLineFormat")).format(name=name, value=value)
                               for value in definition["levels"]])
            width_padding = float(self.property("multilineLabelWidthPadding") or 12)
            desired = max((metrics.horizontalAdvance(line) + width_padding for group in groups for label in group
                           for line in label.splitlines()), default=65)
            self._label_width = max(65., min(desired, float(self.property("multilineLabelMaxWidth") or 260),
                                            self.width() * float(self.property("multilineLabelWidthRatio") or .38)))
            line_width = max(1., self._label_width - 8)
            lines = sum(max((sum(1 if metrics.horizontalAdvance(line) <= line_width else
                                    math.ceil(metrics.horizontalAdvance(line) / line_width) + 1
                                    for line in label.splitlines()) for label in group), default=1) for group in groups)
            height = max(float(self.property("minimumRowHeight") or 50),
                         lines * metrics.lineSpacing() + float(self.property("multilineLabelPadding") or 14))
            self._uniform_row_height = height
            self._row_heights = [height] * len(self.rows)
            self._label_layouts = {}
            self._logical_height = max(190, math.ceil(height * len(self.rows)) + 63)
            self.setMinimumHeight(min(int(self.property("virtualCanvasMaximumHeight") or 16777215), self._logical_height))
            return
        labels = [self._row_label(row) for row in self.rows]
        multiline = any("\n" in label for label in labels)
        if multiline:
            width_padding = float(self.property("multilineLabelWidthPadding") or 12)
            desired = max((metrics.horizontalAdvance(line) + width_padding for label in labels for line in label.splitlines()), default=65)
            self._label_width = max(65., min(desired, float(self.property("multilineLabelMaxWidth") or 260),
                                            self.width() * float(self.property("multilineLabelWidthRatio") or .38)))
        else:
            self._label_width = max(65., min(150., self.width() * .30))
        minimum_height = float(self.property("minimumRowHeight") or 50)
        padding = float(self.property("multilineLabelPadding") or 14)
        self._label_layouts = []
        self._row_heights = []
        for label in labels:
            if "\n" not in label:
                self._label_layouts.append((None, float(metrics.height())))
                self._row_heights.append(max(minimum_height, metrics.height() + padding))
                continue
            layouts, height = [], 0.
            for paragraph in label.split("\n"):
                layout = QTextLayout(paragraph, self.font())
                option = QTextOption(Qt.AlignRight)
                option.setWrapMode(QTextOption.WrapAtWordBoundaryOrAnywhere)
                layout.setTextOption(option)
                layout.beginLayout()
                while True:
                    line = layout.createLine()
                    if not line.isValid():
                        break
                    line.setLineWidth(self._label_width - 8)
                    line.setPosition(QPointF(0, height))
                    height += line.height()
                layout.endLayout()
                layouts.append(layout)
            self._label_layouts.append((layouts, height))
            self._row_heights.append(max(minimum_height, height + padding))
        self.setMinimumHeight(max(190, math.ceil(sum(self._row_heights)) + 63))

    def resizeEvent(self, event):
        self._update_label_layout()
        super().resizeEvent(event)

    def changeEvent(self, event):
        if event.type() == QEvent.FontChange:
            self._update_label_layout()
        super().changeEvent(event)

    def _draw_row_label(self, painter, index, label, center):
        if self._virtual and index not in self._label_layouts:
            layouts, height = [], 0.
            for paragraph in label.split("\n"):
                layout = QTextLayout(paragraph, self.font())
                option = QTextOption(Qt.AlignRight)
                option.setWrapMode(QTextOption.WrapAtWordBoundaryOrAnywhere)
                layout.setTextOption(option)
                layout.beginLayout()
                while True:
                    line = layout.createLine()
                    if not line.isValid():
                        break
                    line.setLineWidth(self._label_width - 8)
                    line.setPosition(QPointF(0, height))
                    height += line.height()
                layout.endLayout()
                layouts.append(layout)
            self._label_layouts[index] = (layouts, height)
        layouts, label_height = self._label_layouts[index]
        label_region = QRectF(5, center - label_height / 2, self._label_width - 8, label_height)
        self._label_regions.append((label_region, label))
        if layouts is not None:
            for layout in layouts:
                layout.draw(painter, label_region.topLeft())
        else:
            painter.drawText(label_region, Qt.AlignRight | Qt.AlignVCenter,
                             painter.fontMetrics().elidedText(label, Qt.ElideRight, int(self._label_width - 8)))

    def _virtual_scroll_offset(self):
        # QWidgets cannot exceed QWIDGETSIZE_MAX. Compress only the scrollbar
        # coordinate beyond that limit, while keeping bars at readable heights.
        # This lets the last row remain reachable without dropping any rows.
        if not self._virtual or self._logical_height <= self.height():
            return 0.
        viewport_height = self.parentWidget().height() if self.parentWidget() else self.height()
        physical_span = max(1., self.height() - viewport_height)
        logical_span = max(1., self._logical_height - viewport_height)
        return max(0., -self.y()) * (logical_span / physical_span - 1.)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        colors = self._colors()
        painter.fillRect(self.rect(), colors["background"])
        self._hit_regions = []
        self._selection_regions = []
        self._label_regions = []
        if not self.rows:
            self._empty(painter, colors)
            return
        metrics = painter.fontMetrics()
        label_width = self._label_width
        value_width = max(58., metrics.horizontalAdvance("100.000%") + 10)
        if self._has_boundary:
            value_width = max(value_width, metrics.horizontalAdvance(str(self.property("boundaryLowText") or "")) + 10)
        left, right = label_width + 6, self.width() - value_width - 8
        top = 14.
        scroll_offset = self._virtual_scroll_offset()
        bottom = top + (self._uniform_row_height * len(self.rows) if self._virtual else sum(self._row_heights)) - scroll_offset
        plot_width = max(16., right - left)
        maximum = self._maximum
        scale = lambda value: left + value / maximum * plot_width
        ticks = 2 if plot_width < 230 else 4
        painter.setPen(QPen(colors["grid"], 1))
        painter.drawLine(QPointF(left, bottom), QPointF(right, bottom))
        for index in range(ticks + 1):
            value = maximum * index / ticks
            x = scale(value)
            painter.setPen(QPen(colors["grid"], 1))
            painter.drawLine(QPointF(x, top - scroll_offset), QPointF(x, bottom))
            painter.setPen(colors["muted"])
            alignment = Qt.AlignLeft if index == 0 else Qt.AlignRight if index == ticks else Qt.AlignHCenter
            tick_rect = QRectF(x if index == 0 else x - 50 if index == ticks else x - 25, bottom + 4, 50, 17)
            painter.drawText(tick_rect, alignment | Qt.AlignVCenter, f"{100 * value:.2f}")
        painter.setPen(colors["ink"])
        painter.drawText(QRectF(left - 10, bottom + 24, plot_width + 20, 20), Qt.AlignCenter,
                         str(self.property("axisLabel") or ""))
        start, end = 0, len(self.rows)
        if self._virtual:
            # Scrolling can repaint only an exposed strip (even just the axis).
            # Rebuild hover targets for every visible row, not only that strip.
            visible = self.visibleRegion().boundingRect()
            if visible.isEmpty():
                visible = event.rect()
            start = max(0, int((visible.top() + scroll_offset - top) // self._uniform_row_height))
            end = min(len(self.rows), int((visible.bottom() + scroll_offset - top) // self._uniform_row_height) + 1)
            self._label_layouts = {}
        row_top = top + (start * self._uniform_row_height if self._virtual else 0) - scroll_offset
        for index in range(start, end):
            row = self.rows[index]
            row_height = self._row_heights[index]
            center = row_top + row_height / 2
            row_region = QRectF(0, row_top, self.width(), row_height)
            self._selection_regions.append((row_region, row))
            if self._row_key(row) == self._selected_key:
                fill = QColor(colors["series"])
                fill.setAlpha(int(self.property("selectionFillAlpha") or 28))
                painter.fillRect(row_region, fill)
                painter.setPen(QPen(colors["series"], float(self.property("selectionOutlineWidth") or 1.5)))
                painter.setBrush(Qt.NoBrush)
                painter.drawRect(row_region.adjusted(1, 1, -1, -1))
            label = self._row_label(row)
            painter.setPen(colors["ink"])
            self._draw_row_label(painter, index, label, center)
            probability = row.get("probability")
            identified = row.get("identifiable", True)
            detail = f"TSK {label}\n状态：{row.get('status', '')}\n实例数：{row.get('layout_instance_count', row.get('instance_count', '—'))}"
            if not identified or not _probability(probability):
                if row.get("status") == "no_data":
                    text = str(self.property("noDataText") or "")
                    detail += "\n" + str(self.property("noDataTooltip") or "")
                elif row.get("status") in {"reference_outside_domain", "outside_model_domain"}:
                    text = str(self.property("outsideDomainText") or "")
                else:
                    text = "不可单独估计" if not identified else "无有效估计"
                painter.setPen(colors["muted"])
                painter.drawText(QRectF(left + 4, center - 11, self.width() - left - 8, 22), Qt.AlignLeft | Qt.AlignVCenter, text)
                detail += "\n" + text
            else:
                bar_width = max(0., scale(probability) - left)
                painter.fillRect(QRectF(left, center - 7, bar_width, 14), colors["series"])
                low, high = row.get("ci_lower"), row.get("ci_upper")
                if row.get("interval_sidedness") == "upper" and _probability(high):
                    painter.setPen(QPen(colors["ink"], 1.5))
                    painter.drawLine(QPointF(scale(probability), center), QPointF(scale(high), center))
                    painter.drawLine(QPointF(scale(high), center - 5), QPointF(scale(high), center + 5))
                elif _probability(low) and _probability(high):
                    painter.setPen(QPen(colors["ink"], 1.5))
                    painter.drawLine(QPointF(scale(low), center), QPointF(scale(high), center))
                    for bound in (low, high):
                        painter.drawLine(QPointF(scale(bound), center - 5), QPointF(scale(bound), center + 5))
                if probability == 0:
                    painter.setPen(QPen(colors["series"], 2))
                    painter.drawLine(QPointF(left, center - 6), QPointF(left, center + 6))
                painter.setPen(colors["ink"])
                painter.drawText(QRectF(right + 6, center - 10, value_width, 20), Qt.AlignLeft | Qt.AlignVCenter,
                                 risk_probability_text(self, row, precision=3))
                detail += f"\nP_fail：{risk_probability_text(self, row)}\n{risk_interval_text(self, row)}"
                note = boundary_note(self, row)
                if note:
                    detail += "\n" + note
            if row.get("interval_error"):
                detail += "\n" + str(self.property("intervalErrorFormat") or "{error}").format(error=row["interval_error"])
            if row.get("interval_method"):
                detail += "\n" + str(self.property("intervalMethodFormat") or "{method}").format(method=row["interval_method"])
            if row.get("categories") and self.property("supportFormat"):
                detail += "\n" + str(self.property("supportFormat")).format(
                    chains=row.get("chain_count", 0), exposure=row.get("chain_test_exposure", 0))
            detail = row.get("tooltip", detail)
            if row.get("combination_chain_tooltip"):
                detail += "\n\n" + row["combination_chain_tooltip"]
            self._hit_regions.append((row_region, detail))
            row_top += row_height


class TskChainFitPlot(_TskPlot):
    @staticmethod
    def _row_key(row):
        return str(row.get("chain_id", ""))

    def set_rows(self, rows):
        self.rows = list(rows)
        self._selection_regions = []
        self._rebind_selection()
        self.update()

    @staticmethod
    def _drawable_row(row):
        tested = row.get("n_tested")
        has_tests = (tested is None or
                     isinstance(tested, (int, float)) and not isinstance(tested, bool)
                     and math.isfinite(tested) and tested > 0)
        return (has_tests and _probability(row.get("observed_probability"))
                and _probability(row.get("predicted_probability")))

    def event(self, event):
        if event.type() == QEvent.ToolTip:
            details = [text for region, text in self._hit_regions if region.contains(event.pos())]
            if details:
                QToolTip.showText(event.globalPos(), "\n\n".join(details), self)
                return True
        return super().event(event)

    def _tooltip(self, row):
        detail = str(self.property("tooltipFormat")).format(
            chain_id=row.get("chain_id", ""), observed=_percentage(row.get("observed_probability")),
            predicted=_percentage(row.get("predicted_probability")), failed=row.get("n_failed", "—"),
            tested=row.get("n_tested", "—"), missing=row.get("n_missing", "—"))
        members = row.get("members", [])
        if not members:
            return detail + "\n" + str(self.property("noMembersText"))
        detail += "\n" + str(self.property("membersHeading"))
        notes = {}
        has_boundary = False
        unavailable_properties = {
            "no_data": "memberNoDataText", "not_identifiable": "memberNotIdentifiableText",
            "fit_not_converged": "memberNotConvergedText",
            "outside_model_domain": "memberOutsideDomainText",
        }
        for member in members:
            conditions = member.get("features") or {**member.get("categories", {}), **member.get("numeric", {})}
            description = "; ".join(f"{_single_line(name)}={_single_line(value)}" for name, value in conditions.items())
            probability = (risk_probability_text(self, member) if member.get("identifiable", True)
                           and _probability(member.get("probability")) else str(self.property(
                               unavailable_properties.get(member.get("status"), "memberUnavailableText"))))
            reason = " ".join(str(member.get("reason") or "").split())
            note_reference = ""
            if reason:
                index = notes.setdefault(reason, len(notes) + 1)
                note_reference = str(self.property("memberNoteReferenceFormat")).format(index=index)
            has_boundary = has_boundary or bool(boundary_note(self, member))
            detail += "\n" + str(self.property("memberFormat")).format(
                tsk_id=_single_line(member.get("tsk_id", "")), count=member.get("count", 1),
                conditions=description or self.property("noFeaturesText"), probability=probability,
                reason=note_reference)
        if has_boundary:
            detail += "\n" + str(self.property("boundaryHintText"))
        for note, index in notes.items():
            detail += "\n" + str(self.property("memberNoteFormat")).format(index=index, text=note)
        return detail

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        colors = self._colors()
        painter.fillRect(self.rect(), colors["background"])
        self._hit_regions = []
        self._selection_regions = []
        points = [row for row in self.rows if self._drawable_row(row)]
        if not points:
            self._empty(painter, colors)
            return
        left = float(self.property("axisLeftMargin") or 82)
        tick_left = float(self.property("axisTickLeft") or 34)
        top, right, bottom = 25., self.width() - 20., self.height() - 48.
        if right <= left or bottom <= top:
            return
        maximum = _axis_maximum(value for row in points for value in
                                (row["observed_probability"], row["predicted_probability"]))
        x = lambda value: left + value / maximum * (right - left)
        y = lambda value: bottom - value / maximum * (bottom - top)
        ticks = 2 if self.width() < 450 else 4
        painter.setPen(QPen(colors["grid"], 1))
        painter.drawRect(QRectF(left, top, right - left, bottom - top))
        for index in range(ticks + 1):
            value = maximum * index / ticks
            px, py = x(value), y(value)
            painter.setPen(QPen(colors["grid"], 1))
            painter.drawLine(QPointF(px, top), QPointF(px, bottom))
            painter.drawLine(QPointF(left, py), QPointF(right, py))
            painter.setPen(colors["muted"])
            painter.drawText(QRectF(tick_left, py - 9, left - tick_left - 5, 18), Qt.AlignRight | Qt.AlignVCenter, f"{100 * value:.2f}")
            alignment = Qt.AlignLeft if index == 0 else Qt.AlignRight if index == ticks else Qt.AlignHCenter
            tick_rect = QRectF(px if index == 0 else px - 50 if index == ticks else px - 25, bottom + 4, 50, 18)
            painter.drawText(tick_rect, alignment | Qt.AlignVCenter, f"{100 * value:.2f}")
        painter.setPen(QPen(colors["muted"], 1.3, Qt.DashLine))
        painter.drawLine(QPointF(left, bottom), QPointF(right, top))
        painter.setPen(colors["ink"])
        painter.drawText(QRectF(left - 10, bottom + 25, right - left + 20, 20), Qt.AlignCenter,
                         str(self.property("xAxisLabel") or ""))
        painter.save()
        painter.translate(float(self.property("axisTitleX") or 12), (top + bottom) / 2)
        painter.rotate(-90)
        painter.drawText(QRectF(-(bottom - top) / 2 - 15, -10, bottom - top + 30, 20), Qt.AlignCenter,
                         str(self.property("yAxisLabel") or ""))
        painter.restore()
        mark_color = QColor(colors["series"])
        mark_color.setAlpha(185)
        painter.setBrush(mark_color)
        painter.setPen(QPen(colors["background"], 1))
        selected_point = None
        for row in points:
            point = QPointF(x(row["predicted_probability"]), y(row["observed_probability"]))
            painter.drawEllipse(point, 4.5, 4.5)
            detail = self._tooltip(row)
            region = QRectF(point.x() - 9, point.y() - 9, 18, 18)
            self._hit_regions.append((region, detail))
            self._selection_regions.append((region, row))
            if self._row_key(row) == self._selected_key:
                selected_point = point
        if selected_point is not None:
            # Paint after every point so a coincident chain cannot cover selection.
            marker_size = float(self.property("selectionMarkerSize") or 16)
            marker = QRectF(selected_point.x() - marker_size / 2, selected_point.y() - marker_size / 2,
                            marker_size, marker_size)
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(colors["ink"], float(self.property("selectionOutlineWidth") or 2)))
            painter.drawRect(marker)
            label = str(self.property("selectionLabelFormat") or "{chain_id}").format(
                chain_id=_single_line(self._selected_row.get("chain_id", "")))
            padding = float(self.property("selectionLabelPadding") or 4)
            gap = float(self.property("selectionLabelGap") or 6)
            metrics = QFontMetricsF(painter.font(), painter.device())
            # Integer font metrics can round down a fraction of a pixel and
            # incorrectly elide short names such as Chain_23 on macOS.
            text_width = math.ceil(max(metrics.horizontalAdvance(label), metrics.boundingRect(label).width()))
            label_width = min(float(self.width()) - 2 * padding,
                              text_width + 2 * padding)
            label_height = math.ceil(metrics.height()) + 2 * padding
            label_left = marker.right() + gap
            if label_left + label_width > self.width() - padding:
                label_left = marker.left() - gap - label_width
            label_top = marker.top() - gap - label_height
            if label_top < padding:
                label_top = marker.bottom() + gap
            label_region = QRectF(max(padding, label_left),
                                  min(max(padding, label_top), self.height() - padding - label_height),
                                  max(1., label_width), label_height)
            painter.fillRect(label_region, colors["background"])
            visible_label = label
            if label_width < text_width + 2 * padding:
                mode = self.property("selectionLabelElideMode")
                visible_label = metrics.elidedText(label, Qt.TextElideMode(mode) if mode is not None else Qt.ElideRight,
                                                   max(1., label_width - 2 * padding))
            painter.drawText(label_region.adjusted(padding, 0, -padding, 0), Qt.AlignCenter,
                             visible_label)
            self._hit_regions.append((label_region, label))
