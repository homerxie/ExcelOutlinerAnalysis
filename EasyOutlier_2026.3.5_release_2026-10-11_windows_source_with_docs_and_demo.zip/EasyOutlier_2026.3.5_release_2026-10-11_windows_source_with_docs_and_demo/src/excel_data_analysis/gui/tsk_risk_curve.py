"""Interactive probability / log-odds view of the saved TSK risk estimates."""
from __future__ import annotations

import math

from PySide6.QtCore import QEvent, QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QToolTip

from ..tsk_sorting import natural_sort_key
from .tsk_plot import _TskPlot, _single_line
from .tsk_risk_display import percentage, risk_available, valid_probability


def log_odds(probability):
    """Invert a saved probability without clipping legitimate boundary values."""
    if probability == 0:
        return -math.inf
    if probability == 1:
        return math.inf
    return math.log(probability) - math.log1p(-probability)


def risk_coordinates(row):
    """Return (eta, p, h), or None for a risk that cannot be displayed."""
    if not risk_available(row):
        return None
    probability = float(row["probability"])
    hazard = math.inf if probability == 1 else -math.log1p(-probability)
    return log_odds(probability), probability, hazard


def probability_interval(row):
    """Read the saved confidence limits, preserving one-sided upper limits."""
    lower = 0. if row.get("interval_sidedness") == "upper" else row.get("ci_lower")
    upper = row.get("ci_upper")
    probability = row.get("probability")
    if (risk_available(row) and valid_probability(lower) and valid_probability(upper)
            and lower <= probability <= upper):
        return float(lower), float(upper)
    return None


def _sigmoid(eta):
    if eta >= 0:
        return 1. / (1. + math.exp(-eta))
    exponent = math.exp(eta)
    return exponent / (1. + exponent)


def _number(value, precision=7):
    if math.isinf(value):
        return "−∞" if value < 0 else "+∞"
    return f"{value:.{precision}g}"


class TskRiskCurvePlot(_TskPlot):
    """QPainter plot; its texts, geometry defaults and containing UI live in .ui."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._records = []
        self._point_positions = []
        self._interval_segments = []
        self._horizontal_intervals = False
        self._vertical_intervals = False
        self._zoom_axes = "both"
        self._view_domain = None
        self._plot_rect = QRectF()
        self._drag_origin = None
        self._drag_domain = None

    def _number_property(self, name, default):
        value = self.property(name)
        return float(default if value is None else value)

    def _colors(self):
        colors = super()._colors()
        background = colors["background"]
        luminance = .2126 * background.redF() + .7152 * background.greenF() + .0722 * background.blueF()
        prefix = "dark" if luminance < .5 else "light"
        for key in ("series", "point", "interval"):
            value = self.property(prefix + key.title() + "Color")
            color = QColor(value) if isinstance(value, QColor) else QColor(str(value or ""))
            colors[key] = color if color.isValid() else colors["series"]
        return colors

    def set_rows(self, rows, *, preserve_order=True):
        self.rows = list(rows)
        if not preserve_order:
            self.rows.sort(key=lambda row: (
                not risk_available(row), -row["probability"] if risk_available(row) else 0,
                natural_sort_key(row.get("tsk_id", ""))))
        self._records = [(row, coordinates, probability_interval(row))
                         for row in self.rows if (coordinates := risk_coordinates(row)) is not None]
        self._selection_regions = []
        self._hit_regions = []
        self._point_positions = []
        self._rebind_selection()
        self.reset_view()

    def set_interval_visibility(self, horizontal, vertical):
        self._horizontal_intervals = bool(horizontal)
        self._vertical_intervals = bool(vertical)
        self.update()

    def set_zoom_axes(self, mode):
        if mode not in {"both", "eta", "probability"}:
            raise ValueError(mode)
        self._zoom_axes = mode

    def _automatic_domain(self):
        extent = self._number_property("minimumEtaSpan", 6)
        values = [-extent, extent]
        for _, (eta, _, _), interval in self._records:
            if math.isfinite(eta):
                values.append(eta)
            if self._horizontal_intervals and interval:
                values.extend(value for p in interval if math.isfinite(value := log_odds(p)))
        lower, upper = min(values), max(values)
        padding = (upper - lower) * self._number_property("etaPaddingRatio", .08)
        return lower - padding, upper + padding, 0., 1.

    @property
    def view_domain(self):
        return self._view_domain or self._automatic_domain()

    def reset_view(self):
        self._view_domain = None
        self._drag_origin = None
        self._drag_domain = None
        self.unsetCursor()
        self.update()

    def focus_risks(self):
        """Fit the saved interior estimates, matching the HTML focus control."""
        points = [(eta, probability) for _, (eta, probability, _), _ in self._records
                  if math.isfinite(eta)]
        if not points:
            self.reset_view()
            return
        low_eta = min(eta for eta, _ in points)
        high_eta = max(eta for eta, _ in points)
        low_p = min(probability for _, probability in points)
        high_p = max(probability for _, probability in points)
        padding = self._number_property("focusPaddingRatio", .12)
        eta_margin = max(self._number_property("focusMinimumEtaPadding", .4),
                         (high_eta - low_eta) * padding)
        probability_margin = max(1e-300, (high_p - low_p) * padding,
                                 min(high_p, 1 - low_p) * padding, 8 * math.ulp(high_p))
        self._view_domain = (low_eta - eta_margin, high_eta + eta_margin,
                             max(0., low_p - probability_margin), min(1., high_p + probability_margin))
        self._drag_origin = self._drag_domain = None
        self.unsetCursor()
        self.update()

    def reveal_selected_row(self):
        """Reveal a locator choice without changing an already suitable zoom."""
        if self._selected_row is None:
            return
        coordinates = risk_coordinates(self._selected_row)
        if coordinates is None:
            return
        eta, probability, _ = coordinates
        x0, x1, y0, y1 = self.view_domain
        if not (y0 <= probability <= y1 and (not math.isfinite(eta) or x0 <= eta <= x1)):
            self.reset_view()

    @staticmethod
    def _bounded_probability_range(lower, upper):
        span = min(1., upper - lower)
        lower = max(0., min(1. - span, lower))
        return lower, lower + span

    def _zoom_at(self, factor, position):
        if not math.isfinite(factor) or factor <= 0 or self._plot_rect.isEmpty():
            return
        x0, x1, y0, y1 = self.view_domain
        rect = self._plot_rect
        fx = min(1., max(0., (position.x() - rect.left()) / rect.width()))
        fy = min(1., max(0., (rect.bottom() - position.y()) / rect.height()))
        anchor_x, anchor_y = x0 + fx * (x1 - x0), y0 + fy * (y1 - y0)
        width = max(8 * math.ulp(anchor_x), 1e-12, (x1 - x0) / factor)
        height = min(1., max(8 * math.ulp(anchor_y), 1e-300, (y1 - y0) / factor))
        lower, upper = self._bounded_probability_range(anchor_y - fy * height, anchor_y + (1 - fy) * height)
        horizontal = ((anchor_x - fx * width, anchor_x + (1 - fx) * width)
                      if self._zoom_axes != "probability" else (x0, x1))
        vertical = (lower, upper) if self._zoom_axes != "eta" else (y0, y1)
        self._view_domain = *horizontal, *vertical
        self.update()

    def zoom(self, factor):
        position = next((point for row, point in self._point_positions
                         if self._row_key(row) == self._selected_key), self._plot_rect.center())
        self._zoom_at(float(factor), position)

    def wheelEvent(self, event):
        if self._records and self._plot_rect.contains(event.position()):
            delta = event.angleDelta().y() or event.pixelDelta().y()
            if delta:
                self._zoom_at(1.25 ** max(-10., min(10., delta / 120.)), event.position())
                event.accept()
                return
        super().wheelEvent(event)

    def _nearest_rows(self, position):
        candidates = [(math.hypot(point.x() - position.x(), point.y() - position.y()), row)
                      for row, point in self._point_positions
                      if math.hypot(point.x() - position.x(), point.y() - position.y())
                      <= self._number_property("hitRadius", 9)]
        if not candidates:
            return []
        distance = min(item[0] for item in candidates)
        # Nearly coincident subpixel points must remain reachable as well.
        return [row for candidate_distance, row in candidates if candidate_distance <= distance + 1.5]

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            rows = self._nearest_rows(event.position())
            if rows:
                previous = next((index for index, row in enumerate(rows)
                                 if self._row_key(row) == self._selected_key), -1)
                row = rows[(previous + 1) % len(rows)]
                self.set_selected_row(row)
                self.row_selected.emit(row)
                event.accept()
                return
        if (event.button() in (Qt.LeftButton, Qt.MiddleButton)
                and self._plot_rect.contains(event.position())):
            self._drag_origin, self._drag_domain = event.position(), self.view_domain
            self.setCursor(Qt.ClosedHandCursor)
            event.accept()
            return
        # _TskPlot uses rectangular hit regions; the curve uses circular distance.
        super(_TskPlot, self).mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._drag_origin is not None:
            x0, x1, y0, y1 = self._drag_domain
            delta = event.position() - self._drag_origin
            dx = -delta.x() / self._plot_rect.width() * (x1 - x0)
            dy = delta.y() / self._plot_rect.height() * (y1 - y0)
            lower, upper = self._bounded_probability_range(y0 + dy, y1 + dy)
            self._view_domain = x0 + dx, x1 + dx, lower, upper
            self.update()
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._drag_origin is not None:
            self._drag_origin = self._drag_domain = None
            self.unsetCursor()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton and self._plot_rect.contains(event.position()):
            self.reset_view()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    @staticmethod
    def _row_label(row):
        label = row.get("label")
        if label:
            return _single_line(label)
        conditions = ", ".join(f"{_single_line(name)}={_single_line(value)}"
                               for name, value in (row.get("categories") or {}).items())
        return " · ".join(filter(None, (_single_line(row.get("tsk_id", "")), conditions)))

    def _text_values(self, row):
        eta, probability, hazard = risk_coordinates(row)
        probability_text = f"{probability:.10g}"
        if probability not in (0., 1.) and float(probability_text) in (0., 1.):
            probability_text = repr(probability)
        return {"label": self._row_label(row), "eta": _number(eta), "hazard": _number(hazard),
                "probability": f"{probability_text} ({percentage(probability)})",
                "boundary": str(self.property("boundaryText") or "") if not math.isfinite(eta) else ""}

    def _tooltip(self, row, count=1):
        text = str(self.property("tooltipFormat") or "").format(**self._text_values(row)).strip()
        if count > 1:
            text += "\n" + str(self.property("overlapText") or "").format(count=count)
        return text

    def event(self, event):
        if event.type() == QEvent.ToolTip:
            rows = self._nearest_rows(event.pos())
            if rows:
                row = next((row for row in rows if self._row_key(row) == self._selected_key), rows[0])
                QToolTip.showText(event.globalPos(), self._tooltip(row, len(rows)), self)
                return True
        return super().event(event)

    def _boundary_flags(self):
        negative = positive = False
        for _, (eta, _, _), interval in self._records:
            negative = negative or eta == -math.inf
            positive = positive or eta == math.inf
            if self._horizontal_intervals and interval:
                negative = negative or interval[0] == 0
                positive = positive or interval[1] == 1
        return negative, positive

    def _tick_probability(self, value, span):
        if value == 0 or value == 1:
            return f"{value:.0%}"
        if span >= .05:
            return f"{value:.0%}"
        return f"{100 * value:.5g}%"

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        colors = self._colors()
        painter.fillRect(self.rect(), colors["background"])
        self._hit_regions, self._selection_regions = [], []
        self._point_positions, self._interval_segments = [], []
        if not self._records:
            self._plot_rect = QRectF()
            self._empty(painter, colors)
            return
        negative_boundary, positive_boundary = self._boundary_flags()
        rail = self._number_property("boundaryRailWidth", 36)
        x0, x1, y0, y1 = self.view_domain
        metrics = painter.fontMetrics()
        tick_width = max(metrics.horizontalAdvance(self._tick_probability(y0 + (y1 - y0) * i / 4, y1 - y0))
                         for i in range(5))
        left = max(self._number_property("axisLeftMargin", 76), tick_width + 30) + rail * negative_boundary
        right = self.width() - self._number_property("axisRightMargin", 24) - rail * positive_boundary
        top = self._number_property("axisTopMargin", 30)
        line_height = metrics.height() + 4
        bottom = self.height() - max(self._number_property("axisBottomMargin", 92), 4 * line_height + 14)
        rect = QRectF(left, top, right - left, bottom - top)
        self._plot_rect = rect
        if rect.width() < 30 or rect.height() < 30:
            return
        x = lambda eta: (left - rail if eta == -math.inf else right + rail if eta == math.inf
                         else left + (eta - x0) / (x1 - x0) * rect.width())
        y = lambda p: bottom - (p - y0) / (y1 - y0) * rect.height()
        value_label_width = left - rail * negative_boundary - 30
        tick_precision = max(4, min(15, math.ceil(math.log10(max(1., max(abs(x0), abs(x1)) / (x1 - x0)))) + 3))
        painter.setPen(QPen(colors["grid"], 1))
        painter.drawRect(rect)
        ticks = 2 if rect.width() < 300 else 4
        for index in range(ticks + 1):
            eta, probability = x0 + (x1 - x0) * index / ticks, y0 + (y1 - y0) * index / ticks
            px, py = x(eta), y(probability)
            painter.setPen(QPen(colors["grid"], 1))
            painter.drawLine(QPointF(px, top), QPointF(px, bottom))
            painter.drawLine(QPointF(left, py), QPointF(right, py))
            painter.setPen(colors["muted"])
            painter.drawText(QRectF(px - 35, bottom + 3, 70, line_height), Qt.AlignCenter, _number(eta, tick_precision))
            painter.drawText(QRectF(22, py - line_height / 2, value_label_width, line_height),
                             Qt.AlignRight | Qt.AlignVCenter, self._tick_probability(probability, y1 - y0))
        painter.setPen(colors["ink"])
        painter.drawText(QRectF(left, bottom + line_height + 4, rect.width(), line_height), Qt.AlignCenter,
                         str(self.property("xAxisLabel") or ""))
        painter.save()
        painter.translate(self._number_property("axisTitleX", 16), rect.center().y())
        painter.rotate(-90)
        painter.drawText(QRectF(-rect.height() / 2, -line_height / 2, rect.height(), line_height),
                         Qt.AlignCenter, str(self.property("yAxisLabel") or ""))
        painter.restore()
        for active, value in ((negative_boundary, -math.inf), (positive_boundary, math.inf)):
            if active:
                px = x(value)
                painter.setPen(QPen(colors["grid"], 1, Qt.DotLine))
                painter.drawLine(QPointF(px, top), QPointF(px, bottom))
                painter.setPen(colors["muted"])
                painter.drawText(QRectF(px - 17, bottom + 3, 34, line_height), Qt.AlignCenter, _number(value))
        clip = QRectF(left - rail * negative_boundary, top, rect.width() + rail * (negative_boundary + positive_boundary), rect.height())
        painter.save()
        painter.setClipRect(clip.adjusted(-8, -8, 8, 8))
        interval_color = QColor(colors["interval"])
        interval_color.setAlpha(int(self._number_property("intervalAlpha", 110)))
        cap = self._number_property("intervalCapSize", 4)
        for row, (eta, probability, _), interval in self._records:
            if interval is None:
                continue
            px, py = x(eta), y(probability)
            painter.setPen(QPen(interval_color, self._number_property("intervalLineWidth", 1.25)))
            if self._horizontal_intervals and y0 <= probability <= y1:
                low, high = (log_odds(p) for p in interval)
                # Infinite endpoints occupy separate rails, with dotted breaks
                # between the rail and the finite log-odds coordinate system.
                a, b = QPointF(x(low), py), QPointF(x(high), py)
                self._interval_segments.append((row, "horizontal", a, b))
                finite_a, finite_b = max(left, a.x()), min(right, b.x())
                if finite_a <= finite_b:
                    painter.drawLine(QPointF(finite_a, py), QPointF(finite_b, py))
                for value, point, edge in ((low, a, left), (high, b, right)):
                    if math.isinf(value):
                        painter.setPen(QPen(interval_color, self._number_property("intervalLineWidth", 1.25), Qt.DotLine))
                        painter.drawLine(point, QPointF(edge, py))
                    painter.drawLine(QPointF(point.x(), py - cap), QPointF(point.x(), py + cap))
                painter.setPen(QPen(interval_color, self._number_property("intervalLineWidth", 1.25)))
            if self._vertical_intervals and (not math.isfinite(eta) or x0 <= eta <= x1):
                a, b = QPointF(px, y(interval[0])), QPointF(px, y(interval[1]))
                self._interval_segments.append((row, "vertical", a, b))
                painter.drawLine(a, b)
                for point in (a, b):
                    painter.drawLine(QPointF(px - cap, point.y()), QPointF(px + cap, point.y()))
        painter.setClipRect(rect)
        path = QPainterPath()
        # Restrict samples to the visible probability range. A heavily zoomed
        # p axis should not pass enormous offscreen coordinates to QPainter.
        curve_left, curve_right = max(x0, log_odds(y0)), min(x1, log_odds(y1))
        if curve_left < curve_right:
            samples = max(80, int((curve_right - curve_left) / (x1 - x0) * rect.width()))
            for index in range(samples + 1):
                eta = curve_left + (curve_right - curve_left) * index / samples
                point = QPointF(x(eta), y(_sigmoid(eta)))
                if index == 0:
                    path.moveTo(point)
                else:
                    path.lineTo(point)
        painter.setPen(QPen(colors["series"], self._number_property("curveLineWidth", 2)))
        painter.setBrush(Qt.NoBrush)
        painter.drawPath(path)
        painter.setClipRect(clip.adjusted(-8, -8, 8, 8))
        selected_point = None
        painted_pixels = set()
        radius = self._number_property("pointRadius", 4.5)
        hit_radius = self._number_property("hitRadius", 9)
        for row, (eta, probability, _), _ in self._records:
            if not y0 <= probability <= y1 or (math.isfinite(eta) and not x0 <= eta <= x1):
                continue
            point = QPointF(x(eta), y(probability))
            self._point_positions.append((row, point))
            region = QRectF(point.x() - hit_radius, point.y() - hit_radius, 2 * hit_radius, 2 * hit_radius)
            self._selection_regions.append((region, row))
            if self._row_key(row) == self._selected_key:
                selected_point = point
            pixel = round(point.x()), round(point.y())
            if pixel in painted_pixels:
                continue
            painted_pixels.add(pixel)
            fill = QColor(colors["point"])
            fill.setAlpha(int(self._number_property("pointFillAlpha", 170)))
            painter.setBrush(fill)
            painter.setPen(QPen(colors["background"], 1))
            painter.drawEllipse(point, radius, radius)
        if selected_point is not None:
            painter.setPen(QPen(colors["point"], self._number_property("selectionOutlineWidth", 2), Qt.DashLine))
            painter.drawLine(QPointF(left, selected_point.y()), selected_point)
            painter.drawLine(selected_point, QPointF(selected_point.x(), bottom))
            painter.setBrush(colors["background"])
            painter.setPen(QPen(colors["point"], self._number_property("selectionOutlineWidth", 2)))
            selected_radius = self._number_property("selectionRadius", 7)
            painter.drawEllipse(selected_point, selected_radius, selected_radius)
            painter.setBrush(colors["point"])
            painter.drawEllipse(selected_point, radius / 2, radius / 2)
        painter.restore()
        if selected_point is not None:
            eta, probability, _ = risk_coordinates(self._selected_row)
            probability_text = f"{100 * probability:.5g}%"
            p_badge = QRectF(left + 5, min(bottom - line_height - 5, max(top + 5, selected_point.y() - line_height / 2)),
                             metrics.horizontalAdvance(probability_text) + 12, line_height)
            marker_padding = self._number_property("selectionRadius", 7) + 5
            marker = QRectF(selected_point.x() - marker_padding, selected_point.y() - marker_padding,
                            2 * marker_padding, 2 * marker_padding)

            def avoid_marker(badge):
                if badge.intersects(marker):
                    above = selected_point.y() - marker_padding - line_height - 3
                    badge.moveTop(above if above >= top + 3 else selected_point.y() + marker_padding + 3)

            avoid_marker(p_badge)
            if math.isfinite(eta):
                eta_text = _number(eta)
                badge_width = metrics.horizontalAdvance(eta_text) + 12
                eta_badge = QRectF(min(right - badge_width - 5, max(left + 5, selected_point.x() - badge_width / 2)),
                                   bottom - line_height - 5, badge_width, line_height)
                avoid_marker(eta_badge)
                if p_badge.intersects(eta_badge):
                    p_badge.moveBottom(eta_badge.top() - 4)
                self._draw_axis_value(painter, eta_badge, eta_text, colors)
            self._draw_axis_value(painter, p_badge, probability_text, colors)
        if self._selected_row is not None and risk_available(self._selected_row):
            summary = str(self.property("selectionFormat") or "").format(**self._text_values(self._selected_row))
            summary_rect = QRectF(8, bottom + 2 * line_height + 9, self.width() - 16, line_height)
            painter.setPen(colors["ink"])
            painter.drawText(summary_rect, Qt.AlignCenter, metrics.elidedText(summary, Qt.ElideMiddle, int(summary_rect.width())))
            self._hit_regions.append((summary_rect, summary))
        if negative_boundary or positive_boundary:
            warning = str(self.property("boundaryText") or "")
            warning_rect = QRectF(8, self.height() - line_height - 2, self.width() - 16, line_height)
            painter.setPen(colors["muted"])
            painter.drawText(warning_rect, Qt.AlignCenter, metrics.elidedText(warning, Qt.ElideRight, int(warning_rect.width())))
            self._hit_regions.append((warning_rect, warning))

    def _draw_axis_value(self, painter, rect, text, colors):
        painter.fillRect(rect, colors["background"])
        painter.setPen(colors["point"])
        painter.drawText(rect, Qt.AlignCenter, text)
