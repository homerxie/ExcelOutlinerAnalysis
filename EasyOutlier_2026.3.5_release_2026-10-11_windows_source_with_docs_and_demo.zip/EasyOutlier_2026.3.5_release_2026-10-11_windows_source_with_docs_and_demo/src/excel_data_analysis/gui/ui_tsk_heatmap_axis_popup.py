# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_heatmap_axis_popup.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QFrame, QHBoxLayout,
    QLabel, QListWidget, QListWidgetItem, QPushButton,
    QSizePolicy, QVBoxLayout, QWidget)

class Ui_TskHeatmapAxisPopupForm(object):
    def setupUi(self, TskHeatmapAxisPopupForm):
        if not TskHeatmapAxisPopupForm.objectName():
            TskHeatmapAxisPopupForm.setObjectName(u"TskHeatmapAxisPopupForm")
        TskHeatmapAxisPopupForm.resize(340, 330)
        TskHeatmapAxisPopupForm.setMinimumSize(QSize(280, 260))
        TskHeatmapAxisPopupForm.setFrameShape(QFrame.Shape.StyledPanel)
        self.popupLayout = QVBoxLayout(TskHeatmapAxisPopupForm)
        self.popupLayout.setSpacing(8)
        self.popupLayout.setObjectName(u"popupLayout")
        self.popupLayout.setContentsMargins(10, 10, 10, 10)
        self.axisLabel = QLabel(TskHeatmapAxisPopupForm)
        self.axisLabel.setObjectName(u"axisLabel")
        self.axisLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.axisLabel.setWordWrap(True)

        self.popupLayout.addWidget(self.axisLabel)

        self.selectionHintLabel = QLabel(TskHeatmapAxisPopupForm)
        self.selectionHintLabel.setObjectName(u"selectionHintLabel")
        self.selectionHintLabel.setWordWrap(True)

        self.popupLayout.addWidget(self.selectionHintLabel)

        self.dimensionsListWidget = QListWidget(TskHeatmapAxisPopupForm)
        self.dimensionsListWidget.setObjectName(u"dimensionsListWidget")
        self.dimensionsListWidget.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.dimensionsListWidget.setAlternatingRowColors(True)
        self.dimensionsListWidget.setSortingEnabled(False)
        self.dimensionsListWidget.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.dimensionsListWidget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)

        self.popupLayout.addWidget(self.dimensionsListWidget)

        self.orderButtonsLayout = QHBoxLayout()
        self.orderButtonsLayout.setObjectName(u"orderButtonsLayout")
        self.moveUpButton = QPushButton(TskHeatmapAxisPopupForm)
        self.moveUpButton.setObjectName(u"moveUpButton")
        self.moveUpButton.setEnabled(False)

        self.orderButtonsLayout.addWidget(self.moveUpButton)

        self.moveDownButton = QPushButton(TskHeatmapAxisPopupForm)
        self.moveDownButton.setObjectName(u"moveDownButton")
        self.moveDownButton.setEnabled(False)

        self.orderButtonsLayout.addWidget(self.moveDownButton)


        self.popupLayout.addLayout(self.orderButtonsLayout)

        self.liveHintLabel = QLabel(TskHeatmapAxisPopupForm)
        self.liveHintLabel.setObjectName(u"liveHintLabel")
        self.liveHintLabel.setWordWrap(True)

        self.popupLayout.addWidget(self.liveHintLabel)


        self.retranslateUi(TskHeatmapAxisPopupForm)

        QMetaObject.connectSlotsByName(TskHeatmapAxisPopupForm)
    # setupUi

    def retranslateUi(self, TskHeatmapAxisPopupForm):
        self.axisLabel.setText(QCoreApplication.translate("TskHeatmapAxisPopupForm", u"\u8f74\u7c7b\u522b", None))
        self.selectionHintLabel.setText(QCoreApplication.translate("TskHeatmapAxisPopupForm", u"\u52fe\u9009\u672c\u8f74\u7ef4\u5ea6\uff1b\u5df2\u9009\u7ef4\u5ea6\u4f9d\u6b21\u7ec4\u5408\u663e\u793a\u3002", None))
        self.moveUpButton.setText(QCoreApplication.translate("TskHeatmapAxisPopupForm", u"\u4e0a\u79fb \u2191", None))
#if QT_CONFIG(tooltip)
        self.moveUpButton.setToolTip(QCoreApplication.translate("TskHeatmapAxisPopupForm", u"\u5c06\u5f53\u524d\u9009\u4e2d\u7684\u5df2\u52fe\u9009\u7ef4\u5ea6\u5411\u524d\u79fb\u52a8\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.moveDownButton.setText(QCoreApplication.translate("TskHeatmapAxisPopupForm", u"\u4e0b\u79fb \u2193", None))
#if QT_CONFIG(tooltip)
        self.moveDownButton.setToolTip(QCoreApplication.translate("TskHeatmapAxisPopupForm", u"\u5c06\u5f53\u524d\u9009\u4e2d\u7684\u5df2\u52fe\u9009\u7ef4\u5ea6\u5411\u540e\u79fb\u52a8\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.liveHintLabel.setText(QCoreApplication.translate("TskHeatmapAxisPopupForm", u"\u52fe\u9009\u4e0e\u6392\u5e8f\u7acb\u5373\u751f\u6548\u3002\u70b9\u51fb\u5217\u8868\u5916\u53ef\u6536\u8d77\u3002", None))
        pass
    # retranslateUi

