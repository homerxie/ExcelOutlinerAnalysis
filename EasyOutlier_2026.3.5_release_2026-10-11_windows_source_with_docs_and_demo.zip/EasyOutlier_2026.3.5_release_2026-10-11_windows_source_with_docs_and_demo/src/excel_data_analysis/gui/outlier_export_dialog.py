from PySide6.QtCore import QSignalBlocker, Qt
from PySide6.QtWidgets import QDialog, QListWidgetItem, QWidget

from .ui_outlier_export_dialog import Ui_OutlierExportDialog


class OutlierExportDialog(QDialog):
    """Choose report contents without changing the analysis scope or settings."""

    def __init__(
        self,
        available_nodes: list[str],
        parent: QWidget | None = None,
        *,
        before_analysis: bool = False,
    ) -> None:
        super().__init__(parent)
        self.ui = Ui_OutlierExportDialog()
        self.ui.setupUi(self)
        if before_analysis:
            self.setWindowTitle(str(self.property("beforeAnalysisWindowTitle")))
            self.ui.exportButton.setText(str(self.property("beforeAnalysisConfirmText")))
            self.ui.descriptionLabel.setText(str(self.property("beforeAnalysisDescriptionText")))
        for node in dict.fromkeys(available_nodes):
            item = QListWidgetItem(node)
            item.setData(Qt.ItemDataRole.UserRole, node)
            item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Checked)
            self.ui.nodesListWidget.addItem(item)
        for radio in (
            self.ui.allResultsRadioButton,
            self.ui.newChainsRadioButton,
            self.ui.newSamplesRadioButton,
        ):
            radio.toggled.connect(self._sync_state)
        self.ui.nodesListWidget.itemChanged.connect(self._sync_state)
        self.ui.selectAllCheckBox.clicked.connect(self._toggle_all_nodes)
        self.ui.exportButton.clicked.connect(self.accept)
        self.ui.cancelButton.clicked.connect(self.reject)
        self._sync_state()

    def export_scope(self) -> dict[str, str | list[str]]:
        mode = "all"
        if self.ui.newChainsRadioButton.isChecked():
            mode = "new_chains"
        elif self.ui.newSamplesRadioButton.isChecked():
            mode = "new_samples"
        return {"mode": mode, "nodes": self._selected_nodes() if mode != "all" else []}

    def accept(self) -> None:
        # Guard programmatic acceptance and the dialog's Enter shortcut as well.
        if self.ui.allResultsRadioButton.isChecked() or self._selected_nodes():
            super().accept()

    def _selected_nodes(self) -> list[str]:
        return [
            item.data(Qt.ItemDataRole.UserRole)
            for item in self._node_items()
            if item.checkState() == Qt.CheckState.Checked
        ]

    def _node_items(self) -> list[QListWidgetItem]:
        return [self.ui.nodesListWidget.item(row) for row in range(self.ui.nodesListWidget.count())]

    def _toggle_all_nodes(self, _checked: bool) -> None:
        state = self.ui.selectAllCheckBox.checkState()
        target = Qt.CheckState.Unchecked if state == Qt.CheckState.Unchecked else Qt.CheckState.Checked
        with QSignalBlocker(self.ui.nodesListWidget):
            for item in self._node_items():
                item.setCheckState(target)
        self._sync_state()

    def _sync_state(self, *_args: object) -> None:
        scope = self.export_scope()
        focused = scope["mode"] != "all"
        selected_count = len(self._selected_nodes())
        node_count = self.ui.nodesListWidget.count()
        self.ui.nodesGroupBox.setEnabled(focused)
        self.ui.selectAllCheckBox.setEnabled(bool(node_count))
        state = Qt.CheckState.Unchecked
        if selected_count:
            state = Qt.CheckState.Checked if selected_count == node_count else Qt.CheckState.PartiallyChecked
        with QSignalBlocker(self.ui.selectAllCheckBox):
            self.ui.selectAllCheckBox.setCheckState(state)
        self.ui.exportButton.setEnabled(not focused or bool(selected_count))
        if not focused:
            text = str(self.property("allSummaryText"))
        elif not node_count:
            text = str(self.property("emptyNodesText"))
        elif not selected_count:
            text = str(self.property("missingNodesText"))
        else:
            key = "chainsSummaryText" if scope["mode"] == "new_chains" else "samplesSummaryText"
            text = str(self.property(key)).format(count=selected_count)
        self.ui.selectionSummaryLabel.setText(text)
