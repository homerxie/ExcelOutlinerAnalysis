"""Independent TSK controls and result binding; form geometry lives in .ui files."""
from __future__ import annotations

from dataclasses import asdict, is_dataclass
from datetime import datetime
import json
import math
from pathlib import Path
import re

from PySide6.QtCore import QAbstractTableModel, QItemSelectionModel, QModelIndex, QSignalBlocker, Qt, Signal
from PySide6.QtWidgets import QApplication, QAbstractItemView, QDialog, QFileDialog, QHeaderView, QLineEdit, QListWidgetItem, QMessageBox, QTableWidgetItem, QWidget

from ..field_names import preferred_batch_field
from ..tsk_features import ALL_CATEGORY_COMBINATIONS, category_label
from ..tsk_sorting import natural_sort_key

from .ui_tsk_analysis_panel import Ui_TskAnalysisPanelForm
from .ui_tsk_results_panel import Ui_TskResultsPanelForm
from .ui_tsk_risk_help_dialog import Ui_TskRiskHelpDialogForm
from .tsk_risk_filter import TskRiskFilter
from .tsk_risk_display import boundary_note, percentage, risk_available, risk_interval_kind, risk_interval_text, risk_probability_text


def _mapping(value):
    if isinstance(value, dict):
        return value
    return asdict(value) if is_dataclass(value) else {}


def _values(text):
    return list(dict.fromkeys(part.strip() for part in re.split(r"[,，\n]+", text) if part.strip()))


def _finite(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)


def _retired_feature_model(group):
    """Keep historical Linear fits distinct from the supported Logistic model."""
    model = group.get("diagnostics", {}).get("model")
    context_model = (group.get("prediction_context") or {}).get("model")
    return (model == "instance_linear_hazard_features" or context_model == "instance_linear_hazard_features"
            or (model != "type_only" and group.get("options", {}).get("feature_model") == "linear_hazard"))


class TskAnalysisPanel(QWidget):
    run_requested = Signal(object)
    mode_selected = Signal(object)
    save_html_requested = Signal()
    refresh_requested = Signal()
    batch_scan_requested = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskAnalysisPanelForm()
        self.ui.setupUi(self)
        self.template = None
        self._template_ready = False
        self._ready_override = None
        self._pending_dataset_ids = set()
        self._pending_feature_names = None
        self._batch_mode = "none"
        self._batch_dimension = ""
        self._batch_mappings = {}
        self._batch_values = {}
        for combo, codes in (
            (self.ui.sourceComboBox, ("analyze",)),
            (self.ui.scopeComboBox, ("entire_database", "checked_imports")),
            (self.ui.batchModeComboBox, ("none", "separate", "parent")),
            (self.ui.nodeModeComboBox, ("separate", "combined_new")),
            (self.ui.featureEffectsModeComboBox, ("fixed_zero", "boundary_simulation")),
            (self.ui.xyModelComboBox, ("origin_even_quartic", "linear")),
        ):
            for index, code in enumerate(codes):
                combo.setItemData(index, code)
        self.ui.sourceComboBox.currentIndexChanged.connect(self._update_state)
        self.ui.scopeComboBox.currentIndexChanged.connect(self._update_state)
        self.ui.nodeModeComboBox.currentIndexChanged.connect(self._update_state)
        self.ui.featureEffectsModeComboBox.currentIndexChanged.connect(self._update_state)
        self.ui.featureEffectsModeComboBox.activated.connect(lambda: self.mode_selected.emit(self.settings()))
        self.ui.includeXYCheckBox.toggled.connect(self._update_state)
        self.ui.importsListWidget.itemChanged.connect(self._imports_changed)
        self.ui.featuresListWidget.itemChanged.connect(self._features_changed)
        self.ui.batchModeComboBox.currentIndexChanged.connect(self._batch_mode_changed)
        self.ui.batchDimensionComboBox.currentIndexChanged.connect(self._batch_dimension_changed)
        self.ui.batchMappingTableWidget.itemChanged.connect(self._batch_mapping_changed)
        self.ui.scanBatchesButton.clicked.connect(lambda: self.batch_scan_requested.emit(self.settings()))
        self.ui.refreshButton.clicked.connect(self.refresh_requested)
        self.ui.runButton.clicked.connect(lambda: self.run_requested.emit(self.settings()))
        self.ui.saveHtmlButton.clicked.connect(self.save_html_requested)

    def set_result_available(self, available):
        self.ui.saveHtmlButton.setEnabled(bool(available))

    @staticmethod
    def _checked_values(widget):
        return [str(widget.item(index).data(Qt.UserRole)) for index in range(widget.count())
                if widget.item(index).checkState() == Qt.Checked]

    @staticmethod
    def _select_code(combo, code):
        index = combo.findData(code)
        if index >= 0:
            combo.setCurrentIndex(index)

    def _imports_changed(self, *_args):
        self._pending_dataset_ids = set(self._checked_values(self.ui.importsListWidget))

    def _features_changed(self, *_args):
        self._pending_feature_names = self._checked_values(self.ui.featuresListWidget)
        self._update_state()

    def set_template(self, template):
        self.template = template
        config = _mapping(getattr(template, "tsk_analysis", None))
        instances = [_mapping(item) for item in config.get("instances", [])]
        self._template_ready = bool(config.get("enabled") and instances)
        self._ready_override = None
        complete_xy = sum(_finite(item.get("x")) and _finite(item.get("y")) for item in instances)
        if not instances:
            summary = self.ui.topologySummaryLabel.property("emptyText")
        else:
            chains = {tuple(item.get("chain_key") or [item.get("chain_id", "")]) for item in instances}
            types = {item.get("tsk_id") for item in instances}
            summary = (f"{len(chains)} Chains · {len(types)} TSK types · {len(instances)} instances\n"
                       f"有效 XY：{complete_xy}/{len(instances)} · 坐标单位：{config.get('coordinate_unit') or '未指定'}")
        if not config.get("enabled"):
            summary = f"{self.ui.topologySummaryLabel.property('disabledText')}\n{summary}"
        self.ui.topologySummaryLabel.setText(str(summary))
        self.ui.includeXYCheckBox.setEnabled(bool(complete_xy))
        self.ui.includeXYCheckBox.setChecked(bool(config.get("use_xy")))
        self._select_code(self.ui.xyModelComboBox, config.get("xy_model", "origin_even_quartic"))
        self.ui.logisticCoefficientBoundSpinBox.setValue(float(config.get("logistic_coefficient_bound", 35.)))
        self.set_shared_fail_rules(getattr(template, "report", None))
        features = sorted(set(config.get("feature_columns", [])) |
                          {key for item in instances for key in item.get("features", {})}, key=str.casefold)
        selected = set(config.get("feature_columns", []))
        categorical = set(config.get("categorical_feature_columns", []))
        self.ui.featuresListWidget.blockSignals(True)
        self.ui.featuresListWidget.clear()
        for name in features:
            text = self.ui.featuresListWidget.property("categoricalItemText").format(name=name) if name in categorical else name
            item = QListWidgetItem(text)
            item.setData(Qt.UserRole, name)
            hint = "categoricalHintText" if name in categorical else "numericHintText"
            item.setToolTip(self.ui.featuresListWidget.property(hint))
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if name in selected else Qt.Unchecked)
            self.ui.featuresListWidget.addItem(item)
        self.ui.featuresListWidget.blockSignals(False)
        self._pending_feature_names = None
        self.ui.featuresListWidget.setEnabled(bool(features))
        dimensions = [dimension.name for dimension in getattr(template, "row_dimensions", [])]
        node = getattr(getattr(template, "report", None), "reliability_node_dimension", "")
        available = [name for name in dimensions if name != node]
        self._reset_batch_dimensions(available)
        self._update_state()

    def set_shared_fail_rules(self, report):
        """Display the Analyze rule snapshot without maintaining a TSK override."""
        report = _mapping(report)
        label = self.ui.sharedFailRulesLabel
        if not report:
            label.setText(label.property("emptyText"))
            return
        method = report.get("outlier_fail_method")
        method_property = {
            "modified_z_score": "modifiedZScoreText", "golden_deviation": "goldenDeviationText",
            "zscore_and_golden": "combinedAndText", "zscore_or_golden": "combinedOrText",
        }.get(method)
        method_name = label.property(method_property) if method_property else str(method or label.property("unknownText"))
        threshold = _mapping(report.get("zscore_thresholds")).get("default")
        threshold_text = f"{threshold:g}" if _finite(threshold) else label.property("unknownText")
        empty = report.get("outlier_treat_empty_cells_as_fail")
        empty_property = "emptyEnabledText" if empty is True else "emptyDisabledText" if empty is False else "unknownText"
        label.setText(label.property("summaryFormat").format(method=method_name, threshold=threshold_text,
                                                            empty=label.property(empty_property)))

    def _reset_batch_dimensions(self, dimensions):
        self.ui.batchModeComboBox.blockSignals(True)
        self.ui.batchDimensionComboBox.blockSignals(True)
        self.ui.batchModeComboBox.setCurrentIndex(0)
        self.ui.batchDimensionComboBox.clear()
        self.ui.batchDimensionComboBox.addItem(self.ui.batchDimensionComboBox.property("noBatchFieldText"), None)
        for name in dimensions:
            self.ui.batchDimensionComboBox.addItem(name, name)
        self._select_code(self.ui.batchDimensionComboBox, preferred_batch_field(dimensions))
        self.ui.batchModeComboBox.blockSignals(False)
        self.ui.batchDimensionComboBox.blockSignals(False)
        self._batch_mode = "none"
        self._batch_dimension = str(self.ui.batchDimensionComboBox.currentData() or "")
        self._batch_mappings.clear()
        self._batch_values.clear()
        self._render_batch_values()

    def _commit_batch_editor(self):
        """Read the current editor before run, scan, persistence or hiding rows."""
        table = self.ui.batchMappingTableWidget
        editor = QApplication.focusWidget()
        if isinstance(editor, QLineEdit) and table.isAncestorOf(editor):
            index = table.currentIndex()
            if index.isValid() and index.column() == 1:
                table.itemDelegateForIndex(index).setModelData(editor, table.model(), index)

    def _remember_batch_mapping(self):
        self._commit_batch_editor()
        if not self._batch_dimension:
            return
        mapping = self._batch_mappings.setdefault(self._batch_dimension, {})
        table = self.ui.batchMappingTableWidget
        for row in range(table.rowCount()):
            source, parent = table.item(row, 0), table.item(row, 1)
            if source is not None and parent is not None:
                mapping[str(source.data(Qt.UserRole))] = parent.text().strip()

    def _batch_mode_changed(self, *_args):
        self._remember_batch_mapping()
        self._batch_mode = str(self.ui.batchModeComboBox.currentData() or "none")
        self._update_state()

    def _batch_dimension_changed(self, *_args):
        self._remember_batch_mapping()
        self._batch_dimension = str(self.ui.batchDimensionComboBox.currentData() or "")
        self._render_batch_values()
        self._update_state()

    def _batch_mapping_changed(self, item):
        if item.column() == 1 and self._batch_dimension:
            source = self.ui.batchMappingTableWidget.item(item.row(), 0)
            if source is not None:
                self._batch_mappings.setdefault(self._batch_dimension, {})[str(source.data(Qt.UserRole))] = item.text().strip()

    def _render_batch_values(self):
        table = self.ui.batchMappingTableWidget
        values = self._batch_values.get(self._batch_dimension, [])
        mapping = self._batch_mappings.get(self._batch_dimension, {})
        table.blockSignals(True)
        table.setRowCount(0)
        table.setRowCount(len(values))
        for row, value in enumerate(values):
            source = QTableWidgetItem(value)
            source.setData(Qt.UserRole, value)
            source.setFlags(source.flags() & ~Qt.ItemIsEditable)
            parent = QTableWidgetItem(mapping.get(value, value))
            if self._batch_mode != "parent":
                parent.setFlags(parent.flags() & ~Qt.ItemIsEditable)
            table.setItem(row, 0, source)
            table.setItem(row, 1, parent)
        table.blockSignals(False)

    def set_batch_values(self, values: list[str]):
        self._remember_batch_mapping()
        if not self._batch_dimension:
            return
        values = list(dict.fromkeys(str(value) for value in values))
        mapping = self._batch_mappings.setdefault(self._batch_dimension, {})
        for value in values:
            mapping.setdefault(value, value)
        self._batch_values[self._batch_dimension] = values
        self._render_batch_values()
        self._update_state()

    def set_import_entries(self, entries):
        selected = self._pending_dataset_ids | set(self._checked_values(self.ui.importsListWidget))
        self.ui.importsListWidget.blockSignals(True)
        self.ui.importsListWidget.clear()
        for entry in entries or []:
            dataset_id = str(entry.get("dataset_id", ""))
            if not dataset_id:
                continue
            label = (f"{entry.get('created_at_utc', '')} | {dataset_id} | "
                     f"{Path(str(entry.get('source_file') or '')).name} | {entry.get('measurement_count', '')} measurements")
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, dataset_id)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if dataset_id in selected else Qt.Unchecked)
            self.ui.importsListWidget.addItem(item)
        self.ui.importsListWidget.blockSignals(False)
        self._pending_dataset_ids = selected
        self._update_state()

    def set_context(self, mapping_summary: str = "", *, ready: bool | None = None):
        if mapping_summary:
            self.ui.contextLabel.setText(mapping_summary)
        self._ready_override = ready
        self._update_state()

    def _update_state(self, *_args):
        combined = self.ui.nodeModeComboBox.currentData() == "combined_new"
        self.ui.nodeModeHintLabel.setText(self.ui.nodeModeHintLabel.property("combinedText" if combined else "separateText"))
        xy_enabled = self.ui.includeXYCheckBox.isEnabled() and self.ui.includeXYCheckBox.isChecked()
        for widget in (self.ui.xyModelLabel, self.ui.xyModelComboBox, self.ui.xyModelHintLabel):
            widget.setEnabled(xy_enabled)
        simulation = self.ui.featureEffectsModeComboBox.currentData() == "boundary_simulation"
        for widget in (self.ui.simulationReplicatesLabel, self.ui.simulationReplicatesSpinBox,
                       self.ui.simulationSeedLabel, self.ui.simulationSeedSpinBox,
                       self.ui.simulationWorkersLabel, self.ui.simulationWorkersSpinBox):
            widget.setEnabled(simulation)
        self.ui.simulationHintLabel.setVisible(simulation)
        features_enabled = bool(self._checked_values(self.ui.featuresListWidget)) or (
            self.ui.includeXYCheckBox.isEnabled() and self.ui.includeXYCheckBox.isChecked())
        for widget in (self.ui.logisticCoefficientBoundLabel, self.ui.logisticCoefficientBoundSpinBox,
                       self.ui.logisticCoefficientBoundHintLabel):
            widget.setEnabled(features_enabled)
        database = self.ui.sourceComboBox.currentData() == "database"
        self.ui.scopeComboBox.setEnabled(database)
        self.ui.refreshButton.setEnabled(database)
        self.ui.importsListWidget.setEnabled(database and self.ui.scopeComboBox.currentData() == "checked_imports")
        self.ui.runButton.setEnabled(self._template_ready if self._ready_override is None else self._ready_override)
        batch_enabled = self._batch_mode != "none"
        parent_mode = self._batch_mode == "parent"
        self.ui.batchDimensionComboBox.setEnabled(self.ui.batchDimensionComboBox.count() > 0)
        self.ui.scanBatchesButton.setEnabled(batch_enabled and bool(self._batch_dimension))
        for widget in (self.ui.batchMappingHintLabel, self.ui.batchMappingTableWidget, self.ui.batchScanHintLabel):
            widget.setVisible(batch_enabled)
        self.ui.batchMappingHintLabel.setText(self.ui.batchMappingHintLabel.property("parentText" if parent_mode else "separateText"))
        table = self.ui.batchMappingTableWidget
        table.setEnabled(batch_enabled)
        table.setColumnHidden(1, not parent_mode)
        table.setEditTriggers((QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed | QAbstractItemView.SelectedClicked)
                              if parent_mode else QAbstractItemView.NoEditTriggers)
        table.blockSignals(True)
        for row in range(table.rowCount()):
            item = table.item(row, 1)
            item.setFlags((item.flags() | Qt.ItemIsEditable) if parent_mode else (item.flags() & ~Qt.ItemIsEditable))
        table.blockSignals(False)

    def settings(self):
        self._remember_batch_mapping()
        return {
            "source": self.ui.sourceComboBox.currentData(),
            "nodes": _values(self.ui.nodesEdit.text()),
            "node_mode": self.ui.nodeModeComboBox.currentData(),
            "sample_ids": _values(self.ui.samplesEdit.text()),
            "batch_mode": self._batch_mode,
            "batch_dimension": self.ui.batchDimensionComboBox.currentData() if self.ui.batchDimensionComboBox.currentIndex() >= 0 else "",
            "batch_mapping": dict(self._batch_mappings.get(self._batch_dimension, {})),
            "include_xy": self.ui.includeXYCheckBox.isChecked(),
            "xy_model": self.ui.xyModelComboBox.currentData(),
            "feature_model": "logistic",
            "logistic_coefficient_bound": self.ui.logisticCoefficientBoundSpinBox.value(),
            "feature_names": self._checked_values(self.ui.featuresListWidget),
            "confidence_level": .95,
            "feature_effects_mode": self.ui.featureEffectsModeComboBox.currentData(),
            "simulation_replicates": self.ui.simulationReplicatesSpinBox.value(),
            "simulation_seed": self.ui.simulationSeedSpinBox.value(),
            "simulation_workers": self.ui.simulationWorkersSpinBox.value(),
        }

    def restore_settings(self, settings):
        if not isinstance(settings, dict):
            return
        for name, combo in (("source", self.ui.sourceComboBox), ("analysis_scope", self.ui.scopeComboBox)):
            if name in settings:
                self._select_code(combo, settings[name])
        for name, edit in (("nodes", self.ui.nodesEdit), ("sample_ids", self.ui.samplesEdit)):
            if isinstance(settings.get(name), list):
                edit.setText(", ".join(str(value) for value in settings[name]))
        self._select_code(self.ui.nodeModeComboBox, settings.get("node_mode", "separate"))
        if "include_xy" in settings:
            self.ui.includeXYCheckBox.setChecked(bool(settings["include_xy"]))
        if "xy_model" in settings:
            self._select_code(self.ui.xyModelComboBox, settings["xy_model"])
        if _finite(settings.get("logistic_coefficient_bound")):
            self.ui.logisticCoefficientBoundSpinBox.setValue(float(settings["logistic_coefficient_bound"]))
        self._select_code(self.ui.featureEffectsModeComboBox, settings.get("feature_effects_mode", "fixed_zero"))
        for name, widget in (("simulation_replicates", self.ui.simulationReplicatesSpinBox),
                             ("simulation_seed", self.ui.simulationSeedSpinBox),
                             ("simulation_workers", self.ui.simulationWorkersSpinBox)):
            if _finite(settings.get(name)):
                widget.setValue(int(settings[name]))
        for name, widget in (("dataset_ids", self.ui.importsListWidget), ("feature_names", self.ui.featuresListWidget)):
            if not isinstance(settings.get(name), list):
                continue
            selected = set(str(value) for value in settings[name])
            widget.blockSignals(True)
            for index in range(widget.count()):
                item = widget.item(index)
                item.setCheckState(Qt.Checked if str(item.data(Qt.UserRole)) in selected else Qt.Unchecked)
            widget.blockSignals(False)
            if name == "dataset_ids":
                self._pending_dataset_ids = selected
            else:
                self._pending_feature_names = list(selected)
        if "batch_dimension" in settings:
            # A removed field must be chosen again, never silently mapped to another dimension.
            self.ui.batchDimensionComboBox.setCurrentIndex(self.ui.batchDimensionComboBox.findData(settings["batch_dimension"]))
        if "batch_mode" in settings:
            self._select_code(self.ui.batchModeComboBox, settings["batch_mode"])
        if isinstance(settings.get("batch_mapping"), dict) and self._batch_dimension:
            mapping = {str(source): "" if parent is None else str(parent) for source, parent in settings["batch_mapping"].items()}
            self._batch_mappings[self._batch_dimension] = mapping
            self._batch_values[self._batch_dimension] = list(mapping)
            self._render_batch_values()
        self._update_state()


class _ResultTableModel(QAbstractTableModel):
    """Numeric sorting and lazy cells for compact results and larger topologies."""

    def __init__(self, columns, headers, parent=None):
        super().__init__(parent)
        self.columns = list(columns)
        self.headers = list(headers)
        self.rows = []
        self._sort_column = -1
        self._sort_order = Qt.AscendingOrder

    def set_rows(self, rows, *, columns=None, headers=None):
        self.beginResetModel()
        self.rows = list(rows)
        if columns is not None:
            self.columns = list(columns)
        if headers is not None:
            self.headers = list(headers)
        if 0 <= self._sort_column < len(self.columns):
            self._sort()
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.columns)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role == Qt.DisplayRole:
            return self.headers[section] if orientation == Qt.Horizontal else str(section + 1)
        return None

    def _raw(self, row, key):
        if key == "instance_count" and "layout_instance_count" in row:
            return row["layout_instance_count"]
        if key == "n_passed":
            return max(0, int(row.get("n_tested", 0)) - int(row.get("n_failed", 0)))
        if key == "identifiable" and row.get("status") == "no_data":
            return None
        if key == "support_status" and row.get("status") == "no_data":
            return self.parent().property("noDataSupportText") or row.get(key)
        if key in {"probability", "ci_lower", "ci_upper"} and row.get("identifiable") is False:
            return None
        if key == "ci_lower" and row.get("interval_sidedness") == "upper":
            return None
        if key.startswith("features."):
            return row.get("features", {}).get(key.removeprefix("features."))
        return row.get(key)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        key, kind = self.columns[index.column()]
        value = self._raw(self.rows[index.row()], key)
        if role == Qt.TextAlignmentRole and kind in {"percent", "pp", "number", "integer"}:
            return int(Qt.AlignRight | Qt.AlignVCenter)
        if role not in {Qt.DisplayRole, Qt.ToolTipRole}:
            return None
        row = self.rows[index.row()]
        if role == Qt.ToolTipRole and row.get("chain_members_tooltip"):
            return row["chain_members_tooltip"]
        if role == Qt.ToolTipRole and row.get("combination_chain_tooltip"):
            if key in {"probability", "ci_lower", "ci_upper"}:
                detail = "\n".join(item for item in (risk_interval_text(self.parent(), row),
                    boundary_note(self.parent(), row), row.get("interval_error")) if item)
            else:
                detail = self.data(index, Qt.DisplayRole)
            return "\n\n".join(item for item in (detail, row["combination_chain_tooltip"]) if item)
        if key == "interval_sidedness":
            return risk_interval_kind(self.parent(), row)
        if role == Qt.ToolTipRole and key in {"probability", "ci_lower", "ci_upper"}:
            return "\n".join(item for item in (risk_interval_text(self.parent(), row),
                              boundary_note(self.parent(), row), row.get("interval_error")) if item)
        if value is None or isinstance(value, float) and not math.isfinite(value):
            return "—"
        if kind == "bool":
            return "是" if value else "否"
        if kind == "percent":
            return risk_probability_text(self.parent(), row) if key == "probability" else percentage(value)
        if key == "status" and value == "boundary_low":
            return self.parent().property("boundaryLowText") or value
        if key == "delta_status" and value == "boundary_interval_unavailable":
            return self.parent().property("boundaryIntervalUnavailableText") or value
        if kind == "pp":
            return f"{float(value) * 100:+.4f}"
        if kind == "number" and _finite(value):
            return f"{value:.6g}"
        if kind == "path" and isinstance(value, (list, tuple)):
            return " / ".join(str(part) for part in value)
        return str(value)

    def _sort(self):
        key = self.columns[self._sort_column][0]
        def sort_key(row):
            value = self._raw(row, key)
            if value is None:
                return (2, "")
            return (0, float(value)) if _finite(value) else (1, natural_sort_key(value))
        self.rows.sort(key=sort_key, reverse=self._sort_order == Qt.DescendingOrder)

    def sort(self, column, order=Qt.AscendingOrder):
        if not 0 <= column < len(self.columns):
            return
        self.beginResetModel()
        self._sort_column, self._sort_order = column, order
        self._sort()
        self.endResetModel()


class TskResultsPanel(QWidget):
    export_requested = Signal()
    saved_analysis_selected = Signal(str)
    result_available_changed = Signal(bool)
    combination_requested = Signal(dict)
    full_combination_requested = Signal(dict)
    detail_visibility_changed = Signal(bool)
    TYPE_COLUMNS = [("tsk_id", "text"), ("level", "text"), ("probability", "percent"), ("ci_lower", "percent"),
                    ("ci_upper", "percent"), ("identifiable", "bool"), ("status", "text"),
                    ("instance_count", "integer"), ("interval_method", "text"), ("interval_error", "text"),
                    ("interval_sidedness", "text"), ("support_status", "text"),
                    ("active_instance_count", "integer"), ("chain_count", "integer"),
                    ("chain_test_exposure", "integer")]
    CHAIN_COLUMNS = [("chain_id", "text"), ("n_tested", "integer"), ("n_failed", "integer"),
                     ("n_passed", "integer"), ("n_missing", "integer"), ("observed_probability", "percent"),
                     ("predicted_probability", "percent"), ("residual", "pp"), ("deviance_residual", "number")]
    TOPOLOGY_COLUMNS = [("chain_id", "text"), ("tsk_instance_id", "text"), ("tsk_id", "text"),
                        ("x", "number"), ("y", "number"), ("chain_key", "path")]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskResultsPanelForm()
        self.ui.setupUi(self)
        self._risk_help_dialog = None
        self.result = {}
        self.types_model = self._table_model(self.ui.typesTableView, self.TYPE_COLUMNS)
        self.chains_model = self._table_model(self.ui.chainsTableView, self.CHAIN_COLUMNS)
        self.topology_model = self._table_model(self.ui.topologyTableView, self.TOPOLOGY_COLUMNS)
        self._combination_view = None
        self._combination_busy = False
        self._combination_categories = {}
        self._home_view = None
        self._home_rows = []
        self._risk_source_rows = []
        self._risk_filter_widgets = {}
        self._risk_categories = {}
        self._risk_visible_rows = []
        self._risk_curve_locator_rows = []
        self._risk_curve_locator_indexes = {}
        self._selected_risk_key = None
        self._selected_chain_id = None
        self._binding_group = False
        self._syncing_table_selection = False
        self._heatmap_dimension_labels = {}
        self._heatmap_x_dimensions = []
        self._heatmap_y_dimensions = []
        self._heatmap_matrix = {"records": {}, "column_keys": [], "row_keys": []}
        self._full_request_pending = set()
        self._deferred_full_requests = set()
        self.ui.calculateFullCombinationButton.clicked.connect(self.request_all_combinations)
        self.ui.combinationHeatmapMetricComboBox.currentIndexChanged.connect(
            lambda index: self.ui.combinationHeatmap.set_metric("support" if index else "probability"))
        self.ui.combinationHeatmap.row_selected.connect(self._select_risk_row)
        self.ui.heatmapXAxisSelector.dimensions_changed.connect(
            lambda selected: self._heatmap_axis_changed("x", selected))
        self.ui.heatmapYAxisSelector.dimensions_changed.connect(
            lambda selected: self._heatmap_axis_changed("y", selected))
        self.ui.heatmapPageSpinBox.valueChanged.connect(self._show_heatmap_page)
        self.ui.riskNoExtrapolationCheckBox.toggled.connect(self._risk_extrapolation_changed)
        self.ui.riskSortFieldComboBox.currentIndexChanged.connect(self._risk_sort_field_changed)
        self.ui.riskSortDirectionComboBox.currentIndexChanged.connect(self._apply_risk_view)
        self.ui.clearRiskFiltersButton.clicked.connect(self._clear_risk_filters)
        self.ui.diagnosticsButton.clicked.connect(self._open_diagnostics)
        self.ui.warningsLabel.linkActivated.connect(self._open_diagnostics)
        self.ui.summaryDetailsButton.toggled.connect(self.ui.summaryDetailsWidget.setVisible)
        self.ui.riskHelpButton.clicked.connect(self._open_risk_help)
        for widget in (self.ui.riskCurveFormula, self.ui.riskCurvePredictorFormula):
            widget.load(str(widget.property("svgSource")).encode("utf-8"))
            widget.renderer().setAspectRatioMode(Qt.KeepAspectRatio)
        self.ui.riskCurveExplanationButton.toggled.connect(self.ui.riskCurveExplanationWidget.setVisible)
        self.ui.riskCurveHorizontalIntervalsCheckBox.toggled.connect(self._update_curve_intervals)
        self.ui.riskCurveVerticalIntervalsCheckBox.toggled.connect(self._update_curve_intervals)
        self.ui.riskCurveZoomAxesComboBox.currentIndexChanged.connect(
            lambda index: self.ui.riskCurvePlot.set_zoom_axes(("both", "eta", "probability")[index]))
        self.ui.riskCurveZoomInButton.clicked.connect(lambda: self.ui.riskCurvePlot.zoom(1.5))
        self.ui.riskCurveZoomOutButton.clicked.connect(lambda: self.ui.riskCurvePlot.zoom(1 / 1.5))
        self.ui.riskCurveResetButton.clicked.connect(self.ui.riskCurvePlot.reset_view)
        self.ui.riskCurveFocusButton.clicked.connect(self.ui.riskCurvePlot.focus_risks)
        self.ui.riskCurvePlot.row_selected.connect(self._select_risk_row)
        self.ui.riskCurveLocatorComboBox.activated.connect(self._locate_curve_combination)
        self.ui.typesTableView.selectionModel().selectionChanged.connect(self._remember_risk_selection)
        self.ui.typesTableView.clicked.connect(self._remember_risk_selection)
        self.ui.chainsTableView.selectionModel().selectionChanged.connect(self._remember_chain_selection)
        self.ui.chainsTableView.clicked.connect(self._remember_chain_selection)
        self.ui.riskPlot.row_selected.connect(self._select_risk_row)
        self.ui.chainPlot.row_selected.connect(self._select_chain_row)
        self.ui.detailPanel.close_requested.connect(lambda: self.set_detail_visible(False))
        self.ui.detailPanel.chain_fit_requested.connect(self._open_chain_fit)
        self.ui.detailToggleButton.toggled.connect(self.set_detail_visible)
        self.ui.detailsTabWidget.currentChanged.connect(self._detail_tab_changed)
        self.types_model.modelReset.connect(self._restore_risk_selection)
        self.chains_model.modelReset.connect(self._restore_chain_selection)
        self.ui.copyDiagnosticsButton.clicked.connect(self._copy_diagnostics)
        self.ui.saveDiagnosticsButton.clicked.connect(self._save_diagnostics)
        self.ui.groupComboBox.currentIndexChanged.connect(self._group_changed)
        self.ui.exportButton.clicked.connect(self.export_requested)
        self.ui.savedAnalysesComboBox.activated.connect(
            lambda: self.saved_analysis_selected.emit(str(self.ui.savedAnalysesComboBox.currentData() or "")))
        self._reset_combination_group()

    def set_run_history(self, history):
        combo = self.ui.savedAnalysesComboBox
        with QSignalBlocker(combo):
            combo.clear()
            for entry in history.get("entries", []):
                settings = entry.get("settings", {})
                simulation = entry.get("mode") == "boundary_simulation"
                created_at = str(entry.get("created_at", ""))
                try:
                    created_at = datetime.fromisoformat(created_at).astimezone().strftime("%Y-%m-%d %H:%M:%S")
                except ValueError:
                    pass
                scope = combo.property("scopeFormat").format(
                    nodes=", ".join(settings.get("nodes") or []) or combo.property("allNodesText"),
                    features=", ".join(settings.get("feature_names") or []) or combo.property("noFeaturesText"),
                    context=str(entry.get("context_key", ""))[:8])
                text = combo.property("itemFormat").format(
                    mode=combo.property("simulationText" if simulation else "fixedZeroText"),
                    simulation=combo.property("simulationFormat").format(
                        replicates=settings.get("simulation_replicates", ""),
                        seed=settings.get("simulation_seed", "")) if simulation else "",
                    created_at=created_at, scope=scope)
                combo.addItem(text, entry["key"])
                combo.setItemData(combo.count() - 1, text, Qt.ToolTipRole)
            combo.setCurrentIndex(combo.findData(history.get("active_key")))
            combo.setEnabled(bool(combo.count()))

    def _update_curve_intervals(self, *_args):
        self.ui.riskCurvePlot.set_interval_visibility(
            horizontal=self.ui.riskCurveHorizontalIntervalsCheckBox.isChecked(),
            vertical=self.ui.riskCurveVerticalIntervalsCheckBox.isChecked())

    def _bind_curve_locator(self, rows):
        self._risk_curve_locator_rows = sorted((row for row in rows if risk_available(row)),
                                               key=lambda row: -row["probability"])
        self._risk_curve_locator_indexes = {
            self._risk_row_key(row): index for index, row in enumerate(self._risk_curve_locator_rows)}
        combo = self.ui.riskCurveLocatorComboBox
        with QSignalBlocker(combo):
            combo.clear()
            for row in self._risk_curve_locator_rows:
                values = self.ui.riskCurvePlot._text_values(row)
                values["probability"] = percentage(row["probability"])
                text = combo.property("itemFormat").format(**values)
                combo.addItem(text)
                combo.setItemData(combo.count() - 1, text, Qt.ToolTipRole)
            combo.setEnabled(bool(self._risk_curve_locator_rows))
            self._sync_curve_locator()

    def _sync_curve_locator(self):
        with QSignalBlocker(self.ui.riskCurveLocatorComboBox):
            self.ui.riskCurveLocatorComboBox.setCurrentIndex(
                self._risk_curve_locator_indexes.get(self._selected_risk_key, -1))

    def _locate_curve_combination(self, index):
        if 0 <= index < len(self._risk_curve_locator_rows):
            self._select_risk_row(self._risk_curve_locator_rows[index])
            self.ui.riskCurvePlot.reveal_selected_row()

    def _update_curve_confidence(self, confidence):
        label = self.ui.riskCurveIntervalLabel
        label.setText(label.property("formatText").format(confidence=f"{confidence:.0%}"))

    @staticmethod
    def _table_model(table, columns):
        model = _ResultTableModel(columns, table.property("columnHeaders") or [], table)
        table.setModel(model)
        table.horizontalHeader().setResizeContentsPrecision(100)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        table.horizontalHeader().setStretchLastSection(True)
        return model

    @property
    def current_group(self):
        index = self.ui.groupComboBox.currentIndex()
        groups = self.result.get("groups", [])
        return groups[index] if 0 <= index < len(groups) else None

    @property
    def detail_visible(self):
        return not self.ui.detailPanel.isHidden()

    def _detail_row(self):
        tab = self.ui.detailsTabWidget.currentWidget()
        if tab is self.ui.riskTab:
            return next((row for row in self.types_model.rows
                         if self._risk_row_key(row) == self._selected_risk_key), None)
        if tab is self.ui.chainFitTab:
            return next((row for row in self.chains_model.rows
                         if str(row.get("chain_id")) == self._selected_chain_id), None)
        return None

    def _render_detail(self):
        row = self._detail_row()
        if row is None:
            return False
        if self.ui.detailsTabWidget.currentWidget() is self.ui.riskTab:
            self.ui.detailPanel.show_risk(row, self._home_view)
        else:
            self.ui.detailPanel.show_chain(row)
        return True

    def set_detail_visible(self, visible):
        was_visible = self.detail_visible
        visible = bool(visible and self._detail_row() is not None)
        if visible:
            self._render_detail()
        self.ui.detailPanel.setVisible(visible)
        with QSignalBlocker(self.ui.detailToggleButton):
            self.ui.detailToggleButton.setChecked(visible)
        self.ui.detailToggleButton.setEnabled(self._detail_row() is not None)
        if visible != was_visible:
            self.detail_visibility_changed.emit(visible)
            if visible:
                splitter = self.ui.resultsDetailSplitter
                width = int(splitter.property("preferredDetailWidth"))
                splitter.setSizes([max(1, splitter.width() - width - splitter.handleWidth()), width])

    def _detail_tab_changed(self, *_args):
        self.set_detail_visible(self.detail_visible)

    def _select_risk_row(self, row, *, sync_table=True):
        if self._binding_group:
            return
        key = self._risk_row_key(row)
        changed = self._selected_risk_key != key
        self._selected_risk_key = key
        if sync_table:
            self._restore_risk_selection()
        self.ui.riskPlot.set_selected_row(row)
        self.ui.riskCurvePlot.set_selected_row(row)
        self._sync_curve_locator()
        self.ui.combinationHeatmap.set_selected_row(row)
        if changed or not self.detail_visible:
            self.set_detail_visible(True)

    def _select_chain_row(self, row, *, sync_table=True):
        if self._binding_group:
            return
        chain_id = str(row.get("chain_id"))
        changed = self._selected_chain_id != chain_id
        self._selected_chain_id = chain_id
        if sync_table:
            self._restore_chain_selection()
        self.ui.chainPlot.set_selected_row(row)
        if changed or not self.detail_visible:
            self.set_detail_visible(True)

    def _restore_table_row(self, table, row):
        # Keep Qt's selection notifications live so the view repaints both the
        # old and new rows. Only suppress our own table-to-detail callbacks.
        previous = self._syncing_table_selection
        self._syncing_table_selection = True
        try:
            column = max(0, table.currentIndex().column())
            table.selectionModel().setCurrentIndex(
                table.model().index(row, column), QItemSelectionModel.ClearAndSelect | QItemSelectionModel.Rows)
        finally:
            self._syncing_table_selection = previous

    def _remember_chain_selection(self, *_args):
        if self._binding_group or self._syncing_table_selection:
            return
        selected = self.ui.chainsTableView.selectionModel().selectedRows()
        if selected:
            self._select_chain_row(self.chains_model.rows[selected[0].row()], sync_table=False)
        else:
            self._selected_chain_id = None
            self.ui.chainPlot.set_selected_row(None)
            if self.ui.detailsTabWidget.currentWidget() is self.ui.chainFitTab:
                self.set_detail_visible(False)

    def _restore_chain_selection(self):
        for index, row in enumerate(self.chains_model.rows):
            if str(row.get("chain_id")) == self._selected_chain_id:
                self._restore_table_row(self.ui.chainsTableView, index)
                return
        self._selected_chain_id = None

    def _open_chain_fit(self, chain_id):
        row = next((row for row in self.chains_model.rows if str(row.get("chain_id")) == str(chain_id)), None)
        if row is None:
            return
        self._selected_chain_id = str(chain_id)
        self.ui.detailsTabWidget.setCurrentWidget(self.ui.chainFitTab)
        self.ui.fitViewsTabWidget.setCurrentWidget(self.ui.chainOverviewTab)
        self._select_chain_row(row)
        self.ui.chainsTableView.scrollTo(self.ui.chainsTableView.currentIndex())

    def set_result(self, payload):
        self.result = _mapping(payload)
        self._full_request_pending.clear()
        self._deferred_full_requests.clear()
        self.ui.groupComboBox.blockSignals(True)
        self.ui.groupComboBox.clear()
        for index, group in enumerate(self.result.get("groups", [])):
            self.ui.groupComboBox.addItem(str(group.get("label") or group.get("node") or f"Group {index + 1}"), index)
        self.ui.groupComboBox.blockSignals(False)
        groups = self.result.get("groups", [])
        self.ui.groupComboBox.setEnabled(bool(groups))
        self.ui.exportButton.setEnabled(bool(groups))
        topology = sorted((_mapping(row) for row in self.result.get("topology", [])),
                          key=lambda row: (natural_sort_key(row.get("chain_id", "")),
                                           natural_sort_key(row.get("tsk_instance_id", row.get("instance_id", "")))))
        features = sorted({name for row in topology for name in row.get("features", {})}, key=str.casefold)
        config = self.result.get("provenance", {}).get("template_snapshot", {}).get("tsk_analysis", {})
        categorical = set(config.get("categorical_feature_columns", []))
        columns = self.TOPOLOGY_COLUMNS + [("features." + name, "text" if name in categorical else "number") for name in features]
        headers = list(self.ui.topologyTableView.property("columnHeaders") or []) + features
        self.topology_model.set_rows(topology, columns=columns, headers=headers)
        self._show_group()
        self.result_available_changed.emit(bool(groups))

    def html_view_state(self):
        """Capture presentation choices without filtering the exported payload."""
        filters = {}
        for key, control in self._risk_filter_widgets.items():
            selected = control.selected_values
            if selected != set(control.values):
                filters[key] = [value for value in control.values if value in selected]
        return {
            "group_index": self.ui.groupComboBox.currentIndex(),
            "no_extrapolation": self.ui.riskNoExtrapolationCheckBox.isChecked(),
            "filters": filters,
            "sort_field": self.ui.riskSortFieldComboBox.currentData() or "tsk_id",
            "sort_descending": self.ui.riskSortDirectionComboBox.currentIndex() == 1,
            "x_dimensions": list(self._heatmap_x_dimensions),
            "y_dimensions": list(self._heatmap_y_dimensions),
            "risk_view": {self.ui.riskCurveTab: "curve", self.ui.riskChartTab: "bars", self.ui.combinationHeatmapTab: "heatmap",
                          self.ui.riskDetailsTab: "table"}[self.ui.riskViewsTabWidget.currentWidget()],
            "curve_horizontal_intervals": self.ui.riskCurveHorizontalIntervalsCheckBox.isChecked(),
            "curve_vertical_intervals": self.ui.riskCurveVerticalIntervalsCheckBox.isChecked(),
            "curve_zoom_axis": ("both", "eta", "probability")[self.ui.riskCurveZoomAxesComboBox.currentIndex()],
            "main_view": {self.ui.riskTab: "risk", self.ui.chainFitTab: "fit", self.ui.jointRiskTab: "joint",
                          self.ui.featureEffectsTab: "effects",
                          self.ui.modelDiagnosticsTab: "model"}[self.ui.detailsTabWidget.currentWidget()],
            "effects_feature": self.ui.featureEffectsPanel.ui.featureComboBox.currentData(),
            "effects_view": {self.ui.featureEffectsPanel.ui.overviewTab: "overall",
                             self.ui.featureEffectsPanel.ui.levelsTab: "levels",
                             self.ui.featureEffectsPanel.ui.pairwiseTab: "pairs"}[
                                 self.ui.featureEffectsPanel.ui.effectsTabWidget.currentWidget()],
            "heatmap_metric": "support" if self.ui.combinationHeatmapMetricComboBox.currentIndex() else "probability",
        }

    def clear_result(self, message: str = ""):
        self.set_result({})
        self.ui.summaryLabel.setText(message or self.ui.summaryLabel.property("emptyText"))
        self.ui.compactSummaryLabel.setText(self.ui.summaryLabel.text())

    def _show_group(self, *_args):
        group = self.current_group or {}
        self.set_detail_visible(False)
        self._binding_group = True
        self._home_view = None
        self._home_rows = []
        self._selected_risk_key = None
        self._selected_chain_id = None
        self.ui.detailPanel.set_payload_group(self.result, group)
        self.ui.detailPanel.clear_selection()
        self.ui.detailToggleButton.setEnabled(False)
        self._combination_categories = {}
        self.ui.riskPlot.set_category_dimensions({})
        self.ui.jointRiskPanel.set_group(group)
        self.ui.featureEffectsPanel.set_group(group)
        types = list(group.get("types", []))
        chains = sorted(group.get("chains", []), key=lambda row: natural_sort_key(row.get("chain_id", "")))
        self.ui.riskPlot.setProperty("axisLabel", self.ui.riskPlot.property("typeAxisLabel"))
        self._bind_risk_rows(types, {}, reset=True)
        members = group.get("chain_members", {})
        chain_rows = [{**row, "members": row.get("members", members.get(row.get("chain_id"), []))} for row in chains]
        self.ui.chainPlot.set_rows(chain_rows)
        self.ui.chainPlot.set_selected_row(None)
        self.chains_model.set_rows([{**row, "chain_members_tooltip": self.ui.chainPlot._tooltip(row)} for row in chain_rows])
        self._binding_group = False
        diagnostics = group.get("diagnostics", {})
        confidence = float((group.get("prediction_context") or {}).get("confidence_level",
                           diagnostics.get("confidence_level", group.get("options", {}).get("confidence_level", .95))))
        self.ui.riskPlot.setProperty("confidenceLevel", confidence)
        self._update_curve_confidence(confidence)
        self.ui.typesTableView.setProperty("confidenceLevel", confidence)
        self.ui.riskLegendLabel.setText(self.ui.riskLegendLabel.property("formatText").format(confidence=f"{confidence:.0%}"))
        warnings = list(self.result.get("warnings", [])) + list(diagnostics.get("warnings", []))
        unique_warnings = list(dict.fromkeys(str(item) for item in warnings if item))
        self.ui.warningsLabel.setVisible(bool(unique_warnings))
        self.ui.warningsLabel.setText(self.ui.warningsLabel.property("summaryText").format(count=len(unique_warnings)))
        self.ui.warningsLabel.setToolTip("\n".join(unique_warnings))
        self.ui.summaryDetailsButton.setEnabled(bool(group))
        if not group:
            self.ui.summaryDetailsButton.setChecked(False)
            self.ui.summaryLabel.setText(self.ui.summaryLabel.property("emptyText"))
            self.ui.compactSummaryLabel.setText(self.ui.summaryLabel.text())
            self.ui.summaryLabel.setToolTip("")
            self.ui.referenceLabel.clear()
            self.ui.referenceLabel.setToolTip("")
            self.ui.riskLegendLabel.setToolTip("")
            self._reset_combination_group()
            self._update_reference_summary()
            return
        convergence = "已收敛" if diagnostics.get("converged") else "未确认收敛"
        self.ui.compactSummaryLabel.setText(self.ui.compactSummaryLabel.property("summaryFormat").format(
            types=len(types), chains=len(chains), convergence=convergence))
        rank = diagnostics.get("rank", "—")
        parameters = diagnostics.get("parameter_count", "—")
        summary = f"{len(types)} TSK types · {len(chains)} Chains · {convergence} · 秩 {rank}/{parameters}"
        model = diagnostics.get("model")
        options = group.get("options", {})
        model_property = "retiredModelText" if _retired_feature_model(group) else "logisticModelText"
        summary += "\n" + self.ui.summaryLabel.property("modelSummaryFormat").format(
            model=self.ui.summaryLabel.property(model_property),
            details=self.ui.summaryLabel.property("typeOnlyModelSuffix") if model == "type_only" else "")
        source_batches = [str(value) for value in group.get("source_batches", [])]
        batch_mode = group.get("batch_mode", "none")
        if source_batches:
            members = ", ".join(source_batches[:6]) + (f" 等 {len(source_batches)} 批" if len(source_batches) > 6 else "")
            if batch_mode == "none":
                summary += f"\n混合全部原批：{members}"
            else:
                summary += (f"\n母批：{group.get('parent_batch_id', '')} · 原批：{members}" if batch_mode == "parent" else f"\n原批：{members}")
        details = [f"原批次字段：{group.get('batch_dimension', '')}", f"原批次成员：{', '.join(source_batches)}"] if source_batches else []
        details.extend(f"{row.get('source_batch', '')} / {row.get('chain_id', '')}: "
                       f"Tested={row.get('n_tested', 0)}, Fail={row.get('n_failed', 0)}, "
                       f"Pass={row.get('n_passed', 0)}, Missing={row.get('n_missing', 0)}"
                       for row in group.get("batch_counts", []))
        self.ui.summaryLabel.setText(summary)
        if group.get("saved_display_only"):
            self.ui.summaryLabel.setText(summary + "\n" + self.ui.summaryLabel.property("savedText"))
        self.ui.summaryLabel.setToolTip("\n".join(details))
        reference = diagnostics.get("reference_environment")
        reference_text = json.dumps(reference, ensure_ascii=False) if isinstance(reference, (list, dict)) else str(reference or "")
        self.ui.referenceLabel.setToolTip(reference_text)
        categories = (group.get("prediction_context") or {}).get("categorical_features") or diagnostics.get("categorical_features", {})
        if categories:
            references = "; ".join(f"{name}={info['reference']}" for name, info in categories.items())
            self.ui.referenceLabel.setText(self.ui.referenceLabel.property("categoricalText").format(categories=references))
        elif options.get("categorical_feature_names"):
            self.ui.referenceLabel.setText(self.ui.referenceLabel.property("categoricalNoFitText"))
        elif model == "instance_logistic_features" or (model != "type_only" and (
                options.get("include_xy") or options.get("use_xy") or options.get("feature_names"))):
            self.ui.referenceLabel.setText(self.ui.referenceLabel.property("featureText"))
        elif model == "type_only" or not reference:
            self.ui.referenceLabel.setText(self.ui.referenceLabel.property("typeOnlyText"))
        else:
            self.ui.referenceLabel.setText(f"概率参照环境：{reference_text}")
        self.ui.riskLegendLabel.setToolTip(str(diagnostics.get("interval_method", "")))
        self._reset_combination_group()
        self._update_reference_summary()

    def _group_changed(self, *_args):
        self._show_group()
        self.ensure_all_combinations()

    def _reset_combination_group(self):
        group = self.current_group or {}
        fitted_order = (group.get("prediction_context") or {}).get("categorical_features", {})
        definitions = fitted_order or group.get("diagnostics", {}).get("categorical_features", {})
        names = group.get("options", {}).get("categorical_feature_names") or list(definitions)
        names = [name for name in fitted_order if name in names] + [name for name in names if name not in fitted_order]
        self._combination_categories = {name: definitions[name] for name in names
                                        if name in definitions and definitions[name].get("levels")}
        self._configure_heatmap_axes()
        views = group.get("combination_views", [])
        latest = views[-1] if views else None
        full = self._complete_all_view(latest, respect_policy=False)
        # A historical slice must not change the complete result's policy.
        check = self.ui.riskNoExtrapolationCheckBox
        check.blockSignals(True)
        check.setChecked(not full.get("extrapolate", True) if full else True)
        check.blockSignals(False)
        self.set_combination_result(latest)

    def set_combination_busy(self, busy):
        self._combination_busy = bool(busy)
        self._update_combination_request_state()

    def _update_combination_request_state(self, *_args):
        group = self.current_group or {}
        retired = _retired_feature_model(group)
        saved_only = bool(group.get("saved_display_only"))
        valid = bool(self._combination_categories and group.get("prediction_context") and not retired and not saved_only)
        status = self.ui.riskCalculationStatusLabel
        if retired:
            text = status.property("retiredModelText")
        elif saved_only:
            text = status.property("savedResultText")
        elif self._combination_busy:
            text = status.property("busyText")
        elif not self._combination_categories:
            text = status.property("noCategoriesText")
        elif not valid:
            text = status.property("noContextText")
        else:
            text = status.property("readyText").format(count=self.full_combination_count())
        status.setText(str(text))
        status.setVisible(bool(group) and bool(retired or self._combination_busy or
                          self._combination_categories and not self._complete_all_view()))
        check = self.ui.riskNoExtrapolationCheckBox
        has_saved_view = bool(self._combination_categories and self._complete_all_view(respect_policy=False))
        check.setEnabled((valid or has_saved_view) and not self._combination_busy)
        if not group:
            tooltip = "emptyToolTip"
        elif not self._combination_categories:
            tooltip = "noCategoriesToolTip"
        elif self._combination_busy:
            tooltip = "busyToolTip"
        elif valid:
            tooltip = "readyToolTip"
        elif has_saved_view:
            tooltip = "savedToolTip"
        else:
            tooltip = "unavailableToolTip"
        check.setToolTip(check.property(tooltip))
        self.ui.diagnosticsButton.setEnabled(bool(group))
        self._update_full_combination_state()

    def all_combinations_query(self):
        return {"dimension": ALL_CATEGORY_COMBINATIONS, "fixed_categories": {},
                "tsk_ids": None, "reference_level": None,
                "extrapolate": not self.ui.riskNoExtrapolationCheckBox.isChecked()}

    def full_combination_count(self):
        group = self.current_group or {}
        types = (group.get("prediction_context") or {}).get(
            "all_type_ids", [row["tsk_id"] for row in group.get("types", [])])
        return (len(set(types)) * math.prod(len(value["levels"]) for value in self._combination_categories.values())
                if self._combination_categories else 0)

    def _full_combination_key(self):
        return self.ui.groupComboBox.currentIndex(), not self.ui.riskNoExtrapolationCheckBox.isChecked()

    def _update_full_combination_state(self):
        group = self.current_group or {}
        missing = bool(not group.get("saved_display_only") and not _retired_feature_model(group) and group.get("prediction_context") and self._combination_categories
                       and not self._complete_all_view())
        self.ui.riskCompletionHintLabel.setVisible(missing)
        self.ui.calculateFullCombinationButton.setVisible(missing)
        self.ui.calculateFullCombinationButton.setEnabled(
            missing and self.full_combination_count() > 0 and not self._combination_busy
            and self._full_combination_key() not in self._full_request_pending)

    def request_all_combinations(self):
        """The explicit risk-tab button authorizes the full calculation."""
        self._update_full_combination_state()
        if not self.ui.calculateFullCombinationButton.isEnabled():
            return False
        key = self._full_combination_key()
        self._deferred_full_requests.discard(key)
        self._full_request_pending.add(key)
        self._update_full_combination_state()
        self.combination_requested.emit(self.all_combinations_query())
        return True

    def defer_combination_request(self):
        key = self._full_combination_key()
        self._full_request_pending.discard(key)
        self._deferred_full_requests.add(key)
        self._update_full_combination_state()

    def ensure_all_combinations(self):
        """Ask for consent before filling a missing view, once per group/policy."""
        self._update_full_combination_state()
        group = self.current_group or {}
        if (group.get("saved_display_only") or _retired_feature_model(group) or not group.get("prediction_context")
                or not self._combination_categories or self._combination_busy):
            return False
        query = self.all_combinations_query()
        view = self._complete_all_view()
        if view and view.get("extrapolate", True) == query["extrapolate"]:
            return False
        key = (self.ui.groupComboBox.currentIndex(), query["extrapolate"])
        if key in self._full_request_pending or key in self._deferred_full_requests:
            return False
        self._full_request_pending.add(key)
        self._update_full_combination_state()
        self.full_combination_requested.emit(query)
        return True

    def _risk_extrapolation_changed(self, checked):
        self._show_all_combination_risk(None)
        self._show_diagnostics(self._home_view)
        self._update_combination_request_state()
        self.ensure_all_combinations()

    def finish_combination_request(self):
        self._full_request_pending.clear()
        self._update_full_combination_state()

    def set_combination_result(self, view):
        """Keep cached slices compatible; all visible risk views use the full grid."""
        self._combination_view = view
        self._show_all_combination_risk(view)
        self._show_diagnostics(self._home_view or view)
        self._update_combination_request_state()

    def _open_diagnostics(self, *_args):
        self.ui.detailsTabWidget.setCurrentWidget(self.ui.modelDiagnosticsTab)
        self.ui.modelViewsTabWidget.setCurrentWidget(self.ui.combinationWarningsTab)

    def _open_risk_help(self):
        if self._risk_help_dialog is None:
            self._risk_help_dialog = QDialog(self)
            self._risk_help_ui = Ui_TskRiskHelpDialogForm()
            self._risk_help_ui.setupUi(self._risk_help_dialog)
        text = self._risk_help_ui.helpTextBrowser
        confidence = float(self.ui.riskPlot.property("confidenceLevel") or .95)
        sections = [
            ("summaryHeading", self.ui.summaryLabel.text()),
            ("referenceHeading", self.ui.referenceLabel.text()),
            ("intervalHeading", self.ui.riskLegendLabel.property("detailsFormat").format(
                confidence=f"{confidence:.0%}")),
            ("heatmapHeading", self.ui.combinationHeatmapLegendLabel.property("detailsText")),
            ("axesHeading", self.ui.heatmapAxesHintLabel.text()),
            ("filterHeading", text.property("filterText")),
        ]
        text.setPlainText("\n\n".join(text.property(heading) + "\n" + content
                                    for heading, content in sections if content))
        self._risk_help_dialog.open()

    def _update_reference_summary(self):
        label = self.ui.riskReferenceSummaryLabel
        group = self.current_group or {}
        if not group:
            key = "emptyText"
        elif self._home_view:
            key = "completeText"
        elif self._combination_categories:
            key = "pendingText"
        elif group.get("diagnostics", {}).get("model") == "type_only":
            key = "typeText"
        else:
            key = "featureText"
        label.setText(label.property(key))
        label.setToolTip(self.ui.referenceLabel.text())

    def _show_diagnostics(self, view):
        details = self.ui.combinationWarningsTextEdit
        group = self.current_group or {}
        diagnostics = group.get("diagnostics", {})
        sections = []
        if group:
            empty = details.property("noneText")
            batch_mode = group.get("batch_mode", "none")
            batch_property = {"none": "mixedBatchText", "separate": "separateBatchText", "parent": "parentBatchText"}.get(batch_mode)
            sections.extend([
                details.property("contextFormat").format(
                    label=group.get("label") or group.get("node") or empty, node=group.get("node") or empty,
                    batch_mode=details.property(batch_property) if batch_property else batch_mode,
                    batch_dimension=group.get("batch_dimension") or empty,
                    parent_batch=group.get("parent_batch_id") or empty,
                    source_batches=", ".join(str(value) for value in group.get("source_batches", [])) or empty),
                details.property("debugScopeText"),
            ])
            report = diagnostics.get("fit_debug_report")
            report = report.strip() if isinstance(report, str) else ""
            sections.append(details.property("debugHeading") + "\n" + (report or details.property("noDebugReportText")))
            if view:
                sections.append(details.property("modelScopeText"))
            group_warnings = list(dict.fromkeys(str(item) for item in
                [*self.result.get("warnings", []), *diagnostics.get("warnings", [])] if item))
            view_warnings = list(dict.fromkeys(str(item) for item in (view or {}).get("warnings", [])
                                               if item and str(item) not in group_warnings))
            if group_warnings:
                sections.append(details.property("groupHeading") + "\n" + "\n\n".join(group_warnings))
            if view_warnings:
                sections.append(details.property("viewHeading") + "\n" + "\n\n".join(view_warnings))
            warnings = group_warnings + view_warnings
            self.ui.warningsLabel.setVisible(bool(warnings))
            self.ui.warningsLabel.setText(self.ui.warningsLabel.property("summaryText").format(count=len(warnings)))
            self.ui.warningsLabel.setToolTip("\n".join(warnings))
        details.setPlainText("\n\n".join(sections))
        self.ui.copyDiagnosticsButton.setEnabled(bool(sections))
        self.ui.saveDiagnosticsButton.setEnabled(bool(sections))
        self.ui.diagnosticsActionStatusLabel.clear()
        self.ui.diagnosticsActionStatusLabel.hide()

    def _copy_diagnostics(self):
        text = self.ui.combinationWarningsTextEdit.toPlainText()
        if not text:
            return
        QApplication.clipboard().setText(text)
        label = self.ui.diagnosticsActionStatusLabel
        label.setText(label.property("copiedText"))
        label.show()

    def _save_diagnostics(self):
        text = self.ui.combinationWarningsTextEdit.toPlainText()
        if not text:
            return
        button = self.ui.saveDiagnosticsButton
        filename, _ = QFileDialog.getSaveFileName(self, button.property("dialogTitle"),
            button.property("defaultFilename"), button.property("fileFilter"))
        if not filename:
            return
        path = Path(filename)
        if not path.suffix:
            path = path.with_suffix(".txt")
        try:
            path.write_text(text + "\n", encoding="utf-8")
        except OSError as error:
            QMessageBox.warning(self, button.property("errorTitle"),
                                button.property("errorFormat").format(error=error))
            return
        label = self.ui.diagnosticsActionStatusLabel
        label.setText(label.property("savedFormat").format(path=path))
        label.show()

    def _complete_all_view(self, candidate=None, *, respect_policy=True):
        group = self.current_group or {}
        types = set((group.get("prediction_context") or {}).get("all_type_ids", [row["tsk_id"] for row in group.get("types", [])]))
        definitions = self._combination_categories or group.get("diagnostics", {}).get("categorical_features", {})
        count = math.prod(len(value["levels"]) for value in definitions.values()) if definitions else 0
        candidates = [candidate, self._home_view, *reversed(group.get("combination_views", []))]
        for view in candidates:
            if (view and view.get("dimension") == ALL_CATEGORY_COMBINATIONS
                    and (not respect_policy or view.get("extrapolate", True) == (not self.ui.riskNoExtrapolationCheckBox.isChecked()))
                    and len(view.get("levels", [])) == count
                    and len(view.get("rows", [])) == len(types) * count
                    and {row["tsk_id"] for row in view["rows"]} == types):
                return view
        return None

    @staticmethod
    def _risk_field_value(row, field):
        value = row.get("tsk_id") if field == "tsk_id" else row.get("categories", {}).get(field[9:])
        return "" if value is None else str(value)

    def _with_combination_chain_details(self, rows, categories):
        """Join saved layout membership to this group's existing whole-chain fit."""
        if not rows:
            return []
        group = self.current_group or {}
        chains = {str(row["chain_id"]): row for row in group.get("chains", [])}
        topology = self.result.get("topology") or (group.get("prediction_context") or {}).get("topology")
        if not topology:
            legacy_members = group.get("chain_members", {})
            chain_ids = set(chains) | set(legacy_members)
            topology = [{**member, "chain_id": chain_id}
                        for chain_id in chain_ids
                        for member in chains.get(chain_id, {}).get("members", legacy_members.get(chain_id, []))]

        names = tuple(sorted(categories))

        def combination_key(tsk_id, values):
            try:
                return str(tsk_id), tuple(category_label(values.get(name), name) for name in names)
            except ValueError:
                return None

        by_combination, incomplete_types = {}, set()
        for source in topology:
            instance = _mapping(source)
            values = {**(instance.get("features") or {}), **(instance.get("categories") or {})}
            key = combination_key(instance.get("tsk_id"), values)
            if key is None or instance.get("chain_id") is None:
                incomplete_types.add(str(instance.get("tsk_id")))
                continue
            by_combination.setdefault(key, set()).add(str(instance["chain_id"]))

        # Repeated instances in one chain still contribute one line. Cache the
        # formatted chain results instead of rebuilding them for each cell.
        chain_details = {}
        for chain_id in sorted({chain_id for ids in by_combination.values() for chain_id in ids}, key=natural_sort_key):
            chain = chains.get(chain_id, {})
            observed = (self.property("combinationChainNoDataText") if chain.get("n_tested") == 0
                        else percentage(chain.get("observed_probability")))
            chain_details[chain_id] = self.property("combinationChainFormat").format(
                chain_id=chain_id.translate(str.maketrans({"\\": "\\\\", "\n": r"\n", "\r": r"\r", "\t": r"\t"})),
                observed=observed, predicted=percentage(chain.get("predicted_probability")))
        details = {}
        enriched = []
        for row in rows:
            key = combination_key(row.get("tsk_id"), row.get("categories") or {})
            if key not in details:
                ids = by_combination.get(key, set())
                if ids:
                    detail = "\n".join([self.property("combinationChainsHeading"),
                        *(chain_details[chain_id] for chain_id in sorted(ids, key=natural_sort_key)),
                        self.property("combinationChainScopeText")])
                else:
                    unavailable = not topology or key is None or str(row.get("tsk_id")) in incomplete_types
                    detail = self.property("combinationChainsUnavailableText" if unavailable else "combinationChainsEmptyText")
                details[key] = detail
            enriched.append({**row, "combination_chain_tooltip": details[key]})
        return enriched

    def _bind_risk_rows(self, rows, categories, *, reset=False):
        """Bind choices without changing the stored calculation or its export order."""
        rows = self._with_combination_chain_details(rows, categories)
        self._risk_source_rows = rows
        self._risk_categories = dict(categories)
        sort = self.ui.riskSortFieldComboBox
        fields = {"tsk_id": sort.property("tskText"),
                  **{"category:" + name: name for name in categories}}
        if reset or list(fields) != list(self._risk_filter_widgets):
            previous = {} if reset else {key: (widget.values, widget.selected_values)
                                          for key, widget in self._risk_filter_widgets.items()}
            for widget in self._risk_filter_widgets.values():
                self.ui.riskFiltersLayout.removeWidget(widget)
                widget.deleteLater()
            self._risk_filter_widgets = {}
            for field in fields:
                widget = TskRiskFilter(self.ui.riskFiltersContents)
                self.ui.riskFiltersLayout.insertWidget(self.ui.riskFiltersLayout.count() - 1, widget)
                self._risk_filter_widgets[field] = widget
                widget.selection_changed.connect(self._apply_risk_view)
                widget.sort_requested.connect(lambda descending, key=field: self._sort_risk_by(key, descending))
            # Reapply partial selections when dimensions first become available.
            for field, (values, selected) in previous.items():
                if field in self._risk_filter_widgets:
                    widget = self._risk_filter_widgets[field]
                    widget.set_values(fields[field], values, reset=True)
                    widget.popup.set_selected_values(selected)
        for field, widget in self._risk_filter_widgets.items():
            if field == "tsk_id":
                values = [row.get("tsk_id") for row in (self.current_group or {}).get("types", [])]
            else:
                values = list(categories[field[9:]].get("levels", []))
            values.extend(self._risk_field_value(row, field) for row in rows)
            widget.set_values(fields[field], values, reset=reset)
            widget.setEnabled(bool(rows))
        current = None if reset else sort.currentData()
        sort.blockSignals(True)
        sort.clear()
        sort.addItem(sort.property("tskText"), "tsk_id")
        sort.addItem(sort.property("probabilityText"), "probability")
        for name in categories:
            sort.addItem(name, "category:" + name)
        sort.setCurrentIndex(max(0, sort.findData(current)))
        sort.setEnabled(bool(rows))
        sort.blockSignals(False)
        direction = self.ui.riskSortDirectionComboBox
        direction.setEnabled(bool(rows))
        if reset:
            direction.blockSignals(True)
            direction.setCurrentIndex(0)
            direction.blockSignals(False)
        self._apply_risk_view()

    def _risk_sort_field_changed(self, *_args):
        direction = self.ui.riskSortDirectionComboBox
        direction.blockSignals(True)
        direction.setCurrentIndex(1 if self.ui.riskSortFieldComboBox.currentData() == "probability" else 0)
        direction.blockSignals(False)
        self._apply_risk_view()

    def _sort_risk_by(self, field, descending):
        sort = self.ui.riskSortFieldComboBox
        sort.blockSignals(True)
        sort.setCurrentIndex(sort.findData(field))
        sort.blockSignals(False)
        direction = self.ui.riskSortDirectionComboBox
        direction.blockSignals(True)
        direction.setCurrentIndex(int(descending))
        direction.blockSignals(False)
        self._apply_risk_view()

    def _clear_risk_filters(self):
        for widget in self._risk_filter_widgets.values():
            widget.blockSignals(True)
            widget.select_all()
            widget.blockSignals(False)
        self._apply_risk_view()

    def _apply_risk_view(self, *_args):
        selected = {field: widget.selected_values for field, widget in self._risk_filter_widgets.items()
                    if widget.selected_values != set(widget.values)}
        rows = [row for row in self._risk_source_rows
                if all(self._risk_field_value(row, field) in values for field, values in selected.items())]
        rows.sort(key=lambda row: natural_sort_key(row.get("tsk_id")))
        field = self.ui.riskSortFieldComboBox.currentData() or "tsk_id"
        descending = self.ui.riskSortDirectionComboBox.currentIndex() == 1
        if field == "probability":
            def estimable(row):
                value = row.get("probability")
                return row.get("identifiable", True) and _finite(value) and 0 <= value <= 1
            available = [row for row in rows if estimable(row)]
            unavailable = [row for row in rows if not estimable(row)]
            rows = sorted(available, key=lambda row: row["probability"], reverse=descending) + unavailable
        else:
            rows.sort(key=lambda row: natural_sort_key(self._risk_field_value(row, field)), reverse=descending)
        self._risk_visible_rows = rows
        self.types_model.set_rows(rows)
        self._restore_risk_selection()
        self._bind_curve_locator(rows)
        self.ui.riskPlot.set_rows(rows, preserve_order=True)
        self.ui.riskCurvePlot.set_rows(rows, preserve_order=True)
        self.ui.riskCurvePlot.set_selected_row(next((row for row in rows
            if self._risk_row_key(row) == self._selected_risk_key), None))
        self.ui.riskPlot.set_selected_row(next((row for row in rows
            if self._risk_row_key(row) == self._selected_risk_key), None))
        self._rebuild_heatmap_matrix()
        self.set_detail_visible(self.detail_visible)
        label = self.ui.riskVisibleCountLabel
        text = label.property("formatText").format(visible=len(rows), total=len(self._risk_source_rows))
        if self._risk_source_rows and not rows:
            text += " · " + label.property("noMatchesText")
        label.setText(text)
        self.ui.clearRiskFiltersButton.setEnabled(bool(selected))

    def _show_all_combination_risk(self, view):
        view = self._complete_all_view(view)
        self.ui.featurePanel.set_group(self.current_group or {}, view=view)
        if not view:
            if self._combination_categories:
                self._home_view = None
                self._home_rows = []
                self._bind_risk_rows([], self._combination_categories)
                self.ui.referenceLabel.setText(self.ui.referenceLabel.property("allCombinationsPendingText"))
            else:
                self._show_heatmap_page()
            self._update_reference_summary()
            return
        self._home_view = view
        self._home_rows = view.get("rows", [])
        self._full_request_pending.discard((self.ui.groupComboBox.currentIndex(), view.get("extrapolate", True)))
        self.ui.riskPlot.setProperty("axisLabel", self.ui.riskPlot.property("combinationAxisLabel"))
        self.ui.riskPlot.set_category_dimensions(self._combination_categories)
        self.ui.riskLegendLabel.setText(self.ui.riskLegendLabel.property("formatText").format(
            confidence=f"{float(view.get('confidence_level', .95)):.0%}"))
        self.ui.riskPlot.setProperty("confidenceLevel", float(view.get("confidence_level", .95)))
        self._update_curve_confidence(float(view.get("confidence_level", .95)))
        self.ui.typesTableView.setProperty("confidenceLevel", float(view.get("confidence_level", .95)))
        self._bind_risk_rows(self._home_rows, self._combination_categories)
        reference = self.ui.referenceLabel
        reference.setText(reference.property("allCombinationsText").format(
            dimensions="、".join(view.get("categorical_dimensions", self._combination_categories)),
            missing=reference.property("extrapolationText" if view.get("extrapolate", True) else "noExtrapolationText")))
        reference.setToolTip(json.dumps(view.get("numeric_reference", {}), ensure_ascii=False))
        self._update_reference_summary()

    @staticmethod
    def _risk_row_key(row):
        return (str(row.get("tsk_id", "")),
                tuple(sorted((str(name), value) for name, value in (row.get("categories") or {}).items())))

    def _remember_risk_selection(self, *_args):
        if self._binding_group or self._syncing_table_selection:
            return
        selected = self.ui.typesTableView.selectionModel().selectedRows()
        if selected:
            self._select_risk_row(self.types_model.rows[selected[0].row()], sync_table=False)
        else:
            self._selected_risk_key = None
            self.ui.riskPlot.set_selected_row(None)
            self.ui.riskCurvePlot.set_selected_row(None)
            self._sync_curve_locator()
            self.ui.combinationHeatmap.set_selected_row(None)
            if self.ui.detailsTabWidget.currentWidget() is self.ui.riskTab:
                self.set_detail_visible(False)

    def _restore_risk_selection(self):
        if self._selected_risk_key is None:
            return
        for index, row in enumerate(self.types_model.rows):
            if self._risk_row_key(row) == self._selected_risk_key:
                self._restore_table_row(self.ui.typesTableView, index)
                return
        self._selected_risk_key = None

    def _configure_heatmap_axes(self):
        """Preserve shared dimensions across groups; assign new categories to X."""
        labels = ({"tsk_id": self.ui.riskSortFieldComboBox.property("tskText"),
                   **{"category:" + name: name for name in self._combination_categories}}
                  if self.current_group else {})
        self._heatmap_dimension_labels = labels
        self._heatmap_x_dimensions = [key for key in self._heatmap_x_dimensions if key in labels]
        self._heatmap_y_dimensions = [key for key in self._heatmap_y_dimensions
                                      if key in labels and key not in self._heatmap_x_dimensions]
        assigned = set(self._heatmap_x_dimensions + self._heatmap_y_dimensions)
        for key in labels:
            if key not in assigned:
                target = self._heatmap_y_dimensions if key == "tsk_id" else self._heatmap_x_dimensions
                target.append(key)
        self._sync_heatmap_axis_selectors()
        self._rebuild_heatmap_matrix()

    def _sync_heatmap_axis_selectors(self):
        for selector, selected in ((self.ui.heatmapXAxisSelector, self._heatmap_x_dimensions),
                                   (self.ui.heatmapYAxisSelector, self._heatmap_y_dimensions)):
            selector.set_dimensions(self._heatmap_dimension_labels, selected)
            selector.setEnabled(bool(self._heatmap_dimension_labels))

    def _heatmap_axis_changed(self, axis, selected):
        # Every dimension belongs to exactly one axis: no averaging or lost keys.
        selected = list(dict.fromkeys(key for key in selected if key in self._heatmap_dimension_labels))
        current, other = ((self._heatmap_x_dimensions, self._heatmap_y_dimensions) if axis == "x"
                          else (self._heatmap_y_dimensions, self._heatmap_x_dimensions))
        remaining = [key for key in other if key not in selected]
        remaining.extend(key for key in current if key not in selected and key not in remaining)
        remaining.extend(key for key in self._heatmap_dimension_labels
                         if key not in selected and key not in remaining)
        if axis == "x":
            self._heatmap_x_dimensions, self._heatmap_y_dimensions = selected, remaining
        else:
            self._heatmap_y_dimensions, self._heatmap_x_dimensions = selected, remaining
        self._sync_heatmap_axis_selectors()
        self._rebuild_heatmap_matrix()

    def _heatmap_axis_label(self, dimensions, values):
        if not dimensions:
            return str(self.ui.combinationHeatmap.property("allAxisText"))
        separator = self.ui.combinationHeatmap.property("axisLabelSeparator")
        return separator.join(str(value) for value in values)

    def _heatmap_axis_title(self, dimensions):
        separator = self.ui.combinationHeatmap.property("axisLabelSeparator")
        return separator.join(self._heatmap_dimension_labels[key] for key in dimensions)

    def _heatmap_axis_tooltip(self, dimensions, values):
        if not dimensions:
            return str(self.ui.combinationHeatmap.property("allAxisText"))
        template = self.ui.combinationHeatmap.property("axisValueFormat")
        separator = self.ui.combinationHeatmap.property("axisLabelSeparator")
        return separator.join(template.format(name=self._heatmap_dimension_labels[key], value=value)
                              for key, value in zip(dimensions, values))

    def _rebuild_heatmap_matrix(self):
        # Cache tuple identities once per selection/layout change. Paging only
        # copies the visible cells, and never uses rendered labels as identities.
        records = {}
        if self._heatmap_dimension_labels:
            for row in self._risk_visible_rows:
                x_key = tuple(self._risk_field_value(row, key) for key in self._heatmap_x_dimensions)
                y_key = tuple(self._risk_field_value(row, key) for key in self._heatmap_y_dimensions)
                records[y_key, x_key] = row
        axis_order = lambda values: (tuple(natural_sort_key(value) for value in values), values)
        self._heatmap_matrix = {
            "records": records,
            "column_keys": sorted({key[1] for key in records}, key=axis_order),
            "row_keys": sorted({key[0] for key in records}, key=axis_order),
        }
        spin = self.ui.heatmapPageSpinBox
        spin.blockSignals(True)
        spin.setValue(1)
        spin.blockSignals(False)
        self._show_heatmap_page()

    def _show_heatmap_page(self, *_args):
        matrix = self._heatmap_matrix
        columns, rows = matrix["column_keys"], matrix["row_keys"]
        records = matrix.get("records", {})
        size = int(self.ui.heatmapPageLabel.property("pageSize"))
        column_pages = max(1, math.ceil(len(columns) / size))
        pages = max(1, math.ceil(len(rows) / size) * column_pages)
        spin = self.ui.heatmapPageSpinBox
        spin.blockSignals(True)
        spin.setMaximum(pages)
        spin.blockSignals(False)
        row_page, column_page = divmod(spin.value() - 1, column_pages)
        row_start, column_start = row_page * size, column_page * size
        shown_columns = columns[column_start:column_start + size]
        shown_rows = rows[row_start:row_start + size]
        cells = []
        for y_key in shown_rows:
            for x_key in shown_columns:
                source = records.get((y_key, x_key))
                if source is not None:
                    cell = {**source, "level": source.get("level", ""),
                            "_heatmap_column_key": x_key, "_heatmap_row_key": y_key}
                    if not self._combination_categories and "instance_count" in source:
                        cell.setdefault("layout_instance_count", source["instance_count"])
                    cells.append(cell)
        self.ui.combinationHeatmap.set_view({
            "column_keys": shown_columns,
            "column_labels": [self._heatmap_axis_label(self._heatmap_x_dimensions, key) for key in shown_columns],
            "column_axis_title": self._heatmap_axis_title(self._heatmap_x_dimensions),
            "column_tooltips": [self._heatmap_axis_tooltip(self._heatmap_x_dimensions, key) for key in shown_columns],
            "row_keys": shown_rows,
            "row_labels": [self._heatmap_axis_label(self._heatmap_y_dimensions, key) for key in shown_rows],
            "row_axis_title": self._heatmap_axis_title(self._heatmap_y_dimensions),
            "row_tooltips": [self._heatmap_axis_tooltip(self._heatmap_y_dimensions, key) for key in shown_rows],
            "rows": cells,
            "confidence_level": float(self.ui.riskPlot.property("confidenceLevel") or .95),
        })
        self.ui.combinationHeatmap.set_selected_row(next((row for row in self._risk_visible_rows
            if self._risk_row_key(row) == self._selected_risk_key), None))
        self.ui.combinationHeatmapMetricComboBox.setEnabled(bool(records) and bool(self._combination_categories))
        if not self._combination_categories:
            self.ui.combinationHeatmapMetricComboBox.setCurrentIndex(0)
        self.ui.heatmapPageControls.setVisible(pages > 1)
        self.ui.heatmapPageLabel.setText(self.ui.heatmapPageLabel.property("formatText").format(
            count=len(records), row_start=row_start + 1 if rows else 0, row_end=min(len(rows), row_start + size),
            column_start=column_start + 1 if columns else 0, column_end=min(len(columns), column_start + size), pages=pages))
        self.ui.combinationHeatmapScrollArea.horizontalScrollBar().setValue(0)
        self.ui.combinationHeatmapScrollArea.verticalScrollBar().setValue(0)

    def _combination_cell_selected(self, tsk_id, level):
        key = str(tsk_id), str(level) if self._combination_categories else ""
        for index, row in enumerate(self.types_model.rows):
            if (str(row.get("tsk_id", "")), str(row.get("level") or "")) == key:
                self._select_risk_row(row)
                self.ui.typesTableView.scrollTo(self.types_model.index(index, 0))
                break
