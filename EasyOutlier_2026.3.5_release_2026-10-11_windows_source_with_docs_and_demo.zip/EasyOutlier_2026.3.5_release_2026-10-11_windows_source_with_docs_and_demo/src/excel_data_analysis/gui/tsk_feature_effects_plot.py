"""Signed effect estimates and their pointwise intervals, painted from saved rows."""
from __future__ import annotations

import math

from PySide6.QtCore import QEvent, QPointF, QRectF, QSize, Qt
from PySide6.QtGui import QColor, QPainter, QPalette, QPen
from PySide6.QtWidgets import QToolTip, QWidget


def _finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


class TskFeatureEffectsPlot(QWidget):
    """Render model coefficients, never infer significance from interval overlap."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.rows = []
        self._hit_regions = []

    def set_rows(self, rows):
        self.rows = list(rows)
        self._hit_regions = []
        height = int(self.property("minimumRowHeight") or 40)
        self.setMinimumHeight(max(150, len(self.rows) * height + 80))
        self.update()

    def sizeHint(self):
        return QSize(int(self.property("preferredCanvasWidth") or 520),
                     int(self.property("preferredCanvasHeight") or 240))

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        palette = self.palette()
        painter.fillRect(event.rect(), palette.color(QPalette.Base))
        ink = palette.color(QPalette.Text)
        muted = QColor(ink)
        muted.setAlpha(190)
        painter.setPen(ink)
        self._hit_regions = []
        if not self.rows:
            painter.drawText(self.rect().adjusted(12, 12, -12, -12), Qt.AlignCenter | Qt.TextWordWrap,
                             str(self.property("emptyText") or ""))
            return
        metrics = self.fontMetrics()
        label_width = min(float(self.property("labelMaximumWidth") or 230), self.width() * .32)
        left, right = max(70., label_width), max(100., self.width() - 25.)
        width = max(1., right - left)
        values = [float(value) for row in self.rows for value in
                  (row.get("estimate"), row.get("ci_lower"), row.get("ci_upper")) if _finite(value)]
        low, high = min([0., *values]), max([0., *values])
        extent = max(high - low, .5)
        low, high = low - .08 * extent, high + .08 * extent

        def x(value):
            return left + (value - low) / (high - low) * width

        top = 55.
        row_height = float(self.property("minimumRowHeight") or 40)
        bottom = top + len(self.rows) * row_height
        painter.setPen(muted)
        painter.drawText(QRectF(left, 5, width, 20), Qt.AlignCenter,
                         metrics.elidedText(str(self.property("axisLabel") or ""), Qt.ElideRight, int(width)))
        for tick in range(5):
            value = low + (high - low) * tick / 4
            position = x(value)
            painter.setPen(QPen(palette.color(QPalette.Mid), .5))
            painter.drawLine(QPointF(position, top - 8), QPointF(position, bottom))
            painter.setPen(muted)
            painter.drawText(QRectF(position - 38, 27, 76, 20), Qt.AlignCenter, f"{value:.3g}")
        painter.setPen(QPen(ink, 1., Qt.DashLine))
        painter.drawLine(QPointF(x(0.), top - 8), QPointF(x(0.), bottom))
        start = max(0, int((event.rect().top() - top) // row_height))
        stop = min(len(self.rows), int((event.rect().bottom() - top) // row_height) + 1)
        for index in range(start, stop):
            row = self.rows[index]
            y = top + (index + .5) * row_height
            label = str(row.get("label", ""))
            painter.setPen(ink)
            painter.drawText(QRectF(5, y - row_height / 2, left - 13, row_height),
                             Qt.AlignRight | Qt.AlignVCenter,
                             metrics.elidedText(label, Qt.ElideRight, max(1, int(left - 13))))
            region = QRectF(0, y - row_height / 2, self.width(), row_height)
            self._hit_regions.append((region, str(row.get("tooltip") or label)))
            estimate = row.get("estimate")
            if not _finite(estimate):
                painter.setPen(muted)
                painter.drawText(QRectF(left + 8, y - 12, width - 8, 24), Qt.AlignLeft | Qt.AlignVCenter,
                                 str(row.get("unavailable_label") or self.property("missingText") or ""))
                continue
            reference = bool(row.get("reference"))
            color = muted if reference else QColor(str(self.property("positiveColor" if estimate >= 0 else "negativeColor")))
            if self.property("drawBars") and not reference:
                fill = QColor(color)
                fill.setAlpha(105)
                painter.fillRect(QRectF(min(x(0.), x(estimate)), y - 8, abs(x(estimate) - x(0.)), 16), fill)
            painter.setPen(QPen(color, 1.8))
            lower, upper = row.get("ci_lower"), row.get("ci_upper")
            if not reference and _finite(lower) and _finite(upper):
                painter.drawLine(QPointF(x(lower), y), QPointF(x(upper), y))
                painter.drawLine(QPointF(x(lower), y - 5), QPointF(x(lower), y + 5))
                painter.drawLine(QPointF(x(upper), y - 5), QPointF(x(upper), y + 5))
            painter.setBrush(color)
            painter.drawEllipse(QPointF(x(estimate), y), 3.5, 3.5)
            painter.setBrush(Qt.NoBrush)
            if reference or not (_finite(lower) and _finite(upper)):
                painter.setPen(muted)
                text = str(self.property("referenceText" if reference else "pointOnlyText") or "")
                painter.drawText(QRectF(left + 5, y + 5, width - 10, row_height / 2), Qt.AlignRight | Qt.AlignVCenter,
                                 metrics.elidedText(text, Qt.ElideRight, max(1, int(width - 10))))

    def event(self, event):
        if event.type() == QEvent.ToolTip:
            for region, text in self._hit_regions:
                if region.contains(event.pos()):
                    QToolTip.showText(event.globalPos(), text, self)
                    return True
            QToolTip.hideText()
        return super().event(event)
