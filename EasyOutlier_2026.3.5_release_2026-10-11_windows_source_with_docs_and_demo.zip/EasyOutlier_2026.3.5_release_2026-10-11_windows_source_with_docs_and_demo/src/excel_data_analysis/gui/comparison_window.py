from __future__ import annotations

import re
from hashlib import sha256
from concurrent.futures import CancelledError
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from threading import Event
from time import perf_counter

from PySide6.QtCore import QEvent, QObject, QStringListModel, QThread, QTimer, Qt, Signal, Slot
from PySide6.QtWidgets import (
    QApplication,
    QCompleter,
    QListWidgetItem,
    QMainWindow,
    QTableWidgetItem,
    QTreeWidgetItem,
    QWidget,
)

from ..field_names import field_key as normalized_field_key, row_fields
from ..file_revision import golden_file_revision
from ..comparison_models import MetricDescriptor, MetricFilterRule, PlotBuildResult, PlotSeries
from ..comparison_service import (
    PlotAnalysisSession,
    build_plot_result,
    lane_dimension_options,
    load_measurements_for_plot,
    metric_filter_fields,
    project_plot_result_columns,
)
from ..models import MeasurementRecord, TemplateConfig
from ..plot_navigation import ratio_filter_from_navigation, ratio_filter_payload
from ..sample_locator import SamplePointIndex, SampleSelection
from .comparison_plot_view import PlotViewGroup
from .ui_comparison_window import Ui_PlotInspectorWindow


@dataclass(frozen=True, slots=True)
class PlotInspectorContext:
    template_path: str
    analysis_scope: str
    input_path: str = ""
    storage_path: str = ""
    golden_path: str = ""
    dataset_ids: list[str] | None = None
    dimension_filters: dict[str, dict[str, list[str]]] | None = None
    column_filters: dict[str, dict[str, list[str]]] | None = None
    outlier_fail_method: str = "modified_z_score"
    zscore_threshold: float | None = 3.5
    template_payload: dict | None = None
    zscore_use_golden_reference: bool | None = None


@dataclass(frozen=True, slots=True)
class RenderedMetricPlot:
    """Searchable plot metadata, independent of whether any pixels were rendered."""

    descriptor: MetricDescriptor
    title: str
    series: tuple[PlotSeries, ...]


@dataclass(frozen=True, slots=True)
class SearchMatch:
    group_index: int
    lane_index: int | None = None


def _default_metric_rules() -> list[MetricFilterRule]:
    return [
        MetricFilterRule(
            field_name="Metric Has Outlier",
            operator="is",
            value="true",
            connector="and",
        )
    ]


@dataclass(frozen=True, slots=True)
class SearchGroupData:
    group_index: int
    group_texts: tuple[str, ...]
    lane_headers: tuple[str, ...]
    lane_labels: tuple[str, ...]
    visible_indices: tuple[int, ...]


class _WorkerCancelled(Exception):
    pass


class PlotDataLoadWorker(QObject):
    stopped = Signal()
    progress = Signal(str, int, int)
    finished = Signal(object, object, object)
    failed = Signal(str)

    def __init__(self, context: PlotInspectorContext, metric_rules: list[MetricFilterRule] | None = None,
                 report_filter_config: dict[str, list[str]] | None = None,
                 analysis_session: PlotAnalysisSession | None = None) -> None:
        super().__init__()
        self._context = context
        self._metric_rules = _default_metric_rules() if metric_rules is None else list(metric_rules)
        self._report_filter_config = report_filter_config
        self._analysis_session = analysis_session
        self._cancelled = Event()

    def cancel(self) -> None:
        self._cancelled.set()

    def _progress(self, message: str, value: int, total: int) -> None:
        if self._cancelled.is_set():
            raise _WorkerCancelled
        self.progress.emit(message, value, total)

    @Slot()
    def run(self) -> None:
        try:
            self._progress("Loading template and measurements...", 0, 12)
            template, measurements = load_measurements_for_plot(
                template_path=self._context.template_path,
                analysis_scope=self._context.analysis_scope,
                input_path=self._context.input_path or None,
                storage_path=self._context.storage_path or None,
                dataset_ids=self._context.dataset_ids,
                dimension_filters=self._context.dimension_filters,
                column_filters=self._context.column_filters,
                template_payload=self._context.template_payload,
                progress_callback=lambda message, value, total: self._progress(
                    message,
                    value,
                    12,
                ),
            )
            result = build_plot_result(
                template=template,
                measurements=measurements,
                metric_rules=self._metric_rules,
                report_filter_config=self._report_filter_config,
                golden_path=self._context.golden_path or None,
                outlier_fail_method=self._context.outlier_fail_method,
                zscore_threshold=self._context.zscore_threshold,
                zscore_use_golden_reference=self._context.zscore_use_golden_reference,
                analysis_session=self._analysis_session,
                progress_callback=lambda message, value, total: self._progress(
                    message,
                    4 + value,
                    4 + total,
                ),
            )
            if not self._cancelled.is_set():
                self.finished.emit(template, measurements, result)
        except _WorkerCancelled:
            pass
        except Exception as exc:
            self.failed.emit(str(exc))
        finally:
            self.stopped.emit()


class PlotBuildWorker(QObject):
    stopped = Signal()
    progress = Signal(int, str, int, int)
    finished = Signal(int, object, bool)
    failed = Signal(int, str)

    def __init__(
        self,
        request_id: int,
        template: TemplateConfig,
        measurements: list[MeasurementRecord],
        metric_rules: list[MetricFilterRule],
        selected_metrics: list[str],
        lane_dimensions: list[str],
        golden_path: str,
        outlier_fail_method: str,
        zscore_threshold: float | None,
        update_tree: bool,
        report_filter_config: dict[str, list[str]] | None = None,
        zscore_use_golden_reference: bool | None = None,
        analysis_session: PlotAnalysisSession | None = None,
    ) -> None:
        super().__init__()
        self._request_id = request_id
        self._template = template
        self._measurements = measurements
        self._metric_rules = metric_rules
        self._selected_metrics = selected_metrics
        self._lane_dimensions = lane_dimensions
        self._golden_path = golden_path
        self._outlier_fail_method = outlier_fail_method
        self._zscore_threshold = zscore_threshold
        self._zscore_use_golden_reference = zscore_use_golden_reference
        self._update_tree = update_tree
        self._report_filter_config = report_filter_config
        self._analysis_session = analysis_session
        self._cancelled = Event()

    def cancel(self) -> None:
        self._cancelled.set()

    def _progress(self, message: str, value: int, total: int) -> None:
        if self._cancelled.is_set():
            raise _WorkerCancelled
        self.progress.emit(self._request_id, message, value, total)

    @Slot()
    def run(self) -> None:
        try:
            self._progress("Building plot groups...", 0, 8)
            result = build_plot_result(
                template=self._template,
                measurements=self._measurements,
                metric_rules=self._metric_rules,
                metric_search_query="",
                selected_logical_metrics=self._selected_metrics,
                lane_dimensions=self._lane_dimensions,
                golden_path=self._golden_path or None,
                outlier_fail_method=self._outlier_fail_method,
                zscore_threshold=self._zscore_threshold,
                zscore_use_golden_reference=self._zscore_use_golden_reference,
                report_filter_config=self._report_filter_config,
                analysis_session=self._analysis_session,
                progress_callback=self._progress,
            )
            if not self._cancelled.is_set():
                self.finished.emit(self._request_id, result, self._update_tree)
        except _WorkerCancelled:
            pass
        except Exception as exc:
            self.failed.emit(self._request_id, str(exc))
        finally:
            self.stopped.emit()


class SearchWorker(QObject):
    stopped = Signal()
    progress = Signal(int, int, int, str)
    finished = Signal(int, object, object, bool, bool)
    failed = Signal(int, str)

    def __init__(
        self,
        request_id: int,
        groups: list[SearchGroupData],
        query: str,
        reset_to_first: bool,
        apply_scroll: bool,
    ) -> None:
        super().__init__()
        self._request_id = request_id
        self._groups = groups
        self._query = query
        self._reset_to_first = reset_to_first
        self._apply_scroll = apply_scroll
        self._cancelled = Event()

    def cancel(self) -> None:
        self._cancelled.set()

    @Slot()
    def run(self) -> None:
        try:
            if self._cancelled.is_set():
                return
            matches: list[SearchMatch] = []
            result_groups: set[int] = set()
            total = max(1, len(self._groups))
            emit_every = max(1, total // 100)
            for index, group in enumerate(self._groups, start=1):
                if self._cancelled.is_set():
                    return
                if index == 1 or index == total or index % emit_every == 0:
                    self.progress.emit(self._request_id, index, total, "Searching plot results")
                visible_indices = set(group.visible_indices)
                if not visible_indices:
                    continue
                group_match = _text_matches_query(list(group.group_texts), self._query)
                lane_matches = [
                    lane_index
                    for lane_index, label in enumerate(group.lane_labels)
                    if lane_index in visible_indices
                    if _text_matches_query([*group.group_texts, *group.lane_headers, label], self._query)
                ]
                if group_match or lane_matches:
                    result_groups.add(group.group_index)
                if lane_matches:
                    matches.extend(SearchMatch(group.group_index, lane_index) for lane_index in lane_matches)
                elif group_match:
                    matches.append(SearchMatch(group.group_index, None))
            if self._cancelled.is_set():
                return
            self.finished.emit(
                self._request_id,
                matches,
                result_groups,
                self._reset_to_first,
                self._apply_scroll,
            )
        except Exception as exc:
            self.failed.emit(self._request_id, str(exc))
        finally:
            self.stopped.emit()


class SampleIndexWorker(QObject):
    stopped = Signal()
    finished = Signal(int, object)
    failed = Signal(int, str)

    def __init__(self, generation: int, result: PlotBuildResult, fields: tuple[str, ...]) -> None:
        super().__init__()
        self.generation = generation
        self.result = result
        self.fields = fields
        self._cancelled = Event()

    def cancel(self) -> None:
        self._cancelled.set()

    @Slot()
    def run(self) -> None:
        try:
            index = SamplePointIndex.build(self.result.series_by_metric, self.fields, self._cancelled.is_set)
            if not self._cancelled.is_set():
                self.finished.emit(self.generation, index)
        except CancelledError:
            pass
        except Exception as exc:
            if not self._cancelled.is_set():
                self.failed.emit(self.generation, str(exc))
        finally:
            self.stopped.emit()


class PlotInspectorWindow(QMainWindow):
    def __init__(self, context: PlotInspectorContext, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.ui = Ui_PlotInspectorWindow()
        self.ui.setupUi(self)
        self._context = context
        self._sync_range_legend()
        self._template: TemplateConfig | None = None
        self._measurements: list[MeasurementRecord] = []
        self._analysis_session = PlotAnalysisSession()
        self._rules: list[MetricFilterRule] = _default_metric_rules()
        self._metric_catalog: tuple[MetricDescriptor, ...] = ()
        self._metric_search_suggestions: set[str] = set()
        self._suspend_metric_item_changes = False
        self._suspend_metric_tree_selection = False
        self._suspend_lane_item_changes = False
        self._close_requested = False
        self._delete_pending = False
        self._load_thread: QThread | None = None
        self._load_worker: PlotDataLoadWorker | None = None
        self._build_request_id = 0
        self._build_threads: list[QThread] = []
        self._build_workers: list[PlotBuildWorker] = []
        self._pending_build_worker: PlotBuildWorker | None = None
        self._active_build_signature: tuple[object, ...] | None = None
        self._last_build_signature: tuple[object, ...] | None = None
        self._load_build_signature: tuple[object, ...] | None = None
        self._report_filter_config: dict[str, list[str]] = {}
        self._pending_summary_navigation: tuple[dict, dict] | None = None
        self._summary_restore_pending = False
        self._summary_raw_columns: frozenset[str] | None = None
        self._summary_target_metrics: frozenset[str] | None = None
        self._projection_signature: tuple | None = None
        self._analysis_result: PlotBuildResult | None = None
        self._search_request_id = 0
        self._search_threads: list[QThread] = []
        self._search_workers: list[SearchWorker] = []
        self._active_search_signature: tuple[str, str, int] | None = None
        self._current_result: PlotBuildResult | None = None
        self._result_generation = 0
        self._last_render_signature: tuple[object, ...] | None = None
        self._rendered_plots: list[RenderedMetricPlot] = []
        self._rendered_generation = 0
        self._search_display_signature: tuple[str, str, int] | None = None
        self._enter_advances_search = False
        self._search_matches: list[SearchMatch] = []
        self._search_match_cursor = -1
        self._search_result_groups: set[int] = set()
        self._compact_search_base_selection: dict[str, set[str]] | None = None
        self._sample_index: SamplePointIndex | None = None
        self._sample_selection: SampleSelection | None = None
        self._sample_conditions: dict[str, str] = {}
        self._sample_active_conditions: dict[str, str] = {}
        self._sample_threads: list[QThread] = []
        self._sample_workers: list[SampleIndexWorker] = []
        self._sample_defer_started: float | None = None
        self._sample_index_timer = QTimer(self)
        self._sample_index_timer.setSingleShot(True)
        self._sample_index_timer.timeout.connect(self._start_sample_index)
        self._sample_value_model = QStringListModel(self)
        self._sample_completer = QCompleter(self._sample_value_model, self)
        self._sample_completer.setCaseSensitivity(Qt.CaseSensitivity.CaseSensitive)
        self._sample_completer.setFilterMode(Qt.MatchFlag.MatchContains)
        self._sample_completer.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        self.ui.sampleValueComboBox.setCompleter(self._sample_completer)
        self._lane_height = 30
        self._render_timer = QTimer(self)
        self._render_timer.setSingleShot(True)
        self._render_timer.timeout.connect(self._render_selected_metrics)
        self._metric_search_timer = QTimer(self)
        self._metric_search_timer.setSingleShot(True)
        self._metric_search_timer.timeout.connect(self._refresh_search_results_from_timer)
        self._metric_search_model = QStringListModel(self)
        self._metric_filter_value_model = QStringListModel(self)
        self._metric_search_completer = QCompleter(self._metric_search_model, self)
        self._metric_search_completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self._metric_search_completer.setFilterMode(Qt.MatchFlag.MatchContains)
        self._metric_search_completer.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        self.ui.metricSearchEdit.setCompleter(self._metric_search_completer)
        self.ui.metricSearchEdit.installEventFilter(self)
        self._metric_filter_value_completer = QCompleter(self._metric_filter_value_model, self)
        self._metric_filter_value_completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self._metric_filter_value_completer.setFilterMode(Qt.MatchFlag.MatchContains)
        self._metric_filter_value_completer.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        self.ui.metricValueComboBox.setEditable(True)
        self.ui.metricValueComboBox.setCompleter(self._metric_filter_value_completer)
        self._render_status_label = self.ui.renderStatusLabel
        self._render_progress = self.ui.renderProgressBar
        self.ui.plotScrollArea.renderingProgress.connect(self._on_view_render_progress)
        self.ui.plotScrollArea.renderingReady.connect(self._on_view_render_ready)
        self.ui.plotScrollArea.renderFailed.connect(self._on_render_failed)
        self.ui.plotScrollArea.workersFinished.connect(self._delete_after_workers_finish)
        self._wire_events()
        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(self._on_application_quit)
        QTimer.singleShot(0, self._start_load_context)

    def context(self) -> PlotInspectorContext:
        """The analysis snapshot used by this window, for safe window reuse."""
        return self._context

    def navigate_to_summary(self, target: dict, navigation: dict) -> None:
        """Locate a report sample without filtering the comparison population.

        A request may arrive before loading/indexing has completed. Keep only
        the latest requested sample while those asynchronous steps finish.
        """
        if self._close_requested:
            return
        conditions = target.get("conditions")
        metrics = target.get("logical_metrics")
        if (not isinstance(conditions, dict) or not conditions
                or any(not isinstance(key, str) or not isinstance(value, str)
                       for key, value in conditions.items())):
            raise ValueError("The summary sample requires complete identity dimensions.")
        if not isinstance(metrics, (list, tuple)) or not metrics or any(not isinstance(item, str) for item in metrics):
            raise ValueError("The summary sample has no related plot metrics.")
        config = ratio_filter_from_navigation(navigation)
        self._report_filter_config = {
            key: values for key, values in ratio_filter_payload(config).items() if values
        }
        # A row can contain hundreds of other samples with thousands of links.
        # Retain only this target and the small report scope metadata.
        self._pending_summary_navigation = (
            deepcopy(target), deepcopy({key: value for key, value in navigation.items() if key != "targets"})
        )
        self._summary_restore_pending = False
        raw_columns = target.get("raw_columns")
        self._summary_raw_columns = frozenset(raw_columns) if isinstance(raw_columns, (list, tuple)) else None
        self._summary_target_metrics = frozenset(metrics)
        self._update_summary_link_scope(target, navigation)
        self.ui.summaryLinkGroupBox.setVisible(True)
        self._rules = []
        self._populate_rules_table()
        self._metric_search_timer.stop()
        self.ui.metricSearchEdit.blockSignals(True)
        self.ui.metricSearchEdit.clear()
        self.ui.metricSearchEdit.blockSignals(False)
        self._compact_search_base_selection = None
        self._sample_active_conditions.clear()
        self._sample_conditions.clear()
        self._sample_selection = None
        self.ui.plotScrollArea.set_sample_highlights(None)
        self._invalidate_sample_search()
        if self._template is not None:
            # Always retain the full node history for failure/recovery checks.
            self._populate_lane_options()
        self.ui.sampleLocatorStatusLabel.setText("Locating sample from Outlier Summary...")
        if not self._summary_navigation_needs_build():
            self._apply_pending_summary_navigation()

    def _report_filter_signature(self) -> tuple:
        return tuple(sorted((key, tuple(values)) for key, values in self._report_filter_config.items() if values))

    def _summary_navigation_needs_build(self) -> bool:
        if ((self._pending_summary_navigation is None and not self._summary_restore_pending)
                or self._template is None or self._current_result is None):
            return False
        if self._current_build_signature([]) == self._last_build_signature:
            if self._active_build_signature is not None:
                # The user can return to the currently cached scope while a
                # different one is still building. Invalidate that old request
                # so it cannot replace this newer click when it finishes.
                self._start_build_worker(selected_metrics=[], update_tree=True)
            self._update_summary_column_projection()
            self._summary_restore_pending = False
            return False
        # Build all metrics in this report's filter scope once. Picking another
        # sample or chain in that scope only changes checkboxes and overlays.
        self._start_build_worker(selected_metrics=[], update_tree=True)
        return True

    def _project_analysis_result(self, result: PlotBuildResult) -> PlotBuildResult:
        self._analysis_result = result
        self._projection_signature = (self._summary_raw_columns, self._summary_target_metrics)
        return project_plot_result_columns(result, self._summary_raw_columns, self._summary_target_metrics)

    def _update_summary_column_projection(self) -> None:
        signature = (self._summary_raw_columns, self._summary_target_metrics)
        if self._analysis_result is None or signature == self._projection_signature:
            return
        result = self._project_analysis_result(self._analysis_result)
        if result is self._current_result:
            return
        self._current_result = result
        self._result_generation += 1
        self._metric_catalog = result.metrics
        self._update_metric_search_completions(result.metrics)
        self._populate_metric_tree(result)
        self._queue_render_current_result()
        self._start_sample_index()

    def _apply_pending_summary_navigation(self) -> None:
        if (self._pending_summary_navigation is None or self._sample_index is None
                or self._template is None or self._close_requested):
            return
        if self._summary_navigation_needs_build():
            return
        if self._sample_index is None:
            return
        target, navigation = self._pending_summary_navigation
        self._pending_summary_navigation = None
        conditions = dict(target["conditions"])
        if set(conditions) != set(self._sample_index.fields):
            self.ui.sampleLocatorStatusLabel.setText("Cannot locate this sample: its identity dimensions differ from this analysis.")
            return
        metrics = set(target["logical_metrics"])
        self._set_metric_tree_selection({
            key: {lane.aggregate_id for lane in lanes}
            for key, lanes in self._current_result.series_by_metric.items() if key in metrics
        })
        self._sample_conditions = conditions
        self._populate_sample_conditions()
        self._update_sample_values()
        self._apply_sample_conditions(conditions, scroll=False)
        focus_nodes = [str(value) for value in target.get("focus_nodes", [])]
        node_field = self._template.report.reliability_node_dimension
        first_match = None
        focus_match = None
        for group_index, rendered in enumerate(self._rendered_plots):
            if rendered.descriptor.logical_metric not in metrics:
                continue
            lanes = self.ui.plotScrollArea.displayed_lane_indices(group_index)
            if lanes and first_match is None:
                first_match = SearchMatch(group_index, lanes[0])
            for lane_index in lanes:
                lane = rendered.series[lane_index]
                if lane.points and lane.points[0].dimensions.get(node_field) in focus_nodes:
                    focus_match = SearchMatch(group_index, lane_index)
                    break
            if focus_match is not None:
                break
        match = focus_match or first_match
        if match is not None:
            self._select_metric_tree_match(match)
            self.ui.plotScrollArea.scroll_to(match.group_index, match.lane_index)
        self._show_summary_navigation_status(target, navigation)

    def _show_summary_navigation_status(self, target: dict, navigation: dict) -> None:
        self._update_summary_link_scope(target, navigation)
        selection = self._sample_selection
        requested_metrics = set(target["logical_metrics"])
        present_metrics = requested_metrics.intersection(selection.metric_keys)
        if not present_metrics:
            note = "No numeric points for this sample in the selected scope. Missing/non-numeric cells cannot be plotted."
        else:
            note = self.ui.sampleLocatorStatusLabel.text()
            missing_metrics = requested_metrics - present_metrics
            present_columns = set()
            present_nodes = set()
            for metric in present_metrics:
                for lane, indices in zip(self._current_result.series_by_metric[metric], selection.indices_by_metric[metric]):
                    for point_index in indices:
                        point = lane.points[int(point_index)]
                        present_columns.add(point.raw_column)
                        present_nodes.add(point.dimensions.get(self._template.report.reliability_node_dimension))
            missing_columns = set(target.get("raw_columns", [])) - present_columns
            missing_nodes = set(target.get("focus_nodes", [])) - present_nodes
            if missing_metrics or missing_columns:
                note += (f" Some related measurements have no numeric points "
                         f"({len(missing_metrics)} metric(s), {len(missing_columns)} column(s)).")
            if missing_nodes:
                note += f" No numeric points at summary node(s): {', '.join(sorted(missing_nodes))}; showing available history."
        self.ui.sampleLocatorStatusLabel.setText(note)
        self.ui.sampleLocatorStatusLabel.setToolTip(note)

    def _update_summary_link_scope(self, target: dict, navigation: dict) -> None:
        report_name = str(navigation.get("label") or navigation.get("id") or "Outlier Summary")
        groups = ", ".join(
            f"{field}={value}" for field, value in zip(
                navigation.get("group_dimensions", []), navigation.get("group_values", [])
            )
        )
        filters = "; ".join(
            f"{_readable_field_name(field)}: {', '.join(values[:3])}"
            + (f" (+{len(values) - 3})" if len(values) > 3 else "")
            for field, values in self._report_filter_config.items()
        ) or "All columns"
        source = f"From {report_name}" + (f" ({groups})" if groups else "") + f". Report filter: {filters}."
        filter_details = "\n".join(
            f"{_readable_field_name(field)}: {', '.join(values)}"
            for field, values in self._report_filter_config.items()
        ) or "All columns"
        columns = list(target.get("raw_columns", []))
        if columns:
            source += f" Related columns: {', '.join(columns[:3])}"
            if len(columns) > 3:
                source += f" (+{len(columns) - 3})"
            source += "."
        self.ui.summaryLinkScopeLabel.setText(source)
        self.ui.summaryLinkScopeLabel.setToolTip(
            f"From {report_name}\n{groups}\nReport filter:\n{filter_details}\nRelated columns: {', '.join(columns)}"
        )

    def _reset_summary_link(self) -> None:
        if self._close_requested:
            return
        self._pending_summary_navigation = None
        self._summary_restore_pending = True
        self._report_filter_config = {}
        self._summary_raw_columns = None
        self._summary_target_metrics = None
        self._rules = []
        self._populate_rules_table()
        self.ui.summaryLinkGroupBox.setVisible(False)
        self._clear_sample_locator()
        self.ui.sampleLocatorStatusLabel.setToolTip("")
        if not self._summary_navigation_needs_build() and self._current_result is not None:
            self._render_timer.stop()
            self._render_selected_metrics()
            self._set_all_metric_tree_items_checked(Qt.CheckState.Checked)


    def _wire_events(self) -> None:
        self.ui.resetSummaryLinkButton.clicked.connect(self._reset_summary_link)
        self.ui.sampleFieldComboBox.currentIndexChanged.connect(self._update_sample_values)
        self.ui.sampleAddConditionButton.clicked.connect(self._set_sample_condition)
        self.ui.sampleRemoveConditionButton.clicked.connect(self._remove_sample_condition)
        self.ui.sampleLocateButton.clicked.connect(self._locate_sample)
        self.ui.sampleClearButton.clicked.connect(self._clear_sample_locator)
        self.ui.sampleValueComboBox.lineEdit().returnPressed.connect(self._locate_sample)
        self.ui.sampleConditionsTableWidget.cellDoubleClicked.connect(self._edit_sample_condition)
        self.ui.metricSearchEdit.textChanged.connect(self._on_metric_search_text_changed)
        self.ui.metricSearchEdit.returnPressed.connect(self._activate_search_from_enter)
        self._metric_search_completer.activated.connect(self._on_metric_search_completion_activated)
        self.ui.metricSearchViewComboBox.currentTextChanged.connect(self._on_metric_search_view_changed)
        self.ui.metricSearchButton.clicked.connect(self._activate_search_from_button)
        self.ui.metricSearchPrevButton.clicked.connect(self._select_previous_search_match)
        self.ui.metricSearchNextButton.clicked.connect(self._select_next_search_match)
        self.ui.selectAllMetricsButton.clicked.connect(self._select_all_metric_tree_items)
        self.ui.deselectAllMetricsButton.clicked.connect(self._deselect_all_metric_tree_items)
        self.ui.metricRealtimeCheckBox.stateChanged.connect(self._on_metric_realtime_changed)
        self.ui.advancedMetricFilterButton.toggled.connect(self.ui.advancedMetricFilterWidget.setVisible)
        self.ui.metricFieldComboBox.currentTextChanged.connect(self._update_metric_filter_value_options)
        self.ui.metricOperatorComboBox.currentTextChanged.connect(self._update_metric_filter_value_options)
        self.ui.addMetricRuleButton.clicked.connect(self._add_metric_rule)
        self.ui.deleteMetricRuleButton.clicked.connect(self._delete_selected_metric_rules)
        self.ui.modifyMetricRuleButton.clicked.connect(self._modify_selected_metric_rule)
        self.ui.clearMetricRulesButton.clicked.connect(self._clear_metric_rules)
        self.ui.metricRulesTableWidget.cellDoubleClicked.connect(self._load_metric_rule_into_editor)
        self.ui.refreshButton.clicked.connect(self._refresh_all)
        self.ui.plotTypeComboBox.currentTextChanged.connect(self._queue_render_selected_metrics)
        self.ui.laneDimensionsListWidget.itemChanged.connect(self._on_lane_item_changed)
        self.ui.laneDimensionsListWidget.model().rowsMoved.connect(self._on_lane_order_changed)
        self.ui.metricTreeWidget.itemChanged.connect(self._on_metric_tree_item_changed)
        self.ui.metricTreeWidget.itemSelectionChanged.connect(self._on_metric_tree_selection_changed)

    def _start_load_context(self) -> None:
        if self._close_requested:
            return
        self.ui.plotScrollArea.prewarm()
        self._set_controls_enabled(False)
        self._set_status_progress("Loading plot data...", 0, 12)
        self.ui.summaryLabel.setText("Loading plot data...")
        worker = PlotDataLoadWorker(
            self._context, self._rules, self._report_filter_config, self._analysis_session,
        )
        # Lane choices are initialized only once the template has been read.
        self._load_build_signature = (
            tuple((rule.connector, rule.field_name, rule.operator, rule.value) for rule in self._rules),
            self._report_filter_signature(),
            self._golden_content_signature(),
        )
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._on_load_progress)
        worker.finished.connect(self._on_load_finished)
        worker.failed.connect(self._on_load_failed)
        worker.stopped.connect(worker.deleteLater)
        worker.stopped.connect(thread.quit, Qt.ConnectionType.DirectConnection)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(self._clear_load_worker)
        thread.finished.connect(self._delete_after_workers_finish)
        self._load_worker = worker
        self._load_thread = thread
        thread.start()

    @Slot(str, int, int)
    def _on_load_progress(self, message: str, value: int, total: int) -> None:
        if self._close_requested:
            return
        self._set_status_progress(message, value, total)
        self.ui.summaryLabel.setText(message)

    @Slot(object, object, object)
    def _on_load_finished(
        self,
        template: TemplateConfig,
        measurements: list[MeasurementRecord],
        result: PlotBuildResult,
    ) -> None:
        if self._close_requested:
            return
        self._template = template
        self._measurements = measurements
        result = self._project_analysis_result(result)
        self._populate_filter_fields()
        self._populate_lane_options()
        self._populate_rules_table()
        self._metric_catalog = result.metrics
        self._current_result = result
        self._result_generation += 1
        self._last_build_signature = self._current_build_signature(selected_metrics=[])
        if self._load_build_signature is not None:
            rules, report_filter, golden_signature = self._load_build_signature
            signature = list(self._last_build_signature)
            signature[0], signature[3], signature[-1] = rules, golden_signature, report_filter
            self._last_build_signature = tuple(signature)
        self._active_build_signature = None
        self._update_metric_search_completions(result.metrics)
        self._update_metric_filter_value_options()
        self._populate_metric_tree(result)
        self._set_controls_enabled(True)
        self._set_render_busy(False)
        self._queue_render_current_result()
        if not self._summary_navigation_needs_build():
            self._start_sample_index()

    @Slot(str)
    def _on_load_failed(self, message: str) -> None:
        if self._close_requested:
            return
        self._set_controls_enabled(True)
        self._set_render_busy(False)
        self.ui.summaryLabel.setText(f"Plot data unavailable: {message}")

    def _clear_load_worker(self) -> None:
        self._load_worker = None
        self._load_thread = None

    def _start_sample_index(self) -> None:
        self._sample_index_timer.stop()
        if self._close_requested:
            return
        for worker in self._sample_workers:
            worker.cancel()
        self._sample_index = None
        self._sample_selection = None
        self.ui.plotScrollArea.set_sample_highlights(None)
        self.ui.sampleLocatorGroupBox.setEnabled(False)
        fields = tuple(self._template.report.sample_dimension_names) if self._template else ()
        if not fields or self._current_result is None:
            self.ui.sampleLocatorStatusLabel.setText("The template has no sample identity dimensions.")
            return
        self.ui.sampleLocatorStatusLabel.setText("Preparing sample lookup...")
        if self._result_generation == 1:
            # Let the initial Qt tree/layout and visible tiles settle before a
            # Python index worker competes for the GIL. Do not wait indefinitely
            # if rendering fails or a very large first tile takes longer.
            if self._sample_defer_started is None:
                self._sample_defer_started = perf_counter()
            if (perf_counter() - self._sample_defer_started < 1.0
                    and (self._last_render_signature != self._current_render_signature()
                         or not self.ui.plotScrollArea.cache_info()["ready"])):
                self._sample_index_timer.start(25)
                return
        worker = SampleIndexWorker(self._result_generation, self._current_result, fields)
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.finished.connect(self._on_sample_index_ready)
        worker.failed.connect(self._on_sample_index_failed)
        worker.stopped.connect(worker.deleteLater)
        worker.stopped.connect(thread.quit, Qt.ConnectionType.DirectConnection)
        thread.finished.connect(lambda: self._finish_sample_thread(thread, worker))
        self._sample_threads.append(thread)
        self._sample_workers.append(worker)
        thread.start()

    def _finish_sample_thread(self, thread: QThread, worker: SampleIndexWorker) -> None:
        if thread not in self._sample_threads:
            return
        # finished is emitted before Qt drains the worker's deferred deletion.
        # Deleting the QThread wrapper then can wait while holding Python's GIL,
        # which that worker cleanup still needs. Join non-blockingly first.
        if not thread.wait(0):
            QTimer.singleShot(1, lambda: self._finish_sample_thread(thread, worker))
            return
        self._sample_threads.remove(thread)
        self._sample_workers.remove(worker)
        thread.deleteLater()
        self._delete_after_workers_finish()

    @Slot(int, object)
    def _on_sample_index_ready(self, generation: int, index: SamplePointIndex) -> None:
        if self._close_requested or generation != self._result_generation:
            return
        self._sample_index = index
        self._sample_conditions = {key: value for key, value in self._sample_conditions.items() if key in index.fields}
        self._sample_active_conditions = {key: value for key, value in self._sample_active_conditions.items() if key in index.fields}
        labels = {item.name: item.display_name or _readable_field_name(item.name) for item in self._template.row_dimensions}
        combo = self.ui.sampleFieldComboBox
        previous = combo.currentData()
        combo.blockSignals(True)
        combo.clear()
        for field in index.fields:
            combo.addItem(labels.get(field, _readable_field_name(field)), field)
        combo.setCurrentIndex(max(0, combo.findData(previous)))
        combo.blockSignals(False)
        self._populate_sample_conditions()
        self._update_sample_values()
        self.ui.sampleLocatorGroupBox.setEnabled(True)
        if self._sample_active_conditions:
            self._apply_sample_conditions(self._sample_active_conditions, scroll=False)
        else:
            self.ui.sampleLocatorStatusLabel.setText("Enter a value, then Locate. Add conditions to narrow the sample.")
        self._apply_pending_summary_navigation()

    @Slot(int, str)
    def _on_sample_index_failed(self, generation: int, message: str) -> None:
        if not self._close_requested and generation == self._result_generation:
            self.ui.sampleLocatorStatusLabel.setText(f"Sample lookup unavailable: {message}")

    def _update_sample_values(self, *args: object) -> None:
        field = self.ui.sampleFieldComboBox.currentData()
        values = self._sample_index.values_for(field) if self._sample_index is not None and field else ()
        combo = self.ui.sampleValueComboBox
        combo.blockSignals(True)
        combo.clear()
        combo.addItems(values)
        combo.setCurrentIndex(-1)
        combo.setEditText(self._sample_conditions.get(field, ""))
        combo.blockSignals(False)
        self._sample_value_model.setStringList(values)

    def _populate_sample_conditions(self) -> None:
        table = self.ui.sampleConditionsTableWidget
        table.setRowCount(len(self._sample_conditions))
        for row, (field, value) in enumerate(self._sample_conditions.items()):
            index = self.ui.sampleFieldComboBox.findData(field)
            item = QTableWidgetItem(self.ui.sampleFieldComboBox.itemText(index) if index >= 0 else field)
            item.setData(Qt.ItemDataRole.UserRole, field)
            table.setItem(row, 0, item)
            table.setItem(row, 1, QTableWidgetItem(value))
        table.resizeColumnToContents(0)

    def _set_sample_condition(self) -> None:
        field = self.ui.sampleFieldComboBox.currentData()
        value = self.ui.sampleValueComboBox.currentText().strip()
        if field and value:
            self._sample_conditions[field] = value
            self._populate_sample_conditions()
            self.ui.sampleLocatorStatusLabel.setText("Conditions changed; press Locate to apply.")

    def _remove_sample_condition(self) -> None:
        row = self.ui.sampleConditionsTableWidget.currentRow()
        if row < 0:
            return
        field = self.ui.sampleConditionsTableWidget.item(row, 0).data(Qt.ItemDataRole.UserRole)
        self._sample_conditions.pop(field, None)
        self._populate_sample_conditions()
        if self.ui.sampleFieldComboBox.currentData() == field:
            self.ui.sampleValueComboBox.setCurrentIndex(-1)
            self.ui.sampleValueComboBox.setEditText("")
        self.ui.sampleLocatorStatusLabel.setText("Conditions changed; press Locate to apply.")

    def _edit_sample_condition(self, row: int, column: int) -> None:
        field = self.ui.sampleConditionsTableWidget.item(row, 0).data(Qt.ItemDataRole.UserRole)
        self.ui.sampleFieldComboBox.setCurrentIndex(self.ui.sampleFieldComboBox.findData(field))
        self._update_sample_values()

    def _invalidate_sample_search(self) -> None:
        self._search_request_id += 1
        self._active_search_signature = None
        self._search_display_signature = None
        self._rendered_generation += 1
        for worker in self._search_workers:
            worker.cancel()

    def _locate_sample(self) -> None:
        if self._sample_index is None or self._close_requested:
            return
        self._set_sample_condition()
        if not self._sample_conditions:
            self._clear_sample_locator()
            return
        self._apply_sample_conditions(self._sample_conditions, scroll=True)

    def _apply_sample_conditions(self, conditions: dict[str, str], *, scroll: bool) -> None:
        self._sample_selection = self._sample_index.query(conditions)
        self._sample_active_conditions = dict(conditions)
        self._invalidate_sample_search()
        if self._last_render_signature != self._current_render_signature():
            # A small rebuilt index can finish before the render debounce. Its
            # original lane indices must only be applied to that new result.
            self._render_timer.stop()
            self._render_selected_metrics()
        else:
            self._rebuild_rendered_plot_widgets(reset_to_first=True, apply_scroll=False)
        if scroll:
            for group_index, item in enumerate(self._rendered_plots):
                if self.ui.plotScrollArea.displayed_lane_indices(group_index):
                    self.ui.plotScrollArea.scroll_to(group_index)
                    break

    def _clear_sample_locator(self) -> None:
        self._sample_conditions.clear()
        self._sample_active_conditions.clear()
        self._sample_selection = None
        self._populate_sample_conditions()
        self.ui.sampleValueComboBox.setCurrentIndex(-1)
        self.ui.sampleValueComboBox.setEditText("")
        self.ui.plotScrollArea.set_sample_highlights(None)
        self._invalidate_sample_search()
        self._rebuild_rendered_plot_widgets(reset_to_first=False, apply_scroll=False)
        self.ui.sampleLocatorStatusLabel.setText("Sample locator cleared.")

    def _sample_metric_matches(self, metric: str) -> bool:
        return self._sample_selection is None or metric in self._sample_selection.metric_keys

    def _populate_filter_fields(self) -> None:
        if self._template is None:
            return
        fields = metric_filter_fields(self._template)
        self.ui.metricFieldComboBox.clear()
        self.ui.metricFieldComboBox.setEditable(False)
        self.ui.metricFieldComboBox.addItems(fields)
        self._update_metric_filter_value_options()

    def _populate_lane_options(self) -> None:
        if self._template is None:
            return
        self._suspend_lane_item_changes = True
        self.ui.laneDimensionsListWidget.clear()
        existing_dimensions = set(lane_dimension_options(self._template))
        for dimension in sorted(self._template.row_dimensions, key=lambda item: item.priority):
            if dimension.name not in existing_dimensions:
                continue
            item = QListWidgetItem(dimension.display_name or dimension.name)
            item.setData(Qt.ItemDataRole.UserRole, dimension.name)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsDragEnabled)
            item.setCheckState(
                Qt.CheckState.Checked
                if dimension.name == self._template.report.reliability_node_dimension
                else Qt.CheckState.Unchecked
            )
            self.ui.laneDimensionsListWidget.addItem(item)
        self._suspend_lane_item_changes = False

    def _add_metric_rule(self) -> None:
        self._rules.append(self._metric_rule_from_editor())
        self._populate_rules_table()
        self._refresh_all()

    def _delete_selected_metric_rules(self) -> None:
        selected_rows = sorted(
            {index.row() for index in self.ui.metricRulesTableWidget.selectionModel().selectedRows()},
            reverse=True,
        )
        if not selected_rows:
            current_row = self.ui.metricRulesTableWidget.currentRow()
            if current_row >= 0:
                selected_rows = [current_row]
        for row in selected_rows:
            if 0 <= row < len(self._rules):
                del self._rules[row]
        if selected_rows:
            self._populate_rules_table()
            self._refresh_all()

    def _modify_selected_metric_rule(self) -> None:
        row = self._selected_metric_rule_row()
        if row < 0 or row >= len(self._rules):
            return
        self._rules[row] = self._metric_rule_from_editor()
        self._populate_rules_table()
        self.ui.metricRulesTableWidget.selectRow(row)
        self._refresh_all()

    def _load_metric_rule_into_editor(self, row: int, column: int) -> None:
        del column
        if row < 0 or row >= len(self._rules):
            return
        rule = self._rules[row]
        self.ui.metricConnectorComboBox.setCurrentText(rule.connector)
        self.ui.metricFieldComboBox.setCurrentText(rule.field_name)
        self.ui.metricOperatorComboBox.setCurrentText(rule.operator)
        self._update_metric_filter_value_options()
        self.ui.metricValueComboBox.setCurrentText(rule.value)
        self.ui.metricRulesTableWidget.selectRow(row)

    def _selected_metric_rule_row(self) -> int:
        selected_rows = self.ui.metricRulesTableWidget.selectionModel().selectedRows()
        if selected_rows:
            return selected_rows[0].row()
        return self.ui.metricRulesTableWidget.currentRow()

    def _clear_metric_rules(self) -> None:
        self._rules = []
        self._populate_rules_table()
        self._refresh_all()

    def _metric_rule_from_editor(self) -> MetricFilterRule:
        return MetricFilterRule(
            field_name=self.ui.metricFieldComboBox.currentText().strip(),
            operator=self.ui.metricOperatorComboBox.currentText().strip(),
            value=self.ui.metricValueComboBox.currentText().strip(),
            connector=self.ui.metricConnectorComboBox.currentText().strip(),
        )

    def _populate_rules_table(self) -> None:
        table = self.ui.metricRulesTableWidget
        table.setRowCount(len(self._rules))
        for row_index, rule in enumerate(self._rules):
            for column_index, value in enumerate(
                [rule.connector, rule.field_name, rule.operator, rule.value]
            ):
                table.setItem(row_index, column_index, QTableWidgetItem(value))
        table.resizeColumnsToContents()

    def _update_metric_filter_value_options(self, *args: object) -> None:
        del args
        field_name = self.ui.metricFieldComboBox.currentText().strip()
        operator = self.ui.metricOperatorComboBox.currentText().strip().lower()
        previous_value = self.ui.metricValueComboBox.currentText().strip()
        exact_operator = operator in {"is", "is not", "has outlier"}
        values = self._metric_filter_values(field_name, operator)
        combo = self.ui.metricValueComboBox
        combo.blockSignals(True)
        combo.clear()
        combo.addItems(values)
        combo.setEditable(not exact_operator)
        combo.setEnabled(operator != "has outlier" or bool(values))
        if exact_operator:
            if previous_value in values:
                combo.setCurrentText(previous_value)
            elif values:
                combo.setCurrentIndex(0)
            else:
                combo.setCurrentText("")
        else:
            combo.setCurrentText(previous_value)
        line_edit = combo.lineEdit()
        if line_edit is not None:
            line_edit.setPlaceholderText("Select a value" if exact_operator else "Type or choose a suggested value")
            line_edit.setReadOnly(exact_operator)
            line_edit.setCompleter(None if exact_operator else self._metric_filter_value_completer)
        self._metric_filter_value_model.setStringList(values)
        combo.blockSignals(False)

    def _metric_filter_values(self, field_name: str, operator: str) -> list[str]:
        field_key = _field_key(field_name)
        outlier_fields = {normalized_field_key(name) for name in ("has_outlier", "lane_has_outlier", "metric_has_outlier")}
        if operator == "has outlier" or field_key in outlier_fields:
            return ["true", "false"]
        values: set[str] = set()
        row_dimension_name = self._row_dimension_name_for_filter_field(field_name)
        if row_dimension_name:
            values.update(
                str(item.dimensions.get(row_dimension_name, "") or "")
                for item in self._measurements
            )
            return sorted((value for value in values if value), key=_natural_text_key)
        for descriptor in self._metric_catalog:
            values.update(value for value in descriptor.field_values(field_name) if value)
        return sorted(values, key=_natural_text_key)

    def _row_dimension_name_for_filter_field(self, field_name: str) -> str | None:
        if self._template is None:
            return None
        fields = row_fields(self._template)
        name = fields.resolve(field_name)
        return name if name in fields.names else None

    def _refresh_all(self) -> None:
        if self._template is None:
            return
        self._start_build_worker(selected_metrics=[], update_tree=True)

    def _start_build_worker(self, selected_metrics: list[str], update_tree: bool) -> None:
        if self._close_requested or self._template is None:
            return
        signature = self._current_build_signature(selected_metrics)
        if signature == self._active_build_signature:
            return
        self._build_request_id += 1
        request_id = self._build_request_id
        for worker in self._build_workers:
            worker.cancel()
        if self._pending_build_worker is not None:
            self._pending_build_worker.deleteLater()
            self._pending_build_worker = None
        if signature == self._last_build_signature and self._current_result is not None:
            self._active_build_signature = None
            if update_tree:
                self._populate_metric_tree(self._current_result)
            self._rebuild_rendered_plot_widgets(reset_to_first=False, apply_scroll=False)
            return
        self._active_build_signature = signature
        worker = PlotBuildWorker(
            request_id=request_id,
            template=self._template,
            measurements=self._measurements,
            metric_rules=list(self._rules),
            selected_metrics=list(selected_metrics),
            lane_dimensions=self._lane_dimensions(),
            golden_path=self._context.golden_path,
            outlier_fail_method=self._context.outlier_fail_method,
            zscore_threshold=self._context.zscore_threshold,
            zscore_use_golden_reference=self._context.zscore_use_golden_reference,
            update_tree=update_tree,
            report_filter_config=self._report_filter_config,
            analysis_session=self._analysis_session,
        )
        # A slow analysis phase may not notice cancellation immediately. Keep one
        # running job and only the most recent pending request, never a backlog.
        if self._build_threads:
            self._pending_build_worker = worker
            self._set_status_progress("Updating plot groups...", 0, 1)
            return
        self._launch_build_worker(worker)

    def _launch_build_worker(self, worker: PlotBuildWorker) -> None:
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._on_build_progress)
        worker.finished.connect(self._on_build_finished)
        worker.failed.connect(self._on_build_failed)
        worker.stopped.connect(worker.deleteLater)
        worker.stopped.connect(thread.quit, Qt.ConnectionType.DirectConnection)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(
            lambda thread=thread: self._build_threads.remove(thread)
            if thread in self._build_threads
            else None
        )
        thread.finished.connect(
            lambda worker=worker: self._build_workers.remove(worker)
            if worker in self._build_workers
            else None
        )
        self._build_threads.append(thread)
        self._build_workers.append(worker)
        thread.finished.connect(self._resume_pending_build)
        thread.finished.connect(self._delete_after_workers_finish)
        self._set_status_progress("Building plot groups...", 0, 1)
        thread.start()

    def _resume_pending_build(self) -> None:
        if self._close_requested or self._build_threads or self._pending_build_worker is None:
            return
        worker = self._pending_build_worker
        self._pending_build_worker = None
        self._launch_build_worker(worker)

    @Slot(int, str, int, int)
    def _on_build_progress(self, request_id: int, message: str, value: int, total: int) -> None:
        if request_id != self._build_request_id:
            return
        self._set_status_progress(message, value, total)

    @Slot(int, object, bool)
    def _on_build_finished(self, request_id: int, result: PlotBuildResult, update_tree: bool) -> None:
        if request_id != self._build_request_id:
            return
        result = self._project_analysis_result(result)
        self._current_result = result
        self._result_generation += 1
        self._last_build_signature = self._active_build_signature
        self._active_build_signature = None
        self._metric_catalog = result.metrics
        self._update_metric_search_completions(result.metrics)
        self._update_metric_filter_value_options()
        if update_tree:
            self._populate_metric_tree(result)
        self._queue_render_current_result()
        if not self._summary_navigation_needs_build():
            self._start_sample_index()

    @Slot(int, str)
    def _on_build_failed(self, request_id: int, message: str) -> None:
        if request_id != self._build_request_id:
            return
        self._active_build_signature = None
        self._set_render_busy(False)
        self.ui.summaryLabel.setText(f"Plot build failed: {message}")

    def _current_build_signature(self, selected_metrics: list[str]) -> tuple[object, ...]:
        return (
            tuple((rule.connector, rule.field_name, rule.operator, rule.value) for rule in self._rules),
            tuple(selected_metrics),
            tuple(self._lane_dimensions()),
            self._golden_content_signature(),
            self._context.outlier_fail_method,
            self._context.zscore_threshold,
            self._context.zscore_use_golden_reference,
            self._report_filter_signature(),
        )

    def _golden_content_signature(self) -> tuple[str, bytes | None]:
        # Rehash after metadata changes. On Windows the revision also checks
        # ChangeTime, since stat ctime can describe creation rather than changes.
        path = self._context.golden_path
        if not path:
            return path, None
        try:
            source = Path(path)
            key = golden_file_revision(source)
            if key is not None and key == getattr(self, "_golden_signature_stat_key", None):
                return self._golden_signature_value
            signature = (path, sha256(source.read_bytes()).digest())
        except OSError:
            # Let the build worker report a missing/unreadable Golden normally.
            self._golden_signature_stat_key = None
            return path, None
        self._golden_signature_stat_key = key
        self._golden_signature_value = signature
        return signature

    def _on_metric_search_text_changed(self, *args: object) -> None:
        self._enter_advances_search = False
        if self.ui.metricRealtimeCheckBox.isChecked():
            self._metric_search_timer.start(500)

    def _activate_search_from_enter(self) -> None:
        self._metric_search_timer.stop()
        if (
            self._enter_advances_search
            and self._current_search_signature() == self._search_display_signature
            and self._search_matches
        ):
            self._select_next_search_match()
            return
        self._refresh_search_results()
        self._enter_advances_search = True

    def _activate_search_from_button(self) -> None:
        self._refresh_search_results()
        self._enter_advances_search = True

    def _refresh_search_results_from_timer(self) -> None:
        self._refresh_search_results()
        self._enter_advances_search = False

    def _refresh_search_results(self) -> None:
        self._metric_search_timer.stop()
        signature = self._current_search_signature()
        if signature == self._search_display_signature:
            self._sync_search_state(reset_to_first=False, apply_scroll=False)
            self._apply_search_selection(apply_scroll=True)
            return
        self._start_search_worker(reset_to_first=True, apply_scroll=True)

    def _on_metric_search_completion_activated(self, text: str) -> None:
        self._metric_search_timer.stop()
        self.ui.metricSearchEdit.setText(text)
        self._refresh_search_results()
        self._enter_advances_search = True

    def _on_metric_search_view_changed(self, *args: object) -> None:
        self._enter_advances_search = False
        self._search_display_signature = None
        if self.ui.metricSearchViewComboBox.currentText() != "Compact Results":
            self._restore_compact_search_selection()
        self._rebuild_rendered_plot_widgets(reset_to_first=False, apply_scroll=False)

    def _on_metric_realtime_changed(self, *args: object) -> None:
        if self.ui.metricRealtimeCheckBox.isChecked():
            self._refresh_search_results()
        else:
            self._metric_search_timer.stop()

    def _select_next_search_match(self) -> None:
        self._advance_search_match(1)

    def _select_previous_search_match(self) -> None:
        self._advance_search_match(-1)

    def _advance_search_match(self, step: int) -> None:
        if not self._search_matches:
            self._start_search_worker(reset_to_first=True, apply_scroll=False)
            return
        self._search_match_cursor = (self._search_match_cursor + step) % len(self._search_matches)
        self._apply_search_selection(apply_scroll=True)

    def _update_metric_search_completions(self, metrics: tuple[MetricDescriptor, ...]) -> None:
        suggestions = set(self._metric_search_suggestions)
        for descriptor in metrics:
            suggestions.add(descriptor.display_label)
            suggestions.add(descriptor.logical_metric)
            suggestions.add(descriptor.group_display_name)
            suggestions.update(descriptor.raw_columns)
            for values in descriptor.header_values.values():
                suggestions.update(values)
        for item in self._rendered_plots:
            suggestions.add(item.title)
            suggestions.update(self._lane_header_labels())
            suggestions.update(series.label for series in item.series)
        self._metric_search_suggestions = suggestions
        self._metric_search_model.setStringList(sorted(item for item in suggestions if item))

    def _populate_metric_tree(self, result: PlotBuildResult) -> None:
        self._suspend_metric_item_changes = True
        tree = self.ui.metricTreeWidget
        tree.setUpdatesEnabled(False)
        tree.clear()
        tree.setHeaderLabels(["Metric / Lane", "Points"])
        try:
            for descriptor in result.metrics:
                series_items = result.series_by_metric.get(descriptor.logical_metric, ())
                point_count = sum(len(series.points) for series in series_items)
                marker = " *" if descriptor.has_outlier else ""
                parent = QTreeWidgetItem(
                    [
                        f"{descriptor.display_label}{marker}",
                        f"{point_count}",
                    ]
                )
                parent.setData(0, Qt.ItemDataRole.UserRole, descriptor.logical_metric)
                parent.setData(0, Qt.ItemDataRole.UserRole + 1, "metric")
                parent.setFlags(parent.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                parent.setCheckState(0, Qt.CheckState.Checked)
                tree.addTopLevelItem(parent)
                for series in series_items:
                    lane_outlier_count = sum(1 for point in series.points if point.outlier)
                    lane_marker = " *" if lane_outlier_count else ""
                    child = QTreeWidgetItem(
                        [
                            f"{series.label}{lane_marker}",
                            f"{len(series.points)}",
                        ]
                    )
                    child.setData(0, Qt.ItemDataRole.UserRole, descriptor.logical_metric)
                    child.setData(0, Qt.ItemDataRole.UserRole + 1, "lane")
                    child.setData(0, Qt.ItemDataRole.UserRole + 2, series.aggregate_id)
                    child.setFlags(child.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                    child.setCheckState(0, Qt.CheckState.Checked)
                    parent.addChild(child)
                parent.setExpanded(True)
            tree.resizeColumnToContents(0)
            tree.resizeColumnToContents(1)
        finally:
            tree.setUpdatesEnabled(True)
        self._suspend_metric_item_changes = False

    def _select_all_metric_tree_items(self) -> None:
        self._set_all_metric_tree_items_checked(Qt.CheckState.Checked)

    def _deselect_all_metric_tree_items(self) -> None:
        self._set_all_metric_tree_items_checked(Qt.CheckState.Unchecked)

    def _set_all_metric_tree_items_checked(self, state: Qt.CheckState) -> None:
        tree = self.ui.metricTreeWidget
        self._suspend_metric_item_changes = True
        tree.setUpdatesEnabled(False)
        try:
            for index in range(tree.topLevelItemCount()):
                parent = tree.topLevelItem(index)
                parent.setCheckState(0, state)
                for child_index in range(parent.childCount()):
                    parent.child(child_index).setCheckState(0, state)
        finally:
            tree.setUpdatesEnabled(True)
            self._suspend_metric_item_changes = False
        self._rebuild_rendered_plot_widgets(reset_to_first=False, apply_scroll=False)

    @staticmethod
    def _descriptor_matches_search(descriptor: MetricDescriptor, query: str) -> bool:
        values = [
            descriptor.display_label,
            descriptor.logical_metric,
            descriptor.group_id,
            descriptor.group_display_name,
            *(descriptor.raw_columns),
            *(value for values in descriptor.header_values.values() for value in values),
        ]
        return _text_matches_query(values, query)

    def _on_metric_tree_item_changed(self, item: QTreeWidgetItem, column: int) -> None:
        if self._suspend_metric_item_changes or column != 0:
            return
        self._suspend_metric_item_changes = True
        try:
            item_type = item.data(0, Qt.ItemDataRole.UserRole + 1)
            if item_type == "metric":
                state = item.checkState(0)
                for index in range(item.childCount()):
                    item.child(index).setCheckState(0, state)
            else:
                parent = item.parent()
                if parent is not None:
                    child_states = [
                        parent.child(index).checkState(0)
                        for index in range(parent.childCount())
                    ]
                    if all(state == Qt.CheckState.Checked for state in child_states):
                        parent.setCheckState(0, Qt.CheckState.Checked)
                    elif all(state == Qt.CheckState.Unchecked for state in child_states):
                        parent.setCheckState(0, Qt.CheckState.Unchecked)
                    else:
                        parent.setCheckState(0, Qt.CheckState.PartiallyChecked)
        finally:
            self._suspend_metric_item_changes = False
        self._rebuild_rendered_plot_widgets(reset_to_first=False, apply_scroll=False)

    def _on_metric_tree_selection_changed(self) -> None:
        if self._suspend_metric_tree_selection:
            return
        item = self.ui.metricTreeWidget.currentItem()
        if item is None:
            return
        self._locate_metric_tree_item(item, apply_scroll=True)

    def _on_lane_item_changed(self, *args: object) -> None:
        if not self._suspend_lane_item_changes:
            self._refresh_all()

    def _on_lane_order_changed(self, *args: object) -> None:
        if not self._suspend_lane_item_changes:
            self._refresh_all()

    def _queue_render_selected_metrics(self, *args: object) -> None:
        self._queue_render_current_result()

    def _queue_render_current_result(self, *args: object) -> None:
        if self._template is None:
            return
        self._render_timer.start(60)

    def _render_selected_metrics(self, *args: object) -> None:
        if self._close_requested or self._template is None or self._current_result is None:
            return
        signature = self._current_render_signature()
        if signature == self._last_render_signature:
            return
        self._search_request_id += 1
        self._active_search_signature = None
        for worker in self._search_workers:
            worker.cancel()
        result = self._current_result
        self._rendered_plots = [
            RenderedMetricPlot(descriptor, self._metric_title(descriptor, series), series)
            for descriptor in result.selected_metrics
            if (series := tuple(result.series_by_metric.get(descriptor.logical_metric, ())))
        ]
        self._last_render_signature = signature
        self._rendered_generation += 1
        self._search_display_signature = None
        self._enter_advances_search = False
        self._update_metric_search_completions(tuple(item.descriptor for item in self._rendered_plots))
        self.ui.summaryLabel.setText(self._summary_text(result))
        self._rebuild_rendered_plot_widgets(reset_to_first=True, apply_scroll=False)


    def _rebuild_rendered_plot_widgets(self, reset_to_first: bool, apply_scroll: bool, sync_search: bool = True) -> None:
        if self._close_requested:
            return
        if sync_search:
            self._sync_search_state(reset_to_first=reset_to_first, apply_scroll=False)
        # Read the tree once, rather than rescanning every checkbox for every plot.
        selection = self._selected_lane_keys_by_metric()
        compact = bool(self._metric_search_query()) and self.ui.metricSearchViewComboBox.currentText() == "Compact Results"
        compact_lanes: dict[int, set[int]] = {}
        if compact:
            for match in self._search_matches:
                if match.lane_index is not None:
                    compact_lanes.setdefault(match.group_index, set()).add(match.lane_index)
        groups: list[PlotViewGroup] = []
        for group_index, item in enumerate(self._rendered_plots):
            if not self._sample_metric_matches(item.descriptor.logical_metric):
                continue
            indices = self._checked_lane_indices(item, selection)
            if compact:
                if group_index not in self._search_result_groups:
                    continue
                matches = compact_lanes.get(group_index)
                if matches:
                    indices = [index for index in indices if index in matches]
            if not indices:
                continue
            if self._sample_selection is not None:
                sample_lanes = self._sample_selection.indices_by_metric[item.descriptor.logical_metric]
                if not any(len(sample_lanes[index]) for index in indices):
                    continue
            title = item.title if len(indices) == len(item.series) else self._metric_title(
                item.descriptor, tuple(item.series[index] for index in indices)
            )
            groups.append(PlotViewGroup(
                group_index=group_index,
                descriptor=item.descriptor,
                title=title,
                series=item.series,
                lane_indices=tuple(indices),
            ))
        self.ui.plotScrollArea.set_groups(
            groups,
            lane_headers=self._lane_header_labels(),
            plot_type=self.ui.plotTypeComboBox.currentText(),
            lane_height=self._lane_height,
            data_generation=self._result_generation,
        )
        self.ui.plotScrollArea.set_sample_highlights(
            self._sample_selection.indices_by_metric if self._sample_selection is not None else None
        )
        if self._current_result is not None:
            self.ui.summaryLabel.setText(self._summary_text(self._current_result, shown_plots=len(groups)))
        if self._sample_selection is not None:
            shown_points = sum(
                len(self._sample_selection.indices_by_metric[group.descriptor.logical_metric][lane])
                for group in groups for lane in group.lane_indices
            )
            self.ui.sampleLocatorStatusLabel.setText(
                f"Matched {self._sample_selection.sample_count} sample(s) in plot data; "
                f"showing {len(groups)} plot(s), {shown_points} marked point(s)."
            )
        self._apply_search_selection(apply_scroll=apply_scroll)
        self._search_display_signature = self._current_search_signature()

    def _current_search_signature(self) -> tuple[str, str, int]:
        return (
            self._metric_search_query(),
            self.ui.metricSearchViewComboBox.currentText(),
            self._rendered_generation,
        )


    @Slot(str)
    def _on_render_failed(self, message: str) -> None:
        if self._close_requested:
            return
        self._set_render_busy(False)
        self._render_status_label.setText(f"Render failed: {message}")

    @Slot(int, int, str)
    def _on_view_render_progress(self, value: int, total: int, label: str) -> None:
        if not self._close_requested and self._active_build_signature is None and self._active_search_signature is None:
            self._set_status_progress(label, value, total)

    @Slot()
    def _on_view_render_ready(self) -> None:
        if not self._close_requested and self._active_build_signature is None and self._active_search_signature is None:
            self._set_render_busy(False)

    def _set_render_busy(self, busy: bool, total: int = 0) -> None:
        self.ui.refreshButton.setEnabled(not busy)
        if busy:
            self._render_status_label.setText("Rendering...")
            self._render_progress.setEnabled(True)
            self._render_progress.setRange(0, max(1, total))
            self._render_progress.setValue(0)
        else:
            self._render_status_label.setText("Ready")
            self._render_progress.setRange(0, 1)
            self._render_progress.setValue(0)
            self._render_progress.setEnabled(False)

    def _set_status_busy(self, message: str, indeterminate: bool = False) -> None:
        self._render_status_label.setText(message)
        self._render_progress.setEnabled(True)
        if indeterminate:
            self._render_progress.setRange(0, 0)
        else:
            self._render_progress.setRange(0, 1)
            self._render_progress.setValue(0)

    def _set_status_progress(self, message: str, value: int, total: int) -> None:
        resolved_total = max(1, total)
        self._render_status_label.setText(message)
        self._render_progress.setEnabled(True)
        self._render_progress.setRange(0, resolved_total)
        self._render_progress.setValue(max(0, min(value, resolved_total)))

    def _set_controls_enabled(self, enabled: bool) -> None:
        self.ui.controlPanelScrollArea.setEnabled(enabled)
        self.ui.plotScrollArea.setEnabled(enabled)

    def _start_search_worker(self, reset_to_first: bool, apply_scroll: bool) -> None:
        if self._close_requested:
            return
        query = self._metric_search_query()
        signature = self._current_search_signature()
        if query and signature == self._active_search_signature:
            return
        self._search_request_id += 1
        request_id = self._search_request_id
        for worker in self._search_workers:
            worker.cancel()
        if not query:
            self._active_search_signature = None
            self._rebuild_rendered_plot_widgets(reset_to_first=reset_to_first, apply_scroll=apply_scroll)
            return
        self._active_search_signature = signature
        compact_mode = self.ui.metricSearchViewComboBox.currentText() == "Compact Results"
        if compact_mode:
            self._capture_compact_search_selection()
        groups = self._search_group_data(compact_mode=compact_mode)
        worker = SearchWorker(
            request_id=request_id,
            groups=groups,
            query=query,
            reset_to_first=reset_to_first,
            apply_scroll=apply_scroll,
        )
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._on_search_progress)
        worker.finished.connect(self._on_search_finished)
        worker.failed.connect(self._on_search_failed)
        worker.stopped.connect(worker.deleteLater)
        worker.stopped.connect(thread.quit, Qt.ConnectionType.DirectConnection)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(
            lambda thread=thread: self._search_threads.remove(thread)
            if thread in self._search_threads
            else None
        )
        thread.finished.connect(
            lambda worker=worker: self._search_workers.remove(worker)
            if worker in self._search_workers
            else None
        )
        self._search_threads.append(thread)
        self._search_workers.append(worker)
        thread.finished.connect(self._delete_after_workers_finish)
        self._set_status_progress("Searching plot results...", 0, max(1, len(groups)))
        thread.start()

    @Slot(int, int, int, str)
    def _on_search_progress(self, request_id: int, index: int, total: int, label: str) -> None:
        if request_id != self._search_request_id:
            return
        self._set_status_progress(f"{label} {index}/{total}", index, total)

    def _search_group_data(self, compact_mode: bool) -> list[SearchGroupData]:
        lane_headers = self._lane_header_labels()
        groups: list[SearchGroupData] = []
        for group_index, item in enumerate(self._rendered_plots):
            if not self._sample_metric_matches(item.descriptor.logical_metric):
                continue
            visible_indices = tuple(range(len(item.series)))
            group_texts = (
                item.title,
                item.descriptor.display_label,
                item.descriptor.logical_metric,
                item.descriptor.group_id,
                item.descriptor.group_display_name,
                *item.descriptor.raw_columns,
                *(value for values in item.descriptor.header_values.values() for value in values),
            )
            groups.append(
                SearchGroupData(
                    group_index=group_index,
                    group_texts=tuple(str(value) for value in group_texts if value),
                    lane_headers=lane_headers,
                    lane_labels=tuple(series.label for series in item.series),
                    visible_indices=visible_indices,
                )
            )
        return groups

    @Slot(int, object, object, bool, bool)
    def _on_search_finished(
        self,
        request_id: int,
        matches: list[SearchMatch],
        result_groups: set[int],
        reset_to_first: bool,
        apply_scroll: bool,
    ) -> None:
        if request_id != self._search_request_id:
            return
        if self._current_search_signature() != self._active_search_signature:
            self._active_search_signature = None
            if self._active_build_signature is None:
                self._set_render_busy(False)
            return
        self._active_search_signature = None
        self._search_matches = list(matches)
        self._search_result_groups = set(result_groups)
        compact_mode = self.ui.metricSearchViewComboBox.currentText() == "Compact Results"
        if compact_mode:
            self._sync_metric_tree_to_search_matches()
        if not self._search_matches:
            self._search_match_cursor = -1
        elif reset_to_first or self._search_match_cursor < 0 or self._search_match_cursor >= len(self._search_matches):
            self._search_match_cursor = 0
        if compact_mode:
            self._rebuild_rendered_plot_widgets(reset_to_first=False, apply_scroll=apply_scroll, sync_search=False)
        else:
            self._update_search_status()
            self._apply_search_selection(apply_scroll=apply_scroll)
            self._search_display_signature = self._current_search_signature()
        if compact_mode:
            self._render_status_label.setText(
                f"Search matched {len(self._search_matches)} lane(s); compact view updated"
            )
        elif self._search_matches:
            self._render_status_label.setText(f"Search matched {len(self._search_matches)} item(s)")
        else:
            self._render_status_label.setText("Search matched 0 item(s)")
        self._render_progress.setRange(0, 1)
        self._render_progress.setValue(0)
        self._render_progress.setEnabled(False)

    @Slot(int, str)
    def _on_search_failed(self, request_id: int, message: str) -> None:
        if request_id != self._search_request_id:
            return
        self._active_search_signature = None
        self._set_render_busy(False)
        self._render_status_label.setText(f"Search failed: {message}")

    def _sync_search_state(self, reset_to_first: bool, apply_scroll: bool) -> None:
        query = self._metric_search_query()
        if not query:
            self._restore_compact_search_selection()
            self._search_matches = []
            self._search_result_groups = set()
            self._search_match_cursor = -1
            self._update_search_status()
            self._clear_search_highlights()
            if self.ui.metricSearchViewComboBox.currentText() == "Compact Results":
                self._render_status_label.setText("Search: press Search to compact results")
            return
        matches: list[SearchMatch] = []
        result_groups: set[int] = set()
        lane_headers = self._lane_header_labels()
        compact_mode = self.ui.metricSearchViewComboBox.currentText() == "Compact Results"
        if compact_mode:
            self._capture_compact_search_selection()
        for group_index, item in enumerate(self._rendered_plots):
            if not self._sample_metric_matches(item.descriptor.logical_metric):
                continue
            visible_indices = set(range(len(item.series)))
            if not visible_indices:
                continue
            group_texts = [
                item.title,
                item.descriptor.display_label,
                item.descriptor.logical_metric,
                item.descriptor.group_id,
                item.descriptor.group_display_name,
                *(item.descriptor.raw_columns),
                *(value for values in item.descriptor.header_values.values() for value in values),
            ]
            group_match = _text_matches_query(group_texts, query)
            lane_matches = [
                lane_index
                for lane_index, label in enumerate(series.label for series in item.series)
                if lane_index in visible_indices
                if _text_matches_query([*group_texts, *lane_headers, label], query)
            ]
            if group_match or lane_matches:
                result_groups.add(group_index)
            if lane_matches:
                matches.extend(SearchMatch(group_index, lane_index) for lane_index in lane_matches)
            elif group_match:
                matches.append(SearchMatch(group_index, None))
        self._search_matches = matches
        self._search_result_groups = result_groups
        if compact_mode:
            self._sync_metric_tree_to_search_matches()
        if not matches:
            self._search_match_cursor = -1
        elif reset_to_first or self._search_match_cursor < 0 or self._search_match_cursor >= len(matches):
            self._search_match_cursor = 0
        self._update_search_status()
        self._apply_search_selection(apply_scroll=apply_scroll)
        if self.ui.metricSearchViewComboBox.currentText() == "Compact Results":
            self._render_status_label.setText(
                f"Search matched {len(self._search_matches)} lane(s); press Search to compact results"
            )


    def _displayed_lane_indices_for_group(self, group_index: int, item: RenderedMetricPlot) -> list[int]:
        if not self._sample_metric_matches(item.descriptor.logical_metric):
            return []
        visible_indices = self._checked_lane_indices(item)
        if not visible_indices:
            return []
        if self._metric_search_query() and self.ui.metricSearchViewComboBox.currentText() == "Compact Results":
            if group_index not in self._search_result_groups:
                return []
            lane_matches = {
                match.lane_index
                for match in self._search_matches
                if match.group_index == group_index and match.lane_index is not None
            }
            if lane_matches:
                visible_indices = [index for index in visible_indices if index in lane_matches]
        if self._sample_selection is not None:
            sample_lanes = self._sample_selection.indices_by_metric[item.descriptor.logical_metric]
            if not any(len(sample_lanes[index]) for index in visible_indices):
                return []
        return visible_indices

    def _checked_lane_indices(
        self,
        item: RenderedMetricPlot,
        selection: dict[str, set[str]] | None = None,
    ) -> list[int]:
        selected_lanes = (selection if selection is not None else self._selected_lane_keys_by_metric()).get(item.descriptor.logical_metric)
        if not selected_lanes:
            return []
        return [
            index
            for index, series in enumerate(item.series)
            if series.aggregate_id in selected_lanes
        ]

    def _capture_compact_search_selection(self) -> None:
        if self._compact_search_base_selection is None:
            self._compact_search_base_selection = self._selected_lane_keys_by_metric()

    def _restore_compact_search_selection(self) -> None:
        if self._compact_search_base_selection is None:
            return
        selection = self._compact_search_base_selection
        self._compact_search_base_selection = None
        self._set_metric_tree_selection(selection)

    def _sync_metric_tree_to_search_matches(self) -> None:
        selection: dict[str, set[str]] = {}
        for match in self._search_matches:
            if match.group_index < 0 or match.group_index >= len(self._rendered_plots):
                continue
            item = self._rendered_plots[match.group_index]
            if match.lane_index is None:
                selection[item.descriptor.logical_metric] = {
                    series.aggregate_id for series in item.series
                }
                continue
            if 0 <= match.lane_index < len(item.series):
                selection.setdefault(item.descriptor.logical_metric, set()).add(
                    item.series[match.lane_index].aggregate_id
                )
        self._set_metric_tree_selection(selection)

    def _set_metric_tree_selection(self, selection: dict[str, set[str]]) -> None:
        self._suspend_metric_item_changes = True
        tree = self.ui.metricTreeWidget
        tree.setUpdatesEnabled(False)
        try:
            for index in range(tree.topLevelItemCount()):
                parent = tree.topLevelItem(index)
                metric_key = str(parent.data(0, Qt.ItemDataRole.UserRole))
                lane_keys = selection.get(metric_key, set())
                checked_count = 0
                for child_index in range(parent.childCount()):
                    child = parent.child(child_index)
                    lane_key = str(child.data(0, Qt.ItemDataRole.UserRole + 2))
                    state = Qt.CheckState.Checked if lane_key in lane_keys else Qt.CheckState.Unchecked
                    child.setCheckState(0, state)
                    if state == Qt.CheckState.Checked:
                        checked_count += 1
                if parent.childCount() == 0:
                    parent.setCheckState(
                        0,
                        Qt.CheckState.Checked if metric_key in selection else Qt.CheckState.Unchecked,
                    )
                elif checked_count == parent.childCount():
                    parent.setCheckState(0, Qt.CheckState.Checked)
                elif checked_count == 0:
                    parent.setCheckState(0, Qt.CheckState.Unchecked)
                else:
                    parent.setCheckState(0, Qt.CheckState.PartiallyChecked)
        finally:
            tree.setUpdatesEnabled(True)
            self._suspend_metric_item_changes = False


    def _apply_search_selection(self, apply_scroll: bool) -> None:
        self._clear_search_highlights()
        self._update_search_status()
        if not self._search_matches or self._search_match_cursor < 0:
            return
        match = self._search_matches[self._search_match_cursor]
        self._select_metric_tree_match(match)
        self.ui.plotScrollArea.set_search_highlight(match.group_index, match.lane_index)
        if apply_scroll:
            self.ui.plotScrollArea.scroll_to(match.group_index, match.lane_index)


    def _select_metric_tree_match(self, match: SearchMatch) -> None:
        tree_item = self._tree_item_for_match(match)
        if tree_item is None:
            return
        self._suspend_metric_tree_selection = True
        try:
            tree = self.ui.metricTreeWidget
            tree.setCurrentItem(tree_item)
            tree.scrollToItem(tree_item)
        finally:
            self._suspend_metric_tree_selection = False

    def _tree_item_for_match(self, match: SearchMatch) -> QTreeWidgetItem | None:
        if match.group_index < 0 or match.group_index >= len(self._rendered_plots):
            return None
        rendered = self._rendered_plots[match.group_index]
        lane_key = None
        if match.lane_index is not None and 0 <= match.lane_index < len(rendered.series):
            lane_key = rendered.series[match.lane_index].aggregate_id
        return self._tree_item_for_metric_lane(rendered.descriptor.logical_metric, lane_key)

    def _tree_item_for_metric_lane(self, metric_key: str, lane_key: str | None) -> QTreeWidgetItem | None:
        tree = self.ui.metricTreeWidget
        for index in range(tree.topLevelItemCount()):
            parent = tree.topLevelItem(index)
            if str(parent.data(0, Qt.ItemDataRole.UserRole)) != metric_key:
                continue
            if lane_key is None:
                return parent
            for child_index in range(parent.childCount()):
                child = parent.child(child_index)
                if str(child.data(0, Qt.ItemDataRole.UserRole + 2)) == lane_key:
                    return child
            return parent
        return None

    def _locate_metric_tree_item(self, item: QTreeWidgetItem, apply_scroll: bool) -> None:
        match = self._search_match_for_tree_item(item)
        if match is None:
            return
        self.ui.plotScrollArea.set_search_highlight(match.group_index, match.lane_index)
        if apply_scroll:
            self.ui.plotScrollArea.scroll_to(match.group_index, match.lane_index)

    def _search_match_for_tree_item(self, item: QTreeWidgetItem) -> SearchMatch | None:
        item_type = item.data(0, Qt.ItemDataRole.UserRole + 1)
        metric_key = str(item.data(0, Qt.ItemDataRole.UserRole))
        lane_key = None
        if item_type == "lane":
            lane_key = str(item.data(0, Qt.ItemDataRole.UserRole + 2))
        for group_index, rendered in enumerate(self._rendered_plots):
            if rendered.descriptor.logical_metric != metric_key:
                continue
            if lane_key is None:
                return SearchMatch(group_index, None)
            for lane_index, series in enumerate(rendered.series):
                if series.aggregate_id == lane_key:
                    if lane_index in self._displayed_lane_indices_for_group(group_index, rendered):
                        return SearchMatch(group_index, lane_index)
                    return None
        return None


    def _clear_search_highlights(self) -> None:
        self.ui.plotScrollArea.set_search_highlight(None)

    def _update_search_status(self) -> None:
        total = len(self._search_matches)
        current = self._search_match_cursor + 1 if total and self._search_match_cursor >= 0 else 0
        self.ui.metricSearchStatusLabel.setText(f"{current} / {total}")
        enabled = total > 1
        self.ui.metricSearchPrevButton.setEnabled(enabled)
        self.ui.metricSearchNextButton.setEnabled(enabled)


    def eventFilter(self, watched: QObject, event: QEvent) -> bool:
        if watched == self.ui.metricSearchEdit and event.type() == QEvent.Type.KeyPress:
            key = event.key()
            if key == Qt.Key.Key_Up:
                self._select_previous_search_match()
                return True
            if key == Qt.Key.Key_Down:
                self._select_next_search_match()
                return True
        return super().eventFilter(watched, event)


    def closeEvent(self, event) -> None:  # type: ignore[override]
        self._close_requested = True
        self._stop_render_threads(wait=False)
        self._release_large_resources()
        super().closeEvent(event)
        self._delete_after_workers_finish()

    def _on_application_quit(self) -> None:
        # Unlike closing this window, process shutdown leaves no event loop to
        # finish cleanup later. Drain canceled work before Qt destroys children.
        self._close_requested = True
        self._stop_render_threads(wait=True)
        self._release_large_resources()
        self._analysis_session.clear()

    def _stop_render_threads(self, wait: bool = False) -> None:
        self._sample_index_timer.stop()
        self._build_request_id += 1
        self._search_request_id += 1
        self._active_build_signature = None
        self._active_search_signature = None
        if self._pending_build_worker is not None:
            self._pending_build_worker.deleteLater()
            self._pending_build_worker = None
        self._set_render_busy(False)
        for worker in [self._load_worker, *self._build_workers, *self._search_workers, *self._sample_workers]:
            if worker is not None:
                worker.cancel()
        self.ui.plotScrollArea.shutdown(wait=wait)
        for thread in [
            *(thread for thread in [self._load_thread] if thread is not None),
            *self._build_threads,
            *self._search_threads,
            *self._sample_threads,
        ]:
            if thread.isRunning():
                thread.quit()
                if wait:
                    thread.wait()

    def _worker_threads_running(self) -> bool:
        threads = [
            *(thread for thread in [self._load_thread] if thread is not None),
            *self._build_threads,
            *self._search_threads,
            *self._sample_threads,
        ]
        return (bool(self._sample_threads) or self.ui.plotScrollArea.workers_running()
                or any(thread.isRunning() for thread in threads))

    def _delete_after_workers_finish(self) -> None:
        if not self._close_requested or self._delete_pending:
            return
        if self._worker_threads_running():
            return
        # A canceled worker may still be inside an analysis phase. Clear only
        # after its thread has stopped, so it cannot repopulate a closed session.
        self._analysis_session.clear()
        self._delete_pending = True
        self.deleteLater()

    def _release_large_resources(self) -> None:
        self._sample_index_timer.stop()
        self._render_timer.stop()
        self._metric_search_timer.stop()
        self.ui.plotScrollArea.clear()
        self._rendered_plots.clear()
        self._current_result = None
        self._analysis_result = None
        # Workers can still hold the original list until cooperative cancellation.
        self._measurements = []
        self._metric_catalog = ()
        self._metric_search_suggestions.clear()
        self._metric_search_model.setStringList([])
        self._metric_filter_value_model.setStringList([])
        self._sample_value_model.setStringList([])
        self._sample_index = None
        self._sample_selection = None
        self._pending_summary_navigation = None
        self._sample_conditions.clear()
        self._sample_active_conditions.clear()
        self.ui.metricTreeWidget.clear()


    def _current_render_signature(self) -> tuple[object, ...]:
        return (
            self._result_generation,
            self.ui.plotTypeComboBox.currentText(),
            tuple(self._lane_header_labels()),
        )

    def _metric_search_query(self) -> str:
        return self.ui.metricSearchEdit.text().strip()

    def _lane_dimensions(self) -> list[str]:
        dimensions: list[str] = []
        for index in range(self.ui.laneDimensionsListWidget.count()):
            item = self.ui.laneDimensionsListWidget.item(index)
            if item.checkState() == Qt.CheckState.Checked:
                dimensions.append(str(item.data(Qt.ItemDataRole.UserRole)))
        return dimensions

    def _lane_header_labels(self) -> tuple[str, ...]:
        labels: list[str] = []
        for index in range(self.ui.laneDimensionsListWidget.count()):
            item = self.ui.laneDimensionsListWidget.item(index)
            if item.checkState() == Qt.CheckState.Checked:
                labels.append(item.text())
        return tuple(labels) if labels else ("Lane",)

    def _selected_metric_keys(self) -> list[str]:
        keys: list[str] = []
        tree = self.ui.metricTreeWidget
        for index in range(tree.topLevelItemCount()):
            parent = tree.topLevelItem(index)
            metric_key = str(parent.data(0, Qt.ItemDataRole.UserRole))
            if parent.childCount() == 0:
                if parent.checkState(0) == Qt.CheckState.Checked:
                    keys.append(metric_key)
                continue
            if any(
                parent.child(child_index).checkState(0) == Qt.CheckState.Checked
                for child_index in range(parent.childCount())
            ):
                keys.append(metric_key)
        return keys

    def _selected_lane_keys_by_metric(self) -> dict[str, set[str]]:
        selected: dict[str, set[str]] = {}
        tree = self.ui.metricTreeWidget
        for index in range(tree.topLevelItemCount()):
            parent = tree.topLevelItem(index)
            metric_key = str(parent.data(0, Qt.ItemDataRole.UserRole))
            lane_keys = {
                str(parent.child(child_index).data(0, Qt.ItemDataRole.UserRole + 2))
                for child_index in range(parent.childCount())
                if parent.child(child_index).checkState(0) == Qt.CheckState.Checked
            }
            if lane_keys:
                selected[metric_key] = lane_keys
        return selected

    def _sync_range_legend(self) -> None:
        method = self._context.outlier_fail_method
        self.ui.goldenRangeLegendLabel.setVisible(method in {
            "golden_deviation", "zscore_and_golden", "zscore_or_golden",
        })
        self.ui.zscoreRangeLegendLabel.setVisible(method in {
            "modified_z_score", "zscore_and_golden", "zscore_or_golden",
        })

    def _metric_title(self, descriptor: MetricDescriptor, series: tuple[PlotSeries, ...]) -> str:
        point_count = sum(len(item.points) for item in series)
        outlier_count = sum(sum(1 for point in item.points if point.outlier) for item in series)
        hidden_count = sum(1 for item in series if len(item.reference_ranges) > 1)
        suffix = ""
        if hidden_count:
            suffix = f" | reference hidden in {hidden_count} lane(s) with mixed golden ranges"
        return (
            f"{descriptor.display_label} | {len(series)} lane(s), "
            f"{point_count} point(s), {outlier_count} outlier point(s){suffix}"
        )

    @staticmethod
    def _summary_text(result: PlotBuildResult, shown_plots: int | None = None) -> str:
        summary = result.summary()
        if shown_plots is None:
            shown_plots = summary["selected_metrics"]
        return (
            f"Matched metrics: {summary['matched_metrics']} | "
            f"Showing plots: {shown_plots} | "
            f"Loaded points: {summary['point_count']} | "
            f"Outlier points: {summary['outlier_count']} | "
            f"Lanes: {summary['lane_count']} | "
            f"Lanes with < 5 points: {summary['lanes_with_few_points']}"
        )


def _natural_text_key(value: str) -> tuple[object, ...]:
    parts = re.split(r"(\d+)", value.lower())
    return tuple(int(part) if part.isdigit() else part for part in parts)


def _readable_field_name(value: str) -> str:
    text = re.sub(r"[_\-]+", " ", value).strip()
    text = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", text)
    return " ".join(part.upper() if part.lower() in {"id"} else part.capitalize() for part in text.split())


def _field_key(value: str) -> str:
    return normalized_field_key(value)


def _text_matches_query(values: tuple[str, ...] | list[str], query: str) -> bool:
    if not _has_explicit_space(query):
        return _single_token_matches(values, query)
    tokens = _search_tokens(query)
    if not tokens:
        return True
    compact_values = [_compact_search_text(value) for value in values if value]
    combined = _normalize_search_text(" ".join(values))
    combined_compact = _compact_search_text(combined)
    return all(
        _search_token_matches_text(token, compact_values, combined, combined_compact)
        for token in tokens
    )


def _single_token_matches(values: tuple[str, ...] | list[str], query: str) -> bool:
    normalized_token = _normalize_search_text(query)
    compact_token = _compact_search_text(query)
    if not normalized_token and not compact_token:
        return True
    for value in values:
        normalized_value = _normalize_search_text(value)
        if normalized_token and normalized_token in normalized_value:
            return True
        if compact_token and any(compact_token in segment for segment in _compact_search_segments(value)):
            return True
    return False


def _search_tokens(query: str) -> list[str]:
    return [token for token in _normalize_search_text(query).split() if token]


def _normalize_search_text(value: str) -> str:
    normalized = re.sub(r"[^0-9a-zA-Z]+", " ", value.lower())
    return " ".join(normalized.split())


def _compact_search_text(value: str) -> str:
    return re.sub(r"[^0-9a-zA-Z]+", "", value.lower())


def _compact_search_segments(value: str) -> list[str]:
    return [_compact_search_text(segment) for segment in re.findall(r"[0-9a-zA-Z]+", value.lower())]


def _search_token_matches_text(
    token: str,
    compact_values: list[str],
    combined: str,
    combined_compact: str,
) -> bool:
    compact_token = _compact_search_text(token)
    if token in combined:
        return True
    if compact_token and any(compact_token in value for value in compact_values):
        return True
    if compact_token and compact_token in combined_compact and not _contains_digit(compact_token):
        return True
    if _contains_digit(compact_token):
        return False
    if len(compact_token) < 2:
        return False
    return any(
        _is_subsequence(compact_token, value)
        for value in compact_values
        if len(value) >= len(compact_token)
    )


def _is_subsequence(needle: str, haystack: str) -> bool:
    position = 0
    for char in haystack:
        if position < len(needle) and needle[position] == char:
            position += 1
            if position == len(needle):
                return True
    return False


def _contains_digit(value: str) -> bool:
    return any(char.isdigit() for char in value)


def _has_explicit_space(value: str) -> bool:
    return bool(re.search(r"\s", value))
