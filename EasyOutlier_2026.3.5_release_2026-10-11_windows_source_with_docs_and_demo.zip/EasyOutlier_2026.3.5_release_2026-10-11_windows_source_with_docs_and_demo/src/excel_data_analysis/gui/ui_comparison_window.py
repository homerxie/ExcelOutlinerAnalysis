# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'comparison_window.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox,
    QFrame, QGridLayout, QGroupBox, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QMainWindow, QProgressBar, QPushButton,
    QScrollArea, QSizePolicy, QSpacerItem, QSplitter,
    QStatusBar, QTableWidget, QTableWidgetItem, QToolButton,
    QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from .comparison_plot_view import ComparisonPlotViewport

class Ui_PlotInspectorWindow(object):
    def setupUi(self, PlotInspectorWindow):
        if not PlotInspectorWindow.objectName():
            PlotInspectorWindow.setObjectName(u"PlotInspectorWindow")
        PlotInspectorWindow.resize(1280, 780)
        self.centralwidget = QWidget(PlotInspectorWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.mainLayout = QVBoxLayout(self.centralwidget)
        self.mainLayout.setObjectName(u"mainLayout")
        self.mainSplitter = QSplitter(self.centralwidget)
        self.mainSplitter.setObjectName(u"mainSplitter")
        self.mainSplitter.setOrientation(Qt.Horizontal)
        self.controlPanelScrollArea = QScrollArea(self.mainSplitter)
        self.controlPanelScrollArea.setObjectName(u"controlPanelScrollArea")
        self.controlPanelScrollArea.setMinimumSize(QSize(340, 0))
        self.controlPanelScrollArea.setMaximumSize(QSize(460, 16777215))
        self.controlPanelScrollArea.setWidgetResizable(True)
        self.controlPanelScrollArea.setFrameShape(QFrame.NoFrame)
        self.controlPanel = QWidget()
        self.controlPanel.setObjectName(u"controlPanel")
        self.controlPanel.setGeometry(QRect(0, 0, 340, 720))
        self.controlPanelLayout = QVBoxLayout(self.controlPanel)
        self.controlPanelLayout.setSpacing(10)
        self.controlPanelLayout.setObjectName(u"controlPanelLayout")
        self.metricFilterGroupBox = QGroupBox(self.controlPanel)
        self.metricFilterGroupBox.setObjectName(u"metricFilterGroupBox")
        self.metricFilterLayout = QVBoxLayout(self.metricFilterGroupBox)
        self.metricFilterLayout.setSpacing(8)
        self.metricFilterLayout.setObjectName(u"metricFilterLayout")
        self.advancedMetricFilterButton = QToolButton(self.metricFilterGroupBox)
        self.advancedMetricFilterButton.setObjectName(u"advancedMetricFilterButton")
        self.advancedMetricFilterButton.setCheckable(True)
        self.advancedMetricFilterButton.setChecked(False)

        self.metricFilterLayout.addWidget(self.advancedMetricFilterButton)

        self.advancedMetricFilterWidget = QWidget(self.metricFilterGroupBox)
        self.advancedMetricFilterWidget.setObjectName(u"advancedMetricFilterWidget")
        self.advancedMetricFilterWidget.setVisible(False)
        self.advancedMetricFilterLayout = QVBoxLayout(self.advancedMetricFilterWidget)
        self.advancedMetricFilterLayout.setSpacing(8)
        self.advancedMetricFilterLayout.setObjectName(u"advancedMetricFilterLayout")
        self.advancedMetricFilterLayout.setContentsMargins(0, 0, 0, 0)
        self.metricRuleInputLayout = QGridLayout()
        self.metricRuleInputLayout.setObjectName(u"metricRuleInputLayout")
        self.metricRuleInputLayout.setHorizontalSpacing(8)
        self.metricRuleInputLayout.setVerticalSpacing(6)
        self.metricConnectorComboBox = QComboBox(self.advancedMetricFilterWidget)
        self.metricConnectorComboBox.addItem("")
        self.metricConnectorComboBox.addItem("")
        self.metricConnectorComboBox.addItem("")
        self.metricConnectorComboBox.setObjectName(u"metricConnectorComboBox")

        self.metricRuleInputLayout.addWidget(self.metricConnectorComboBox, 0, 0, 1, 1)

        self.metricFieldComboBox = QComboBox(self.advancedMetricFilterWidget)
        self.metricFieldComboBox.setObjectName(u"metricFieldComboBox")

        self.metricRuleInputLayout.addWidget(self.metricFieldComboBox, 0, 1, 1, 1)

        self.metricOperatorComboBox = QComboBox(self.advancedMetricFilterWidget)
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.setObjectName(u"metricOperatorComboBox")

        self.metricRuleInputLayout.addWidget(self.metricOperatorComboBox, 1, 0, 1, 1)

        self.metricValueComboBox = QComboBox(self.advancedMetricFilterWidget)
        self.metricValueComboBox.setObjectName(u"metricValueComboBox")
        self.metricValueComboBox.setEditable(True)
        self.metricValueComboBox.setInsertPolicy(QComboBox.NoInsert)

        self.metricRuleInputLayout.addWidget(self.metricValueComboBox, 1, 1, 1, 1)

        self.addMetricRuleButton = QPushButton(self.advancedMetricFilterWidget)
        self.addMetricRuleButton.setObjectName(u"addMetricRuleButton")

        self.metricRuleInputLayout.addWidget(self.addMetricRuleButton, 2, 0, 1, 1)

        self.clearMetricRulesButton = QPushButton(self.advancedMetricFilterWidget)
        self.clearMetricRulesButton.setObjectName(u"clearMetricRulesButton")

        self.metricRuleInputLayout.addWidget(self.clearMetricRulesButton, 2, 1, 1, 1)


        self.advancedMetricFilterLayout.addLayout(self.metricRuleInputLayout)

        self.metricRuleActionLayout = QHBoxLayout()
        self.metricRuleActionLayout.setObjectName(u"metricRuleActionLayout")
        self.deleteMetricRuleButton = QPushButton(self.advancedMetricFilterWidget)
        self.deleteMetricRuleButton.setObjectName(u"deleteMetricRuleButton")

        self.metricRuleActionLayout.addWidget(self.deleteMetricRuleButton)

        self.modifyMetricRuleButton = QPushButton(self.advancedMetricFilterWidget)
        self.modifyMetricRuleButton.setObjectName(u"modifyMetricRuleButton")

        self.metricRuleActionLayout.addWidget(self.modifyMetricRuleButton)


        self.advancedMetricFilterLayout.addLayout(self.metricRuleActionLayout)

        self.metricRulesTableWidget = QTableWidget(self.advancedMetricFilterWidget)
        if (self.metricRulesTableWidget.columnCount() < 4):
            self.metricRulesTableWidget.setColumnCount(4)
        __qtablewidgetitem = QTableWidgetItem()
        self.metricRulesTableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.metricRulesTableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.metricRulesTableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.metricRulesTableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        self.metricRulesTableWidget.setObjectName(u"metricRulesTableWidget")
        self.metricRulesTableWidget.setMinimumSize(QSize(0, 90))
        self.metricRulesTableWidget.setMaximumSize(QSize(16777215, 130))
        self.metricRulesTableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.metricRulesTableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)

        self.advancedMetricFilterLayout.addWidget(self.metricRulesTableWidget)


        self.metricFilterLayout.addWidget(self.advancedMetricFilterWidget)


        self.controlPanelLayout.addWidget(self.metricFilterGroupBox)

        self.plotOptionsGroupBox = QGroupBox(self.controlPanel)
        self.plotOptionsGroupBox.setObjectName(u"plotOptionsGroupBox")
        self.plotOptionsLayout = QGridLayout(self.plotOptionsGroupBox)
        self.plotOptionsLayout.setObjectName(u"plotOptionsLayout")
        self.plotTypeLabel = QLabel(self.plotOptionsGroupBox)
        self.plotTypeLabel.setObjectName(u"plotTypeLabel")

        self.plotOptionsLayout.addWidget(self.plotTypeLabel, 0, 0, 1, 1)

        self.plotTypeComboBox = QComboBox(self.plotOptionsGroupBox)
        self.plotTypeComboBox.addItem("")
        self.plotTypeComboBox.addItem("")
        self.plotTypeComboBox.setObjectName(u"plotTypeComboBox")

        self.plotOptionsLayout.addWidget(self.plotTypeComboBox, 0, 1, 1, 1)

        self.laneGroupingLabel = QLabel(self.plotOptionsGroupBox)
        self.laneGroupingLabel.setObjectName(u"laneGroupingLabel")

        self.plotOptionsLayout.addWidget(self.laneGroupingLabel, 1, 0, 1, 1)

        self.laneDimensionsListWidget = QListWidget(self.plotOptionsGroupBox)
        self.laneDimensionsListWidget.setObjectName(u"laneDimensionsListWidget")
        self.laneDimensionsListWidget.setMinimumSize(QSize(0, 72))
        self.laneDimensionsListWidget.setMaximumSize(QSize(16777215, 96))
        self.laneDimensionsListWidget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.laneDimensionsListWidget.setDragEnabled(True)
        self.laneDimensionsListWidget.setDragDropMode(QAbstractItemView.InternalMove)
        self.laneDimensionsListWidget.setDefaultDropAction(Qt.MoveAction)

        self.plotOptionsLayout.addWidget(self.laneDimensionsListWidget, 1, 1, 1, 1)


        self.controlPanelLayout.addWidget(self.plotOptionsGroupBox)

        self.matchedMetricsGroupBox = QGroupBox(self.controlPanel)
        self.matchedMetricsGroupBox.setObjectName(u"matchedMetricsGroupBox")
        self.matchedMetricsLayout = QVBoxLayout(self.matchedMetricsGroupBox)
        self.matchedMetricsLayout.setObjectName(u"matchedMetricsLayout")
        self.metricSearchLayout = QGridLayout()
        self.metricSearchLayout.setObjectName(u"metricSearchLayout")
        self.metricSearchLayout.setHorizontalSpacing(8)
        self.metricSearchLayout.setVerticalSpacing(10)
        self.metricSearchEdit = QLineEdit(self.matchedMetricsGroupBox)
        self.metricSearchEdit.setObjectName(u"metricSearchEdit")

        self.metricSearchLayout.addWidget(self.metricSearchEdit, 0, 0, 1, 4)

        self.metricSearchViewComboBox = QComboBox(self.matchedMetricsGroupBox)
        self.metricSearchViewComboBox.addItem("")
        self.metricSearchViewComboBox.addItem("")
        self.metricSearchViewComboBox.setObjectName(u"metricSearchViewComboBox")

        self.metricSearchLayout.addWidget(self.metricSearchViewComboBox, 1, 0, 1, 4)

        self.metricRealtimeCheckBox = QCheckBox(self.matchedMetricsGroupBox)
        self.metricRealtimeCheckBox.setObjectName(u"metricRealtimeCheckBox")
        self.metricRealtimeCheckBox.setChecked(False)

        self.metricSearchLayout.addWidget(self.metricRealtimeCheckBox, 2, 0, 1, 2)

        self.metricSearchButton = QPushButton(self.matchedMetricsGroupBox)
        self.metricSearchButton.setObjectName(u"metricSearchButton")

        self.metricSearchLayout.addWidget(self.metricSearchButton, 2, 2, 1, 2)

        self.metricSearchPrevButton = QPushButton(self.matchedMetricsGroupBox)
        self.metricSearchPrevButton.setObjectName(u"metricSearchPrevButton")

        self.metricSearchLayout.addWidget(self.metricSearchPrevButton, 3, 0, 1, 1)

        self.metricSearchNextButton = QPushButton(self.matchedMetricsGroupBox)
        self.metricSearchNextButton.setObjectName(u"metricSearchNextButton")

        self.metricSearchLayout.addWidget(self.metricSearchNextButton, 3, 1, 1, 1)

        self.metricSearchStatusLabel = QLabel(self.matchedMetricsGroupBox)
        self.metricSearchStatusLabel.setObjectName(u"metricSearchStatusLabel")
        self.metricSearchStatusLabel.setMinimumSize(QSize(64, 0))
        self.metricSearchStatusLabel.setAlignment(Qt.AlignCenter)

        self.metricSearchLayout.addWidget(self.metricSearchStatusLabel, 3, 2, 1, 2)

        self.selectAllMetricsButton = QPushButton(self.matchedMetricsGroupBox)
        self.selectAllMetricsButton.setObjectName(u"selectAllMetricsButton")

        self.metricSearchLayout.addWidget(self.selectAllMetricsButton, 4, 0, 1, 2)

        self.deselectAllMetricsButton = QPushButton(self.matchedMetricsGroupBox)
        self.deselectAllMetricsButton.setObjectName(u"deselectAllMetricsButton")

        self.metricSearchLayout.addWidget(self.deselectAllMetricsButton, 4, 2, 1, 2)


        self.matchedMetricsLayout.addLayout(self.metricSearchLayout)

        self.metricTreeWidget = QTreeWidget(self.matchedMetricsGroupBox)
        self.metricTreeWidget.setObjectName(u"metricTreeWidget")
        self.metricTreeWidget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.metricTreeWidget.setRootIsDecorated(True)
        self.metricTreeWidget.setItemsExpandable(True)
        self.metricTreeWidget.setAllColumnsShowFocus(True)
        self.metricTreeWidget.setUniformRowHeights(True)

        self.matchedMetricsLayout.addWidget(self.metricTreeWidget)


        self.controlPanelLayout.addWidget(self.matchedMetricsGroupBox)

        self.sampleLocatorGroupBox = QGroupBox(self.controlPanel)
        self.sampleLocatorGroupBox.setObjectName(u"sampleLocatorGroupBox")
        self.sampleLocatorGroupBox.setEnabled(False)
        self.sampleLocatorLayout = QVBoxLayout(self.sampleLocatorGroupBox)
        self.sampleLocatorLayout.setSpacing(6)
        self.sampleLocatorLayout.setObjectName(u"sampleLocatorLayout")
        self.sampleLocatorHintLabel = QLabel(self.sampleLocatorGroupBox)
        self.sampleLocatorHintLabel.setObjectName(u"sampleLocatorHintLabel")
        self.sampleLocatorHintLabel.setWordWrap(True)

        self.sampleLocatorLayout.addWidget(self.sampleLocatorHintLabel)

        self.sampleFieldComboBox = QComboBox(self.sampleLocatorGroupBox)
        self.sampleFieldComboBox.setObjectName(u"sampleFieldComboBox")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.sampleFieldComboBox.sizePolicy().hasHeightForWidth())
        self.sampleFieldComboBox.setSizePolicy(sizePolicy)

        self.sampleLocatorLayout.addWidget(self.sampleFieldComboBox)

        self.sampleValueComboBox = QComboBox(self.sampleLocatorGroupBox)
        self.sampleValueComboBox.setObjectName(u"sampleValueComboBox")
        self.sampleValueComboBox.setEditable(True)
        self.sampleValueComboBox.setInsertPolicy(QComboBox.NoInsert)
        sizePolicy.setHeightForWidth(self.sampleValueComboBox.sizePolicy().hasHeightForWidth())
        self.sampleValueComboBox.setSizePolicy(sizePolicy)

        self.sampleLocatorLayout.addWidget(self.sampleValueComboBox)

        self.sampleConditionButtonsLayout = QHBoxLayout()
        self.sampleConditionButtonsLayout.setObjectName(u"sampleConditionButtonsLayout")
        self.sampleAddConditionButton = QPushButton(self.sampleLocatorGroupBox)
        self.sampleAddConditionButton.setObjectName(u"sampleAddConditionButton")

        self.sampleConditionButtonsLayout.addWidget(self.sampleAddConditionButton)

        self.sampleRemoveConditionButton = QPushButton(self.sampleLocatorGroupBox)
        self.sampleRemoveConditionButton.setObjectName(u"sampleRemoveConditionButton")

        self.sampleConditionButtonsLayout.addWidget(self.sampleRemoveConditionButton)


        self.sampleLocatorLayout.addLayout(self.sampleConditionButtonsLayout)

        self.sampleConditionsTableWidget = QTableWidget(self.sampleLocatorGroupBox)
        if (self.sampleConditionsTableWidget.columnCount() < 2):
            self.sampleConditionsTableWidget.setColumnCount(2)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.sampleConditionsTableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem4)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.sampleConditionsTableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem5)
        self.sampleConditionsTableWidget.setObjectName(u"sampleConditionsTableWidget")
        self.sampleConditionsTableWidget.setMinimumSize(QSize(0, 78))
        self.sampleConditionsTableWidget.setMaximumSize(QSize(16777215, 110))
        self.sampleConditionsTableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.sampleConditionsTableWidget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.sampleConditionsTableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.sampleConditionsTableWidget.horizontalHeader().setStretchLastSection(True)
        self.sampleConditionsTableWidget.verticalHeader().setVisible(False)

        self.sampleLocatorLayout.addWidget(self.sampleConditionsTableWidget)

        self.sampleLocateButtonsLayout = QHBoxLayout()
        self.sampleLocateButtonsLayout.setObjectName(u"sampleLocateButtonsLayout")
        self.sampleLocateButton = QPushButton(self.sampleLocatorGroupBox)
        self.sampleLocateButton.setObjectName(u"sampleLocateButton")

        self.sampleLocateButtonsLayout.addWidget(self.sampleLocateButton)

        self.sampleClearButton = QPushButton(self.sampleLocatorGroupBox)
        self.sampleClearButton.setObjectName(u"sampleClearButton")

        self.sampleLocateButtonsLayout.addWidget(self.sampleClearButton)


        self.sampleLocatorLayout.addLayout(self.sampleLocateButtonsLayout)

        self.sampleLocatorStatusLabel = QLabel(self.sampleLocatorGroupBox)
        self.sampleLocatorStatusLabel.setObjectName(u"sampleLocatorStatusLabel")
        self.sampleLocatorStatusLabel.setWordWrap(True)

        self.sampleLocatorLayout.addWidget(self.sampleLocatorStatusLabel)


        self.controlPanelLayout.addWidget(self.sampleLocatorGroupBox)

        self.summaryLinkGroupBox = QGroupBox(self.controlPanel)
        self.summaryLinkGroupBox.setObjectName(u"summaryLinkGroupBox")
        self.summaryLinkGroupBox.setVisible(False)
        self.summaryLinkLayout = QVBoxLayout(self.summaryLinkGroupBox)
        self.summaryLinkLayout.setSpacing(6)
        self.summaryLinkLayout.setObjectName(u"summaryLinkLayout")
        self.summaryLinkScopeLabel = QLabel(self.summaryLinkGroupBox)
        self.summaryLinkScopeLabel.setObjectName(u"summaryLinkScopeLabel")
        self.summaryLinkScopeLabel.setWordWrap(True)
        self.summaryLinkScopeLabel.setTextInteractionFlags(Qt.TextSelectableByMouse)

        self.summaryLinkLayout.addWidget(self.summaryLinkScopeLabel)

        self.summaryLinkHintLabel = QLabel(self.summaryLinkGroupBox)
        self.summaryLinkHintLabel.setObjectName(u"summaryLinkHintLabel")
        self.summaryLinkHintLabel.setWordWrap(True)

        self.summaryLinkLayout.addWidget(self.summaryLinkHintLabel)

        self.resetSummaryLinkButton = QPushButton(self.summaryLinkGroupBox)
        self.resetSummaryLinkButton.setObjectName(u"resetSummaryLinkButton")
        self.resetSummaryLinkButton.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))

        self.summaryLinkLayout.addWidget(self.resetSummaryLinkButton)


        self.controlPanelLayout.addWidget(self.summaryLinkGroupBox)

        self.refreshButton = QPushButton(self.controlPanel)
        self.refreshButton.setObjectName(u"refreshButton")

        self.controlPanelLayout.addWidget(self.refreshButton)

        self.controlPanelScrollArea.setWidget(self.controlPanel)
        self.mainSplitter.addWidget(self.controlPanelScrollArea)
        self.plotPanel = QWidget(self.mainSplitter)
        self.plotPanel.setObjectName(u"plotPanel")
        self.plotPanelLayout = QVBoxLayout(self.plotPanel)
        self.plotPanelLayout.setObjectName(u"plotPanelLayout")
        self.plotPanelLayout.setContentsMargins(0, 0, 0, 0)
        self.summaryLabel = QLabel(self.plotPanel)
        self.summaryLabel.setObjectName(u"summaryLabel")
        self.summaryLabel.setWordWrap(True)

        self.plotPanelLayout.addWidget(self.summaryLabel)

        self.plotInteractionHintLabel = QLabel(self.plotPanel)
        self.plotInteractionHintLabel.setObjectName(u"plotInteractionHintLabel")
        self.plotInteractionHintLabel.setWordWrap(True)

        self.plotPanelLayout.addWidget(self.plotInteractionHintLabel)

        self.rangeLegendWidget = QWidget(self.plotPanel)
        self.rangeLegendWidget.setObjectName(u"rangeLegendWidget")
        self.rangeLegendLayout = QHBoxLayout(self.rangeLegendWidget)
        self.rangeLegendLayout.setSpacing(12)
        self.rangeLegendLayout.setObjectName(u"rangeLegendLayout")
        self.rangeLegendLayout.setContentsMargins(0, 0, 0, 0)
        self.goldenRangeLegendLabel = QLabel(self.rangeLegendWidget)
        self.goldenRangeLegendLabel.setObjectName(u"goldenRangeLegendLabel")
        self.goldenRangeLegendLabel.setStyleSheet(u"QLabel { background-color: #d5e2dd; color: #2f6f58; padding: 3px 8px; }")
        self.goldenRangeLegendLabel.setVisible(False)

        self.rangeLegendLayout.addWidget(self.goldenRangeLegendLabel)

        self.zscoreRangeLegendLabel = QLabel(self.rangeLegendWidget)
        self.zscoreRangeLegendLabel.setObjectName(u"zscoreRangeLegendLabel")
        self.zscoreRangeLegendLabel.setStyleSheet(u"QLabel { border: 1.5px solid #2563eb; background-color: #ffffff; color: #2563eb; padding: 3px 8px; }")

        self.rangeLegendLayout.addWidget(self.zscoreRangeLegendLabel)

        self.rangeLegendSpacer = QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.rangeLegendLayout.addItem(self.rangeLegendSpacer)


        self.plotPanelLayout.addWidget(self.rangeLegendWidget)

        self.plotScrollArea = ComparisonPlotViewport(self.plotPanel)
        self.plotScrollArea.setObjectName(u"plotScrollArea")
        self.plotScrollArea.setCursor(QCursor(Qt.CursorShape.ArrowCursor))
        self.plotScrollArea.setProperty(u"zoomCursorSvg", u"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\"><g fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><g stroke=\"white\" stroke-width=\"5\"><circle cx=\"12\" cy=\"12\" r=\"8\"/><path d=\"M18 18 L27 27 M7 12 H17 M7 12 L9 10 M7 12 L9 14 M17 12 L15 10 M17 12 L15 14\"/></g><g stroke=\"#202020\" stroke-width=\"2\"><circle cx=\"12\" cy=\"12\" r=\"8\"/><path d=\"M18 18 L27 27 M7 12 H17 M7 12 L9 10 M7 12 L9 14 M17 12 L15 10 M17 12 L15 14\"/></g></g></svg>")
        self.plotScrollArea.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)

        self.plotPanelLayout.addWidget(self.plotScrollArea)

        self.renderStatusLayout = QHBoxLayout()
        self.renderStatusLayout.setObjectName(u"renderStatusLayout")
        self.renderStatusLabel = QLabel(self.plotPanel)
        self.renderStatusLabel.setObjectName(u"renderStatusLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.renderStatusLabel.sizePolicy().hasHeightForWidth())
        self.renderStatusLabel.setSizePolicy(sizePolicy1)

        self.renderStatusLayout.addWidget(self.renderStatusLabel)

        self.renderProgressBar = QProgressBar(self.plotPanel)
        self.renderProgressBar.setObjectName(u"renderProgressBar")
        self.renderProgressBar.setEnabled(False)
        self.renderProgressBar.setMinimumSize(QSize(180, 14))
        self.renderProgressBar.setMaximumSize(QSize(180, 14))
        self.renderProgressBar.setMaximum(1)
        self.renderProgressBar.setValue(0)
        self.renderProgressBar.setTextVisible(False)

        self.renderStatusLayout.addWidget(self.renderProgressBar)


        self.plotPanelLayout.addLayout(self.renderStatusLayout)

        self.mainSplitter.addWidget(self.plotPanel)

        self.mainLayout.addWidget(self.mainSplitter)

        PlotInspectorWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(PlotInspectorWindow)
        self.statusbar.setObjectName(u"statusbar")
        PlotInspectorWindow.setStatusBar(self.statusbar)

        self.retranslateUi(PlotInspectorWindow)

        QMetaObject.connectSlotsByName(PlotInspectorWindow)
    # setupUi

    def retranslateUi(self, PlotInspectorWindow):
        PlotInspectorWindow.setWindowTitle(QCoreApplication.translate("PlotInspectorWindow", u"Plot Inspector", None))
        self.metricFilterGroupBox.setTitle(QCoreApplication.translate("PlotInspectorWindow", u"Data Filter", None))
        self.advancedMetricFilterButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Advanced Filter", None))
        self.metricConnectorComboBox.setItemText(0, QCoreApplication.translate("PlotInspectorWindow", u"and", None))
        self.metricConnectorComboBox.setItemText(1, QCoreApplication.translate("PlotInspectorWindow", u"or", None))
        self.metricConnectorComboBox.setItemText(2, QCoreApplication.translate("PlotInspectorWindow", u"and not", None))

        self.metricOperatorComboBox.setItemText(0, QCoreApplication.translate("PlotInspectorWindow", u"contains", None))
        self.metricOperatorComboBox.setItemText(1, QCoreApplication.translate("PlotInspectorWindow", u"is", None))
        self.metricOperatorComboBox.setItemText(2, QCoreApplication.translate("PlotInspectorWindow", u"is not", None))
        self.metricOperatorComboBox.setItemText(3, QCoreApplication.translate("PlotInspectorWindow", u"does not contain", None))
        self.metricOperatorComboBox.setItemText(4, QCoreApplication.translate("PlotInspectorWindow", u"starts with", None))
        self.metricOperatorComboBox.setItemText(5, QCoreApplication.translate("PlotInspectorWindow", u"ends with", None))
        self.metricOperatorComboBox.setItemText(6, QCoreApplication.translate("PlotInspectorWindow", u"is in", None))
        self.metricOperatorComboBox.setItemText(7, QCoreApplication.translate("PlotInspectorWindow", u"has outlier", None))

        self.metricValueComboBox.setPlaceholderText(QCoreApplication.translate("PlotInspectorWindow", u"leakage, ChainA, TestType1...", None))
        self.addMetricRuleButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Add Rule", None))
        self.clearMetricRulesButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Clear Rules", None))
        self.deleteMetricRuleButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Delete Selected Rule", None))
        self.modifyMetricRuleButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Modify Selected Rule", None))
        ___qtablewidgetitem = self.metricRulesTableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("PlotInspectorWindow", u"Connector", None))
        ___qtablewidgetitem1 = self.metricRulesTableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("PlotInspectorWindow", u"Field", None))
        ___qtablewidgetitem2 = self.metricRulesTableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("PlotInspectorWindow", u"Operator", None))
        ___qtablewidgetitem3 = self.metricRulesTableWidget.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("PlotInspectorWindow", u"Value", None))
        self.plotOptionsGroupBox.setTitle(QCoreApplication.translate("PlotInspectorWindow", u"Plot Options", None))
        self.plotTypeLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"Plot Type", None))
        self.plotTypeComboBox.setItemText(0, QCoreApplication.translate("PlotInspectorWindow", u"Ridge Plot", None))
        self.plotTypeComboBox.setItemText(1, QCoreApplication.translate("PlotInspectorWindow", u"Box Plot", None))

#if QT_CONFIG(tooltip)
        self.laneGroupingLabel.setToolTip(QCoreApplication.translate("PlotInspectorWindow", u"Leave all unchecked to combine all rows into one lane. Drag checked dimensions to change label order and lane sorting.", None))
#endif // QT_CONFIG(tooltip)
        self.laneGroupingLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"Lane Dimensions", None))
#if QT_CONFIG(tooltip)
        self.laneDimensionsListWidget.setToolTip(QCoreApplication.translate("PlotInspectorWindow", u"Leave all unchecked to combine all rows into one lane. Drag checked dimensions to change label order and lane sorting.", None))
#endif // QT_CONFIG(tooltip)
        self.matchedMetricsGroupBox.setTitle(QCoreApplication.translate("PlotInspectorWindow", u"Matched Metrics", None))
        self.metricSearchEdit.setPlaceholderText(QCoreApplication.translate("PlotInspectorWindow", u"Search metric, axis title, lane header, or lane label...", None))
        self.metricSearchViewComboBox.setItemText(0, QCoreApplication.translate("PlotInspectorWindow", u"Compact Results", None))
        self.metricSearchViewComboBox.setItemText(1, QCoreApplication.translate("PlotInspectorWindow", u"In Place", None))

        self.metricRealtimeCheckBox.setText(QCoreApplication.translate("PlotInspectorWindow", u"Realtime refresh", None))
        self.metricSearchButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Search", None))
        self.metricSearchPrevButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Prev", None))
        self.metricSearchNextButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Next", None))
        self.metricSearchStatusLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"0 / 0", None))
        self.selectAllMetricsButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Select All", None))
        self.deselectAllMetricsButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Deselect All", None))
        ___qtreewidgetitem = self.metricTreeWidget.headerItem()
        ___qtreewidgetitem.setText(1, QCoreApplication.translate("PlotInspectorWindow", u"Points", None))
        ___qtreewidgetitem.setText(0, QCoreApplication.translate("PlotInspectorWindow", u"Metric / Lane", None))
        self.sampleLocatorGroupBox.setTitle(QCoreApplication.translate("PlotInspectorWindow", u"Sample Locator \u00b7 \u6837\u54c1\u5b9a\u4f4d", None))
        self.sampleLocatorHintLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"Match sample dimensions exactly (AND). Keep other points for comparison.", None))
#if QT_CONFIG(tooltip)
        self.sampleFieldComboBox.setToolTip(QCoreApplication.translate("PlotInspectorWindow", u"Sample identity dimension from the template", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.sampleValueComboBox.setToolTip(QCoreApplication.translate("PlotInspectorWindow", u"Exact value; suggestions come from the current plot data", None))
#endif // QT_CONFIG(tooltip)
        self.sampleAddConditionButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Set Condition", None))
        self.sampleRemoveConditionButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Remove", None))
        ___qtablewidgetitem4 = self.sampleConditionsTableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("PlotInspectorWindow", u"Dimension", None))
        ___qtablewidgetitem5 = self.sampleConditionsTableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("PlotInspectorWindow", u"Exact Value", None))
        self.sampleLocateButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Locate \u00b7 \u5b9a\u4f4d", None))
        self.sampleClearButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Clear \u00b7 \u6e05\u9664", None))
        self.sampleLocatorStatusLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"Load plot data to locate a sample.", None))
        self.summaryLinkGroupBox.setTitle(QCoreApplication.translate("PlotInspectorWindow", u"Summary Link \u00b7 \u7edf\u8ba1\u8054\u52a8", None))
        self.summaryLinkScopeLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"No linked summary scope.", None))
        self.summaryLinkHintLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"Clearing a sample keeps this report scope. Reset to return to all plot data.", None))
        self.resetSummaryLinkButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Reset Summary Link \u00b7 \u89e3\u9664\u8054\u52a8", None))
        self.refreshButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Refresh Plot", None))
        self.summaryLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"No plot data loaded.", None))
        self.plotInteractionHintLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"Zoom X: \u2318 / Ctrl + wheel or trackpad pinch. Alt / Option + drag to pan. Double-click blank plot area to reset.", None))
#if QT_CONFIG(tooltip)
        self.plotInteractionHintLabel.setToolTip(QCoreApplication.translate("PlotInspectorWindow", u"Hold Command on macOS or Ctrl on Windows to show the zoom cursor. Use the wheel or two-finger scrolling to zoom, or pinch the trackpad. Hold Alt (Option on macOS) to show the pan hand, then drag with the left mouse button to move the current plot horizontally. Release Alt to stop panning. Without Alt, the arrow and ordinary left-button actions do not pan. Ordinary scrolling moves through the plots. Double-click an edge triangle to reveal that side's points.", None))
#endif // QT_CONFIG(tooltip)
        self.goldenRangeLegendLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"Golden \u5141\u8bb8\u8303\u56f4", None))
#if QT_CONFIG(tooltip)
        self.goldenRangeLegendLabel.setToolTip(QCoreApplication.translate("PlotInspectorWindow", u"\u6d45\u7eff\u8272\u533a\u57df\uff1aGolden \u7684\u5141\u8bb8\u8303\u56f4\u3002\u4ec5\u5728\u5224\u636e\u5305\u542b Golden \u65f6\u663e\u793a\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.zscoreRangeLegendLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"Z Score \u6b63\u5e38\u8303\u56f4", None))
#if QT_CONFIG(tooltip)
        self.zscoreRangeLegendLabel.setToolTip(QCoreApplication.translate("PlotInspectorWindow", u"\u84dd\u8272\u6846\uff1a\u6309\u672c\u6b21\u5224\u5b9a\u6240\u7528\u7684\u4e2d\u4f4d\u6570\u3001MAD \u548c Z Threshold \u8ba1\u7b97\u7684\u8303\u56f4\u3002AND / OR \u6a21\u5f0f\u4e0b\u4e0e Golden \u8303\u56f4\u5206\u522b\u663e\u793a\u3002\u4e00\u4e2a\u5206\u7ec4\u542b\u591a\u4e2a\u57fa\u51c6\u65f6\u5206\u522b\u753b\u6846\uff1b\u60ac\u505c\u6570\u636e\u70b9\u53ef\u67e5\u770b\u5176\u5bf9\u5e94\u8303\u56f4\u3002\u6837\u672c\u4e0d\u8db3 3 \u6216 MAD \u4e3a 0 \u65f6\u6cbf\u7528\u73b0\u6709\u5224\u5b9a\u89c4\u5219\uff0c\u6ca1\u6709\u6709\u9650\u7684 Z Score \u8fb9\u754c\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.plotScrollArea.setProperty(u"loadingText", QCoreApplication.translate("PlotInspectorWindow", u"Preparing visible plots\u2026", None))
        self.plotScrollArea.setProperty(u"emptyText", QCoreApplication.translate("PlotInspectorWindow", u"No selected plot data.", None))
        self.renderStatusLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"Ready", None))
    # retranslateUi

