"""Lazy display of result rows without allocating objects for empty Lot cells."""
from __future__ import annotations

import re
from collections import OrderedDict

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt


class OutlierRatioTableModel(QAbstractTableModel):
    SAMPLE_LINK_CACHE_LIMIT = 128
    FIELDS = (
        "id", "display_name", "group_by_dimension", "group_value", "numerator",
        "outlier_sample_count", "total_sample_count", "outlier_ratio", "filter_summary",
    )
    HEADERS = (
        "ID", "Display Name", "Group By Dimension", "Group Value", "Numerator",
        "Outlier Sample Count", "Total Sample Count", "Outlier Ratio", "Filter Summary",
    )

    def __init__(self, parent=None):
        super().__init__(parent)
        self._all_rows = []
        self._rows = []
        self._search_text = ""
        self._column_filters = {}
        self._lot_columns = 0
        self._sort_column = -1
        self._sort_order = Qt.AscendingOrder
        self._navigation_available = True
        self._sample_link_cache = OrderedDict()

    def set_navigation_available(self, available):
        self._navigation_available = bool(available)
        self._sample_link_cache.clear()
        if self.rowCount() and self.columnCount():
            self.dataChanged.emit(self.index(0, 0), self.index(self.rowCount() - 1, self.columnCount() - 1))

    def navigation(self, index):
        """Resolve the displayed, possibly sorted row without parsing ID text."""
        if not self._navigation_available or not index.isValid() or not 0 <= index.row() < len(self._rows):
            return None
        offset = index.column() - len(self.FIELDS)
        if offset < 0 or offset % 2 != 1:
            return None
        row = self._rows[index.row()]
        navigation = row.get("plot_navigation")
        if not isinstance(navigation, dict):
            return None
        targets = tuple(target for target in navigation.get("targets", [])
                        if isinstance(target, dict) and target.get("pair_index") == offset // 2
                        and isinstance(target.get("conditions"), dict) and target["conditions"])
        return (navigation, targets) if targets else None

    def sample_links(self, index):
        """Return separately clickable labels, with plain identity suffixes.

        Renderers join the parts with a plain semicolon. Display order comes
        from the cell, but every clickable part retains its structured target;
        numeric-looking IDs are never converted to integers. The small cache
        covers visible cells without retaining link objects for the full table.
        """
        if not self._navigation_available or not index.isValid() or index.model() is not self:
            return None
        if not 0 <= index.row() < len(self._rows):
            return None
        row = self._rows[index.row()]
        key = (id(row), index.column())
        if key in self._sample_link_cache:
            self._sample_link_cache.move_to_end(key)
            return self._sample_link_cache[key]
        resolved = self.navigation(index)
        if resolved is None:
            return None
        navigation, targets = resolved
        by_label = {}
        for target in targets:
            label = str(target.get("sample_label", "")).strip()
            if label:
                by_label.setdefault(label, []).append(target)
        parts = []
        for token in self._value(row, index.column()).split(";"):
            label = token.strip()
            matches = by_label.get(label, ())
            if not matches:
                parts.append({"label": label, "target": None, "plain_suffix": ""})
                continue
            fields = []
            if len(matches) > 1:
                identity_fields = list(dict.fromkeys([
                    *navigation.get("sample_dimensions", []),
                    *(field for target in matches for field in target["conditions"]),
                ]))
                fields = [field for field in identity_fields if len({
                    str(target["conditions"].get(field, "")) for target in matches
                }) > 1] or identity_fields
            for target in matches:
                suffix = ""
                if fields:
                    suffix = " (" + ", ".join(
                        f"{field}={target['conditions'].get(field, '')}" for field in fields
                    ) + ")"
                parts.append({"label": label, "target": target, "plain_suffix": suffix})
        result = (navigation, tuple(parts))
        self._sample_link_cache[key] = result
        if len(self._sample_link_cache) > self.SAMPLE_LINK_CACHE_LIMIT:
            self._sample_link_cache.popitem(last=False)
        return result

    def set_rows(self, rows):
        self._all_rows = list(rows)  # Only row references; cell strings stay lazy.
        self._reset_visible_rows()

    def set_search_text(self, text):
        query = text.strip().casefold()
        if query == self._search_text:
            return
        self._search_text = query
        self._reset_visible_rows()

    def total_row_count(self):
        return len(self._all_rows)

    def column_filter(self, column):
        return self._column_filters.get(column)

    def set_column_filter(self, column, values):
        if not 0 <= column < self.columnCount():
            return
        selected = None if values is None else frozenset(str(value) for value in values)
        if selected == self.column_filter(column):
            return
        if selected is None:
            self._column_filters.pop(column, None)
        else:
            self._column_filters[column] = selected
        self._reset_visible_rows()

    def clear_column_filters(self):
        if self._column_filters:
            self._column_filters.clear()
            self._reset_visible_rows()

    def has_column_filters(self):
        return bool(self._column_filters)

    def column_values(self, column):
        """Offer values allowed by the search and all other column filters."""
        if not 0 <= column < self.columnCount():
            return []
        values = {self._value(row, column) for row in self._all_rows
                  if (not self._search_text or self._matches_search(row))
                  and self._matches_column_filters(row, excluding=column)}
        return sorted(values, key=lambda value: (self._natural_sort_key(value), value))

    def all_column_values(self, column):
        if not 0 <= column < self.columnCount():
            return set()
        return {self._value(row, column) for row in self._all_rows}

    def _matches_column_filters(self, row, excluding=None):
        return all(self._value(row, column) in values
                   for column, values in self._column_filters.items() if column != excluding)

    def _matches_search(self, row):
        if any(self._search_text in str(row.get(field, "")).casefold() for field in self.FIELDS):
            return True
        return any(
            self._search_text in str(value).casefold()
            for pair in row.get("lot_sample_pairs", [])
            if isinstance(pair, (tuple, list)) and len(pair) >= 2
            for value in pair[:2]
        )

    def _reset_visible_rows(self):
        self.beginResetModel()
        self._sample_link_cache.clear()
        self._lot_columns = 2 * max((len(row.get("lot_sample_pairs", [])) for row in self._all_rows), default=0)
        self._column_filters = {column: values for column, values in self._column_filters.items()
                                if 0 <= column < self.columnCount()}
        self._rows = [row for row in self._all_rows
                      if (not self._search_text or self._matches_search(row))
                      and self._matches_column_filters(row)]
        if 0 <= self._sort_column < self.columnCount():
            self._rows.sort(key=lambda row: self._sort_key(row, self._sort_column),
                            reverse=self._sort_order == Qt.DescendingOrder)
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self._rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.FIELDS) + self._lot_columns

    def _value(self, row, column):
        if column < len(self.FIELDS):
            return str(row.get(self.FIELDS[column], ""))
        pair_index, member = divmod(column - len(self.FIELDS), 2)
        pairs = row.get("lot_sample_pairs", [])
        if pair_index < len(pairs):
            pair = pairs[pair_index]
            if isinstance(pair, (tuple, list)) and len(pair) >= 2:
                return str(pair[member])
        return ""

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < len(self._rows):
            return None
        if role == Qt.DisplayRole:
            return self._value(self._rows[index.row()], index.column())
        if role == Qt.ToolTipRole:
            links = self.sample_links(index)
            if links and any(part["target"] is not None for part in links[1]):
                return "Click an underlined sample ID to view its related plots. Semicolons separate sample IDs."
            if index.column() >= len(self.FIELDS) and (index.column() - len(self.FIELDS)) % 2 == 1 and self._value(self._rows[index.row()], index.column()):
                return "Run Analysis again to enable sample links for this saved result."
        return None

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Vertical:
            return str(section + 1)
        if section < len(self.HEADERS):
            return self.HEADERS[section]
        pair_index, member = divmod(section - len(self.HEADERS), 2)
        return f"{'Lot' if member == 0 else 'Sample IDs'} {pair_index + 1}"

    def _sort_key(self, row, column):
        return self._natural_sort_key(self._value(row, column))

    @staticmethod
    def _natural_sort_key(value):
        return tuple((0, int(part)) if part.isdigit() else (1, part.lower())
                     for part in re.split(r"(\d+)", value) if part)

    def sort(self, column, order=Qt.AscendingOrder):
        self._sort_column, self._sort_order = column, order
        if not 0 <= column < self.columnCount():
            return
        old_indexes = self.persistentIndexList()
        old_rows = [self._rows[index.row()] for index in old_indexes]
        self.layoutAboutToBeChanged.emit()
        self._rows.sort(key=lambda row: self._sort_key(row, column), reverse=order == Qt.DescendingOrder)
        positions = {id(row): i for i, row in enumerate(self._rows)} if old_indexes else {}
        self.changePersistentIndexList(old_indexes, [self.index(positions[id(row)], index.column())
                                                    for row, index in zip(old_rows, old_indexes)])
        self.layoutChanged.emit()
