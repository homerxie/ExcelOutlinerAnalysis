"""Qt heatmaps and probability contrasts for an explicitly calculated slice."""
from __future__ import annotations

import math

from PySide6.QtCore import QEvent, QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QPainter, QPen, QTextLayout, QTextOption
from PySide6.QtWidgets import QAbstractScrollArea, QToolTip

from ..tsk_sorting import natural_sort_key
from .tsk_plot import TskRiskPlot, _TskPlot, _percentage, _probability
from .tsk_risk_display import boundary_note, risk_interval_text, risk_probability_text


def _finite(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)


def _points(value):
    return f"{100 * value:+.4f} pp" if _finite(value) else "—"


def _relative_luminance(color):
    channels = [value / 12.92 if value <= .04045 else ((value + .055) / 1.055) ** 2.4
                for value in color.getRgbF()[:3]]
    return sum(value * weight for value, weight in zip(channels, (.2126, .7152, .0722)))


class TskCombinationHeatmap(_TskPlot):
    cell_selected = Signal(str, str)

    @staticmethod
    def _row_key(row):
        # Legacy views distinguish columns by level; current views preserve the
        # complete original condition even when dimensions move between axes.
        if "categories" not in row:
            return (str(row.get("tsk_id", "")), str(row.get("level", "")))
        return _TskPlot._row_key(row)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.levels = []
        self.type_ids = []
        self.column_keys = []
        self.row_keys = []
        self.row_labels = []
        self.column_axis_title = ""
        self.row_axis_title = ""
        self.column_tooltips = []
        self.row_tooltips = []
        self._matrix_view = False
        self._records = {}
        self.display_metric = "probability"
        self._cells = []
        self._header_layouts = []
        self._header_regions = []
        self._row_label_layouts = []
        self._row_label_regions = []
        self._axis_title_regions = []
        self._header_viewport = None
        self._row_heights = []

    def set_view(self, view):
        """Show one row per condition, preserving its identity across axis layouts.

        Matrix views supply ordered tuple keys and separate display labels for
        each axis. The original probability rows carry the matching private
        keys; their TSK and complete condition remain the tooltip/click identity.
        Legacy views retain the TSK-by-level layout.
        """
        view = view or {}
        self.rows = list(view.get("rows", []))
        self._rebind_selection()
        self.column_axis_title = str(view.get("column_axis_title", ""))
        self.row_axis_title = str(view.get("row_axis_title", ""))
        self._matrix_view = "column_keys" in view and "row_keys" in view
        if self._matrix_view:
            self.column_keys = [tuple(key) for key in view["column_keys"]]
            self.row_keys = [tuple(key) for key in view["row_keys"]]
            self.levels = [str(label) for label in view.get("column_labels", [])]
            self.row_labels = [str(label) for label in view.get("row_labels", [])]
            self._records = {
                (tuple(row["_heatmap_row_key"]), tuple(row["_heatmap_column_key"])): row
                for row in self.rows
            }
        else:
            self.levels = list(view.get("levels", []))
            self.row_labels = sorted(dict.fromkeys(str(row["tsk_id"]) for row in self.rows), key=natural_sort_key)
            self.column_keys = [(str(level),) for level in self.levels]
            self.row_keys = [(tsk_id,) for tsk_id in self.row_labels]
            self._records = {
                ((str(row["tsk_id"]),), (str(row["level"]),)): row
                for row in self.rows
            }
        # Keep these public names compatible with existing heatmap consumers.
        self.type_ids = list(self.row_labels)
        self.column_tooltips = list(view.get("column_tooltips", self.levels))
        self.row_tooltips = list(view.get("row_tooltips", self.row_labels))
        self.setProperty("confidenceLevel", float(view.get("confidence_level", .95)))
        self._cells = []
        self._hit_regions = []
        self._header_regions = []
        self._row_label_regions = []
        self._axis_title_regions = []
        self._update_header_layout()
        self.update()

    def _text_layout(self, text, width, alignment):
        layouts, height = [], 0.
        for paragraph in str(text).split("\n"):
            layout = QTextLayout(paragraph, self.font())
            option = QTextOption(alignment)
            option.setWrapMode(QTextOption.WrapAtWordBoundaryOrAnywhere)
            layout.setTextOption(option)
            layout.beginLayout()
            while True:
                line = layout.createLine()
                if not line.isValid():
                    break
                line.setLineWidth(width)
                line.setPosition(QPointF(0, height))
                height += line.height()
            layout.endLayout()
            layouts.append(layout)
        return layouts, height

    def _update_header_layout(self):
        minimum_label_width = float(self.property("typeLabelWidth") or 110)
        maximum_label_width = max(minimum_label_width, float(self.property("maximumRowLabelWidth") or 300))
        self._row_label_horizontal_padding = float(self.property("rowLabelHorizontalPadding") or 12)
        row_label_vertical_padding = float(self.property("rowLabelVerticalPadding") or 12)
        metrics = self.fontMetrics()
        natural_label_width = max((metrics.horizontalAdvance(paragraph)
                                   for label in [*self.row_labels, self.row_axis_title]
                                   for paragraph in label.split("\n")), default=0.)
        self._left = max(minimum_label_width,
                         min(maximum_label_width, natural_label_width + self._row_label_horizontal_padding))
        self._row_label_text_width = max(1., self._left - self._row_label_horizontal_padding)
        self._row_height = float(self.property("cellRowHeight") or 42)
        self._row_label_layouts = [self._text_layout(label, self._row_label_text_width, Qt.AlignRight)
                                   for label in self.row_labels]
        self._row_heights = [max(self._row_height, math.ceil(height + row_label_vertical_padding))
                             for _, height in self._row_label_layouts]
        minimum_cell_width = float(self.property("minimumCellWidth") or 86)
        right_padding = float(self.property("rightPadding") or 8)
        horizontal_padding = float(self.property("headerHorizontalPadding") or 6)
        self._header_vertical_padding = float(self.property("headerVerticalPadding") or 8)
        minimum_width = math.ceil(self._left + right_padding + minimum_cell_width * len(self.levels))
        available_width = max(float(self.width()), minimum_width) - self._left - right_padding
        self._cell_width = max(minimum_cell_width, available_width / max(1, len(self.levels)))
        self._header_text_width = max(1., self._cell_width - horizontal_padding)
        self._header_horizontal_padding = horizontal_padding
        self._header_layouts = [self._text_layout(level, self._header_text_width, Qt.AlignHCenter)
                                for level in self.levels]
        title_padding = float(self.property("axisTitleVerticalPadding") or 8)
        viewport = self.parentWidget()
        area = viewport.parentWidget() if viewport is not None else None
        viewport = viewport if isinstance(area, QAbstractScrollArea) and area.viewport() is viewport else None
        if viewport is not self._header_viewport:
            if self._header_viewport is not None:
                self._header_viewport.removeEventFilter(self)
            self._header_viewport = viewport
            if viewport is not None:
                viewport.installEventFilter(self)
        # A wide matrix keeps its full canvas width while its viewport shrinks.
        # Keep the shared name readable before the user scrolls to later columns.
        visible_width = float(viewport.width() if viewport is not None else self.width())
        self._column_title_text_width = max(1., min(
            float(self.property("maximumAxisTitleWidth") or 620),
            available_width - horizontal_padding,
            visible_width - self._left - right_padding - horizontal_padding))
        self._column_title_layouts, column_title_height = self._text_layout(
            self.column_axis_title, self._column_title_text_width, Qt.AlignLeft)
        self._row_title_layouts, self._row_title_text_height = self._text_layout(
            self.row_axis_title, self._row_label_text_width, Qt.AlignRight)
        self._axis_title_height = (max(float(self.property("minimumAxisTitleHeight") or 30),
                                      math.ceil(column_title_height + title_padding))
                                   if self.column_axis_title else 0.)
        self._column_title_text_height = column_title_height
        maximum_height = max((height for _, height in self._header_layouts), default=0.)
        self._header_height = max(
            self._axis_title_height + max(float(self.property("minimumHeaderHeight") or 37),
                                          math.ceil(maximum_height + self._header_vertical_padding)),
            math.ceil(self._row_title_text_height + title_padding) if self.row_axis_title else 0.)
        minimum_height = max(int(self.property("minimumCanvasHeight") or 160),
                             math.ceil(self._header_height + sum(self._row_heights)
                                       + float(self.property("bottomPadding") or 25)))
        self.setMinimumSize(minimum_width, minimum_height)

    def resizeEvent(self, event):
        self._update_header_layout()
        super().resizeEvent(event)

    def changeEvent(self, event):
        if event.type() == QEvent.FontChange:
            self._update_header_layout()
        super().changeEvent(event)

    def eventFilter(self, watched, event):
        if watched is self._header_viewport and event.type() == QEvent.Resize:
            self._update_header_layout()
            self.update()
        return super().eventFilter(watched, event)

    def event(self, event):
        if event.type() == QEvent.ToolTip:
            for region, text in [*self._axis_title_regions, *self._header_regions, *self._row_label_regions]:
                if region.contains(event.pos()):
                    QToolTip.showText(event.globalPos(), text, self)
                    return True
        return super().event(event)

    def set_metric(self, metric):
        self.display_metric = metric
        self.update()

    @staticmethod
    def _gradient_color(fraction, stops):
        position = max(0., min(1., fraction)) * (len(stops) - 1)
        index = min(int(position), len(stops) - 1)
        start, end = stops[index], stops[min(index + 1, len(stops) - 1)]
        weight = position - index
        return QColor.fromRgbF(*(a + (b - a) * weight
                                 for a, b in zip(start.getRgbF()[:3], end.getRgbF()[:3])))

    def _cell_text_color(self, fill, background):
        # Include alpha blending for unavailable grey cells; valid cells are opaque.
        alpha = fill.alphaF()
        effective = QColor.fromRgbF(*(a * alpha + b * (1. - alpha)
                                      for a, b in zip(fill.getRgbF()[:3], background.getRgbF()[:3])))
        luminance = _relative_luminance(effective)
        candidates = [QColor(self.property("lightCellTextColor") or Qt.black),
                      QColor(self.property("darkCellTextColor") or Qt.white)]

        def contrast(color):
            other = _relative_luminance(color)
            return (max(luminance, other) + .05) / (min(luminance, other) + .05)

        return max(candidates, key=contrast)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            for region, row in self._cells:
                if region.contains(event.position()):
                    self.set_selected_row(row)
                    self.cell_selected.emit(str(row["tsk_id"]), str(row["level"]))
                    self.row_selected.emit(row)
                    event.accept()
                    return
        super().mousePressEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        colors = self._colors()
        painter.fillRect(self.rect(), colors["background"])
        self._hit_regions = []
        self._cells = []
        self._header_regions = []
        self._row_label_regions = []
        self._axis_title_regions = []
        if not self.rows or not self.levels:
            self._empty(painter, colors)
            return
        left, top = self._left, self._header_height
        cell_width = self._cell_width
        values = [row.get(self.display_metric) if self.display_metric != "support" else row.get("active_instance_count")
                  for row in self.rows]
        maximum = max((float(value) for value in values if _finite(value)), default=0.) or 1.
        stops = [QColor(value) for value in (self.property("colorStops") or [])]
        stops = [color for color in stops if color.isValid()] or [colors["series"]]
        painter.setPen(colors["ink"])
        if self.column_axis_title:
            title_region = QRectF(left + self._header_horizontal_padding / 2,
                                  (self._axis_title_height - self._column_title_text_height) / 2,
                                  self._column_title_text_width,
                                  self._column_title_text_height)
            for layout in self._column_title_layouts:
                layout.draw(painter, title_region.topLeft())
            self._axis_title_regions.append((title_region, self.column_axis_title))
            painter.setPen(QPen(colors["grid"], 1))
            painter.drawLine(QPointF(left, self._axis_title_height),
                             QPointF(left + cell_width * len(self.levels), self._axis_title_height))
        if self.row_axis_title:
            title_region = QRectF(self._row_label_horizontal_padding / 2,
                                  (top - self._row_title_text_height) / 2,
                                  self._row_label_text_width, self._row_title_text_height)
            painter.setPen(colors["ink"])
            for layout in self._row_title_layouts:
                layout.draw(painter, title_region.topLeft())
            self._axis_title_regions.append((title_region, self.row_axis_title))
        for column, level in enumerate(self.levels):
            painter.setPen(colors["ink"])
            layouts, height = self._header_layouts[column]
            region = QRectF(left + column * cell_width + self._header_horizontal_padding / 2,
                            self._axis_title_height + (top - self._axis_title_height - height) / 2,
                            self._header_text_width, height)
            for layout in layouts:
                layout.draw(painter, region.topLeft())
            self._header_regions.append((region, str(self.column_tooltips[column])))
        row_top = top
        for row_index, row_key in enumerate(self.row_keys):
            row_height = self._row_heights[row_index]
            layouts, height = self._row_label_layouts[row_index]
            label_region = QRectF(self._row_label_horizontal_padding / 2,
                                  row_top + (row_height - height) / 2,
                                  self._row_label_text_width, height)
            painter.setPen(colors["ink"])
            for layout in layouts:
                layout.draw(painter, label_region.topLeft())
            self._row_label_regions.append((label_region, self.row_tooltips[row_index]))
            for column, column_key in enumerate(self.column_keys):
                row = self._records.get((row_key, column_key))
                region = QRectF(left + column * cell_width, row_top, cell_width - 3, row_height - 3)
                no_data = row is not None and row.get("status") == "no_data"
                value = None if row is None else row.get("active_instance_count") if self.display_metric == "support" else row.get("probability")
                valid = not no_data and (_finite(value) if self.display_metric == "support" else row is not None and row.get("identifiable", True) and _probability(value))
                fill = QColor(colors["grid"])
                fill.setAlpha(65)
                if no_data:
                    fill = QColor(colors["background"])
                elif valid:
                    fill = self._gradient_color(float(value) / maximum, stops)
                text_color = self._cell_text_color(fill, colors["background"])
                painter.fillRect(region, fill)
                if no_data:
                    painter.setPen(QPen(colors["grid"], 1))
                    painter.drawRect(region)
                elif row and row.get("support_status") not in {None, "observed"}:
                    hatch = QColor(text_color)
                    hatch.setAlpha(70)
                    painter.fillRect(region, QBrush(hatch, Qt.BDiagPattern))
                painter.setPen(text_color)
                text = "" if no_data else f"{int(value)}" if valid and self.display_metric == "support" else risk_probability_text(self, row, precision=2) if valid else "—"
                painter.drawText(region, Qt.AlignCenter, text)
                if row:
                    if self._row_key(row) == self._selected_key:
                        line_width = float(self.property("selectionOutlineWidth") or 2)
                        painter.setBrush(Qt.NoBrush)
                        painter.setPen(QPen(text_color, line_width))
                        inset = line_width / 2
                        painter.drawRect(region.adjusted(inset, inset, -inset, -inset))
                    detail = str(self.property("tooltipFormat") or "{tsk_id} · {level}").format(
                        tsk_id=row["tsk_id"], level=row["level"],
                        probability=risk_probability_text(self, row),
                        interval=risk_interval_text(self, row), boundary_note=boundary_note(self, row),
                        support=self.property("noDataSupportText") if no_data else row.get("support_status", "—"),
                        layout=row.get("layout_instance_count", "—"),
                        active=row.get("active_instance_count", "—"), chains=row.get("chain_count", "—"),
                        exposure=row.get("chain_test_exposure", "—"), interval_method=row.get("interval_method") or "—", interval_error=row.get("interval_error") or "—",
                        chain_details=row.get("combination_chain_tooltip", ""))
                    self._hit_regions.append((region, detail))
                    self._cells.append((region, row))
            row_top += row_height


class TskDifferencePlot(TskRiskPlot):
    def set_rows(self, rows):
        super().set_rows([{**row, "label": row.get("label", row.get("level", ""))} for row in rows],
                         preserve_order=True)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        colors = self._colors()
        painter.fillRect(self.rect(), colors["background"])
        self._hit_regions = []
        self._label_regions = []
        if not self.rows:
            self._empty(painter, colors)
            return
        metrics = painter.fontMetrics()
        label_width = self._label_width
        value_width = max(70., metrics.horizontalAdvance("+100.00 pp") + 10)
        left, right, top = label_width + 6, self.width() - value_width - 8, 14.
        bottom = top + sum(self._row_heights)
        width = max(16., right - left)
        maximum = max(.01, max((abs(float(row[key])) for row in self.rows
                                for key in ("delta_probability", "delta_ci_lower", "delta_ci_upper")
                                if _finite(row.get(key))), default=0.) * 1.12)
        scale = lambda value: left + (value + maximum) / (2 * maximum) * width
        ticks = 2 if width < 230 else 4
        for index in range(ticks + 1):
            value = maximum * (2 * index / ticks - 1)
            x = scale(value)
            painter.setPen(QPen(colors["grid"], 1, Qt.DashLine if index == ticks // 2 else Qt.SolidLine))
            painter.drawLine(QPointF(x, top), QPointF(x, bottom))
            painter.setPen(colors["muted"])
            alignment = Qt.AlignLeft if index == 0 else Qt.AlignRight if index == ticks else Qt.AlignHCenter
            tick = QRectF(x if index == 0 else x - 55 if index == ticks else x - 27.5, bottom + 3, 55, 18)
            painter.drawText(tick, alignment | Qt.AlignVCenter, f"{100 * value:+.2f}")
        painter.setPen(colors["ink"])
        painter.drawText(QRectF(left - 8, bottom + 24, width + 16, 20), Qt.AlignCenter, str(self.property("axisLabel") or ""))
        row_top = top
        for index, row in enumerate(self.rows):
            row_height = self._row_heights[index]
            center = row_top + row_height / 2
            level = str(row.get("level", ""))
            painter.setPen(colors["ink"])
            self._draw_row_label(painter, index, str(row.get("label", level)), center)
            value, low, high = row.get("delta_probability"), row.get("delta_ci_lower"), row.get("delta_ci_upper")
            if _finite(value):
                painter.setPen(QPen(colors["ink"], 1.5))
                if _finite(low) and _finite(high):
                    painter.drawLine(QPointF(scale(low), center), QPointF(scale(high), center))
                    for bound in (low, high):
                        painter.drawLine(QPointF(scale(bound), center - 5), QPointF(scale(bound), center + 5))
                painter.setBrush(colors["series"])
                painter.setPen(QPen(colors["series"], 1))
                painter.drawEllipse(QPointF(scale(value), center), 4., 4.)
                painter.setPen(colors["ink"])
                painter.drawText(QRectF(right + 6, center - 10, value_width, 20), Qt.AlignLeft | Qt.AlignVCenter, f"{100 * value:+.3f}")
            else:
                painter.setPen(colors["muted"])
                text_property = ("noDataText" if row.get("status") == "no_data" else
                                 "referenceUnavailableText" if row.get("delta_status") == "no_data" else "unavailableText")
                painter.drawText(QRectF(left + 4, center - 11, self.width() - left - 8, 22), Qt.AlignLeft | Qt.AlignVCenter,
                                 str(self.property(text_property) or "") if text_property == "noDataText" else str(self.property(text_property) or "—"))
            detail = str(self.property("tooltipFormat") or "{level}: {delta}").format(
                level=level, delta=_points(value), interval=f"{_points(low)} – {_points(high)}",
                status=self.property("boundaryIntervalUnavailableText") if row.get("delta_status") == "boundary_interval_unavailable" else row.get("delta_status", ""),
                interval_error=row.get("delta_interval_error") or "—")
            self._hit_regions.append((QRectF(0, row_top, self.width(), row_height), detail))
            row_top += row_height
