# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_heatmap_axis_selector.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QLabel, QSizePolicy,
    QToolButton, QWidget)

class Ui_TskHeatmapAxisSelectorForm(object):
    def setupUi(self, TskHeatmapAxisSelectorForm):
        if not TskHeatmapAxisSelectorForm.objectName():
            TskHeatmapAxisSelectorForm.setObjectName(u"TskHeatmapAxisSelectorForm")
        TskHeatmapAxisSelectorForm.setMinimumSize(QSize(140, 0))
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(TskHeatmapAxisSelectorForm.sizePolicy().hasHeightForWidth())
        TskHeatmapAxisSelectorForm.setSizePolicy(sizePolicy)
        self.selectorLayout = QHBoxLayout(TskHeatmapAxisSelectorForm)
        self.selectorLayout.setSpacing(8)
        self.selectorLayout.setObjectName(u"selectorLayout")
        self.selectorLayout.setContentsMargins(0, 0, 0, 0)
        self.axisLabel = QLabel(TskHeatmapAxisSelectorForm)
        self.axisLabel.setObjectName(u"axisLabel")
        self.axisLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.selectorLayout.addWidget(self.axisLabel)

        self.axisButton = QToolButton(TskHeatmapAxisSelectorForm)
        self.axisButton.setObjectName(u"axisButton")
        self.axisButton.setEnabled(False)
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.axisButton.sizePolicy().hasHeightForWidth())
        self.axisButton.setSizePolicy(sizePolicy1)
        self.axisButton.setMinimumSize(QSize(80, 0))
        self.axisButton.setArrowType(Qt.ArrowType.DownArrow)
        self.axisButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.axisButton.setProperty(u"summaryPadding", 36)

        self.selectorLayout.addWidget(self.axisButton)

#if QT_CONFIG(shortcut)
        self.axisLabel.setBuddy(self.axisButton)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(TskHeatmapAxisSelectorForm)

        QMetaObject.connectSlotsByName(TskHeatmapAxisSelectorForm)
    # setupUi

    def retranslateUi(self, TskHeatmapAxisSelectorForm):
        self.axisLabel.setText(QCoreApplication.translate("TskHeatmapAxisSelectorForm", u"\u8f74\u7c7b\u522b", None))
        self.axisButton.setText(QCoreApplication.translate("TskHeatmapAxisSelectorForm", u"\u5168\u90e8\u7ec4\u5408", None))
        self.axisButton.setProperty(u"emptyText", QCoreApplication.translate("TskHeatmapAxisSelectorForm", u"\u5168\u90e8\u7ec4\u5408", None))
        self.axisButton.setProperty(u"dimensionSeparator", QCoreApplication.translate("TskHeatmapAxisSelectorForm", u" \u2192 ", None))
#if QT_CONFIG(tooltip)
        self.axisButton.setToolTip(QCoreApplication.translate("TskHeatmapAxisSelectorForm", u"\u52fe\u9009\u672c\u8f74\u7ef4\u5ea6\uff1b\u5728\u4e0b\u62c9\u5217\u8868\u4e2d\u4e0a\u4e0b\u79fb\u52a8\u53ef\u8c03\u6574\u7ec4\u5408\u987a\u5e8f\u3002", None))
#endif // QT_CONFIG(tooltip)
        pass
    # retranslateUi

