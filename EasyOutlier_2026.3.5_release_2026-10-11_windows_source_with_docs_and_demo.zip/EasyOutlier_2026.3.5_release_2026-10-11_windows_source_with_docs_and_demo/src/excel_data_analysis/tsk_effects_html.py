"""Read-only feature-effect views for the standalone TSK HTML report."""

FEATURE_EFFECTS_SCRIPT = r'''
function effectBoundaryText(row,pairs=false){
    const state=row?.boundary_state,basis=row?.direction_basis;
    if(!['fitted_boundary','fixed_zero_assumption','type_only_boundary'].includes(basis))return '';
    if(!pairs){
        if(state==='lower'&&row.boundary_probability===0)return basis==='fixed_zero_assumption'?'触及下边界，强制 p=0（低风险）':'拟合触及下边界（p=0，低风险）';
        if(state==='upper'&&row.boundary_probability===1)return '拟合 p=1（高风险边界）';
        return '';
    }
    if(state==='both_lower')return '两者均为 p=0；不排序';
    if(state==='both_upper')return '两者均为 p=1；不排序';
    const expected={a_lower:'b_higher',b_lower:'b_lower',a_upper:'b_lower',b_upper:'b_higher',lower_upper:'b_higher',upper_lower:'b_lower'};
    if(!expected[state]||row.direction!==expected[state])return '';
    return {a_lower:'A：p=0（低风险）；B 较高',b_lower:'B：p=0（低风险）；A 较高',
        a_upper:'A：p=1（高风险）；B 较低',b_upper:'B：p=1（高风险）；A 较低',
        lower_upper:'A：p=0；B：p=1（A 低、B 高）',upper_lower:'A：p=1；B：p=0（A 高、B 低）'}[state];
}
function effectBoundaryTooltip(row=null){
    return (row?.level_a!==undefined?'A：'+row.level_a+'\nB：'+row.level_b+'\n':'')+
        '风险边界描述拟合点估计或明确的固定零约束，不是显著性结论。拟合 p=0 不证明真实风险为 0；两者均为零边界时不能据此排序，也不证明真实风险相等。只有明确 p=1 才显示高风险边界；不可识别或未收敛不会推断方向。'+(row?.boundary_note?'\n'+row.boundary_note:'');
}
function effectBoundaryPairStatus(row){
    return row.boundary_state==='both_lower'?'两者零边界；无有限对比':
        row.boundary_state==='both_upper'?'两者高风险边界；无有限对比':'仅边界方向；无有限系数差';
}
function effectRowReason(row){
    const reason=String(row.reason||''),note=row.boundary_note;
    return (note&&reason.endsWith(note)?reason.slice(0,-note.length).trim():reason)||'—';
}
function effectConclusion(row) {
    if(row?.status==='simulation_experimental'&&finite(row.p_adjusted))return row.experimental_significant===true?'影响显著':row.experimental_significant===false?'尚未检出显著影响':'无法判断';
    if(row?.status==='boundary_uncalibrated')return '边界检验未校准';
    if(row?.status!=='ok'||!finite(row?.p_adjusted))return '无法判断';
    return row?.significant === true ? '影响显著' : row?.significant === false ? '尚未检出显著影响' : '无法判断';
}
function effectPairConclusion(row) {
    if(row?.status==='fixed_zero_assumption')return '强制归零；不提供有限比较';
    if(effectBoundaryText(row,true))return effectBoundaryPairStatus(row);
    if(row?.status==='point_estimate_only'&&finite(row.difference))return '仅点估计；差异尚未检验';
    if(row?.status!=='ok'||!finite(row?.p_adjusted))return '无法判断';
    if (row.significant === true && finite(row.difference) && row.difference!==0) return row.difference > 0 ? row.level_b+' 高于 '+row.level_a : row.level_b+' 低于 '+row.level_a;
    return row.significant === false ? '尚未检出明确差异；先后不确定' : '无法判断';
}
function effectEstimateStatus(row) {
    if(row.status==='fixed_zero_assumption')return '强制归零；不提供有限比较';
    if(effectBoundaryText(row,true))return effectBoundaryPairStatus(row);
    if(effectBoundaryText(row))return '边界估计；无有限系数';
    if(row.status==='reference_coding')return '参考档（固定 0）';
    if(row.status==='ok')return '可估计';
    return row.status==='point_estimate_only'&&finite(row.coefficient??row.difference)?'仅点估计':'无法判断';
}
function effectSummary(features) {
    const estimated=features.filter(feature=>(feature.levels||[]).some(row=>!row.reference&&finite(row.coefficient))||
        (feature.pairwise||[]).some(row=>finite(row.difference))).length;
    const deletion=features.filter(feature=>feature.deletion_impact?.status==='ok').length;
    const significant=features.filter(feature=>effectConclusion(feature.lrt)==='影响显著').length;
    const uncalibrated=features.filter(feature=>feature.lrt?.status==='boundary_uncalibrated').length;
    const unavailable=features.filter(feature=>effectConclusion(feature.lrt)==='无法判断').length;
    return features.length+' 个特征 · '+estimated+' 个有点估计 · '+deletion+' 个有删除预测变化 · '+significant+' 个整体显著 · '+uncalibrated+' 个检验未校准 · '+unavailable+' 个无法判断（整体检验）';
}
function effectInterval(row, odds=false) {
    const lower=odds?row.or_ci_lower:row.ci_lower, upper=odds?row.or_ci_upper:row.ci_upper;
    return finite(lower)&&finite(upper)?'['+number(lower)+', '+number(upper)+']':'—';
}
function effectOddsTooltip(feature,pairs,row=null,interval=false,conditional=false){
    let direction;
    if(pairs)direction=row?'本行比较：'+row.level_b+' 相对 '+row.level_a+'（后档 / 前档）。':'比较方向：后档位 B 相对前档位 A。';
    else if(feature.kind==='numeric')direction='比较方向：数值增加一个 scale 后，相对增加前的条件。';
    else direction=row?'本行比较：'+row.level+' 相对参考档 '+feature.reference_level+'。':'比较方向：当前档位相对参考档 '+feature.reference_level+'。';
    return '固定其他条件，失效优势 odds = p/(1−p) = 失效率 ÷ 通过率。\n'+
        'OR = 对比条件的 odds ÷ 参考条件的 odds = exp(系数差)。\n'+direction+'\n'+
        'OR=1 表示优势相同；>1 更高，<1 更低。OR 是倍数，不是相减的变化量；OR=2 不代表失效率一定变为 2 倍。'+
        (feature.role==='tsk_type'?'\n在相同类别和数值条件下比较 TSK 类型截距；点估计来自同一个联合拟合；可用的普通区间使用该拟合的联合协方差，无需逐对重新拟合。':'')+
        (conditional?'\n这是固定零处理后、其余 TSK 的条件效应；OR 及其区间不适用于固定零风险 TSK。':'')+
        (interval?'\n此处是 OR 的逐项置信区间；包含 1 表示该区间允许无差异，最终显著性以 Holm 校正 p 值为准。仅点估计时没有已校准的区间或显著性结论。':'');
}
function effectOverviewTooltips(report){
    const threshold=number(report.alpha??(1-(report.confidence_level??.95)));
    if(report.inference_mode==='free_boundary_simulation')return {
        statistic:'观测 D：完整模型与删特征模型均保持零风险自由并重新拟合。',
        p_value:'实验性模拟尾部概率；尚未完成校准验证，不是正式显著性。',
        p_adjusted:'对各特征实验性模拟 p 作 Holm 校正；校正不替代方法校准。',
        significant:'Holm 模拟 p ≤ '+threshold+' 判为影响显著；尚未检出显著影响仅表示证据不足，不等于没有影响。结论用语与固定零模式一致，当前模拟方法尚未完成校准验证，仅供探索。缺少有效的校正结果时无法判断。',
        mean_change:'删特征并重新拟合后的单实例预测绝对差均值，单位百分点。',
        max_change:'删特征并重新拟合后的单实例预测绝对差最大值，单位百分点。'};
    return {
        statistic:'D = 2 ×（删去该特征并重拟合后的负对数似然 − 完整模型的负对数似然）。越大说明删去后拟合损失越大，不是失效率变化百分比。边界下可显示 D，但未经分布校准不能据此判断显著性。',
        df:'常规内部解下，两模型独立可估计参数数量之差决定 D 对应的卡方分布。L 档类别通常为 L−1，单个数值特征通常为 1；不是样本数。边界分布未校准时留空。',
        p_value:'假设该特征没有额外解释能力，出现当前或更大 D 的近似概率。越小，反对该假设的证据越强；尚未做多重检验校正，不是“该特征无影响的概率”。边界分布未校准时留空。',
        p_adjusted:'同一节点／批次全部特征的整体检验经 Holm 多重校正后的 p 值，用于控制多项检验带来的误报风险。最终显著性看此列。',
        significant:'有效检验的 Holm p ≤ '+threshold+'（当前阈值）判为显著，表示存在额外关联证据；不显著只表示证据不足，不等于没有影响。边界检验未校准时不报告显著性；“无法判断”请看检验说明。',
        mean_change:'删去该特征并重新拟合其余参数后，各有效布局实例的预测失效率绝对差等权平均。单位为百分点（pp），只表示变化幅度；不是实测误差或因果效果。',
        max_change:'同一次删去并重拟合后，有效布局实例中预测失效率绝对差的最大值，表示变化最大的实例。单位为百分点（pp），不表示所有实例都改变这么多，也不表示升降方向。',
    };
}
function effectPlot(parent, rows, pairs, conditional=false) {
    const usable=rows.filter(row=>finite(pairs?row.difference:row.coefficient)||effectBoundaryText(row,pairs));
    if(!usable.length){empty(parent,'没有可显示的系数或差值估计。');return;}
    const s=state(), range=pager(parent,usable.length,24,s.effectsPlotPage||1,value=>{s.effectsPlotPage=value;renderMain();});
    const shown=usable.slice(...range), host=el('div');parent.append(host);
    const width=Math.max(320,parent.clientWidth-4), left=Math.min(210,Math.max(90,width*.22)), right=width-24;
    const values=[0,...shown.flatMap(r=>[pairs?r.difference:r.coefficient,r.ci_lower,r.ci_upper].filter(finite))];
    let lo=Math.min(...values),hi=Math.max(...values),padding=(hi-lo||1)*.08;lo-=padding;hi+=padding;
    const x=value=>left+(value-lo)/(hi-lo)*(right-left), top=30, bottom=top+shown.length*51, height=bottom+48;
    const intervalLabel=conditional?'条件逐项置信区间':'逐项置信区间';
    const chart=svg('svg',{viewBox:'0 0 '+width+' '+height,width:'100%',role:'img','aria-label':(pairs?'档位系数差及':'档位系数及')+intervalLabel});
    chart.append(svg('rect',{x:left,y:top-16,width:right-left,height:bottom-top+16,fill:'none',stroke:'var(--line)'}));
    chart.append(svg('line',{x1:x(0),x2:x(0),y1:top-16,y2:bottom,stroke:'var(--muted)','stroke-width':1}));
    const label=(value,attrs)=>{const t=svg('text',{fill:'var(--ink)','font-size':12,...attrs});t.textContent=value;chart.append(t);return t;};
    shown.forEach((row,index)=>{
        const y=top+index*51+5, value=pairs?row.difference:row.coefficient;
        const name=pairs?row.level_b+' − '+row.level_a:String(row.level);
        const maxChars=Math.max(8,Math.floor((left-14)/13));
        label(name.length>maxChars?name.slice(0,maxChars-1)+'…':name,{x:left-10,y:y+4,'text-anchor':'end'});
        if(!finite(value)){
            const detail=label(effectBoundaryText(row,pairs),{x:left+5,y:y+4,fill:'var(--muted)'});
            const title=svg('title');title.textContent=name+'：'+effectBoundaryTooltip(row);detail.append(title);
            return;
        }
        if(!pairs)chart.append(svg('rect',{x:Math.min(x(0),x(value)),y:y-7,width:Math.abs(x(value)-x(0)),height:14,fill:'var(--blue)',opacity:.3}));
        if(finite(row.ci_lower)&&finite(row.ci_upper)) {
            chart.append(svg('line',{x1:x(row.ci_lower),x2:x(row.ci_upper),y1:y,y2:y,stroke:'var(--blue)','stroke-width':2}));
            for(const bound of [row.ci_lower,row.ci_upper])chart.append(svg('line',{x1:x(bound),x2:x(bound),y1:y-5,y2:y+5,stroke:'var(--blue)','stroke-width':2}));
        }
        chart.append(svg('circle',{cx:x(value),cy:y,r:4,fill:'var(--blue)'}));
        const pointOnly=!row.reference&&!(finite(row.ci_lower)&&finite(row.ci_upper));
        const detail=label(number(value)+(row.reference?' · 参考编码':pointOnly?' · 仅点估计':''),{x:left+5,y:y+22});
        const title=svg('title');title.textContent=name+'：'+number(value)+'；'+intervalLabel+' '+effectInterval(row)+
            (pointOnly?'；区间不可用':'')+'；'+(pairs?effectPairConclusion(row):effectEstimateStatus(row))+(row.reason?'；'+row.reason:'');detail.append(title);
    });
    for(let i=0;i<=4;i++){const value=lo+(hi-lo)*i/4;label(Number(value.toPrecision(3)).toString(),{x:x(value),y:bottom+18,'text-anchor':i===0?'start':i===4?'end':'middle'});}
    label(pairs?'系数差（log-odds）；0 表示相同':'档位系数（log-odds）',{x:(left+right)/2,y:bottom+40,'text-anchor':'middle'});
    host.append(chart);
}
function effectAssumptionNotice(parent,report){
    const experimental=report.inference_mode==='free_boundary_simulation';
    const ids=report.fixed_zero_tsk_ids||[];
    const assumption=el('section',null,'notice effects-assumption-banner');assumption.setAttribute('role','note');
    assumption.append(el('span',experimental?'自由边界模拟检验（实验性）；结果尚未完成校准验证，仅供探索。':'已将 '+ids.length+' 个触及下边界的 TSK 强制归零；区间依赖固定约束，真实风险非零时可能有偏差。'));
    const openButton=el('button','查看详情');openButton.setAttribute('type','button');
    openButton.setAttribute('aria-haspopup','dialog');openButton.setAttribute('aria-controls','effects-assumption-dialog');
    const dialog=el('dialog',null,'effects-assumption-dialog');dialog.setAttribute('id','effects-assumption-dialog');
    dialog.setAttribute('aria-labelledby','effects-assumption-title');
    const title=el('h2',experimental?'自由边界模拟检验详情（实验性）':'固定零处理详情');title.setAttribute('id','effects-assumption-title');
    if(experimental){
        const settings=report.simulation_settings||{};
        dialog.append(title,el('p',report.experimental_warning||'尚未完成校准验证；模拟仅用于特征整体检验，不提供正式显著性。'),
            el('p','每个特征请求 '+number(settings.replicates)+' 次模拟；随机种子 '+number(settings.seed)+'。每次重拟合完整与删特征模型，零风险保持自由。'),
            el('p','当前不提供自由零边界下的档位或 TSK 对比区间；有限内点模型保留的普通 Wald 区间并未经过模拟校准。MC 区间仅描述插件原假设尾概率的模拟误差，不是系数或风险区间。'));
        (report.features||[]).forEach(feature=>{
            const lrt=feature.lrt||{},sim=lrt.simulation||{};
            dialog.append(el('h3',feature.feature),el('p',effectConclusion(lrt)),
                el('p','模拟 p：'+number(lrt.p_value)+'；Holm 模拟 p：'+number(lrt.p_adjusted)),
                el('p','完成 '+number(sim.replicates_completed)+' / '+number(sim.replicates_requested)+'；失败 '+number(sim.replicates_failed)+'；超越次数 '+number(sim.exceedances)),
                el('p','MC 区间：'+effectInterval({ci_lower:sim.p_value_mc_lower,ci_upper:sim.p_value_mc_upper})+'；MC 标准误：'+number(sim.p_value_mc_se)),
                el('p','观测完整模型零风险 TSK：'+(sim.observed_full_zero_tsk_ids||[]).join('、')+'；删特征模型：'+(sim.observed_reduced_zero_tsk_ids||[]).join('、')),
                el('p','模拟零集合变化次数：完整模型 '+number(sim.full_zero_mask_changed_count)+'，删特征模型 '+number(sim.reduced_zero_mask_changed_count)));
            if(lrt.reason)dialog.append(el('p',lrt.reason));
        });
        const diagnostics=el('details');diagnostics.append(el('summary','完整模拟诊断与轨迹'),
            el('pre',JSON.stringify({simulation_settings:settings,features:(report.features||[]).map(feature=>({feature:feature.feature,lrt:feature.lrt}))},null,2)));
        dialog.append(diagnostics);
    }
    else dialog.append(title,el('p','固定零处理条件分析'),el('p','强制归零的 TSK：'+ids.join('、')),
        el('p',report.assumption_warning||'这些 TSK 的风险触及计算下边界，本次条件分析将其风险贡献强制固定为 0。若实际风险非零，只是样本不足而未观测到失效，其他因素的效应及区间可能有偏差；区间依赖固定约束，不包含解除该约束的不确定性。'),
        el('p','OR 及其区间只适用于未固定零风险的 TSK，不适用于固定零风险 TSK。'));
    const closeButton=el('button','关闭');closeButton.setAttribute('type','button');closeButton.setAttribute('autofocus','');
    closeButton.addEventListener('click',()=>dialog.close());
    const actions=el('div',null,'actions');actions.append(closeButton);dialog.append(actions);
    openButton.addEventListener('click',()=>dialog.showModal());
    assumption.append(openButton);parent.append(assumption,dialog);
}
function effectChoiceValue(feature){return feature.role==='tsk_type'?{role:'tsk_type'}:feature.feature;}
function effectChoiceKey(value){return JSON.stringify(value?.role==='tsk_type'?['tsk_type']:['feature',value]);}
function renderEffects(parent) {
    const s=state(), g=groups[groupIndex], report=g.feature_effects;
    parent.append(el('h2','特征影响'));
    if(!report){empty(parent,'此历史结果未保存特征影响报告；请在应用中重新运行 TSK Analysis。');return;}
    const conditional=report.inference_mode==='fixed_zero_conditional';
    const simulation=report.inference_mode==='free_boundary_simulation';
    if(conditional||simulation)effectAssumptionNotice(parent,report);
    if(conditional||simulation){
        if(report.reason&&report.status!=='ok'&&!(simulation&&report.status==='simulation_experimental'))notice(parent,report.reason);
        const assumptionWarning=String((simulation?report.experimental_warning:report.assumption_warning)||'').trim();
        const methodNotes=[...new Set((report.warnings||[]).map(value=>String(value).trim()))]
            .filter(value=>value&&value!==assumptionWarning);
        if(methodNotes.length){
            const details=el('details');
            details.append(el('summary','计算方法与补充说明（'+methodNotes.length+' 条）'));
            warnings(details,methodNotes);parent.append(details);
        }
    }else{
        if(report.reason)notice(parent,report.reason);
        if(report.warnings?.length)warnings(parent,report.warnings);
    }
    const features=report.features||[];
    const choices=[...features,...(report.type_effects?[report.type_effects]:[])];
    if(!choices.length){empty(parent,report.reason||'本次没有可检验的特征。');return;}
    if(!s.effectsView)s.effectsView=groupIndex===initial.group_index&&['overall','levels','pairs'].includes(initial.effects_view)?initial.effects_view:'overall';
    if(!features.length&&s.effectsView==='overall')s.effectsView='levels';
    if(!choices.some(f=>effectChoiceKey(effectChoiceValue(f))===effectChoiceKey(s.effectsFeature)))
        s.effectsFeature=choices.some(f=>effectChoiceKey(effectChoiceValue(f))===effectChoiceKey(initial.effects_feature))?initial.effects_feature:effectChoiceValue(choices[0]);
    parent.append(el('p',effectSummary(features)+(simulation?' · '+features.filter(f=>f.lrt?.status==='simulation_experimental').length+' 个完成模拟检验':'')+(report.type_effects?' · '+(report.type_effects.levels||[]).length+' 个 TSK 类型可查看系数与两两比较（不参与删特征整体检验）':''),'caption'));
    parent.append(el('p',simulation?'模拟仅用于特征整体检验，不生成系数区间；模拟 p / Holm 模拟 p 尚未完成校准验证。当前不提供自由零边界下的档位或 TSK 对比区间；有限内点模型保留的普通 Wald 区间并未经过模拟校准。MC 区间仅衡量插件原假设尾概率的模拟误差，不是系数或风险区间。':conditional?
        '将所列 TSK 风险贡献强制固定为 0 后，重新拟合其余 TSK 及其特征效应；以下区间与检验均依赖该固定约束。已计算区间为 '+pct(report.confidence_level||.95)+' 条件逐项区间；条件检验使用 Holm 校正 p 值，阈值 '+number(report.alpha??1-(report.confidence_level||.95))+'。':
        '关注单实例失效；类型截距及共享主效应。可检验时，显著性使用 Holm 校正 p 值，阈值 '+number(report.alpha??1-(report.confidence_level||.95))+'。已计算的区间是逐项 '+pct(report.confidence_level||.95)+' 区间。边界下保留可辨识的点估计及可用的删除预测变化，未校准的检验不报告显著性。','muted'));
    if(report.status==='point_estimate_only')parent.append(el('p','共享 OR 由有信息的条件支持，不能视为已验证了零风险 TSK 的风险倍数。','caption'));
    subTabs(parent,[...(features.length?[['overall','整体影响']]:[]),['levels','档位系数'],['pairs','档位两两比较']],s.effectsView,value=>{s.effectsView=value;s.effectsPlotPage=1;renderMain();});
    if(s.effectsView==='overall') {
        const rows=features.map(feature=>({...feature,...(feature.lrt||{}),deletion:feature.deletion_impact||{}}));
        const help=effectOverviewTooltips(report);
        const explain=(key,impact=false)=>({tooltip:help[key],cellTooltip:row=>{
            const outcome=impact?row.deletion:row;
            return help[key]+(outcome.status!=='ok'&&outcome.reason?'\n本项说明：'+outcome.reason:'');
        }});
        const tableRegion=el('div',null,'effects-table-region');parent.append(tableRegion);
        pagedTable(tableRegion,rows,[
            {key:'feature',title:'特征',format:r=>r.label||r.feature}, {key:'kind',title:'类型',format:r=>r.kind==='spatial'?'空间':r.kind==='categorical'?'类别':'数值'},
            {key:'statistic',title:conditional?'条件似然比 D':'似然比 D',numeric:true,format:r=>number(r.statistic),...explain('statistic')},
            ...(simulation?[]:[{key:'df',title:'自由度',numeric:true,format:r=>number(r.df),...explain('df')}]),
            {key:'p_value',title:simulation?'模拟 p':conditional?'条件原始 p':'原始 p',numeric:true,format:r=>number(r.p_value),...explain('p_value')},
            {key:'p_adjusted',title:simulation?'Holm 模拟 p':conditional?'条件 Holm p':'Holm p',numeric:true,format:r=>number(r.p_adjusted),...explain('p_adjusted')},
            {key:'significant',title:conditional?'条件整体结论':'整体结论',format:effectConclusion,...explain('significant')},
            ...(simulation?[
                {key:'simulation_count',title:'模拟完成 / 请求',format:r=>(r.simulation?.replicates_completed??0)+' / '+(r.simulation?.replicates_requested??0)+'（失败 '+(r.simulation?.replicates_failed??0)+'）'},
                {key:'simulation_mc_se',title:'MC 标准误',format:r=>number(r.simulation?.p_value_mc_se)},
                {key:'simulation_mc_interval',title:'MC 区间',format:r=>effectInterval({ci_lower:r.simulation?.p_value_mc_lower,ci_upper:r.simulation?.p_value_mc_upper})}]:[]),
            {key:'mean_change',title:'删去后平均绝对变化',format:r=>pp(r.deletion.mean_abs_probability_change),...explain('mean_change',true)},
            {key:'max_change',title:'删去后最大绝对变化',format:r=>pp(r.deletion.max_abs_probability_change),...explain('max_change',true)},
            {key:'reason',title:'检验说明',wide:true},
            {key:'deletion_reason',title:'预测变化说明',wide:true,format:r=>r.deletion.reason||'—'}
        ],'特征',row=>{s.effectsFeature=row.feature;s.effectsView='levels';s.effectsPlotPage=1;renderMain();});
        parent.append(el('p','删除后变化按原有效拓扑实例等权统计，是两个拟合模型的预测差；不显著不等于没有作用，预测变化不构成因果或实测实例验证。','caption'));
        return;
    }
    const controls=el('div',null,'row'),select=el('select');select.setAttribute('aria-label','特征 / TSK');
    choices.forEach(feature=>{const name=feature.role==='tsk_type'?'TSK 类型':report.type_effects&&feature.feature==='TSK 类型'?'TSK 类型（特征）':feature.label||feature.feature;
        const option=el('option',name);option.value=effectChoiceKey(effectChoiceValue(feature));select.append(option);});
    select.value=effectChoiceKey(s.effectsFeature);select.addEventListener('change',()=>{
        const selected=choices.find(f=>effectChoiceKey(effectChoiceValue(f))===select.value);
        if(selected)s.effectsFeature=effectChoiceValue(selected);s.effectsPlotPage=1;renderMain();});
    controls.append(el('span','特征 / TSK'),select);parent.append(controls);
    const feature=choices.find(f=>effectChoiceKey(effectChoiceValue(f))===effectChoiceKey(s.effectsFeature)),pairs=s.effectsView==='pairs',isType=feature.role==='tsk_type';
    if(feature.reason)notice(parent,feature.reason);
    if(feature.kind==='spatial'){
        empty(parent,'XY 位置的空间基底作为一个因素整体检验；其效应随坐标变化，没有统一的增加一个 scale 的 OR，也没有离散档位对比。请在整体影响页查看整体检验与删组预测变化，或在特征明细查看基底系数。');return;
    }
    parent.append(el('p',isType?'在相同特征条件下比较 TSK 类型截距；系数相对参考 TSK '+(feature.reference_level??'—')+'，两两差值为 B − A。点估计来自同一个联合拟合；可用的普通区间使用该拟合的联合协方差，无需逐对重新拟合；两两检验按全部 TSK 对比进行 Holm 校正。参考系数 0 是编码约定，固定零风险 TSK 不提供有限 log odds 比较。':
        pairs?'方向为后档位减前档位；可检验时，比较结论按本特征内全部档位对比的 Holm 校正 p 值。仅点估计时，差异尚未检验。':'点估计顺序不保证真实顺序；参考档位 0 是编码约定，不代表零风险。数值特征按增加一个标准化尺度解释。','caption'));
    const rows=feature[pairs?'pairwise':'levels']||[];
    if(!rows.length){empty(parent,isType&&pairs?(feature.reason||'本次未计算 TSK 两两比较。'):
        pairs&&feature.kind==='numeric'?'数值特征没有离散档位的两两比较。':'没有可显示的档位结果。');return;}
    effectPlot(parent,rows,pairs,conditional);
    const columns=pairs?[
        {key:'level_a',title:isType?'TSK A':'前档位 A'},{key:'level_b',title:isType?'TSK B':'后档位 B'},
        {key:'difference',title:'差值 B−A',numeric:true,format:r=>number(r.difference)}
    ]:[{key:'level',title:isType?'TSK 类型':'档位／变化'},{key:'point_rank',title:'点估计序位',numeric:true},
        {key:'coefficient',title:'系数',numeric:true,format:r=>number(r.coefficient)},
        {key:'reference',title:'参考档位',format:r=>r.reference?'是':'否'}];
    if(isType)columns.splice(pairs?2:1,0,{key:'boundary_state',title:'风险边界',format:r=>effectBoundaryText(r,pairs)||'—',
        tooltip:effectBoundaryTooltip(),cellTooltip:effectBoundaryTooltip});
    columns.push({key:'se',title:'标准误',numeric:true,format:r=>number(r.se)},
        {key:'ci_lower',title:conditional?'条件逐项系数区间':'逐项系数区间',format:r=>effectInterval(r)},
        {key:'odds_ratio',title:'OR',numeric:true,format:r=>number(r.odds_ratio),
            tooltip:effectOddsTooltip(feature,pairs,null,false,conditional),cellTooltip:r=>effectOddsTooltip(feature,pairs,r,false,conditional)},
        {key:'or_ci_lower',title:conditional?'条件逐项 OR 区间':'逐项 OR 区间',format:r=>effectInterval(r,true),
            tooltip:effectOddsTooltip(feature,pairs,null,true,conditional),cellTooltip:r=>effectOddsTooltip(feature,pairs,r,true,conditional)});
    if(pairs)columns.push({key:'p_value',title:conditional?'条件原始 p':'原始 p',numeric:true,format:r=>number(r.p_value)},
        {key:'p_adjusted',title:conditional?'条件 Holm p':'Holm p',numeric:true,format:r=>number(r.p_adjusted)},
        {key:'significant',title:conditional?'条件比较结论':'比较结论',format:effectPairConclusion});
    columns.push({key:'status',title:'状态',format:effectEstimateStatus},
        {key:'reason',title:'说明',wide:true,format:effectRowReason,cellTooltip:r=>r.reason||''});
    const tableRegion=el('div',null,'effects-table-region');parent.append(tableRegion);
    pagedTable(tableRegion,rows,columns,pairs?'档位对比':'档位');
}
'''
