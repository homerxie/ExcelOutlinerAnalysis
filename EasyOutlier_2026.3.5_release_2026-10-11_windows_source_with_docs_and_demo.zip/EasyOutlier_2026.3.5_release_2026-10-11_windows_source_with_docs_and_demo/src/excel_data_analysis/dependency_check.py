"""Verify an installation using the Python that will run or package the app."""

from __future__ import annotations

import argparse
from importlib import import_module, metadata
import subprocess
import sys


# Distribution names are not always import names (notably pyqtdarktheme).
# Import the binary-backed submodules used by the application as well as roots.
RUNTIME_IMPORTS = {
    "openpyxl": ("openpyxl",),
    "numpy": ("numpy", "numpy.linalg"),
    "scipy": ("scipy", "scipy.optimize", "scipy.special", "scipy.stats"),
    "threadpoolctl": ("threadpoolctl",),
    "PySide6": (
        "PySide6", "PySide6.QtCore", "PySide6.QtGui", "PySide6.QtWidgets", "PySide6.QtSvg",
    ),
    "pyqtdarktheme": ("qdarktheme",),
}
BUILD_IMPORTS = {"pyinstaller": ("PyInstaller", "PyInstaller.__main__")}


def check_dependencies(*, include_build: bool = False) -> bool:
    """Import every dependency, reporting all failures instead of only the first."""
    print(f"Dependency check Python: {sys.executable}", flush=True)
    dependencies = dict(RUNTIME_IMPORTS)
    if include_build:
        dependencies.update(BUILD_IMPORTS)
    failures = []
    for distribution, modules in dependencies.items():
        try:
            for module in modules:
                import_module(module)
            version = metadata.version(distribution)
        except Exception as exc:
            failures.append(distribution)
            print(f"FAIL {distribution}: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
        else:
            print(f"OK {distribution} {version}", flush=True)
    if failures:
        requirements = "requirements-build.txt" if include_build else "requirements.txt"
        command = subprocess.list2cmdline([sys.executable, "-m", "pip", "install", "-r", requirements])
        print(f"Dependency check failed. From the project directory, run:\n  {command}",
              file=sys.stderr, flush=True)
        return False
    print("Dependency check passed.", flush=True)
    return True


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true", help="Also verify PyInstaller build dependencies.")
    args = parser.parse_args(argv)
    return 0 if check_dependencies(include_build=args.build) else 1


if __name__ == "__main__":
    raise SystemExit(main())
