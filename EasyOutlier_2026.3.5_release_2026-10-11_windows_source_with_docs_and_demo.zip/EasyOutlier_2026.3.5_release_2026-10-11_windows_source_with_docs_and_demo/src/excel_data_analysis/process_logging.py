"""Mirror terminal output into the GUI without changing the terminal destination.

The transport is deliberately Qt-free so spawned numerical/report workers can
install it before importing native runtimes. A pipe also captures C/Fortran
writes to stdout/stderr. Original terminal descriptors travel with the queue;
otherwise a child's tee would pass through its parent's tee a second time.

Windows console handles cannot be duplicated into another process. For an
actual Windows console we retain its original ConsoleIO/fds and mirror Python
print/logging only; direct native console writes remain terminal-only. Native
file/pipe writes are mirrored on Windows as well as POSIX.
"""
from __future__ import annotations

import atexit
import codecs
from collections import deque
from contextlib import contextmanager
from functools import wraps
import logging
import multiprocessing as mp
from multiprocessing import reduction
from multiprocessing.util import Finalize
import os
from queue import Empty
import select
import sys
import threading
from typing import Any, Callable

_WINDOWS = os.name == "nt"


def _duplicate_terminal_fd(fd):
    if _WINDOWS:
        import msvcrt
        from multiprocessing.context import get_spawning_popen
        # Put the duplicate in the spawned child directly. If startup is
        # cancelled, its OS process closes the handle rather than leaking a
        # source-side duplicate that no child ever detaches.
        child_pid = getattr(get_spawning_popen(), "pid", None)
        return reduction.DupHandle(msvcrt.get_osfhandle(fd), 0x40000000, child_pid)
    return reduction.DupFd(fd)


def _detach_terminal_fd(descriptor):
    handle = descriptor.detach()
    if _WINDOWS:
        import msvcrt
        return msvcrt.open_osfhandle(handle, os.O_WRONLY | os.O_BINARY)
    return handle


def _windows_kernel():
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.PeekNamedPipe.argtypes = (wintypes.HANDLE, wintypes.LPVOID, wintypes.DWORD,
                                    wintypes.LPVOID, ctypes.POINTER(wintypes.DWORD), wintypes.LPVOID)
    kernel.PeekNamedPipe.restype = wintypes.BOOL
    kernel.GetStdHandle.argtypes = (wintypes.DWORD,)
    kernel.GetStdHandle.restype = wintypes.HANDLE
    kernel.SetStdHandle.argtypes = (wintypes.DWORD, wintypes.HANDLE)
    kernel.SetStdHandle.restype = wintypes.BOOL
    kernel.GetConsoleMode.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
    kernel.GetConsoleMode.restype = wintypes.BOOL
    return kernel


def _is_windows_console(fd):
    import ctypes
    from ctypes import wintypes
    import msvcrt
    try:
        mode = wintypes.DWORD()
        return bool(_windows_kernel().GetConsoleMode(msvcrt.get_osfhandle(fd), ctypes.byref(mode)))
    except OSError:
        return False


class ProcessLogQueue:
    """Queue-compatible transport that retains the actual terminal destination."""

    def __init__(self, queue: Any, terminal_fds: dict[int, int] | None = None):
        self.queue = queue
        self.terminal_fds = dict(terminal_fds or {})
        self._owned_fds: list[int] = []

    def __getstate__(self):
        return self.queue, {fd: _duplicate_terminal_fd(value) for fd, value in self.terminal_fds.items()}

    def __setstate__(self, state):
        self.queue, descriptors = state
        self.terminal_fds = {fd: _detach_terminal_fd(value) for fd, value in descriptors.items()}
        self._owned_fds = list(self.terminal_fds.values())
        Finalize(self, self._close_descriptors, args=(self._owned_fds,), exitpriority=-5)

    @staticmethod
    def _close_descriptors(descriptors):
        for fd in descriptors:
            try:
                os.close(fd)
            except OSError:
                pass
        descriptors.clear()

    def put(self, *args, **kwargs):
        return self.queue.put(*args, **kwargs)

    def get_nowait(self):
        return self.queue.get_nowait()

    def __getattr__(self, name):
        return getattr(self.queue, name)

    def close(self):
        self.queue.close()
        self._close_descriptors(self._owned_fds)


class _Lines:
    def __init__(self, stream: str, emit: Callable):
        self.stream = stream
        self.emit = emit
        self.pending = ""
        self.lock = threading.RLock()

    def write(self, text: str):
        with self.lock:
            self.pending += text
            # Carriage returns are terminal progress updates; preserve each as
            # a readable log entry rather than accumulating one enormous line.
            while "\n" in self.pending or "\r" in self.pending:
                positions = [p for p in (self.pending.find("\n"), self.pending.find("\r")) if p >= 0]
                end = min(positions)
                line, self.pending = self.pending[:end], self.pending[end + 1:]
                if line:
                    self.emit(self.stream, line)
            if len(self.pending) >= 16384:
                self.flush()

    def flush(self):
        with self.lock:
            if self.pending:
                line, self.pending = self.pending, ""
                self.emit(self.stream, line)


class _NativePipe:
    def __init__(self, fd: int, emit: Callable, terminal_fd: int | None = None):
        self.fd = fd
        if _WINDOWS and _is_windows_console(fd):
            # ConsoleIO repeatedly calls WriteConsoleW(_get_osfhandle(fd)).
            # Redirecting that fd to a pipe breaks Python writes, and console
            # handles cannot be carried through the spawn queue either.
            raise OSError("Keep the Windows console descriptor unchanged")
        try:
            self.saved_fd = os.dup(fd if terminal_fd is None else terminal_fd)
        except OSError:
            # pythonw/frozen GUI applications can start without fd 1/2.
            # There is no terminal to preserve, but native output still needs
            # a valid pipe destination and Python print must remain usable.
            self.saved_fd = os.open(os.devnull, os.O_WRONLY)
        self.read_fd, write_fd = os.pipe()
        if _WINDOWS:
            import msvcrt
            self.kernel = _windows_kernel()
            self.read_handle = msvcrt.get_osfhandle(self.read_fd)
            self.std_handle_id = -11 if fd == 1 else -12
        else:
            os.set_blocking(self.read_fd, False)
        self.lines = _Lines("stdout" if fd == 1 else "stderr", emit)
        self.decoder = codecs.getincrementaldecoder("utf-8")("replace")
        self.lock = threading.RLock()
        self.stopping = threading.Event()
        self.closed = False
        os.dup2(write_fd, fd)
        if _WINDOWS:
            self.kernel.SetStdHandle(self.std_handle_id, msvcrt.get_osfhandle(fd))
        os.close(write_fd)
        self.thread = threading.Thread(target=self._read, name=f"terminal-log-{fd}", daemon=True)
        self.thread.start()

    def _drain(self):
        with self.lock:
            while not self.closed:
                try:
                    size = 65536
                    if _WINDOWS:
                        import ctypes
                        from ctypes import wintypes
                        available = wintypes.DWORD()
                        if not self.kernel.PeekNamedPipe(self.read_handle, None, 0, None,
                                                        ctypes.byref(available), None):
                            break
                        size = min(size, available.value)
                        if not size:
                            break
                    data = os.read(self.read_fd, size)
                except (BlockingIOError, OSError):
                    break
                if not data:
                    break
                remaining = memoryview(data)
                try:
                    while remaining:
                        remaining = remaining[os.write(self.saved_fd, remaining):]
                except OSError:
                    pass  # A closed external terminal must not stop analysis.
                self.lines.write(self.decoder.decode(data))

    def _read(self):
        while not self.stopping.is_set():
            if _WINDOWS:
                self._drain()
                self.stopping.wait(0.02)
                continue
            try:
                ready, _, _ = select.select([self.read_fd], [], [], 0.1)
            except (OSError, ValueError):
                break
            if ready:
                self._drain()
        self._drain()

    def flush(self):
        self._drain()
        self.lines.flush()

    def close(self):
        if self.closed:
            return
        os.dup2(self.saved_fd, self.fd)
        if _WINDOWS:
            import msvcrt
            # dup2 closed the old fd's OS handle. Restore the new valid handle,
            # never the stale GetStdHandle value from before installation.
            self.kernel.SetStdHandle(self.std_handle_id, msvcrt.get_osfhandle(self.fd))
        self.stopping.set()
        self.thread.join(timeout=1)
        self.flush()
        with self.lock:
            self.closed = True
            os.close(self.read_fd)
            os.close(self.saved_fd)

    def after_fork(self):
        # Locks/reader threads cannot be reused after fork. Restore the true
        # terminal before the child installs its own pipe and queue sink.
        os.dup2(self.saved_fd, self.fd)
        os.close(self.read_fd)
        # A queue passed to a forked report worker may still borrow saved_fd.
        # The child process owns this duplicate until process exit.
        self.closed = True


class _Tee:
    def __init__(self, original: Any, stream: str, emit: Callable, pipe: _NativePipe | None):
        self.original = original
        self.lines = _Lines(stream, emit)
        self.pipe = pipe
        self.native = False
        if pipe is not None:
            try:
                self.native = original.fileno() == pipe.fd
            except (AttributeError, OSError, ValueError):
                pass

    def write(self, text):
        result = self.original.write(text) if self.original is not None else len(text)
        if self.native:
            self.original.flush()
        else:
            self.lines.write(text)
        return result

    def flush(self):
        if self.original is not None:
            self.original.flush()
        if self.native:
            self.pipe.flush()
        else:
            self.lines.flush()

    def __getattr__(self, name):
        if self.original is None:
            if name == "encoding":
                return "utf-8"
            if name == "isatty":
                return lambda: False
            if name == "fileno":
                def unavailable():
                    raise OSError("No terminal descriptor")
                return unavailable
        return getattr(self.original, name)


class _Capture:
    def __init__(self, sink: Callable, terminal_fds: dict[int, int] | None = None):
        self.sink = sink
        self.pid = os.getpid()
        self.originals = {"stdout": sys.stdout, "stderr": sys.stderr}
        self.pipes: dict[int, _NativePipe] = {}
        self.streams: dict[str, _Tee] = {}
        self.handlers = []
        self.closed = False
        for name, fd in (("stdout", 1), ("stderr", 2)):
            original = self.originals[name]
            try:
                original.flush()
            except (AttributeError, OSError, ValueError):
                pass
            try:
                self.pipes[fd] = _NativePipe(fd, self.emit, (terminal_fds or {}).get(fd))
            except (OSError, ValueError):
                pass
            stream = _Tee(original, name, self.emit, self.pipes.get(fd))
            self.streams[name] = stream
            setattr(sys, name, stream)
        loggers = [logging.getLogger(), *logging.Logger.manager.loggerDict.values()]
        seen = set()
        for logger in loggers:
            for handler in getattr(logger, "handlers", ()):
                if not isinstance(handler, logging.StreamHandler):
                    continue
                if id(handler) in seen:
                    continue
                seen.add(id(handler))
                for name, original in self.originals.items():
                    if original is None and name != "stderr":
                        continue
                    if getattr(handler, "stream", None) is original:
                        handler.setStream(self.streams[name])
                        self.handlers.append((handler, original, self.streams[name]))

    def emit(self, stream, message):
        try:
            self.sink(stream, message)
        except Exception:
            # Never print a failed queue write into the queue itself.
            pass

    def flush(self):
        for stream in self.streams.values():
            try:
                stream.flush()
            except (OSError, ValueError):
                pass
        for pipe in self.pipes.values():
            pipe.flush()

    def close(self):
        if self.closed:
            return
        self.flush()
        for handler, original, tee in self.handlers:
            if getattr(handler, "stream", None) is tee:
                handler.setStream(original)
        for name, original in self.originals.items():
            if getattr(sys, name) is self.streams[name]:
                setattr(sys, name, original)
        for pipe in self.pipes.values():
            pipe.close()
        self.closed = True

    def after_fork(self):
        for name, original in self.originals.items():
            if getattr(sys, name) is self.streams[name]:
                setattr(sys, name, original)
        for handler, original, tee in self.handlers:
            if getattr(handler, "stream", None) is tee:
                handler.stream = original
        for pipe in self.pipes.values():
            pipe.after_fork()


_capture: _Capture | None = None
_process_queue: Any = None
_gui_queue: ProcessLogQueue | None = None
_subscribers: dict[object, Callable] = {}
_pending_logs = deque()
_pending_lock = threading.Lock()


def _enqueue_gui(stream, message):
    with _pending_lock:
        _pending_logs.append((stream, message))


def _broadcast(stream, message):
    for callback in tuple(_subscribers.values()):
        try:
            callback(stream, message)
        except Exception:
            pass


def prepare_process_log_queue(queue):
    """Wrap a task queue once before passing it to a spawned process."""
    if isinstance(queue, ProcessLogQueue):
        return queue
    terminal_fds = {fd: pipe.saved_fd for fd, pipe in _capture.pipes.items()} if _capture else {}
    return ProcessLogQueue(queue, terminal_fds)


def get_process_log_queue():
    return _process_queue if _process_queue is not None else _gui_queue


def install_process_logging(queue):
    """Install in a worker initializer, before importing numerical runtimes."""
    global _capture, _process_queue
    if queue is None:
        return
    if _process_queue is queue and _capture is not None:
        return
    _process_queue = queue
    sink = lambda stream, message: queue.put({"type": "log", "stream": stream, "message": message})
    if _capture is None:
        _capture = _Capture(sink, getattr(queue, "terminal_fds", None))
        Finalize(None, shutdown_process_logging, exitpriority=20)
    else:
        _capture.flush()
        _capture.sink = sink


def flush_process_logging():
    if _capture is not None:
        _capture.flush()


def write_terminal(message: str, *, stream: str = "stderr"):
    """Print an already GUI-logged error without mirroring it a second time."""
    if _capture is not None:
        tee = _capture.streams[stream]
        if tee.native:
            data = message.encode(getattr(tee.original, "encoding", None) or "utf-8", errors="replace")
            remaining = memoryview(data)
            while remaining:
                remaining = remaining[os.write(tee.pipe.saved_fd, remaining):]
            return
        destination = tee.original
    else:
        destination = getattr(sys, stream)
    if destination is not None:
        destination.write(message)
        destination.flush()


def shutdown_process_logging():
    global _capture, _process_queue
    if _capture is not None:
        _capture.close()
        _capture = None
    _process_queue = None


@contextmanager
def process_logging_scope(queue):
    """Keep direct entry-point calls/test embedding from changing global IO."""
    global _process_queue
    previous_capture, previous_queue = _capture, _process_queue
    previous_sink = _capture.sink if _capture else None
    install_process_logging(queue)
    try:
        yield
    finally:
        flush_process_logging()
        if previous_capture is None:
            shutdown_process_logging()
        else:
            _capture.sink = previous_sink
            _process_queue = previous_queue


def logged_process_entry(function):
    """Emit the final result only after every pending terminal line is flushed."""
    @wraps(function)
    def wrapped(payload, result_queue):
        results = []

        class ResultQueue:
            def put(self, item):
                if item.get("type") == "result":
                    results.append(item)
                else:
                    result_queue.put(item)

        with process_logging_scope(result_queue):
            function(payload, ResultQueue())
        for result in results:
            result_queue.put(result)

    return wrapped


def subscribe_terminal_logs(callback: Callable):
    """Register a thread-safe GUI signal callback; return an unsubscribe token."""
    global _capture, _gui_queue
    token = object()
    _subscribers[token] = callback
    if _capture is None:
        _capture = _Capture(_enqueue_gui)
    if _gui_queue is None:
        _gui_queue = prepare_process_log_queue(mp.get_context("spawn").Queue())
    return token


def drain_process_logs(limit: int = 200):
    messages = []
    with _pending_lock:
        for _ in range(min(limit, len(_pending_logs))):
            messages.append(_pending_logs.popleft())
    for _ in range(limit):
        if _gui_queue is None:
            break
        try:
            item = _gui_queue.get_nowait()
        except (Empty, OSError, ValueError):
            break
        if item.get("type") == "log":
            messages.append((str(item.get("stream", "stdout")), str(item.get("message", ""))))
    # One queued Qt signal per adjacent stream batch, not one per print call.
    while messages:
        stream = messages[0][0]
        end = next((i for i, item in enumerate(messages) if item[0] != stream), len(messages))
        _broadcast(stream, "\n".join(item[1] for item in messages[:end]))
        del messages[:end]


def unsubscribe_terminal_logs(token):
    global _gui_queue
    if token not in _subscribers:
        return
    flush_process_logging()
    drain_process_logs(limit=5000)
    _subscribers.pop(token, None)
    if not _subscribers:
        shutdown_process_logging()
        if _gui_queue is not None:
            # Closing a window must never wait on a queue feeder whose pipe
            # has no remaining GUI consumer (including a burst during exit).
            _gui_queue.cancel_join_thread()
            _gui_queue.close()
            _gui_queue = None
        with _pending_lock:
            _pending_logs.clear()


def _after_fork():
    global _capture, _process_queue, _gui_queue, _subscribers, _pending_logs, _pending_lock
    if _capture is not None:
        _capture.after_fork()
    _capture = None
    _process_queue = None
    _gui_queue = None
    _subscribers = {}
    _pending_logs = deque()
    _pending_lock = threading.Lock()


if hasattr(os, "register_at_fork"):
    os.register_at_fork(after_in_child=_after_fork)
atexit.register(shutdown_process_logging)
