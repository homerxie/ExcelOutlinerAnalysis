"""Independent-instance noisy-OR inference from chain Fail/Pass counts.

The observations must already represent the intended physical or operational
failure event.  This module does not turn an outlier flag or a missing value into
a failure.  Confidence intervals assume independent observations; correlations
between chains measured on the same die are not accounted for here.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from collections import Counter
import math
from numbers import Integral, Real
from time import monotonic
from typing import Any, Callable, Sequence

import numpy as np
from scipy.optimize import brentq, linprog, minimize
from scipy.special import expit
from scipy.stats import beta, chi2

from .tsk_features import category_label
from .tsk_sorting import natural_sort_key
from .tsk_parallel import ordered_parallel_map, validate_analysis_workers, worker_count
from .tsk_fit_diagnostics import build_logistic_fit_debug, format_logistic_fit_debug
from .tsk_progress import joint_progress_message
from .tsk_spatial import (DEFAULT_XY_MODEL, build_spatial_transform,
                          spatial_feature_groups, spatial_values, validate_xy_model)


@dataclass(slots=True)
class TskInstance:
    chain_id: str
    instance_id: str
    tsk_id: str
    x: float | None = None
    y: float | None = None
    features: dict[str, float | str] = field(default_factory=dict)


@dataclass(slots=True)
class TskChainObservation:
    chain_id: str
    n_tested: int
    n_failed: int


@dataclass(slots=True)
class TskAnalysisOptions:
    use_xy: bool = False
    feature_names: tuple[str, ...] = ()
    confidence_level: float = 0.95
    categorical_feature_names: tuple[str, ...] = ()
    feature_model: str = "logistic"
    logistic_coefficient_bound: float = 35.
    feature_effects_mode: str = "fixed_zero"
    simulation_replicates: int = 999
    simulation_seed: int = 1729
    xy_model: str = DEFAULT_XY_MODEL
    simulation_workers: int = 0
    analysis_workers: int = 0


@dataclass(slots=True)
class TskTypeEstimate:
    tsk_id: str
    probability: float | None
    ci_lower: float | None
    ci_upper: float | None
    identifiable: bool
    status: str
    instance_count: int
    test_exposure: int
    interval_method: str | None = None
    interval_error: str | None = None
    estimate_kind: str = "interior"
    interval_sidedness: str = "two_sided"
    confidence_level: float | None = None
    coefficient_status: str | None = None


@dataclass(slots=True)
class TskChainEstimate:
    chain_id: str
    n_tested: int
    n_failed: int
    observed_probability: float | None
    predicted_probability: float | None
    residual: float | None
    deviance_residual: float | None
    status: str = "ok"
    members: list[dict[str, Any]] = field(default_factory=list)


@dataclass(slots=True)
class TskAnalysisResult:
    types: list[TskTypeEstimate]
    chains: list[TskChainEstimate]
    diagnostics: dict[str, Any]
    options: TskAnalysisOptions
    prediction_context: dict[str, Any] | None = None
    joint_risk: dict[str, Any] | None = None
    feature_effects: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Return strict-JSON-compatible values, including failed fit results."""
        return _plain(asdict(self))


def _plain(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    if isinstance(value, np.ndarray):
        return _plain(value.tolist())
    if isinstance(value, np.generic):
        return _plain(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _name(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label} must be a nonempty string.")
    return value.strip()


def _numeric(value: Any, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value):
        raise ValueError(f"{label} must be a finite number.")
    return float(value)


def _rank_identifiable(matrix: np.ndarray) -> tuple[int, np.ndarray]:
    """A coefficient is structurally identified iff every null vector is zero there."""
    width = matrix.shape[1]
    if not width:
        return 0, np.ones(0, dtype=bool)
    if not matrix.size:
        return 0, np.zeros(width, dtype=bool)
    # Avoid allocating a chains-by-chains U matrix for tall count matrices.
    _, singular, vh = np.linalg.svd(matrix, full_matrices=matrix.shape[0] < width)
    tolerance = max(matrix.shape) * np.finfo(float).eps * singular[0] * 100
    rank = int(np.sum(singular > tolerance))
    null_space = vh[rank:]
    identified = np.ones(width, dtype=bool) if rank == width else np.linalg.norm(null_space, axis=0) < 1e-7
    return rank, identified


def _loss_and_slope(hazard: np.ndarray, n: np.ndarray, k: np.ndarray) -> tuple[float, np.ndarray]:
    positive = k > 0
    if np.any(hazard[positive] <= 0):
        return math.inf, np.full_like(hazard, math.nan)
    value = float(np.dot(n - k, hazard))
    slope = (n - k).copy()
    # exp(-eta) / (1-exp(-eta)) is stable both near zero and for large eta.
    if np.any(positive):
        selected = hazard[positive]
        failed_probability = -np.expm1(-selected)
        value -= float(np.dot(k[positive], np.log(failed_probability)))
        slope[positive] -= k[positive] * np.exp(-selected) / failed_probability
    return value, slope


def _optimizer_converged(fit, sample_count: float, lower: float, upper: float = math.inf) -> bool:
    if not math.isfinite(fit.fun):
        return False
    # A successful termination based only on objective reduction is insufficient:
    # a line-search trial with zero probability for an observed Fail can leave
    # L-BFGS-B at its initial point while reporting success. Conversely it may
    # report a precision failure at a stationary optimum. Always verify the
    # bound-constrained first-order condition, normalized per observation.
    gradient = np.asarray(fit.jac).copy()
    gradient[(fit.x <= lower + 1e-10) & (gradient > 0)] = 0
    gradient[(fit.x >= upper - 1e-10) & (gradient < 0)] = 0
    return bool(np.all(np.isfinite(gradient)) and np.max(np.abs(gradient), initial=0) / max(sample_count, 1) < 1e-8)


def _minimize_bound_constrained(objective, initial, sample_count, lower, upper=math.inf, hessian=None,
                               diagnostic_trace=None, trace_callback=None):
    """Fit with an explicit stationarity check and an independent fallback.

    SLSQP uses a different line search from L-BFGS-B. Scaling its objective per
    observation avoids very large trial steps for large binomial counts. A
    fallback is accepted only if it also satisfies the projected-gradient test;
    otherwise the caller withholds the fit or interval instead of reporting a
    false optimum.
    """
    bounds = [(lower, None if math.isinf(upper) else upper)] * len(initial)
    options = {"ftol": 1e-12, "gtol": 1e-8, "maxiter": 1500, "maxls": 50}

    def run_stage(function, values, method, settings, phase, objective_scale=1.):
        if diagnostic_trace is None:
            return minimize(function, values, jac=True, method=method, bounds=bounds, options=settings), None
        from .tsk_optimizer_trace import OptimizationStageTrace
        stage = OptimizationStageTrace(function, values, method=method, phase=phase, options=settings,
                                       sample_count=sample_count, lower=lower, upper=upper,
                                       objective_scale=objective_scale, trace_callback=trace_callback)
        diagnostic_trace.setdefault("stages", []).append(stage.data)
        return minimize(stage.evaluate, values, jac=True, method=method, bounds=bounds,
                        options=settings, callback=stage.callback), stage

    def finish(fit, converged, stage):
        if diagnostic_trace is not None:
            from .tsk_optimizer_trace import finish_optimizer_trace
            finish_optimizer_trace(diagnostic_trace, fit, converged, stage, sample_count, lower, upper)
        return fit, converged

    fit, fit_stage = run_stage(objective, initial, "L-BFGS-B", options, "initial_lbfgsb")
    if fit_stage is not None:
        fit_stage.finish(fit)
    if _optimizer_converged(fit, sample_count, lower, upper):
        return finish(fit, True, fit_stage)

    scale = max(float(sample_count), 1.)

    def scaled_objective(values):
        value, gradient = objective(values)
        return value / scale, gradient / scale

    start = fit.x if math.isfinite(fit.fun) and np.all(np.isfinite(fit.x)) else initial
    fallback, fallback_stage = run_stage(scaled_objective, start, "SLSQP",
                                         {"ftol": 1e-16, "maxiter": 1500}, "slsqp_fallback", scale)
    fallback.fun, fallback.jac = objective(fallback.x)
    if fallback_stage is not None:
        fallback_stage.finish(fallback, validation_evaluations=1)
    if _optimizer_converged(fallback, sample_count, lower, upper):
        return finish(fallback, True, fallback_stage)

    # SLSQP's objective-based stopping criterion can finish slightly before the
    # required stationarity tolerance; polish its improved feasible point.
    if math.isfinite(fallback.fun) and np.all(np.isfinite(fallback.x)):
        polished, polished_stage = run_stage(objective, fallback.x, "L-BFGS-B",
                                             {**options, "ftol": 0.}, "lbfgsb_polish")
        if polished_stage is not None:
            polished_stage.finish(polished)
        if _optimizer_converged(polished, sample_count, lower, upper):
            return finish(polished, True, polished_stage)
        if math.isfinite(polished.fun) and polished.fun < fallback.fun:
            fallback = polished
            fallback_stage = polished_stage
    if math.isfinite(fallback.fun) and (not math.isfinite(fit.fun) or fallback.fun < fit.fun):
        fit = fallback
        fit_stage = fallback_stage
    if hessian is not None and math.isfinite(fit.fun):
        # Near a convex optimum, an objective reduction smaller than floating-
        # point resolution can still leave a detectable gradient. Exact Newton
        # corrections resolve it without weakening the convergence criterion.
        for _ in range(20):
            free = ~(((fit.x <= lower + 1e-10) & (fit.jac >= 0)) |
                     ((fit.x >= upper - 1e-10) & (fit.jac <= 0)))
            if not np.any(free):
                break
            curvature = hessian(fit.x)[np.ix_(free, free)]
            if not np.all(np.isfinite(curvature)):
                break
            direction = np.zeros_like(fit.x)
            try:
                direction[free] = np.linalg.lstsq(curvature, -fit.jac[free], rcond=None)[0]
            except np.linalg.LinAlgError:
                break
            if not np.all(np.isfinite(direction)) or fit.jac @ direction >= 0:
                break
            step = 1.
            negative, positive = direction < 0, direction > 0
            if np.any(negative):
                step = min(step, float(np.min((lower - fit.x[negative]) / direction[negative])))
            if math.isfinite(upper) and np.any(positive):
                step = min(step, float(np.min((upper - fit.x[positive]) / direction[positive])))
            if step <= 0:
                break
            for _ in range(50):
                candidate = np.clip(fit.x + step * direction, lower, upper)
                value, gradient = objective(candidate)
                roundoff = 8 * np.finfo(float).eps * max(abs(fit.fun), 1.)
                if math.isfinite(value) and value <= fit.fun + roundoff:
                    fit.x, fit.fun, fit.jac = candidate, value, gradient
                    break
                step *= .5
            else:
                break
            if _optimizer_converged(fit, sample_count, lower, upper):
                return finish(fit, True, fit_stage)
    return finish(fit, False, fit_stage)


class _BaselineModel:
    """Type-only Logistic risks in negative-log-survival coordinates.

    With no feature effects, one free risk per TSK has the same probability
    model under either coordinate system. Hazards also represent p=0 and p=1
    boundaries directly, so this numerical parameterization is retained.
    """

    def __init__(self, counts: np.ndarray, n: np.ndarray, k: np.ndarray):
        self.counts, self.n, self.k = counts, n, k
        self.width = counts.shape[1]
        self.unbounded = (counts.T @ (n - k) == 0) & (counts.sum(axis=0) > 0)

    def fit(self, fixed: tuple[int, float] | None = None, start: np.ndarray | None = None):
        """Analytically saturate unconstrained hazards having no observed passes.

        A fixed value of +inf represents p=1 exactly, without multiplying zeros
        by infinity.  The remaining optimization has a finite nonnegative MLE.
        """
        width = self.width
        fixed_index, fixed_value = fixed if fixed is not None else (-1, 0.0)
        free = np.arange(width) != fixed_index
        infinite = self.unbounded & free
        if math.isinf(fixed_value):
            if np.any((self.counts[:, fixed_index] > 0) & (self.n > self.k)):
                return math.inf, np.zeros(width), np.zeros(len(self.n)), True
            infinite[fixed_index] = True
        saturated = np.any(self.counts[:, infinite] > 0, axis=1)
        selected = ~saturated
        finite = free & ~infinite
        matrix = self.counts[selected][:, finite]
        n, k = self.n[selected], self.k[selected]
        offset = np.zeros(len(n))
        if fixed_index >= 0 and not math.isinf(fixed_value):
            offset = self.counts[selected, fixed_index] * fixed_value
        # A profiled p=0 can make an observed failure impossible regardless of
        # the nuisance parameters. This is an infinite likelihood penalty, not
        # an optimizer convergence failure.
        if np.any((k > 0) & (offset == 0) & (matrix.sum(axis=1) == 0)):
            return math.inf, np.zeros(width), np.zeros(len(self.n)), True
        h = np.zeros(width)
        h[infinite] = math.inf
        if fixed_index >= 0:
            h[fixed_index] = fixed_value
        converged = True
        if finite.any():
            if np.any(k):
                initial_rate = min(max(float(k.sum() / max(n.sum(), 1)), 1e-5), 0.9)
                initial = np.full(int(finite.sum()), -math.log1p(-initial_rate) / max(float(matrix.sum(axis=1).mean()), 1))
                if start is not None:
                    candidate = start[finite]
                    if np.all(np.isfinite(candidate)):
                        initial = np.maximum(candidate, 1e-9)

                def objective(values):
                    value, slope = _loss_and_slope(offset + matrix @ values, n, k)
                    return value, matrix.T @ slope

                def hessian(values):
                    hazard = offset + matrix @ values
                    weight = np.zeros(len(n))
                    positive = k > 0
                    survival = np.exp(-hazard[positive])
                    failure = -np.expm1(-hazard[positive])
                    weight[positive] = k[positive] * survival / failure ** 2
                    return matrix.T @ (weight[:, None] * matrix)

                fit, converged = _minimize_bound_constrained(objective, initial, float(n.sum()), 0., hessian=hessian)
                h[finite] = fit.x
            # All selected rows pass: zero free hazards is the exact optimum.
        hazard = offset + matrix @ h[finite]
        value, _ = _loss_and_slope(hazard, n, k)
        predicted = np.ones(len(self.n))
        predicted[selected] = -np.expm1(-hazard)
        return value, h, predicted, converged

    def identifiability(self, h: np.ndarray) -> tuple[int, np.ndarray]:
        rank, _ = _rank_identifiable(self.counts)
        finite = ~self.unbounded
        selected = ~np.any(self.counts[:, self.unbounded] > 0, axis=1)
        effective = self.counts[selected][:, finite]
        _, identified_finite = _rank_identifiable(effective)
        identified = np.zeros(self.width, dtype=bool)
        identified[finite] = identified_finite
        # p=1 is forced only if at least one all-Fail chain has this type as its
        # sole unconstrained saturation mechanism. Otherwise any value can fit.
        unbounded_count = np.sum(self.counts[:, self.unbounded] > 0, axis=1)
        for index in np.flatnonzero(self.unbounded):
            identified[index] = bool(np.any((self.counts[:, index] > 0) & (unbounded_count == 1)))
        if finite.any():
            # With zero-failure rows, full design rank alone need not make the
            # realized likelihood strictly convex. Its exact flat directions
            # preserve the positive-failure hazards and the total pass exposure.
            n, k = self.n[selected], self.k[selected]
            dependence = np.vstack([effective[k > 0], (n - k) @ effective])
            dep_rank, _ = _rank_identifiable(dependence)
            if dep_rank < int(finite.sum()):
                nonzero = np.max(np.abs(dependence), axis=1) > 0
                equality = dependence[nonzero]
                equality = equality / np.max(np.abs(equality), axis=1)[:, None]
                target = equality @ h[finite]
                for local, index in enumerate(np.flatnonzero(finite)):
                    if not identified[index]:
                        continue
                    direction = np.zeros(effective.shape[1])
                    direction[local] = 1
                    low = linprog(direction, A_eq=equality, b_eq=target, bounds=(0, None), method="highs")
                    high = linprog(-direction, A_eq=equality, b_eq=target, bounds=(0, None), method="highs")
                    if not low.success or not high.success or -high.fun - low.fun > 1e-7:
                        identified[index] = False
        return rank, identified


def _feature_loss_and_derivative(design, chain_index, n, k, theta, derivative_index=None):
    """Shared likelihood evaluator for fitting and frozen prediction queries."""
    logits = design @ theta
    probability = expit(logits)
    hazards = np.bincount(chain_index, weights=np.logaddexp(0, logits), minlength=len(n))
    width = design.shape[1]
    if derivative_index is None:
        derivative_index = (chain_index[:, None] * width + np.arange(width)).ravel()
    derivative = np.bincount(derivative_index, weights=(probability[:, None] * design).ravel(),
                             minlength=len(n) * width).reshape(len(n), width)
    value, slope = _loss_and_slope(hazards, n, k)
    return value, derivative.T @ slope, -np.expm1(-hazards), derivative


class _FeatureModel:
    def __init__(self, counts, n, k, instances, chain_ids, type_ids, feature_names,
                 categorical_levels=None, coefficient_bound=35., *, xy_model="linear"):
        self.counts, self.n, self.k = counts, n, k
        self.type_count = len(type_ids)
        self.coefficient_bound = float(coefficient_bound)
        type_index = {value: index for index, value in enumerate(type_ids)}
        chain_index = {value: index for index, value in enumerate(chain_ids)}
        self.chain_index = np.array([chain_index[row.chain_id] for row in instances], dtype=int)
        self.type_index = np.array([type_index[row.tsk_id] for row in instances], dtype=int)
        categorical_levels = categorical_levels or {}
        self.spatial_transform = build_spatial_transform(instances) if xy_model == DEFAULT_XY_MODEL else None
        self.feature_groups = spatial_feature_groups(self.spatial_transform)
        self.numeric_names = [name for name in feature_names if name not in categorical_levels
                              and not (self.spatial_transform and name in {"x", "y"})]
        values = np.array([[row.x if name == "x" else row.y if name == "y" else row.features.get(name)
                            for name in self.numeric_names] for row in instances], dtype=float)
        self.means = values.mean(axis=0)
        self.numeric_reference = dict(zip(self.numeric_names, map(float, self.means)))
        if self.spatial_transform:
            reference = self.spatial_transform["reference"]
            self.numeric_reference.update(reference)
            spatial_names = [term["name"] for term in self.spatial_transform["terms"]]
            spatial_rows = [spatial_values(self.spatial_transform, row.x, row.y) for row in instances]
            spatial_reference = spatial_values(self.spatial_transform, reference["x"], reference["y"])
            values = np.column_stack([values, [[row[name] for name in spatial_names] for row in spatial_rows]])
            # Reference is one actual XY condition, not an impossible vector
            # assembled from the separate means of X², X⁴ and X²Y².
            self.means = np.r_[self.means, [spatial_reference[name] for name in spatial_names]]
            self.numeric_names.extend(spatial_names)
        self.scales = values.std(axis=0)
        self.constant_features = [name for name, scale in zip(self.numeric_names, self.scales) if scale <= 1e-12]
        self.scales[self.scales <= 1e-12] = 1
        standardized = (values - self.means) / self.scales
        columns = [np.eye(self.type_count)[self.type_index], standardized]
        self.coefficient_columns = [(name, None) for name in self.numeric_names]
        self.categorical_features = {}
        for name in feature_names:
            if name not in categorical_levels:
                continue
            levels = categorical_levels[name]
            labels = [category_label(row.features.get(name), name) for row in instances]
            active = set(labels)
            self.categorical_features[name] = {
                "encoding": "reference_one_hot", "levels": list(levels), "reference": levels[0],
                "active_levels": [level for level in levels if level in active],
                "missing_levels": [level for level in levels if level not in active],
                "reference_source": "Complete selected topology; lexicographically first canonical label.",
            }
            # Do not center dummy columns: alpha_t then represents an actual
            # reference category, rather than an impossible fractional category.
            for level in levels[1:]:
                columns.append(np.array([label == level for label in labels], dtype=float)[:, None])
                self.coefficient_columns.append((name, level))
        self.design = np.column_stack(columns)
        self.width = self.design.shape[1]
        self._derivative_index = (self.chain_index[:, None] * self.width + np.arange(self.width)).ravel()
        self.feature_names = feature_names

    def evaluate(self, theta):
        return _feature_loss_and_derivative(self.design, self.chain_index, self.n, self.k, theta,
                                             self._derivative_index)

    def fit(self, start=None, fixed=None, multistart=False, progress_callback=None, diagnostic_callback=None):
        fixed_index, fixed_value = fixed if fixed is not None else (-1, 0.)
        free = np.arange(self.width) != fixed_index
        if start is None:
            rate = np.clip(self.k.sum() / max(self.n.sum(), 1), 1e-5, .95)
            component = -np.expm1(np.log1p(-rate) / max(self.counts.sum(axis=1).mean(), 1))
            start = np.zeros(self.width)
            start[:self.type_count] = math.log(component / (1 - component))
        starts = [start.copy()]
        if multistart:
            for sign in (-1, 1):
                other = start.copy()
                other[self.type_count:] += sign * .5
                starts.append(other)
        capture_diagnostics = multistart and fixed is None
        if capture_diagnostics:
            from .tsk_optimizer_trace import CONVERGENCE_THRESHOLD, json_safe
            self.optimizer_diagnostics = {
                "version": 1, "convergence_threshold": CONVERGENCE_THRESHOLD,
                "coefficient_bounds": [-self.coefficient_bound, self.coefficient_bound], "boundary_warning_distance": .1,
                "sample_count": float(self.n.sum()), "starts": [],
                "selected_start_index": None, "selection_rule": "lowest_negative_log_likelihood",
            }
        fits = []
        for start_index, initial in enumerate(starts, 1):
            initial = np.clip(initial, -self.coefficient_bound, self.coefficient_bound)
            if fixed_index >= 0:
                initial[fixed_index] = fixed_value

            def objective(values):
                if progress_callback is not None:
                    progress_callback()
                theta = initial.copy()
                theta[free] = values
                value, gradient, _, _ = self.evaluate(theta)
                return value, gradient[free]

            if free.any():
                trace = None
                if capture_diagnostics:
                    trace = {"start_index": start_index, "initial_coefficients": json_safe(initial), "stages": []}
                    self.optimizer_diagnostics["starts"].append(trace)

                def report_diagnostic(event):
                    if diagnostic_callback is not None:
                        diagnostic_callback({"start_index": start_index, **event})

                fit, converged = _minimize_bound_constrained(
                    objective, initial[free], float(self.n.sum()), -self.coefficient_bound, self.coefficient_bound,
                    diagnostic_trace=trace, trace_callback=report_diagnostic if capture_diagnostics else None)
                theta = initial.copy()
                theta[free] = fit.x
                fits.append((float(fit.fun), theta, converged))
            else:
                fits.append((self.evaluate(initial)[0], initial, True))
        value, theta, converged = min(fits, key=lambda row: row[0])
        if capture_diagnostics:
            self.optimizer_diagnostics["selected_start_index"] = min(range(len(fits)), key=lambda i: fits[i][0]) + 1
        _, _, predicted, derivative = self.evaluate(theta)
        return value, theta, predicted, converged and math.isfinite(value), derivative


def _profile_interval(estimate: float, objective, minimum: float, confidence: float,
                      lower: float, upper: float, *, initial_step: float | None = None) -> tuple[float, float]:
    threshold = minimum + float(chi2.ppf(confidence, 1)) / 2
    cache = {estimate: minimum - threshold}

    def root(value):
        if value not in cache:
            cache[value] = objective(value) - threshold
        return cache[value]

    if initial_step is not None:
        def endpoint(boundary):
            # Logistic nuisance fits at +/-35 can be far harder than fits near
            # the likelihood cutoff. Bracket outwards from the MLE instead of
            # first forcing an effectively zero/one probability. Still reach
            # the numerical boundary when the interval genuinely extends there.
            sign = -1 if boundary < estimate else 1
            distance = initial_step
            while True:
                candidate = max(boundary, estimate - distance) if sign < 0 else min(boundary, estimate + distance)
                if root(candidate) >= 0:
                    return brentq(root, *sorted((estimate, candidate)), xtol=1e-9)
                if candidate == boundary:
                    return boundary
                distance *= 2

        return float(endpoint(lower)), float(endpoint(upper))

    low = lower if root(lower) <= 0 else brentq(root, lower, estimate, xtol=1e-9)
    high = upper if root(upper) <= 0 else brentq(root, estimate, upper, xtol=1e-9)
    return float(low), float(high)


def _binomial_interval(n: int, k: int, confidence: float) -> tuple[float, float]:
    tail = (1 - confidence) / 2
    return (0. if k == 0 else float(beta.ppf(tail, k, n - k + 1)),
            1. if k == n else float(beta.ppf(1 - tail, k + 1, n - k)))


def _deviance(n: int, k: int, q: float) -> float | None:
    observed = k / n
    if (q == 0 and k > 0) or (q == 1 and k < n):
        return None
    value = 0.
    if k:
        value += k * math.log(observed / q)
    if k < n:
        value += (n - k) * math.log((1 - observed) / (1 - q))
    return math.copysign(math.sqrt(max(2 * value, 0.)), observed - q) if value else 0.


def _type_interval_task(common, item, heartbeat):
    """One independent profile, sharing the immutable model within each worker."""
    position, index, type_id = item
    model, boundary_engine = common["model"], common["boundary_engine"]
    coefficients, probabilities = common["coefficients"], common["probabilities"]
    counts, n, k = model.counts, model.n, model.k
    minimum, options = common["minimum"], common["options"]
    feature_names, type_ids, all_type_ids = common["feature_names"], common["type_ids"], common["all_type_ids"]
    coefficient_bound, fit_debug = options.logistic_coefficient_bound, common["fit_debug"]
    boundary_zero_types, parameters = common["boundary_zero_types"], common["parameters"]
    joint_engine = common.get("joint_engine")
    interval_method = common["interval_method"]
    exposure = int(np.dot(n, counts[:, index]))
    progress = common.get("progress") or (lambda *_: heartbeat())
    estimate = float(probabilities[index])
    method = "profile_likelihood_approximate"
    interval_error = None
    estimate_kind = "boundary_low" if index in boundary_zero_types else "interior"
    if joint_engine is not None:
        estimate_kind = joint_engine.estimate_kind(np.eye(model.width)[index])
    interval_sidedness = ("upper" if estimate_kind == "boundary_low" else
                         "lower" if estimate_kind == "boundary_high" else "two_sided")
    status = "boundary_low" if estimate_kind == "boundary_low" else "boundary" if estimate <= 1e-9 or estimate >= 1 - 1e-9 else "ok"
    pure = (counts[:, index] > 0) & common["pure_type_rows"]
    exact_boundary_subset = bool(np.any(pure) and (
        (estimate <= 1e-9 and not np.any(k[pure])) or
        (estimate >= 1 - 1e-9 and np.all(k[pure] == n[pure]))))
    try:
        if joint_engine is not None:
            joint_engine.progress_callback = lambda event: progress(
                35 + int(60 * position / len(all_type_ids)),
                joint_progress_message(event, prefix=f"TSK {type_id} 概率区间"))
            low, high, method = joint_engine.profile_interval(
                coefficients, np.eye(model.width)[index], options.confidence_level)
        elif boundary_engine is not None:
            boundary_engine.progress_callback = lambda *args: progress(
                35 + int(60 * position / len(all_type_ids)),
                f"TSK {type_id}: computing nonnegative-odds profile interval")
            low, high, method = boundary_engine.profile_interval(
                parameters, np.eye(model.width)[index], options.confidence_level)
        elif not feature_names and len(type_ids) == 1 and np.all(counts[:, 0] == counts[0, 0]):
            lo_q, hi_q = _binomial_interval(int(n.sum()), int(k.sum()), options.confidence_level)
            copies = counts[0, 0]
            low = -math.expm1(math.log1p(-lo_q) / copies) if lo_q < 1 else 1.
            high = -math.expm1(math.log1p(-hi_q) / copies) if hi_q < 1 else 1.
            method = "exact_binomial_transformed"
        elif not feature_names and not np.any(k):
            low, high = 0., -math.expm1(math.log(1 - options.confidence_level) / exposure)
            method = "exact_one_sided_zero_failure_upper_bound"
        elif not feature_names and exact_boundary_subset:
            # A directly observed pure-type subset supplies a conservative
            # exact one-sided boundary bound, without nuisance estimation.
            alpha = 1 - options.confidence_level
            if estimate <= 1e-9:
                low, high = 0., -math.expm1(math.log(alpha) / float(n[pure] @ counts[pure, index]))
                method = "exact_one_sided_zero_failure_upper_bound_pure_type_subset"
            else:
                def all_fail_log_probability(value):
                    if value == 0:
                        return -math.inf
                    if value == 1:
                        return 0.
                    q = -np.expm1(counts[pure, index] * math.log1p(-value))
                    return float(n[pure] @ np.log(q))
                low = brentq(lambda value: all_fail_log_probability(value) - math.log(alpha), 0., 1.)
                high = 1.
                method = "exact_one_sided_all_failure_lower_bound_pure_type_subset"
        elif feature_names:
            profile_fits = 0
            evaluations = 0
            last_update = monotonic()

            def report_profile_progress():
                nonlocal evaluations, last_update
                evaluations += 1
                now = monotonic()
                if now - last_update >= 1.:
                    last_update = now
                    progress(35 + int(60 * position / len(all_type_ids)),
                             f"TSK {type_id}: computing interval "
                             f"(profile fit {profile_fits}, optimizer evaluation {evaluations})")

            def objective(value):
                nonlocal profile_fits
                profile_fits += 1
                result = model.fit(start=coefficients, fixed=(index, value),
                                   progress_callback=report_profile_progress)
                if not result[3]:
                    raise RuntimeError("Profile nuisance optimization did not converge.")
                touched = np.flatnonzero(np.abs(result[1]) >= coefficient_bound - 1e-8)
                if len(touched):
                    labels = ", ".join(fit_debug["parameters"][item]["name"] for item in touched)
                    raise RuntimeError(
                        f"Profile parameter(s) {labels} reached the Logistic coefficient bound ±{coefficient_bound:g}; "
                        "a stable interval within the numerical limits was not established. "
                        "Increase the coefficient bound and refit to investigate this interval.")
                if result[0] < minimum - max(1e-5, abs(minimum) * 1e-8):
                    raise RuntimeError("Profile found a better logistic optimum; an interval around the original fit is not reliable.")
                return result[0]
            low_logit, high_logit = _profile_interval(float(coefficients[index]), objective, minimum,
                                                    options.confidence_level, -coefficient_bound, coefficient_bound, initial_step=.5)
            low, high = float(expit(low_logit)), float(expit(high_logit))
            if low_logit == -coefficient_bound or high_logit == coefficient_bound:
                raise RuntimeError(
                    f"The profile interval reached the Logistic coefficient bound ±{coefficient_bound:g} "
                    "before crossing the likelihood cutoff; the numerical bound is not a probability 0/1 endpoint. "
                    "Increase the coefficient bound and refit to investigate this interval.")
            method = interval_method
        else:
            def objective(value):
                hazard = -math.log1p(-value) if value < 1 else math.inf
                result = model.fit(fixed=(index, hazard), start=coefficients)
                if not result[3]:
                    raise RuntimeError("Profile nuisance optimization did not converge.")
                return result[0]
            low, high = _profile_interval(estimate, objective, minimum, options.confidence_level, 0., 1.)
            if status == "boundary":
                method = "profile_likelihood_approximate_boundary"
    except (RuntimeError, ValueError, FloatingPointError) as error:
        if getattr(error, "invalidates_fit", False):
            raise
        low = high = None
        status = "interval_unavailable"
        method = None
        interval_error = str(error) or type(error).__name__
    if boundary_engine is not None:
        boundary_engine.progress_callback = None
    if joint_engine is not None:
        joint_engine.progress_callback = None
    return (estimate, low, high, method, status, interval_error, estimate_kind, interval_sidedness)


def analyze_tsk(
    instances: Sequence[TskInstance],
    observations: Sequence[TskChainObservation],
    options: TskAnalysisOptions | None = None,
    progress_callback: Callable[[int, str], None] | None = None,
) -> TskAnalysisResult:
    """Estimate instance-type risk from one homogeneous condition/node group.

    ``residual`` is observed minus predicted chain probability. With features,
    type bars represent the conditional probability at the mean of each numeric
    feature over the measured layout instances and the fixed reference category
    of each categorical feature (not a mean predicted risk).
    ``instance_id`` must be unique within its chain. Repeated TSK types are
    counted separately. Missing and invalid tests must be excluded from n.
    """
    options = options or TskAnalysisOptions()
    validate_analysis_workers(options.analysis_workers)
    validate_xy_model(options.xy_model)
    if not 0 < options.confidence_level < 1:
        raise ValueError("confidence_level must be strictly between 0 and 1.")
    if options.feature_model == "linear_hazard":
        raise ValueError("The linear_hazard feature_model has been removed; only 'logistic' is supported.")
    if options.feature_model != "logistic":
        raise ValueError("feature_model must be 'logistic'.")
    bound = options.logistic_coefficient_bound
    if (isinstance(bound, bool) or not isinstance(bound, Real) or not math.isfinite(bound)
            or not 1 <= bound <= 700):
        raise ValueError("logistic_coefficient_bound must be a finite number between 1 and 700.")
    coefficient_bound = float(bound)
    if options.feature_effects_mode not in ("fixed_zero", "boundary_simulation"):
        raise ValueError("feature_effects_mode must be 'fixed_zero' or 'boundary_simulation'.")
    from .tsk_simulation_inference import validate_simulation_settings
    validate_simulation_settings(options.simulation_replicates, options.simulation_seed, options.simulation_workers)
    feature_names = list(dict.fromkeys((["x", "y"] if options.use_xy else []) + list(options.feature_names)))
    for name in feature_names:
        _name(name, "Feature name")
        if (options.use_xy and options.xy_model == DEFAULT_XY_MODEL
                and (name.startswith("__xy_") or name == "XY")):
            raise ValueError(f"Feature name {name!r} is reserved for the XY spatial model.")
    categorical_names = list(dict.fromkeys(options.categorical_feature_names))
    for name in categorical_names:
        _name(name, "Categorical feature name")
        if name in {"x", "y"}:
            raise ValueError("X and Y coordinates cannot be categorical features.")
        if name not in options.feature_names:
            raise ValueError(f"Categorical feature {name!r} must also be selected in feature_names.")
    progress = progress_callback or (lambda *_: None)
    progress(0, "Validating TSK composition and chain observations")
    normalized = []
    seen = set()
    for instance in instances:
        chain_id = _name(instance.chain_id, "chain_id")
        instance_id = _name(instance.instance_id, "instance_id")
        tsk_id = _name(instance.tsk_id, "tsk_id")
        key = (chain_id, instance_id)
        if key in seen:
            raise ValueError(f"Duplicate physical instance {instance_id!r} in chain {chain_id!r}.")
        seen.add(key)
        normalized.append(TskInstance(chain_id, instance_id, tsk_id, instance.x, instance.y, dict(instance.features)))
    if not normalized:
        raise ValueError("TSK composition is empty.")
    composition_chains = {row.chain_id for row in normalized}
    observation_map = {}
    for row in observations:
        chain_id = _name(row.chain_id, "chain_id")
        if chain_id in observation_map:
            raise ValueError(f"Duplicate observation for chain {chain_id!r}; aggregate one condition/node before fitting.")
        if chain_id not in composition_chains:
            raise ValueError(f"Chain {chain_id!r} has observations but no TSK composition.")
        if any(isinstance(value, bool) or not isinstance(value, Integral) for value in (row.n_tested, row.n_failed)):
            raise ValueError(f"Counts for chain {chain_id!r} must be integers.")
        if not 0 <= row.n_failed <= row.n_tested:
            raise ValueError(f"Chain {chain_id!r} requires 0 <= n_failed <= n_tested.")
        observation_map[chain_id] = TskChainObservation(chain_id, int(row.n_tested), int(row.n_failed))
    chain_ids = sorted((key for key, row in observation_map.items() if row.n_tested > 0),
                       key=natural_sort_key)
    if not chain_ids:
        raise ValueError("No chain has a positive number of valid tested samples.")
    active_chain_ids = set(chain_ids)
    active_instances = [row for row in normalized if row.chain_id in active_chain_ids]
    # Fix the category vocabulary before selecting the chains with data. A
    # sparse batch must not silently choose a different reference category.
    categorical_levels = {
        name: sorted({category_label(row.features.get(name), f"{row.chain_id}/{row.instance_id}: {name}")
                      for row in normalized})
        for name in categorical_names
    }
    for row in active_instances:
        for name in feature_names:
            value = row.x if name == "x" else row.y if name == "y" else row.features.get(name)
            if name in categorical_levels:
                category_label(value, f"{row.chain_id}/{row.instance_id}: {name}")
            else:
                _numeric(value, f"{row.chain_id}/{row.instance_id}: {name}")
    type_ids = sorted({row.tsk_id for row in active_instances}, key=natural_sort_key)
    all_type_ids = sorted({row.tsk_id for row in normalized}, key=natural_sort_key)
    chain_lookup = {name: index for index, name in enumerate(chain_ids)}
    type_lookup = {name: index for index, name in enumerate(type_ids)}
    counts = np.zeros((len(chain_ids), len(type_ids)))
    for row in active_instances:
        counts[chain_lookup[row.chain_id], type_lookup[row.tsk_id]] += 1
    n = np.array([observation_map[name].n_tested for name in chain_ids], dtype=float)
    k = np.array([observation_map[name].n_failed for name in chain_ids], dtype=float)
    warnings = ["Intervals assume independent chain observations; shared die/wafer effects are not included."]
    unused_chains = composition_chains - set(chain_ids)
    if unused_chains:
        warnings.append(f"{len(unused_chains)} composition chains have no valid tested samples and were excluded.")
    diagnostics = {
        "warnings": warnings, "confidence_level": options.confidence_level,
        "interval_method": "profile_likelihood_approximate_with_exact_boundary_special_cases",
        "reference_environment": "Common type probability within the selected condition/node; no feature effects.",
        "model": "type_only", "parameter_count": len(type_ids), "chain_count": len(chain_ids),
        "failure_definition": "Caller-supplied Fail event; missing tests must be excluded from the denominator.",
    }
    progress(10, "Fitting chain failure probabilities")
    boundary_engine = None
    boundary_state = None
    joint_engine = None
    joint_state = None
    boundary_zero_types: set[int] = set()
    if feature_names:
        model = _FeatureModel(counts, n, k, active_instances, chain_ids, type_ids, feature_names,
                              categorical_levels, coefficient_bound=coefficient_bound,
                              xy_model=options.xy_model if options.use_xy else "linear")

        def report_fit_progress(event):
            start_index = int(event.get("start_index", 1))
            ratio = event.get("threshold_ratio")
            ratio_text = f"{ratio:.5g}" if isinstance(ratio, (int, float)) else "—"
            progress(10 + 7 * max(0, min(2, start_index - 1)),
                     f"Logistic 起点 {start_index}/3 · {event.get('phase', '')} · "
                     f"迭代 {event.get('iteration', 0)} · 梯度/标准 {ratio_text}")

        minimum, coefficients, predicted, converged, derivative = model.fit(
            multistart=True, diagnostic_callback=report_fit_progress)
        fit_debug = _plain(build_logistic_fit_debug(model, coefficients, type_ids, converged, derivative))
        diagnostics["fit_debug"] = fit_debug
        clipped_initial = bool(np.any(np.abs(coefficients) >= coefficient_bound - .1))
        check = fit_debug.get("redundant_representation_check")
        review = {"requested_coefficient_bound": coefficient_bound, "canonicalized": False}
        if (clipped_initial and converged and check and check["max_abs_logit_change"] <= 1e-10
                and abs(check["negative_log_likelihood_change"]) <= max(1e-7, abs(minimum) * 32 * np.finfo(float).eps)
                and check["max_abs_coefficient_after"] < coefficient_bound - .1):
            candidate = np.asarray(check["coefficients"], dtype=float)
            value, gradient, prediction, candidate_derivative = model.evaluate(candidate)
            if np.max(np.abs(gradient), initial=0.) / max(float(n.sum()), 1.) < 1e-8:
                coefficients, minimum, predicted, derivative = candidate, value, prediction, candidate_derivative
                review["canonicalized"] = True
                warnings.append("Redundant logit coefficients were replaced by an equivalent finite representation; "
                                "predictions are unchanged and individual identifiability is still checked.")
        zero_observation_types = counts[k > 0].sum(axis=0) == 0
        from .tsk_logistic_joint_boundary import JointLogisticBoundaryFit

        joint_probe = JointLogisticBoundaryFit(model.design, model.chain_index, n, k, len(type_ids),
                                                coefficient_bound=coefficient_bound,
                                                analysis_workers=options.analysis_workers)
        joint_score = joint_probe.stationarity_residual(coefficients)
        independent_score_failed = not math.isfinite(joint_score) or joint_score >= 1e-8
        review.update(independent_direction_score=joint_score, independent_direction_threshold=1e-8)
        # Exposure-normalized optimizer scores can hide separation in a small
        # Chain before any coefficient or fitted logit reaches a tail.
        # Review these observations using the full design, independent of the
        # finite optimizer's stopping point.
        if (independent_score_failed or not converged or np.any(k == 0) or np.any(k == n)
                or np.any(np.abs(coefficients) >= coefficient_bound - .1)
                or np.any(expit(coefficients[:len(type_ids)]) <= 1e-7)
                or np.any(expit(model.design @ coefficients) <= 1e-7)
                or np.any(zero_observation_types)):
            from .tsk_logistic_boundary import LogisticBoundaryFit

            progress(31, "Logistic：在非负 odds 参数下复核零风险边界…")
            candidate_engine = LogisticBoundaryFit(
                model.design, model.chain_index, n, k, len(type_ids), coefficient_bound=coefficient_bound,
                progress_callback=lambda *args: progress(31, "Logistic：复核非负 odds 的边界与收敛…"))
            candidate_state = candidate_engine.fit(coefficients)
            candidate_engine.progress_callback = None
            state_params = np.asarray(candidate_state["params"], dtype=float)
            odds = state_params[:len(type_ids)] * np.asarray(candidate_state["odds_scale"])
            positive_logit = np.full(len(type_ids), -coefficient_bound)
            np.log(odds, out=positive_logit, where=odds > 0)
            accepted = bool(candidate_state["converged"] and not candidate_state["feature_clipped"]
                            and np.all(positive_logit < coefficient_bound - .1)
                            and candidate_state["minimum"] <= minimum + max(1e-7, abs(minimum) * 32 * np.finfo(float).eps))
            type_index = np.argmax(model.design[:, :len(type_ids)], axis=1)
            odds_logits = (positive_logit[type_index]
                           + model.design[:, len(type_ids):] @ state_params[len(type_ids):])
            # A shared coefficient can diverge inside a Fail-containing Chain
            # while an odds-coordinate score vanishes. Resolve this in the
            # joint closure even when the finite-effect odds branch accepted
            # its tiny positive approximation. Exact zero type odds stay in
            # their established nonnegative-odds branch.
            shared_tail = bool(np.any(np.abs(state_params[len(type_ids):]) > 1e-8)
                               and np.any((odds[type_index] > 0) & (np.abs(odds_logits) > 16.)))
            shared_zero_face = bool(candidate_state["zero_type_indices"]
                                    and np.any(model.design[:, len(type_ids):] != 0.))
            joint_review_required = shared_tail or shared_zero_face or independent_score_failed
            review.update(attempted=True, accepted=accepted and not joint_review_required,
                          joint_review_required_by_shared_tail=shared_tail,
                          joint_review_required_by_score=independent_score_failed,
                          joint_review_required_by_shared_zero_face=shared_zero_face, state=_plain(candidate_state))
            accepted = accepted and not joint_review_required
            if accepted:
                boundary_engine, boundary_state = candidate_engine, candidate_state
                coefficients = np.r_[positive_logit, state_params[len(type_ids):]]
                minimum, _, predicted, derivative = boundary_engine.evaluate(state_params)
                converged = True
                boundary_zero_types = set(candidate_state["zero_type_indices"])
                warnings.append("Logistic probabilities were refitted in nonnegative reference odds. "
                                "Validated zero-boundary estimates are reported separately from finite coefficients; "
                                "zero estimates do not establish zero real-world failure risk.")
            else:
                # The old logit gradient can be tiny purely because odds
                # vanish. Do not fall back to that candidate after a failed
                # check in coordinates that resolve the low-risk direction.
                converged = False
                # A type-odds closure cannot retain a shared effect diverging
                # together with compensating TSK intercepts. Investigate the
                # full instance design before withholding any risk query.
                progress(32, "Logistic：保留所有系数的联合补偿，复核组合风险…")
                joint_candidate = joint_probe
                joint_candidate.progress_callback = lambda event: progress(32, joint_progress_message(event))
                try:
                    try:
                        proposed = joint_candidate.fit(coefficients)
                        joint_accepted = bool(proposed.get("converged")
                                              and proposed["minimum"] <= minimum + max(
                                                  1e-7, abs(minimum) * 32 * np.finfo(float).eps))
                        review.update(joint_attempted=True, joint_accepted=joint_accepted,
                                      joint_state=_plain(proposed))
                    except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                        joint_accepted = False
                        review.update(joint_attempted=True, joint_accepted=False, joint_error=str(error))
                    if not joint_accepted:
                        from .tsk_logistic_components import SeparableJointLogisticFit

                        separate = SeparableJointLogisticFit(
                            model.design, model.chain_index, n, k, len(type_ids),
                            coefficient_bound=coefficient_bound,
                            analysis_workers=options.analysis_workers,
                            progress_callback=lambda event: progress(32, joint_progress_message(
                                event, prefix="Logistic 独立子模型复核")))
                        try:
                            recovered = separate.fit(coefficients)
                            review["component_recovery"] = _plain(recovered.get("validation", {}))
                            if recovered.get("usable"):
                                joint_candidate, proposed = separate, recovered
                                joint_accepted = True
                                review.update(joint_accepted=True, joint_state=_plain(proposed))
                        except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                            review["component_recovery_error"] = str(error)
                        finally:
                            separate.progress_callback = None
                    if joint_accepted:
                        coefficients = np.asarray(proposed["coefficients"], dtype=float)
                        minimum = float(proposed["minimum"])
                        predicted = np.asarray(proposed["predicted"], dtype=float)
                        converged = bool(proposed.get("converged"))
                        logits = model.design @ coefficients
                        # A stricter score audit can refine an ordinary finite
                        # fit. Keep its regular covariance/profile inference
                        # only when every retained solution has the same
                        # instance logits; equal Chain predictions alone do
                        # not rule out ambiguous member risks.
                        regular_refinement = bool(
                            proposed.get("parameterization") == "joint_logistic_face" and converged
                            and not proposed["zero_rows"]
                            and np.all(np.abs(coefficients) < coefficient_bound - .1)
                            and np.all(np.abs(logits) < 16.)
                            and proposed.get("equivalent_faces")
                            and all(not face["zero_rows"] and np.allclose(
                                model.design @ np.asarray(face["core_coefficients"]), logits,
                                atol=1e-8, rtol=1e-10) for face in proposed["equivalent_faces"])
                            and joint_probe.stationarity_residual(coefficients) < 1e-8)
                        review["regular_finite_refinement"] = regular_refinement
                        if regular_refinement:
                            minimum, _, predicted, derivative = model.evaluate(coefficients)
                        else:
                            joint_engine, joint_state = joint_candidate, proposed
                            _, _, _, derivative = joint_engine.evaluate(coefficients)
                            warnings.append("Joint coefficient compensation was retained at the Logistic boundary. "
                                            "Risks are checked for each instance condition; the finite coefficient "
                                            "representative may exceed the initial bounds and is not a finite effect estimate.")
                except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                    review.update(joint_attempted=True, joint_accepted=False, joint_error=str(error))
                finally:
                    joint_candidate.progress_callback = None
                if joint_engine is None and not converged:
                    warnings.append("Neither the nonnegative-odds nor joint-coefficient review established a usable fit; "
                                    "risk estimates remain withheld. See the boundary debug report.")
        if review["canonicalized"] or review.get("attempted"):
            review.update(final_coefficients=_plain(coefficients), final_negative_log_likelihood=float(minimum),
                          zero_type_ids=[type_ids[index] for index in sorted(boundary_zero_types)])
            fit_debug["boundary_review"] = review
        diagnostics["fit_debug_report"] = format_logistic_fit_debug(fit_debug)
        rank, identified_all = _rank_identifiable(derivative)
        _, design_identified = _rank_identifiable(model.design)
        identified = identified_all[:len(type_ids)] & design_identified[:len(type_ids)]
        if boundary_engine is not None:
            parameters = np.asarray(boundary_state["params"], dtype=float)
            identified = np.array([bool(design_identified[index] and boundary_engine.identifiable(
                parameters, np.eye(model.width)[index])) for index in range(len(type_ids))])
            diagnostics["boundary_fit"] = _plain(boundary_state)
            diagnostics["rank_parameterization"] = "scaled_type_odds"
        elif joint_engine is not None:
            identified = np.zeros(len(type_ids), dtype=bool)
            previous_progress = joint_engine.progress_callback
            try:
                with joint_engine.parallel_session():
                    for index, type_id in enumerate(type_ids):
                        prefix = f"TSK {type_id} 风险可识别性 {index + 1}/{len(type_ids)}"
                        progress(33, prefix)
                        joint_engine.progress_callback = lambda event, label=prefix: progress(
                            33, joint_progress_message(event, prefix=label))
                        identified[index] = joint_engine.identifiable(coefficients, np.eye(model.width)[index])
                progress(34, f"TSK 参考条件风险复核完成 {len(type_ids)}/{len(type_ids)}")
            finally:
                joint_engine.progress_callback = previous_progress
            boundary_zero_types = {index for index in range(len(type_ids)) if identified[index]
                                   and joint_engine.estimate_kind(np.eye(model.width)[index]) == "boundary_low"}
            diagnostics["joint_boundary_fit"] = _plain(joint_state)
            diagnostics["type_coefficient_identifiable"] = {
                type_id: bool(joint_engine.coefficient_identifiable(index))
                for index, type_id in enumerate(type_ids)}
            diagnostics["rank_parameterization"] = "joint_logistic_face"
            # These are reference-condition zero queries, not whole TSKs
            # fixed to zero in every combination.
            review["zero_type_ids"] = [type_ids[index] for index in sorted(boundary_zero_types)]
            diagnostics["fit_debug_report"] = format_logistic_fit_debug(fit_debug)
        clipped = bool(boundary_engine is None and joint_engine is None
                       and np.any(np.abs(coefficients) >= coefficient_bound - .1))
        if clipped:
            identified[:] = False
            warnings.append("Feature coefficients reached numerical bounds; a finite, stable logistic fit was not established.")
        if model.constant_features:
            warnings.append("Constant feature columns: " + ", ".join(model.constant_features))
        for name, encoding in model.categorical_features.items():
            if len(encoding["levels"]) == 1:
                warnings.append(f"Categorical feature {name!r} has one category; no category contrast is fitted.")
            if encoding["missing_levels"]:
                warnings.append(f"Categorical feature {name!r} has categories without valid chain observations: "
                                + ", ".join(repr(level) for level in encoding["missing_levels"])
                                + "; the topology reference category is retained.")
        probabilities = expit(coefficients[:len(type_ids)])
        if boundary_engine is not None:
            probabilities = np.array([boundary_engine.probability(parameters, np.eye(model.width)[index])
                                      for index in range(len(type_ids))])
        elif joint_engine is not None:
            probabilities = np.array([joint_engine.probability(coefficients, np.eye(model.width)[index])
                                      if identified[index] else math.nan for index in range(len(type_ids))])
        feature_coefficients = {}
        feature_coefficient_identifiable = {}
        for name, encoding in model.categorical_features.items():
            # The zero for the omitted reference level is a coding convention,
            # not an estimated effect or an independent identifiability claim.
            feature_coefficients[name] = {encoding["reference"]: 0.}
            feature_coefficient_identifiable[name] = {encoding["reference"]: None}
        for index, (name, level) in enumerate(model.coefficient_columns, start=len(type_ids)):
            estimable = bool(converged and not clipped and identified_all[index] and design_identified[index])
            if joint_engine is not None:
                estimable = bool(joint_engine.coefficient_identifiable(index))
            value = float(coefficients[index])
            if level is None:
                # Preserve the existing numeric-only coefficient diagnostic.
                feature_coefficients[name] = value
                feature_coefficient_identifiable[name] = estimable
            else:
                feature_coefficients[name][level] = value if estimable else None
                feature_coefficient_identifiable[name][level] = estimable
        reference_environment = (
            "Conditional type probability with numeric features fixed at their training-layout means "
            "and categorical features at their topology reference categories; not an average over instance probabilities."
            if categorical_names else
            "Conditional type probability with every feature fixed at its training-layout mean; not an average over instance probabilities."
        )
        interval_method = ("profile_likelihood_approximate_conditional_reference_environment" if categorical_names
                           else "profile_likelihood_approximate_conditional_mean_environment")
        diagnostics.update({
            "model": "instance_logistic_features",
            "xy_model": options.xy_model if options.use_xy else None,
            "spatial_transform": model.spatial_transform,
            "feature_groups": model.feature_groups,
            "parameter_count": model.width,
            "logistic_coefficient_bound": coefficient_bound,
            "reference_environment": reference_environment,
            "feature_scaling": {name: {"mean": float(mean), "scale": float(scale)} for name, mean, scale in zip(model.numeric_names, model.means, model.scales)},
            "feature_coefficients": feature_coefficients,
            "feature_coefficient_identifiable": feature_coefficient_identifiable,
            "categorical_features": model.categorical_features,
            "feature_reference": {
                **model.numeric_reference,
                **{name: encoding["reference"] for name, encoding in model.categorical_features.items()},
            },
            "interval_method": interval_method,
            "optimization": "Three deterministic starting points; global optimality is not guaranteed.",
        })
    else:
        model = _BaselineModel(counts, n, k)
        minimum, coefficients, predicted, converged = model.fit()
        rank, identified = model.identifiability(coefficients)
        probabilities = -np.expm1(-coefficients)
    partial_fit = bool(joint_state and joint_state.get("partial_fit"))
    diagnostics.update({"converged": bool(converged), "rank": rank, "negative_log_likelihood": float(minimum),
                        "partial_fit": partial_fit})
    if partial_fit:
        warnings.append("Only independently validated Chain likelihood blocks are published. "
                        "The whole model remains unconfirmed; unresolved blocks and cross-block queries are withheld.")
    if not converged and not partial_fit:
        identified[:] = False
        warnings.append("The optimizer did not converge; type estimates and intervals are withheld.")
    if rank < diagnostics["parameter_count"]:
        warnings.append("Individual joint coefficients may be unidentifiable; each complete condition's risk "
                        "is checked using joint directions and likelihood profiles."
                        if joint_engine is not None else
                        "The boundary-fit Jacobian is rank deficient; feasible nonnegative directions are checked "
                        "for each risk estimate. Rank alone does not invalidate zero-boundary estimates."
                        if boundary_engine is not None else
                        "The model is rank deficient; affected type probabilities cannot be independently identified.")
    if not np.all(identified):
        warnings.append("Unidentifiable type estimates are withheld; chain predictions can remain identifiable.")
    progress(35, "Computing type probability intervals")
    instance_counts = Counter(row.tsk_id for row in normalized)
    interval_common = {
        "model": model, "boundary_engine": boundary_engine, "coefficients": coefficients,
        "joint_engine": joint_engine,
        "probabilities": probabilities, "minimum": minimum, "options": options,
        "feature_names": feature_names, "type_ids": type_ids, "all_type_ids": all_type_ids,
        "fit_debug": fit_debug if feature_names else None, "boundary_zero_types": boundary_zero_types,
        "parameters": parameters if boundary_engine is not None else None,
        "interval_method": interval_method if feature_names else None,
        "pure_type_rows": np.count_nonzero(counts, axis=1) == 1,
    }
    interval_jobs = [(position, type_lookup[name], name) for position, name in enumerate(all_type_ids)
                     if name in type_lookup and identified[type_lookup[name]]]
    # Spawning is useful for substantial profile work, but costs more than small
    # fits or exact analytic intervals. Explicit worker selections can override.
    work = len(active_instances) * model.width * len(interval_jobs)
    threshold = 2 if feature_names and work >= 20_000 else 8 if feature_names else len(interval_jobs) + 1
    interval_workers = worker_count(options.analysis_workers, len(interval_jobs), threshold)
    interval_results = None
    intervals_parallel = False
    if interval_workers > 1:
        pending_jobs = interval_jobs
        prefix = []
        if options.analysis_workers == 0:
            # Unidentifiable types before this first job have not been
            # assembled yet; keep the probe at the interval stage's start.
            interval_common["progress"] = lambda _, message: progress(35, message)
            started = monotonic()
            prefix = [_type_interval_task(interval_common, interval_jobs[0], lambda: None)]
            elapsed = monotonic() - started
            interval_common.pop("progress")
            pending_jobs = interval_jobs[1:]
            interval_results = {interval_jobs[0][1]: prefix[0]}
            # Use a completed interval as the timing probe; never refit it.
            interval_workers = (min(4, worker_count(0, len(pending_jobs))) if elapsed >= .25 else 1)
        if interval_workers > 1:
            execution = {}
            computed = ordered_parallel_map(_type_interval_task, pending_jobs, common=interval_common,
                workers=interval_workers, execution=execution,
                progress_callback=lambda completed, total: progress(
                    35 + int(60 * (len(prefix) + completed) / len(interval_jobs)),
                    f"TSK：并行计算概率区间，已完成 {len(prefix) + completed}/{len(interval_jobs)}…"))
            interval_results = {job[1]: result for job, result in zip(interval_jobs, prefix + computed)}
            execution["workers_requested"] = options.analysis_workers
            diagnostics.setdefault("parallel_execution", {})["type_intervals"] = execution
            warnings.extend(execution["execution_warnings"])
            intervals_parallel = True
    if not intervals_parallel:
        interval_common["progress"] = progress
    type_rows = []
    for position, type_id in enumerate(all_type_ids):
        instance_count = instance_counts[type_id]
        if type_id not in type_lookup:
            type_rows.append(TskTypeEstimate(type_id, None, None, None, False, "no_data", instance_count, 0))
            continue
        index = type_lookup[type_id]
        exposure = int(np.dot(n, counts[:, index]))
        if not identified[index]:
            query_fit_valid = converged or (partial_fit and joint_engine.query_validated(np.eye(model.width)[index]))
            type_rows.append(TskTypeEstimate(type_id, None, None, None, False,
                                             "unidentifiable" if query_fit_valid else "fit_not_converged", instance_count, exposure))
            progress(95 if intervals_parallel else 35 + int(60 * (position + 1) / len(all_type_ids)),
                     f"TSK {type_id}: not independently identifiable")
            continue
        if interval_results is None or index not in interval_results:
            values = _type_interval_task(interval_common, (position, index, type_id), lambda: None)
        else:
            values = interval_results[index]
        estimate, low, high, method, status, interval_error, estimate_kind, interval_sidedness = values
        if interval_error is not None:
            warnings.append(f"TSK {type_id}: confidence interval unavailable ({interval_error}).")
        type_rows.append(TskTypeEstimate(type_id, estimate, low, high, True, status, instance_count, exposure,
                                        method, interval_error, estimate_kind, interval_sidedness,
                                        options.confidence_level,
                                        "boundary_unbounded" if estimate_kind in {"boundary_low", "boundary_high"} else None))
        progress(95 if intervals_parallel else 35 + int(60 * (position + 1) / len(all_type_ids)),
                 f"Computed interval for TSK {type_id}")
    chain_rows = []
    for chain_id, observation in sorted(observation_map.items(), key=lambda item: natural_sort_key(item[0])):
        tested, failed = observation.n_tested, observation.n_failed
        if not tested:
            chain_rows.append(TskChainEstimate(chain_id, tested, failed, None, None, None, None, "no_data"))
            continue
        observed = failed / tested
        if partial_fit and chain_lookup[chain_id] not in joint_state["valid_chain_indices"]:
            chain_rows.append(TskChainEstimate(chain_id, tested, failed, observed, None, None, None, "fit_not_converged"))
            continue
        prediction = float(predicted[chain_lookup[chain_id]])
        chain_rows.append(TskChainEstimate(chain_id, tested, failed, observed, prediction, observed - prediction,
                                          _deviance(tested, failed, prediction), "ok" if converged or partial_fit else "fit_not_converged"))
    diagnostics["deviance"] = sum(row.deviance_residual ** 2 for row in chain_rows if row.deviance_residual is not None)
    diagnostics["identifiable_type_count"] = sum(row.identifiable for row in type_rows)
    from .tsk_joint_risk import MAX_DESIGN_CELLS, MAX_DESIGN_WIDTH, MAX_INSTANCES, build_joint_risk_report

    prediction_context = None
    if feature_names:
        # Freeze the fitted likelihood, coding and topology so interactive
        # category views never rerun classification or read a changed template.
        joint_context = {
            "version": 1, "model": diagnostics["model"],
            "confidence_level": options.confidence_level,
            "converged": bool(converged), "clipped": clipped,
            "partial_fit": partial_fit,
            "logistic_coefficient_bound": coefficient_bound,
            "boundary_fit": _plain(boundary_state),
            "joint_boundary_fit": _plain(joint_state),
            "negative_log_likelihood": float(minimum), "coefficients": coefficients,
            "design": model.design, "chain_index": model.chain_index,
            "chain_ids": chain_ids, "n_tested": n, "n_failed": k,
            "type_ids": type_ids, "all_type_ids": all_type_ids,
            "coefficient_columns": model.coefficient_columns,
            "xy_model": options.xy_model if options.use_xy else None,
            "spatial_transform": model.spatial_transform,
            "feature_groups": model.feature_groups,
            "categorical_features": model.categorical_features,
            "numeric_reference": model.numeric_reference,
            "numeric_scaling": diagnostics["feature_scaling"],
            "topology": [
                {"chain_id": row.chain_id, "instance_id": row.instance_id, "tsk_id": row.tsk_id,
                 "categories": {name: category_label(row.features[name], name) for name in categorical_names}}
                for row in normalized
            ],
        }
        if categorical_names or model.spatial_transform:
            prediction_context = _plain(joint_context)
    else:
        skip_joint_matrix = (len(type_ids) > MAX_DESIGN_WIDTH or len(active_instances) > MAX_INSTANCES
                             or len(type_ids) * len(active_instances) > MAX_DESIGN_CELLS)
        joint_context = None if skip_joint_matrix else {
            "version": 1, "model": "type_only", "confidence_level": options.confidence_level,
            "converged": bool(converged), "clipped": False,
            "negative_log_likelihood": float(minimum), "coefficients": coefficients,
            "design": np.eye(len(type_ids))[[type_lookup[row.tsk_id] for row in active_instances]],
            "chain_index": [chain_lookup[row.chain_id] for row in active_instances],
            "chain_ids": chain_ids, "n_tested": n, "n_failed": k,
            "type_ids": type_ids, "all_type_ids": all_type_ids, "coefficient_columns": [],
            "categorical_features": {}, "numeric_reference": {}, "numeric_scaling": {},
        }
    from .tsk_chain_members import build_chain_members

    progress(95, "TSK：计算 Chain 成员在实际实例条件下的风险…")
    member_execution = {}
    member_engine = joint_engine if joint_engine is not None else boundary_engine
    previous_member_progress = member_engine.progress_callback if member_engine is not None else None
    try:
        member_rows = build_chain_members(
            normalized, chain_rows, type_rows, context=joint_context, boundary_engine=boundary_engine,
            joint_engine=joint_engine,
            feature_names=feature_names, categorical_feature_names=categorical_names,
            analysis_workers=options.analysis_workers, execution=member_execution,
            progress_callback=lambda value, message: progress(95 + int(2 * value / 100), message))
        for row in chain_rows:
            row.members = member_rows.get(row.chain_id, [])
    finally:
        if member_engine is not None:
            member_engine.progress_callback = previous_member_progress
    diagnostics.setdefault("parallel_execution", {})["chain_members"] = member_execution
    warnings.extend(member_execution.get("execution_warnings", []))
    if feature_names and review.get("joint_attempted"):
        joint_execution = (joint_engine if joint_engine is not None else joint_probe).parallel_execution
        diagnostics["parallel_execution"]["joint_boundary"] = joint_execution
        warnings.extend(joint_execution.get("execution_warnings", []))
    progress(97, "TSK：检查不可拆参数的联合风险…")
    try:
        if joint_context is None:
            joint_risk = {"version": 1, "status": "computation_limited", "rows": [], "omitted_count": 0,
                          "notes": ["实例或参数规模超过联合风险计算上限；主分析结果不受影响。"]}
        else:
            joint_risk = build_joint_risk_report(joint_context, diagnostics, progress_callback=lambda value, message: progress(
                97 + int(2 * value / 100), message))
    except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
        if getattr(error, "invalidates_fit", False):
            raise
        joint_risk = {"version": 1, "status": "unavailable", "rows": [], "omitted_count": 0,
                      "notes": [f"联合风险未能完成：{error}"]}
        diagnostics["warnings"].append(f"Joint risk report unavailable: {error}")
    feature_effects = {"version": 1, "status": "no_features", "features": [],
                       "confidence_level": options.confidence_level,
                       "reason": "本次分析未选择数值或类别特征；TSK 截距不参与特征整体检验。"}
    if joint_context is None:
        feature_effects.update(status="computation_limited",
                               reason="TSK 类型或实例规模超过类型对比的矩阵计算上限；未计算系数区间与两两比较。")
    if joint_context is not None:
        from .tsk_feature_effects import build_tsk_feature_effects

        progress(99, "TSK：计算类型对比、特征整体检验与档位对比…")
        try:
            feature_effects = build_tsk_feature_effects(
                joint_context, confidence_level=options.confidence_level,
                zero_risk_policy=options.feature_effects_mode,
                simulation_replicates=options.simulation_replicates, simulation_seed=options.simulation_seed,
                simulation_workers=options.simulation_workers,
                analysis_workers=options.analysis_workers,
                progress_callback=lambda _value, message: progress(99, message))
        except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
            feature_effects = {"version": 1, "status": "unavailable", "features": [],
                               "confidence_level": options.confidence_level,
                               "reason": f"特征影响分析未能完成：{error}"}
            diagnostics["warnings"].append(f"Feature effects report unavailable: {error}")
    progress(100, "TSK analysis complete")
    return TskAnalysisResult(type_rows, chain_rows, _plain(diagnostics), options,
                             prediction_context, joint_risk, _plain(feature_effects))
