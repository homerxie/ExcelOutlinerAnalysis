"""Numerical joint-logit closure for attainable zero-instance faces.

A recession direction may change every TSK intercept and every shared effect.
Only instance logits certified by a full-design linear program are removed.
Finite contrasts are fitted on the remaining likelihood face.  Certification
uses shared-odds reentry scores when a removed instance belongs to a Fail
Chain. Certification is sufficient and local: the nonlinear grouped-Chain
likelihood is not a GLM, and face search, multistart and profiling do not
constitute an exhaustive search or a proof of a global optimum.
"""
from __future__ import annotations

import hashlib
import math
from contextlib import contextmanager
from fractions import Fraction
from collections import deque
from functools import wraps
from time import monotonic

import numpy as np
from scipy.linalg import svd
from scipy.optimize import brentq, linprog, minimize
from scipy.special import expit
from scipy.stats import chi2

from .tsk_logistic_boundary import (
    CONSERVATIVE_EXACT_METHOD, EXACT_METHOD, _plain,
)
from .tsk_parallel import validate_analysis_workers, worker_count

INTERIOR_METHOD = "profile_likelihood_approximate_joint_logistic_contrast"
BOUNDARY_METHOD = "profile_likelihood_approximate_joint_logistic_zero_boundary"
_UNCACHED_FAILURE = object()


def _parallel_scope(function):
    """Standalone calls close workers; explicit outer sessions reuse them."""
    @wraps(function)
    def run(self, *args, **kwargs):
        with self.parallel_session():
            return function(self, *args, **kwargs)
    return run


class JointBoundaryBetterOptimumError(RuntimeError):
    """A nuisance refit invalidated the likelihood used by all published queries."""
    invalidates_fit = True


def _space(matrix, absolute_tolerance=0.):
    """An orthonormal row basis and a transform with orthonormal fitted columns."""
    matrix = np.asarray(matrix, dtype=float)
    if not matrix.size:
        return np.zeros((matrix.shape[1], 0)), np.zeros((matrix.shape[1], 0))
    _, singular, right = np.linalg.svd(matrix, full_matrices=False)
    keep = singular > max(absolute_tolerance, max(matrix.shape) * np.finfo(float).eps * singular[0] * 100)
    basis = right[keep].T
    return basis, basis / singular[keep]


def _contained(vector, basis, tolerance=None):
    if tolerance is None:
        tolerance = 100 * np.finfo(float).eps * max(basis.shape, default=1)
    magnitude = float(np.max(np.abs(vector), initial=0.))
    if not math.isfinite(magnitude):
        return False
    if magnitude == 0:
        return True
    normalized = vector / magnitude
    return np.linalg.norm(normalized - basis @ (basis.T @ normalized)) <= tolerance * np.linalg.norm(normalized)


def _null_space(matrix, rcond=None):
    """The same right nullspace without a quadratic tall left-SVD matrix."""
    matrix = np.asarray(matrix)
    _, singular, right = svd(matrix, full_matrices=matrix.shape[0] < matrix.shape[1])
    if rcond is None:
        rcond = np.finfo(singular.dtype).eps * max(matrix.shape)
    tolerance = np.max(singular, initial=0.) * rcond
    return right[int(np.sum(singular > tolerance)):].T.conj()


class JointLogisticBoundaryFit:
    """Fit attainable zero faces while retaining joint compensation.

    ``params`` and ``coefficients`` in saved states are finite representatives;
    ``core_coefficients`` and ``zero_rows`` define the exact fitted limit.
    ``coefficient_bound`` is an initial search scale, never a statistical bound.
    """
    def __init__(self, design, chain_index, n, k, type_count, coefficient_bound=35., progress_callback=None, analysis_workers=1):
        # Cache keys are valid for this owned, immutable model data only.
        self.design = np.array(design, dtype=float, copy=True)
        self.chain_index = np.array(chain_index, dtype=int, copy=True)
        self.n, self.k = np.array(n, dtype=float, copy=True), np.array(k, dtype=float, copy=True)
        self.type_count = int(type_count)
        self.coefficient_bound = float(coefficient_bound)
        self.progress_callback = progress_callback
        self.analysis_workers = validate_analysis_workers(analysis_workers)
        self._parallel_runner = None
        self._parallel_session_depth = 0
        self.parallel_execution = {"workers_requested": self.analysis_workers, "workers_used": 1,
                                   "execution_backend": "serial", "execution_warnings": [],
                                   "worker_pids": [], "workers_observed": 0, "pilot_starts": 0}
        if (self.design.ndim != 2 or not len(self.design) or not 0 < self.type_count <= self.design.shape[1]
                or self.chain_index.shape != (len(self.design),) or self.n.ndim != 1 or self.n.shape != self.k.shape
                or not len(self.n) or np.any(self.n <= 0) or np.any(self.k < 0) or np.any(self.k > self.n)
                or np.any(self.chain_index < 0) or np.any(self.chain_index >= len(self.n))
                or not all(np.all(np.isfinite(a)) for a in (self.design, self.n, self.k))
                or not math.isfinite(self.coefficient_bound) or self.coefficient_bound <= .1):
            raise ValueError("Invalid joint Logistic model arrays or search scale.")
        kinds = self.design[:, :self.type_count]
        if not (np.all((kinds == 0) | (kinds == 1)) and np.all(kinds.sum(axis=1) == 1)):
            raise ValueError("Joint Logistic instances require exactly one TSK indicator.")
        if np.any(np.bincount(self.chain_index, minlength=len(self.n)) == 0):
            raise ValueError("Every Chain needs at least one instance.")
        self.width = self.design.shape[1]
        self._raw_design_basis = None
        # Normalize source columns before SVD. A feature measured in tiny units
        # is not absent information and may require a very large coefficient.
        self._column_scale = np.linalg.norm(self.design, axis=0)
        self._column_scale[self._column_scale == 0] = 1.
        self._scaled_design_basis, scaled_transform = _space(self.design / self._column_scale)
        self._design_transform = scaled_transform / self._column_scale[:, None]
        self._reduced_design = self.design @ self._design_transform
        self._normalized_design = self._reduced_design / np.maximum(np.linalg.norm(self._reduced_design, axis=1)[:, None], 1e-300)
        self._positive_chains = self.k > 0
        self._failed_rows = self._positive_chains[self.chain_index]
        self._pass_counts = self.n - self.k
        self._derivative_index = (self.chain_index[:, None] * self.width + np.arange(self.width)).ravel()
        digest = hashlib.sha256()
        for value in (self.design, self.chain_index.astype(float), self.n, self.k, np.array([self.type_count])):
            digest.update(str(value.shape).encode("ascii"))
            digest.update(np.ascontiguousarray(value, dtype="<f8").tobytes())
        self._fingerprint = digest.hexdigest()
        _, self._design_group = np.unique(self.design, axis=0, return_inverse=True)
        self._design_group_count = int(self._design_group.max()) + 1
        self.state = None
        self._profile_cache, self._identified_cache = {}, {}
        self._face_cache, self._certificate_cache, self._coordinate_cache = {}, {}, {}
        self._reentry_geometry_cache, self._upper_cache, self._matching_cache, self._kind_cache = {}, {}, {}, {}
        # Certificates are only a mask/query key and an optional short ray.
        # A fixed 128-entry FIFO thrashes when each profile repeatedly scans
        # more than 128 candidate masks in the same order. Keep two initial
        # scans when feasible, with a conservative 16 MiB/8192-entry budget.
        # Heavy coordinate and reentry geometry caches retain their own caps.
        certificate_entry_bytes = (len(self.design) + 7) // 8 + 56 * self.width + 768
        initial_face_count = self._design_group_count + 2 * self.width + 1
        self._certificate_cache_limit = max(1, min(max(128, 2 * initial_face_count), 8192,
                                                   (16 * 1024 * 1024) // certificate_entry_bytes))
        self._started_at = monotonic()
        self._last_progress = self._started_at
        self._search_serial = self._profile_serial = self._query_serial = 0
        self._progress_context = {}
        for value in (self.design, self.chain_index, self.n, self.k, self._reduced_design, self._normalized_design):
            value.flags.writeable = False

    def _progress(self, phase, *, force=False, **values):
        if self.progress_callback is None:
            return
        now = monotonic()
        if force or now - self._last_progress >= 1.:
            self._last_progress = now
            self.progress_callback({**self._progress_context, "phase": phase,
                                    "elapsed_seconds": max(0., now - self._started_at), **values})

    @contextmanager
    def parallel_session(self):
        """Reuse a lazy worker pool across fits, faces and profile queries."""
        self._parallel_session_depth += 1
        try:
            yield self
        except BaseException:
            self.close(terminate=True)
            raise
        finally:
            self._parallel_session_depth -= 1
            if self._parallel_session_depth == 0:
                self.close()

    def close(self, *, terminate=False):
        runner, self._parallel_runner = self._parallel_runner, None
        if runner is not None:
            runner.close(terminate=terminate)

    def __getstate__(self):
        # Outer type/member query pools may serialize a fitted engine. Process
        # handles and UI callbacks are never part of a worker's model snapshot.
        state = self.__dict__.copy()
        state.update(_parallel_runner=None, _parallel_session_depth=0,
                     progress_callback=None, _progress_context={})
        return state

    @staticmethod
    def _cache_put(cache, key, value, limit=128):
        # Eviction only discards reusable calculations; it never prunes work.
        if len(cache) >= limit and key not in cache:
            cache.pop(next(iter(cache)))
        cache[key] = value
        return value

    @staticmethod
    def _geometry_key(zero, vector=None):
        return (np.packbits(np.asarray(zero, dtype=bool)).tobytes(),
                None if vector is None else tuple(np.asarray(vector, dtype=float)))

    def _matching_rows(self, vector):
        key = tuple(np.asarray(vector, dtype=float))
        if key not in self._matching_cache:
            self._cache_put(self._matching_cache, key, np.all(self.design == vector, axis=1), limit=64)
        return self._matching_cache[key]

    @property
    def design_basis(self):
        # Retain the optional inspection API without paying for an unused raw
        # SVD on every ordinary fit's independent-stationarity probe.
        if self._raw_design_basis is None:
            self._raw_design_basis = _space(self.design)[0]
            self._raw_design_basis.flags.writeable = False
        return self._raw_design_basis

    def _query(self, vector):
        vector = np.asarray(vector, dtype=float)
        if vector.shape != (self.width,) or not np.all(np.isfinite(vector)):
            raise ValueError("Invalid joint Logistic contrast.")
        indicators = vector[:self.type_count]
        if np.count_nonzero(indicators) != 1 or np.max(indicators) != 1.:
            raise ValueError("A probability query must select exactly one TSK.")
        return vector

    def _evaluate(self, theta, zero_rows=None, *, hessian=False, fixed=None):
        logits = self.design @ theta
        matching = np.zeros(len(self.design), dtype=bool)
        if fixed is not None:
            matching = self._matching_rows(fixed[0])
            logits[matching] = fixed[1]
        if zero_rows is not None:
            logits = logits.copy()
            logits[zero_rows] = -math.inf
        probability = expit(logits)
        derivative_probability = probability.copy()
        derivative_probability[matching] = 0.
        hazards = np.bincount(self.chain_index, weights=np.logaddexp(0., logits), minlength=len(self.n))
        predicted = -np.expm1(-hazards)
        positive = self._positive_chains
        derivative = np.bincount(self._derivative_index, weights=(derivative_probability[:, None] * self.design).ravel(),
                                 minlength=len(self.n) * self.width).reshape(len(self.n), self.width)
        if np.any(hazards[positive] <= 0) or not np.all(np.isfinite(hazards)):
            return math.inf, np.full(self.width, math.nan), predicted, derivative, None
        slope = self._pass_counts.copy()
        loss = float(slope @ hazards)
        slope[positive] -= self.k[positive] * np.exp(-hazards[positive]) / predicted[positive]
        loss -= float(self.k[positive] @ np.log(predicted[positive]))
        gradient = derivative.T @ slope
        curvature = None
        if hessian:
            weights = np.zeros(len(self.n))
            weights[positive] = self.k[positive] * np.exp(-hazards[positive]) / predicted[positive] ** 2
            curvature = derivative.T @ (weights[:, None] * derivative)
            curvature += self.design.T @ ((slope[self.chain_index] * derivative_probability * (1 - probability))[:, None] * self.design)
        return loss, gradient, predicted, derivative, curvature

    def evaluate(self, params):
        """Evaluate the exact fitted face, using finite active-row coefficients."""
        theta = np.asarray(params, dtype=float)
        if theta.shape != (self.width,) or not np.all(np.isfinite(theta)):
            raise ValueError("Invalid joint Logistic coefficients.")
        if self.state is not None:
            # Avoid subtracting enormous compensating coefficients when the
            # caller passes the stored representative.
            if np.array_equal(theta, np.asarray(self.state["coefficients"])):
                theta = np.asarray(self.state["core_coefficients"])
            zero = np.asarray(self.state["zero_rows"], dtype=int)
        else:
            zero = None
        return self._evaluate(theta, zero)[:4]

    def fitted_evaluation(self):
        if self.state is None:
            raise RuntimeError("Fit the joint Logistic model first.")
        return self.evaluate(self.state["coefficients"])

    def _scaled_score(self, gradient, derivative, transform):
        if not np.all(np.isfinite(gradient)) or not np.all(np.isfinite(derivative)):
            return math.inf
        if not transform.shape[1]:
            return 0.
        local = derivative @ transform
        # Independent likelihood directions keep a very large Chain from
        # hiding the score of a small Chain through coefficient cancellation.
        _, _, right = np.linalg.svd(np.sqrt(self.n)[:, None] * local,
                                    full_matrices=len(self.n) < local.shape[1])
        rotation = right.T
        exposure = np.maximum(np.abs(local @ rotation).T @ self.n, 1.)
        return float(np.max(np.abs(rotation.T @ (transform.T @ gradient)) / exposure, initial=0.))

    def stationarity_residual(self, theta):
        """Check a full finite fit without fitting or choosing a zero face."""
        theta = np.asarray(theta, dtype=float)
        if theta.shape != (self.width,) or not np.all(np.isfinite(theta)):
            return math.inf
        loss, gradient, _, derivative, _ = self._evaluate(theta)
        return self._scaled_score(gradient, derivative, self._design_transform) if math.isfinite(loss) else math.inf

    def instance_hazards(self, params=None):
        if self.state is None:
            raise RuntimeError("Fit the joint Logistic model first.")
        theta = np.asarray(self.state["core_coefficients"] if params is None else params, dtype=float)
        if params is not None and np.array_equal(theta, self.state["coefficients"]):
            theta = np.asarray(self.state["core_coefficients"])
        if theta.shape != (self.width,) or not np.all(np.isfinite(theta)):
            raise ValueError("Invalid joint Logistic coefficients.")
        hazards = np.logaddexp(0., self.design @ theta)
        hazards[np.asarray(self.state["zero_rows"], dtype=int)] = 0.
        return hazards

    def _face(self, constraint=None):
        key = None if constraint is None else tuple(np.asarray(constraint, dtype=float))
        if key not in self._face_cache:
            self._cache_put(self._face_cache, key, self._compute_face(constraint))
        zero, ray = self._face_cache[key]
        return zero.copy(), ray.copy()

    def _compute_face(self, constraint=None):
        """Maximal removable set within the sufficient monotone recession cone."""
        transform = self._design_transform
        reduced = self._reduced_design
        rows = self._normalized_design
        failed = self._failed_rows
        equalities = rows[failed]
        if constraint is not None:
            extra = np.asarray(constraint) @ transform
            if np.linalg.norm(extra) > 1e-13:
                equalities = np.vstack([equalities, extra / np.linalg.norm(extra)])
        passed = rows[~failed]
        zero = np.zeros(len(self.design), dtype=bool)
        ray = np.zeros(transform.shape[1])
        if not len(passed) or not transform.shape[1]:
            return zero, transform @ ray
        pending = np.ones(len(passed), dtype=bool)
        for iteration in range(len(passed) + 1):
            if not np.any(pending):
                break
            self._progress("joint_face", operation="monotone_linear_program", iteration=iteration + 1,
                           zero_instance_count=int(np.sum(~pending)))
            result = linprog(passed[pending].sum(axis=0), A_ub=passed, b_ub=np.zeros(len(passed)),
                             A_eq=equalities if len(equalities) else None,
                             b_eq=np.zeros(len(equalities)) if len(equalities) else None,
                             bounds=[(-1., 1.)] * transform.shape[1], method="highs")
            if not result.success:
                raise RuntimeError("Joint monotone-face linear program failed.")
            movement = passed @ result.x
            if np.max(movement, initial=0.) > 1e-7 or (len(equalities) and np.max(np.abs(equalities @ result.x)) > 1e-7):
                raise RuntimeError("Joint monotone-face certificate is numerically infeasible.")
            removed = pending & (movement < -1e-8)
            if not np.any(removed):
                break
            ray += result.x
            pending[removed] = False
        zero[np.flatnonzero(~failed)[~pending]] = True
        full_ray = transform @ ray
        if np.any(zero):
            # Refine away equality roundoff before making a finite representative.
            retained = reduced[~zero]
            if constraint is not None:
                retained = np.vstack([retained, np.asarray(constraint) @ transform])
            active_basis, _ = _space(retained)
            ray -= active_basis @ (active_basis.T @ ray)
            full_ray = transform @ ray
            movement = self.design @ full_ray
            if np.max(movement[zero]) >= -1e-10:
                raise RuntimeError("Joint face does not retain a strict recession certificate.")
            full_ray /= -float(np.max(movement[zero]))
            retained_movement = self.design[~zero] @ full_ray
            if (np.max(np.abs(retained_movement), initial=0.) > 1e-7
                    or (constraint is not None and abs(float(np.asarray(constraint) @ full_ray)) > 1e-7)):
                raise RuntimeError("Joint recession normalization changed a retained constraint.")
        return zero, full_ray

    def _face_certificate(self, zero, constraint=None):
        key = self._geometry_key(zero, constraint)
        if key not in self._certificate_cache:
            result = self._compute_face_certificate(zero, constraint)
            if result is _UNCACHED_FAILURE:
                return None
            self._cache_put(self._certificate_cache, key, result, limit=self._certificate_cache_limit)
        result = self._certificate_cache[key]
        return None if result is None else result.copy()

    def _compute_face_certificate(self, zero, constraint=None):
        """Certify an attainable zero face, including rows in Fail Chains."""
        zero = np.asarray(zero, dtype=bool)
        if not np.any(zero):
            return np.zeros(self.width)
        counts = np.bincount(self.chain_index[~zero], minlength=len(self.n))
        if np.any((self.k > 0) & (counts == 0)):
            return None
        reduced = self._reduced_design
        rows = self._normalized_design
        retained = rows[~zero]
        if constraint is not None:
            extra = np.asarray(constraint) @ self._design_transform
            retained = np.vstack([retained, extra / max(np.linalg.norm(extra), 1e-300)])
        basis, _ = _space(retained)
        if any(_contained(row, basis) for row in rows[zero]):
            return None
        # Maximize one common strict margin. Equalities retain all finite
        # logits and, for a profile, the requested contrast.
        self._progress("joint_face", operation="face_certificate_linear_program", zero_instance_count=int(np.sum(zero)))
        result = linprog(np.r_[np.zeros(reduced.shape[1]), -1.],
                         A_ub=np.c_[rows[zero], np.ones(np.sum(zero))], b_ub=np.zeros(np.sum(zero)),
                         A_eq=np.c_[retained, np.zeros(len(retained))] if len(retained) else None,
                         b_eq=np.zeros(len(retained)) if len(retained) else None,
                         bounds=[(-1., 1.)] * reduced.shape[1] + [(0., None)], method="highs")
        if not result.success:
            return None if result.status == 2 else _UNCACHED_FAILURE
        if result.x[-1] <= 1e-8:
            return None
        direction = result.x[:-1] - basis @ (basis.T @ result.x[:-1])
        ray = self._design_transform @ direction
        movement = self.design @ ray
        if np.max(movement[zero]) >= -1e-10:
            return None
        ray /= -float(np.max(movement[zero]))
        if (np.max(np.abs(self.design[~zero] @ ray), initial=0.) > 1e-7
                or (constraint is not None and abs(float(np.asarray(constraint) @ ray)) > 1e-7)):
            return None
        return ray

    def _face_coordinates(self, zero, constraint=None):
        vector = None if constraint is None else constraint[0]
        key = self._geometry_key(zero, vector)
        if key not in self._coordinate_cache:
            offset, transform = self._compute_face_coordinates(zero, constraint)
            transform.flags.writeable = False
            self._cache_put(self._coordinate_cache, key, transform)
            return offset, transform
        transform = self._coordinate_cache[key]
        if constraint is None:
            offset = np.zeros(self.width)
        else:
            contrast = vector @ self._design_transform
            offset = self._design_transform @ (contrast * constraint[1] / float(contrast @ contrast))
        return offset, transform

    def _compute_face_coordinates(self, zero, constraint=None):
        full_transform = self._design_transform
        if constraint is None:
            offset = np.zeros(self.width)
            nuisance = np.eye(full_transform.shape[1])
        else:
            vector, logit = constraint
            contrast = vector @ full_transform
            offset = full_transform @ (contrast * logit / float(contrast @ contrast))
            nuisance = _null_space(contrast[None, :])
        projected = self._reduced_design[~zero] @ nuisance
        _, reduced_transform = _space(projected, absolute_tolerance=max(self.design.shape) * np.finfo(float).eps * 100)
        return offset, full_transform @ nuisance @ reduced_transform

    def _reentry_groups(self, zero, constraint=None):
        key = self._geometry_key(zero, None if constraint is None else constraint[0])
        if key in self._reentry_geometry_cache:
            return self._reentry_geometry_cache[key]
        retained = self._reduced_design[~zero]
        retained_original = self.design[~zero]
        if constraint is not None:
            retained = np.vstack([retained, constraint[0] @ self._design_transform])
            retained_original = np.vstack([retained_original, constraint[0]])
        directions = _null_space(retained, rcond=max(self.design.shape) * np.finfo(float).eps * 100)
        projected = self._reduced_design[zero] @ directions
        indices = np.flatnonzero(zero)
        selections, assigned = [], np.zeros(len(indices), dtype=bool)
        exact_basis = None
        membership = {}

        def same_normal(left, right):
            nonlocal exact_basis
            pair = (int(self._design_group[left]), int(self._design_group[right]))
            if pair[0] == pair[1]:
                return True
            if pair in membership:
                return membership[pair]
            if exact_basis is None:
                # Nearly equal exponents cannot be rounded into a common
                # shared-odds multiplier: even a 1e-9 exponent difference
                # changes the leading term as the odds approach exact zero.
                # An exact rational span check (of the supplied float values)
                # proves ties while tolerating SVD projection roundoff.
                exact_basis = []
                target_rank = retained.shape[1] - directions.shape[1]
                for row in np.unique(retained_original, axis=0):
                    self._progress("joint_reentry", operation="exact_normal_span", zero_instance_count=len(indices))
                    value = [Fraction.from_float(float(item)) for item in row]
                    for pivot, basis_row in exact_basis:
                        amount = value[pivot]
                        if amount:
                            value = [a - amount * b for a, b in zip(value, basis_row)]
                    pivot = next((i for i, item in enumerate(value) if item), None)
                    if pivot is not None:
                        amount = value[pivot]
                        exact_basis.append((pivot, [item / amount for item in value]))
                        exact_basis.sort(key=lambda item: item[0])
                    if len(exact_basis) >= target_rank:
                        break
            value = [Fraction.from_float(float(a)) - Fraction.from_float(float(b))
                     for a, b in zip(self.design[left], self.design[right])]
            for pivot, basis_row in exact_basis:
                amount = value[pivot]
                if amount:
                    value = [a - amount * b for a, b in zip(value, basis_row)]
            membership[pair] = not any(value)
            return membership[pair]

        for index in range(len(indices)):
            if assigned[index]:
                continue
            self._progress("joint_reentry", operation="normal_group_geometry", group_index=len(selections) + 1, zero_instance_count=len(indices))
            norm = max(np.linalg.norm(projected[index]), 1e-300)
            close = np.linalg.norm(projected - projected[index], axis=1) <= 1e-8 * norm
            same = np.array([bool(close[i] and same_normal(indices[index], other)) for i, other in enumerate(indices)])
            assigned |= same
            selected = indices[same]
            selected.flags.writeable = False
            selections.append(selected)
        return self._cache_put(self._reentry_geometry_cache, key, (directions.shape[1], tuple(selections)))

    def _reentry_validation(self, core, zero, ray, constraint=None):
        """Check attainable odds reentry rather than vanishing logit scores.

        Removed rows with the same projection onto the retained nullspace
        share their reentry multiplier. Their different finite offsets must
        remain in the score: one adverse Chain can be offset by another Chain
        through the same shared effect. Nonnegative scores for all multiplier
        groups give a sufficient first-order certificate. A one-dimensional
        face also permits positive leading powers to dominate faster terms.
        """
        mixed = zero & (self.k[self.chain_index] > 0)
        if not np.any(mixed):
            return {"valid": True, "method": "monotone_all_pass", "groups": [], "flat_groups": False}
        _, _, q, _, _ = self._evaluate(core, zero)
        if np.any(q[self.k > 0] <= 0):
            return {"valid": False, "method": "positive_chain_hazard_missing", "groups": []}
        slope = self.n.copy()
        positive = self.k > 0
        slope[positive] -= self.k[positive] / q[positive]
        dimension, selections = self._reentry_groups(zero, constraint)
        logits = self.design @ core
        rates = -(self.design @ ray)
        groups = []
        for selected in selections:
            shift = float(np.max(logits[selected]))
            weights = np.exp(logits[selected] - shift)
            score = float(math.fsum((weights * slope[self.chain_index[selected]]).tolist()))
            exposure = self.n[self.chain_index[selected]]
            tolerance = max(1e-10, 128 * np.finfo(float).eps * float(exposure @ weights))
            groups.append({"rows": selected, "scaled_score": score, "tolerance": tolerance,
                           "log_weight_scale": shift, "rate": float(np.mean(rates[selected]))})
        valid = all(group["scaled_score"] >= -group["tolerance"] for group in groups)
        method = "shared_odds_reentry_group_scores"
        if not valid and dimension == 1 and groups:
            ordered = sorted(groups, key=lambda group: group["rate"])
            leading = ordered[0]
            rate_tolerance = 128 * np.finfo(float).eps * max(self.design.shape) * max(leading["rate"], 1.)
            separated = len(ordered) == 1 or ordered[1]["rate"] - leading["rate"] > rate_tolerance
            valid = separated and leading["scaled_score"] > leading["tolerance"]
            method = "one_dimensional_leading_odds_reentry_score"
        return {"valid": bool(valid), "method": method, "null_dimension": dimension, "groups": groups,
                "flat_groups": any(abs(group["scaled_score"]) <= group["tolerance"] for group in groups)}

    def _loss_change(self, new, old, zero, fixed=None):
        return self._loss_difference(new, zero, old, zero, fixed, fixed)

    def _loss_difference(self, new, new_zero, old, old_zero, new_fixed=None, old_fixed=None):
        def hazards(theta, zero, fixed):
            logits = self.design @ theta
            if fixed is not None:
                logits[self._matching_rows(fixed[0])] = fixed[1]
            return np.bincount(self.chain_index, weights=np.where(zero, 0., np.logaddexp(0., logits)), minlength=len(self.n))

        new_h = hazards(new, new_zero, new_fixed)
        old_h = hazards(old, old_zero, old_fixed)
        if np.any(new_h[self._positive_chains] <= 0):
            return math.inf
        change = new_h - old_h
        value = float(self._pass_counts @ change)
        use = self._positive_chains
        with np.errstate(over="ignore", divide="ignore", invalid="ignore"):
            log_ratio = np.log1p(np.exp(-old_h[use]) * -np.expm1(-change[use]) / -np.expm1(-old_h[use]))
        bad = ~np.isfinite(log_ratio)
        if np.any(bad):
            log_ratio[bad] = np.log(-np.expm1(-new_h[use][bad])) - np.log(-np.expm1(-old_h[use][bad]))
        return value - float(self.k[use] @ log_ratio)

    def _upper_recession(self, zero, transform):
        """Reject sufficient upper separation outside this zero-face closure."""
        all_fail = (self.n[self.chain_index] == self.k[self.chain_index]) & ~zero
        if not np.any(all_fail) or not transform.shape[1]:
            return False
        key = (self._geometry_key(zero), transform.shape, transform.tobytes())
        if key in self._upper_cache:
            return self._upper_cache[key]
        rows = self.design @ transform
        rows /= np.maximum(np.linalg.norm(rows, axis=1)[:, None], 1e-300)
        upper = rows[all_fail]
        fixed = rows[~all_fail & ~zero]
        self._progress("joint_face", operation="upper_recession_linear_program", zero_instance_count=int(np.sum(zero)))
        result = linprog(-upper.sum(axis=0), A_ub=-upper, b_ub=np.zeros(len(upper)),
                         A_eq=fixed if len(fixed) else None, b_eq=np.zeros(len(fixed)) if len(fixed) else None,
                         bounds=[(-1., 1.)] * transform.shape[1], method="highs")
        if not result.success:
            raise RuntimeError("Joint upper-recession linear program failed.")
        return self._cache_put(self._upper_cache, key, bool(result.fun < -1e-8))

    def _optimize(self, start, zero, offset, transform, constraint=None):
        iterations = evaluations = 0
        last_score = None
        zero_instance_count = int(np.sum(zero))

        def heartbeat(operation, **values):
            if self.progress_callback is None:
                return
            self._progress("joint_optimize", operation=operation, iteration=iterations, evaluations=evaluations,
                           zero_instance_count=zero_instance_count, score_residual=last_score, score_threshold=1e-8, **values)

        def unpack(values):
            theta = offset + transform @ values
            if constraint is not None:
                vector, logit = constraint
                pivot = int(np.argmax(np.abs(vector)))
                # Reimpose the scalar equality after matrix multiplication.
                # A 1e-14 drift in a fixed logit can change a profile objective
                # by 1e-3 for a Chain with 1e12 tests and a nonzero fixed score.
                theta[pivot] = (logit - math.fsum(float(vector[i] * theta[i]) for i in range(self.width) if i != pivot)) / vector[pivot]
            return theta

        columns = self.design @ transform
        # Retained fitted columns are orthonormal. Work in logits instead of
        # solving in raw coefficient units, which can differ by many orders.
        coords = columns[~zero].T @ (self.design @ (np.asarray(start) - offset))[~zero]
        bound = max(self.coefficient_bound, 45.) * math.sqrt(max(len(self.design), 1))
        bound = max(bound, float(np.max(np.abs(coords), initial=0.)) * 1.2 + 1.)
        trace = []
        upper_recession = self._upper_recession(zero, transform)
        if not len(coords):
            core = unpack(coords)
            loss, gradient, predicted, J, _ = self._evaluate(core, zero, fixed=constraint)
            return {"core": core, "minimum": loss, "predicted": predicted, "converged": math.isfinite(loss), "score": 0., "stages": []}

        # Optimizer objectives, stationarity checks and Newton polishing often
        # ask for the identical point. Retain two owned keys and upgrade only
        # the requested point to a Hessian; no approximate point reuse occurs.
        recent = []

        def evaluate(value, *, hessian=False):
            nonlocal evaluations
            entry = next((item for item in recent if np.array_equal(item["value"], value)), None)
            if entry is None:
                entry = {"value": np.asarray(value).copy(), "theta": unpack(value), "hessian": False, "score": None}
                recent.insert(0, entry)
                del recent[2:]
            if "result" not in entry or (hessian and not entry["hessian"]):
                evaluations += 1
                entry["result"] = self._evaluate(entry["theta"], zero, fixed=constraint, hessian=hessian)
                entry["hessian"] = hessian
                heartbeat("likelihood_evaluation")
            return entry

        def objective(value):
            evaluation = evaluate(value)["result"]
            return evaluation[0], transform.T @ evaluation[1]

        def scaled_score(value):
            nonlocal last_score
            entry = evaluate(value)
            if entry["score"] is None:
                _, gradient, _, J, _ = entry["result"]
                entry["score"] = self._scaled_score(gradient, J, transform)
            last_score = entry["score"]
            return last_score

        def optimizer_callback(_values):
            nonlocal iterations
            iterations += 1
            heartbeat("lbfgsb_iteration")

        if not math.isfinite(objective(coords)[0]):
            coords = np.zeros_like(coords)
        if not math.isfinite(objective(coords)[0]):
            core = unpack(coords)
            return {"core": core, "minimum": math.inf, "predicted": self._evaluate(core, zero)[2],
                    "converged": False, "score": math.inf, "stages": [{"reason": "nonfinite_profile_start"}]}
        touched = False
        for expansion in range(4):
            heartbeat("search_expansion", search_expansion=expansion + 1, search_radius=bound)
            fit = minimize(objective, coords, jac=True, method="L-BFGS-B", bounds=[(-bound, bound)] * len(coords),
                           options={"ftol": 1e-14, "gtol": 1e-10, "maxiter": 1500, "maxls": 50},
                           callback=optimizer_callback)
            if math.isfinite(fit.fun):
                coords = fit.x.copy()
            # Newton polishing compares differences of chain log likelihoods,
            # so an enormous constant NLL does not swallow small improvements.
            for polish_iteration in range(35):
                theta = unpack(coords)
                loss, gradient, _, _, hessian = evaluate(coords, hessian=True)["result"]
                heartbeat("newton_polish", polish_iteration=polish_iteration + 1)
                if hessian is None:
                    break
                g, H = transform.T @ gradient, transform.T @ hessian @ transform
                if not np.all(np.isfinite(H)):
                    break
                try:
                    eig, rotation = np.linalg.eigh(H)
                except np.linalg.LinAlgError:
                    break
                floor = max(float(np.max(np.abs(eig), initial=0.)) * 1e-10, 1e-12)
                direction = -rotation @ ((rotation.T @ g) / np.maximum(eig, floor))
                if not np.all(np.isfinite(direction)) or g @ direction >= 0:
                    break
                if np.max(np.abs(direction), initial=0.) < 1e-10:
                    break
                step = 1.
                for line_iteration in range(40):
                    candidate = np.clip(coords + step * direction, -bound, bound)
                    heartbeat("newton_line_search", polish_iteration=polish_iteration + 1, line_search_iteration=line_iteration + 1)
                    if self._loss_change(unpack(candidate), theta, zero, constraint) <= 1e-11:
                        coords = candidate
                        break
                    step *= .5
                else:
                    break
                if scaled_score(coords) < 1e-10:
                    break
            touched = bool(np.max(np.abs(coords), initial=0.) > bound * .99)
            trace.append({"search_radius": bound, "optimizer_success": bool(fit.success), "iterations": int(fit.nit),
                          "score_residual": scaled_score(coords), "search_radius_reached": touched})
            if not touched:
                break
            bound *= 4
        core = unpack(coords)
        loss, _, predicted, _, H = evaluate(coords, hessian=True)["result"]
        score = scaled_score(coords)
        heartbeat("optimizer_complete")
        # Very small probabilities alone are not a stationarity certificate.
        # Reject unresolved active saturation, including unsupported zero risks
        # within a Fail-containing Chain. Coefficients themselves are unbounded.
        active_logits = (self.design @ core)[~zero]
        exposure = self.n[self.chain_index[~zero]]
        tails = (((active_logits < -20.) & (exposure * expit(active_logits) < 1e-6))
                 | ((active_logits > 20.) & (exposure * expit(-active_logits) < 1e-6)))
        retained = columns[~zero]
        supported_basis, _ = _space(retained[~tails])
        # A tiny probability at an extreme x can be pinned by ordinary x rows.
        # It is unresolved extra directions, not numerical tail values, that
        # indicate a boundary outside the supported monotone face.
        saturated = any(not _contained(row, supported_basis) for row in retained[tails])
        curvature = transform.T @ H @ transform if H is not None else np.full((1, 1), math.nan)
        eigen = np.linalg.eigvalsh(curvature) if np.all(np.isfinite(curvature)) else np.array([-math.inf])
        negative_curvature = float(np.min(eigen, initial=0.)) < -1e-7 * max(float(np.max(np.abs(eigen), initial=0.)), 1.)
        return {"core": core, "minimum": loss, "predicted": predicted, "score": score,
                "converged": bool(math.isfinite(loss) and score < 1e-8 and not touched and not saturated and not negative_curvature and not upper_recession),
                "active_saturation": saturated, "upper_recession": upper_recession,
                "negative_curvature": negative_curvature, "stages": trace}

    def _optimize_starts(self, starts, zero, offset, transform, constraint):
        """Preserve original start order while sharing independent work."""
        count = worker_count(self.analysis_workers, len(starts))
        completed = 0
        pilot_elapsed = 0.
        while completed < len(starts):
            remaining = len(starts) - completed
            use_parallel = count > 1 and remaining > 1 and (
                self._parallel_runner is not None or self.analysis_workers > 0
                or (pilot_elapsed >= .25 and pilot_elapsed * remaining / completed >= 2.))
            if use_parallel:
                from .tsk_joint_parallel import JointStartPool

                starting_pool = self._parallel_runner is None
                if self._parallel_runner is None:
                    common = (self.design, self.chain_index, self.n, self.k, self.type_count, self.coefficient_bound)
                    self._parallel_runner = JointStartPool(common, min(count, remaining), self.parallel_execution)
                items = [(index, starts[index], zero, offset, transform, constraint)
                         for index in range(completed, len(starts))]

                def progress(done, total, active):
                    self._progress("joint_optimize", operation="parallel_multistart",
                        active_workers=active, workers_used=self.parallel_execution["workers_used"],
                        workers_observed=self.parallel_execution.get("session_workers_observed", 0),
                        completed_starts=completed + done, confirmed_starts=completed,
                        start_count=len(starts), execution_backend=self.parallel_execution["execution_backend"],
                        execution_phase=self.parallel_execution.get("phase"), score_threshold=1e-8)

                self._progress("joint_optimize", force=starting_pool, operation="parallel_multistart_start",
                               active_workers=0, workers_used=self._parallel_runner.workers,
                               completed_starts=completed, confirmed_starts=completed, start_count=len(starts))
                def local(item):
                    self._progress_context.update(start_index=item[0] + 1, start_count=len(starts))
                    return self._optimize(*item[1:])

                results = self._parallel_runner.map(items, local=local, progress=progress)
                for candidate in results:
                    self._progress_context.update(start_index=completed + 1, start_count=len(starts))
                    yield candidate
                    completed += 1
                return
            self._progress_context.update(start_index=completed + 1, start_count=len(starts))
            self._progress("joint_logistic_start", active_workers=1, completed_starts=completed)
            started = monotonic()
            candidate = self._optimize(starts[completed], zero, offset, transform, constraint)
            pilot_elapsed += monotonic() - started
            if self.analysis_workers == 0 and count > 1:
                self.parallel_execution["pilot_starts"] += 1
            yield candidate
            completed += 1

    @_parallel_scope
    def _solve(self, starts, constraint=None):
        self._search_serial += 1
        previous_context = self._progress_context
        self._progress_context = {**previous_context, "search_index": self._search_serial,
                                  "start_count": len(starts), "face_count_total_known": False}
        self._progress("joint_search_start", force=constraint is None, constrained=constraint is not None)
        try:
            result = self._solve_search(starts, constraint)
            self._progress("joint_search_complete", force=constraint is None, converged=bool(result[0]["converged"]),
                           face_count_total_known=True, face_count_pending=0, score_residual=result[0]["score"], score_threshold=1e-8)
            return result
        finally:
            self._progress_context = previous_context

    def _solve_search(self, starts, constraint=None):
        base_zero, base_ray = self._face(None if constraint is None else constraint[0])
        queue, seen, pending = deque(), set(), set()

        def enqueue(mask):
            key = np.packbits(mask).tobytes()
            if key not in seen and key not in pending:
                queue.append((mask, key))
                pending.add(key)

        enqueue(base_zero)
        # Whole design groups and coordinate-supported faces also reveal
        # remote equal-likelihood allocations that a small positive probe can
        # miss. Lower-tail unions below find joint compensation faces.
        for group in range(self._design_group_count):
            enqueue(base_zero | (self._design_group == group))
        for column in self.design.T:
            if np.all(column >= 0) or np.all(column <= 0):
                enqueue(base_zero | (column != 0))
        candidates = []
        base_offset, base_transform = self._face_coordinates(base_zero, constraint)
        while queue:
            zero, key = queue.popleft()
            pending.remove(key)
            seen.add(key)
            self._progress_context.update(face_index=len(seen), face_count_discovered=len(seen) + len(pending),
                                          face_count_pending=len(pending), zero_instance_count=int(np.sum(zero)),
                                          start_index=None, start_count=len(starts))
            self._progress("joint_face", operation="candidate_geometry")
            if np.array_equal(zero, base_zero):
                ray = base_ray
            else:
                ray = self._face_certificate(zero, None if constraint is None else constraint[0])
                if ray is None:
                    continue
            offset, transform = self._face_coordinates(zero, constraint)
            face_candidates = []
            for candidate in self._optimize_starts(starts, zero, offset, transform, constraint):
                candidate["zero_rows"] = np.flatnonzero(zero)
                candidate["recession_direction"] = ray
                candidate["finite_face_converged"] = candidate["converged"]
                self._progress("joint_reentry", operation="candidate_validation", score_residual=candidate["score"], score_threshold=1e-8)
                candidate["reentry"] = self._reentry_validation(candidate["core"], zero, ray, constraint)
                candidate["converged"] = candidate["converged"] and candidate["reentry"]["valid"]
                face_candidates.append(candidate)
                candidates.append(candidate)
                logits = self.design @ candidate["core"]
                for threshold in (-8., -16., -24.):
                    discovered = zero | (logits < threshold)
                    if np.any(discovered != zero):
                        enqueue(discovered)
                self._progress_context.update(face_count_discovered=len(seen) + len(pending), face_count_pending=len(pending))
            # A flat first-order boundary score is not a uniqueness proof or
            # a second-order check. Re-enter the original likelihood at a
            # positive odds value and free all original nuisance directions.
            valid = [item for item in face_candidates if item["converged"]]
            if valid and np.any(zero & (self.k[self.chain_index] > 0)):
                face_best = min(valid, key=lambda item: item["minimum"])
                if face_best["reentry"].get("flat_groups"):
                    self._progress("joint_reentry", operation="positive_reentry_probe")
                    movement = self.design @ ray
                    distance = max(float(np.max(((self.design @ face_best["core"])[zero] + 6.) / -movement[zero])), 0.)
                    probe_start = face_best["core"] + distance * ray
                    probe = self._optimize(probe_start, base_zero, base_offset, base_transform, constraint)
                    probe["zero_rows"] = np.flatnonzero(base_zero)
                    probe["recession_direction"] = base_ray
                    probe["finite_face_converged"] = probe["converged"]
                    probe["reentry"] = self._reentry_validation(probe["core"], base_zero, base_ray, constraint)
                    probe["converged"] = probe["converged"] and probe["reentry"]["valid"]
                    candidates.append(probe)
                    change = self._loss_difference(probe["core"], base_zero, face_best["core"], zero, constraint, constraint)
                    for item in valid:
                        item["reentry"]["positive_reentry_probe_change"] = change
                        if change < -1e-7:
                            item["converged"] = False
                            item["reentry"]["valid"] = False
                    logits = self.design @ probe["core"]
                    for threshold in (-8., -16., -24.):
                        enqueue(base_zero | (logits < threshold))
        finite = [item for item in candidates if math.isfinite(item["minimum"])]
        if not finite:
            raise RuntimeError("No finite joint Logistic likelihood candidate.")

        def mask(item):
            value = np.zeros(len(self.design), dtype=bool)
            value[item["zero_rows"]] = True
            return value

        best = finite[0]
        for candidate in finite[1:]:
            if self._loss_difference(candidate["core"], mask(candidate), best["core"], mask(best), constraint, constraint) < -1e-10:
                best = candidate
        accepted = [item for item in finite if item["converged"] and
                    self._loss_difference(item["core"], mask(item), best["core"], mask(best), constraint, constraint) <= 1e-8]
        if accepted:
            # Prefer exact validated boundary likelihoods over numerically
            # indistinguishable finite representatives of those same limits.
            best = max(accepted, key=lambda item: len(item["zero_rows"]))
        return best, candidates, mask(best), best["recession_direction"]

    def _starts(self, initial, *, profiles=False):
        rate = np.clip(self.k.sum() / self.n.sum(), 1e-7, 1 - 1e-7)
        multiplicity = max(float(len(self.design)) / len(self.n), 1.)
        component = -math.expm1(math.log1p(-rate) / multiplicity)
        baseline = np.r_[np.full(self.type_count, math.log(component) - math.log1p(-component)), np.zeros(self.width - self.type_count)]
        starts = [np.asarray(initial).copy(), baseline]
        # Opposite perturbations expose symmetric alternate allocations, which
        # a local Jacobian alone cannot exclude in this nonlinear likelihood.
        rng = np.random.default_rng(1079)
        for _ in range(1 if profiles else 2):
            movement = self._design_transform @ (rng.normal(size=self._design_transform.shape[1]) * math.sqrt(len(self.design)) * 2.)
            starts.extend([baseline + movement, baseline - movement])
        return starts

    @_parallel_scope
    def fit(self, logit_start):
        start = np.asarray(logit_start, dtype=float)
        if start.shape != (self.width,) or not np.all(np.isfinite(start)):
            raise ValueError("Joint boundary fitting needs finite initial logits.")
        self._started_at = monotonic()
        best, candidates, zero, ray = self._solve(self._starts(start))
        core = best["core"]
        representative = core.copy()
        if np.any(zero):
            movement = self.design @ ray
            target = max(60., math.log(max(float(self.n.sum()), 1.)) + 35.)
            distance = float(np.max(((self.design @ core)[zero] + target) / -movement[zero]))
            representative += max(distance, 0.) * ray
        if not np.all(np.isfinite(representative)):
            raise RuntimeError("Joint Logistic face has no stable finite serialization representative.")
        equivalent_faces = []
        for item in candidates:
            other_zero = np.zeros(len(self.design), dtype=bool)
            other_zero[item["zero_rows"]] = True
            if item["converged"] and self._loss_difference(item["core"], other_zero, core, zero) <= 1e-7:
                equivalent_faces.append({"core_coefficients": item["core"], "zero_rows": item["zero_rows"],
                                         "recession_direction": item["recession_direction"], "reentry": item["reentry"]})
        equivalent = [item["core_coefficients"] for item in equivalent_faces if np.array_equal(item["zero_rows"], np.flatnonzero(zero))]
        reasons = [] if best["converged"] else ["joint_finite_face_stationarity_not_established"]
        if best.get("active_saturation"):
            reasons.append("unsupported_active_instance_recession")
        if best.get("upper_recession"):
            reasons.append("unsupported_positive_instance_recession")
        if not best["reentry"]["valid"]:
            reasons.append("joint_boundary_reentry_not_established")
        self.state = _plain({"version": 1, "parameterization": "joint_logistic_face", "model_fingerprint": self._fingerprint,
                            "type_count": self.type_count, "coefficient_bound": self.coefficient_bound,
                            "coefficients": representative, "params": representative, "core_coefficients": core,
                            "recession_direction": ray, "zero_rows": np.flatnonzero(zero), "active_rows": np.flatnonzero(~zero),
                            "minimum": best["minimum"], "predicted": best["predicted"], "converged": best["converged"],
                            "equivalent_core_coefficients": equivalent,
                            "equivalent_faces": equivalent_faces, "face_search_version": 2,
                            "trace": {"starts": candidates, "finite_representative_maximum": float(np.max(np.abs(representative)))},
                            "validation": {"reason_codes": reasons, "score_residual": best["score"], "score_threshold": 1e-8,
                                           "monotone_face_certified": not bool(np.any(zero & (self.k[self.chain_index] > 0))),
                                           "zero_face_certified": True, "boundary_reentry": best["reentry"],
                                           "identifiability_scope": "attainable zero faces, shared-odds reentry scores, local Chain Jacobian, equivalent faces and full nuisance profile probes; not a global uniqueness proof"}})
        self._setup_geometry()
        self._progress("joint_fit_complete", force=True, converged=bool(self.state["converged"]),
                       zero_instance_count=len(self.state["zero_rows"]), score_residual=best["score"], score_threshold=1e-8)
        return self.state

    def _setup_geometry(self):
        self._profile_cache.clear()
        self._identified_cache.clear()
        self._kind_cache.clear()
        zero = np.zeros(len(self.design), dtype=bool)
        zero[np.asarray(self.state["zero_rows"], dtype=int)] = True
        self._zero = zero
        self._active_basis, _ = _space(self.design[~zero] @ self._design_transform)
        J = self._evaluate(np.asarray(self.state["core_coefficients"]), zero)[3]
        J = J @ self._design_transform
        norms = np.linalg.norm(J, axis=1)
        self._information_basis, _ = _space(J[norms > 0] / norms[norms > 0, None])
        self._equivalent_geometry = []
        faces = self.state.get("equivalent_faces")
        if faces is None:
            faces = [{"core_coefficients": core, "zero_rows": self.state["zero_rows"]}
                     for core in self.state.get("equivalent_core_coefficients", [self.state["core_coefficients"]])]
        for face in faces:
            other_zero = np.zeros(len(self.design), dtype=bool)
            other_zero[np.asarray(face["zero_rows"], dtype=int)] = True
            other_core = np.asarray(face["core_coefficients"])
            active_basis, _ = _space(self.design[~other_zero] @ self._design_transform)
            J = self._evaluate(other_core, other_zero)[3] @ self._design_transform
            norms = np.linalg.norm(J, axis=1)
            information_basis, _ = _space(J[norms > 0] / norms[norms > 0, None])
            self._equivalent_geometry.append((other_zero, other_core, active_basis, information_basis))

    def load_state(self, state):
        if (not isinstance(state, dict) or state.get("version") != 1 or state.get("parameterization") != "joint_logistic_face"
                or state.get("type_count") != self.type_count or state.get("model_fingerprint") != self._fingerprint):
            raise ValueError("Unsupported or stale joint Logistic boundary state.")
        arrays = {}
        for key in ("coefficients", "core_coefficients", "recession_direction"):
            arrays[key] = np.asarray(state.get(key), dtype=float)
            if arrays[key].shape != (self.width,) or not np.all(np.isfinite(arrays[key])):
                raise ValueError("Invalid stored joint Logistic coefficients.")
        stored_zero = np.asarray(state.get("zero_rows"), dtype=int)
        if (stored_zero.ndim != 1 or np.any(stored_zero < 0) or np.any(stored_zero >= len(self.design))
                or not np.array_equal(stored_zero, np.unique(stored_zero))):
            raise ValueError("Invalid stored joint Logistic face rows.")
        zero = np.zeros(len(self.design), dtype=bool)
        zero[stored_zero] = True
        ray = self._face_certificate(zero)
        monotone_zero, _ = self._face()
        if ray is None or np.any(monotone_zero & ~zero):
            raise ValueError("Stored joint Logistic face does not match its model.")
        if not np.array_equal(np.asarray(state.get("active_rows"), dtype=int), np.flatnonzero(~zero)):
            raise ValueError("Invalid joint Logistic active rows.")
        if np.any(zero):
            movement = self.design @ arrays["recession_direction"]
            if np.max(movement[zero]) >= -1e-9 or np.max(np.abs(movement[~zero]), initial=0.) > 1e-7:
                raise ValueError("Invalid stored joint Logistic recession certificate.")
        if np.max(np.abs(self.design[~zero] @ (arrays["coefficients"] - arrays["core_coefficients"])), initial=0.) > 1e-6:
            raise ValueError("Finite joint representative changes the retained likelihood.")
        minimum, _, predicted, _, _ = self._evaluate(arrays["core_coefficients"], zero)
        stored_minimum = state.get("minimum")
        if (not isinstance(stored_minimum, (float, int)) or not math.isfinite(float(stored_minimum))
                or abs(minimum - stored_minimum) > max(1e-7, abs(minimum) * 1e-12)
                or np.asarray(state.get("predicted")).shape != predicted.shape
                or not np.allclose(state["predicted"], predicted, rtol=1e-9, atol=1e-12)):
            raise ValueError("Stored joint Logistic likelihood is inconsistent.")
        equivalents = state.get("equivalent_core_coefficients", [])
        for equivalent in equivalents:
            equivalent = np.asarray(equivalent, dtype=float)
            if equivalent.shape != (self.width,) or not np.all(np.isfinite(equivalent)) or abs(self._loss_change(equivalent, arrays["core_coefficients"], zero)) > 1e-6:
                raise ValueError("Invalid stored joint Logistic alternate optimum.")
        for face in state.get("equivalent_faces", []):
            other_core = np.asarray(face.get("core_coefficients"), dtype=float)
            other_indices = np.asarray(face.get("zero_rows"), dtype=int)
            if (other_core.shape != (self.width,) or not np.all(np.isfinite(other_core))
                    or other_indices.ndim != 1 or np.any(other_indices < 0) or np.any(other_indices >= len(self.design))
                    or not np.array_equal(other_indices, np.unique(other_indices))):
                raise ValueError("Invalid stored joint Logistic alternate face.")
            other_zero = np.zeros(len(self.design), dtype=bool)
            other_zero[other_indices] = True
            other_ray = self._face_certificate(other_zero)
            if (other_ray is None or abs(self._loss_difference(other_core, other_zero, arrays["core_coefficients"], zero)) > 1e-6
                    or not self._reentry_validation(other_core, other_zero, other_ray)["valid"]):
                raise ValueError("Invalid stored joint Logistic alternate face likelihood or reentry.")
        self.state = _plain(dict(state))
        self._setup_geometry()
        # A snapshot's Boolean does not substitute for current stationarity.
        if self.state.get("converged"):
            _, retained_transform = _space(self.design[~zero] @ self._design_transform)
            checked = self._optimize(arrays["core_coefficients"], zero, np.zeros(self.width), self._design_transform @ retained_transform)
            if not checked["converged"] or self._loss_change(checked["core"], arrays["core_coefficients"], zero) < -1e-7:
                raise ValueError("Stored joint Logistic fit fails current stationarity checks.")
            if not self._reentry_validation(arrays["core_coefficients"], zero, ray)["valid"]:
                raise ValueError("Stored joint Logistic fit fails current boundary reentry checks.")
        return self

    def _kind(self, vector, zero=None, active_basis=None):
        if self.state is None or not self.state.get("converged") or not _contained(vector / self._column_scale, self._scaled_design_basis):
            return "unidentifiable"
        zero = self._zero if zero is None else zero
        active_basis = self._active_basis if active_basis is None else active_basis
        if _contained(vector @ self._design_transform, active_basis):
            return "interior"
        if not np.any(zero):
            return "unidentifiable"
        key = self._geometry_key(zero, vector)
        if key in self._kind_cache:
            return self._kind_cache[key]
        transform = self._design_transform
        contrast = vector @ transform
        contrast -= active_basis @ (active_basis.T @ contrast)
        contrast /= max(np.linalg.norm(contrast), 1e-300)
        retained = self.design[~zero] @ transform
        removed = self.design[zero] @ transform
        removed /= np.maximum(np.linalg.norm(removed, axis=1)[:, None], 1e-300)
        if len(retained):
            retained /= np.maximum(np.linalg.norm(retained, axis=1)[:, None], 1e-300)
        arguments = dict(A_ub=removed, b_ub=np.zeros(len(removed)), A_eq=retained if len(retained) else None,
                         b_eq=np.zeros(len(retained)) if len(retained) else None,
                         bounds=[(-1., 1.)] * transform.shape[1], method="highs")
        self._progress("joint_query", operation="contrast_linear_program", zero_instance_count=int(np.sum(zero)))
        low, high = linprog(contrast, **arguments), linprog(-contrast, **arguments)
        # Both signs are tested over the entire face cone. The direction used
        # for serialization never establishes a query's risk.
        if not low.success or not high.success:
            return "unidentifiable"
        kind = "zero_boundary" if low.fun < -1e-7 and -high.fun <= 1e-8 else "unidentifiable"
        return self._cache_put(self._kind_cache, key, kind)

    def estimate_kind(self, vector):
        kind = self._kind(self._query(vector))
        return "boundary_low" if kind == "zero_boundary" else kind

    def _profile_logit(self, vector, logit):
        if self.state is None or not self.state.get("converged"):
            raise RuntimeError("Joint profile requires a currently validated fit.")
        key = (tuple(vector), float(logit))
        if key in self._profile_cache:
            return self._profile_cache[key]
        self._profile_serial += 1
        previous_context = self._progress_context
        self._progress_context = {**previous_context, "profile_index": self._profile_serial, "profile_logit": float(logit)}
        self._progress("joint_profile", operation="profile_start")
        try:
            result = self._compute_profile_logit(vector, logit)
            self._progress("joint_profile", operation="profile_complete", likelihood_increase=result[0])
            return result
        finally:
            self._progress_context = previous_context

    def _compute_profile_logit(self, vector, logit):
        key = (tuple(vector), float(logit))
        starts = self._starts(np.asarray(self.state["coefficients"]), profiles=True)
        nearby = [(abs(value - logit), result[1]) for (query, value), result in self._profile_cache.items() if query == tuple(vector)]
        if nearby:
            starts.insert(0, min(nearby, key=lambda item: item[0])[1])
        best, _, zero, _ = self._solve(starts, (vector, logit))
        difference = self._loss_difference(best["core"], zero, np.asarray(self.state["core_coefficients"]), self._zero, (vector, logit))
        if difference < -1e-7:
            self.state["converged"] = False
            self.state["validation"]["reason_codes"].append("joint_profile_found_better_optimum")
            self._identified_cache.clear()
            self._profile_cache.clear()
            self._kind_cache.clear()
            raise JointBoundaryBetterOptimumError("Joint profile found a better likelihood than the stored fit.")
        if not best["converged"]:
            raise RuntimeError("Joint profile nuisance stationarity was not established.")
        result = (max(difference, 0.), best["core"], zero)
        self._profile_cache[key] = result
        return result

    @_parallel_scope
    def identifiable(self, params, vector):
        vector = self._query(vector)
        if self.state is None or not self.state.get("converged") or not np.array_equal(np.asarray(params), np.asarray(self.state["coefficients"])):
            return False
        key = tuple(vector)
        if key in self._identified_cache:
            return self._identified_cache[key]
        self._query_serial += 1
        previous_context = self._progress_context
        self._progress_context = {**previous_context, "query_index": self._query_serial}
        self._progress("joint_query", force=True, operation="identifiability_start")
        result = None
        try:
            result = self._identify_uncached(params, vector)
            return result
        finally:
            self._progress("joint_query", force=True, operation="identifiability_complete" if result is not None else "identifiability_failed", identifiable=result)
            self._progress_context = previous_context

    def _identify_uncached(self, params, vector):
        vector = self._query(vector)
        if self.state is None or not np.array_equal(np.asarray(params), np.asarray(self.state["coefficients"])):
            return False
        key = tuple(vector)
        if key in self._identified_cache:
            return self._identified_cache[key]
        kind = self._kind(vector)
        identified = kind != "unidentifiable"
        core = np.asarray(self.state["core_coefficients"])
        if kind == "interior":
            identified = _contained(vector @ self._design_transform, self._information_basis)
        if identified:
            for other_zero, other_core, active_basis, information_basis in self._equivalent_geometry:
                other_kind = self._kind(vector, other_zero, active_basis)
                if (other_kind != kind or (kind == "interior" and
                    (not _contained(vector @ self._design_transform, information_basis)
                     or abs(float(vector @ (other_core - core))) > 1e-4))):
                    identified = False
                    break
        if identified:
            try:
                if kind == "zero_boundary":
                    # Directly observed all-Pass combinations have a strictly
                    # positive likelihood penalty at every positive query risk.
                    matching = np.all(np.isclose(self.design, vector, rtol=0., atol=1e-12), axis=1)
                    if not np.any(matching) or np.any(self.k[self.chain_index[matching]] > 0):
                        exposure = max(float(self.n.sum()), 1.)
                        p = max(1e-5, min(.01, 2. / exposure))
                        identified = self._profile_logit(vector, math.log(p) - math.log1p(-p))[0] > 1e-8
                else:
                    logit = float(vector @ core)
                    identified = all(self._profile_logit(vector, logit + step)[0] > 1e-8 for step in (-.25, .25))
            except JointBoundaryBetterOptimumError:
                raise
            except (ValueError, RuntimeError, FloatingPointError, np.linalg.LinAlgError):
                identified = False
        self._identified_cache[key] = bool(identified)
        return bool(identified)

    def probability(self, params, vector):
        vector = self._query(vector)
        if not self.identifiable(params, vector):
            return math.nan
        return 0. if self._kind(vector) == "zero_boundary" else float(expit(vector @ np.asarray(self.state["core_coefficients"])))

    def coefficient_identifiable(self, index):
        if not 0 <= int(index) < self.width or self.state is None or not self.state.get("converged"):
            return False
        vector = np.eye(self.width)[int(index)]
        if (not _contained(vector / self._column_scale, self._scaled_design_basis)
                or not _contained(vector @ self._design_transform, self._active_basis)
                or not _contained(vector @ self._design_transform, self._information_basis)):
            return False
        core = np.asarray(self.state["core_coefficients"])
        return all(_contained(vector @ self._design_transform, active_basis)
                   and _contained(vector @ self._design_transform, information_basis)
                   and abs(float(vector @ (other - core))) <= 1e-4
                   for _, other, active_basis, information_basis in self._equivalent_geometry)

    def _exact_zero_upper(self, vector, confidence):
        matching = np.all(np.isclose(self.design, vector, rtol=0., atol=1e-12), axis=1)
        copies = np.bincount(self.chain_index, weights=matching.astype(float), minlength=len(self.n))
        selected = copies > 0
        if not np.any(selected) or np.any(self.k[selected] > 0):
            return None
        exposure = float(self.n @ copies)
        counts = np.bincount(self.chain_index, minlength=len(self.n))
        pure = bool(np.all(copies[selected] == counts[selected]))
        return 0., -math.expm1(math.log1p(-confidence) / exposure), EXACT_METHOD if pure else CONSERVATIVE_EXACT_METHOD

    @_parallel_scope
    def profile_interval(self, params, vector, confidence):
        if not 0 < confidence < 1:
            raise ValueError("Confidence level must lie between zero and one.")
        vector = self._query(vector)
        previous_context = self._progress_context
        self._progress_context = {**previous_context, "confidence": float(confidence)}
        self._progress("joint_profile", force=True, operation="interval_start")
        result = None
        try:
            result = self._compute_profile_interval(params, vector, confidence)
            return result
        finally:
            self._progress("joint_profile", force=True, operation="interval_complete" if result is not None else "interval_unavailable")
            self._progress_context = previous_context

    def _compute_profile_interval(self, params, vector, confidence):
        if not self.identifiable(params, vector):
            raise RuntimeError("Requested joint Logistic risk is not independently estimable.")
        estimate = self.probability(params, vector)
        if estimate == 0.:
            exact = self._exact_zero_upper(vector, confidence)
            if exact is not None:
                return exact
        cutoff = float(chi2.ppf(confidence, 1)) / 2
        centre = float(vector @ np.asarray(self.state["core_coefficients"])) if estimate else -35.

        def objective(logit):
            return self._profile_logit(vector, float(logit))[0] - cutoff

        if estimate:
            # The fitted face itself is an admissible constrained nuisance fit.
            self._profile_cache[(tuple(vector), centre)] = (0., np.asarray(self.state["core_coefficients"]), self._zero.copy())
        else:
            # A derived zero contrast may approach zero much faster than an
            # observed instance. Find an interior LR bracket rather than using
            # the historical coefficient bound as an implicit risk floor.
            for step in (0., 16., 32., 64., 128., 256.):
                centre -= step
                if objective(centre) < 0:
                    break
            else:
                raise RuntimeError("Joint zero profile has no stable lower likelihood bracket.")
        upper = centre
        for step in (1., 2., 4., 8., 16., 32., 64.):
            upper = centre + step
            if objective(upper) > 0:
                upper = float(expit(brentq(objective, centre, upper, xtol=1e-8)))
                break
        else:
            raise RuntimeError("Joint profile has no certified upper likelihood crossing.")
        lower = 0.
        if estimate:
            for step in (1., 2., 4., 8., 16., 32., 64.):
                endpoint = centre - step
                if objective(endpoint) > 0:
                    lower = float(expit(brentq(objective, endpoint, centre, xtol=1e-8)))
                    break
            else:
                raise RuntimeError("Joint profile has no certified lower likelihood crossing.")
        return lower, upper, BOUNDARY_METHOD if estimate == 0 else INTERIOR_METHOD
