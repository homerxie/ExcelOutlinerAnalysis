"""Experimental plug-in parametric LR simulation with freely changing zero faces.

This is not a proven boundary calibration. Every generated data set is retained
in its original Chain layout and every fit must pass finite-effect, likelihood,
KKT and nesting checks. Failed simulations are reported, never discarded or
replaced by another draw to manufacture a p-value.
"""

from concurrent.futures import ProcessPoolExecutor, TimeoutError as FutureTimeoutError
from hashlib import sha256
import logging
import math
import multiprocessing
from numbers import Integral
import os
import threading
from time import monotonic
from typing import Any, Mapping

import numpy as np
from scipy.stats import beta

from .tsk_analysis import _plain
from .compute_resources import limit_process_workers
from .tsk_logistic_boundary import KKT_TOLERANCE, LogisticBoundaryFit
from .tsk_parallel import _SPAWN_ENV_LOCK, _THREAD_ENV, in_parallel_worker, require_parallel_runtime


METHOD = "experimental_plugin_null_parametric_binomial_likelihood_ratio_plus_one"
EXPERIMENTAL_WARNING = (
    "自由边界模拟检验仍处于实验阶段，尚未完成覆盖率和误报率校准验证。完整模型、删特征模型与每次模拟均允许 "
    "TSK 风险为 0 或正值，不固定原来的零风险集合。p 值来自删特征拟合模型的插入式参数模拟，"
    "不保证在所有边界和样本规模下控制误报率；Monte Carlo 区间仅描述有限模拟次数的数值误差，"
    "不代表模型或真实风险的不确定性。"
)


def validate_simulation_settings(replicates, seed, workers=0):
    if isinstance(replicates, bool) or not isinstance(replicates, Integral) or replicates < 1:
        raise ValueError("simulation_replicates must be a positive integer.")
    if isinstance(seed, bool) or not isinstance(seed, Integral) or not 0 <= seed <= 2 ** 32 - 1:
        raise ValueError("simulation_seed must be an integer between 0 and 4294967295.")
    if isinstance(workers, bool) or not isinstance(workers, Integral) or not 0 <= workers <= 64:
        raise ValueError("simulation_workers must be an integer between 0 and 64 (0 means automatic).")
    return int(replicates), int(seed)


_WORKER_COMMON = None
_WORKER_THREAD_LIMIT = None
_WORKER_STARTUP_GATE = None


def _worker_initialize(common, startup_gate, log_queue=None):
    """Workers receive immutable layout once, and never inherit GUI callbacks."""
    from .process_logging import install_process_logging
    install_process_logging(log_queue)
    from threadpoolctl import threadpool_limits

    global _WORKER_COMMON, _WORKER_THREAD_LIMIT, _WORKER_STARTUP_GATE
    _WORKER_COMMON = common
    _WORKER_STARTUP_GATE = startup_gate
    _WORKER_THREAD_LIMIT = threadpool_limits(limits=1)
    parent = multiprocessing.parent_process()
    if parent is not None:
        def parent_died():
            from multiprocessing.connection import wait
            wait([parent.sentinel])
            # The GUI can forcibly terminate its analysis subprocess. Its
            # finally blocks then cannot close this nested pool.
            os._exit(0)
        threading.Thread(target=parent_died, name="simulation-parent-watch", daemon=True).start()


def _replicate_result(common, payload, heartbeat):
    design, chain_index, n, type_count, bound = common
    replicate, generated, keep, start = payload
    try:
        full, reduced, statistic = _fit_pair(design, chain_index, n, generated, type_count, keep,
                                             start, bound, heartbeat, stage=f"replicate_{replicate}")
    except SimulationFitError as error:
        # Return a plain payload: custom exception constructors need not be
        # pickle-compatible, and statistical failures must not break the pool.
        return {"failure": {"replicate": replicate, "stage": error.stage,
                            "reason": str(error), "n_failed": generated.tolist()}}
    return {"statistic": statistic, "zero_masks": {"full": list(full.state["zero_type_indices"]),
                                                     "reduced": list(reduced.state["zero_type_indices"])},
            "diagnostics": {"full": full.state["simulation_validation"],
                            "reduced": reduced.state["simulation_validation"]}}


def _worker_replicate(payload):
    return _replicate_result(_WORKER_COMMON, payload, lambda: None)


def _worker_count(requested, count):
    if in_parallel_worker():
        return 1
    # Small jobs cost more to spawn than to fit. Explicit selections are still
    # honored, so they can be benchmarked and tested with just a few draws.
    if requested == 0:
        workers = 1 if count < 16 else min(8, max((os.cpu_count() or 1) - 1, 1), count)
    else:
        workers = min(requested, count, 61 if os.name == "nt" else 64)
    return limit_process_workers(workers)


def _poll_result(future):
    """Separate a pending wait from a completed task that raised TimeoutError.

    Python 3.11 aliases concurrent.futures.TimeoutError to builtin TimeoutError.
    Re-read a completed future as well: it may have completed between the timed
    wait and done(), in which case its actual result must be preserved.
    """
    try:
        return True, future.result(timeout=.1), None
    except FutureTimeoutError:
        if not future.done():
            return False, None, None
        try:
            return True, future.result(), None
        except Exception as error:
            return True, None, error
    except Exception as error:
        return True, None, error


class _SimulationExecutor:
    """Bounded, ordered replication with one spawn pool across all features.

    The parent alone draws counts in the original RNG order. Results are
    consumed by replicate number, so racing failures never select a different
    accepted prefix. Work already started beyond a statistical stop is retained
    separately for auditing and is never used to replace that failed replicate.
    """

    def __init__(self, common, workers, settings):
        self.common, self.workers, self.settings = common, workers, settings
        self.pool = None
        self.pending = {}
        self.confirmed = self.submitted = 0
        self.completed = set()
        self.phase = "serial" if workers == 1 else "not_started"
        self.settings.update(workers_used=workers, execution_backend="serial" if workers == 1 else "spawn_process_pool",
                             worker_blas_threads=1 if workers > 1 else None,
                             execution_warnings=[], replicate_order="original_rng_draw_order")

    def __enter__(self):
        return self

    def _shutdown(self, *, terminate=False):
        if self.pool is None:
            return
        pool, self.pool = self.pool, None
        if terminate:
            # Python 3.10 has no public terminate_workers(). Keep the fallback
            # localized; ordinary completion uses the public shutdown API.
            processes = list((getattr(pool, "_processes", None) or {}).values())
            for process in processes:
                if process.is_alive():
                    process.terminate()
            pool.shutdown(wait=False, cancel_futures=True)
            for process in processes:
                process.join(timeout=.2)
                if process.is_alive():
                    process.kill()
                    process.join(timeout=.2)
        else:
            pool.shutdown(wait=True, cancel_futures=True)

    def __exit__(self, kind, value, traceback):
        self._shutdown(terminate=kind is not None)
        self.pending.clear()

    def _fallback(self, error):
        self._shutdown(terminate=True)
        self.workers = 1
        self.phase = "serial_after_process_failure"
        self.settings["execution_backend"] = "serial_after_process_failure"
        self.settings["workers_used"] = 1
        self.settings["worker_blas_threads"] = None
        self.settings["execution_warnings"].append(
            f"模拟子进程不可用，使用已生成的同一份计数串行继续（不补抽）：{type(error).__name__}: {error}")
        logging.getLogger(__name__).warning(self.settings["execution_warnings"][-1])

    def _submit(self, payload):
        if self.pool is None:
            # A missing dependency must be actionable, rather than silently
            # turning an expensive requested parallel run into a serial run.
            require_parallel_runtime()
        from .process_logging import get_process_log_queue
        try:
            if self.pool is None:
                # Spawn inherits environment before importing NumPy. This also
                # limits Apple's Accelerate, which threadpoolctl cannot manage.
                # Restore the parent's exact environment immediately after all
                # workers have started; runtime BLAS limits apply only in children.
                with _SPAWN_ENV_LOCK:
                    previous = {key: os.environ.get(key) for key in _THREAD_ENV}
                    try:
                        os.environ.update({key: "1" for key in _THREAD_ENV})
                        spawn = multiprocessing.get_context("spawn")
                        startup_gate = spawn.Event()
                        self.pool = ProcessPoolExecutor(max_workers=self.workers,
                            mp_context=spawn, initializer=_worker_initialize,
                            initargs=(self.common, startup_gate, get_process_log_queue()))
                        # Executor starts workers lazily. Submit enough tiny
                        # setup jobs here so later launches cannot inherit the
                        # restored parent thread counts.
                        for _ in range(self.workers):
                            self.pool.submit(_worker_ready)
                        startup_gate.set()
                        self.phase = "starting_workers"
                    finally:
                        for key, value in previous.items():
                            if value is None:
                                os.environ.pop(key, None)
                            else:
                                os.environ[key] = value
            return self.pool.submit(_worker_replicate, payload)
        except Exception as error:
            self._fallback(error)
            return None

    def _result(self, future, payload, heartbeat):
        if future is not None and self.workers > 1:
            while True:
                done, value, error = _poll_result(future)
                if not done:
                    heartbeat()
                    continue
                if error is not None:
                    # Infrastructure failure is not a statistical failure. The
                    # identical generated counts are retried locally once.
                    self._fallback(error)
                    break
                return value
        return _replicate_result(self.common, payload, heartbeat)

    def progress_description(self):
        backend = self.settings["execution_backend"]
        if self.phase == "not_started":
            state = "准备启动模拟进程"
        elif self.phase == "starting_workers":
            state = "正在启动进程并等待首批结果"
        elif self.phase == "serial_after_process_failure":
            state = "子进程不可用，使用原计数串行继续（不补抽）"
        elif self.workers == 1:
            state = "串行计算"
        else:
            state = "并行计算／等待下一顺序结果"
        return (f"{state} · {self.workers} 进程 · {backend} · "
                f"已完成 {len(self.completed)}，按顺序确认 {self.confirmed}，已派发 {self.submitted}")

    def replicates(self, rng, q_null, keep, start, count, heartbeat):
        self.pending.clear()
        self.completed.clear()
        self.confirmed = self.submitted = 0
        next_submit = 1
        n_integer = self.common[2].astype(np.int64)
        # Refill idle workers when later replicates finish first, but do not
        # generate an unbounded tail behind one slow fit. Counts dominate each
        # buffered payload; always allow at least the original two jobs/worker.
        lookahead = max(2 * self.workers, min(8 * self.workers,
                        (64 * 1024 * 1024) // max(n_integer.nbytes, 1)))
        checked = set()
        failure_waiting = False
        heartbeat(0)

        def collect_and_fill(replicate):
            nonlocal next_submit, failure_waiting
            for number, (future, _payload) in self.pending.items():
                if number in checked or future is None or not future.done():
                    continue
                checked.add(number)
                done, value, error = _poll_result(future)
                if done and error is None:
                    self.completed.add(number)
                    if self.workers > 1:
                        self.phase = "running"
                # Stop speculative draws as soon as a completed failure is
                # known. It is still consumed only at its original position.
                failure_waiting |= error is not None or (done and "failure" in value)
            window = 1 if self.workers == 1 else 2 * self.workers
            active = sum(future is None or not future.done() for future, _ in self.pending.values())
            while (next_submit <= count and len(self.pending) < lookahead
                   and active < window
                   and (not failure_waiting or replicate not in self.pending)):
                # Deliberately keep one binomial call per replicate. Vectorized
                # draws can change the stream and would invalidate replay.
                generated = rng.binomial(n_integer, q_null).astype(float)
                payload = (next_submit, generated, keep, start)
                future = self._submit(payload) if self.workers > 1 else None
                self.pending[next_submit] = (future, payload)
                self.submitted = next_submit
                next_submit += 1
                active += 1
                if self.workers == 1:
                    break

        for replicate in range(1, count + 1):
            collect_and_fill(replicate)
            # Keep the current payload in pending while waiting, so the refill
            # and its memory bound include it. Remove only when consumed.
            future, payload = self.pending[replicate]
            def tick():
                collect_and_fill(replicate)
                heartbeat(self.confirmed)
            heartbeat(self.confirmed)
            outcome = self._result(future, payload, tick)
            self.completed.add(replicate)
            if "failure" not in outcome:
                self.confirmed = replicate
            if self.workers > 1:
                self.phase = "running"
            self.pending.pop(replicate)
            # Confirm only the successful prefix. Do not refill here: a
            # statistical failure must reach the caller before more dispatch.
            heartbeat(self.confirmed)
            yield replicate, outcome

    def finish_feature(self, detail, heartbeat):
        # A statistical stop can leave a bounded amount of already-dispatched
        # work. Preserve every completed diagnostic; cancel unstarted tasks.
        after_stop = []
        for replicate, (future, payload) in sorted(self.pending.items()):
            item = {"replicate": replicate, "n_failed": payload[1].tolist()}
            if future is None or future.cancel():
                item["status"] = "cancelled_before_fit"
            else:
                while True:
                    done, value, error = _poll_result(future)
                    if not done:
                        heartbeat()
                        continue
                    if error is not None:
                        item.update(status="process_failed_after_earlier_stop", reason=f"{type(error).__name__}: {error}")
                    else:
                        item.update(status="completed_after_earlier_stop", outcome=value)
                        self.completed.add(replicate)
                    break
            after_stop.append(item)
            heartbeat()
        if after_stop:
            detail["prefetched_after_stop"] = after_stop
            detail["replicates_used_before_stop"] = detail["replicates_completed"]
            for item in after_stop:
                if item["status"] == "process_failed_after_earlier_stop":
                    # A dead process cannot attest whether this payload had
                    # started. Do not mislabel it as definitely unattempted.
                    detail["replicates_execution_unknown"] = detail.get("replicates_execution_unknown", 0) + 1
                    detail["replicates_unattempted"] -= 1
                if item["status"] != "completed_after_earlier_stop":
                    continue
                detail["replicates_attempted"] += 1
                detail["replicates_unattempted"] -= 1
                if "failure" in item["outcome"]:
                    detail["replicates_failed"] += 1
                    detail["failures"].append(item["outcome"]["failure"])
                else:
                    detail["replicates_completed"] += 1
        self.pending.clear()


def _worker_ready():
    _WORKER_STARTUP_GATE.wait()
    return True


class SimulationFitError(RuntimeError):
    def __init__(self, stage, reason):
        super().__init__(reason)
        self.stage = stage


def _project_analytic_zero(engine, stage):
    """Set only types supported exclusively by all-Pass chains to exact zero.

    For those types, decreasing their nonnegative odds lowers every affected
    all-Pass chain hazard and leaves every Fail-containing chain unchanged.
    Thus zero is an analytically justified optimum coordinate, independently
    of the numerical size of its current odds. No probability cutoff is used.
    """
    from .tsk_feature_effects import _likelihood_tolerance

    state = engine.state
    original = np.asarray(state["params"], dtype=float)
    present = np.any(engine.counts > 0, axis=0)
    touches_fail = np.any(engine.counts[engine.k > 0] > 0, axis=0)
    eligible = np.flatnonzero(present & ~touches_fail)
    projected = eligible[original[eligible] > 0]
    diagnostic = {"criterion": "observed_type_all_containing_chains_have_zero_failures",
                  "eligible_type_indices": eligible.tolist(), "projected_type_indices": projected.tolist(),
                  "original_scaled_odds": original[projected].tolist(), "probability_threshold_used": False}
    if len(projected):
        before = engine.evaluate(original)[0]
        saved = state.get("minimum")
        if (saved is None or not math.isfinite(before)
                or abs(before - float(saved)) > _likelihood_tolerance(float(saved))):
            raise SimulationFitError(stage, "解析零投影前的参数与保存似然不一致。")
        candidate = original.copy()
        candidate[projected] = 0.
        after = engine.evaluate(candidate)[0]
        if not math.isfinite(after) or after > before + _likelihood_tolerance(before):
            raise SimulationFitError(stage, "可证明零风险坐标的投影没有通过似然非增复核。")
        state.update(params=candidate.tolist(), minimum=after,
                     zero_type_indices=np.flatnonzero(candidate[:engine.type_count] == 0).tolist())
        diagnostic.update(negative_log_likelihood_before=before, negative_log_likelihood_after=after)
    return diagnostic


def _fit_candidate(design, chain_index, n, k, type_count, start, bound, heartbeat, stage):
    from .tsk_feature_effects import _boundary_separation, _likelihood_tolerance

    heartbeat()
    engine = LogisticBoundaryFit(design, chain_index, n, k, type_count,
                                 coefficient_bound=bound, progress_callback=lambda *_: heartbeat())
    heartbeat()
    if not np.any(k):
        # Both nested maxima are exactly L=1. Shared beta is unidentified, but
        # that does not invalidate the known likelihood maximum or D*=0.
        params = np.zeros(engine.width)
        engine.state = {"version": 1, "parameterization": "scaled_type_odds", "type_count": type_count,
                        "params": params.tolist(), "odds_scale": engine.odds_scale.tolist(),
                        "coefficient_bound": bound, "converged": True, "feature_clipped": False,
                        "zero_type_indices": list(range(type_count)), "minimum": 0.,
                        "validation": {"analytic_all_pass_maximum": True}}
    else:
        try:
            engine.fit(start)
        except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
            raise SimulationFitError(stage, f"自由边界拟合出现数值异常：{error}") from error
    state = engine.state
    heartbeat()
    analytic_zero = _project_analytic_zero(engine, stage)
    if not state.get("converged") or state.get("feature_clipped"):
        raise SimulationFitError(stage, "自由边界拟合未建立可靠收敛或存在发散的共享特征。")
    params = np.asarray(state["params"], dtype=float)
    value, gradient, _, derivative = engine.evaluate(params)
    minimum = state.get("minimum")
    if (minimum is None or not math.isfinite(value)
            or abs(value - float(minimum)) > _likelihood_tolerance(float(minimum))):
        raise SimulationFitError(stage, "保存参数与似然损失不一致。")
    bounds = [(0., None)] * type_count + [(-bound, bound)] * (engine.width - type_count)
    kkt = engine._kkt(params, gradient, derivative, bounds)
    if kkt >= KKT_TOLERANCE:
        raise SimulationFitError(stage, "自由边界参数没有通过单侧 KKT 驻点复核。")
    if np.any(np.abs(params[type_count:]) >= bound - .1):
        raise SimulationFitError(stage, "共享特征触及数值界限，不能将截断系数当作有限估计。")
    heartbeat()
    separation = _boundary_separation(engine, params)
    heartbeat()
    if separation["status"] != "no_certificate":
        raise SimulationFitError(stage, "有限共享效应的分离检查未通过。")
    state["simulation_validation"] = {"negative_log_likelihood": value, "kkt_residual": kkt,
                                      "kkt_threshold": KKT_TOLERANCE, "finite_effect_check": separation["status"],
                                      "shared_coefficients_clipped": False, "analytic_zero_check": analytic_zero}
    return engine


def _fit(design, chain_index, n, k, type_count, start, bound, heartbeat, stage):
    try:
        return _fit_candidate(design, chain_index, n, k, type_count, start, bound, heartbeat, stage)
    except SimulationFitError:
        raise
    except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
        raise SimulationFitError(stage, f"自由边界拟合或验证出现数值异常：{error}") from error


def _statistic(full, reduced, stage):
    from .tsk_feature_effects import _likelihood_tolerance

    first, second = float(full.state["minimum"]), float(reduced.state["minimum"])
    delta = second - first
    tolerance = _likelihood_tolerance(first)
    if delta < -tolerance:
        raise SimulationFitError(stage, "删特征模型损失低于完整模型，嵌套最优解复核失败。")
    return 0. if abs(delta) <= tolerance else 2 * delta


def _fit_pair(design, chain_index, n, k, type_count, keep, start, bound, heartbeat,
              *, full=None, stage="simulation"):
    from .tsk_feature_effects import _boundary_logit_start

    if full is None:
        full = _fit(design, chain_index, n, k, type_count, start, bound, heartbeat, stage + "_full")
    full_start = _boundary_logit_start(full, np.asarray(full.state["params"]))
    reduced = _fit(design[:, keep], chain_index, n, k, type_count, full_start[keep], bound, heartbeat, stage + "_null")
    lifted = np.zeros(design.shape[1])
    lifted[keep] = _boundary_logit_start(reduced, np.asarray(reduced.state["params"]))
    audited = _fit(design, chain_index, n, k, type_count, lifted, bound, heartbeat, stage + "_nested_full_audit")
    if audited.state["minimum"] < full.state["minimum"]:
        full = audited
    return full, reduced, _statistic(full, reduced, stage + "_nesting")


def _context_for_engine(context, engine):
    from .tsk_feature_effects import _boundary_logit_start

    return dict(context, boundary_fit=engine.state, converged=True, clipped=False,
                coefficients=_boundary_logit_start(engine, np.asarray(engine.state["params"])),
                negative_log_likelihood=float(engine.state["minimum"]))


def _holm_values(values):
    order = sorted(range(len(values)), key=lambda index: (values[index], index))
    adjusted, previous = [1.] * len(values), 0.
    for position, index in enumerate(order):
        previous = min(1., max(previous, (len(values) - position) * values[index]))
        adjusted[index] = previous
    return adjusted


def _experimental_holm(rows, alpha):
    p = [row["p_value"] if row.get("p_value") is not None else 1. for row in rows]
    low = [row.get("simulation", {}).get("p_value_mc_lower") if row.get("p_value") is not None else 1. for row in rows]
    high = [row.get("simulation", {}).get("p_value_mc_upper") if row.get("p_value") is not None else 1. for row in rows]
    adjusted, lower, upper = _holm_values(p), _holm_values(low), _holm_values(high)
    for index, row in enumerate(rows):
        row["significant"] = None
        row["p_adjusted_mc_lower"] = row["p_adjusted_mc_upper"] = row["experimental_significant"] = None
        if row.get("p_value") is not None:
            row.update(p_adjusted=adjusted[index], p_adjusted_mc_lower=lower[index],
                       p_adjusted_mc_upper=upper[index], experimental_significant=bool(adjusted[index] <= alpha))


def _mc_interval(exceedances, count, family_size):
    # Bonferroni intervals for the Monte Carlo tail probabilities make their
    # monotone Holm transforms simultaneous bounds across requested features.
    tail = .05 / max(family_size, 1) / 2
    low = 0. if exceedances == 0 else float(beta.ppf(tail, exceedances, count - exceedances + 1))
    high = 1. if exceedances == count else float(beta.ppf(1 - tail, exceedances + 1, count - exceedances))
    return low, high


def build_boundary_simulation(context: Mapping[str, Any], *, confidence_level=.95,
                              simulation_replicates=999, simulation_seed=1729, simulation_workers=0,
                              progress_callback=None):
    from .tsk_feature_effects import (_boundary_logit_start, _deletion_impact, _empty_lrt, _likelihood_tolerance,
                                     _status, _type_effects, _unavailable_feature, build_tsk_feature_effects)
    from .tsk_prediction import _FrozenFit

    count, seed = validate_simulation_settings(simulation_replicates, simulation_seed, simulation_workers)
    progress = progress_callback or (lambda *_: None)
    report = None
    warning = EXPERIMENTAL_WARNING
    settings = {"replicates": count, "seed": seed, "method": METHOD, "monte_carlo_confidence_level": .95,
                "monte_carlo_interval_method": "clopper_pearson_bonferroni_plugin_null_tail_probability",
                "failure_policy": "stop_feature_withhold_p_no_discard_no_replacement"}
    settings["workers_requested"] = int(simulation_workers)
    workers = _worker_count(simulation_workers, count)
    preparation = f"原样本串行预处理（1 进程）；模拟计划使用 {workers} 进程，尚未开始模拟"
    progress(0, f"自由边界模拟 · {preparation} · 读取并检查完整模型…")
    if workers > 1 and not context.get("joint_boundary_fit"):
        require_parallel_runtime()

    def annotate(value):
        value.update(inference_mode="free_boundary_simulation", calibration_status="experimental_not_validated",
                     experimental_warning=warning, simulation_settings=settings)
        value["warnings"].insert(0, warning)
        value["warnings"].extend(settings.get("execution_warnings", []))
        value["methods"]["overall_test"] = METHOD
        value["methods"]["overall_multiplicity"] = "experimental_simulation_p_holm_unavailable_as_one"
        value["model_scope"] = "自由非负 odds 的共享主效应 Logistic；全部模型均可重新选择零风险边界，整体检验采用实验性参数模拟。"
        return _plain(value)

    if context.get("joint_boundary_fit"):
        report = build_tsk_feature_effects(context, confidence_level=confidence_level,
                                          zero_risk_policy="boundary")
        reason = "当前自由非负 odds 模拟尚不支持共享系数联合边界；保留逐组合风险，不输出未经校准的模拟显著性。"
        report.update(_status("boundary", reason))
        settings.update(replicates_attempted=0, replicates_completed=0)
        progress(100, reason)
        return annotate(report)

    design = np.asarray(context["design"], dtype=float)
    chain_index = np.asarray(context["chain_index"], dtype=int)
    n, k = np.asarray(context["n_tested"], dtype=float), np.asarray(context["n_failed"], dtype=float)
    if (np.any(n != np.floor(n)) or np.any(n >= 2. ** 63) or np.any(k != np.floor(k))):
        raise ValueError("Simulation requires integer binomial counts with n_tested within int64 range.")
    types = list(context["type_ids"])
    type_count = len(types)
    bound = float(context.get("logistic_coefficient_bound", 35.))
    start = np.asarray(context["coefficients"], dtype=float)
    state = context.get("boundary_fit")
    if state is not None:
        saved = _FrozenFit(context)
        start = _boundary_logit_start(saved.boundary_engine, saved.theta)
    progress(0, f"自由边界模拟 · {preparation} · 复核并重新拟合完整模型…")
    try:
        full = _fit(design, chain_index, n, k, type_count, start, bound,
                    lambda: progress(1, f"自由边界模拟 · {preparation} · 拟合并验证完整模型…"), "observed_full")
    except SimulationFitError as error:
        failed_context = dict(context, converged=False, boundary_fit=None)
        report = build_tsk_feature_effects(failed_context, confidence_level=confidence_level, zero_risk_policy="boundary")
        reason = f"自由边界完整模型验证失败（{error.stage}）：{error}"
        report.update(_status("simulation_fit_failed", reason))
        for feature in report["features"]:
            _unavailable_feature(feature, "simulation_fit_failed", reason)
        report["type_effects"] = _type_effects(_FrozenFit(failed_context), 0., 1 - confidence_level, ("simulation_fit_failed", reason))
        progress(100, reason)
        return annotate(report)
    full_context = _context_for_engine(context, full)
    # The simulation loop below validates each observed null and nested full
    # fit itself. Build contrasts here without fitting those same deletions a
    # second time merely to overwrite their LR and prediction-impact results.
    report = build_tsk_feature_effects(full_context, confidence_level=confidence_level,
                                     zero_risk_policy="boundary", _defer_feature_refits=True,
                                     progress_callback=lambda value, message: progress(
                                         2 + .03 * value, f"自由边界模拟 · {preparation} · {message}"))
    if report["status"] in ("full_fit_not_optimal", "fit_not_converged", "nonfinite_mle", "finite_mle_check_failed", "boundary"):
        progress(100, "自由边界完整模型的原样本复核未通过，模拟未执行。")
        return annotate(report)
    settings["observed_full_zero_tsk_ids"] = [types[index] for index in full.state["zero_type_indices"]]
    report["interval_source"] = ("ordinary_finite_model_wald_not_simulated" if not full.state["zero_type_indices"] else "unavailable_at_free_zero_boundary")
    report["warnings"].append("模拟仅针对特征整体 LR 检验；可用的有限模型系数区间仍是普通近似区间，并非模拟得到的区间。")
    columns = list(context["coefficient_columns"])
    names = [feature["feature"] for feature in report["features"]]
    # No ordinary chi-square result may survive an early simulation stop.
    for feature in report["features"]:
        feature["lrt"].update(p_value=None, p_adjusted=None, significant=None, critical_value=None)
    # Reuse exact, unchanged full-model query identifiability results across
    # feature deletions. A newly audited optimum gets its own frozen fit.
    progress(5, f"自由边界模拟 · {preparation} · 准备完整模型预测与可识别性检查…")
    frozen_full = _FrozenFit(full_context)
    global_failure = None
    with _SimulationExecutor((design, chain_index, n, type_count, bound),
                             workers, settings) as execution:
        for feature_index, feature in enumerate(report["features"]):
            name = feature["feature"]
            member_names = set(feature.get("column_names", [name]))
            indices = [type_count + index for index, column in enumerate(columns) if column[0] in member_names]
            if not indices:
                feature["lrt"] = _empty_lrt("no_variation", "该特征无可删除参数，未执行模拟检验。", full.state["minimum"])
                continue
            words = np.frombuffer(sha256(str(name).encode("utf-8")).digest(), dtype="<u4").astype(np.uint32).tolist()
            stream = np.random.SeedSequence([seed, *words])
            rng = np.random.default_rng(stream)
            detail = {"method": METHOD, "seed": seed, "feature_seed": [seed, *words],
                      "replicates_requested": count, "replicates_attempted": 0, "replicates_completed": 0,
                      "replicates_failed": 0, "replicates_unattempted": count, "stopped_early": False,
                      "exceedances": 0, "resolution": 1 / (count + 1), "p_value_mc_se": None,
                      "p_value_mc_lower": None, "p_value_mc_upper": None, "monte_carlo_confidence_level": .95,
                      "monte_carlo_interval_method": settings["monte_carlo_interval_method"],
                      "replicate_statistics": [], "replicate_zero_masks": [], "failures": [],
                      "replicate_fit_diagnostics": [],
                      "full_zero_mask_changed_count": 0, "reduced_zero_mask_changed_count": 0}
            keep = np.ones(design.shape[1], dtype=bool)
            keep[indices] = False
            def message(replicate, stage):
                value = 5 + 94 * (feature_index + replicate / count) / max(len(names), 1)
                progress(value, f"自由边界模拟 · {name} · {replicate}/{count} · {stage}")
            def simulation_message(replicate):
                stage = ("准备模拟" if execution.phase == "not_started"
                         else "重拟合完整/删特征模型并验证")
                message(replicate, f"{stage} · {execution.progress_description()}")
            try:
                observed_stage = "尚未开始本特征模拟：原始样本删特征拟合与完整模型复核（串行 1 进程）"
                message(0, observed_stage)
                observed_full, reduced, observed = _fit_pair(design, chain_index, n, k, type_count, keep, start, bound,
                                                            lambda: message(0, observed_stage), full=full, stage="observed")
                if observed_full.state["minimum"] < full.state["minimum"] - _likelihood_tolerance(full.state["minimum"]):
                    global_failure = "从删特征模型重启找到更好的完整模型，原完整拟合未建立可信最优解；本次推断停用。"
                    raise SimulationFitError("observed_full_audit", global_failure)
                full_zeros = list(observed_full.state["zero_type_indices"])
                null_zeros = list(reduced.state["zero_type_indices"])
                detail.update(observed_full_zero_tsk_ids=[types[index] for index in full_zeros],
                              observed_reduced_zero_tsk_ids=[types[index] for index in null_zeros],
                              observed_full_validation=observed_full.state["simulation_validation"],
                              observed_reduced_validation=reduced.state["simulation_validation"])
                lrt = {**_empty_lrt("simulation_experimental", "实验性自由边界参数模拟 LR；参考分布尚未完成校准验证。", observed_full.state["minimum"]),
                       "statistic": observed, "reduced_nll": reduced.state["minimum"], "simulation": detail}
                detail["tie_tolerance"] = 2 * _likelihood_tolerance(observed_full.state["minimum"])
                feature["lrt"] = lrt
                reduced_context = _context_for_engine(context, reduced)
                reduced_context.update(design=design[:, keep],
                                       coefficient_columns=[column for index, column in enumerate(columns, type_count) if keep[index]],
                                       categorical_features={key: value for key, value in context.get("categorical_features", {}).items() if key != name})
                message(0, "尚未开始本特征模拟：计算删特征预测变化与可识别性（串行 1 进程）")
                impact_full = frozen_full if observed_full is full else _FrozenFit(_context_for_engine(context, observed_full))
                impact_progress_state = [None, 0., 0]
                def impact_progress(stage, done, total):
                    now = monotonic()
                    previous_stage, last_time, last_done = impact_progress_state
                    if (stage != previous_stage or done == total or (done > 0 and last_done == 0)
                            or now - last_time >= .25):
                        impact_progress_state[:] = [stage, now, done]
                        message(0, f"尚未开始本特征模拟：{stage} {done}/{total}（串行 1 进程）")
                feature["deletion_impact"] = _deletion_impact(
                    impact_full, _FrozenFit(reduced_context), heartbeat=impact_progress)
                message(0, "原样本拟合与预测检查完成，准备生成模拟计数")
                params = np.asarray(reduced.state["params"])
                q_null = reduced.evaluate(params)[2]
                detail["null_chain_probabilities"] = q_null.tolist()
                replicate_start = np.zeros(design.shape[1])
                replicate_start[keep] = _boundary_logit_start(reduced, params)
                outcomes = execution.replicates(rng, q_null, keep, replicate_start, count, simulation_message)
                for replicate, outcome in outcomes:
                    detail["replicates_attempted"] += 1
                    detail["replicates_unattempted"] -= 1
                    if "failure" in outcome:
                        failure = outcome["failure"]
                        detail["replicates_failed"] += 1
                        detail["stopped_early"] = True
                        detail["failures"].append(failure)
                        lrt.update(_status("simulation_fit_failed", f"第 {replicate} 次模拟未通过拟合验证，未丢弃或补抽，整项 p 值不予报告：{failure['reason']}"))
                        break
                    statistic = outcome["statistic"]
                    detail["replicates_completed"] += 1
                    detail["replicate_statistics"].append(statistic)
                    new_full, new_null = outcome["zero_masks"]["full"], outcome["zero_masks"]["reduced"]
                    detail["replicate_zero_masks"].append(outcome["zero_masks"])
                    detail["replicate_fit_diagnostics"].append(outcome["diagnostics"])
                    detail["full_zero_mask_changed_count"] += int(new_full != full_zeros)
                    detail["reduced_zero_mask_changed_count"] += int(new_null != null_zeros)
                    detail["exceedances"] += int(statistic >= observed - detail["tie_tolerance"])
                execution.finish_feature(detail, lambda: message(execution.confirmed,
                    f"保留已派发的模拟诊断 · {execution.progress_description()}"))
                outcomes.close()
                if detail["replicates_completed"] == count and not detail["replicates_failed"]:
                    probability = (1 + detail["exceedances"]) / (count + 1)
                    lrt["p_value"] = probability
                    tail_estimate = detail["exceedances"] / count
                    detail["p_value_mc_se"] = (math.sqrt(tail_estimate * (1 - tail_estimate) / count)
                                                if 0 < detail["exceedances"] < count else None)
                    detail["p_value_mc_se_method"] = "binomial_tail_probability_plugin_interior_only_use_exact_mc_interval_at_endpoints"
                    detail["p_value_mc_lower"], detail["p_value_mc_upper"] = _mc_interval(detail["exceedances"], count, len(names))
            except SimulationFitError as error:
                detail["stopped_early"] = True
                detail["failures"].append({"replicate": None, "stage": error.stage, "reason": str(error)})
                feature["lrt"] = {**_empty_lrt("simulation_fit_failed", f"原始样本的自由边界嵌套拟合未通过：{error}", full.state["minimum"]), "simulation": detail}
            feature.update(_status(feature["lrt"]["status"], feature["lrt"]["reason"]))
            if global_failure:
                break
    _experimental_holm([feature["lrt"] for feature in report["features"]], 1 - confidence_level)
    if global_failure:
        report.update(_status("full_fit_not_optimal", global_failure))
        for feature in report["features"]:
            _unavailable_feature(feature, "full_fit_not_optimal", global_failure)
            feature["lrt"].update(experimental_significant=None, p_adjusted_mc_lower=None, p_adjusted_mc_upper=None)
        report["type_effects"] = _type_effects(_FrozenFit(full_context), 0., 1 - confidence_level, ("full_fit_not_optimal", global_failure))
    elif not names:
        report.update(_status("no_features", "没有数值或类别特征可做删组模拟检验；TSK 类型对比不执行删除 TSK 的整体检验。"))
    elif any(feature["lrt"]["status"] == "simulation_fit_failed" for feature in report["features"]):
        report.update(_status("partial", "部分模拟拟合未通过验证，相应整体 p 值未输出；已完成项目仍为未经校准的实验结果。"))
    else:
        report.update(_status("simulation_experimental", "已完成实验性自由边界整体模拟检验；尚未完成统计校准验证。"))
    progress(100, "自由边界模拟检验完成；结果仍属实验性。")
    return annotate(report)
