"""Reusable bounded spawn workers for independent joint-boundary starts.

Only numerical optimizations run in children. The parent retains candidate
ordering, boundary certification, adaptive face discovery and all inference.
"""
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from concurrent.futures.process import BrokenProcessPool
import logging
import multiprocessing
import os

from . import tsk_parallel as parallel


def _prepare_joint_model(common):
    from .tsk_logistic_joint_boundary import JointLogisticBoundaryFit

    design, chain_index, n, k, type_count, coefficient_bound = common
    return JointLogisticBoundaryFit(design, chain_index, n, k, type_count,
                                    coefficient_bound=coefficient_bound, analysis_workers=1)


def _optimize_joint_start(model, item, heartbeat):
    _, start, zero, offset, transform, constraint = item
    return model._optimize(start, zero, offset, transform, constraint)


class JointStartPool:
    """One lazy pool shared by successive face/profile batches.

    Completed results are returned in input order. A broken process pool keeps
    every completed value and invokes ``local`` only for unfinished jobs.
    Statistical/numerical exceptions from jobs and callback cancellation
    propagate, with workers terminated before control returns to the caller.
    """

    def __init__(self, common, workers, execution):
        self.common, self.workers, self.execution = common, workers, execution
        self.pool = None
        self.failed = False
        self.worker_pids = set(execution.get("worker_pids", []))
        self.session_worker_pids = set()
        execution.update(workers_used=workers, execution_backend="spawn_process_pool",
                         worker_pids=sorted(self.worker_pids), workers_observed=len(self.worker_pids),
                         phase="starting", session_workers_observed=0,
                         max_workers_used=max(workers, execution.get("max_workers_used", 1)),
                         pool_sessions=execution.get("pool_sessions", 0) + 1)
        for key, value in (("execution_warnings", []), ("batches", 0), ("completed_tasks", 0)):
            execution.setdefault(key, value)

    def close(self, *, terminate=False):
        pool, self.pool = self.pool, None
        parallel._shutdown(pool, terminate=terminate)

    def _start(self):
        if self.pool is not None:
            return
        parallel.require_parallel_runtime()
        from .process_logging import get_process_log_queue

        with parallel._SPAWN_ENV_LOCK:
            previous = {key: os.environ.get(key) for key in parallel._THREAD_ENV}
            try:
                os.environ.update({key: "1" for key in parallel._THREAD_ENV})
                spawn = multiprocessing.get_context("spawn")
                gate = spawn.Event()
                self.pool = ProcessPoolExecutor(max_workers=self.workers, mp_context=spawn,
                    initializer=parallel._initialize,
                    initargs=(_optimize_joint_start, self.common, _prepare_joint_model, gate, get_process_log_queue()))
                # Force every lazy worker to inherit the one-thread environment.
                for _ in range(self.workers):
                    self.pool.submit(parallel._ready)
                gate.set()
            finally:
                for key, value in previous.items():
                    if value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = value

    def map(self, items, *, local, progress):
        items = list(items)
        missing = object()
        output = [missing] * len(items)
        pending = {}
        completed = submitted = 0
        prior_completed = self.execution["completed_tasks"]
        self.execution["batches"] += 1

        def report():
            self.execution.update(completed_tasks=prior_completed + completed,
                                  worker_pids=sorted(self.worker_pids), workers_observed=len(self.worker_pids),
                                  session_workers_observed=len(self.session_worker_pids))
            progress(completed, len(items), min(len(pending), self.workers) if not self.failed else 1)

        def collect(ready):
            nonlocal completed
            broken = None
            # Sorting here also makes exception selection deterministic when
            # several completed jobs contain failures in the same poll.
            for future in sorted(ready, key=lambda value: pending[value]):
                index = pending.pop(future)
                try:
                    result = future.result()
                except BrokenProcessPool as error:
                    broken = error
                    continue
                if isinstance(result, parallel._WorkerResult):
                    self.worker_pids.add(result.pid)
                    self.session_worker_pids.add(result.pid)
                    result = result.value
                output[index] = result
                completed += 1
            return broken

        def fallback(error):
            nonlocal completed
            # Preserve other completed successes, including those outside the
            # wait() snapshot. Actual job exceptions still propagate here.
            collect([future for future in pending if future.done()])
            self.close(terminate=True)
            pending.clear()
            self.failed = True
            self.execution.update(workers_used=1, execution_backend="serial_after_process_failure", phase="serial")
            warning = f"联合边界子进程不可用，保留已完成起点，其余串行继续：{type(error).__name__}: {error}"
            self.execution["execution_warnings"].append(warning)
            logging.getLogger(__name__).warning(warning)
            for index, item in enumerate(items):
                if output[index] is missing:
                    report()
                    output[index] = local(item)
                    completed += 1
            report()
            return output

        try:
            if self.failed:
                for index, item in enumerate(items):
                    report()
                    output[index] = local(item)
                    completed += 1
                report()
                return output
            # Missing runtime dependencies remain actionable; they do not
            # silently turn a requested parallel calculation into serial work.
            parallel.require_parallel_runtime()
            try:
                self._start()
            except (OSError, RuntimeError) as error:
                return fallback(error)
            self.execution["phase"] = "running" if self.worker_pids else "starting"
            while completed < len(items):
                try:
                    while submitted < len(items) and len(pending) < 2 * self.workers:
                        pending[self.pool.submit(parallel._run, items[submitted])] = submitted
                        submitted += 1
                except (OSError, RuntimeError) as error:
                    return fallback(error)
                report()
                ready, _ = wait(pending, timeout=.1, return_when=FIRST_COMPLETED)
                broken = collect(ready)
                self.execution["phase"] = "running" if completed else "starting"
                if broken is not None:
                    return fallback(broken)
                report()
            self.execution["phase"] = "idle"
            return output
        except BaseException:
            self.close(terminate=True)
            raise
