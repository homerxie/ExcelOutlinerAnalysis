from __future__ import annotations

import multiprocessing


def main() -> None:
    # Frozen workers and the shared-memory resource tracker must branch away
    # before loading the application's GUI and its heavyweight dependencies.
    multiprocessing.freeze_support()
    from excel_data_analysis.gui.app import launch

    launch()


if __name__ == "__main__":
    main()
