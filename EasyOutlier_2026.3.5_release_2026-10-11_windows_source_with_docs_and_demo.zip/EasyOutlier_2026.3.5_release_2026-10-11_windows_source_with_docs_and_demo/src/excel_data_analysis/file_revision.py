"""Metadata revisions for reusing a Golden file's content digest safely."""
from __future__ import annotations

import ctypes
from functools import lru_cache
import os
from pathlib import Path


_WINDOWS = os.name == "nt"


class _WindowsFileBasicInfo(ctypes.Structure):
    # FILE_BASIC_INFO uses four LARGE_INTEGERs and one DWORD, even when this
    # structure is inspected by tests running on a non-Windows 64-bit host.
    _fields_ = [
        ("CreationTime", ctypes.c_int64),
        ("LastAccessTime", ctypes.c_int64),
        ("LastWriteTime", ctypes.c_int64),
        ("ChangeTime", ctypes.c_int64),
        ("FileAttributes", ctypes.c_uint32),
    ]


@lru_cache(maxsize=1)
def _windows_file_api():
    try:
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        create = kernel.CreateFileW
        create.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32,
                          ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p]
        create.restype = ctypes.c_void_p
        query = kernel.GetFileInformationByHandleEx
        query.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
        query.restype = ctypes.c_int32
        close = kernel.CloseHandle
        close.argtypes = [ctypes.c_void_p]
        close.restype = ctypes.c_int32
        return create, query, close
    except (AttributeError, OSError):
        return None


def _windows_change_time(path: Path) -> int | None:
    api = _windows_file_api()
    if api is None:
        return None
    create, query, close = api
    try:
        # FILE_READ_ATTRIBUTES; FILE_SHARE_READ | WRITE | DELETE; OPEN_EXISTING;
        # FILE_ATTRIBUTE_NORMAL. No data read or write access is requested.
        handle = create(str(path), 0x80, 0x7, None, 3, 0x80, None)
    except OSError:
        return None
    if handle is None or handle == ctypes.c_void_p(-1).value:
        return None
    try:
        info = _WindowsFileBasicInfo()
        if not query(handle, 0, ctypes.byref(info), ctypes.sizeof(info)):
            return None
        # Some filesystems can expose the structure without a usable ChangeTime.
        return int(info.ChangeTime) if info.ChangeTime > 0 else None
    except OSError:
        return None
    finally:
        close(handle)


def golden_file_revision(path: Path) -> tuple | None:
    """Return a metadata-only revision, or None when hashing is required.

    Unlike POSIX ctime, Windows stat ctime can mean creation time. Ask Windows
    for its metadata ChangeTime to detect an overwrite whose mtime was restored.
    Failure to stat propagates; an unavailable extended revision requests the
    caller's safe fallback of reading and hashing the file contents every time.
    """
    stat = path.stat()
    revision = (str(path), stat.st_dev, stat.st_ino, stat.st_ctime_ns, stat.st_mtime_ns, stat.st_size)
    if not _WINDOWS:
        return revision
    change_time = _windows_change_time(path)
    return (*revision, change_time) if change_time is not None else None
