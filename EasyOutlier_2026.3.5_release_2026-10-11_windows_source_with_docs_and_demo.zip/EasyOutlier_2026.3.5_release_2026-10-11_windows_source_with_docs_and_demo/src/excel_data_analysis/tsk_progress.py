"""Readable progress for joint Logistic fitting and conditional risk checks."""
from __future__ import annotations

import math


_JOINT_PHASES = {
    "joint_search_start": "搜索联合边界",
    "joint_face": "验证候选边界",
    "joint_face_certificate": "验证边界可达性",
    "joint_face_coordinates": "准备联合补偿方向",
    "joint_logistic_start": "拟合边界内的有限风险",
    "joint_optimize": "优化有限风险",
    "joint_reentry": "检查零风险重新进入正值",
    "joint_profile": "求解条件风险的似然剖面",
    "joint_query": "检查组合风险可识别性",
    "joint_search_complete": "候选边界搜索完成",
    "joint_fit_complete": "联合拟合完成",
    "independent_joint_block": "复核独立子模型",
}

_JOINT_OPERATIONS = {
    "monotone_linear_program": "检查单调分离方向",
    "face_certificate_linear_program": "检查边界可达性",
    "upper_recession_linear_program": "检查正向发散边界",
    "candidate_geometry": "准备联合补偿方向",
    "exact_normal_span": "核对共享系数约束",
    "normal_group_geometry": "建立共享重入约束",
    "candidate_validation": "检查重新进入正值的得分",
    "positive_reentry_probe": "重新拟合正风险候选",
    "likelihood_evaluation": "计算似然与梯度",
    "lbfgsb_iteration": "更新拟合参数",
    "newton_polish": "精化驻点",
    "newton_line_search": "试探精化步长",
    "search_expansion": "扩展搜索范围",
    "optimizer_complete": "该起点优化完成",
    "contrast_linear_program": "检查组合风险的边界方向",
    "identifiability_start": "检查组合风险可识别性",
    "identifiability_complete": "组合风险可识别性检查完成",
    "identifiability_failed": "组合风险检查未完成",
    "interval_start": "计算概率区间",
    "interval_complete": "概率区间计算完成",
    "interval_unavailable": "概率区间未通过验证",
    "profile_start": "拟合当前剖面点",
    "profile_complete": "当前剖面点拟合完成",
    "parallel_multistart_start": "准备并行拟合起点",
    "parallel_multistart": "并行拟合边界内的有限风险",
}


def joint_progress_message(event, *, prefix="Logistic 联合复核"):
    """Keep dynamic candidate counts distinct from a fixed completion total."""
    event = event if isinstance(event, dict) else {}
    stage = _JOINT_OPERATIONS.get(event.get("operation")) or _JOINT_PHASES.get(
        event.get("phase"), "复核联合边界与组合风险")
    parts = [prefix, stage]
    if event.get("block") is not None:
        parts.append(f"子模型 {event['block']}/{event.get('count', '?')}")
    if event.get("query_index") is not None:
        parts.append(f"组合检查 {event['query_index']}")
    if event.get("profile_index") is not None:
        parts.append(f"剖面点 {event['profile_index']}")
    elif event.get("search_index") is not None:
        parts.append(f"搜索轮次 {event['search_index']}")
    face = event.get("face_index", event.get("face_count"))
    if face is not None:
        discovered = event.get("face_count_discovered")
        if discovered is None:
            parts.append(f"候选边界 {face}")
        elif event.get("face_count_total_known"):
            parts.append(f"已检查边界 {face}/{discovered}")
        else:
            parts.append(f"候选边界 {face}/已发现 {discovered}（总数动态增加）")
    if event.get("workers_used") is not None:
        parts.append(f"并行进程 {event['workers_used']} · 活动 {event.get('active_workers', 0)}")
        if event.get("execution_phase") == "starting":
            parts.append("正在启动子进程")
    if event.get("completed_starts") is not None:
        parts.append(f"起点已完成 {event['completed_starts']}/{event.get('start_count', '?')}")
    elif event.get("start_index") is not None:
        parts.append(f"起点 {event['start_index']}/{event.get('start_count', '?')}")
    if event.get("zero_instance_count") is not None:
        parts.append(f"候选零风险实例 {event['zero_instance_count']}")
    if event.get("iteration") is not None:
        parts.append(f"迭代 {event['iteration']}")
    if event.get("evaluations") is not None:
        parts.append(f"评估 {event['evaluations']}")
    score, threshold = event.get("score_residual"), event.get("score_threshold")
    if isinstance(score, (int, float)) and math.isfinite(score) and threshold:
        parts.append(f"最近梯度/标准 {score / threshold:.3g}")
    elapsed = event.get("elapsed_seconds")
    if isinstance(elapsed, (int, float)) and math.isfinite(elapsed):
        parts.append(f"复核已用 {max(elapsed, 0.):.1f}s")
    return " · ".join(parts)
