"""Self-contained, read-only HTML presentation of saved TSK results."""
from __future__ import annotations

import json

from .tsk_effects_html import FEATURE_EFFECTS_SCRIPT


def render_tsk_html(report: dict) -> str:
    """Embed all supplied results without fitting, rounding or external assets."""
    data = json.dumps(report, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    for character, escape in (("&", "\\u0026"), ("<", "\\u003c"), (">", "\\u003e"),
                              ("\u2028", "\\u2028"), ("\u2029", "\\u2029")):
        data = data.replace(character, escape)
    return _DOCUMENT.replace("__FEATURE_EFFECTS_SCRIPT__", FEATURE_EFFECTS_SCRIPT, 1).replace("__TSK_REPORT_JSON__", data, 1)


_DOCUMENT = r'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'none'; base-uri 'none'; form-action 'none'">
<title>TSK 分析结果报告</title>
<style>
:root{color-scheme:light;--ink:#202838;--muted:#657184;--line:#dce2ec;--blue:#245bd6;--pale:#edf3ff;--surface:#fff;--bg:#fff}
.effects-table-region{min-width:0;max-width:100%}.effects-table-region .table-wrap{overflow-x:auto;max-width:100%;width:100%}.effects-table-region table{width:max-content;min-width:100%;table-layout:auto}.effects-table-region th,.effects-table-region td:not(.wide){min-width:86px;white-space:nowrap;overflow-wrap:normal}.effects-table-region td.wide{min-width:240px;max-width:360px;white-space:normal;overflow-wrap:anywhere}
.effects-assumption-banner{display:flex;align-items:center;justify-content:space-between;gap:12px}.effects-assumption-banner button{flex:none}.effects-assumption-dialog{width:min(560px,calc(100vw - 32px));max-height:80vh;overflow:auto;overscroll-behavior:contain;border:1px solid var(--line);border-radius:10px;padding:20px;color:var(--ink);background:var(--surface);box-shadow:0 12px 40px #20304a33;overflow-wrap:anywhere;white-space:pre-wrap}.effects-assumption-dialog::backdrop{background:#15253e55}.effects-assumption-dialog .actions{justify-content:flex-end}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif}
button,input,select{font:inherit}button,select,input[type=search]{border:1px solid #bac5d8;border-radius:6px;background:white;color:var(--ink);padding:7px 10px}button{cursor:pointer}button:hover{background:var(--pale)}button:disabled{opacity:.45;cursor:default}button.active{background:var(--blue);border-color:var(--blue);color:white}button:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid #9ebcff;outline-offset:2px}button.small{padding:3px 8px}
header{background:var(--surface);color:var(--ink);border-bottom:1px solid var(--line);padding:24px}header h1{font-size:25px;margin:0 0 4px;font-weight:650}header p{margin:0;color:var(--muted)}main{width:100%;min-width:0;margin:auto;padding:20px 24px 44px}.toolbar,.row,.tabs,.actions,.pager{display:flex;align-items:center;gap:9px;flex-wrap:wrap}.toolbar{justify-content:space-between;margin-bottom:15px}.toolbar label{font-weight:600}.toolbar select{max-width:min(620px,80vw)}.tabs{margin:16px 0}.tabs button{padding:10px 18px;border:0}.panel{background:white;border:1px solid var(--line);border-radius:10px;padding:20px;box-shadow:0 2px 6px #20304a05}.panel+.panel{margin-top:14px}h2{font-size:19px;margin:0 0 12px}h3{font-size:15px;margin:0 0 9px}p{margin:6px 0 12px}.muted,.caption{color:var(--muted)}.caption{font-size:12px}.badge{display:inline-block;border-radius:4px;background:var(--pale);color:#315181;padding:2px 7px;margin:2px 5px 2px 0}.notice{padding:12px 14px;background:#fff6e4;border:1px solid #eed9ad;border-radius:7px;white-space:pre-wrap;overflow-wrap:anywhere}.empty{padding:30px 18px;text-align:center;color:var(--muted);background:#f8f9fb;border-radius:8px}.summary-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}.stat{background:#f7f9fc;padding:12px;border-radius:7px}.stat strong{display:block;font-size:20px}.stat span{color:var(--muted)}.filters{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0}.picker{position:relative;max-width:300px}.picker>summary,.axis>summary{list-style:none;border:1px solid #c4ccda;border-radius:6px;padding:7px 10px;background:white;cursor:pointer;overflow-wrap:anywhere}.picker[open]{z-index:5}.picker-body{position:absolute;left:0;top:calc(100% + 5px);background:white;border:1px solid var(--line);box-shadow:0 5px 24px #15253e24;border-radius:8px;padding:12px;width:290px;max-width:85vw}.picker-list{max-height:240px;overflow:auto;margin:8px 0}.check-row{display:flex;align-items:flex-start;gap:7px;padding:4px 0;overflow-wrap:anywhere}.check-row input{margin-top:5px}.picker input[type=search]{width:100%}.axis{min-width:min(250px,100%);max-width:100%;flex:1}.axis-body{border:1px solid var(--line);border-top:0;border-radius:0 0 7px 7px;padding:9px}.axis-line{display:flex;align-items:center;gap:6px;padding:3px 0}.axis-line label{flex:1;overflow-wrap:anywhere}.axis-line button{min-width:29px}.axis-list{max-height:240px;overflow:auto}.table-wrap,.chart-scroll,.heatmap-wrap{overflow:auto;max-width:100%;border:1px solid var(--line);border-radius:7px;margin-top:12px}table{border-collapse:collapse;width:100%;font-size:13px}th,td{text-align:left;padding:9px 11px;border-bottom:1px solid var(--line);vertical-align:top;white-space:pre-wrap;overflow-wrap:anywhere}th{position:sticky;top:0;background:#eef2f8;font-weight:600;z-index:1;white-space:nowrap}th button{padding:0;border:0;background:transparent;font-weight:600;color:inherit}td.numeric{font-variant-numeric:tabular-nums;white-space:nowrap;text-align:right}tbody tr:nth-child(even){background:#fafbfd}tbody tr.clickable{cursor:pointer}tbody tr.clickable:hover,tbody tr.selected{background:#eaf1ff}td.wide{min-width:180px;max-width:440px}.pager{justify-content:flex-end;margin:12px 0 2px}.pager .page-number{width:75px;padding:4px}.pager .caption{margin-right:auto}.detail{margin-top:16px;border-top:1px solid var(--line);padding-top:15px;scroll-margin-top:12px}.detail:empty{display:none}.key-values{display:grid;grid-template-columns:minmax(110px,180px) 1fr;gap:5px 14px;margin:8px 0}.key-values dt{color:var(--muted)}.key-values dd{margin:0;white-space:pre-wrap;overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f5f7fa;padding:14px;border-radius:7px;font:12px/1.65 ui-monospace,SFMono-Regular,Consolas,monospace;max-height:65vh;overflow:auto}.plot{display:block;width:100%;min-width:0;background:white}.fit-plot{max-width:100%;margin:auto}.heatmap{table-layout:fixed;width:auto}.heatmap th{position:static;font-size:12px;white-space:pre-wrap;min-width:105px;max-width:180px;width:125px;text-align:center}.heatmap .heatmap-row-axis,.heatmap tbody th{min-width:110px;max-width:300px;width:160px;text-align:right}.heatmap td{padding:3px;width:125px;min-width:105px;height:44px;text-align:center}.heat-cell{border:1px solid #00000012;min-height:38px;width:100%;height:100%;border-radius:3px;font-variant-numeric:tabular-nums}.heat-cell:hover{outline:2px solid var(--blue);outline-offset:-2px}.heat-cell.missing{background:#fff!important;color:#6d7584!important;border:1px solid #ccd3df}.heat-cell.unavailable{background:#e2e6ed!important;color:#515d72!important}.extrapolation-setting{padding:10px 12px;border:1px solid var(--line);border-radius:7px;background:#fff}.extrapolation-setting>label{font-weight:600}.extrapolation-setting input{accent-color:var(--blue)}.legend{display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin:9px 0}.gradient{height:12px;width:150px;background:linear-gradient(90deg,#0d0887,#5302a3,#7e03a8,#a82296,#cb4679,#e56b5d,#f89441,#fdca26,#f0f921);border-radius:3px}.group-context{margin-top:6px;overflow-wrap:anywhere}.warning-list{margin:8px 0;padding-left:22px;white-space:pre-wrap;overflow-wrap:anywhere}.split{display:grid;grid-template-columns:minmax(0,1fr) minmax(280px,.7fr);gap:16px}.print-note{display:none}footer{margin-top:18px;color:var(--muted);font-size:12px}.error{border-color:#bd3546;background:#fff0f1;color:#8c2735}
@media(max-width:800px){main{padding:12px}.panel{padding:14px}.split{grid-template-columns:1fr}header{padding:20px 16px}.tabs button{padding:8px 12px}.toolbar{align-items:flex-start}.key-values{grid-template-columns:100px 1fr}}
@media print{body{background:white;font-size:10pt}header{background:white;color:black;padding:0 0 12px;border-bottom:1px solid #aaa}header p{color:#444}main{max-width:none;padding:12px 0}.toolbar,.tabs,.filters,.actions,.axis-controls,.pager button,.pager input,.no-print{display:none!important}.panel{border:0;box-shadow:none;padding:8px 0}.panel+.panel{border-top:1px solid #ccc}.chart-scroll,.heatmap-wrap,.table-wrap{overflow:visible;border:0}.plot{min-width:0}.heatmap{width:100%}.heatmap th,.heatmap td{min-width:0;width:auto;padding:4px;font-size:8pt}.heat-cell{padding:2px;font-size:8pt}th{position:static}.detail,pre{max-height:none;overflow:visible}pre{font-size:8pt}.print-note{display:block;color:#666}.heat-cell,.gradient{print-color-adjust:exact;-webkit-print-color-adjust:exact}tr{break-inside:avoid}}

/* The current result owns its side panel; wide tables scroll inside the main column. */
#content,.detail-main,.detail-main>*,.detail-sidebar,.detail-content{min-width:0}
.detail-layout{display:grid;grid-template-columns:minmax(0,1fr) clamp(320px,28vw,380px);gap:20px;align-items:start;min-width:0}
.detail-sidebar{position:sticky;top:12px;max-height:var(--detail-available-height,calc(100vh - 24px));overflow:auto;overscroll-behavior:contain;border:1px solid var(--line);border-radius:9px;background:#fff;overflow-wrap:anywhere}
.detail-heading{position:sticky;top:0;z-index:3;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:12px 14px;border-bottom:1px solid var(--line);background:#fff}
.detail-heading h3{margin:0}.detail-content{padding:14px}.detail-content h3{margin-top:16px}.detail-content h3:first-child{margin-top:0}
.detail-content .key-values{grid-template-columns:minmax(0,100px) minmax(0,1fr);gap:5px 10px}.detail-content .key-values>*{min-width:0}
.detail-content .pager{gap:6px;font-size:12px}.detail-content .pager .caption{flex-basis:100%}.detail-content .pager .page-number{width:55px;min-width:0}
.detail-content .empty{padding:22px 12px}.detail-content .notice{padding:9px 10px}.detail-content pre{padding:10px;max-width:100%}
.detail-summary{padding:9px 11px;border-radius:7px;background:#f5f8fd;margin-bottom:14px}.detail-summary p{margin:3px 0}
.related-search{width:100%;min-width:0;margin-bottom:8px}.related-card{padding:10px 11px;border:1px solid var(--line);border-radius:7px;margin:9px 0;background:#fff;overflow-wrap:anywhere}.related-card h4{margin:0 0 5px;font-size:14px}.related-card p{margin:4px 0}.related-card .key-values{grid-template-columns:minmax(0,90px) minmax(0,1fr);font-size:12px}
.related-card details{margin-top:8px}.detail-more{margin:14px 0}.detail-more>summary{cursor:pointer;font-weight:600;color:#315181}
.chain-members{border-top:1px solid var(--line);padding-top:9px}.chain-members>summary{cursor:pointer;font-weight:600;color:#315181}.chain-members[open]>summary{margin-bottom:10px}.chain-members .related-card{padding:9px;background:#f8fafc}.chain-members .related-card h4{font-size:13px}
.tsk-identity,.tsk-conditions,.tsk-coordinates{color:var(--ink);overflow-wrap:anywhere}.tsk-conditions,.tsk-coordinates{font-size:12px}
.detail-toggle,.detail-close,.detail-backdrop{display:none}.detail-toggle{margin:0 0 12px}.detail-backdrop{position:fixed;inset:0;background:#14223855;z-index:29}
.risk-bar{display:grid;grid-template-columns:minmax(0,30%) minmax(0,1fr) minmax(0,17%);align-items:center;gap:12px;padding:9px 12px;border-bottom:1px solid #e5e9f0;cursor:pointer;overflow-wrap:anywhere}.risk-bar>*{min-width:0}.risk-bar.selected{background:#eaf1ff}.risk-bar:focus-visible{outline:2px solid var(--blue);outline-offset:-2px}
.risk-formulas{display:flex;flex-wrap:wrap;gap:12px;margin:12px 0}.risk-formulas>div{padding:12px 16px;border:1px solid #cbd8ef;border-radius:7px;background:#f7faff;max-width:100%;overflow-x:auto}.risk-formulas math{font-size:18px}.risk-formula-notes math{font-size:17px;margin:10px 0}.risk-formula-notes .formula-scroll{overflow-x:auto}.risk-curve-controls{margin:12px 0}.risk-curve-controls select{flex:1;max-width:100%}.risk-curve-selection{padding:10px 12px;background:#eef4ff;border-radius:7px;overflow-wrap:anywhere;font-variant-numeric:tabular-nums}.risk-curve-point{cursor:pointer;outline:none}.risk-curve-marker{opacity:.65}.risk-curve-point.selected .risk-curve-marker{stroke:#8d3c09;stroke-width:2.5;opacity:.85}.risk-curve-point:focus-visible .risk-curve-marker{stroke:#142238;stroke-width:3;opacity:1}.risk-curve-plot{min-width:500px}.risk-curve-plot text{font-family:inherit}.risk-interval-horizontal,.risk-interval-vertical{stroke:#808080;opacity:.6}
.table-wrap,.chart-scroll,.heatmap-wrap{min-width:0;width:100%}.detail-main select,.detail-main input[type=search]{min-width:0;max-width:100%}.detail-main p,.detail-main h2,.detail-main h3{overflow-wrap:anywhere}
.heatmap .heatmap-column-axis{min-width:0;max-width:none;width:auto;text-align:left;padding:7px 11px;background:#e4ebf5}.heatmap-axis-names{display:block;max-width:min(620px,60vw);overflow-wrap:anywhere}.heatmap .heatmap-row-axis{vertical-align:bottom;background:#e4ebf5}
@media(max-width:899px){
 .detail-layout{grid-template-columns:minmax(0,1fr)}.detail-toggle,.detail-close{display:inline-block}
 .detail-sidebar{position:fixed;inset:12px 12px 12px auto;width:min(380px,calc(100vw - 24px));max-height:calc(100dvh - 24px);z-index:30;box-shadow:0 8px 36px #17263d38;visibility:hidden;transform:translateX(calc(100% + 24px))}
 .detail-sidebar.drawer-open{visibility:visible;transform:none}.detail-backdrop.drawer-open{display:block}
}
@media(max-width:599px){.risk-bar{grid-template-columns:minmax(0,1fr) minmax(80px,25%);gap:5px 10px}.risk-bar>div:first-child{grid-column:1 / -1}.detail-layout{gap:12px}}
@media print{
 .detail-layout{display:block}.detail-sidebar{display:block!important;position:static;inset:auto;width:100%;max-height:none;overflow:visible;visibility:visible;transform:none;box-shadow:none;border:1px solid #aaa;margin-top:18px}
 .detail-heading{position:static}.detail-backdrop,.detail-toggle,.detail-close,.related-search{display:none!important}.detail-content pre{max-height:none;overflow:visible}.related-card{break-inside:avoid}
}
</style></head><body>
<header><h1>TSK 分析结果报告</h1><p id="report-subtitle">已保存结果 · 单文件离线查看</p></header>
<main><div class="toolbar"><div class="row"><label id="analysis-selector-label" hidden>已保存分析 <select id="analysis-select" aria-label="切换已保存分析"></select></label><label>节点 / 批次 <select id="group-select" aria-label="选择节点和批次"></select></label></div><div class="actions"><button id="print-report">打印当前视图</button></div></div>
<section class="panel" id="overview"></section><nav class="tabs" id="main-tabs" aria-label="报告页面"></nav><section class="panel" id="content"></section>
<p class="print-note">打印范围为当前节点／批次和当前视图的可见分页。完整结果与其他页面保留在 HTML 文件中。</p>
<footer>本报告保留导出时已有的结果。切换已保存分析、筛选、排序、换轴与分页只改变显示；不会重新拟合、补算概率或推断缺失数据。无数据与不可估计结果不会作为零风险显示。</footer></main>
<noscript><p>请启用浏览器 JavaScript 查看嵌入的结果。报告不连接网络。</p></noscript>
<script id="tsk-report-data" type="application/json">__TSK_REPORT_JSON__</script>
<script>
(()=>{'use strict';
const documentReport=JSON.parse(document.getElementById('tsk-report-data').textContent);
let report=documentReport,groups=Array.isArray(report.groups)?report.groups:[];
const initial=report.view_state||{};
const $=id=>document.getElementById(id), NS='http://www.w3.org/2000/svg';
const nat=new Intl.Collator('zh-CN',{numeric:true,sensitivity:'base'}), caches=new Map(),analysisStates=new Map();
let states=new Map(),analysisKey=documentReport.active_analysis_key||'__current__';
let groupIndex=Number.isInteger(initial.group_index)&&initial.group_index>=0&&initial.group_index<groups.length?initial.group_index:0;
let mainPage=['risk','fit','joint','effects','model'].includes(initial.main_view)?initial.main_view:'risk';
let resizeScatter=null;
let updateRiskCurve=null;
const narrowDetails=window.matchMedia('(max-width: 899px)');
const STATUS={ok:'可用',no_data:'无数据',not_identifiable:'不可单独识别',unidentifiable:'不可单独识别',interval_unavailable:'区间不可用',fit_not_converged:'未收敛',not_converged:'未收敛',boundary_low:'零边界估计',boundary_unbounded:'系数趋向无穷边界',unavailable:'不可用',outside_model_domain:'定义域外',observed:'有有效数据支持',no_active_support:'本组无有效支持',extrapolated:'模板外组合',reference_coding:'参考类别编码',computation_limited:'计算受限',model_interval_mismatch:'估计与区间不一致'};
function el(tag,text,cls){const n=document.createElement(tag);if(text!==undefined&&text!==null)n.textContent=String(text);if(cls)n.className=cls;return n;}
function svg(tag,attrs={}){const n=document.createElementNS(NS,tag);Object.entries(attrs).forEach(([k,v])=>n.setAttribute(k,String(v)));return n;}
function button(text,fn,cls){const n=el('button',text,cls);n.type='button';n.addEventListener('click',fn);return n;}
function clean(n){n.replaceChildren();return n;}
function preserveViewport(node,render){
    const x=window.scrollX,y=window.scrollY,minHeight=node.style.minHeight;
    // Chart measurements can flush layout while the old content is empty.
    // Keep its height during that interval so the browser cannot clamp scrollY.
    node.style.minHeight=node.getBoundingClientRect().height+'px';
    try{return render();}
    finally{
        node.style.minHeight=minHeight;
        // A genuinely shorter result may only scroll as far as its new bottom.
        window.scrollTo({left:x,top:y,behavior:'instant'});
    }
}
function finite(v){return typeof v==='number'&&Number.isFinite(v);}
function probability(v){return finite(v)&&v>=0&&v<=1;}
function number(v){return finite(v)?(v!==0&&Math.abs(v)<1e-5?v.toExponential(4):Number(v.toPrecision(9)).toLocaleString('en-US',{maximumFractionDigits:10})):v===null||v===undefined?'—':String(v);}
function pct(v){if(!probability(v))return '—';const p=v*100;return (p!==0&&p<.0001?p.toExponential(4):p.toLocaleString('en-US',{maximumFractionDigits:5}))+'%';}
function pp(v){return finite(v)?(v>0?'+':'')+number(v*100)+' pp':'—';}
function text(v){if(v===null||v===undefined)return '—';if(Array.isArray(v))return v.map(text).join('、')||'—';if(typeof v==='object')return Object.entries(v).map(([key,value])=>key+'：'+text(value)).join('；')||'—';return String(v);}
function status(v){return STATUS[v]||v||'—';}
function available(r){return r&&r.status!=='no_data'&&r.identifiable!==false&&probability(r.probability);}
function boundary(r){return r&&(r.estimate_kind==='boundary_low'||r.status==='boundary_low');}
function riskText(r){return available(r)?boundary(r)?'零边界估计':pct(r.probability):'—';}
function confidence(r,v){const g=groups[groupIndex]||{};return r.confidence_level||v?.confidence_level||g.prediction_context?.confidence_level||g.diagnostics?.confidence_level||.95;}
function interval(r,v){if(!available(r)||!probability(r.ci_upper))return '区间不可用';const conf=pct(confidence(r,v)),method=r.interval_method||'';if(r.interval_sidedness==='upper')return method.includes('approximate')?'近似上限（'+conf+' 轮廓似然阈值）：'+pct(r.ci_upper):'单侧 '+conf+' 上限：'+pct(r.ci_upper);if(!probability(r.ci_lower))return '区间不可用';return conf+(method==='conservative_binomial_chain_bounds'?' 保守区间：':' 区间：')+pct(r.ci_lower)+' – '+pct(r.ci_upper);}
function conditions(r){return Object.entries(r.categories||{}).map(([k,v])=>k+'='+text(v)).join(' · ')||r.level||'类型概率';}
function rowLabel(r){return String(r.tsk_id??'—')+' · '+conditions(r);}
function kv(parent,values){const list=el('dl',null,'key-values');Object.entries(values).forEach(([k,v])=>{list.append(el('dt',k),el('dd',text(v)));});parent.append(list);}
function notice(parent,message){parent.append(el('div',message,'notice'));}
function empty(parent,message){parent.append(el('div',message,'empty'));}
function ordered(values){return [...new Set(values.map(String))].sort((a,b)=>nat.compare(a,b)||(a<b?-1:a>b?1:0));}
function field(r,key){return key==='tsk_id'?String(r.tsk_id??''):key.startsWith('category:')?String(r.categories?.[key.slice(9)]??''):key.startsWith('features:')?r.features?.[key.slice(9)]:r[key];}
function sortRows(rows,key,descending){return [...rows].sort((a,b)=>{let av=field(a,key),bv=field(b,key);if(key==='probability'){if(!available(a))av=null;if(!available(b))bv=null;}const am=av===null||av===undefined||typeof av==='number'&&!finite(av),bm=bv===null||bv===undefined||typeof bv==='number'&&!finite(bv);if(am||bm)return am===bm?0:am?1:-1;const cmp=finite(av)&&finite(bv)?av-bv:nat.compare(String(av),String(bv));return descending?-cmp:cmp;});}
function definitions(g){const context=g.prediction_context?.categorical_features,defs=context&&Object.keys(context).length?context:g.diagnostics?.categorical_features||{};const names=g.options?.categorical_feature_names?.length?g.options.categorical_feature_names:Object.keys(defs);return Object.fromEntries(names.map(name=>[name,defs[name]||{levels:[]} ]));}
function fullViews(g){if(caches.has(g))return caches.get(g);const defs=definitions(g),names=Object.keys(defs),ids=new Set((g.prediction_context?.all_type_ids||g.types?.map(r=>r.tsk_id)||[]).map(String));const count=names.reduce((n,k)=>n*(defs[k].levels||[]).length,1),found={};for(const v of [...(g.combination_views||[])].reverse()){const policy=v.extrapolate!==false?'yes':'no';if(found[policy]||v.dimension!=='__all_categories__'||!names.length||!count||v.levels?.length!==count||v.rows?.length!==ids.size*count)continue;const seen=new Set();let valid=true;const allowed=names.map(k=>new Set((defs[k].levels||[]).map(String)));for(const r of v.rows){const values=names.map(k=>String(r.categories?.[k]??''));if(!ids.has(String(r.tsk_id))||values.some((x,i)=>!allowed[i].has(x))){valid=false;break;}const key=JSON.stringify([String(r.tsk_id),...values]);if(seen.has(key)){valid=false;break;}seen.add(key);}if(valid)found[policy]=v;}caches.set(g,found);return found;}
function state(){if(states.has(groupIndex))return states.get(groupIndex);const g=groups[groupIndex]||{},defs=definitions(g),cats=Object.keys(defs),views=fullViews(g),apply=groupIndex===initial.group_index;const saved=apply?initial:{};const keys=['tsk_id',...cats.map(k=>'category:'+k)];let x=Array.isArray(saved.x_dimensions)?saved.x_dimensions.filter(k=>keys.includes(k)):[...keys.slice(1)];x=[...new Set(x)];let y=Array.isArray(saved.y_dimensions)?saved.y_dimensions.filter(k=>keys.includes(k)&&!x.includes(k)):['tsk_id'].filter(k=>!x.includes(k));y=[...new Set(y)];for(const k of keys)if(!x.includes(k)&&!y.includes(k))(k==='tsk_id'?y:x).push(k);const latest=[...(g.combination_views||[])].reverse().find(v=>v===views.yes||v===views.no);const s={noExtrap:typeof saved.no_extrapolation==='boolean'?saved.no_extrapolation:latest?latest.extrapolate===false:true,filters:{},sort:keys.includes(saved.sort_field)||saved.sort_field==='probability'?saved.sort_field:'tsk_id',desc:!!saved.sort_descending,x,y,riskView:['curve','bars','bar','chart','heatmap','table','details'].includes(saved.risk_view)?({bars:'bar',chart:'bar',details:'table'}[saved.risk_view]||saved.risk_view):'curve',curveHorizontal:!!saved.curve_horizontal_intervals,curveVertical:!!saved.curve_vertical_intervals,curveZoomAxis:['both','eta','probability'].includes(saved.curve_zoom_axis)?saved.curve_zoom_axis:'both',metric:saved.heatmap_metric==='support'?'support':'probability',riskPage:1,heatPage:1,fitPage:1,topologyPage:1,jointPage:1,coefficientPage:1,fitView:'fit',modelView:'model',tableSort:null};for(const k of keys){const vals=k==='tsk_id'?(g.prediction_context?.all_type_ids||g.types?.map(r=>r.tsk_id)||[]):defs[k.slice(9)].levels||[];const all=ordered(vals);s.filters[k]=new Set(Array.isArray(saved.filters?.[k])?saved.filters[k].map(String).filter(v=>all.includes(v)):all);}states.set(groupIndex,s);return s;}
function riskSource(){const g=groups[groupIndex]||{},s=state(),defs=definitions(g);if(!Object.keys(defs).length)return {rows:g.types||[],view:null,defs};const view=fullViews(g)[s.noExtrap?'no':'yes'];return {rows:view?.rows||[],view,defs};}
function filteredRisk(){const s=state(),source=riskSource().rows,signature=JSON.stringify([Object.entries(s.filters).map(([k,v])=>[k,[...v]]),s.sort,s.desc]);if(s.filteredCache?.source===source&&s.filteredCache.signature===signature)return s.filteredCache.rows;const rows=sortRows(source.filter(r=>Object.entries(s.filters).every(([k,values])=>values.has(field(r,k)))),s.sort,s.desc);s.filteredCache={source,signature,rows};return rows;}
function pager(parent,total,size,current,onChange,label='条'){const pages=Math.max(1,Math.ceil(total/size)),page=Math.min(Math.max(1,current),pages),wrap=el('div',null,'pager');wrap.append(el('span',total?'共 '+number(total)+' '+label+' · 当前 '+number((page-1)*size+1)+'–'+number(Math.min(page*size,total)):'暂无记录','caption'));const prev=button('上一页',()=>onChange(page-1),'small'),next=button('下一页',()=>onChange(page+1),'small');prev.disabled=page<=1;next.disabled=page>=pages;const input=el('input');input.type='number';input.className='page-number';input.min='1';input.max=String(pages);input.value=String(page);input.setAttribute('aria-label','页码');let submitted=false;const submit=()=>{if(submitted)return;const target=Math.max(1,Math.min(pages,Math.floor(Number(input.value)||1)));input.value=String(target);if(target!==page){submitted=true;onChange(target);}};input.addEventListener('change',submit);input.addEventListener('blur',submit);input.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();submit();}});wrap.append(prev,input,el('span','/ '+number(pages)),next);parent.append(wrap);return [(page-1)*size,page*size];}
function makeTable(parent,rows,columns,{onSelect,selected,onSort}={}){
    const wrap=el('div',null,'table-wrap'),table=el('table'),thead=el('thead'),head=el('tr');
    columns.forEach(c=>{
        const th=el('th'),label=onSort?button(c.title,()=>onSort(c.key)):document.createTextNode(c.title);
        if(c.tooltip){th.title=c.tooltip;if(onSort)label.title=c.tooltip;}
        th.append(label);head.append(th);
    });
    thead.append(head);table.append(thead);const body=el('tbody');
    rows.forEach(r=>{
        const tr=el('tr');
        if(onSelect){
            tr.className='clickable'+(selected===r?' selected':'');tr.tabIndex=0;
            const pick=()=>{for(const item of body.children)item.classList.remove('selected');tr.classList.add('selected');onSelect(r);};
            tr.addEventListener('click',pick);tr.addEventListener('keydown',e=>{if(e.key==='Enter')pick();});
        }
        columns.forEach(c=>{
            const value=c.format?c.format(r):text(field(r,c.key)),td=el('td',value,c.numeric?'numeric':c.wide?'wide':'');
            const tooltip=c.cellTooltip?c.cellTooltip(r):c.tooltip;if(tooltip)td.title=tooltip;
            tr.append(td);
        });
        body.append(tr);
    });
    table.append(body);wrap.append(table);parent.append(wrap);return table;
}
function subTabs(parent,choices,current,onChange){const n=el('div',null,'tabs no-print');choices.forEach(([key,label])=>n.append(button(label,()=>onChange(key),current===key?'active':'')));parent.append(n);}
function picker(parent,key,title,values){const s=state(),d=el('details',null,'picker'),summary=el('summary'),body=el('div',null,'picker-body'),search=el('input');search.type='search';search.placeholder='搜索 '+title;const actions=el('div',null,'row'),list=el('div',null,'picker-list'),paging=el('div');let page=1;const updateSummary=()=>summary.textContent=title+' · '+s.filters[key].size+'/'+values.length;const changed=()=>{updateSummary();s.riskPage=s.heatPage=1;renderRiskBody();};actions.append(button('全选',()=>{s.filters[key]=new Set(values);renderList();changed();},'small'),button('清空',()=>{s.filters[key].clear();renderList();changed();},'small'));function renderList(){clean(list);clean(paging);const needle=search.value.toLocaleLowerCase(),visible=values.filter(v=>v.toLocaleLowerCase().includes(needle));const [from,to]=pager(paging,visible.length,60,page,p=>{page=p;renderList();},'值');visible.slice(from,to).forEach(v=>{const label=el('label',null,'check-row'),input=el('input');input.type='checkbox';input.checked=s.filters[key].has(v);input.addEventListener('change',()=>{input.checked?s.filters[key].add(v):s.filters[key].delete(v);changed();});label.append(input,el('span',v));list.append(label);});}search.addEventListener('input',()=>{page=1;renderList();});body.append(search,actions,list,paging);d.append(summary,body);d.addEventListener('toggle',()=>{if(d.open)renderList();});parent.append(d);updateSummary();}
function groupOverview(){const g=groups[groupIndex]||{},node=$('overview');clean(node);node.append(el('h2',g.label||g.node||'暂无结果'));const diag=g.diagnostics||{},summary=el('div',null,'row');summary.append(el('span',(g.types||[]).length+' 个 TSK','badge'),el('span',(g.chains||[]).length+' 条 Chain','badge'),el('span',diag.converged?'已收敛':'未确认收敛','badge'));if(diag.rank!==undefined)summary.append(el('span','秩 '+diag.rank+'/'+(diag.parameter_count??'—'),'badge'));node.append(summary);node.append(el('p','节点：'+text(g.node)+' · 批次方式：'+({none:'混合原批',separate:'按原批',parent:'按母批'}[g.batch_mode]||g.batch_mode||'—')+(g.parent_batch_id?' · 母批：'+g.parent_batch_id:''),'group-context'));if(g.source_batches?.length)node.append(el('p','原批：'+g.source_batches.join('、'),'caption'));const actions=el('div',null,'actions');actions.append(button('查看诊断',()=>{mainPage='model';state().modelView='diagnostics';renderMain();},'small'));node.append(actions);}
function renderMain(){
    preserveViewport($('content'),()=>{
        resizeScatter=null;groupOverview();const tabs=clean($('main-tabs'));
        [['risk','风险结果'],['fit','拟合检查'],['joint','联合风险'],['effects','特征影响'],['model','模型与诊断']].forEach(([key,label])=>
            tabs.append(button(label,()=>{mainPage=key;renderMain();},mainPage===key?'active':'')));
        const content=clean($('content'));
        if(!groups.length){empty(content,'没有可展示的 TSK 结果。');return;}
        if(mainPage==='risk')renderRisk(content);
        else if(mainPage==='fit')renderFit(content);
        else if(mainPage==='joint')renderJoint(content);
        else if(mainPage==='effects')renderEffects(content);
        else renderModel(content);
    });
    fitDetailHeight();
}
function relation(row){const g=groups[groupIndex]||{},index=g.combination_chain_index;if(!index?.available)return {rows:[],reason:'本结果没有可用的关联链信息。'};const dims=index.dimensions||[],key=JSON.stringify([String(row.tsk_id),dims.map(n=>String(row.categories?.[n]??''))]),ids=index.chains_by_key?.[key]||[];if(!ids.length)return {rows:[],reason:(index.incomplete_types||[]).map(String).includes(String(row.tsk_id))?'该 TSK 的关联信息不完整，无法确定相关 Chain。':'完整模板中没有匹配该条件的 Chain。'};const s=state();if(!s.chainMap)s.chainMap=new Map((g.chains||[]).map(r=>[String(r.chain_id),r]));return {rows:ids.map(id=>s.chainMap.get(String(id))||{chain_id:id,n_tested:0}),reason:''};}

function riskKey(row){
    return JSON.stringify([String(row.tsk_id??''),Object.entries(row.categories||{}).sort(([a],[b])=>a<b?-1:a>b?1:0).map(([key,value])=>[key,String(value)])]);
}
function selectedRisk(){
    const s=state(),source=riskSource().rows;
    if(s.riskLookup?.source!==source)s.riskLookup={source,rows:new Map(source.map(row=>[riskKey(row),row]))};
    const row=s.riskLookup.rows.get(s.selectedRiskKey);
    s.selectedRisk=row&&Object.entries(s.filters).every(([key,values])=>values.has(field(row,key)))?row:null;
    return s.selectedRisk;
}
function selectedChain(){
    const s=state();
    if(!s.chainMap)s.chainMap=new Map((groups[groupIndex].chains||[]).map(row=>[String(row.chain_id),row]));
    return s.chainMap.get(s.selectedChainId)||null;
}
function setDrawer(kind,open,focus=false){
    const s=state();s.drawerOpen=s.drawerOpen||{};s.drawerOpen[kind]=open;
    syncDetailVisibility();
    if(focus&&narrowDetails.matches){
        const target=open?document.querySelector('.detail-close'):document.querySelector('.detail-toggle');
        target?.focus({preventScroll:true});
    }
}
function fitDetailHeight(){
    const aside=document.querySelector('.detail-sidebar');if(!aside||narrowDetails.matches)return;
    const layout=aside.closest('.detail-layout'),top=Math.max(12,layout.getBoundingClientRect().top);
    // Measure with the viewport cap first so a short main view does not freeze a
    // newly selected detail at the previous placeholder's height.
    const viewportHeight=Math.max(0,window.innerHeight-top-12);
    aside.style.setProperty('--detail-available-height',viewportHeight+'px');
    const bottom=Math.min(window.innerHeight-12,layout.getBoundingClientRect().bottom);
    aside.style.setProperty('--detail-available-height',Math.max(0,bottom-top)+'px');
}
function focusOpenDrawer(){
    const aside=document.querySelector('.detail-sidebar.drawer-open');
    if(aside&&narrowDetails.matches&&!aside.contains(document.activeElement))aside.querySelector('.detail-close')?.focus({preventScroll:true});
}
function syncDetailVisibility(){
    const aside=document.querySelector('.detail-sidebar');if(!aside)return;
    const kind=aside.dataset.kind,open=!!state().drawerOpen?.[kind],hidden=narrowDetails.matches&&!open;
    aside.classList.toggle('drawer-open',open);aside.inert=hidden;
    aside.setAttribute('aria-hidden',String(hidden));
    aside.setAttribute('role',narrowDetails.matches?'dialog':'complementary');
    if(narrowDetails.matches&&open)aside.setAttribute('aria-modal','true');else aside.removeAttribute('aria-modal');
    document.querySelector('.detail-backdrop')?.classList.toggle('drawer-open',narrowDetails.matches&&open);
    const toggle=document.querySelector('.detail-toggle');if(toggle)toggle.setAttribute('aria-expanded',String(!hidden));
    fitDetailHeight();
}
function detailLayout(parent,kind){
    const layout=el('div',null,'detail-layout'),main=el('div',null,'detail-main');
    const aside=el('aside',null,'detail-sidebar'),heading=el('div',null,'detail-heading');
    const title=kind==='risk'?'TSK 与相关 Chain':'Chain 与成员 TSK';
    aside.id=kind+'-sidebar';aside.dataset.kind=kind;aside.setAttribute('aria-label',title);
    const toggle=button('查看所选详情',()=>setDrawer(kind,true,true),'detail-toggle no-print');
    toggle.setAttribute('aria-controls',aside.id);main.append(toggle);
    const close=button('关闭',()=>setDrawer(kind,false,true),'detail-close small no-print');
    close.setAttribute('aria-label','关闭详情侧栏');heading.append(el('h3',title),close);
    const content=el('div',null,'detail-content');content.id=kind==='risk'?'risk-detail':'chain-detail';
    aside.append(heading,content);const backdrop=el('div',null,'detail-backdrop no-print');
    backdrop.setAttribute('aria-hidden','true');backdrop.addEventListener('click',()=>setDrawer(kind,false,true));
    layout.append(main,aside,backdrop);parent.append(layout);syncDetailVisibility();
    return main;
}
function detailStats(parent,title,values){
    const details=el('details',null,'detail-more');details.append(el('summary',title));kv(details,values);parent.append(details);
}
function pagedCards(parent,rows,key,renderCard){
    const s=state();s.cardLists=s.cardLists||{};
    const local=s.cardLists[key]||(s.cardLists[key]={page:1,search:''});
    const search=el('input');search.type='search';search.className='related-search no-print';
    search.placeholder='搜索关联记录';search.setAttribute('aria-label',search.placeholder);search.value=local.search;
    const body=el('div');parent.append(search,body);
    function draw(){
        clean(body);const query=local.search.toLocaleLowerCase();
        const shown=query?rows.filter(row=>JSON.stringify(row).toLocaleLowerCase().includes(query)):rows;
        const [from,to]=pager(body,shown.length,15,local.page,page=>{local.page=page;draw();});
        if(!shown.length){empty(body,'没有匹配的关联记录；可清空搜索查看全部。');focusOpenDrawer();return;}
        shown.slice(from,to).forEach(row=>{const card=el('article',null,'related-card');renderCard(card,row);body.append(card);});
        focusOpenDrawer();
    }
    search.addEventListener('input',()=>{local.search=search.value;local.page=1;draw();});draw();
}
function showRisk(row){
    const s=state(),key=riskKey(row),changed=s.selectedRiskKey!==key;
    s.selectedRiskKey=key;refreshRiskDetail();fitDetailHeight();
    if(changed)$('risk-sidebar').scrollTop=0;
    setDrawer('risk',true,true);
    document.querySelectorAll('.risk-bar').forEach(item=>item.classList.toggle('selected',item.dataset.riskKey===key));
    if(updateRiskCurve)updateRiskCurve(true);
}
function refreshRiskDetail(){
    const parent=$('risk-detail');if(!parent)return;
    const row=selectedRisk();clean(parent);
    if(row)riskDetail(parent,row);
    else empty(parent,state().selectedRiskKey?'所选 TSK 不在当前筛选或当前外插策略的已保存结果中；请选择当前显示的结果。':'点击风险曲线上的点、条形、热力图格子或明细表中的 TSK，在这里查看相关 Chain。');
}
function showChain(row){
    const s=state(),key=String(row.chain_id),changed=s.selectedChainId!==key||s.selectedTopologyIndex!=null;
    s.selectedChainId=key;s.selectedTopologyIndex=null;
    refreshChainDetail();fitDetailHeight();if(changed)$('fit-sidebar').scrollTop=0;
    setDrawer('fit',true,true);
}
function refreshChainDetail(){
    const parent=$('chain-detail');if(!parent)return;clean(parent);
    const s=state(),chain=selectedChain();
    const instance=s.fitView==='topology'?(report.topology||[])[s.selectedTopologyIndex]:null;
    if(chain){
        if(s.fitView==='fit'&&s.chainTableMatches&&!s.chainTableMatches.has(String(chain.chain_id)))notice(parent,'所选 Chain 不在当前表格搜索结果中；以下仍为本组已选 Chain 的信息。');
        chainDetail(parent,chain);
    }else if(!instance){
        empty(parent,'点击散点或 Chain 明细行，在这里查看链上 TSK；也可选择模板实例查看其所属 Chain。');
    }
    if(instance){
        parent.append(el('h3','所选模板实例 '+text(instance.tsk_instance_id??instance.instance_id)));
        kv(parent,{'TSK ID':instance.tsk_id,'Chain ID':instance.chain_id,'实际条件':memberConditions(instance)});
        if(!chain)notice(parent,'当前结果组没有保存该 Chain 的拟合结果；下方为全局模板实例。');
        if(instance.chain_key?.length)kv(parent,{'Chain 完整路径':instance.chain_key.join(' / ')});
        if(instance.x!=null||instance.y!=null)parent.append(el('p','坐标：X='+text(instance.x)+' · Y='+text(instance.y),'tsk-coordinates'));
    }
}
narrowDetails.addEventListener('change',()=>{syncDetailVisibility();focusOpenDrawer();});
let detailResizePending=false;
function queueDetailResize(){
    if(detailResizePending)return;detailResizePending=true;
    requestAnimationFrame(()=>{detailResizePending=false;resizeScatter?.();fitDetailHeight();});
}
window.addEventListener('resize',queueDetailResize);
window.addEventListener('scroll',queueDetailResize,{passive:true});
window.addEventListener('beforeprint',()=>resizeScatter?.());
window.addEventListener('afterprint',()=>resizeScatter?.());
document.addEventListener('keydown',event=>{
    const aside=document.querySelector('.detail-sidebar.drawer-open');if(!aside||!narrowDetails.matches)return;
    if(event.key==='Escape'){event.preventDefault();setDrawer(aside.dataset.kind,false,true);return;}
    if(event.key!=='Tab')return;
    const controls=[...aside.querySelectorAll('button,input,select,summary,[tabindex="0"]')].filter(node=>!node.disabled&&node.getClientRects().length);
    const first=controls[0],last=controls[controls.length-1];
    if(!aside.contains(document.activeElement)){event.preventDefault();(event.shiftKey?last:first)?.focus();}
    else if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus();}
    else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}
});

function riskTooltip(r){const rel=relation(r);return [rowLabel(r),'单实例概率：'+riskText(r),interval(r,riskSource().view),'状态：'+status(r.status),'支持：'+(r.status==='no_data'?'无有效数据，不外推':status(r.support_status)),r.interval_error?'区间原因：'+r.interval_error:'',boundary(r)?'零边界不表示保证零失效。':'',rel.rows.length?'相关整条 Chain 的观察 / 预测失效率：\n'+rel.rows.map(c=>c.chain_id+'：'+((c.n_tested>0?pct(c.observed_probability):'无有效测试')+' / '+pct(c.predicted_probability))).join('\n'):rel.reason].filter(Boolean).join('\n');}
function renderRisk(parent){parent=detailLayout(parent,'risk');const s=state(),source=riskSource(),defs=source.defs;parent.append(el('h2','风险结果'));const condition=el('p',Object.keys(defs).length?'每项为 TSK 与类别组合的单实例条件风险；XY 及其他数值特征固定在本组训练均值。':'本组未使用类别特征；显示各 TSK 在模型参考条件下的单实例风险。','muted');parent.append(condition);const settings=el('div',null,'row extrapolation-setting'),policy=el('label',null,'check-row'),check=el('input'),hasCategories=Object.keys(defs).length>0,cached=fullViews(groups[groupIndex]),hasResults=!!(cached.yes?.rows?.length||cached.no?.rows?.length);check.type='checkbox';check.id='no-extrapolation-toggle';check.checked=s.noExtrap;check.disabled=!hasCategories||!hasResults;check.setAttribute('aria-describedby','no-extrapolation-explanation');check.addEventListener('change',()=>{s.noExtrap=check.checked;s.riskPage=s.heatPage=1;renderMain();});policy.append(check,document.createTextNode('关闭外插（无数据组合留空）'));const explanation=el('span',!hasCategories?'本组未使用类别特征，无需外插类别组合；此开关不适用。':!hasResults?'本组尚未保存完整类别组合；请在应用中计算后重新导出。':'仅切换已保存的结果；未计算的策略不会在此补算。','caption');explanation.id='no-extrapolation-explanation';settings.append(policy,explanation);parent.append(settings);const numericReference=source.view?.numeric_reference||groups[groupIndex].prediction_context?.numeric_reference||{};if(Object.keys(numericReference).length)detailStats(parent,'数值参考条件',numericReference);const filters=el('div',null,'filters');picker(filters,'tsk_id','TSK ID',ordered((groups[groupIndex].prediction_context?.all_type_ids||groups[groupIndex].types?.map(r=>r.tsk_id)||[])));Object.entries(defs).forEach(([name,d])=>picker(filters,'category:'+name,name,ordered(d.levels||[])));parent.append(filters);const order=el('div',null,'row no-print'),sort=el('select');[['tsk_id','TSK ID'],['probability','风险概率'],...Object.keys(defs).map(k=>['category:'+k,k])].forEach(([value,label])=>{const o=el('option',label);o.value=value;sort.append(o);});sort.value=s.sort;sort.setAttribute('aria-label','风险排序字段');sort.addEventListener('change',()=>{s.sort=sort.value;s.desc=s.sort==='probability';s.tableSort=null;s.riskPage=1;renderMain();});const direction=el('select');[['asc','升序'],['desc','降序']].forEach(([v,l])=>{const o=el('option',l);o.value=v;direction.append(o);});direction.value=s.desc?'desc':'asc';direction.setAttribute('aria-label','排序方向');direction.addEventListener('change',()=>{s.desc=direction.value==='desc';s.tableSort=null;s.riskPage=1;renderRiskBody();});order.append(el('span','排序'),sort,direction,button('清除筛选',()=>{for(const [k,d] of Object.entries(s.filters)){const values=k==='tsk_id'?(groups[groupIndex].prediction_context?.all_type_ids||groups[groupIndex].types?.map(r=>r.tsk_id)||[]):defs[k.slice(9)].levels||[];s.filters[k]=new Set(values.map(String));}s.riskPage=s.heatPage=1;renderMain();}));parent.append(order);subTabs(parent,[['curve','风险曲线'],['bar','条形图'],['heatmap','热力图'],['table','明细表']],s.riskView,v=>{s.riskView=v;renderMain();});const body=el('div');body.id='risk-body';parent.append(body);renderRiskBody();}
function renderRiskBody(){
    const parent=$('risk-body');if(!parent)return;clean(parent);updateRiskCurve=null;
    const s=state(),source=riskSource(),rows=filteredRisk();refreshRiskDetail();
    if(Object.keys(source.defs).length&&!source.view){
        notice(parent,'当前节点／批次尚未保存'+(s.noExtrap?'不外推':'允许外推')+'策略的完整类别组合。报告不会用局部切片替代完整结果；请在应用中计算完整组合后重新导出。');if(s.riskView==='curve')renderRiskCurve(parent,[],showRisk);return;
    }
    parent.append(el('p','当前筛选 '+number(rows.length)+' / '+number(source.rows.length)+' 项','caption'));
    if(s.riskView==='curve'){renderRiskCurve(parent,rows,showRisk);fitDetailHeight();return;}
    if(!rows.length){empty(parent,source.rows.length?'当前筛选没有匹配结果。可清除筛选后查看全部记录。':'本组没有风险结果。');return;}
    if(s.riskView==='heatmap')renderHeatmap(parent,rows,showRisk);
    else if(s.riskView==='table')renderRiskTable(parent,rows,showRisk);
    else renderBars(parent,rows,showRisk);
    fitDetailHeight();
}
// Coordinates are a display transform of saved probabilities, never a refit.
function riskCurveAvailable(row){return available(row)&&!['not_identifiable','unidentifiable','unavailable','outside_model_domain','computation_limited'].includes(row.status);}
function riskLogOdds(p){return p===0?-Infinity:p===1?Infinity:Math.log(p)-Math.log1p(-p);}
function riskEtaText(eta){return eta===-Infinity?'−∞':eta===Infinity?'+∞':number(eta);}
function riskCurveInterval(row){
    const low=row.interval_sidedness==='upper'?0:row.ci_lower,high=row.ci_upper;
    return probability(low)&&probability(high)&&low<=row.probability&&row.probability<=high?[low,high]:null;
}
function riskCurveDomain(rows,horizontal){
    const values=[];
    rows.forEach(row=>{values.push(riskLogOdds(row.probability));if(horizontal){const ci=riskCurveInterval(row);if(ci)ci.forEach(p=>values.push(riskLogOdds(p)));}});
    const finiteValues=values.filter(finite);let lo=-6,hi=6;
    finiteValues.forEach(eta=>{lo=Math.min(lo,eta-1);hi=Math.max(hi,eta+1);});
    return {xmin:lo,xmax:hi,ymin:0,ymax:1};
}
function riskCurveZoomDomain(domain,factor,fx=.5,fy=.5,axis='both'){
    const cx=domain.xmin+(domain.xmax-domain.xmin)*fx,cy=domain.ymin+(domain.ymax-domain.ymin)*fy;
    const minWidth=Math.max(1e-12,Number.EPSILON*Math.max(1,Math.abs(cx))*8),minHeight=Math.max(1e-300,Number.EPSILON*Math.max(cy,1e-300)*8);
    const w=Math.max(minWidth,Math.min(2000,(domain.xmax-domain.xmin)*factor)),h=Math.max(minHeight,Math.min(1,(domain.ymax-domain.ymin)*factor)),ymin=Math.max(0,Math.min(1-h,cy-h*fy));
    return {xmin:axis==='probability'?domain.xmin:cx-w*fx,xmax:axis==='probability'?domain.xmax:cx+w*(1-fx),ymin:axis==='eta'?domain.ymin:ymin,ymax:axis==='eta'?domain.ymax:ymin+h};
}
function renderRiskCurveFormulas(parent){
    const group=groups[groupIndex]||{},spatial=group.feature_summary?.spatial_transform||group.diagnostics?.spatial_transform||group.prediction_context?.spatial_transform;
    const hasSpatial=!!spatial?.terms?.length;
    const formulas=el('div',null,'risk-formulas');
    // Static MathML keeps real fractions, subscripts and superscripts offline.
    formulas.innerHTML='<div><math xmlns="http://www.w3.org/1998/Math/MathML" aria-label="p j equals sigmoid eta j equals one divided by one plus e to minus eta j"><mrow><msub><mi>p</mi><mi>j</mi></msub><mo>=</mo><mi>σ</mi><mo>(</mo><msub><mi>η</mi><mi>j</mi></msub><mo>)</mo><mo>=</mo><mfrac><mn>1</mn><mrow><mn>1</mn><mo>+</mo><msup><mi>e</mi><mrow><mo>−</mo><msub><mi>η</mi><mi>j</mi></msub></mrow></msup></mrow></mfrac></mrow></math></div>'+
        '<div><math xmlns="http://www.w3.org/1998/Math/MathML" aria-label="eta j equals natural log of p j divided by one minus p j equals log odds j"><mrow><msub><mi>η</mi><mi>j</mi></msub><mo>=</mo><mi mathvariant="normal">ln</mi><mo>(</mo><mfrac><msub><mi>p</mi><mi>j</mi></msub><mrow><mn>1</mn><mo>−</mo><msub><mi>p</mi><mi>j</mi></msub></mrow></mfrac><mo>)</mo><mo>=</mo><mi mathvariant="normal">log</mi><mspace width="0.2em"/><msub><mi mathvariant="normal">odds</mi><mi>j</mi></msub></mrow></math></div>'+
        '<div><math xmlns="http://www.w3.org/1998/Math/MathML" aria-label="odds j equals p j divided by one minus p j equals e to eta j"><mrow><msub><mi mathvariant="normal">odds</mi><mi>j</mi></msub><mo>=</mo><mfrac><msub><mi>p</mi><mi>j</mi></msub><mrow><mn>1</mn><mo>−</mo><msub><mi>p</mi><mi>j</mi></msub></mrow></mfrac><mo>=</mo><msup><mi>e</mi><msub><mi>η</mi><mi>j</mi></msub></msup></mrow></math></div>';
    parent.append(formulas,el('p','横轴 η 是 log odds（对数优势）；纵轴为单实例失效概率 pⱼ，表示该 TSK 与条件组合的单实例风险。oddsⱼ 为失效概率与不失效概率之比。η = 0 对应 pⱼ = 50%；η 越大，风险越高。','caption'));
    const details=el('details',null,'detail-more risk-formula-notes');details.append(el('summary','公式与参考条件说明'));
    const model=el('div',null,'formula-scroll');
    model.innerHTML='<math xmlns="http://www.w3.org/1998/Math/MathML" display="block" aria-label="Logistic predictor: type baseline, selected spatial surface, numeric and category effects"><mrow><msub><mi>η</mi><mi>j</mi></msub><mo>=</mo><msub><mi>α</mi><mrow><mi>t</mi><mo>(</mo><mi>j</mi><mo>)</mo></mrow></msub>'+
        (hasSpatial?'<mo>+</mo><mi>F</mi><mo>(</mo><msub><mi>X</mi><mi>j</mi></msub><mo>,</mo><msub><mi>Y</mi><mi>j</mi></msub><mo>)</mo>':'')+
        '<mo>+</mo><munder><mo>∑</mo><mi>k</mi></munder><msub><mi>β</mi><mi>k</mi></msub><msub><mi>z</mi><mrow><mi>j</mi><mi>k</mi></mrow></msub><mo>+</mo><munder><mo>∑</mo><mrow><mi>f</mi><mo>,</mo><mi>ℓ</mi><mo>≠</mo><msub><mi>r</mi><mi>f</mi></msub></mrow></munder><msub><mi>γ</mi><mrow><mi>f</mi><mi>ℓ</mi></mrow></msub><mi mathvariant="normal">I</mi><mo>(</mo><msub><mi>c</mi><mrow><mi>j</mi><mi>f</mi></mrow></msub><mo>=</mo><mi>ℓ</mi><mo>)</mo></mrow></math>'+
        '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block" aria-label="z j k equals x j k minus training mean k divided by training scale k"><mrow><msub><mi>z</mi><mrow><mi>j</mi><mi>k</mi></mrow></msub><mo>=</mo><mfrac><mrow><msub><mi>x</mi><mrow><mi>j</mi><mi>k</mi></mrow></msub><mo>−</mo><msub><mi>μ</mi><mi>k</mi></msub></mrow><msub><mi>s</mi><mi>k</mi></msub></mfrac></mrow></math>';
    details.append(el('p',hasSpatial?'Logistic 对数优势由 TSK 基线、空间曲面 F(X,Y)、其他数值特征和类别效应相加：':'Logistic 特征模型的对数优势由 TSK 基线、数值特征和类别效应相加：'),model,
        el('p','j 表示当前 TSK 条件组合；t(j) 为 TSK 类型，α 为其基线，β 为普通数值系数，γ 为类别系数。c 为类别取值，r 为参考水平，I 在条件成立时取 1，否则取 0；μ 与 s 为训练均值及尺度。'+(hasSpatial?'XY 固定在原始坐标的训练均值，F 在该参考位置为 0；其他数值特征在均值处 z = 0，参考类别效应为 0。F 基于物理原点 (0,0) 的 X²、Y²、X⁴、X²Y²、Y⁴ 构造，允许非线性升高或外围回落；数值中心化不移动物理原点。没有统一的“X 或 Y 增加一个 scale”的 OR，也不强制原点最低或单一峰值。':'XY 和其他数值特征固定在训练均值，因此本页 z = 0；参考类别的效应为 0。'),'caption'),
        el('p','仅 TSK ID 模型也可将保存的概率映射至这条曲线；上面的 Logistic 系数分解仅适用于 Logistic 特征模型。','caption'),
        el('p','η 由保存的概率反算；p = 0 或 1 映射到 −∞ 或 +∞，仅表示概率映射端点，不代表原始拟合系数为无穷。端点单列在坐标轴两侧。无数据、不可识别及不可用结果不绘制。零边界估计不代表保证零风险。','caption'),
        el('p','横向与纵向误差条来自同一份已保存置信区间，分别显示 log odds 区间与概率区间，可独立开关；缺失或无效区间保留点估计。单侧上限从 p = 0 开始，横向无穷界以箭头指向端点区。','caption'));
    parent.append(details);
}
function renderRiskCurve(parent,rows,select){
    renderRiskCurveFormulas(parent);
    const s=state(),plotted=rows.filter(riskCurveAvailable);
    if(s.curveRows!==rows){s.curveViewport=null;s.curveRows=rows;}
    if(!plotted.length){empty(parent,rows.length?'当前筛选没有可绘制的风险概率；无数据及不可识别结果不会显示为零。':'当前筛选没有风险结果。');return;}
    parent.append(el('p','曲线显示 '+number(plotted.length)+' / '+number(rows.length)+' 个组合。点击点查看同一风险侧栏；重合点可重复点击轮换，或在下方选择具体组合。','caption'));
    const controls=el('div',null,'row risk-curve-controls no-print'),chooser=el('select');chooser.id='risk-curve-combination';chooser.setAttribute('aria-label','选择曲线上的 TSK 组合');
    const placeholder=el('option','选择 TSK 与条件组合');placeholder.value='';chooser.append(placeholder);
    // Order the locator by risk while retaining each plotted row's selection value.
    plotted.map((row,index)=>({row,index})).sort((a,b)=>b.row.probability-a.row.probability||a.index-b.index).forEach(({row,index})=>{const option=el('option',rowLabel(row)+' · '+pct(row.probability)+' · η = '+riskEtaText(riskLogOdds(row.probability)));option.value=String(index);chooser.append(option);});
    chooser.addEventListener('change',()=>{if(chooser.value!=='')select(plotted[Number(chooser.value)]);});controls.append(el('label','定位组合'),chooser);parent.append(controls);
    const settings=el('div',null,'row no-print');
    [['curveHorizontal','横向误差条（η）','risk-curve-horizontal'],['curveVertical','纵向误差条（pⱼ）','risk-curve-vertical']].forEach(([key,label,id])=>{const wrap=el('label',null,'check-row'),check=el('input');check.id=id;check.type='checkbox';check.checked=s[key];check.addEventListener('change',()=>{s[key]=check.checked;s.curveViewport=null;renderRiskBody();});wrap.append(check,document.createTextNode(label));settings.append(wrap);});parent.append(settings);
    const selection=el('p',null,'risk-curve-selection');selection.id='risk-curve-selection';selection.setAttribute('aria-live','polite');parent.append(selection);
    const zoomControls=el('div',null,'row no-print'),zoomAxis=el('select');zoomAxis.id='risk-curve-zoom-axis';zoomAxis.setAttribute('aria-label','曲线缩放轴');
    [['both','双轴缩放'],['eta','仅 η 轴'],['probability','仅概率轴']].forEach(([value,title])=>{const option=el('option',title);option.value=value;zoomAxis.append(option);});zoomAxis.value=s.curveZoomAxis||'both';zoomAxis.addEventListener('change',()=>{s.curveZoomAxis=zoomAxis.value;});zoomControls.append(zoomAxis);parent.append(zoomControls);
    const scroll=el('div',null,'chart-scroll'),chart=svg('svg',{viewBox:'0 0 820 470',class:'plot risk-curve-plot',role:'group','aria-label':'风险 sigmoid 曲线，横轴 log odds η，纵轴单实例失效概率 p j'});chart.id='risk-curve-plot';chart.style.touchAction='none';scroll.append(chart);parent.append(scroll);
    const viewportCaption=el('p',null,'caption');parent.append(viewportCaption);
    const W=820,H=470,L=90,R=736,T=28,B=392,base=riskCurveDomain(plotted,s.curveHorizontal),leftEndpoint=35,rightEndpoint=791;
    let current=base,x,y,guides,pointNodes=[];
    const clusters=new Map();plotted.forEach(row=>{const key=row.probability;let cluster=clusters.get(key);if(!cluster){cluster=[];clusters.set(key,cluster);}cluster.push(row);});
    const label=(content,xx,yy,attrs={})=>{const node=svg('text',{x:xx,y:yy,'font-size':12,fill:'#657184','text-anchor':'middle',...attrs});node.textContent=content;return node;};
    function visible(row){const p=row.probability,eta=riskLogOdds(p);return p>=current.ymin&&p<=current.ymax&&(!finite(eta)||eta>=current.xmin&&eta<=current.xmax);}
    function draw(){
        clean(chart);pointNodes=[];current=s.curveViewport||base;x=eta=>eta===-Infinity?leftEndpoint:eta===Infinity?rightEndpoint:L+(eta-current.xmin)/(current.xmax-current.xmin)*(R-L);y=p=>B-(p-current.ymin)/(current.ymax-current.ymin)*(B-T);
        const defs=svg('defs'),clip=svg('clipPath',{id:'risk-curve-clip'});clip.append(svg('rect',{x:20,y:T-8,width:780,height:B-T+16}));defs.append(clip);const finiteClip=svg('clipPath',{id:'risk-curve-finite-clip'});finiteClip.append(svg('rect',{x:L,y:T,width:R-L,height:B-T}));defs.append(finiteClip);chart.append(defs);
        chart.append(svg('rect',{x:20,y:T-8,width:43,height:B-T+16,fill:'#f3f6fa'}),svg('rect',{x:764,y:T-8,width:43,height:B-T+16,fill:'#f3f6fa'}));
        for(let i=0;i<=4;i++){const p=current.ymin+(current.ymax-current.ymin)*i/4;chart.append(svg('line',{x1:L,x2:R,y1:y(p),y2:y(p),stroke:'#e4e9f1'}),label(p!==0&&p<.000001?pct(p):(p*100).toLocaleString('en-US',{maximumFractionDigits:Math.min(14,Math.max(5,Math.ceil(-Math.log10((current.ymax-current.ymin)*100))+1))})+'%',L-10,y(p)+4,{'text-anchor':'end','font-size':11}));}
        for(let i=0;i<=6;i++){const eta=current.xmin+(current.xmax-current.xmin)*i/6;chart.append(svg('line',{x1:x(eta),x2:x(eta),y1:T,y2:B,stroke:'#edf0f5'}),label(number(Number(eta.toPrecision(4))),x(eta),B+21,{'font-size':11}));}
        chart.append(svg('line',{x1:L,x2:R,y1:B,y2:B,stroke:'#718197'}),svg('line',{x1:L,x2:L,y1:T,y2:B,stroke:'#718197'}),label('−∞',leftEndpoint,B+21),label('+∞',rightEndpoint,B+21),label('映射端点',leftEndpoint,B+38,{'font-size':10}),label('映射端点',rightEndpoint,B+38,{'font-size':10}),label('log odds η（对数优势）',(L+R)/2,H-14),label('单实例失效概率 pⱼ',L,T-13,{'text-anchor':'start'}));
        const curve=svg('g',{'clip-path':'url(#risk-curve-finite-clip)'}),samples=[];
        for(let i=0;i<=300;i++)samples.push(current.xmin+(current.xmax-current.xmin)*i/300);
        for(let eta=-12;eta<=12;eta+=.1)if(eta>current.xmin&&eta<current.xmax)samples.push(eta);
        samples.sort((a,b)=>a-b);const path=samples.map((eta,index)=>{const ex=Math.exp(-Math.abs(eta)),p=eta>=0?1/(1+ex):ex/(1+ex);return (index?'L':'M')+x(eta)+','+y(p);}).join(' ');
        curve.append(svg('path',{d:path,fill:'none',stroke:'#4778be','stroke-width':2.5}));chart.append(curve);
        const errorLayer=svg('g',{'clip-path':'url(#risk-curve-clip)','pointer-events':'none'});
        function cappedLine(x1,y1,x2,y2,horizontal,lowInfinite,highInfinite){const group=svg('g',{class:horizontal?'risk-interval-horizontal':'risk-interval-vertical','stroke-width':1.5});group.append(svg('line',{x1,y1,x2,y2}));[[x1,y1,lowInfinite,-1],[x2,y2,highInfinite,1]].forEach(([xx,yy,infinite,direction])=>{group.append(infinite&&horizontal?svg('path',{d:'M'+(xx-direction*5)+','+(yy-4)+' L'+xx+','+yy+' L'+(xx-direction*5)+','+(yy+4),fill:'none'}):svg('line',horizontal?{x1:xx,x2:xx,y1:yy-4,y2:yy+4}:{x1:xx-4,x2:xx+4,y1:yy,y2:yy}));});errorLayer.append(group);}
        plotted.forEach(row=>{const ci=riskCurveInterval(row);if(!ci||!visible(row))return;const eta=riskLogOdds(row.probability),xx=x(eta),yy=y(row.probability);if(s.curveHorizontal){const low=riskLogOdds(ci[0]),high=riskLogOdds(ci[1]);cappedLine(finite(low)?Math.max(L,Math.min(R,x(low))):x(low),yy,finite(high)?Math.max(L,Math.min(R,x(high))):x(high),yy,true,!finite(low),!finite(high));}if(s.curveVertical)cappedLine(xx,Math.max(T,y(ci[1])),xx,Math.min(B,y(ci[0])),false,false,false);});chart.append(errorLayer);
        guides=svg('g',{'pointer-events':'none'});chart.append(guides);
        const marks=svg('g',{'clip-path':'url(#risk-curve-clip)'});
        clusters.forEach(cluster=>{const row=cluster[0];if(!visible(row))return;const eta=riskLogOdds(row.probability),point=svg('g',{class:'risk-curve-point',role:'button',tabindex:0,'aria-label':rowLabel(row)+'，p = '+pct(row.probability)+'，η = '+riskEtaText(eta)+(cluster.length>1?'，'+cluster.length+' 个重合组合，重复点击轮换':''),'data-count':cluster.length,'data-probability':row.probability});point.append(svg('circle',{class:'risk-curve-hit-target',cx:x(eta),cy:y(row.probability),r:9,fill:'transparent','pointer-events':'all'}),svg('circle',{class:'risk-curve-marker',cx:x(eta),cy:y(row.probability),r:cluster.length>1?4.5:3.5,fill:finite(eta)?'#e0782c':'white',stroke:'#d47832','stroke-width':1.5}));const title=svg('title');title.textContent=cluster.map(item=>rowLabel(item)).join('\n')+'\np = '+pct(row.probability)+'；η = '+riskEtaText(eta);point.append(title);if(cluster.length>1)point.append(label(String(cluster.length),x(eta)+10,y(row.probability)-10,{'text-anchor':'start','font-size':11,fill:'#315181'}));const choose=()=>{const active=cluster.findIndex(item=>riskKey(item)===s.selectedRiskKey);select(cluster[(active+1)%cluster.length]);};point.addEventListener('click',event=>{event.stopPropagation();if(!s.curveSuppressClick)choose();});point.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();choose();}});pointNodes.push({point,cluster});marks.append(point);});chart.append(marks);
        viewportCaption.textContent='滚轮或按钮缩放，拖动画布平移；重置可查看全部。当前可见 '+number(plotted.filter(visible).length)+' / '+number(plotted.length)+' 个组合；缩放范围外的点与区间将被裁切。';
    }
    function updateSelection(reveal=false){
        const row=plotted.find(item=>riskKey(item)===s.selectedRiskKey);if(reveal&&row&&!visible(row)){s.curveViewport=null;draw();}
        chooser.value=row?String(plotted.indexOf(row)):'';pointNodes.forEach(({point,cluster})=>{const selected=cluster.some(item=>riskKey(item)===s.selectedRiskKey);point.classList.toggle('selected',selected);const count=point.querySelector('text');if(count)count.setAttribute('visibility',selected?'hidden':'visible');});clean(guides);
        if(!row){selection.textContent='选择一个组合，即可查看 pⱼ、log odds η，以及对应的坐标引导线。';return;}
        const eta=riskLogOdds(row.probability);selection.textContent=rowLabel(row)+'　pⱼ = '+pct(row.probability)+'　η = '+riskEtaText(eta)+(boundary(row)?'（零边界估计）':'');
        if(!visible(row))return;const xx=x(eta),yy=y(row.probability);guides.append(svg('line',{x1:L,x2:xx,y1:yy,y2:yy,stroke:'#d47832','stroke-dasharray':'5 4'}),svg('line',{x1:xx,x2:xx,y1:yy,y2:B,stroke:'#d47832','stroke-dasharray':'5 4'}),svg('circle',{cx:xx,cy:yy,r:11,fill:'none',stroke:'#d47832','stroke-width':1.5}),label('p = '+pct(row.probability),Math.min(R-10,Math.max(L+10,xx+12)),Math.max(T+14,yy-16),{'text-anchor':xx>(L+R)/2?'end':'start',fill:'#9c4f19',stroke:'white','stroke-width':4,'paint-order':'stroke'}),label('η = '+riskEtaText(eta),Math.max(L+45,Math.min(R-45,xx)),B+42,{fill:'#9c4f19'}));
    }
    function zoom(factor,fx=.5,fy=.5){s.curveViewport=riskCurveZoomDomain(s.curveViewport||base,factor,fx,fy,s.curveZoomAxis||'both');draw();updateSelection();}
    function focusRisks(){
        const points=plotted.filter(row=>row.probability>0&&row.probability<1);if(!points.length){s.curveViewport=null;draw();updateSelection();return;}
        let lowEta=Infinity,highEta=-Infinity,lowP=1,highP=0;points.forEach(row=>{const eta=riskLogOdds(row.probability);lowEta=Math.min(lowEta,eta);highEta=Math.max(highEta,eta);lowP=Math.min(lowP,row.probability);highP=Math.max(highP,row.probability);});
        const mx=Math.max(.4,(highEta-lowEta)*.12),my=Math.max(1e-300,(highP-lowP)*.12,Math.min(highP,1-lowP)*.12,Number.EPSILON*highP*8);
        s.curveViewport={xmin:lowEta-mx,xmax:highEta+mx,ymin:Math.max(0,lowP-my),ymax:Math.min(1,highP+my)};draw();updateSelection();
    }
    function zoomAtSelection(factor){const row=plotted.find(item=>riskKey(item)===s.selectedRiskKey&&visible(item))||plotted.find(visible);if(!row){zoom(factor);return;}const eta=riskLogOdds(row.probability);zoom(factor,finite(eta)?(eta-current.xmin)/(current.xmax-current.xmin):.5,(row.probability-current.ymin)/(current.ymax-current.ymin));}
    zoomControls.append(button('放大 +',()=>zoomAtSelection(.65),'small'),button('缩小 −',()=>zoomAtSelection(1/.65),'small'),button('聚焦风险点',focusRisks,'small'),button('重置视图',()=>{s.curveViewport=null;draw();updateSelection();},'small'));
    const local=event=>{const point=chart.createSVGPoint();point.x=event.clientX;point.y=event.clientY;return point.matrixTransform(chart.getScreenCTM().inverse());};
    chart.addEventListener('wheel',event=>{const p=local(event);if(p.x<L||p.x>R||p.y<T||p.y>B)return;event.preventDefault();zoom(event.deltaY<0?.8:1.25,(p.x-L)/(R-L),(B-p.y)/(B-T));},{passive:false});
    let drag=null;
    chart.addEventListener('pointerdown',event=>{if(event.button!==0||event.target.closest('.risk-curve-point'))return;const p=local(event);if(p.x<L||p.x>R||p.y<T||p.y>B)return;drag={point:p,domain:{...(s.curveViewport||base)}};s.curveSuppressClick=false;chart.setPointerCapture(event.pointerId);});
    chart.addEventListener('pointermove',event=>{if(!drag)return;const p=local(event),d=drag.domain,dx=(p.x-drag.point.x)/(R-L)*(d.xmax-d.xmin),dy=(p.y-drag.point.y)/(B-T)*(d.ymax-d.ymin),height=d.ymax-d.ymin,ymin=Math.max(0,Math.min(1-height,d.ymin+dy));s.curveSuppressClick=true;s.curveViewport={xmin:d.xmin-dx,xmax:d.xmax-dx,ymin,ymax:ymin+height};draw();updateSelection();});
    const endDrag=()=>{drag=null;s.curveSuppressClick=false;};chart.addEventListener('pointerup',endDrag);chart.addEventListener('pointercancel',endDrag);
    draw();updateRiskCurve=updateSelection;updateSelection();
}

function riskColumns(){return [{key:'tsk_id',title:'TSK ID'},{key:'level',title:'类别组合',wide:true,format:conditions},{key:'probability',title:'单实例概率',numeric:true,format:riskText},{key:'ci_lower',title:'区间下界',numeric:true,format:r=>available(r)&&r.interval_sidedness!=='upper'?pct(r.ci_lower):'—'},{key:'ci_upper',title:'区间上界 / 单侧上限',numeric:true,format:r=>available(r)?pct(r.ci_upper):'—'},{key:'status',title:'拟合状态',format:r=>status(r.status)},{key:'support_status',title:'支持状态',format:r=>r.status==='no_data'?'无有效数据（不外推）':status(r.support_status)},{key:'layout_instance_count',title:'模板实例',numeric:true,format:r=>number(r.layout_instance_count??r.instance_count)},{key:'active_instance_count',title:'有效实例',numeric:true},{key:'chain_count',title:'有效 Chain',numeric:true},{key:'chain_test_exposure',title:'链测试暴露',numeric:true},{key:'interval_method',title:'区间方法',wide:true},{key:'interval_error',title:'区间不可用原因',wide:true}];}
function renderRiskTable(parent,rows,select){const s=state();if(s.tableSort)rows=sortRows(rows,s.tableSort.key,s.tableSort.desc);const p=el('div');parent.append(p);const [from,to]=pager(p,rows.length,50,s.riskPage,v=>{s.riskPage=v;renderRiskBody();});makeTable(parent,rows.slice(from,to),riskColumns(),{onSelect:select,selected:s.selectedRisk,onSort:key=>{s.tableSort={key,desc:s.tableSort?.key===key?!s.tableSort.desc:false};s.riskPage=1;renderRiskBody();}});}
function renderBars(parent,rows,select){const s=state(),p=el('div');parent.append(p);const [from,to]=pager(p,rows.length,25,s.riskPage,v=>{s.riskPage=v;renderRiskBody();});let maximum=rows.reduce((m,r)=>available(r)?Math.max(m,r.probability,probability(r.ci_upper)?r.ci_upper:0):m,0);maximum=maximum>0?Math.min(1,maximum*1.05):.01;parent.append(el('p','条形：单实例概率；线段：已计算置信区间。零边界从 0 延伸至已有上限；区间不可用时保留点估计。横轴按当前筛选结果缩放。','caption'));const list=el('div',null,'chart-scroll');rows.slice(from,to).forEach(r=>{const wrap=el('div');wrap.className='risk-bar'+(s.selectedRiskKey===riskKey(r)?' selected':'');wrap.dataset.riskKey=riskKey(r);wrap.setAttribute('role','button');wrap.tabIndex=0;wrap.title=riskTooltip(r);wrap.addEventListener('click',()=>select(r));wrap.addEventListener('keydown',e=>{if(e.key==='Enter')select(r);});wrap.append(el('div',rowLabel(r)));const chart=svg('svg',{viewBox:'0 0 510 48',width:'100%',height:48,role:'img','aria-label':riskTooltip(r)}),x=v=>8+480*v/maximum;for(let i=0;i<=4;i++)chart.append(svg('line',{x1:x(maximum*i/4),x2:x(maximum*i/4),y1:2,y2:31,stroke:'#e1e6ef'}));if(available(r)){chart.append(svg('rect',{x:8,y:10,width:Math.max(0,x(r.probability)-8),height:14,fill:boundary(r)?'#496480':'#4b73cf',rx:2}));if(probability(r.ci_upper)&&(probability(r.ci_lower)||r.interval_sidedness==='upper')){const low=r.interval_sidedness==='upper'?0:r.ci_lower;chart.append(svg('line',{x1:x(low),x2:x(r.ci_upper),y1:17,y2:17,stroke:'#142238','stroke-width':2}));[low,r.ci_upper].forEach(v=>chart.append(svg('line',{x1:x(v),x2:x(v),y1:12,y2:22,stroke:'#142238','stroke-width':2})));}chart.append(svg('circle',{cx:x(r.probability),cy:17,r:3,fill:'#142238'}));}else{const label=svg('text',{x:8,y:21,fill:'#697489','font-size':12});label.textContent=status(r.status);chart.append(label);}for(let i=0;i<=4;i++){const label=svg('text',{x:x(maximum*i/4),y:44,'text-anchor':i===0?'start':i===4?'end':'middle',fill:'#687487','font-size':10});label.textContent=pct(maximum*i/4);chart.append(label);}wrap.append(chart,el('div',riskText(r),'numeric'));list.append(wrap);});parent.append(list);}
function riskDetail(parent,r){
    clean(parent);tskIdentity(parent,r,'h3');
    const summary=el('div',null,'detail-summary');
    summary.append(el('p','单实例概率：'+riskText(r)),el('p',interval(r,riskSource().view),'caption'));
    parent.append(summary);
    if(boundary(r))notice(parent,'零边界是当前模型与数据下的边界估计，不表示保证零失效。请结合上限阅读。');
    const rel=relation(r);parent.append(el('h3','相关 Chain · '+number(rel.rows.length)+' 条'));
    parent.append(el('p','以下为整条链的观察与预测失效率；不是所选 TSK 对本次失效的归因。风险页使用数值训练均值，链成员使用实例实际条件。','caption'));
    if(rel.rows.length)pagedCards(parent,rel.rows,'相关 Chain '+riskKey(r),(card,chain)=>{
        card.append(el('h4','Chain '+text(chain.chain_id)));
        kv(card,{'观察失效率':chain.n_tested>0?pct(chain.observed_probability):'无有效测试','预测失效率':pct(chain.predicted_probability),'有效测试数':chain.n_tested});
        chainMemberDisclosure(card,chain);
        const open=button('查看拟合结果',()=>{
            state().selectedChainId=String(chain.chain_id);state().selectedTopologyIndex=null;state().fitView='fit';
            state().drawerOpen={...(state().drawerOpen||{}),fit:true};mainPage='fit';renderMain();focusOpenDrawer();
        },'small no-print');open.disabled=!(groups[groupIndex].chains||[]).includes(chain);card.append(open);
    });else empty(parent,rel.reason);
    detailStats(parent,'风险统计与区间说明',{
        '单实例概率':riskText(r),'置信区间':interval(r,riskSource().view),'拟合状态':status(r.status),
        '支持状态':r.status==='no_data'?'无有效数据（不外推）':status(r.support_status),
        '模板实例数':r.layout_instance_count??r.instance_count,'有效实例数':r.active_instance_count,
        '有效 Chain 数':r.chain_count,'链测试暴露':r.chain_test_exposure??r.test_exposure,'区间方法':r.interval_method,
        '区间不可用原因':r.interval_error,'说明':r.reason
    });
    parent.append(el('p','链测试暴露不是独立样本量。','caption'));
}
function axisName(key){return key==='tsk_id'?'TSK ID':key.slice(9);}
function axisLabel(dimensions,values){return dimensions.length?dimensions.map((key,index)=>axisName(key)+'='+values[index]).join(' · '):'全部';}
function axisValues(dimensions,values){return dimensions.length?values.map(text).join(' · '):'全部';}
function axisControl(parent,axis){const s=state(),selected=s[axis],all=['tsk_id',...Object.keys(riskSource().defs).map(k=>'category:'+k)],d=el('details',null,'axis'),summary=el('summary',axis.toUpperCase()+' 轴 · '+(selected.map(axisName).join(' → ')||'全部')),body=el('div',null,'axis-body'),list=el('div',null,'axis-list');body.append(el('p','每个维度只归属一个轴；取消勾选会移至另一个轴。上下箭头调整组合顺序。','caption'));function change(next){const other=axis==='x'?'y':'x',remain=s[other].filter(k=>!next.includes(k));for(const k of s[axis])if(!next.includes(k)&&!remain.includes(k))remain.push(k);for(const k of all)if(!next.includes(k)&&!remain.includes(k))remain.push(k);s[axis]=next;s[other]=remain;s.heatPage=1;renderRiskBody();}for(const key of [...selected,...all.filter(k=>!selected.includes(k))]){const row=el('div',null,'axis-line'),label=el('label'),check=el('input');check.type='checkbox';check.checked=selected.includes(key);check.addEventListener('change',()=>change(check.checked?[...selected,key]:selected.filter(k=>k!==key)));label.append(check,document.createTextNode(' '+axisName(key)));const index=selected.indexOf(key),up=button('↑',()=>{const next=[...selected];[next[index-1],next[index]]=[next[index],next[index-1]];change(next);},'small'),down=button('↓',()=>{const next=[...selected];[next[index+1],next[index]]=[next[index],next[index+1]];change(next);},'small');up.disabled=index<=0;down.disabled=index<0||index>=selected.length-1;up.setAttribute('aria-label','前移 '+axisName(key));down.setAttribute('aria-label','后移 '+axisName(key));row.append(label,up,down);list.append(row);}body.append(list);d.append(summary,body);s.axisOpen=s.axisOpen||{};d.open=!!s.axisOpen[axis];d.addEventListener('toggle',()=>{if(d.isConnected)s.axisOpen[axis]=d.open;});parent.append(d);}
function matrixFor(rows){const s=state(),signature=JSON.stringify([s.x,s.y]);if(s.matrix?.source===rows&&s.matrix.signature===signature)return s.matrix;const records=new Map(),xs=new Map(),ys=new Map();for(const row of rows){const x=s.x.map(k=>field(row,k)),y=s.y.map(k=>field(row,k)),xkey=JSON.stringify(x),ykey=JSON.stringify(y);xs.set(xkey,x);ys.set(ykey,y);records.set(JSON.stringify([y,x]),row);}const order=(a,b)=>{for(let i=0;i<a.length;i++){const c=nat.compare(a[i],b[i]);if(c)return c;if(a[i]!==b[i])return a[i]<b[i]?-1:1;}return 0;};s.matrix={source:rows,signature,records,x:[...xs.values()].sort(order),y:[...ys.values()].sort(order)};return s.matrix;}
const PLASMA=[[13,8,135],[83,2,163],[126,3,168],[168,34,150],[203,70,121],[229,107,93],[248,148,65],[253,202,38],[240,249,33]];
function plasma(value){const v=Math.max(0,Math.min(1,value))*(PLASMA.length-1),i=Math.min(PLASMA.length-2,Math.floor(v)),f=v-i;const rgb=PLASMA[i].map((c,j)=>Math.round(c+(PLASMA[i+1][j]-c)*f));const luminance=rgb.map(c=>c/255).map(c=>c<=.04045?c/12.92:((c+.055)/1.055)**2.4).reduce((n,c,i)=>n+c*[.2126,.7152,.0722][i],0);return {background:'rgb('+rgb.join(',')+')',color:luminance>.179?'#000000':'#ffffff'};}
function renderHeatmap(parent,rows,select){
    const s=state(),axes=el('div',null,'row axis-controls');axisControl(axes,'x');axisControl(axes,'y');parent.append(axes);
    const metric=el('select');
    [['probability','概率热力图'],['support','支持度（有效实例数）']].forEach(([value,label])=>{const option=el('option',label);option.value=value;metric.append(option);});
    if(!Object.keys(riskSource().defs).length)s.metric='probability';
    metric.value=s.metric;metric.disabled=!Object.keys(riskSource().defs).length;metric.setAttribute('aria-label','热力图指标');
    metric.addEventListener('change',()=>{s.metric=metric.value;renderRiskBody();});
    const legend=el('div',null,'legend');legend.append(metric,el('span','低'),el('span',null,'gradient'),el('span','高'));parent.append(legend);
    parent.append(el('p','空白：无数据且不外推；灰格：不可估计；斜纹：外推或无有效支持。点击格子在右侧查看相关 Chain。支持度为布局实例数，不是独立样本量。色阶按当前矩阵页缩放；跨页比较请看概率数值。','caption'));
    const m=matrixFor(rows),size=25,xpages=Math.max(1,Math.ceil(m.x.length/size)),ypages=Math.max(1,Math.ceil(m.y.length/size)),pages=xpages*ypages;
    const paging=el('div');parent.append(paging);pager(paging,pages,1,s.heatPage,value=>{s.heatPage=value;renderRiskBody();},'矩阵页');
    const actual=Math.min(Math.max(1,s.heatPage),pages)-1,yi=Math.floor(actual/xpages)*size,xi=(actual%xpages)*size;
    const x=m.x.slice(xi,xi+size),y=m.y.slice(yi,yi+size);
    parent.append(el('p','矩阵共 '+m.y.length+' 行 × '+m.x.length+' 列；当前 Y '+(yi+1)+'–'+Math.min(yi+size,m.y.length)+'，X '+(xi+1)+'–'+Math.min(xi+size,m.x.length)+'。','caption'));
    const shownRows=y.flatMap(yk=>x.map(xk=>m.records.get(JSON.stringify([yk,xk]))).filter(Boolean));
    const maximum=shownRows.reduce((value,row)=>Math.max(value,s.metric==='support'&&finite(row.active_instance_count)?row.active_instance_count:available(row)&&s.metric==='probability'?row.probability:0),0)||1;
    const wrap=el('div',null,'heatmap-wrap'),table=el('table',null,'heatmap'),head=el('thead'),values=el('tr');
    const rowAxis=el('th',s.y.map(axisName).join(' · '),'heatmap-row-axis');rowAxis.setAttribute('scope','col');
    // Dimension names appear once; ordered value labels still use the original tuple keys.
    if(s.x.length){
        const titles=el('tr'),columnAxis=el('th',null,'heatmap-column-axis');columnAxis.colSpan=x.length;columnAxis.setAttribute('scope','colgroup');
        columnAxis.append(el('span',s.x.map(axisName).join(' · '),'heatmap-axis-names'));rowAxis.rowSpan=2;
        titles.append(rowAxis,columnAxis);head.append(titles);
    }else values.append(rowAxis);
    x.forEach(key=>{const label=el('th',axisValues(s.x,key));label.setAttribute('scope','col');label.title=axisLabel(s.x,key);values.append(label);});
    head.append(values);table.append(head);const body=el('tbody');table.append(body);
    for(const ykey of y){
        const tr=el('tr'),label=el('th',axisValues(s.y,ykey));label.setAttribute('scope','row');label.title=axisLabel(s.y,ykey);tr.append(label);
        for(const xkey of x){
            const td=el('td'),row=m.records.get(JSON.stringify([ykey,xkey]));
            const cell=button('',()=>{if(row)select(row);},'heat-cell');
            if(!row){cell.classList.add('unavailable');cell.disabled=true;cell.textContent='—';}
            else{
                cell.title=riskTooltip(row);cell.setAttribute('aria-label',cell.title);
                const value=s.metric==='support'?row.active_instance_count:row.probability,valid=row.status!=='no_data'&&(s.metric==='support'?finite(value):available(row));
                if(row.status==='no_data')cell.classList.add('missing');
                else if(!valid){cell.classList.add('unavailable');cell.textContent='—';}
                else{
                    const color=plasma(value/maximum);cell.style.backgroundColor=color.background;cell.style.color=color.color;
                    cell.textContent=s.metric==='support'?number(value):boundary(row)?'零边界':pct(value);
                    if(row.support_status&&row.support_status!=='observed')cell.style.backgroundImage='repeating-linear-gradient(135deg,transparent,transparent 5px,rgba(127,127,127,.35) 5px,rgba(127,127,127,.35) 7px)';
                }
            }
            td.append(cell);tr.append(td);
        }
        body.append(tr);
    }
    wrap.append(table);parent.append(wrap);
}
function pagedTable(parent,rows,columns,key,onSelect,{size=50,search=true,getSelected,onRowsChange,revealSelected=false}={}){
    const s=state();s.tables=s.tables||{};
    const local=s.tables[key]||(s.tables[key]={page:1,search:'',sort:null}),section=el('div');parent.append(section);
    let searchInput,table,currentRows=[];
    if(search){
        const controls=el('div',null,'row no-print');searchInput=el('input');searchInput.type='search';
        searchInput.placeholder='搜索当前表格';searchInput.setAttribute('aria-label','搜索 '+key);searchInput.value=local.search;
        controls.append(searchInput);section.append(controls);
    }
    const body=el('div');section.append(body);
    function refreshSelection(){
        const selected=getSelected?.();
        if(table)currentRows.forEach((row,index)=>table.tBodies[0].children[index].classList.toggle('selected',selected===row));
    }
    function matchingRows(){
        const query=local.search.toLocaleLowerCase();
        const shown=query?rows.filter(row=>JSON.stringify(row).toLocaleLowerCase().includes(query)):rows;
        return local.sort?sortRows(shown,local.sort.key,local.sort.desc):shown;
    }
    function revealSelection(){
        const selected=getSelected?.();
        if(!selected){draw();return;}
        let shown=matchingRows(),index=shown.indexOf(selected);
        if(index<0&&rows.includes(selected)){
            local.search='';if(searchInput)searchInput.value='';shown=matchingRows();index=shown.indexOf(selected);
        }
        const page=index<0?local.page:Math.floor(index/size)+1;
        if(table&&page===local.page&&currentRows.includes(selected)){refreshSelection();return;}
        local.page=page;draw();
    }
    function draw(){
        preserveViewport(body,()=>{
            clean(body);table=null;const shown=matchingRows();
            onRowsChange?.(shown);
            const [from,to]=pager(body,shown.length,size,local.page,page=>{local.page=page;draw();});
            if(!shown.length){empty(body,rows.length?'没有匹配记录。':'暂无记录。');return;}
            currentRows=shown.slice(from,to);
            table=makeTable(body,currentRows,columns,{onSelect,selected:getSelected?.(),onSort:field=>{
                local.sort={key:field,desc:local.sort?.key===field?!local.sort.desc:false};local.page=1;draw();
            }});
        });
    }
    if(searchInput)searchInput.addEventListener('input',()=>{local.search=searchInput.value;local.page=1;draw();});
    if(revealSelected)revealSelection();else draw();return {refreshSelection,revealSelection};
}
function chainColumns(){return [{key:'chain_id',title:'Chain ID'},{key:'n_tested',title:'有效样品数',numeric:true},{key:'n_failed',title:'Fail',numeric:true},{key:'n_passed',title:'Pass',numeric:true,format:r=>number(r.n_passed??(finite(r.n_tested)&&finite(r.n_failed)?Math.max(0,r.n_tested-r.n_failed):null))},{key:'n_missing',title:'Missing',numeric:true},{key:'observed_probability',title:'观察概率',numeric:true,format:r=>r.n_tested>0?pct(r.observed_probability):'无有效测试'},{key:'predicted_probability',title:'预测概率',numeric:true,format:r=>pct(r.predicted_probability)},{key:'residual',title:'观察 − 预测',numeric:true,format:r=>pp(r.residual)},{key:'deviance_residual',title:'Deviance residual',numeric:true,format:r=>number(r.deviance_residual)}];}
function renderFit(parent){
    parent=detailLayout(parent,'fit');const s=state(),g=groups[groupIndex];
    parent.append(el('h2','拟合检查'));
    subTabs(parent,[['fit','观察与预测'],['topology','模板实例组成']],s.fitView,value=>{s.fitView=value;renderMain();});
    if(s.fitView==='topology'){
        parent.append(el('p','本次分析保存的全局模板实例；不随节点／批次切换。每行表示一个物理实例，不代表该实例所属 Chain 在当前组一定有有效测试。选择实例可在右侧查看其所属 Chain 与成员。','muted'));
        const rows=report.topology||[],features=ordered(rows.flatMap(row=>Object.keys(row.features||{})));
        const columns=[{key:'chain_id',title:'CHAIN_ID'},{key:'tsk_instance_id',title:'TSK_instance_ID',format:row=>text(row.tsk_instance_id??row.instance_id)},
            {key:'tsk_id',title:'TSK_ID'},{key:'x',title:'X',numeric:true,format:row=>number(row.x)},{key:'y',title:'Y',numeric:true,format:row=>number(row.y)},
            {key:'chain_key',title:'Chain 完整路径',wide:true,format:row=>Array.isArray(row.chain_key)?row.chain_key.join(' / '):text(row.chain_key)},
            ...features.map(name=>({key:'features:'+name,title:name,wide:true,format:row=>text(row.features?.[name])}))];
        pagedTable(parent,rows,columns,'模板实例组成',row=>{
            const index=rows.indexOf(row),changed=s.selectedTopologyIndex!==index;
            s.selectedTopologyIndex=index;s.selectedChainId=String(row.chain_id);refreshChainDetail();fitDetailHeight();
            if(changed)$('fit-sidebar').scrollTop=0;setDrawer('fit',true,true);
        },{getSelected:()=>rows[s.selectedTopologyIndex]});
        refreshChainDetail();return;
    }
    const chains=sortRows(g.chains||[],'chain_id',false),plotPageSize=200;
    function selectedPlotPage(){const index=chains.indexOf(selectedChain());return index<0?s.fitPage:Math.floor(index/plotPageSize)+1;}
    s.fitPage=selectedPlotPage();
    parent.append(el('p','横轴为预测概率，纵轴为观察概率；对角线表示一致。散点按页显示，所有 Chain 均保留在明细中。点击点或表格行，在右侧查看链上 TSK。','muted'));
    const plotArea=el('div');parent.append(plotArea);let chainTable,scatter;
    const choose=row=>{
        showChain(row);const page=selectedPlotPage();
        if(s.fitPage!==page){s.fitPage=page;drawPlot();}else scatter?.refreshSelection();
        chainTable?.revealSelection();
    };
    function drawPlot(){
        clean(plotArea);const [from,to]=pager(plotArea,chains.length,plotPageSize,s.fitPage,page=>{s.fitPage=page;drawPlot();},'条 Chain（散点）');
        const rows=chains.slice(from,to);
        scatter=drawScatter(plotArea,rows,chains,choose);
        const selectionNote=el('div');plotArea.append(selectionNote);
        const refreshPoint=scatter.refreshSelection;
        scatter.refreshSelection=()=>{
            refreshPoint();clean(selectionNote);const selected=selectedChain();if(!selected)return;
            if(!chainHasPoint(selected))notice(selectionNote,'已选 Chain '+text(selected.chain_id)+'：'+(selected.n_tested>0?'缺少有效的观察或预测概率':'没有有效测试')+'，无法在散点图中标出；可查看表格与右侧详情。');
            else if(!rows.includes(selected))selectionNote.append(el('span','已选 Chain '+text(selected.chain_id)+' 位于第 '+selectedPlotPage()+' 页。 ','caption'),button('定位所选 Chain',()=>{s.fitPage=selectedPlotPage();drawPlot();},'small no-print'));
        };
        scatter.refreshSelection();
    }
    drawPlot();parent.append(el('h3','Chain 明细'));
    chainTable=pagedTable(parent,chains,chainColumns(),'Chain 明细',choose,{
        getSelected:selectedChain,revealSelected:true,onRowsChange:rows=>{s.chainTableMatches=new Set(rows.map(row=>String(row.chain_id)));refreshChainDetail();}
    });
    if(g.batch_counts?.length){
        const block=el('details',null,'raw');block.append(el('summary','原批次计数明细'));
        const area=el('div');block.append(area);let loaded=false;
        block.addEventListener('toggle',()=>{
            if(block.open&&!loaded){loaded=true;pagedTable(area,g.batch_counts,[{key:'source_batch',title:'原批次'},...chainColumns().slice(0,5)],'原批次计数');}
        });parent.append(block);
    }
    refreshChainDetail();
}
function chainHasPoint(row){return row.n_tested>0&&probability(row.observed_probability)&&probability(row.predicted_probability);}
function drawScatter(parent,rows,allRows,select){
    resizeScatter=null;
    const usable=rows.filter(chainHasPoint);
    if(!usable.length){
        empty(parent,rows.length?'本页没有可绘制的有效观察／预测配对；可在表格中查看原因和计数。':'本组没有 Chain 结果。');
        return {refreshSelection:()=>{}};
    }
    let max=allRows.reduce((value,row)=>Math.max(value,probability(row.observed_probability)?row.observed_probability:0,probability(row.predicted_probability)?row.predicted_probability:0),0);
    max=max>0?Math.min(1,max*1.08):.01;
    let w=760,h=430,right=732,bottom=385;
    const left=100,top=22;
    const x=value=>left+(right-left)*value/max,y=value=>bottom-(bottom-top)*value/max;
    const chart=svg('svg',{viewBox:'0 0 '+w+' '+h,class:'plot fit-plot',role:'img','aria-label':'Chain 观察与预测概率散点图'});
    const axes=svg('g',{class:'fit-axes'});chart.append(axes);const points=[];
    for(const row of usable){
        const point=svg('circle',{cx:x(row.predicted_probability),cy:y(row.observed_probability),r:5,fill:'#426dc3','fill-opacity':.7,stroke:'white','stroke-width':1,tabindex:0,role:'button','aria-label':row.chain_id+' · 观察 '+pct(row.observed_probability)+' / 预测 '+pct(row.predicted_probability)});
        point.style.cursor='pointer';
        const title=svg('title');title.textContent=row.chain_id+'\n观察：'+pct(row.observed_probability)+'\n预测：'+pct(row.predicted_probability)+'\nFail / Tested：'+number(row.n_failed)+' / '+number(row.n_tested);
        point.append(title);point.addEventListener('click',()=>select(row));
        point.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();select(row);}});
        chart.append(point);points.push({row,point});
    }
    // Draw the selection after every point so coincident chains cannot hide it.
    const overlay=svg('g',{class:'fit-selection','pointer-events':'none','aria-hidden':'true'});chart.append(overlay);
    function refreshSelection(){
        const selected=selectedChain();clean(overlay);
        for(const {row,point} of points){
            const active=row===selected;point.setAttribute('aria-pressed',String(active));
            point.setAttribute('fill',active?'#b54708':'#426dc3');point.setAttribute('fill-opacity',active?'1':'.7');
        }
        if(!usable.includes(selected))return;
        const cx=x(selected.predicted_probability),cy=y(selected.observed_probability);
        overlay.append(svg('rect',{x:cx-11,y:cy-11,width:22,height:22,rx:3,fill:'none',stroke:'white','stroke-width':5}),
            svg('rect',{x:cx-11,y:cy-11,width:22,height:22,rx:3,fill:'none',stroke:'#b54708','stroke-width':2.5}),
            svg('circle',{cx,cy,r:5,fill:'#b54708',stroke:'white','stroke-width':1.5}));
        const onRight=cx>(left+right)/2,label=svg('text',{x:cx+(onRight?-16:16),y:Math.max(top+12,cy-16),'text-anchor':onRight?'end':'start','font-size':11,'font-weight':600,fill:'#8c3505',stroke:'white','stroke-width':4,'paint-order':'stroke','stroke-linejoin':'round'});
        const id=text(selected.chain_id);label.textContent=id.length>48?id.slice(0,45)+'…':id;overlay.append(label);
    }
    function axisPct(value){
        const percent=value*100;
        return (percent!==0&&percent<.01?percent.toExponential(2):Number(percent.toPrecision(3)).toLocaleString('en-US',{maximumFractionDigits:4}))+'%';
    }
    let renderedWidth=0;
    function layout(){
        if(!chart.isConnected)return;
        const width=chart.getBoundingClientRect().width;if(width<=0||Math.abs(width-renderedWidth)<.5)return;
        renderedWidth=width;w=width;h=Math.max(280,Math.min(430,w*.56));right=w-28;bottom=h-48;
        // Match SVG units to CSS pixels so plot labels never grow with a wide window.
        chart.style.height=h+'px';chart.setAttribute('viewBox','0 0 '+w+' '+h);clean(axes);
        const steps=w<520?3:5;
        for(let i=0;i<=steps;i++){
            const value=max*i/steps;
            axes.append(svg('line',{x1:x(value),x2:x(value),y1:top,y2:bottom,stroke:'#e1e7ef'}),svg('line',{x1:left,x2:right,y1:y(value),y2:y(value),stroke:'#e1e7ef'}));
            const tx=svg('text',{x:x(value),y:bottom+20,'text-anchor':'middle','font-size':11,fill:'#627084'});tx.textContent=axisPct(value);
            const ty=svg('text',{x:left-10,y:y(value)+4,'text-anchor':'end','font-size':11,fill:'#627084'});ty.textContent=axisPct(value);axes.append(tx,ty);
        }
        axes.append(svg('line',{x1:left,x2:right,y1:bottom,y2:top,stroke:'#7b8ea8','stroke-dasharray':'5 5'}));
        const xlabel=svg('text',{x:(left+right)/2,y:h-8,'text-anchor':'middle','font-size':12,fill:'#26354a'});xlabel.textContent='预测 Chain 异常率';
        const mid=(top+bottom)/2,ylabel=svg('text',{x:18,y:mid,transform:'rotate(-90 18 '+mid+')','text-anchor':'middle','font-size':12,fill:'#26354a'});ylabel.textContent='观察 Chain 异常率';axes.append(xlabel,ylabel);
        const pointRadius=Math.max(2,Math.min(5,w/152));
        for(const {row,point} of points){
            point.setAttribute('cx',x(row.predicted_probability));point.setAttribute('cy',y(row.observed_probability));
            point.setAttribute('r',pointRadius);point.setAttribute('stroke-width',Math.min(1,pointRadius/4));
        }
        refreshSelection();
    }
    const wrap=el('div',null,'chart-scroll');wrap.append(chart);parent.append(wrap);resizeScatter=layout;layout();
    return {refreshSelection};
}
function memberAttributes(r){return r.features&&Object.keys(r.features).length?r.features:{...(r.categories||{}),...(r.numeric||{})};}
function conditionParts(r){
    const entries=Object.entries(memberAttributes(r));
    // X/Y are reserved coordinate fields in the saved instance schema.
    const coordinate=([key])=>/^[xy]$/i.test(key);
    return {features:entries.filter(entry=>!coordinate(entry)),coordinates:entries.filter(coordinate)};
}
function namedConditions(entries){return entries.map(([key,value])=>key+'='+text(value)).join(' · ');}
function memberConditions(r){const parts=conditionParts(r);return namedConditions([...parts.features,...parts.coordinates])||'无额外特征';}
function tskIdentity(parent,r,tag='h4',count=null){
    const {features}=conditionParts(r),identity='TSK '+text(r.tsk_id)+(count===null?'':' × '+number(count));
    parent.append(el(tag,[identity,...features.map(([,value])=>text(value))].join(' · '),'tsk-identity'));
    parent.append(el('p',namedConditions(features)||'无额外特征','tsk-conditions'));
}
function chainMembers(row){return row.members||groups[groupIndex].chain_members?.[row.chain_id]||[];}
function chainMemberDisclosure(parent,chain){
    const s=state();s.expandedChains=s.expandedChains||new Set();
    const key=String(chain.chain_id),members=chainMembers(chain),details=el('details',null,'chain-members');
    const summary=el('summary'),body=el('div');let loaded=false;
    function update(){
        summary.textContent=(details.open?'收起':'展开')+'链上 TSK'+(members.length?'（'+number(members.length)+' 项）':'');
        if(details.open&&!loaded){loaded=true;renderChainMembers(body,chain,'关联链成员 ');}
    }
    details.append(summary,body);parent.append(details);details.open=s.expandedChains.has(key);update();
    details.addEventListener('toggle',()=>{
        if(!details.isConnected)return;
        if(details.open)s.expandedChains.add(key);else s.expandedChains.delete(key);
        update();fitDetailHeight();
    });
}
function renderChainMembers(parent,r,keyPrefix='链成员 '){
    parent.append(el('p','单实例概率使用成员实际条件；同一 TSK 的不同条件分别列出。链整体风险为 1 − ∏(1 − p_member)^count，count 为同条件成员实例数。成员概率不表示某次观测失效由该成员造成。','caption'));
    const members=chainMembers(r);
    if(!members.length)empty(parent,'本结果未保存链成员风险明细。');
    else pagedCards(parent,members,keyPrefix+r.chain_id,(card,member)=>{
        tskIdentity(card,member,'h4',member.count);
        kv(card,{'单实例概率':riskText(member),'置信区间':interval(member),'状态':status(member.status)});
        if(member.reason)card.append(el('p',member.reason,'caption'));
        if(member.interval_error)card.append(el('p','区间不可用原因：'+member.interval_error,'caption'));
        if(boundary(member))card.append(el('p','零边界不表示保证零失效，请结合上限阅读。','caption'));
        if(member.instance_ids)card.append(el('p','实例编号：'+(Array.isArray(member.instance_ids)?member.instance_ids.join('、'):text(member.instance_ids)),'caption'));
        const coordinates=conditionParts(member).coordinates;
        if(coordinates.length)card.append(el('p','坐标：'+namedConditions(coordinates),'tsk-coordinates'));
    });
}
function chainDetail(parent,r){
    parent.append(el('h3','Chain '+text(r.chain_id)));
    const summary=el('div',null,'detail-summary');
    summary.append(el('p','观察概率：'+(r.n_tested>0?pct(r.observed_probability):'无有效测试')),el('p','预测概率：'+pct(r.predicted_probability)));
    parent.append(summary,el('h3','链上 TSK 成员'));renderChainMembers(parent,r);
    detailStats(parent,'Chain 统计与残差',{
        '观察概率':r.n_tested>0?pct(r.observed_probability):'无有效测试','预测概率':pct(r.predicted_probability),
        '有效样品数':r.n_tested,'Fail':r.n_failed,'Pass':r.n_passed??(finite(r.n_tested)&&finite(r.n_failed)?Math.max(0,r.n_tested-r.n_failed):null),
        'Missing':r.n_missing,'残差（观察 − 预测）':pp(r.residual),'Deviance residual':r.deviance_residual
    });
}
function jointAvailable(r){return ['ok','boundary_low','interval_unavailable','model_interval_mismatch'].includes(r.status)&&available(r);}
function membersText(r){return Array.isArray(r.members)?r.members.map(m=>typeof m==='object'?text(m.tsk_id||m.label)+' × '+number(m.count)+' ['+memberConditions(m)+']':text(m)).join(' + '):text(r.members);}
function jointConditions(r){if(!r.conditions||typeof r.conditions!=='object')return text(r.conditions);return Object.entries(r.conditions).map(([k,v])=>typeof v==='object'?Object.entries(v||{}).map(([n,a])=>n+'='+text(a)).join(' · '):k+'='+text(v)).join(' · ');}
function jointKind(r){return {multiple_instances:'多个实例整体风险',joint_conditions:'单实例联合条件'}[r.kind]||text(r.kind);}
function renderJoint(parent){const g=groups[groupIndex],joint=g.joint_risk;parent.append(el('h2','联合风险'),el('p','展示个别贡献无法分离时，仍可识别的完整条件或实例组合。成员数量与条件是定义的一部分，不能把联合概率平均分配给成员。','muted'));if(!joint){empty(parent,'本结果没有保存联合风险报告；需在应用中重新分析后导出。');return;}if(joint.notes?.length)warnings(parent,joint.notes);if(joint.omitted_count)notice(parent,'计算中省略了 '+number(joint.omitted_count)+' 个候选组合；此报告不会补算。');const rows=joint.rows||[];if(!rows.length){empty(parent,joint.reason||status(joint.status)||'没有可展示的联合风险。');return;}parent.append(el('p','共 '+rows.length+' 项，其中 '+rows.filter(jointAvailable).length+' 项有可显示的概率。','caption'));const detail=el('div',null,'detail');const choose=r=>{clean(detail);detail.append(el('h3',r.label||r.group_id||'联合风险详情'));kv(detail,{'类型':jointKind(r),'成员':membersText(r),'条件':jointConditions(r),'概率':jointAvailable(r)?riskText(r):'—','置信区间':jointAvailable(r)?interval(r):'—','状态':status(r.status),'原因':r.reason,'公式':r.formula,'支持 Chain 数':r.chain_count,'测试暴露':r.test_exposure,'区间方法':r.interval_method,'区间不可用原因':r.interval_error});if(r.parameter_names?.length)detail.append(el('p','关联参数：'+r.parameter_names.join(' · ')));if(r.notes?.length)warnings(detail,r.notes);if(boundary(r)&&jointAvailable(r))notice(detail,'零边界估计不表示保证零失效。');};pagedTable(parent,rows,[{key:'label',title:'联合对象',wide:true,format:r=>r.label||r.group_id||'—'},{key:'kind',title:'类型',format:jointKind},{key:'members',title:'成员组成',wide:true,format:membersText},{key:'conditions',title:'条件',wide:true,format:jointConditions},{key:'probability',title:'整体概率',numeric:true,format:r=>jointAvailable(r)?riskText(r):'—'},{key:'ci_lower',title:'区间下界',numeric:true,format:r=>jointAvailable(r)&&r.interval_sidedness!=='upper'?pct(r.ci_lower):'—'},{key:'ci_upper',title:'区间上界 / 上限',numeric:true,format:r=>jointAvailable(r)?pct(r.ci_upper):'—'},{key:'status',title:'状态',format:r=>status(r.status)},{key:'reason',title:'原因',wide:true}],'联合风险',r=>{choose(r);detail.scrollIntoView({block:'nearest',behavior:'smooth'});},{size:30});parent.append(detail);choose(rows[0]);}
function warnings(parent,items){const unique=[...new Set(items.filter(Boolean).map(String))];if(!unique.length)return;const list=el('ul',null,'warning-list');unique.forEach(item=>list.append(el('li',item)));parent.append(list);}
function renderAnalysisSettings(parent,g,diag){
    const options=g.options||{},context=g.prediction_context||{},values={};
    const level=options.confidence_level??context.confidence_level??diag.confidence_level;
    if(probability(level))values['置信水平']=pct(level);
    const xy=options.include_xy??options.use_xy;
    if(typeof xy==='boolean')values['使用坐标 X/Y']=xy?'是':'否';
    const xyModel=options.xy_model||diag.xy_model;
    if(xy&&xyModel)values['XY 模型']=xyModel==='origin_even_quartic'?'基于物理原点的对称四次曲面':xyModel==='linear'?'线性 X/Y':xyModel;
    if(options.feature_names?.length)values['分析特征']=options.feature_names.join('、');
    const categories=options.categorical_feature_names||Object.keys(definitions(g));
    if(categories.length)values['类别特征']=categories.join('、');
    if(typeof diag.finite_mle==='boolean')values['有限参数估计']=diag.finite_mle?'是':'否';
    if(finite(diag.deviance))values['Deviance']=number(diag.deviance);
    if(Object.keys(values).length){parent.append(el('h3','分析设置与拟合统计'));kv(parent,values);}
}
function renderModel(parent){
    const s=state(),g=groups[groupIndex],summary=g.feature_summary||{},diag=g.diagnostics||{};
    parent.append(el('h2','模型与诊断'));subTabs(parent,[['model','模型说明'],['diagnostics','诊断与提示']],s.modelView,v=>{s.modelView=v;renderMain();});
    if(s.modelView==='diagnostics'){
        kv(parent,{'结果组':g.label||g.node,'节点':g.node,'批次方式':g.batch_mode,'原批次字段':g.batch_dimension,'母批':g.parent_batch_id,'原批次':(g.source_batches||[]).join('、'),'模型':diag.model,'收敛':diag.converged===true?'已收敛':'未确认收敛','秩':text(diag.rank)+' / '+text(diag.parameter_count)});
        parent.append(el('h3','分析与组合提示'));const list=[...(report.warnings||[]),...(diag.warnings||[]),...(riskSource().view?.warnings||[])];
        if(list.length)warnings(parent,list);else parent.append(el('p','本结果没有记录额外提示。','muted'));renderAnalysisSettings(parent,g,diag);return;
    }
    if(summary.formula)parent.append(el('pre',summary.formula));else empty(parent,'本结果没有可用的模型公式说明。');
    if(summary.notes?.length)warnings(parent,summary.notes);
    const refs=summary.category_references||{};
    if(Object.keys(refs).length){parent.append(el('h3','类别参考水平'));kv(parent,refs);}
    const spatial=summary.spatial_transform||diag.spatial_transform||g.prediction_context?.spatial_transform||{},spatialNames=new Set((spatial.terms||[]).map(term=>term.name));
    if(spatialNames.size){
        parent.append(el('h3','XY 空间曲面与参考位置'));
        kv(parent,{'物理原点':'(0,0)','X 坐标尺度':number(spatial.coordinate_scales?.x),'Y 坐标尺度':number(spatial.coordinate_scales?.y),'原始 X 均值参考':number(spatial.reference?.x),'原始 Y 均值参考':number(spatial.reference?.y)});
        parent.append(el('p','五个基底共同描述 F(X,Y)。先由物理原点构造基底，再减去原始 XY 均值位置的基底值。下表空间项的“均值 / 基底参考”是该位置的基底值，不是派生项样本均值；单项系数不是移动 X 或 Y 的 OR。','caption'));
    }
    const scaling=Object.entries(summary.numeric_scaling||{}).filter(([feature])=>!spatialNames.has(feature));
    if(scaling.length){parent.append(el('h3','数值特征标准化'));pagedTable(parent,scaling.map(([feature,value])=>({feature,...value})),[{key:'feature',title:'数值特征'},{key:'mean',title:'训练均值',numeric:true,format:r=>number(r.mean)},{key:'scale',title:'标准化尺度',numeric:true,format:r=>number(r.scale)}],'数值标准化',null,{search:false});}
    parent.append(el('h3','模型系数'));const coefficients=summary.coefficients||[];
    if(coefficients.length)pagedTable(parent,coefficients,[{key:'term',title:'参数',wide:true},{key:'coefficient',title:'系数',numeric:true,format:r=>number(r.coefficient)},{key:'status',title:'状态',format:r=>status(r.status)},{key:'coefficient_scale',title:'系数尺度'},{key:'mean',title:spatialNames.size?'均值 / 基底参考':'均值',numeric:true,format:r=>number(r.mean)},{key:'scale',title:'标准化尺度',numeric:true,format:r=>number(r.scale)},{key:'note',title:'说明',wide:true}],'模型系数');
    else empty(parent,'本组没有可显示的特征系数。类型模型的风险结果可在“风险结果”查看。');
}
__FEATURE_EFFECTS_SCRIPT__
const groupSelect=$('group-select');
function bindGroups(){
    clean(groupSelect);groups.forEach((g,index)=>{const option=el('option',g.label||g.node||'结果组 '+(index+1));option.value=String(index);groupSelect.append(option);});
    groupSelect.value=String(groupIndex);groupSelect.disabled=!groups.length;
    $('report-subtitle').textContent='导出时间：'+text(documentReport.exported_at)+' · '+groups.length+' 个结果组 · 全部资源已内嵌，可离线查看';
}
groupSelect.addEventListener('change',()=>{groupIndex=Number(groupSelect.value);renderMain();});
const analyses=(Array.isArray(documentReport.saved_analyses)?documentReport.saved_analyses:[])
    .filter(entry=>entry&&typeof entry.key==='string'&&entry.result?.groups?.length)
    .map(entry=>entry.key===analysisKey?{...entry,result:documentReport}:entry);
if(analyses.length&&!analyses.some(entry=>entry.key===analysisKey))analyses.unshift({key:analysisKey,result:documentReport});
const analysisSelect=$('analysis-select');
function analysisLabel(entry){
    const settings=entry.settings||entry.result.provenance?.settings||entry.result.groups?.[0]?.options||{},
        mode=entry.mode||settings.feature_effects_mode||'fixed_zero';
    return mode==='boundary_simulation'?'自由边界模拟检验 · '+(settings.simulation_replicates??999)+' 次 · 种子 '+(settings.simulation_seed??1729):'固定零风险条件分析';
}
analyses.forEach(entry=>{const option=el('option',analysisLabel(entry));option.value=entry.key;analysisSelect.append(option);});
analysisSelect.value=analysisKey;analysisSelect.disabled=analyses.length<2;
$('analysis-selector-label').hidden=analyses.length<2;
analysisSelect.title='仅切换已有计算结果，不重新拟合或模拟。';
analysisSelect.addEventListener('change',()=>{
    const entry=analyses.find(item=>item.key===analysisSelect.value);if(!entry||entry.key===analysisKey)return;
    analysisStates.set(analysisKey,{states,groupIndex,mainPage});
    const previousGroup=groupIndex;analysisKey=entry.key;report=entry.result;groups=report.groups;
    const restored=analysisStates.get(analysisKey);states=restored?.states||new Map();
    groupIndex=Math.min(restored?.groupIndex??previousGroup,Math.max(0,groups.length-1));mainPage=restored?.mainPage||mainPage;
    updateRiskCurve=null;bindGroups();renderMain();
});
bindGroups();
$('print-report').addEventListener('click',()=>window.print());
try{renderMain();}catch(error){console.error(error);const content=clean($('content'));notice(content,'报告显示失败，请重新打开文件或从应用重新导出。');}
})();
</script></body></html>'''
