"""Bounded process parallelism for independent TSK fits.

Only the parent reports progress. Layouts are sent once per worker, native
numeric libraries use one thread, and nested analyses share the outer budget.
"""
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from concurrent.futures.process import BrokenProcessPool
from dataclasses import dataclass
import logging
import multiprocessing
from numbers import Integral
import os
import threading
import sys
import shlex

from .compute_resources import limit_process_workers


_SPAWN_ENV_LOCK = threading.Lock()
_THREAD_ENV = ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS", "VECLIB_MAXIMUM_THREADS",
               "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS")
_IN_WORKER = False
_COMMON = None
_FUNCTION = None
_THREAD_LIMIT = None
_STARTUP_GATE = None


def require_parallel_runtime():
    """Report missing native-thread controls before starting failing children."""
    try:
        from threadpoolctl import threadpool_limits
    except ImportError as error:
        if getattr(sys, "frozen", False):
            remedy = "请重新安装包含完整依赖的程序包。"
        else:
            command = ([sys.executable, "-m", "pip", "install", "threadpoolctl>=3.1,<4"])
            formatted = (f'& "{sys.executable}" -m pip install "threadpoolctl>=3.1,<4"'
                         if os.name == "nt" else shlex.join(command))
            remedy = f"请在启动本程序的 Python 环境执行：\n{formatted}"
        raise RuntimeError(f"多进程计算依赖 threadpoolctl 无法加载：{error}\n{remedy}\n安装后请重新启动程序。") from error
    return threadpool_limits


@dataclass(frozen=True)
class _WorkerResult:
    value: object
    pid: int


def in_parallel_worker():
    return _IN_WORKER


def validate_analysis_workers(workers):
    if isinstance(workers, bool) or not isinstance(workers, Integral) or not 0 <= workers <= 64:
        raise ValueError("analysis_workers must be an integer between 0 and 64 (0 means automatic).")
    return int(workers)


def worker_count(workers, task_count, min_parallel_items=2):
    workers = validate_analysis_workers(workers)
    if _IN_WORKER or task_count < 2:
        return 1
    if workers == 0:
        if task_count < min_parallel_items:
            return 1
        workers = min(8, max((os.cpu_count() or 1) - 1, 1))
    return limit_process_workers(min(workers, task_count, 61 if os.name == "nt" else 64))


def _initialize(function, common, prepare_common, gate, log_queue=None):
    from .process_logging import install_process_logging

    install_process_logging(log_queue)
    threadpool_limits = require_parallel_runtime()

    global _IN_WORKER, _COMMON, _FUNCTION, _THREAD_LIMIT, _STARTUP_GATE
    _IN_WORKER = True
    _FUNCTION, _STARTUP_GATE = function, gate
    _THREAD_LIMIT = threadpool_limits(limits=1)
    parent = multiprocessing.parent_process()
    if parent is not None:
        def parent_died():
            from multiprocessing.connection import wait
            wait([parent.sentinel])
            os._exit(0)
        threading.Thread(target=parent_died, name="tsk-parent-watch", daemon=True).start()
    _COMMON = prepare_common(common) if prepare_common is not None else common


def _ready():
    _STARTUP_GATE.wait()


def _run(item):
    return _WorkerResult(_FUNCTION(_COMMON, item, lambda: None), os.getpid())


def _shutdown(pool, *, terminate=False):
    if pool is None:
        return
    if not terminate:
        pool.shutdown(wait=True, cancel_futures=True)
        return
    # Python 3.10 lacks the public terminate_workers API.
    processes = list((getattr(pool, "_processes", None) or {}).values())
    for process in processes:
        if process.is_alive():
            process.terminate()
    pool.shutdown(wait=False, cancel_futures=True)
    for process in processes:
        process.join(timeout=.2)
        if process.is_alive():
            process.kill()
            process.join(timeout=.2)


def ordered_parallel_map(function, items, *, common=None, prepare_common=None, workers=0,
                         progress_callback=None, min_parallel_items=2, execution=None):
    """Map ``function(common, item, heartbeat)`` in input order.

    ``prepare_common`` builds worker-local reusable state once. The callback is
    called with (completed, total), including while waiting, and may cancel by
    raising. Infrastructure failures retry only unfinished items serially;
    computation exceptions propagate. Completion drives progress and refill;
    only the returned list is ordered. Callers must provide side-effect-free jobs.
    """
    items = list(items)
    total = len(items)
    count = worker_count(workers, total, min_parallel_items)
    progress = progress_callback or (lambda *_: None)
    execution = execution if execution is not None else {}
    execution.update(workers_requested=int(workers), workers_used=count,
                     execution_backend="serial" if count == 1 else "spawn_process_pool",
                     execution_warnings=[], worker_pids=[], workers_observed=0,
                     phase="serial" if count == 1 else "starting", completed_tasks=0)
    missing = object()
    output = [missing] * total
    completed = 0
    worker_pids = set()
    local_common = None
    local_ready = False

    def serial_tail():
        nonlocal local_common, local_ready, completed
        execution["phase"] = "serial"
        if not local_ready:
            local_common = prepare_common(common) if prepare_common is not None else common
            local_ready = True
        for index, item in enumerate(items):
            if output[index] is not missing:
                continue
            heartbeat = lambda: progress(completed, total)
            heartbeat()
            output[index] = function(local_common, item, heartbeat)
            completed += 1
            execution["completed_tasks"] = completed
            progress(completed, total)
        execution["phase"] = "completed"
        return output

    if count == 1 or not items:
        return serial_tail()
    require_parallel_runtime()
    from .process_logging import get_process_log_queue
    pool = None
    pending = {}

    def fallback(error):
        nonlocal pool
        _shutdown(pool, terminate=True)
        pool = None
        execution.update(workers_used=1, execution_backend="serial_after_process_failure")
        warning = f"TSK 子进程不可用，保留已完成结果，其余串行继续：{type(error).__name__}: {error}"
        execution["execution_warnings"].append(warning)
        logging.getLogger(__name__).warning(warning)
        return serial_tail()

    try:
        progress(0, total)
        try:
            with _SPAWN_ENV_LOCK:
                previous = {key: os.environ.get(key) for key in _THREAD_ENV}
                try:
                    os.environ.update({key: "1" for key in _THREAD_ENV})
                    spawn = multiprocessing.get_context("spawn")
                    gate = spawn.Event()
                    pool = ProcessPoolExecutor(max_workers=count, mp_context=spawn,
                        initializer=_initialize, initargs=(function, common, prepare_common, gate, get_process_log_queue()))
                    for _ in range(count):
                        pool.submit(_ready)
                    gate.set()
                finally:
                    for key, value in previous.items():
                        if value is None:
                            os.environ.pop(key, None)
                        else:
                            os.environ[key] = value
        except (OSError, RuntimeError) as error:
            return fallback(error)
        next_submit = 0
        while completed < total:
            try:
                while next_submit < total and len(pending) < 2 * count:
                    pending[pool.submit(_run, items[next_submit])] = next_submit
                    next_submit += 1
                progress(completed, total)
                ready, _ = wait(pending, timeout=.1, return_when=FIRST_COMPLETED)
                broken = None
                for future in ready:
                    index = pending.pop(future)
                    try:
                        result = future.result()
                    except BrokenProcessPool as error:
                        broken = error
                        continue
                    if isinstance(result, _WorkerResult):
                        worker_pids.add(result.pid)
                        result = result.value
                    output[index] = result
                    completed += 1
                execution.update(completed_tasks=completed, worker_pids=sorted(worker_pids),
                                 workers_observed=len(worker_pids),
                                 phase="running" if completed else "starting")
                if broken is not None:
                    return fallback(broken)
            except BrokenProcessPool as error:
                return fallback(error)
            progress(completed, total)
    except BaseException:
        _shutdown(pool, terminate=True)
        pool = None
        raise
    finally:
        _shutdown(pool)
    execution["phase"] = "completed"
    return output
