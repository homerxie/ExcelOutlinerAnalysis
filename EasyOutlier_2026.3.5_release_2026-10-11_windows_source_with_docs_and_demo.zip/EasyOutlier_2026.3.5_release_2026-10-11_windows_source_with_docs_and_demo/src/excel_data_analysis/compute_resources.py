"""Shared process ceilings, independent of GUI settings and task scheduling.

Zero preserves each task's existing automatic strategy. A positive ceiling
limits that task's process workers; it is neither CPU affinity nor a shared
quota across independent tasks. The GUI freezes this value when dispatching
work, and subprocess entry points install their own frozen value.
"""

from numbers import Integral
import os


SETTINGS_KEY = "compute/max_process_workers"
_PROCESS_LIMIT = 0


def validate_process_limit(value):
    if isinstance(value, bool) or not isinstance(value, Integral) or not 0 <= value <= 64:
        raise ValueError("Process limit must be an integer between 0 and 64 (0 means automatic).")
    return int(value)


def set_process_limit(value):
    global _PROCESS_LIMIT
    _PROCESS_LIMIT = validate_process_limit(value)


def get_process_limit():
    return _PROCESS_LIMIT


def limit_process_workers(count):
    count = max(1, int(count))
    return min(count, _PROCESS_LIMIT) if _PROCESS_LIMIT else count


def available_process_limit():
    return max(1, min(os.cpu_count() or 1, 61 if os.name == "nt" else 64))
