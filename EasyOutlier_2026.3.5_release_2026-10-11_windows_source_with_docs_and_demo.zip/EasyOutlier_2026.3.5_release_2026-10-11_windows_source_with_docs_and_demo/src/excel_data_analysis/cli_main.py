from __future__ import annotations

import multiprocessing


def main() -> None:
    # Handle frozen worker arguments before importing the command parser.
    multiprocessing.freeze_support()
    from excel_data_analysis.cli import main as launch

    launch()


if __name__ == "__main__":
    main()
