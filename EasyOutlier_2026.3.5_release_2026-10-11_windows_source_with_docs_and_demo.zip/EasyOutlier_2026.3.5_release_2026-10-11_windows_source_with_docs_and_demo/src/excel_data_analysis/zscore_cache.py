"""Bounded, process-transferable caches of lossless Z-score statistics and scores.

Only numeric vectors and content fingerprints are retained. In particular, cache
entries never own measurements, result objects, filters, or anomaly thresholds.
"""

from __future__ import annotations

from array import array
from bisect import bisect_left
from collections import OrderedDict, defaultdict
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from hashlib import sha256
import json
from math import copysign, isfinite
import pickle
from struct import pack, unpack
import sys
from threading import RLock
from typing import Any

import numpy as np

from .models import MeasurementRecord


_STATE_VERSION = 1


def _key(context: Any) -> str:
    return sha256(json.dumps(context, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()


def _value_bits(value: float) -> int:
    return unpack("!Q", pack("!d", value))[0]


def _cacheable(values: Sequence[float]) -> bool:
    # Imported measurements are floats, but preserve standalone callers' exact
    # behavior for arbitrary integers and non-finite values too.
    try:
        return all(
            isfinite(value) and float(value) == value
            and (not isinstance(value, int) or abs(value) <= 2**53)
            for value in values
        )
    except (OverflowError, TypeError, ValueError):
        return False


class PopulationFingerprint:
    """Order-independent multiset fingerprint, including repeated pool members."""

    def __init__(self) -> None:
        self._members = defaultdict(list)
        self.cacheable = True

    def add(self, record: MeasurementRecord) -> None:
        identity = (record.dataset_id, record.source_file, record.raw_column)
        try:
            value = float(record.value)
            if (not isfinite(value) or value != record.value
                    or (isinstance(record.value, int) and abs(record.value) > 2**53)):
                self.cacheable = False
        except (OverflowError, TypeError):
            value = record.value
            self.cacheable = False
        self._members[identity].append((record.row_number, value, value == 0 and copysign(1, value) < 0))

    def key(self, logical_metric: str, population_key: tuple[tuple[str, str], ...]) -> str:
        digest = sha256(json.dumps([logical_metric, sorted(population_key)], ensure_ascii=False).encode())
        for identity, members in sorted(self._members.items()):
            identity_bytes = json.dumps(identity, ensure_ascii=False).encode()
            # Serialize numeric members in C, once per raw column. Unlike
            # hashing each record separately this costs little on warm reads.
            # Sorting includes duplicates and makes deep copies and reordered
            # scopes use the same complete membership fingerprint.
            member_bytes = pickle.dumps(sorted(members), protocol=4)
            digest.update(pack("!QQ", len(identity_bytes), len(member_bytes)))
            digest.update(identity_bytes)
            digest.update(member_bytes)
        return "population:" + digest.hexdigest()


def golden_cache_key(
    logical_metric: str,
    reference_key: tuple[tuple[str, str], ...],
    center: float,
    mad: float,
    sample_size: int,
) -> str:
    # The file name, timestamps, allowed ranges and golden-rule thresholds do
    # not determine Z-scores. Only the matched saved baseline does.
    return "golden:" + _key(
        [logical_metric, sorted(reference_key), center, mad, sample_size]
    )


@dataclass(frozen=True, slots=True)
class CachedZScores:
    center: float | None
    mad: float | None
    value_bits: array
    scores: array

    def score(self, value: float) -> float | None:
        if self.center is None:
            return None
        bits = _value_bits(value)
        index = bisect_left(self.value_bits, bits)
        if index == len(self.value_bits) or self.value_bits[index] != bits:
            raise KeyError(value)
        return self.scores[index]

    def scores_for(self, values: Sequence[float]) -> list[float | None]:
        if self.center is None:
            return [None] * len(values)
        bits = np.asarray(values, dtype=np.float64).view(np.uint64)
        offsets = np.searchsorted(np.frombuffer(self.value_bits, dtype=np.uint64), bits)
        return np.frombuffer(self.scores, dtype=np.float64)[offsets].tolist()

    @property
    def size_bytes(self) -> int:
        # Allow for the arrays, dataclass, OrderedDict node and fixed-size key.
        return 512 + self.value_bits.buffer_info()[1] * self.value_bits.itemsize + self.scores.buffer_info()[1] * self.scores.itemsize


class ZScoreCache:
    def __init__(self, *, max_entries: int = 4096, max_bytes: int = 32 * 1024 * 1024) -> None:
        self.max_entries = max(0, max_entries)
        self.max_bytes = max(0, max_bytes)
        self._entries: OrderedDict[str, CachedZScores] = OrderedDict()
        self._bytes = 0
        self._hits = 0
        self._misses = 0
        self._lock = RLock()

    def clear(self) -> None:
        with self._lock:
            self._entries.clear()
            self._bytes = self._hits = self._misses = 0

    def info(self) -> dict[str, int]:
        with self._lock:
            return {
                "entries": len(self._entries),
                "bytes": self._bytes,
                "hits": self._hits,
                "misses": self._misses,
                "max_entries": self.max_entries,
                "max_bytes": self.max_bytes,
            }

    def _store(self, key: str, entry: CachedZScores) -> None:
        old = self._entries.pop(key, None)
        if old is not None:
            self._bytes -= old.size_bytes
        if not self.max_entries or entry.size_bytes > self.max_bytes:
            return
        self._entries[key] = entry
        self._bytes += entry.size_bytes
        while len(self._entries) > self.max_entries or self._bytes > self.max_bytes:
            _, removed = self._entries.popitem(last=False)
            self._bytes -= removed.size_bytes

    def population_scores(
        self,
        key: str,
        values: Sequence[float],
        statistics: Callable[[Sequence[float]], tuple[float | None, float | None]],
        score: Callable[[float, float | None, float | None], float | None],
        *,
        values_cacheable: bool | None = None,
    ) -> CachedZScores | None:
        if not (values_cacheable if values_cacheable is not None else _cacheable(values)):
            return None
        with self._lock:
            cached = self._entries.get(key)
            if cached is not None:
                self._entries.move_to_end(key)
                self._hits += 1
                return cached
            self._misses += 1
            center, mad = statistics(values)
            entry = self._score_values(values, center, mad, score)
            self._store(key, entry)
            return entry

    @staticmethod
    def _score_values(
        values: Sequence[float],
        center: float | None,
        mad: float | None,
        score: Callable[[float, float | None, float | None], float | None],
        previous: CachedZScores | None = None,
    ) -> CachedZScores:
        if center is None:
            return CachedZScores(None, mad, array("Q"), array("d"))
        known = dict(zip(previous.value_bits, previous.scores)) if previous is not None else {}
        for value in values:
            bits = _value_bits(value)
            if bits not in known:
                known[bits] = score(value, center, mad)
        ordered = sorted(known)
        return CachedZScores(center, mad, array("Q", ordered), array("d", (known[bits] for bits in ordered)))

    def golden_scores(
        self,
        key: str,
        values: Sequence[float],
        center: float | None,
        mad: float | None,
        score: Callable[[float, float | None, float | None], float | None],
    ) -> CachedZScores | None:
        if not _cacheable(values):
            return None
        with self._lock:
            cached = self._entries.get(key)
            if cached is not None:
                # Golden scores are independent of the other measurement
                # values. A narrower view reuses each previously scored value.
                if center is None or all(self._contains(cached, value) for value in values):
                    self._entries.move_to_end(key)
                    self._hits += 1
                    return cached
            self._misses += 1
            entry = self._score_values(values, center, mad, score, previous=cached)
            self._store(key, entry)
            return entry

    @staticmethod
    def _contains(entry: CachedZScores, value: float) -> bool:
        bits = _value_bits(value)
        index = bisect_left(entry.value_bits, bits)
        return index < len(entry.value_bits) and entry.value_bits[index] == bits

    def export_state(self) -> dict[str, Any]:
        """Export compact, versioned numeric buffers for process transfer."""
        with self._lock:
            return {
                "version": _STATE_VERSION,
                "byteorder": sys.byteorder,
                "entries": [
                    [key, entry.center, entry.mad, entry.value_bits.tobytes(), entry.scores.tobytes()]
                    for key, entry in self._entries.items()
                ],
            }

    def import_state(self, state: dict[str, Any] | None) -> None:
        """Merge a compatible snapshot while applying this cache's limits."""
        if not isinstance(state, dict) or state.get("version") != _STATE_VERSION:
            return
        if not isinstance(state.get("entries"), (tuple, list)):
            return
        with self._lock:
            for item in state.get("entries", []):
                try:
                    key, center, mad, bits, scores = item
                    if not isinstance(key, str) or not key.startswith(("population:", "golden:")):
                        continue
                    if center is not None and (not isinstance(center, (int, float)) or not isinstance(mad, (int, float))):
                        continue
                    if isinstance(bits, bytes) and isinstance(scores, bytes):
                        values_array, scores_array = array("Q"), array("d")
                        values_array.frombytes(bits)
                        scores_array.frombytes(scores)
                        if state.get("byteorder", sys.byteorder) != sys.byteorder:
                            values_array.byteswap()
                            scores_array.byteswap()
                    else:
                        values_array, scores_array = array("Q", bits), array("d", scores)
                    if len(values_array) != len(scores_array) or any(a >= b for a, b in zip(values_array, values_array[1:])):
                        continue
                    entry = CachedZScores(center, mad, values_array, scores_array)
                except (TypeError, ValueError, OverflowError):
                    continue
                previous = self._entries.get(key)
                if key.startswith("golden:") and previous is not None and previous.center == center and previous.mad == mad:
                    merged = dict(zip(previous.value_bits, previous.scores))
                    merged.update(zip(entry.value_bits, entry.scores))
                    ordered = sorted(merged)
                    entry = CachedZScores(center, mad, array("Q", ordered), array("d", (merged[bits] for bits in ordered)))
                self._store(key, entry)


_shared_cache = ZScoreCache()


def get_shared_zscore_cache() -> ZScoreCache:
    return _shared_cache
