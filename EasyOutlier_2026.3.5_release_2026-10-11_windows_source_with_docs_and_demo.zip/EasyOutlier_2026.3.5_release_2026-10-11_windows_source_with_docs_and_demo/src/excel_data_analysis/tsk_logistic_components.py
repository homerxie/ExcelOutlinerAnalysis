"""Publish validated risks from provably independent Chain likelihood blocks.

An unresolved block never supplies a point estimate for another query. Blocks
are separated in the full fitted-logit space, not by coefficient names, and a
Chain is indivisible. This permits shared coefficient representations while
requiring a direct-sum factorization of the actual likelihood.
"""
from __future__ import annotations

import math
from contextlib import contextmanager

import numpy as np
from scipy.linalg import qr

from .tsk_logistic_boundary import _plain
from .tsk_logistic_joint_boundary import JointLogisticBoundaryFit, _contained, _space


class SeparableJointLogisticFit:
    parameterization = "joint_logistic_components"

    def __init__(self, design, chain_index, n, k, type_count, coefficient_bound=35., progress_callback=None,
                 analysis_workers=1):
        self.full = JointLogisticBoundaryFit(design, chain_index, n, k, type_count, coefficient_bound,
                                             analysis_workers=analysis_workers)
        for name in ("design", "chain_index", "n", "k", "type_count", "width", "coefficient_bound"):
            setattr(self, name, getattr(self.full, name))
        self.progress_callback = progress_callback
        self.state = None
        self.components = []
        self.analysis_workers = self.full.analysis_workers
        self._parallel_session_depth = 0
        self._active_parallel_engine = None
        self._active_parallel_context = None

    @contextmanager
    def parallel_session(self):
        """Reuse only one component pool at a time, within the process budget."""
        self._parallel_session_depth += 1
        try:
            yield self
        except BaseException:
            self.close(terminate=True)
            raise
        finally:
            self._parallel_session_depth -= 1
            if self._parallel_session_depth == 0:
                self.close()

    def close(self, *, terminate=False):
        for component in self.components:
            component["engine"].close(terminate=terminate)
        self.full.close(terminate=terminate)
        context, self._active_parallel_context = self._active_parallel_context, None
        self._active_parallel_engine = None
        if context is not None:
            context.__exit__(None, None, None)

    @contextmanager
    def _query_session(self, engine):
        if not self._parallel_session_depth:
            with engine.parallel_session():
                yield engine
            return
        if self._active_parallel_engine is not engine:
            self.close()
            context = engine.parallel_session()
            context.__enter__()
            self._active_parallel_engine, self._active_parallel_context = engine, context
        yield engine

    def __getstate__(self):
        state = self.__dict__.copy()
        state.update(_parallel_session_depth=0, _active_parallel_engine=None,
                     _active_parallel_context=None, progress_callback=None)
        return state

    @property
    def parallel_execution(self):
        blocks = [component["engine"].parallel_execution for component in self.components]
        return {"workers_requested": self.analysis_workers,
                "workers_used": max((block["workers_used"] for block in blocks), default=1),
                "execution_backend": "sequential_independent_blocks",
                "execution_warnings": list(dict.fromkeys(
                    warning for block in blocks for warning in block["execution_warnings"])),
                "components": blocks}

    def _partition(self):
        fitted = self.design @ self.full._design_transform
        unique, inverse = np.unique(fitted, axis=0, return_inverse=True)
        norms = np.linalg.norm(unique, axis=1)
        normalized = unique / norms[:, None]
        parent = np.arange(len(unique))

        def root(index):
            while parent[index] != index:
                parent[index] = parent[parent[index]]
                index = parent[index]
            return index

        def unite(indices):
            indices = list(indices)
            if indices:
                first = root(indices[0])
                for index in indices[1:]:
                    parent[root(index)] = first

        # A spanning set of pivot rows suffices to find the connected blocks
        # of U U^T, without allocating a quadratic instance-by-instance matrix.
        _, _, pivots = qr(normalized.T, mode="economic", pivoting=True)
        tolerance = 100 * np.finfo(float).eps * max(fitted.shape)
        for pivot in pivots[:fitted.shape[1]]:
            unite(np.flatnonzero(np.abs(normalized @ normalized[pivot]) > tolerance))
        for chain in range(len(self.n)):
            unite(np.unique(inverse[self.chain_index == chain]))
        groups = {}
        for instance, index in enumerate(inverse):
            groups.setdefault(root(index), []).append(instance)
        blocks = [np.asarray(rows, dtype=int) for rows in groups.values()]
        # Refuse a numerical split unless the fitted-logit spans form a direct
        # sum. Keeping one block is conservative in a nearly singular model.
        ranks = [len(_space(fitted[rows])[0].T) for rows in blocks]
        if sum(ranks) != fitted.shape[1]:
            return [np.arange(len(self.design))]
        return sorted(blocks, key=lambda rows: int(rows[0]))

    def _engine(self, rows):
        chains, local = np.unique(self.chain_index[rows], return_inverse=True)
        engine = JointLogisticBoundaryFit(self.design[rows], local, self.n[chains], self.k[chains],
                                           self.type_count, self.coefficient_bound,
                                           analysis_workers=self.analysis_workers)
        basis, _ = _space(self.design[rows] / self.full._column_scale)
        return {"rows": rows, "chains": chains, "engine": engine, "basis": basis}

    def _unavailable(self, component, start, error):
        """Keep numerical bookkeeping for an unavailable block, never risks."""
        engine = component["engine"]
        theta = np.asarray(start, dtype=float)
        if theta.shape != (self.width,) or not np.all(np.isfinite(theta)):
            raise ValueError("Invalid unavailable-block representative.")
        value, _, predicted, _, _ = engine._evaluate(theta)
        if not math.isfinite(value):
            theta = np.zeros(self.width)
            value, _, predicted, _, _ = engine._evaluate(theta)
        component["failure"] = str(error)
        engine.state = _plain({"converged": False, "coefficients": theta, "core_coefficients": theta,
                              "recession_direction": np.zeros(self.width), "zero_rows": [],
                              "minimum": value, "predicted": predicted,
                              "validation": {"reason_codes": ["independent_block_numerical_failure"]}})

    def _assemble(self):
        fitted = self.design @ self.full._design_transform
        def coefficients(field):
            logits = np.empty(len(self.design))
            for component in self.components:
                rows = component["rows"]
                logits[rows] = self.design[rows] @ np.asarray(component["engine"].state[field])
            result = self.full._design_transform @ (fitted.T @ logits)
            if not np.allclose(self.design @ result, logits, atol=1e-7, rtol=1e-10):
                raise RuntimeError("Independent joint blocks could not be combined without changing their logits.")
            return result
        usable = [bool(component["engine"].state.get("converged")) for component in self.components]
        zero, valid_chains = [], []
        for component, valid in zip(self.components, usable):
            if valid:
                valid_chains.extend(component["chains"].tolist())
            zero.extend(component["rows"][component["engine"].state["zero_rows"]].tolist())
        self.state = _plain({
            "version": 1, "parameterization": self.parameterization,
            "model_fingerprint": self.full._fingerprint, "type_count": self.type_count,
            "coefficient_bound": self.coefficient_bound, "converged": all(usable), "usable": any(usable),
            "partial_fit": any(usable) and not all(usable),
            "coefficients": coefficients("coefficients"), "core_coefficients": coefficients("core_coefficients"),
            "recession_direction": coefficients("recession_direction"),
            "zero_rows": sorted(zero), "active_rows": sorted(set(range(len(self.design))) - set(zero)),
            "valid_chain_indices": sorted(valid_chains),
            "components": [{"rows": component["rows"], "chains": component["chains"],
                            "state": component["engine"].state, "failure": component.get("failure")}
                           for component in self.components],
            "validation": {"reason_codes": [] if all(usable) else ["independent_component_risks_only"],
                           "likelihood_factorization_certified": True,
                           "validated_components": sum(usable), "component_count": len(usable),
                           "identifiability_scope": "Only queries entirely inside a validated independent Chain likelihood block."},
        })
        self.state["params"] = list(self.state["coefficients"])
        minimum, _, predicted, _ = self.evaluate(self.state["coefficients"])
        self.state.update(minimum=minimum, predicted=predicted.tolist())
        return self.state

    def fit(self, start):
        blocks = self._partition()
        if len(blocks) < 2:
            raise RuntimeError("Unresolved joint boundary is coupled to the remaining likelihood; no independent recovery block.")
        self.components = []
        for index, rows in enumerate(blocks):
            if self.progress_callback:
                self.progress_callback({"phase": "independent_joint_block", "block": index + 1, "count": len(blocks)})
            component = self._engine(rows)
            engine = component["engine"]
            engine.progress_callback = (lambda event, block=index + 1: self.progress_callback(
                dict(event, block=block, count=len(blocks)))) if self.progress_callback is not None else None
            try:
                state = engine.fit(start)
            except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                self._unavailable(component, start, error)
                self.components.append(component)
                continue
            finally:
                engine.progress_callback = None
            reference = engine._evaluate(np.asarray(start))[0]
            if state["minimum"] > reference + max(1e-7, abs(reference) * 32 * np.finfo(float).eps):
                state["converged"] = False
                state["validation"]["reason_codes"].append("independent_block_likelihood_not_improved")
            self.components.append(component)
        return self._assemble()

    def load_state(self, state):
        if (not isinstance(state, dict) or state.get("version") != 1
                or state.get("parameterization") != self.parameterization
                or state.get("model_fingerprint") != self.full._fingerprint):
            raise ValueError("Unsupported or stale independent joint Logistic state.")
        blocks = self._partition()
        saved = state.get("components", [])
        if len(blocks) < 2 or len(blocks) != len(saved):
            raise ValueError("Saved independent joint partition is inconsistent.")
        self.components = []
        for rows, entry in zip(blocks, saved):
            component = self._engine(rows)
            if (not np.array_equal(rows, entry.get("rows"))
                    or not np.array_equal(component["chains"], entry.get("chains"))):
                raise ValueError("Saved independent joint block is inconsistent.")
            if entry.get("failure") is not None:
                self._unavailable(component, entry["state"]["coefficients"], entry["failure"])
                if entry["state"].get("converged"):
                    raise ValueError("An unavailable block cannot have a validated fit.")
            else:
                component["engine"].load_state(entry["state"])
            self.components.append(component)
        rebuilt = self._assemble()
        for key in ("coefficients", "core_coefficients", "predicted", "minimum"):
            if not np.allclose(rebuilt[key], state.get(key), atol=1e-8, rtol=1e-12):
                raise ValueError("Saved independent joint likelihood or coefficients are inconsistent.")
        for key in ("converged", "usable", "partial_fit", "valid_chain_indices"):
            if rebuilt[key] != state.get(key):
                raise ValueError("Saved independent joint validation status is inconsistent.")
        return self

    def evaluate(self, params):
        theta = np.asarray(params, dtype=float)
        exact = self.state is not None and np.array_equal(theta, self.state["coefficients"])
        loss, gradient = 0., np.zeros(self.width)
        predicted, derivative = np.zeros(len(self.n)), np.zeros((len(self.n), self.width))
        for component in self.components:
            engine = component["engine"]
            value, grad, q, jacobian = engine.evaluate(engine.state["coefficients"] if exact else theta)
            loss += value
            gradient += grad
            predicted[component["chains"]], derivative[component["chains"]] = q, jacobian
        return float(loss), gradient, predicted, derivative

    def instance_hazards(self, params=None):
        result = np.empty(len(self.design))
        exact = params is None or np.array_equal(params, self.state["coefficients"])
        for component in self.components:
            result[component["rows"]] = component["engine"].instance_hazards(None if exact else params)
        return result

    def _component(self, vector):
        if self.state is None or not self.state.get("usable"):
            return None
        vector = np.asarray(vector, dtype=float)
        if vector.shape != (self.width,) or not np.all(np.isfinite(vector)):
            return None
        for component in self.components:
            if (component["engine"].state.get("converged")
                    and _contained(vector / self.full._column_scale, component["basis"],
                                   tolerance=8 * np.finfo(float).eps * self.width)):
                return component["engine"]
        return None

    def query_validated(self, vector):
        return self._component(vector) is not None

    def identifiable(self, params, vector):
        if self.state is None or not np.array_equal(params, self.state["coefficients"]):
            return False
        engine = self._component(vector)
        if engine is None:
            return False
        engine.progress_callback = self.progress_callback
        try:
            with self._query_session(engine):
                return engine.identifiable(engine.state["coefficients"], vector)
        finally:
            engine.progress_callback = None

    def probability(self, params, vector):
        if not self.identifiable(params, vector):
            return math.nan
        engine = self._component(vector)
        return engine.probability(engine.state["coefficients"], vector)

    def estimate_kind(self, vector):
        engine = self._component(vector)
        return engine.estimate_kind(vector) if engine is not None else "unidentifiable"

    def coefficient_identifiable(self, index):
        engine = self._component(np.eye(self.width)[index])
        return engine is not None and engine.coefficient_identifiable(index)

    def profile_interval(self, params, vector, confidence):
        if not self.identifiable(params, vector):
            raise RuntimeError("The risk does not belong to a validated independent likelihood block.")
        engine = self._component(vector)
        engine.progress_callback = self.progress_callback
        try:
            with self._query_session(engine):
                return engine.profile_interval(engine.state["coefficients"], vector, confidence)
        finally:
            engine.progress_callback = None


def joint_fit_from_state(design, chain_index, n, k, type_count, state, coefficient_bound=35.):
    if not isinstance(state, dict):
        raise ValueError("Invalid joint Logistic state.")
    cls = (SeparableJointLogisticFit if state.get("parameterization") == SeparableJointLogisticFit.parameterization
           else JointLogisticBoundaryFit)
    return cls(design, chain_index, n, k, type_count, coefficient_bound).load_state(state)
