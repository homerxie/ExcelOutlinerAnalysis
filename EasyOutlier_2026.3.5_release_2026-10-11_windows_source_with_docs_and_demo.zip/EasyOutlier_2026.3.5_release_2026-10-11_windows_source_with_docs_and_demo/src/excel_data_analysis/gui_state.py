from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile
from typing import Any
import zlib

from .tsk_result_state import decode_tsk_result, encode_tsk_result
from .tsk_run_history import decode_history, encode_history


GUI_STATE_FILENAME = ".excel_data_analysis_gui_state.json"


def gui_state_path(storage_path: str | Path) -> Path:
    return Path(storage_path) / GUI_STATE_FILENAME


def save_gui_state(
    storage_path: str | Path,
    payload: dict[str, Any],
) -> Path:
    results = payload.get("current_results")
    if isinstance(results, dict):
        results = dict(results)
        if isinstance(results.get("tsk_result"), dict):
            results["tsk_result"] = encode_tsk_result(results["tsk_result"])
        if "tsk_history" in results:
            results["tsk_history"] = encode_history(results["tsk_history"])
        payload = {**payload, "current_results": results}
    target = gui_state_path(storage_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=target.parent,
                                         prefix=".gui-state-", suffix=".tmp", delete=False) as handle:
            temporary = Path(handle.name)
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return target


def load_gui_state(
    storage_path: str | Path,
) -> dict[str, Any] | None:
    target = gui_state_path(storage_path)
    if not target.exists():
        return None
    payload = json.loads(target.read_text(encoding="utf-8"))
    results = payload.get("current_results")
    if isinstance(results, dict) and isinstance(results.get("tsk_result"), dict):
        try:
            results["tsk_result"] = decode_tsk_result(results["tsk_result"])
        except (ValueError, OSError, EOFError, KeyError, TypeError, zlib.error) as exc:
            # A damaged result must not prevent opening the database itself.
            results["tsk_result"] = None
            results["tsk_result_restore_error"] = str(exc)
    if isinstance(results, dict) and "tsk_history" in results:
        results["tsk_history"], errors = decode_history(results["tsk_history"])
        if errors:
            results["tsk_history_restore_errors"] = errors
    return payload
