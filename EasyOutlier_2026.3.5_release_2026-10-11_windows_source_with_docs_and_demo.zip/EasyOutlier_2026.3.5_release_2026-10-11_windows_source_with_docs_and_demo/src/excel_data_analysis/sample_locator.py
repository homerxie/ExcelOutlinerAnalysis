"""Compact identities for locating sample points across Plot Inspector metrics.

Only template identity dimensions participate: ``PlotPoint.sample_id`` is a
display value and can contain a concatenation of dimensions. Original point
positions are preserved, including repeated measurements and separate nodes.
The completed index retains integer arrays and distinct dimension values, not
point objects, point-sized Python containers, or references to source series.
"""

from __future__ import annotations

from concurrent.futures import CancelledError
from dataclasses import dataclass
from types import MappingProxyType
from typing import Callable, Mapping

import numpy as np

from .comparison_models import PlotSeries


_MISSING = object()
_EMPTY_INDICES = np.frombuffer(b"", dtype=np.uint32)


def _immutable_array(values: np.ndarray) -> np.ndarray:
    """Return an array whose write flag cannot be re-enabled by its caller."""
    return np.frombuffer(values.tobytes(), dtype=values.dtype).reshape(values.shape)


@dataclass(frozen=True, slots=True)
class SampleSelection:
    sample_count: int
    point_count: int
    metric_keys: frozenset[str]
    indices_by_metric: Mapping[str, tuple[np.ndarray, ...]]


class SamplePointIndex:
    """Integer-coded sample identities and original-lane point membership.

    Missing identity fields are represented by zero, distinct from the literal
    empty string. Samples with the same configured dimension values (including
    missing markers) are one identity; no unsupported identity is inferred from
    a display label or source row. Queries AND exact, case-sensitive values.
    """

    __slots__ = ("_fields", "_values", "_candidates", "_identities", "_sample_ids", "_lanes")

    @classmethod
    def build(
        cls,
        series_by_metric: dict[str, tuple[PlotSeries, ...]],
        sample_dimensions: tuple[str, ...],
        cancelled: Callable[[], bool] | None = None,
    ) -> SamplePointIndex:
        fields = tuple(sample_dimensions)
        if not fields or any(not isinstance(field, str) or not field for field in fields):
            raise ValueError("Sample dimensions must contain non-empty field names")
        if len(set(fields)) != len(fields):
            raise ValueError("Sample dimensions must be unique")

        def check_cancelled() -> None:
            if cancelled is not None and cancelled():
                raise CancelledError("Sample locator indexing cancelled")

        check_cancelled()
        point_count = sum(len(lane.points) for lanes in series_by_metric.values() for lane in lanes)
        if point_count > np.iinfo(np.uint32).max:
            raise ValueError("Sample locator supports at most 2^32 - 1 points")
        sample_ids = np.empty(point_count, dtype=np.uint32)
        values: list[dict[str, int]] = [{} for _ in fields]
        identities: dict[tuple[int, ...], int] = {}
        lane_ranges: dict[str, tuple[tuple[int, int], ...]] = {}
        offset = 0
        for metric, series in series_by_metric.items():
            check_cancelled()
            ranges: list[tuple[int, int]] = []
            for lane in series:
                check_cancelled()
                start = offset
                for point in lane.points:
                    if offset % 2048 == 0:
                        check_cancelled()
                    codes = []
                    for field, field_values in zip(fields, values):
                        value = point.dimensions.get(field, _MISSING)
                        if value is _MISSING or value is None:
                            codes.append(0)
                        else:
                            text = value if isinstance(value, str) else str(value)
                            code = field_values.get(text)
                            if code is None:
                                code = len(field_values) + 1
                                field_values[text] = code
                            codes.append(code)
                    key = tuple(codes)
                    sample_id = identities.get(key)
                    if sample_id is None:
                        sample_id = len(identities)
                        identities[key] = sample_id
                    sample_ids[offset] = sample_id
                    offset += 1
                ranges.append((start, offset))
            lane_ranges[metric] = tuple(ranges)
        check_cancelled()
        identity_array = np.asarray(tuple(identities), dtype=np.uint32).reshape((-1, len(fields)))
        index = cls()
        index._fields = fields
        index._values = tuple(MappingProxyType(field_values) for field_values in values)
        index._candidates = tuple(tuple(sorted(field_values)) for field_values in values)
        index._identities = _immutable_array(identity_array)
        index._sample_ids = _immutable_array(sample_ids)
        index._lanes = MappingProxyType(lane_ranges)
        check_cancelled()
        return index

    @property
    def fields(self) -> tuple[str, ...]:
        return self._fields

    @property
    def array_nbytes(self) -> int:
        """Retained numeric storage; approximately four bytes per source point."""
        return self._identities.nbytes + self._sample_ids.nbytes

    def values_for(self, field: str) -> tuple[str, ...]:
        try:
            field_index = self._fields.index(field)
        except ValueError as exc:
            raise ValueError(f"Unknown sample dimension: {field}") from exc
        return self._candidates[field_index]

    @staticmethod
    def _empty_selection() -> SampleSelection:
        return SampleSelection(0, 0, frozenset(), MappingProxyType({}))

    def query(self, conditions: dict[str, str]) -> SampleSelection:
        """Select exact dimension values; an empty query selects all points.

        Unknown values yield no matches. Unknown fields are caller mistakes and
        raise ValueError. Missing fields never match an explicit empty string.
        Point searches use numeric masks; source point objects are not visited.
        Only matching metrics appear in the result, preserving their lane order.
        """
        unknown = set(conditions).difference(self._fields)
        if unknown:
            raise ValueError(f"Unknown sample dimension: {sorted(unknown)[0]}")
        selected = np.ones(len(self._identities), dtype=np.bool_)
        for field, value in conditions.items():
            field_index = self._fields.index(field)
            code = self._values[field_index].get(value)
            if code is None:
                return self._empty_selection()
            selected &= self._identities[:, field_index] == code
        sample_count = int(np.count_nonzero(selected))
        if not sample_count:
            return self._empty_selection()
        indices_by_metric: dict[str, tuple[np.ndarray, ...]] = {}
        point_count = 0
        for metric, ranges in self._lanes.items():
            metric_indices = []
            metric_point_count = 0
            for start, end in ranges:
                indices = np.flatnonzero(selected[self._sample_ids[start:end]])
                metric_point_count += len(indices)
                metric_indices.append(
                    _immutable_array(indices.astype(np.uint32, copy=False)) if len(indices) else _EMPTY_INDICES
                )
            if metric_point_count:
                indices_by_metric[metric] = tuple(metric_indices)
                point_count += metric_point_count
        return SampleSelection(
            sample_count, point_count, frozenset(indices_by_metric), MappingProxyType(indices_by_metric),
        )
