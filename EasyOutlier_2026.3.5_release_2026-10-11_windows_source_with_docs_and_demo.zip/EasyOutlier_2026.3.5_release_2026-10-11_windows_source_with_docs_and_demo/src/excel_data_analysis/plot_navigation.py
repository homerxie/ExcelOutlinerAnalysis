"""Structured report scope carried from an outlier statistic to its plots."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from .models import OutlierRatioStatConfig


RATIO_FILTER_FIELDS = (
    "group_ids", "group_display_names", "test_types", "chain_names",
    "column_names", "units", "logical_metrics",
)


def ratio_filter_payload(config: OutlierRatioStatConfig) -> dict[str, list[str]]:
    """Canonicalize legacy aliases without parsing user-facing filter text."""
    fields = {name: list(getattr(config, name)) for name in RATIO_FILTER_FIELDS}
    fields["chain_names"] = list(config.chain_names or config.chains)
    fields["column_names"] = list(config.column_names or config.raw_columns)
    return fields


def ratio_filter_from_navigation(navigation: Mapping[str, Any]) -> OutlierRatioStatConfig:
    """Restore only the pre-merge column filter; grouping does not narrow it."""
    payload = navigation.get("filter_config", {})
    if not isinstance(payload, Mapping):
        raise ValueError("Plot navigation filter_config must be a mapping.")
    fields: dict[str, list[str]] = {}
    for name in RATIO_FILTER_FIELDS:
        values = payload.get(name, [])
        if not isinstance(values, (list, tuple)) or any(not isinstance(value, str) for value in values):
            raise ValueError(f"Plot navigation {name} must be a list of strings.")
        fields[name] = list(values)
    return OutlierRatioStatConfig(id=str(navigation.get("id", "plot-navigation")), **fields)
