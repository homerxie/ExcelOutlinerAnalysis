# Easy Outlier

文档核对日期：2026-09-20；对应当前源码与 schema_version=3 模板。

Easy Outlier 是面向 Excel/CSV 测试数据的桌面分析工具，支持按模板解析数据、生成 Golden、检测异常、比较历史可靠性节点，并导出报表。提供 PySide6 GUI 和 CLI，支持 macOS 和 Windows。

主要功能：

- 支持多表头 `xlsx` 输入
- 支持模板文件使用 `json` 或“人类更易编辑”的 `xlsx`
- 支持从 `recordName` 这类复合字段拆出 `SampleID / node / repeat`
- 支持按链路、测试条件、重复次数重排结果列
- 分析与 Excel 导出分开；运行时可选择同时导出 `_data.xlsx` 和／或 `_outlier.xlsx`，也可分析完成后按关注的节点、样品与链路单独导出
- 支持把 golden、阈值、node 顺序、outlier 判定标准放进模板 JSON
- 支持 `node_orders` 多 sequence，并用于 `Outlier Summary` 的 `New / Existed` 判定
- 支持导入时先做数值文本清洗，例如去掉单位、逗号，同时保留科学记数法 `10E-3`
- 支持 `outlier_ratio_stats` 按单个或多个行维度联合分组，例如 `reliability_node + lot_id`
- 独立的 **TSK Analysis** 页可根据 Chain 的 Fail/Pass 和模板中的物理实例组成估计 TSK 单实例异常风险，支持可选 XY/数值特征、95% 区间、概率条形图、Chain 拟合偏差、XLSX 导出及单文件离线 HTML 报告；普通 Analyze 不会运行这项估计。快速体验见 [TSK 假设数据示例](examples/tsk_risk_demo/README.md)，统计口径见 [TSK 使用说明](docs/tsk-risk-analysis.md)，详细推导见 [TSK 概率估算数学原理](docs/tsk-probability-estimation-mathematics.md)。

新版模板使用 Initial / Final 行列合并命名，层级表示“合并后保留到哪一层”。GUI 按 Merge Order 横向排列 2×4 个层级和判据选择框，Final 目标由节点与 Chain 角色固定；同层时 Final 判据锁定并跟随 Initial。旧模板首次使用时提示升级并备份，跨 Chain 的旧边界须确认修正。

## 功能范围

- 支持 `csv` 和 `xlsx`
- 支持多行表头和列乱序的 `xlsx`
- 横向模板定义
  - 哪些列属于同一类数据并应合并分析
  - 哪些列要分别分析但在结果中一起呈现
- 纵向模板定义
  - 哪些列代表样品编号、可靠性节点、重复次序，以及更多层级维度
  - 哪些字段需要从同一个 `recordName` 拆出来
- 支持历史数据仓库存档
  - 后续导入新的可靠性节点后，可以与历史数据联动分析
- 支持两类异常策略
  - `golden reference`
  - `modified z-score`
- 支持面向芯片可靠性报告的多 sheet Excel 导出

## 模板编辑与运行

窗口顶部默认锁定模板相关设置。点击“解锁编辑”，阅读谨慎编辑提醒后可修改数值清理、Golden 参数和 Analyze 设置；两个 Template Convert 按钮也必须解锁后才可用，并按当前模板格式启用对应方向。

点击 Import、Build Golden 或 Analyze 会立即锁回，即使随后取消或校验失败也保持锁定。锁回保留当前修改，不自动保存模板。Analyze 设置与模板不同时，可选择“仅本次运行”“保存到模板并运行”“恢复模板配置并运行”或“取消”；Import 和 Build Golden 使用 Yes / No / Cancel 提示，分别表示保存到模板、仅本次使用或取消。

路径选择、分析范围及运行按钮不受模板编辑锁影响；任务运行期间仍会禁用工作区操作。修改 Unique Sample ID Fields、Reliability Node Row Level 或 Chain Column Level 不会自动修改 Golden 的 Reference Dims，具体区别见下方 Golden Reference 说明。

如果模板文件中同方向 Initial 与 Final 已经同层，但 any_fail / all_fail 不一致，Validate Template 会报错。打开或使用模板时，GUI 会列出冲突，要求明确选择统一判据并“保存到当前模板并继续”；未选择时不能保存，取消则保留原文件和原配置。

## 计算资源设置

顶部菜单 **设置 → 计算资源…** 可选择“自动”或自定义各项任务的多进程计算核心数上限。默认保留现有自动策略；自定义上限不会强制小任务开启并行，也不会增加原有阶段的自动进程数。设为 1 时顺序计算。可选范围受本机逻辑核心数及平台限制。

该设置统一约束 TSK 节点／批次拟合、类型区间、特征删组、边界模拟、类别组合、对比图绘制和报表写入。设置自动保存到程序偏好中，重新启动仍有效；对后续分析任务及新打开的绘图窗口生效，当前任务保持原设置。它是各任务的进程上限，不是多个独立窗口合计的 CPU 配额。

自由边界模拟会先做原样本拟合、删特征拟合及预测可识别性检查，再开始模拟次数计数。这些前置步骤按阶段显示；`0/999` 本身不能说明多进程未启动或失效。进入模拟后会显示进程数、实际完成数和按顺序确认数；后续任务可以先完成，统计结果仍按固定随机顺序确认。最后的 TSK × 类别组合计算同样按实际完成情况更新进度并补充任务，输出顺序保持不变。缺少 `threadpoolctl` 会在创建计算池前报告安装方法；进程故障转串行时会明确记录原因。

窗口打开后，程序的 Python 标准输出、标准错误及终端 logging 会同步到 **Log**，包括后台线程、分析进程、TSK 计算进程、报表进程和绘图进程，原终端继续保留输出。日志批量刷新以减少对界面响应的影响。macOS 的原生 stdout/stderr 和 Windows 文件／管道输出也会转发；Windows 原生库直接写控制台的内容仍可能只出现在 Terminal，尚不能保证全部捕获。

## 跨平台与打包

当前代码已经按 `macOS + Windows` 两端可运行来整理：

- 运行时路径改成 `pathlib`
- GUI 默认数据库目录使用程序目录下的 `tempDatabase/`
- GUI 默认模板使用包内自带模板，因此 PyInstaller 打包后仍可直接启动
- 保存时，用户模板、输入文件、Golden、Result 以及数据库导入记录中的来源路径都以 database 为基准记录相对位置（同级目录使用 `../`）；保持相对目录结构一起移动后，重新打开数据库会自动定位。包内默认模板仍随程序定位，Windows 不同盘符之间保留绝对路径
- 打开数据库时，找不到关联模板、输入文件或 Golden 会弹出重定位窗口；成功打开后记住新位置。输入文件和 Golden 可选择“暂不关联”，已有导入数据不受影响；Result 是输出位置，无需预先存在
- 所有文件／文件夹选择窗口使用系统原生对话框；Browse 检查旧起始目录超时后回退到程序目录，系统对话框自身的网络响应由操作系统处理
- 模板和数据库的打开过程使用后台线程，底部进度条与状态栏显示当前阶段，完成后统一刷新 GUI；失败或取消保留原工作区
- 提供了独立的 PyInstaller spec：
  - `excel-data-analysis-gui.spec`
  - `excel-data-analysis-cli.spec`

注意：

- `PyInstaller` 需要在目标平台各自打包，不能在 macOS 上直接产出 Windows 可执行文件，反之亦然
- 也就是说：
  - macOS 包请在 macOS 上构建
  - Windows 包请在 Windows 上构建

## 核心概念

### 1. 行维度 `row_dimensions`

用于告诉系统，每一行的前几列文本里，哪些列表示什么业务含义。

现在 `row_dimensions` 支持一个维度挂多个 `sources`。每个 source 可以单独配置：

- `column`
- `default_split_position`
- `split_delimiters`
- `skip_empty_parts`

这样可以实现：

- 同一个维度值从多个原始列取值
- 每个原始列先按不同 delimiter 拆分
- 再把多个 source 的结果按顺序重组成同一个维度
- 同一个 source 按另一列的值动态选择 split 位置

示例：

- `sample_id`：样品编号
- `reliability_node`：可靠性节点/轮次
- `repeat_id`：同一样品同一节点下的重复测试次数
- `site_id`：第四层维度，例如 site、链路、腔体等

补充：

- 如果某个维度来自同一列，但不同 `Site`、`Channel` 或其他条件下要取不同片段，现在可以配置：
  - `split_position_by_column`
  - `split_position_map`
- 例如：
  - `Site=1` 时取第 0 段
  - `Site=2` 时取第 1 段
  - `Site=3` 时取第 2 段
- 如果没有命中映射，会回退到默认的 `default_split_position`
- 如果 `repeat_id` 最终提取结果出现缺失、非数字、重复或不连续，程序会在同一组样品属性内部按行顺序自动重编号为 `1..N`

### 2. 分析组 `analysis_groups`

用于描述横向测试项目该如何分析。

- 现在结果表头的横向层级不再由程序从列名解析
- 必须在 template 里显式定义：
  - `column_header_levels`
  - 每个 raw column 对应的 `header_values`
- 程序会严格按模板给出的层级顺序展示和排序

- `pooled_columns`
  - 多列本质上是同一逻辑测项，比如同一电阻在固定条件下重复测 3 次
  - 这几列会被当成同一类数据做分析
- `per_column`
  - 多列需要分别分析，比如电阻、电流、电压、电容
  - 但它们仍然可以通过第一层 header value 被摆在一起展示

### 3. Golden Reference

从某个基准轮次或基准样品生成长期可复用的 golden 文件。

常见做法：

- Reference Dims 填 `lot_id,sample_id`，按 Lot 和样品分别建立基准；仅当样品编号在所有 Lot 中唯一，或确实需要跨 Lot 共用基准时，才只填 `sample_id`
- Filters 填 `reliability_node=T0`，仅用基准节点的数据计算 Golden；自定义节点字段为 `stage` 时应填写 `stage=T0`
- Golden 按 Reference Dims、逻辑测项及分析组组织计算，使用 Filters、中心值和阈值规则生成允许范围

**Golden 与 Analyze 的三个设置相互独立：** Unique Sample ID Fields 用于识别样品和关联历史；Reliability Node Row Level 用于节点筛选和行合并；Chain Column Level 用于列合并。它们不改变 Golden 的 Reference Dims，也不会重算已有 Golden。Analyze 匹配 Golden 时使用 Golden 文件内保存的 reference_dimensions 和逻辑测项。因此，唯一 ID 加入 Lot 后，若希望 Golden 也区分 Lot，需要另外修改 Reference Dims 并重新 Build Golden。

当前 built golden 的判定规则不再使用 `hybrid` 这种固定词，而是统一使用显式表达式：

- 任意由 `relative`、`sigma`、`absolute`、`and`、`or`、括号组成的表达式

例如：

- `relative`
- `sigma`
- `absolute`
- `relative and sigma`
- `relative or absolute`
- `relative or (sigma and absolute)`
- `relative or ((sigma and absolute) or (absolute and relative))`

含义：

- `relative`
  - 用相对偏差百分比判断
- `sigma`
  - 用 sigma 倍数判断
- `absolute`
  - 用绝对上下界判断
- `and`
  - 必须同时满足两边规则
- `or`
  - 满足任意一边规则即可
- 下拉框或文档里出现的组合只是示例，不是完整枚举

built golden 的默认值来源现在也是统一的：

- 全局默认来自 `golden_reference_defaults`
- 如果某个 `analysis_groups[*]` 显式定义了：
  - `outlier_golden_method`
  - `golden_relative_limit`
  - `golden_sigma_multiplier`
  - `golden_absolute_lower_bound`
  - `golden_absolute_upper_bound`
  - `golden_overwrite_lowerbound` / `golden_overwrite_upperbound`
  - `golden_continuous_interval`
  - `golden_empty_range_fallback_to_absolute`
  那么这个 analysis group 会优先使用自己的定义，不再读取 GUI / 全局默认

### 4. Node Sequences

`node_orders` 用来定义 node 的先后顺序，支持多条 sequence，例如：

```json
"node_orders": [
  ["T0", "T1", "T2"],
  ["T0", "T3", "T4"]
]
```

它主要影响：

- 行排序
- `Outlier Summary` 中 node 的展示顺序
- `New / Existed` 的判断逻辑

当前 `New / Existed` 的规则是：

- 先按当前 node 所在 sequence 往前找
- 如果上一项 node 不存在于当前 sample，就继续往前找更早 node
- 一旦找到同一条 chain 在更早 node 已经 fail，就判 `Existed`
- 如果一路都找不到，才判 `New`

这能覆盖“中间 node 缺失，但更早 node 已经失效”的情况。

### 5. Numeric Cleanup

如果输入表里的数值列可能带单位、逗号或其他文本，可以在 template 或 GUI 里开启 `numeric_cleanup`。

支持两种模式：

- `all_non_numeric`
  - 自动去掉大多数非数字字符
  - 适合例如 `1,234mV`
- `specified_chars`
  - 只去掉你明确指定的字符或字符串
  - 适合例如只去掉 `mV`、`%`、`,` 等

补充：

- 清洗时会保留合法科学记数法里的 `E/e`
- 例如：
  - `10E-3`
  - `-1.25e-3A`
  - `10E-3mA`
  都可以被正确解析成数字

### 6. Modified Z-Score

不使用 golden reference，直接在某个大池子内找异常值。适合：

- 没有参考轮次时
- 想先做总体异常扫描时

## 快速开始

### 1. 安装

```bash
python -m pip install -e .
```

如果你只是先在仓库里直接试跑，还没做安装，也可以使用开发态方式：

```bash
PYTHONPATH=src python -m excel_data_analysis.cli --help
```

### 1.1 启动 GUI

macOS / Linux:

```bash
source .venv/bin/activate
easy-outlier-gui
```

Windows CMD:

```bat
.venv\Scripts\activate
easy-outlier-gui
```

Windows PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
easy-outlier-gui
```

点击 **Run Analysis** 会先询问是否同时输出 **Outlier Excel** 和 **Data Excel**，两项默认都勾选，也可分别取消；均不勾选时只分析。勾选 Outlier Excel 后，立即选择导出范围，默认「全部结果」，保持原有完整输出。所选导出的范围和已有输出文件的处理方式（例如是否覆盖）都会在分析开始前确认；确认完成后才运行分析，完成后自动输出所选 Excel 文件，不再弹出范围选择或覆盖确认窗口。分析完成后也可使用 **Export Outlier Excel…** 或 **Export Data Excel** 单独输出，不重复计算。Outlier 导出可以选择全部结果，或勾选节点后仅输出：

- 这些节点原本判定为 `New` 的样品＋链路；例如第三个节点只有 A 样品的链路 1 新增失效，则只带出 A／链路 1 在本次分析全部节点的数据。
- 这些节点出现 `New` 的样品的所有失效链路；例如 A／链路 1 新增，则也带出 A 的其他曾失效链路。

节点选择仅决定导出哪些样品和链路，保留它们在本次分析范围内的前后节点历史、数值及原有状态。它不是分析 Filter，不改变 Z Score 总体、合并判定或比例分母；Excel 汇总仍使用完整分析统计，并注明导出范围。每次导出使用当前会话最近一次完成的分析快照，调整设置后需再次 Run Analysis 才会产生新结果。重新打开数据库后，已保存的汇总仍可查看，Excel 导出需要重新运行分析。输出文件使用 Report Output File 的名称加 `_outlier.xlsx` 或 `_data.xlsx`；CLI `generate-report` 保持一次生成两份工作簿的行为。

Plot Inspector 按需生成并缓存可见图片，使用最多四个独立进程绘图，同时减少悬停索引的对象分配；拖动窗口时先复用已有图片，停止调整后更新清晰内容。120 万点的原生窗口验证与复现方式见 [渲染性能示例](examples/plot_inspector_render_benchmark/README.md)。

图中蓝色框表示 Z Score 正常范围，浅绿色区域表示 Golden 允许范围。仅选 Z Score 时只画蓝框；仅选 Golden 时只画绿色区域；AND / OR 组合时分别显示两者，异常点仍按组合判据着色。蓝框使用本次判定的中位数、MAD 和阈值；不同基准分别画框，悬停数据点可查看对应范围。样本不足 3 或 MAD 为 0 时沿用现有判定规则，蓝线延伸至视口两端，不表示有限边界。

在图的横轴或数据区使用 **Ctrl + 滚轮／双指滑动**，或触控板双指捏合，可围绕鼠标位置缩放当前链路的横轴，同一图的各节点共用范围；macOS 也支持 Command。按住修饰键时显示水平缩放的放大镜鼠标。默认显示箭头，普通左键不会平移；在数据区按住 **Alt（macOS Option）** 显示平移手形，配合左键左右拖动可平移当前图的横轴。拖动时显示抓手，松开 Alt 立即退出平移。普通双指滑动仍用于滚动列表，双击图中空白处恢复自动范围。连续输入会合并为最新范围，只由后台重绘当前图；新图完成前保留旧图和对应刻度，悬停详情在新图完成后恢复。

Ridge 密度按所有原始点的真实数值计算，边界三角形只表示范围外还有数据，不参与边界密度堆积。曲线保留全部分段线性转折点，缩放时按当前坐标映射可见部分，不把完整范围压成固定数量的粗格子；远端异常值不会降低中心曲线的分辨率。平滑尺度由原始数据决定，缩放不改变统计分布。密度在后台计算并缓存，缩放和平移复用同一条曲线。

Matched Metrics 下方的 **Sample Locator · 样品定位** 使用模板的样品身份维度（`sample_dimension_names`）。选择维度并输入完整值后点击 Locate；用 Set Condition 添加多个维度时按 AND 精确匹配，区分大小写并保留编号中的前导零。候选值来自当前绘图数据。只填 Sample ID 时可同时命中不同批次的重号样品，状态栏显示匹配样品数，以及当前展示的图数和标记点数。定位在现有数据筛选、测项搜索和勾选范围内保留包含目标点的图，图内其他样品和已选节点仍保留作比较；Clear 清除样品条件并恢复展示范围。

目标样品的点显示黄色空心圆；坐标轴边缘的压缩三角形显示黄色三角形外框。双击边缘三角形会展开该侧全部数据点，另一侧范围保持原样，黄色标记跟随对应点；在图中普通位置双击可恢复自动范围。样品定位复用背景图片，只在可见区域叠加标记；首次加载及数据筛选变更后的样品索引在后台准备。

**Outlier Summary → Plot Inspector**：统计表右侧 Sample IDs 列以分号分隔样品编号。直接点击单个带下划线的编号，即可跳转并标黄；分号、身份后缀和单元格空白处不带下划线或手形光标，不触发跳转。前导零保留，同号但完整身份不同的样品会在表内用普通文本后缀区分，无需选择弹窗。Inspector 自动选中该统计项对应的链路、滚动到相关节点并标黄该样品，保留其他样品和节点作对照；合并失效保留参与判定的相关列，恢复项保留历史链路。空值导致的失效没有可绘制点时会明确说明。

联动沿用生成统计时的模板和分析范围，统计项的列筛选在原总体的分数计算之后应用，保持报告的合并判定含义。Summary Link 区域显示来源与筛选条件，可用 Reset Summary Link 取消联动范围。同一范围内切换样品复用已有窗口与图片。保存及另存数据库会迁移有效链接；旧结果缺少导航信息，或数据库/Golden 文件已发生变化时，需要重新 Analyze。

打包桌面版前可先安装构建依赖：

```bash
python -m pip install -e ".[build]"
```

### 1.2 用 PyInstaller 打包

GUI 桌面版：

```bash
pyinstaller excel-data-analysis-gui.spec
```

CLI 独立可执行版：

```bash
pyinstaller excel-data-analysis-cli.spec
```

产物默认会出现在：

- `dist/EasyOutlier/` 或 `dist/EasyOutlier.app`
- `dist/easy-outlier`

Windows GUI 的图标资源由打包配置自动收集。运行时会从 PyInstaller 的资源目录（例如 `_internal/icon`）读取，无需手动复制 `icon` 到 `.exe` 同级目录；旧版同级 `icon` 目录仍兼容。分发时请保留完整的 `dist/EasyOutlier` 文件夹。

打包后的 GUI 默认行为：

- 内置一份 JSON 模板
- 默认数据库目录位于程序目录下的 `tempDatabase/`
- 默认分析结果目录位于当前数据库下的 `result/`
- TSK 结果新增“特征影响”页，按节点／批次展示特征整体删组似然比检验、档位系数／OR 区间及两两比较；Holm 校正后的 p 值用于显著性判断，逐项区间单独标注。删去特征后的实例预测变化用于衡量模型变化，不等同于因果影响或实测验证。新分析自动计算，保存快照、XLSX 和 HTML 导出保留结果；旧结果需重新分析才有此报告。
- TSK 结果按“风险结果 → 拟合检查 → 联合风险 → 特征影响 → 模型与诊断”展示；条形图、热力图和明细表共享风险筛选。
- **TSK Analysis** 最底部的“保存结果为 HTML”可导出所有节点／批次的已计算展示结果；单文件在浏览器中离线查看，支持筛选、排序、热力图换轴和分页，也支持重新打开的历史结果。
- TSK 分析及组合计算完成后，自动将精简、压缩的结果快照保存在数据库的 `.excel_data_analysis_gui_state.json`；重新打开可直接查看风险、区间、特征、联合风险及已计算的组合。快照不保存逐样品记录和拟合矩阵；重新打开后补算完整组合或改变外推策略需重新运行 TSK 分析
- 数据修改先写入当前数据库下的 `temp/` 工作区，保存后再合并回数据库根目录

如果还没做 editable install，也可以：

macOS / Linux:

```bash
source .venv/bin/activate
PYTHONPATH=src python -m excel_data_analysis.gui_main
```

Windows CMD:

```bat
.venv\Scripts\activate
set PYTHONPATH=src
python -m excel_data_analysis.gui_main
```

Windows PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
$env:PYTHONPATH = "src"
python -m excel_data_analysis.gui_main
```

### 1.3 Windows 一键安装

如果你要在 Windows 上快速试运行，直接在项目根目录双击：

```bat
setup_windows.bat
```

它会自动：

- 检查是否已有 Python 3.10+
- 如果没有，先尝试自动安装 Python
- 在当前项目目录下创建 `.venv`
- 安装 `requirements.txt` 中的依赖
- 使用同一虚拟环境运行 `pip check` 并实际导入全部运行依赖，含 `threadpoolctl` 和 NumPy / SciPy / Qt 的计算及界面模块

安装完成后可用下面命令启动 GUI：

```bat
.venv\Scripts\python -m excel_data_analysis.gui_main
```

更新源码后，已有虚拟环境也需要更新依赖。在项目目录用 PowerShell 执行：

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pip check
.\.venv\Scripts\python.exe -m excel_data_analysis.dependency_check
.\.venv\Scripts\python.exe -m excel_data_analysis.gui_main
```

请使用 `easy-outlier-gui` 或 `-m excel_data_analysis.gui_main` 启动。这个入口会先处理多进程启动，再加载界面，避免每个数值计算子进程重复加载 GUI。若提示缺少 `threadpoolctl`，应给启动程序的同一个 Python 环境安装依赖；仅复制新源码不会更新旧虚拟环境。

如果后面还要测试 PyInstaller 打包，再额外执行：

```bat
.venv\Scripts\python -m pip install -r requirements-build.txt
```

也可以直接双击：

```bat
build_windows.bat
```

它会自动：

- 检查并创建 `.venv`
- 安装 `requirements-build.txt`
- 构建 GUI 包
- 构建 CLI 包

默认输出在：

- `dist\EasyOutlier`
- `dist\easy-outlier`

## GUI 教程

如果你主要通过桌面界面操作，建议先看这份说明：

- [GUI 教程（Markdown）](GUI_tutorial_v2.md)
- [GUI 教程（可直接用浏览器打开）](GUI_tutorial_v2.html)
- [模板参数说明](template_help_v2.md)

### 2. 导入数据到本地历史仓库

这里的 `--storage` 就是一套独立数据库的目录。  
如果你要维护多套数据库，直接使用不同的目录即可，例如 `.eda_store/project_a`、`.eda_store/project_b`。

```bash
easy-outlier import-data \
  --template src/excel_data_analysis/assets/templates/chip_reliability_template.json \
  --input /path/to/data.xlsx \
  --storage .eda_store/project_a
```

模板路径也可以直接换成 `src/excel_data_analysis/assets/templates/chip_reliability_template.xlsx`。

如果导入文件和当前数据库里已有数据出现同样的 sample/node/site... 键：

- `--conflict-mode error`
  - 默认模式，先报冲突，不写入
- `--conflict-mode replace`
  - 删掉当前数据库里同键的旧数据，再导入新数据
- `--conflict-mode append`
  - 保留旧数据，并把新数据的 `repeat_id` 继续往后累加

```bash
easy-outlier import-data \
  --template src/excel_data_analysis/assets/templates/chip_reliability_template.json \
  --input /path/to/data.xlsx \
  --storage .eda_store/project_a \
  --conflict-mode append
```

导入前也可以先预览冲突：

```bash
easy-outlier preview-import \
  --template src/excel_data_analysis/assets/templates/chip_reliability_template.json \
  --input /path/to/data.xlsx \
  --storage .eda_store/project_a
```

查看当前数据库里已经有哪些数据：

```bash
easy-outlier show-storage \
  --template src/excel_data_analysis/assets/templates/chip_reliability_template.json \
  --storage .eda_store/project_a \
  --limit 200
```

### 3. 基于某个节点构建 golden

下面例子表示：

- 用 `lot_id,sample_id` 作为 golden key，区分不同 Lot 的同名样品
- 只使用 `reliability_node=T0` 的数据建 golden
- 默认规则使用 `relative or (sigma and absolute)`
- 这里只是示例，实际也可以换成任意合法表达式
- 默认参数来自 template
- 如果某个 `analysis_group` 自己定义了 golden rule，就优先用那个 group 自己的规则

```bash
easy-outlier build-golden \
  --template src/excel_data_analysis/assets/templates/chip_reliability_template.json \
  --storage .eda_store/project_a \
  --name chip_t0_golden \
  --reference-dims lot_id,sample_id \
  --filter reliability_node=T0 \
  --center-method mean \
  --outlier-golden-method "relative or (sigma and absolute)" \
  --relative-limit 0.2 \
  --sigma-multiplier 3 \
  --absolute-lower-bound 80 \
  --absolute-upper-bound 120
```

`--center-method` 当前支持：

- `mean`
- `median`

`build-golden` 里这几个参数的关系是：

- `--template`
  - 推荐总是带上
  - 因为它会让程序同时读取 template 里的全局默认值和 `analysis_groups` 局部 override
- `--outlier-golden-method`
  - 控制全局默认方法
- `--relative-limit`
  - 当方法里出现 `relative` 时使用
- `--sigma-multiplier`
  - 当方法里出现 `sigma` 时使用
- `--absolute-lower-bound` / `--absolute-upper-bound`
  - 当方法里出现 `absolute` 时使用

如果你只想用 template 里已经写好的默认值，也可以少传这些参数，只保留：

```bash
easy-outlier build-golden \
  --template src/excel_data_analysis/assets/templates/chip_reliability_template.json \
  --storage .eda_store/project_a \
  --name chip_t0_golden \
  --reference-dims lot_id,sample_id \
  --filter reliability_node=T0
```

### 4. 查看数据库导入历史

```bash
easy-outlier show-imports \
  --storage .eda_store/project_a
```

### 5. 直接从数据库生成真实芯片报表

整库导出：

```bash
easy-outlier generate-report \
  --template src/excel_data_analysis/assets/templates/chip_reliability_template.json \
  --storage .eda_store/project_a \
  --golden .eda_store/project_a/golden/chip_t0_golden.json \
  --output examples/sample_chip_data_real_result.xlsx
```

只导出某几个 sample / node：

```bash
easy-outlier generate-report \
  --template src/excel_data_analysis/assets/templates/chip_reliability_template.json \
  --storage .eda_store/project_a \
  --sample-ids "LotA:S001,S002" \
  --nodes T0,T1 \
  --golden .eda_store/project_a/golden/chip_t0_golden.json \
  --output examples/sample_chip_data_real_result.xlsx
```

### 6. 直接生成真实芯片报表

如果你的输入是像 `examples/sample_chip_data_real.xlsx` 这样带多行表头、列顺序可能打乱、`recordName` 里还塞了多个维度的真实表，直接用：

```bash
easy-outlier generate-report \
  --template src/excel_data_analysis/assets/templates/chip_reliability_template.json \
  --input examples/sample_chip_data_real.xlsx \
  --golden .eda_store/project_a/golden/chip_t0_golden.json \
  --output examples/sample_chip_data_real_result.xlsx \
  --if-exists timestamp \
  --outlier-fail-mode zscore_or_golden
```

输出路径是文件名前缀。例如指定 `report.xlsx`，会生成：

| 文件 | Sheet | 内容 |
| --- | --- | --- |
| `report_data.xlsx` | `Sorted` | 排序后的完整数据和行列表头 |
| 同上 | `deviation-zscore`、`deviation-golden` | 各测试点的偏差与阈值 |
| 同上 | `golden-by-point`（按需生成） | 同一测试列不同点采用不同 Golden 中心值时，展示逐点基准 |
| `report_outlier.xlsx` | `Outlier Summary` | 汇总数量、比例、节点序列与相关提示 |
| 同上 | `all outliers` | 某个样品的某条 Chain 有任意原始测试点判为 fail 时，带出该样品、该 Chain 在当前分析范围内的各节点数据 |
| 同上 | `merged outlier` | 某个样品的某条 Chain 经 Merge Order 和四个合并判据处理后，有节点最终 fail 时，带出该样品、该 Chain 的各节点数据 |

因此，异常表中可以有用于历史对比的全 PASS 节点；但如果当前范围内只有一个节点，该样品、该 Chain 的所有原始测试点都 PASS，也没有按配置计为 fail 的空白/非数字测试格，就不应仅因其他 Lot 存在同名样品而被带入。样品唯一 ID 必须包含 Lot 等节点上方的分组维度。

报表里：

- `deviation-zscore` 和 `deviation-golden` 都会始终输出
- 两类偏差各自超 threshold 时都会标红
- 异常表的原始测试点 `Pass/Fail` 按 Outlier Criteria 选择判定标准：
  - `modified_z_score`
  - `golden_deviation`
  - `zscore_and_golden`
  - `zscore_or_golden`

使用 Z Score（包括 AND / OR 组合）时，Golden 页中的 **Use Golden Range for Z Score** 默认勾选。Build Golden 会按 Golden 的筛选范围、Reference Dims 和测项分组计算中位数与 MAD，并写入 Golden JSON 和配套 Excel 的 `zscore_median`、`zscore_mad` 列。分析、Plot Inspector 和 TSK 使用这份固定基准，改变分析范围不会重新拟合基准。旧 Golden 文件缺少这些统计值时，需要重新 Build Golden。

取消勾选后，恢复按本次分析范围内全部数据计算 Z Score。该选项随模板和数据库设置保存；JSON 字段为 `report.zscore_use_golden_reference`，Excel 模板的 `template_info` 字段为 `report_zscore_use_golden_reference`，设为 `false` / `FALSE` 可关闭。仅使用 Golden Deviation 时，此选项不参与判定。

`build-golden`、`generate-report` 和模板转换命令支持以下输出文件冲突策略（`import-data` 使用前述 `--conflict-mode`）：

- `--if-exists error`
- `--if-exists overwrite`
- `--if-exists timestamp`

如果你只想先看报表里会被判成 fail 的测试点，也可以用：

```bash
easy-outlier report-failures \
  --template src/excel_data_analysis/assets/templates/chip_reliability_template.json \
  --input examples/sample_chip_data_real.xlsx \
  --golden .eda_store/project_a/golden/chip_t0_golden.json
```

## Excel 模板与 JSON 模板互转

如果你觉得 JSON 模板太冗长，现在可以直接使用 Excel 模板编辑。程序内部会把它解析成同一套 `TemplateConfig`，所以导入、建 golden、分析、报表都能直接吃 `xlsx` 模板。

当前仓库内置两种格式的模板：

- `src/excel_data_analysis/assets/templates/chip_reliability_template.json`
- `src/excel_data_analysis/assets/templates/chip_reliability_template.xlsx`

### 校验模板

```bash
easy-outlier validate-template \
  --input src/excel_data_analysis/assets/templates/chip_reliability_template.xlsx
```

### JSON 转 Excel

```bash
easy-outlier template-to-xlsx \
  --input src/excel_data_analysis/assets/templates/chip_reliability_template.json \
  --output chip_reliability_template_copy.xlsx
```

### Excel 转 JSON

```bash
easy-outlier template-to-json \
  --input src/excel_data_analysis/assets/templates/chip_reliability_template.xlsx \
  --output chip_reliability_template_copy.json
```

Excel 模板当前包含这些 sheet：

- `template_info`
- `row_dimensions`
- `column_header_levels`
- `analysis_groups`
- `node_orders`
- `analysis_dimension_filters`
- `analysis_column_filters`
- `outlier_ratio_stats`
- `README`

新的 Excel 模板会尽量避免单元格内换行：

- `row_dimensions` 会写成长表，每个 source 单独占一行，并使用 `delimiter_1 / delimiter_2 / ...`
- `analysis_groups` 会写成长表，每个 `column_name` 单独占一行，方便做漏项和唯一性校验
- `node_orders` 横向使用 `Node 1 / Node 2 / ...`；节点更多时继续向右增加 `Node 3`、`Node 4` 等列
- `analysis_groups` 的最后几列是可扩展的列表头层级。先在 `column_header_levels` 定义 Name 和 Priority，再在 `analysis_groups` 右侧增加同名列并逐行填写
- schema_version=3 的七个配置明细页，第 1 行是中文填写说明，第 2 行是英文表头，第 3 行起填写数据，前两行冻结；`template_info` 使用 Notes 列说明
- 旧模板使用时提示升级并备份；新版保留层级不会被再次按旧起点转换

如果同一套模板里可能出现多种节点路径，例如：

- `T0 -> T1 -> T2`
- `T0 -> T1 -> T3 -> T4`

可以改用：

```json
"report": {
  "node_orders": [
    ["T0", "T1", "T2"],
    ["T0", "T1", "T3", "T4"]
  ]
}
```

程序会为每个 sample 自动匹配最合适的节点顺序，用于：

- 报表行排序
- 异常明细中的节点前后关系判断
- `Outlier Summary` 中“从哪个 node 开始失效”的排序与展示

Excel 模板里：

- `row_dimensions` sheet：一行表示一个 source
- `node_orders` sheet：一行表示一条 sequence，每个 node 单独占一个单元格

## 目录结构

```text
src/excel_data_analysis/
  analyzer.py        # 统计分析核心
  cli.py             # 命令行入口
  io.py              # Excel/CSV 读取与数值转换
  models.py          # 领域模型
  repository.py      # 本地历史仓库
  template.py        # 模板加载与校验
  exporters.py       # JSON / Excel 导出
  service.py         # GUI/CLI 共用业务入口
  gui/app.py         # PySide6 GUI 主程序
  gui/main_window.ui # Qt Designer UI 文件
  gui/ui_main_window.py
src/excel_data_analysis/assets/templates/
  chip_reliability_template.json
  chip_reliability_template.xlsx
```

## GUI 开发约定

GUI 相关文件建议按下面的职责分层：

- [main_window.ui](src/excel_data_analysis/gui/main_window.ui)
  - Qt Designer 的布局真源。所有 UI 修改必须先修改对应 `.ui`，再使用 `pyside6-uic` 生成 Python。
- [ui_main_window.py](src/excel_data_analysis/gui/ui_main_window.py)
  - 由 `.ui` 自动生成
  - 禁止手改生成文件。新增控件、标签、布局及尺寸设置均在 `.ui` 定义。
- [app.py](src/excel_data_analysis/gui/app.py)
  - 放事件绑定、状态切换、业务逻辑、弹窗、导入导出等 `.ui` 不适合表达的行为

重新生成 `ui_main_window.py` 的命令：

```bash
./.venv/bin/pyside6-uic \
  src/excel_data_analysis/gui/main_window.ui \
  -o src/excel_data_analysis/gui/ui_main_window.py
```

## 注意

- `xlsx` 读取依赖 `openpyxl`
- GUI 现在支持模板校验、`json/xlsx` 双向转换，以及直接加载 Excel 模板
- 新模板通过 `report.node_orders` / Excel 的 `node_orders` 页配置节点序列；旧 `node_order` 仅兼容读取，升级后不再输出该冗余字段
- 真实芯片报表导出依赖模板里的 `report` 配置
- `report.sample_dimension_names` 必须显式指向一个或多个 `row_dimensions.name`，用于 Outlier Summary、样品聚合和 node-order 比较
- `report.reliability_node_dimension` 指定代表可靠性节点的内部维度名称，默认 `reliability_node`，也可设为 `stage` 等自定义名称。
- 样品唯一 ID 是 `sample_dimension_names` 指定字段按顺序组成的元组，不自动补齐。它必须明确包含所选节点上方所有分组维度，且不包含节点及下方 site/repeat；不一致时阻止分析，避免跨批次覆盖。例如 `lot_id → sample_id → stage → repeat_id` 应配置 `reliability_node_dimension=stage`、`sample_dimension_names=lot_id;sample_id`。
- Analyze And Export 顶部提供 **Unique Sample ID Fields**、**Reliability Node Row Level** 和 **Chain Column Level**。运行时统一处理与模板的差异：仅本次运行、保存到模板并运行、恢复模板配置并运行或取消，无需单独确认保存。行字段名必须与 `row_dimensions.name` 一致；`display_name` 只用于显示。
- `test_data_start_row` 现在必须显式写在 template 里，程序不再自动推断
- 新版合并判据是 `initial_column_merge_fail_rule`、`final_column_merge_fail_rule`、`initial_row_merge_fail_rule`、`final_row_merge_fail_rule`，分别控制四个步骤的 any_fail / all_fail 聚合
- `initial_row_merge_level` 和 `initial_column_merge_level` 表示合并后保留到哪一层，保留该层及更高层级，可与 Final 相同；相同时只执行一次有效合并，Final 判据跟随 Initial
- Final row 固定到 `reliability_node_dimension`，Final column 固定到 `chain_column_level`，均不能单独设置合并层级；Chain 上方仍有层级时也会保留
- 旧 `outlier_merged_test_fail_rule` / `outlier_test_group_fail_rule` / `outlier_merged_sample_fail_rule` / `outlier_node_fail_rule` 兼容读取，保存或升级时输出新版名称
- 旧 `outlier_row_merge_max_dimension` / `outlier_test_merge_max_level` 表示被消掉的起点，升级时通常转换为它的上一级。若旧列起点会合掉 Chain，GUI 报错，用户确定后修正为保留 Chain；取消则不改文件
- `report.outlier_fail_method` 目前支持 `modified_z_score`、`golden_deviation`、`zscore_and_golden`、`zscore_or_golden`
- `report.outlier_merge_order` 现在支持 6 种合法执行顺序，用来调度 Initial column merge、Final column merge、Initial row merge、Final row merge；同一方向的 Initial 必须先于 Final
- `report.outlier_ratio_stats[*].group_by_dimensions` 现在必须显式写出，可使用列表头层级；行维度仅允许所选 Reliability Node Row Level 及更高层级；`site_id`、`repeat_id` 这类更低层级应该通过 filter 控制，不应该参与最终 ratio 分组
- Excel template 中凡是“一个单元格里写多个值”的地方，统一使用 `;`。例如：`lot_id;sample_id`、`reliability_node;lot_id`、`reliability_node=T0;site_id=A`
- 测量数据库默认保存为 `measurements.jsonl.gz`：按批次保存来源，复用测试定义，按原始行保存维度和有序测试值，再用 gzip 等级 6 无损压缩。数值精度、重复测量值和记录顺序保持不变。
- Windows / macOS 均由 Python 标准库处理 gzip，打包后的程序不需要用户安装 gzip、7-Zip 或其他解压工具。`datasets.jsonl` 仍保存少量导入历史信息。
- 旧 `measurements.jsonl` 可以直接读取，在追加、替换或保存数据库时自动迁移；Save As 会生成压缩的新数据库。读取时直接流式解压，不生成未压缩的临时文件。每次写入先校验临时压缩文件，再原子替换，成功后移除旧明文文件。
- 新格式带有版本号；旧版软件无法读取新压缩数据库。升级前保留需要供旧版使用的数据库副本。仅更改扩展名或解压不能转换回旧格式，因为内部结构也做了去重。
- 压缩主要优化磁盘体积与序列化内容；分析目前仍加载测量对象列表，内存不会按相同比例下降。后续如需按需查询，可进一步升级为 SQLite 等存储。
- 可用 `python scripts/benchmark_measurement_storage.py --source "旧数据库目录" --output "空的测试输出目录"` 测量体积并逐条核对往返数据；该工具不修改源数据库，输出压缩副本及 `report.json`。


### 字段名称自动匹配

引用 row 维度、column 层级或设置字段时，名称忽略大小写、空格、下划线和连字符。例如 `Chain Name`、`chain_name`、`CHAIN-NAME`、`ChainName` 可匹配同一层；`Lot ID` 可匹配 `lot_id`。中文名称保留，row 维度也可通过唯一的 Display Name 引用。

适用于 JSON/XLSX 模板、统计 Group By、统计 Filter Type、样品 ID 组成、可靠性节点、Chain 层级、新旧合并目标、Golden 参考维度及筛选、分析筛选、对比窗口字段及分组。原始数据的来源列、拆分条件列和测试列也使用此规则。模板保存时，维度引用还原为声明的 Name。

实际 Name 精确匹配优先；非精确写法若同时匹配多个字段，会报歧义并列出候选名称。筛选值、样品 ID、链路值和数据内容不会随字段名转换而改写；字段转换也不会放宽原有的层级与统计限制。
