"""Run the actual import/fitting/report path for the near-zero demo."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from excel_data_analysis.tsk_html_export import export_tsk_html
from excel_data_analysis.tsk_result_state import compact_tsk_result
from excel_data_analysis.tsk_service import analyze_tsk_workspace


def validate_demo(source, output, *, replicates=None):
    output.mkdir(parents=True, exist_ok=True)
    truth = json.loads((source / "simulation_truth.json").read_text(encoding="utf-8"))
    settings = json.loads((source / "settings_simulation.json").read_text(encoding="utf-8"))
    if replicates is not None:
        settings["simulation_replicates"] = replicates
    with (source / "expected_chain_counts.csv").open(newline="", encoding="utf-8") as handle:
        expected = {(row["Node"], row["CHAIN_ID"]): (int(row["n"]), int(row["k"])) for row in csv.DictReader(handle)}
    last = 0.

    def progress(value, message):
        nonlocal last
        now = time.monotonic()
        if now - last >= 10 or value >= 100:
            print(json.dumps({"progress": round(value, 1), "message": message}, ensure_ascii=False), flush=True)
            last = now

    summaries = []
    for mode, prefix in (("boundary_simulation", "simulation"), ("fixed_zero", "fixed_zero")):
        started = time.monotonic()
        result = analyze_tsk_workspace(template_path=str(source / "template.json"), source="input",
                                       input_path=str(source / "data.csv"), settings=dict(settings, feature_effects_mode=mode),
                                       progress_callback=progress)
        result["warnings"].insert(0, "合成验证数据：近零 TSK 真值为正；三条边界挑战链使用固定计数，仅验证软件路径，不验证误报率。")
        nodes = []
        for group in result["groups"]:
            for chain in group["chains"]:
                assert (chain["n_tested"], chain["n_failed"]) == expected[group["node"], chain["chain_id"]]
                assert chain["n_missing"] == 0
            types = {row["tsk_id"]: row for row in group["types"]}
            assert types["TSK_NEAR_ZERO"]["probability"] == 0
            assert types["TSK_SWITCH_ZERO"]["probability"] > 0
            tests = {row["feature"]: row["lrt"] for row in group["feature_effects"]["features"]}
            bump = tests["bump_size"]
            if mode == "boundary_simulation":
                assert "TSK_SWITCH_ZERO" not in bump["simulation"]["observed_full_zero_tsk_ids"]
                assert "TSK_SWITCH_ZERO" in bump["simulation"]["observed_reduced_zero_tsk_ids"]
                assert bump["statistic"] > 0
            else:
                assert bump["status"] == "boundary_uncalibrated", bump
                assert bump["statistic"] > 0 and bump["p_value"] is None
                assert "TSK_SWITCH_ZERO" in bump["reduced_zero_tsk_ids"]
            nodes.append({"node": group["node"], "near_zero_reference_estimate": types["TSK_NEAR_ZERO"]["probability"],
                          "switch_full_reference_estimate": types["TSK_SWITCH_ZERO"]["probability"],
                          "bump_size_lrt": bump,
                          "tests": [{"feature": name, "status": test["status"], "D": test["statistic"],
                                     "p_value": test["p_value"], "p_adjusted": test["p_adjusted"],
                                     "completed": test.get("simulation", {}).get("replicates_completed"),
                                     "failed": test.get("simulation", {}).get("replicates_failed"),
                                     "reason": test["reason"]} for name, test in tests.items()]})
        (output / f"{prefix}_results.json").write_text(json.dumps(compact_tsk_result(result), ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
        export_tsk_html(result, str(output / f"{prefix}_report.html"), view_state={
            "group_index": 0, "main_view": "effects", "effects_view": "overall"})
        # Full replicate traces remain in the saved result; keep the summary small.
        for node in nodes:
            node["bump_size_lrt"] = {key: value for key, value in node["bump_size_lrt"].items() if key != "simulation"}
            matching = next(group for group in result["groups"] if group["node"] == node["node"])
            sim = next(row for row in matching["feature_effects"]["features"] if row["feature"] == "bump_size")["lrt"].get("simulation", {})
            node["bump_zero_sets"] = {name: sim.get(name) for name in ("observed_full_zero_tsk_ids", "observed_reduced_zero_tsk_ids")}
        summaries.append({"mode": mode, "elapsed_seconds": time.monotonic() - started, "nodes": nodes})
        print(json.dumps(summaries[-1], ensure_ascii=False, allow_nan=False), flush=True)
    verification = {"purpose": "Software-path verification, not statistical type-I-error calibration.",
                    "settings": settings, "near_zero_generating_truth": truth["near_zero"],
                    "challenge": truth["boundary_challenge"], "analyses": summaries,
                    "input_sha256": {name: hashlib.sha256((source / name).read_bytes()).hexdigest()
                                     for name in ("template.json", "data.csv", "expected_chain_counts.csv")}}
    (output / "verification.json").write_text(json.dumps(verification, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    failures = [row for analysis in summaries if analysis["mode"] == "boundary_simulation" for node in analysis["nodes"]
                for row in node["tests"] if row["status"] != "simulation_experimental" or row["failed"] != 0]
    if failures:
        raise RuntimeError(f"Some simulated fits failed; reports preserve their diagnostics: {failures}")
    return verification


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path(__file__).resolve().parent / "near_zero")
    parser.add_argument("--output", type=Path, default=ROOT / "outputs/tsk-near-zero-demo_2026-10-09")
    parser.add_argument("--replicates", type=int)
    args = parser.parse_args()
    validate_demo(args.source, args.output, replicates=args.replicates)
