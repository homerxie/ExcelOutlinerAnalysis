"""Append reproducible near-zero and deletion-boundary cases to the TSK demo.

Original measurements are copied verbatim as CSV cell values. The near-zero
block is an unconditioned random draw; the three boundary-challenge chains
use declared fixed failure counts, not a sample for calibrating test size.
Only the new output directory is written. No fitting or seed selection is
performed by this generator.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import csv
import hashlib
from itertools import product
import json
import math
from pathlib import Path
import random
from statistics import fmean, pstdev


SOURCE = Path(__file__).resolve().parent
SEED = 20261009
NEAR_ZERO = "TSK_NEAR_ZERO"
ANCHOR = "TSK_ANCHOR"
SWITCH = "TSK_SWITCH_ZERO"
NEAR_ZERO_REFERENCE_P = 1e-6
CHALLENGE_COUNTS = {"T0": (40, 80, 55), "T1": (59, 112, 81)}


def _write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def build_near_zero_demo(directory: Path, source: Path = SOURCE):
    source, directory = source.resolve(), directory.resolve()
    if directory == source:
        raise ValueError("Choose a separate directory; the original demo must be preserved.")
    template = json.loads((source / "template.json").read_text(encoding="utf-8"))
    base_truth = json.loads((source / "simulation_truth.json").read_text(encoding="utf-8"))
    with (source / "data.csv").open(encoding="utf-8", newline="") as stream:
        original_rows = list(csv.reader(stream))
    with (source / "expected_chain_counts.csv").open(encoding="utf-8", newline="") as stream:
        original_counts = list(csv.reader(stream))
    samples = sorted({row[1] for row in original_rows[1:]})
    nodes = list(base_truth["node_log_odds_effects"])
    if len(samples) != 400 or nodes != ["T0", "T1"] or len(original_rows) != 801:
        raise ValueError("This challenge is designed for the original 400-sample T0/T1 demo.")
    rng = random.Random(SEED)
    noise_rng = random.Random(SEED + 1)
    challenge_rng = random.Random(SEED + 2)
    categories = base_truth["category_log_odds_effects"]
    category_grid = list(product(*(values.keys() for values in categories.values())))
    rng.shuffle(category_grid)
    intercepts = dict(base_truth["type_intercepts"], **{
        NEAR_ZERO: math.log(NEAR_ZERO_REFERENCE_P / (1 - NEAR_ZERO_REFERENCE_P)),
        ANCHOR: math.log(.1 / .9), SWITCH: math.log((1 / 24) / (23 / 24)),
    })
    original_instances = deepcopy(template["tsk_analysis"]["instances"])
    new_instances, near_chains, challenge_chains = [], [], []
    chains_by_id = {}

    def instance(chain, tsk, position, *, baseline=False, bump="large"):
        if baseline:
            features = {"bump_size": bump, "stack": "stack1", "material": "aluminum", "metal_A_density": .5}
            x = y = 0.
        else:
            levels = category_grid.pop() if tsk == NEAR_ZERO else tuple(rng.choice(list(values)) for values in categories.values())
            features = dict(zip(categories, levels))
            features["metal_A_density"] = round(rng.uniform(.15, .85), 4)
            x, y = round(rng.uniform(-1200, 1200), 3), round(rng.uniform(-1200, 1200), 3)
        return {"chain_id": chain, "tsk_instance_id": f"{chain}_{tsk}_{position}", "tsk_id": tsk,
                "chain_key": ["DemoDesign", chain], "x": x, "y": y, "features": features}

    def add_chain(chain, instances):
        if chain in {row["id"] for row in template["analysis_groups"]}:
            raise ValueError(f"Duplicate chain: {chain}")
        group = deepcopy(template["analysis_groups"][0])
        group.update(id=chain, display_name=chain)
        group["columns"] = [{"column_order": 1, "name": f"R_{chain}",
                             "header_values": ["DemoDesign", chain, "Resistance"]}]
        template["analysis_groups"].append(group)
        new_instances.extend(instances)
        chains_by_id[chain] = instances

    layouts = [[NEAR_ZERO] * count for count in (1, 1, 2, 2, 3, 3)]
    layouts += [[tsk, NEAR_ZERO] for tsk in ("TSK_A", "TSK_A", "TSK_B", "TSK_B", "TSK_C", "TSK_C")]
    for index, layout in enumerate(layouts, 1):
        chain = f"Chain_NZ_{index:02d}"
        near_chains.append(chain)
        add_chain(chain, [instance(chain, tsk, position) for position, tsk in enumerate(layout, 1)])
    assert not category_grid
    for index, layout in enumerate(((ANCHOR,), (ANCHOR,), (ANCHOR, SWITCH)), 1):
        chain = f"Chain_Boundary_{index:02d}"
        challenge_chains.append(chain)
        add_chain(chain, [instance(chain, tsk, position, baseline=True, bump="small" if index == 2 else "large")
                          for position, tsk in enumerate(layout, 1)])
    template["name"] = "SYNTHETIC_TSK_NEAR_ZERO_AND_DELETION_BOUNDARY_DEMO"
    template["tsk_analysis"]["instances"] = original_instances + new_instances
    # Match the known generating model, including its linear X/Y effects.
    template["tsk_analysis"].update(use_xy=True, xy_model="linear")
    # Include the parent Design level so chains from different designs stay
    # separate when this configuration is reused with a larger data set.
    template["report"]["outlier_ratio_stats"] = [
        {
            "id": f"{metric}_by_{scope}",
            "display_name": f"{label} by {scope_label}",
            "group_by_dimensions": dimensions,
            "numerator": numerator,
        }
        for scope, scope_label, dimensions in (
            ("chain", "Chain", ["reliability_node", "Design", "Chain Name"]),
            ("lot", "Lot", ["reliability_node", "lot_id"]),
            ("lot_chain", "Lot + Chain", ["reliability_node", "lot_id", "Design", "Chain Name"]),
        )
        for metric, label, numerator in (
            ("accumulated", "Accumulated Rate", "outlier_samples"),
            ("new", "New Rate", "new_outlier_samples"),
            ("recovered", "Recovered Rate", "recovered_samples"),
        )
    ]

    def probability(item, node):
        eta = intercepts[item["tsk_id"]] + base_truth["node_log_odds_effects"][node]
        eta += sum(effects[item["features"][name]] for name, effects in categories.items())
        for name, effect in base_truth["numeric_log_odds_effects"].items():
            value = item[name] if name in ("x", "y") else item["features"][name]
            eta += effect["coefficient"] * (value - effect["center"]) / effect["scale"]
        return 1 / (1 + math.exp(-eta))

    probabilities = {(node, item["tsk_instance_id"]): probability(item, node) for node in nodes for item in new_instances}
    failures, latent_counts = {}, {(node, tsk): 0 for node in nodes for tsk in intercepts}
    for sample in samples:
        uniforms = {item["tsk_instance_id"]: rng.random() for chain in near_chains for item in chains_by_id[chain]}
        for node in nodes:
            for chain in near_chains:
                events = [uniforms[item["tsk_instance_id"]] < probabilities[node, item["tsk_instance_id"]]
                          for item in chains_by_id[chain]]
                for item, failed in zip(chains_by_id[chain], events):
                    latent_counts[node, item["tsk_id"]] += int(failed)
                failures[sample, node, chain] = any(events)
    # Fixed counts form a transparent numerical regression challenge. One
    # permutation per chain keeps T0 failures nested in T1, like the base demo.
    for index, chain in enumerate(challenge_chains):
        order = samples.copy()
        challenge_rng.shuffle(order)
        for node in nodes:
            selected = set(order[:CHALLENGE_COUNTS[node][index]])
            for sample in samples:
                failures[sample, node, chain] = sample in selected
    new_chains = near_chains + challenge_chains
    rows = [original_rows[0] + [f"R_{chain}" for chain in new_chains]]
    for original in original_rows[1:]:
        sample, node = original[1], original[2]
        rows.append(original + [str(round((1000 if failures[sample, node, chain] else 100) + noise_rng.uniform(-1, 1), 6))
                                for chain in new_chains])
    counts = original_counts + [["SYNTHETIC_LOT", node, chain, len(samples),
                                sum(failures[sample, node, chain] for sample in samples)]
                               for node in nodes for chain in new_chains]

    directory.mkdir(parents=True, exist_ok=True)
    _write_json(directory / "template.json", template)
    for name, values in (("data.csv", rows), ("expected_chain_counts.csv", counts)):
        with (directory / name).open("w", encoding="utf-8", newline="") as stream:
            csv.writer(stream, lineterminator="\n").writerows(values)
    truth = deepcopy(base_truth)
    truth.update(seed=SEED, source_seed=base_truth["seed"], samples_per_node=len(samples),
                 chain_count=len(template["analysis_groups"]), instance_count=len(template["tsk_analysis"]["instances"]),
                 type_intercepts=intercepts,
                 source_sha256={name: hashlib.sha256((source / name).read_bytes()).hexdigest()
                                for name in ("template.json", "data.csv", "expected_chain_counts.csv", "simulation_truth.json")},
                 added_random_chains=near_chains,
                 near_zero={"tsk_id": NEAR_ZERO, "reference_probability": NEAR_ZERO_REFERENCE_P,
                            "reference_probability_ppm": 1., "structural_zero": False,
                            "instance_count": sum(item["tsk_id"] == NEAR_ZERO for item in new_instances),
                            "pure_chains": near_chains[:6], "mixed_chains": near_chains[6:],
                            "probability_by_node": {node: {"minimum": min(probabilities[node, item["tsk_instance_id"]] for item in new_instances if item["tsk_id"] == NEAR_ZERO),
                                                               "maximum": max(probabilities[node, item["tsk_instance_id"]] for item in new_instances if item["tsk_id"] == NEAR_ZERO),
                                                               "realized_instance_failures": latent_counts[node, NEAR_ZERO]}
                                                    for node in nodes}},
                 boundary_challenge={"sampling": "fixed_chain_failure_counts_not_iid_binomial_draw",
                                     "purpose": "Numerical regression: positive full-fit TSK_SWITCH_ZERO becomes zero after removing bump_size.",
                                     "anchor_tsk": ANCHOR, "switch_tsk": SWITCH, "remove_feature": "bump_size",
                                     "chains": challenge_chains, "counts_by_node": CHALLENGE_COUNTS,
                                     "not_for_type_I_error_calibration": True,
                                     "reference_probability_anchor": .1, "reference_probability_switch": 1 / 24,
                                     "reference_parameters_are_design_targets_not_random_generation_truth": True},
                 seeds={"near_zero_layout_and_events": SEED, "measurement_noise": SEED + 1, "challenge_sample_allocation": SEED + 2},
                 note="Synthetic validation fixture. Original CSV columns/counts are preserved. Near-zero block uses strictly positive Logistic probabilities and an unconditioned fixed-seed draw. The three challenge chains have explicitly fixed counts and are NOT an iid sample for validating p-value calibration. No resampling to obtain a desired fit. T0/T1 share failures; fit nodes separately.")
    for node in nodes:
        for chain in new_chains:
            truth["chain_probabilities"][node][chain] = 1 - math.prod(1 - probabilities[node, item["tsk_instance_id"]] for item in chains_by_id[chain])
    truth["chain_probability_scope"] = "Original/near-zero chain values are generating probabilities; boundary-challenge values are design references only."
    shift, standardization = 0., {}
    for name, effect in base_truth["numeric_log_odds_effects"].items():
        values = [item[name] if name in ("x", "y") else item["features"][name] for item in template["tsk_analysis"]["instances"]]
        mean, scale = fmean(values), pstdev(values)
        standardization[name] = {"mean": mean, "scale": scale, "coefficient_per_layout_sd": effect["coefficient"] * scale / effect["scale"]}
        shift += effect["coefficient"] * (mean - effect["center"]) / effect["scale"]
    truth["layout_standardization"] = standardization
    truth["type_intercepts_at_layout_mean_T0"] = {name: value + shift for name, value in intercepts.items()}
    _write_json(directory / "simulation_truth.json", truth)
    settings = {"source": "input", "batch_mode": "none", "nodes": ["T0", "T1"],
                "include_xy": True, "xy_model": "linear", "feature_names": list(template["tsk_analysis"]["feature_columns"]),
                "feature_effects_mode": "boundary_simulation", "simulation_replicates": 199, "simulation_seed": 1729}
    _write_json(directory / "settings_simulation.json", settings)
    _write_json(directory / "settings_fixed_zero.json", dict(settings, feature_effects_mode="fixed_zero"))
    return truth


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=SOURCE / "near_zero")
    args = parser.parse_args()
    result = build_near_zero_demo(args.output)
    print(json.dumps({"directory": str(args.output), "chains": result["chain_count"],
                      "instances": result["instance_count"], "near_zero": result["near_zero"]}, ensure_ascii=False))
