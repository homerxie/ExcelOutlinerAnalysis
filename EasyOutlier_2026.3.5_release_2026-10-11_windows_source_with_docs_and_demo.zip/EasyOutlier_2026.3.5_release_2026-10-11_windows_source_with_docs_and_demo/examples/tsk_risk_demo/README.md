# TSK 风险反推示例

这里的拓扑、坐标、测量值和失效概率全部为假设数据，用于演示及回归测试。它们不代表任何真实芯片、版图或 TSK 的可靠性。

1. 在软件中选择 `template.json` 或等价的 `template.xlsx`。
2. 将 `data.csv` 导入一个新的测试数据库。
3. 在 Analyze 中选择 Modified Z-score、阈值 3.5，并关闭 Use Golden Range for Z Score（使用本次分析总体），确认排除范围后运行 Analyze。再打开 TSK 分析页，直接基于该次 Analyze 的最终结果拟合；被排除的样品、测项和链路不会恢复。修改范围或规则后须重新运行 Analyze。
4. 首次加载模板时，默认选中 `feature_columns` 声明的四项特征：`bump_size`、`stack`、`material`、`metal_A_density`。XY 默认关闭，可按需勾选。清空特征并关闭 XY 后，仅估计各 TSK 类型的风险。每个可靠性节点独立拟合；是否按原批或母批拆分由批次设置控制。

数据包含 400 个唯一样品、T0/T1 两个节点、48 条 Chain、136 个布局实例和 3 种 TSK 类型。原有 12 种类型数量组成重复四组，各组使用不同的实例特征。`TSK_A/B/C` 是设计类型，`TSK_instance_ID` 是各链中的不同物理实例；同链重复的设计类型必须逐行保留。所有 Chain 的完整键为 `["DemoDesign", "Chain_XX"]`，不能省掉 Design 后将不同设计的同名链混为一条。

实例包含三个类别特征：`bump_size=large/medium/small`、`stack=stack1/stack2/stack3`、`material=aluminum/copper`，以及范围为 0.15–0.85 的数值特征 `metal_A_density`。每种 TSK 的全部 18 种类别组合均至少有两个布局实例，类别在各 Chain 上随机交叉安排。布局覆盖并不保证每批有限观测中的全部参数都可独立识别。

测量值为约 100 Ohm 的正常值和约 1000 Ohm 的注入失效值，叠加 [-1, 1] 内的随机噪声。模板使用 modified z-score 3.5 判据；该构造保证正常值与注入失效可以明确分离。真实项目需要另行确认 Fail 判据是否代表物理开路，不能把一般统计离群等同于开路。

`expected_chain_counts.csv` 记录注入模型产生的各节点、各链总样品数 n 和失败样品数 k，可与软件结果核对。T1 沿用 T0 的实例随机阈值并提高风险，因此此例没有恢复，且不包含缺失测量。分母每个样品只计算一次，不是测试点或重复次数。

固定随机种子为 20260922。实例 X/Y 范围约为 -1200 至 1200 um。数据严格按以下 Logistic 模型生成：

```text
eta = alpha_type + bump_effect + stack_effect + material_effect
      + 0.25 × (metal_A_density - 0.5) / 0.2
      + 0.30 × X / 1000 - 0.20 × Y / 1000 + node_effect
p_instance = 1 / (1 + exp(-eta))
```

其中 `eta` 为实例失效概率的 log-odds，生成参数如下：

| 参数 | 取值 |
| --- | --- |
| `alpha_type` | TSK_A：−5.1；TSK_B：−4.5；TSK_C：−3.9 |
| `bump_effect` | large：0；medium：0.35；small：0.8 |
| `stack_effect` | stack1：0；stack2：0.3；stack3：0.6 |
| `material_effect` | aluminum：0；copper：0.25 |
| `node_effect` | T0：0；T1：0.45 |

链中任一实例失败即为该链失败。[simulation_truth.json](simulation_truth.json) 记录生成参数及数值特征的缩放口径。生成式使用固定的密度中心 0.5、尺度 0.2；软件拟合按当前有效布局实例的均值和标准差进行标准化，因此不能直接比较未换算的数值系数与截距。有限样本的估计不会精确等于生成参数；默认关闭 XY 时还省略了生成过程中的位置因素。

需要重新生成时，在仓库根目录运行：

```bash
./.venv/bin/python examples/tsk_risk_demo/generate_demo.py
```

更新示例后须重新载入模板；旧数据库中的测量仍是旧版数据，需重新导入新的 `data.csv`，不能只替换模板。建议使用新的测试数据库；已有运行设置应在运行页核对。保留用户已有的 `result`、`temp` 工作文件，避免以新示例覆盖已有分析结果。

## 近零风险与删特征后新增零边界示例

独立版本位于 [`near_zero`](near_zero)，保留原示例 48 条链的模板实例、测量列和计数，新增到 **63 条链、164 个布局实例、6 种 TSK**。样品数仍为每节点 400，节点仍为 T0/T1。它同时覆盖两种情况：

- **`TSK_NEAR_ZERO`**：生成时的基准失效概率为 **0.0001%（1 ppm）**，严格大于零；沿用原共享特征和节点效应。其 18 个实例覆盖全部 18 种类别组合，分布在 6 条纯链和 6 条混合链中。本次固定种子的样本没有产生该类型的实例失效，两个节点都拟合为零，但混合链仍有来自其他类型的失效。这演示的是有限样本中的零估计，不是已知真实风险为零。
- **`TSK_SWITCH_ZERO`**：完整模型中风险为正，删除 **`bump_size`** 后变为零。另加 `TSK_ANCHOR` 提供可辨识的参照；三条挑战链的全部其他特征相同，因此可清楚核对边界变化来自此次删特征拟合。

下载或选择本目录中的配套文件，不能混用原模板与新增数据：

| 文件 | 用途 |
| --- | --- |
| [template.xlsx](near_zero/template.xlsx) / [template.json](near_zero/template.json) | 两份语义一致的新版模板 |
| [data.csv](near_zero/data.csv) | 原 48 条链及 15 条新增链的测量数据 |
| [expected_chain_counts.csv](near_zero/expected_chain_counts.csv) | 126 条节点／Chain 的预期 n、k |
| [simulation_truth.json](near_zero/simulation_truth.json) | 近零真值、种子、原文件指纹和挑战条件 |
| [settings_simulation.json](near_zero/settings_simulation.json) | 自由边界模拟设置，199 次、种子 1729 |
| [settings_fixed_zero.json](near_zero/settings_fixed_zero.json) | 相同数据与特征的固定零条件分析设置 |

在 Setup 中加载新版模板和 `data.csv`，建议导入新的测试数据库。Analyze 使用 Modified Z-score 3.5。TSK Analysis 保留全部四项特征，勾选 XY 并选择 **linear** 空间模型；这与原数据的生成公式一致。选择“自由边界模拟检验（实验性）”、199 次、种子 1729，然后在“特征影响 → 整体影响”查看 `bump_size`。设置 JSON 用于程序调用，不是另一个拓扑模板。

模板的 `outlier_ratio_stats` 已配置 9 项统计：按 Chain、按 Lot、按 Lot + Chain 分组，各查看 Accumulated、New、Recovered Rate，并分别显示 T0/T1。链路分组包含上级 Design，避免不同设计中的同名链路混在一起。分母为各组实际测试的独立样品数；Lot 统计对样品去重，不对各链路的率取平均。Accumulated 使用 `outlier_samples`（当前节点全部异常），New 使用 `new_outlier_samples`，Recovered 使用 `recovered_samples`。本数据的失效从 T0 到 T1 不恢复，因此 Recovered 为 0；只有一个 `SYNTHETIC_LOT`，所以按 Chain 与按 Lot + Chain 的结果一致。

“模拟进程数”默认 **自动**：根据 CPU 数使用最多 8 个进程并保留一个逻辑核；也可设为 1 串行或手动指定进程数。每个子进程限制数值库线程，避免重复抢占 CPU。进程数只改变执行方式，相同种子仍生成相同模拟计数；保留完整拟合验证和失败诊断。自动模式对少于 16 次的小任务使用串行，避免启动进程反而更慢。程序调用可设置 `simulation_workers`（0 为自动）。

两个节点的完整拟合都应把 `TSK_NEAR_ZERO` 估计为 0，而 `TSK_SWITCH_ZERO` 为正。“查看详情”中的 `bump_size` 删特征模型应新增 `TSK_SWITCH_ZERO` 到零风险集合，且仍能给出观测 D 与完成模拟后的 p。模拟只用于特征整体似然比检验，不生成档位系数、TSK 两两比较或 OR 的置信区间。在自由零边界下，可局部识别的有限系数差，以及正风险 TSK 之间可识别的系数差和 OR，仍保留为“仅点估计”；标准误、区间和两两比较 p 留空。参考类型使用首个正风险 TSK。涉及零风险类型的比较没有有限 log odds 差，不能拿数值截断系数代替。

在“档位系数”和“档位两两比较”切到 **TSK 类型**，名称旁的 **风险边界** 列会明确显示 `TSK_NEAR_ZERO` 为“拟合触及下边界（p=0，低风险）”，而不是只写无法判断。固定零模式显示“触及下边界，强制 p=0（低风险）”，表示后续分析持续固定该贡献为零；当前没有正概率截断阈值。涉及它的两两对比标出哪一方为 p=0、哪方拟合风险较高；两个零边界类型不排序。只有明确的 p=1 才标注高风险边界，不可识别或未收敛不能据此推断方向。边界方向不是显著性结论，没有有限对比时，系数差、OR、区间和 p 仍留空。这里 `TSK_NEAR_ZERO` 的生成真值严格为正，正好提醒用户：拟合为零不代表真实失效概率一定为零。

改用固定零条件模式时，原 `TSK_NEAR_ZERO` 保持固定零，但删 bump 后另一个 TSK 新增零边界，因此该项保留可用的 D 和删除预测变化，普通卡方 p 留空并标注“边界检验未校准”。这不妨碍完整有限条件模型中仍然可用的档位区间。自由边界模拟模式则通过实际模拟另行给出实验性 p，便于对照两种方法的适用范围。

两种方法在 GUI 和 HTML 中统一使用 **“影响显著 / 尚未检出显著影响 / 无法判断”**。整体结论按各自有效的 Holm 校正 p 与所选显著性水平比较；模拟模式使用 Holm 模拟 p。模拟方法的实验性提示、模拟 p 列名和详情仍保留：相同的结论措辞不代表模拟已通过统计校准，也不代表未检出显著影响就是没有影响。

两种方法各运行一次后，可在 **TSK Results → 已保存分析** 中直接切换；切换 TSK Analysis 的模式选择也会查找当前设置对应的结果，已计算过时不重新拟合。没有对应结果时只提示尚未计算，点击运行才开始；重复点击运行也会复用相同输入的结果。保存结果选择器显示模式、次数／种子、时间、节点、特征和条件标识，查看历史结果不会改动当前分析输入设置。

已有结果随数据库自动保存，重新打开数据库直接恢复，另存数据库也保留。GUI 导出的 HTML 会包含当前数据与模型条件下已保存的两种方法及模拟次数／种子版本，可以离线切换；不同数据或模型条件的结果需分别导出。XLSX 导出当前选中的结果。

数据内容、模板、Analyze 当前 Fail 规则、Golden 文件、数据范围、节点／样品、批次、特征、XY 或拟合设置变化后，点击运行会计算并保留新的结果。模拟次数或种子改变也会产生新模拟结果；只改变进程数不会重算。固定零模式不受模拟次数和种子影响。进程异常或取消后可重新运行，已有结果保留。包含失败或未完成模拟的报告仍保留在历史中供查看；再次点击“运行分析”会重试相同设置，不把失败模拟当作已完成结果复用。返回的新报告替换相同设置的历史条目，重试过程中若进程异常或取消，旧条目保留。已完整完成的模拟会正常复用，包括“尚未检出显著影响”的结果。重试不会丢弃失败模拟样本，也不能通过挑选种子来获得期望的显著性。

三条挑战链使用以下**固定失效计数**，失效样品的位置由固定随机排列分配，T1 包含 T0 的失效样品：

| Chain | 组成及 bump | T0 k/n | T1 k/n |
| --- | --- | --- | --- |
| `Chain_Boundary_01` | ANCHOR，large | 40/400 | 59/400 |
| `Chain_Boundary_02` | ANCHOR，small | 80/400 | 112/400 |
| `Chain_Boundary_03` | ANCHOR + SWITCH_ZERO，均 large | 55/400 | 81/400 |

三条链均使用 stack1、aluminum、密度 0.5、X=Y=0。删去 bump 后，ANCHOR 在三条链中的条件相同；混合链失效率低于两条纯链的平均值，非负 SWITCH_ZERO 贡献的最优解为零，三条链共同预测分别为 **175/1200** 和 **252/1200**。保留 bump 时，large 的 ANCHOR 基线较低，SWITCH_ZERO 可以承担额外的正风险。

**这些固定计数是明确构造的数值挑战条件，不是独立二项抽样得到的校准数据。** 原 48 条链保持原随机样本，近零块使用未筛选的单次随机样本；不更换种子直到拟合符合预期。整个数据集用于验证导入、分类、零边界拟合和模拟检验的程序路径，不能据此证明误报率或覆盖率。真值文件明确区分随机生成概率与挑战块的设计参考参数。

可在仓库根目录重新生成 JSON／CSV，并运行实际分析验证：

```bash
./.venv/bin/python examples/tsk_risk_demo/generate_near_zero_demo.py
./.venv/bin/python examples/tsk_risk_demo/validate_near_zero_demo.py
```

生成器只写 `near_zero` 的数据、JSON 模板和设置，不改原 demo、已有数据库或 Excel 模板。若修改了生成器或原模板，重新生成后应在软件中加载 JSON 并另存配套 Excel 模板，避免使用旧 XLSX。随附的两份模板已核对一致。

验证脚本按相同输入分别运行自由边界模拟与固定零条件分析，核对全部 Chain 计数并保存两份 HTML、计算快照及 `verification.json`；默认输出到 `outputs/tsk-near-zero-demo_2026-10-09`。可用 `--output` 指定新目录，`--replicates` 调整模拟次数。199 次只适合快速演示，最小模拟 p 为 0.005；需要更稳定的尾部估计时增加次数，并查看 MC 区间。拟合失败会保留诊断，不丢弃或补抽。

可用 `./.venv/bin/python scripts/benchmark_tsk_simulation.py --workers 0 --replicates 199 --output outputs/tsk-simulation-benchmark` 实测本机完整流程耗时；将 `--workers` 改为 1 可作串行对照。输出包含逐次 D、零集合、失败次数及执行设置，便于核对提速后结果。

## 分批与母批示例

`batch_data.csv` 是同一组模拟测量的三批版本，继续使用上面的 `template.xlsx`：L001 有 100 个样品、L002 和 L003 各有 150 个样品，每批都包含 T0/T1。各批的样品编号都从 S0001 重新开始，因此也可核对软件不会跨批合并重号样品。

1. Setup 选择 `batch_data.csv` 和 `template.xlsx`，TSK Analysis 的数据来源选择输入文件；也可导入一个新的测试数据库后选择该导入记录。
2. 批次模式选择“按原批次分别统计”，批次字段选 `lot_id`，读取批次。运行后应有 3 批 × 2 节点共 6 组。
3. 改为母批合并模式，将 L001、L002 的母批编号都填为 M001，L003 填为 M002。Fail 规则继续使用 Analyze 当前设置，Z-score 按所选全部范围计算，不按原批或母批重新分池。
4. 运行后共有 4 组。M001 每节点、每链有效分母是 250，M002 是 150；各组有自己的 TSK 概率和区间。
5. 导出结果的 `Batch Counts` 保留原批计数，可与 `batch_expected_counts.csv` 核对。`batch_settings.json` 是上述运行参数的程序调用示例，不是另一个拓扑模板。

批次模式为 `none`（不分批，所选所有 lot 混合）时，仍保留原批字段 `lot_id`，先在各原批合并重复测量，再把三批的最终计数按节点汇总拟合，不平均原批概率，也不把跨批同号样品合成一个。此时得到 T0/T1 共 2 组，每节点、每链有效分母为 400。TSK 页没有额外的温度、电压等条件分层；分组只由可靠性节点与原批／母批设置决定。旧模板或旧界面设置中的 `group_by_dimensions` 会被忽略。

这是从当前 48 条 Chain 主示例派生的批次操作演示：只改变批次标签和样品编号，没有人为注入额外的批次风险效应。`batch_settings.json` 保持 `feature_names=[]`、XY 关闭，仅演示分批统计；GUI 首次载入模板则默认选中模板声明的特征，可按需要保留或清空。合并要求使用者判断所选原批是否适合共享一套风险参数。

TSK 直接读取已完成 Analyze 的 Pass/Fail 结果，节点和样品选择只能在该结果内缩小范围；批次、XY 和特征可独立设置。旧 TSK 的数据源、导入选择、`fail_method`、`classification_pool` 不再影响新运行。更改阈值或排除规则后，请先重新运行 Analyze。

空数值遵循 Analyze 的 `empty_as_fail`：开启时直接判 Fail；关闭时跳过该测量，只有已知样品在某节点、某 Chain 完全没有剩余测量时才记为 Missing 并排除分母。此示例没有空值。MAD 为零或有效值不足 3 个时，Z-score 判据按有效分数 0 处理；Golden 无匹配时 Golden Fail 为 False，这些情况本身不会产生 Missing。

`generate_demo.py` 会同步生成三批版本；若只需从当前 `data.csv` 重新派生批次文件，可运行 `./.venv/bin/python examples/tsk_risk_demo/generate_batch_demo.py`。已有批次数据库也需重新导入新的 `batch_data.csv`。

## 模板字段说明

JSON 顶层 `tsk_analysis` 与 Excel 两张独立工作表对应：

| 字段 | 作用 |
| --- | --- |
| `enabled` | 是否启用当前模板的 TSK 配置。普通 Analyze 不会自动执行本模块。 |
| `use_xy` | 默认是否考虑坐标，运行页可切换。 |
| `coordinate_unit` | 所有 X/Y 的统一长度单位。 |
| `feature_columns` | 所有额外特征列名称，首次载入时默认选中。既可包含数值列，也可包含显式声明的类别列；运行页可调整或清空。 |
| `categorical_feature_columns` | `feature_columns` 的类别子集；未列入此处的特征保持数值含义，兼容原模板。X/Y 始终为数值。 |
| `instances` | 每行一个物理实例，对应 `tsk_instances` 工作表。 |

实例字段为 `chain_id`、`tsk_instance_id`、`tsk_id`、`chain_key`、`x`、`y`、`features`。Excel 表头分别是 `CHAIN_ID`、`TSK_instance_ID`、`TSK_ID`、`CHAIN_KEY`、`X`、`Y`，以及已声明的特征列。`CHAIN_KEY` 使用 JSON 数组，例如 `["DemoDesign", "Chain_01"]`。如果 Chain 名在整个模板中唯一，可以只填 `CHAIN_ID`，完整键会自动补齐；重名时必须填写完整键并给各链不同的 `CHAIN_ID`。

未配置新字段或新工作表的旧模板仍可正常使用，默认关闭 TSK。软件内置普通模板中的 `EXAMPLE_*` 实例也是假设占位，保持关闭；真实分析前必须替换成真实映射并启用。

## 类别与数值特征的配置

主示例已经包含 bump 尺寸、stack 和材料类别。类别可以直接使用文本，不需要先编成数字；将对应列同时列入 `feature_columns` 与 `categorical_feature_columns` 即可。

若 bump 尺寸也有具体数值，需要明确它的数学含义：

- 想把 `40`、`60`、`80` 当作连续尺寸，加入 `feature_columns` 即可，列中填写统一单位下的数值。模型估计尺寸每增加一个标准差的 log-odds 变化。
- 想分别比较三种规格，则同时把 `bump_size` 加入 `categorical_feature_columns`。这时 `40`、`60`、`80` 只是类别标签，也可明确写成 `40um`、`60um`、`80um` 或使用 `M`、`L` 等文字标签；模型不会假定类别有等距或单调关系。

主示例的特征配置为：

```json
{
  "feature_columns": ["bump_size", "stack", "material", "metal_A_density"],
  "categorical_feature_columns": ["bump_size", "stack", "material"]
}
```

实例特征例如 `{"bump_size": "small", "stack": "stack2", "material": "copper", "metal_A_density": 0.35}`。Excel 中在 `tsk_analysis` 声明两份列名列表，在 `tsk_instances` 填写相应属性列。

类别使用完整模板中按稳定顺序排列的首个标签作为基准，采用不居中的 L−1 指示变量编码。概率条和误差线表示“数值特征取本组均值、类别特征取各自基准”时的条件概率，不是所有 bump 规格混在一起的平均概率。类别基准不会随 lot 筛选改变；若某批缺少需要的类别信息，诊断会提示，相关参数可能无法单独估计。类别是模型输入，不是额外分层条件，批次模式与 Analyze 共享 Fail 规则保持原样。

## 文本类别与组合预测的独立示例

[categories/template.xlsx](categories/template.xlsx)（也有 [JSON 版本](categories/template.json)）与 [categories/data.csv](categories/data.csv) 保留为较小的独立示例，专门演示组合查询和无布局组合的外推。该例含三种 TSK、`bump_size=large/small` 和 `material=aluminum/copper`，共 14 条 Chain、17 个实例。T0/T1 每节点各有 600 个样品，分为两批，每批 300 个；批内样品编号重新开始。

1. 在 Setup 选择类别模板和 `categories/data.csv`。在 Analyze 中确认 Modified Z-score、阈值 3.5，并关闭空值判 Fail；不需要先运行 Analyze。
2. 在 TSK Analysis 选择输入文件、批次字段 `lot_id`。要一起使用每节点 600 个样品，选择所有 lot 混合模式；也可按原批分别拟合。
3. 保持 XY 关闭，在特征选择中选中 `bump_size` 与 `material`，运行 TSK 分析。
4. GUI 分析完成后，风险图默认显示 3 种 TSK × 2 种 bump × 2 种材料的 12 个组合；无有效数据的组合保留位置、概率留空。进入 **组合分析 → 计算条件** 可切换“全部类别组合”与单个比较维度，也可选择是否勾选“无数据组合留空（不外推）”。例如横轴选 `bump_size`、材料固定为 `aluminum`，以 `large` 为基线后点击 **计算组合概率**。
5. 计算完成后自动切到 **热力图**。点击某格进入该 TSK 的 **类别对比**，查看 large/small 条件概率、95% 区间及 small 相对 large 的概率差与区间；支持度和完整提示分别见 **明细**、**全部提示**。返回 **计算条件**，把材料改为 `copper` 计算第二个查询；已完成的不同查询可以保留、随数据库状态保存并导出 XLSX。
6. 注意 `TSK_C + small + copper`：此组合刻意没有放入模板布局，默认不外推时概率与区间均留空。取消勾选“无数据组合留空（不外推）”并重新计算后，模型可辨识时才显示标注为 `extrapolated` 的预测值；它不代表该组合已被直接测试过。
7. 在 **模型系数** 查看拟合系数、公式、类别基准和数值标准化信息；条件风险及区间在 **风险图**、**风险明细** 或 **组合分析** 查看。比较某个 bump／材料特征时，可在风险图将其他类别筛选为固定水平，XY 不展开为组合。系数表注明 Logistic 公式，数值系数对应标准化变量；概率和系数分别导出到 `Feature Risk`、`Feature Coefficients` 工作表。`interval_unavailable` 表示概率存在但区间计算失败，明细中的 `interval_error` 可查看具体原因。

本轮模型共享 bump 与材料主效应，没有加入 TSK×类别或 bump×材料交互。热图中的每一格是同一拟合模型下的一个条件预测；切换组合不会单独训练一个新模型。比较基线只用于计算概率差，不会改动模板编码中的类别基准。

支持度同时给出布局实例数、有效链上的匹配实例数、不同有效 Chain 数及 Chain 测试暴露量。最后一项对每条 Chain 的有效样品数只加一次；它不是独立样品总数，也不是逐实例 Fail 的观测数。无对应布局称为 `extrapolated`，有布局但本组没有有效测试支持称为 `no_active_support`，有匹配实例所在 Chain 的有效测试才称为 `observed`。统计上不可估计另行标记，空值不会补成 0% 概率。

每个查询最多 200 格，较大的类型／类别集合可按单 TSK 分次计算。组合概率区间采用轮廓似然近似；概率差区间考虑同一拟合中两项预测的协方差，不能由两条概率区间相减得到。所有这些区间都是逐点区间，不代表整个热图同时具有 95% 覆盖率。颜色强弱只相对于当前视图，跨查询应比较概率数值与区间。

[expected_chain_counts.csv](categories/expected_chain_counts.csv) 提供注入后的链计数，[simulation_truth.json](categories/simulation_truth.json) 记录生成参数：类型截距 A/B/C 为 −4.6/−3.9/−3.4，small 的 log-odds 增量为 0.65、copper 为 0.35、T1 额外增加 0.35。它们是生成真值，不要求有限样品的拟合结果完全相等。可用 `./.venv/bin/python examples/tsk_risk_demo/generate_category_demo.py` 重新生成。
