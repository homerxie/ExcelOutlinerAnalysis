Easy Outlier Windows source release

This archive is intended to be unpacked and built on Windows.

Included:
- application source code
- Windows setup/build scripts
- PyInstaller spec files
- README.md, GUI_Tutorial.md, template_help.md
- one template example under template_example\chip_reliability_template_example.xlsx

Build on Windows:
1. Extract this zip to a normal writable folder.
2. Double-click setup_windows.bat
3. After setup finishes, double-click build_windows.bat
4. GUI output will be created under dist\EasyOutlier
5. CLI output will be created under dist\easy-outlier

Note: PyInstaller must run on Windows to produce Windows executables.
