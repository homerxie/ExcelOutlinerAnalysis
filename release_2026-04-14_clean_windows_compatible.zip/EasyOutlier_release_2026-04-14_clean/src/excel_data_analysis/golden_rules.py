from __future__ import annotations

from functools import lru_cache
import math
import re
from dataclasses import dataclass
from typing import Any

from .models import GoldenAllowedRange

RULE_TERM_NAMES = {"relative", "sigma", "absolute"}
RULE_TOKEN_RE = re.compile(r"\(|\)|[a-z_]+")
RULE_SPACE_RE = re.compile(r"\s+")
OUTLIER_GOLDEN_METHOD_EXAMPLES = [
    "relative",
    "sigma",
    "absolute",
    "relative and sigma",
    "relative or sigma",
    "relative and absolute",
    "relative or absolute",
    "sigma and absolute",
    "sigma or absolute",
    "relative or (sigma and absolute)",
]


@dataclass(slots=True)
class GoldenRuleConfigLike:
    outlier_golden_method: str
    relative_limit: float | None
    sigma_multiplier: float | None
    absolute_lower_bound: float | None
    absolute_upper_bound: float | None


def normalize_outlier_golden_method(value: str | None) -> str:
    return _normalize_outlier_golden_method_cached(str(value or ""))


@lru_cache(maxsize=128)
def _normalize_outlier_golden_method_cached(raw_value: str) -> str:
    text = raw_value.strip().lower()
    if not text:
        raise ValueError("Outlier golden method cannot be empty.")
    text = RULE_SPACE_RE.sub(" ", text)
    tokens = RULE_TOKEN_RE.findall(text)
    if not tokens:
        raise ValueError("Outlier golden method cannot be empty.")
    normalized = " ".join(tokens)
    normalized = normalized.replace("( ", "(").replace(" )", ")")
    _parse_expression(normalized)
    return normalized


def outlier_golden_method_terms(value: str | None) -> frozenset[str]:
    normalized = normalize_outlier_golden_method(value)
    return _outlier_golden_method_terms_cached(normalized)


@lru_cache(maxsize=128)
def _outlier_golden_method_terms_cached(normalized: str) -> frozenset[str]:
    return frozenset(token for token in _tokenize_cached(normalized) if token in RULE_TERM_NAMES)


def validate_golden_rule_config(
    label: str,
    outlier_golden_method: str | None,
    relative_limit: float | None,
    sigma_multiplier: float | None,
    absolute_lower_bound: float | None,
    absolute_upper_bound: float | None,
) -> str:
    normalized = normalize_outlier_golden_method(outlier_golden_method)
    terms = outlier_golden_method_terms(normalized)
    if "relative" in terms and relative_limit is None:
        raise ValueError(f"{label} requires relative_limit because the method uses relative.")
    if "sigma" in terms and sigma_multiplier is None:
        raise ValueError(f"{label} requires sigma_multiplier because the method uses sigma.")
    if "absolute" in terms:
        if absolute_lower_bound is None or absolute_upper_bound is None:
            raise ValueError(
                f"{label} requires both absolute_lower_bound and absolute_upper_bound because the method uses absolute."
            )
        if absolute_lower_bound > absolute_upper_bound:
            raise ValueError(
                f"{label} requires absolute_lower_bound <= absolute_upper_bound."
            )
    return normalized


def evaluate_outlier_golden_rule(
    value: float,
    center: float,
    stdev: float,
    outlier_golden_method: str,
    relative_limit: float | None,
    sigma_multiplier: float | None,
    absolute_lower_bound: float | None,
    absolute_upper_bound: float | None,
) -> bool:
    normalized = normalize_outlier_golden_method(outlier_golden_method)
    ast = _parse_expression(normalized)
    return _eval_ast(
        ast,
        value=value,
        center=center,
        stdev=stdev,
        relative_limit=relative_limit,
        sigma_multiplier=sigma_multiplier,
        absolute_lower_bound=absolute_lower_bound,
        absolute_upper_bound=absolute_upper_bound,
    )


def compute_outlier_golden_display_bounds(
    center: float,
    stdev: float,
    outlier_golden_method: str,
    relative_limit: float | None,
    sigma_multiplier: float | None,
    absolute_lower_bound: float | None,
    absolute_upper_bound: float | None,
) -> tuple[float | None, float | None]:
    allowed_ranges = compute_outlier_golden_allowed_ranges(
        center=center,
        stdev=stdev,
        outlier_golden_method=outlier_golden_method,
        relative_limit=relative_limit,
        sigma_multiplier=sigma_multiplier,
        absolute_lower_bound=absolute_lower_bound,
        absolute_upper_bound=absolute_upper_bound,
    )
    if len(allowed_ranges) != 1:
        return None, None
    interval = allowed_ranges[0]
    return interval.lower_bound, interval.upper_bound


def compute_outlier_golden_allowed_ranges(
    center: float,
    stdev: float,
    outlier_golden_method: str,
    relative_limit: float | None,
    sigma_multiplier: float | None,
    absolute_lower_bound: float | None,
    absolute_upper_bound: float | None,
) -> list[GoldenAllowedRange]:
    normalized = normalize_outlier_golden_method(outlier_golden_method)
    ast = _parse_expression(normalized)
    return _ranges_for_ast(
        ast,
        center=center,
        stdev=stdev,
        relative_limit=relative_limit,
        sigma_multiplier=sigma_multiplier,
        absolute_lower_bound=absolute_lower_bound,
        absolute_upper_bound=absolute_upper_bound,
    )


def _tokenize(expression: str) -> list[str]:
    return list(_tokenize_cached(expression))


@lru_cache(maxsize=128)
def _tokenize_cached(expression: str) -> tuple[str, ...]:
    tokens = tuple(RULE_TOKEN_RE.findall(expression.lower()))
    allowed = RULE_TERM_NAMES | {"and", "or"}
    for token in tokens:
        if token not in allowed and token not in {"(", ")"}:
            raise ValueError(
                f"Unsupported token in outlier golden method: {token}. "
                "Allowed tokens are relative, sigma, absolute, and, or, (, )."
            )
    return tokens


def _parse_expression(expression: str):
    return _parse_expression_cached(expression)


@lru_cache(maxsize=128)
def _parse_expression_cached(expression: str):
    tokens = _tokenize_cached(expression)
    index = 0

    def parse_or():
        nonlocal index
        node = parse_and()
        while index < len(tokens) and tokens[index] == "or":
            index += 1
            node = ("or", node, parse_and())
        return node

    def parse_and():
        nonlocal index
        node = parse_term()
        while index < len(tokens) and tokens[index] == "and":
            index += 1
            node = ("and", node, parse_term())
        return node

    def parse_term():
        nonlocal index
        if index >= len(tokens):
            raise ValueError("Outlier golden method ended unexpectedly.")
        token = tokens[index]
        if token == "(":
            index += 1
            node = parse_or()
            if index >= len(tokens) or tokens[index] != ")":
                raise ValueError("Outlier golden method contains an unmatched '('.")
            index += 1
            return node
        if token in RULE_TERM_NAMES:
            index += 1
            return ("term", token)
        raise ValueError(
            "Outlier golden method must use relative, sigma, absolute, and, or, and parentheses."
        )

    ast = parse_or()
    if index != len(tokens):
        raise ValueError("Outlier golden method contains trailing tokens.")
    return ast


def _eval_ast(
    ast,
    *,
    value: float,
    center: float,
    stdev: float,
    relative_limit: float | None,
    sigma_multiplier: float | None,
    absolute_lower_bound: float | None,
    absolute_upper_bound: float | None,
) -> bool:
    node_type = ast[0]
    if node_type == "term":
        term = ast[1]
        if term == "relative":
            if relative_limit is None:
                return False
            if center == 0:
                return abs(value - center) <= relative_limit
            return abs((value - center) / abs(center)) <= relative_limit
        if term == "sigma":
            if sigma_multiplier is None:
                return False
            return abs(value - center) <= stdev * sigma_multiplier
        if term == "absolute":
            if absolute_lower_bound is None or absolute_upper_bound is None:
                return False
            return absolute_lower_bound <= value <= absolute_upper_bound
        raise ValueError(f"Unsupported rule term: {term}")
    if node_type == "and":
        return _eval_ast(
            ast[1],
            value=value,
            center=center,
            stdev=stdev,
            relative_limit=relative_limit,
            sigma_multiplier=sigma_multiplier,
            absolute_lower_bound=absolute_lower_bound,
            absolute_upper_bound=absolute_upper_bound,
        ) and _eval_ast(
            ast[2],
            value=value,
            center=center,
            stdev=stdev,
            relative_limit=relative_limit,
            sigma_multiplier=sigma_multiplier,
            absolute_lower_bound=absolute_lower_bound,
            absolute_upper_bound=absolute_upper_bound,
        )
    if node_type == "or":
        return _eval_ast(
            ast[1],
            value=value,
            center=center,
            stdev=stdev,
            relative_limit=relative_limit,
            sigma_multiplier=sigma_multiplier,
            absolute_lower_bound=absolute_lower_bound,
            absolute_upper_bound=absolute_upper_bound,
        ) or _eval_ast(
            ast[2],
            value=value,
            center=center,
            stdev=stdev,
            relative_limit=relative_limit,
            sigma_multiplier=sigma_multiplier,
            absolute_lower_bound=absolute_lower_bound,
            absolute_upper_bound=absolute_upper_bound,
        )
    raise ValueError(f"Unsupported AST node type: {node_type}")


def _ranges_for_ast(
    ast,
    *,
    center: float,
    stdev: float,
    relative_limit: float | None,
    sigma_multiplier: float | None,
    absolute_lower_bound: float | None,
    absolute_upper_bound: float | None,
) -> list[GoldenAllowedRange]:
    node_type = ast[0]
    if node_type == "term":
        return [_range_for_term(
            ast[1],
            center=center,
            stdev=stdev,
            relative_limit=relative_limit,
            sigma_multiplier=sigma_multiplier,
            absolute_lower_bound=absolute_lower_bound,
            absolute_upper_bound=absolute_upper_bound,
        )]
    left = _ranges_for_ast(
        ast[1],
        center=center,
        stdev=stdev,
        relative_limit=relative_limit,
        sigma_multiplier=sigma_multiplier,
        absolute_lower_bound=absolute_lower_bound,
        absolute_upper_bound=absolute_upper_bound,
    )
    right = _ranges_for_ast(
        ast[2],
        center=center,
        stdev=stdev,
        relative_limit=relative_limit,
        sigma_multiplier=sigma_multiplier,
        absolute_lower_bound=absolute_lower_bound,
        absolute_upper_bound=absolute_upper_bound,
    )
    if node_type == "and":
        return _intersect_ranges(left, right)
    if node_type == "or":
        return _merge_ranges([*left, *right])
    raise ValueError(f"Unsupported AST node type: {node_type}")


def _range_for_term(
    term: str,
    *,
    center: float,
    stdev: float,
    relative_limit: float | None,
    sigma_multiplier: float | None,
    absolute_lower_bound: float | None,
    absolute_upper_bound: float | None,
) -> GoldenAllowedRange:
    if term == "relative":
        if relative_limit is None:
            raise ValueError("relative_limit is required for relative golden rule.")
        delta = abs(center) * relative_limit
        return GoldenAllowedRange(center - delta, center + delta)
    if term == "sigma":
        if sigma_multiplier is None:
            raise ValueError("sigma_multiplier is required for sigma golden rule.")
        delta = stdev * sigma_multiplier
        return GoldenAllowedRange(center - delta, center + delta)
    if term == "absolute":
        if absolute_lower_bound is None or absolute_upper_bound is None:
            raise ValueError("absolute golden rule requires lower and upper bound.")
        return GoldenAllowedRange(absolute_lower_bound, absolute_upper_bound)
    raise ValueError(f"Unsupported rule term: {term}")


def _merge_ranges(ranges: list[GoldenAllowedRange]) -> list[GoldenAllowedRange]:
    if not ranges:
        return []
    sorted_ranges = sorted(ranges, key=lambda item: (item.lower_bound, item.upper_bound))
    merged: list[GoldenAllowedRange] = [sorted_ranges[0]]
    for current in sorted_ranges[1:]:
        previous = merged[-1]
        if current.lower_bound <= previous.upper_bound:
            merged[-1] = GoldenAllowedRange(
                previous.lower_bound,
                max(previous.upper_bound, current.upper_bound),
            )
            continue
        merged.append(current)
    return merged


def _intersect_ranges(
    left: list[GoldenAllowedRange],
    right: list[GoldenAllowedRange],
) -> list[GoldenAllowedRange]:
    intersections: list[GoldenAllowedRange] = []
    for left_range in left:
        for right_range in right:
            lower_bound = max(left_range.lower_bound, right_range.lower_bound)
            upper_bound = min(left_range.upper_bound, right_range.upper_bound)
            if lower_bound <= upper_bound:
                intersections.append(GoldenAllowedRange(lower_bound, upper_bound))
    return _merge_ranges(intersections)
