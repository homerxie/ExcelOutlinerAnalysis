"""Recover sample identities from frozen Analyze states, without refitting TSK."""
from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from .tsk_analysis_state import encode_analysis_snapshot, snapshot_bytes
from .tsk_observations import (
    observations_from_snapshot, read_analysis_snapshot, resolve_snapshot_node_groups,
    selected_snapshot_rows, template_for_snapshot,
)
from .tsk_run_history import _file_digest, run_signature


def _matches_signature(path, signature):
    # The GUI always requests combinations. Earlier direct API callers did not;
    # that setting changes the run identity but never its sample observations.
    return any(run_signature({
        "source": "analyze", "analysis_snapshot_path": str(path),
        "settings": signature["settings"], "include_all_combinations": combinations,
    })["context_key"] == signature["context_key"] for combinations in (True, False))


def _group_identity(group):
    node = group.get("node")
    identity = {
        "node": node,
        "node_mode": group.get("node_mode", "separate"),
        "source_nodes": group.get("source_nodes", [node]),
        "denominator_node": group.get("denominator_node", node),
        "node_group_index": group.get("node_group_index"),
        "stratum": group.get("stratum", {}),
        "batch_mode": group.get("batch_mode", "none"),
        "batch_dimension": group.get("batch_dimension"),
        "parent_batch_id": group.get("parent_batch_id"),
        "source_batches": sorted(group.get("source_batches", [])),
    }
    return json.dumps(identity, sort_keys=True, ensure_ascii=False)


def _verify_counts(saved, observation):
    chains = saved.get("chains")
    counts = {row["chain_id"]: row for row in observation["counts"]}
    if (not isinstance(chains, list) or not all(isinstance(row, dict) for row in chains)
            or len(chains) != len(counts)
            or {row.get("chain_id") for row in chains} != set(counts)):
        raise ValueError("保存结果与 Analyze 明细的 Chain 范围不同，无法恢复失效样品编号。")
    for chain in chains:
        expected = counts[chain["chain_id"]]
        # n_tested/n_failed are present even in early display archives. Check
        # every additional count retained by newer archives as well.
        fields = ("n_tested", "n_failed", "n_passed", "n_missing")
        if (any(name not in chain for name in fields[:2])
                or any(chain[name] != expected[name] for name in fields if name in chain)):
            raise ValueError("保存结果与 Analyze 明细的 Chain 计数不同，无法恢复失效样品编号。")


def recover_failed_samples(payload, snapshot_path, *, signature=None):
    """Return Fail rows aligned with saved groups, leaving all inputs untouched.

    A history context fingerprint binds the retained selection to exact Analyze
    input bytes. Counts alone cannot identify a cohort: two samples can exchange
    failures without changing any fitted sufficient statistics. Old provenance
    ``analysis_result`` likewise contains only source labels and aggregate counts.
    Such unsigned results cannot be safely joined to a different saved archive.
    """
    if not snapshot_path or not Path(snapshot_path).is_file():
        raise ValueError("当前数据库未保存 Analyze 的样品/链路判定明细。请重新运行一次 Analyze 并保存数据库；"
                         "恢复样品编号不需要重新拟合 TSK。")
    if (not isinstance(signature, dict) or not isinstance(signature.get("settings"), dict)
            or not isinstance(signature.get("context_key"), str) or not signature["context_key"]):
        raise ValueError("该旧结果缺少来源指纹，无法确认当前 Analyze 明细属于此结果。"
                         "请打开包含该结果原始分析记录的数据库。")
    groups = payload.get("groups") if isinstance(payload, dict) else None
    if not isinstance(groups, list) or not groups or not all(isinstance(group, dict) for group in groups):
        raise ValueError("保存的 TSK 结果缺少分析组，无法读取失效样品编号。")
    fingerprint = _file_digest(snapshot_path)
    matched = _matches_signature(snapshot_path, signature)
    snapshot = read_analysis_snapshot(snapshot_path)
    if _file_digest(snapshot_path) != fingerprint:
        raise ValueError("读取期间 Analyze 明细已改变，请重新展开失效样品编号。")
    if not matched:
        # Some older databases retain only the full Analyze export archive.
        # Recreate its deterministic TSK input in private temporary storage so
        # it can be checked against the original history fingerprint.
        with TemporaryDirectory(prefix="tsk-sample-identities-") as directory:
            canonical_path = Path(directory) / "tsk-analysis.json.gz"
            canonical_path.write_bytes(snapshot_bytes(encode_analysis_snapshot(snapshot)))
            matched = _matches_signature(canonical_path, signature)
        if not matched:
            raise ValueError("当前保存的 Analyze 明细与此 TSK 结果的来源不一致。"
                             "请打开生成该结果时保存的数据库或恢复对应的 Analyze 明细。")
    from .tsk_service import _batch_settings

    settings = signature["settings"]
    template = template_for_snapshot(snapshot)
    batch = _batch_settings(template, **{name: settings[name] for name in
                           ("batch_mode", "batch_dimension", "batch_mapping") if name in settings})
    observations = observations_from_snapshot(
        snapshot, template, selected_snapshot_rows(snapshot, settings), batch,
        node_mode=settings.get("node_mode", "separate"),
        node_groups=resolve_snapshot_node_groups(snapshot, settings),
    )
    by_identity = {}
    for observation in observations:
        identity = _group_identity(observation)
        if identity in by_identity:
            raise ValueError("Analyze 明细中的分析组身份重复，无法确定失效样品对应关系。")
        by_identity[identity] = observation
    recovered = []
    used = set()
    for group in groups:
        identity = _group_identity(group)
        observation = by_identity.get(identity)
        if observation is None or identity in used:
            raise ValueError("保存结果与 Analyze 明细的节点或批次范围不同，无法恢复失效样品编号。")
        used.add(identity)
        _verify_counts(group, observation)
        recovered.append(deepcopy([row for row in observation["sample_outcomes"] if row["status"] == "Fail"]))
    if len(used) != len(observations):
        raise ValueError("保存结果与 Analyze 明细的分析组范围不同，无法恢复失效样品编号。")
    return recovered
