"""Individually verified joint-boundary effects and profile LR references.

Finite representatives of diverging coefficients are never effect estimates.
Contrasts are checked with all original nuisance directions free. Deletion
models retain every original Chain and instance and may select new zero faces.
The chi-square reference is explicit, not a claim of boundary calibration.
"""
from __future__ import annotations

from itertools import combinations
import logging
import math
from time import monotonic

import numpy as np

from .tsk_analysis import _plain
from .tsk_feature_effects import (
    MAX_TYPE_PAIRS, _deletion_impact, _empty_contrast, _empty_impact, _empty_lrt,
    _exp, _feature_definitions, _status, _unavailable_feature,
)
from .tsk_logistic_joint_boundary import JointBoundaryBetterOptimumError, JointLogisticBoundaryFit
from .tsk_parallel import ordered_parallel_map, worker_count
from .tsk_prediction import _FrozenFit
from .tsk_progress import joint_effect_progress_message, joint_progress_message


_ERRORS = (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError)
_LOGGER = logging.getLogger(__name__)
_POINT_REASON = (
    "保留 TSK 与全部特征的联合补偿，已通过保留面、局部信息、等似然解和完整干扰参数剖面复核；"
    "保留有限点差与共享 OR；剖面区间或零效应检验未通过时逐项留空。这不是全局唯一性的证明。"
)
_REFERENCE_METHOD = "joint_full_nuisance_profile_lr_chi_square_1_reference"
_REFERENCE_CALIBRATION = "chi_square_1_reference_not_boundary_calibrated"
_REFERENCE_REASON = (
    "固定本对比后重新优化全部 TSK 与特征，允许联合补偿和边界改变；"
    "区间与 p 使用 χ²₁ 渐近参考，联合边界下的覆盖率及误报率尚未校准。"
    "Holm 校正仍是参考值，不代表已校准显著性；区间为逐项区间，未作多重比较校正。"
)
_CONTRAST_REASONS = {
    "contrast_outside_observed_design": "现有布局无法把这个效应差与其他参数区分。",
    "contrast_varies_across_boundary_directions": "允许的联合补偿方向会改变该差值，不能由一条发散方向确定它。",
    "contrast_not_locally_identified": "现有 Chain 观测没有足够的局部信息来独立识别该差值。",
    "contrast_varies_across_equivalent_faces": "已找到的等似然边界或解对该差值给出不同结果。",
    "contrast_profile_flat": "改变这个差值后，其余参数仍能补偿而维持原似然，差值尚不可识别。",
    "joint_fit_not_validated": "相关联合模型尚未通过收敛复核。",
    "contrast_profile_unavailable": "完整干扰参数的剖面复核未完成或未通过原有数值检查。",
    "contrast_profile_scale_not_representable": "该差值的剖面扰动超出浮点表示精度。",
    "contrast_value_not_representable": "该差值超出有限浮点数的表示范围。",
    "contrast_requires_unvalidated_or_unobserved_component": "该差值需要尚未通过复核的独立部分，或超出现有观测的支持范围。",
    "independent_joint_fit_not_validated": "当前没有已通过复核、可支持此差值的独立子模型。",
    "independent_contrast_profile_unavailable": "支持此差值的独立子模型联合复核未通过，暂不报告这个对比。",
}
_INFERENCE_REASONS = {
    "contrast_profile_centre_not_verified": "剖面中心未确认达到保存的最优似然。",
    "contrast_profile_endpoint_not_representable": "搜索端点超出浮点表示范围。",
    "contrast_profile_likelihood_crossing_not_bracketed": "当前搜索范围内未找到经过验证的阈值交点，不能据此声明无穷区间。",
    "contrast_profile_root_residual_not_verified": "端点的似然残差未达标。",
    "contrast_profile_endpoint_unavailable": "该端点的完整联合拟合未通过复核。",
    "contrast_endpoint_value_not_representable": "端点换算后超出浮点表示范围。",
    "contrast_null_profile_unavailable": "零效应约束下的完整联合拟合未通过复核，暂不报告参考 p。",
    "contrast_profile_interior_exceeds_cutoff": "剖面已出现内部超过阈值的点，不能把相应范围当作连续区间。",
}


def _contrast_output(checked, sign=1.):
    status = checked.get("status")
    if status == "finite":
        value = sign * float(checked["estimate"])
        result = _empty_contrast("point_estimate_only", _POINT_REASON)
        odds = _exp(value)
        result.update(difference=value, odds_ratio=odds if odds else None)
        lower, upper = checked.get("ci_lower"), checked.get("ci_upper")
        if sign < 0:
            lower, upper = (-upper if upper is not None else None), (-lower if lower is not None else None)
        result.update(ci_lower=lower, ci_upper=upper,
                      or_ci_lower=(_exp(lower) or None) if lower is not None else None,
                      or_ci_upper=(_exp(upper) or None) if upper is not None else None,
                      statistic=checked.get("statistic"), df=checked.get("df"),
                      p_value=checked.get("p_value"), reference_significant=None,
                      inference_method="joint_full_nuisance_profile_likelihood_ratio",
                      inference_calibration=_REFERENCE_CALIBRATION,
                      interval_method=_REFERENCE_METHOD, test_method=_REFERENCE_METHOD)
        if lower is not None or upper is not None or result["p_value"] is not None:
            complete = lower is not None and upper is not None and result["p_value"] is not None
            result.update(_status("profile_reference" if complete else "profile_reference_partial", _REFERENCE_REASON))
            if not complete:
                result["reason"] += " 本项部分区间端点或零效应检验未通过复核，已通过的结果保留。"
        if checked.get("inference_status") in {"partial", "unavailable"}:
            failures = []
            for section in ("interval", "test"):
                diagnostic = checked.get(section, {})
                failures.extend(diagnostic.get("reason_codes", []))
                for side in ("lower", "upper"):
                    failures.extend(diagnostic.get(side, {}).get("reason_codes", []))
            result["inference_reason_codes"] = sorted(set(failures))
            result["reason"] += "".join(_INFERENCE_REASONS[code] for code in result["inference_reason_codes"]
                                         if code in _INFERENCE_REASONS)
        if checked.get("interval_validation", {}).get("disconnected_acceptance_detected"):
            result["reason"] += " 已发现显示区间外仍有满足似然阈值的点；该区间不是完整接受集合。"
        if not odds:
            result["reason"] += " OR 超出浮点表示范围，保留 log odds 差。"
        for side in ("lower", "upper"):
            if result["ci_" + side] is not None and result["or_ci_" + side] is None:
                result["or_ci_" + side + "_status"] = "not_representable"
                result["reason"] += " OR 区间" + ("下" if side == "lower" else "上") + "端点超出浮点表示范围，已验证的 log odds 区间仍保留。"
    elif status == "divergent":
        direction = {"positive": "positive_infinity", "negative": "negative_infinity"}.get(
            checked.get("divergence_direction"), checked.get("divergence_direction"))
        if sign < 0:
            direction = {"positive_infinity": "negative_infinity", "negative_infinity": "positive_infinity"}.get(direction, direction)
        label = {"positive_infinity": "+∞", "negative_infinity": "−∞"}.get(direction)
        reason = (f"该对比沿已复核的联合边界趋于 {label}，没有有限 log odds 差；不使用截断系数代替。"
                  if label else "该对比在联合边界上没有稳定的有限 log odds 差；不使用截断系数代替。")
        result = _empty_contrast("nonfinite_effect", reason)
        result.update(log_odds_limit=direction, odds_ratio_limit={
            "positive_infinity": "positive_infinity", "negative_infinity": "zero"}.get(direction))
    else:
        unavailable = status == "unavailable"
        result = _empty_contrast(
            "identifiability_check_failed" if unavailable else "not_identifiable",
            "该对比的联合边界复核未完成，暂不报告；其他通过复核的对比仍保留。" if unavailable else
            "该对比未通过联合边界下的可识别性检查；其他通过复核的对比仍保留。")
        detail = "".join(_CONTRAST_REASONS[code] for code in checked.get("reason_codes", []) if code in _CONTRAST_REASONS)
        if detail:
            result["reason"] = detail + result["reason"]
    result["joint_contrast_validation"] = {**checked, "reported_sign": sign}
    return result


def _reference_holm(feature, alpha):
    """Keep the prespecified family; adjusted reference p is not calibrated p."""
    pairs = feature["pairwise"]
    rows = pairs if feature["kind"] == "categorical" else feature["levels"]
    family_id = "tsk_pairs" if feature.get("role") == "tsk_type" else f"feature:{feature['feature']}"
    ordered = sorted(enumerate(rows), key=lambda item: (
        item[1]["p_value"] if item[1].get("p_value") is not None else 1., item[0]))
    previous = 0.
    for rank, (_, row) in enumerate(ordered):
        p = row.get("p_value")
        adjusted = min(1., max(previous, (len(rows) - rank) * (p if p is not None else 1.)))
        previous = adjusted
        row.update(significant=None, reference_significant=None, p_adjusted=None,
                   multiplicity_family=family_id, multiplicity_family_size=len(rows),
                   p_adjustment="holm_reference_unavailable_as_one")
        if p is not None:
            row.update(p_adjusted=adjusted, reference_significant=bool(adjusted <= alpha))
    # Reference-coded level rows duplicate one of the prespecified pair tests.
    for row in feature["levels"] if feature["kind"] == "categorical" else []:
        if row["reference"]:
            continue
        counterpart = next((pair for pair in pairs if
            {pair["level_a"], pair["level_b"]} == {row["level"], feature["reference_level"]}), None)
        if counterpart is not None:
            for name in ("p_adjusted", "reference_significant", "multiplicity_family", "multiplicity_family_size", "p_adjustment"):
                row[name] = counterpart[name]


def _state_zero(state, count):
    zero = np.zeros(count, dtype=bool)
    zero[np.asarray(state["zero_rows"], dtype=int)] = True
    return zero


def _joint_refit(fit, design, start, heartbeat, label):
    engine = JointLogisticBoundaryFit(
        design, fit.chain_index, fit.n, fit.k, len(fit.context["type_ids"]),
        coefficient_bound=float(fit.context.get("logistic_coefficient_bound", 35.)),
        analysis_workers=1,
        progress_callback=lambda event: heartbeat({"message": joint_progress_message(event, prefix=label)}))
    engine.fit(start)
    return engine


def _reduced_context(fit, grouped, keep, state):
    context = dict(fit.context)
    type_count = len(context["type_ids"])
    removed = set(grouped["column_names"])
    context.update(
        design=fit.design[:, keep], coefficients=state["coefficients"],
        negative_log_likelihood=state["minimum"], converged=bool(state["converged"]),
        clipped=False, boundary_fit=None, joint_boundary_fit=state,
        coefficient_columns=[column for index, column in enumerate(context["coefficient_columns"], type_count)
                             if keep[index]],
        categorical_features={name: value for name, value in context.get("categorical_features", {}).items()
                              if name != grouped["name"]},
        numeric_scaling={name: value for name, value in context.get("numeric_scaling", {}).items() if name not in removed},
        feature_groups={name: value for name, value in context.get("feature_groups", {}).items() if name != grouped["name"]},
    )
    return context


def _drop_joint_feature(fit, grouped, heartbeat):
    """Refit the nested model, audit the full optimum, then compare actual risks."""
    minimum, count = fit.minimum, len(fit.design)

    def unavailable(status, reason):
        return _empty_lrt(status, reason, minimum), _empty_impact(status, reason, count)

    if not fit.joint_engine.state.get("converged"):
        return unavailable("fit_not_converged", "仅部分独立子模型通过复核，不能使用包含未收敛部分的总似然进行整体删组比较。")
    if not grouped["indices"]:
        return unavailable("no_variation", "该特征没有可删除的效应参数，无法检验档位差异。")
    keep = np.ones(fit.width, dtype=bool)
    keep[grouped["indices"]] = False
    name = grouped["label"]
    reduced_engine = _joint_refit(fit, fit.design[:, keep], fit.theta[keep], heartbeat, f"特征 {name}：删组重拟合")
    state = reduced_engine.state
    full_engine = getattr(fit.joint_engine, "full", fit.joint_engine)
    original = fit.joint_engine.state
    old_core = np.asarray(original["core_coefficients"])
    old_zero = _state_zero(original, count)
    new_zero = _state_zero(state, count)
    lifted_core = np.zeros(fit.width)
    lifted_core[keep] = state["core_coefficients"]
    # Compare exact attainable limits on the same design; avoid subtracting
    # two large total NLL values or evaluating capped serialization logits.
    change = full_engine._loss_difference(lifted_core, new_zero, old_core, old_zero)
    if change < -1e-7:
        raise JointBoundaryBetterOptimumError("联合删组模型找到比保存的完整模型更低的损失，请重新拟合完整模型。")
    if not state.get("converged") or not math.isfinite(change):
        lrt, impact = unavailable("reduced_fit_not_converged", "该特征的联合边界删组模型未通过收敛复核；其他已验证的档位差不受影响。")
        lrt["reduced_fit_validation"] = state.get("validation", {})
        return lrt, impact
    lifted = np.zeros(fit.width)
    lifted[keep] = state["coefficients"]
    audited = _joint_refit(fit, fit.design, lifted, heartbeat, f"特征 {name}：重启完整模型复核")
    audit = audited.state
    audit_change = full_engine._loss_difference(
        np.asarray(audit["core_coefficients"]), _state_zero(audit, count), old_core, old_zero)
    if audit_change < -1e-7:
        raise JointBoundaryBetterOptimumError("从联合删组解重启后找到更好的完整模型，请重新拟合后分析效应。")
    if not audit.get("converged") or not math.isfinite(audit_change) or audit_change > 1e-7:
        lrt, impact = unavailable("full_refit_check_failed", "从删组解重启的完整模型未确认保存的最优损失，本项删组比较暂不可用；已验证档位差保留。")
        lrt.update(reduced_nll=state["minimum"], full_refit_nll=audit["minimum"],
                   full_fit_validation=audit.get("validation", {}))
        return lrt, impact
    lrt = _empty_lrt("boundary_uncalibrated",
        "保留全部原始 Chain、实例与 TSK 截距，删去本特征后重新搜索联合边界并复核完整模型；"
        "仅报告原始 LR，参考分布尚未校准，不给出普通卡方 p 值或显著性。", minimum)
    lrt.update(statistic=max(0., 2 * change), reduced_nll=state["minimum"], full_refit_nll=audit["minimum"],
               reduced_fit_validation=state.get("validation", {}), full_fit_validation=audit.get("validation", {}))
    try:
        reduced = _FrozenFit(_reduced_context(fit, grouped, keep, state))
        reduced.joint_engine.progress_callback = lambda event: heartbeat({
            "message": joint_progress_message(event, prefix=f"特征 {name}：删组后实例风险")})
        with reduced.joint_engine.parallel_session():
            impact = _deletion_impact(fit, reduced, lambda stage, done, total: heartbeat({
                "message": f"特征 {name}：{stage} · 已完成 {done}/{total}"}))
    except JointBoundaryBetterOptimumError:
        raise
    except _ERRORS as error:
        impact = _empty_impact("numerical_error", "实例风险复核遇到数值异常，删除预测变化暂不可用；已验证的原始 LR 与档位差保留。", count)
        impact["diagnostic_error"] = str(error)
    return lrt, impact


def _prepare(common):
    return common if isinstance(common, _FrozenFit) else _FrozenFit(common)


def _task(fit, task, heartbeat):
    engine = fit.joint_engine
    heartbeat({"message": f"正在处理：{task['label']}"})
    engine.progress_callback = lambda event: heartbeat({"message": joint_progress_message(event, prefix=task["label"])})
    try:
        with engine.parallel_session():
            if task["kind"] == "contrast":
                return engine.contrast_inference(task["vector"], confidence=task["confidence"])
            return _drop_joint_feature(fit, task["grouped"], heartbeat)
    except JointBoundaryBetterOptimumError:
        raise
    except _ERRORS as error:
        if task["kind"] == "contrast":
            return {"status": "unavailable", "identifiable": False, "estimate": None,
                    "reason_codes": ["contrast_numerical_error"], "diagnostic_error": str(error)}
        lrt = _empty_lrt("numerical_error", "该特征的联合删组复核遇到数值异常；已验证档位差及其他特征保留。", fit.minimum)
        lrt["diagnostic_error"] = str(error)
        return lrt, _empty_impact("numerical_error", lrt["reason"], len(fit.design))
    finally:
        engine.progress_callback = None


def build_joint_feature_effects(context, *, confidence, progress, analysis_workers, defer_refits=False):
    started = monotonic()
    progress(0, "读取联合边界快照，准备逐项效应复核…")
    fit = _FrozenFit(context)
    types = list(context["type_ids"])
    definitions = _feature_definitions(context)
    result = {
        "version": 1, **_status("profile_reference", "联合边界下逐项保留已验证的效应与完整剖面 LR 参考区间、参考 p；不宣称边界显著性已校准。"),
        "inference_mode": "joint_boundary_profile_likelihood", "confidence_level": confidence, "alpha": 1 - confidence,
        "calibration_status": _REFERENCE_CALIBRATION,
        "model_scope": "共享主效应 Logistic；控制其他条件比较单实例 log odds，全部 TSK 与特征保留联合补偿。",
        "methods": {
            "coefficient_interval": _REFERENCE_METHOD,
            "pairwise_test": _REFERENCE_METHOD,
            "type_pairwise_test": _REFERENCE_METHOD,
            "pairwise_multiplicity": "holm_reference_unavailable_as_one",
            "overall_test": "joint_boundary_drop_feature_raw_likelihood_ratio_uncalibrated",
            "contrast_identifiability": "joint_logistic_full_nuisance_profile_verified_contrast",
            "type_effects": "joint_boundary_verified_type_log_odds_difference",
            "deletion_impact": "in_sample_model_sensitivity_not_instance_validation",
        },
        "finite_mle_check": _status("joint_boundary", "使用已验证联合边界，不要求每个系数有有限最大似然估计。"),
        "features": [],
        "warnings": [
            "输出的是经逐项复核的效应差，不是优化器保存的有限代表系数；一个档位发散不会自动停用其他档位或特征。",
            "共享 OR 是条件赔率比，不是失效率倍数或因果影响；两个零风险条件的 0/0 odds 比不能由共享 OR 独立证实。",
            _REFERENCE_REASON,
            "标准误和已校准显著性仍留空；整体删组 LR 未套用 χ²₁ 对比参考分布。局部留空不代表无效应。",
            "可识别性复核包含局部信息、已发现等似然边界与完整干扰参数剖面，不是全局唯一性的证明。",
            "删除影响是原有效布局上的模型预测变化；模型假设 Chain 观测独立，尚未修正同一 die/wafer 内的相关性。",
        ],
    }
    tasks, requested, pending = [], {}, []

    def request(row, vector, label):
        vector = np.asarray(vector, dtype=float)
        nonzero = np.flatnonzero(vector)
        sign = -1. if len(nonzero) and vector[nonzero[0]] < 0 else 1.
        canonical = vector * sign
        canonical[canonical == 0.] = 0.  # ±0 is the same exact contrast.
        key = canonical.tobytes()
        if key not in requested:
            requested[key] = len(tasks)
            tasks.append({"kind": "contrast", "vector": canonical, "label": label, "confidence": confidence})
        pending.append((row, requested[key], sign))

    def feature_base(name, kind, reference, **extra):
        return {"feature": name, "kind": kind, "reference_level": reference,
                **_status("profile_reference", result["reason"]), "levels": [], "pairwise": [],
                "lrt": _empty_lrt("not_computed", "尚未计算删组比较。", fit.minimum),
                "deletion_impact": _empty_impact("not_computed", "尚未计算删除影响。", len(fit.design)), **extra}

    def add_levels(feature, levels, vectors, reference):
        for level in levels:
            is_reference = level == reference
            data = _empty_contrast("reference_coding" if is_reference else "not_computed",
                                   "参考档固定编码为 0、OR 为 1，不是零风险声明。" if is_reference else "等待联合效应复核。")
            if is_reference:
                data.update(difference=0., odds_ratio=1.)
            row = {"level": level, "reference": is_reference, **data, "coefficient": data["difference"], "point_rank": None}
            feature["levels"].append(row)
            if not is_reference:
                request(row, vectors[level], f"{feature['feature']}：档位 {level}")
        if feature["kind"] == "categorical":
            for a, b in combinations(levels, 2):
                row = {"level_a": a, "level_b": b, "contrast": "b_minus_a",
                       **_empty_contrast("not_computed", "等待联合效应复核。")}
                feature["pairwise"].append(row)
                request(row, vectors[b] - vectors[a], f"{feature['feature']}：{b} − {a}")

    categorical = context.get("categorical_features", {})
    columns = list(context.get("coefficient_columns", []))
    for grouped in definitions:
        name = grouped["name"]
        definition = categorical.get(name)
        reference = str(definition["reference"]) if definition else None
        feature = feature_base(name, grouped["kind"], reference,
                               label=grouped["label"], column_names=grouped["column_names"])
        if grouped["kind"] == "spatial":
            feature["reason"] = "XY 的全部空间基底作为一个因素整体删组；位置效应随坐标变化，没有统一的档位 OR。"
        else:
            levels = list(map(str, definition["levels"])) if definition else ["增加一个 scale"]
            indices = {str(column[1]): len(types) + index for index, column in enumerate(columns) if column[0] == name}
            vectors = {}
            for level in levels:
                vector = np.zeros(fit.width)
                if level != reference:
                    index = indices.get(level) if definition else (grouped["indices"][0] if len(grouped["indices"]) == 1 else None)
                    if index is None:
                        raise ValueError(f"Missing fitted coefficient for {name!r}, {level!r}.")
                    vector[index] = 1.
                vectors[level] = vector
            add_levels(feature, levels, vectors, reference)
            if not definition:
                feature["levels"][0].update(context.get("numeric_scaling", {}).get(name, {}))
        result["features"].append(feature)
    pair_count = len(types) * (len(types) - 1) // 2
    type_report = feature_base("TSK 类型", "categorical", types[0] if types else None, role="tsk_type",
                              pairwise_count=pair_count, computed_pairwise_count=0,
                              pairwise_limit=MAX_TYPE_PAIRS, pairwise_omitted_count=0)
    type_report["lrt"] = _empty_lrt("not_applicable", "TSK 类型不进行删除 TSK 的整体检验。", fit.minimum)
    type_report["deletion_impact"] = _empty_impact("not_applicable", "TSK 类型不进行删除影响分析。", len(fit.design))
    if pair_count > MAX_TYPE_PAIRS:
        type_report.update(_status("computation_limited", f"TSK 共 {pair_count} 个两两对比，超过既有 {MAX_TYPE_PAIRS} 项上限，本次未计算类型对比。"),
                           pairwise_omitted_count=pair_count)
    else:
        vectors = {name: np.eye(fit.width)[index] - np.eye(fit.width)[0] for index, name in enumerate(types)}
        add_levels(type_report, types, vectors, types[0] if types else None)
    result["type_effects"] = type_report
    contrast_count = len(tasks)
    if not defer_refits:
        tasks.extend({"kind": "deletion", "grouped": grouped, "label": f"特征 {grouped['label']}：删组影响"}
                     for grouped in definitions)
    from .tsk_compute_budget import current_role

    # A compact design can still require hours of boundary profile work.
    # Admitted groups use their shared allocation for these independent
    # contrasts; design size alone must not force the entire stage serial.
    workers = (analysis_workers if analysis_workers else 0 if current_role() == "group" else
               1 if fit.design.size * len(tasks) < 100_000 else min(4, worker_count(0, len(tasks))))
    execution = {}
    # Deletion fits include per-instance risk checks and often dominate the
    # tail. Start them first, filling freed workers with the many independent
    # contrast profiles; restore the original result order afterwards.
    task_order = list(range(contrast_count, len(tasks))) + list(range(contrast_count))
    scheduled_tasks = [tasks[index] for index in task_order]
    activity = {}
    timings = {}
    last_log = started

    def receive_activity(snapshot):
        nonlocal activity
        activity = snapshot

    def receive_detail(index, event):
        if event.get("phase") == "completed":
            task = scheduled_tasks[index]
            timings[index] = {"task_index": task_order[index], "kind": task["kind"],
                              "label": task["label"], "elapsed_seconds": event["elapsed_seconds"]}
            _LOGGER.info("联合效应复核任务完成：%s · 已用 %.1fs", task["label"], event["elapsed_seconds"])

    def update(done, total):
        nonlocal last_log
        now = monotonic()
        message = joint_effect_progress_message(scheduled_tasks, activity, done=done,
            workers=execution.get("workers_used", 1), elapsed=now - started)
        progress(3 + 94 * done / max(total, 1), message)
        if now - last_log >= 30.:
            _LOGGER.info("%s", message)
            last_log = now

    try:
        scheduled_values = ordered_parallel_map(
            _task, scheduled_tasks, common=fit if worker_count(workers, len(tasks)) == 1 else dict(context),
            prepare_common=_prepare, workers=workers, execution=execution, progress_callback=update,
            detail_callback=receive_detail, activity_callback=receive_activity)
    except JointBoundaryBetterOptimumError as error:
        reason = "复核找到比保存结果更好的完整模型，原效应估计不再可信；请重新拟合后计算。" + str(error)
        result.update(_status("full_fit_not_optimal", reason))
        for feature in [*result["features"], type_report]:
            _unavailable_feature(feature, "full_fit_not_optimal", reason)
        progress(100, reason)
        return _plain(result)
    values = [None] * len(tasks)
    for index, value in zip(task_order, scheduled_values):
        values[index] = value
    for row, index, sign in pending:
        row.update(_contrast_output(values[index], sign))
        if "coefficient" in row:
            row["coefficient"] = row["difference"]
    for index, feature in enumerate(result["features"]):
        if not defer_refits:
            feature["lrt"], feature["deletion_impact"] = values[contrast_count + index]
    for feature in [*result["features"], type_report]:
        _reference_holm(feature, 1 - confidence)
        rows = [row for row in feature["levels"] if not row["reference"]] + feature["pairwise"]
        unavailable = sum(row["difference"] is None for row in rows)
        inference_incomplete = any(row["status"] != "profile_reference" for row in rows)
        if feature.get("status") != "computation_limited":
            refit_failed = (feature["lrt"]["status"] not in {"boundary_uncalibrated", "not_applicable", "not_computed"}
                            or feature["deletion_impact"]["status"] not in {"ok", "not_applicable", "not_computed"})
            reason = (feature["reason"] + " " if feature["kind"] == "spatial" else
                      f"已逐项复核：{len(rows) - unavailable}/{len(rows)} 项有有限效应点估计；其余项目请查看具体原因。")
            intervals = sum(row["ci_lower"] is not None and row["ci_upper"] is not None for row in rows)
            tests = sum(row["p_value"] is not None for row in rows)
            reason += f"{intervals}/{len(rows)} 项有完整剖面参考区间，{tests}/{len(rows)} 项有参考 p；边界显著性尚未校准。"
            if refit_failed:
                reason += " 整体删组或部分实例预测变化暂不可用，请查看各项原因。"
            feature.update(_status("partial" if unavailable or refit_failed or inference_incomplete else "profile_reference", reason))
        if feature["levels"] and all(row["coefficient"] is not None for row in feature["levels"]):
            rank, previous = 0, None
            for row in sorted(feature["levels"], key=lambda item: item["coefficient"]):
                if previous is None or row["coefficient"] != previous:
                    rank += 1
                row["point_rank"], previous = rank, row["coefficient"]
    type_report["computed_point_pairwise_count"] = sum(row["difference"] is not None for row in type_report["pairwise"])
    type_report["computed_pairwise_count"] = sum(row["p_value"] is not None for row in type_report["pairwise"])
    type_report["computed_reference_interval_count"] = sum(
        row["ci_lower"] is not None and row["ci_upper"] is not None for row in type_report["pairwise"])
    if any(feature["status"] != "profile_reference" for feature in [*result["features"], type_report]):
        result.update(_status("partial", "已逐项保留通过联合边界复核的效应及剖面参考推断；部分对比或端点不可用，请查看各项原因。"))
    execution["task_timings"] = sorted(timings.values(), key=lambda item: item["task_index"])
    result["execution"] = execution
    result["warnings"].extend(execution.get("execution_warnings", []))
    progress(100, f"联合边界特征效应分析完成 · 已用 {monotonic() - started:.1f}s")
    return _plain(result)
