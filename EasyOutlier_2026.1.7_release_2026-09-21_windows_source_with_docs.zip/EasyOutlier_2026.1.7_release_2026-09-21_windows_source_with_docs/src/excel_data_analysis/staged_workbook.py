"""Serialize finished report sheets before constructing the next sheet.

The original openpyxl worksheet writer preserves all existing cell styles and
merges. Only its completed XML is retained until the final XLSX archive is saved.
This adapter is intentionally isolated because it uses openpyxl's writer API.
"""
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from openpyxl import Workbook
from openpyxl.drawing.spreadsheet_drawing import SpreadsheetDrawing
from openpyxl.worksheet._writer import WorksheetWriter
from openpyxl.writer.excel import ExcelWriter


class _StagedExcelWriter(ExcelWriter):
    def write_worksheet(self, worksheet):
        writer = self.workbook._staged_sheets.get(worksheet)
        if writer is None:
            return super().write_worksheet(worksheet)
        worksheet._rels = writer._rels
        self._archive.write(writer.out, worksheet.path[1:])
        self.manifest.append(worksheet)
        writer.cleanup()


class StagedWorkbook(Workbook):
    """Single-save workbook; a staged sheet must not be edited afterwards."""

    def __init__(self):
        super().__init__()
        self._staged_sheets = {}

    def stage(self, worksheet):
        if worksheet in self._staged_sheets:
            raise ValueError("Worksheet has already been staged")
        worksheet._drawing = SpreadsheetDrawing()
        worksheet._drawing.charts = worksheet._charts
        worksheet._drawing.images = worksheet._images
        writer = WorksheetWriter(worksheet)
        self._staged_sheets[worksheet] = writer
        writer.write()
        worksheet._cells.clear()

    def save(self, filename):
        self.properties.modified = datetime.now(timezone.utc).replace(tzinfo=None)
        try:
            with ZipFile(filename, "w", ZIP_DEFLATED, allowZip64=True) as archive:
                _StagedExcelWriter(self, archive).save()
        finally:
            self.close()

    def close(self):
        for writer in self._staged_sheets.values():
            if Path(writer.out).exists():
                try:
                    writer.close()
                finally:
                    writer.cleanup()
        super().close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
