"""User-facing, per-column instructions for editable template worksheets."""
from __future__ import annotations

import re


SHEET_COLUMN_GUIDANCE = {
    "row_dimensions": {
        "name": "维度内部名，如 lot_id、sample_id。同一维度占多行时填写相同名字。其他页引用此名字。",
        "display_name": "报表上显示的名称，可以填中文。留空时使用 Name。",
        "priority": "行表头层级：1 为最高层，数字越大越低。每个维度的数字应不同。",
        "optional": "此维度能否缺失：TRUE 可以，FALSE 不可以。留空按 FALSE。",
        "default_value": "未提取到内容时使用的默认值。不需要则留空。",
        "source_order": "同一维度有多个来源时，按 1、2、3 排列提取顺序。",
        "source_column": "从原始数据哪一列取值，填写原始表中的列名。一个来源写一行。",
        "default_split_position": "拆分后取第几段：0 是第一段，1 是第二段。填写时须同时填分隔符；不拆分则留空。",
        "split_position_by_column": "需要按条件选不同片段时，填条件所在的原始列名。不需要则连同后两列留空。",
        "match_value": "条件列等于什么值时使用右边的位置。每个条件单独写一行。",
        "mapped_split_position": "命中左边条件时取第几段，0 是第一段。未命中时使用默认位置。",
        "skip_empty_parts": "拆分时是否跳过空片段：TRUE 跳过，FALSE 保留。留空按 FALSE。",
    },
    "column_header_levels": {
        "name": "列表头层级名，如 Chain Name、Test Type。每层一行；analysis_groups 中须有同名列。",
        "priority": "列层级顺序：1 为最高层，数字越大越低。每层的数字应不同。",
    },
    "analysis_groups": {
        "id": "分析组编号。同一组的测试列填相同 ID；每个原始测试列占一行。同组判据应一致。",
        "display_name": "分析组的显示名称，可以填中文。留空时使用 ID。",
        "analysis_mode": "per_column：每列单独算；pooled_columns：同 ID 的列一起算 Golden 和 Z-score。",
        "unit": "测试单位，如 V、A、Ohm。不需要显示单位时留空。",
        "outlier_golden_method": "Golden 判据，如 relative、sigma、absolute，也可用 and / or 组合。留空用全局设置。",
        "golden_relative_limit": "相对偏差比例，如 0.2 表示 20%。留空用全局设置。",
        "golden_sigma_multiplier": "允许偏差为多少倍标准差，如 3。留空用全局设置。",
        "golden_lower_bound": "absolute 判据的允许下限，单位同测试值。留空用全局设置。",
        "golden_upper_bound": "absolute 判据的允许上限，单位同测试值。留空用全局设置。",
        "golden_overwrite_lower_bound": "覆盖计算结果的最终下限。启用 overwrite_lowerbound 时使用；留空用全局设置。",
        "golden_overwrite_upper_bound": "覆盖计算结果的最终上限。启用 overwrite_upperbound 时使用；留空用全局设置。",
        "golden_continuous_interval": "TRUE：把多个允许区间连成一个区间；FALSE：保留分开的区间。留空用全局设置。",
        "golden_empty_range_fallback_to_absolute": "允许区间为空时，TRUE 改用 absolute 上下限，FALSE 不回退。留空用全局设置。",
        "column_order": "该测试列在组内的顺序，填 1、2、3。",
        "column_name": "原始数据的测试列名，必须与原表对应。每列写一行。",
    },
    "node_orders": {
        "sequence_name": "节点顺序的名称，可自行命名。一行写一条完整的先后顺序。",
    },
    "analysis_dimension_filters": {
        "mode": "include 只保留，exclude 排除。不筛选时整行留空。",
        "dimension": "要筛选的行维度 Name；sample_key 表示完整样品 ID。",
        "value_order": "同一筛选字段有多个值时，填 1、2、3。",
        "value": "要匹配的值，每个值单独一行。sample_key 按唯一 ID 字段顺序，用英文分号连接。",
    },
    "analysis_column_filters": {
        "mode": "include 只保留，exclude 排除。不筛选时整行留空。",
        "field": "要筛选的列层级名，如 Chain Name；也可填 id、raw_column 等测试字段。",
        "value_order": "同一筛选字段有多个值时，填 1、2、3。",
        "value": "要匹配的 Chain、组 ID 或测试列名等。每个值单独一行。",
    },
    "outlier_ratio_stats": {
        "id": "统计项编号。一个统计项有多个筛选条件时，分行填写相同 ID。不统计则整行留空。",
        "display_name": "统计结果的显示名称，可以填中文。留空时使用 ID。",
        "group_by_dimension": "按哪些层级统计：填节点、节点上方的行维度或列层级名。多个名字用英文分号分隔。",
        "numerator": "分子统计什么：new_outlier_samples 新增异常；outlier_samples 全部异常；recovered_samples 恢复正常。",
        "filter_type": "筛选哪类测试，如 chain_name、test_type、id、unit。不筛选时与 Filter Value 一起留空。",
        "filter_order": "同一统计项有多个条件时，填 1、2、3。",
        "filter_value": "筛选的具体值，每个值单独一行。同类条件满足任一即可，不同类条件须同时满足。",
    },
}


def column_guidance(sheet_name: str, headers: list[str]) -> list[str]:
    result = []
    for index, header in enumerate(headers):
        key = re.sub(r"\s+", "_", str(header).strip().lower())
        text = SHEET_COLUMN_GUIDANCE[sheet_name].get(key)
        if text is None and sheet_name == "row_dimensions" and key.startswith("delimiter_"):
            text = "用于拆分原始文本的分隔符，如 _、-。每格写一个；不拆分则留空。"
        if text is None and sheet_name == "node_orders" and key.startswith("node_"):
            text = "填写此阶段的节点值，须与数据一致。从左到右按先后排列；未用列留空。"
            if index == len(headers) - 1:
                next_node = int(key.removeprefix("node_")) + 1
                text += f"\n节点更多时，继续向右加列，表头依次填 Node {next_node}、Node {next_node + 1}…，每格一个节点。"
        if text is None and sheet_name == "analysis_groups":
            text = f"此测试列在“{header}”层的具体值，必填。同值归为一组。"
            if index == len(headers) - 1:
                text += "\n层级不限于现有列。新增层级时，在 column_header_levels 增加 Name 和 Priority，再向右添加同名列，并为每个测试列填值。"
        if text is None:
            raise ValueError(f"Missing template column guidance: {sheet_name}.{header}")
        result.append(text)
    return result
