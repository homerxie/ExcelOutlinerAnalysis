from __future__ import annotations

import math
import re
from dataclasses import dataclass
from pathlib import Path

from PySide6.QtCore import QEvent, QObject, QPoint, QPointF, QRectF, QStringListModel, QThread, QTimer, Qt, Signal, Slot
from PySide6.QtGui import QColor, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QCompleter,
    QLabel,
    QListWidgetItem,
    QMainWindow,
    QProgressBar,
    QTableWidgetItem,
    QToolTip,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..comparison_models import MetricDescriptor, MetricFilterRule, PlotBuildResult, PlotSeries
from ..comparison_service import (
    build_plot_result,
    lane_dimension_options,
    load_measurements_for_plot,
    metric_filter_fields,
)
from ..models import MeasurementRecord, TemplateConfig
from .comparison_renderer import ComparisonRenderer, HoverPoint, RenderPayload
from .ui_comparison_window import Ui_PlotInspectorWindow


@dataclass(frozen=True, slots=True)
class PlotInspectorContext:
    template_path: str
    analysis_scope: str
    input_path: str = ""
    storage_path: str = ""
    golden_path: str = ""
    dataset_ids: list[str] | None = None
    dimension_filters: dict[str, dict[str, list[str]]] | None = None
    column_filters: dict[str, dict[str, list[str]]] | None = None
    outlier_fail_method: str = "modified_z_score"
    zscore_threshold: float = 3.5


@dataclass(frozen=True, slots=True)
class RenderedMetricPlot:
    descriptor: MetricDescriptor
    title: str
    series: list[PlotSeries]
    payload: RenderPayload


@dataclass(slots=True)
class PlotGroupWidgets:
    group_index: int
    header_key: int
    container: QWidget
    header: AxisLabel
    image: HoverImageLabel


@dataclass(frozen=True, slots=True)
class SearchMatch:
    group_index: int
    lane_index: int | None = None


def _default_metric_rules() -> list[MetricFilterRule]:
    return [
        MetricFilterRule(
            field_name="Metric Has Outlier",
            operator="is",
            value="true",
            connector="and",
        )
    ]


@dataclass(frozen=True, slots=True)
class SearchGroupData:
    group_index: int
    group_texts: tuple[str, ...]
    lane_headers: tuple[str, ...]
    lane_labels: tuple[str, ...]
    visible_indices: tuple[int, ...]


class PlotDataLoadWorker(QObject):
    progress = Signal(str, int, int)
    finished = Signal(object, object, object)
    failed = Signal(str)

    def __init__(self, context: PlotInspectorContext) -> None:
        super().__init__()
        self._context = context

    def cancel(self) -> None:
        pass

    @Slot()
    def run(self) -> None:
        try:
            self.progress.emit("Loading template and measurements...", 0, 12)
            template, measurements = load_measurements_for_plot(
                template_path=self._context.template_path,
                analysis_scope=self._context.analysis_scope,
                input_path=self._context.input_path or None,
                storage_path=self._context.storage_path or None,
                dataset_ids=self._context.dataset_ids,
                dimension_filters=self._context.dimension_filters,
                column_filters=self._context.column_filters,
                progress_callback=lambda message, value, total: self.progress.emit(
                    message,
                    value,
                    12,
                ),
            )
            result = build_plot_result(
                template=template,
                measurements=measurements,
                metric_rules=_default_metric_rules(),
                golden_path=self._context.golden_path or None,
                outlier_fail_method=self._context.outlier_fail_method,
                zscore_threshold=self._context.zscore_threshold,
                progress_callback=lambda message, value, total: self.progress.emit(
                    message,
                    4 + value,
                    4 + total,
                ),
            )
            self.finished.emit(template, measurements, result)
        except Exception as exc:
            self.failed.emit(str(exc))


class PlotBuildWorker(QObject):
    progress = Signal(int, str, int, int)
    finished = Signal(int, object, bool)
    failed = Signal(int, str)

    def __init__(
        self,
        request_id: int,
        template: TemplateConfig,
        measurements: list[MeasurementRecord],
        metric_rules: list[MetricFilterRule],
        selected_metrics: list[str],
        lane_dimensions: list[str],
        golden_path: str,
        outlier_fail_method: str,
        zscore_threshold: float,
        update_tree: bool,
    ) -> None:
        super().__init__()
        self._request_id = request_id
        self._template = template
        self._measurements = measurements
        self._metric_rules = metric_rules
        self._selected_metrics = selected_metrics
        self._lane_dimensions = lane_dimensions
        self._golden_path = golden_path
        self._outlier_fail_method = outlier_fail_method
        self._zscore_threshold = zscore_threshold
        self._update_tree = update_tree

    def cancel(self) -> None:
        pass

    @Slot()
    def run(self) -> None:
        try:
            self.progress.emit(self._request_id, "Building plot groups...", 0, 8)
            result = build_plot_result(
                template=self._template,
                measurements=self._measurements,
                metric_rules=self._metric_rules,
                metric_search_query="",
                selected_logical_metrics=self._selected_metrics,
                lane_dimensions=self._lane_dimensions,
                golden_path=self._golden_path or None,
                outlier_fail_method=self._outlier_fail_method,
                zscore_threshold=self._zscore_threshold,
                progress_callback=lambda message, value, total: self.progress.emit(
                    self._request_id,
                    message,
                    value,
                    total,
                ),
            )
            self.finished.emit(self._request_id, result, self._update_tree)
        except Exception as exc:
            self.failed.emit(self._request_id, str(exc))


class SearchWorker(QObject):
    progress = Signal(int, int, int, str)
    finished = Signal(int, object, object, bool, bool)
    failed = Signal(int, str)

    def __init__(
        self,
        request_id: int,
        groups: list[SearchGroupData],
        query: str,
        reset_to_first: bool,
        apply_scroll: bool,
    ) -> None:
        super().__init__()
        self._request_id = request_id
        self._groups = groups
        self._query = query
        self._reset_to_first = reset_to_first
        self._apply_scroll = apply_scroll
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    @Slot()
    def run(self) -> None:
        try:
            matches: list[SearchMatch] = []
            result_groups: set[int] = set()
            total = max(1, len(self._groups))
            emit_every = max(1, total // 100)
            for index, group in enumerate(self._groups, start=1):
                if self._cancelled:
                    return
                if index == 1 or index == total or index % emit_every == 0:
                    self.progress.emit(self._request_id, index, total, "Searching plot results")
                visible_indices = set(group.visible_indices)
                if not visible_indices:
                    continue
                group_match = _text_matches_query(list(group.group_texts), self._query)
                lane_matches = [
                    lane_index
                    for lane_index, label in enumerate(group.lane_labels)
                    if lane_index in visible_indices
                    if _text_matches_query([*group.group_texts, *group.lane_headers, label], self._query)
                ]
                if group_match or lane_matches:
                    result_groups.add(group.group_index)
                if lane_matches:
                    matches.extend(SearchMatch(group.group_index, lane_index) for lane_index in lane_matches)
                elif group_match:
                    matches.append(SearchMatch(group.group_index, None))
            self.finished.emit(
                self._request_id,
                matches,
                result_groups,
                self._reset_to_first,
                self._apply_scroll,
            )
        except Exception as exc:
            self.failed.emit(self._request_id, str(exc))


class PlotRenderWorker(QObject):
    progress = Signal(int, int, int, str)
    finished = Signal(int, object)
    failed = Signal(int, str)

    def __init__(
        self,
        request_id: int,
        plot_type: str,
        items: list[tuple[MetricDescriptor, str, list[PlotSeries]]],
        lane_headers: tuple[str, ...],
        lane_height: int,
        width: int,
        dpr: float,
    ) -> None:
        super().__init__()
        self._request_id = request_id
        self._plot_type = plot_type
        self._items = items
        self._lane_headers = lane_headers
        self._lane_height = lane_height
        self._width = width
        self._dpr = dpr
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    @Slot()
    def run(self) -> None:
        try:
            renderer = ComparisonRenderer()
            rendered: list[RenderedMetricPlot] = []
            total = len(self._items)
            for index, (descriptor, title, series) in enumerate(self._items, start=1):
                if self._cancelled:
                    return
                self.progress.emit(self._request_id, index, total, descriptor.display_label)
                if self._plot_type == "Box Plot":
                    payload = renderer.render_box_series(
                        series,
                        lane_height=self._lane_height,
                        width=self._width,
                        dpr=self._dpr,
                        lane_headers=self._lane_headers,
                    )
                else:
                    payload = renderer.render_ridge_series(
                        series,
                        lane_height=self._lane_height,
                        width=self._width,
                        dpr=self._dpr,
                        lane_headers=self._lane_headers,
                    )
                rendered.append(
                    RenderedMetricPlot(
                        descriptor=descriptor,
                        title=title,
                        series=series,
                        payload=payload,
                    )
                )
            self.finished.emit(self._request_id, rendered)
        except Exception as exc:
            self.failed.emit(self._request_id, str(exc))


class SingleMetricRenderWorker(QObject):
    progress = Signal(int, int, int, str)
    finished = Signal(int, int, object, str)
    failed = Signal(int, str)

    def __init__(
        self,
        request_id: int,
        group_index: int,
        plot_type: str,
        rendered: RenderedMetricPlot,
        lane_headers: tuple[str, ...],
        lane_height: int,
        width: int,
        dpr: float,
        status_message: str,
        range_override: tuple[float, float] | None = None,
        pinned_point_key: tuple[str, str, int, str] | None = None,
    ) -> None:
        super().__init__()
        self._request_id = request_id
        self._group_index = group_index
        self._plot_type = plot_type
        self._rendered = rendered
        self._lane_headers = lane_headers
        self._lane_height = lane_height
        self._width = width
        self._dpr = dpr
        self._status_message = status_message
        self._range_override = range_override
        self._pinned_point_key = pinned_point_key
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    @Slot()
    def run(self) -> None:
        try:
            if self._cancelled:
                return
            self.progress.emit(self._request_id, 1, 1, self._rendered.descriptor.display_label)
            renderer = ComparisonRenderer()
            if self._plot_type == "Box Plot":
                payload = renderer.render_box_series(
                    self._rendered.series,
                    lane_height=self._lane_height,
                    width=self._width,
                    dpr=self._dpr,
                    lane_headers=self._lane_headers,
                    range_override=self._range_override,
                    pinned_point_key=self._pinned_point_key,
                )
            else:
                payload = renderer.render_ridge_series(
                    self._rendered.series,
                    lane_height=self._lane_height,
                    width=self._width,
                    dpr=self._dpr,
                    lane_headers=self._lane_headers,
                    range_override=self._range_override,
                    pinned_point_key=self._pinned_point_key,
                )
            self.finished.emit(self._request_id, self._group_index, payload, self._status_message)
        except Exception as exc:
            self.failed.emit(self._request_id, str(exc))


class HoverImageLabel(QLabel):
    clippedOutlierDoubleClicked = Signal(object)
    resetMetricRangeRequested = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setMouseTracking(True)
        self._payload: RenderPayload | None = None
        self._search_band: QRectF | None = None
        self._hover_merge_keys: frozenset[tuple[str, int, str]] = frozenset()

    def bind_payload(self, payload: RenderPayload) -> None:
        self._payload = payload
        self._search_band = None
        pixmap = QPixmap.fromImage(payload.image)
        pixmap.setDevicePixelRatio(payload.image.devicePixelRatio())
        self.setPixmap(pixmap)
        self.setFixedSize(payload.logical_size())

    def clear_payload(self) -> None:
        self._payload = None
        self._search_band = None
        self._hover_merge_keys = frozenset()
        self.clear()

    def current_payload(self) -> RenderPayload | None:
        return self._payload

    def set_search_highlight(self, band: QRectF | None) -> None:
        if self._search_band == band:
            return
        self._search_band = band
        self.update()

    def paintEvent(self, event) -> None:  # type: ignore[override]
        super().paintEvent(event)
        painter = QPainter(self)
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            if self._search_band is not None:
                painter.fillRect(QRectF(self._search_band), QColor(46, 94, 70, 24))
                painter.fillRect(
                    QRectF(self._search_band.left(), self._search_band.top(), 4.0, self._search_band.height()),
                    QColor("#1f5c4a"),
                )
                painter.setPen(QPen(QColor("#1f5c4a"), 1.0))
                painter.drawRect(QRectF(self._search_band).adjusted(0.5, 0.5, -0.5, -0.5))
            self._draw_hover_merge_group(painter)
            self._draw_pinned_point(painter)
        finally:
            painter.end()

    def _draw_hover_merge_group(self, painter: QPainter) -> None:
        payload = self._payload
        if payload is None or not self._hover_merge_keys:
            return
        for item in payload.hover_points:
            if not item.point.outlier:
                continue
            if _plot_point_merge_key(item.point) not in self._hover_merge_keys:
                continue
            radius = max(5.5, item.radius + 4.0)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.setPen(QPen(QColor("#ffffff"), 3.0))
            painter.drawEllipse(item.position, radius + 1.5, radius + 1.5)
            painter.setPen(QPen(QColor("#1f5c4a"), 2.0))
            painter.drawEllipse(item.position, radius, radius)

    def _draw_pinned_point(self, painter: QPainter) -> None:
        payload = self._payload
        if payload is None or payload.pinned_point_key is None:
            return
        for item in payload.hover_points:
            if _plot_point_key(item.point) != payload.pinned_point_key:
                continue
            painter.setPen(QPen(QColor("#1f5c4a"), 2.0))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            radius = max(6.0, item.radius + 4.0)
            painter.drawEllipse(item.position, radius, radius)
            painter.setPen(QPen(QColor("#ffffff"), 1.0))
            painter.drawEllipse(item.position, radius + 2.0, radius + 2.0)
            return

    def mouseMoveEvent(self, event) -> None:  # type: ignore[override]
        payload = self._payload
        if payload is None:
            super().mouseMoveEvent(event)
            return
        hit = self._find_hover_point(payload, event.position())
        if hit is None:
            self._set_hover_merge_keys(())
            QToolTip.hideText()
        else:
            self._set_hover_merge_keys(hit.point.merge_outlier_keys)
            QToolTip.showText(
                event.globalPosition().toPoint(),
                self._tooltip(hit),
                self,
            )
        super().mouseMoveEvent(event)

    def _set_hover_merge_keys(self, keys: tuple[tuple[str, int, str], ...]) -> None:
        next_keys = frozenset(keys)
        if next_keys == self._hover_merge_keys:
            return
        self._hover_merge_keys = next_keys
        self.update()

    def mouseDoubleClickEvent(self, event) -> None:  # type: ignore[override]
        payload = self._payload
        if payload is None:
            super().mouseDoubleClickEvent(event)
            return
        hit = self._find_hover_point(payload, event.position())
        if (
            hit is not None
            and hit.point.outlier
            and (hit.point.value < payload.minimum or hit.point.value > payload.maximum)
        ):
            self.clippedOutlierDoubleClicked.emit(hit.point)
            event.accept()
            return
        self.resetMetricRangeRequested.emit()
        event.accept()
        return

    def leaveEvent(self, event) -> None:  # type: ignore[override]
        self._set_hover_merge_keys(())
        QToolTip.hideText()
        super().leaveEvent(event)

    @staticmethod
    def _find_hover_point(payload: RenderPayload, position: QPointF) -> HoverPoint | None:
        bucket_size = 24
        base_x = int(position.x() // bucket_size)
        base_y = int(position.y() // bucket_size)
        best_hit: HoverPoint | None = None
        best_distance = 12.0
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for item in payload.hover_buckets.get((base_x + dx, base_y + dy), []):
                    distance = math.hypot(item.position.x() - position.x(), item.position.y() - position.y())
                    if distance <= item.radius + 5.0 and distance < best_distance:
                        best_hit = item
                        best_distance = distance
        return best_hit

    @staticmethod
    def _tooltip(hit: HoverPoint) -> str:
        point = hit.point
        dimension_lines = [
            f"{key}: {value}"
            for key, value in sorted(point.dimensions.items())
            if value
        ]
        reference = ""
        if point.golden_center is not None or point.golden_lower_bound is not None or point.golden_upper_bound is not None:
            golden_range = (
                ", ".join(
                    f"{_format_optional(lower)} - {_format_optional(upper)}"
                    for lower, upper in point.golden_allowed_ranges
                )
                or f"{_format_optional(point.golden_lower_bound)} - {_format_optional(point.golden_upper_bound)}"
            )
            reference = (
                "\n"
                f"golden center: {_format_optional(point.golden_center)}\n"
                f"golden range: {golden_range}"
            )
        return (
            f"{point.metric}\n"
            f"{point.sample_id}\n"
            f"value: {point.value:.6g}\n"
            f"raw_column: {point.raw_column}\n"
            f"logical_metric: {point.logical_metric}\n"
            f"merged_outlier_block: {_format_merged_outlier_status(point)}\n"
            f"z_score: {_format_optional(point.z_score)}"
            f"{reference}\n"
            f"dataset_id: {point.dataset_id}\n"
            f"row_number: {point.row_number}\n"
            f"outlier: {'yes' if point.outlier else 'no'}\n"
            + "\n".join(dimension_lines)
        )


class AxisLabel(QLabel):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._pixmap: QPixmap | None = None
        self.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)

    def bind_pixmap(self, pixmap: QPixmap) -> None:
        self._pixmap = pixmap
        self.setPixmap(pixmap)
        self.setFixedSize(pixmap.deviceIndependentSize().toSize())

    def clear_pixmap(self) -> None:
        self._pixmap = None
        self.clear()

    def current_pixmap(self) -> QPixmap | None:
        return self._pixmap


class PlotInspectorWindow(QMainWindow):
    def __init__(self, context: PlotInspectorContext, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.ui = Ui_PlotInspectorWindow()
        self.ui.setupUi(self)
        self._context = context
        self._template: TemplateConfig | None = None
        self._measurements: list[MeasurementRecord] = []
        self._renderer = ComparisonRenderer()
        self._rules: list[MetricFilterRule] = _default_metric_rules()
        self._metric_catalog: tuple[MetricDescriptor, ...] = ()
        self._metric_search_suggestions: set[str] = set()
        self._suspend_metric_item_changes = False
        self._suspend_metric_tree_selection = False
        self._suspend_lane_item_changes = False
        self._close_requested = False
        self._load_thread: QThread | None = None
        self._load_worker: PlotDataLoadWorker | None = None
        self._build_request_id = 0
        self._build_threads: list[QThread] = []
        self._build_workers: list[PlotBuildWorker] = []
        self._active_build_signature: tuple[object, ...] | None = None
        self._last_build_signature: tuple[object, ...] | None = None
        self._search_request_id = 0
        self._search_threads: list[QThread] = []
        self._search_workers: list[SearchWorker] = []
        self._active_search_signature: tuple[str, str, int] | None = None
        self._current_result: PlotBuildResult | None = None
        self._result_generation = 0
        self._render_request_id = 0
        self._render_threads: list[QThread] = []
        self._render_workers: list[QObject] = []
        self._active_render_signature: tuple[object, ...] | None = None
        self._last_render_signature: tuple[object, ...] | None = None
        self._render_scroll_values: dict[int, int] = {}
        self._last_render_width = 0
        self._last_viewport_width = 0
        self._plot_groups: list[PlotGroupWidgets] = []
        self._rendered_plots: list[RenderedMetricPlot] = []
        self._rendered_generation = 0
        self._search_display_signature: tuple[str, str, int] | None = None
        self._enter_advances_search = False
        self._search_matches: list[SearchMatch] = []
        self._search_match_cursor = -1
        self._search_result_groups: set[int] = set()
        self._compact_search_base_selection: dict[str, set[str]] | None = None
        self._lane_height = 30
        self._suspend_width_refresh = False
        self._render_timer = QTimer(self)
        self._render_timer.setSingleShot(True)
        self._render_timer.timeout.connect(self._render_selected_metrics)
        self._resize_render_timer = QTimer(self)
        self._resize_render_timer.setSingleShot(True)
        self._resize_render_timer.timeout.connect(self._render_selected_metrics)
        self._metric_search_timer = QTimer(self)
        self._metric_search_timer.setSingleShot(True)
        self._metric_search_timer.timeout.connect(self._refresh_search_results_from_timer)
        self._metric_search_model = QStringListModel(self)
        self._metric_filter_value_model = QStringListModel(self)
        self._metric_search_completer = QCompleter(self._metric_search_model, self)
        self._metric_search_completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self._metric_search_completer.setFilterMode(Qt.MatchFlag.MatchContains)
        self._metric_search_completer.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        self.ui.metricSearchEdit.setCompleter(self._metric_search_completer)
        self.ui.metricSearchEdit.installEventFilter(self)
        self._metric_filter_value_completer = QCompleter(self._metric_filter_value_model, self)
        self._metric_filter_value_completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self._metric_filter_value_completer.setFilterMode(Qt.MatchFlag.MatchContains)
        self._metric_filter_value_completer.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        self.ui.metricValueComboBox.setEditable(True)
        self.ui.metricValueComboBox.setCompleter(self._metric_filter_value_completer)
        self._plot_layout = QVBoxLayout()
        self._plot_layout.setContentsMargins(8, 8, 8, 8)
        self._plot_layout.setSpacing(12)
        content = QWidget()
        content.setLayout(self._plot_layout)
        self.ui.plotScrollArea.setWidget(content)
        self.ui.plotScrollArea.viewport().installEventFilter(self)
        self.ui.mainSplitter.splitterMoved.connect(self._queue_width_refresh)
        self.ui.plotScrollArea.verticalScrollBar().valueChanged.connect(self._update_sticky_axis)
        self.ui.plotScrollArea.horizontalScrollBar().valueChanged.connect(self._update_sticky_axis)
        self._sticky_axis = AxisLabel(self.ui.plotScrollArea.viewport())
        self._sticky_axis_group_key: int | None = None
        self._sticky_axis.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._sticky_axis.hide()
        self._build_status_bar()
        self._wire_events()
        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(self._stop_render_threads)
        QTimer.singleShot(0, self._start_load_context)

    def _build_status_bar(self) -> None:
        status_bar = self.statusBar()
        self._render_status_label = QLabel("Ready", status_bar)
        self._render_status_label.setStyleSheet("padding-left: 8px;")
        self._render_progress = QProgressBar(status_bar)
        self._render_progress.setFixedWidth(180)
        self._render_progress.setFixedHeight(14)
        self._render_progress.setTextVisible(False)
        self._render_progress.setRange(0, 1)
        self._render_progress.setValue(0)
        self._render_progress.setEnabled(False)
        status_bar.addWidget(self._render_status_label, 1)
        status_bar.addPermanentWidget(self._render_progress)

    def _wire_events(self) -> None:
        self.ui.metricSearchEdit.textChanged.connect(self._on_metric_search_text_changed)
        self.ui.metricSearchEdit.returnPressed.connect(self._activate_search_from_enter)
        self._metric_search_completer.activated.connect(self._on_metric_search_completion_activated)
        self.ui.metricSearchViewComboBox.currentTextChanged.connect(self._on_metric_search_view_changed)
        self.ui.metricSearchButton.clicked.connect(self._activate_search_from_button)
        self.ui.metricSearchPrevButton.clicked.connect(self._select_previous_search_match)
        self.ui.metricSearchNextButton.clicked.connect(self._select_next_search_match)
        self.ui.selectAllMetricsButton.clicked.connect(self._select_all_metric_tree_items)
        self.ui.deselectAllMetricsButton.clicked.connect(self._deselect_all_metric_tree_items)
        self.ui.metricRealtimeCheckBox.stateChanged.connect(self._on_metric_realtime_changed)
        self.ui.advancedMetricFilterButton.toggled.connect(self.ui.advancedMetricFilterWidget.setVisible)
        self.ui.metricFieldComboBox.currentTextChanged.connect(self._update_metric_filter_value_options)
        self.ui.metricOperatorComboBox.currentTextChanged.connect(self._update_metric_filter_value_options)
        self.ui.addMetricRuleButton.clicked.connect(self._add_metric_rule)
        self.ui.deleteMetricRuleButton.clicked.connect(self._delete_selected_metric_rules)
        self.ui.modifyMetricRuleButton.clicked.connect(self._modify_selected_metric_rule)
        self.ui.clearMetricRulesButton.clicked.connect(self._clear_metric_rules)
        self.ui.metricRulesTableWidget.cellDoubleClicked.connect(self._load_metric_rule_into_editor)
        self.ui.refreshButton.clicked.connect(self._refresh_all)
        self.ui.plotTypeComboBox.currentTextChanged.connect(self._queue_render_selected_metrics)
        self.ui.laneDimensionsListWidget.itemChanged.connect(self._on_lane_item_changed)
        self.ui.laneDimensionsListWidget.model().rowsMoved.connect(self._on_lane_order_changed)
        self.ui.metricTreeWidget.itemChanged.connect(self._on_metric_tree_item_changed)
        self.ui.metricTreeWidget.itemSelectionChanged.connect(self._on_metric_tree_selection_changed)

    def _start_load_context(self) -> None:
        self._set_controls_enabled(False)
        self._set_status_progress("Loading plot data...", 0, 12)
        self.ui.summaryLabel.setText("Loading plot data...")
        worker = PlotDataLoadWorker(self._context)
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._on_load_progress)
        worker.finished.connect(self._on_load_finished)
        worker.failed.connect(self._on_load_failed)
        worker.finished.connect(worker.deleteLater)
        worker.failed.connect(worker.deleteLater)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(self._clear_load_worker)
        self._load_worker = worker
        self._load_thread = thread
        thread.start()

    @Slot(str, int, int)
    def _on_load_progress(self, message: str, value: int, total: int) -> None:
        self._set_status_progress(message, value, total)
        self.ui.summaryLabel.setText(message)

    @Slot(object, object, object)
    def _on_load_finished(
        self,
        template: TemplateConfig,
        measurements: list[MeasurementRecord],
        result: PlotBuildResult,
    ) -> None:
        self._template = template
        self._measurements = measurements
        self._populate_filter_fields()
        self._populate_lane_options()
        self._populate_rules_table()
        self._metric_catalog = result.metrics
        self._current_result = result
        self._result_generation += 1
        self._last_build_signature = self._current_build_signature(selected_metrics=[])
        self._active_build_signature = None
        self._update_metric_search_completions(result.metrics)
        self._update_metric_filter_value_options()
        self._populate_metric_tree(result)
        self._set_controls_enabled(True)
        self._set_render_busy(False)
        self._queue_render_current_result()

    @Slot(str)
    def _on_load_failed(self, message: str) -> None:
        self._set_controls_enabled(True)
        self._set_render_busy(False)
        self.ui.summaryLabel.setText(f"Plot data unavailable: {message}")

    def _clear_load_worker(self) -> None:
        self._load_worker = None
        self._load_thread = None

    def _populate_filter_fields(self) -> None:
        if self._template is None:
            return
        fields = metric_filter_fields(self._template)
        self.ui.metricFieldComboBox.clear()
        self.ui.metricFieldComboBox.setEditable(False)
        self.ui.metricFieldComboBox.addItems(fields)
        self._update_metric_filter_value_options()

    def _populate_lane_options(self) -> None:
        if self._template is None:
            return
        self._suspend_lane_item_changes = True
        self.ui.laneDimensionsListWidget.clear()
        existing_dimensions = set(lane_dimension_options(self._template))
        for dimension in sorted(self._template.row_dimensions, key=lambda item: item.priority):
            if dimension.name not in existing_dimensions:
                continue
            item = QListWidgetItem(dimension.display_name or dimension.name)
            item.setData(Qt.ItemDataRole.UserRole, dimension.name)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsDragEnabled)
            item.setCheckState(
                Qt.CheckState.Checked
                if dimension.name == self._template.report.reliability_node_dimension
                else Qt.CheckState.Unchecked
            )
            self.ui.laneDimensionsListWidget.addItem(item)
        self._suspend_lane_item_changes = False

    def _add_metric_rule(self) -> None:
        self._rules.append(self._metric_rule_from_editor())
        self._populate_rules_table()
        self._refresh_all()

    def _delete_selected_metric_rules(self) -> None:
        selected_rows = sorted(
            {index.row() for index in self.ui.metricRulesTableWidget.selectionModel().selectedRows()},
            reverse=True,
        )
        if not selected_rows:
            current_row = self.ui.metricRulesTableWidget.currentRow()
            if current_row >= 0:
                selected_rows = [current_row]
        for row in selected_rows:
            if 0 <= row < len(self._rules):
                del self._rules[row]
        if selected_rows:
            self._populate_rules_table()
            self._refresh_all()

    def _modify_selected_metric_rule(self) -> None:
        row = self._selected_metric_rule_row()
        if row < 0 or row >= len(self._rules):
            return
        self._rules[row] = self._metric_rule_from_editor()
        self._populate_rules_table()
        self.ui.metricRulesTableWidget.selectRow(row)
        self._refresh_all()

    def _load_metric_rule_into_editor(self, row: int, column: int) -> None:
        del column
        if row < 0 or row >= len(self._rules):
            return
        rule = self._rules[row]
        self.ui.metricConnectorComboBox.setCurrentText(rule.connector)
        self.ui.metricFieldComboBox.setCurrentText(rule.field_name)
        self.ui.metricOperatorComboBox.setCurrentText(rule.operator)
        self._update_metric_filter_value_options()
        self.ui.metricValueComboBox.setCurrentText(rule.value)
        self.ui.metricRulesTableWidget.selectRow(row)

    def _selected_metric_rule_row(self) -> int:
        selected_rows = self.ui.metricRulesTableWidget.selectionModel().selectedRows()
        if selected_rows:
            return selected_rows[0].row()
        return self.ui.metricRulesTableWidget.currentRow()

    def _clear_metric_rules(self) -> None:
        self._rules = []
        self._populate_rules_table()
        self._refresh_all()

    def _metric_rule_from_editor(self) -> MetricFilterRule:
        return MetricFilterRule(
            field_name=self.ui.metricFieldComboBox.currentText().strip(),
            operator=self.ui.metricOperatorComboBox.currentText().strip(),
            value=self.ui.metricValueComboBox.currentText().strip(),
            connector=self.ui.metricConnectorComboBox.currentText().strip(),
        )

    def _populate_rules_table(self) -> None:
        table = self.ui.metricRulesTableWidget
        table.setRowCount(len(self._rules))
        for row_index, rule in enumerate(self._rules):
            for column_index, value in enumerate(
                [rule.connector, rule.field_name, rule.operator, rule.value]
            ):
                table.setItem(row_index, column_index, QTableWidgetItem(value))
        table.resizeColumnsToContents()

    def _update_metric_filter_value_options(self, *args: object) -> None:
        del args
        field_name = self.ui.metricFieldComboBox.currentText().strip()
        operator = self.ui.metricOperatorComboBox.currentText().strip().lower()
        previous_value = self.ui.metricValueComboBox.currentText().strip()
        exact_operator = operator in {"is", "is not", "has outlier"}
        values = self._metric_filter_values(field_name, operator)
        combo = self.ui.metricValueComboBox
        combo.blockSignals(True)
        combo.clear()
        combo.addItems(values)
        combo.setEditable(not exact_operator)
        combo.setEnabled(operator != "has outlier" or bool(values))
        if exact_operator:
            if previous_value in values:
                combo.setCurrentText(previous_value)
            elif values:
                combo.setCurrentIndex(0)
            else:
                combo.setCurrentText("")
        else:
            combo.setCurrentText(previous_value)
        line_edit = combo.lineEdit()
        if line_edit is not None:
            line_edit.setPlaceholderText("Select a value" if exact_operator else "Type or choose a suggested value")
            line_edit.setReadOnly(exact_operator)
            line_edit.setCompleter(None if exact_operator else self._metric_filter_value_completer)
        self._metric_filter_value_model.setStringList(values)
        combo.blockSignals(False)

    def _metric_filter_values(self, field_name: str, operator: str) -> list[str]:
        field_key = _field_key(field_name)
        if operator == "has outlier" or field_key in {"has_outlier", "lane_has_outlier", "metric_has_outlier"}:
            return ["true", "false"]
        values: set[str] = set()
        row_dimension_name = self._row_dimension_name_for_filter_field(field_name)
        if row_dimension_name:
            values.update(
                str(item.dimensions.get(row_dimension_name, "") or "")
                for item in self._measurements
            )
            return sorted((value for value in values if value), key=_natural_text_key)
        for descriptor in self._metric_catalog:
            values.update(value for value in descriptor.field_values(field_name) if value)
        return sorted(values, key=_natural_text_key)

    def _row_dimension_name_for_filter_field(self, field_name: str) -> str | None:
        if self._template is None:
            return None
        normalized = field_name.strip().lower()
        for dimension in self._template.row_dimensions:
            if _field_key(normalized) == _field_key(dimension.name):
                return dimension.name
            if _field_key(normalized) == _field_key(_readable_field_name(dimension.name)):
                return dimension.name
            if dimension.display_name and _field_key(normalized) == _field_key(dimension.display_name):
                return dimension.name
        return None

    def _refresh_all(self) -> None:
        if self._template is None:
            return
        self._start_build_worker(selected_metrics=[], update_tree=True)

    def _start_build_worker(self, selected_metrics: list[str], update_tree: bool) -> None:
        if self._template is None:
            return
        signature = self._current_build_signature(selected_metrics)
        if signature == self._active_build_signature:
            return
        if signature == self._last_build_signature and self._current_result is not None:
            if update_tree:
                self._populate_metric_tree(self._current_result)
            self._queue_render_current_result()
            return
        self._build_request_id += 1
        request_id = self._build_request_id
        self._active_build_signature = signature
        worker = PlotBuildWorker(
            request_id=request_id,
            template=self._template,
            measurements=self._measurements,
            metric_rules=list(self._rules),
            selected_metrics=list(selected_metrics),
            lane_dimensions=self._lane_dimensions(),
            golden_path=self._context.golden_path,
            outlier_fail_method=self._context.outlier_fail_method,
            zscore_threshold=self._context.zscore_threshold,
            update_tree=update_tree,
        )
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._on_build_progress)
        worker.finished.connect(self._on_build_finished)
        worker.failed.connect(self._on_build_failed)
        worker.finished.connect(worker.deleteLater)
        worker.failed.connect(worker.deleteLater)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(
            lambda thread=thread: self._build_threads.remove(thread)
            if thread in self._build_threads
            else None
        )
        thread.finished.connect(
            lambda worker=worker: self._build_workers.remove(worker)
            if worker in self._build_workers
            else None
        )
        self._build_threads.append(thread)
        self._build_workers.append(worker)
        self._set_status_progress("Building plot groups...", 0, 1)
        thread.start()

    @Slot(int, str, int, int)
    def _on_build_progress(self, request_id: int, message: str, value: int, total: int) -> None:
        if request_id != self._build_request_id:
            return
        self._set_status_progress(message, value, total)

    @Slot(int, object, bool)
    def _on_build_finished(self, request_id: int, result: PlotBuildResult, update_tree: bool) -> None:
        if request_id != self._build_request_id:
            return
        self._current_result = result
        self._result_generation += 1
        self._last_build_signature = self._active_build_signature
        self._active_build_signature = None
        self._metric_catalog = result.metrics
        self._update_metric_search_completions(result.metrics)
        self._update_metric_filter_value_options()
        if update_tree:
            self._populate_metric_tree(result)
        self._queue_render_current_result()

    @Slot(int, str)
    def _on_build_failed(self, request_id: int, message: str) -> None:
        if request_id != self._build_request_id:
            return
        self._active_build_signature = None
        self._set_render_busy(False)
        self.ui.summaryLabel.setText(f"Plot build failed: {message}")

    def _current_build_signature(self, selected_metrics: list[str]) -> tuple[object, ...]:
        return (
            tuple((rule.connector, rule.field_name, rule.operator, rule.value) for rule in self._rules),
            tuple(selected_metrics),
            tuple(self._lane_dimensions()),
            self._context.golden_path,
            self._context.outlier_fail_method,
            self._context.zscore_threshold,
        )

    def _on_metric_search_text_changed(self, *args: object) -> None:
        self._enter_advances_search = False
        if self.ui.metricRealtimeCheckBox.isChecked():
            self._metric_search_timer.start(500)

    def _activate_search_from_enter(self) -> None:
        self._metric_search_timer.stop()
        if (
            self._enter_advances_search
            and self._current_search_signature() == self._search_display_signature
            and self._search_matches
        ):
            self._select_next_search_match()
            return
        self._refresh_search_results()
        self._enter_advances_search = True

    def _activate_search_from_button(self) -> None:
        self._refresh_search_results()
        self._enter_advances_search = True

    def _refresh_search_results_from_timer(self) -> None:
        self._refresh_search_results()
        self._enter_advances_search = False

    def _refresh_search_results(self) -> None:
        self._metric_search_timer.stop()
        signature = self._current_search_signature()
        if signature == self._search_display_signature:
            self._sync_search_state(reset_to_first=False, apply_scroll=False)
            self._apply_search_selection(apply_scroll=True)
            return
        self._start_search_worker(reset_to_first=True, apply_scroll=True)

    def _on_metric_search_completion_activated(self, text: str) -> None:
        self._metric_search_timer.stop()
        self.ui.metricSearchEdit.setText(text)
        self._refresh_search_results()
        self._enter_advances_search = True

    def _on_metric_search_view_changed(self, *args: object) -> None:
        self._enter_advances_search = False
        self._search_display_signature = None
        if self.ui.metricSearchViewComboBox.currentText() != "Compact Results":
            self._restore_compact_search_selection()
        self._rebuild_rendered_plot_widgets(reset_to_first=False, apply_scroll=False)

    def _on_metric_realtime_changed(self, *args: object) -> None:
        if self.ui.metricRealtimeCheckBox.isChecked():
            self._refresh_search_results()
        else:
            self._metric_search_timer.stop()

    def _select_next_search_match(self) -> None:
        self._advance_search_match(1)

    def _select_previous_search_match(self) -> None:
        self._advance_search_match(-1)

    def _advance_search_match(self, step: int) -> None:
        if not self._search_matches:
            self._start_search_worker(reset_to_first=True, apply_scroll=False)
            return
        self._search_match_cursor = (self._search_match_cursor + step) % len(self._search_matches)
        self._apply_search_selection(apply_scroll=True)

    def _update_metric_search_completions(self, metrics: tuple[MetricDescriptor, ...]) -> None:
        suggestions = set(self._metric_search_suggestions)
        for descriptor in metrics:
            suggestions.add(descriptor.display_label)
            suggestions.add(descriptor.logical_metric)
            suggestions.add(descriptor.group_display_name)
            suggestions.update(descriptor.raw_columns)
            for values in descriptor.header_values.values():
                suggestions.update(values)
        for item in self._rendered_plots:
            suggestions.add(item.title)
            suggestions.update(self._lane_header_labels())
            suggestions.update(item.payload.labels)
        self._metric_search_suggestions = suggestions
        self._metric_search_model.setStringList(sorted(item for item in suggestions if item))

    def _populate_metric_tree(self, result: PlotBuildResult) -> None:
        self._suspend_metric_item_changes = True
        tree = self.ui.metricTreeWidget
        tree.setUpdatesEnabled(False)
        tree.clear()
        tree.setHeaderLabels(["Metric / Lane", "Points"])
        try:
            for descriptor in result.metrics:
                series_items = result.series_by_metric.get(descriptor.logical_metric, ())
                point_count = sum(len(series.points) for series in series_items)
                marker = " *" if descriptor.has_outlier else ""
                parent = QTreeWidgetItem(
                    [
                        f"{descriptor.display_label}{marker}",
                        f"{point_count}",
                    ]
                )
                parent.setData(0, Qt.ItemDataRole.UserRole, descriptor.logical_metric)
                parent.setData(0, Qt.ItemDataRole.UserRole + 1, "metric")
                parent.setFlags(parent.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                parent.setCheckState(0, Qt.CheckState.Checked)
                tree.addTopLevelItem(parent)
                for series in series_items:
                    lane_outlier_count = sum(1 for point in series.points if point.outlier)
                    lane_marker = " *" if lane_outlier_count else ""
                    child = QTreeWidgetItem(
                        [
                            f"{series.label}{lane_marker}",
                            f"{len(series.points)}",
                        ]
                    )
                    child.setData(0, Qt.ItemDataRole.UserRole, descriptor.logical_metric)
                    child.setData(0, Qt.ItemDataRole.UserRole + 1, "lane")
                    child.setData(0, Qt.ItemDataRole.UserRole + 2, series.aggregate_id)
                    child.setFlags(child.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                    child.setCheckState(0, Qt.CheckState.Checked)
                    parent.addChild(child)
                parent.setExpanded(True)
            tree.resizeColumnToContents(0)
            tree.resizeColumnToContents(1)
        finally:
            tree.setUpdatesEnabled(True)
        self._suspend_metric_item_changes = False

    def _select_all_metric_tree_items(self) -> None:
        self._set_all_metric_tree_items_checked(Qt.CheckState.Checked)

    def _deselect_all_metric_tree_items(self) -> None:
        self._set_all_metric_tree_items_checked(Qt.CheckState.Unchecked)

    def _set_all_metric_tree_items_checked(self, state: Qt.CheckState) -> None:
        tree = self.ui.metricTreeWidget
        self._suspend_metric_item_changes = True
        tree.setUpdatesEnabled(False)
        try:
            for index in range(tree.topLevelItemCount()):
                parent = tree.topLevelItem(index)
                parent.setCheckState(0, state)
                for child_index in range(parent.childCount()):
                    parent.child(child_index).setCheckState(0, state)
        finally:
            tree.setUpdatesEnabled(True)
            self._suspend_metric_item_changes = False
        self._rebuild_rendered_plot_widgets(reset_to_first=False, apply_scroll=False)

    @staticmethod
    def _descriptor_matches_search(descriptor: MetricDescriptor, query: str) -> bool:
        values = [
            descriptor.display_label,
            descriptor.logical_metric,
            descriptor.group_id,
            descriptor.group_display_name,
            *(descriptor.raw_columns),
            *(value for values in descriptor.header_values.values() for value in values),
        ]
        return _text_matches_query(values, query)

    def _on_metric_tree_item_changed(self, item: QTreeWidgetItem, column: int) -> None:
        if self._suspend_metric_item_changes or column != 0:
            return
        self._suspend_metric_item_changes = True
        try:
            item_type = item.data(0, Qt.ItemDataRole.UserRole + 1)
            if item_type == "metric":
                state = item.checkState(0)
                for index in range(item.childCount()):
                    item.child(index).setCheckState(0, state)
            else:
                parent = item.parent()
                if parent is not None:
                    child_states = [
                        parent.child(index).checkState(0)
                        for index in range(parent.childCount())
                    ]
                    if all(state == Qt.CheckState.Checked for state in child_states):
                        parent.setCheckState(0, Qt.CheckState.Checked)
                    elif all(state == Qt.CheckState.Unchecked for state in child_states):
                        parent.setCheckState(0, Qt.CheckState.Unchecked)
                    else:
                        parent.setCheckState(0, Qt.CheckState.PartiallyChecked)
        finally:
            self._suspend_metric_item_changes = False
        self._rebuild_rendered_plot_widgets(reset_to_first=False, apply_scroll=False)

    def _on_metric_tree_selection_changed(self) -> None:
        if self._suspend_metric_tree_selection:
            return
        item = self.ui.metricTreeWidget.currentItem()
        if item is None:
            return
        self._locate_metric_tree_item(item, apply_scroll=True)

    def _on_lane_item_changed(self, *args: object) -> None:
        if not self._suspend_lane_item_changes:
            self._refresh_all()

    def _on_lane_order_changed(self, *args: object) -> None:
        if not self._suspend_lane_item_changes:
            self._refresh_all()

    def _queue_render_selected_metrics(self, *args: object) -> None:
        self._queue_render_current_result()

    def _queue_render_current_result(self, *args: object) -> None:
        if self._template is None:
            return
        self._render_timer.start(60)

    def _render_selected_metrics(self, *args: object) -> None:
        if self._template is None or self._current_result is None:
            return
        render_signature = self._current_render_signature()
        if render_signature == self._active_render_signature or render_signature == self._last_render_signature:
            return
        result = self._current_result
        lane_headers = self._lane_header_labels()
        render_items: list[tuple[MetricDescriptor, str, list[PlotSeries]]] = []
        for descriptor in result.selected_metrics:
            series = list(result.series_by_metric.get(descriptor.logical_metric, ()))
            if not series:
                continue
            render_items.append(
                (
                    descriptor,
                    self._metric_title(descriptor, series),
                    series,
                )
            )
        self.ui.summaryLabel.setText(self._summary_text(result))
        self._start_render_worker(
            items=render_items,
            lane_headers=lane_headers,
            plot_type=self.ui.plotTypeComboBox.currentText(),
            render_signature=render_signature,
        )

    def _start_render_worker(
        self,
        items: list[tuple[MetricDescriptor, str, list[PlotSeries]]],
        lane_headers: tuple[str, ...],
        plot_type: str,
        render_signature: tuple[object, ...],
    ) -> None:
        self._render_request_id += 1
        request_id = self._render_request_id
        self._active_render_signature = render_signature
        self._render_scroll_values[request_id] = self.ui.plotScrollArea.verticalScrollBar().value()
        if not items:
            self._active_render_signature = None
            self._last_render_signature = render_signature
            self._set_render_busy(False)
            self._clear_plot_layout()
            self._plot_layout.addStretch(1)
            return
        render_width = self._available_plot_width()
        self._last_render_width = render_width
        self._last_viewport_width = self.ui.plotScrollArea.viewport().width()
        worker = PlotRenderWorker(
            request_id=request_id,
            plot_type=plot_type,
            items=items,
            lane_headers=lane_headers,
            lane_height=self._lane_height,
            width=render_width,
            dpr=self.devicePixelRatioF(),
        )
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._on_render_progress)
        worker.finished.connect(self._on_render_finished)
        worker.failed.connect(self._on_render_failed)
        worker.finished.connect(worker.deleteLater)
        worker.failed.connect(worker.deleteLater)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(
            lambda thread=thread: self._render_threads.remove(thread)
            if thread in self._render_threads
            else None
        )
        thread.finished.connect(
            lambda worker=worker: self._render_workers.remove(worker)
            if worker in self._render_workers
            else None
        )
        self._render_threads.append(thread)
        self._render_workers.append(worker)
        self._set_render_busy(True, total=len(items))
        thread.start()

    def _available_plot_width(self) -> int:
        margins = self._plot_layout.contentsMargins()
        viewport_width = self.ui.plotScrollArea.viewport().width()
        return max(1, viewport_width - margins.left() - margins.right())

    @Slot(int, int, int, str)
    def _on_render_progress(self, request_id: int, index: int, total: int, label: str) -> None:
        if request_id != self._render_request_id:
            return
        self._render_progress.setRange(0, max(1, total))
        self._render_progress.setValue(max(0, index - 1))
        self._render_status_label.setText(f"Rendering {index}/{total}: {label}")

    @Slot(int, object)
    def _on_render_finished(self, request_id: int, rendered: list[RenderedMetricPlot]) -> None:
        preserved_value = self._render_scroll_values.pop(request_id, 0)
        if request_id != self._render_request_id:
            return
        self._last_render_signature = self._active_render_signature
        self._active_render_signature = None
        self._rendered_plots = list(rendered)
        self._rendered_generation += 1
        self._search_display_signature = None
        self._enter_advances_search = False
        self._update_metric_search_completions(tuple(item.descriptor for item in self._rendered_plots))
        self._rebuild_rendered_plot_widgets(reset_to_first=True, apply_scroll=False)
        self._set_render_busy(False)
        self._restore_plot_scroll_later(request_id, preserved_value)

    def _rebuild_rendered_plot_widgets(self, reset_to_first: bool, apply_scroll: bool, sync_search: bool = True) -> None:
        self.ui.plotScrollArea.setUpdatesEnabled(False)
        self._suspend_width_refresh = True
        try:
            self._clear_plot_layout()
            self._plot_groups = []
            self._sticky_axis.hide()
            lane_headers = self._lane_header_labels()
            dpr = self.devicePixelRatioF()
            if sync_search:
                self._sync_search_state(reset_to_first=reset_to_first, apply_scroll=False)
            for group_index, item in enumerate(self._rendered_plots):
                display_payload = self._display_payload_for_group(group_index, item)
                if display_payload is None:
                    continue
                title = self._metric_title_for_payload(item, display_payload)
                group = QWidget()
                group_layout = QVBoxLayout(group)
                group_layout.setContentsMargins(0, 0, 0, 0)
                group_layout.setSpacing(0)
                plot_body = QWidget(group)
                plot_body.setObjectName("plotBody")
                plot_body.setStyleSheet("QWidget#plotBody { background-color: #ffffff; }")
                plot_body_layout = QVBoxLayout(plot_body)
                plot_body_layout.setContentsMargins(0, 0, 0, 0)
                plot_body_layout.setSpacing(0)
                header = AxisLabel()
                header.bind_pixmap(
                    self._renderer.render_header_ruler(
                        title=title,
                        width=display_payload.logical_size().width(),
                        minimum=display_payload.minimum,
                        maximum=display_payload.maximum,
                        visible_height=42,
                        dpr=dpr,
                        label_margin=display_payload.label_margin,
                        lane_headers=lane_headers,
                        series=item.series,
                    )
                )
                plot_body_layout.addWidget(header)
                image = HoverImageLabel()
                image.bind_payload(display_payload)
                image.clippedOutlierDoubleClicked.connect(self._zoom_clipped_outlier_metric)
                image.resetMetricRangeRequested.connect(
                    lambda group_index=group_index: self._reset_metric_axis_range(group_index)
                )
                plot_body_layout.addWidget(image)
                group_layout.addWidget(plot_body)
                self._plot_layout.addWidget(group)
                self._plot_groups.append(
                    PlotGroupWidgets(
                        group_index=group_index,
                        header_key=id(header.current_pixmap()),
                        container=group,
                        header=header,
                        image=image,
                    )
                )
            self._plot_layout.addStretch(1)
            self._apply_search_selection(apply_scroll=apply_scroll)
            self._search_display_signature = self._current_search_signature()
        finally:
            self.ui.plotScrollArea.setUpdatesEnabled(True)
            QTimer.singleShot(0, self._resume_width_refresh_after_search_layout)
            QTimer.singleShot(30, self._resume_width_refresh_after_search_layout)

    def _current_search_signature(self) -> tuple[str, str, int]:
        return (
            self._metric_search_query(),
            self.ui.metricSearchViewComboBox.currentText(),
            self._rendered_generation,
        )

    def _resume_width_refresh_after_search_layout(self) -> None:
        self._suspend_width_refresh = False
        self._update_sticky_axis()

    @Slot(int, str)
    def _on_render_failed(self, request_id: int, message: str) -> None:
        self._render_scroll_values.pop(request_id, None)
        if request_id != self._render_request_id:
            return
        self._active_render_signature = None
        self._set_render_busy(False)
        self._render_status_label.setText(f"Render failed: {message}")

    def _set_render_busy(self, busy: bool, total: int = 0) -> None:
        self.ui.refreshButton.setEnabled(not busy)
        if busy:
            self._render_status_label.setText("Rendering...")
            self._render_progress.setEnabled(True)
            self._render_progress.setRange(0, max(1, total))
            self._render_progress.setValue(0)
        else:
            self._render_status_label.setText("Ready")
            self._render_progress.setRange(0, 1)
            self._render_progress.setValue(0)
            self._render_progress.setEnabled(False)

    def _set_status_busy(self, message: str, indeterminate: bool = False) -> None:
        self._render_status_label.setText(message)
        self._render_progress.setEnabled(True)
        if indeterminate:
            self._render_progress.setRange(0, 0)
        else:
            self._render_progress.setRange(0, 1)
            self._render_progress.setValue(0)

    def _set_status_progress(self, message: str, value: int, total: int) -> None:
        resolved_total = max(1, total)
        self._render_status_label.setText(message)
        self._render_progress.setEnabled(True)
        self._render_progress.setRange(0, resolved_total)
        self._render_progress.setValue(max(0, min(value, resolved_total)))

    def _set_controls_enabled(self, enabled: bool) -> None:
        self.ui.controlPanelScrollArea.setEnabled(enabled)
        self.ui.plotScrollArea.setEnabled(enabled)

    def _start_search_worker(self, reset_to_first: bool, apply_scroll: bool) -> None:
        query = self._metric_search_query()
        if not query:
            self._active_search_signature = None
            self._search_display_signature = self._current_search_signature()
            self._sync_search_state(reset_to_first=reset_to_first, apply_scroll=apply_scroll)
            return
        signature = self._current_search_signature()
        if signature == self._active_search_signature:
            return
        self._search_request_id += 1
        request_id = self._search_request_id
        self._active_search_signature = signature
        compact_mode = self.ui.metricSearchViewComboBox.currentText() == "Compact Results"
        if compact_mode:
            self._capture_compact_search_selection()
        groups = self._search_group_data(compact_mode=compact_mode)
        worker = SearchWorker(
            request_id=request_id,
            groups=groups,
            query=query,
            reset_to_first=reset_to_first,
            apply_scroll=apply_scroll,
        )
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._on_search_progress)
        worker.finished.connect(self._on_search_finished)
        worker.failed.connect(self._on_search_failed)
        worker.finished.connect(worker.deleteLater)
        worker.failed.connect(worker.deleteLater)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(
            lambda thread=thread: self._search_threads.remove(thread)
            if thread in self._search_threads
            else None
        )
        thread.finished.connect(
            lambda worker=worker: self._search_workers.remove(worker)
            if worker in self._search_workers
            else None
        )
        self._search_threads.append(thread)
        self._search_workers.append(worker)
        self._set_status_progress("Searching plot results...", 0, max(1, len(groups)))
        thread.start()

    @Slot(int, int, int, str)
    def _on_search_progress(self, request_id: int, index: int, total: int, label: str) -> None:
        if request_id != self._search_request_id:
            return
        self._set_status_progress(f"{label} {index}/{total}", index, total)

    def _search_group_data(self, compact_mode: bool) -> list[SearchGroupData]:
        lane_headers = self._lane_header_labels()
        groups: list[SearchGroupData] = []
        for group_index, item in enumerate(self._rendered_plots):
            visible_indices = tuple(range(len(item.series)))
            group_texts = (
                item.title,
                item.descriptor.display_label,
                item.descriptor.logical_metric,
                item.descriptor.group_id,
                item.descriptor.group_display_name,
                *item.descriptor.raw_columns,
                *(value for values in item.descriptor.header_values.values() for value in values),
            )
            groups.append(
                SearchGroupData(
                    group_index=group_index,
                    group_texts=tuple(str(value) for value in group_texts if value),
                    lane_headers=lane_headers,
                    lane_labels=tuple(item.payload.labels),
                    visible_indices=visible_indices,
                )
            )
        return groups

    @Slot(int, object, object, bool, bool)
    def _on_search_finished(
        self,
        request_id: int,
        matches: list[SearchMatch],
        result_groups: set[int],
        reset_to_first: bool,
        apply_scroll: bool,
    ) -> None:
        if request_id != self._search_request_id:
            return
        if self._current_search_signature() != self._active_search_signature:
            self._active_search_signature = None
            if self._active_build_signature is None and self._active_render_signature is None:
                self._set_render_busy(False)
            return
        self._active_search_signature = None
        self._search_matches = list(matches)
        self._search_result_groups = set(result_groups)
        compact_mode = self.ui.metricSearchViewComboBox.currentText() == "Compact Results"
        if compact_mode:
            self._sync_metric_tree_to_search_matches()
        if not self._search_matches:
            self._search_match_cursor = -1
        elif reset_to_first or self._search_match_cursor < 0 or self._search_match_cursor >= len(self._search_matches):
            self._search_match_cursor = 0
        if compact_mode:
            self._rebuild_rendered_plot_widgets(reset_to_first=False, apply_scroll=apply_scroll, sync_search=False)
        else:
            self._update_search_status()
            self._apply_search_selection(apply_scroll=apply_scroll)
            self._search_display_signature = self._current_search_signature()
        if compact_mode:
            self._render_status_label.setText(
                f"Search matched {len(self._search_matches)} lane(s); compact view updated"
            )
        elif self._search_matches:
            self._render_status_label.setText(f"Search matched {len(self._search_matches)} item(s)")
        else:
            self._render_status_label.setText("Search matched 0 item(s)")
        self._render_progress.setRange(0, 1)
        self._render_progress.setValue(0)
        self._render_progress.setEnabled(False)

    @Slot(int, str)
    def _on_search_failed(self, request_id: int, message: str) -> None:
        if request_id != self._search_request_id:
            return
        self._active_search_signature = None
        self._set_render_busy(False)
        self._render_status_label.setText(f"Search failed: {message}")

    def _sync_search_state(self, reset_to_first: bool, apply_scroll: bool) -> None:
        query = self._metric_search_query()
        if not query:
            self._restore_compact_search_selection()
            self._search_matches = []
            self._search_result_groups = set()
            self._search_match_cursor = -1
            self._update_search_status()
            self._clear_search_highlights()
            if self.ui.metricSearchViewComboBox.currentText() == "Compact Results":
                self._render_status_label.setText("Search: press Search to compact results")
            return
        matches: list[SearchMatch] = []
        result_groups: set[int] = set()
        lane_headers = self._lane_header_labels()
        compact_mode = self.ui.metricSearchViewComboBox.currentText() == "Compact Results"
        if compact_mode:
            self._capture_compact_search_selection()
        for group_index, item in enumerate(self._rendered_plots):
            visible_indices = set(range(len(item.series)))
            if not visible_indices:
                continue
            group_texts = [
                item.title,
                item.descriptor.display_label,
                item.descriptor.logical_metric,
                item.descriptor.group_id,
                item.descriptor.group_display_name,
                *(item.descriptor.raw_columns),
                *(value for values in item.descriptor.header_values.values() for value in values),
            ]
            group_match = _text_matches_query(group_texts, query)
            lane_matches = [
                lane_index
                for lane_index, label in enumerate(item.payload.labels)
                if lane_index in visible_indices
                if _text_matches_query([*group_texts, *lane_headers, label], query)
            ]
            if group_match or lane_matches:
                result_groups.add(group_index)
            if lane_matches:
                matches.extend(SearchMatch(group_index, lane_index) for lane_index in lane_matches)
            elif group_match:
                matches.append(SearchMatch(group_index, None))
        self._search_matches = matches
        self._search_result_groups = result_groups
        if compact_mode:
            self._sync_metric_tree_to_search_matches()
        if not matches:
            self._search_match_cursor = -1
        elif reset_to_first or self._search_match_cursor < 0 or self._search_match_cursor >= len(matches):
            self._search_match_cursor = 0
        self._update_search_status()
        self._apply_search_selection(apply_scroll=apply_scroll)
        if self.ui.metricSearchViewComboBox.currentText() == "Compact Results":
            self._render_status_label.setText(
                f"Search matched {len(self._search_matches)} lane(s); press Search to compact results"
            )

    def _display_payload_for_group(self, group_index: int, item: RenderedMetricPlot) -> RenderPayload | None:
        payload = item.payload
        visible_indices = self._displayed_lane_indices_for_group(group_index, item)
        if not visible_indices:
            return None
        if visible_indices == list(range(len(payload.labels))):
            return payload
        return self._build_compact_payload(payload, visible_indices)

    def _displayed_lane_indices_for_group(self, group_index: int, item: RenderedMetricPlot) -> list[int]:
        visible_indices = self._checked_lane_indices(item)
        if not visible_indices:
            return []
        if self._metric_search_query() and self.ui.metricSearchViewComboBox.currentText() == "Compact Results":
            if group_index not in self._search_result_groups:
                return []
            lane_matches = {
                match.lane_index
                for match in self._search_matches
                if match.group_index == group_index and match.lane_index is not None
            }
            if lane_matches:
                visible_indices = [index for index in visible_indices if index in lane_matches]
        return visible_indices

    def _checked_lane_indices(
        self,
        item: RenderedMetricPlot,
        selection: dict[str, set[str]] | None = None,
    ) -> list[int]:
        selected_lanes = (selection or self._selected_lane_keys_by_metric()).get(item.descriptor.logical_metric)
        if not selected_lanes:
            return []
        return [
            index
            for index, series in enumerate(item.series)
            if series.aggregate_id in selected_lanes
        ]

    def _capture_compact_search_selection(self) -> None:
        if self._compact_search_base_selection is None:
            self._compact_search_base_selection = self._selected_lane_keys_by_metric()

    def _restore_compact_search_selection(self) -> None:
        if self._compact_search_base_selection is None:
            return
        selection = self._compact_search_base_selection
        self._compact_search_base_selection = None
        self._set_metric_tree_selection(selection)

    def _sync_metric_tree_to_search_matches(self) -> None:
        selection: dict[str, set[str]] = {}
        for match in self._search_matches:
            if match.group_index < 0 or match.group_index >= len(self._rendered_plots):
                continue
            item = self._rendered_plots[match.group_index]
            if match.lane_index is None:
                selection[item.descriptor.logical_metric] = {
                    series.aggregate_id for series in item.series
                }
                continue
            if 0 <= match.lane_index < len(item.series):
                selection.setdefault(item.descriptor.logical_metric, set()).add(
                    item.series[match.lane_index].aggregate_id
                )
        self._set_metric_tree_selection(selection)

    def _set_metric_tree_selection(self, selection: dict[str, set[str]]) -> None:
        self._suspend_metric_item_changes = True
        tree = self.ui.metricTreeWidget
        tree.setUpdatesEnabled(False)
        try:
            for index in range(tree.topLevelItemCount()):
                parent = tree.topLevelItem(index)
                metric_key = str(parent.data(0, Qt.ItemDataRole.UserRole))
                lane_keys = selection.get(metric_key, set())
                checked_count = 0
                for child_index in range(parent.childCount()):
                    child = parent.child(child_index)
                    lane_key = str(child.data(0, Qt.ItemDataRole.UserRole + 2))
                    state = Qt.CheckState.Checked if lane_key in lane_keys else Qt.CheckState.Unchecked
                    child.setCheckState(0, state)
                    if state == Qt.CheckState.Checked:
                        checked_count += 1
                if parent.childCount() == 0:
                    parent.setCheckState(
                        0,
                        Qt.CheckState.Checked if metric_key in selection else Qt.CheckState.Unchecked,
                    )
                elif checked_count == parent.childCount():
                    parent.setCheckState(0, Qt.CheckState.Checked)
                elif checked_count == 0:
                    parent.setCheckState(0, Qt.CheckState.Unchecked)
                else:
                    parent.setCheckState(0, Qt.CheckState.PartiallyChecked)
        finally:
            tree.setUpdatesEnabled(True)
            self._suspend_metric_item_changes = False

    def _metric_title_for_payload(self, item: RenderedMetricPlot, payload: RenderPayload) -> str:
        suffix = ""
        if item.payload.reference_hidden_count:
            suffix = f" | reference hidden in {item.payload.reference_hidden_count} lane(s) with mixed golden ranges"
        return (
            f"{item.descriptor.display_label} | {payload.aggregate_count} lane(s), "
            f"{payload.point_count} point(s), {payload.outlier_count} outlier point(s){suffix}"
        )

    def _build_compact_payload(self, payload: RenderPayload, matches: list[int]) -> RenderPayload:
        if not matches:
            return payload
        source_size = payload.logical_size()
        dpr = payload.image.devicePixelRatio()
        top_margin = payload.lane_bands[0][0] if payload.lane_bands else 0.0
        lane_height = payload.lane_bands[0][1] if payload.lane_bands else float(self._lane_height)
        width = source_size.width()
        height = int(round(top_margin * 2.0 + lane_height * len(matches)))
        image, painter = self._renderer._make_image(width, height, dpr)
        new_hover_points: list[HoverPoint] = []
        new_lane_bands: list[tuple[float, float]] = []
        labels: list[str] = []
        try:
            image.fill(self._renderer._colors["background"])
            for compact_index, base_index in enumerate(matches):
                if base_index < 0 or base_index >= len(payload.lane_bands):
                    continue
                old_top, old_height = payload.lane_bands[base_index]
                new_top = top_margin + compact_index * old_height
                painter.drawImage(
                    QRectF(0.0, new_top, float(width), old_height),
                    payload.image,
                    QRectF(0.0, old_top * dpr, float(width) * dpr, old_height * dpr),
                )
                labels.append(payload.labels[base_index])
                new_lane_bands.append((new_top, old_height))
                y_offset = new_top - old_top
                lane_bottom = old_top + old_height
                for hover_point in payload.hover_points:
                    y = hover_point.position.y()
                    if old_top <= y < lane_bottom:
                        new_hover_points.append(
                            HoverPoint(
                                point=hover_point.point,
                                position=QPointF(hover_point.position.x(), hover_point.position.y() + y_offset),
                                radius=hover_point.radius,
                            )
                        )
        finally:
            if painter.isActive():
                painter.end()
        return RenderPayload(
            image=image,
            hover_points=tuple(new_hover_points),
            hover_buckets=self._renderer._build_hover_buckets(new_hover_points),
            labels=tuple(labels),
            lane_bands=tuple(new_lane_bands),
            label_margin=payload.label_margin,
            minimum=payload.minimum,
            maximum=payload.maximum,
            aggregate_count=len(labels),
            point_count=len(new_hover_points),
            outlier_count=sum(1 for item in new_hover_points if item.point.outlier),
            reference_hidden_count=payload.reference_hidden_count,
            clipped_low_count=sum(1 for item in new_hover_points if item.point.value < payload.minimum),
            clipped_high_count=sum(1 for item in new_hover_points if item.point.value > payload.maximum),
            pinned_point_key=payload.pinned_point_key,
        )

    @Slot(object)
    def _zoom_clipped_outlier_metric(self, point: object) -> None:
        metric_key = getattr(point, "logical_metric", "")
        point_value = getattr(point, "value", None)
        if not metric_key or point_value is None:
            return
        for group_index, rendered in enumerate(self._rendered_plots):
            if rendered.descriptor.logical_metric != metric_key:
                continue
            override = self._expanded_range_for_point(
                rendered.payload.minimum,
                rendered.payload.maximum,
                float(point_value),
            )
            self._start_single_metric_render_worker(
                group_index=group_index,
                range_override=override,
                pinned_point_key=_plot_point_key(point),
                status_message=f"Expanded axis for {rendered.descriptor.display_label} to include {float(point_value):.6g}",
            )
            return

    def _reset_metric_axis_range(self, group_index: int) -> None:
        if group_index < 0 or group_index >= len(self._rendered_plots):
            return
        rendered = self._rendered_plots[group_index]
        if rendered.payload.pinned_point_key is None:
            return
        self._start_single_metric_render_worker(
            group_index=group_index,
            status_message=f"Reset axis for {rendered.descriptor.display_label}",
        )

    def _start_single_metric_render_worker(
        self,
        group_index: int,
        range_override: tuple[float, float] | None = None,
        pinned_point_key: tuple[str, str, int, str] | None = None,
        status_message: str = "Updated metric plot",
    ) -> None:
        if group_index < 0 or group_index >= len(self._rendered_plots):
            return
        rendered = self._rendered_plots[group_index]
        self._render_request_id += 1
        request_id = self._render_request_id
        self._render_scroll_values[request_id] = self.ui.plotScrollArea.verticalScrollBar().value()
        render_width = self._available_plot_width()
        self._last_render_width = render_width
        self._last_viewport_width = self.ui.plotScrollArea.viewport().width()
        worker = SingleMetricRenderWorker(
            request_id=request_id,
            group_index=group_index,
            plot_type=self.ui.plotTypeComboBox.currentText(),
            rendered=rendered,
            lane_headers=self._lane_header_labels(),
            lane_height=self._lane_height,
            width=render_width,
            dpr=self.devicePixelRatioF(),
            range_override=range_override,
            pinned_point_key=pinned_point_key,
            status_message=status_message,
        )
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._on_single_metric_render_progress)
        worker.finished.connect(self._on_single_metric_render_finished)
        worker.failed.connect(self._on_render_failed)
        worker.finished.connect(worker.deleteLater)
        worker.failed.connect(worker.deleteLater)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(
            lambda thread=thread: self._render_threads.remove(thread)
            if thread in self._render_threads
            else None
        )
        thread.finished.connect(
            lambda worker=worker: self._render_workers.remove(worker)
            if worker in self._render_workers
            else None
        )
        self._render_threads.append(thread)
        self._render_workers.append(worker)
        self.ui.refreshButton.setEnabled(False)
        self._set_status_progress(f"Rendering metric: {rendered.descriptor.display_label}", 0, 1)
        thread.start()

    @Slot(int, int, int, str)
    def _on_single_metric_render_progress(self, request_id: int, index: int, total: int, label: str) -> None:
        if request_id != self._render_request_id:
            return
        self._set_status_progress(f"Rendering metric {index}/{total}: {label}", index - 1, total)

    @Slot(int, int, object, str)
    def _on_single_metric_render_finished(
        self,
        request_id: int,
        group_index: int,
        payload: RenderPayload,
        status_message: str,
    ) -> None:
        preserved_value = self._render_scroll_values.pop(request_id, self.ui.plotScrollArea.verticalScrollBar().value())
        if request_id != self._render_request_id:
            return
        if group_index < 0 or group_index >= len(self._rendered_plots):
            self._set_render_busy(False)
            return
        rendered = self._rendered_plots[group_index]
        self._rendered_plots[group_index] = RenderedMetricPlot(
            descriptor=rendered.descriptor,
            title=rendered.title,
            series=rendered.series,
            payload=payload,
        )
        self._rendered_generation += 1
        self._search_display_signature = None
        self._replace_single_metric_plot_widgets(group_index)
        self._sync_search_state(reset_to_first=False, apply_scroll=False)
        self._restore_plot_scroll_later(request_id, preserved_value)
        self._set_render_busy(False)
        self._render_status_label.setText(status_message)

    def _replace_single_metric_plot_widgets(self, group_index: int) -> None:
        if group_index < 0 or group_index >= len(self._rendered_plots):
            return
        group = self._plot_group_for_index(group_index)
        if group is None:
            self._rebuild_rendered_plot_widgets(reset_to_first=False, apply_scroll=False)
            return
        item = self._rendered_plots[group_index]
        display_payload = self._display_payload_for_group(group_index, item)
        if display_payload is None:
            self._rebuild_rendered_plot_widgets(reset_to_first=False, apply_scroll=False)
            return
        dpr = self.devicePixelRatioF()
        lane_headers = self._lane_header_labels()
        title = self._metric_title_for_payload(item, display_payload)
        group.header.bind_pixmap(
            self._renderer.render_header_ruler(
                title=title,
                width=display_payload.logical_size().width(),
                minimum=display_payload.minimum,
                maximum=display_payload.maximum,
                visible_height=42,
                dpr=dpr,
                label_margin=display_payload.label_margin,
                lane_headers=lane_headers,
                series=item.series,
            )
        )
        group.header_key = id(group.header.current_pixmap())
        group.image.bind_payload(display_payload)
        self._update_sticky_axis()

    def _render_single_metric_payload(
        self,
        rendered: RenderedMetricPlot,
        range_override: tuple[float, float] | None = None,
        pinned_point_key: tuple[str, str, int, str] | None = None,
    ) -> RenderPayload:
        plot_type = self.ui.plotTypeComboBox.currentText()
        if plot_type == "Box Plot":
            return self._renderer.render_box_series(
                rendered.series,
                lane_height=self._lane_height,
                width=self._available_plot_width(),
                dpr=self.devicePixelRatioF(),
                lane_headers=self._lane_header_labels(),
                range_override=range_override,
                pinned_point_key=pinned_point_key,
            )
        return self._renderer.render_ridge_series(
            rendered.series,
            lane_height=self._lane_height,
            width=self._available_plot_width(),
            dpr=self.devicePixelRatioF(),
            lane_headers=self._lane_header_labels(),
            range_override=range_override,
            pinned_point_key=pinned_point_key,
        )

    @staticmethod
    def _expanded_range_for_point(minimum: float, maximum: float, point_value: float) -> tuple[float, float]:
        expanded_minimum = min(minimum, point_value)
        expanded_maximum = max(maximum, point_value)
        if math.isclose(expanded_minimum, expanded_maximum):
            expanded_minimum -= 1.0
            expanded_maximum += 1.0
        span = expanded_maximum - expanded_minimum
        padding = span * 0.04
        return expanded_minimum - padding, expanded_maximum + padding

    def _scroll_to_metric_point_later(self, group_index: int, point: object) -> None:
        point_key = _plot_point_key(point)

        def scroll_once() -> None:
            group = self._plot_group_for_index(group_index)
            if group is None:
                return
            payload = group.image.current_payload()
            if payload is None:
                self._scroll_to_group(group)
                return
            for item in payload.hover_points:
                if _plot_point_key(item.point) == point_key:
                    self._scroll_to_group_lane(group, item.position.y(), 1.0)
                    return
            self._scroll_to_group(group)

        QTimer.singleShot(0, scroll_once)
        QTimer.singleShot(30, scroll_once)

    def _apply_search_selection(self, apply_scroll: bool) -> None:
        self._clear_search_highlights()
        self._update_search_status()
        if not self._search_matches or self._search_match_cursor < 0:
            return
        match = self._search_matches[self._search_match_cursor]
        self._select_metric_tree_match(match)
        group = self._plot_group_for_index(match.group_index)
        if group is None:
            return
        if match.lane_index is not None:
            payload = group.image.current_payload()
            if payload is not None:
                display_lane_index = self._display_lane_index(match)
                if 0 <= display_lane_index < len(payload.lane_bands):
                    lane_top, lane_height = payload.lane_bands[display_lane_index]
                    band = QRectF(0.0, lane_top, float(payload.logical_size().width()), lane_height)
                    group.image.set_search_highlight(band)
                    if apply_scroll:
                        self._scroll_to_group_lane(group, lane_top, lane_height)
                    return
        if apply_scroll:
            self._scroll_to_group(group)

    def _display_lane_index(self, match: SearchMatch) -> int:
        if match.group_index < 0 or match.group_index >= len(self._rendered_plots):
            return -1
        group_lane_indices = self._displayed_lane_indices_for_group(
            match.group_index,
            self._rendered_plots[match.group_index],
        )
        try:
            return group_lane_indices.index(match.lane_index)
        except ValueError:
            return -1

    def _select_metric_tree_match(self, match: SearchMatch) -> None:
        tree_item = self._tree_item_for_match(match)
        if tree_item is None:
            return
        self._suspend_metric_tree_selection = True
        try:
            tree = self.ui.metricTreeWidget
            tree.setCurrentItem(tree_item)
            tree.scrollToItem(tree_item)
        finally:
            self._suspend_metric_tree_selection = False

    def _tree_item_for_match(self, match: SearchMatch) -> QTreeWidgetItem | None:
        if match.group_index < 0 or match.group_index >= len(self._rendered_plots):
            return None
        rendered = self._rendered_plots[match.group_index]
        lane_key = None
        if match.lane_index is not None and 0 <= match.lane_index < len(rendered.series):
            lane_key = rendered.series[match.lane_index].aggregate_id
        return self._tree_item_for_metric_lane(rendered.descriptor.logical_metric, lane_key)

    def _tree_item_for_metric_lane(self, metric_key: str, lane_key: str | None) -> QTreeWidgetItem | None:
        tree = self.ui.metricTreeWidget
        for index in range(tree.topLevelItemCount()):
            parent = tree.topLevelItem(index)
            if str(parent.data(0, Qt.ItemDataRole.UserRole)) != metric_key:
                continue
            if lane_key is None:
                return parent
            for child_index in range(parent.childCount()):
                child = parent.child(child_index)
                if str(child.data(0, Qt.ItemDataRole.UserRole + 2)) == lane_key:
                    return child
            return parent
        return None

    def _locate_metric_tree_item(self, item: QTreeWidgetItem, apply_scroll: bool) -> None:
        match = self._search_match_for_tree_item(item)
        if match is None:
            return
        self._clear_search_highlights()
        group = self._plot_group_for_index(match.group_index)
        if group is None:
            return
        if match.lane_index is not None:
            payload = group.image.current_payload()
            if payload is not None:
                display_lane_index = self._display_lane_index(match)
                if 0 <= display_lane_index < len(payload.lane_bands):
                    lane_top, lane_height = payload.lane_bands[display_lane_index]
                    band = QRectF(0.0, lane_top, float(payload.logical_size().width()), lane_height)
                    group.image.set_search_highlight(band)
                    if apply_scroll:
                        self._scroll_to_group_lane(group, lane_top, lane_height)
                    return
        if apply_scroll:
            self._scroll_to_group(group)

    def _search_match_for_tree_item(self, item: QTreeWidgetItem) -> SearchMatch | None:
        item_type = item.data(0, Qt.ItemDataRole.UserRole + 1)
        metric_key = str(item.data(0, Qt.ItemDataRole.UserRole))
        lane_key = None
        if item_type == "lane":
            lane_key = str(item.data(0, Qt.ItemDataRole.UserRole + 2))
        for group_index, rendered in enumerate(self._rendered_plots):
            if rendered.descriptor.logical_metric != metric_key:
                continue
            if lane_key is None:
                return SearchMatch(group_index, None)
            for lane_index, series in enumerate(rendered.series):
                if series.aggregate_id == lane_key:
                    if lane_index in self._displayed_lane_indices_for_group(group_index, rendered):
                        return SearchMatch(group_index, lane_index)
                    return None
        return None

    def _plot_group_for_index(self, group_index: int) -> PlotGroupWidgets | None:
        for group in self._plot_groups:
            if group.group_index == group_index:
                return group
        return None

    def _clear_search_highlights(self) -> None:
        for group in self._plot_groups:
            group.image.set_search_highlight(None)

    def _update_search_status(self) -> None:
        total = len(self._search_matches)
        current = self._search_match_cursor + 1 if total and self._search_match_cursor >= 0 else 0
        self.ui.metricSearchStatusLabel.setText(f"{current} / {total}")
        enabled = total > 1
        self.ui.metricSearchPrevButton.setEnabled(enabled)
        self.ui.metricSearchNextButton.setEnabled(enabled)

    def _scroll_to_group(self, group: PlotGroupWidgets) -> None:
        viewport = self.ui.plotScrollArea.viewport()
        group_top = group.container.mapTo(viewport, QPoint(0, 0)).y()
        desired_value = self.ui.plotScrollArea.verticalScrollBar().value() + group_top
        self._restore_plot_scroll(desired_value)

    def _scroll_to_group_lane(self, group: PlotGroupWidgets, lane_top: float, lane_height: float) -> None:
        viewport = self.ui.plotScrollArea.viewport()
        image_top = group.image.mapTo(viewport, QPoint(0, 0)).y()
        target_center = image_top + lane_top + lane_height / 2.0
        desired_value = self.ui.plotScrollArea.verticalScrollBar().value() + target_center - viewport.height() / 2.0
        self._restore_plot_scroll(int(round(desired_value)))

    def _restore_plot_scroll(self, desired_value: int) -> None:
        scrollbar = self.ui.plotScrollArea.verticalScrollBar()
        scrollbar.setValue(max(scrollbar.minimum(), min(desired_value, scrollbar.maximum())))
        self._update_sticky_axis()

    def _restore_plot_scroll_later(self, request_id: int, desired_value: int) -> None:
        def restore_once() -> None:
            if request_id != self._render_request_id:
                return
            self._restore_plot_scroll(desired_value)

        def finish_restore() -> None:
            restore_once()
            if request_id == self._render_request_id:
                self._suspend_width_refresh = False

        QTimer.singleShot(0, restore_once)
        QTimer.singleShot(30, finish_restore)

    def _update_sticky_axis(self, *args: object) -> None:
        viewport = self.ui.plotScrollArea.viewport()
        for group in self._plot_groups:
            pixmap = group.header.current_pixmap()
            if pixmap is None:
                continue
            header_height = group.header.height()
            header_width = pixmap.deviceIndependentSize().toSize().width()
            if header_height <= 0:
                continue
            group_top = group.container.mapTo(viewport, QPoint(0, 0)).y()
            group_bottom = group_top + group.container.height()
            header_position = group.header.mapTo(viewport, QPoint(0, 0))
            header_top = header_position.y()
            if header_top <= 0 and group_bottom > 0:
                sticky_y = min(0, group_bottom - header_height)
                if sticky_y <= -header_height:
                    continue
                if self._sticky_axis_group_key != group.header_key:
                    self._sticky_axis.bind_pixmap(pixmap)
                    self._sticky_axis_group_key = group.header_key
                self._sticky_axis.setGeometry(header_position.x(), sticky_y, header_width, header_height)
                self._sticky_axis.show()
                self._sticky_axis.raise_()
                return
        self._sticky_axis_group_key = None
        self._sticky_axis.hide()

    def eventFilter(self, watched: QObject, event: QEvent) -> bool:
        if watched == self.ui.metricSearchEdit and event.type() == QEvent.Type.KeyPress:
            key = event.key()
            if key == Qt.Key.Key_Up:
                self._select_previous_search_match()
                return True
            if key == Qt.Key.Key_Down:
                self._select_next_search_match()
                return True
        if watched == self.ui.plotScrollArea.viewport() and event.type() == QEvent.Type.Resize:
            self._queue_width_refresh_if_viewport_width_changed()
            self._update_sticky_axis()
        return super().eventFilter(watched, event)

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        super().resizeEvent(event)
        self._queue_width_refresh()

    def closeEvent(self, event) -> None:  # type: ignore[override]
        self._close_requested = True
        self._stop_render_threads(wait=False)
        self._release_large_resources()
        super().closeEvent(event)
        self._delete_after_workers_finish()

    def _stop_render_threads(self, wait: bool = False) -> None:
        self._build_request_id += 1
        self._search_request_id += 1
        self._render_request_id += 1
        self._active_build_signature = None
        self._active_search_signature = None
        self._active_render_signature = None
        self._render_scroll_values.clear()
        self._set_render_busy(False)
        for worker in [self._load_worker, *self._build_workers, *self._search_workers, *self._render_workers]:
            if worker is not None and hasattr(worker, "cancel"):
                worker.cancel()
        if self._load_thread is not None and self._load_thread.isRunning():
            self._load_thread.quit()
            if wait:
                self._load_thread.wait(1500)
        for thread in list(self._build_threads):
            if thread.isRunning():
                thread.quit()
                if wait:
                    thread.wait(1500)
        for thread in list(self._search_threads):
            if thread.isRunning():
                thread.quit()
                if wait:
                    thread.wait(1500)
        for thread in list(self._render_threads):
            if thread.isRunning():
                thread.quit()
                if wait:
                    thread.wait(1500)
        self._build_workers.clear()
        self._search_workers.clear()
        self._render_workers.clear()

    def _worker_threads_running(self) -> bool:
        threads = [
            *(thread for thread in [self._load_thread] if thread is not None),
            *self._build_threads,
            *self._search_threads,
            *self._render_threads,
        ]
        return any(thread.isRunning() for thread in threads)

    def _delete_after_workers_finish(self) -> None:
        if not self._close_requested:
            return
        if self._worker_threads_running():
            for thread in [
                *(thread for thread in [self._load_thread] if thread is not None),
                *self._build_threads,
                *self._search_threads,
                *self._render_threads,
            ]:
                try:
                    thread.finished.disconnect(self._delete_after_workers_finish)
                except (RuntimeError, TypeError):
                    pass
                thread.finished.connect(self._delete_after_workers_finish)
            return
        self._close_requested = False
        self.deleteLater()

    def _release_large_resources(self) -> None:
        self._render_timer.stop()
        self._resize_render_timer.stop()
        self._metric_search_timer.stop()
        app = QApplication.instance()
        if app is not None:
            try:
                app.aboutToQuit.disconnect(self._stop_render_threads)
            except (RuntimeError, TypeError):
                pass
        self._clear_search_highlights()
        for group in self._plot_groups:
            group.header.clear_pixmap()
            group.image.clear_payload()
        self._clear_plot_layout()
        self._sticky_axis.clear_pixmap()
        self._sticky_axis_group_key = None
        self._rendered_plots.clear()
        self._plot_groups.clear()
        self._current_result = None
        self._measurements.clear()
        self._metric_catalog = ()
        self._metric_search_suggestions.clear()
        self._metric_search_model.setStringList([])
        self._metric_filter_value_model.setStringList([])
        self.ui.metricTreeWidget.clear()

    def _queue_width_refresh(self) -> None:
        if self._template is None or self._suspend_width_refresh:
            return
        width = self._available_plot_width()
        if abs(width - self._last_render_width) > 2:
            self._resize_render_timer.start(450)

    def _queue_width_refresh_if_viewport_width_changed(self) -> None:
        viewport_width = self.ui.plotScrollArea.viewport().width()
        if self._last_viewport_width and abs(viewport_width - self._last_viewport_width) <= 2:
            return
        self._last_viewport_width = viewport_width
        self._queue_width_refresh()

    def _current_render_signature(self) -> tuple[object, ...]:
        return (
            self._result_generation,
            self.ui.plotTypeComboBox.currentText(),
            self._available_plot_width(),
            tuple(self._lane_header_labels()),
        )

    def _metric_search_query(self) -> str:
        return self.ui.metricSearchEdit.text().strip()

    def _lane_dimensions(self) -> list[str]:
        dimensions: list[str] = []
        for index in range(self.ui.laneDimensionsListWidget.count()):
            item = self.ui.laneDimensionsListWidget.item(index)
            if item.checkState() == Qt.CheckState.Checked:
                dimensions.append(str(item.data(Qt.ItemDataRole.UserRole)))
        return dimensions

    def _lane_header_labels(self) -> tuple[str, ...]:
        labels: list[str] = []
        for index in range(self.ui.laneDimensionsListWidget.count()):
            item = self.ui.laneDimensionsListWidget.item(index)
            if item.checkState() == Qt.CheckState.Checked:
                labels.append(item.text())
        return tuple(labels) if labels else ("Lane",)

    def _selected_metric_keys(self) -> list[str]:
        keys: list[str] = []
        tree = self.ui.metricTreeWidget
        for index in range(tree.topLevelItemCount()):
            parent = tree.topLevelItem(index)
            metric_key = str(parent.data(0, Qt.ItemDataRole.UserRole))
            if parent.childCount() == 0:
                if parent.checkState(0) == Qt.CheckState.Checked:
                    keys.append(metric_key)
                continue
            if any(
                parent.child(child_index).checkState(0) == Qt.CheckState.Checked
                for child_index in range(parent.childCount())
            ):
                keys.append(metric_key)
        return keys

    def _selected_lane_keys_by_metric(self) -> dict[str, set[str]]:
        selected: dict[str, set[str]] = {}
        tree = self.ui.metricTreeWidget
        for index in range(tree.topLevelItemCount()):
            parent = tree.topLevelItem(index)
            metric_key = str(parent.data(0, Qt.ItemDataRole.UserRole))
            lane_keys = {
                str(parent.child(child_index).data(0, Qt.ItemDataRole.UserRole + 2))
                for child_index in range(parent.childCount())
                if parent.child(child_index).checkState(0) == Qt.CheckState.Checked
            }
            if lane_keys:
                selected[metric_key] = lane_keys
        return selected

    def _metric_title(self, descriptor: MetricDescriptor, series: list) -> str:
        point_count = sum(len(item.points) for item in series)
        outlier_count = sum(sum(1 for point in item.points if point.outlier) for item in series)
        hidden_count = sum(1 for item in series if len(item.reference_ranges) > 1)
        suffix = ""
        if hidden_count:
            suffix = f" | reference hidden in {hidden_count} lane(s) with mixed golden ranges"
        return (
            f"{descriptor.display_label} | {len(series)} lane(s), "
            f"{point_count} point(s), {outlier_count} outlier point(s){suffix}"
        )

    @staticmethod
    def _summary_text(result: PlotBuildResult) -> str:
        summary = result.summary()
        return (
            f"Matched metrics: {summary['matched_metrics']} | "
            f"Selected metrics: {summary['selected_metrics']} | "
            f"Points: {summary['point_count']} | "
            f"Outlier points: {summary['outlier_count']} | "
            f"Lanes: {summary['lane_count']} | "
            f"Lanes with < 5 points: {summary['lanes_with_few_points']}"
        )

    def _clear_plot_layout(self) -> None:
        for group in self._plot_groups:
            group.header.clear_pixmap()
            group.image.clear_payload()
        self._plot_groups = []
        self._sticky_axis.clear_pixmap()
        self._sticky_axis_group_key = None
        self._sticky_axis.hide()
        while self._plot_layout.count():
            item = self._plot_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()


def _format_optional(value: float | None) -> str:
    return "" if value is None else f"{value:.6g}"


def _plot_point_key(point: object) -> tuple[str, str, int, str]:
    return (
        str(getattr(point, "dataset_id", "")),
        str(getattr(point, "source_file", "")),
        int(getattr(point, "row_number", 0)),
        str(getattr(point, "raw_column", "")),
    )


def _plot_point_merge_key(point: object) -> tuple[str, int, str]:
    return (
        str(getattr(point, "dataset_id", "")),
        int(getattr(point, "row_number", 0)),
        str(getattr(point, "raw_column", "")),
    )


def _format_merged_outlier_status(point: object) -> str:
    if not bool(getattr(point, "outlier", False)):
        return "not a raw outlier"
    if bool(getattr(point, "merged_outlier", False)):
        return "merged outlier"
    if str(getattr(point, "merge_block_key", "")):
        return "raw outlier only"
    return "not evaluated"


def _natural_text_key(value: str) -> tuple[object, ...]:
    parts = re.split(r"(\d+)", value.lower())
    return tuple(int(part) if part.isdigit() else part for part in parts)


def _readable_field_name(value: str) -> str:
    text = re.sub(r"[_\-]+", " ", value).strip()
    text = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", text)
    return " ".join(part.upper() if part.lower() in {"id"} else part.capitalize() for part in text.split())


def _field_key(value: str) -> str:
    return re.sub(r"[^0-9a-zA-Z]+", "_", value.strip().lower()).strip("_")


def _text_matches_query(values: tuple[str, ...] | list[str], query: str) -> bool:
    if not _has_explicit_space(query):
        return _single_token_matches(values, query)
    tokens = _search_tokens(query)
    if not tokens:
        return True
    compact_values = [_compact_search_text(value) for value in values if value]
    combined = _normalize_search_text(" ".join(values))
    combined_compact = _compact_search_text(combined)
    return all(
        _search_token_matches_text(token, compact_values, combined, combined_compact)
        for token in tokens
    )


def _single_token_matches(values: tuple[str, ...] | list[str], query: str) -> bool:
    normalized_token = _normalize_search_text(query)
    compact_token = _compact_search_text(query)
    if not normalized_token and not compact_token:
        return True
    for value in values:
        normalized_value = _normalize_search_text(value)
        if normalized_token and normalized_token in normalized_value:
            return True
        if compact_token and any(compact_token in segment for segment in _compact_search_segments(value)):
            return True
    return False


def _search_tokens(query: str) -> list[str]:
    return [token for token in _normalize_search_text(query).split() if token]


def _normalize_search_text(value: str) -> str:
    normalized = re.sub(r"[^0-9a-zA-Z]+", " ", value.lower())
    return " ".join(normalized.split())


def _compact_search_text(value: str) -> str:
    return re.sub(r"[^0-9a-zA-Z]+", "", value.lower())


def _compact_search_segments(value: str) -> list[str]:
    return [_compact_search_text(segment) for segment in re.findall(r"[0-9a-zA-Z]+", value.lower())]


def _search_token_matches_text(
    token: str,
    compact_values: list[str],
    combined: str,
    combined_compact: str,
) -> bool:
    compact_token = _compact_search_text(token)
    if token in combined:
        return True
    if compact_token and any(compact_token in value for value in compact_values):
        return True
    if compact_token and compact_token in combined_compact and not _contains_digit(compact_token):
        return True
    if _contains_digit(compact_token):
        return False
    if len(compact_token) < 2:
        return False
    return any(
        _is_subsequence(compact_token, value)
        for value in compact_values
        if len(value) >= len(compact_token)
    )


def _is_subsequence(needle: str, haystack: str) -> bool:
    position = 0
    for char in haystack:
        if position < len(needle) and needle[position] == char:
            position += 1
            if position == len(needle):
                return True
    return False


def _contains_digit(value: str) -> bool:
    return any(char.isdigit() for char in value)


def _has_explicit_space(value: str) -> bool:
    return bool(re.search(r"\s", value))
