from __future__ import annotations

from datetime import datetime
import json
import multiprocessing as mp
from queue import Empty
import re
import sys
import traceback
from uuid import uuid4
from pathlib import Path
import qdarktheme

from ..golden_rules import (
    OUTLIER_GOLDEN_METHOD_EXAMPLES,
    normalize_outlier_golden_method,
    outlier_golden_method_modifiers,
    outlier_golden_method_terms,
)
from ..gui_state import load_gui_state, save_gui_state
from ..output_paths import derive_split_output_paths, resolve_split_output_base_path
from ..runtime import (
    APP_DISPLAY_NAME,
    APP_TEAM,
    APP_VERSION,
    bundled_template_path,
    default_database_root,
    default_dialog_dir,
    default_output_path,
    icon_png_path,
)
from ..service import (
    SAMPLE_KEY_FILTER,
    analyze_report_outlier_summary_artifacts,
    analyze_report_outlier_summary_artifacts_from_storage,
    build_column_filters,
    build_dimension_filters,
    clear_storage_root,
    delete_storage_workspace,
    create_golden_reference,
    delete_storage_rows,
    discard_storage_workspace_changes,
    describe_storage,
    ensure_storage_workspace,
    generate_report,
    generate_report_from_storage,
    import_dataset,
    list_import_history,
    parse_csv_items,
    parse_filter_text,
    parse_semicolon_items,
    preview_import,
    save_debug_bundle,
    save_storage_workspace,
    save_storage_workspace_as,
    storage_workspace_differs,
    summarize_built_golden_coverage_for_input,
    summarize_built_golden_coverage_for_storage,
)
from ..template import (
    OUTLIER_MERGE_ORDER_OPTIONS,
    load_template,
    save_template,
    summarize_template,
)
from ..workspace import default_database_output_path
from .ui_about_dialog import Ui_AboutDialog
from .ui_main_window import Ui_MainWindow

try:
    from PySide6.QtCore import QDateTime, QObject, QThread, QTimer, Qt, QUrl, Signal, Slot
    from PySide6.QtGui import QAction, QCloseEvent, QDesktopServices, QIcon, QPixmap
    from PySide6.QtWidgets import (
        QApplication,
        QDialog,
        QFileDialog,
        QInputDialog,
        QLabel,
        QListWidgetItem,
        QMainWindow,
        QMenu,
        QMessageBox,
        QPushButton,
        QProgressBar,
        QSizePolicy,
        QTableWidgetItem,
    )
except ImportError as exc:
    raise RuntimeError(
        "PySide6 is not installed yet. Activate the project virtual environment and install dependencies first."
    ) from exc


OUTLIER_CRITERIA_OPTIONS = [
    ("Modified Z Score", "modified_z_score"),
    ("Golden Deviation", "golden_deviation"),
    ("Modified Z Score And Golden Deviation", "zscore_and_golden"),
    ("Modified Z Score Or Golden Deviation", "zscore_or_golden"),
]
ANALYSIS_SCOPE_OPTIONS = [
    ("Current Input File", "current_input_file"),
    ("Entire Database", "entire_database"),
    ("Checked Imports", "checked_imports"),
]
CENTER_METHOD_OPTIONS = [
    ("Mean", "mean"),
    ("Median", "median"),
]
OUTLIER_GOLDEN_METHOD_OPTIONS = [
    (item, item) for item in OUTLIER_GOLDEN_METHOD_EXAMPLES
]
NUMERIC_CLEANUP_MODE_OPTIONS = [
    ("Remove All Non-Numeric Characters", "all_non_numeric"),
    ("Remove Specified Characters", "specified_chars"),
]
OUTLIER_MERGE_ORDER_GUI_OPTIONS = [(item, item) for item in OUTLIER_MERGE_ORDER_OPTIONS]


def _natural_sort_key(value: str) -> tuple[object, ...]:
    parts = re.split(r"(\d+)", str(value or ""))
    key: list[object] = []
    for part in parts:
        if not part:
            continue
        if part.isdigit():
            key.append((0, int(part)))
        else:
            key.append((1, part.lower()))
    return tuple(key)


class NaturalSortTableWidgetItem(QTableWidgetItem):
    def __lt__(self, other: object) -> bool:
        if not isinstance(other, QTableWidgetItem):
            return super().__lt__(other)
        return _natural_sort_key(self.text()) < _natural_sort_key(other.text())


class BackgroundTaskWorker(QObject):
    progress = Signal(int, str)
    finished = Signal(object)
    failed = Signal(str, str)

    def __init__(self, task_callable) -> None:
        super().__init__()
        self._task_callable = task_callable

    @Slot()
    def run(self) -> None:
        try:
            result = self._task_callable(self._report_progress)
        except Exception as exc:  # pragma: no cover - UI path
            self.failed.emit(str(exc), traceback.format_exc())
            return
        self.finished.emit(result)

    def _report_progress(self, value: int, message: str) -> None:
        self.progress.emit(value, message)


def _run_analysis_in_subprocess(payload: dict[str, object], result_queue) -> None:
    def send_progress(value: int, message: str) -> None:
        result_queue.put({"type": "progress", "value": value, "message": message})

    try:
        analysis_scope = str(payload["analysis_scope"])
        template_path = str(payload["template_path"])
        built_golden_path = payload.get("built_golden_path")
        if built_golden_path is not None:
            built_golden_path = str(built_golden_path)
        outlier_fail_method = payload.get("outlier_fail_method_override")
        if outlier_fail_method is not None:
            outlier_fail_method = str(outlier_fail_method)
        outlier_merge_order = payload.get("outlier_merge_order_override")
        if outlier_merge_order is not None:
            outlier_merge_order = str(outlier_merge_order)
        zscore_threshold_override = payload.get("zscore_threshold_override")
        dataset_ids = payload.get("dataset_ids")
        dimension_filters = payload.get("dimension_filters")
        column_filters = payload.get("column_filters")
        temp_output_path = str(payload["temp_output_path"])

        if analysis_scope == "current_input_file":
            input_path = str(payload["input_path"])
            golden_coverage_summary = None
            if built_golden_path:
                golden_coverage_summary = summarize_built_golden_coverage_for_input(
                    template_path=template_path,
                    input_path=input_path,
                    golden_path=built_golden_path,
                    dimension_filters=dimension_filters,
                    column_filters=column_filters,
                    progress_callback=lambda value, message: send_progress(
                        min(18, max(2, value // 6)),
                        message,
                    ),
                )
            send_progress(22, "Preparing report generation...")
            report_payload = generate_report(
                template_path=template_path,
                input_path=input_path,
                output_path=temp_output_path,
                built_golden_path=built_golden_path,
                outlier_fail_method_override=outlier_fail_method,
                outlier_merge_order_override=outlier_merge_order,
                zscore_threshold_override=zscore_threshold_override,
                dimension_filters=dimension_filters,
                column_filters=column_filters,
                if_exists="overwrite",
                progress_callback=lambda value, message: send_progress(
                    20 + int(value * 0.55),
                    message,
                ),
            )
            send_progress(78, "Preparing outlier summary...")
            outlier_artifacts = analyze_report_outlier_summary_artifacts(
                template_path=template_path,
                input_path=input_path,
                built_golden_path=built_golden_path,
                outlier_fail_method_override=outlier_fail_method,
                outlier_merge_order_override=outlier_merge_order,
                zscore_threshold_override=zscore_threshold_override,
                dimension_filters=dimension_filters,
                column_filters=column_filters,
                progress_callback=lambda value, message: send_progress(
                    78 + int(value * 0.20),
                    message,
                ),
            )
        else:
            storage_path = str(payload["storage_path"])
            golden_coverage_summary = None
            if built_golden_path:
                golden_coverage_summary = summarize_built_golden_coverage_for_storage(
                    storage_path=storage_path,
                    golden_path=built_golden_path,
                    dataset_ids=dataset_ids,
                    dimension_filters=dimension_filters,
                    column_filters=column_filters,
                    template_path=template_path,
                    progress_callback=lambda value, message: send_progress(
                        min(18, max(2, value // 6)),
                        message,
                    ),
                )
            send_progress(22, "Preparing report generation...")
            report_payload = generate_report_from_storage(
                template_path=template_path,
                storage_path=storage_path,
                output_path=temp_output_path,
                built_golden_path=built_golden_path,
                outlier_fail_method_override=outlier_fail_method,
                outlier_merge_order_override=outlier_merge_order,
                zscore_threshold_override=zscore_threshold_override,
                dataset_ids=dataset_ids,
                dimension_filters=dimension_filters,
                column_filters=column_filters,
                if_exists="overwrite",
                progress_callback=lambda value, message: send_progress(
                    20 + int(value * 0.55),
                    message,
                ),
            )
            send_progress(78, "Preparing outlier summary...")
            outlier_artifacts = analyze_report_outlier_summary_artifacts_from_storage(
                template_path=template_path,
                storage_path=storage_path,
                built_golden_path=built_golden_path,
                outlier_fail_method_override=outlier_fail_method,
                outlier_merge_order_override=outlier_merge_order,
                zscore_threshold_override=zscore_threshold_override,
                dataset_ids=dataset_ids,
                dimension_filters=dimension_filters,
                column_filters=column_filters,
                progress_callback=lambda value, message: send_progress(
                    78 + int(value * 0.20),
                    message,
                ),
            )
        send_progress(99, "Finalizing analysis result...")
        result_queue.put(
            {
                "type": "result",
                "ok": True,
                "payload": report_payload,
                "golden_coverage_summary": golden_coverage_summary,
                "outlier_summary_rows": outlier_artifacts["summary_rows"],
                "outlier_summary_stats_rows": outlier_artifacts.get("summary_stats_rows", []),
                "outlier_ratio_rows": outlier_artifacts["ratio_rows"],
            }
        )
    except Exception as exc:  # pragma: no cover - subprocess path
        result_queue.put(
            {
                "type": "result",
                "ok": False,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            }
        )


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        expanding_policy = QSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Expanding,
        )
        self.ui.leftPanel.setSizePolicy(expanding_policy)
        self.ui.workbenchTabWidget.setSizePolicy(expanding_policy)
        self.ui.leftPanelLayout.setStretch(0, 1)
        self._ensure_help_menu()
        self._apply_window_icon()
        self._configure_combo_boxes()
        self.current_golden_coverage_summary: dict | None = None
        self.current_outlier_summary_rows: list[dict[str, object]] = []
        self.current_outlier_ratio_rows: list[dict[str, object]] = []
        self._template_backed_golden_values: dict[str, float | None] = {
            "relative_limit": None,
            "sigma_multiplier": None,
            "absolute_lower_bound": None,
            "absolute_upper_bound": None,
            "overwrite_lowerbound": None,
            "overwrite_upperbound": None,
            "continuous_interval": None,
        }
        self._template_analysis_dimension_filters: dict[str, dict[str, list[str]]] = {}
        self._template_analysis_column_filters: dict[str, dict[str, list[str]]] = {}
        self.current_storage_headers: list[str] = []
        self.current_workspace_path: str = ""
        self._verbose_logging_enabled = False
        self._last_verbose_progress_signature: tuple[str | None, int, str] | None = None
        self._active_task_thread: QThread | None = None
        self._active_task_worker: BackgroundTaskWorker | None = None
        self._active_task_title: str | None = None
        self._active_task_success_handler = None
        self._background_task_outcome: tuple[str, object] | tuple[str, str, str] | None = None
        self._retained_background_workers: list[BackgroundTaskWorker] = []
        self._analysis_process: mp.Process | None = None
        self._analysis_result_queue = None
        self._analysis_poll_timer = QTimer(self)
        self._analysis_poll_timer.setInterval(200)
        self._analysis_poll_timer.timeout.connect(self._poll_analysis_process)
        self._analysis_final_output_path: str | None = None
        self._analysis_temp_output_path: str | None = None
        self._progress_label = QLabel("")
        self._progress_bar = QProgressBar()
        self._cancel_task_button = QPushButton("Cancel Analysis")
        self._setup_progress_widgets()
        self._wire_events()
        self._apply_defaults()
        self._ensure_storage_workspace_for_current_database(silent=True)
        self._prompt_workspace_recovery_if_needed()
        self._update_analysis_mode_state()
        self._refresh_analysis_imports(silent=True)
        self._refresh_storage_overview(silent=True)
        self._refresh_golden_coverage_view(None)
        self._refresh_outlier_summary_view([], [])
        self._load_saved_settings_for_current_database(silent=True)

    def _ensure_help_menu(self) -> None:
        menu_bar = self.menuBar()
        menu_help = getattr(self.ui, "menuHelp", None)
        if menu_help is None:
            menu_help = QMenu("Help", self)
            menu_help.setObjectName("menuHelp")
            self.ui.menuHelp = menu_help

        action_about = getattr(self.ui, "actionAboutEasyOutlier", None)
        if action_about is None:
            action_about = QAction("About Easy Outlier", self)
            action_about.setObjectName("actionAboutEasyOutlier")
            self.ui.actionAboutEasyOutlier = action_about

        menu_help.setTitle("Help")
        action_about.setText("About Easy Outlier")

        if action_about not in menu_help.actions():
            menu_help.addAction(action_about)

        existing_menu_actions = {action.menu() for action in menu_bar.actions() if action.menu() is not None}
        if menu_help not in existing_menu_actions:
            menu_bar.addMenu(menu_help)

    def _wire_events(self) -> None:
        self.ui.actionSaveDatabase.triggered.connect(self._save_database)
        self.ui.actionSaveDatabaseAs.triggered.connect(self._save_database_as)
        self.ui.actionVerboseLogging.toggled.connect(self._on_verbose_logging_toggled)
        self.ui.actionAboutEasyOutlier.triggered.connect(self._show_about_dialog)
        self.ui.browseTemplateButton.clicked.connect(self._browse_template)
        self.ui.validateTemplateButton.clicked.connect(self._validate_template)
        self.ui.exportTemplateJsonButton.clicked.connect(self._export_template_json)
        self.ui.exportTemplateExcelButton.clicked.connect(self._export_template_excel)
        self.ui.saveDebugBundleButton.clicked.connect(self._save_debug_bundle)
        self.ui.browseInputButton.clicked.connect(self._browse_input)
        self.ui.browseStorageButton.clicked.connect(self._browse_storage)
        self.ui.browseGoldenButton.clicked.connect(self._browse_golden)
        self.ui.browseOutputButton.clicked.connect(self._browse_output)
        self.ui.importButton.clicked.connect(self._import_dataset)
        self.ui.refreshStorageViewButton.clicked.connect(self._refresh_storage_overview)
        self.ui.deleteSelectedRowsButton.clicked.connect(self._delete_selected_storage_rows)
        self.ui.refreshAnalysisImportsButton.clicked.connect(self._refresh_analysis_imports)
        self.ui.buildGoldenButton.clicked.connect(self._build_golden)
        self.ui.runAnalysisButton.clicked.connect(self._run_analysis)
        self.ui.analysisScopeComboBox.currentTextChanged.connect(self._update_analysis_mode_state)
        self.ui.thresholdModeComboBox.currentTextChanged.connect(self._update_golden_threshold_mode_state)
        self.ui.numericCleanupCheckBox.toggled.connect(self._update_numeric_cleanup_state)
        self.ui.numericCleanupModeComboBox.currentTextChanged.connect(self._update_numeric_cleanup_state)
        self.ui.templatePathEdit.textChanged.connect(self._update_template_conversion_buttons)
        self._connect_optional_button("openTemplateButton", self._open_template_file)
        self._connect_optional_button("openInputButton", self._open_input_file)
        self._connect_optional_button("openGoldenButton", self._open_golden_file)
        self._connect_optional_button("openDatabaseButton", self._open_database_folder)
        self._connect_optional_button("openResultButton", self._open_result_folder)

    def _apply_window_icon(self) -> None:
        icon_path = icon_png_path()
        if icon_path is None:
            return
        icon = QIcon(str(icon_path))
        self.setWindowIcon(icon)
        app = QApplication.instance()
        if app is not None:
            app.setWindowIcon(icon)

    def _show_about_dialog(self) -> None:
        dialog = AboutDialog(self)
        dialog.exec()

    def _setup_progress_widgets(self) -> None:
        self._progress_label.setMinimumWidth(220)
        self._progress_bar.setMinimumWidth(220)
        self._progress_bar.setRange(0, 100)
        self._progress_bar.setValue(0)
        self._cancel_task_button.clicked.connect(self._cancel_analysis_process)
        self._progress_label.hide()
        self._progress_bar.hide()
        self._cancel_task_button.hide()
        self.statusBar().addPermanentWidget(self._progress_label)
        self.statusBar().addPermanentWidget(self._progress_bar)
        self.statusBar().addPermanentWidget(self._cancel_task_button)

    def _update_numeric_cleanup_state(self) -> None:
        enabled = self.ui.numericCleanupCheckBox.isChecked()
        mode = self._combo_code(self.ui.numericCleanupModeComboBox)
        self.ui.numericCleanupModeComboBox.setEnabled(enabled)
        self.ui.numericCleanupCharsEdit.setEnabled(enabled and mode == "specified_chars")

    def _update_template_conversion_buttons(self) -> None:
        suffix = Path(self.ui.templatePathEdit.text().strip()).suffix.lower()
        disable_to_xlsx = suffix == ".xlsx"
        disable_to_json = suffix == ".json"
        self.ui.exportTemplateJsonButton.setEnabled(not disable_to_xlsx)
        self.ui.exportTemplateExcelButton.setEnabled(not disable_to_json)

    def _set_busy_state(self, busy: bool, title: str | None = None) -> None:
        self.ui.workbenchTabWidget.setEnabled(not busy)
        self.ui.actionSaveDatabase.setEnabled(not busy)
        self.ui.actionSaveDatabaseAs.setEnabled(not busy)
        self._last_verbose_progress_signature = None
        if busy:
            self._progress_label.setText(title or "Working...")
            self._progress_label.show()
            self._progress_bar.setRange(0, 0)
            self._progress_bar.show()
            self._cancel_task_button.setVisible(self._analysis_process is not None)
            self.statusBar().showMessage(title or "Working...")
        else:
            self._progress_label.hide()
            self._progress_bar.hide()
            self._cancel_task_button.hide()
            self._progress_bar.setRange(0, 100)
            self._progress_bar.setValue(0)
            self._progress_label.setText("")

    def _update_task_progress(self, value: int, message: str) -> None:
        self._progress_label.setText(message)
        if value < 0:
            self._progress_bar.setRange(0, 0)
        else:
            if self._progress_bar.maximum() == 0:
                self._progress_bar.setRange(0, 100)
            self._progress_bar.setValue(max(0, min(100, value)))
        self.statusBar().showMessage(message)

    def _start_background_task(
        self,
        title: str,
        task_callable,
        success_handler,
    ) -> None:
        if self._active_task_thread is not None:
            QMessageBox.information(
                self,
                "Task Running",
                "Another background task is still running. Please wait for it to finish first.",
            )
            return
        thread = QThread(self)
        worker = BackgroundTaskWorker(task_callable)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._update_task_progress)
        worker.finished.connect(self._store_background_task_success)
        worker.failed.connect(self._store_background_task_failure)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(self._on_background_task_thread_finished)
        thread.finished.connect(thread.deleteLater)
        self._active_task_thread = thread
        self._active_task_worker = worker
        self._active_task_title = title
        self._active_task_success_handler = success_handler
        self._background_task_outcome = None
        self._set_busy_state(True, title)
        thread.start()

    def _clear_background_task(self) -> None:
        self._active_task_thread = None
        self._active_task_worker = None
        self._active_task_title = None
        self._active_task_success_handler = None
        self._background_task_outcome = None
        self._set_busy_state(False)

    @Slot(object)
    def _store_background_task_success(self, result) -> None:
        self._background_task_outcome = ("success", result)

    @Slot(str, str)
    def _store_background_task_failure(self, message: str, details: str) -> None:
        self._background_task_outcome = ("failure", message, details)

    @Slot()
    def _on_background_task_thread_finished(self) -> None:
        title = self._active_task_title or "Task"
        success_handler = self._active_task_success_handler
        worker = self._active_task_worker
        outcome = self._background_task_outcome
        if worker is not None:
            self._retained_background_workers.append(worker)
        self._clear_background_task()
        if outcome is None:
            self._log(f"{title} failed:\nBackground task finished without emitting a result.")
            QMessageBox.critical(
                self,
                f"{title} failed",
                "Background task finished without emitting a result.",
            )
            self.statusBar().showMessage(f"{title} failed", 5000)
            return
        if outcome[0] == "success":
            if success_handler is None:
                return
            try:
                success_handler(outcome[1])
            except Exception as exc:  # pragma: no cover - UI path
                self._show_error(f"{title} post-processing failed", exc)
            return
        message = str(outcome[1])
        details = str(outcome[2])
        self._log(f"{title} failed:\n{details}")
        print(f"{title} failed: {message}", file=sys.stderr, flush=True)
        if details:
            print(details, file=sys.stderr, flush=True)
        QMessageBox.critical(self, f"{title} failed", message)
        self.statusBar().showMessage(f"{title} failed", 5000)

    def _start_analysis_process(self, payload: dict[str, object]) -> None:
        if self._active_task_thread is not None or self._analysis_process is not None:
            QMessageBox.information(
                self,
                "Task Running",
                "Another task is still running. Please wait for it to finish first.",
            )
            return
        ctx = mp.get_context("spawn")
        self._analysis_result_queue = ctx.Queue()
        process = ctx.Process(
            target=_run_analysis_in_subprocess,
            args=(payload, self._analysis_result_queue),
        )
        self._analysis_process = process
        self._analysis_final_output_path = str(payload["final_output_path"])
        self._analysis_temp_output_path = str(payload["temp_output_path"])
        self._set_busy_state(True, "Run Analysis")
        self._progress_bar.setRange(0, 100)
        self._progress_bar.setValue(0)
        self._progress_label.setText("Starting analysis process...")
        self._cancel_task_button.show()
        process.start()
        self._analysis_poll_timer.start()

    def _poll_analysis_process(self) -> None:
        if self._analysis_process is None or self._analysis_result_queue is None:
            self._analysis_poll_timer.stop()
            return
        result = None
        try:
            while True:
                item = self._analysis_result_queue.get_nowait()
                if item.get("type") == "progress":
                    self._update_task_progress(
                        int(item.get("value", -1)),
                        str(item.get("message", "Running analysis...")),
                    )
                    continue
                result = item
                break
        except Empty:
            if self._analysis_process.is_alive():
                return
            self._analysis_poll_timer.stop()
            exit_code = self._analysis_process.exitcode
            self._cleanup_analysis_process_state()
            self._cleanup_analysis_temp_output()
            if exit_code not in {0, None}:
                self._log(f"Run Analysis failed: background process exited with code {exit_code}.")
                QMessageBox.critical(
                    self,
                    "Run Analysis failed",
                    f"Background analysis process exited with code {exit_code}.",
                )
                self.statusBar().showMessage("Run Analysis failed", 5000)
            return
        if result is None:
            return
        self._analysis_poll_timer.stop()
        self._analysis_process.join(timeout=1)
        self._cleanup_analysis_process_state()
        if not result.get("ok"):
            self._cleanup_analysis_temp_output()
            details = str(result.get("traceback", ""))
            message = str(result.get("error", "Run Analysis failed"))
            self._log(f"Run Analysis failed:\n{details}")
            QMessageBox.critical(self, "Run Analysis failed", message)
            self.statusBar().showMessage("Run Analysis failed", 5000)
            return
        self._finalize_analysis_output_file()
        self._handle_run_analysis_completed(
            {
                "payload": result["payload"],
                "golden_coverage_summary": result["golden_coverage_summary"],
                "outlier_summary_stats_rows": result.get("outlier_summary_stats_rows", []),
                "outlier_ratio_rows": result["outlier_ratio_rows"],
            }
        )

    def _cancel_analysis_process(self) -> None:
        if self._analysis_process is None:
            return
        response = QMessageBox.question(
            self,
            "Cancel Analysis",
            (
                "Stop the current analysis?\n\n"
                "This will terminate the background analysis process and remove the temporary output file. "
                "The database will not be modified."
            ),
            QMessageBox.Yes | QMessageBox.Cancel,
            QMessageBox.Cancel,
        )
        if response != QMessageBox.Yes:
            return
        process = self._analysis_process
        self._analysis_poll_timer.stop()
        if process.is_alive():
            process.terminate()
            process.join(timeout=2)
        self._cleanup_analysis_process_state()
        self._cleanup_analysis_temp_output()
        self._log("Run Analysis cancelled by user.")
        self.statusBar().showMessage("Analysis cancelled.", 5000)

    def _cleanup_analysis_process_state(self) -> None:
        self._analysis_process = None
        self._analysis_result_queue = None
        self._set_busy_state(False)

    def _prepare_analysis_temp_output_path(self, final_output_path: str) -> str:
        target = Path(final_output_path)
        return str(
            target.with_name(f"{target.stem}.__running__.{uuid4().hex}{target.suffix}")
        )

    def _finalize_analysis_output_file(self) -> None:
        if not self._analysis_temp_output_path or not self._analysis_final_output_path:
            return
        temp_paths = derive_split_output_paths(self._analysis_temp_output_path)
        final_paths = derive_split_output_paths(self._analysis_final_output_path)
        for key, temp_path in temp_paths.items():
            final_path = final_paths[key]
            if not temp_path.exists():
                continue
            final_path.parent.mkdir(parents=True, exist_ok=True)
            temp_path.replace(final_path)
        self._analysis_temp_output_path = None
        self._analysis_final_output_path = None

    def _cleanup_analysis_temp_output(self) -> None:
        if not self._analysis_temp_output_path:
            return
        for temp_path in derive_split_output_paths(self._analysis_temp_output_path).values():
            if temp_path.exists():
                try:
                    temp_path.unlink()
                except OSError:
                    pass
        self._analysis_temp_output_path = None
        self._analysis_final_output_path = None

    def closeEvent(self, event: QCloseEvent) -> None:
        if self._active_task_thread is not None or self._analysis_process is not None:
            QMessageBox.information(
                self,
                "Task Running",
                "A background task is still running. Please wait for it to finish before closing the window.",
            )
            event.ignore()
            return
        if not self._should_prompt_save_temp_database_on_close():
            event.accept()
            return
        outcome = self._prompt_save_temp_database_before_exit()
        if outcome == "cancel":
            event.ignore()
            return
        event.accept()

    def _apply_defaults(self) -> None:
        template_path = bundled_template_path()
        self.ui.templatePathEdit.setText(str(template_path.resolve()))
        self.ui.inputPathEdit.setText("")
        self.ui.storagePathEdit.setText(str(default_database_root().resolve()))
        self.ui.goldenNameEdit.setText("sample_t0_golden")
        self.ui.referenceDimsEdit.setText("sample_id")
        self.ui.filtersEdit.setPlainText("reliability_node=T0")
        self._set_combo_code_if_present(self.ui.centerMethodComboBox, "mean")
        self._set_combo_code_if_present(self.ui.outlierFailModeComboBox, "golden_deviation")
        self.ui.numericCleanupCheckBox.setChecked(False)
        self._set_combo_code_if_present(self.ui.numericCleanupModeComboBox, "all_non_numeric")
        self.ui.numericCleanupCharsEdit.setText("")
        self.ui.zThresholdSpinBox.setValue(3.5)
        self._set_combo_code_if_present(self.ui.analysisScopeComboBox, "current_input_file")
        self._sync_template_backed_settings_from_template(silent=True)
        self._update_golden_threshold_mode_state()
        self._update_numeric_cleanup_state()
        self._update_template_conversion_buttons()
        self._refresh_default_output_path()

    def _browse_template(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Template File",
            self.ui.templatePathEdit.text() or str(default_dialog_dir()),
            "Template Files (*.json *.xlsx);;JSON Files (*.json);;Excel Files (*.xlsx)",
        )
        if path:
            self.ui.templatePathEdit.setText(path)
            self._sync_template_backed_settings_from_template(silent=True)
            self._refresh_storage_overview(silent=True)

    def _validate_template(self) -> None:
        try:
            template_path = self._ensure_template_path()
            template = load_template(template_path)
        except Exception as exc:
            self._show_error("Validate template failed", exc)
            return
        payload = {
            "template_path": str(Path(template_path).resolve()),
            "summary": summarize_template(template),
        }
        self._log("Template valid:\n" + json.dumps(payload, ensure_ascii=False, indent=2))
        QMessageBox.information(self, "Template Valid", json.dumps(payload, ensure_ascii=False, indent=2))
        self.statusBar().showMessage("Template validated.", 5000)

    def _export_template_json(self) -> None:
        self._export_template(".xlsx", "Excel Files (*.xlsx)")

    def _export_template_excel(self) -> None:
        self._export_template(".json", "JSON Files (*.json)")

    def _export_template(self, suffix: str, file_filter: str) -> None:
        try:
            template_path = self._ensure_template_path()
            template = load_template(template_path)
            default_path = str(Path(template_path).with_suffix(suffix))
            output_path, _ = QFileDialog.getSaveFileName(
                self,
                f"Save Template As {suffix.upper().lstrip('.')}",
                default_path,
                file_filter,
            )
            if not output_path:
                return
            resolved_output_path = self._resolve_existing_output_path(
                output_path,
                "Template output file",
            )
            if resolved_output_path is None:
                self.statusBar().showMessage("Template export cancelled.", 5000)
                return
            resolved_output = save_template(
                template,
                resolved_output_path,
                if_exists="overwrite",
            )
        except Exception as exc:
            self._show_error("Template export failed", exc)
            return
        payload = {
            "input": str(Path(template_path).resolve()),
            "output": str(Path(resolved_output).resolve()),
            "summary": summarize_template(template),
        }
        self._log("Template converted:\n" + json.dumps(payload, ensure_ascii=False, indent=2))
        self.statusBar().showMessage("Template exported.", 5000)

    def _browse_input(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Input File",
            self.ui.inputPathEdit.text() or str(default_dialog_dir()),
            "Table Files (*.csv *.xlsx *.xlsm);;CSV Files (*.csv);;Excel Files (*.xlsx *.xlsm)",
        )
        if path:
            self.ui.inputPathEdit.setText(path)

    def _browse_storage(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Select Database Folder", self.ui.storagePathEdit.text() or str(default_dialog_dir()))
        if path:
            self.ui.storagePathEdit.setText(path)
            self._ensure_storage_workspace_for_current_database(silent=True)
            self._prompt_workspace_recovery_if_needed()
            self._refresh_default_output_path()
            self._refresh_storage_overview(silent=True)
            self._load_saved_settings_for_current_database(silent=True)
            self._verbose_log_storage_snapshot("After Switch Database")

    def _browse_golden(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select Golden Reference File", self.ui.goldenPathEdit.text() or str(default_dialog_dir()), "JSON Files (*.json)")
        if path:
            self.ui.goldenPathEdit.setText(path)
            self._sync_build_golden_controls_from_file(path)

    def _browse_output(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Select Report Output File",
            self.ui.outputPathEdit.text() or str(default_output_path()),
            "Excel Files (*.xlsx)",
        )
        if path:
            self.ui.outputPathEdit.setText(path)

    def _connect_optional_button(self, button_name: str, handler) -> None:
        button = getattr(self.ui, button_name, None)
        if isinstance(button, QPushButton):
            button.clicked.connect(handler)

    def _open_template_file(self) -> None:
        self._open_local_target(
            self.ui.templatePathEdit.text().strip(),
            "Template file",
            target_type="file",
        )

    def _open_input_file(self) -> None:
        self._open_local_target(
            self.ui.inputPathEdit.text().strip(),
            "Input file",
            target_type="file",
        )

    def _open_golden_file(self) -> None:
        self._open_local_target(
            self.ui.goldenPathEdit.text().strip(),
            "Golden reference file",
            target_type="file",
        )

    def _open_database_folder(self) -> None:
        self._open_local_target(
            self.ui.storagePathEdit.text().strip(),
            "Database folder",
            target_type="directory",
        )

    def _open_result_folder(self) -> None:
        output_path = self.ui.outputPathEdit.text().strip()
        if not output_path:
            QMessageBox.information(
                self,
                "Open Output Folder",
                "Report Output File is empty. Please choose an output path first.",
            )
            return
        output_target = Path(output_path).expanduser()
        folder_target = output_target if output_target.is_dir() else output_target.parent
        self._open_local_target(
            str(folder_target),
            "Report output folder",
            target_type="directory",
        )

    def _open_local_target(
        self,
        raw_path: str,
        label: str,
        target_type: str,
    ) -> None:
        if not raw_path:
            QMessageBox.information(
                self,
                f"Open {label}",
                f"{label} is empty. Please choose a path first.",
            )
            return
        target = Path(raw_path).expanduser().resolve()
        if target_type == "directory":
            exists = target.is_dir()
        else:
            exists = target.is_file()
        if not exists:
            self._show_error(
                f"Open {label} failed",
                FileNotFoundError(f"{label} does not exist:\n{target}"),
            )
            return
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(target))):
            self._show_error(
                f"Open {label} failed",
                RuntimeError(f"Could not open {label.lower()}:\n{target}"),
            )

    def _save_debug_bundle(self) -> None:
        try:
            parent = QFileDialog.getExistingDirectory(
                self,
                "Select Folder For Debug Bundle",
                self.ui.storagePathEdit.text() or str(default_dialog_dir()),
            )
            if not parent:
                return
            bundle_path = Path(parent) / "excel_data_analysis_debug_bundle"
            resolved_bundle_path = self._resolve_existing_output_directory(
                bundle_path,
                "Debug bundle folder",
            )
            if resolved_bundle_path is None:
                self.statusBar().showMessage("Save debug bundle cancelled.", 5000)
                return
            payload = save_debug_bundle(
                bundle_path=resolved_bundle_path,
                gui_settings=self._collect_gui_settings_snapshot(),
                current_results=self._collect_current_results_snapshot(),
                log_text=self.ui.logPlainTextEdit.toPlainText(),
                template_path=self.ui.templatePathEdit.text().strip() or None,
                input_path=self.ui.inputPathEdit.text().strip() or None,
                storage_path=self._active_storage_path() or None,
                golden_path=self.ui.goldenPathEdit.text().strip() or None,
                output_path=self.ui.outputPathEdit.text().strip() or None,
                if_exists="overwrite",
            )
        except Exception as exc:
            self._show_error("Save debug bundle failed", exc)
            return
        self._log("Saved debug bundle:\n" + json.dumps(payload, ensure_ascii=False, indent=2))
        self.statusBar().showMessage("Debug bundle saved.", 5000)
        QMessageBox.information(
            self,
            "Debug Bundle Saved",
            (
                "Current GUI settings and results were saved to:\n"
                f"{payload['bundle_root']}"
            ),
        )

    def _save_database(self) -> None:
        database_root = self._database_root_path()
        if not database_root:
            self._show_error("Save database failed", ValueError("Database Folder is required."))
            return
        if Path(database_root).resolve() == default_database_root().resolve():
            self._save_database_as()
            return
        self._verbose_log_storage_snapshot("Before Save Database")
        try:
            payload = save_storage_workspace(database_root)
            target = save_gui_state(
                database_root,
                self._collect_persistent_gui_state(),
            )
            cleanup_payload = delete_storage_workspace(database_root)
        except Exception as exc:
            self._show_error("Save database failed", exc)
            return
        self.current_workspace_path = ""
        self._refresh_storage_overview(silent=True)
        self._refresh_database_scoped_paths(database_root, database_root)
        self._log(
            "Saved database:\n"
            + json.dumps(
                {
                    "workspace_merge": payload,
                    "settings_file": str(target),
                    "workspace_cleanup": cleanup_payload,
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        self.statusBar().showMessage("Database saved.", 5000)
        QMessageBox.information(
            self,
            "Database Saved",
            (
                "Current temp workspace has been merged into the database root and temp/ was deleted.\n\n"
                f"Settings file:\n{target}"
            ),
        )

    def _save_database_as(self) -> None:
        database_root = self._database_root_path()
        if not database_root:
            self._show_error("Save database as failed", ValueError("Database Folder is required."))
            return
        self._verbose_log_storage_snapshot("Before Save Database As")
        try:
            saved_path = self._save_database_copy_as(database_root)
        except Exception as exc:
            self._show_error("Save database as failed", exc)
            return
        if not saved_path:
            self.statusBar().showMessage("Save database as cancelled.", 5000)
            return
        previous_database_root = database_root
        self.ui.storagePathEdit.setText(saved_path)
        self.current_workspace_path = ""
        self._refresh_storage_overview(silent=True)
        self._load_saved_settings_for_current_database(silent=True)
        self._refresh_database_scoped_paths(previous_database_root, saved_path)
        save_gui_state(saved_path, self._collect_persistent_gui_state())
        self.statusBar().showMessage("Database saved to a new folder.", 5000)
        QMessageBox.information(
            self,
            "Database Saved",
            f"Current workspace was saved as:\n{saved_path}",
        )

    def _save_database_copy_as(self, storage_path: str) -> str | None:
        source_path = Path(storage_path).resolve()
        default_temp_root = default_database_root().resolve()
        parent = QFileDialog.getExistingDirectory(
            self,
            "Select Parent Folder For Saved Database",
            str(default_dialog_dir()),
        )
        if not parent:
            return None
        default_name = "projectDatabase"
        folder_name, ok = QInputDialog.getText(
            self,
            "Database Folder Name",
            "Enter a folder name for the saved database:",
            text=default_name,
        )
        if not ok:
            return None
        folder_name = folder_name.strip()
        if not folder_name:
            raise ValueError("Database folder name cannot be empty.")
        target_path = Path(parent) / folder_name
        resolved_target_path = self._resolve_existing_output_directory(
            target_path,
            "Saved database folder",
        )
        if resolved_target_path is None:
            return None
        resolved_target_path_obj = Path(resolved_target_path).resolve()
        payload = save_storage_workspace_as(
            storage_root_path=storage_path,
            target_storage_root_path=resolved_target_path_obj,
        )
        save_gui_state(resolved_target_path_obj, self._collect_persistent_gui_state())
        self._log("Saved database copy:\n" + json.dumps(payload, ensure_ascii=False, indent=2))
        if source_path == default_temp_root and resolved_target_path_obj != default_temp_root:
            try:
                cleanup_payload = clear_storage_root(storage_path)
            except Exception as exc:
                self._log(f"Failed to clear tempDatabase after save: {exc}")
                QMessageBox.warning(
                    self,
                    "Temp Database Cleanup Failed",
                    (
                        "Database copy was saved successfully, but the default tempDatabase "
                        "could not be cleared automatically.\n\n"
                        "Please close any files that may still be using tempDatabase and try again later.\n\n"
                        f"Reason: {exc}"
                    ),
                )
            else:
                self._log(
                    "Cleared default tempDatabase after successful save:\n"
                    + json.dumps(cleanup_payload, ensure_ascii=False, indent=2)
                )
        return str(resolved_target_path_obj)

    def _import_dataset(self) -> None:
        try:
            self._ensure_required_paths(require_input=True)
            template_path = self.ui.templatePathEdit.text().strip()
            template = load_template(template_path)
            if self._maybe_write_back_template_settings(
                template_path,
                template,
                scope="import",
            ) is None:
                self.statusBar().showMessage("Import cancelled.", 5000)
                return
            input_path = self.ui.inputPathEdit.text().strip()
            storage_path = self._active_storage_path()
        except Exception as exc:
            self._show_error("Import failed", exc)
            return
        self._verbose_log_storage_snapshot("Before Import")
        def task(report_progress):
            report_progress(-1, "Previewing import conflicts...")
            preview = preview_import(
                template_path,
                input_path,
                storage_path,
            )
            return {
                "template_path": template_path,
                "input_path": input_path,
                "storage_path": storage_path,
                "preview": preview,
            }

        self._start_background_task(
            "Import Preview",
            task,
            self._handle_import_preview_ready,
        )

    def _handle_import_preview_ready(self, result: dict[str, object]) -> None:
        preview = result["preview"]
        self._log(
            "Import preview:\n"
            + json.dumps(
                {
                    "template_path": result["template_path"],
                    "input_path": result["input_path"],
                    "storage_path": result["storage_path"],
                    "existing_measurement_count": preview["existing_measurement_count"],
                    "incoming_measurement_count": preview["incoming_measurement_count"],
                    "existing_row_count": preview["existing_row_count"],
                    "incoming_row_count": preview["incoming_row_count"],
                    "conflict_row_count": preview["conflict_row_count"],
                    "existing_conflict_row_count": preview["existing_conflict_row_count"],
                    "dimensions": preview["dimensions"],
                    "conflict_rows_preview": preview["conflict_rows_preview"],
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        if int(preview["incoming_measurement_count"]) == 0:
            QMessageBox.warning(
                self,
                "Import Preview Warning",
                (
                    "This input produced 0 measurements during preview.\n\n"
                    "The database would remain empty after import unless the file/template mapping is adjusted.\n"
                    "Please check the GUI Log for preview details, then verify row dimensions, test columns, and numeric cleanup settings."
                ),
            )
        conflict_mode = "error"
        if preview["conflict_row_count"]:
            conflict_mode = self._prompt_import_conflict_mode(preview)
            if conflict_mode is None:
                self.statusBar().showMessage("Import cancelled.", 5000)
                return
        template_path = str(result["template_path"])
        input_path = str(result["input_path"])
        storage_path = str(result["storage_path"])

        def task(report_progress):
            return import_dataset(
                template_path,
                input_path,
                storage_path,
                conflict_mode=conflict_mode,
                progress_callback=report_progress,
            )

        def start_import_task() -> None:
            self._start_background_task(
                "Import Dataset",
                task,
                self._handle_import_completed,
            )

        # Start the second import stage on the next event-loop turn.
        # This avoids creating a fresh worker thread while the preview
        # thread is still unwinding its finished signal cleanup.
        QTimer.singleShot(0, start_import_task)

    def _handle_import_completed(self, payload: dict[str, object]) -> None:
        self._log(f"Imported dataset:\n{json.dumps(payload, ensure_ascii=False, indent=2)}")
        self._refresh_storage_overview(silent=True)
        self._verbose_log_storage_snapshot("After Import")
        imported_measurements = int(payload.get("imported_measurements", 0) or 0)
        imported_rows = int(payload.get("imported_rows", 0) or 0)
        if imported_measurements == 0 or imported_rows == 0:
            QMessageBox.warning(
                self,
                "Import Completed With No Data",
                (
                    "Import finished, but 0 measurements or 0 rows were written.\n\n"
                    "Please open the GUI Log and review the Import preview / Imported dataset sections.\n"
                    "That output now includes the incoming measurement count and the post-import database summary."
                ),
            )
        self.statusBar().showMessage("Dataset imported.", 5000)

    def _delete_selected_storage_rows(self) -> None:
        database_root = self._database_root_path()
        if not database_root:
            self._show_error("Delete rows failed", ValueError("Database Folder is required."))
            return
        selectors = self._selected_storage_row_selectors()
        if not selectors:
            QMessageBox.information(
                self,
                "No Rows Selected",
                "Please select one or more database rows to delete.",
            )
            return
        response = QMessageBox.question(
            self,
            "Delete Selected Database Rows",
            (
                f"Delete {len(selectors)} selected database row(s)?\n\n"
                "Use this for cases like mistaken imports or rows that should be removed from the database."
            ),
            QMessageBox.Yes | QMessageBox.Cancel,
            QMessageBox.Cancel,
        )
        if response != QMessageBox.Yes:
            self.statusBar().showMessage("Delete rows cancelled.", 5000)
            return
        self._verbose_log(
            "Delete rows request:\n"
            + json.dumps(selectors, ensure_ascii=False, indent=2)
        )
        self._verbose_log_storage_snapshot("Before Delete Rows")
        try:
            payload = delete_storage_rows(self._active_storage_path(), selectors)
        except Exception as exc:
            self._show_error("Delete rows failed", exc)
            return
        self._log("Deleted database rows:\n" + json.dumps(payload, ensure_ascii=False, indent=2))
        self._refresh_storage_overview(silent=True)
        self._verbose_log_storage_snapshot("After Delete Rows")
        self.statusBar().showMessage("Selected database rows deleted.", 5000)

    def _build_golden(self) -> None:
        try:
            self._ensure_required_paths(require_input=False)
            template_path = self.ui.templatePathEdit.text().strip()
            template = load_template(
                template_path,
                analysis_group_conflict_mode="error",
            )
            if self._maybe_write_back_template_settings(
                template_path,
                template,
                scope="build_golden",
            ) is None:
                self.statusBar().showMessage("Build golden cancelled.", 5000)
                return
            golden_name = self.ui.goldenNameEdit.text().strip() or "golden_reference"
            golden_target_path = (
                Path(self._active_storage_path()) / "golden" / f"{golden_name}.json"
            )
            existing_mode = self._resolve_existing_output_mode(
                golden_target_path,
                "Golden reference file",
            )
            if existing_mode is None:
                self.statusBar().showMessage("Build golden cancelled.", 5000)
                return
        except Exception as exc:
            self._show_error("Build golden failed", exc)
            return
        storage_path = self._active_storage_path()
        reference_dimensions = parse_csv_items(self.ui.referenceDimsEdit.text().strip())
        filters = parse_filter_text(self.ui.filtersEdit.toPlainText())
        center_method = self._combo_code(self.ui.centerMethodComboBox)
        outlier_golden_method = self._resolved_outlier_golden_method()
        relative_limit = self._resolve_relative_limit()
        sigma_multiplier = self._resolve_sigma_multiplier()
        absolute_lower_bound = self._resolve_absolute_lower_bound()
        absolute_upper_bound = self._resolve_absolute_upper_bound()
        overwrite_lowerbound = self._resolve_overwrite_lowerbound()
        overwrite_upperbound = self._resolve_overwrite_upperbound()
        continuous_interval = self._resolve_continuous_interval()

        def task(report_progress):
            reference, path = create_golden_reference(
                storage_path=storage_path,
                name=golden_name,
                reference_dimensions=reference_dimensions,
                filters=filters,
                center_method=center_method,
                outlier_golden_method=outlier_golden_method,
                relative_limit=relative_limit,
                sigma_multiplier=sigma_multiplier,
                absolute_lower_bound=absolute_lower_bound,
                absolute_upper_bound=absolute_upper_bound,
                overwrite_lowerbound=overwrite_lowerbound,
                overwrite_upperbound=overwrite_upperbound,
                continuous_interval=continuous_interval,
                template_path=template_path,
                analysis_group_conflict_mode="error",
                if_exists=existing_mode,
                progress_callback=report_progress,
            )
            return {"reference": reference, "path": path}

        self._start_background_task(
            "Build Golden",
            task,
            self._handle_build_golden_completed,
        )

    def _handle_build_golden_completed(self, payload: dict[str, object]) -> None:
        reference = payload["reference"]
        path = str(payload["path"])
        self.ui.goldenPathEdit.setText(path)
        self._log(
            "Golden built:\n"
            + json.dumps(
                {
                    "golden_name": reference.name,
                    "metric_count": len(reference.metrics),
                    "center_method": reference.center_method,
                    "saved_to": path,
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        self._verbose_log_storage_snapshot("After Build Golden")
        self.statusBar().showMessage("Golden reference created.", 5000)

    def _run_analysis(self) -> None:
        try:
            analysis_scope = self._analysis_scope_code()
            self._ensure_analysis_paths(analysis_scope)
            template_path = self.ui.templatePathEdit.text().strip()
            template = load_template(template_path)
            if self._maybe_write_back_template_settings(
                template_path,
                template,
                scope="analysis",
            ) is None:
                self.statusBar().showMessage("Analysis cancelled.", 5000)
                return
            golden_coverage_summary = None
            outlier_summary_rows: list[dict[str, str]] = []
            outlier_ratio_rows: list[dict[str, object]] = []
            report_outlier_fail_method = None
            report_outlier_merge_order = self._outlier_merge_order_text()
            built_golden_path = self.ui.goldenPathEdit.text().strip() or None
            dataset_ids, dimension_filters, column_filters = self._collect_database_analysis_filters(
                analysis_scope
            )
            if self._should_use_report_mode(template):
                report_outlier_fail_method = self._outlier_fail_mode_code()

            output_path = self.ui.outputPathEdit.text().strip()
            if not output_path:
                raise ValueError("Report Output File cannot be empty.")
            zscore_threshold_override = self.ui.zThresholdSpinBox.value()
            resolved_output_base_path = self._resolve_existing_report_output_base_path(
                output_path,
                "Report output files",
            )
            if resolved_output_base_path is None:
                self.statusBar().showMessage("Analysis cancelled.", 5000)
                return
        except Exception as exc:
            self._show_error("Analysis failed", exc)
            return
        report_mode = self._should_use_report_mode(template)
        input_path = self.ui.inputPathEdit.text().strip()
        storage_path = self._active_storage_path()
        if analysis_scope == "current_input_file" and not report_mode:
            self._show_error(
                "Analysis failed",
                ValueError(
                    "Current input file scope is only available for report-style templates. "
                    "Please choose a database scope for storage analysis."
                ),
            )
            return
        if self._analysis_requires_golden_file() and not built_golden_path:
            self._show_error(
                "Analysis failed",
                ValueError(
                    "Golden File is required when Outlier Criteria uses Golden Deviation."
                ),
            )
            return

        temp_output_path = self._prepare_analysis_temp_output_path(resolved_output_base_path)
        self._start_analysis_process(
            {
                "analysis_scope": analysis_scope,
                "template_path": template_path,
                "input_path": input_path,
                "storage_path": storage_path,
                "built_golden_path": built_golden_path,
                "outlier_fail_method_override": report_outlier_fail_method,
                "outlier_merge_order_override": report_outlier_merge_order,
                "zscore_threshold_override": zscore_threshold_override,
                "dataset_ids": dataset_ids,
                "dimension_filters": dimension_filters,
                "column_filters": column_filters,
                "temp_output_path": temp_output_path,
                "final_output_path": resolved_output_base_path,
            }
        )

    def _handle_run_analysis_completed(self, result: dict[str, object]) -> None:
        payload = dict(result["payload"])
        if self.ui.outputPathEdit.text().strip():
            payload["output"] = self.ui.outputPathEdit.text().strip()
        golden_coverage_summary = result["golden_coverage_summary"]
        outlier_summary_rows = result["outlier_summary_stats_rows"]
        outlier_ratio_rows = result["outlier_ratio_rows"]
        self.current_golden_coverage_summary = golden_coverage_summary
        self.current_outlier_summary_rows = outlier_summary_rows
        self.current_outlier_ratio_rows = outlier_ratio_rows
        self._refresh_golden_coverage_view(golden_coverage_summary)
        self._refresh_outlier_summary_view(outlier_summary_rows, outlier_ratio_rows)
        if outlier_summary_rows or outlier_ratio_rows:
            self.ui.resultTabWidget.setCurrentWidget(self.ui.outlierSummaryTab)
        elif golden_coverage_summary:
            self.ui.resultTabWidget.setCurrentWidget(self.ui.goldenCoverageTab)
        else:
            self.ui.resultTabWidget.setCurrentWidget(self.ui.logTab)
        self._log("Report exported:\n" + json.dumps(payload, ensure_ascii=False, indent=2))
        self._verbose_log_storage_snapshot("After Run Analysis")
        self.statusBar().showMessage("Analysis completed.", 5000)

    def _refresh_storage_overview(self, silent: bool = False) -> None:
        database_root = self._database_root_path()
        if not database_root:
            self.current_storage_headers = []
            self.ui.storageSummaryLabel.setText("Database folder is empty.")
            self._populate_table(self.ui.storageTableWidget, ["Current Database Rows"], [])
            return
        template_path = self.ui.templatePathEdit.text().strip() or None
        try:
            storage_path = self._storage_path_for_read()
            payload = describe_storage(storage_path, template_path=template_path, limit=500)
        except Exception as exc:
            self.current_storage_headers = []
            self.ui.storageSummaryLabel.setText(f"Current database view unavailable: {exc}")
            if not silent:
                self._show_error("Refresh database view failed", exc)
            return

        dimensions = payload["dimensions"]
        headers = [*dimensions, "measurement_count", "dataset_id", "__row_number__", "__source_file__"]
        rows = [
            [
                *[str(item.get(header, "")) for header in dimensions],
                str(item.get("measurement_count", "")),
                str(item.get("dataset_id", "")),
                str(item.get("row_number", "")),
                str(item.get("source_file", "")),
            ]
            for item in payload["rows"]
        ]
        self.current_storage_headers = headers
        self._populate_table(self.ui.storageTableWidget, headers or ["Current Database Rows"], rows)
        self._set_hidden_table_columns(
            self.ui.storageTableWidget,
            ["__row_number__", "__source_file__"],
        )

        summary = (
            f"Current workspace: {payload['dataset_count']} dataset(s), "
            f"{payload['row_count']} row(s), {payload['measurement_count']} measurement(s), "
            f"{payload['import_history_count']} import record(s)."
        )
        summary += (
            f" Database root: {Path(database_root).resolve()} | "
            f"Workspace: {Path(storage_path).resolve()}"
        )
        if payload["truncated"]:
            summary += " Only the first 500 rows are shown."
        self.ui.storageSummaryLabel.setText(summary)
        self._refresh_analysis_imports(silent=True)

    def _refresh_golden_coverage_view(self, summary: dict | None) -> None:
        if not summary:
            self.ui.goldenCoverageSummaryLabel.setText(
                "No built golden coverage checked yet."
            )
            self._populate_table(
                self.ui.goldenCoverageSummaryTableWidget,
                ["scope", "total_measurement_count", "matched_measurement_count", "unmatched_measurement_count", "matched_row_count", "unmatched_row_count"],
                [],
            )
            self._populate_table(
                self.ui.goldenCoverageExamplesTableWidget,
                ["row_number", "dataset_id", "logical_metric", "raw_column", "dimensions"],
                [],
            )
            return

        self.ui.goldenCoverageSummaryLabel.setText(
            (
                f"Built golden coverage for {summary.get('scope', 'analysis')}: "
                f"{summary.get('matched_measurement_count', 0)}/"
                f"{summary.get('total_measurement_count', 0)} measurements matched."
            )
        )
        summary_headers = [
            "scope",
            "total_measurement_count",
            "matched_measurement_count",
            "unmatched_measurement_count",
            "matched_row_count",
            "unmatched_row_count",
        ]
        self._populate_table(
            self.ui.goldenCoverageSummaryTableWidget,
            summary_headers,
            [[str(summary.get(header, "")) for header in summary_headers]],
        )
        example_headers = ["row_number", "dataset_id", "logical_metric", "raw_column", "dimensions"]
        example_rows = [
            [
                str(item.get("row_number", "")),
                str(item.get("dataset_id", "")),
                str(item.get("logical_metric", "")),
                str(item.get("raw_column", "")),
                json.dumps(item.get("dimensions", {}), ensure_ascii=False, sort_keys=True),
            ]
            for item in summary.get("unmatched_examples", [])
        ]
        self._populate_table(
            self.ui.goldenCoverageExamplesTableWidget,
            example_headers,
            example_rows,
        )

    def _refresh_outlier_summary_view(
        self,
        rows: list[dict[str, object]],
        ratio_rows: list[dict[str, object]],
    ) -> None:
        if not rows and not ratio_rows:
            self.ui.outlierSummaryLabel.setText("No outlier summary statistics available for the current analysis scope.")
            self._populate_table(
                self.ui.outlierSummaryTableWidget,
                ["metric", "value", "note"],
                [],
            )
            self.ui.outlierRatioSummaryLabel.setText("No outlier ratio statistics configured for the current analysis scope.")
            self._populate_table(
                self.ui.outlierRatioTableWidget,
                *self._build_outlier_ratio_table_payload([]),
            )
            return
        self.ui.outlierSummaryLabel.setText(
            f"Current outlier summary statistics contain {len(rows)} row(s)."
        )
        self._populate_table(
            self.ui.outlierSummaryTableWidget,
            ["metric", "value", "note"],
            [
                [
                    str(item.get("metric", "")),
                    str(item.get("value", "")),
                    str(item.get("note", "")),
                ]
                for item in rows
            ],
        )
        self.ui.outlierRatioSummaryLabel.setText(
            f"Current outlier ratio statistics contain {len(ratio_rows)} row(s)."
        )
        self._populate_table(
            self.ui.outlierRatioTableWidget,
            *self._build_outlier_ratio_table_payload(ratio_rows),
        )

    @staticmethod
    def _build_outlier_ratio_table_payload(
        ratio_rows: list[dict[str, object]],
    ) -> tuple[list[str], list[list[str]]]:
        headers = [
            "id",
            "display_name",
            "group_by_dimension",
            "group_value",
            "numerator",
            "outlier_sample_count",
            "total_sample_count",
            "outlier_ratio",
            "filter_summary",
        ]
        max_lot_pair_count = max(
            (
                len(item.get("lot_sample_pairs", []))
                for item in ratio_rows
                if isinstance(item, dict)
            ),
            default=0,
        )
        for pair_index in range(1, max_lot_pair_count + 1):
            headers.extend([f"Lot {pair_index}", f"Sample IDs {pair_index}"])

        rows: list[list[str]] = []
        for item in ratio_rows:
            values = [
                str(item.get("id", "")),
                str(item.get("display_name", "")),
                str(item.get("group_by_dimension", "")),
                str(item.get("group_value", "")),
                str(item.get("numerator", "")),
                str(item.get("outlier_sample_count", "")),
                str(item.get("total_sample_count", "")),
                str(item.get("outlier_ratio", "")),
                str(item.get("filter_summary", "")),
            ]
            lot_sample_pairs = item.get("lot_sample_pairs", [])
            if not isinstance(lot_sample_pairs, list):
                lot_sample_pairs = []
            for pair_index in range(max_lot_pair_count):
                if pair_index < len(lot_sample_pairs):
                    pair = lot_sample_pairs[pair_index]
                    if isinstance(pair, (list, tuple)) and len(pair) >= 2:
                        values.extend([str(pair[0]), str(pair[1])])
                    else:
                        values.extend(["", ""])
                else:
                    values.extend(["", ""])
            rows.append(values)
        return headers, rows

    def _refresh_analysis_imports(self, silent: bool = False) -> None:
        widget = self.ui.analysisImportsListWidget
        checked_ids = set(self._selected_analysis_dataset_ids())
        widget.blockSignals(True)
        widget.clear()
        database_root = self._database_root_path()
        if not database_root:
            widget.blockSignals(False)
            return
        try:
            entries = list_import_history(self._storage_path_for_read())
        except Exception as exc:
            widget.blockSignals(False)
            if not silent:
                self._show_error("Refresh import list failed", exc)
            return
        for entry in entries:
            dataset_id = str(entry.get("dataset_id", ""))
            created_at = str(entry.get("created_at_utc", ""))
            source_file = Path(str(entry.get("source_file", "") or "")).name
            measurement_count = entry.get("measurement_count", "")
            label = (
                f"{created_at} | {dataset_id} | {source_file} | "
                f"{measurement_count} measurements"
            )
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, dataset_id)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if dataset_id in checked_ids else Qt.Unchecked)
            widget.addItem(item)
        widget.blockSignals(False)

    def _update_analysis_mode_state(self) -> None:
        database_scope = self._analysis_scope_code() != "current_input_file"
        checked_imports_scope = self._analysis_scope_code() == "checked_imports"
        self.ui.goldenPathEdit.setEnabled(True)
        self.ui.browseGoldenButton.setEnabled(True)
        self.ui.analysisSampleIdsEdit.setEnabled(True)
        self.ui.analysisExcludeSampleIdsEdit.setEnabled(True)
        self.ui.analysisNodesEdit.setEnabled(True)
        self.ui.analysisExcludeNodesEdit.setEnabled(True)
        self.ui.analysisTestsEdit.setEnabled(True)
        self.ui.analysisExcludeTestsEdit.setEnabled(True)
        self.ui.refreshAnalysisImportsButton.setEnabled(database_scope)
        self.ui.analysisImportsListWidget.setEnabled(checked_imports_scope)
        self.ui.outputPathEdit.setEnabled(True)
        self.ui.browseOutputButton.setEnabled(True)
        self._update_golden_threshold_mode_state()

    def _update_golden_threshold_mode_state(self) -> None:
        try:
            terms = outlier_golden_method_terms(self._outlier_golden_method_text())
        except Exception:
            terms = {"relative", "sigma", "absolute"}
        try:
            modifiers = outlier_golden_method_modifiers(self._outlier_golden_method_text())
        except Exception:
            modifiers = {"overwrite_lowerbound", "overwrite_upperbound"}
        self.ui.relativeLimitSpinBox.setEnabled("relative" in terms)
        self.ui.sigmaMultiplierSpinBox.setEnabled("sigma" in terms)
        self.ui.absoluteLowerBoundEdit.setEnabled("absolute" in terms)
        self.ui.absoluteUpperBoundEdit.setEnabled("absolute" in terms)
        self.ui.overwriteMinEdit.setEnabled("overwrite_lowerbound" in modifiers)
        self.ui.overwriteMaxEdit.setEnabled("overwrite_upperbound" in modifiers)

    def _ensure_required_paths(self, require_input: bool) -> None:
        self._ensure_template_path()
        if require_input and not self.ui.inputPathEdit.text().strip():
            raise ValueError("Input Excel/CSV path is required.")
        if not self._database_root_path():
            raise ValueError("Storage Folder is required.")

    def _ensure_report_paths(self) -> None:
        self._ensure_template_path()
        if not self.ui.inputPathEdit.text().strip():
            raise ValueError("Input Excel/CSV path is required.")

    def _ensure_analysis_paths(self, analysis_scope: str) -> None:
        self._ensure_template_path()
        if analysis_scope == "current_input_file":
            self._ensure_report_paths()
            return
        if not self._database_root_path():
            raise ValueError("Database Folder is required.")

    def _ensure_template_path(self) -> str:
        template_path = self.ui.templatePathEdit.text().strip()
        if not template_path:
            raise ValueError("Template path is required.")
        return template_path

    def _outlier_golden_method_text(self) -> str:
        return str(self.ui.thresholdModeComboBox.currentText() or "").strip()

    def _resolved_outlier_golden_method(self) -> str:
        return normalize_outlier_golden_method(self._outlier_golden_method_text())

    def _outlier_merge_order_text(self) -> str:
        return str(self.ui.outlierMergeOrderComboBox.currentText() or "").strip()

    def _resolve_relative_limit(self) -> float | None:
        if (
            "relative" in outlier_golden_method_terms(self._resolved_outlier_golden_method())
            or self._template_backed_golden_values.get("relative_limit") is not None
        ):
            return self.ui.relativeLimitSpinBox.value()
        return None

    def _resolve_sigma_multiplier(self) -> float | None:
        if (
            "sigma" in outlier_golden_method_terms(self._resolved_outlier_golden_method())
            or self._template_backed_golden_values.get("sigma_multiplier") is not None
        ):
            return self.ui.sigmaMultiplierSpinBox.value()
        return None

    def _parse_optional_float_text(self, text: str, label: str) -> float | None:
        value = text.strip()
        if not value:
            return None
        try:
            return float(value)
        except ValueError as exc:
            raise ValueError(f"{label} must be a valid number.") from exc

    def _resolve_absolute_lower_bound(self) -> float | None:
        if (
            "absolute" in outlier_golden_method_terms(self._resolved_outlier_golden_method())
            or self._template_backed_golden_values.get("absolute_lower_bound") is not None
        ):
            return self._parse_optional_float_text(
                self.ui.absoluteLowerBoundEdit.text(),
                "Absolute Lower Bound",
            )
        return None

    def _resolve_absolute_upper_bound(self) -> float | None:
        if (
            "absolute" in outlier_golden_method_terms(self._resolved_outlier_golden_method())
            or self._template_backed_golden_values.get("absolute_upper_bound") is not None
        ):
            return self._parse_optional_float_text(
                self.ui.absoluteUpperBoundEdit.text(),
                "Absolute Upper Bound",
            )
        return None

    def _resolve_overwrite_lowerbound(self) -> float | None:
        if (
            "overwrite_lowerbound"
            in outlier_golden_method_modifiers(self._resolved_outlier_golden_method())
            or self._template_backed_golden_values.get("overwrite_lowerbound") is not None
        ):
            return self._parse_optional_float_text(
                self.ui.overwriteMinEdit.text(),
                "Overwrite Lower Bound",
            )
        return None

    def _resolve_overwrite_upperbound(self) -> float | None:
        if (
            "overwrite_upperbound"
            in outlier_golden_method_modifiers(self._resolved_outlier_golden_method())
            or self._template_backed_golden_values.get("overwrite_upperbound") is not None
        ):
            return self._parse_optional_float_text(
                self.ui.overwriteMaxEdit.text(),
                "Overwrite Upper Bound",
            )
        return None

    def _resolve_continuous_interval(self) -> bool:
        return bool(self.ui.continuousIntervalCheckBox.isChecked())

    def _parse_numeric_cleanup_chars(self) -> list[str]:
        text = self.ui.numericCleanupCharsEdit.text().strip()
        if not text:
            return []
        return [item.strip() for item in text.split(";") if item.strip()]

    def _database_root_path(self) -> str:
        return self.ui.storagePathEdit.text().strip()

    def _active_storage_path(self) -> str:
        database_root = self._database_root_path()
        if not database_root:
            return ""
        if self.current_workspace_path:
            return self.current_workspace_path
        self._ensure_storage_workspace_for_current_database(silent=True)
        return self.current_workspace_path

    def _storage_path_for_read(self) -> str:
        if self.current_workspace_path:
            return self.current_workspace_path
        database_root = self._database_root_path()
        return str(Path(database_root).resolve()) if database_root else ""

    def _ensure_storage_workspace_for_current_database(self, silent: bool) -> None:
        database_root = self._database_root_path()
        if not database_root:
            self.current_workspace_path = ""
            return
        try:
            payload = ensure_storage_workspace(database_root)
        except Exception as exc:
            self.current_workspace_path = ""
            if not silent:
                self._show_error("Prepare database workspace failed", exc)
            return
        self.current_workspace_path = str(Path(payload["workspace"]).resolve())

    def _refresh_default_output_path(self) -> None:
        database_root = self._database_root_path()
        if not database_root:
            self.ui.outputPathEdit.setText(
                str(default_output_path("sample_chip_data_real_result.xlsx").resolve())
            )
            return
        self.ui.outputPathEdit.setText(
            str(default_database_output_path(database_root).resolve())
        )

    def _refresh_database_scoped_paths(
        self,
        previous_database_root: str | Path | None,
        new_database_root: str | Path | None,
    ) -> None:
        if not new_database_root:
            return
        new_root = Path(new_database_root).resolve()
        previous_root = Path(previous_database_root).resolve() if previous_database_root else None

        current_output = self.ui.outputPathEdit.text().strip()
        if current_output:
            remapped_output = self._remap_database_scoped_path(
                current_output,
                previous_root,
                new_root,
                category="result",
            )
            if remapped_output is not None:
                self.ui.outputPathEdit.setText(str(remapped_output))
        else:
            self.ui.outputPathEdit.setText(str(default_database_output_path(new_root).resolve()))

        current_golden = self.ui.goldenPathEdit.text().strip()
        if current_golden:
            remapped_golden = self._remap_database_scoped_path(
                current_golden,
                previous_root,
                new_root,
                category="golden",
            )
            if remapped_golden is not None:
                self.ui.goldenPathEdit.setText(str(remapped_golden))

    @staticmethod
    def _remap_database_scoped_path(
        current_path: str,
        previous_database_root: Path | None,
        new_database_root: Path,
        category: str,
    ) -> Path | None:
        try:
            path = Path(current_path).resolve()
        except Exception:
            return None

        category_dir_name = "result" if category == "result" else "golden"
        candidate_bases: list[tuple[Path, Path]] = []
        if previous_database_root is not None:
            candidate_bases.extend(
                [
                    (previous_database_root / category_dir_name, new_database_root / category_dir_name),
                    (previous_database_root / "temp" / category_dir_name, new_database_root / category_dir_name),
                    (previous_database_root / "temp", new_database_root / category_dir_name),
                ]
            )
        candidate_bases.extend(
            [
                (new_database_root / "temp" / category_dir_name, new_database_root / category_dir_name),
                (new_database_root / "temp", new_database_root / category_dir_name),
            ]
        )

        for source_base, target_base in candidate_bases:
            try:
                relative = path.relative_to(source_base)
            except ValueError:
                continue
            filename = relative.name if relative.name else path.name
            return (target_base / filename).resolve()
        return None

    def _prompt_workspace_recovery_if_needed(self) -> None:
        database_root = self._database_root_path()
        if not database_root:
            return
        try:
            payload = storage_workspace_differs(database_root)
        except Exception as exc:
            self._show_error("Check temp workspace failed", exc)
            return
        if not payload.get("differs"):
            return
        response = QMessageBox(self)
        response.setWindowTitle("Unsaved Temp Workspace Found")
        response.setIcon(QMessageBox.Warning)
        response.setText(
            (
                "This database contains a temp workspace that is different from the last saved database.\n\n"
                f"Database root:\n{database_root}\n\n"
                f"Temp workspace:\n{payload.get('workspace', '')}"
            )
        )
        response.setInformativeText(
            "Choose Continue Temp Workspace to keep working from temp/, or Discard Temp And Reload Saved Database to drop those unsaved temp changes."
        )
        continue_button = response.addButton("Continue Temp Workspace", QMessageBox.AcceptRole)
        discard_button = response.addButton("Discard Temp And Reload Saved Database", QMessageBox.DestructiveRole)
        response.setDefaultButton(continue_button)
        self._ensure_message_box_button_widths(response)
        response.exec()
        if response.clickedButton() == discard_button:
            try:
                reset_payload = discard_storage_workspace_changes(database_root)
            except Exception as exc:
                self._show_error("Discard temp workspace failed", exc)
                return
            self.current_workspace_path = str(Path(reset_payload["workspace"]).resolve())
            self._log(
                "Discarded temp workspace changes and reloaded saved database:\n"
                + json.dumps(reset_payload, ensure_ascii=False, indent=2)
            )
        else:
            self._log(
                "Continuing with unsaved temp workspace:\n"
                + json.dumps(payload, ensure_ascii=False, indent=2)
            )

    def _show_error(self, title: str, exc: Exception) -> None:
        self._log(f"{title}: {exc}")
        QMessageBox.critical(self, title, str(exc))
        self.statusBar().showMessage(title, 5000)

    @staticmethod
    def _ensure_message_box_button_widths(message_box: QMessageBox) -> None:
        for button in message_box.buttons():
            desired_width = max(
                button.minimumSizeHint().width(),
                button.sizeHint().width(),
            )
            button.setMinimumWidth(desired_width)

    def _log(self, message: str) -> None:
        timestamp = QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
        self.ui.logPlainTextEdit.appendPlainText(f"[{timestamp}] {message}")

    @staticmethod
    def _should_use_report_mode(template) -> bool:
        return bool(
            template.test_data_header_row != template.row_header_row
            or template.unit_row is not None
        )

    def _analysis_requires_golden_file(self) -> bool:
        return self._outlier_fail_mode_code() in {
            "golden_deviation",
            "zscore_and_golden",
            "zscore_or_golden",
        }

    @staticmethod
    def _format_outlier_method_label(method: str) -> str:
        if method == "golden_deviation":
            return "Golden Deviation"
        if method == "zscore_and_golden":
            return "Modified Z Score And Golden Deviation"
        if method == "zscore_or_golden":
            return "Modified Z Score Or Golden Deviation"
        return "Modified Z Score"

    def _prompt_import_conflict_mode(self, preview: dict) -> str | None:
        message_box = QMessageBox(self)
        message_box.setWindowTitle("Import Conflict Detected")
        message_box.setIcon(QMessageBox.Warning)
        message_box.setText(
            (
                "Current database already contains rows with the same sample attributes.\n\n"
                f"Incoming conflicting rows: {preview['conflict_row_count']}\n"
                f"Existing rows affected: {preview['existing_conflict_row_count']}"
            )
        )

        preview_lines = []
        for item in preview["conflict_rows_preview"][:5]:
            text = ", ".join(f"{key}={value}" for key, value in item.items() if value != "")
            if text:
                preview_lines.append(text)
        informative_lines = [
            "Replace: remove existing rows with the same sample/node/site... key, then import this file.",
        ]
        if preview["has_repeat_dimension"]:
            informative_lines.append(
                "Append: keep existing rows and shift repeat_id upward for the new file."
            )
        else:
            informative_lines.append(
                "Append is unavailable because conflicting rows do not contain a valid repeat_id."
            )
        if preview_lines:
            informative_lines.append("")
            informative_lines.append("Examples:")
            informative_lines.extend(preview_lines)
        message_box.setInformativeText("\n".join(informative_lines))

        replace_button = message_box.addButton("Replace Existing", QMessageBox.AcceptRole)
        append_button = None
        if preview["has_repeat_dimension"]:
            append_button = message_box.addButton("Append And Shift Repeat", QMessageBox.ActionRole)
        cancel_button = message_box.addButton(QMessageBox.Cancel)
        message_box.setDefaultButton(replace_button)
        self._ensure_message_box_button_widths(message_box)
        message_box.exec()

        clicked = message_box.clickedButton()
        if clicked == replace_button:
            return "replace"
        if append_button is not None and clicked == append_button:
            return "append"
        if clicked == cancel_button:
            return None
        return None

    def _selected_analysis_dataset_ids(self) -> list[str]:
        dataset_ids: list[str] = []
        for index in range(self.ui.analysisImportsListWidget.count()):
            item = self.ui.analysisImportsListWidget.item(index)
            if item.checkState() == Qt.Checked:
                dataset_ids.append(str(item.data(Qt.UserRole)))
        return dataset_ids

    @staticmethod
    def _format_analysis_column_filter_text(filters: dict[str, list[str]]) -> str:
        parts: list[str] = []
        for key, values in filters.items():
            normalized_values = [str(value).strip() for value in values if str(value).strip()]
            if normalized_values:
                parts.append(f"{key}={','.join(normalized_values)}")
        return ";".join(parts)

    def _apply_analysis_column_filter_text(
        self,
        widget,
        filters: dict[str, list[str]],
    ) -> None:
        text = self._format_analysis_column_filter_text(filters)
        widget.setReadOnly(False)
        widget.setToolTip(text)
        widget.setText(text)

    @staticmethod
    def _analysis_dimension_filter_text(
        filters: dict[str, list[str]],
        key: str,
        *,
        separator: str,
    ) -> str:
        values = filters.get(key, [])
        normalized_values: list[str] = []
        for value in values:
            text = str(value).strip()
            if not text:
                continue
            if key == "sample_key":
                text = text.replace(";", ",")
            normalized_values.append(text)
        return separator.join(normalized_values)

    @staticmethod
    def _normalize_filter_payload(
        payload: dict[str, dict[str, list[str]]] | None,
    ) -> dict[str, dict[str, list[str]]]:
        normalized: dict[str, dict[str, list[str]]] = {}
        if not isinstance(payload, dict):
            return normalized
        for mode_name, filters in payload.items():
            if not isinstance(filters, dict):
                continue
            normalized_filters: dict[str, list[str]] = {}
            for key, values in filters.items():
                if not isinstance(values, list):
                    continue
                normalized_values = [
                    str(value).strip() for value in values if str(value).strip()
                ]
                if normalized_values:
                    normalized_filters[str(key)] = normalized_values
            if normalized_filters:
                normalized[mode_name] = normalized_filters
        return normalized

    def _resolve_analysis_column_filters(
        self,
        template,
    ) -> dict[str, dict[str, list[str]]]:
        tests = parse_semicolon_items(self.ui.analysisTestsEdit.text().strip())
        exclude_tests = parse_semicolon_items(self.ui.analysisExcludeTestsEdit.text().strip())
        return build_column_filters(
            template,
            include_tests=tests,
            exclude_tests=exclude_tests,
        )

    def _analysis_test_text_for_state(self, mode: str) -> str:
        if mode == "include":
            widget = self.ui.analysisTestsEdit
        else:
            widget = self.ui.analysisExcludeTestsEdit
        return widget.text().strip()

    def _resolve_analysis_dimension_filters(self) -> dict[str, dict[str, list[str]]]:
        return {
            "include": {
                "sample_key": parse_semicolon_items(
                    self.ui.analysisSampleIdsEdit.text().strip()
                ),
                "reliability_node": parse_csv_items(
                    self.ui.analysisNodesEdit.text().strip()
                ),
            },
            "exclude": {
                "sample_key": parse_semicolon_items(
                    self.ui.analysisExcludeSampleIdsEdit.text().strip()
                ),
                "reliability_node": parse_csv_items(
                    self.ui.analysisExcludeNodesEdit.text().strip()
                ),
            },
        }

    def _collect_database_analysis_filters(
        self,
        analysis_scope: str,
    ) -> tuple[
        list[str] | None,
        dict[str, dict[str, list[str]]],
        dict[str, dict[str, list[str]]],
    ]:
        dataset_ids: list[str] | None = None
        if analysis_scope == "checked_imports":
            dataset_ids = self._selected_analysis_dataset_ids()
            if not dataset_ids:
                raise ValueError("Please check at least one import entry to analyze.")
        template = load_template(self._ensure_template_path())
        analysis_dimension_filters = self._resolve_analysis_dimension_filters()
        return (
            dataset_ids,
            build_dimension_filters(
                sample_keys=analysis_dimension_filters.get("include", {}).get(
                    "sample_key", []
                ),
                sample_dimension_names=template.report.sample_dimension_names,
                reliability_nodes=analysis_dimension_filters.get("include", {}).get(
                    "reliability_node", []
                ),
                exclude_sample_keys=analysis_dimension_filters.get("exclude", {}).get(
                    "sample_key", []
                ),
                exclude_reliability_nodes=analysis_dimension_filters.get(
                    "exclude", {}
                ).get("reliability_node", []),
            ),
            self._resolve_analysis_column_filters(template),
        )

    def _collect_template_write_back_diffs(
        self,
        template,
        scope: str,
    ) -> list[dict[str, object]]:
        diffs: list[dict[str, object]] = []
        if scope == "import":
            desired_numeric_cleanup_enabled = self.ui.numericCleanupCheckBox.isChecked()
            desired_numeric_cleanup_mode = self._combo_code(
                self.ui.numericCleanupModeComboBox
            )
            desired_numeric_cleanup_chars = self._parse_numeric_cleanup_chars()
            template_numeric_cleanup = template.numeric_cleanup
            if desired_numeric_cleanup_enabled != template_numeric_cleanup.enabled:
                diffs.append(
                    {
                        "label": "Numeric Cleanup Enabled",
                        "gui": "Enabled" if desired_numeric_cleanup_enabled else "Disabled",
                        "template": "Enabled"
                        if template_numeric_cleanup.enabled
                        else "Disabled",
                        "apply": lambda item, desired=desired_numeric_cleanup_enabled: setattr(
                            item.numeric_cleanup,
                            "enabled",
                            desired,
                        ),
                    }
                )
            if desired_numeric_cleanup_mode != template_numeric_cleanup.mode:
                diffs.append(
                    {
                        "label": "Numeric Cleanup Mode",
                        "gui": desired_numeric_cleanup_mode,
                        "template": template_numeric_cleanup.mode,
                        "apply": lambda item, desired=desired_numeric_cleanup_mode: setattr(
                            item.numeric_cleanup,
                            "mode",
                            desired,
                        ),
                    }
                )
            if desired_numeric_cleanup_chars != template_numeric_cleanup.characters:
                diffs.append(
                    {
                        "label": "Numeric Cleanup Characters",
                        "gui": ";".join(desired_numeric_cleanup_chars) or "(empty)",
                        "template": ";".join(template_numeric_cleanup.characters)
                        or "(empty)",
                        "apply": lambda item, desired=desired_numeric_cleanup_chars: setattr(
                            item.numeric_cleanup,
                            "characters",
                            list(desired),
                        ),
                    }
                )
            return diffs

        if scope == "analysis":
            desired_dimension_filters = self._resolve_analysis_dimension_filters()
            normalized_dimension_filters = build_dimension_filters(
                sample_keys=desired_dimension_filters.get("include", {}).get(
                    "sample_key", []
                ),
                sample_dimension_names=template.report.sample_dimension_names,
                reliability_nodes=desired_dimension_filters.get("include", {}).get(
                    "reliability_node", []
                ),
                exclude_sample_keys=desired_dimension_filters.get("exclude", {}).get(
                    "sample_key", []
                ),
                exclude_reliability_nodes=desired_dimension_filters.get(
                    "exclude", {}
                ).get("reliability_node", []),
            )
            template_dimension_filters = self._normalize_filter_payload({
                "include": {
                    key: list(values)
                    for key, values in template.report.analysis_dimension_filters.include.items()
                },
                "exclude": {
                    key: list(values)
                    for key, values in template.report.analysis_dimension_filters.exclude.items()
                },
            })
            desired_sample_filters = {
                "include": normalized_dimension_filters.get(SAMPLE_KEY_FILTER, {}).get(
                    "include", []
                ),
                "exclude": normalized_dimension_filters.get(SAMPLE_KEY_FILTER, {}).get(
                    "exclude", []
                ),
            }
            template_sample_filters = {
                "include": template_dimension_filters.get("include", {}).get(
                    "sample_key", []
                ),
                "exclude": template_dimension_filters.get("exclude", {}).get(
                    "sample_key", []
                ),
            }
            if desired_sample_filters != template_sample_filters:
                diffs.append(
                    {
                        "label": "Analysis Sample-Key Filters",
                        "gui": (
                            f"include={';'.join(desired_sample_filters.get('include', [])) or '(empty)'} | "
                            f"exclude={';'.join(desired_sample_filters.get('exclude', [])) or '(empty)'}"
                        ),
                        "template": (
                            f"include={';'.join(template_sample_filters.get('include', [])) or '(empty)'} | "
                            f"exclude={';'.join(template_sample_filters.get('exclude', [])) or '(empty)'}"
                        ),
                        "apply": lambda item, desired=desired_dimension_filters: setattr(
                            item.report,
                            "analysis_dimension_filters",
                            item.report.analysis_dimension_filters.__class__(
                                include={
                                    key: list(values)
                                    for key, values in desired.get("include", {}).items()
                                },
                                exclude={
                                    key: list(values)
                                    for key, values in desired.get("exclude", {}).items()
                                },
                            ),
                        ),
                    }
                )
            desired_node_filters = {
                "include": desired_dimension_filters.get("include", {}).get(
                    "reliability_node", []
                ),
                "exclude": desired_dimension_filters.get("exclude", {}).get(
                    "reliability_node", []
                ),
            }
            template_node_filters = {
                "include": template_dimension_filters.get("include", {}).get(
                    "reliability_node", []
                ),
                "exclude": template_dimension_filters.get("exclude", {}).get(
                    "reliability_node", []
                ),
            }
            if desired_node_filters != template_node_filters:
                diffs.append(
                    {
                        "label": "Analysis Node Filters",
                        "gui": (
                            f"include={','.join(desired_node_filters.get('include', [])) or '(empty)'} | "
                            f"exclude={','.join(desired_node_filters.get('exclude', [])) or '(empty)'}"
                        ),
                        "template": (
                            f"include={','.join(template_node_filters.get('include', [])) or '(empty)'} | "
                            f"exclude={','.join(template_node_filters.get('exclude', [])) or '(empty)'}"
                        ),
                        "apply": lambda item, desired=desired_dimension_filters: setattr(
                            item.report,
                            "analysis_dimension_filters",
                            item.report.analysis_dimension_filters.__class__(
                                include={
                                    key: list(values)
                                    for key, values in desired.get("include", {}).items()
                                },
                                exclude={
                                    key: list(values)
                                    for key, values in desired.get("exclude", {}).items()
                                },
                            ),
                        ),
                    }
                )
            desired_outlier = self._outlier_fail_mode_code()
            if desired_outlier != template.report.outlier_fail_method:
                diffs.append(
                    {
                        "label": "Outlier Criteria",
                        "gui": self._format_outlier_method_label(desired_outlier),
                        "template": self._format_outlier_method_label(
                            template.report.outlier_fail_method
                        ),
                        "apply": lambda item, desired=desired_outlier: setattr(
                            item.report,
                            "outlier_fail_method",
                            desired,
                        ),
                    }
                )
            desired_merge_order = self._outlier_merge_order_text()
            if desired_merge_order != template.report.outlier_merge_order:
                diffs.append(
                    {
                        "label": "Outlier Merge Order",
                        "gui": desired_merge_order,
                        "template": template.report.outlier_merge_order,
                        "apply": lambda item, desired=desired_merge_order: setattr(
                            item.report,
                            "outlier_merge_order",
                            desired,
                        ),
                    }
                )
            desired_column_filters = self._normalize_filter_payload(
                self._resolve_analysis_column_filters(template)
            )
            template_column_filters = self._normalize_filter_payload({
                "include": {
                    key: list(values)
                    for key, values in template.report.analysis_column_filters.include.items()
                },
                "exclude": {
                    key: list(values)
                    for key, values in template.report.analysis_column_filters.exclude.items()
                },
            })
            if desired_column_filters != template_column_filters:
                diffs.append(
                    {
                        "label": "Analysis Test Filters",
                        "gui": (
                            f"include={self._format_analysis_column_filter_text(desired_column_filters.get('include', {})) or '(empty)'} | "
                            f"exclude={self._format_analysis_column_filter_text(desired_column_filters.get('exclude', {})) or '(empty)'}"
                        ),
                        "template": (
                            f"include={self._format_analysis_column_filter_text(template_column_filters.get('include', {})) or '(empty)'} | "
                            f"exclude={self._format_analysis_column_filter_text(template_column_filters.get('exclude', {})) or '(empty)'}"
                        ),
                        "apply": lambda item, desired=desired_column_filters: setattr(
                            item.report,
                            "analysis_column_filters",
                            item.report.analysis_column_filters.__class__(
                                include={
                                    key: list(values)
                                    for key, values in desired.get("include", {}).items()
                                },
                                exclude={
                                    key: list(values)
                                    for key, values in desired.get("exclude", {}).items()
                                },
                            ),
                        ),
                    }
                )
            desired_z = float(self.ui.zThresholdSpinBox.value())
            template_z = float(template.report.zscore_thresholds.default)
            override_count = len(template.report.zscore_thresholds.overrides)
            if abs(desired_z - template_z) > 1e-12 or override_count:
                template_label = f"{template_z:g}"
                if override_count:
                    template_label = f"{template_label} (+{override_count} override)"
                    if override_count > 1:
                        template_label += "s"
                diffs.append(
                    {
                        "label": "Z Threshold",
                        "gui": f"{desired_z:g}",
                        "template": template_label,
                        "note": (
                            "Writing back will set template default z-threshold "
                            "and clear metric-specific zscore overrides to match the GUI."
                        )
                        if override_count
                        else None,
                        "apply": lambda item, desired=desired_z: setattr(
                            item.report,
                            "zscore_thresholds",
                            item.report.zscore_thresholds.__class__(
                                default=desired,
                                overrides={},
                            ),
                        ),
                    }
                )
            return diffs

        if scope == "build_golden":
            golden_defaults = template.golden_reference_defaults
            desired_reference_dims = parse_csv_items(
                self.ui.referenceDimsEdit.text().strip()
            )
            if desired_reference_dims != golden_defaults.reference_dimensions:
                diffs.append(
                    {
                        "label": "Golden Reference Dims",
                        "gui": ",".join(desired_reference_dims) or "(empty)",
                        "template": ",".join(golden_defaults.reference_dimensions)
                        or "(empty)",
                        "apply": lambda item, desired=desired_reference_dims: setattr(
                            item.golden_reference_defaults,
                            "reference_dimensions",
                            list(desired),
                        ),
                    }
                )
            desired_filters = parse_filter_text(self.ui.filtersEdit.toPlainText())
            if desired_filters != golden_defaults.filters:
                diffs.append(
                    {
                        "label": "Golden Filters",
                        "gui": "; ".join(
                            f"{key}={value}" for key, value in desired_filters.items()
                        )
                        or "(empty)",
                        "template": "; ".join(
                            f"{key}={value}"
                            for key, value in golden_defaults.filters.items()
                        )
                        or "(empty)",
                        "apply": lambda item, desired=desired_filters: setattr(
                            item.golden_reference_defaults,
                            "filters",
                            dict(desired),
                        ),
                    }
                )
            desired_center_method = self._combo_code(self.ui.centerMethodComboBox)
            if desired_center_method != golden_defaults.center_method:
                diffs.append(
                    {
                        "label": "Golden Center",
                        "gui": desired_center_method,
                        "template": golden_defaults.center_method,
                        "apply": lambda item, desired=desired_center_method: setattr(
                            item.golden_reference_defaults,
                            "center_method",
                            desired,
                        ),
                    }
                )
            desired_outlier_golden_method = self._resolved_outlier_golden_method()
            if desired_outlier_golden_method != golden_defaults.outlier_golden_method:
                diffs.append(
                    {
                        "label": "Outlier Golden Method",
                        "gui": desired_outlier_golden_method,
                        "template": golden_defaults.outlier_golden_method,
                        "apply": lambda item, desired=desired_outlier_golden_method: setattr(
                            item.golden_reference_defaults,
                            "outlier_golden_method",
                            desired,
                        ),
                    }
                )
            desired_relative_limit = self._resolve_relative_limit()
            template_relative_limit = golden_defaults.relative_limit
            if desired_relative_limit != template_relative_limit:
                diffs.append(
                    {
                        "label": "Golden Relative Limit",
                        "gui": self._format_optional_number(desired_relative_limit),
                        "template": self._format_optional_number(
                            template_relative_limit
                        ),
                        "apply": lambda item, desired=desired_relative_limit: setattr(
                            item.golden_reference_defaults,
                            "relative_limit",
                            desired,
                        ),
                    }
                )
            desired_sigma_multiplier = self._resolve_sigma_multiplier()
            template_sigma_multiplier = golden_defaults.sigma_multiplier
            if desired_sigma_multiplier != template_sigma_multiplier:
                diffs.append(
                    {
                        "label": "Golden Sigma Multiplier",
                        "gui": self._format_optional_number(desired_sigma_multiplier),
                        "template": self._format_optional_number(
                            template_sigma_multiplier
                        ),
                        "apply": lambda item, desired=desired_sigma_multiplier: setattr(
                            item.golden_reference_defaults,
                            "sigma_multiplier",
                            desired,
                        ),
                    }
                )
            desired_absolute_lower_bound = self._resolve_absolute_lower_bound()
            if desired_absolute_lower_bound != golden_defaults.absolute_lower_bound:
                diffs.append(
                    {
                        "label": "Golden Absolute Lower Bound",
                        "gui": self._format_optional_number(
                            desired_absolute_lower_bound
                        ),
                        "template": self._format_optional_number(
                            golden_defaults.absolute_lower_bound
                        ),
                        "apply": lambda item, desired=desired_absolute_lower_bound: setattr(
                            item.golden_reference_defaults,
                            "absolute_lower_bound",
                            desired,
                        ),
                    }
                )
            desired_absolute_upper_bound = self._resolve_absolute_upper_bound()
            if desired_absolute_upper_bound != golden_defaults.absolute_upper_bound:
                diffs.append(
                    {
                        "label": "Golden Absolute Upper Bound",
                        "gui": self._format_optional_number(
                            desired_absolute_upper_bound
                        ),
                        "template": self._format_optional_number(
                            golden_defaults.absolute_upper_bound
                        ),
                        "apply": lambda item, desired=desired_absolute_upper_bound: setattr(
                            item.golden_reference_defaults,
                            "absolute_upper_bound",
                            desired,
                        ),
                    }
                )
            desired_overwrite_lowerbound = self._resolve_overwrite_lowerbound()
            if desired_overwrite_lowerbound != golden_defaults.overwrite_lowerbound:
                diffs.append(
                    {
                        "label": "Golden Overwrite Lower Bound",
                        "gui": self._format_optional_number(
                            desired_overwrite_lowerbound
                        ),
                        "template": self._format_optional_number(
                            golden_defaults.overwrite_lowerbound
                        ),
                        "apply": lambda item, desired=desired_overwrite_lowerbound: setattr(
                            item.golden_reference_defaults,
                            "overwrite_lowerbound",
                            desired,
                        ),
                    }
                )
            desired_overwrite_upperbound = self._resolve_overwrite_upperbound()
            if desired_overwrite_upperbound != golden_defaults.overwrite_upperbound:
                diffs.append(
                    {
                        "label": "Golden Overwrite Upper Bound",
                        "gui": self._format_optional_number(
                            desired_overwrite_upperbound
                        ),
                        "template": self._format_optional_number(
                            golden_defaults.overwrite_upperbound
                        ),
                        "apply": lambda item, desired=desired_overwrite_upperbound: setattr(
                            item.golden_reference_defaults,
                            "overwrite_upperbound",
                            desired,
                        ),
                    }
                )
            desired_continuous_interval = self._resolve_continuous_interval()
            if desired_continuous_interval != bool(golden_defaults.continuous_interval):
                diffs.append(
                    {
                        "label": "Golden Continuous Interval",
                        "gui": "True" if desired_continuous_interval else "False",
                        "template": (
                            "True" if golden_defaults.continuous_interval else "False"
                        ),
                        "apply": lambda item, desired=desired_continuous_interval: setattr(
                            item.golden_reference_defaults,
                            "continuous_interval",
                            desired,
                        ),
                    }
                )
            return diffs

        raise ValueError(f"Unsupported template write-back scope: {scope}")

    def _sync_template_backed_settings_from_template(self, silent: bool = False) -> None:
        try:
            template = load_template(self._ensure_template_path())
        except Exception as exc:
            if not silent:
                self._show_error("Load template failed", exc)
            return
        self._set_combo_code_if_present(
            self.ui.outlierFailModeComboBox,
            template.report.outlier_fail_method,
        )
        self._set_combo_code_if_present(
            self.ui.outlierMergeOrderComboBox,
            template.report.outlier_merge_order,
        )
        self.ui.zThresholdSpinBox.setValue(template.report.zscore_thresholds.default)
        golden_defaults = template.golden_reference_defaults
        self._template_backed_golden_values = {
            "relative_limit": golden_defaults.relative_limit,
            "sigma_multiplier": golden_defaults.sigma_multiplier,
            "absolute_lower_bound": golden_defaults.absolute_lower_bound,
            "absolute_upper_bound": golden_defaults.absolute_upper_bound,
            "overwrite_lowerbound": golden_defaults.overwrite_lowerbound,
            "overwrite_upperbound": golden_defaults.overwrite_upperbound,
            "continuous_interval": golden_defaults.continuous_interval,
        }
        self.ui.referenceDimsEdit.setText(",".join(golden_defaults.reference_dimensions))
        self.ui.filtersEdit.setPlainText(
            "\n".join(f"{key}={value}" for key, value in golden_defaults.filters.items())
        )
        self._set_combo_code_if_present(
            self.ui.centerMethodComboBox,
            golden_defaults.center_method,
        )
        self._set_combo_code_if_present(
            self.ui.thresholdModeComboBox,
            golden_defaults.outlier_golden_method,
        )
        if golden_defaults.relative_limit is not None:
            self.ui.relativeLimitSpinBox.setValue(float(golden_defaults.relative_limit))
        if golden_defaults.sigma_multiplier is not None:
            self.ui.sigmaMultiplierSpinBox.setValue(float(golden_defaults.sigma_multiplier))
        self.ui.absoluteLowerBoundEdit.setText(
            self._format_optional_input_number(golden_defaults.absolute_lower_bound)
        )
        self.ui.absoluteUpperBoundEdit.setText(
            self._format_optional_input_number(golden_defaults.absolute_upper_bound)
        )
        self.ui.overwriteMinEdit.setText(
            self._format_optional_input_number(golden_defaults.overwrite_lowerbound)
        )
        self.ui.overwriteMaxEdit.setText(
            self._format_optional_input_number(golden_defaults.overwrite_upperbound)
        )
        self.ui.continuousIntervalCheckBox.setChecked(
            bool(golden_defaults.continuous_interval)
        )
        numeric_cleanup = template.numeric_cleanup
        self.ui.numericCleanupCheckBox.setChecked(bool(numeric_cleanup.enabled))
        self._set_combo_code_if_present(
            self.ui.numericCleanupModeComboBox,
            numeric_cleanup.mode,
        )
        self.ui.numericCleanupCharsEdit.setText(";".join(numeric_cleanup.characters))
        self._update_numeric_cleanup_state()
        self._template_analysis_dimension_filters = {
            "include": {
                key: list(values)
                for key, values in template.report.analysis_dimension_filters.include.items()
            },
            "exclude": {
                key: list(values)
                for key, values in template.report.analysis_dimension_filters.exclude.items()
            },
        }
        self.ui.analysisSampleIdsEdit.setText(
            self._analysis_dimension_filter_text(
                self._template_analysis_dimension_filters.get("include", {}),
                "sample_key",
                separator=";",
            )
        )
        self.ui.analysisExcludeSampleIdsEdit.setText(
            self._analysis_dimension_filter_text(
                self._template_analysis_dimension_filters.get("exclude", {}),
                "sample_key",
                separator=";",
            )
        )
        self.ui.analysisNodesEdit.setText(
            self._analysis_dimension_filter_text(
                self._template_analysis_dimension_filters.get("include", {}),
                "reliability_node",
                separator=",",
            )
        )
        self.ui.analysisExcludeNodesEdit.setText(
            self._analysis_dimension_filter_text(
                self._template_analysis_dimension_filters.get("exclude", {}),
                "reliability_node",
                separator=",",
            )
        )
        self._template_analysis_column_filters = {
            "include": {
                key: list(values)
                for key, values in template.report.analysis_column_filters.include.items()
            },
            "exclude": {
                key: list(values)
                for key, values in template.report.analysis_column_filters.exclude.items()
            },
        }
        self._apply_analysis_column_filter_text(
            self.ui.analysisTestsEdit,
            self._template_analysis_column_filters.get("include", {}),
        )
        self._apply_analysis_column_filter_text(
            self.ui.analysisExcludeTestsEdit,
            self._template_analysis_column_filters.get("exclude", {}),
        )
        self._update_golden_threshold_mode_state()

    def _sync_build_golden_controls_from_file(self, golden_path: str) -> None:
        try:
            golden = json.loads(Path(golden_path).read_text(encoding="utf-8"))
        except Exception:
            return
        default_rule = golden.get("default_rule", golden)
        self._template_backed_golden_values = {
            "relative_limit": default_rule.get("relative_limit"),
            "sigma_multiplier": default_rule.get("sigma_multiplier"),
            "absolute_lower_bound": default_rule.get("absolute_lower_bound"),
            "absolute_upper_bound": default_rule.get("absolute_upper_bound"),
            "overwrite_lowerbound": default_rule.get(
                "overwrite_lowerbound",
                default_rule.get("overwrite_min"),
            ),
            "overwrite_upperbound": default_rule.get(
                "overwrite_upperbound",
                default_rule.get("overwrite_max"),
            ),
            "continuous_interval": default_rule.get("continuous_interval"),
        }
        self._set_combo_code_if_present(
            self.ui.centerMethodComboBox,
            golden.get("center_method"),
        )
        self._set_combo_code_if_present(
            self.ui.thresholdModeComboBox,
            default_rule.get("outlier_golden_method"),
        )
        if default_rule.get("relative_limit") is not None:
            self.ui.relativeLimitSpinBox.setValue(float(default_rule["relative_limit"]))
        if default_rule.get("sigma_multiplier") is not None:
            self.ui.sigmaMultiplierSpinBox.setValue(float(default_rule["sigma_multiplier"]))
        self.ui.absoluteLowerBoundEdit.setText(
            self._format_optional_input_number(default_rule.get("absolute_lower_bound"))
        )
        self.ui.absoluteUpperBoundEdit.setText(
            self._format_optional_input_number(default_rule.get("absolute_upper_bound"))
        )
        self.ui.overwriteMinEdit.setText(
            self._format_optional_input_number(
                default_rule.get("overwrite_lowerbound", default_rule.get("overwrite_min"))
            )
        )
        self.ui.overwriteMaxEdit.setText(
            self._format_optional_input_number(
                default_rule.get("overwrite_upperbound", default_rule.get("overwrite_max"))
            )
        )
        self.ui.continuousIntervalCheckBox.setChecked(
            bool(default_rule.get("continuous_interval", False))
        )
        self._update_golden_threshold_mode_state()

    def _maybe_write_back_template_settings(
        self,
        template_path: str,
        template,
        scope: str,
    ) -> bool | None:
        diffs = self._collect_template_write_back_diffs(template, scope)

        if not diffs:
            return True

        lines = ["当前 GUI 设置和 template 中的默认值不一致：", ""]
        for diff in diffs:
            lines.append(
                f"- {diff['label']}: GUI={diff['gui']} | Template={diff['template']}"
            )
            note = diff.get("note")
            if note:
                lines.append(f"  {note}")
        lines.extend(
            [
                "",
                "是否把这些值回写到当前 template？",
                "选择 Yes 会保存到 template；选择 No 只对本次操作生效。",
            ]
        )
        response = QMessageBox.question(
            self,
            "Sync Settings Back To Template",
            "\n".join(lines),
            QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
            QMessageBox.Yes,
        )
        if response == QMessageBox.Cancel:
            return None
        if response == QMessageBox.No:
            return True

        updated_template = load_template(template_path)
        for diff in diffs:
            apply_fn = diff["apply"]
            apply_fn(updated_template)
        save_template(updated_template, template_path)
        self._sync_template_backed_settings_from_template(silent=True)
        self._log(
            "Updated template-backed GUI settings in "
            f"{template_path}:\n"
            + json.dumps(
                [
                    {
                        "label": diff["label"],
                        "gui": diff["gui"],
                        "template_previous": diff["template"],
                    }
                    for diff in diffs
                ],
                ensure_ascii=False,
                indent=2,
            )
        )
        return True

    @staticmethod
    def _format_optional_number(value: float | None) -> str:
        if value is None:
            return "(empty)"
        return f"{value:g}"

    @staticmethod
    def _format_optional_input_number(value: object) -> str:
        if value in {None, ""}:
            return ""
        return f"{float(value):g}"

    def _warn_built_golden_coverage_for_input(
        self,
        golden_path: str,
        dimension_filters: dict[str, dict[str, list[str]]] | None = None,
    ) -> dict:
        summary = summarize_built_golden_coverage_for_input(
            self.ui.templatePathEdit.text().strip(),
            self.ui.inputPathEdit.text().strip(),
            golden_path,
            dimension_filters=dimension_filters,
        )
        self._show_built_golden_coverage_summary(summary)
        return summary

    def _warn_built_golden_coverage_for_storage(
        self,
        golden_path: str,
        dataset_ids: list[str] | None,
        dimension_filters: dict[str, dict[str, list[str]]],
    ) -> dict:
        summary = summarize_built_golden_coverage_for_storage(
            self._active_storage_path(),
            golden_path,
            dataset_ids=dataset_ids,
            dimension_filters=dimension_filters,
        )
        self._show_built_golden_coverage_summary(summary)
        return summary

    def _show_built_golden_coverage_summary(self, summary: dict) -> None:
        matched = summary["matched_measurement_count"]
        unmatched = summary["unmatched_measurement_count"]
        total = summary["total_measurement_count"]
        self._log(
            "Built golden coverage:\n"
            + json.dumps(summary, ensure_ascii=False, indent=2)
        )
        if total == 0:
            QMessageBox.information(
                self,
                "Built Golden Coverage",
                "Current analysis scope does not contain any measurement data.",
            )
            return
        if unmatched == 0:
            self.statusBar().showMessage(
                f"Built golden coverage: {matched}/{total} measurements matched.",
                5000,
            )
            return

        examples = []
        for item in summary.get("unmatched_examples", [])[:5]:
            dimensions = item.get("dimensions", {})
            dimension_text = ", ".join(
                f"{key}={value}" for key, value in dimensions.items() if value != ""
            )
            examples.append(
                f"- row {item.get('row_number')} | {item.get('raw_column')} | {dimension_text}"
            )
        detail = [
            (
                f"Built golden matched {matched}/{total} measurements, "
                f"but {unmatched} measurements in {summary['unmatched_row_count']} row(s) "
                "did not match any golden key."
            ),
        ]
        if examples:
            detail.append("")
            detail.append("Examples:")
            detail.extend(examples)
        QMessageBox.warning(
            self,
            "Built Golden Coverage Warning",
            "\n".join(detail),
        )

    def _collect_persistent_gui_settings(self) -> dict[str, object]:
        return {
            "version": 1,
            "paths": {
                "template_path": self.ui.templatePathEdit.text().strip(),
                "input_path": self.ui.inputPathEdit.text().strip(),
                "golden_path": self.ui.goldenPathEdit.text().strip(),
                "output_path": self.ui.outputPathEdit.text().strip(),
            },
            "golden": {
                "golden_name": self.ui.goldenNameEdit.text().strip(),
                "reference_dims_text": self.ui.referenceDimsEdit.text().strip(),
                "filters_text": self.ui.filtersEdit.toPlainText(),
                "center_method": self._combo_code(self.ui.centerMethodComboBox),
                "outlier_golden_method": self._outlier_golden_method_text(),
                "relative_limit": self.ui.relativeLimitSpinBox.value(),
                "sigma_multiplier": self.ui.sigmaMultiplierSpinBox.value(),
                "absolute_lower_bound": self.ui.absoluteLowerBoundEdit.text().strip(),
                "absolute_upper_bound": self.ui.absoluteUpperBoundEdit.text().strip(),
                "overwrite_lowerbound": self.ui.overwriteMinEdit.text().strip(),
                "overwrite_upperbound": self.ui.overwriteMaxEdit.text().strip(),
                "continuous_interval": self.ui.continuousIntervalCheckBox.isChecked(),
            },
            "parsing": {
                "numeric_cleanup_enabled": self.ui.numericCleanupCheckBox.isChecked(),
                "numeric_cleanup_mode": self._combo_code(self.ui.numericCleanupModeComboBox),
                "numeric_cleanup_characters": self.ui.numericCleanupCharsEdit.text().strip(),
            },
            "analysis": {
                "analysis_scope": self._analysis_scope_code(),
                "outlier_fail_mode": self._outlier_fail_mode_code(),
                "outlier_merge_order": self._outlier_merge_order_text(),
                "z_threshold": self.ui.zThresholdSpinBox.value(),
                "sample_ids_text": self.ui.analysisSampleIdsEdit.text().strip(),
                "exclude_sample_ids_text": self.ui.analysisExcludeSampleIdsEdit.text().strip(),
                "nodes_text": self.ui.analysisNodesEdit.text().strip(),
                "exclude_nodes_text": self.ui.analysisExcludeNodesEdit.text().strip(),
                "tests_text": self._analysis_test_text_for_state("include"),
                "exclude_tests_text": self._analysis_test_text_for_state("exclude"),
                "selected_dataset_ids": self._selected_analysis_dataset_ids(),
            },
            "debug": {
                "verbose_logging_enabled": self._verbose_logging_enabled,
            },
            "ui_state": {
                "workbench_tab_index": self.ui.workbenchTabWidget.currentIndex(),
                "result_tab_index": self.ui.resultTabWidget.currentIndex(),
                "splitter_sizes": self.ui.mainSplitter.sizes(),
            },
        }

    def _collect_persistent_gui_state(self) -> dict[str, object]:
        payload = self._collect_persistent_gui_settings()
        payload["current_results"] = self._collect_current_results_snapshot()
        payload["log_text"] = self.ui.logPlainTextEdit.toPlainText()
        return payload

    def _load_saved_settings_for_current_database(self, silent: bool) -> None:
        database_root = self._database_root_path()
        if not database_root:
            return
        try:
            payload = load_gui_state(database_root)
        except Exception as exc:
            if not silent:
                self._show_error("Load settings failed", exc)
            return
        if payload is None:
            if not silent:
                QMessageBox.information(
                    self,
                    "No Saved Settings",
                    "Current database does not contain any saved GUI settings yet.",
                )
            return
        try:
            self._apply_persistent_gui_settings(payload)
        except Exception as exc:
            if not silent:
                self._show_error("Apply settings failed", exc)
            return
        self._refresh_database_scoped_paths(database_root, database_root)
        self._log(f"Loaded database GUI settings from {Path(database_root) / '.excel_data_analysis_gui_state.json'}")
        self.statusBar().showMessage("Saved database settings loaded.", 5000)

    def _should_prompt_save_temp_database_on_close(self) -> bool:
        database_root = self._database_root_path()
        if not database_root:
            return False
        try:
            current = Path(database_root).resolve()
            default_temp = default_database_root().resolve()
        except Exception:
            return False
        if current != default_temp:
            return True
        try:
            differs_payload = storage_workspace_differs(database_root)
        except Exception:
            return False
        differs = bool(differs_payload.get("differs", False))
        if differs:
            return True
        return self._storage_has_user_content(Path(self._active_storage_path()))

    @staticmethod
    def _storage_has_user_content(storage_path: Path) -> bool:
        measurements_path = storage_path / "measurements.jsonl"
        datasets_path = storage_path / "datasets.jsonl"
        golden_dir = storage_path / "golden"
        imports_dir = storage_path / "imports"
        return (
            (measurements_path.exists() and measurements_path.stat().st_size > 0)
            or (datasets_path.exists() and datasets_path.stat().st_size > 0)
            or (golden_dir.exists() and any(golden_dir.iterdir()))
            or (imports_dir.exists() and any(imports_dir.iterdir()))
        )

    def _prompt_save_temp_database_before_exit(self) -> str:
        database_root = self._database_root_path()
        if not database_root:
            return "exit"
        current_root = Path(database_root).resolve()
        default_temp_root = default_database_root().resolve()
        is_default_temp = current_root == default_temp_root
        message_box = QMessageBox(self)
        message_box.setWindowTitle("Unsaved Database Changes")
        message_box.setIcon(QMessageBox.Warning)
        if is_default_temp:
            message_box.setText(
                (
                    "Current database is still using the default temporary folder:\n"
                    f"{default_temp_root}\n\n"
                    "Please save it to a proper project directory before closing."
                )
            )
            message_box.setInformativeText(
                "Choose Save Database to copy the current database to a new folder, Exit Anyway to discard the unsaved workspace reminder, or Cancel to stay in the app."
            )
        else:
            message_box.setText(
                (
                    "Current database is using a temp workspace under this database folder:\n"
                    f"{current_root / 'temp'}\n\n"
                    "Do you want to save temp/ back into the database root before closing?"
                )
            )
            message_box.setInformativeText(
                "Choose Save Database to merge temp/ into the database root, Don't Save to discard temp/ changes, or Cancel to stay in the app. In both Save and Don't Save cases, temp/ will be deleted before the app exits."
            )
        save_button = message_box.addButton("Save Database", QMessageBox.AcceptRole)
        exit_button = message_box.addButton(
            "Exit Anyway" if is_default_temp else "Don't Save",
            QMessageBox.DestructiveRole,
        )
        cancel_button = message_box.addButton(QMessageBox.Cancel)
        message_box.setDefaultButton(save_button)
        self._ensure_message_box_button_widths(message_box)
        message_box.exec()
        clicked = message_box.clickedButton()
        if clicked == cancel_button:
            return "cancel"
        if clicked == exit_button:
            if is_default_temp:
                return "exit"
            try:
                cleanup_payload = delete_storage_workspace(database_root)
            except Exception as exc:
                self._show_error("Discard temp workspace failed", exc)
                return "cancel"
            self.current_workspace_path = ""
            self._log(
                "Discarded temp workspace on exit:\n"
                + json.dumps(cleanup_payload, ensure_ascii=False, indent=2)
            )
            return "exit"
        if clicked == save_button:
            if is_default_temp:
                try:
                    saved_path = self._save_database_copy_as(self._database_root_path())
                except Exception as exc:
                    self._show_error("Save database copy failed", exc)
                    return "cancel"
                if not saved_path:
                    return "cancel"
                previous_database_root = database_root
                self.ui.storagePathEdit.setText(saved_path)
                self._refresh_storage_overview(silent=True)
                self._load_saved_settings_for_current_database(silent=True)
                self._refresh_database_scoped_paths(previous_database_root, saved_path)
                save_gui_state(saved_path, self._collect_persistent_gui_state())
                QMessageBox.information(
                    self,
                    "Database Saved",
                    f"Current database was copied to:\n{saved_path}",
                )
                return "saved"
            try:
                payload = save_storage_workspace(database_root)
                target = save_gui_state(
                    database_root,
                    self._collect_persistent_gui_state(),
                )
                cleanup_payload = delete_storage_workspace(database_root)
            except Exception as exc:
                self._show_error("Save database failed", exc)
                return "cancel"
            self.current_workspace_path = ""
            self._log(
                "Saved database:\n"
                + json.dumps(
                    {
                        "workspace_merge": payload,
                        "settings_file": str(target),
                        "workspace_cleanup": cleanup_payload,
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
            self.statusBar().showMessage("Database saved.", 5000)
            QMessageBox.information(
                self,
                "Database Saved",
                (
                    "Current temp workspace has been merged into the database root.\n\n"
                    f"Settings file:\n{target}"
                ),
            )
            return "saved"
        return "cancel"

    def _apply_persistent_gui_settings(self, payload: dict[str, object]) -> None:
        paths = payload.get("paths", {})
        if isinstance(paths, dict):
            self.ui.templatePathEdit.setText(self._coerce_saved_text(paths.get("template_path"), self.ui.templatePathEdit.text()))
            self.ui.inputPathEdit.setText(self._coerce_saved_text(paths.get("input_path"), self.ui.inputPathEdit.text()))
            self.ui.goldenPathEdit.setText(self._coerce_saved_text(paths.get("golden_path"), self.ui.goldenPathEdit.text()))
            self.ui.outputPathEdit.setText(self._coerce_saved_text(paths.get("output_path"), self.ui.outputPathEdit.text()))
        if self.ui.templatePathEdit.text().strip():
            self._sync_template_backed_settings_from_template(silent=True)
        else:
            self._template_backed_golden_values = {
                "relative_limit": None,
                "sigma_multiplier": None,
                "absolute_lower_bound": None,
                "absolute_upper_bound": None,
                "overwrite_lowerbound": None,
                "overwrite_upperbound": None,
                "continuous_interval": None,
            }
            self.ui.continuousIntervalCheckBox.setChecked(False)
            self._template_analysis_dimension_filters = {}
            self.ui.analysisSampleIdsEdit.clear()
            self.ui.analysisExcludeSampleIdsEdit.clear()
            self.ui.analysisNodesEdit.clear()
            self.ui.analysisExcludeNodesEdit.clear()
            self._template_analysis_column_filters = {}
            self._apply_analysis_column_filter_text(self.ui.analysisTestsEdit, {})
            self._apply_analysis_column_filter_text(self.ui.analysisExcludeTestsEdit, {})

        golden = payload.get("golden", {})
        if isinstance(golden, dict):
            default_rule = golden.get("default_rule", golden)
            self.ui.goldenNameEdit.setText(self._coerce_saved_text(golden.get("golden_name"), self.ui.goldenNameEdit.text()))
            self.ui.referenceDimsEdit.setText(self._coerce_saved_text(golden.get("reference_dims_text"), self.ui.referenceDimsEdit.text()))
            self.ui.filtersEdit.setPlainText(self._coerce_saved_text(golden.get("filters_text"), self.ui.filtersEdit.toPlainText()))
            self._set_combo_code_if_present(self.ui.centerMethodComboBox, golden.get("center_method"))
            self._set_combo_code_if_present(
                self.ui.thresholdModeComboBox,
                default_rule.get("outlier_golden_method"),
            )
            if "relative_limit" in default_rule:
                self.ui.relativeLimitSpinBox.setValue(float(default_rule["relative_limit"]))
            if "sigma_multiplier" in default_rule:
                self.ui.sigmaMultiplierSpinBox.setValue(float(default_rule["sigma_multiplier"]))
            self.ui.absoluteLowerBoundEdit.setText(
                self._coerce_saved_text(
                    default_rule.get("absolute_lower_bound"),
                    self.ui.absoluteLowerBoundEdit.text(),
                )
            )
            self.ui.absoluteUpperBoundEdit.setText(
                self._coerce_saved_text(
                    default_rule.get("absolute_upper_bound"),
                    self.ui.absoluteUpperBoundEdit.text(),
                )
            )
            self.ui.overwriteMinEdit.setText(
                self._coerce_saved_text(
                    default_rule.get(
                        "overwrite_lowerbound",
                        default_rule.get("overwrite_min"),
                    ),
                    self.ui.overwriteMinEdit.text(),
                )
            )
            self.ui.overwriteMaxEdit.setText(
                self._coerce_saved_text(
                    default_rule.get(
                        "overwrite_upperbound",
                        default_rule.get("overwrite_max"),
                    ),
                    self.ui.overwriteMaxEdit.text(),
                )
            )
            if "continuous_interval" in default_rule:
                self.ui.continuousIntervalCheckBox.setChecked(
                    bool(default_rule.get("continuous_interval"))
                )

        analysis = payload.get("analysis", {})
        selected_dataset_ids: list[str] = []
        parsing = payload.get("parsing", {})
        if isinstance(parsing, dict):
            self.ui.numericCleanupCheckBox.setChecked(bool(parsing.get("numeric_cleanup_enabled", False)))
            self._set_combo_code_if_present(self.ui.numericCleanupModeComboBox, parsing.get("numeric_cleanup_mode"))
            self.ui.numericCleanupCharsEdit.setText(
                self._coerce_saved_text(parsing.get("numeric_cleanup_characters"), self.ui.numericCleanupCharsEdit.text())
            )
            self._update_numeric_cleanup_state()
        if isinstance(analysis, dict):
            self._set_combo_code_if_present(self.ui.analysisScopeComboBox, analysis.get("analysis_scope"))
            self._set_combo_code_if_present(self.ui.outlierFailModeComboBox, analysis.get("outlier_fail_mode"))
            self._set_combo_code_if_present(self.ui.outlierMergeOrderComboBox, analysis.get("outlier_merge_order"))
            if "z_threshold" in analysis:
                self.ui.zThresholdSpinBox.setValue(float(analysis["z_threshold"]))
            self.ui.analysisSampleIdsEdit.setText(self._coerce_saved_text(analysis.get("sample_ids_text"), self.ui.analysisSampleIdsEdit.text()))
            self.ui.analysisExcludeSampleIdsEdit.setText(self._coerce_saved_text(analysis.get("exclude_sample_ids_text"), self.ui.analysisExcludeSampleIdsEdit.text()))
            self.ui.analysisNodesEdit.setText(self._coerce_saved_text(analysis.get("nodes_text"), self.ui.analysisNodesEdit.text()))
            self.ui.analysisExcludeNodesEdit.setText(self._coerce_saved_text(analysis.get("exclude_nodes_text"), self.ui.analysisExcludeNodesEdit.text()))
            if not self.ui.analysisTestsEdit.isReadOnly():
                self.ui.analysisTestsEdit.setText(self._coerce_saved_text(analysis.get("tests_text"), self.ui.analysisTestsEdit.text()))
            if not self.ui.analysisExcludeTestsEdit.isReadOnly():
                self.ui.analysisExcludeTestsEdit.setText(self._coerce_saved_text(analysis.get("exclude_tests_text"), self.ui.analysisExcludeTestsEdit.text()))
            selected_dataset_ids = [str(item) for item in analysis.get("selected_dataset_ids", [])]

        debug = payload.get("debug", {})
        if isinstance(debug, dict):
            self._set_verbose_logging_enabled(
                bool(debug.get("verbose_logging_enabled", False)),
                log_change=False,
            )

        ui_state = payload.get("ui_state", {})
        splitter_sizes: list[int] | None = None
        if isinstance(ui_state, dict):
            workbench_tab_index = ui_state.get("workbench_tab_index")
            if isinstance(workbench_tab_index, int) and 0 <= workbench_tab_index < self.ui.workbenchTabWidget.count():
                self.ui.workbenchTabWidget.setCurrentIndex(workbench_tab_index)
            result_tab_index = ui_state.get("result_tab_index")
            if isinstance(result_tab_index, int) and 0 <= result_tab_index < self.ui.resultTabWidget.count():
                self.ui.resultTabWidget.setCurrentIndex(result_tab_index)
            if isinstance(ui_state.get("splitter_sizes"), list):
                splitter_sizes = [int(item) for item in ui_state["splitter_sizes"]]

        self._refresh_analysis_imports(silent=True)
        self._set_selected_analysis_dataset_ids(selected_dataset_ids)
        self._update_analysis_mode_state()
        if splitter_sizes:
            self.ui.mainSplitter.setSizes(splitter_sizes)
        self._apply_persistent_result_state(payload)

    def _apply_persistent_result_state(self, payload: dict[str, object]) -> None:
        current_results = payload.get("current_results", {})
        if not isinstance(current_results, dict):
            current_results = {}

        golden_summary = current_results.get("golden_coverage_summary")
        if not isinstance(golden_summary, dict):
            golden_summary = None

        outlier_summary_rows = current_results.get("outlier_summary_rows", [])
        if not isinstance(outlier_summary_rows, list):
            outlier_summary_rows = []

        outlier_ratio_rows = current_results.get("outlier_ratio_rows", [])
        if not isinstance(outlier_ratio_rows, list):
            outlier_ratio_rows = []

        self.current_golden_coverage_summary = golden_summary
        self.current_outlier_summary_rows = list(outlier_summary_rows)
        self.current_outlier_ratio_rows = list(outlier_ratio_rows)
        self._refresh_golden_coverage_view(golden_summary)
        self._refresh_outlier_summary_view(
            self.current_outlier_summary_rows,
            self.current_outlier_ratio_rows,
        )

        log_text = payload.get("log_text")
        if isinstance(log_text, str):
            self.ui.logPlainTextEdit.setPlainText(log_text)

    @staticmethod
    def _set_combo_code_if_present(combo_box, value: object) -> None:
        if value is None:
            return
        text = str(value).strip()
        index = combo_box.findData(text)
        if index >= 0:
            combo_box.setCurrentIndex(index)
            return
        text_index = combo_box.findText(text)
        if text_index >= 0:
            combo_box.setCurrentIndex(text_index)
            return
        if text == "filtered_database":
            fallback_index = combo_box.findData("entire_database")
            if fallback_index >= 0:
                combo_box.setCurrentIndex(fallback_index)
                return
        if combo_box.isEditable():
            combo_box.setCurrentIndex(-1)
            combo_box.setEditText(text)

    @staticmethod
    def _coerce_saved_text(value: object, fallback: str) -> str:
        if value is None:
            return fallback
        return str(value)

    @Slot(bool)
    def _on_verbose_logging_toggled(self, checked: bool) -> None:
        self._set_verbose_logging_enabled(checked, log_change=True)

    def _set_verbose_logging_enabled(self, enabled: bool, log_change: bool) -> None:
        self._verbose_logging_enabled = bool(enabled)
        if self.ui.actionVerboseLogging.isChecked() != self._verbose_logging_enabled:
            self.ui.actionVerboseLogging.setChecked(self._verbose_logging_enabled)
        if log_change:
            if self._verbose_logging_enabled:
                self._safe_log(
                    "Verbose logging enabled. Extra progress details and database snapshots will be written to the Log tab."
                )
            else:
                self._safe_log("Verbose logging disabled.")

    def _verbose_log(self, message: str) -> None:
        if not self._verbose_logging_enabled:
            return
        self._safe_log("[Verbose] " + message)

    def _collect_storage_snapshot_for_logging(self) -> dict[str, object] | None:
        storage_path = self._storage_path_for_read()
        if not storage_path:
            return None
        template_path = self.ui.templatePathEdit.text().strip() or None
        payload = describe_storage(storage_path, template_path=template_path, limit=20)
        return {
            "database_root": self._database_root_path(),
            "workspace": storage_path,
            "dataset_count": payload["dataset_count"],
            "row_count": payload["row_count"],
            "measurement_count": payload["measurement_count"],
            "import_history_count": payload["import_history_count"],
            "dimensions": payload["dimensions"],
            "preview_rows": payload["rows"],
            "truncated": payload["truncated"],
        }

    def _verbose_log_storage_snapshot(self, label: str) -> None:
        if not self._verbose_logging_enabled:
            return
        try:
            snapshot = self._collect_storage_snapshot_for_logging()
        except Exception as exc:
            self._safe_log(f"[Verbose] {label}: failed to collect storage snapshot: {exc}")
            return
        self._safe_log(
            "[Verbose] "
            + label
            + ":\n"
            + json.dumps(snapshot, ensure_ascii=False, indent=2)
        )

    def _safe_log(self, message: str) -> None:
        try:
            self._log(message)
        except Exception as exc:
            print(f"GUI log write failed: {exc}", file=sys.stderr, flush=True)
            print(message, file=sys.stderr, flush=True)

    def _configure_combo_boxes(self) -> None:
        self._populate_combo_box(self.ui.outlierFailModeComboBox, OUTLIER_CRITERIA_OPTIONS)
        self._populate_combo_box(self.ui.outlierMergeOrderComboBox, OUTLIER_MERGE_ORDER_GUI_OPTIONS)
        self._populate_combo_box(self.ui.analysisScopeComboBox, ANALYSIS_SCOPE_OPTIONS)
        self._populate_combo_box(self.ui.centerMethodComboBox, CENTER_METHOD_OPTIONS)
        self._populate_combo_box(self.ui.thresholdModeComboBox, OUTLIER_GOLDEN_METHOD_OPTIONS)
        self.ui.thresholdModeComboBox.setEditable(True)
        self._populate_combo_box(self.ui.numericCleanupModeComboBox, NUMERIC_CLEANUP_MODE_OPTIONS)

    @staticmethod
    def _populate_combo_box(combo_box, options: list[tuple[str, str]]) -> None:
        combo_box.clear()
        for label, code in options:
            combo_box.addItem(label, code)

    @staticmethod
    def _combo_code(combo_box) -> str:
        if combo_box.isEditable():
            return str(combo_box.currentText() or "").strip()
        value = combo_box.currentData()
        if value is None:
            return str(combo_box.currentText() or "").strip()
        return str(value).strip()

    def _analysis_scope_code(self) -> str:
        return self._combo_code(self.ui.analysisScopeComboBox)

    def _outlier_fail_mode_code(self) -> str:
        return self._combo_code(self.ui.outlierFailModeComboBox)

    def _set_selected_analysis_dataset_ids(self, dataset_ids: list[str]) -> None:
        selected_ids = set(dataset_ids)
        for index in range(self.ui.analysisImportsListWidget.count()):
            item = self.ui.analysisImportsListWidget.item(index)
            item.setCheckState(Qt.Checked if str(item.data(Qt.UserRole)) in selected_ids else Qt.Unchecked)

    def _selected_storage_row_selectors(self) -> list[dict[str, object]]:
        headers = self.current_storage_headers
        if not headers:
            return []
        dataset_index = self._header_index(headers, "dataset_id")
        row_number_index = self._header_index(headers, "__row_number__")
        source_file_index = self._header_index(headers, "__source_file__")
        if dataset_index < 0 or row_number_index < 0 or source_file_index < 0:
            return []
        selectors: list[dict[str, object]] = []
        for row_index in sorted({item.row() for item in self.ui.storageTableWidget.selectedItems()}):
            dataset_item = self.ui.storageTableWidget.item(row_index, dataset_index)
            row_number_item = self.ui.storageTableWidget.item(row_index, row_number_index)
            source_file_item = self.ui.storageTableWidget.item(row_index, source_file_index)
            if dataset_item is None or row_number_item is None or source_file_item is None:
                continue
            selectors.append(
                {
                    "dataset_id": dataset_item.text(),
                    "row_number": row_number_item.text(),
                    "source_file": source_file_item.text(),
                }
            )
        return selectors

    @staticmethod
    def _header_index(headers: list[str], name: str) -> int:
        try:
            return headers.index(name)
        except ValueError:
            return -1

    @staticmethod
    def _set_hidden_table_columns(table, hidden_headers: list[str]) -> None:
        actual_headers = [
            table.horizontalHeaderItem(index).text()
            if table.horizontalHeaderItem(index) is not None
            else ""
            for index in range(table.columnCount())
        ]
        for header in hidden_headers:
            if header in actual_headers:
                table.setColumnHidden(actual_headers.index(header), True)

    def _collect_gui_settings_snapshot(self) -> dict[str, object]:
        template_summary = None
        template_error = None
        template_path = self.ui.templatePathEdit.text().strip()
        if template_path:
            try:
                template_summary = summarize_template(load_template(template_path))
            except Exception as exc:
                template_error = str(exc)
        return {
            "paths": {
                "template_path": template_path,
                "input_path": self.ui.inputPathEdit.text().strip(),
                "database_root_path": self._database_root_path(),
                "workspace_storage_path": self._active_storage_path(),
                "storage_path": self._active_storage_path(),
                "golden_path": self.ui.goldenPathEdit.text().strip(),
                "output_path": self.ui.outputPathEdit.text().strip(),
            },
            "template_summary": template_summary,
            "template_summary_error": template_error,
            "golden": {
                "golden_name": self.ui.goldenNameEdit.text().strip(),
                "reference_dims_text": self.ui.referenceDimsEdit.text().strip(),
                "filters_text": self.ui.filtersEdit.toPlainText(),
                "center_method": self._combo_code(self.ui.centerMethodComboBox),
                "outlier_golden_method": self._outlier_golden_method_text(),
                "relative_limit": self.ui.relativeLimitSpinBox.value(),
                "sigma_multiplier": self.ui.sigmaMultiplierSpinBox.value(),
                "absolute_lower_bound": self.ui.absoluteLowerBoundEdit.text().strip(),
                "absolute_upper_bound": self.ui.absoluteUpperBoundEdit.text().strip(),
                "overwrite_lowerbound": self.ui.overwriteMinEdit.text().strip(),
                "overwrite_upperbound": self.ui.overwriteMaxEdit.text().strip(),
                "continuous_interval": self.ui.continuousIntervalCheckBox.isChecked(),
            },
            "analysis": {
                "analysis_scope": self._analysis_scope_code(),
                "outlier_fail_mode": self._outlier_fail_mode_code(),
                "outlier_merge_order": self._outlier_merge_order_text(),
                "z_threshold": self.ui.zThresholdSpinBox.value(),
                "sample_ids_text": self.ui.analysisSampleIdsEdit.text().strip(),
                "exclude_sample_ids_text": self.ui.analysisExcludeSampleIdsEdit.text().strip(),
                "nodes_text": self.ui.analysisNodesEdit.text().strip(),
                "exclude_nodes_text": self.ui.analysisExcludeNodesEdit.text().strip(),
                "tests_text": self._analysis_test_text_for_state("include"),
                "exclude_tests_text": self._analysis_test_text_for_state("exclude"),
                "selected_dataset_ids": self._selected_analysis_dataset_ids(),
                "selected_import_entries": self._selected_analysis_import_entries(),
                "workbench_tab": self.ui.workbenchTabWidget.tabText(
                    self.ui.workbenchTabWidget.currentIndex()
                ),
                "result_tab": self.ui.resultTabWidget.tabText(
                    self.ui.resultTabWidget.currentIndex()
                ),
            },
        }

    def _collect_current_results_snapshot(self) -> dict[str, object]:
        return {
            "golden_coverage_summary": self.current_golden_coverage_summary,
            "outlier_summary_rows": self.current_outlier_summary_rows,
            "outlier_ratio_rows": self.current_outlier_ratio_rows,
            "storage_summary_label": self.ui.storageSummaryLabel.text(),
            "golden_coverage_summary_label": self.ui.goldenCoverageSummaryLabel.text(),
            "outlier_summary_label": self.ui.outlierSummaryLabel.text(),
            "outlier_ratio_summary_label": self.ui.outlierRatioSummaryLabel.text(),
        }

    def _resolve_existing_output_path(
        self,
        output_path: str | Path,
        label: str,
    ) -> str | None:
        mode = self._resolve_existing_output_mode(output_path, label)
        if mode is None:
            return None
        if mode == "timestamp":
            from ..output_paths import resolve_output_path

            return str(resolve_output_path(output_path, if_exists="timestamp"))
        return str(output_path)

    def _resolve_existing_report_output_base_path(
        self,
        output_path: str | Path,
        label: str,
    ) -> str | None:
        mode = self._resolve_existing_report_output_mode(output_path, label)
        if mode is None:
            return None
        if mode == "timestamp":
            return str(resolve_split_output_base_path(output_path, if_exists="timestamp"))
        return str(output_path)

    def _resolve_existing_report_output_mode(
        self,
        output_path: str | Path,
        label: str,
    ) -> str | None:
        target = Path(output_path)
        split_paths = derive_split_output_paths(target)
        existing_paths = [path for path in split_paths.values() if path.exists()]
        if not existing_paths:
            return "overwrite"
        message_box = QMessageBox(self)
        message_box.setWindowTitle("Output Path Already Exists")
        message_box.setIcon(QMessageBox.Warning)
        message_box.setText(
            f"{label} already exists:\n" + "\n".join(str(path) for path in existing_paths)
        )
        message_box.setInformativeText(
            "Choose Overwrite to replace them, Timestamp Suffix to keep the old files and create a new pair, or Cancel to stop this action."
        )
        overwrite_button = message_box.addButton("Overwrite", QMessageBox.AcceptRole)
        timestamp_button = message_box.addButton("Timestamp Suffix", QMessageBox.ActionRole)
        cancel_button = message_box.addButton(QMessageBox.Cancel)
        message_box.setDefaultButton(timestamp_button)
        self._ensure_message_box_button_widths(message_box)
        message_box.exec()
        clicked = message_box.clickedButton()
        if clicked == overwrite_button:
            return "overwrite"
        if clicked == timestamp_button:
            return "timestamp"
        if clicked == cancel_button:
            return None
        return None

    def _resolve_existing_output_directory(
        self,
        output_path: str | Path,
        label: str,
    ) -> str | None:
        mode = self._resolve_existing_output_mode(output_path, label)
        if mode is None:
            return None
        if mode == "timestamp":
            from ..output_paths import prepare_output_directory

            resolved = prepare_output_directory(output_path, if_exists="timestamp")
            return str(resolved)
        return str(output_path)

    def _resolve_existing_output_mode(
        self,
        output_path: str | Path,
        label: str,
    ) -> str | None:
        target = Path(output_path)
        if not target.exists():
            return "overwrite"
        message_box = QMessageBox(self)
        message_box.setWindowTitle("Output Path Already Exists")
        message_box.setIcon(QMessageBox.Warning)
        message_box.setText(
            f"{label} already exists:\n{target}"
        )
        message_box.setInformativeText(
            "Choose Overwrite to replace it, Timestamp Suffix to keep the old file and create a new one, or Cancel to stop this action."
        )
        overwrite_button = message_box.addButton("Overwrite", QMessageBox.AcceptRole)
        timestamp_button = message_box.addButton("Timestamp Suffix", QMessageBox.ActionRole)
        cancel_button = message_box.addButton(QMessageBox.Cancel)
        message_box.setDefaultButton(timestamp_button)
        self._ensure_message_box_button_widths(message_box)
        message_box.exec()
        clicked = message_box.clickedButton()
        if clicked == overwrite_button:
            return "overwrite"
        if clicked == timestamp_button:
            return "timestamp"
        if clicked == cancel_button:
            return None
        return None

    def _selected_analysis_import_entries(self) -> list[dict[str, str]]:
        entries: list[dict[str, str]] = []
        for index in range(self.ui.analysisImportsListWidget.count()):
            item = self.ui.analysisImportsListWidget.item(index)
            if item.checkState() != Qt.Checked:
                continue
            entries.append(
                {
                    "dataset_id": str(item.data(Qt.UserRole)),
                    "label": item.text(),
                }
            )
        return entries

    @staticmethod
    def _populate_table(table, headers: list[str], rows: list[list[str]]) -> None:
        table.setSortingEnabled(False)
        table.clearContents()
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(
            [MainWindow._display_header_label(header) for header in headers]
        )
        table.setRowCount(len(rows))
        for row_index, values in enumerate(rows):
            for column_index, value in enumerate(values):
                table.setItem(
                    row_index,
                    column_index,
                    NaturalSortTableWidgetItem(value),
                )
        table.resizeColumnsToContents()
        table.setSortingEnabled(True)

    @staticmethod
    def _display_header_label(header: str) -> str:
        if not header:
            return header
        if " " in header and "_" not in header:
            return header
        normalized = str(header).strip()
        special = {
            "id": "ID",
            "sample_id": "Sample ID",
            "dataset_id": "Dataset ID",
            "row_number": "Row Number",
            "logical_metric": "Logical Metric",
            "raw_column": "Raw Column",
            "display_name": "Display Name",
            "chain": "Chain Name",
            "group_by_dimension": "Group By Dimension",
            "group_value": "Group Value",
            "outlier_sample_count": "Outlier Sample Count",
            "total_sample_count": "Total Sample Count",
            "outlier_ratio": "Outlier Ratio",
            "filter_summary": "Filter Summary",
            "total_measurement_count": "Total Measurement Count",
            "matched_measurement_count": "Matched Measurement Count",
            "unmatched_measurement_count": "Unmatched Measurement Count",
            "matched_row_count": "Matched Row Count",
            "unmatched_row_count": "Unmatched Row Count",
            "current_database_rows": "Current Database Rows",
        }
        if normalized in special:
            return special[normalized]
        words = normalized.replace("_", " ").split()
        return " ".join(
            "ID" if word.lower() == "id" else word.capitalize()
            for word in words
        )


class AboutDialog(QDialog):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.ui = Ui_AboutDialog()
        self.ui.setupUi(self)
        self.setWindowTitle(f"About {APP_DISPLAY_NAME}")
        self.ui.summaryLabel.setText(
            f"{APP_DISPLAY_NAME} helps teams import evolving test data, compare it with golden or z-score criteria, and generate highly configurable outlier reports with node-aware tracking."
        )
        self.ui.versionLabel.setText(f"Version: {APP_VERSION}")
        self.ui.teamLabel.setText(f"Team: {APP_TEAM}")
        icon_path = icon_png_path()
        if icon_path is not None and icon_path.exists():
            pixmap = QPixmap(str(icon_path))
            if not pixmap.isNull():
                self.ui.iconLabel.setPixmap(
                    pixmap.scaled(
                        144,
                        144,
                        Qt.KeepAspectRatio,
                        Qt.SmoothTransformation,
                    )
                )


def launch() -> None:
    mp.freeze_support()
    app = QApplication(sys.argv)
    qdarktheme.setup_theme("dark")
    window = MainWindow()
    window.show()
    app.exec()


if __name__ == "__main__":
    launch()
