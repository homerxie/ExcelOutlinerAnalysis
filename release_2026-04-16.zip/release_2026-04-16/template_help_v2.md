# Template Manual v2

[toc]

## 1. Workbook 总览

### 1.1 支持格式

当前 template 支持两种文件格式：

- `json`
- `xlsx`

程序内部会先把它们解析成同一套 `TemplateConfig`。

### 1.2 `xlsx` Workbook 包含的 sheet

| Sheet | 是否参与解析 | 主要作用 |
| --- | --- | --- |
| `template_info` | 是 | 全局参数入口。决定数据区位置、golden 默认值、outlier 判定方式等。 |
| `row_dimensions` | 是 | 定义左侧行维度如何从原始输入表提取。 |
| `column_header_levels` | 是 | 定义横向测试表头的层级名字和顺序。 |
| `analysis_groups` | 是 | 定义每个测试列属于哪个逻辑 group，以及 group 级规则。 |
| `node_orders` | 是 | 定义 node 的时序关系。 |
| `analysis_dimension_filters` | 是 | 定义分析开始前就生效的行维度过滤。 |
| `analysis_column_filters` | 是 | 定义分析开始前就生效的测试列过滤。 |
| `outlier_ratio_stats` | 是 | 定义 `Outlier Summary` 里的比例统计块。 |
| `README` | 否 | 仅用于说明，不参与配置解析。 |

### 1.3 推荐编辑顺序

1. `template_info`
2. `row_dimensions`
3. `column_header_levels`
4. `analysis_groups`
5. `node_orders`
6. `analysis_dimension_filters`
7. `analysis_column_filters`
8. `outlier_ratio_stats`

原因：

- 后面的很多字段都依赖前面已经定义好的名字
- 例如 `analysis_groups` 依赖 `column_header_levels`
- 例如 `sample_dimension_names`、`outlier_row_merge_max_dimension`、`outlier_ratio_stats.group_by_dimension` 都依赖 `row_dimensions`

## 2. 通用填写规则

### 2.1 行号和列号都是零基准

下面这些字段都使用零基准：

- `test_data_header_row`
- `row_header_row`
- `unit_row`
- `test_data_start_row`
- `test_data_start_column`

含义：

- `0` 表示第一行或第一列
- `1` 表示第二行或第二列

例如：

- `test_data_header_row = 0`
  - 表示测试区列名在 Excel 的第一行
- `test_data_start_row = 5`
  - 表示真正的数据从 Excel 的第六行开始

### 2.2 一个单元格内的多值写法

如果一个单元格需要表达多个值，统一使用 `;` 分隔。

常见场景：

- `sample_dimension_names = lot_id;sample_id`
- `golden_reference_dimensions = lot_id;sample_id;reliability_node`
- `group_by_dimension = reliability_node;lot_id`
- `numeric_cleanup_characters = ,;%;mV;ohm`

### 2.3 布尔值写法

Excel / JSON 中布尔字段支持这些写法：

- 真值：
  - `1`
  - `true`
  - `yes`
  - `y`
- 假值：
  - `0`
  - `false`
  - `no`
  - `n`

如果布尔内容不是这些，会报错。

### 2.4 自由输入字段建议

这类字段不是从几个固定选项里选，而是由使用者自由命名或自由填写。

| xlsx 写法 | JSON 写法 | 建议示例 | 说明 |
| --- | --- | --- | --- |
| `Field = name` | `name` | `chip_reliability_template` | 模板名建议稳定、简洁、易区分版本。 |
| `row_dimensions.Name` | `row_dimensions[*].name` | `sample_id`、`reliability_node`、`repeat_id` | 建议使用稳定的 snake_case。 |
| `row_dimensions.Display Name` | `row_dimensions[*].display_name` | `Sample ID`、`Reliability Node` | 报表展示名称，可以更偏业务语言。 |
| `row_dimensions.Source Column` | `row_dimensions[*].sources[*].column` | `recordName`、`Lot`、`Site` | 必须与输入表中的真实列名一致。 |
| `column_header_levels.Name` | `column_header_levels[*].name` | `Chain Name`、`Test Type`、`Repeat Index` | 横向表头层级名。 |
| `analysis_groups.ID` | `analysis_groups[*].id` | `link1_resistance` | 建议使用稳定、短、可读的业务名。 |
| `analysis_groups.Display Name` | `analysis_groups[*].display_name` | `Link1 Resistance` | 最终会直接影响报表显示。 |
| `analysis_groups.Unit` | `analysis_groups[*].unit` | `Ohm`、`uA`、`V`、`f` | 单位字段自由填写。 |
| `analysis_groups.Column Name` | `analysis_groups[*].columns[*].name` | `R_Link1_1V_1` | 必须与原始测试列列名完全一致。 |
| `node_orders.Sequence Name` | `node_orders[*].name` | `Sequence 1`、`T0 to T2 Path` | 只用于阅读和标识。 |
| `outlier_ratio_stats.ID` | `report.outlier_ratio_stats[*].id` | `new_ratio_by_node_all` | 统计项内部标识。 |
| `outlier_ratio_stats.Display Name` | `report.outlier_ratio_stats[*].display_name` | `New Outlier Ratio By Node` | 报表中展示的统计项标题。 |

<a id="template-info-sheet"></a>
## 3. `template_info` Sheet

### 3.1 作用

`template_info` 是整个模板的控制面板。

它负责定义：

- 输入表中数据区和表头区的位置
- 样品主键如何构成
- outlier 判定使用哪种策略
- 行合并、列合并从哪里开始
- golden 默认规则怎么设
- 数字清洗是否启用

通常这是最先填写、也最需要先确认的一页。

### 3.2 表头结构

| 列名 | 作用 |
| --- | --- |
| `Field` | 参数名 |
| `Value` | 参数值 |
| `Notes` | 备注列，仅用于阅读 |

### 3.3 基础定位字段

本节关键词直接使用 `template_info` 里 `Field` 列实际填写的值；对应 JSON 写法如下：

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `name` | `name` |
| `test_data_header_row` | `test_data_header_row` |
| `row_header_row` | `row_header_row` |
| `test_data_start_column` | `test_data_start_column` |
| `unit_row` | `unit_row` |
| `test_data_start_row` | `test_data_start_row` |

- `name`
  - 作用：
    - 给整套 template 起一个唯一、稳定的标识名。
  - 可选值：
    - 任意字符串。
  - 详细说明：
    - 这个字段主要用于标识模板本身，不直接影响分析计算逻辑。
    - 但在多人协作、模板归档、调试记录时，建议保持命名稳定。
  - 示例：
    - `chip_reliability_template`

- `test_data_header_row`
  - 作用：
    - 指定测试区列名所在的行。
  - 可选值：
    - 非负整数。
  - 详细说明：
    - 这一行通常包含横向测试列名，例如 `R_Link1_1V_1`、`V_Link1_1p8V` 这类原始测试列头。
    - 程序会用它来定位测试数据区域的列名。
  - 示例：
    - `0`

- `row_header_row`
  - 作用：
    - 指定样品属性列名所在的行。
  - 可选值：
    - 非负整数。
  - 详细说明：
    - 这一行通常包含左侧属性列名，例如 `recordName`、`Lot`、`Site` 等。
    - 程序会用这行去识别 `row_dimensions` 中引用的源列。
  - 示例：
    - `4`

- `test_data_start_column`
  - 作用：
    - 指定测试数据区域从哪一列开始。
  - 可选值：
    - 非负整数或留空。
  - 详细说明：
    - 如果填写了它，程序从这列开始会优先使用 `test_data_header_row` 的表头作为测试列名。
    - 这样可以避免测试区右半部分继续被 `row_header_row` 覆盖。
    - 如果留空，则程序不会强行用这一列切断区域。
  - 示例：
    - `8`

- `unit_row`
  - 作用：
    - 指定单位行的位置。
  - 可选值：
    - 非负整数或留空。
  - 详细说明：
    - 有些输入表会专门在某一行写单位，如 `V`、`Ohm`、`uA`。
    - 如果你的原始表没有单位行，可以留空。
  - 示例：
    - `3`

- `test_data_start_row`
  - 作用：
    - 指定真正的测试数据从哪一行开始。
  - 可选值：
    - 非负整数。
  - 详细说明：
    - 这是必填字段。
    - 程序不会自动推断数据起始行，如果不写，模板校验会直接报错。
  - 示例：
    - `5`

### 3.4 样品主键与 node 顺序字段

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `node_order` | `report.node_order` |
| `sample_dimension_names` | `report.sample_dimension_names` |

- `node_order`
  - 作用：
    - 表示旧版的单条 node 顺序。
  - 可选值：
    - `;` 分隔的 node 列表，或留空。
  - 详细说明：
    - 这个字段在 Excel 模板里已经属于兼容写法。
    - 新模板更推荐改写 `node_orders` sheet，而不是继续在这里维护。
  - 示例：
    - `T0;T1;T2`

- `sample_dimension_names`
  - 作用：
    - 明确指定哪些 `row_dimensions.name` 要一起构成“样品主键”。
  - 可选值：
    - 一个或多个已定义的 `row_dimensions.name`，多值用 `;` 分隔。
  - 详细说明：
    - 这个字段会直接影响：
      - `Outlier Summary`
      - outlier ratio 的样品去重
      - sample 级 node order 匹配
    - 程序不会再隐式取第一个 row dimension 作为样品主键。
    - 只要你定义了 `row_dimensions`，通常这里就必须写清楚。
  - 示例：
    - `sample_id`
    - `lot_id;sample_id`

### 3.5 `outlier_fail_method`

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `outlier_fail_method` | `report.outlier_fail_method` |

- `outlier_fail_method`
  - 作用：
    - 定义最终 fail 是根据 zscore、golden，还是两者组合来判定。
  - 可选值：
    - `modified_z_score`
    - `golden_deviation`
    - `zscore_and_golden`
    - `zscore_or_golden`
  - 详细说明：
    - 这是最核心的判 fail 策略之一。
    - 它会影响 `outliers`、`summary` 等结果页中“这条记录是否算 fail”。

各可选项含义：

- `modified_z_score`
  - 含义：
    - 只看 zscore 是否超阈值。
  - 适用理解：
    - 更偏统计异常检测，不依赖 built golden。

- `golden_deviation`
  - 含义：
    - 只看是否偏离 golden 允许范围。
  - 适用理解：
    - 更偏工艺/规范基准判断。

- `zscore_and_golden`
  - 含义：
    - zscore 超 threshold 且 golden 偏差也超范围，才判 fail。
  - 适用理解：
    - 判定更严格，倾向于降低误报。

- `zscore_or_golden`
  - 含义：
    - zscore 或 golden 任意一个超界，就判 fail。
  - 适用理解：
    - 判定更敏感，倾向于不漏掉风险。

### 3.6 四类 fail rule

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `outlier_merged_test_fail_rule` | `report.outlier_merged_test_fail_rule` |
| `outlier_test_group_fail_rule` | `report.outlier_test_group_fail_rule` |
| `outlier_merged_sample_fail_rule` | `report.outlier_merged_sample_fail_rule` |
| `outlier_node_fail_rule` | `report.outlier_node_fail_rule` |

这四个字段都只有两个选项：

- `any_fail`
- `all_fail`

但它们作用的“聚合层级”不同，所以不能混着理解。

#### 3.6.1 `outlier_merged_test_fail_rule`

- 作用：
  - 定义 `column merge` 阶段，一个 merged test pool 内部如何从多个单个原始测试项汇总成一个结果。
- 可选值：
  - `any_fail`
  - `all_fail`

各可选项含义：

- `any_fail`
  - 只要该 merged test pool 里任意一个单个原始测试项 fail，就认为这个 merged test pool fail。

- `all_fail`
  - 只有该 merged test pool 里所有单个原始测试项都 fail，才认为这个 merged test pool fail。

#### 3.6.2 `outlier_test_group_fail_rule`

- 作用：
  - 定义 `column group` 阶段，较高层测试分组如何继续向上汇总。
- 可选值：
  - `any_fail`
  - `all_fail`

各可选项含义：

- `any_fail`
  - 只要任意一个子组 fail，就认为更高层 test group fail。

- `all_fail`
  - 必须所有子组都 fail，才认为更高层 test group fail。

#### 3.6.3 `outlier_merged_sample_fail_rule`

- 作用：
  - 定义同一个 merged row pool 内，多条原始数据行如何汇总成一个 row pool 结果。
- 可选值：
  - `any_fail`
  - `all_fail`

各可选项含义：

- `any_fail`
  - 只要该 row pool 里任意一条原始数据行 fail，就认为该 row pool fail。

- `all_fail`
  - 必须该 row pool 里所有原始数据行都 fail，才认为该 row pool fail。

#### 3.6.4 `outlier_node_fail_rule`

- 作用：
  - 定义同一个 `sample + reliability_node` 下，多个 merged row pool 如何再聚合成 node-level fail。
- 可选值：
  - `any_fail`
  - `all_fail`

各可选项含义：

- `any_fail`
  - 只要该 node 下任意一个 merged row pool fail，就认为该 node fail。

- `all_fail`
  - 必须该 node 下所有 merged row pool 都 fail，才认为该 node fail。

### 3.7 行合并和列合并边界

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `outlier_row_merge_max_dimension` | `report.outlier_row_merge_max_dimension` |
| `outlier_test_merge_max_level` | `report.outlier_test_merge_max_level` |

- `outlier_row_merge_max_dimension`
  - 作用：
    - 定义从哪一个 `row_dimensions.name` 开始往下 merge 成 row pool。
  - 可选值：
    - 已存在的 `row_dimensions.name`。
  - 详细说明：
    - row 维度会按 `priority` 排序。
    - 这个字段决定“从哪一层开始，下面的 row 维度一起参加 any/all 判断”。
    - 写得越靠后，池子越小。
    - 写得越靠前，池子越大。
    - 如果存在 `reliability_node`，这个字段必须低于 `reliability_node`。
  - 示例：
    - 假设优先级顺序是：
      - `lot`
      - `sample_id`
      - `reliability_node`
      - `site_id`
      - `repeat_id`
    - 如果写：
      - `outlier_row_merge_max_dimension = site_id`
    - 含义就是：
      - `lot`、`sample_id`、`reliability_node` 保留在 pool 外
      - `site_id`、`repeat_id` 一起进入 row pool

- `outlier_test_merge_max_level`
  - 作用：
    - 定义从哪一个 `column_header_levels.name` 开始往下合并成 test pool。
  - 可选值：
    - 已存在的 `column_header_levels.name`。
  - 详细说明：
    - column 层级会按 `priority` 排序。
    - 这个字段定义“从哪一层开始，下面的列层级一起参加 column merge”。
  - 示例：
    - 假设层级顺序是：
      - `Chain Name`
      - `Test Type`
      - `Repeat Index`
    - 如果写：
      - `outlier_test_merge_max_level = Test Type`
    - 含义就是：
      - `Chain Name` 保留在 pool 外
      - `Test Type` 和 `Repeat Index` 一起进入 test pool

### 3.8 `outlier_merge_order`

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `outlier_merge_order` | `report.outlier_merge_order` |

- `outlier_merge_order`
  - 作用：
    - 决定四个 merge 模块执行的先后顺序。
  - 可选值：
    1. `column merge -> column group -> row merge -> row node`
    2. `row merge -> row node -> column merge -> column group`
    3. `column merge -> row merge -> column group -> row node`
    4. `row merge -> column merge -> row node -> column group`
    5. `column merge -> row merge -> row node -> column group`
    6. `row merge -> column merge -> column group -> row node`
  - 详细说明：
    - 这 6 种顺序是固定枚举，不能随意拼写其他字符串。
    - 它决定 column 方向和 row 方向上的聚合是先做还是后做。
    - 这个字段主要影响复杂模板下最终 fail 的传播路径和聚合结果。

### 3.9 golden 默认字段

这一组字段都写在 `template_info` 的 `Field / Value` 里，但 JSON 会落到 `golden_reference_defaults` 对象下。

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `golden_reference_dimensions` | `golden_reference_defaults.reference_dimensions` |
| `golden_reference_filters` | `golden_reference_defaults.filters` |
| `golden_reference_center_method` | `golden_reference_defaults.center_method` |
| `golden_reference_outlier_golden_method` | `golden_reference_defaults.outlier_golden_method` |
| `golden_reference_relative_limit` | `golden_reference_defaults.relative_limit` |
| `golden_reference_sigma_multiplier` | `golden_reference_defaults.sigma_multiplier` |
| `golden_reference_absolute_lower_bound` | `golden_reference_defaults.absolute_lower_bound` |
| `golden_reference_absolute_upper_bound` | `golden_reference_defaults.absolute_upper_bound` |
| `golden_reference_overwrite_lowerbound` | `golden_reference_defaults.overwrite_lowerbound` |
| `golden_reference_overwrite_upperbound` | `golden_reference_defaults.overwrite_upperbound` |
| `golden_reference_continuous_interval` | `golden_reference_defaults.continuous_interval` |

#### 3.9.1 `golden_reference_dimensions`

- 作用：
  - 定义 Build Golden 时，reference key 由哪些 row 维度组成。
- 可选值：
  - 一个或多个已定义的 `row_dimensions.name`，使用 `;` 分隔。
- 详细说明：
  - 这个字段决定 golden reference 是按什么粒度建立的。
  - 写得越细，golden reference 的分组越细。
  - 写得越粗，更多数据会被归到同一个 reference key 里。
- 示例：
  - `sample_id`
  - `lot_id;sample_id`

#### 3.9.2 `golden_reference_filters`

- 作用：
  - 定义 Build Golden 时默认要保留哪些 reference 数据。
- 可选值：
  - `key=value` 形式的过滤条件，多个条件之间使用 `;` 分隔。
  - `key`必须是是template `row_dimensions`表格中的`Name`，`value`就是实际样品可能的值
- 详细说明：
  - 这个字段在解析时会被当成一个字典读取。
  - 每一项都必须写成 `key=value`。
  - 不同 key 之间是同时生效的关系。
  - 如果同一个 key 需要匹配多个值，可以在 value 里用 `,`。

标准格式：

```text
reliability_node=T0;site_id=A;temp=25C
```

多值示例：

```text
reliability_node=T0,T1,T2;site_id=A
```

上面的含义是：

- `reliability_node` 只要是 `T0`、`T1`、`T2` 之一就算命中
- 同时 `site_id` 还必须等于 `A`

注意：

- 分隔符必须是 `;`
- 同一个 key 如果需要拆开写，也可以重复出现，程序会自动合并

重复 key 示例：

```text
reliability_node=T0;reliability_node=T1;site_id=A
```

上面的含义与下面这条写法等价：

```text
reliability_node=T0,T1;site_id=A
```

#### 3.9.3 `golden_reference_center_method`

- 作用：
  - 定义 golden center 是用均值还是中位数。
- 可选值：
  - `mean`
  - `median`

各可选项含义：

- `mean`
  - 使用平均值作为 golden center。
  - 适合数据分布比较稳定、极端值影响不大的场景。

- `median`
  - 使用中位数作为 golden center。
  - 适合更稳健地抵抗离群值影响。

#### 3.9.4 `golden_reference_outlier_golden_method`

- 作用：
  - 定义默认的 golden 允许区间规则。
- 可选值：
  - 合法 golden rule 表达式。
- 详细说明：
  - 这是 built golden 的核心规则。
  - 它决定允许区间是按相对偏差、sigma、绝对边界，还是这些规则的组合来构建。

#### 3.9.5 golden rule 表达式可用元素

| 类别 | 可选值 | 作用 |
| --- | --- | --- |
| 基础项 | `relative` | 按相对偏差建范围 |
| 基础项 | `sigma` | 按 sigma 倍数建范围 |
| 基础项 | `absolute` | 按绝对上下界建范围 |
| 逻辑运算 | `and` | 多个条件同时成立 |
| 逻辑运算 | `or` | 满足任一条件即可 |
| 结构 | `(` `)` | 控制表达式优先级 |
| 后缀修饰 | `+ overwrite_lowerbound` | 最终强行覆盖下界 |
| 后缀修饰 | `+ overwrite_upperbound` | 最终强行覆盖上界 |

合法示例：

- `relative`
- `sigma`
- `absolute`
- `relative and sigma`
- `relative or absolute`
- `relative or (sigma and absolute)`
- `absolute or relative + overwrite_upperbound`
- `sigma + overwrite_lowerbound + overwrite_upperbound`

#### 3.9.6 配套参数

- `golden_reference_relative_limit`
  - 作用：
    - 为 `relative` 规则提供相对偏差阈值。
  - 何时必填：
    - 当规则使用 `relative` 时。
  - 示例：
    - `0.2`

- `golden_reference_sigma_multiplier`
  - 作用：
    - 为 `sigma` 规则提供 sigma 倍数。
  - 何时必填：
    - 当规则使用 `sigma` 时。
  - 示例：
    - `3.0`

- `golden_reference_absolute_lower_bound`
  - 作用：
    - 为 `absolute` 规则提供下界。
  - 何时必填：
    - 当规则使用 `absolute` 时。
  - 示例：
    - `80`

- `golden_reference_absolute_upper_bound`
  - 作用：
    - 为 `absolute` 规则提供上界。
  - 何时必填：
    - 当规则使用 `absolute` 时。
  - 示例：
    - `120`

- `golden_reference_overwrite_lowerbound`
  - 作用：
    - 在最终允许区间生成后，强制改写最低下界。
  - 何时必填：
    - 当规则使用 `+ overwrite_lowerbound` 时。
  - 示例：
    - `85`

- `golden_reference_overwrite_upperbound`
  - 作用：
    - 在最终允许区间生成后，强制改写最高上界。
  - 何时必填：
    - 当规则使用 `+ overwrite_upperbound` 时。
  - 示例：
    - `115`

- `golden_reference_continuous_interval`
  - 作用：
    - 如果最终规则会得到多个分段区间，是否把它们强制并成一个连续区间。
  - 可选值：
    - `true`
    - `false`
  - 详细说明：
    - `false` 时保留分段区间。
    - `true` 时会取所有结果区间中的最小下界和最大上界，形成一个连续区间。
    - 这个字段和其他 golden 规则一起生效，analysis group 里的同名字段会覆盖全局默认。

### 3.10 `numeric_cleanup`

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `numeric_cleanup_enabled` | `numeric_cleanup.enabled` |
| `numeric_cleanup_mode` | `numeric_cleanup.mode` |
| `numeric_cleanup_characters` | `numeric_cleanup.characters` |

- `numeric_cleanup_enabled`
  - 作用：
    - 控制在把单元格文本转成数字前，是否先做字符清洗。
  - 可选值：
    - 布尔值。

- `numeric_cleanup_mode`
  - 作用：
    - 定义清洗使用哪种模式。
  - 可选值：
    - `all_non_numeric`
    - `specified_chars`

各可选项含义：

- `all_non_numeric`
  - 含义：
    - 把所有非数字字符都清掉，再尝试解析数字。
  - 适用场景：
    - 原始数据中混有单位、百分号、文本后缀。

- `specified_chars`
  - 含义：
    - 只清掉你在 `numeric_cleanup_characters` 里明确列出的字符。
  - 适用场景：
    - 你不希望“全部非数字字符”都被删掉，只想精确去除几个已知字符。

- `numeric_cleanup_characters`
  - 作用：
    - 定义 `specified_chars` 模式下要删掉哪些字符。
  - 可选值：
    - 使用 `;` 分隔的字符列表。
  - 示例：
    - `,;%;mV;ohm`

<a id="row-dimensions-sheet"></a>
## 4. `row_dimensions` Sheet

### 4.1 作用

`row_dimensions` 用来定义每一行样品数据的业务维度怎么提取。

常见维度包括：

- `sample_id`
- `reliability_node`
- `repeat_id`
- `site_id`
- `temp`

### 4.2 一行代表什么

在 Excel 模板里：

- 一行表示一个 `source`
- 如果同一个维度有多个 `source`，就会出现多行
- 如果同一个 source 需要写多条“匹配值 -> split 位置”的映射，也可能占多行

所以 Excel 里的 `row_dimensions` 是“长表模式”。

### 4.3 字段说明

下面优先使用 `row_dimensions` sheet 的 Excel 列名来说明；右侧给出对应 JSON 写法。

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `Name` | `row_dimensions[*].name` |
| `Display Name` | `row_dimensions[*].display_name` |
| `Priority` | `row_dimensions[*].priority` |
| `Optional` | `row_dimensions[*].optional` |
| `Default Value` | `row_dimensions[*].default_value` |
| `Source Order` | `row_dimensions[*].sources[*]` 的数组顺序，Excel 专用列 |
| `Source Column` | `row_dimensions[*].sources[*].column` |
| `Default Split Position` | `row_dimensions[*].sources[*].default_split_position` |
| `Split Position By Column` | `row_dimensions[*].sources[*].split_position_by_column` |
| `Match Value` | `row_dimensions[*].sources[*].split_position_map` 的 key |
| `Mapped Split Position` | `row_dimensions[*].sources[*].split_position_map` 的 value |
| `Skip Empty Parts` | `row_dimensions[*].sources[*].skip_empty_parts` |
| `Delimiter 1..N` | `row_dimensions[*].sources[*].split_delimiters[*]` |

- `Name`
  - 作用：
    - 定义维度的内部名称。
  - 可选值：
    - 唯一字符串。
  - 详细说明：
    - 后续会作为 `dimensions[name]` 的 key 使用。
    - 不能重复。
  - 示例：
    - `sample_id`
    - `reliability_node`

- `Display Name`
  - 作用：
    - 定义报表里显示的维度标题。
  - 可选值：
    - 任意字符串，或留空。
  - 详细说明：
    - 如果省略，界面或报表通常会退回使用 `Name`。
  - 示例：
    - `Sample ID`
    - `Reliability Node`

- `Priority`
  - 作用：
    - 定义 row 维度的优先级顺序。
  - 可选值：
    - 正整数。
  - 详细说明：
    - 数字越小，优先级越高，越靠前。
    - `outlier_row_merge_max_dimension` 等规则依赖这个顺序。
  - 示例：
    - `1`
    - `2`
    - `3`

- `Optional`
  - 作用：
    - 定义该维度取不到值时，整行是否仍然允许继续保留。
  - 可选值：
    - 布尔值。

各可选项含义：

- `true`
  - 允许缺失。
  - 如果最终提取不到值，这个维度可以为空，不一定导致整行报废。

- `false`
  - 不允许缺失。
  - 如果最终提取不到值，整行会被视为无效并跳过。

- `Default Value`
  - 作用：
    - 当该维度所有 source 都提取不到值时，提供一个回填值。
  - 可选值：
    - 任意字符串，或留空。
  - 详细说明：
    - 常见用法是给 `repeat_id` 这类维度补默认值。
  - 示例：
    - `1`

- `Source Order`
  - 作用：
    - 定义同一个维度下多个 source 的提取顺序。
  - 可选值：
    - 正整数。
  - 详细说明：
    - JSON 中 `sources` 本身是数组，天然有顺序。
    - Excel 中因为一个维度会拆成多行，所以需要单独写 `Source Order`。

- `Source Column`
  - 作用：
    - 指定从输入表的哪一列取原始文本。
  - 可选值：
    - 输入表中真实存在的列名。
  - 示例：
    - `recordName`
    - `Lot`
    - `Site`

- `Default Split Position`
  - 作用：
    - 指定 split 之后默认取第几个片段。
  - 可选值：
    - 非负整数或留空。
  - 详细说明：
    - 如果填写了它，必须同时定义至少一个 delimiter。
    - 旧字段名 `split_position` 在兼容读取时仍然能工作，但新模板建议统一写 `Default Split Position`。
  - 示例：
    - `0`
    - `1`
    - `2`

- `Split Position By Column`
  - 作用：
    - 指定要参考哪一列，动态决定当前 source 使用哪个 split position。
  - 可选值：
    - 输入表列名或留空。
  - 示例：
    - `Site`

- `Match Value`
  - 作用：
    - 表示另一列的某个匹配值。
  - 可选值：
    - 任意字符串或留空。
  - 示例：
    - `1`
    - `2`
    - `A`

- `Mapped Split Position`
  - 作用：
    - 当命中 `Match Value` 时，改用哪个 split position。
  - 可选值：
    - 非负整数或留空。
  - 示例：
    - `0`
    - `1`
    - `2`

- `Skip Empty Parts`
  - 作用：
    - 控制 split 后是否忽略空片段。
  - 可选值：
    - 布尔值。

各可选项含义：

- `true`
  - 连续分隔符导致的空字符串会被丢掉。
  - 例如 `A__B` 可能被当成 `A`、`B`。

- `false`
  - 空字符串片段会被保留。

- `Delimiter 1..N`
  - 作用：
    - 定义一个 source 可以用哪些分隔符切分。
  - 可选值：
    - 任意普通文本分隔符。
  - 详细说明：
    - 这是普通文本切分，不是正则表达式。
  - 示例：
    - `_`
    - `｜`
    - `-`
    - `:`

### 4.4 程序实际提取行为

程序提取维度时的规则如下：

1. 按 `row_dimensions` 顺序处理每个维度。
2. 对当前维度，按 `sources` 顺序依次提取。
3. 每个 source：
   - 如果配了 `split_position_by_column + split_position_map`：
     - 先读取另一列的值；
     - 如果命中映射，优先用映射得到的 split position；
     - 如果没命中，再回退到普通 `default_split_position`。
   - 如果最终没有可用 split position：
     - 直接取整格文本。
   - 如果最终有 split position：
     - 先按 `split_delimiters` 切分，再取指定位置。
4. 把所有成功提取的 source 结果用 `|` 拼成最终维度值。
5. 如果一个维度所有 source 都没拿到值：
   - 有 `default_value` 就用默认值；
   - 没默认值但 `optional=true` 就允许为空；
   - 否则整行数据无效。

### 4.5 典型示例

#### 4.5.1 从一个列里拆出样品号

| `Name` | `Display Name` | `Priority` | `Optional` | `Default Value` | `Source Order` | `Source Column` | `Default Split Position` | `Split Position By Column` | `Match Value` | `Mapped Split Position` | `Skip Empty Parts` | `Delimiter 1` | `Delimiter 2` |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `sample_id` | `SampleID` | `2` | `false` |  | `1` | `recordName` | `0` |  |  |  | `false` | `_` | `｜` |

这表示：

- 从 `recordName` 列取原始文本
- 先按 `_` 或 `｜` 切分
- 默认取第 `0` 段作为 `sample_id`

#### 4.5.2 一个维度由多个原始列重组

| `Name` | `Display Name` | `Priority` | `Optional` | `Default Value` | `Source Order` | `Source Column` | `Default Split Position` | `Split Position By Column` | `Match Value` | `Mapped Split Position` | `Skip Empty Parts` | `Delimiter 1` | `Delimiter 2` |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `location` | `Location` | `4` | `false` |  | `1` | `Line` |  |  |  |  | `false` |  |  |
| `location` | `Location` | `4` | `false` |  | `2` | `Site` |  |  |  |  | `false` |  |  |

最终结果可能是：

| 输入列 `Line` | 输入列 `Site` | 最终 `location` |
| --- | --- | --- |
| `A` | `03` | `A|03` |

这表示：

- 先取 `Line`
- 再取 `Site`
- 两个 source 的结果按 `Source Order` 顺序用 `|` 拼接

#### 4.5.3 按另一列动态决定 split position

| `Name` | `Display Name` | `Priority` | `Optional` | `Default Value` | `Source Order` | `Source Column` | `Default Split Position` | `Split Position By Column` | `Match Value` | `Mapped Split Position` | `Skip Empty Parts` | `Delimiter 1` | `Delimiter 2` |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `sample_id` | `SampleID` | `2` | `false` |  | `1` | `recordName` | `0` | `Site` | `1` | `0` | `false` | `_` |  |
| `sample_id` | `SampleID` | `2` | `false` |  | `1` | `recordName` | `0` | `Site` | `2` | `1` | `false` | `_` |  |
| `sample_id` | `SampleID` | `2` | `false` |  | `1` | `recordName` | `0` | `Site` | `3` | `2` | `false` | `_` |  |

例如：

| 输入列 `recordName` | 输入列 `Site` | 命中的映射 | 最终取值 |
| --- | --- | --- | --- |
| `S001_T0_3` | `2` | `Match Value = 2 -> Mapped Split Position = 1` | `T0` |

那么程序会优先命中：

- `Site = 2`
- 对应使用 `Mapped Split Position = 1`
- 所以最后取 `recordName` 按 `_` 切分后的第 `1` 段，也就是 `T0`

<a id="column-header-levels-sheet"></a>
## 5. `column_header_levels` Sheet

### 5.1 作用

这一页定义结果横向表头的层级名字和顺序。

例如可以定义为：

- `Chain Name`
- `Test Type`
- `Repeat Index`

程序不会再从原始 `column_name` 自动猜层级值，而是依赖这里和 `analysis_groups` 中的明确配置。

### 5.2 字段说明

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `Name` | `column_header_levels[*].name` |
| `Priority` | `column_header_levels[*].priority` |

- `Name`
  - 作用：
    - 定义一个横向表头层级的名称。
  - 可选值：
    - 任意非空字符串。
  - 示例：
    - `Chain Name`
    - `Test Type`
    - `Repeat Index`

- `Priority`
  - 作用：
    - 定义层级顺序。
  - 可选值：
    - 正整数。
  - 详细说明：
    - 数字越小，层级越靠前。
    - `outlier_test_merge_max_level` 会依赖这组顺序。

### 5.3 典型层级示例

| 层级 | 示例 | 说明 |
| --- | --- | --- |
| Level 1 | `Chain Name` | 顶层链路或大类 |
| Level 2 | `Test Type` | 中层测试类型 |
| Level 3 | `Repeat Index` | 最底层重复编号 |

<a id="analysis-groups-sheet"></a>
## 6. `analysis_groups` Sheet

### 6.1 作用

`analysis_groups` 是整个模板的核心页。

它决定：

- 每个 raw test column 属于哪个逻辑 group
- 这些列在报表里如何形成横向层级
- golden / zscore 统计是按组一起算，还是按列分开算
- 组级 built golden 规则是什么

### 6.2 一行代表什么

在 Excel 模板里：

- 一行表示一个 raw column
- 同一个 group 的多列会使用相同的 `ID`

所以这也是长表模式。

### 6.3 字段说明

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `ID` | `analysis_groups[*].id` |
| `Display Name` | `analysis_groups[*].display_name` |
| `Analysis Mode` | `analysis_groups[*].analysis_mode` |
| `Unit` | `analysis_groups[*].unit` |
| `Outlier Golden Method` | `analysis_groups[*].outlier_golden_method` |
| `Golden Relative Limit` | `analysis_groups[*].golden_relative_limit` |
| `Golden Sigma Multiplier` | `analysis_groups[*].golden_sigma_multiplier` |
| `Golden Lower Bound` | `analysis_groups[*].golden_absolute_lower_bound` |
| `Golden Upper Bound` | `analysis_groups[*].golden_absolute_upper_bound` |
| `Golden Overwrite Lower Bound` | `analysis_groups[*].golden_overwrite_lowerbound` |
| `Golden Overwrite Upper Bound` | `analysis_groups[*].golden_overwrite_upperbound` |
| `Golden Continuous Interval` | `analysis_groups[*].golden_continuous_interval` |
| `Column Order` | `analysis_groups[*].columns[*].column_order` |
| `Column Name` | `analysis_groups[*].columns[*].name` |
| `<column_header_levels.Name>` | `analysis_groups[*].columns[*].header_values[*]` |

- `ID`
  - 作用：
    - 作为一组测试列的逻辑分组标识。
  - 可选值：
    - 非空字符串。
  - 详细说明：
    - 如果这些列应该一起参与 golden / zscore 相关计算，就使用同一个 `ID`。
    - 如果这些列不应该一起计算，就不要复用同一个 `ID`。
  - 示例：
    - `link1_resistance`

- `Display Name`
  - 作用：
    - 定义这组测试在报表中的显示名称。
  - 可选值：
    - 任意字符串，或留空。
  - 详细说明：
    - 如果省略，通常会退回使用 `ID`。
  - 示例：
    - `Link1 Resistance`

- `Analysis Mode`
  - 作用：
    - 定义组内多列是合并分析，还是逐列分析。
  - 可选值：
    - `pooled_columns`
    - `per_column`

各可选项含义：

- `pooled_columns`
  - 同一个 `ID` 下的列会一起参与 golden 和 zscore 计算。
  - 更适合同条件重复测量、同质测点。

- `per_column`
  - 同一个 `ID` 下的列不会在 golden 和 zscore 里合并。
  - 每个 raw column 各自单独计算。
  - 但它们仍然共享这一组的 group 级规则配置。

- `Unit`
  - 作用：
    - 定义该组默认单位。
  - 可选值：
    - 任意字符串或留空。
  - 详细说明：
    - 结果报表只使用 template 里定义的单位。
    - 如果留空，通常就按空值保留，不再从输入表猜单位。

- `Outlier Golden Method`
  - 作用：
    - 定义该 analysis group 自己的 built golden 判定方法。
  - 可选值：
    - 合法 golden rule 表达式，或留空。
  - 详细说明：
    - 如果这里显式定义，就不会再读取 GUI / `golden_reference_defaults` 的全局默认。

- `Golden Relative Limit`
  - 作用：
    - 为 group 级 golden 规则提供 `relative` 参数。
  - 可选值：
    - 数字或留空。
  - 规则：
    - 当 `Outlier Golden Method` 用到 `relative` 时必须显式定义。

- `Golden Sigma Multiplier`
  - 作用：
    - 为 group 级 golden 规则提供 `sigma` 参数。
  - 可选值：
    - 数字或留空。
  - 规则：
    - 当 `Outlier Golden Method` 用到 `sigma` 时必须显式定义。

- `Golden Lower Bound` / `Golden Upper Bound`
  - 作用：
    - 为 group 级 golden 规则提供 `absolute` 上下界。
  - 可选值：
    - 数字或留空。
  - 规则：
    - 当 `Outlier Golden Method` 用到 `absolute` 时必须显式定义。

- `Column Order`
  - 作用：
    - 保留 group 内 raw column 的原始顺序。
  - 可选值：
    - 正整数。

- `Column Name`
  - 作用：
    - 指定该行对应的原始测试列名。
  - 可选值：
    - 输入表中真实存在的测试列列名。
  - 示例：
    - `R_Link1_1V_1`

- `<column_header_levels.Name>`
  - 作用：
    - 为当前 raw column 填写每一层横向表头值。
  - 可选值：
    - 任意非空字符串，但必须与业务分组一致。
  - 示例：
    - `Chain Name = Link1`
    - `Test Type = Resistance`
    - `Repeat Index = 1`

### 6.4 同一个 `ID` 下哪些字段应该一致

同一个 `ID` 的多行里，以下字段属于“共享字段”：

- `Display Name`
- `Analysis Mode`
- `Unit`
- `Outlier Golden Method`
- `Golden Relative Limit`
- `Golden Sigma Multiplier`
- `Golden Lower Bound`
- `Golden Upper Bound`

设计意图：

- 同一个 `ID` 表示同一个逻辑 group
- 同一个逻辑 group 的这些共享属性应该保持一致

如果同一个 `ID` 的多行写出了不同共享值：

- 默认严格模式下，`validate-template` 和 `build-golden` 会要求先修正模板
- 如果明确使用兼容策略，程序可能会按“第一个非空值”处理

### 6.5 典型示例

下面示例展示一个 `ID = link1_resistance` 的 group，包含 3 个原始测试列，并且这 3 行共享同一套 group 级规则：

| `ID` | `Display Name` | `Analysis Mode` | `Unit` | `Outlier Golden Method` | `Golden Relative Limit` | `Golden Sigma Multiplier` | `Golden Lower Bound` | `Golden Upper Bound` | `Column Order` | `Column Name` | `Chain Name` | `Test Type` | `Repeat Index` |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `link1_resistance` | `Link1 Resistance` | `pooled_columns` | `Ohm` | `relative or (sigma and absolute)` | `0.20` | `3` | `80` | `120` | `1` | `R_Link1_1V_1` | `Link1` | `Resistance` | `1` |
| `link1_resistance` | `Link1 Resistance` | `pooled_columns` | `Ohm` | `relative or (sigma and absolute)` | `0.20` | `3` | `80` | `120` | `2` | `R_Link1__1V_2` | `Link1` | `Resistance` | `2` |
| `link1_resistance` | `Link1 Resistance` | `pooled_columns` | `Ohm` | `relative or (sigma and absolute)` | `0.20` | `3` | `80` | `120` | `3` | `R_Link1_1V_3` | `Link1` | `Resistance` | `3` |

<a id="node-orders-sheet"></a>
## 7. `node_orders` Sheet

### 7.1 作用

`node_orders` 用来定义 node 的先后顺序。

它会影响：

- 报表行排序
- outlier 的先后判断
- `Outlier Summary` 里 `New / Existed / Recovered` 的判定

### 7.2 一行代表什么

- 一行表示一条 node sequence
- 一个 node 占一个单元格

表头形式通常是：

- `Sequence Name`
- `Node 1`
- `Node 2`
- `Node 3`
- ...

### 7.3 字段说明

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `Sequence Name` | `node_orders[*].name` |
| `Node 1..N` | `node_orders[*].sequence[*]` |

- `Sequence Name`
  - 作用：
    - 给这条 sequence 起一个便于阅读的名字。
  - 可选值：
    - 任意字符串。

- `Node 1..N`
  - 作用：
    - 依次填写该 sequence 中的 node 顺序。
  - 可选值：
    - 任意 node 名称。
  - 示例：
    - `T0`
    - `T1`
    - `HTOL_168H`

### 7.4 `New / Existed / Recovered` 与 node 顺序的关系

程序会按每个 sample 实际出现的 node 集合，自动匹配最合适的顺序。

`Outlier Summary` 中这些状态的理解如下：

- `New`
  - 当前节点最终判定为 `fail`
  - 且所有更早的已存在前驱节点里，这一条 test group 都没有 fail 过

- `Existed`
  - 当前节点最终判定为 `fail`
  - 且任意一个更早的已存在前驱节点里，这一条 test group 已经 fail 过

- `Recovered`
  - 当前节点最终判定为 `pass`
  - 且最近一个有数据的前驱节点，这一条 test group 是 `fail`

### 7.5 校验规则

- 每条 sequence 不能为空
- 同一条 sequence 内部不能有重复 node
- 多条 sequence 之间，公共节点的相对顺序不能冲突

<a id="analysis-dimension-filters-sheet"></a>
## 8. `analysis_dimension_filters` Sheet

### 8.1 作用

这是分析开始前就直接生效的输入数据过滤。

它不是 `outlier_ratio_stats` 那种统计阶段过滤，而是在分析刚开始时就先筛掉 measurement。

### 8.2 表头结构

| 列名 | 作用 |
| --- | --- |
| `Mode` | 包含或排除 |
| `Dimension` | 过滤的是哪个维度 |
| `Value Order` | 同一字段下的值顺序 |
| `Value` | 过滤值本身 |

### 8.3 支持的字段

根据原版 help，这里支持的 `Dimension` 只有：

- `sample_key`
- `reliability_node`

### 8.4 字段说明

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `Mode` | `report.analysis_dimension_filters.include` / `report.analysis_dimension_filters.exclude` |
| `Dimension` | `report.analysis_dimension_filters.<mode>.<dimension>` |
| `Value Order` | `report.analysis_dimension_filters.<mode>.<dimension>[*]` 的数组顺序 |
| `Value` | `report.analysis_dimension_filters.<mode>.<dimension>[*]` |

- `Mode`
  - 作用：
    - 定义这是白名单过滤还是黑名单过滤。
  - 可选值：
    - `include`
    - `exclude`

各可选项含义：

- `include`
  - 只保留命中的值。

- `exclude`
  - 去掉命中的值。

- `Dimension`
  - 作用：
    - 指定过滤针对哪个维度。
  - 可选值：
    - `sample_key`
    - `reliability_node`

各可选项含义：

- `sample_key`
  - 使用 GUI `Sample Keys / Exclude Sample Keys` 同款写法。
  - 适合按样品主键范围精确筛选。

- `reliability_node`
  - 直接写 node 名称。
  - 适合按阶段筛选。

- `Value Order`
  - 作用：
    - 定义同一字段下多个值的顺序。
  - 可选值：
    - 正整数。

- `Value`
  - 作用：
    - 实际过滤值。
  - 示例：
    - `LOT1:S1,S2,S3`
    - `T0`

### 8.5 典型示例

```text
include | sample_key       | 1 | LOT1:S1,S2,S3,S4,3
include | sample_key       | 2 | LOT2:3
include | reliability_node | 1 | Node1
include | reliability_node | 2 | Node2
exclude | sample_key       | 1 | LOTX:S999
```

<a id="analysis-column-filters-sheet"></a>
## 9. `analysis_column_filters` Sheet

### 9.1 作用

这也是分析开始前的过滤，但它过滤的是测试列，而不是样品行。

它对应 GUI `Analyze` 页里的：

- `Tests`
- `Exclude Tests`

### 9.2 表头结构

| 列名 | 作用 |
| --- | --- |
| `Mode` | 包含或排除 |
| `Field` | 按哪个字段过滤 |
| `Value Order` | 同字段下的值顺序 |
| `Value` | 过滤值本身 |

### 9.3 支持的字段

根据原版 help，这里的字段来自：

- `column_header_levels`
- `analysis_groups` 里的：
  - `id`
  - `display_name`
  - `raw_column(column_name)`
  - `unit`

常见字段示例：

- `Chain Name`
- `Test Type`
- `Repeat Index`
- `id`
- `display_name`
- `column_name`
- `unit`

### 9.4 字段说明

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `Mode` | `report.analysis_column_filters.include` / `report.analysis_column_filters.exclude` |
| `Field` | `report.analysis_column_filters.<mode>.<field>` |
| `Value Order` | `report.analysis_column_filters.<mode>.<field>[*]` 的数组顺序 |
| `Value` | `report.analysis_column_filters.<mode>.<field>[*]` |

- `Mode`
  - 作用：
    - 定义保留命中项还是排除命中项。
  - 可选值：
    - `include`
    - `exclude`

- `Field`
  - 作用：
    - 指定过滤依据是哪一个测试属性。
  - 可选值：
    - 来自 `column_header_levels` 的层级名
    - 或 `analysis_groups` 元数据字段

- `Value Order`
  - 作用：
    - 定义多个过滤值的显示顺序。
  - 可选值：
    - 正整数

- `Value`
  - 作用：
    - 实际命中的字段值。
  - 规则：
    - 必须来自模板里已经定义过的值

### 9.5 典型示例

```text
include | Chain Name | 1 | Chain1
include | Chain Name | 2 | Chain2
include | Test Type  | 1 | TestType1
include | Test Type  | 2 | TestType2
exclude | id         | 1 | TestType2_Chain2_1
```

<a id="outlier-ratio-stats-sheet"></a>
## 10. `outlier_ratio_stats` Sheet

### 10.1 作用

这一页定义 `Outlier Summary` 里的比例统计区域。

它不是决定 fail 的规则，而是决定：

- 按什么维度分组做统计
- 分子统计什么
- 是否只看某一条链、某一个 group、某一个原始列

### 10.2 一行代表什么

- 一行表示一个 ratio filter 项
- 同一个统计项可以占多行
- 多行会通过相同的 `ID` 聚合成同一个统计配置

### 10.3 表头结构

| 列名 | 作用 |
| --- | --- |
| `ID` | 统计项标识 |
| `Display Name` | 统计项显示名 |
| `Group By Dimension` | 按哪些 row 维度分组 |
| `Numerator` | 分子统计规则 |
| `Filter Type` | 过滤条件类型 |
| `Filter Order` | 过滤条件顺序 |
| `Filter Value` | 过滤条件值 |

### 10.4 字段说明

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `ID` | `report.outlier_ratio_stats[*].id` |
| `Display Name` | `report.outlier_ratio_stats[*].display_name` |
| `Group By Dimension` | `report.outlier_ratio_stats[*].group_by_dimension` / `report.outlier_ratio_stats[*].group_by_dimensions` |
| `Numerator` | `report.outlier_ratio_stats[*].numerator` |
| `Filter Type` | `report.outlier_ratio_stats[*]` 中的 `group_ids / group_display_names / test_types / chain_names / column_names / units` 之一 |
| `Filter Order` | 对应 filter 数组里的顺序 |
| `Filter Value` | 对应 filter 数组里的元素值 |

- `ID`
  - 作用：
    - 标识一个 ratio 统计项。
  - 可选值：
    - 非空字符串。
  - 示例：
    - `new_ratio_by_node_all`

- `Display Name`
  - 作用：
    - 定义该统计项在报表里的标题。
  - 可选值：
    - 任意字符串，或留空。

- `Group By Dimension`
  - 作用：
    - 定义统计时按哪些 row 维度分组。
  - 可选值：
    - 一个或多个已存在的 `row_dimensions.name`，多个值用 `;` 分隔。
  - 示例：
    - `reliability_node`
    - `reliability_node;lot_id`

- `Numerator`
  - 作用：
    - 定义分子统计什么。
  - 可选值：
    - `new_outlier_samples`
    - `outlier_samples`

各可选项含义：

- `new_outlier_samples`
  - 统计“新增失效样品”数量。
  - 常用于看每个 node 的新失效比例。

- `outlier_samples`
  - 统计“失效样品”总量。
  - 不区分是新增还是已存在。

- `Filter Type`
  - 作用：
    - 定义过滤器是按什么字段筛选。
  - 可选值：
    - `id`
    - `display_name`
    - `test_type`
    - `chain_name`
    - `column_name`
    - `unit`
    - `chain`
    - `raw_column`

各可选项含义：

- `id`
  - 按 analysis group id 过滤。

- `display_name`
  - 按 analysis group 显示名过滤。

- `test_type`
  - 按测试类型过滤。

- `chain_name`
  - 按链路名过滤。

- `column_name`
  - 按 raw column 过滤。

- `unit`
  - 按单位过滤。

- `chain`
  - `chain_name` 的兼容别名。

- `raw_column`
  - `column_name` 的兼容别名。

- `Filter Order`
  - 作用：
    - 定义同一统计项下多条 filter 的顺序。
  - 可选值：
    - 正整数。

- `Filter Value`
  - 作用：
    - 对应 filter 的具体值。
  - 可选值：
    - 任意已定义值，或留空。

- 同一个 `ID` 下的 filter 组合规则：
  - 同一个 `Filter Type` 下多个 `Filter Value` 是 `OR`
  - 例如两行 `test_type=A` 和 `test_type=B`，表示 `test_type=A or B`
  - 不同 `Filter Type` 之间是 `AND`
  - 例如 `test_type=Voltage` 且 `chain_name=Link4`
  - Excel 长表里如果要表达一个 key 对多个值，请写成多行
  - 当前不是在一个 `Filter Value` 单元格里写 `A,B`

### 10.5 典型示例

下面的示例都按同一套列顺序展开：

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |

示例 1：不加任何 filter，只统计每个 node 的新增 outlier 比例

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |
| `new_ratio_by_node_all` | `New Outlier Ratio By Node` | `reliability_node` | `new_outlier_samples` |  | `1` |  |

示例 2：只统计某一条 chain 的总 outlier 比例

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |
| `total_ratio_by_node_link4` | `Total Outlier Ratio By Node (Link4)` | `reliability_node` | `outlier_samples` | `chain_name` | `1` | `Link4` |

示例 3：只统计某一个原始测试列的总 outlier 比例

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |
| `total_ratio_by_node_v_link1_1p8v` | `Total Outlier Ratio By Node (V_Link1_1p8V)` | `reliability_node` | `outlier_samples` | `column_name` | `1` | `V_Link1_1p8V` |

示例 4：同一个统计项叠加多条 filter

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |
| `link4_voltage_v_ratio` | `Link4 Voltage Ratio` | `reliability_node` | `outlier_samples` | `id` | `1` | `link4_voltage` |
| `link4_voltage_v_ratio` | `Link4 Voltage Ratio` | `reliability_node` | `outlier_samples` | `display_name` | `2` | `Link4 Voltage` |
| `link4_voltage_v_ratio` | `Link4 Voltage Ratio` | `reliability_node` | `outlier_samples` | `test_type` | `3` | `V` |
| `link4_voltage_v_ratio` | `Link4 Voltage Ratio` | `reliability_node` | `outlier_samples` | `unit` | `4` | `V` |

这组写法表示：

- 4 行会按相同的 `ID` 聚合成同一个统计项
- 这个统计项既要求命中 `id=link4_voltage`
- 也要求命中 `display_name=Link4 Voltage`
- 同时还要求 `test_type=V`、`unit=V`

示例 4.1：同一个 `Filter Type` 写多个值，表示 `OR`

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |
| `ab_ratio` | `A Or B Ratio` | `reliability_node` | `outlier_samples` | `test_type` | `1` | `A` |
| `ab_ratio` | `A Or B Ratio` | `reliability_node` | `outlier_samples` | `test_type` | `2` | `B` |

这组写法表示：

- `test_type=A or B`
- 不是 `A and B`

示例 5：按多个 row 维度联合分组

| `ID` | `Display Name` | `Group By Dimension` | `Numerator` | `Filter Type` | `Filter Order` | `Filter Value` |
| --- | --- | --- | --- | --- | --- | --- |
| `new_ratio_by_node_and_lot` | `New Outlier Ratio By Node And Lot` | `reliability_node;lot_id` | `new_outlier_samples` |  | `1` |  |

### 10.6 使用限制

- 如果一个统计项没有任何 filter，也可以只留一行基础配置，把 `Filter Type / Filter Value` 留空
- `Group By Dimension` 里写的每个维度都必须已经存在于 `row_dimensions`
- 如果模板存在 `reliability_node`，那么 `Group By Dimension` 只能使用 `reliability_node` 以及更高优先级的 row 维度

## 11. `README` Sheet

### 11.1 作用

`README` 是模板自带说明页。

它的作用是：

- 给维护者写业务说明
- 记录模板版本信息
- 写字段命名约定
- 写风险提示

### 11.2 注意

- 这一页不参与解析
- 改它不会改变计算逻辑
- 但很适合放团队内部约定

## 12. Excel 与 JSON 的关系

Excel 模板为了方便人工编辑，很多地方会“展开”成长表。

| Excel 结构 | JSON 结构 | 说明 |
| --- | --- | --- |
| `row_dimensions` 一行一个 source | `row_dimensions[*].sources[*]` | Excel 中按 source 展开 |
| `analysis_groups` 一行一个 raw column | `analysis_groups[*].columns[*]` | 同一 `ID` 的多行会聚合成一个 group |
| `node_orders` 一行一条 sequence | `report.node_orders[*]` | 一个节点占一个单元格 |
| `analysis_dimension_filters` 一行一个值 | `report.analysis_dimension_filters` | include/exclude 按长表存储 |
| `analysis_column_filters` 一行一个值 | `report.analysis_column_filters` | include/exclude 按长表存储 |
| `outlier_ratio_stats` 一行一个 filter | `report.outlier_ratio_stats[*]` | 同一 `ID` 的多行会聚合 |

## 13. 主要校验规则

程序会自动校验以下内容：

- `row_dimension.name` 不能重复
- `test_data_start_row` 必须显式定义，不能依赖程序自动推断
- 每个 `row_dimension` 必须至少有一个 source
- 每个 source 必须有 `column`
- 如果 source 使用了任意 split 逻辑，就必须同时有 `split_delimiters`
- 如果 source 配了 `split_position_by_column`，必须同时有 `split_position_map`
- 如果 source 配了 `split_position_map`，必须同时有 `split_position_by_column`
- `split_position_map` 里的位置值不能是负数
- `analysis_group.analysis_mode` 只能是：
  - `pooled_columns`
  - `per_column`
- 同一个 raw column 不能出现在多个 `analysis_groups`
- `report.outlier_fail_method` 只能是：
  - `modified_z_score`
  - `golden_deviation`
  - `zscore_and_golden`
  - `zscore_or_golden`
- 四个 fail rule 都只能是：
  - `any_fail`
  - `all_fail`
- `report.outlier_row_merge_max_dimension` 必须是已存在的 `row_dimensions.name`
- `report.outlier_test_merge_max_level` 必须是已存在的 `column_header_levels.name`
- `report.outlier_merge_order` 必须是 6 种合法执行顺序之一
- `report.outlier_ratio_stats[*].numerator` 只能是：
  - `new_outlier_samples`
  - `outlier_samples`
- `report.outlier_ratio_stats[*].group_by_dimension` 必须是已存在的 `row_dimensions.name`
- 如果存在 `reliability_node`，那么 `report.outlier_row_merge_max_dimension` 必须低于 `reliability_node`
- `node_orders` 中每条 sequence 不能为空
- 每条 node sequence 内部不能有重复 node
- 多条 node sequence 之间不能出现公共节点的反向顺序冲突

## 14. 推荐做法

- `row_dimensions`
  - 尽量把一个维度的提取规则写清楚
  - 能直接取整列就不要无必要增加复杂 split

- `analysis_groups`
  - `ID` 建议使用稳定、短、可读的业务名
  - 同一个 `ID` 的共享字段尽量保持完全一致

- `node_orders`
  - 如果业务里确实有多种 node 路径，优先写 `node_orders`
  - 公共节点的相对顺序必须保持一致

- `outlier_ratio_stats`
  - 如果只是想看每个 node 的新增失效比例，可以先从：
    - `group_by_dimension = reliability_node`
    - `numerator = new_outlier_samples`
    开始

- `analysis_dimension_filters` / `analysis_column_filters`
  - 推荐只放最常复用的默认分析范围
  - 临时性的筛选更适合在 GUI 的 `Analyze` 页里改

## 15. Command Reference

校验 template：

```bash
./.venv/bin/python -m excel_data_analysis.cli_main validate-template --input examples/chip_reliability_template.xlsx
./.venv/bin/python -m excel_data_analysis.cli_main validate-template --input examples/chip_reliability_template.json
```

模板互转：

```bash
./.venv/bin/python -m excel_data_analysis.cli_main template-to-json \
  --input examples/chip_reliability_template.xlsx \
  --output /tmp/chip_reliability_template.json

./.venv/bin/python -m excel_data_analysis.cli_main template-to-xlsx \
  --input examples/chip_reliability_template.json \
  --output /tmp/chip_reliability_template.xlsx
```
