# Analyze 快照：共享数据与分块存储

Analyze 新结果使用 `analyze-snapshot-v2`，仍放在 `result/analysis/<result-id>.json.gz`。
文件内容是 gzip 压缩的逐行 JSON 记录；v1 是单份 JSON 文档。GUI 引用保留真实版本。
新版继续读取 v1，旧应用不能读取 v2。已有数据库不会因打开或 Save Database 被自动改写成 v2；新 Analyze 使用新格式。

## 内存与文件去重

- 密集 Golden 结果使用 `PackedGoldenMap`。每点保存值、展示值、规则索引、状态和插入顺序；阈值、Golden 值、上下界、允许区间和显示格式在规则表中只保存一次。
- 普通逐点数值采用 float64；整数、Decimal、字符串及其他原有受支持类型保存在精确旁表中，None 使用独立标志。保留符号零、非有限数、缺失点及重复键的最后值/首次插入顺序。
- Golden 覆盖范围按真实规则匹配。稀疏范围继续使用字典，避免分配很大的行列笛卡尔积；Columnar 预检只匹配实际存在的行列组合，并使用有界缓存。
- 来源路径、数据集 ID、列名顺序、维度名顺序及缺失列定义使用共享表。每行保存索引及自己的数值，恢复后的可变行字典保持独立。
- `merged_outlier_rows` 中与最终状态完全一致的行保存引用；`summary_rows` 的标准精确投影也保存引用。差异行、独立原始异常记录和未知字段继续保留。
- 相同类型且逐字节相同的数值数组只写一次。读取恢复独立数组，避免后续修改互相影响。比较不会把正零和负零合并。
- 显示阈值和范围按列/规则计算，避免为相同规则的每个点重复创建对象和格式化文本。点级属性仍逐点处理。

去重不会合并真实测量记录，也不会改变节点身份、数据点个数或统计权重。

## 分块与失败行为

列表及映射最多 512 条一个记录块，数值数组最多 65,536 项一个块。读写不再建立完整序列化对象树。
单个超宽行或单项元数据仍需完整编码；块数限制不是固定字节上限。数组使用明确的小端格式。

保存到同目录临时文件，在 gzip 关闭、flush/fsync 成功后原子替换目标。写入失败保留旧文件并清理临时文件。
GUI 打开 v1/v2 时只恢复模板、节点等元信息，以 64 KiB 缓冲扫描文件，不再构造 Golden 指标、数值数组和完整测量行。旧版单行大 JSON 在缓冲内使用原生 JSON 解码器处理小对象，跨缓冲部分才按结构扫描；仍检查 JSON 语法和 gzip CRC。未使用的指标类型与数值语义留到实际导出时校验。

导出直接从文件流读取，不先把完整压缩文件读到内存。旧 v1 的**完整导出读取**仍使用完整 JSON 解析，仍可能产生较高峰值；本次打开优化不等同于把所有旧文件操作改成常量内存。

会话私有 pickle 和精简 TSK 输入目前保留，供现有导出与 TSK 工作流使用；本次没有取消这些用途不同的文件。

## 旧库打开与 TSK 去重

- TSK Analyze 输入在打开时只恢复模板和节点，保留压缩文件，运行 TSK 时才读取完整链路状态。
- TSK 展示结果解码后直接接管已解析对象，避免再次深拷贝；通过 gzip 文本流解析，不让完整解压字节缓冲与解析对象长期同时驻留。标准库 JSON 解析仍会临时建立完整字符串，拟合矩阵仍完整恢复。
- 旧库中当前 TSK 结果和 active history 的编码内容（包括拟合快照）完全一致时只解码一次。其他历史运行独立恢复，不把不同运行合并成同一个可变对象。
- 新保存的当前/live 结果若与 active history 相同，使用 `tsk-history-result-ref-v1` 引用该历史正文，不再重复编码和写入。展示值、拟合精度、历史条目和删组分析输入均保留；不相同的内容仍独立保存。
- 如果旧库缺少专用 TSK 输入文件，打开时不补建；首次显式运行、发现批次或请求模式缓存时才从完整 Analyze 结果生成，保持原来的文件哈希/历史缓存标识。这种首次操作仍有 v1 完整读取开销。原有 TSK 输入文件存在时直接沿用原始字节。
- 打开/普通保存不会把旧 Analyze v1 文件自动重写成 v2，也不会修改原分析值。新引用格式应使用更新后的程序读取。

## 可复现基准

```sh
.venv/bin/python scripts/benchmark_analysis_snapshot.py --counts 100000 300000
```

Windows 使用环境中的 Python 调用同一脚本即可。macOS/Linux 使用 `resource`，Windows 使用 `GetProcessMemoryInfo` 的峰值工作集；Windows 分支尚未现场验证。

结果位于 `outputs/analyze-snapshot-performance_2026-10-12/summary.json`。保存和加载分别在独立进程中测量；逐字段 SHA-256 验证、解压体积统计和查找测试不计入持久化耗时/峰值。对比使用 200 列、200 个共享单区间 Golden 规则的合成数据，汇总表较小；它不代表整个 Analyze 或用户的 Win11 数据集。

本机 macOS/Python 3.10、300,000 点结果（MB 为十进制，内存为进程峰值）：

| 指标 | v1 | v2 |
|---|---:|---:|
| 保存耗时 | 12.335 s | 0.901 s |
| 保存峰值内存 | 730.1 MB | 133.3 MB |
| 加载耗时 | 6.623 s | 0.364 s |
| 加载峰值内存 | 1260.9 MB | 114.6 MB |
| gzip 文件 | 15.54 MB | 7.10 MB |
| 解压后的内容 | 147.60 MB | 24.28 MB |

两种表示及恢复结果的全部字段/逐点语义哈希一致。精确类型、Excel 内容/格式、旧存档、损坏数据和原子失败行为另由回归测试覆盖。

紧凑存储有 CPU 取舍：单点 `get()` 会按需重建 `MetricValue` 和独立区间对象。上述 300,000 点完整查找遍历约从 0.035 s 变为 0.572 s。因此不能声称每个分析/导出阶段都更快；重复规则的展示汇总已增加单独优化，完整 Windows 工作流仍需真实数据验证。

### 2026-10-13：旧存档打开基准

```sh
.venv/bin/python scripts/benchmark_snapshot_metadata.py outputs/analyze-snapshot-performance_2026-10-12/legacy-300000.json.gz outputs/analyze-snapshot-performance_2026-10-12/current-300000.json.gz --output outputs/database-open-memory_2026-10-13/analysis-metadata-benchmark.json
.venv/bin/python scripts/benchmark_tsk_result_restore.py --chains 100000
.venv/bin/python scripts/benchmark_tsk_gui_restore.py --chains 100000
```

同样使用独立子进程、macOS/Python 3.10；MiB 为 1024² 字节，内存含解释器/模块基线。

| 阶段和合成输入 | 原读取 | 优化后读取同一旧文件 |
|---|---:|---:|
| Analyze v1，300,000 点：时间 | 6.665 s | 2.110 s |
| Analyze v1，300,000 点：峰值 | 1,208.2 MiB | 46.8 MiB |
| TSK，100,000 链 × 5 列拟合矩阵，当前 + active history：时间 | 3.014 s | 0.561 s |
| 同上 TSK：峰值 | 583.9 MiB | 303.5 MiB |

TSK 新引用文件在该单历史示例中从 8.85 MB 降至 4.42 MB，保存从 3.246 s 降至 1.670 s。历史越多，当前一份重复正文占总文件的比例越小，不能一概承诺文件减半。

Analyze 恢复元信息哈希一致；TSK 全部展示与拟合字段哈希一致。报告在 `outputs/database-open-memory_2026-10-13/` 和 `outputs/tsk-open-memory_2026-10-13/`。这些结果不包含 Qt、数据库工作区及其他常驻对象，不能将这些降幅直接套用到用户 Win11 的 19 GB 整体峰值。
