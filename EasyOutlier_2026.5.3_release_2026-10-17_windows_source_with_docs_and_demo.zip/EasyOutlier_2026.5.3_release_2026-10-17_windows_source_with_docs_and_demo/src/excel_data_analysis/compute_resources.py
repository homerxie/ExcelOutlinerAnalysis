"""Shared process ceilings, independent of GUI settings and task scheduling.

Zero preserves each task's existing automatic strategy. A positive ceiling
limits that task's process workers; it is neither CPU affinity nor a shared
quota across independent tasks. The GUI freezes this value when dispatching
work, and subprocess entry points install their own frozen value.
"""

from functools import lru_cache
from numbers import Integral
import os
from pathlib import Path
import struct
import subprocess
import sys


SETTINGS_KEY = "compute/max_process_workers"
_PROCESS_LIMIT = 0


def validate_process_limit(value):
    if isinstance(value, bool) or not isinstance(value, Integral) or not 0 <= value <= 64:
        raise ValueError("Process limit must be an integer between 0 and 64 (0 means automatic).")
    return int(value)


def set_process_limit(value):
    global _PROCESS_LIMIT
    _PROCESS_LIMIT = validate_process_limit(value)
    _analysis_cpu_topology.cache_clear()


def get_process_limit():
    return _PROCESS_LIMIT


def limit_process_workers(count):
    count = max(1, int(count))
    return min(count, _PROCESS_LIMIT) if _PROCESS_LIMIT else count


def available_process_limit():
    return max(1, min(os.cpu_count() or 1, 61 if os.name == "nt" else 64))


def _positive_count(value):
    return int(value) if isinstance(value, Integral) and not isinstance(value, bool) and value > 0 else None


def _cpu_list(text):
    """Parse the Linux CPU-list format, preserving non-contiguous CPU IDs."""
    result = set()
    for item in text.strip().split(","):
        bounds = item.split("-")
        if len(bounds) not in (1, 2):
            raise ValueError("Invalid CPU list")
        start, end = int(bounds[0]), int(bounds[-1])
        if start < 0 or end < start or end > 1048576:
            raise ValueError("Invalid CPU list range")
        result.update(range(start, end + 1))
    if not result:
        raise ValueError("Empty CPU list")
    return result


def _linux_physical_count(cpus):
    root = Path("/sys/devices/system/cpu")
    core_ids = {}
    try:
        for cpu in cpus:
            topology = root / f"cpu{cpu}/topology"
            package = int((topology / "physical_package_id").read_text())
            core = int((topology / "core_id").read_text())
            # Linux's unknown-topology defaults are package=-1, core=0 and
            # singleton thread_siblings. Those do not establish physical cores.
            if package < 0 or core < 0:
                return None, "unknown"
            try:
                die = int((topology / "die_id").read_text())
            except OSError:
                die = None
            core_ids[cpu] = (package, die, core)
    except (OSError, ValueError):
        return None, "unknown"
    try:
        groups = {}
        for cpu in cpus:
            siblings = frozenset(_cpu_list((root / f"cpu{cpu}/topology/thread_siblings_list").read_text()))
            if cpu not in siblings:
                raise ValueError("CPU missing from its sibling list")
            groups[cpu] = siblings
        # A partial, changing or inconsistent sysfs view must not invent cores.
        for cpu, siblings in groups.items():
            if any(groups[other] != siblings or core_ids[other] != core_ids[cpu]
                   for other in siblings.intersection(cpus)):
                return None, "unknown"
        id_groups = {}
        for cpu, siblings in groups.items():
            if core_ids[cpu] in id_groups and id_groups[core_ids[cpu]] != siblings:
                return None, "unknown"
            id_groups[core_ids[cpu]] = siblings
        return len(set(groups.values())), "linux_sysfs_thread_siblings_list"
    except (OSError, ValueError):
        return len(set(core_ids.values())), "linux_sysfs_core_ids"


def _linux_topology():
    notes = []
    try:
        online = _cpu_list(Path("/sys/devices/system/cpu/online").read_text())
    except (OSError, ValueError):
        online = None
    try:
        visible = set(os.sched_getaffinity(0))
        if not visible:
            raise ValueError("Empty CPU affinity")
        source = "os.sched_getaffinity"
        scope = "process_affinity"
    except (AttributeError, OSError, ValueError):
        visible = online
        source = "linux_sysfs_online" if online else "os.cpu_count"
        scope = "system_affinity_unknown"
        notes.append("Process CPU affinity could not be read.")
    result = {"notes": notes, "affinity_scope": scope, "logical_source": source}
    if visible:
        physical, physical_source = _linux_physical_count(visible)
        result.update(logical_cpus=len(visible), physical_cores=physical, physical_source=physical_source)
    if online:
        physical, physical_source = _linux_physical_count(online) if visible != online else (
            result.get("physical_cores"), result.get("physical_source", "unknown"))
        result.update(system_logical_cpus=len(online), system_physical_cores=physical,
                      system_physical_source=physical_source)
        if scope == "process_affinity":
            result["affinity_limited"] = visible != online
    notes.append("CPU counts describe affinity-visible topology, not a cgroup CPU-time quota.")
    return result


def _sysctl_count(name):
    try:
        output = subprocess.check_output(["/usr/sbin/sysctl", "-n", name], text=True,
                                         stderr=subprocess.DEVNULL, timeout=1.0)
        return _positive_count(int(output.strip()))
    except (OSError, ValueError, subprocess.SubprocessError):
        return None


def _mac_topology():
    physical = _sysctl_count("hw.physicalcpu")
    logical = _sysctl_count("hw.logicalcpu")
    result = {"physical_cores": physical, "system_physical_cores": physical,
              "physical_source": "sysctl_hw.physicalcpu" if physical else "unknown",
              "system_physical_source": "sysctl_hw.physicalcpu" if physical else "unknown",
              "affinity_scope": "system_active_cpus", "affinity_limited": False,
              "notes": [] if physical else ["sysctl did not provide the physical CPU count."]}
    if logical:
        result.update(logical_cpus=logical, system_logical_cpus=logical, logical_source="sysctl_hw.logicalcpu")
    return result


def _windows_core_records(data, pointer_size):
    """Read RelationProcessorCore records without assuming a fixed record size.

    Windows GROUP_AFFINITY has a pointer-sized mask, a WORD group and three
    reserved WORDs. PROCESSOR_RELATIONSHIP's GroupCount is at byte 22 and its
    GroupMask array at byte 24, following the eight-byte record header.
    """
    if pointer_size not in (4, 8):
        raise ValueError("Unsupported Windows pointer size")
    cores = []
    offset = 0
    while offset < len(data):
        if len(data) - offset < 8:
            raise ValueError("Truncated Windows topology header")
        relationship, size = struct.unpack_from("<II", data, offset)
        if size < 8 or size > len(data) - offset:
            raise ValueError("Invalid Windows topology record size")
        if relationship == 0:  # RelationProcessorCore
            if size < 32:
                raise ValueError("Truncated Windows core record")
            count = struct.unpack_from("<H", data, offset + 30)[0]
            # A physical core belongs to exactly one processor group.
            if count != 1 or size < 32 + pointer_size + 8:
                raise ValueError("Invalid Windows core group count")
            mask = int.from_bytes(data[offset + 32:offset + 32 + pointer_size], "little")
            group = struct.unpack_from("<H", data, offset + 32 + pointer_size)[0]
            if not mask:
                raise ValueError("Empty Windows core affinity")
            cores.append((group, mask))
        offset += size
    if not cores:
        raise ValueError("No Windows physical core records")
    return cores


def _windows_cpu_data():
    """Native Windows topology and the current process' primary-group mask."""
    import ctypes

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    query = kernel.GetLogicalProcessorInformationEx
    query.argtypes = (ctypes.c_int, ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32))
    query.restype = ctypes.c_int
    length = ctypes.c_uint32()
    query(0, None, ctypes.byref(length))
    if ctypes.get_last_error() != 122 or not 0 < length.value <= 16 * 1024 * 1024:
        raise OSError("Windows CPU topology size query failed")
    for _ in range(3):
        buffer = ctypes.create_string_buffer(length.value)
        if query(0, buffer, ctypes.byref(length)):
            cores = _windows_core_records(buffer.raw[:length.value], ctypes.sizeof(ctypes.c_size_t))
            break
        if ctypes.get_last_error() != 122 or not 0 < length.value <= 16 * 1024 * 1024:
            raise OSError("Windows CPU topology query failed")
    else:
        raise OSError("Windows CPU topology changed during detection")

    class GroupAffinity(ctypes.Structure):
        _fields_ = [("mask", ctypes.c_size_t), ("group", ctypes.c_uint16),
                    ("reserved", ctypes.c_uint16 * 3)]

    process_mask = ctypes.c_size_t()
    system_mask = ctypes.c_size_t()
    kernel.GetCurrentProcess.restype = ctypes.c_void_p
    kernel.GetCurrentThread.restype = ctypes.c_void_p
    affinity = kernel.GetProcessAffinityMask
    affinity.argtypes = (ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t))
    affinity.restype = ctypes.c_int
    group_affinity = kernel.GetThreadGroupAffinity
    group_affinity.argtypes = (ctypes.c_void_p, ctypes.POINTER(GroupAffinity))
    group_affinity.restype = ctypes.c_int
    group = GroupAffinity()
    if not affinity(kernel.GetCurrentProcess(), ctypes.byref(process_mask), ctypes.byref(system_mask)):
        process_mask.value = 0
    group_id = group.group if group_affinity(kernel.GetCurrentThread(), ctypes.byref(group)) else None
    return cores, group_id, process_mask.value, ctypes.sizeof(ctypes.c_size_t)


def _windows_topology():
    cores, group_id, mask, pointer_size = _windows_cpu_data()
    result = {"system_physical_cores": len(cores),
              "system_physical_source": "windows_GetLogicalProcessorInformationEx",
              "notes": []}
    groups = {}
    overlapping = False
    for group, core_mask in cores:
        overlapping |= bool(groups.get(group, 0) & core_mask)
        groups[group] = groups.get(group, 0) | core_mask
    if overlapping:
        # WOW64 can fold affinity bits 32..63 onto 0..31. Counting core
        # records is still valid, but mapping visible logical CPUs is not.
        result["notes"].append("Windows core affinity masks overlap; visible physical cores are unknown.")
        return result
    if pointer_size == 4 and (os.cpu_count() or 0) > 32:
        result["notes"].append("32-bit Windows affinity cannot reliably map all logical processors.")
        return result
    result["system_logical_cpus"] = sum(value.bit_count() for value in groups.values())
    if group_id is None and len(groups) == 1:
        group_id = next(iter(groups))
    if group_id not in groups or not mask or mask & ~groups[group_id]:
        result["notes"].append("The process' primary-group CPU affinity could not be verified.")
        return result
    result.update(logical_cpus=mask.bit_count(),
                  physical_cores=sum(bool(core_mask & mask) for group, core_mask in cores if group == group_id),
                  logical_source="windows_GetProcessAffinityMask",
                  physical_source="windows_core_records_with_process_affinity",
                  affinity_scope="process_affinity" if len(groups) == 1 else "primary_processor_group",
                  affinity_limited=mask != groups[group_id] if len(groups) == 1 else None)
    if len(groups) > 1:
        result["notes"].append("Only the verified primary processor group is budgeted; other groups are not assumed available.")
    return result


def cpu_topology():
    """Return a fresh, JSON-safe CPU topology snapshot and its evidence sources.

    ``logical_cpus`` and ``physical_cores`` refer to the verified scheduling
    scope in ``affinity_scope``. An unknown physical count stays ``None``;
    it is never inferred by dividing logical CPUs by two. ``system_*`` counts
    describe the whole machine when known. Windows processor-group ambiguity
    is reported explicitly rather than treating one group as the whole host.
    This detects CPU topology, not guaranteed throughput or CPU-time quotas.
    """
    logical = _positive_count(os.cpu_count())
    result = {"logical_cpus": logical or 1, "physical_cores": None,
              "system_logical_cpus": logical, "system_physical_cores": None,
              "logical_source": "os.cpu_count" if logical else "minimum_one_worker",
              "physical_source": "unknown", "system_physical_source": "unknown",
              "affinity_scope": "system_affinity_unknown", "affinity_limited": None,
              "platform_limit": 61 if os.name == "nt" else 64, "notes": []}
    detector = _mac_topology if sys.platform == "darwin" else (
        _windows_topology if sys.platform == "win32" else _linux_topology if sys.platform.startswith("linux") else None)
    if detector is not None:
        try:
            result.update(detector())
        except (OSError, ValueError, AttributeError):
            result["notes"].append("Native CPU topology detection was unavailable.")
    if result["physical_cores"] is not None and result["physical_cores"] > result["logical_cpus"]:
        result.update(physical_cores=None, physical_source="unknown")
        result["notes"].append("Physical and logical CPU probes disagreed; the physical count was not used.")
    result["smt_active"] = (result["logical_cpus"] > result["physical_cores"]
                            if result["physical_cores"] is not None else None)
    result["system_smt_active"] = (result["system_logical_cpus"] > result["system_physical_cores"]
                                   if result["system_logical_cpus"] is not None and
                                   result["system_physical_cores"] is not None else None)
    result["source"] = result["physical_source"] if result["physical_cores"] is not None else result["logical_source"]
    return result


def automatic_tsk_budget(topology=None, *, process_limit=None):
    """Choose a TSK-wide process budget, before splitting outer/inner work.

    Automatic mode prefers visible physical cores; unknown physical topology
    falls back to the reported logical count. A positive process setting is an
    explicit budget and may use SMT, up to visible logical CPUs and the platform
    process cap. Callers may pass a frozen ``cpu_topology()`` snapshot, avoiding
    repeated detection while scheduling one analysis. ``process_limit=0`` can
    preview automatic mode without changing the installed process setting;
    None uses that setting. Existing general worker ceiling helpers intentionally
    retain their prior behavior.
    """
    topology = cpu_topology() if topology is None else topology
    logical = _positive_count(topology.get("logical_cpus")) or 1
    physical = _positive_count(topology.get("physical_cores"))
    platform_limit = _positive_count(topology.get("platform_limit")) or (61 if os.name == "nt" else 64)
    limit = _PROCESS_LIMIT if process_limit is None else validate_process_limit(process_limit)
    preferred = limit or physical or logical
    return max(1, min(preferred, logical, platform_limit, 61 if os.name == "nt" else 64))


@lru_cache(maxsize=1)
def _analysis_cpu_topology():
    return cpu_topology()


def process_tsk_budget():
    """Reuse one analysis process's topology; apply its current ceiling each call.

    Installing the frozen process setting starts a new topology snapshot.
    Direct ``cpu_topology()`` calls, including GUI previews, remain fresh.
    Spawned processes start with an empty cache rather than inheriting a host
    snapshot from a different analysis process.
    """
    return automatic_tsk_budget(_analysis_cpu_topology())
