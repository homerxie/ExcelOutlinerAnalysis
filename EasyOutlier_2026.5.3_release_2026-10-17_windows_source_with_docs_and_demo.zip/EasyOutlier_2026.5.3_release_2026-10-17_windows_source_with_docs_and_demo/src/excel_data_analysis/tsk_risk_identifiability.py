"""Local risk evidence from the geometry of an already validated joint fit.

These checks reuse the fitted design and Chain Jacobian spaces. They do not
assert global uniqueness of a nonlinear Chain likelihood, or treat a deficient
first derivative as proof that higher-order identification is impossible.
"""
from __future__ import annotations

import numpy as np


LOCAL_SCOPE = "local first-order risk estimability and checked equivalent fits; not global uniqueness"
BOUNDARY_SCOPE = "attainable zero-face geometry and validated local reentry; not global uniqueness"
PROFILE_SCOPE = "local evidence and finite full-nuisance likelihood probes; not global uniqueness"


def risk_outcome(status, *reasons):
    return {
        "status": status,
        "identifiable": status in {"local_estimable", "boundary_supported", "profile_verified"},
        "scope": (PROFILE_SCOPE if status == "profile_verified" else
                  BOUNDARY_SCOPE if status == "boundary_supported" else LOCAL_SCOPE),
        "reason_codes": list(dict.fromkeys(reasons)),
        "profile_verified": status == "profile_verified",
    }


def _boundary_support(model):
    if model._risk_boundary_evidence is not None:
        return model._risk_boundary_evidence
    from .tsk_risk_profile import finite_shared_anchor_certificate

    core = np.asarray(model.state["core_coefficients"], dtype=float)
    ray = np.asarray(model.state["recession_direction"], dtype=float)
    reentry = model._reentry_validation(core, model._zero, ray)
    if not reentry.get("valid"):
        result = (False, "boundary_reentry_not_established")
    elif reentry.get("method") == "monotone_all_pass":
        result = (True, "monotone_all_pass_reentry")
    elif (reentry.get("flat_groups", True) or not reentry.get("groups")
          or not all(group["scaled_score"] > group["tolerance"] for group in reentry["groups"])):
        result = (False, "boundary_reentry_not_strict")
    else:
        kinds = model.design[:, :model.type_count]
        one_hot = np.all((kinds == 0) | (kinds == 1)) and np.all(kinds.sum(axis=1) == 1)
        types = np.argmax(kinds, axis=1)
        whole = one_hot and all(not np.any(model._zero[types == index])
                                or np.all(model._zero[types == index])
                                for index in range(model.type_count))
        if not whole:
            result = (False, "mixed_zero_face_requires_profile_review")
        else:
            certificate = finite_shared_anchor_certificate(
                model.design, model.chain_index, model.n, model.k, model.type_count)
            if certificate["certified"]:
                result = (True, "whole_type_zero_strict_reentry_finite_shared_anchors")
            else:
                result = (False, "finite_shared_anchors_not_established")
    model._risk_boundary_evidence = result
    return result


def geometry_risk_evidence(model, vector):
    """Return (public evidence, kind, whether finite probes can add evidence)."""
    from .tsk_logistic_joint_boundary import _contained

    if not _contained(vector / model._column_scale, model._scaled_design_basis):
        return risk_outcome("not_identifiable", "risk_changes_in_design_nullspace"), None, False
    kind = model._kind(vector)
    if kind == "unidentifiable":
        # The cone calculation cannot represent every closure as finite or
        # identically zero. Unsupported geometry is not a numerical negative.
        return risk_outcome("unresolved", "unsupported_boundary_query"), kind, False
    core = np.asarray(model.state["core_coefficients"])
    locally_supported = kind != "interior" or _contained(
        vector @ model._design_transform, model._information_basis)
    for zero, other, active_basis, information_basis in model._equivalent_geometry:
        other_kind = model._kind(vector, zero, active_basis)
        if other_kind == "unidentifiable":
            return risk_outcome("unresolved", "alternate_face_geometry_unresolved"), None, False
        if (other_kind != kind or (kind == "interior" and
                                  abs(float(vector @ (other - core))) > 1e-4)):
            return risk_outcome("not_identifiable", "observed_equivalent_fit_risk_conflict"), kind, False
        if kind == "interior" and not _contained(vector @ model._design_transform, information_basis):
            locally_supported = False
    if kind == "interior":
        if locally_supported:
            return risk_outcome("local_estimable", "design_and_chain_information_support"), kind, False
        return risk_outcome("unresolved", "local_information_deficient_higher_order_possible"), kind, True
    supported, reason = _boundary_support(model)
    return risk_outcome("boundary_supported" if supported else "unresolved", reason), kind, not supported
