"""Portable source references shared by database metadata and measurements."""
from __future__ import annotations

import os
import json
from functools import lru_cache
from pathlib import Path, PurePosixPath, PureWindowsPath


WORKSPACE_MARKER_FILENAME = ".database-workspace"
_STORAGE_DIRECTORIES = {"imports", "golden"}


def _saved_path(value: str):
    windows = PureWindowsPath(value)
    return windows if windows.is_absolute() else PurePosixPath(value.replace("\\", "/"))


def relative_internal_path(value: str, database_root: str | Path) -> str:
    """Make a known database-owned path portable, leaving external provenance alone."""
    path, root = _saved_path(value), _saved_path(str(database_root))
    if not path.is_absolute():
        return value
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        if isinstance(path, PureWindowsPath) != isinstance(Path(), PureWindowsPath):
            return value
        try:
            return Path(value).resolve().relative_to(Path(database_root).resolve()).as_posix()
        except (OSError, ValueError):
            return value


def _legacy_database_roots(database_root: Path) -> list:
    """Read only explicit old database anchors; never infer a root from a filename."""
    target = database_root / ".excel_data_analysis_gui_state.json"
    try:
        stat = target.stat()
        return _cached_legacy_database_roots(target, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)
    except OSError:
        return []


@lru_cache(maxsize=32)
def _cached_legacy_database_roots(target: Path, size: int, mtime_ns: int, ctime_ns: int) -> list:
    try:
        state = json.loads(target.read_text(encoding="utf-8"))
        snapshot = state.get("current_results", {}).get("plot_inspector_snapshot", {})
        storage = snapshot.get("context", {}).get("storage_path")
        roots = []
        if isinstance(storage, str) and _saved_path(storage).is_absolute():
            root = _saved_path(storage)
            # An old database itself may have been called temp. Its name alone
            # is not evidence that its parent owned the data.
            roots.append(root)
        for references in (snapshot.get("portable_paths"), snapshot.get("path_references")):
            if isinstance(references, dict) and isinstance(references.get("database_root"), str):
                root = _saved_path(references["database_root"])
                if root.is_absolute():
                    roots.append(root)
        # Earlier GUI settings retained both the database-relative value and
        # its original absolute fallback. Together they explicitly identify
        # the old root, including when the Summary analyzed its temp workspace.
        paths = state.get("paths", {})
        bases = state.get("path_bases", {})
        fallbacks = state.get("path_fallbacks", {})
        anchored_roots = set()
        if isinstance(paths, dict) and isinstance(bases, dict) and isinstance(fallbacks, dict):
            for key, value in paths.items():
                fallback = fallbacks.get(key)
                if bases.get(key) != "database" or not isinstance(value, str) or not isinstance(fallback, str):
                    continue
                relative, absolute = _saved_path(value), _saved_path(fallback)
                if relative.is_absolute() or ".." in relative.parts or not relative.parts or not absolute.is_absolute():
                    continue
                root = absolute
                for _ in relative.parts:
                    root = root.parent
                if root.joinpath(*relative.parts) != absolute:
                    continue
                if isinstance(storage, str) and _saved_path(storage).is_absolute():
                    if _saved_path(storage) not in (root, root / "temp"):
                        continue
                anchored_roots.add(root)
        if len(anchored_roots) == 1:
            roots.extend(anchored_roots)
        return roots
    except (OSError, ValueError, TypeError, AttributeError):
        return []


def relocate_legacy_source_path(source_file: str, database_root: Path, *, storage_root: Path | None = None) -> str:
    """Recover only a complete internal suffix anchored to a known database root."""
    path = _saved_path(source_file)
    if not path.is_absolute():
        return source_file
    def candidate_for(root, *, storage_directories_only=False):
        try:
            parts = path.relative_to(root).parts
        except ValueError:
            return None
        workspace_relative = parts[:1] == ("temp",)
        if workspace_relative:
            parts = parts[1:]
        if not parts or ".." in parts:
            return None
        if storage_directories_only and (len(parts) < 2 or parts[0] not in _STORAGE_DIRECTORIES):
            return None
        # Arbitrary files at the saved root are not cloned into temp. A
        # different same-named custom file there must not replace that source.
        bases = ((storage_root or database_root, database_root)
                 if workspace_relative or parts[0] in _STORAGE_DIRECTORIES else (database_root,))
        for base in bases:
            candidate = base.joinpath(*parts)
            if candidate.is_file():
                return str(candidate)
        return None

    current_root = _saved_path(str(database_root))
    if path.is_relative_to(current_root):
        # The common path must never parse the potentially large saved GUI
        # state, even when a source file is currently unavailable.
        return candidate_for(current_root) or source_file
    if isinstance(path, PureWindowsPath) == isinstance(Path(), PureWindowsPath):
        resolved_root = _saved_path(str(database_root.resolve()))
        if path.is_relative_to(resolved_root):
            return candidate_for(resolved_root) or source_file
    roots = _legacy_database_roots(database_root)
    for root in roots:
        candidate = candidate_for(root)
        if candidate is not None:
            return candidate
    # A folder copy commonly preserves the database folder name. Require its
    # complete internal subtree and an existing copied file, not a basename hit.
    for index, part in enumerate(path.parts[:-1]):
        if part == database_root.name:
            candidate = candidate_for(type(path)(*path.parts[:index + 1]), storage_directories_only=True)
            if candidate is not None:
                return candidate
    return source_file


def database_root_for_storage(storage: str | Path) -> Path:
    root = Path(os.path.abspath(storage))
    # Only a marked temp workspace uses its parent. A user database is allowed
    # to be called 'temp', too. The marker is never copied into a saved database.
    if (root / WORKSPACE_MARKER_FILENAME).is_file():
        return root.parent
    return root


def pack_source_path(source_file: str, database_root: Path, *, storage_root: Path | None = None) -> dict[str, str]:
    source_file = relocate_legacy_source_path(source_file, database_root, storage_root=storage_root)
    path = Path(source_file)
    if storage_root is not None and path.is_absolute():
        for base in (storage_root, database_root / "temp", database_root):
            try:
                relative = path.relative_to(base)
            except ValueError:
                continue
            if relative.parts and (relative.parts[0] in _STORAGE_DIRECTORIES or base != database_root):
                return {"source_file": relative.as_posix(), "source_path_base": "storage"}
    if path.is_absolute():
        try:
            return {
                "source_file": Path(os.path.relpath(path, database_root)).as_posix(),
                "source_path_base": "database",
            }
        except ValueError:  # Windows volumes may differ.
            pass
    # Older callers may pass a literal relative path or a foreign-platform path.
    # Preserve it rather than guessing where the original file lived.
    return {"source_file": source_file}


def restore_source_path(payload: dict, database_root: Path, *, storage_root: Path | None = None) -> str:
    if payload.get("source_path_base") in {"database", "storage"}:
        relative = _saved_path(payload["source_file"])
        if relative.is_absolute():
            raise ValueError("Expected a relative source path")
        base = (storage_root or database_root) if payload["source_path_base"] == "storage" else database_root
        source = os.path.abspath(base.joinpath(*relative.parts))
        return relocate_legacy_source_path(source, database_root, storage_root=storage_root)
    if payload.get("source_path_base") is not None:
        raise ValueError("Unsupported source path base")
    return relocate_legacy_source_path(payload["source_file"], database_root, storage_root=storage_root)
