"""Bounded JSON records for v2 Analyze snapshots (inside a single gzip stream).

Rules and packed arrays stay compact on disk and on restore. Each record is
consumed before the next one is decoded; neither side builds a second full tree.
"""
from __future__ import annotations

from array import array
import base64
from itertools import islice
import json
import sys

from .compact_analysis import DenseZScoreMap
from .compact_golden import PackedGoldenMap
from .analysis_snapshot_tables import pack_summary_artifacts, unpack_summary_artifacts

ITEM_CHUNK = 512
ARRAY_CHUNK = 65536
_DENSE_FIELDS = ("_rows", "_columns", "_scores", "_thresholds", "_flags", "_order")
_GOLDEN_FIELDS = ("_rows", "_columns", "_rules", "_values", "_display_values", "_rule_ids",
                  "_flags", "_order", "_exact_values", "_exact_display_values")


def _line(output, value):
    output.write(json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False))
    output.write("\n")


def _read(input):
    from .analysis_snapshot_state import _reject_constant
    line = input.readline()
    if not line:
        raise ValueError("Truncated saved Analyze snapshot")
    return json.loads(line, parse_constant=_reject_constant)


def _count(value):
    if type(value) is not int or value < 0:
        raise ValueError("Invalid saved Analyze record length")
    return value


def _write_section(output, value, *, database_root=None):
    from .analysis_snapshot_state import _encode
    if isinstance(value, (DenseZScoreMap, PackedGoldenMap)):
        golden = isinstance(value, PackedGoldenMap)
        names = _GOLDEN_FIELDS if golden else _DENSE_FIELDS
        _line(output, {"kind": "golden" if golden else "zscores"})
        arrays = {}
        for name in names:
            item = getattr(value, name)
            if isinstance(item, array):
                # Golden's report and outlier values often have identical bits.
                # Store that vector once without equating -0/+0 or NaN payloads.
                reference = next((key for key, previous in arrays.items()
                                  if item.typecode == previous.typecode and len(item) == len(previous)
                                  and memoryview(item).cast("B") == memoryview(previous).cast("B")), None)
                if reference is not None:
                    _line(output, {"kind": "array_ref", "field": reference})
                    continue
                arrays[name] = item
            _write_section(output, item, database_root=database_root)
    elif isinstance(value, array):
        if (value.typecode, value.itemsize) not in (("d", 8), ("Q", 8), ("I", 4)):
            raise ValueError("Unsupported saved Analyze array")
        _line(output, {"kind": "array", "type": value.typecode, "length": len(value)})
        for start in range(0, len(value), ARRAY_CHUNK):
            chunk = value[start:start + ARRAY_CHUNK]
            if sys.byteorder != "little":
                chunk.byteswap()
            _line(output, base64.b64encode(chunk.tobytes()).decode("ascii"))
    elif isinstance(value, (bytes, bytearray)):
        _line(output, {"kind": "bytes", "length": len(value)})
        for start in range(0, len(value), ARRAY_CHUNK):
            _line(output, base64.b64encode(value[start:start + ARRAY_CHUNK]).decode("ascii"))
    elif isinstance(value, list):
        from .reporting import RowData
        if value and isinstance(value[0], RowData) and all(isinstance(row, RowData) for row in value):
            from .analysis_snapshot_rows import write_rows
            write_rows(value, output, database_root=database_root)
            return
        _line(output, {"kind": "list", "length": len(value)})
        for start in range(0, len(value), ITEM_CHUNK):
            _line(output, [_encode(item) for item in value[start:start + ITEM_CHUNK]])
    elif isinstance(value, dict):
        # Small structural dictionaries (the root and summaries) contain large
        # child tables. Descend into them instead of encoding those tables here.
        if len(value) <= 32 and any(isinstance(item, (dict, list)) for item in value.values()):
            _line(output, {"kind": "fields", "keys": [_encode(key) for key in value]})
            for item in value.values():
                _write_section(output, item, database_root=database_root)
        else:
            _line(output, {"kind": "mapping", "length": len(value)})
            items = iter(value.items())
            while chunk := list(islice(items, ITEM_CHUNK)):
                _line(output, [[_encode(key), _encode(item)] for key, item in chunk])
    else:
        _line(output, {"kind": "value", "value": _encode(value)})


def _read_section(input, arrays=None):
    from .analysis_snapshot_state import _decode
    header = _read(input)
    if not isinstance(header, dict):
        raise ValueError("Invalid saved Analyze section")
    kind = header.get("kind")
    if kind == "array_ref":
        name = header.get("field")
        if arrays is None or not isinstance(name, str) or name not in arrays:
            raise ValueError("Invalid saved Analyze array reference")
        source = arrays[name]
        # Preserve independent arrays for future insertions/replacements.
        return array(source.typecode, source)
    if kind == "rows":
        from .analysis_snapshot_rows import read_rows
        return read_rows(input, _count(header["length"]))
    if kind == "value":
        return _decode(header["value"])
    if kind == "fields":
        keys = header["keys"]
        if not isinstance(keys, list):
            raise ValueError("Invalid saved Analyze field keys")
        result = {}
        for encoded in keys:
            key = _decode(encoded)
            if key in result:
                raise ValueError("Duplicate saved Analyze mapping key")
            result[key] = _read_section(input)
        return result
    if kind in ("list", "mapping"):
        length = _count(header["length"])
        result = [] if kind == "list" else {}
        remaining = length
        while remaining:
            chunk = _read(input)
            if not isinstance(chunk, list) or not 0 < len(chunk) <= min(ITEM_CHUNK, remaining):
                raise ValueError("Invalid saved Analyze table chunk")
            if kind == "list":
                result.extend(_decode(item) for item in chunk)
            else:
                for pair in chunk:
                    if not isinstance(pair, list) or len(pair) != 2:
                        raise ValueError("Invalid saved Analyze mapping entry")
                    key = _decode(pair[0])
                    if key in result:
                        raise ValueError("Duplicate saved Analyze mapping key")
                    result[key] = _decode(pair[1])
            remaining -= len(chunk)
        return result
    if kind in ("array", "bytes"):
        length = _count(header["length"])
        if kind == "array":
            code = header["type"]
            if code not in ("d", "Q", "I"):
                raise ValueError("Unsupported saved Analyze array")
            result = array(code)
            width = 4 if code == "I" else 8
            if result.itemsize != width:
                raise ValueError("Unsupported saved Analyze array width")
        else:
            result, width = bytearray(), 1
        remaining = length
        while remaining:
            encoded = _read(input)
            if not isinstance(encoded, str):
                raise ValueError("Invalid saved Analyze array chunk")
            raw = base64.b64decode(encoded, validate=True)
            if not raw or len(raw) % width or len(raw) // width > min(ARRAY_CHUNK, remaining):
                raise ValueError("Invalid saved Analyze array length")
            if kind == "array":
                result.frombytes(raw)
            else:
                result.extend(raw)
            remaining -= len(raw) // width
        if kind == "array" and sys.byteorder != "little":
            result.byteswap()
        return result
    if kind in ("zscores", "golden"):
        from .reporting import MetricValue
        names = _GOLDEN_FIELDS if kind == "golden" else _DENSE_FIELDS
        cls = PackedGoldenMap if kind == "golden" else DenseZScoreMap
        result = cls([], [], MetricValue)
        arrays = {}
        for name in names:
            item = _read_section(input, arrays)
            setattr(result, name, item)
            if isinstance(item, array):
                arrays[name] = item
        _validate_packed(result)
        result._row_index = {key: index for index, key in enumerate(result._rows)}
        result._column_index = {key: index for index, key in enumerate(result._columns)}
        if kind == "golden":
            result._rule_index = None
        return result
    raise ValueError("Unsupported saved Analyze section")


def _validate_packed(value):
    rows, columns = value._rows, value._columns
    if (not isinstance(rows, list) or not isinstance(columns, list)
            or any(not isinstance(row, tuple) or len(row) != 2 for row in rows)
            or any(not isinstance(column, str) for column in columns)
            or len(set(rows)) != len(rows) or len(set(columns)) != len(columns)):
        raise ValueError("Invalid saved Analyze score axes")
    length = len(rows) * len(columns)
    golden = isinstance(value, PackedGoldenMap)
    names = (("_values", "d"), ("_display_values", "d"), ("_rule_ids", "I")) if golden else (
        ("_scores", "d"), ("_thresholds", "d"))
    for name, code in names:
        data = getattr(value, name)
        if not isinstance(data, array) or data.typecode != code or len(data) != length:
            raise ValueError("Invalid saved Analyze packed numeric array")
    flags, order = value._flags, value._order
    if (not isinstance(flags, bytearray) or len(flags) != length
            or not isinstance(order, array) or order.typecode != "Q"
            or any((flag != 0 and (not flag & 1 or flag & ~31)) if golden else flag not in (0, 1, 3, 5, 7)
                   for flag in flags)
            or sum(bool(flag) for flag in flags) != len(order)):
        raise ValueError("Invalid saved Analyze packed flags")
    seen = bytearray(length)
    for offset in order:
        if offset >= length or not flags[offset] or seen[offset]:
            raise ValueError("Invalid saved Analyze packed order")
        seen[offset] = 1
    if golden:
        rules = value._rules
        if not isinstance(rules, list) or any(not isinstance(rule, tuple) or len(rule) != 6
                or not isinstance(rule[4], tuple)
                or any(not isinstance(pair, tuple) or len(pair) != 2 for pair in rule[4]) for rule in rules):
            raise ValueError("Invalid saved Analyze Golden rules")
        if any(value._rule_ids[offset] >= len(rules) for offset in order):
            raise ValueError("Invalid saved Analyze Golden rule index")
        for name, none_flag in (("_exact_values", 8), ("_exact_display_values", 16)):
            exact = getattr(value, name)
            if not isinstance(exact, dict) or any(type(offset) is not int or not 0 <= offset < length
                                                or not flags[offset] or flags[offset] & none_flag
                                                for offset in exact):
                raise ValueError("Invalid saved Analyze exact values")


def write_snapshot(snapshot, output, format, *, database_root=None):
    from .analysis_snapshot_paths import portable_analysis_result
    _line(output, {"format": format})
    compact = dict(snapshot)
    compact["result"] = portable_analysis_result(snapshot["result"], database_root)
    compact["summary_artifacts"] = pack_summary_artifacts(snapshot["summary_artifacts"])
    _write_section(output, compact, database_root=database_root)
    _line(output, {"end": True})


def read_snapshot(input):
    snapshot = _read_section(input)
    if _read(input) != {"end": True} or input.read(1):
        raise ValueError("Invalid saved Analyze snapshot terminator")
    if not isinstance(snapshot, dict):
        raise ValueError("Invalid saved Analyze snapshot root")
    snapshot["summary_artifacts"] = unpack_summary_artifacts(snapshot["summary_artifacts"])
    return snapshot
