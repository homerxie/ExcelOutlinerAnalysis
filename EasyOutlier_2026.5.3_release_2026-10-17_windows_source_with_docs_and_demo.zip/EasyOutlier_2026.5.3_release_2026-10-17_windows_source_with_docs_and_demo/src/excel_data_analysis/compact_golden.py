"""Lossless Golden results with shared rules and packed per-point storage."""
from __future__ import annotations

from array import array
from collections.abc import Mapping
from copy import deepcopy
from decimal import Decimal
import struct

from .models import GoldenAllowedRange


_IMMUTABLE_TYPES = frozenset((type(None), bool, int, float, str, Decimal))


def _isolated(value):
    # Numeric/reporting lookups dominate; immutable scalars need no copying.
    return value if type(value) in _IMMUTABLE_TYPES else deepcopy(value)


def _typed_key(value):
    """Deduplicate without conflating bool/int/float, signed zero or decimals."""
    kind = type(value)
    if kind is float:
        return (kind, struct.pack("!d", value))
    if kind is Decimal:
        return (kind, value.as_tuple())
    if kind in (list, tuple):
        return (kind, tuple(_typed_key(item) for item in value))
    if kind is dict:
        return (kind, tuple((_typed_key(key), _typed_key(item)) for key, item in value.items()))
    return (kind, value)


class PackedGoldenMap(Mapping):
    """Read-only metric lookup with independent reconstructed MetricValues.

    Select this container only for a sufficiently dense row/column scope. Rule
    fields are stored once, and numeric point fields are float64 arrays. None
    uses flag bits; every non-float value has an exact side-table entry, retaining
    integer types, Decimal precision and composite display text. Missing keys,
    insertion order and duplicate-key replacement follow dict semantics.
    """

    def __init__(self, row_keys, raw_columns, value_type):
        self._rows = list(dict.fromkeys(row_keys))
        self._columns = list(dict.fromkeys(raw_columns))
        self._row_index = {key: index for index, key in enumerate(self._rows)}
        self._column_index = {key: index for index, key in enumerate(self._columns)}
        self._value_type = value_type
        length = len(self._rows) * len(self._columns)
        self._values = array("d", [0.0]) * length
        self._display_values = array("d", [0.0]) * length
        self._rule_ids = array("I", [0]) * length
        self._flags = bytearray(length)
        self._order = array("Q")
        self._exact_values = {}
        self._exact_display_values = {}
        self._rules = []
        self._rule_index = {}

    def _offset(self, key):
        if not isinstance(key, tuple) or len(key) != 3:
            raise KeyError(key)
        return self._row_index[key[:2]] * len(self._columns) + self._column_index[key[2]]

    def intern_rule(self, metric):
        """Return a stable rule ID. Callers may reuse it for the same source rule."""
        rule = (metric.threshold, metric.golden_value, metric.lower_bound,
                metric.upper_bound,
                tuple((item.lower_bound, item.upper_bound) for item in metric.allowed_ranges),
                metric.outlier_number_format)
        if self._rule_index is None:
            self._rule_index = {_typed_key(item): index for index, item in enumerate(self._rules)}
        key = _typed_key(rule)
        rule_id = self._rule_index.get(key)
        if rule_id is None:
            rule_id = len(self._rules)
            self._rules.append(deepcopy(rule))
            self._rule_index[key] = rule_id
        return rule_id

    def add(self, key, metric, *, rule_id=None):
        """Insert a metric, optionally using an already-interned matching rule."""
        offset = self._offset(key)
        if rule_id is None:
            rule_id = self.intern_rule(metric)
        if not 0 <= rule_id < len(self._rules):
            raise ValueError("Unknown Golden rule ID")
        flags = 1 | (2 if metric.is_fail else 0) | (4 if metric.absolute_rule_failed else 0)
        flags |= self._store_value(offset, metric.value, self._values, self._exact_values, 8)
        flags |= self._store_value(offset, metric.outlier_display_value, self._display_values,
                                   self._exact_display_values, 16)
        if not self._flags[offset]:
            self._order.append(offset)
        self._rule_ids[offset] = rule_id
        self._flags[offset] = flags

    @staticmethod
    def _store_value(offset, value, values, exact, none_flag):
        exact.pop(offset, None)
        if value is None:
            values[offset] = 0.0
            return none_flag
        if type(value) is float:
            values[offset] = value
        else:
            values[offset] = 0.0
            exact[offset] = _isolated(value)
        return 0

    def __getitem__(self, key):
        offset = self._offset(key)
        flags = self._flags[offset]
        if not flags:
            raise KeyError(key)
        threshold, golden, lower, upper, ranges, number_format = self._rules[self._rule_ids[offset]]
        return self._value_type(
            value=None if flags & 8 else _isolated(self._exact_values[offset])
            if offset in self._exact_values else self._values[offset],
            threshold=_isolated(threshold), golden_value=_isolated(golden),
            is_fail=bool(flags & 2), lower_bound=_isolated(lower), upper_bound=_isolated(upper),
            allowed_ranges=[GoldenAllowedRange(_isolated(low), _isolated(high)) for low, high in ranges],
            outlier_display_value=None if flags & 16 else _isolated(self._exact_display_values[offset])
            if offset in self._exact_display_values else self._display_values[offset],
            outlier_number_format=_isolated(number_format), absolute_rule_failed=bool(flags & 4),
        )

    def __iter__(self):
        width = len(self._columns)
        for offset in self._order:
            row, column = divmod(offset, width)
            yield (*self._rows[row], self._columns[column])

    def __len__(self):
        return len(self._order)

    def __getstate__(self):
        state = self.__dict__.copy()
        # Rebuild this construction-only cache on the next insertion, if any.
        state["_rule_index"] = None
        return state
