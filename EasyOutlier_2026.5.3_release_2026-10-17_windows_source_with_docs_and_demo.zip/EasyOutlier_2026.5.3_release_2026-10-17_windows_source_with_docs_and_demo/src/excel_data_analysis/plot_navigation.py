"""Structured report scope carried from an outlier statistic to its plots."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from .models import OutlierRatioStatConfig


RATIO_FILTER_FIELDS = (
    "group_ids", "group_display_names", "test_types", "chain_names",
    "column_names", "units", "logical_metrics",
)
RATIO_DIMENSION_FILTER_FIELDS = ("column_header_filters", "row_dimension_filters")

RatioFilterPayload = dict[str, list[str] | dict[str, list[str]]]


def ratio_filter_payload(config: OutlierRatioStatConfig) -> RatioFilterPayload:
    """Canonicalize legacy aliases without parsing user-facing filter text."""
    fields: RatioFilterPayload = {name: list(getattr(config, name)) for name in RATIO_FILTER_FIELDS}
    fields["chain_names"] = list(config.chain_names or config.chains)
    fields["column_names"] = list(config.column_names or config.raw_columns)
    for field in RATIO_DIMENSION_FILTER_FIELDS:
        fields[field] = {name: list(values) for name, values in getattr(config, field).items()}
    return fields


def ratio_filter_items(payload: Mapping[str, Any]) -> list[tuple[str, list[str]]]:
    """Expose declared row and column fields beside built-in filters."""
    items = []
    for name, values in payload.items():
        if name in RATIO_DIMENSION_FILTER_FIELDS:
            items.extend((field, list(choices)) for field, choices in values.items() if choices)
        elif values:
            items.append((name, list(values)))
    return items


def ratio_filter_cache_key(payload: Mapping[str, Any]) -> tuple:
    """Freeze nested filter values without discarding their selected choices."""
    items = []
    for name, values in payload.items():
        frozen = (tuple(sorted(
            (field, tuple(sorted(set(choices)))) for field, choices in values.items() if choices
        )) if name in RATIO_DIMENSION_FILTER_FIELDS else tuple(sorted(set(values))))
        if frozen:
            items.append((name, frozen))
    return tuple(sorted(items))


def ratio_filter_from_navigation(navigation: Mapping[str, Any], template=None) -> OutlierRatioStatConfig:
    """Restore pre-merge row and column filters; grouping does not narrow them."""
    payload = navigation.get("filter_config", {})
    if not isinstance(payload, Mapping):
        raise ValueError("Plot navigation filter_config must be a mapping.")
    fields: RatioFilterPayload = {}
    for name in (*RATIO_FILTER_FIELDS, "chains", "raw_columns"):
        values = payload.get(name, [])
        if not isinstance(values, (list, tuple)) or any(not isinstance(value, str) for value in values):
            raise ValueError(f"Plot navigation {name} must be a list of strings.")
        fields[name] = list(values)
    for field in RATIO_DIMENSION_FILTER_FIELDS:
        filters = payload.get(field, {})
        if not isinstance(filters, Mapping):
            raise ValueError(f"Plot navigation {field} must be a mapping.")
        fields[field] = {}
        for name, values in filters.items():
            if (not isinstance(name, str) or not isinstance(values, (list, tuple))
                    or any(not isinstance(value, str) for value in values)):
                raise ValueError(f"Plot navigation {field} must map field names to lists of strings.")
            fields[field][name] = list(values)
    config = OutlierRatioStatConfig(id=str(navigation.get("id", "plot-navigation")), **fields)
    if template is not None:
        from .field_names import normalize_ratio_filters
        normalize_ratio_filters(config, template)
    return config


def normalized_ratio_filter_payload(payload: Mapping[str, Any], template) -> RatioFilterPayload:
    """Bind old navigation field spellings to actual declared template fields."""
    return ratio_filter_payload(ratio_filter_from_navigation({"filter_config": payload}, template))
