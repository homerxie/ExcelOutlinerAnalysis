"""One analysis's shared numerical-compute budget, independent of pool layout.

Only explicitly installed group coordinators and leaf workers participate. A
lease represents numerical work, not a resident process: coordinators may lend
their slot while waiting, and idle persistent workers hold no lease. The owner
must join its workers before explicitly reclaiming a dead PID's leases.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
import multiprocessing as mp
from multiprocessing.managers import SyncManager
from numbers import Integral
import os
import threading
from time import monotonic
from typing import Any
from uuid import uuid4


def _integer(value, name, minimum=1):
    if isinstance(value, bool) or not isinstance(value, Integral) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}.")
    return int(value)


class _BudgetState:
    """Manager-owned state. All changes, including grants, share one lock."""

    def __init__(self, total, group_count, remaining_jobs):
        self.total = _integer(total, "total")
        self.group_count = _integer(group_count, "group_count")
        if self.group_count > min(4, self.total):
            raise ValueError("group_count must not exceed four or the total compute budget.")
        self.remaining_jobs = _integer(remaining_jobs, "remaining_jobs", 0)
        self._condition = threading.Condition(threading.RLock())
        self._groups = {}
        self._processes = {}
        self._leases = {}
        self._waiting = {}
        self._peak_used = 0
        self._sequence = 0

    def _active(self):
        return sorted((key for key, value in self._groups.items() if not value["done"]),
                      key=lambda key: self._groups[key]["sequence"])

    def _quotas(self):
        active = self._active()
        # Reserve a share for not-yet-started jobs in the admission window.
        # Finishing one of 24 jobs must not grant its share to the other three
        # just before its replacement starts. At the final tail this divisor
        # falls with remaining_jobs and the surviving groups can grow.
        slots = min(self.group_count, max(self.remaining_jobs, len(active)))
        if not slots:
            return {}
        base, extra = divmod(self.total, slots)
        return {group: base + (index < extra) for index, group in enumerate(active)}

    def start_group(self, group_id, pid, parent_pid=None):
        group_id, pid = str(group_id), _integer(pid, "pid")
        parent_pid = None if parent_pid is None else _integer(parent_pid, "parent_pid")
        with self._condition:
            old_registration = self._processes.get(pid)
            if old_registration is not None and (old_registration["group_id"] != group_id
                                                  or old_registration["role"] != "group"):
                raise RuntimeError("A process must clear its previous group context first.")
            previous = self._groups.get(group_id)
            if previous is not None:
                if previous["done"]:
                    return False
                owner = previous["coordinator_pid"]
                if owner != pid:
                    if (owner is not None or any(p["group_id"] == group_id for p in self._processes.values())
                            or any(p["group_id"] == group_id for p in self._leases.values())):
                        raise RuntimeError("The previous group owner/workers must be unregistered or explicitly reclaimed first.")
                    previous["attempts"] += 1
            else:
                if not self.remaining_jobs:
                    raise RuntimeError("No unfinished groups remain.")
                if len(self._active()) >= min(self.group_count, self.remaining_jobs):
                    raise RuntimeError("The group admission limit has been reached.")
                self._sequence += 1
                previous = self._groups[group_id] = {"sequence": self._sequence, "done": False,
                                                     "coordinator_pid": None, "attempts": 1}
            previous["coordinator_pid"] = pid
            self._processes[pid] = {"pid": pid, "parent_pid": parent_pid,
                                    "group_id": group_id, "role": "group"}
            self._condition.notify_all()
            return True

    def finish_group(self, group_id):
        """Mark a successful group complete; never release a live worker lease."""
        with self._condition:
            group = self._groups.get(str(group_id))
            if group is None:
                raise KeyError(f"Unknown group: {group_id}")
            if group["done"]:
                return False
            group["done"] = True
            self.remaining_jobs -= 1
            self._condition.notify_all()
            return True

    def register_leaf(self, group_id, pid, parent_pid=None):
        group_id, pid = str(group_id), _integer(pid, "pid")
        parent_pid = None if parent_pid is None else _integer(parent_pid, "parent_pid")
        with self._condition:
            if group_id not in self._groups or self._groups[group_id]["done"]:
                raise RuntimeError("A leaf requires an active registered group.")
            owner = self._groups[group_id]["coordinator_pid"]
            if owner is None or parent_pid != owner:
                raise RuntimeError("A leaf must belong to the current group coordinator.")
            previous = self._processes.get(pid)
            if previous is not None and (previous["group_id"] != group_id or previous["role"] != "leaf"):
                raise RuntimeError("A process must clear its previous context before becoming a leaf.")
            self._processes[pid] = {"pid": pid, "parent_pid": parent_pid,
                                    "group_id": group_id, "role": "leaf"}
            return True

    def unregister(self, pid):
        """Normal teardown only; a running lease is not silently reclaimed."""
        pid = _integer(pid, "pid")
        with self._condition:
            if any(lease["pid"] == pid for lease in self._leases.values()):
                raise RuntimeError("Release compute leases before unregistering a process.")
            record = self._processes.pop(pid, None)
            if record is not None and record["role"] == "group":
                group = self._groups[record["group_id"]]
                if group["coordinator_pid"] == pid:
                    group["coordinator_pid"] = None
            self._condition.notify_all()
            return record is not None

    def acquire(self, group_id, pid, lease_id, timeout=.1):
        """Try one bounded wait; repeated calls with a granted ID are idempotent."""
        group_id, pid, lease_id = str(group_id), _integer(pid, "pid"), str(lease_id)
        timeout = float(timeout)
        if not 0 <= timeout <= 1.:
            raise ValueError("Lease waits must be between zero and one second.")
        deadline = monotonic() + timeout
        with self._condition:
            self._waiting[group_id] = self._waiting.get(group_id, 0) + 1
            try:
                while True:
                    existing = self._leases.get(lease_id)
                    if existing is not None:
                        if existing["pid"] != pid or existing["group_id"] != group_id:
                            raise RuntimeError("A lease ID cannot be reused by another owner.")
                        return True
                    registered = self._processes.get(pid)
                    if registered is None or registered["group_id"] != group_id:
                        raise RuntimeError("Install a matching process context before acquiring compute.")
                    group = self._groups[group_id]
                    if group["done"]:
                        raise RuntimeError("A completed group cannot start more numerical work.")
                    used = sum(lease["group_id"] == group_id for lease in self._leases.values())
                    if len(self._leases) < self.total and used < self._quotas()[group_id]:
                        self._leases[lease_id] = {"lease_id": lease_id, "pid": pid, "group_id": group_id}
                        self._peak_used = max(self._peak_used, len(self._leases))
                        return True
                    remaining = deadline - monotonic()
                    if remaining <= 0:
                        return False
                    self._condition.wait(remaining)
            finally:
                self._waiting[group_id] -= 1
                if not self._waiting[group_id]:
                    self._waiting.pop(group_id)

    def release(self, lease_id, pid):
        pid = _integer(pid, "pid")
        with self._condition:
            existing = self._leases.get(str(lease_id))
            if existing is None:
                return False
            if existing["pid"] != pid:
                raise RuntimeError("Only a lease's owner may release it.")
            del self._leases[str(lease_id)]
            self._condition.notify_all()
            return True

    def group_worker_limit(self, group_id):
        with self._condition:
            return self._quotas().get(str(group_id), 0)

    def retire_coordinators(self, joined_pids):
        """Close joined coordinators' leaf admission and take one atomic snapshot.

        The caller must already have joined these exact processes. Leases and
        registrations remain intact until every known descendant has exited;
        retiring an attempt neither completes its group nor frees its budget.
        """
        pids = {_integer(pid, "pid") for pid in joined_pids}
        with self._condition:
            for pid in pids:
                record = self._processes.get(pid)
                if record is not None and record["role"] == "group":
                    group = self._groups[record["group_id"]]
                    if group["coordinator_pid"] == pid:
                        group["coordinator_pid"] = None
            self._condition.notify_all()
            return self.snapshot()

    def reclaim_dead_pids(self, pids):
        """Caller must first verify/join these specific dead processes.

        There is deliberately no process scan, timeout expiry or signal here.
        Reclamation does not mark an interrupted group successfully complete.
        """
        pids = {_integer(pid, "pid") for pid in pids}
        with self._condition:
            leases = [key for key, value in self._leases.items() if value["pid"] in pids]
            for key in leases:
                del self._leases[key]
            records = [self._processes.pop(pid) for pid in pids if pid in self._processes]
            for record in records:
                group = self._groups[record["group_id"]]
                if record["role"] == "group" and group["coordinator_pid"] == record["pid"]:
                    group["coordinator_pid"] = None
            self._condition.notify_all()
            return {"leases_reclaimed": len(leases), "processes_reclaimed": len(records)}

    def snapshot(self):
        with self._condition:
            quotas = self._quotas()
            groups = {key: {**value, "quota": quotas.get(key, 0),
                            "used": sum(lease["group_id"] == key for lease in self._leases.values())}
                      for key, value in self._groups.items()}
            return {"total": self.total, "group_count": self.group_count, "remaining_jobs": self.remaining_jobs,
                    "manager_pid": os.getpid(),
                    "active_group_count": len(quotas), "used": len(self._leases),
                    "available": self.total - len(self._leases), "peak_used": self._peak_used,
                    "groups": groups, "registered_processes": [dict(value) for _, value in sorted(self._processes.items())],
                    "leases": [dict(value) for value in self._leases.values()], "waiting": dict(self._waiting)}


class BudgetManager(SyncManager):
    pass


BudgetManager.register("BudgetState", _BudgetState)


def _manager_initialize():
    parent = mp.parent_process()
    if parent is not None:
        def parent_died():
            from multiprocessing.connection import wait
            wait([parent.sentinel])
            os._exit(0)
        threading.Thread(target=parent_died, name="tsk-budget-parent-watch", daemon=True).start()


@contextmanager
def create_budget(total, group_count, remaining_jobs):
    """Retain the spawn Manager until every group/leaf has been shut down."""
    manager = BudgetManager(ctx=mp.get_context("spawn"))
    try:
        manager.start(initializer=_manager_initialize)
    except BaseException:
        process = getattr(manager, "_process", None)
        if process is not None and process.pid is not None:
            if process.is_alive():
                process.terminate()
            process.join(timeout=2.)
            if process.is_alive():
                process.kill()
                process.join(timeout=2.)
        raise
    try:
        yield manager.BudgetState(total, group_count, remaining_jobs)
    finally:
        manager.shutdown()


@dataclass(frozen=True)
class _Context:
    proxy: Any
    group_id: str
    role: str
    pid: int


_context = None
_local = threading.local()


def _thread_state():
    state = getattr(_local, "state", None)
    if state is None or state["pid"] != os.getpid():
        state = _local.state = {"pid": os.getpid(), "depth": 0, "held": False, "lease_id": None}
    return state


def _installed():
    return _context if _context is not None and _context.pid == os.getpid() else None


def _install(proxy, group_id, role):
    global _context
    if _thread_state()["depth"]:
        raise RuntimeError("Cannot replace a budget context inside compute_slot().")
    if _installed() is not None:
        clear_context()
    pid, group_id = os.getpid(), str(group_id)
    if role == "group":
        proxy.start_group(group_id, pid, os.getppid())
    else:
        proxy.register_leaf(group_id, pid, os.getppid())
    _context = _Context(proxy, group_id, role, pid)


def install_group(proxy, group_id):
    _install(proxy, group_id, "group")


def install_leaf(proxy, group_id):
    _install(proxy, group_id, "leaf")


def clear_context():
    """Unregister normally; this never decrements the remaining group count."""
    global _context
    if _thread_state()["depth"]:
        raise RuntimeError("Exit compute_slot() before clearing its context.")
    context = _installed()
    if context is not None:
        context.proxy.unregister(context.pid)
    _context = None


def current_budget():
    context = _installed()
    return context.proxy if context is not None else None


def current_group_id():
    context = _installed()
    return context.group_id if context is not None else None


def current_role():
    context = _installed()
    return context.role if context is not None else None


def group_worker_limit():
    context = _installed()
    return context.proxy.group_worker_limit(context.group_id) if context is not None else None


def finish_group():
    context = _installed()
    if context is None or context.role != "group":
        raise RuntimeError("Only an installed group coordinator can finish its group.")
    return context.proxy.finish_group(context.group_id)


def snapshot():
    proxy = current_budget()
    return proxy.snapshot() if proxy is not None else None


def _acquire(context, state, poll):
    lease_id = state["lease_id"] or f"{context.pid}:{threading.get_ident()}:{uuid4().hex}"
    state["lease_id"] = lease_id
    try:
        while not context.proxy.acquire(context.group_id, context.pid, lease_id, .1):
            if poll is not None:
                poll()
    except BaseException:
        # An interruption can arrive after the server granted a lease but
        # before its RPC response reached us. Release by its idempotent ID.
        try:
            context.proxy.release(lease_id, context.pid)
        except Exception:
            pass  # Preserve the original cancellation/transport failure.
        raise
    state["held"] = True


def _release(context, state):
    context.proxy.release(state["lease_id"], context.pid)
    state["held"] = False


@contextmanager
def compute_slot(poll=None):
    """Acquire once for nested scopes on this PID/thread; no context is a no-op."""
    context = _installed()
    if context is None:
        yield
        return
    state = _thread_state()
    acquired = not state["held"]
    if acquired:
        _acquire(context, state, poll)
    state["depth"] += 1
    try:
        yield
    finally:
        state["depth"] -= 1
        if acquired and state["held"]:
            _release(context, state)
        if not state["depth"]:
            state["lease_id"] = None


@contextmanager
def yield_coordinator_slot(poll=None):
    """Lend a coordinator's slot across a non-numerical wait.

    Exceptional exit leaves the slot yielded so worker shutdown cannot wait
    behind the very workers it must terminate. A caller that catches the error
    must enter a fresh compute_slot() before resuming numerical work.
    """
    context = _installed()
    state = _thread_state()
    lent = context is not None and context.role == "group" and state["held"]
    if lent:
        _release(context, state)
    yield
    if lent:
        _acquire(context, state, poll)
