"""Resolve optional semantic roles without tying user fields to positions."""

from .field_names import row_fields


def repeat_dimension(template):
    configured = template.repeat_dimension_name
    if not configured:
        return None
    names = {dimension.name for dimension in template.row_dimensions}
    resolved = row_fields(template).resolve(configured)
    if resolved in names:
        return resolved
    # Preserve the default for old templates without a repeat dimension.
    if configured == "repeat_id":
        return None
    raise ValueError(f"repeat_dimension_name={configured!r} must name an existing row dimension.")
