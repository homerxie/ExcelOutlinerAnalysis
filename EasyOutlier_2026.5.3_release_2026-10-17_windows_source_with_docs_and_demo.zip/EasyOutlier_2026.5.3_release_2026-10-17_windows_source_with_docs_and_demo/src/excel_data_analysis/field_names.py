"""Resolve user-entered field references without changing declared names or values."""
from __future__ import annotations

from collections import defaultdict
from functools import lru_cache
import re
import unicodedata


@lru_cache(maxsize=4096)
def field_key(value: str) -> str:
    # Preserve non-ASCII names and meaningful punctuation such as +, / and .
    text = unicodedata.normalize('NFKC', str(value)).strip().casefold()
    return re.sub(r'[\s_\-]+', '', text)


def preferred_batch_field(names):
    """Recognize explicit batch names; never mistake slot/repeat fields for lots."""
    recognized = ("lotid", "lot", "lotnumber", "lotno", "batchid", "batch",
                  "batchnumber", "batchno", "批次编号", "批次号", "批次", "生产批次")
    candidates = [name for name in names if field_key(name) in recognized]
    return min(candidates, key=lambda name: recognized.index(field_key(name))) if candidates else None


class FieldNames:
    def __init__(self, names, aliases=()):
        self.names = set(names)
        self.matches = defaultdict(set)
        for name in self.names:
            self.matches[field_key(name)].add(name)
        for alias, name in aliases:
            self.matches[field_key(alias)].add(name)

    def resolve(self, value, *, strict=False):
        text = str(value or '').strip()
        if text in self.names:
            return text
        matches = self.matches.get(field_key(text), set())
        if len(matches) > 1:
            raise ValueError(f"Ambiguous field name / 字段名存在歧义: {text!r}. "
                             f"Use an exact Name: {', '.join(sorted(matches))}.")
        if matches:
            return next(iter(matches))
        if strict:
            raise ValueError(f"Unsupported field / 不存在的字段: {text!r}. "
                             f"Available names: {', '.join(sorted(self.names))}.")
        return text

    def mapping(self, values, *, strict=False):
        result = {}
        for key, value in values.items():
            canonical = self.resolve(key, strict=strict)
            if canonical in result and result[canonical] != value:
                raise ValueError(f"Conflicting values for field {canonical!r} after name normalization.")
            result[canonical] = value
        return result


def row_fields(template):
    return FieldNames((d.name for d in template.row_dimensions),
                      ((d.display_name, d.name) for d in template.row_dimensions if d.display_name))


class _GroupDimensionFields:
    def __init__(self, template):
        self.rows = row_fields(template)
        self.columns = FieldNames(level.name for level in template.column_header_levels)
        self.names = self.rows.names | self.columns.names | {
            'row_dimension:' + name for name in self.rows.names
        } | {'column_header:' + name for name in self.columns.names}

    def resolve(self, value, *, strict=False):
        text = str(value or '').strip()
        prefix, separator, name = text.partition(':')
        if separator:
            if field_key(prefix) == 'rowdimension':
                return 'row_dimension:' + self.rows.resolve(name, strict=True)
            if field_key(prefix) == 'columnheader':
                return 'column_header:' + self.columns.resolve(name, strict=True)
        candidates = []
        for fields in (self.rows, self.columns):
            canonical = fields.resolve(text)
            if canonical in fields.names:
                candidates.append(canonical)
        if len(candidates) == 1:
            return candidates[0]
        if candidates:
            raise ValueError(
                f"Ambiguous group_by dimension / 分组字段名存在歧义: {text!r}. "
                "Use row_dimension:Name or column_header:Name to select its scope."
            )
        if strict:
            raise ValueError(f"Unsupported group_by dimension: {text!r}.")
        return text


def group_dimension_fields(template):
    """Resolve group-by dimensions without silently preferring one axis."""
    return _GroupDimensionFields(template)


COLUMN_FILTER_ALIASES = {
    'id': 'id', 'display_name': 'display_name', 'raw_column': 'raw_column',
    'logical_metric': 'logical_metric', 'unit': 'unit',
    'group_id': 'id', 'group_display_name': 'display_name', 'column_name': 'raw_column',
}
_COLUMN_FILTER_RESERVED_KEYS = frozenset(field_key(alias) for alias in COLUMN_FILTER_ALIASES)


@lru_cache(maxsize=4096)
def column_header_filter_name(name):
    """Keep declared header names separate from analysis-group metadata."""
    prefix, separator, _ = str(name).partition(':')
    if field_key(name) in _COLUMN_FILTER_RESERVED_KEYS or (separator and field_key(prefix) == 'columnheader'):
        return 'column_header:' + name
    return name


class _ColumnFilterFields(FieldNames):
    def __init__(self, template):
        self.headers = FieldNames(level.name for level in template.column_header_levels)
        self.builtins = FieldNames(COLUMN_FILTER_ALIASES.values(), COLUMN_FILTER_ALIASES.items())
        super().__init__(
            [*self.builtins.names, *(column_header_filter_name(name) for name in self.headers.names)],
            COLUMN_FILTER_ALIASES.items(),
        )

    def resolve(self, value, *, strict=False):
        text = str(value or '').strip()
        prefix, separator, name = text.partition(':')
        if separator and field_key(prefix) == 'columnheader':
            # An explicit scope must identify a declared header. In particular,
            # column_header:id must never fall back to an analysis-group ID.
            return column_header_filter_name(self.headers.resolve(name, strict=True))
        builtin = self.builtins.resolve(text)
        if builtin in self.builtins.names:
            return builtin
        header = self.headers.resolve(text)
        if header in self.headers.names:
            return column_header_filter_name(header)
        return super().resolve(text, strict=strict)


def column_filter_fields(template):
    return _ColumnFilterFields(template)


def column_filter_context(template, group, column):
    """Metadata for filtering one column, with no name-based overwriting."""
    context = {
        'id': str(group.id),
        'display_name': str(group.display_name),
        'raw_column': str(column.name),
        'logical_metric': str(group.id if group.analysis_mode == 'pooled_columns'
                              else f'{group.id}::{column.name}'),
        'unit': '' if group.unit is None else str(group.unit),
    }
    context.update({
        column_header_filter_name(level.name): str(value)
        for level, value in zip(
            sorted(template.column_header_levels, key=lambda item: item.priority), column.header_values,
        )
    })
    return context


def normalize_ratio_filters(config, template):
    """Resolve every declared dimension filter by name, including old wire keys.

    test_types/chain_names/chains are accepted only as legacy input spellings.
    They never imply a column position or a semantic role in the template.
    """
    rows = row_fields(template)
    columns = FieldNames(level.name for level in template.column_header_levels)
    pending = {}
    for attribute in ("column_header_filters", "row_dimension_filters"):
        raw = getattr(config, attribute)
        if not isinstance(raw, dict):
            raise ValueError(f"report.outlier_ratio_stats[{config.id}].{attribute} must be an object.")
        pending[attribute] = dict(raw)
    for field_name, values in (("test_type", config.test_types),
                               ("chain_name", config.chain_names or config.chains)):
        if not values:
            continue
        matches = []
        for attribute, names in (("column_header_filters", columns), ("row_dimension_filters", rows)):
            canonical = names.resolve(field_name)
            if canonical in names.names:
                matches.append((attribute, canonical))
        if not matches:
            raise ValueError(
                f"Unknown statistics filter field {field_name!r} for {config.id!r}. "
                "Use a declared row dimension or column header name; no field is inferred by position."
            )
        if len(matches) > 1:
            raise ValueError(
                f"Ambiguous statistics filter field {field_name!r}. "
                "Use row_dimension_filters or column_header_filters to select its scope."
            )
        attribute, canonical = matches[0]
        existing = pending[attribute].get(canonical, [])
        if not isinstance(existing, (list, tuple)):
            raise ValueError(f"report.outlier_ratio_stats[{config.id}].{attribute}[{canonical}] must be a list.")
        pending[attribute][canonical] = [*existing, *values]
    normalized = {}
    for attribute, names in (("column_header_filters", columns), ("row_dimension_filters", rows)):
        filters = {}
        for name, values in pending[attribute].items():
            canonical = names.resolve(name, strict=True)
            if not isinstance(values, (list, tuple)):
                raise ValueError(f"report.outlier_ratio_stats[{config.id}].{attribute}[{name}] must be a list.")
            for value in values:
                text = str(value).strip()
                if text:
                    target = filters.setdefault(canonical, [])
                    if text not in target:
                        target.append(text)
        normalized[attribute] = filters
    for attribute, filters in normalized.items():
        setattr(config, attribute, filters)
    config.test_types = []
    config.chain_names = []
    config.chains = []
    return config


def normalize_template_references(template):
    """Canonicalize references once at configuration boundaries, before analysis."""
    rows = row_fields(template)
    columns = FieldNames(level.name for level in template.column_header_levels)
    report = template.report
    for field in ('reliability_node_dimension', 'initial_row_merge_level', 'outlier_row_merge_max_dimension'):
        value = getattr(report, field)
        if value:
            setattr(report, field, rows.resolve(value))
    for field in ('chain_column_level', 'initial_column_merge_level', 'outlier_test_merge_max_level'):
        value = getattr(report, field)
        if value:
            setattr(report, field, columns.resolve(value))
    report.sample_dimension_names = [rows.resolve(value) for value in report.sample_dimension_names]
    grouped = group_dimension_fields(template)
    for stat in report.outlier_ratio_stats:
        stat.group_by_dimension = grouped.resolve(stat.group_by_dimension)
        stat.group_by_dimensions = [grouped.resolve(value) for value in stat.group_by_dimensions]
        normalize_ratio_filters(stat, template)
    golden = template.golden_reference_defaults
    try:
        golden.reference_dimensions = [rows.resolve(value, strict=True) for value in golden.reference_dimensions]
    except ValueError as exc:
        raise ValueError(f"golden_reference_defaults.reference_dimensions: {exc}") from exc
    try:
        golden.filters = rows.mapping(golden.filters, strict=True)
    except ValueError as exc:
        raise ValueError(f"golden_reference_defaults.filters: {exc}") from exc


class FieldLookup(dict):
    """Read template dictionaries using the shared field spelling rules.

    Iteration preserves the original keys, so IDs, filter values and declared
    dimension names are not rewritten. Used only while decoding configuration.
    """
    def __missing__(self, key):
        if not isinstance(key, str):
            raise KeyError(key)
        canonical = FieldNames(self).resolve(key)
        if dict.__contains__(self, canonical):
            return dict.__getitem__(self, canonical)
        raise KeyError(key)

    def get(self, key, default=None):
        try:
            return self[key]
        except KeyError:
            return default

    def __contains__(self, key):
        try:
            self[key]
            return True
        except KeyError:
            return False


def configuration_fields(value):
    if isinstance(value, dict):
        return FieldLookup({key: configuration_fields(item) for key, item in value.items()})
    if isinstance(value, list):
        return [configuration_fields(item) for item in value]
    return value
