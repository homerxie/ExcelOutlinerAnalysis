from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .comparison_fields import resolve_comparison_field


@dataclass(frozen=True, slots=True)
class MetricDescriptor:
    logical_metric: str
    group_id: str
    group_display_name: str
    raw_columns: tuple[str, ...] = ()
    unit: str | None = None
    header_values: dict[str, tuple[str, ...]] = field(default_factory=dict)
    display_label: str = ""
    has_outlier: bool = False
    point_count: int = 0

    def field_values(self, field_name: str) -> tuple[str, ...]:
        scope, normalized_key = resolve_comparison_field(
            field_name, headers=self.header_values, allow_missing_headers=True,
        )
        if scope == "column_header":
            return self.header_values.get(normalized_key, ())
        if normalized_key == "logical_metric":
            return (self.logical_metric,)
        if normalized_key == "analysis_group_id":
            return (self.group_id,)
        if normalized_key in {"analysis_group_display_name", "analysis_group_name"}:
            return (self.group_display_name,)
        if normalized_key == "raw_column":
            return self.raw_columns
        if normalized_key == "unit":
            return (self.unit or "",)
        if normalized_key == "display_label":
            return (self.display_label,)
        if normalized_key in {"lane_has_outlier", "metric_has_outlier"}:
            return ("true" if self.has_outlier else "false",)
        return ()


@dataclass(frozen=True, slots=True)
class MetricFilterRule:
    field_name: str
    operator: str
    value: str
    connector: str = "and"


@dataclass(frozen=True, slots=True)
class ReferenceRange:
    center: float | None
    lower_bound: float | None
    upper_bound: float | None
    key: tuple[tuple[str, str], ...]
    allowed_ranges: tuple[tuple[float, float], ...] = ()


@dataclass(frozen=True, slots=True)
class PlotPoint:
    aggregate_id: str
    sample_id: str
    dataset_id: str
    source_file: str
    row_number: int
    metric: str
    logical_metric: str
    raw_column: str
    value: float
    dimensions: dict[str, str]
    outlier: bool = False
    z_score: float | None = None
    golden_center: float | None = None
    golden_lower_bound: float | None = None
    golden_upper_bound: float | None = None
    golden_allowed_ranges: tuple[tuple[float, float], ...] = ()
    golden_key: tuple[tuple[str, str], ...] = ()
    merged_outlier: bool = False
    merge_block_key: str = ""
    merge_outlier_keys: tuple[tuple[str, int, str], ...] = ()
    zscore_reference: ReferenceRange | None = None


@dataclass(frozen=True, slots=True)
class PlotSeries:
    aggregate_id: str
    label: str
    metric: str
    logical_metric: str
    points: tuple[PlotPoint, ...]
    reference_ranges: tuple[ReferenceRange, ...] = ()
    lane_values: tuple[str, ...] = ()
    zscore_ranges: tuple[ReferenceRange, ...] = ()
    outlier_count: int = field(init=False, compare=False, repr=False)

    def __post_init__(self) -> None:
        # Calculate alongside construction on the analysis worker. Tree/title
        # updates must not rescan every plotted point on the GUI thread.
        # dataclasses.replace(points=...) also recalculates projected counts.
        object.__setattr__(self, "outlier_count", sum(point.outlier for point in self.points))

    @property
    def reference_overlay_allowed(self) -> bool:
        return len(self.reference_ranges) == 1


@dataclass(frozen=True, slots=True)
class PlotBuildResult:
    metrics: tuple[MetricDescriptor, ...]
    selected_metrics: tuple[MetricDescriptor, ...]
    series_by_metric: dict[str, tuple[PlotSeries, ...]]
    point_count: int
    outlier_count: int
    lane_count: int
    lanes_with_few_points: int

    def summary(self) -> dict[str, Any]:
        return {
            "matched_metrics": len(self.metrics),
            "selected_metrics": len(self.selected_metrics),
            "point_count": self.point_count,
            "outlier_count": self.outlier_count,
            "lane_count": self.lane_count,
            "lanes_with_few_points": self.lanes_with_few_points,
        }
