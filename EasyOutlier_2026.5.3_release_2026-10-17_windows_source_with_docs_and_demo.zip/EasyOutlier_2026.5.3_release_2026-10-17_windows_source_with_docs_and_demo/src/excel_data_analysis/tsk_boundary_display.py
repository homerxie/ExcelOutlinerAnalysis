"""Interpret saved boundary metadata without inventing finite estimates."""
from __future__ import annotations

import math
from collections.abc import Mapping
from typing import Any


_BOUNDARY_STATUSES = frozenset({
    "boundary_unbounded", "nonfinite_effect", "nonfinite_mle",
    "fixed_zero_assumption", "boundary_low", "boundary_high",
})
_BOUNDARY_BASES = frozenset({"fitted_boundary", "fixed_zero_assumption", "type_only_boundary"})
_LIMITS = frozenset({"negative_infinity", "positive_infinity", "zero", "undefined"})


def _finite(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def boundary_limit(row: Mapping[str, Any], field: str = "coefficient") -> str | None:
    """Return a verified limit code, ``undetermined``, or no boundary display.

    Finite values always take precedence. A missing direction is distinct from
    an undefined contrast, and unavailable/unstable fits never acquire a sign.
    ``odds_limit`` is intentionally ignored: absolute odds are not an OR.
    """
    value = row.get(field)
    numeric = isinstance(value, (int, float)) and not isinstance(value, bool)
    if _finite(value):
        return None
    if row.get("status") not in _BOUNDARY_STATUSES:
        return None
    limit = row.get("odds_ratio_limit" if field == "odds_ratio" else "log_odds_limit")
    if row.get("status") == "nonfinite_mle":
        # This is also a *global* fit status. One endpoint type must not turn
        # unrelated interior-type comparisons into supposed infinite limits.
        saved_limit = any(row.get(key) in _LIMITS | {"undetermined"}
                          for key in ("log_odds_limit", "odds_ratio_limit"))
        endpoint = (row.get("direction_basis") in _BOUNDARY_BASES and
                    row.get("boundary_state") in {"lower", "upper", "both_lower", "both_upper",
                                                   "a_lower", "b_lower", "a_upper", "b_upper",
                                                   "lower_upper", "upper_lower"})
        if not (saved_limit or endpoint or numeric and math.isinf(value)):
            return None
    if limit == "undetermined":
        return "undetermined"
    if limit in _LIMITS:
        return limit if field != "odds_ratio" or limit != "negative_infinity" else "undetermined"
    if numeric and math.isinf(value):
        return "positive_infinity" if value > 0 else ("negative_infinity" if field != "odds_ratio" else "undetermined")
    if row.get("direction_basis") not in _BOUNDARY_BASES:
        return "undetermined"
    state = row.get("boundary_state")
    if state in {"both_lower", "both_upper"}:
        return "undefined"
    expected = {
        "a_lower": "b_higher", "b_lower": "b_lower", "a_upper": "b_lower",
        "b_upper": "b_higher", "lower_upper": "b_higher", "upper_lower": "b_lower",
    }
    if state in expected and row.get("direction") == expected[state]:
        if field == "odds_ratio":
            return "positive_infinity" if expected[state] == "b_higher" else "zero"
        return "positive_infinity" if expected[state] == "b_higher" else "negative_infinity"
    if field != "odds_ratio":
        if state == "lower" and row.get("boundary_probability") == 0:
            return "negative_infinity"
        if state == "upper" and row.get("boundary_probability") == 1:
            return "positive_infinity"
    return "undetermined"


def effect_sort_value(row: Mapping[str, Any], field: str = "coefficient") -> float | None:
    """Sort the displayed estimate, including only verified boundary limits."""
    value = row.get(field)
    if _finite(value):
        return value
    return {"negative_infinity": -math.inf, "positive_infinity": math.inf,
            "zero": 0.}.get(boundary_limit(row, field))


def effect_level_boundary_row(feature: Mapping[str, Any], row: Mapping[str, Any]) -> dict[str, Any]:
    """Copy an effect row with limits for its *relative* coefficient and OR.

    Legacy type endpoint metadata describes absolute log odds. Reuse a verified
    comparison against the reference (reversing B−A when needed) before using
    the endpoint against a confirmed interior reference. Never mutate reports.
    """
    result = dict(row)
    if (feature.get("role") != "tsk_type" or row.get("status") not in _BOUNDARY_STATUSES
            or _finite(row.get("coefficient"))):
        return result
    absolute_endpoint = (row.get("boundary_state") in {"lower", "upper"}
                         and row.get("direction_basis") in _BOUNDARY_BASES)
    if not absolute_endpoint and row.get("log_odds_limit") in _LIMITS:
        return result
    reference_name = feature.get("reference_level")
    reference = next((level for level in feature.get("levels", [])
                      if level.get("level") == reference_name), None)
    level_name = row.get("level")
    relative = odds = None
    for pair in feature.get("pairwise", []):
        forward = pair.get("level_a") == reference_name and pair.get("level_b") == level_name
        reverse = pair.get("level_b") == reference_name and pair.get("level_a") == level_name
        if not (forward or reverse):
            continue
        pair_limit = boundary_limit(pair, "difference")
        if pair_limit is None and row.get("status") == "nonfinite_mle" and boundary_limit(row) is None:
            return result
        relative = pair_limit or "undetermined"
        odds = boundary_limit(pair, "odds_ratio") or "undetermined"
        if reverse:
            relative = {"positive_infinity": "negative_infinity", "negative_infinity": "positive_infinity"}.get(relative, relative)
            odds = {"positive_infinity": "zero", "zero": "positive_infinity"}.get(odds, odds)
        break
    if relative is None:
        if row.get("status") == "nonfinite_mle" and boundary_limit(row) is None:
            return result
        if reference is None or reference_name == level_name:
            relative = odds = "undefined"
        elif (_finite(reference.get("coefficient"))
              and row.get("boundary_state") in {"lower", "upper"}
              and row.get("direction_basis") in _BOUNDARY_BASES
              and reference.get("boundary_state") not in {"lower", "upper"}
              and reference.get("status") in {"reference_coding", "ok", "point_estimate_only",
                                               "profile_reference", "profile_reference_partial"}):
            relative = boundary_limit(row) or "undetermined"
            odds = {"negative_infinity": "zero", "positive_infinity": "positive_infinity"}.get(relative, relative)
        else:
            relative = odds = "undetermined"
    # Explicitly mark unknown relative directions so absolute fallback cannot
    # turn them into a spurious signed relative coefficient.
    result["log_odds_limit"] = relative
    result["odds_ratio_limit"] = odds
    result["relative_boundary_limit"] = True
    return result
