"""Read frozen Analyze export metadata without materializing point results.

Opening a database needs its exact template and available nodes. Metric, row,
and summary semantics are validated later by the full export reader. This path
still validates JSON boundaries and consumes gzip to EOF (including its CRC).
"""
from __future__ import annotations

import base64
from decimal import InvalidOperation
import gzip
import io
from pathlib import Path
import zlib

from .analysis_snapshot_state import FORMAT, LEGACY_FORMAT, _decode
from .analysis_snapshot_stream import _DENSE_FIELDS, _GOLDEN_FIELDS
from .models import TemplateConfig
from .snapshot_json_stream import JSONStream


_METADATA = {"template", "available_nodes", "result"}


def inspect_snapshot_format(path: str | Path) -> str:
    """Probe the first 64 KiB, with bounded streaming fallback for reordered JSON.

    Analyze and TSK writers put format first. Older/reordered documents can put
    large values before it; scan those without retaining their contents. The
    selected/full reader is responsible for EOF/gzip validation after dispatch.
    """
    def find_format(reader):
        for key in reader.object_keys():
            if key == "format":
                value = reader.value()
                if not isinstance(value, str):
                    raise ValueError("Invalid snapshot format")
                return value
            reader.skip()
        raise ValueError("Missing snapshot format")

    with gzip.open(path, "rt", encoding="utf-8") as source:
        prefix = source.read(65536)
        try:
            return find_format(JSONStream(io.StringIO(prefix)))
        except ValueError:
            if len(prefix) < 65536:
                raise
        source.seek(0)
        return find_format(JSONStream(source))


def _count(value):
    if type(value) is not int or value < 0:
        raise ValueError("Invalid saved Analyze section length")
    return value


def _section(reader, *, retain=False):
    header = reader.line_value()
    if not isinstance(header, dict):
        raise ValueError("Invalid saved Analyze section header")
    kind = header.get("kind")
    if kind == "value":
        return _decode(header["value"]) if retain else None
    if kind == "array_ref":
        if not isinstance(header.get("field"), str):
            raise ValueError("Invalid saved Analyze array reference")
        return None
    if kind in ("golden", "zscores"):
        for _ in _GOLDEN_FIELDS if kind == "golden" else _DENSE_FIELDS:
            _section(reader)
        return None
    if kind == "fields":
        keys = header["keys"]
        if not isinstance(keys, list):
            raise ValueError("Invalid saved Analyze field keys")
        result, seen = {}, set()
        for encoded in keys:
            key = _decode(encoded)
            if key in seen:
                raise ValueError("Duplicate saved Analyze field")
            seen.add(key)
            value = _section(reader, retain=retain)
            if retain:
                result[key] = value
        return result if retain else None
    if kind in ("list", "mapping", "rows", "array", "bytes"):
        remaining = _count(header["length"])
        result = {} if kind == "mapping" else []
        width = 1
        if kind == "array":
            if header.get("type") not in ("d", "Q", "I"):
                raise ValueError("Invalid saved Analyze array type")
            width = 4 if header["type"] == "I" else 8
        while remaining:
            chunk = reader.line_value()
            if kind in ("array", "bytes"):
                if not isinstance(chunk, str):
                    raise ValueError("Invalid saved Analyze array chunk")
                raw = base64.b64decode(chunk, validate=True)
                if len(raw) % width:
                    raise ValueError("Invalid saved Analyze array width")
                count = len(raw) // width
            elif kind == "rows":
                if not isinstance(chunk, dict) or not isinstance(chunk.get("rows"), list):
                    raise ValueError("Invalid saved Analyze row chunk")
                count = len(chunk["rows"])
            else:
                if not isinstance(chunk, list):
                    raise ValueError("Invalid saved Analyze table chunk")
                count = len(chunk)
                if retain:
                    if kind == "list":
                        result.extend(_decode(item) for item in chunk)
                    else:
                        for pair in chunk:
                            if not isinstance(pair, list) or len(pair) != 2:
                                raise ValueError("Invalid saved Analyze mapping entry")
                            key = _decode(pair[0])
                            if key in result:
                                raise ValueError("Duplicate saved Analyze mapping key")
                            result[key] = _decode(pair[1])
            if not 0 < count <= remaining:
                raise ValueError("Invalid saved Analyze chunk length")
            remaining -= count
        return result if retain else None
    raise ValueError("Unsupported saved Analyze section")


def _v2_metadata(reader):
    header = reader.line_value()
    if not isinstance(header, dict) or header.get("kind") != "fields" or not isinstance(header.get("keys"), list):
        raise ValueError("Invalid saved Analyze metadata root")
    result, seen = {}, set()
    for encoded in header["keys"]:
        key = _decode(encoded)
        if key in seen:
            raise ValueError("Duplicate saved Analyze root field")
        seen.add(key)
        value = _section(reader, retain=key in _METADATA)
        if key in _METADATA:
            result[key] = value
    if reader.line_value() != {"end": True}:
        raise ValueError("Invalid saved Analyze terminator")
    return result


def load_analysis_snapshot_metadata(path: str | Path) -> dict:
    """Return format/template/available_nodes/result with bounded input buffers."""
    try:
        with Path(path).open("rb") as source, gzip.GzipFile(fileobj=source, mode="rb") as packed:
            with io.TextIOWrapper(packed, encoding="utf-8") as text:
                reader = JSONStream(text)
                envelope = reader.object_fields({
                    "format": None,
                    "snapshot": lambda value: value.object_fields(dict.fromkeys(_METADATA)),
                })
                format = envelope.get("format")
                if format == LEGACY_FORMAT:
                    metadata = {key: _decode(value) for key, value in envelope["snapshot"].items()}
                elif format == FORMAT and set(envelope) == {"format"}:
                    metadata = _v2_metadata(reader)
                else:
                    raise ValueError("Unsupported saved Analyze snapshot format")
                reader.finish()
        if (not isinstance(metadata.get("template"), TemplateConfig)
                or not isinstance(metadata.get("available_nodes"), list)
                or any(not isinstance(node, str) for node in metadata["available_nodes"])
                or ("result" in metadata and not isinstance(metadata["result"], dict))):
            raise ValueError("Invalid saved Analyze metadata")
        return {"format": format, **metadata}
    except (OSError, EOFError, zlib.error, UnicodeError, KeyError, TypeError, ValueError,
            OverflowError, InvalidOperation, IndexError, AttributeError, RecursionError) as exc:
        raise ValueError(f"Invalid saved Analyze snapshot metadata: {exc}") from exc
