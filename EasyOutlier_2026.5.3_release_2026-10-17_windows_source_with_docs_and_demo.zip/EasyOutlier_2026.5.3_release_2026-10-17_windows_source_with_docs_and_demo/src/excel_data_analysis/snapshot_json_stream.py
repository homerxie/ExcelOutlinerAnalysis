"""Bounded JSON selection for legacy snapshots stored as one very long line.

Discarded values are syntax-checked without building dictionaries or lists.
Selected values still use Python's JSON decoder, preserving its number/string
semantics. This reader does not interpret Analyze's tagged data types.
"""
from __future__ import annotations

import json
import re


READ_CHUNK = 65536
_NONSPACE = re.compile(r"[^ \t\r\n]")
_STRING_SPECIAL = re.compile(r'["\\\x00-\x1f]')
_PRIMITIVE_END = re.compile(r"[,}\] \t\r\n]")
_NUMBER = re.compile(r"-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?\Z")


def _reject_constant(value):
    raise ValueError(f"Invalid JSON numeric constant: {value}")


class JSONStream:
    def __init__(self, input):
        self.input = input
        self.buffer = ""
        self.position = 0
        self._capture = None
        self._capture_start = 0
        self._decoder = json.JSONDecoder(parse_constant=_reject_constant)

    def _fill(self):
        if self.position < len(self.buffer):
            return True
        if self._capture is not None:
            self._capture.append(self.buffer[self._capture_start:])
            self._capture_start = 0
        self.buffer = self.input.read(READ_CHUNK)
        self.position = 0
        return bool(self.buffer)

    def _peek(self):
        return self.buffer[self.position] if self._fill() else ""

    def _space(self):
        while self._fill():
            match = _NONSPACE.search(self.buffer, self.position)
            if match is not None:
                self.position = match.start()
                return
            self.position = len(self.buffer)

    def _expect(self, character):
        self._space()
        if self._peek() != character:
            raise ValueError(f"Invalid JSON structure: expected {character!r}")
        self.position += 1

    def _string(self):
        self._expect('"')
        while self._fill():
            match = _STRING_SPECIAL.search(self.buffer, self.position)
            if match is None:
                self.position = len(self.buffer)
                continue
            character = match.group()
            self.position = match.end()
            if character == '"':
                return
            if character != "\\":
                raise ValueError("Invalid JSON control character")
            escape = self._peek()
            if not escape or escape not in '"\\/bfnrtu':
                raise ValueError("Invalid JSON string escape")
            self.position += 1
            if escape == "u":
                for _ in range(4):
                    digit = self._peek()
                    if not digit or digit not in "0123456789abcdefABCDEF":
                        raise ValueError("Invalid JSON unicode escape")
                    self.position += 1
        raise ValueError("Truncated JSON string")

    def _primitive(self):
        parts = []
        while self._fill():
            match = _PRIMITIVE_END.search(self.buffer, self.position)
            end = match.start() if match else len(self.buffer)
            parts.append(self.buffer[self.position:end])
            self.position = end
            if match is not None:
                break
        value = "".join(parts)
        if value not in ("true", "false", "null") and _NUMBER.fullmatch(value) is None:
            raise ValueError("Invalid JSON primitive")

    def _consume(self):
        self._space()
        character = self._peek()
        if self._capture is None and character:
            # Most discarded rows/metrics fit within the current fixed buffer.
            # Let the C decoder validate and discard those small objects in one
            # operation; only containers crossing buffers need Python scanning.
            try:
                _, end = self._decoder.raw_decode(self.buffer, self.position)
            except json.JSONDecodeError:
                pass
            else:
                # A number/literal at a buffer edge may continue in the next
                # buffer (e.g. 12|34 or 1.2|e3), so retain explicit boundaries.
                if character in '[{"' or (end < len(self.buffer) and self.buffer[end] in ',}] \t\r\n'):
                    self.position = end
                    return
        if character == '"':
            self._string()
        elif character == "{":
            self.position += 1
            self._space()
            if self._peek() == "}":
                self.position += 1
                return
            while True:
                self._string()
                self._expect(":")
                self._consume()
                self._space()
                character = self._peek()
                self.position += bool(character)
                if character == "}":
                    return
                if character != ",":
                    raise ValueError("Invalid JSON object boundary")
        elif character == "[":
            self.position += 1
            self._space()
            if self._peek() == "]":
                self.position += 1
                return
            while True:
                self._consume()
                self._space()
                character = self._peek()
                self.position += bool(character)
                if character == "]":
                    return
                if character != ",":
                    raise ValueError("Invalid JSON array boundary")
        elif character:
            self._primitive()
        else:
            raise ValueError("Truncated JSON value")

    def value(self):
        self._space()
        self._capture = []
        self._capture_start = self.position
        try:
            self._consume()
            self._capture.append(self.buffer[self._capture_start:self.position])
            return json.loads("".join(self._capture), parse_constant=_reject_constant)
        finally:
            self._capture = None

    def skip(self):
        self._consume()

    def object_keys(self):
        """Yield each key with the reader positioned at its value.

        The caller must consume that value before advancing. Stopping iteration
        early permits a format probe; it deliberately skips EOF/CRC validation.
        """
        self._expect("{")
        seen = set()
        self._space()
        if self._peek() == "}":
            self.position += 1
            return
        while True:
            self._space()
            if self._peek() != '"':
                raise ValueError("Invalid JSON object key")
            key = self.value()
            if key in seen:
                raise ValueError("Duplicate saved JSON field")
            seen.add(key)
            self._expect(":")
            yield key
            self._space()
            character = self._peek()
            self.position += bool(character)
            if character == "}":
                return
            if character != ",":
                raise ValueError("Invalid JSON object boundary")

    def object_fields(self, selected):
        """Select keys; callable values read nested content using this reader."""
        result = {}
        for key in self.object_keys():
            if key in selected:
                callback = selected[key]
                result[key] = callback(self) if callable(callback) else self.value()
            else:
                self.skip()
        return result

    def array_items(self, read_item=None):
        """Yield one item at a time; a callback may select fields within it.

        Consumers must exhaust the iterator before reading the next JSON field.
        No list of previously yielded items is retained by the reader.
        """
        self._expect("[")
        self._space()
        if self._peek() == "]":
            self.position += 1
            return
        while True:
            yield read_item(self) if callable(read_item) else self.value()
            self._space()
            character = self._peek()
            self.position += bool(character)
            if character == "]":
                return
            if character != ",":
                raise ValueError("Invalid JSON array boundary")

    def line_value(self):
        """Decode one bounded v2 record using JSON's native decoder."""
        parts = []
        while self._fill():
            end = self.buffer.find("\n", self.position)
            if end < 0:
                parts.append(self.buffer[self.position:])
                self.position = len(self.buffer)
                continue
            parts.append(self.buffer[self.position:end])
            self.position = end + 1
            value = "".join(parts)
            if value.strip():
                return json.loads(value, parse_constant=_reject_constant)
            parts.clear()
        if "".join(parts).strip():
            return json.loads("".join(parts), parse_constant=_reject_constant)
        raise ValueError("Truncated saved JSON record")

    def finish(self):
        self._space()
        if self._peek():
            raise ValueError("Invalid JSON trailing content")
