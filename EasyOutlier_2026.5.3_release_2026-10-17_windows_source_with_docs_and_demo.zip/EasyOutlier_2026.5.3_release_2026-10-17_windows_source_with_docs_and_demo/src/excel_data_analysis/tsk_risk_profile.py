"""A certified finite-shared-effects parameterization for joint risk profiles.

The main joint fit and its identifiability/contrast inference remain authoritative.
This adapter only replaces a probability nuisance solve when singleton interior
observations bound every shared coefficient on finite likelihood level sets.
Numerical uncertainty returns control to the ordinary joint profile search.
"""
from __future__ import annotations

import math
from numbers import Integral

import numpy as np
from scipy.special import expit

from .tsk_logistic_boundary import KKT_TOLERANCE, LogisticBoundaryFit, _loss_tolerance
from .tsk_logistic_joint_boundary import JointBoundaryBetterOptimumError


ANCHOR_SINGULAR_RATIO = 1e-8


class RiskProfileFallback(RuntimeError):
    """The original joint profile must handle this numerical problem."""


class _ScaledOddsRiskFit(LogisticBoundaryFit):
    """Condition each start without changing its odds or its nuisance domain."""

    def _optimize(self, start, fixed=None):
        base_scale = self.odds_scale
        start = np.asarray(start, dtype=float)
        factor = np.maximum(start[:self.type_count], 1.)
        with np.errstate(over="ignore", invalid="ignore", under="ignore"):
            scale = base_scale * factor
        if not np.all(np.isfinite(scale)) or np.any(scale <= 0.):
            raise RiskProfileFallback("A profile start cannot be rescaled in finite arithmetic.")
        normalized = start.copy()
        normalized[:self.type_count] /= factor
        try:
            self.odds_scale = scale
            fit = super()._optimize(normalized, fixed)
            params = np.asarray(fit["params"], dtype=float).copy()
            params[:self.type_count] *= factor
            return dict(fit, params=params)
        finally:
            # Every subsequent likelihood comparison and unrestricted KKT
            # check uses the authoritative adapter coordinates again.
            self.odds_scale = base_scale


def finite_shared_anchor_certificate(design, chain_index, n, k, type_count):
    """Certify bounded shared coefficients using actual singleton observations.

    A singleton with 0 < k < n bounds its fitted logit on every finite NLL
    level set. Full column rank then bounds all retained coefficients. Only
    type columns absent from the anchors may be removed: dropping an absent
    shared column would incorrectly certify an unrestricted shared direction.
    This is a closure certificate, not a global-uniqueness assertion.
    """
    result = {"certified": False, "reason": "invalid_model_arrays", "anchor_count": 0,
              "retained_column_count": 0, "rank": 0, "min_singular_ratio": None,
              "singular_ratio_threshold": ANCHOR_SINGULAR_RATIO}
    if isinstance(type_count, bool) or not isinstance(type_count, Integral):
        return result
    try:
        design = np.asarray(design, dtype=float)
        raw_index = np.asarray(chain_index)
        chain_index = np.asarray(chain_index, dtype=int)
        n, k = np.asarray(n, dtype=float), np.asarray(k, dtype=float)
    except (ValueError, TypeError, OverflowError):
        return result
    if (design.ndim != 2 or not len(design) or not 0 < type_count < design.shape[1]
            or chain_index.shape != (len(design),) or not np.array_equal(raw_index, chain_index)
            or n.ndim != 1 or n.shape != k.shape or not len(n)
            or np.any(chain_index < 0) or np.any(chain_index >= len(n))
            or np.any(n <= 0) or np.any(k < 0) or np.any(k > n)
            or not all(np.all(np.isfinite(value)) for value in (design, n, k))):
        return result
    kinds = design[:, :type_count]
    if not (np.all((kinds == 0) | (kinds == 1)) and np.all(kinds.sum(axis=1) == 1)):
        return result
    counts = np.bincount(chain_index, minlength=len(n))
    anchors = (counts[chain_index] == 1) & (k[chain_index] > 0) & (k[chain_index] < n[chain_index])
    result["anchor_count"] = int(np.sum(anchors))
    if not np.any(anchors):
        return dict(result, reason="no_singleton_interior_anchors")
    retained = np.r_[np.any(design[anchors, :type_count] != 0, axis=0),
                     np.ones(design.shape[1] - type_count, dtype=bool)]
    matrix = design[anchors][:, retained]
    result["retained_column_count"] = matrix.shape[1]
    result["retained_type_indices"] = np.flatnonzero(retained[:type_count]).tolist()
    scales = np.max(np.abs(matrix), axis=0)
    if np.any(scales == 0):
        return dict(result, reason="shared_column_absent_from_anchors")
    if matrix.shape[0] < matrix.shape[1]:
        return dict(result, reason="insufficient_anchor_rank")
    # Max scaling first avoids squaring an otherwise harmless feature unit.
    normalized = matrix / scales
    normalized /= np.linalg.norm(normalized, axis=0)
    try:
        singular = np.linalg.svd(normalized, compute_uv=False)
    except np.linalg.LinAlgError:
        return dict(result, reason="anchor_decomposition_failed")
    threshold = max(ANCHOR_SINGULAR_RATIO, 100 * np.finfo(float).eps * max(matrix.shape))
    ratio = float(singular[-1] / singular[0])
    result.update(rank=int(np.count_nonzero(singular > singular[0] * threshold)),
                  min_singular_ratio=ratio, singular_ratio_threshold=threshold)
    if not math.isfinite(ratio) or ratio <= threshold:
        return dict(result, reason="anchor_rank_or_conditioning_failed")
    return dict(result, certified=True, reason="singleton_interior_full_rank")


def create_certified_odds_risk_profile(parent):
    """Return an adapter only for the supported, already-validated joint face."""
    try:
        return CertifiedOddsRiskProfile(parent)
    except (RiskProfileFallback, ValueError, FloatingPointError, OverflowError, np.linalg.LinAlgError):
        return None


class CertifiedOddsRiskProfile:
    def __init__(self, parent):
        state = parent.state
        if (not isinstance(state, dict) or not state.get("converged")
                or state.get("parameterization") != "joint_logistic_face"
                or state.get("model_fingerprint") != parent._fingerprint):
            raise RiskProfileFallback("A validated complete joint face is required.")
        certificate = finite_shared_anchor_certificate(parent.design, parent.chain_index,
                                                        parent.n, parent.k, parent.type_count)
        if not certificate["certified"]:
            raise RiskProfileFallback(certificate["reason"])
        self.parent = parent
        self.certificate = certificate
        self._state = state
        self._coefficients = np.asarray(state["coefficients"], dtype=float).copy()
        self._core = np.asarray(state["core_coefficients"], dtype=float).copy()
        self._minimum = float(state["minimum"])
        self._zero = np.asarray(parent._zero, dtype=bool).copy()
        t = parent.type_count
        types = np.argmax(parent.design[:, :t], axis=1)
        zero_types = np.array([np.any(self._zero[types == index]) for index in range(t)])
        if (not np.array_equal(self._zero, zero_types[types])
                or not np.any(self._zero & (parent.k[parent.chain_index] > 0))):
            raise RiskProfileFallback("Only whole-type zero faces containing a Fail Chain are supported.")
        self.certificate = dict(certificate, zero_type_indices=np.flatnonzero(zero_types).tolist())
        engine = _ScaledOddsRiskFit(parent.design, parent.chain_index, parent.n, parent.k, t,
                                   coefficient_bound=parent.coefficient_bound)
        if np.any(engine.counts.T @ (parent.n - parent.k) == 0):
            raise RiskProfileFallback("Positive type-odds recession is not supported.")
        if np.any(np.abs(self._core[t:]) >= engine.coefficient_bound - .1):
            raise RiskProfileFallback("Shared coefficients require the unrestricted joint solver.")
        exposures = engine.counts.T @ parent.n
        if not np.all(np.isfinite(exposures)):
            raise RiskProfileFallback("Nonfinite type exposure cannot be scaled reliably.")
        log_scales = np.maximum(self._core[:t], -np.log(np.maximum(exposures, 1.)))
        log_scales[zero_types] = -np.log(np.maximum(exposures[zero_types], 1.))
        if np.any(np.abs(log_scales) > 700.):
            raise RiskProfileFallback("Type odds scaling exceeds finite arithmetic.")
        engine.odds_scale = np.exp(log_scales)
        self.engine = engine
        self._log_scales = log_scales
        params = self._convert_start(self._core)
        params[:t][zero_types] = 0.
        self.params = params
        value, gradient, predicted, derivative = engine.evaluate(params)
        if (not math.isfinite(value)
                or abs(value - self._minimum) > max(1e-7, 64 * np.finfo(float).eps * abs(self._minimum))
                or not np.allclose(predicted, state["predicted"], rtol=1e-9, atol=1e-12)):
            raise RiskProfileFallback("The odds parameterization does not reproduce the joint likelihood.")
        unrestricted = [(0., None)] * t + [(None, None)] * (parent.width - t)
        if engine._kkt(params, gradient, derivative, unrestricted) >= KKT_TOLERANCE:
            raise RiskProfileFallback("The exact joint zero face does not satisfy odds KKT.")
        self._cache = {}

    def _convert_start(self, start):
        start = np.asarray(start, dtype=float)
        t = self.parent.type_count
        if start.shape != (self.parent.width,) or not np.all(np.isfinite(start)):
            raise RiskProfileFallback("A joint profile start is not finite.")
        if np.any(np.abs(start[t:]) >= self.engine.coefficient_bound - .1):
            raise RiskProfileFallback("A joint profile start exceeds the odds trial box.")
        logarithm = start[:t] - self._log_scales
        if np.any(np.abs(logarithm) > 700.):
            raise RiskProfileFallback("A joint profile start cannot be converted without clipping.")
        return np.r_[np.exp(logarithm), start[t:]]

    def _check_current_fit(self):
        state = self.parent.state
        if (state is not self._state or not state.get("converged")
                or float(state["minimum"]) != self._minimum
                or not np.array_equal(state["coefficients"], self._coefficients)
                or not np.array_equal(state["core_coefficients"], self._core)
                or not np.array_equal(self.parent._zero, self._zero)):
            raise RiskProfileFallback("The parent joint fit changed after certification.")

    def _joint_coordinates(self, params):
        t = self.parent.type_count
        core = np.asarray(params, dtype=float).copy()
        positive = core[:t] > 0
        core[:t] = 0.
        core[:t][positive] = np.log(params[:t][positive]) + self._log_scales[positive]
        zero = (np.asarray(params)[:t] == 0)[self.engine.type_index]
        return core, zero

    def _unrestricted_kkt(self, params, fixed):
        free, _, unpack = self.engine._coordinates(params, fixed)
        reconstructed, transform = unpack(params[free])
        if not np.allclose(reconstructed, params, atol=0., rtol=1e-10):
            return math.inf
        loss, gradient, _, derivative = self.engine.evaluate(params)
        if not math.isfinite(loss):
            return math.inf
        gradient, derivative = transform.T @ gradient, derivative @ transform
        bounds = [(0., None) if index < self.parent.type_count else (None, None) for index in free]
        return self.engine._kkt(params[free], gradient, derivative, bounds)

    def _validated_difference(self, params, core, zero, vector, logit):
        # A numerically corrupted change of coordinates must request fallback,
        # not invalidate a valid main fit as though it found a better optimum.
        represented_logit = float(vector @ core)
        if not math.isfinite(represented_logit) or abs(represented_logit - logit) > 1e-8:
            raise RiskProfileFallback("The odds profile does not preserve its fixed logit.")
        difference = self.parent._loss_difference(core, zero, self._core, self._zero, (vector, logit))
        odds_difference = self.engine._loss_change(params, self.params)
        if (not math.isfinite(difference) or not math.isfinite(odds_difference)
                or abs(difference - odds_difference) > 1e-7):
            raise RiskProfileFallback("Independent joint likelihood validation disagrees with the odds profile.")
        return difference

    def profile_logit(self, vector, logit, starts):
        """Solve a full probability nuisance problem or request joint fallback."""
        self._check_current_fit()
        vector = np.asarray(vector, dtype=float)
        try:
            self.engine._query(vector)  # Only a probability, never a beta contrast.
        except ValueError as error:
            raise RiskProfileFallback(str(error)) from error
        logit = float(logit)
        probability = float(expit(logit))
        if (not math.isfinite(logit) or not 0. < probability < 1.
                or abs(math.log(probability) - math.log1p(-probability) - logit) > 1e-10):
            raise RiskProfileFallback("The probability constraint cannot preserve its finite logit.")
        key = (tuple(vector), logit)
        if key in self._cache:
            difference, core, zero, _ = self._cache[key]
            return difference, core.copy(), zero.copy()
        converted = [self._convert_start(start) for start in starts]
        converted.append(self.params.copy())
        positive = self.params.copy()
        positive[:self.parent.type_count] = np.maximum(positive[:self.parent.type_count], .25)
        converted.append(positive)
        nearby = [(abs(value - logit), entry[3]) for (query, value), entry in self._cache.items()
                  if query == key[0]]
        if nearby:
            converted.insert(0, min(nearby, key=lambda item: item[0])[1].copy())
        fixed = (vector, probability)
        self.engine.progress_callback = lambda event: self.parent._progress(
            "joint_optimize", operation="certified_odds_risk_profile",
            odds_phase=event.get("phase"), iteration=event.get("iteration", 0),
            start_index=event.get("start_index"))
        try:
            fits = self.engine._optimize_starts(converted, fixed, report_progress=True)
        except JointBoundaryBetterOptimumError:
            raise
        except (RuntimeError, ValueError, FloatingPointError, OverflowError, np.linalg.LinAlgError) as error:
            raise RiskProfileFallback(str(error)) from error
        finally:
            self.engine.progress_callback = None
        finite, accepted = [], []
        for fit in fits:
            params = np.asarray(fit["params"], dtype=float)
            value = self.engine.evaluate(params)[0]
            if not math.isfinite(value):
                continue
            core, zero = self._joint_coordinates(params)
            difference = self._validated_difference(params, core, zero, vector, logit)
            if difference < -1e-7:
                raise JointBoundaryBetterOptimumError("Risk profile found a better likelihood than the stored joint fit.")
            finite.append((params, core, zero, difference))
            if np.any(np.abs(params[self.parent.type_count:]) >= self.engine.coefficient_bound - .1):
                raise RiskProfileFallback("An odds profile candidate reached the shared-feature trial bound.")
            if fit["converged"] and self._unrestricted_kkt(params, fixed) < KKT_TOLERANCE:
                accepted.append(finite[-1])
        if not accepted:
            raise RiskProfileFallback("The unrestricted odds profile KKT check failed.")
        reference = accepted[0][0]
        best = min(accepted, key=lambda candidate: self.engine._loss_change(candidate[0], reference))
        tolerance = min(1e-8, _loss_tolerance(self.engine.evaluate(best[0])[0]))
        if any(self.engine._loss_change(candidate[0], best[0]) < -tolerance for candidate in finite):
            raise RiskProfileFallback("An unvalidated nuisance candidate has a better likelihood.")
        # Prefer an already-found exact boundary when likelihoods are
        # numerically equivalent. Never round a small positive odds to zero;
        # every eligible candidate has independently passed unrestricted KKT.
        best = max((candidate for candidate in accepted
                    if self.engine._loss_change(candidate[0], best[0]) <= tolerance),
                   key=lambda candidate: int(np.count_nonzero(
                       candidate[0][:self.parent.type_count] == 0.)))
        if any(self.engine._loss_change(candidate[0], best[0]) < -tolerance for candidate in finite):
            raise RiskProfileFallback("An unvalidated nuisance candidate has a better likelihood.")
        params, core, zero, difference = best
        # The closure certificate changes the nuisance parameterization, not
        # the joint engine's independent numerical acceptance conditions.
        # Confirm this one face with its original score, tail, curvature and
        # reentry checks, instead of repeating the whole face/start search.
        constraint = (vector, logit)
        try:
            ray = self.parent._face_certificate(zero, vector)
            if ray is None:
                raise RiskProfileFallback("The odds face has no joint recession certificate.")
            offset, transform = self.parent._face_coordinates(zero, constraint)
            checked = self.parent._optimize(core, zero, offset, transform, constraint)
            core = np.asarray(checked["core"], dtype=float)
            params = self._convert_start(core)
            params[:self.parent.type_count][np.array([
                np.any(zero[self.engine.type_index == index])
                for index in range(self.parent.type_count)])] = 0.
            difference = self._validated_difference(params, core, zero, vector, logit)
            if difference < -1e-7:
                raise JointBoundaryBetterOptimumError("Joint confirmation found a better likelihood than the stored fit.")
            if not checked["converged"]:
                raise RiskProfileFallback("The joint confirmation did not establish nuisance stationarity.")
            reentry = self.parent._reentry_validation(checked["core"], zero, ray, constraint)
            if not reentry["valid"] or reentry.get("flat_groups"):
                raise RiskProfileFallback("The joint face requires the original reentry search.")
            if self._unrestricted_kkt(params, fixed) >= KKT_TOLERANCE:
                raise RiskProfileFallback("Joint confirmation disagrees with unrestricted odds KKT.")
        except JointBoundaryBetterOptimumError:
            raise
        except (RuntimeError, ValueError, FloatingPointError, OverflowError, np.linalg.LinAlgError) as error:
            raise RiskProfileFallback(str(error)) from error
        value = (max(float(difference), 0.), core.copy(), zero.copy(), params.copy())
        self._cache[key] = value
        return value[0], value[1].copy(), value[2].copy()
