"""Lossless references between the completed Analyze summary views.

The envelope is private to the snapshot codec. Actual artifact dictionaries,
including unknown keys and rows that differ from the final state, stay intact.
Only the small view lists are rebuilt; the final state is never deep-copied.
"""
from __future__ import annotations

from decimal import Decimal
import struct


FORMAT = "analyze-summary-tables-v1"
_SUMMARY_FIELDS = (
    "sample_id", "sample_key", "node", "chain", "status", "test_group_key",
    "row_group_key", "row_group_dimensions",
)
_SUMMARY_LIST_FIELDS = frozenset((
    "sample_key", "test_group_key", "row_group_key", "row_group_dimensions",
))


def _fingerprint(value):
    """Return a small candidate key; an exact comparison always follows it."""
    kind = type(value)
    if kind is dict:
        return hash((kind, tuple((_fingerprint(key), _fingerprint(item))
                                 for key, item in value.items())))
    if kind in (list, tuple):
        return hash((kind, tuple(_fingerprint(item) for item in value)))
    if kind is float:
        return hash((kind, struct.pack("!d", value)))
    if kind is Decimal:
        return hash((kind, value.as_tuple()))
    if kind in (str, bool, int, type(None)):
        return hash((kind, value))
    # Unrecognized mutable values can still share their identical object, but
    # are not coalesced based on overloaded or approximate equality.
    return hash((kind, id(value)))


def _same_value(left, right):
    if left is right:
        return True
    kind = type(left)
    if kind is not type(right):
        return False
    if kind is dict:
        return (len(left) == len(right)
                and all(_same_value(a, b) and _same_value(left[a], right[b])
                        for a, b in zip(left, right)))
    if kind in (list, tuple):
        return len(left) == len(right) and all(_same_value(a, b) for a, b in zip(left, right))
    if kind is float:
        return struct.pack("!d", left) == struct.pack("!d", right)
    if kind is Decimal:
        return left.as_tuple() == right.as_tuple()
    return kind in (str, bool, int, type(None)) and left == right


def _row_key(row):
    if type(row) is dict and all(name in row for name in ("sample_key", "node", "test_group_key")):
        # The ordinary path avoids hashing long raw-column and metadata lists.
        return hash(("identity", *(_fingerprint(row[name]) for name in ("sample_key", "node", "test_group_key"))))
    return hash(("value", _fingerprint(row)))


def _is_projection(row, final):
    if type(row) is not dict or type(final) is not dict or tuple(row) != _SUMMARY_FIELDS:
        return False
    for name in _SUMMARY_FIELDS:
        if name not in final or not _same_value(row[name], final[name]):
            return False
        value = final[name]
        if name in _SUMMARY_LIST_FIELDS:
            if type(value) is not list or any(type(item) is not str for item in value):
                return False
        elif type(value) is not str:
            return False
    return True


def pack_summary_artifacts(artifacts: dict) -> dict:
    """Share exact final-state rows and their standard summary projections."""
    if type(artifacts) is not dict:
        raise ValueError("Invalid Analyze summary artifacts")
    packed = dict(artifacts)
    views = {}
    final = artifacts.get("final_status_rows")
    view_names = [name for name in ("merged_outlier_rows", "summary_rows")
                  if type(artifacts.get(name)) is list and artifacts[name]]
    if type(final) is list and view_names:
        by_object, by_key = {}, {}
        for index, row in enumerate(final):
            by_object[id(row)] = index
            key = _row_key(row)
            previous = by_key.get(key)
            if previous is None:
                by_key[key] = index
            elif type(previous) is int:
                by_key[key] = [previous, index]
            else:
                previous.append(index)
        for name in view_names:
            rows = artifacts[name]
            entries, reference_count = [], 0
            for row in rows:
                index = by_object.get(id(row)) if name == "merged_outlier_rows" else None
                if index is None:
                    matches = _same_value if name == "merged_outlier_rows" else _is_projection
                    candidates = by_key.get(_row_key(row), ())
                    if type(candidates) is int:
                        candidates = (candidates,)
                    index = next((candidate for candidate in candidates
                                  if matches(row, final[candidate])), None)
                if index is None:
                    entries.append({"row": row})
                else:
                    entries.append(index)
                    reference_count += 1
            if reference_count:
                packed[name] = entries
                views[name] = "full" if name == "merged_outlier_rows" else list(_SUMMARY_FIELDS)
    return {"format": FORMAT, "artifacts": packed, "views": views}


def unpack_summary_artifacts(encoded: dict) -> dict:
    """Restore views, rejecting invalid references before exposing artifacts."""
    if (type(encoded) is not dict or set(encoded) != {"format", "artifacts", "views"}
            or encoded.get("format") != FORMAT or type(encoded.get("artifacts")) is not dict
            or type(encoded.get("views")) is not dict):
        raise ValueError("Invalid saved Analyze summary tables")
    result = dict(encoded["artifacts"])
    final = result.get("final_status_rows")
    for name, mode in encoded["views"].items():
        full = name == "merged_outlier_rows" and mode == "full"
        projection = name == "summary_rows" and type(mode) is list and mode == list(_SUMMARY_FIELDS)
        entries = result.get(name)
        if not (full or projection) or type(final) is not list or type(entries) is not list:
            raise ValueError("Invalid saved Analyze summary view")
        rows = []
        for entry in entries:
            if type(entry) is int:
                if not 0 <= entry < len(final):
                    raise ValueError("Invalid saved Analyze summary row reference")
                row = final[entry]
                if projection:
                    if type(row) is not dict or any(name not in row for name in _SUMMARY_FIELDS):
                        raise ValueError("Invalid saved Analyze summary projection")
                    projected = {name: row[name] for name in _SUMMARY_FIELDS}
                    if not _is_projection(projected, row):
                        raise ValueError("Invalid saved Analyze summary projection")
                    # Summary lists were independent when the analysis was built.
                    row = {name: list(value) if name in _SUMMARY_LIST_FIELDS else value
                           for name, value in projected.items()}
                rows.append(row)
            elif type(entry) is dict and set(entry) == {"row"}:
                rows.append(entry["row"])
            else:
                raise ValueError("Invalid saved Analyze summary view entry")
        result[name] = rows
    return result
