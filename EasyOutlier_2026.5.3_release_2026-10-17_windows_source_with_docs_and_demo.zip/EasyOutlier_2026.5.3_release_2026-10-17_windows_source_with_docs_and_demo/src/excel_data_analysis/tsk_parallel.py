"""Bounded process parallelism for independent TSK fits.

Only the parent reports progress. Layouts are sent once per worker, native
numeric libraries use one thread, and nested analyses share the outer budget.
"""
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from concurrent.futures.process import BrokenProcessPool
from dataclasses import dataclass
from functools import wraps
import logging
import math
import multiprocessing
from numbers import Integral
import os
from queue import Empty, Full
import threading
import sys
import shlex
from time import monotonic

from .compute_resources import limit_process_workers, process_tsk_budget
from .tsk_compute_budget import (compute_slot, yield_coordinator_slot, current_budget,
                                 current_group_id, current_role, group_worker_limit, install_leaf)
from .tsk_elastic_pool import make_pool, grow_pool


_SPAWN_ENV_LOCK = threading.RLock()
_THREAD_ENV = ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS", "VECLIB_MAXIMUM_THREADS",
               "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS")
_IN_WORKER = False
_COMMON = None
_FUNCTION = None
_THREAD_LIMIT = None
_STARTUP_GATE = None
_STARTUP_QUEUE = None
_PROGRESS_QUEUE = None


def require_parallel_runtime():
    """Report missing native-thread controls before starting failing children."""
    try:
        from threadpoolctl import threadpool_limits
    except ImportError as error:
        if getattr(sys, "frozen", False):
            remedy = "请重新安装包含完整依赖的程序包。"
        else:
            command = ([sys.executable, "-m", "pip", "install", "threadpoolctl>=3.1,<4"])
            formatted = (f'& "{sys.executable}" -m pip install "threadpoolctl>=3.1,<4"'
                         if os.name == "nt" else shlex.join(command))
            remedy = f"请在启动本程序的 Python 环境执行：\n{formatted}"
        raise RuntimeError(f"多进程计算依赖 threadpoolctl 无法加载：{error}\n{remedy}\n安装后请重新启动程序。") from error
    return threadpool_limits


@dataclass(frozen=True)
class _WorkerResult:
    value: object
    pid: int
    detail: object = None


class _Heartbeat:
    """Coalesced progress and opt-in module snapshots; work never waits on IPC."""

    def __init__(self, report=None, poll=None):
        self.report, self.poll = report, poll
        self.started = monotonic()
        self.last_sent = None
        self.latest = None
        self.sequence = 0

    def __call__(self, detail=None):
        if self.poll is not None:
            self.poll()
        if self.report is None:
            return
        result_changed = False
        if isinstance(detail, dict):
            # Keep the pipe payload small even if a caller supplies a full context.
            tasks = (self.latest or {}).get("tasks")
            result_snapshot = (self.latest or {}).get("result_snapshot")
            result_sequence = (self.latest or {}).get("result_sequence")
            self.latest = {"message": str(detail.get("message", ""))[:768]}
            value = detail.get("progress")
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                self.latest["progress"] = max(0., min(100., float(value)))
            if isinstance(detail.get("tasks"), (list, tuple)):
                # A small cumulative stage snapshot survives best-effort IPC
                # and 1 Hz coalescing. Never transfer designs or solver state.
                tasks = []
                for source in detail["tasks"][:8]:
                    if not isinstance(source, dict):
                        continue
                    task = {key: str(source[key])[:limit] for key, limit in (
                        ("task_id", 64), ("label", 160), ("state", 24), ("message", 512)) if key in source}
                    for key in ("progress", "elapsed_seconds", "completed", "total"):
                        value = source.get(key)
                        if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value):
                            task[key] = value
                    tasks.append(task)
            if tasks is not None:
                self.latest["tasks"] = tasks
            if isinstance(detail.get("result_snapshot"), dict) and detail.get("result_sequence") != result_sequence:
                # Explicit module snapshots contain display output only. Keep
                # the latest one across ordinary progress updates so queue
                # coalescing or saturation cannot lose a completed module.
                from .tsk_result_state import compact_tsk_result

                source = detail["result_snapshot"]
                result_snapshot = compact_tsk_result({"groups": [source]})["groups"][0]
                result_snapshot.pop("saved_display_only", None)
                if "diagnostics" not in source:
                    result_snapshot.pop("diagnostics", None)
                result_snapshot.update({key: source[key] for key in ("analysis_status", "completed_modules") if key in source})
                result_sequence = detail["result_sequence"]
                result_changed = True
            if result_snapshot is not None:
                self.latest.update(result_snapshot=result_snapshot, result_sequence=result_sequence)
        if self.latest is None:
            return
        now = monotonic()
        if result_changed or self.last_sent is None or now - self.last_sent >= 1.:
            self.last_sent = now
            self.report(self.event(now=now))

    # Jobs can detect this method while still accepting older zero-argument
    # heartbeat functions supplied by external callers or test adapters.
    detail = __call__

    def event(self, *, now=None, completed=False):
        if self.latest is None:
            return None
        self.sequence += 1
        detail = dict(self.latest)
        if "tasks" in detail:
            detail["tasks"] = [dict(task) for task in detail["tasks"]]
        return {**detail, "elapsed_seconds": max(0., (monotonic() if now is None else now) - self.started),
                "pid": os.getpid(), "sequence": self.sequence,
                "phase": "completed" if completed else "running"}


def in_parallel_worker():
    return _IN_WORKER


def validate_analysis_workers(workers):
    if isinstance(workers, bool) or not isinstance(workers, Integral) or not 0 <= workers <= 64:
        raise ValueError("analysis_workers must be an integer between 0 and 64 (0 means automatic).")
    return int(workers)


def worker_count(workers, task_count, min_parallel_items=2):
    workers = validate_analysis_workers(workers)
    if (_IN_WORKER and current_role() != "group") or task_count < 2:
        return 1
    if current_role() == "group":
        return min(task_count, group_worker_limit()) if workers != 1 else 1
    if workers == 0:
        if task_count < min_parallel_items:
            return 1
        workers = min(8, process_tsk_budget())
    return limit_process_workers(min(workers, task_count, 61 if os.name == "nt" else 64))


def _initialize(function, common, prepare_common, gate, log_queue=None, progress_queue=None,
                startup_queue=None, compute_budget=None, group_id=None):
    from .process_logging import install_process_logging

    install_process_logging(log_queue)
    threadpool_limits = require_parallel_runtime()

    global _IN_WORKER, _COMMON, _FUNCTION, _THREAD_LIMIT, _STARTUP_GATE, _STARTUP_QUEUE, _PROGRESS_QUEUE
    _IN_WORKER = True
    _FUNCTION, _STARTUP_GATE = function, gate
    _STARTUP_QUEUE = startup_queue
    _PROGRESS_QUEUE = progress_queue
    if progress_queue is not None:
        # Progress is best effort. A full pipe must not hold worker shutdown;
        # the final detail also travels with the task's authoritative result.
        progress_queue.cancel_join_thread()
    _THREAD_LIMIT = threadpool_limits(limits=1)
    parent = multiprocessing.parent_process()
    if parent is not None:
        def parent_died():
            from multiprocessing.connection import wait
            wait([parent.sentinel])
            os._exit(0)
        threading.Thread(target=parent_died, name="tsk-parent-watch", daemon=True).start()
    if compute_budget is not None:
        install_leaf(compute_budget, group_id)
    with compute_slot():
        _COMMON = prepare_common(common) if prepare_common is not None else common


def _ready():
    if _STARTUP_QUEUE is not None:
        # Every worker blocks here until the parent has observed every PID.
        # A fast worker therefore cannot acknowledge on behalf of slow peers.
        # Unlike progress, readiness must never be dropped on a full queue.
        _STARTUP_QUEUE.put(os.getpid())
    # A long-running parent can still hold the earlier Event-based startup
    # protocol while a newly spawned worker imports this updated module.
    # Readiness reporting does not determine which gate API the parent uses.
    acquire = getattr(_STARTUP_GATE, "acquire", None)
    if callable(acquire):
        acquire()
    else:
        _STARTUP_GATE.wait()


def _run(item, index=None, report_activity=False):
    def report(event):
        if report_activity:
            event = {**event, "_started_monotonic": heartbeat.started,
                     "_reported_monotonic": monotonic()}
        try:
            _PROGRESS_QUEUE.put_nowait((index, event))
        except (Full, OSError, ValueError):
            pass
    heartbeat = _Heartbeat(report if _PROGRESS_QUEUE is not None and index is not None else None)
    if report_activity:
        report({"phase": "started", "pid": os.getpid(), "sequence": 0, "elapsed_seconds": 0.})
    with compute_slot():
        value = _FUNCTION(_COMMON, item, heartbeat)
    detail = heartbeat.event(completed=True)
    if report_activity:
        # The result is authoritative even if the best-effort progress queue
        # was full, or this job never emitted a numerical detail.
        detail = {**(detail or {"phase": "completed", "pid": os.getpid(), "sequence": 1,
                              "elapsed_seconds": max(0., monotonic() - heartbeat.started)}),
                  "_started_monotonic": heartbeat.started, "_reported_monotonic": monotonic()}
    return _WorkerResult(value, os.getpid(), detail)


class _MapActivity:
    """Parent-owned activity; no task inputs or statistical results are retained."""

    def __init__(self, callback, total):
        self.callback, self.total = callback, total
        self.active = {}
        self.completed_indices = set()

    def start(self, index, *, local=False):
        if self.callback is not None:
            self.active[index] = {"state": "running" if local else "submitted",
                                  "pid": os.getpid() if local else None,
                                  "started": monotonic(), "last_detail": None, "last_reported": None}

    def event(self, index, event):
        task = self.active.get(index)
        if task is None or event is None:
            return  # A delayed queue message cannot resurrect a completed job.
        now = monotonic()
        # Python's monotonic clock is shared across processes on supported
        # platforms. Fallback also accepts older/mocked worker events.
        task.update(state="running", pid=event.get("pid"),
                    started=event.get("_started_monotonic", now - event.get("elapsed_seconds", 0.)))
        if "message" in event:
            task["last_detail"] = {key: value for key, value in event.items() if not key.startswith("_")}
            if "tasks" in event:
                task["last_detail"]["tasks"] = [dict(stage) for stage in event["tasks"]]
            task["last_reported"] = event.get("_reported_monotonic", now)

    def finish(self, index):
        if self.callback is not None:
            self.active.pop(index, None)
            self.completed_indices.add(index)

    def reset_active(self):
        self.active.clear()

    def report(self, completed):
        if self.callback is None:
            return
        now = monotonic()
        active = [{"index": index, "state": task["state"], "pid": task["pid"],
                   "elapsed_seconds": max(0., now - task["started"]),
                   "last_detail": dict(task["last_detail"]) if task["last_detail"] is not None else None,
                   "last_detail_age_seconds": (max(0., now - task["last_reported"])
                                               if task["last_reported"] is not None else None)}
                  for index, task in sorted(self.active.items())]
        for task in active:
            if task["last_detail"] is not None and "tasks" in task["last_detail"]:
                task["last_detail"]["tasks"] = [dict(stage) for stage in task["last_detail"]["tasks"]]
        self.callback({"completed": completed, "total": self.total,
                       "completed_indices": sorted(self.completed_indices), "active_tasks": active})


def _shutdown(pool, *, terminate=False):
    if pool is None:
        return
    processes = list((getattr(pool, "_processes", None) or {}).values())
    if not terminate:
        pool.shutdown(wait=True, cancel_futures=True)
        _reclaim_shutdown(pool, processes)
        return
    # Python 3.10 lacks the public terminate_workers API.
    processes = list((getattr(pool, "_processes", None) or {}).values())
    for process in processes:
        if process.is_alive():
            process.terminate()
    for process in processes:
        process.join(timeout=.2)
        if process.is_alive():
            process.kill()
            process.join(timeout=2.)
    # The manager can still be handling a worker's exit while join() above
    # races its own reaping. Wait for that thread as well before returning;
    # otherwise cancellation may leave an active child visible to the caller.
    pool.shutdown(wait=True, cancel_futures=True)
    _reclaim_shutdown(pool, processes)


def _reclaim_shutdown(pool, processes):
    budget = getattr(pool, "_tsk_budget", None) or current_budget()
    if budget is not None:
        from .tsk_hybrid_parallel import reclaim_process_tree
        # Workers are joined before their own leases or orphaned descendants
        # can be reclaimed. Never infer worker death from missing progress.
        reclaim_process_tree(budget, [p.pid for p in processes if p.exitcode is not None])


def _dispatch_scope(function):
    @wraps(function)
    def dispatched(*args, **kwargs):
        with yield_coordinator_slot():
            return function(*args, **kwargs)
    return dispatched


@_dispatch_scope
def ordered_parallel_map(function, items, *, common=None, prepare_common=None, workers=0,
                         progress_callback=None, min_parallel_items=2, execution=None,
                         detail_callback=None, activity_callback=None, _cleanup_budget=None,
                         _item_completed=None):
    """Map ``function(common, item, heartbeat)`` in input order.

    ``prepare_common`` builds worker-local reusable state once. The callback is
    called with (completed, total), including while waiting, and may cancel by
    raising. A broken pool during startup is rebuilt once, before any job is
    submitted. Later infrastructure failures retry only unfinished items serially;
    computation exceptions propagate. Completion drives progress and refill;
    only the returned list is ordered. Callers must provide side-effect-free jobs.
    Jobs may call ``heartbeat.detail({"progress": percent, "message": text})``.
    Optional ``detail_callback(index, event)`` runs only in the parent, receives
    at most one live event per second per job plus its final detail, and may
    cancel by raising. Queue saturation drops only progress, never task results.
    Optional ``activity_callback(snapshot)`` runs before each progress callback.
    It supplies successful ``completed_indices`` and ``active_tasks`` (index,
    state, pid, elapsed_seconds, last_detail, last_detail_age_seconds). Submitted
    tasks may still be queued; only an observed worker start/detail establishes
    ``running``. Elapsed time starts at submission until that start is observed.
    The latest detail persists while waiting, even when a job emits no further
    detail. This opt-in interface also tracks jobs without any detail calls;
    existing detail callbacks keep their original event contract. Snapshots
    contain no inputs/results and may cancel by raising.
    """
    items = list(items)
    total = len(items)
    count = worker_count(workers, total, min_parallel_items)
    progress = progress_callback or (lambda *_: None)
    execution = execution if execution is not None else {}
    execution.update(workers_requested=int(workers), workers_used=count,
                     execution_backend="serial" if count == 1 else "spawn_process_pool",
                     execution_warnings=[], worker_pids=[], workers_observed=0,
                     phase="serial" if count == 1 else "starting", completed_tasks=0)
    missing = object()
    output = [missing] * total
    completed = 0
    worker_pids = set()
    local_common = None
    local_ready = False
    activity = _MapActivity(activity_callback, total)

    def report_progress():
        activity.report(completed)
        progress(completed, total)

    def serial_tail():
        nonlocal local_common, local_ready, completed
        execution["phase"] = "serial"
        if not local_ready:
            with compute_slot(poll=report_progress):
                local_common = prepare_common(common) if prepare_common is not None else common
            local_ready = True
        for index, item in enumerate(items):
            if output[index] is not missing:
                continue
            activity.start(index, local=True)

            def report(event):
                activity.event(index, event)
                if activity_callback is not None:
                    report_progress()
                if detail_callback is not None:
                    detail_callback(index, event)

            heartbeat = _Heartbeat(report if detail_callback is not None or activity_callback is not None else None,
                                   poll=report_progress)
            heartbeat()
            with compute_slot(poll=report_progress):
                output[index] = function(local_common, item, heartbeat)
            if detail_callback is not None and heartbeat.latest is not None:
                detail_callback(index, heartbeat.event(completed=True))
            if _item_completed is not None:
                _item_completed(index)
            activity.finish(index)
            completed += 1
            execution["completed_tasks"] = completed
            report_progress()
        execution["phase"] = "completed"
        if not items and activity_callback is not None:
            report_progress()
        return output

    if count == 1 or not items:
        return serial_tail()
    require_parallel_runtime()
    from .process_logging import get_process_log_queue
    pool = None
    pending = {}
    detail_queue = None
    startup_queue = None
    detail_sequences = {}

    def report_detail(index, event):
        if event is None:
            return
        sequence = event.get("sequence", 0)
        if sequence > detail_sequences.get(index, -1):
            detail_sequences[index] = sequence
            activity.event(index, event)
            if detail_callback is not None and "message" in event:
                detail_callback(index, {key: value for key, value in event.items() if not key.startswith("_")})

    def drain_details():
        if detail_queue is None:
            return
        while True:
            try:
                index, event = detail_queue.get_nowait()
            except Empty:
                break
            except (EOFError, OSError, ValueError):
                # Progress transport is optional; authoritative task results
                # still determine success or the infrastructure fallback.
                close_details()
                break
            report_detail(index, event)

    def close_details():
        nonlocal detail_queue
        if detail_queue is not None:
            detail_queue.close()
            detail_queue.cancel_join_thread()
            detail_queue = None

    def close_startup():
        nonlocal startup_queue
        if startup_queue is not None:
            startup_queue.close()
            startup_queue.cancel_join_thread()
            startup_queue = None

    def collect_ready(futures):
        nonlocal completed
        broken = None
        for future in futures:
            index = pending.pop(future)
            if future.cancelled():
                continue  # Infrastructure shutdown cancelled this unstarted item.
            try:
                result = future.result()
            except BrokenProcessPool as error:
                broken = error
                continue
            if isinstance(result, _WorkerResult):
                worker_pids.add(result.pid)
                report_detail(index, result.detail)
                result = result.value
            output[index] = result
            if _item_completed is not None:
                _item_completed(index)
            activity.finish(index)
            completed += 1
        execution.update(completed_tasks=completed, worker_pids=sorted(worker_pids),
                         workers_observed=len(worker_pids), phase="running")
        return broken

    def fallback(error):
        nonlocal pool
        # A submission/startup failure can occur outside wait()'s last ready
        # snapshot. Preserve all already-returned work and propagate any real
        # computation failure, including fit-invalidating numerical errors.
        collect_ready([future for future in pending if future.done()])
        _shutdown(pool, terminate=True)
        pool = None
        collect_ready([future for future in pending if future.done()])
        close_details()
        close_startup()
        activity.reset_active()
        execution.update(workers_used=1, execution_backend="serial_after_process_failure")
        warning = f"TSK 子进程不可用，保留已完成结果，其余串行继续：{type(error).__name__}: {error}"
        execution["execution_warnings"].append(warning)
        logging.getLogger(__name__).warning(warning)
        return serial_tail()

    try:
        report_progress()
        startup_started = monotonic()
        execution.update(startup_attempts=0, startup_failures=[], startup_workers_ready=0,
                         startup_elapsed_seconds=0.)
        for attempt in (1, 2):
            execution.update(startup_attempts=attempt, startup_workers_ready=0)
            startup_pending, startup_pids, startup_processes = set(), set(), []
            startup_released = False
            startup_error = None
            try:
                with _SPAWN_ENV_LOCK:
                    previous = {key: os.environ.get(key) for key in _THREAD_ENV}
                    try:
                        os.environ.update({key: "1" for key in _THREAD_ENV})
                        spawn = multiprocessing.get_context("spawn")
                        # Releasing a semaphore does not wait for the waiter.
                        # Event.set/Condition.notify can block forever if a
                        # worker is killed after ACK but before being woken.
                        gate = spawn.Semaphore(0)
                        startup_queue = spawn.Queue(maxsize=count)
                        if detail_callback is not None or activity_callback is not None:
                            detail_queue = spawn.Queue(maxsize=max(16, 4 * count))
                        pool = make_pool(ProcessPoolExecutor, max_workers=count, mp_context=spawn,
                            initializer=_initialize, initargs=(function, common, prepare_common, gate,
                                get_process_log_queue(), detail_queue, startup_queue, current_budget(), current_group_id()))
                        if _cleanup_budget is not None:
                            pool._tsk_budget = _cleanup_budget
                        for _ in range(count):
                            startup_pending.add(pool.submit(_ready))
                    finally:
                        startup_processes = list((getattr(pool, "_processes", None) or {}).values())
                        for key, value in previous.items():
                            if value is None:
                                os.environ.pop(key, None)
                            else:
                                os.environ[key] = value
            except BrokenProcessPool as error:
                startup_error = error
            except (OSError, RuntimeError) as error:
                return fallback(error)
            while startup_pending and startup_error is None:
                execution["startup_elapsed_seconds"] = max(0., monotonic() - startup_started)
                report_progress()  # Cancellation propagates; it never triggers a retry.
                while len(startup_pids) < count:
                    try:
                        startup_pids.add(startup_queue.get_nowait())
                    except Empty:
                        break
                    except (EOFError, OSError, ValueError) as error:
                        startup_error = BrokenProcessPool(f"Worker readiness channel failed: {error}")
                        break
                execution["startup_workers_ready"] = len(startup_pids)
                if len(startup_pids) == count and not startup_released:
                    for _ in range(count):
                        gate.release()
                    startup_released = True
                ready, startup_pending = wait(startup_pending, timeout=.1, return_when=FIRST_COMPLETED)
                for future in ready:
                    try:
                        future.result()
                    except BrokenProcessPool as error:
                        startup_error = error
            if startup_error is None:
                execution.update(startup_elapsed_seconds=max(0., monotonic() - startup_started),
                                 startup_worker_pids=sorted(startup_pids), phase="running")
                if attempt > 1:
                    logging.getLogger(__name__).info("TSK 进程池重建成功，%s 个进程已就绪，开始计算。", count)
                break
            failure = {"attempt": attempt, "error_type": type(startup_error).__name__,
                       "message": str(startup_error), "processes": [
                           {"pid": process.pid, "exitcode": process.exitcode} for process in startup_processes]}
            _shutdown(pool, terminate=True)
            pool = None
            for record, process in zip(failure["processes"], startup_processes):
                record["cleanup_exitcode"] = process.exitcode
            close_details()
            close_startup()
            execution["startup_failures"].append(failure)
            if attempt == 2:
                return fallback(startup_error)
            codes = ", ".join(f"{record['pid']}:{record['exitcode']}" for record in failure["processes"])
            warning = ("TSK 子进程启动失败，尚未提交计算任务；清理后重建进程池一次 "
                       f"(1/1，PID:退出码 {codes or '不可用'})：{type(startup_error).__name__}: {startup_error}")
            execution["execution_warnings"].append(warning)
            logging.getLogger(__name__).warning(warning)
        next_submit = 0
        while completed < total:
            try:
                count = grow_pool(pool, total - completed, execution) or count
            except (OSError, RuntimeError) as error:
                return fallback(error)
            try:
                while next_submit < total and len(pending) < count:
                    pending[pool.submit(_run, items[next_submit], next_submit,
                                        activity_callback is not None)] = next_submit
                    activity.start(next_submit)
                    next_submit += 1
                report_progress()
                ready, _ = wait(pending, timeout=.1, return_when=FIRST_COMPLETED)
                drain_details()
                broken = collect_ready(ready)
                if broken is not None:
                    return fallback(broken)
            except BrokenProcessPool as error:
                return fallback(error)
            report_progress()
    except BaseException:
        _shutdown(pool, terminate=True)
        pool = None
        raise
    finally:
        try:
            _shutdown(pool)
        finally:
            close_details()
            close_startup()
    execution["phase"] = "completed"
    return output


def start_tsk_process(process):
    """Start a root TSK child with one-thread native-library environment.

    Set this before spawn imports numerical libraries, including Accelerate,
    whose thread count cannot be changed by threadpoolctl after import. The
    launching process' environment is restored on both success and failure.
    """
    with _SPAWN_ENV_LOCK:
        previous = {name: os.environ.get(name) for name in _THREAD_ENV}
        try:
            os.environ.update({name: "1" for name in _THREAD_ENV})
            process.start()
        finally:
            for name, value in previous.items():
                if value is None:
                    os.environ.pop(name, None)
                else:
                    os.environ[name] = value
