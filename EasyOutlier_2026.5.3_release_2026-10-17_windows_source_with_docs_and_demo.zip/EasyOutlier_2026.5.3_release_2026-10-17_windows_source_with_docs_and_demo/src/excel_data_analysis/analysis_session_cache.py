"""Fast, disposable full Analyze snapshots for the current GUI session.

The gzip archive remains authoritative and portable. Pickles are read only when
explicitly supplied by the controller for the same application-owned runtime
job; a durable archive never implicitly discovers a neighboring pickle cache.
"""
from __future__ import annotations

from collections.abc import Mapping
import json
import os
from pathlib import Path
import pickle
import stat
import tempfile

from .analysis_snapshot_state import _ARTIFACTS, _REQUIRED, load_analysis_snapshot
from .database_runtime import RUNTIME_DIRNAME, RUNTIME_OWNER_FILENAME, _OWNER_RECORD, _managed_prefix
from .models import TemplateConfig
from .runtime_lease import RuntimeLease, is_redirected


SESSION_PICKLE_FILENAME = "analysis.pickle"
_ARCHIVE_FILENAME = "analysis.json.gz"


def _plain_file(path: Path, *, missing_ok: bool = False) -> bool:
    try:
        info = path.lstat()
        return (stat.S_ISREG(info.st_mode) and info.st_nlink == 1
                and not is_redirected(path))
    except FileNotFoundError:
        return missing_ok


def _session_cache_path(snapshot_path: str | Path, cache_path: str | Path | None) -> Path | None:
    """Recognize explicit, private siblings without following redirected files."""
    if cache_path is None:
        return None
    try:
        archive, cache = Path(snapshot_path), Path(cache_path)
        if (not archive.is_absolute() or not cache.is_absolute()
                or ".." in archive.parts or ".." in cache.parts
                or archive.name != _ARCHIVE_FILENAME or cache.name != SESSION_PICKLE_FILENAME
                or archive.parent != cache.parent):
            return None
        job, runtime = cache.parent, cache.parent.parent
        if runtime.name != RUNTIME_DIRNAME or _managed_prefix(job.name) is None:
            return None
        if any(is_redirected(path) or not path.is_dir() for path in (job, runtime)):
            return None
        marker = job / RUNTIME_OWNER_FILENAME
        if (not _plain_file(marker) or marker.stat().st_size > 1024
                or json.loads(marker.read_text(encoding="utf-8")) != _OWNER_RECORD
                or not _plain_file(archive) or not _plain_file(cache, missing_ok=True)):
            return None
        return cache
    except (OSError, ValueError, TypeError, RecursionError):
        return None


def _usable_snapshot(snapshot: object) -> bool:
    """Check the full snapshot envelope without traversing every measurement."""
    if not isinstance(snapshot, dict) or not _REQUIRED <= snapshot.keys():
        return False
    if (not isinstance(snapshot["template"], TemplateConfig)
            or not isinstance(snapshot["rows"], list)
            or not isinstance(snapshot["columns"], list)
            or not isinstance(snapshot["zscore_values"], Mapping)
            or not isinstance(snapshot["golden_values"], Mapping)
            or not isinstance(snapshot["sample_node_orders"], dict)
            or not isinstance(snapshot["available_nodes"], list)
            or not isinstance(snapshot["include_point_golden_sheet"], bool)
            or not isinstance(snapshot["fail_mode"], str)
            or not isinstance(snapshot["result"], dict)):
        return False
    artifacts = snapshot["summary_artifacts"]
    return (isinstance(artifacts, dict) and _ARTIFACTS <= artifacts.keys()
            and all(isinstance(artifacts[name], list) for name in _ARTIFACTS))


def _read_pickle(path: Path) -> dict:
    with path.open("rb") as source:
        snapshot = pickle.load(source)
    if not _usable_snapshot(snapshot):
        raise ValueError("Invalid private Analyze snapshot cache")
    return snapshot


def write_session_pickle(snapshot: dict, cache_path: str | Path) -> bool:
    """Atomically replace a private runtime cache, preserving it on failure.

    Cache writes are optional; serialization and I/O failures leave the durable
    archive usable. Interrupts still propagate after temporary-file cleanup.
    """
    temporary = None
    try:
        requested = Path(cache_path)
        archive = requested.with_name(_ARCHIVE_FILENAME)
        cache = _session_cache_path(archive, requested)
        if cache is None or not _usable_snapshot(snapshot):
            return False
        with RuntimeLease(cache.parent.parent):
            # Recheck after taking ownership in case an orphan collector won
            # the race before the lease was acquired.
            if _session_cache_path(archive, cache) is None:
                return False
            with tempfile.NamedTemporaryFile(mode="wb", dir=cache.parent,
                                             prefix=".analysis-cache-", suffix=".tmp",
                                             delete=False) as output:
                temporary = Path(output.name)
                pickle.dump(snapshot, output, protocol=pickle.HIGHEST_PROTOCOL)
            os.replace(temporary, cache)
            temporary = None
        return True
    except Exception:
        # User cancellation/SystemExit are BaseExceptions and must propagate.
        return False
    finally:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass


def load_session_snapshot(snapshot_path: str | Path, cache_path: str | Path | None = None,
                          *, load_archive=load_analysis_snapshot) -> dict:
    """Load a complete snapshot, rebuilding an explicitly permitted cache once."""
    archive = Path(snapshot_path)
    if archive.name.endswith(".pickle"):
        # Compatibility for private files made by older running application
        # versions and explicit direct callers of the report worker, including
        # their historical partial snapshots. Only optional caches require the
        # current full snapshot envelope.
        with archive.open("rb") as source:
            return pickle.load(source)
    cache = _session_cache_path(archive, cache_path)
    if cache is None:
        return load_archive(archive)
    try:
        lease = RuntimeLease(cache.parent.parent)
    except OSError:
        return load_archive(archive)
    with lease:
        if _session_cache_path(archive, cache) is None:
            return load_archive(archive)
        try:
            return _read_pickle(cache)
        except Exception:
            # Missing, truncated, obsolete or structurally invalid caches are
            # disposable; only archive failures should prevent an export.
            pass
        snapshot = load_archive(archive)
        write_session_pickle(snapshot, cache)
        return snapshot
