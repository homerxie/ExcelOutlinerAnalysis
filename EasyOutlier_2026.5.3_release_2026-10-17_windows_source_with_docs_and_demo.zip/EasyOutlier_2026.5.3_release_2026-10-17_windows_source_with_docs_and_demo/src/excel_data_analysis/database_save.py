"""Database save orchestration for background workers, without Qt access."""
from __future__ import annotations

import filecmp
from contextlib import contextmanager
from pathlib import Path
import shutil
from typing import Any, Callable

from .analysis_snapshot_paths import prepare_result_provenance_updates
from .gui_state import save_gui_state
from .database_paths import WORKSPACE_MARKER_FILENAME
from .database_runtime import RUNTIME_DIRNAME, RUNTIME_OWNER_FILENAME, temporary_database_directory
from .repository import Repository
from .service import (
    clear_storage_root,
    delete_storage_workspace,
    describe_storage,
    list_import_history,
    save_storage_workspace,
    save_storage_workspace_as,
)
from .summary_snapshot import prepare_summary_snapshot_for_copy, rebase_summary_snapshot_after_copy
from .workspace import DATABASE_ENTRY_NAMES


def _stage_associated_files(request, source_root: Path, target_root: Path, staging: Path):
    """Retain selected internal files before the workspace merge clears entries."""
    settings = request["gui_state"]
    paths, bases = settings.get("paths", {}), settings.get("path_bases", {})
    configured = []
    for key, value in request.get("associated_paths", {}).items():
        if not value or bases.get(key) != "database":
            continue
        relative = Path(paths.get(key, ""))
        if relative.is_absolute() or ".." in relative.parts or not relative.parts:
            continue
        configured.append((key, value, relative))
    # Imported files can live in custom database folders and need not remain
    # selected in the current input control. Retain every referenced internal
    # source before merging or retiring the workspace.
    entries = Repository(request["storage_path"]).load_dataset_entries()
    for index, entry in enumerate(entries):
        value = entry.get("source_file")
        if not isinstance(value, str) or not value:
            continue
        source = Path(value).absolute()
        for base in (source_root / "temp", source_root):
            if source.is_relative_to(base):
                configured.append((f"import_source_{index}", value, source.relative_to(base)))
                break
    # Summary navigation belongs to the completed run. Its Golden can differ
    # from the file currently selected in the editable GUI controls.
    snapshot = request.get("summary_snapshot")
    golden = snapshot.get("context", {}).get("golden_path") if isinstance(snapshot, dict) else None
    if golden:
        source = Path(golden).absolute()
        for base in (source_root / "temp", source_root):
            if source.is_relative_to(base):
                configured.append(("summary_golden_path", golden, source.relative_to(base)))
                break
    staged = {}
    destinations = {}
    active_storage = Path(request["storage_path"]).absolute()
    marked_workspace = (active_storage / WORKSPACE_MARKER_FILENAME).is_file()
    for key, value, relative in configured:
        source = Path(value).absolute()
        if not source.is_relative_to(source_root) or not source.is_file():
            continue
        destination = target_root / relative
        if key != "summary_golden_path" and destination in destinations:
            previous = destinations[destination]
            if not filecmp.cmp(source, previous, shallow=False):
                raise ValueError(
                    f"Cannot save two different internal files to {destination}: {previous} and {source}. "
                    "Give these source files different database-relative locations before saving."
                )
            continue
        if key != "summary_golden_path":
            destinations[destination] = source
        if key.startswith("import_source_") and marked_workspace and source.is_relative_to(active_storage):
            bulk_relative = source.relative_to(active_storage)
            if bulk_relative.parts[0] in DATABASE_ENTRY_NAMES and destination == target_root / bulk_relative:
                # These original imports are already retained by the bulk
                # workspace copy. Keep collision checks above without staging
                # and copying every large historical workbook a second time.
                continue
        temporary = staging / key
        shutil.copy2(source, temporary)
        staged[key] = (temporary, destination)
    return staged


def _copy_associated_file(source: Path, destination: Path, *, preserve_current: bool = False) -> bool:
    if preserve_current and destination.is_file() and not filecmp.cmp(source, destination, shallow=False):
        return False
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    return True


@contextmanager
def _copied_runtime_state(request, source_root: Path, target_root: Path):
    """Transfer live worker files on Save As without mutating UI-owned state."""
    directories, paths = {}, {}
    try:
        if source_root != target_root:
            runtime_root = source_root / RUNTIME_DIRNAME
            sources = {}
            for attribute, value in request.get("runtime_directories", {}).items():
                source = Path(value).absolute()
                if (source == runtime_root or not source.is_relative_to(runtime_root)
                        or not source.resolve().is_relative_to(runtime_root.resolve())
                        or not source.is_dir() or source.is_symlink()):
                    raise ValueError("Live runtime directory must belong to the source database")
                if any(path.is_symlink() for path in source.rglob("*")):
                    raise ValueError("Live runtime files must not be symbolic links")
                directory = temporary_database_directory(target_root, prefix="saved-")
                directories[attribute] = directory
                # The target's lease/ownership marker belongs to this new
                # runtime directory, not the source being transferred.
                shutil.copytree(source, directory.name, dirs_exist_ok=True,
                                ignore=lambda _directory, names: {RUNTIME_OWNER_FILENAME} & set(names))
                sources[source] = Path(directory.name)
            for attribute, value in request.get("runtime_paths", {}).items():
                if not value:
                    continue
                source = Path(value).absolute()
                for directory, target in sources.items():
                    if source.is_relative_to(directory):
                        destination = target / source.relative_to(directory)
                        if not destination.is_file():
                            raise ValueError("Live runtime file is missing from its database directory")
                        paths[attribute] = str(destination)
                        break
                else:
                    # Durable snapshots already saved below result/analysis
                    # are handled by the normal saved snapshot reference.
                    if source.is_relative_to(runtime_root):
                        raise ValueError("Live runtime file has no owning directory")
        yield directories, paths
    except BaseException:
        for directory in directories.values():
            directory.cleanup()
        raise


def save_database_job(
    request: dict[str, Any],
    progress_callback: Callable[[int, str], None] | None = None,
) -> dict[str, Any]:
    """Save a frozen GUI request and prepare everything needed for UI completion.

    The caller captures widget values before dispatch. Nonnegative progress
    values mark completed stages; -1 requests an indeterminate indicator while
    performing disk operations whose work cannot be counted in advance.
    """
    progress = progress_callback or (lambda _value, _message: None)
    source_root = Path(request["source_root"]).resolve()
    target_root = Path(request["target_root"]).resolve()
    save_as = source_root != target_root
    if save_as and (target_root.is_relative_to(source_root) or source_root.is_relative_to(target_root)):
        raise ValueError("The saved database folder must not contain, or be inside, the source database folder.")
    # The request is already detached from the UI. Copy only the dictionaries
    # this job changes, avoiding another copy of potentially large TSK results.
    gui_state = dict(request["gui_state"])
    results = gui_state.get("current_results")
    results = dict(results) if isinstance(results, dict) else {}
    gui_state["current_results"] = results
    provenance_updates = prepare_result_provenance_updates(results, request["storage_path"])

    progress(0, "Preparing database save")
    progress(-1, "Checking saved analysis navigation")
    prepared = prepare_summary_snapshot_for_copy(request.get("summary_snapshot"), request["storage_path"])
    progress(15, "Analysis navigation checked")

    progress(-1, "Compacting and copying database" if save_as else "Compacting and merging database")
    with temporary_database_directory(source_root, prefix="save-files-") as temporary:
        associated = _stage_associated_files(request, source_root, target_root, Path(temporary))
        # Custom input/template folders are not part of the workspace entry
        # list. Copy them first so source identities can be rebased during Save
        # As, then restore all selected files after the bulk entries are merged.
        for key, (staged, destination) in associated.items():
            if destination.relative_to(target_root).parts[0] not in DATABASE_ENTRY_NAMES:
                _copy_associated_file(staged, destination, preserve_current=key == "summary_golden_path")
        if save_as:
            workspace_merge = save_storage_workspace_as(
                storage_root_path=str(source_root), target_storage_root_path=str(target_root),
            )
        else:
            workspace_merge = save_storage_workspace(str(source_root))
        for key, (staged, destination) in associated.items():
            if not _copy_associated_file(staged, destination, preserve_current=key == "summary_golden_path"):
                # The active workspace/current GUI file owns this destination.
                # Summary validation must reject a changed reference, rather
                # than reverting newer user data to an old run's Golden.
                continue
            relative = destination.relative_to(target_root)
            if save_as and relative.parts[0] in DATABASE_ENTRY_NAMES and (target_root / "temp").is_dir():
                _copy_associated_file(staged, target_root / "temp" / relative)
    progress(55, "Database files saved")

    progress(-1, "Updating saved analysis paths")
    snapshot = rebase_summary_snapshot_after_copy(prepared, source_root, target_root, target_root)
    results["plot_inspector_snapshot"] = snapshot
    progress(65, "Analysis paths updated")

    progress(-1, "Saving analysis results and settings")
    settings_file = save_gui_state(target_root, gui_state, source_storage_path=request["storage_path"])
    progress(80, "Analysis results and settings saved")

    workspace_cleanup = None
    cleanup_error = None
    progress(-1, "Refreshing database overview")
    template_path = str(associated["template_path"][1]) if "template_path" in associated else request.get("template_path")
    overview = describe_storage(str(target_root), template_path=template_path or None, limit=500)
    entries = list_import_history(str(target_root))
    progress(95, "Database overview refreshed")

    with _copied_runtime_state(request, source_root, target_root) as (runtime_directories, runtime_paths):
        # Keep the working source until all required save and refresh work has
        # succeeded. Cleanup failure cannot invalidate a committed database save.
        cleanup = None
        if not save_as:
            progress(-1, "Removing saved temporary workspace")
            cleanup = delete_storage_workspace
        elif request.get("clear_default_source"):
            progress(-1, "Clearing saved default temporary database")
            cleanup = clear_storage_root
        if cleanup is not None:
            try:
                workspace_cleanup = cleanup(str(source_root))
            except Exception as exc:
                cleanup_error = str(exc)
        progress(100, "Database saved")
        return {
            "root": str(target_root),
            "settings_file": str(settings_file),
            "gui_state": gui_state,
            "provenance_updates": provenance_updates,
            "snapshot": snapshot,
            "workspace_merge": workspace_merge,
            "workspace_cleanup": workspace_cleanup,
            "overview": overview,
            "entries": entries,
            "cleanup_error": cleanup_error,
            "runtime_directories": runtime_directories,
            "runtime_paths": runtime_paths,
        }
