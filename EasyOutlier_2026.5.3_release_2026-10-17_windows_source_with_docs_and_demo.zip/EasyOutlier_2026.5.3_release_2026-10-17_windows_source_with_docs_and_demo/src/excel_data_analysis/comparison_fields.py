"""Resolve Plot Inspector fields without confusing rows, headers and metadata."""
from __future__ import annotations

from .field_names import FieldNames, field_key, row_fields


BUILTIN_LABELS = {
    "display_label": "Display Label",
    "logical_metric": "Logical Metric",
    "analysis_group_id": "Analysis Group ID",
    "analysis_group_name": "Analysis Group Name",
    "raw_column": "Raw Column",
    "unit": "Unit",
    "lane_has_outlier": "Lane Has Outlier",
    "metric_has_outlier": "Metric Has Outlier",
}
_BUILTINS = FieldNames(BUILTIN_LABELS, [
    ("has_outlier", "lane_has_outlier"),
    ("analysis_group_display_name", "analysis_group_name"),
])


def resolve_comparison_field(field_name, *, rows=None, headers=(), allow_missing_headers=False):
    scopes = {"builtin": _BUILTINS, "column_header": FieldNames(headers)}
    if rows is not None:
        scopes["row_dimension"] = rows
    text = str(field_name).strip()
    prefix, separator, remainder = text.partition(":")
    if separator:
        prefix = {field_key(scope): scope for scope in scopes}.get(field_key(prefix), prefix)
    if separator and prefix in scopes:
        strict = not (prefix == "column_header" and allow_missing_headers)
        return prefix, scopes[prefix].resolve(remainder, strict=strict)
    matches = []
    for scope, names in scopes.items():
        name = names.resolve(text)
        if name in names.names:
            matches.append((scope, name))
    if len(matches) > 1:
        alternatives = ", ".join(f"{scope}:{name}" for scope, name in matches)
        raise ValueError(f"Ambiguous plot field / 绘图字段存在歧义: {text!r}. Use {alternatives}.")
    return matches[0] if matches else ("column_header", text)


def resolve_plot_field(template, field_name):
    return resolve_comparison_field(
        field_name, rows=row_fields(template),
        headers=(level.name for level in template.column_header_levels),
    )


def plot_field_choices(template, readable_name):
    candidates = [("builtin", name, label) for name, label in BUILTIN_LABELS.items()]
    candidates.extend(("row_dimension", item.name, item.display_name or readable_name(item.name))
                      for item in sorted(template.row_dimensions, key=lambda item: item.priority))
    candidates.extend(("column_header", item.name, item.name)
                      for item in sorted(template.column_header_levels, key=lambda item: item.priority))
    choices = []
    for scope, name, label in candidates:
        try:
            resolved = resolve_plot_field(template, label)
        except ValueError:
            resolved = None
        # Canonical names also disambiguate duplicate display names.
        choice = label if resolved == (scope, name) else f"{scope}:{name}"
        if choice not in choices:
            choices.append(choice)
    return choices
