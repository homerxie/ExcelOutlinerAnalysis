from __future__ import annotations

from array import array
from collections import defaultdict
from collections.abc import Iterator, Sequence
from functools import lru_cache
from itertools import repeat
from statistics import mean, median, pstdev

from .golden_rules import (
    MODIFIED_ZSCORE_SCALE,
    compute_outlier_golden_allowed_ranges,
    compute_outlier_golden_display_bounds,
    evaluate_outlier_golden_rule,
    validate_golden_rule_config,
)
from .field_names import FieldNames
from .models import (
    AnomalyResult,
    GoldenAllowedRange,
    GoldenMetricRange,
    GoldenReference,
    GoldenRuleConfig,
    MeasurementRecord,
)
from .zscore_cache import PopulationFingerprint, ZScoreCache, golden_cache_key


def _format_optional_bound(value: float | None) -> str:
    return "None" if value is None else str(value)


def _measurement_dimension_fields(measurements: Sequence[MeasurementRecord]) -> FieldNames:
    # Imported rows can have different schemas after a template refresh. The
    # first record alone does not describe all available stored dimensions.
    return FieldNames({name for record in measurements for name in record.dimensions})


def _dimension_key(record: MeasurementRecord, names: Sequence[str], purpose: str) -> tuple[tuple[str, str], ...]:
    if not names:
        return ()
    missing = [name for name in names if name not in record.dimensions]
    if missing:
        raise ValueError(
            f"Missing {purpose} dimensions in stored measurements: {', '.join(missing)}. "
            f"dataset={record.dataset_id}, row={record.row_number}. "
            "Populate these dimensions before grouping the measurements."
        )
    return tuple((name, record.dimensions[name]) for name in names)


def _format_golden_metric_context(
    *,
    reference_key: tuple[tuple[str, str], ...],
    logical_metric: str,
    group_id: str,
    rule: GoldenRuleConfig,
    center: float,
    stdev: float,
    sample_size: int,
) -> str:
    reference_text = (
        ", ".join(f"{key}={value}" for key, value in reference_key)
        if reference_key
        else "<global>"
    )
    return (
        f"logical_metric={logical_metric}, group_id={group_id}, "
        f"reference_key={reference_text}, sample_size={sample_size}, "
        f"center={center}, stdev={stdev}, "
        f"outlier_golden_method={rule.outlier_golden_method}, "
        f"relative_limit={_format_optional_bound(rule.relative_limit)}, "
        f"sigma_multiplier={_format_optional_bound(rule.sigma_multiplier)}, "
        f"mad_multiplier={_format_optional_bound(rule.mad_multiplier)}, "
        f"absolute_lower_bound={_format_optional_bound(rule.absolute_lower_bound)}, "
        f"absolute_upper_bound={_format_optional_bound(rule.absolute_upper_bound)}, "
        f"overwrite_lowerbound={_format_optional_bound(rule.overwrite_lowerbound)}, "
        f"overwrite_upperbound={_format_optional_bound(rule.overwrite_upperbound)}, "
        f"continuous_interval={rule.continuous_interval}, "
        f"empty_range_fallback_to_absolute={rule.empty_range_fallback_to_absolute}"
    )


def build_golden_reference(
    name: str,
    measurements: list[MeasurementRecord],
    reference_dimensions: list[str],
    filters: dict[str, str] | None = None,
    center_method: str = "mean",
    outlier_golden_method: str = "relative",
    relative_limit: float | None = 0.2,
    sigma_multiplier: float | None = 3.0,
    absolute_lower_bound: float | None = None,
    absolute_upper_bound: float | None = None,
    overwrite_lowerbound: float | None = None,
    overwrite_upperbound: float | None = None,
    continuous_interval: bool = False,
    empty_range_fallback_to_absolute: bool = False,
    group_rule_overrides: dict[str, GoldenRuleConfig] | None = None,
    mad_multiplier: float | None = 3.5,
    reference_node_dimension: str | None = None,
    column_reference_nodes: dict[str, str] | None = None,
    dimension_names: Sequence[str] | None = None,
) -> GoldenReference:
    filters = filters or {}
    column_reference_nodes = {
        name: str(node).strip() for name, node in (column_reference_nodes or {}).items()
        if node is not None and str(node).strip()
    }
    reference_column_names = sorted({record.raw_column for record in measurements})
    column_reference_nodes = FieldNames(reference_column_names).mapping(column_reference_nodes)
    if column_reference_nodes and not reference_node_dimension:
        raise ValueError("Golden Reference Node requires a reference_node_dimension.")
    fields = (FieldNames(dimension_names) if dimension_names is not None else
              _measurement_dimension_fields(measurements)
              if reference_dimensions or filters or reference_node_dimension else FieldNames(()))
    reference_dimensions = [fields.resolve(name, strict=True) for name in reference_dimensions]
    filters = fields.mapping(filters, strict=True)
    if reference_node_dimension:
        reference_node_dimension = fields.resolve(reference_node_dimension, strict=bool(column_reference_nodes))
    if center_method not in {"mean", "median"}:
        raise ValueError(f"Unsupported center_method: {center_method}")
    normalized_default_method = validate_golden_rule_config(
        "Global golden rule",
        outlier_golden_method,
        relative_limit,
        sigma_multiplier,
        absolute_lower_bound,
        absolute_upper_bound,
        overwrite_lowerbound,
        overwrite_upperbound,
        continuous_interval,
        empty_range_fallback_to_absolute,
        mad_multiplier=mad_multiplier,
    )
    grouped: dict[tuple[tuple[str, str], str, str], list[float]] = defaultdict(list)
    source_nodes = defaultdict(lambda: defaultdict(set))
    other_filters = {key: value for key, value in filters.items() if key != reference_node_dimension}
    requested_sources = set()
    matched_sources = set()
    selectors_by_pool = defaultdict(set)
    overridden_pools = set()

    for record in measurements:
        if column_reference_nodes:
            if not _match_dimensions(record.dimensions, other_filters):
                continue
            forced_node = column_reference_nodes.get(record.raw_column)
            scope_key = _dimension_key(
                record, [dimension for dimension in reference_dimensions if dimension != reference_node_dimension],
                "Golden reference",
            )
            source_key = (scope_key, record.logical_metric, record.raw_column, forced_node)
            if forced_node is not None:
                requested_sources.add(source_key)
            pool_key = (scope_key, record.logical_metric)
            if reference_node_dimension in reference_dimensions:
                selector = ((forced_node,) if forced_node is not None else
                            _filter_values(filters[reference_node_dimension]) if reference_node_dimension in filters else None)
                selectors_by_pool[pool_key].add(selector)
                if forced_node is not None:
                    overridden_pools.add(pool_key)
            if forced_node is not None:
                if record.dimensions.get(reference_node_dimension) != forced_node:
                    continue
                matched_sources.add(source_key)
            elif not _match_dimensions(record.dimensions, filters):
                continue
        elif not _match_dimensions(record.dimensions, filters):
            continue
        reference_key = _dimension_key(record, reference_dimensions, "Golden reference")
        group_key = (reference_key, record.logical_metric, record.group_id)
        grouped[group_key].append(record.value)
        nodes = source_nodes[group_key][record.raw_column]
        if reference_node_dimension and reference_node_dimension in record.dimensions:
            nodes.add(record.dimensions[reference_node_dimension])

    missing_sources = requested_sources - matched_sources
    if missing_sources:
        scope_key, metric, raw_column, node = sorted(missing_sources)[0]
        raise ValueError(
            "Golden Reference Node has no matching reference measurements: "
            f"raw_column={raw_column}, logical_metric={metric}, "
            f"{reference_node_dimension}={node}, reference_key={dict(scope_key)}. "
            "Check the requested node and the remaining Golden filters."
        )
    if any(len(selectors_by_pool[key]) > 1 for key in overridden_pools):
        raise ValueError(
            "Golden Reference Node cannot select different source nodes within a pooled logical metric "
            f"while {reference_node_dimension!r} is also a Golden reference dimension. "
            "Remove the node from reference dimensions or choose the same reference node for the pooled columns."
        )

    metrics: list[GoldenMetricRange] = []
    default_rule = GoldenRuleConfig(
        outlier_golden_method=normalized_default_method,
        relative_limit=relative_limit,
        sigma_multiplier=sigma_multiplier,
        absolute_lower_bound=absolute_lower_bound,
        absolute_upper_bound=absolute_upper_bound,
        overwrite_lowerbound=overwrite_lowerbound,
        overwrite_upperbound=overwrite_upperbound,
        continuous_interval=continuous_interval,
        empty_range_fallback_to_absolute=empty_range_fallback_to_absolute,
        mad_multiplier=mad_multiplier,
    )
    for (reference_key, logical_metric, group_id), values in grouped.items():
        center = _resolve_center(values, center_method)
        stdev = pstdev(values, mu=center) if len(values) > 1 else 0.0
        zscore_median = median(values)
        zscore_mad = median([abs(value - zscore_median) for value in values])
        rule = _resolve_group_rule(group_id, default_rule, group_rule_overrides or {})
        allowed_ranges = compute_outlier_golden_allowed_ranges(
            center=center,
            stdev=stdev,
            outlier_golden_method=rule.outlier_golden_method,
            relative_limit=rule.relative_limit,
            sigma_multiplier=rule.sigma_multiplier,
            absolute_lower_bound=rule.absolute_lower_bound,
            absolute_upper_bound=rule.absolute_upper_bound,
            overwrite_lowerbound=rule.overwrite_lowerbound,
            overwrite_upperbound=rule.overwrite_upperbound,
            continuous_interval=rule.continuous_interval,
            mad_multiplier=rule.mad_multiplier,
            zscore_median=zscore_median,
            zscore_mad=zscore_mad,
            sample_size=len(values),
        )
        empty_range_fallback_used = False
        empty_range_fallback_reason = None
        if not allowed_ranges:
            context = _format_golden_metric_context(
                reference_key=reference_key,
                logical_metric=logical_metric,
                group_id=group_id,
                rule=rule,
                center=center,
                stdev=stdev,
                sample_size=len(values),
            )
            if rule.empty_range_fallback_to_absolute:
                if (
                    rule.absolute_lower_bound is None
                    or rule.absolute_upper_bound is None
                ):
                    raise ValueError(
                        "Build golden failed because one metric produced no allowed ranges "
                        "and empty_range_fallback_to_absolute is enabled, but absolute_lower_bound "
                        "and absolute_upper_bound are not both set. Please set absolute bounds in "
                        f"the template. {context}"
                    )
                allowed_ranges = [
                    GoldenAllowedRange(
                        rule.absolute_lower_bound,
                        rule.absolute_upper_bound,
                    )
                ]
                empty_range_fallback_used = True
                empty_range_fallback_reason = (
                    "原 golden rule 按 AND/交集计算后没有有效 allowed range；"
                    "已 fallback 到 absolute 数值范围。请注意判断是否所有样品均失效。 "
                    f"{context}"
                )
            else:
                raise ValueError(
                    "Build golden failed because one metric produced no allowed ranges. "
                    "This usually means the configured golden rule has no valid overlap "
                    "(for example, an 'and' rule whose relative/sigma/absolute/mad intervals "
                    "do not intersect), or an overwrite_lowerbound/overwrite_upperbound "
                    f"setting reversed the computed bounds. {context}"
                )
        if len(allowed_ranges) == 1:
            lower_bound = allowed_ranges[0].lower_bound
            upper_bound = allowed_ranges[0].upper_bound
        else:
            lower_bound, upper_bound = compute_outlier_golden_display_bounds(
                center=center,
                stdev=stdev,
                outlier_golden_method=rule.outlier_golden_method,
                relative_limit=rule.relative_limit,
                sigma_multiplier=rule.sigma_multiplier,
                absolute_lower_bound=rule.absolute_lower_bound,
                absolute_upper_bound=rule.absolute_upper_bound,
                overwrite_lowerbound=rule.overwrite_lowerbound,
                overwrite_upperbound=rule.overwrite_upperbound,
                continuous_interval=rule.continuous_interval,
                mad_multiplier=rule.mad_multiplier,
                zscore_median=zscore_median,
                zscore_mad=zscore_mad,
                sample_size=len(values),
            )
        metrics.append(
            GoldenMetricRange(
                reference_key=dict(reference_key),
                logical_metric=logical_metric,
                sample_size=len(values),
                center=center,
                stdev=stdev,
                lower_bound=lower_bound,
                upper_bound=upper_bound,
                outlier_golden_method=rule.outlier_golden_method,
                relative_limit=rule.relative_limit,
                sigma_multiplier=rule.sigma_multiplier,
                absolute_lower_bound=rule.absolute_lower_bound,
                absolute_upper_bound=rule.absolute_upper_bound,
                overwrite_lowerbound=rule.overwrite_lowerbound,
                overwrite_upperbound=rule.overwrite_upperbound,
                continuous_interval=rule.continuous_interval,
                allowed_ranges=allowed_ranges,
                empty_range_fallback_used=empty_range_fallback_used,
                empty_range_fallback_reason=empty_range_fallback_reason,
                zscore_median=zscore_median,
                zscore_mad=zscore_mad,
                mad_multiplier=rule.mad_multiplier,
                reference_nodes_by_column={
                    column: sorted(nodes)
                    for column, nodes in source_nodes[(reference_key, logical_metric, group_id)].items()
                },
            )
        )

    return GoldenReference(
        name=name,
        reference_dimensions=reference_dimensions,
        filters=filters,
        outlier_golden_method=normalized_default_method,
        relative_limit=relative_limit,
        sigma_multiplier=sigma_multiplier,
        absolute_lower_bound=absolute_lower_bound,
        absolute_upper_bound=absolute_upper_bound,
        overwrite_lowerbound=overwrite_lowerbound,
        overwrite_upperbound=overwrite_upperbound,
        continuous_interval=continuous_interval,
        empty_range_fallback_to_absolute=empty_range_fallback_to_absolute,
        mad_multiplier=mad_multiplier,
        metrics=sorted(
            metrics,
            key=lambda item: (
                tuple(sorted(item.reference_key.items())),
                item.logical_metric,
            ),
        ),
        center_method=center_method,
        group_rule_overrides={
            group_id: _resolve_group_rule(group_id, default_rule, group_rule_overrides or {})
            for group_id in sorted((group_rule_overrides or {}).keys())
        },
        reference_node_dimension=reference_node_dimension,
        column_reference_nodes=column_reference_nodes,
        reference_column_names=reference_column_names,
    )


def detect_against_golden(
    measurements: list[MeasurementRecord],
    reference: GoldenReference,
) -> list[AnomalyResult]:
    evaluations = evaluate_against_golden(measurements, reference)
    return [item for item in evaluations if item.reason]


def evaluate_against_golden(
    measurements: Sequence[MeasurementRecord],
    reference: GoldenReference,
) -> list[AnomalyResult]:
    return list(iter_against_golden(measurements, reference))


def iter_against_golden(
    measurements: Sequence[MeasurementRecord],
    reference: GoldenReference,
) -> Iterator[AnomalyResult]:
    index = _build_golden_index(reference)
    reference_key_for = _golden_reference_key_resolver(reference)

    for record in measurements:
        reference_key = reference_key_for(record)
        metric = index.get((reference_key, record.logical_metric))
        if metric is None:
            continue
        if metric.allowed_ranges:
            is_within = any(
                item.lower_bound <= record.value <= item.upper_bound
                for item in metric.allowed_ranges
            )
        else:
            is_within = evaluate_outlier_golden_rule(
                value=record.value,
                center=metric.center,
                stdev=metric.stdev,
                outlier_golden_method=metric.outlier_golden_method,
                relative_limit=metric.relative_limit,
                sigma_multiplier=metric.sigma_multiplier,
                absolute_lower_bound=metric.absolute_lower_bound,
                absolute_upper_bound=metric.absolute_upper_bound,
                overwrite_lowerbound=metric.overwrite_lowerbound,
                overwrite_upperbound=metric.overwrite_upperbound,
                continuous_interval=metric.continuous_interval,
                mad_multiplier=metric.mad_multiplier,
                zscore_median=metric.zscore_median,
                zscore_mad=metric.zscore_mad,
                sample_size=metric.sample_size,
            )
        yield AnomalyResult(
            method="golden_reference",
            dataset_id=record.dataset_id,
            source_file=record.source_file,
            row_number=record.row_number,
            logical_metric=record.logical_metric,
            raw_column=record.raw_column,
            value=record.value,
            dimensions=record.dimensions,
            lower_bound=metric.lower_bound,
            upper_bound=metric.upper_bound,
            center=metric.center,
            stdev=metric.stdev,
            outlier_golden_method=metric.outlier_golden_method,
            relative_limit=metric.relative_limit,
            sigma_multiplier=metric.sigma_multiplier,
            absolute_lower_bound=metric.absolute_lower_bound,
            absolute_upper_bound=metric.absolute_upper_bound,
            overwrite_lowerbound=metric.overwrite_lowerbound,
            overwrite_upperbound=metric.overwrite_upperbound,
            continuous_interval=metric.continuous_interval,
            allowed_ranges=list(metric.allowed_ranges),
            reference_key=metric.reference_key,
            reason="Value is outside configured golden rule." if not is_within else None,
            mad_multiplier=metric.mad_multiplier,
            zscore_median=metric.zscore_median,
            zscore_mad=metric.zscore_mad,
            zscore_sample_size=metric.sample_size,
        )


def summarize_golden_coverage(
    measurements: list[MeasurementRecord],
    reference: GoldenReference,
) -> dict[str, object]:
    index = _build_golden_index(reference)
    reference_key_for = _golden_reference_key_resolver(reference)
    matched_measurement_count = 0
    unmatched_measurement_count = 0
    matched_rows: set[tuple[str, str, int]] = set()
    unmatched_rows: set[tuple[str, str, int]] = set()
    unmatched_examples: list[dict[str, object]] = []

    for record in measurements:
        reference_key = reference_key_for(record)
        metric = index.get((reference_key, record.logical_metric))
        row_key = (record.dataset_id, record.source_file, record.row_number)
        if metric is None:
            unmatched_measurement_count += 1
            unmatched_rows.add(row_key)
            if len(unmatched_examples) < 5:
                unmatched_examples.append(
                    {
                        "dataset_id": record.dataset_id,
                        "row_number": record.row_number,
                        "logical_metric": record.logical_metric,
                        "raw_column": record.raw_column,
                        "dimensions": dict(record.dimensions),
                    }
                )
            continue
        matched_measurement_count += 1
        matched_rows.add(row_key)

    total_measurement_count = len(measurements)
    return {
        "total_measurement_count": total_measurement_count,
        "matched_measurement_count": matched_measurement_count,
        "unmatched_measurement_count": unmatched_measurement_count,
        "matched_row_count": len(matched_rows),
        "unmatched_row_count": len(unmatched_rows),
        "unmatched_examples": unmatched_examples,
    }


def detect_by_modified_zscore(
    measurements: list[MeasurementRecord],
    population_dimensions: list[str] | None = None,
    z_threshold: float = 3.5,
    *,
    golden_reference: GoldenReference | None = None,
) -> list[AnomalyResult]:
    evaluations = evaluate_modified_zscore(
        measurements=measurements,
        population_dimensions=population_dimensions,
        golden_reference=golden_reference,
    )
    anomalies: list[AnomalyResult] = []
    for item in evaluations:
        if item.score is None or abs(item.score) <= z_threshold:
            continue
        item.reason = f"Absolute modified z-score exceeded threshold {z_threshold}."
        anomalies.append(item)
    return anomalies


def evaluate_modified_zscore(
    measurements: Sequence[MeasurementRecord],
    population_dimensions: list[str] | None = None,
    *,
    golden_reference: GoldenReference | None = None,
    cache: ZScoreCache | None = None,
) -> list[AnomalyResult]:
    return list(
        iter_modified_zscore(
            measurements,
            population_dimensions,
            golden_reference=golden_reference,
            cache=cache,
        )
    )


def iter_modified_zscore(
    measurements: Sequence[MeasurementRecord],
    population_dimensions: list[str] | None = None,
    *,
    golden_reference: GoldenReference | None = None,
    cache: ZScoreCache | None = None,
) -> Iterator[AnomalyResult]:
    if golden_reference is not None:
        yield from _iter_modified_zscore_against_golden(measurements, golden_reference, cache=cache)
        return
    population_dimensions = population_dimensions or []
    if population_dimensions:
        fields = _measurement_dimension_fields(measurements)
        population_dimensions = [fields.resolve(name, strict=True) for name in population_dimensions]
    grouped = {}
    for index, record in enumerate(measurements):
        population_key = _dimension_key(record, population_dimensions, "Z-score population")
        key = (population_key, record.logical_metric)
        if key not in grouped:
            grouped[key] = array("Q")
        grouped[key].append(index)

    # Only group indices survive the first pass, including for compact inputs.
    # The population is still the complete filtered scope, never a chunk of it.
    value_at = getattr(measurements, "value_at", lambda index: measurements[index].value)
    for (population_key, logical_metric), indices in grouped.items():
        values = [value_at(index) for index in indices]
        cached = None
        if cache is not None:
            # Fingerprint one pool at a time; do not retain per-record tuples
            # for the whole analysis scope alongside its compact index arrays.
            fingerprint = PopulationFingerprint()
            for index in indices:
                fingerprint.add(measurements[index])
            fingerprint_key = fingerprint.key(logical_metric, population_key)
            values_cacheable = fingerprint.cacheable
            del fingerprint
            cached = cache.population_scores(
                fingerprint_key,
                values,
                _modified_zscore_statistics,
                _modified_zscore_value,
                values_cacheable=values_cacheable,
            )
        med, mad = (cached.center, cached.mad) if cached is not None else _modified_zscore_statistics(values)
        cached_scores = cached.scores_for(values) if cached is not None else None
        for offset, index in enumerate(indices):
            record = measurements[index]
            score = cached_scores[offset] if cached_scores is not None else _modified_zscore_value(record.value, med, mad)
            yield AnomalyResult(
                method="modified_z_score",
                dataset_id=record.dataset_id,
                source_file=record.source_file,
                row_number=record.row_number,
                logical_metric=logical_metric,
                raw_column=record.raw_column,
                value=record.value,
                dimensions=record.dimensions,
                center=med,
                score=score,
                reason=None,
                zscore_mad=mad,
            )


def _modified_zscore_statistics(values: Sequence[float]) -> tuple[float | None, float | None]:
    med = median(values) if len(values) >= 3 else None
    mad = median([abs(value - med) for value in values]) if med is not None else None
    return med, mad


def _modified_zscore_value(value: float, med: float | None, mad: float | None) -> float | None:
    return None if med is None else (0.0 if mad == 0 else MODIFIED_ZSCORE_SCALE * (value - med) / mad)


def _iter_modified_zscore_against_golden(
    measurements: Sequence[MeasurementRecord],
    reference: GoldenReference,
    *,
    cache: ZScoreCache | None = None,
) -> Iterator[AnomalyResult]:
    index = _build_golden_index(reference)
    reference_key_for = _golden_reference_key_resolver(reference)
    record_groups = None
    resolved_groups = []
    if cache is not None:
        # Remember each match in four bytes so the output pass preserves input
        # order without rebuilding every reference key and looking it up again.
        record_groups = array("I")
        group_ids = {}
        grouped_values = []
        for record in measurements:
            reference_key = reference_key_for(record)
            group_key = (reference_key, record.logical_metric)
            group_id = group_ids.get(group_key)
            if group_id is None:
                group_id = len(grouped_values)
                group_ids[group_key] = group_id
                grouped_values.append([])
            record_groups.append(group_id)
            grouped_values[group_id].append(record.value)
        for group_key, group_id in group_ids.items():
            values = grouped_values[group_id]
            grouped_values[group_id] = None
            metric = index.get(group_key)
            # Missing statistics keep the existing explicit error below. They
            # must never fall back to statistics derived from analysis rows.
            scores = None
            if metric is not None and metric.zscore_median is not None and metric.zscore_mad is not None:
                med = metric.zscore_median if metric.sample_size >= 3 else None
                mad = metric.zscore_mad if med is not None else None
                cached = cache.golden_scores(
                    golden_cache_key(metric.logical_metric, group_key[0], metric.zscore_median, metric.zscore_mad, metric.sample_size),
                    values,
                    med,
                    mad,
                    _modified_zscore_value,
                )
                if cached is not None:
                    # Resolve a whole baseline group in C rather than packing
                    # and bisecting each value again. Retain compact scores,
                    # releasing input lists as their groups are resolved.
                    scores = (repeat(None) if cached.center is None
                              else iter(array("d", cached.scores_for(values))))
            resolved_groups.append((group_key[0], metric, scores))
        # Do not keep the last group's input values alive during result assembly.
        values = None
        del grouped_values, group_ids
    for offset, record in enumerate(measurements):
        if record_groups is None:
            reference_key = reference_key_for(record)
            metric = index.get((reference_key, record.logical_metric))
            scores = None
        else:
            reference_key, metric, scores = resolved_groups[record_groups[offset]]
        if metric is None or metric.zscore_median is None or metric.zscore_mad is None:
            issue = (
                "has no matching metric"
                if metric is None
                else "does not contain saved Z-score median/MAD statistics"
            )
            raise ValueError(
                f"Golden reference '{reference.name}' {issue} for "
                f"logical_metric={record.logical_metric}, reference_key={dict(reference_key)}. "
                "Rebuild the Golden file with the required scope or disable "
                "'Use Golden Range for Z Score' (report.zscore_use_golden_reference) "
                "to calculate from all analysis data."
            )
        med = metric.zscore_median if metric.sample_size >= 3 else None
        score = next(scores) if scores is not None else _modified_zscore_value(record.value, med, metric.zscore_mad)
        yield AnomalyResult(
            method="modified_z_score",
            dataset_id=record.dataset_id,
            source_file=record.source_file,
            row_number=record.row_number,
            logical_metric=record.logical_metric,
            raw_column=record.raw_column,
            value=record.value,
            dimensions=record.dimensions,
            center=med,
            score=score,
            reference_key=metric.reference_key,
            reason=None,
            zscore_mad=metric.zscore_mad if med is not None else None,
        )


def _match_dimensions(dimensions: dict[str, str], expected: dict[str, str]) -> bool:
    for key, value in expected.items():
        if dimensions.get(key) not in _filter_values(value):
            return False
    return True


@lru_cache(maxsize=128)
def _filter_values(value: str) -> tuple[str, ...]:
    values = {item.strip() for item in str(value).split(",") if item.strip()}
    return tuple(sorted(values or {str(value).strip()}))


def _golden_reference_key_resolver(reference: GoldenReference):
    """Bind baseline-node selection once, including cached Z-score lookups."""
    node_dimension = reference.reference_node_dimension
    overrides = reference.column_reference_nodes
    columns = FieldNames({
        *reference.reference_column_names,
        *overrides,
        *(raw for metric in reference.metrics for raw in metric.reference_nodes_by_column),
    })
    global_nodes = _filter_values(reference.filters[node_dimension]) if node_dimension in reference.filters else ()
    shared_baseline_columns = defaultdict(set)
    if overrides:
        for metric in reference.metrics:
            if any(columns.resolve(raw) in overrides for raw in metric.reference_nodes_by_column):
                shared_baseline_columns[metric.logical_metric].update(metric.reference_nodes_by_column)

    @lru_cache(maxsize=None)
    def selected_node(raw_column, logical_metric):
        if not overrides:
            return None
        resolved_column = columns.resolve(raw_column)
        forced_node = overrides.get(resolved_column)
        if forced_node is not None:
            return forced_node
        # Only columns sharing a forced pooled baseline need the corresponding
        # global node. Unrelated metrics retain their original key lookup.
        if resolved_column in shared_baseline_columns[logical_metric] and len(global_nodes) == 1:
            return global_nodes[0]
        return None

    def reference_key_for(record):
        node = selected_node(record.raw_column, record.logical_metric) if node_dimension in reference.reference_dimensions else None
        return tuple(
            (dimension, node if dimension == node_dimension and node is not None else record.dimensions.get(dimension, ""))
            for dimension in reference.reference_dimensions
        )

    return reference_key_for


def _build_golden_index(
    reference: GoldenReference,
) -> dict[tuple[tuple[tuple[str, str], ...], str], GoldenMetricRange]:
    return {
        (
            tuple(
                (dimension, metric.reference_key.get(dimension, ""))
                for dimension in reference.reference_dimensions
            ),
            metric.logical_metric,
        ): metric
        for metric in reference.metrics
    }


def _resolve_center(values: list[float], center_method: str) -> float:
    if center_method == "median":
        return median(values)
    return mean(values)


def _resolve_group_rule(
    group_id: str,
    defaults: GoldenRuleConfig,
    overrides: dict[str, GoldenRuleConfig],
) -> GoldenRuleConfig:
    override = overrides.get(group_id)
    if override is None:
        return defaults
    effective_continuous_interval = (
        override.continuous_interval
        if override.continuous_interval is not None
        else defaults.continuous_interval
    )
    normalized = validate_golden_rule_config(
        f"Analysis group {group_id} golden rule",
        override.outlier_golden_method,
        override.relative_limit,
        override.sigma_multiplier,
        override.absolute_lower_bound,
        override.absolute_upper_bound,
        override.overwrite_lowerbound,
        override.overwrite_upperbound,
        bool(effective_continuous_interval),
        override.empty_range_fallback_to_absolute,
        mad_multiplier=override.mad_multiplier,
    )
    return GoldenRuleConfig(
        outlier_golden_method=normalized,
        relative_limit=override.relative_limit,
        sigma_multiplier=override.sigma_multiplier,
        absolute_lower_bound=override.absolute_lower_bound,
        absolute_upper_bound=override.absolute_upper_bound,
        overwrite_lowerbound=override.overwrite_lowerbound,
        overwrite_upperbound=override.overwrite_upperbound,
        continuous_interval=bool(effective_continuous_interval),
        empty_range_fallback_to_absolute=override.empty_range_fallback_to_absolute,
        mad_multiplier=override.mad_multiplier,
    )
