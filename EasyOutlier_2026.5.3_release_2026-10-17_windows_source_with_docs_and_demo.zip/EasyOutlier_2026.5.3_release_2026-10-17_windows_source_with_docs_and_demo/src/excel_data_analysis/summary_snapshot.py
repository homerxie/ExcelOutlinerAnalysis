"""Analysis settings and source revisions used by Summary plot navigation."""
from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
import hashlib
import os
from pathlib import Path, PurePosixPath, PureWindowsPath

from .file_revision import golden_file_revision
from .measurement_storage import MeasurementStorage
from .template import load_template, template_to_payload


def _file_revision(path: Path) -> dict:
    try:
        stat = path.stat()
    except FileNotFoundError:
        return {"path": str(path.resolve()), "revision": None}
    return {"path": str(path.resolve()), "revision": [stat.st_size, stat.st_mtime_ns]}


def _source_revisions(context: dict) -> dict:
    storage = MeasurementStorage(context["storage_path"])
    source = storage.path if storage.path.exists() else storage.legacy_path
    revisions = {"measurements": _file_revision(source)}
    if context.get("golden_path"):
        revisions["golden"] = _file_revision(Path(context["golden_path"]))
    return revisions


def capture_summary_snapshot(payload: dict) -> dict:
    """Capture once before analysis; later UI edits must not change this scope.

    Large measurement files stay on disk. Revision checks reject changed data
    instead of silently associating a saved Summary with another population.
    The template itself is small enough to retain, including one-run settings.
    """
    template = deepcopy(payload.get("template_payload"))
    if template is None:
        template = template_to_payload(load_template(payload["template_path"]))
    report = template["report"]
    # Every newly captured analysis records the setting, including callers that
    # supply an older template payload rather than loading a TemplateConfig.
    report.setdefault("zscore_use_golden_reference", True)
    for parameter, field in (
        ("outlier_fail_method_override", "outlier_fail_method"),
        ("outlier_merge_order_override", "outlier_merge_order"),
        ("outlier_treat_empty_cells_as_fail_override", "outlier_treat_empty_cells_as_fail"),
    ):
        if payload.get(parameter) is not None:
            report[field] = payload[parameter]
    threshold = payload.get("zscore_threshold_override")
    if threshold is not None:
        report["zscore_thresholds"] = {
            "default": threshold,
            "overrides": dict(report.get("zscore_thresholds", {}).get("overrides", {})),
        }
    context = {
        "template_path": str(Path(payload["template_path"]).resolve()),
        "template_payload": template,
        "analysis_scope": payload["analysis_scope"],
        "storage_path": str(Path(payload["storage_path"]).resolve()),
        "golden_path": str(Path(payload["built_golden_path"]).resolve()) if payload.get("built_golden_path") else "",
        "dataset_ids": deepcopy(payload.get("dataset_ids")) if payload["analysis_scope"] == "checked_imports" else None,
        "dimension_filters": deepcopy(payload.get("dimension_filters")),
        "column_filters": deepcopy(payload.get("column_filters")),
        "outlier_fail_method": report["outlier_fail_method"],
        "zscore_threshold": None,
    }
    return {"version": 1, "context": context, "sources": _source_revisions(context)}


def summary_plot_context(snapshot: dict) -> dict:
    """Copy a saved analysis context, retaining pre-Golden Z-score behavior.

    Old saved summaries scored against their analysis population. Template
    defaults may evolve, but opening those summaries must reproduce their
    original classifications without requiring a newly built Golden file.
    """
    context = deepcopy(snapshot["context"])
    report = context["template_payload"].setdefault("report", {})
    report.setdefault("zscore_use_golden_reference", False)
    return context


def summary_snapshot_error(snapshot: dict | None) -> str:
    if not isinstance(snapshot, dict) or snapshot.get("version") != 1:
        return "This saved result has no plot navigation context. Run Analysis again to enable sample links."
    context = snapshot.get("context")
    if not isinstance(context, dict) or not context.get("template_payload") or not context.get("storage_path"):
        return "The saved analysis context is incomplete. Run Analysis again to enable sample links."
    try:
        current = _source_revisions(context)
    except (OSError, ValueError, TypeError):
        return "The original analysis data is unavailable. Restore it or run Analysis again."
    if any(item["revision"] is None for item in current.values()):
        return "The original database or Golden file is unavailable. Restore it or run Analysis again."
    if current != snapshot.get("sources") or snapshot.get("relocation_error"):
        return "The database or Golden file has changed since this Summary was generated. Run Analysis again before opening its sample links."
    try:
        for name, digest in snapshot.get("source_digests", {}).items():
            if _stable_file_digest(Path(current[name]["path"])) != digest:
                return "The database or Golden file has changed since this Summary was generated. Run Analysis again before opening its sample links."
    except (OSError, ValueError, TypeError, KeyError):
        return "The original analysis data is unavailable. Restore it or run Analysis again."
    return ""


def _measurement_file(storage_path: str | Path) -> Path:
    storage = MeasurementStorage(storage_path)
    return storage.path if storage.path.exists() else storage.legacy_path


def _file_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


@lru_cache(maxsize=32)
def _cached_file_digest(path: Path, revision: tuple) -> str:
    return _file_digest(path)


def _stable_file_digest(path: Path) -> str:
    # The extended revision includes file identity and metadata change time,
    # including on Windows. Repeated settings saves need not reread a large DB.
    before = golden_file_revision(path)
    if before is None:
        before_stat = _file_revision(path)
        digest = _file_digest(path)
        changed = _file_revision(path) != before_stat
    else:
        digest = _cached_file_digest(path, before)
        changed = golden_file_revision(path) != before
    if changed:
        raise OSError("Analysis source changed while checking its contents")
    return digest


def _saved_path(value: str):
    """Interpret stored Windows paths lexically even when loading on macOS."""
    windows = PureWindowsPath(value)
    return windows if windows.is_absolute() else PurePosixPath(value)


def pack_summary_snapshot(snapshot: dict | None, database_root: str | Path) -> dict | None:
    """Save navigation references relative to the owning database, never cwd.

    Hash only still-valid sources. Saving settings must never bless data that
    changed after Analyze. Digests allow an unchanged copy to have new mtimes.
    """
    if not isinstance(snapshot, dict) or snapshot.get("version") not in (1, 2):
        return snapshot
    if snapshot.get("portable_paths"):
        snapshot = restore_summary_snapshot(snapshot, database_root)
    result = deepcopy(snapshot)
    if not isinstance(result.get("context"), dict) or not isinstance(result.get("sources"), dict):
        return result
    root = Path(database_root).resolve()
    references = {"version": 2, "base": "database", "context": [], "sources": [],
                  "external_fallbacks": {}, "digests": {}}
    for section, fields in (("context", ("storage_path", "golden_path", "template_path")),
                            ("sources", tuple(result.get("sources", {})))):
        for name in fields:
            entry = result.get(section, {}).get(name)
            value = entry.get("path") if section == "sources" and isinstance(entry, dict) else entry
            if not isinstance(value, str) or not value:
                continue
            path = _saved_path(value)
            # Foreign-volume paths cannot be made relative to this database.
            if not path.is_absolute() or type(path) is not type(_saved_path(str(root))):
                continue
            try:
                relative = Path(os.path.relpath(value, root)).as_posix()
            except ValueError:
                continue
            references[section].append(name)
            if section == "context":
                result[section][name] = relative
            else:
                result[section][name]["path"] = relative
            if section == "sources" and PurePosixPath(relative).parts[:1] == ("..",):
                references["external_fallbacks"][name] = value
    if not summary_snapshot_error(snapshot):
        try:
            for name, source in snapshot["sources"].items():
                path = Path(source["path"])
                digest = _stable_file_digest(path)
                if _file_revision(path) == source:
                    references["digests"][name] = digest
        except (OSError, ValueError, TypeError, KeyError):
            # Persisting a result remains possible when its sources disappear.
            references["digests"] = {}
    result["version"] = 2
    result["portable_paths"] = references
    return result


def _relocate_snapshot(snapshot: dict, old_root, new_root: Path) -> dict:
    result = deepcopy(snapshot)
    for name in ("storage_path", "golden_path", "template_path"):
        value = result["context"].get(name)
        if value:
            try:
                relative = _saved_path(value).relative_to(old_root)
            except ValueError:
                continue  # External files cannot be recovered by basename.
            result["context"][name] = str(new_root.joinpath(*relative.parts))
    for source in result.get("sources", {}).values():
        try:
            relative = _saved_path(source["path"]).relative_to(old_root)
        except ValueError:
            continue
        source["path"] = str(new_root.joinpath(*relative.parts))
    return result


def _legacy_database_root(gui_state: dict, storage):
    roots = set()
    paths = gui_state.get("paths", {})
    bases = gui_state.get("path_bases", {})
    fallbacks = gui_state.get("path_fallbacks", {})
    for key, value in paths.items():
        fallback = fallbacks.get(key)
        if bases.get(key) != "database" or not value or not fallback:
            continue
        relative, absolute = _saved_path(value), _saved_path(fallback)
        if relative.is_absolute() or ".." in relative.parts or not absolute.is_absolute() or not relative.parts:
            continue
        root = absolute
        for _ in relative.parts:
            root = root.parent
        if root.joinpath(*relative.parts) == absolute and storage in (root, root / "temp"):
            roots.add(root)
    return next(iter(roots)) if len(roots) == 1 else None


def restore_summary_snapshot(
    snapshot: dict | None, database_root: str | Path, *, gui_state: dict | None = None,
) -> dict | None:
    """Resolve a copied Summary without replacing its analysis/settings scope."""
    if not isinstance(snapshot, dict) or snapshot.get("version") not in (1, 2):
        return snapshot
    try:
        return _restore_summary_snapshot(snapshot, database_root, gui_state=gui_state)
    except (OSError, ValueError, TypeError, KeyError, AttributeError):
        # An incomplete saved navigation record must not prevent the database
        # from opening, or silently fall back to another computer's data.
        result = deepcopy(snapshot)
        result["relocation_error"] = True
        return result


def _restore_summary_snapshot(snapshot: dict, database_root: str | Path, *, gui_state: dict | None) -> dict:
    result = deepcopy(snapshot)
    references = result.pop("portable_paths", None)
    root = Path(database_root).resolve()
    if isinstance(references, dict) and references.get("version") == 2:
        if snapshot.get("version") != 2 or references.get("base") != "database":
            raise ValueError("Unsupported Summary path base")
        result["version"] = 1
        for name in references["context"]:
            value = result["context"][name]
            if _saved_path(value).is_absolute():
                raise ValueError("Summary database reference must be relative")
            result["context"][name] = str((root / value).resolve())
        for name in references["sources"]:
            value = result["sources"][name]["path"]
            if _saved_path(value).is_absolute():
                raise ValueError("Summary source reference must be relative")
            result["sources"][name]["path"] = str((root / value).resolve())
        # External Golden files are explicitly distinguished from library files;
        # an internal missing file must never fall back to another database.
        fallback = references.get("external_fallbacks", {}).get("golden")
        if fallback and not Path(result["context"]["golden_path"]).exists():
            original = _saved_path(fallback)
            if original.is_absolute() and type(original) is type(_saved_path(str(root))):
                try:
                    digest = references.get("digests", {}).get("golden")
                    matches = (_stable_file_digest(Path(fallback)) == digest if digest else
                               _file_revision(Path(fallback))["revision"] == result["sources"]["golden"]["revision"])
                    if matches:
                        result["context"]["golden_path"] = fallback
                        result["sources"]["golden"]["path"] = fallback
                except OSError:
                    pass
        digests = references.get("digests", {})
        if digests:
            result["source_digests"] = digests
            current = _source_revisions(result["context"])
            for name, digest in digests.items():
                source = current[name]
                try:
                    if (source["path"] == result["sources"][name]["path"]
                            and source["revision"] is not None
                            and _stable_file_digest(Path(source["path"])) == digest):
                        result["sources"][name] = source
                    else:
                        result["relocation_error"] = True
                except OSError:
                    result["relocation_error"] = True
        return result
    if isinstance(references, dict) and references.get("version") == 1:
        if _saved_path(references["database_root"]) == _saved_path(str(root)):
            return result
        for name, relative in references["context"].items():
            result["context"][name] = str((root / relative).resolve())
        for name, relative in references["sources"].items():
            result["sources"][name]["path"] = str((root / relative).resolve())
        digests = references.get("digests", {})
        # A sibling/external Golden may not have been copied with the database.
        # Keep its original location only when it still identifies this run's
        # file. Internal sources always follow the opened copy, even if stale.
        golden_relative = references["sources"].get("golden", "")
        if PurePosixPath(golden_relative).parts[:1] == ("..",):
            source = snapshot["sources"]["golden"]
            original = _saved_path(source["path"])
            candidate = Path(result["sources"]["golden"]["path"])
            if (not candidate.exists() and original.is_absolute()
                    and type(original) is type(_saved_path(str(root)))):
                path = Path(source["path"])
                try:
                    matches = (_stable_file_digest(path) == digests["golden"] if "golden" in digests
                               else _file_revision(path) == source)
                    if matches:
                        result["context"]["golden_path"] = str(path)
                        result["sources"]["golden"]["path"] = str(path)
                except OSError:
                    pass
        if digests:
            result["source_digests"] = digests
            try:
                current = _source_revisions(result["context"])
                for name, digest in digests.items():
                    source = current[name]
                    if (source["path"] == result["sources"][name]["path"]
                            and source["revision"] is not None
                            and _stable_file_digest(Path(source["path"])) == digest):
                        result["sources"][name] = source
            except (OSError, ValueError, TypeError, KeyError):
                pass  # Normal navigation validation reports unavailable data.
        return result

    # 2026.4.6 and earlier saved only absolute Summary paths. Existing GUI path
    # fallbacks often identify the old root exactly, even for a DB named temp.
    context = result.get("context")
    if not isinstance(context, dict) or not context.get("storage_path"):
        return result
    storage = _saved_path(context["storage_path"])
    old_root = _legacy_database_root(gui_state or {}, storage)
    if old_root is not None:
        return _relocate_snapshot(result, old_root, root)
    if storage in (_saved_path(str(root)), _saved_path(str(root / "temp"))):
        return result
    candidates = [_relocate_snapshot(result, storage, root)]
    if storage.name == "temp":
        candidates.append(_relocate_snapshot(result, storage.parent, root))
    matching = [candidate for candidate in candidates if not summary_snapshot_error(candidate)]
    if len(matching) == 1:
        return matching[0]
    # Do not silently fall back to a still-existing database on the old machine.
    result = candidates[-1]
    result["relocation_error"] = True
    return result


def prepare_summary_snapshot_for_copy(snapshot: dict | None, source_storage: str | Path) -> dict | None:
    """Validate before a known lossless workspace save can compact its files.

    A saved-root snapshot may also describe its untouched copy2 workspace.
    Changed workspaces must not inherit an older root's analysis association.
    The result is an ephemeral preparation token, not persistent GUI state.
    """
    if summary_snapshot_error(snapshot):
        return None
    try:
        source = _measurement_file(source_storage)
        active = _file_revision(source)
        original = snapshot["sources"]["measurements"]
        if not source.is_file() or active["revision"] != original["revision"]:
            return None
        if Path(active["path"]).name != Path(original["path"]).name:
            return None
        if (active["path"] != original["path"]
                and _stable_file_digest(source) != _stable_file_digest(Path(original["path"]))):
            return None
        prepared = deepcopy(snapshot)
        preparation = {"source_storage": str(Path(source_storage).resolve())}
        golden = snapshot["context"].get("golden_path")
        if golden:
            preparation["golden_digest"] = _file_digest(Path(golden))
            # Do not bless a file which changed while its digest was read.
            if _file_revision(Path(golden)) != snapshot["sources"]["golden"]:
                return None
        prepared["_copy_preparation"] = preparation
        return prepared
    except (OSError, ValueError, TypeError, KeyError):
        return None


def rebase_summary_snapshot_after_copy(
    prepared: dict | None,
    source_root: str | Path,
    destination_root: str | Path,
    destination_storage: str | Path,
) -> dict | None:
    """Complete a successful save using its pre-save validation token.

    The save itself guarantees measurement equivalence, including format
    compaction and Save As source-path rewriting. Golden files are smaller and
    checked by content, because the workspace may hold a newer same-name file.
    """
    if not isinstance(prepared, dict) or not isinstance(prepared.get("_copy_preparation"), dict):
        return None
    try:
        preparation = prepared["_copy_preparation"]
        source_storage = Path(preparation["source_storage"]).resolve()
        source_root = Path(source_root).resolve()
        destination_root = Path(destination_root).resolve()
        destination_storage = Path(destination_storage).resolve()
        if not _measurement_file(destination_storage).is_file():
            return None
        result = deepcopy(prepared)
        result.pop("_copy_preparation")
        context = result["context"]
        context["storage_path"] = str(destination_storage)
        template_path = context.get("template_path")
        if template_path:
            for base in (source_storage, source_root):
                try:
                    relative = Path(template_path).resolve().relative_to(base)
                except ValueError:
                    continue
                context["template_path"] = str(destination_root / relative)
                break
        golden = context.get("golden_path")
        if golden:
            original = Path(golden).resolve()
            candidates: list[Path] = []
            for base in (source_storage, source_root):
                try:
                    relative = original.relative_to(base)
                except ValueError:
                    continue
                if relative.parts:
                    candidates.append(destination_root / relative)
            digest = preparation["golden_digest"]
            for candidate in candidates:
                if candidate.is_file() and _file_digest(candidate) == digest:
                    context["golden_path"] = str(candidate.resolve())
                    break
            else:
                # Internal files must follow the saved database. Only genuine
                # external references may keep their unchanged source path.
                if candidates:
                    return None
                if _file_revision(original) != result["sources"]["golden"]:
                    return None
                if _file_digest(original) != digest:
                    return None
        result["sources"] = _source_revisions(context)
        # This authorized lossless save may compact/rewrite measurement bytes.
        # Its old content hashes no longer describe the physical files; the
        # settings writer captures fresh portable hashes after this rebase.
        result.pop("source_digests", None)
        return result if not summary_snapshot_error(result) else None
    except (OSError, ValueError, TypeError, KeyError):
        return None
