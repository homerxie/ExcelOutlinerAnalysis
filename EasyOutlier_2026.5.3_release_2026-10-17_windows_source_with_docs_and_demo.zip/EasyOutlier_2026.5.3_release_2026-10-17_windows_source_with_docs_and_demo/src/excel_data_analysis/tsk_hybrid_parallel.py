"""A few group coordinators share a physical-core-aware, elastic leaf budget.

Only this entry point grants permission for one additional spawn layer. Ordinary
TSK workers remain leaves. Numerical tolerances and task definitions are unchanged.
"""
from numbers import Integral
import os
from time import monotonic, sleep

from .compute_resources import automatic_tsk_budget, cpu_topology, limit_process_workers
from .tsk_compute_budget import (create_budget, install_group, clear_context,
                                 compute_slot, current_role)


def group_plan(total_budget, group_count):
    if isinstance(total_budget, bool) or not isinstance(total_budget, Integral) or not 1 <= total_budget <= 64:
        raise ValueError("total_budget must be an integer between 1 and 64.")
    if isinstance(group_count, bool) or not isinstance(group_count, Integral) or group_count < 0:
        raise ValueError("group_count must be a non-negative integer.")
    groups = min(4, max(1, group_count), max(1, total_budget // 4))
    return {"total_budget": int(total_budget), "group_workers": groups,
            "initial_per_group": int(total_budget) // groups,
            "initial_extra_slots": int(total_budget) % groups}


def process_is_alive(pid):
    """Probe only a registered descendant, using native Windows handles there."""
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel.WaitForSingleObject.restype = wintypes.DWORD
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel.CloseHandle.restype = wintypes.BOOL
        handle = kernel.OpenProcess(0x00100000, False, pid)  # SYNCHRONIZE only
        if not handle:
            if ctypes.get_last_error() == 87:  # ERROR_INVALID_PARAMETER: no such PID
                return False
            return True  # Access denied/unknown is never permission to reclaim.
        try:
            return kernel.WaitForSingleObject(handle, 0) != 0
        finally:
            kernel.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    # Linux can retain reparented dead children as zombies until init reaps.
    # They cannot compute and no signal is sent. Other platforms use kill(0).
    try:
        with open(f"/proc/{pid}/stat", encoding="ascii") as stream:
            return stream.read().rsplit(")", 1)[1].strip().split()[0] != "Z"
    except (FileNotFoundError, PermissionError, IndexError):
        return True


def reclaim_process_tree(budget, joined_pids):
    """Wait for known descendants' parent-death watchers before reusing slots."""
    roots = set(joined_pids)
    if not roots:
        return
    # Close the dead coordinators' admission before taking the descendant
    # snapshot. A leaf still importing from an old attempt must not register
    # after this snapshot and escape cleanup/retry validation.
    records = budget.retire_coordinators(sorted(roots))["registered_processes"]
    descendants = set(roots)
    while True:
        found = {row["pid"] for row in records if row["parent_pid"] in descendants}
        if found <= descendants:
            break
        descendants.update(found)
    pending = descendants - roots
    deadline = monotonic() + 10.
    while pending:
        pending = {pid for pid in pending if process_is_alive(pid)}
        if not pending:
            break
        if monotonic() >= deadline:
            raise RuntimeError("TSK 子进程退出尚未确认，停止重试以避免重复计算：" + str(sorted(pending)))
        sleep(.02)
    budget.reclaim_dead_pids(sorted(descendants))


def _hybrid_group_task(common, item, heartbeat):
    function, payload, budget = common
    index, value = item
    install_group(budget, str(index))
    try:
        with compute_slot(poll=heartbeat):
            result = function(payload, value, heartbeat)
        return result
    finally:
        clear_context()


def ordered_group_map(function, items, *, common=None, total_budget=None, execution=None,
                      progress_callback=None, detail_callback=None, activity_callback=None):
    from .tsk_parallel import ordered_parallel_map, require_parallel_runtime

    items = list(items)
    if current_role() is not None:
        raise RuntimeError("Hybrid group admission is allowed only at the analysis root.")
    topology = cpu_topology()
    requested_plan = group_plan(automatic_tsk_budget(topology) if total_budget is None else total_budget, len(items))
    resolved = limit_process_workers(min(requested_plan["total_budget"], topology["logical_cpus"],
                                        topology["platform_limit"], 61 if os.name == "nt" else 64))
    plan = group_plan(resolved, len(items))
    execution = execution if execution is not None else {}
    execution.update(hybrid_plan=plan, cpu_topology=topology)
    if not items:
        return []
    with require_parallel_runtime()(limits=1), create_budget(
            plan["total_budget"], plan["group_workers"], len(items)) as budget:
        last_snapshot = None

        def progress(done, total):
            nonlocal last_snapshot
            now = monotonic()
            if last_snapshot is None or now - last_snapshot >= .5 or done == total:
                state = budget.snapshot()
                execution["compute_budget"] = {key: state[key] for key in
                    ("total", "used", "peak_used", "remaining_jobs", "active_group_count", "groups")}
                last_snapshot = now
            if progress_callback is not None:
                progress_callback(done, total)

        return ordered_parallel_map(_hybrid_group_task, list(enumerate(items)),
            common=(function, common, budget), workers=plan["group_workers"], execution=execution,
            progress_callback=progress, detail_callback=detail_callback,
            activity_callback=activity_callback, _cleanup_budget=budget,
            _item_completed=lambda index: budget.finish_group(str(index)))
