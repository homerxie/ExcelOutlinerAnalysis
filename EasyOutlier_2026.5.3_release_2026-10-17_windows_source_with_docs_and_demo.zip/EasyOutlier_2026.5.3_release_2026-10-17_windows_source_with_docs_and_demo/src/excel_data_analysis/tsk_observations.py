"""Adapt completed Analyze states to TSK counts without repeating classification."""
from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
from pathlib import Path
import pickle

from .merge_config import chain_level, column_levels
from .reporting import _configured_node_orders, _sample_key_display, _sample_key_from_dimensions
from .tsk_sorting import natural_sort_key


def read_analysis_snapshot(path):
    """Read frozen TSK inputs, full Analyze archives, or private session pickle.

    Old databases may have only the full Analyze archive. Keep that archive
    compressed while opening the GUI and materialize it here on an explicit
    TSK request, in the caller's worker, without rerunning classification.
    """
    if not path or not Path(path).is_file():
        raise ValueError("请先在 Analyze 完成分析，再运行 TSK；TSK 必须基于已完成的 Analyze 结果。")
    if Path(path).name.endswith(".json.gz"):
        from .analysis_snapshot_metadata import inspect_snapshot_format
        from .analysis_snapshot_state import SUPPORTED_FORMATS, load_analysis_snapshot
        from .tsk_analysis_state import decode_analysis_snapshot

        if inspect_snapshot_format(path) in SUPPORTED_FORMATS:
            return load_analysis_snapshot(path)
        return decode_analysis_snapshot(Path(path).read_bytes())
    with Path(path).open("rb") as stream:
        snapshot = pickle.load(stream)
    if not all(name in snapshot for name in ("template", "rows", "columns", "summary_artifacts")):
        raise ValueError("Analyze 结果不完整，请重新运行 Analyze。")
    return snapshot


def template_for_snapshot(snapshot):
    """Exclude topology branches absent from the actual Analyze column scope."""
    template = deepcopy(snapshot["template"])
    prefix = column_levels(template).index(chain_level(template)) + 1
    chains = {tuple(column.header_values[:prefix]) for column in snapshot["columns"]}
    template.tsk_analysis.instances = [item for item in template.tsk_analysis.instances
                                       if tuple(item.chain_key) in chains]
    if not template.tsk_analysis.instances:
        raise ValueError("Analyze 结果中没有可用于 TSK 的链路；请检查 Analyze 的排除范围及 Chain–TSK 对应表。")
    template.report.outlier_fail_method = snapshot.get("fail_mode", template.report.outlier_fail_method)
    return template


def configured_node_sequences(template):
    """Return the same template sequences that Analyze uses for New states."""
    return _configured_node_orders(template)


def normalize_node_groups(template, available_nodes, node_groups):
    """Validate full sequence intervals, allowing unobserved interior nodes.

    Both endpoints must exist in the Analyze scope. Keep the complete template
    interval so missing intermediate nodes do not change its identity or cohort.
    """
    if not isinstance(node_groups, (list, tuple)) or not node_groups:
        raise ValueError("请至少添加一个连续节点分析组。")
    sequences = configured_node_sequences(template)
    if not sequences:
        raise ValueError("请先在 template 的 node_orders 中定义 Analyze 节点 sequence，再选择连续节点分析组。")
    available = set(available_nodes)
    normalized = []
    for index, group in enumerate(node_groups, 1):
        if (not isinstance(group, (list, tuple)) or not group
                or any(not isinstance(node, str) or not node for node in group)):
            raise ValueError(f"节点分析组 {index} 必须包含至少一个节点名称。")
        nodes = list(group)
        unknown = {nodes[0], nodes[-1]} - available
        if unknown:
            raise ValueError("首尾节点不在 Analyze 结果中：" + "、".join(sorted(unknown, key=natural_sort_key)))
        if not any(nodes == sequence[start:start + len(nodes)]
                   for sequence in sequences for start in range(len(sequence))):
            raise ValueError(f"节点分析组 {index} 必须是 template 中同一 sequence 按顺序连续的一段节点。")
        normalized.append(nodes)
    return normalized


def _combined_node_group(template, available_nodes, selected_nodes):
    """Keep legacy checkbox selections, with sequence order and validation."""
    selected = set(selected_nodes)
    available = set(available_nodes)
    for sequence in configured_node_sequences(template):
        positions = [index for index, node in enumerate(sequence) if node in selected]
        if not positions:
            continue
        candidate = sequence[positions[0]:positions[-1] + 1]
        # Only bridge nodes absent from Analyze; never omit an observed node
        # inside the selected interval or combine nodes from separate branches.
        if selected.issubset(candidate) and not (set(candidate) - selected) & available:
            return normalize_node_groups(template, available, [candidate])[0]
    # Let the shared validation provide the appropriate actionable error.
    return normalize_node_groups(template, available,
                                 [sorted(selected, key=natural_sort_key)])[0]


def resolve_snapshot_node_groups(snapshot, options):
    """Resolve requested groups before a sample filter can remove source nodes."""
    template = snapshot["template"]
    mode = validate_node_mode(options.get("node_mode", "separate"))
    if mode == "separate":
        return None
    available = {row.dimensions.get(template.report.reliability_node_dimension) for row in snapshot["rows"]}
    if mode == "sequence_groups":
        return normalize_node_groups(template, available, options.get("node_groups"))
    nodes = set(options.get("nodes") or [])
    if options.get("nodes_explicit") and not nodes:
        raise ValueError("请至少选择一个要分析的节点。")
    return [_combined_node_group(template, available, nodes or available)]


def selected_snapshot_rows(snapshot, options):
    template = snapshot["template"]
    groups = resolve_snapshot_node_groups(snapshot, options)
    if groups is not None:
        nodes = {node for group in groups for node in group}
    else:
        nodes = set(options.get("nodes") or [])
        if options.get("nodes_explicit") and not nodes:
            raise ValueError("请至少选择一个要分析的节点。")
        available = {row.dimensions.get(template.report.reliability_node_dimension) for row in snapshot["rows"]}
        unknown = nodes - available
        if unknown:
            raise ValueError("节点不在 Analyze 结果中：" + "、".join(sorted(unknown, key=natural_sort_key)))
    samples = set(options.get("sample_ids") or [])
    rows = []
    for row in snapshot["rows"]:
        sample = _sample_key_from_dimensions(row.dimensions, template.report.sample_dimension_names)
        if nodes and row.dimensions.get(template.report.reliability_node_dimension) not in nodes:
            continue
        if samples and _sample_key_display(sample) not in samples and (not sample or sample[-1] not in samples):
            continue
        rows.append(row)
    if not rows:
        raise ValueError("所选范围在 Analyze 结果中没有样品数据。")
    return rows


def validate_node_mode(node_mode):
    if node_mode not in {"separate", "combined_new", "sequence_groups"}:
        raise ValueError(f"不支持的 TSK 节点分析方式：{node_mode}")
    return node_mode


def observations_from_snapshot(snapshot, template, rows, batch, warnings=(), *, node_mode="separate",
                               node_groups=None):
    """Count Analyze New states within each group's terminal-node cohort.

    A Chain without a retained terminal state remains Missing, even if it had
    a New failure at an earlier selected node. No source data is reclassified.
    """
    from .tsk_service import _batch_value, _pool_batch_groups

    node_name = template.report.reliability_node_dimension
    validate_node_mode(node_mode)
    available = {row.dimensions[node_name] for row in rows}
    if node_mode == "sequence_groups" or (node_mode == "combined_new" and node_groups is not None):
        snapshot_nodes = {row.dimensions[node_name] for row in snapshot["rows"]}
        selections = normalize_node_groups(template, snapshot_nodes, node_groups)
        if node_mode == "combined_new" and len(selections) != 1:
            raise ValueError("旧版组合新增分析只支持一个节点组，请使用连续节点分析组。")
        for index, nodes in enumerate(selections, 1):
            if nodes[-1] not in available:
                raise ValueError(f"节点分析组 {index} 的末节点 {nodes[-1]} 在所选样品范围中没有数据，请调整 Sample IDs 或节点分析组。")
    elif node_mode == "combined_new":
        selections = [_combined_node_group(template, available, available)]
    else:
        ordered = list(dict.fromkeys(node for sequence in configured_node_sequences(template)
                                    for node in sequence if node in available))
        ordered.extend(sorted(available - set(ordered), key=natural_sort_key))
        selections = [[node] for node in ordered]
    selected_nodes = {node for group in selections for node in group}
    dimension = batch["batch_dimension"]
    chain_keys = {tuple(item.chain_key): item.chain_id for item in template.tsk_analysis.instances}
    identities = defaultdict(set)
    for row in rows:
        node = row.dimensions[node_name]
        if node not in selected_nodes:
            continue
        sample = _sample_key_from_dimensions(row.dimensions, template.report.sample_dimension_names)
        source_batch = _batch_value(row.dimensions, dimension) if dimension is not None else ""
        identities[(sample, node)].add(source_batch)
    if any(len(batches) > 1 for batches in identities.values()):
        raise ValueError("Analyze 的同一样品/节点跨越多个原批次；请将批次加入 Analyze 的唯一 Sample ID 字段后重新分析。")
    terminal_nodes = {nodes[-1] for nodes in selections}
    source_batches = {next(iter(values)) for (_, node), values in identities.items()
                      if node in terminal_nodes}
    if batch["batch_mode"] == "parent":
        missing = sorted(source for source in source_batches if not batch["batch_mapping"].get(source))
        if missing:
            raise ValueError("请为所有所选原批次填写母批编号：" + ", ".join(missing))

    states = defaultdict(dict)
    for (sample, node), batches in identities.items():
        outcomes = states[(node, next(iter(batches)))]
        for chain in chain_keys.values():
            outcomes[(sample, chain)] = "Missing"
    seen = set()
    for record in snapshot["summary_artifacts"]["final_status_rows"]:
        identity = (tuple(record["sample_key"]), record["node"])
        chain = chain_keys.get(tuple(record["test_group_key"]))
        if identity not in identities or chain is None:
            continue
        key = (*identity, chain)
        if key in seen:
            raise ValueError("Analyze 结果中一个样品/节点/Chain 存在多个状态，请检查唯一 Sample ID。")
        seen.add(key)
        batch_id = next(iter(identities[identity]))
        if record["is_fail"] and record.get("status") not in {"New", "Existed"}:
            raise ValueError("Analyze 结果缺少新增 / 已有异常标记，请重新运行 Analyze 后再分析 TSK。")
        failed = record["is_fail"] and record.get("status") == "New"
        states[(identity[1], batch_id)][(identity[0], chain)] = "Fail" if failed else "Pass"

    output = []
    labels = [" + ".join(nodes) for nodes in selections]
    for group_index, nodes in enumerate(selections):
        node = labels[group_index]
        terminal = nodes[-1]
        for source_batch in sorted({source for source_node, source in states if source_node == terminal},
                                   key=natural_sort_key):
            terminal_outcomes = states[(terminal, source_batch)]
            counts = {chain: dict(chain_id=chain, n_tested=0, n_failed=0, n_passed=0, n_missing=0)
                      for chain in chain_keys.values()}
            paired = []
            for (sample, chain), terminal_status in sorted(terminal_outcomes.items(), key=lambda item: (
                    tuple(natural_sort_key(value) for value in item[0][0]), natural_sort_key(item[0][1]))):
                statuses = [(selected, states.get((selected, source_batch), {}).get((sample, chain), "Missing"))
                            for selected in nodes]
                status = ("Missing" if terminal_status == "Missing" else
                          "Fail" if any(state == "Fail" for _, state in statuses) else "Pass")
                count = counts[chain]
                count[{"Missing": "n_missing", "Fail": "n_failed", "Pass": "n_passed"}[status]] += 1
                count["n_tested"] += int(status != "Missing")
                detail = ({"observed_nodes": [selected for selected, state in statuses if state != "Missing"],
                           "new_nodes": [selected for selected, state in statuses if state == "Fail"]}
                          if len(nodes) > 1 else {})
                paired.append({"sample_key": list(sample), "chain_id": chain, "status": status, **detail})
            label = f"{node_name}{' 新增组合' if len(nodes) > 1 else ''}={node}"
            if labels.count(node) > 1:
                label += f" [组 {group_index + 1}]"
            output.append({"label": label, "node": node, "stratum": {},
                           "node_mode": node_mode, "source_nodes": list(nodes), "denominator_node": terminal,
                           **({"node_group_index": group_index} if node_mode == "sequence_groups" else {}),
                           "counts": sorted(counts.values(), key=lambda row: natural_sort_key(row["chain_id"])),
                           "sample_outcomes": paired, "classification_warnings": list(warnings),
                           **({"source_batch": source_batch} if dimension is not None else {})})
    return _pool_batch_groups(output, batch) if dimension is not None else output
