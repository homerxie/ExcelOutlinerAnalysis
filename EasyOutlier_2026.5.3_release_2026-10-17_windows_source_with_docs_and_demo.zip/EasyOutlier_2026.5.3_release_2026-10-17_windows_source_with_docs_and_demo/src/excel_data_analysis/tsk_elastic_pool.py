"""Grow a group's leaf capacity with public, independently owned executors.

Existing futures never move between executors. New capacity receives only new
submissions; completed results and the caller's result ordering are untouched.
"""
import os


def _warm_worker():
    return os.getpid()


class ElasticProcessPool:
    def __init__(self, factory, **kwargs):
        self.factory, self.kwargs = factory, dict(kwargs)
        self.capacity = kwargs["max_workers"]
        self.shards = [(factory(**kwargs), self.capacity, [])]
        self.warmups = []
        self.closed = False

    @property
    def _processes(self):
        return {pid: process for pool, _, _ in self.shards
                for pid, process in (getattr(pool, "_processes", None) or {}).items()}

    def grow(self, target):
        if self.closed or target <= self.capacity:
            return
        from .tsk_parallel import _SPAWN_ENV_LOCK, _THREAD_ENV

        extra = target - self.capacity
        with _SPAWN_ENV_LOCK:
            previous = {name: os.environ.get(name) for name in _THREAD_ENV}
            try:
                os.environ.update({name: "1" for name in _THREAD_ENV})
                pool = self.factory(**{**self.kwargs, "max_workers": extra})
                # Retain even a partially started shard for exception cleanup.
                self.shards.append((pool, extra, []))
                for _ in range(extra):
                    self.warmups.append(pool.submit(_warm_worker))
                self.capacity = target
            finally:
                for name, value in previous.items():
                    if value is None:
                        os.environ.pop(name, None)
                    else:
                        os.environ[name] = value

    def submit(self, function, *args, **kwargs):
        for future in self.warmups:
            if future.done():
                future.result()  # An initializer failure is still infrastructure failure.
        self.warmups[:] = [future for future in self.warmups if not future.done()]
        for _, _, futures in self.shards:
            futures[:] = [future for future in futures if not future.done()]
        pool, _, futures = min(self.shards, key=lambda shard: len(shard[2]) / shard[1])
        # Executors may lazily spawn another worker on ANY submit, including
        # when fast warmup tasks used fewer processes than the shard capacity.
        from .tsk_parallel import _SPAWN_ENV_LOCK, _THREAD_ENV
        with _SPAWN_ENV_LOCK:
            previous = {name: os.environ.get(name) for name in _THREAD_ENV}
            try:
                os.environ.update({name: "1" for name in _THREAD_ENV})
                future = pool.submit(function, *args, **kwargs)
            finally:
                for name, value in previous.items():
                    if value is None:
                        os.environ.pop(name, None)
                    else:
                        os.environ[name] = value
        futures.append(future)
        return future

    def shutdown(self, *, wait=True, cancel_futures=False):
        self.closed = True
        first_error = None
        for pool, _, _ in self.shards:
            try:
                pool.shutdown(wait=wait, cancel_futures=cancel_futures)
            except BaseException as error:
                if first_error is None:
                    first_error = error
        if first_error is not None:
            raise first_error


def make_pool(factory, **kwargs):
    from .tsk_compute_budget import current_role

    return ElasticProcessPool(factory, **kwargs) if current_role() == "group" else factory(**kwargs)


def grow_pool(pool, maximum_tasks, execution=None):
    if not isinstance(pool, ElasticProcessPool):
        return None
    from .tsk_compute_budget import group_worker_limit

    target = min(group_worker_limit(), max(1, maximum_tasks))
    pool.grow(target)
    if execution is not None:
        previous = execution.get("workers_used", 1)
        execution.update(workers_used=pool.capacity,
                         max_workers_used=max(pool.capacity, execution.get("max_workers_used", 1)))
        if previous != pool.capacity:
            execution.setdefault("capacity_changes", []).append({"from": previous, "to": pool.capacity})
    return pool.capacity
