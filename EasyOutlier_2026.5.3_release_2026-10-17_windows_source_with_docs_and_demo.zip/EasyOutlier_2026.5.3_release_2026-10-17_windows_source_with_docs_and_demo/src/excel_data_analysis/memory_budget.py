"""Small native memory snapshots for sizing disposable in-memory plot history.

Reads only kernel counters: no process enumeration, subprocesses, swap probing
or third-party dependency. Callers should sample periodically, not while painting.
Available memory is a moving estimate, so the policy leaves an explicit reserve.
"""

from __future__ import annotations

import ctypes
from dataclasses import dataclass
from functools import lru_cache
import os
from pathlib import Path, PurePosixPath
import sys


GiB = 1024 ** 3
DEFAULT_HISTORY_BUDGET_BYTES = 96 * 1024 ** 2


@dataclass(frozen=True, slots=True)
class MemorySnapshot:
    total_bytes: int
    available_bytes: int


def recommended_history_budget(snapshot: MemorySnapshot | None) -> int:
    """Use at most a quarter of RAM and half of headroom beyond the reserve.

    Reserve the greater of 1 GiB and 10% of RAM for other applications and new
    analysis work. Pressure can reduce history to zero; 96 MiB is only a fallback
    when the operating-system snapshot is unavailable, never a minimum budget.
    """
    if snapshot is None or snapshot.total_bytes < 0:
        return DEFAULT_HISTORY_BUDGET_BYTES
    total = snapshot.total_bytes
    available = max(0, min(snapshot.available_bytes, total))
    reserve = max(GiB, total // 10)
    return min(total // 4, max(0, available - reserve) // 2)


def read_memory_snapshot() -> MemorySnapshot | None:
    """Return physical/effective memory, or None when counters are unavailable."""
    try:
        if sys.platform == "darwin":
            snapshot = _read_macos_memory()
        elif sys.platform == "win32":
            snapshot = _read_windows_memory()
        elif sys.platform.startswith("linux"):
            snapshot = _read_linux_memory()
        else:
            return None
        if snapshot is None or snapshot.total_bytes < 0 or snapshot.available_bytes < 0:
            return None
        return MemorySnapshot(snapshot.total_bytes, min(snapshot.total_bytes, snapshot.available_bytes))
    except (OSError, ValueError, TypeError, AttributeError, OverflowError):
        # Memory reporting is optional and must never prevent plot navigation.
        return None


class _MacVMStatistics(ctypes.Structure):
    # Fixed HOST_VM_INFO layout, verified against Apple's mach/vm_statistics.h
    # and mach/host_info.h SDK headers. natural_t is uint32 on Intel and ARM.
    _fields_ = [(name, ctypes.c_uint32) for name in (
        "free_count", "active_count", "inactive_count", "wire_count",
        "zero_fill_count", "reactivations", "pageins", "pageouts", "faults",
        "cow_faults", "lookups", "hits", "purgeable_count", "purges",
        "speculative_count",
    )]


@lru_cache(maxsize=1)
def _mac_memory_api():
    system = ctypes.CDLL("/usr/lib/libSystem.B.dylib", use_errno=True)
    system.sysctlbyname.argtypes = [ctypes.c_char_p, ctypes.c_void_p,
                                   ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p, ctypes.c_size_t]
    system.sysctlbyname.restype = ctypes.c_int
    system.mach_host_self.argtypes = []
    system.mach_host_self.restype = ctypes.c_uint32
    system.host_statistics.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_void_p,
                                      ctypes.POINTER(ctypes.c_uint32)]
    system.host_statistics.restype = ctypes.c_int
    page_size = int(os.sysconf("SC_PAGE_SIZE"))
    # Keep one host send right for this process; do not request a new right on
    # every timer tick. The loader itself runs once and retains the native library.
    return system, int(system.mach_host_self()), page_size


def _read_macos_memory() -> MemorySnapshot | None:
    system, host, page_size = _mac_memory_api()
    if not host or page_size <= 0:
        return None
    total = ctypes.c_uint64()
    size = ctypes.c_size_t(ctypes.sizeof(total))
    if system.sysctlbyname(b"hw.memsize", ctypes.byref(total), ctypes.byref(size), None, 0):
        return None
    if size.value != ctypes.sizeof(total) or not total.value:
        return None
    stats = _MacVMStatistics()
    count = ctypes.c_uint32(ctypes.sizeof(stats) // ctypes.sizeof(ctypes.c_uint32))
    if system.host_statistics(host, 2, ctypes.byref(stats), ctypes.byref(count)):
        return None
    if count.value < 4:
        return None
    # Speculative pages are already in free_count (Apple's SDK explicitly says
    # so). Do not add them again, nor compressed/swap or active/wired pages.
    available = (int(stats.free_count) + int(stats.inactive_count)) * page_size
    return MemorySnapshot(int(total.value), available)


class _WindowsMemoryStatus(ctypes.Structure):
    # DWORD stays 32-bit even when tests inspect this structure on 64-bit POSIX.
    # https://learn.microsoft.com/en-us/windows/win32/api/sysinfoapi/ns-sysinfoapi-memorystatusex
    _fields_ = [
        ("dwLength", ctypes.c_uint32), ("dwMemoryLoad", ctypes.c_uint32),
        ("ullTotalPhys", ctypes.c_uint64), ("ullAvailPhys", ctypes.c_uint64),
        ("ullTotalPageFile", ctypes.c_uint64), ("ullAvailPageFile", ctypes.c_uint64),
        ("ullTotalVirtual", ctypes.c_uint64), ("ullAvailVirtual", ctypes.c_uint64),
        ("ullAvailExtendedVirtual", ctypes.c_uint64),
    ]


@lru_cache(maxsize=1)
def _windows_memory_api():
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    query = kernel.GlobalMemoryStatusEx
    query.argtypes = [ctypes.POINTER(_WindowsMemoryStatus)]
    query.restype = ctypes.c_int
    return query


def _read_windows_memory() -> MemorySnapshot | None:
    info = _WindowsMemoryStatus()
    info.dwLength = ctypes.sizeof(info)
    if not _windows_memory_api()(ctypes.byref(info)) or not info.ullTotalPhys:
        return None
    return MemorySnapshot(int(info.ullTotalPhys), int(info.ullAvailPhys))


def _read_text(path: Path) -> str:
    return path.read_text(encoding="ascii")


def _linux_cgroup_paths() -> tuple[tuple[Path, str, str], ...]:
    """Standard cgroup mounts, including visible ancestor limits and namespaces.

    A namespace can expose its own cgroup as the mount root, so inspect the root
    even when the process membership uses a host-relative path not visible here.
    Nonstandard controller mounts cannot be discovered by this small fast reader.
    """
    v2_root = Path("/sys/fs/cgroup")
    v1_root = v2_root / "memory"
    paths = [(v2_root, "memory.max", "memory.current"),
             (v1_root, "memory.limit_in_bytes", "memory.usage_in_bytes")]
    try:
        membership = _read_text(Path("/proc/self/cgroup"))
    except OSError:
        return tuple(paths)
    for line in membership.splitlines():
        fields = line.split(":", 2)
        if len(fields) != 3:
            continue
        _, controllers, group = fields
        if not controllers:
            root, limit_name, usage_name = v2_root, "memory.max", "memory.current"
        elif "memory" in controllers.split(","):
            root, limit_name, usage_name = v1_root, "memory.limit_in_bytes", "memory.usage_in_bytes"
        else:
            continue
        parts = PurePosixPath(group).parts
        if not parts or parts[0] != "/" or ".." in parts:
            continue
        current = root
        for part in parts[1:]:
            current = current / part
            paths.append((current, limit_name, usage_name))
    return tuple(dict.fromkeys(paths))


def _read_linux_memory() -> MemorySnapshot | None:
    # Kernel MemAvailable already estimates reclaimable caches without swapping;
    # MemFree alone would unnecessarily discard useful history on Linux.
    # https://docs.kernel.org/filesystems/proc.html
    values = {}
    for line in _read_text(Path("/proc/meminfo")).splitlines():
        name, separator, payload = line.partition(":")
        if separator and name in {"MemTotal", "MemAvailable"}:
            parts = payload.split()
            if len(parts) != 2 or parts[1] != "kB":
                return None
            values[name] = int(parts[0]) * 1024
    total, available = values.get("MemTotal", 0), values.get("MemAvailable", -1)
    if total <= 0 or available < 0:
        return None
    # cgroup memory.max/current (or v1 limit/usage) bound the process's usable
    # headroom even when /proc/meminfo still describes the entire host.
    # https://docs.kernel.org/admin-guide/cgroup-v2.html
    for directory, limit_name, usage_name in _linux_cgroup_paths():
        try:
            raw_limit = _read_text(directory / limit_name).strip()
            if raw_limit == "max":
                continue
            limit = int(raw_limit)
        except (OSError, ValueError):
            continue
        if limit < 0:
            continue
        try:
            used = int(_read_text(directory / usage_name).strip())
            if used < 0:
                raise ValueError("Negative cgroup usage")
        except (OSError, ValueError):
            # A known hard limit without readable usage provides no safe
            # evidence of remaining capacity for additional history.
            used = limit
        total = min(total, limit)
        available = min(available, max(0, limit - used))
    return MemorySnapshot(total, min(total, available))
