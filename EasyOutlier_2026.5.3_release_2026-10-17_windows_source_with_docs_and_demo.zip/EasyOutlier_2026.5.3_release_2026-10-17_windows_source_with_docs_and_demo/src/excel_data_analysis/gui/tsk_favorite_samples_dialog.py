"""Choose common failed samples from the current group's bookmarked chains."""
from collections import Counter
from html import escape

from PySide6.QtCore import QAbstractTableModel, QEvent, QModelIndex, QTimer, Qt, Signal
from PySide6.QtGui import QFont, QKeySequence
from PySide6.QtWidgets import QDialog, QHeaderView

from ..tsk_favorite_samples import build_favorite_failure_samples
from .tsk_sample_table_support import HTML_ROLE, RichTextItemDelegate, copy_table_selection
from .ui_tsk_favorite_samples_dialog import Ui_TskFavoriteSamplesDialogForm


class _FailureMatrixModel(QAbstractTableModel):
    samples_selected = Signal()
    sample_pinned = Signal(object)

    def __init__(self, dialog):
        super().__init__(dialog)
        self.dialog = dialog
        self.result = build_favorite_failure_samples(None, ())
        self.samples = ()
        self.selected = set()

    def set_context(self, result, selected):
        self.beginResetModel()
        self.result = result
        self.selected = set(selected).intersection(sample.identity for sample in result.samples)
        self.samples = self._ordered_samples()
        self.endResetModel()

    def _ordered_samples(self):
        # Stable original order inside the pinned and unselected groups.
        return tuple(sorted(self.result.samples, key=lambda sample: sample.identity not in self.selected))

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() or not self.result.chains else len(self.result.chains) + 1

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.result.samples) + 1

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if orientation != Qt.Horizontal or not 0 <= section < self.columnCount():
            return None
        if role == Qt.DisplayRole:
            return (self.dialog._text("matrixChainHeaderText") if section == 0
                    else self.dialog.sample_title(self.samples[section - 1]))
        if role == Qt.ToolTipRole and section:
            return self.dialog.sample_tooltip(self.samples[section - 1])
        return None

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        row, column = index.row(), index.column()
        if role == Qt.DisplayRole:
            if column == 0:
                return self.dialog._text("extractRowText") if row == 0 else self.result.chains[row - 1]
            return ("✓" if row and self.result.chains[row - 1] in self.samples[column - 1].failed_chains
                    else "")
        if role == Qt.CheckStateRole and row == 0 and column:
            return Qt.Checked if self.samples[column - 1].identity in self.selected else Qt.Unchecked
        if role == Qt.TextAlignmentRole:
            return Qt.AlignVCenter | (Qt.AlignLeft if column == 0 else Qt.AlignHCenter)
        if role == Qt.FontRole and column == 0:
            font = QFont(self.dialog.ui.matrixTableView.font())
            font.setBold(True)
            return font
        if role == Qt.ToolTipRole and column:
            return self.dialog.sample_tooltip(self.samples[column - 1])
        return None

    def flags(self, index):
        if not index.isValid():
            return Qt.NoItemFlags
        flags = Qt.ItemIsEnabled | Qt.ItemIsSelectable
        if index.row() == 0 and index.column():
            flags |= Qt.ItemIsUserCheckable
        return flags

    def setData(self, index, value, role=Qt.EditRole):
        if role != Qt.CheckStateRole or not index.isValid() or index.row() != 0 or index.column() == 0:
            return False
        selected = set(self.selected)
        identity = self.samples[index.column() - 1].identity
        checked = value in (Qt.Checked, Qt.Checked.value)
        if checked:
            selected.add(identity)
        else:
            selected.discard(identity)
        self.select_samples(selected)
        if checked:
            self.sample_pinned.emit(identity)
        return True

    def select_samples(self, identities):
        selected = set(identities).intersection(sample.identity for sample in self.result.samples)
        if selected == self.selected:
            return
        self.selected = selected
        ordered = self._ordered_samples()
        if ordered != self.samples:
            # Preserve the user's selected cells/current index by sample ID as
            # columns move; clipboard selections must not drift to other IDs.
            self.layoutAboutToBeChanged.emit()
            previous = self.persistentIndexList()
            old_samples = self.samples
            self.samples = ordered
            columns = {sample.identity: column for column, sample in enumerate(self.samples, 1)}
            self.changePersistentIndexList(previous, [
                self.index(index.row(), columns[old_samples[index.column() - 1].identity] if index.column() else 0)
                for index in previous])
            self.layoutChanged.emit()
            self.headerDataChanged.emit(Qt.Horizontal, 1, self.columnCount() - 1)
        if self.result.samples:
            self.dataChanged.emit(self.index(0, 1), self.index(0, self.columnCount() - 1), [Qt.CheckStateRole])
        self.samples_selected.emit()


class _SampleDetailsModel(QAbstractTableModel):
    def __init__(self, dialog):
        super().__init__(dialog)
        self.dialog = dialog
        self.samples = ()
        self.favorites = set()
        self.only_favorites = False

    def set_context(self, samples, favorites, only_favorites):
        self.beginResetModel()
        self.samples = tuple(samples)
        self.favorites = set(favorites)
        self.only_favorites = only_favorites
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.samples)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else 2

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole and 0 <= section < 2:
            return self.dialog._text(("sampleIdHeaderText", "failedChainsHeaderText")[section])
        return None

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        sample = self.samples[index.row()]
        chains = [chain for chain in sample.failed_chains if not self.only_favorites or chain in self.favorites]
        if role == Qt.DisplayRole:
            return self.dialog.sample_title(sample) if index.column() == 0 else ", ".join(chains)
        if role == HTML_ROLE and index.column() == 1:
            color = self.dialog._text("favoriteHighlightColor")
            background = self.dialog._text("favoriteHighlightBackground")
            return ", ".join(
                f'<span style="color:{color};background-color:{background};font-weight:600">{escape(chain)}</span>'
                if chain in self.favorites else escape(chain) for chain in chains)
        if role == Qt.ToolTipRole:
            return self.dialog.sample_tooltip(sample) if index.column() == 0 else ", ".join(chains)
        return None


class TskFavoriteSamplesDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskFavoriteSamplesDialogForm()
        self.ui.setupUi(self)
        self._group = None
        self._failed_samples_loading = False
        self._failed_samples_error = ""
        self._sample_name_counts = Counter()
        self.matrix_model = _FailureMatrixModel(self)
        self.details_model = _SampleDetailsModel(self)
        self.ui.matrixTableView.setModel(self.matrix_model)
        self.ui.sampleDetailsTableView.setModel(self.details_model)
        self.ui.sampleDetailsTableView.setItemDelegateForColumn(1, RichTextItemDelegate(self.ui.sampleDetailsTableView))
        self._detail_resize_timer = QTimer(self)
        self._detail_resize_timer.setSingleShot(True)
        self._detail_resize_timer.timeout.connect(self.ui.sampleDetailsTableView.resizeRowsToContents)
        self.ui.matrixTableView.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.ui.sampleDetailsTableView.horizontalHeader().sectionResized.connect(self._resize_detail_rows)
        self.matrix_model.samples_selected.connect(self._refresh_details)
        self.matrix_model.sample_pinned.connect(self._show_pinned_sample)
        self.ui.selectAllSamplesButton.clicked.connect(self._select_all)
        self.ui.clearSamplesButton.clicked.connect(lambda: self.matrix_model.select_samples(()))
        self.ui.onlyFavoritesCheckBox.toggled.connect(self._refresh_details)
        for view, copy_action, headers_action in (
            (self.ui.matrixTableView, self.ui.matrixCopyAction, self.ui.matrixCopyHeadersAction),
            (self.ui.sampleDetailsTableView, self.ui.detailsCopyAction, self.ui.detailsCopyHeadersAction),
        ):
            view.addActions([copy_action, headers_action])
            copy_action.triggered.connect(lambda _checked=False, table=view: self._copy(table))
            headers_action.triggered.connect(lambda _checked=False, table=view: self._copy(table, include_headers=True))
            view.installEventFilter(self)
            view.selectionModel().selectionChanged.connect(self._update_copy_actions)
        self._update_copy_actions()

    def _text(self, name, **values):
        return str(self.property(name) or "").format(**values)

    def sample_title(self, sample):
        if self._sample_name_counts[sample.sample_id] > 1:
            return self._text("sourceBatchFormat", sample=sample.sample_id,
                              batch=sample.source_batch if sample.source_batch is not None else self._text("blankBatchText"))
        return sample.sample_id

    def sample_tooltip(self, sample):
        return self._text("sourceBatchToolTipFormat", sample=sample.sample_id,
                          batch=sample.source_batch if sample.source_batch is not None else self._text("blankBatchText"))

    def set_context(self, group, favorites):
        result = build_favorite_failure_samples(group, favorites)
        selected = self.matrix_model.selected if group is self._group else set()
        if group is not self._group:
            self._failed_samples_loading = False
            self._failed_samples_error = ""
        self._group = group
        self._sample_name_counts = Counter(sample.sample_id for sample in result.samples)
        self.matrix_model.set_context(result, selected)
        self.ui.contextLabel.setText(self._text("contextFormat", group=group.get("label") or group.get("node") or "",
                                                chains=len(result.chains)))
        self._refresh_availability()
        self._refresh_details()

    def set_failed_samples_state(self, *, loading=False, error=""):
        self._failed_samples_loading = loading
        self._failed_samples_error = error
        self._refresh_availability()

    def _refresh_availability(self):
        result = self.matrix_model.result
        if not result.chains:
            message = self._text("noFavoritesText")
        elif not result.details_available:
            message = (self._text("loadingFailedSamplesText") if self._failed_samples_loading else
                       self._failed_samples_error or self._text("unavailableText"))
        elif result.incomplete_chains:
            message = self._text("incompleteFormat", chains=", ".join(result.incomplete_chains))
        elif not result.samples:
            message = self._text("noFailuresText")
        else:
            message = ""
        self.ui.availabilityLabel.setText(message)
        self.ui.availabilityLabel.setVisible(bool(message))

    def _select_all(self):
        self.matrix_model.select_samples(sample.identity for sample in self.matrix_model.result.samples)

    def _show_pinned_sample(self, identity):
        column = next(column for column, sample in enumerate(self.matrix_model.samples, 1) if sample.identity == identity)
        self.ui.matrixTableView.scrollTo(self.matrix_model.index(0, 0))
        self.ui.matrixTableView.scrollTo(self.matrix_model.index(0, column))

    def _refresh_details(self, *_):
        result = self.matrix_model.result
        selected = self.matrix_model.selected
        self.details_model.set_context([sample for sample in result.samples if sample.identity in selected],
                                       result.chains, self.ui.onlyFavoritesCheckBox.isChecked())
        self.ui.selectionCountLabel.setText(self._text("summaryFormat", samples=len(result.samples), selected=len(selected)))
        self.ui.selectAllSamplesButton.setEnabled(len(selected) < len(result.samples))
        self.ui.clearSamplesButton.setEnabled(bool(selected))
        self.ui.onlyFavoritesCheckBox.setEnabled(bool(result.samples))
        self.ui.statusLabel.setText(self._text("summaryFormat", samples=len(result.samples), selected=len(selected))
                                   if selected else self._text("selectionHint"))
        self._resize_detail_rows()
        self._update_copy_actions()

    def _resize_detail_rows(self, *_):
        # Header resize signals precede the viewport's final geometry. Reflow
        # once it settles so narrowing the window cannot clip the last line.
        self._detail_resize_timer.start(0)

    def _copy(self, view, *, include_headers=False):
        if copy_table_selection(view, include_headers=include_headers):
            self.ui.statusLabel.setText(self._text("copiedText"))

    def _update_copy_actions(self, *_):
        for view, actions in (
            (self.ui.matrixTableView, (self.ui.matrixCopyAction, self.ui.matrixCopyHeadersAction)),
            (self.ui.sampleDetailsTableView, (self.ui.detailsCopyAction, self.ui.detailsCopyHeadersAction)),
        ):
            for action in actions:
                action.setEnabled(view.selectionModel().hasSelection())

    def eventFilter(self, watched, event):
        if watched in (self.ui.matrixTableView, self.ui.sampleDetailsTableView) and event.type() == QEvent.KeyPress:
            if event.matches(QKeySequence.Copy) or (event.key() == Qt.Key_C and event.modifiers() == Qt.ControlModifier):
                self._copy(watched)
                event.accept()
                return True
        return super().eventFilter(watched, event)
