"""Stable all-instance label reservations, independent of the visible viewport."""
from __future__ import annotations

import math
from dataclasses import dataclass
from statistics import median

from PySide6.QtCore import QPointF, QRectF


@dataclass(frozen=True)
class LabelConstraints:
    """Fixed coordinate-space ownership, plus continuously shrinking obstacles."""

    cell: tuple[float, float, float, float]
    point_extrema: tuple[float, float, float, float]
    initial_point_radius: float


def stable_label_constraints(anchors, rects, *, spacing_scale=1., point_radius=12., overlay=False,
                             avoid_points=True):
    """Give each initial label a disjoint region that does not depend on zoom.

    Each pair of padded labels has at least one separating axis. Keep that
    ordering by assigning the intervening midpoint to both ownership regions.
    Their intersections are rectangles containing the initial padded labels.
    Point obstacles retain a separating axis too, but their boundary may move
    continuously as a screen-size cap reduces their coordinate-space radius.

    NumPy operates on one row of pairs at a time: construction is quadratic,
    while memory and Python/Qt work remain linear in the number of labels.
    """
    import numpy as np

    if len(anchors) != len(rects):
        raise ValueError("Anchors and label rectangles must have equal lengths")
    count = len(rects)
    active = [index for index, rect in enumerate(rects) if rect is not None]
    if not active:
        return [None] * count
    padding = 3. * spacing_scale
    padded = [rects[index].adjusted(-padding, -padding, padding, padding) for index in active]
    edges = np.asarray([(rect.left(), rect.top(), rect.right(), rect.bottom()) for rect in padded])
    widths, heights = edges[:, 2] - edges[:, 0], edges[:, 3] - edges[:, 1]
    cells = np.tile((-np.inf, -np.inf, np.inf, np.inf), (len(active), 1))
    tiny = np.finfo(float).tiny

    for index, (left, top, right, bottom) in enumerate(edges[:-1]):
        rest = edges[index + 1:]
        x_gap = np.maximum(rest[:, 0] - right, left - rest[:, 2])
        y_gap = np.maximum(rest[:, 1] - bottom, top - rest[:, 3])
        if np.any((x_gap < 0.) & (y_gap < 0.)):
            raise ValueError("Initial padded label rectangles must not overlap")
        # A roomier separation leaves more freedom to approach the anchor
        # after a cap, without changing the labels' established ordering.
        horizontal = (x_gap >= 0.) & ((y_gap < 0.) | (
            x_gap / np.maximum(widths[index] + widths[index + 1:], tiny)
            >= y_gap / np.maximum(heights[index] + heights[index + 1:], tiny)))
        masks = (horizontal & (rest[:, 0] >= right),
                 ~horizontal & (rest[:, 1] >= bottom),
                 horizontal & (rest[:, 2] <= left),
                 ~horizontal & (rest[:, 3] <= top))
        # (own bound, other's bound, first edge, other edge).
        for mask, own_side, other_side, edge, other_edge in (
                (masks[0], 2, 0, right, 0), (masks[1], 3, 1, bottom, 1),
                (masks[2], 0, 2, left, 2), (masks[3], 1, 3, top, 3)):
            offsets = np.flatnonzero(mask)
            if not offsets.size:
                continue
            neighbors = offsets + index + 1
            boundaries = (edge + rest[offsets, other_edge]) / 2.
            if own_side < 2:
                cells[index, own_side] = max(cells[index, own_side], boundaries.max())
                cells[neighbors, other_side] = np.minimum(cells[neighbors, other_side], boundaries)
            else:
                cells[index, own_side] = min(cells[index, own_side], boundaries.min())
                cells[neighbors, other_side] = np.maximum(cells[neighbors, other_side], boundaries)

    points = np.asarray([(point.x(), point.y()) for point in anchors])
    result = [None] * count
    for row, index in enumerate(active):
        if not avoid_points:
            result[index] = LabelConstraints(tuple(float(value) for value in cells[row]),
                                             (-math.inf, -math.inf, math.inf, math.inf), 0.)
            continue
        left, top, right, bottom = edges[row]
        xs, ys = points[:, 0], points[:, 1]
        x_gap = np.maximum(left - xs - point_radius, xs - point_radius - right)
        y_gap = np.maximum(top - ys - point_radius, ys - point_radius - bottom)
        relevant = np.ones(count, dtype=bool)
        if overlay:
            relevant[index] = False
        if np.any(relevant & (x_gap < 0.) & (y_gap < 0.)):
            raise ValueError("Initial padded labels must avoid other point obstacles")
        horizontal = (x_gap >= 0.) & ((y_gap < 0.) | (
            x_gap / max(widths[row] + 2 * point_radius, tiny)
            >= y_gap / max(heights[row] + 2 * point_radius, tiny)))
        masks = (relevant & horizontal & (xs + point_radius <= left),
                 relevant & ~horizontal & (ys + point_radius <= top),
                 relevant & horizontal & (xs - point_radius >= right),
                 relevant & ~horizontal & (ys - point_radius >= bottom))
        extrema = (float(xs[masks[0]].max()) if masks[0].any() else -math.inf,
                   float(ys[masks[1]].max()) if masks[1].any() else -math.inf,
                   float(xs[masks[2]].min()) if masks[2].any() else math.inf,
                   float(ys[masks[3]].min()) if masks[3].any() else math.inf)
        result[index] = LabelConstraints(tuple(float(value) for value in cells[row]), extrema,
                                         float(point_radius))
    return result


def place_constrained_labels(anchors, rects, constraints, *, text_ratio=1., point_radius=12., spacing_scale=1.):
    """Shrink capped labels toward their anchors without assigning new slots.

    Before the text cap, positions remain exactly their original world
    coordinates, even if dots have already reached their own cap. Afterwards
    projection into each fixed ownership rectangle is continuous, reversible,
    and cannot introduce a collision with another label or a point.
    """
    if len(anchors) != len(rects) or len(rects) != len(constraints):
        raise ValueError("Anchors, rectangles and constraints must have equal lengths")
    ratio = max(0., min(1., float(text_ratio)))
    if ratio == 1.:
        return [QRectF(rect) if rect is not None else None for rect in rects]
    padding = 3. * spacing_scale * ratio
    result = []
    for anchor, original, constraint in zip(anchors, rects, constraints):
        if original is None:
            result.append(None)
            continue
        left, top, right, bottom = constraint.cell
        left_point, top_point, right_point, bottom_point = constraint.point_extrema
        radius = min(point_radius, constraint.initial_point_radius)
        width, height = original.width() * ratio, original.height() * ratio
        half_width, half_height = width / 2. + padding, height / 2. + padding
        # Keep a few ulps inside shared boundaries. Reconstructing a QRectF
        # from its center otherwise makes touching padded edges overlap by
        # rounding error. Available shrinkage bounds the inset, so it also
        # tends continuously to zero at the cap and cannot remove feasibility.
        magnitude = max(abs(original.left()), abs(original.right()), abs(original.top()),
                        abs(original.bottom()), abs(anchor.x()), abs(anchor.y()), 1.)
        inset = min(math.ulp(magnitude) * 8.,
                    (original.width() + 6. * spacing_scale) * (1. - ratio) / 4.,
                    (original.height() + 6. * spacing_scale) * (1. - ratio) / 4.)
        low_x = max(left, left_point + radius) + half_width + inset
        high_x = min(right, right_point - radius) - half_width - inset
        low_y = max(top, top_point + radius) + half_height + inset
        high_y = min(bottom, bottom_point - radius) - half_height - inset
        desired = anchor + (original.center() - anchor) * ratio
        center_x = max(low_x, min(high_x, desired.x()))
        center_y = max(low_y, min(high_y, desired.y()))
        result.append(QRectF(center_x - width / 2., center_y - height / 2., width, height))
    return result


class RectIndex:
    def __init__(self, cell_size=64.):
        self.cell_size = cell_size
        self.buckets = {}

    def cells(self, rect):
        for x in range(math.floor(rect.left() / self.cell_size), math.floor(rect.right() / self.cell_size) + 1):
            for y in range(math.floor(rect.top() / self.cell_size), math.floor(rect.bottom() / self.cell_size) + 1):
                yield x, y

    def add(self, rect, owner=None):
        for cell in self.cells(rect):
            self.buckets.setdefault(cell, []).append((rect, owner))

    def intersects(self, rect, ignore=None):
        return any((ignore is None or owner != ignore) and rect.intersects(other)
                   for cell in self.cells(rect) for other, owner in self.buckets.get(cell, ()))


def _spiral(x, y):
    """Infinite empty-slot search; each coincident anchor shares its cursor."""
    yield x, y
    radius = 1
    while True:
        for dx in range(-radius, radius + 1):
            yield x + dx, y - radius
            yield x + dx, y + radius
        for dy in range(-radius + 1, radius):
            yield x - radius, y + dy
            yield x + radius, y + dy
        radius += 1


def compact_label_scale(anchors, sizes, maximum=.65, *, vertical=False):
    """Estimate text size from typical spacing, not the closest pair globally.

    An isolated crowded pair must not make the entire map microscopic. Use
    median nearest-neighbor distance in label-sized cells; the packer handles
    local conflicts and coincident coordinates without hiding any labels.
    """
    from scipy.spatial import cKDTree

    width = max((width for width, height in sizes if height), default=1.)
    height = max((height for width, height in sizes if height), default=1.)
    width = max(width + 6, width / 2 + 15) if vertical else width + 32
    height = height + 32 if vertical else max(height + 6, height / 2 + 15)
    points = sorted({(point.x() / width, point.y() / height) for point in anchors})
    if len(points) < 2:
        return maximum
    distances, _ = cKDTree(points).query(points, k=2, p=math.inf)
    return min(maximum, float(median(distances[:, 1])))


def pack_label_rectangles(anchors, sizes, *, overlay=False, spacing_scale=1., preferred_axis="horizontal",
                          point_radius=12., avoid_points=True):
    """Retain every nonempty label, reserving disjoint padded rectangles.

    Try nearby positions first. A shared grid of vacant slots provides a
    guaranteed fallback, without repeatedly searching from zero for hundreds
    of coincident instances. Overlay ignores only the label's own point.
    """
    cell_size = max(64., point_radius * 2, max((max(size) for size in sizes), default=1.))
    occupied, point_boxes = RectIndex(cell_size), RectIndex(cell_size)
    padding, radius = 3 * spacing_scale, point_radius
    gap = radius + 4 * spacing_scale
    point_owners = {}
    for index, point in enumerate(anchors):
        key = point.x(), point.y()
        point_owners[key] = None if key in point_owners else index
    # Duplicate coordinates share one obstacle. Otherwise every nearby query
    # scans thousands of identical point boxes before reaching a placed label.
    if avoid_points:
        for (x, y), owner in point_owners.items():
            point_boxes.add(QRectF(x - radius, y - radius, radius * 2, radius * 2), owner)
    # Tiny text beside a large coordinate-sized point must not search millions
    # of microscopic grid slots just to get past the point's obstacle.
    cell_width = max(radius, max((width for width, height in sizes if height), default=1.) + 4 * padding)
    cell_height = max(radius, max((height for width, height in sizes if height), default=1.) + 4 * padding)
    cursors, blocked_cells, result = {}, set(), []
    for index, (point, (width, height)) in enumerate(zip(anchors, sizes)):
        if not height:
            result.append(None)
            continue
        horizontal = [(gap, -height / 2), (-width - gap, -height / 2)]
        vertical = [(-width / 2, -height - gap), (-width / 2, gap)]
        # Stay on the point's row or column; use the roomier axis first.
        candidates = vertical + horizontal if preferred_axis == "vertical" else horizontal + vertical
        if overlay:
            candidates.insert(0, (-width / 2, -height / 2))
        region = None
        for dx, dy in candidates:
            candidate = QRectF(point.x() + dx, point.y() + dy, width, height)
            padded = candidate.adjusted(-padding, -padding, padding, padding)
            if not occupied.intersects(padded) and not point_boxes.intersects(padded, ignore=index if overlay else None):
                region = candidate
                break
        if region is None:
            origin = (round(point.x() / cell_width), round(point.y() / cell_height))
            cursor = cursors.setdefault(origin, _spiral(*origin))
            for cell in cursor:
                if cell in blocked_cells:
                    continue
                blocked_cells.add(cell)
                center = QPointF(cell[0] * cell_width, cell[1] * cell_height)
                # Test the full slot so rejection can be shared across labels.
                slot = QRectF(center.x() - (cell_width - 2 * padding) / 2,
                              center.y() - (cell_height - 2 * padding) / 2,
                              cell_width - 2 * padding, cell_height - 2 * padding)
                if not occupied.intersects(slot) and not point_boxes.intersects(slot):
                    region = QRectF(center.x() - width / 2, center.y() - height / 2, width, height)
                    break
        occupied.add(region.adjusted(-padding, -padding, padding, padding))
        result.append(region)
    return result
