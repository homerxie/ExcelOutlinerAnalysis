"""Modeless field-tag editor for coordinate labels, with form-backed rows."""
from html import escape
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QDialog, QListWidgetItem, QWidget

from .tsk_coordinate_labels import available_field_keys, default_label_rows, normalize_label_rows, render_label_lines
from .ui_tsk_label_layout_dialog import Ui_TskLabelLayoutDialogForm
from .ui_tsk_label_layout_row import Ui_TskLabelLayoutRowForm


class TskLabelLayoutRow(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskLabelLayoutRowForm()
        self.ui.setupUi(self)


class TskLabelLayoutDialog(QDialog):
    layout_changed = Signal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskLabelLayoutDialogForm()
        self.ui.setupUi(self)
        self._token = object()
        self._features = []
        self._field_labels = {}
        self._preview_point = None
        self._separator = " · "
        self.row_widgets = []
        self.ui.hiddenTags.editor_token = self._token
        self.ui.hiddenTags.tags_moved.connect(self._changed)
        self.ui.addRowButton.clicked.connect(self.add_row)
        self.ui.resetButton.clicked.connect(self.reset_layout)
        self.ui.closeButton.clicked.connect(self.close)

    @property
    def label_rows(self):
        return [row.ui.tags.field_keys() for row in self.row_widgets]

    def set_context(self, feature_names, rows, preview_point, separator=" · "):
        self._features = list(dict.fromkeys(feature_names))
        names = dict(line.split("=", 1) for line in str(self.property("builtinFieldLabels")).splitlines() if "=" in line)
        self._field_labels = {key: names[key] if key in names else key.removeprefix("feature:")
                              for key in available_field_keys(self._features)}
        self._separator = separator
        self._preview_point = preview_point
        self._set_rows(normalize_label_rows(rows, self._field_labels))

    def set_preview_point(self, point):
        self._preview_point = point
        self._update_preview()

    def _populate(self, tags, keys):
        tags.clear()
        for key in keys:
            item = QListWidgetItem(self._field_labels[key], tags)
            item.setData(Qt.UserRole, key)
            item.setToolTip("<qt>" + escape(self._field_labels[key]) + "</qt>")
            item.setFlags(item.flags() & ~Qt.ItemIsEditable)

    def _set_rows(self, rows):
        for row in self.row_widgets:
            self.ui.rowsLayout.removeWidget(row)
            row.hide()
            row.deleteLater()
        self.row_widgets = []
        for keys in rows:
            self._append_row(keys)
        shown = {key for keys in rows for key in keys}
        self._populate(self.ui.hiddenTags, [key for key in self._field_labels if key not in shown])
        self._update_rows()
        self._update_preview()

    def _append_row(self, keys):
        row = TskLabelLayoutRow(self.ui.rowsContainer)
        row.ui.tags.editor_token = self._token
        self._populate(row.ui.tags, keys)
        row.ui.tags.tags_moved.connect(self._changed)
        row.ui.upButton.clicked.connect(lambda: self._move_row(row, -1))
        row.ui.downButton.clicked.connect(lambda: self._move_row(row, 1))
        row.ui.removeButton.clicked.connect(lambda: self._remove_row(row))
        self.row_widgets.append(row)
        self.ui.rowsLayout.insertWidget(len(self.row_widgets) - 1, row)
        return row

    def add_row(self):
        row = self._append_row([])
        self._changed()
        self.ui.rowsScrollArea.ensureWidgetVisible(row)

    def _update_rows(self):
        for index, row in enumerate(self.row_widgets):
            row.ui.rowLabel.setText(str(row.property("rowFormat")).format(number=index + 1))
            row.ui.upButton.setEnabled(index > 0)
            row.ui.downButton.setEnabled(index + 1 < len(self.row_widgets))

    def _move_row(self, row, direction):
        index = self.row_widgets.index(row)
        target = index + direction
        if not 0 <= target < len(self.row_widgets):
            return
        self.row_widgets[index], self.row_widgets[target] = self.row_widgets[target], row
        self.ui.rowsLayout.removeWidget(row)
        self.ui.rowsLayout.insertWidget(target, row)
        self._changed()

    def _remove_row(self, row):
        # Removing a line is reversible: its tags go into the hidden pool.
        while row.ui.tags.count():
            self.ui.hiddenTags.addItem(row.ui.tags.takeItem(0))
        self.row_widgets.remove(row)
        self.ui.rowsLayout.removeWidget(row)
        row.hide()
        row.deleteLater()
        self._changed()

    def move_field(self, key, target_row, position=None):
        if target_row is not None and not 0 <= target_row < len(self.row_widgets):
            return False
        target = self.ui.hiddenTags if target_row is None else self.row_widgets[target_row].ui.tags
        sources = [row.ui.tags for row in self.row_widgets] + [self.ui.hiddenTags]
        source = next((tags for tags in sources if key in tags.field_keys()), None)
        if source is None:
            return False
        return target.transfer_from(source, key, target.count() if position is None else position)

    def reset_layout(self):
        self._set_rows(default_label_rows(self._features))
        self._changed()

    def _changed(self):
        self._update_rows()
        self._update_preview()
        self.layout_changed.emit(self.label_rows)

    def _update_preview(self):
        point = self._preview_point
        if point is None:
            self.ui.previewTitle.setText(str(self.ui.previewTitle.property("defaultText")))
            self.ui.previewEdit.setPlainText(str(self.property("noInstanceText")))
            return
        self.ui.previewTitle.setText(str(self.property("previewFormat")).format(instance=point.instance_id))
        lines = render_label_lines(point, self.label_rows, self._separator)
        self.ui.previewEdit.setPlainText("\n".join(lines) if lines else str(self.property("emptyPreviewText")))
