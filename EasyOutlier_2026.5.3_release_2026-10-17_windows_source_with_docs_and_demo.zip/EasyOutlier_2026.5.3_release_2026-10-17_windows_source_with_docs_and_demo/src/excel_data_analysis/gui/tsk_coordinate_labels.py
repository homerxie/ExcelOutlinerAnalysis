"""Value-only coordinate labels with user-controlled rows and field order."""
from __future__ import annotations

from collections.abc import Iterable
import re
from typing import TYPE_CHECKING

from .tsk_risk_display import valid_probability

if TYPE_CHECKING:
    from .tsk_coordinate_plot import CoordinateInstance


BUILTIN_FIELD_KEYS = (
    "tsk_id", "instance_id", "chain_id", "x", "y",
    "probability", "observed", "predicted",
)
FEATURE_PREFIX = "feature:"
_PROBABILITY_FIELDS = frozenset(("probability", "observed", "predicted"))


def available_field_keys(feature_names: Iterable[str]) -> list[str]:
    """Keep feature identity separate from built-ins, preserving source order."""
    return list(dict.fromkeys([
        *BUILTIN_FIELD_KEYS,
        *(FEATURE_PREFIX + name for name in feature_names if isinstance(name, str)),
    ]))


def default_label_rows(feature_names: Iterable[str]) -> list[list[str]]:
    """Share the identity row; show each feature and the fitted risk below it."""
    features = available_field_keys(feature_names)[len(BUILTIN_FIELD_KEYS):]
    return [["tsk_id", "instance_id"], *[[key] for key in features], ["probability"]]


def normalize_label_rows(rows, available: Iterable[str]) -> list[list[str]]:
    """Remove invalid/duplicate fields without restoring intentionally hidden ones.

    Empty rows are meaningful editor drop targets and survive normalization.
    Every result owns its lists so editing it cannot mutate saved input state.
    """
    if not isinstance(rows, (list, tuple)):
        return []
    allowed = {key for key in available if isinstance(key, str)}
    seen = set()
    result = []
    for row in rows:
        if not isinstance(row, (list, tuple)):
            continue
        fields = []
        for key in row:
            if isinstance(key, str) and key in allowed and key not in seen:
                fields.append(key)
                seen.add(key)
        result.append(fields)
    return result


def _single_line(value) -> str:
    if value is None:
        return ""
    return re.sub(r"[\r\n\t]+", " ", str(value)).strip()


def _field_value(point: CoordinateInstance, key: str) -> str:
    if key.startswith(FEATURE_PREFIX):
        return _single_line(point.features.get(key[len(FEATURE_PREFIX):]))
    if key not in BUILTIN_FIELD_KEYS:
        return ""
    value = getattr(point, key, None)
    if key in _PROBABILITY_FIELDS:
        return f"{100 * value:.4g}%" if valid_probability(value) else "—"
    if key in {"x", "y"} and isinstance(value, (int, float)) and not isinstance(value, bool):
        return f"{value:g}"
    return _single_line(value)


def render_label_lines(
    point: CoordinateInstance, rows, separator: str = " · ",
) -> list[str]:
    """Render plain values in row order, omitting rows without visible values."""
    normalized = normalize_label_rows(rows, available_field_keys(point.features))
    lines = []
    for row in normalized:
        values = [_field_value(point, key) for key in row]
        line = separator.join(value for value in values if value)
        if line:
            lines.append(line)
    return lines
