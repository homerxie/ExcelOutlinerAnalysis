"""Shared risk-dimension filters and TSK-combination navigation for the map."""
from __future__ import annotations

from PySide6.QtCore import QSignalBlocker, Qt, Signal
from PySide6.QtWidgets import QTreeWidgetItem, QWidget

from ..tsk_features import category_label, risk_category_definitions
from ..tsk_sorting import natural_sort_key, numeric_sort_key
from .tsk_risk_display import percentage, valid_probability
from .tsk_risk_filter import TskRiskFilter
from .ui_tsk_coordinate_search_panel import Ui_TskCoordinateSearchPanelForm


def _text_value(value):
    return "" if value is None else str(value)


def _identity(tsk_id, features):
    # Empty, missing and None values are the same filter choice. Physical IDs,
    # coordinates and chain membership never distinguish a TSK combination.
    return (_text_value(tsk_id), tuple(sorted((str(name), _text_value(value))
            for name, value in features.items() if _text_value(value))))


def _category_value(value, name):
    try:
        return category_label(value, name)
    except ValueError:
        return ""


def _text_category(value):
    if not isinstance(value, str) or not value.strip():
        return False
    try:
        float(value)
    except ValueError:
        return True
    return False


def _category_dimensions(group, template_config, rows, points):
    """Use the bar chart's dimensions, including before a fit is available."""
    definitions = risk_category_definitions(group)
    context = group.get("prediction_context") or {}
    diagnostics = group.get("diagnostics") or {}
    options = group.get("options") or {}
    if definitions or context.get("categorical_features") or diagnostics.get("categorical_features"):
        return definitions
    if "categorical_feature_names" in options:
        return {name: {} for name in options["categorical_feature_names"]}
    if diagnostics.get("model") == "type_only":
        return {}
    if "categorical_feature_columns" in template_config:
        return {name: {} for name in template_config["categorical_feature_columns"]}

    # Old map-only payloads lack schema metadata. Explicit categories and text
    # columns are still useful; continuous numbers must not split each point.
    values, explicit = {}, set()
    for row in rows:
        explicit.update(row.get("categories") or {})
        for name, value in {**(row.get("features") or {}), **(row.get("categories") or {})}.items():
            values.setdefault(str(name), []).append(value)
    for point in points:
        for name, value in point.features.items():
            values.setdefault(str(name), []).append(value)
    return {name: {} for name, choices in values.items() if name.casefold() not in {"x", "y"}
            and (name in explicit or any(_text_category(value) for value in choices))}


class TskCoordinateSearchPanel(QWidget):
    instances_selected = Signal(object)
    chain_selected = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskCoordinateSearchPanelForm()
        self.ui.setupUi(self)
        self._filter_widgets = {}
        self._source_entries = []
        self._visible_entries = []
        self._group_key = None
        self.ui.clearFiltersButton.clicked.connect(self._clear_filters)
        self.ui.sortFieldComboBox.currentIndexChanged.connect(self._sort_field_changed)
        self.ui.sortDirectionComboBox.currentIndexChanged.connect(self._apply_filters)
        self.ui.resultsTreeWidget.itemClicked.connect(self._activate_item)
        self.ui.resultsTreeWidget.itemActivated.connect(self._activate_item)

    def _text(self, key, **values):
        return str(self.property(key) or "").format(**values)

    @staticmethod
    def _field_value(entry, field):
        return entry["tsk_id"] if field == "tsk_id" else _text_value(entry["features"].get(field[8:]))

    def set_context(self, points, topology, group=None, *, reset=False, template_config=None):
        """Group the bar chart's TSK/category combinations across map instances."""
        group = group or {}
        group_key = tuple(repr(group.get(name)) for name in ("node", "test_group_key", "label"))
        reset = reset or group_key != self._group_key
        self._group_key = group_key
        points = list(points)
        topology = [row for row in topology or [] if isinstance(row, dict)]
        categories = _category_dimensions(group, template_config or {}, topology, points)
        feature_names = list(categories)
        entries = {}

        def add(chain_id, tsk_id, features, index=None):
            features = {name: _category_value(features.get(name), name) for name in feature_names}
            key = _identity(tsk_id, features)
            entry = entries.setdefault(key, dict(key=key, tsk_id=_text_value(tsk_id),
                features=features, chains=set(), indexes=set(), probabilities=[]))
            entry["chains"].add(_text_value(chain_id))
            if index is not None:
                entry["indexes"].add(index)
                if valid_probability(points[index].probability):
                    entry["probabilities"].append(points[index].probability)

        attributes = {}
        for row in topology:
            features = {**(row.get("features") or {}), **(row.get("categories") or {})}
            add(row.get("chain_id"), row.get("tsk_id"), features)
            key = (_text_value(row.get("chain_id")), _text_value(row.get("tsk_id")),
                   _text_value(row.get("tsk_instance_id", row.get("instance_id"))), row.get("x"), row.get("y"))
            attributes[key] = features
        # Also support direct map inputs and partial legacy topology payloads.
        for index, point in enumerate(points):
            key = (point.chain_id, point.tsk_id, point.instance_id, point.x, point.y)
            features = {**attributes.get(key, {}), **point.features}
            add(point.chain_id, point.tsk_id, features, index)
        for entry in entries.values():
            entry["features"] = {name: entry["features"].get(name, "") for name in feature_names}
            entry["indexes"] = sorted(entry["indexes"])
            entry["chains"] = sorted(entry["chains"], key=natural_sort_key)
            risks = entry.pop("probabilities")
            entry["probability"] = max(risks) if risks else None
        self._source_entries = list(entries.values())
        fields = {"tsk_id": self._text("tskText"), **{"feature:" + name: name for name in feature_names}}
        previous = {} if reset else {field: (list(widget.values), widget.selected_values)
                                     for field, widget in self._filter_widgets.items()}
        if list(fields) != list(self._filter_widgets):
            for widget in self._filter_widgets.values():
                self.ui.filtersLayout.removeWidget(widget)
                widget.deleteLater()
            self._filter_widgets = {}
            for field, label in fields.items():
                widget = TskRiskFilter(self.ui.filtersContents)
                self.ui.filtersLayout.insertWidget(self.ui.filtersLayout.count() - 1, widget)
                self._filter_widgets[field] = widget
                widget.selection_changed.connect(self._apply_filters)
                widget.sort_requested.connect(lambda descending, key=field: self._sort_by(key, descending))
                widget.popup.ui.liveHintLabel.setText(self._text("filterHintText"))
                if field in previous:
                    values, selected = previous[field]
                    with QSignalBlocker(widget):
                        widget.set_values(label, values, reset=True)
                        widget.popup.set_selected_values(selected)
        for field, widget in self._filter_widgets.items():
            values = ([_text_value(row.get("tsk_id")) for row in group.get("types", [])] if field == "tsk_id"
                      else [_category_value(value, field[8:]) for value in categories[field[8:]].get("levels", [])])
            values.extend(self._field_value(entry, field) for entry in self._source_entries)
            widget.set_values(fields[field], values, reset=reset)
            widget.setEnabled(bool(self._source_entries))
        sort = self.ui.sortFieldComboBox
        current = None if reset else sort.currentData()
        with QSignalBlocker(sort):
            sort.clear()
            sort.addItem(self._text("tskText"), "tsk_id")
            sort.addItem(self._text("probabilityText"), "probability")
            for name in feature_names:
                sort.addItem(name, "feature:" + name)
            sort.setCurrentIndex(max(0, sort.findData(current)))
            sort.setEnabled(bool(self._source_entries))
        direction = self.ui.sortDirectionComboBox
        direction.setEnabled(bool(self._source_entries))
        if reset:
            with QSignalBlocker(direction):
                direction.setCurrentIndex(0)
        self._apply_filters()

    def _sort_field_changed(self, *_args):
        with QSignalBlocker(self.ui.sortDirectionComboBox):
            self.ui.sortDirectionComboBox.setCurrentIndex(int(self.ui.sortFieldComboBox.currentData() == "probability"))
        self._apply_filters()

    def _sort_by(self, field, descending):
        with QSignalBlocker(self.ui.sortFieldComboBox):
            self.ui.sortFieldComboBox.setCurrentIndex(self.ui.sortFieldComboBox.findData(field))
        with QSignalBlocker(self.ui.sortDirectionComboBox):
            self.ui.sortDirectionComboBox.setCurrentIndex(int(descending))
        self._apply_filters()

    def _clear_filters(self):
        for widget in self._filter_widgets.values():
            with QSignalBlocker(widget):
                widget.select_all()
        self._apply_filters()

    def clear_selection(self):
        """Clear navigation focus without requesting another map selection."""
        with QSignalBlocker(self.ui.resultsTreeWidget):
            self.ui.resultsTreeWidget.clearSelection()
            self.ui.resultsTreeWidget.setCurrentItem(None)
        self.ui.statusLabel.setText(self.ui.statusLabel.property("idleText"))

    def _apply_filters(self, *_args):
        selected = {field: widget.selected_values for field, widget in self._filter_widgets.items()
                    if widget.selected_values != set(widget.values)}
        entries = [entry for entry in self._source_entries
                   if all(self._field_value(entry, field) in values for field, values in selected.items())]
        entries.sort(key=lambda entry: (natural_sort_key(entry["tsk_id"]),
                     tuple(natural_sort_key(value) for value in entry["features"].values())))
        field = self.ui.sortFieldComboBox.currentData() or "tsk_id"
        descending = self.ui.sortDirectionComboBox.currentIndex() == 1
        if field == "probability":
            entries.sort(key=lambda entry: numeric_sort_key(entry["probability"], descending=descending))
        else:
            entries.sort(key=lambda entry: natural_sort_key(self._field_value(entry, field)), reverse=descending)
        self._visible_entries = entries
        self._populate_results(entries)
        count = self._text("resultCountFormat", visible=len(entries), total=len(self._source_entries))
        self.ui.resultCountLabel.setText((count if entries else count + " · " + self._text("noMatchesText"))
                                        if self._source_entries else self._text("emptyText"))
        self.ui.clearFiltersButton.setEnabled(bool(selected))
        self.ui.statusLabel.setText(self.ui.statusLabel.property("idleText"))

    def _populate_results(self, entries):
        tree = self.ui.resultsTreeWidget
        expanded = {tree.topLevelItem(index).data(0, Qt.UserRole)["key"]
                    for index in range(tree.topLevelItemCount()) if tree.topLevelItem(index).isExpanded()}
        current = tree.currentItem()
        current_data = current.data(0, Qt.UserRole) if current else None
        with QSignalBlocker(tree):
            tree.clear()
            for entry in entries:
                tsk_id = entry["tsk_id"] or self._text("blankText")
                title = tsk_id
                if entry["features"]:
                    title = self._text("combinationFormat", tsk_id=tsk_id,
                        values=" · ".join(value or self._text("blankText") for value in entry["features"].values()))
                item = QTreeWidgetItem(tree, [title])
                data = dict(kind="combination", key=entry["key"], indexes=entry["indexes"])
                item.setData(0, Qt.UserRole, data)
                details = [title, self._text("scopeFormat", chains=len(entry["chains"]), points=len(entry["indexes"])),
                           *(self._text("featureFormat", name=name, value=_text_value(value) or self._text("blankText"))
                             for name, value in entry["features"].items()),
                           self._text("riskFormat", risk=percentage(entry["probability"]))]
                if not entry["indexes"]:
                    details.append(self._text("missingCoordinatesText"))
                item.setToolTip(0, "\n".join(details))
                item.setExpanded(entry["key"] in expanded)
                if data == current_data:
                    tree.setCurrentItem(item)
                for chain_id in entry["chains"]:
                    child = QTreeWidgetItem(item, [self._text("chainFormat", chain_id=chain_id or self._text("blankText"))])
                    child_data = dict(kind="chain", key=entry["key"], chain_id=chain_id)
                    child.setData(0, Qt.UserRole, child_data)
                    child.setToolTip(0, child.text(0))
                    if child_data == current_data:
                        tree.setCurrentItem(child)

    def _activate_item(self, item, _column=0):
        self.ui.resultsTreeWidget.setCurrentItem(item)
        data = item.data(0, Qt.UserRole)
        if data["kind"] == "chain":
            self.chain_selected.emit(data["chain_id"])
            self.ui.statusLabel.setText(item.text(0))
        else:
            indexes = list(data["indexes"])
            self.instances_selected.emit(indexes)
            self.ui.statusLabel.setText(self._text("selectionFormat", count=len(indexes)) if indexes
                                        else self._text("missingCoordinatesText"))
