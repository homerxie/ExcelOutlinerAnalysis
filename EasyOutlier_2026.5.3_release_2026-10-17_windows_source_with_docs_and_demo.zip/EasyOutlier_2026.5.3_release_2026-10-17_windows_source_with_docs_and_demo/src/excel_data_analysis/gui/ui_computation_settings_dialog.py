# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'computation_settings_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog, QDialogButtonBox,
    QHBoxLayout, QLabel, QRadioButton, QSizePolicy,
    QSpacerItem, QSpinBox, QVBoxLayout, QWidget)

class Ui_ComputationSettingsDialog(object):
    def setupUi(self, ComputationSettingsDialog):
        if not ComputationSettingsDialog.objectName():
            ComputationSettingsDialog.setObjectName(u"ComputationSettingsDialog")
        ComputationSettingsDialog.resize(640, 480)
        ComputationSettingsDialog.setMinimumSize(QSize(560, 440))
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(ComputationSettingsDialog.sizePolicy().hasHeightForWidth())
        ComputationSettingsDialog.setSizePolicy(sizePolicy)
        ComputationSettingsDialog.setSizeGripEnabled(True)
        self.dialogLayout = QVBoxLayout(ComputationSettingsDialog)
        self.dialogLayout.setSpacing(12)
        self.dialogLayout.setObjectName(u"dialogLayout")
        self.dialogLayout.setContentsMargins(20, 20, 20, 20)
        self.descriptionLabel = QLabel(ComputationSettingsDialog)
        self.descriptionLabel.setObjectName(u"descriptionLabel")
        sizePolicy.setHeightForWidth(self.descriptionLabel.sizePolicy().hasHeightForWidth())
        self.descriptionLabel.setSizePolicy(sizePolicy)
        self.descriptionLabel.setWordWrap(True)

        self.dialogLayout.addWidget(self.descriptionLabel)

        self.detectedCoresLabel = QLabel(ComputationSettingsDialog)
        self.detectedCoresLabel.setObjectName(u"detectedCoresLabel")
        sizePolicy.setHeightForWidth(self.detectedCoresLabel.sizePolicy().hasHeightForWidth())
        self.detectedCoresLabel.setSizePolicy(sizePolicy)
        self.detectedCoresLabel.setWordWrap(True)

        self.dialogLayout.addWidget(self.detectedCoresLabel)

        self.topologyScopeLabel = QLabel(ComputationSettingsDialog)
        self.topologyScopeLabel.setObjectName(u"topologyScopeLabel")
        self.topologyScopeLabel.setVisible(False)
        sizePolicy.setHeightForWidth(self.topologyScopeLabel.sizePolicy().hasHeightForWidth())
        self.topologyScopeLabel.setSizePolicy(sizePolicy)
        self.topologyScopeLabel.setWordWrap(True)

        self.dialogLayout.addWidget(self.topologyScopeLabel)

        self.autoWorkersLayout = QHBoxLayout()
        self.autoWorkersLayout.setSpacing(12)
        self.autoWorkersLayout.setObjectName(u"autoWorkersLayout")
        self.autoWorkersRadioButton = QRadioButton(ComputationSettingsDialog)
        self.autoWorkersRadioButton.setObjectName(u"autoWorkersRadioButton")
        self.autoWorkersRadioButton.setChecked(True)

        self.autoWorkersLayout.addWidget(self.autoWorkersRadioButton)

        self.autoWorkersSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.autoWorkersLayout.addItem(self.autoWorkersSpacer)


        self.dialogLayout.addLayout(self.autoWorkersLayout)

        self.autoWorkersDescriptionLabel = QLabel(ComputationSettingsDialog)
        self.autoWorkersDescriptionLabel.setObjectName(u"autoWorkersDescriptionLabel")
        sizePolicy.setHeightForWidth(self.autoWorkersDescriptionLabel.sizePolicy().hasHeightForWidth())
        self.autoWorkersDescriptionLabel.setSizePolicy(sizePolicy)
        self.autoWorkersDescriptionLabel.setWordWrap(True)
        self.autoWorkersDescriptionLabel.setIndent(22)

        self.dialogLayout.addWidget(self.autoWorkersDescriptionLabel)

        self.customWorkersLayout = QHBoxLayout()
        self.customWorkersLayout.setSpacing(12)
        self.customWorkersLayout.setObjectName(u"customWorkersLayout")
        self.customWorkersRadioButton = QRadioButton(ComputationSettingsDialog)
        self.customWorkersRadioButton.setObjectName(u"customWorkersRadioButton")

        self.customWorkersLayout.addWidget(self.customWorkersRadioButton)

        self.workerCountSpinBox = QSpinBox(ComputationSettingsDialog)
        self.workerCountSpinBox.setObjectName(u"workerCountSpinBox")
        self.workerCountSpinBox.setEnabled(False)
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.workerCountSpinBox.sizePolicy().hasHeightForWidth())
        self.workerCountSpinBox.setSizePolicy(sizePolicy1)
        self.workerCountSpinBox.setMinimumSize(QSize(120, 0))
        self.workerCountSpinBox.setMinimum(1)
        self.workerCountSpinBox.setMaximum(64)
        self.workerCountSpinBox.setValue(1)

        self.customWorkersLayout.addWidget(self.workerCountSpinBox)


        self.dialogLayout.addLayout(self.customWorkersLayout)

        self.customWorkersDescriptionLabel = QLabel(ComputationSettingsDialog)
        self.customWorkersDescriptionLabel.setObjectName(u"customWorkersDescriptionLabel")
        sizePolicy.setHeightForWidth(self.customWorkersDescriptionLabel.sizePolicy().hasHeightForWidth())
        self.customWorkersDescriptionLabel.setSizePolicy(sizePolicy)
        self.customWorkersDescriptionLabel.setWordWrap(True)
        self.customWorkersDescriptionLabel.setIndent(22)

        self.dialogLayout.addWidget(self.customWorkersDescriptionLabel)

        self.verticalSpacer = QSpacerItem(20, 12, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.dialogLayout.addItem(self.verticalSpacer)

        self.persistenceLabel = QLabel(ComputationSettingsDialog)
        self.persistenceLabel.setObjectName(u"persistenceLabel")
        sizePolicy.setHeightForWidth(self.persistenceLabel.sizePolicy().hasHeightForWidth())
        self.persistenceLabel.setSizePolicy(sizePolicy)
        self.persistenceLabel.setWordWrap(True)

        self.dialogLayout.addWidget(self.persistenceLabel)

        self.buttonBox = QDialogButtonBox(ComputationSettingsDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setOrientation(Qt.Orientation.Horizontal)
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)

        self.dialogLayout.addWidget(self.buttonBox)


        self.retranslateUi(ComputationSettingsDialog)
        self.buttonBox.accepted.connect(ComputationSettingsDialog.accept)
        self.buttonBox.rejected.connect(ComputationSettingsDialog.reject)

        QMetaObject.connectSlotsByName(ComputationSettingsDialog)
    # setupUi

    def retranslateUi(self, ComputationSettingsDialog):
        ComputationSettingsDialog.setWindowTitle(QCoreApplication.translate("ComputationSettingsDialog", u"\u8ba1\u7b97\u8d44\u6e90\u8bbe\u7f6e", None))
        self.descriptionLabel.setText(QCoreApplication.translate("ComputationSettingsDialog", u"\u8bbe\u7f6e\u540e\u7eed\u4efb\u52a1\u53ef\u4f7f\u7528\u7684\u6700\u5927\u5e76\u884c\u8fdb\u7a0b\u6570\u3002", None))
        self.detectedCoresLabel.setText(QCoreApplication.translate("ComputationSettingsDialog", u"\u7269\u7406\u6838\u5fc3\uff1a\u2014\uff1b\u903b\u8f91\u5904\u7406\u5668\uff1a\u2014\n"
"SMT\uff08\u8d85\u7ebf\u7a0b\uff09\uff1a\u672a\u80fd\u786e\u8ba4\u3002", None))
        self.detectedCoresLabel.setProperty(u"formatText", QCoreApplication.translate("ComputationSettingsDialog", u"\u7269\u7406\u6838\u5fc3\uff1a{physical}\uff1b\u903b\u8f91\u5904\u7406\u5668\uff1a{logical}\n"
"SMT\uff08\u8d85\u7ebf\u7a0b\uff09\uff1a{smt}\u3002\u81ea\u5b9a\u4e49\u4e0a\u9650\uff1a1\uff5e{maximum} \u4e2a\u8fdb\u7a0b\u3002", None))
        self.detectedCoresLabel.setProperty(u"unknownCountText", QCoreApplication.translate("ComputationSettingsDialog", u"\u672a\u80fd\u786e\u8ba4", None))
        self.detectedCoresLabel.setProperty(u"smtAvailableText", QCoreApplication.translate("ComputationSettingsDialog", u"\u5df2\u786e\u8ba4\u53ef\u7528", None))
        self.detectedCoresLabel.setProperty(u"smtUnavailableText", QCoreApplication.translate("ComputationSettingsDialog", u"\u5f53\u524d\u53ef\u7528\u8303\u56f4\u672a\u63d0\u4f9b\u989d\u5916\u7ebf\u7a0b", None))
        self.detectedCoresLabel.setProperty(u"smtUnknownText", QCoreApplication.translate("ComputationSettingsDialog", u"\u672a\u80fd\u786e\u8ba4", None))
        self.topologyScopeLabel.setText(QCoreApplication.translate("ComputationSettingsDialog", u"\u4ee5\u4e0a\u8ba1\u6570\u6309\u5f53\u524d\u53ef\u9a8c\u8bc1\u7684\u8ba1\u7b97\u8d44\u6e90\u8303\u56f4\u663e\u793a\u3002", None))
        self.topologyScopeLabel.setProperty(u"primaryGroupText", QCoreApplication.translate("ComputationSettingsDialog", u"Windows \u591a\u5904\u7406\u5668\u7ec4\uff1a\u4ee5\u4e0a\u8ba1\u6570\u4e0e TSK \u9884\u7b97\u4ec5\u4f7f\u7528\u5df2\u9a8c\u8bc1\u7684\u4e3b\u5904\u7406\u5668\u7ec4\uff1b\u5176\u4ed6\u7ec4\u672a\u8ba1\u5165\u3002", None))
        self.topologyScopeLabel.setProperty(u"restrictedAffinityText", QCoreApplication.translate("ComputationSettingsDialog", u"\u4ee5\u4e0a\u8ba1\u6570\u4e3a\u5f53\u524d\u8fdb\u7a0b\u5141\u8bb8\u4f7f\u7528\u7684\u5904\u7406\u5668\u8303\u56f4\uff0c\u53ef\u80fd\u5c11\u4e8e\u6574\u673a\u6570\u91cf\u3002", None))
        self.topologyScopeLabel.setProperty(u"unknownAffinityText", QCoreApplication.translate("ComputationSettingsDialog", u"\u672a\u80fd\u786e\u8ba4\u8fdb\u7a0b\u7684\u5904\u7406\u5668\u9650\u5236\uff1b\u4ee5\u4e0a\u663e\u793a\u7cfb\u7edf\u68c0\u6d4b\u503c\u3002", None))
        self.autoWorkersRadioButton.setText(QCoreApplication.translate("ComputationSettingsDialog", u"\u81ea\u52a8\uff08\u63a8\u8350\uff09", None))
        self.autoWorkersDescriptionLabel.setText(QCoreApplication.translate("ComputationSettingsDialog", u"TSK \u81ea\u52a8\u6a21\u5f0f\u4f18\u5148\u6309\u7269\u7406\u6838\u5fc3\u786e\u5b9a\u603b\u8fdb\u7a0b\u9884\u7b97\uff0c\u7ec4\u95f4\u4e0e\u7ec4\u5185\u4efb\u52a1\u5171\u4eab\u9884\u7b97\u3002\u5176\u4ed6\u4efb\u52a1\u4fdd\u7559\u5404\u81ea\u7684\u81ea\u52a8\u7b56\u7565\u3002", None))
        self.autoWorkersDescriptionLabel.setProperty(u"formatText", QCoreApplication.translate("ComputationSettingsDialog", u"TSK \u81ea\u52a8\u6a21\u5f0f\uff1a\u603b\u9884\u7b97 {budget} \u4e2a\u8fdb\u7a0b\uff08\u4f18\u5148\u6309\u7269\u7406\u6838\u5fc3\uff09\u3002\u7ec4\u95f4\u4e0e\u7ec4\u5185\u4efb\u52a1\u5171\u4eab\u9884\u7b97\uff1b\u5176\u4ed6\u4efb\u52a1\u4fdd\u7559\u5404\u81ea\u7684\u81ea\u52a8\u7b56\u7565\u3002", None))
        self.autoWorkersDescriptionLabel.setProperty(u"fallbackFormatText", QCoreApplication.translate("ComputationSettingsDialog", u"TSK \u81ea\u52a8\u6a21\u5f0f\uff1a\u603b\u9884\u7b97 {budget} \u4e2a\u8fdb\u7a0b\uff08\u7269\u7406\u6838\u5fc3\u6570\u672a\u77e5\uff0c\u56de\u9000\u5230\u903b\u8f91\u5904\u7406\u5668\u6570\uff09\u3002\u7ec4\u95f4\u4e0e\u7ec4\u5185\u4efb\u52a1\u5171\u4eab\u9884\u7b97\uff1b\u5176\u4ed6\u4efb\u52a1\u4fdd\u7559\u5404\u81ea\u7684\u81ea\u52a8\u7b56\u7565\u3002", None))
        self.customWorkersRadioButton.setText(QCoreApplication.translate("ComputationSettingsDialog", u"\u81ea\u5b9a\u4e49\u6700\u5927\u8fdb\u7a0b\u6570\uff1a", None))
        self.workerCountSpinBox.setSuffix(QCoreApplication.translate("ComputationSettingsDialog", u" \u4e2a\u8fdb\u7a0b", None))
        self.customWorkersDescriptionLabel.setText(QCoreApplication.translate("ComputationSettingsDialog", u"\u53ef\u6309\u903b\u8f91\u5904\u7406\u5668\u6570\u8bbe\u7f6e\u4e0a\u9650\uff0c\u5305\u62ec\u53ef\u7528\u7684 SMT \u7ebf\u7a0b\u3002\u8bbe\u4e3a 1 \u65f6\u987a\u5e8f\u8ba1\u7b97\uff1bTSK \u7ec4\u95f4\u4e0e\u7ec4\u5185\u4efb\u52a1\u5171\u4eab\u6b64\u603b\u9884\u7b97\uff0c\u5b9e\u9645\u8fdb\u7a0b\u6570\u4e5f\u53d7\u4efb\u52a1\u89c4\u6a21\u9650\u5236\u3002", None))
        self.persistenceLabel.setText(QCoreApplication.translate("ComputationSettingsDialog", u"\u8bbe\u7f6e\u81ea\u52a8\u4fdd\u5b58\uff0c\u5bf9\u540e\u7eed\u5206\u6790\u4efb\u52a1\u53ca\u65b0\u6253\u5f00\u7684\u7ed8\u56fe\u7a97\u53e3\u751f\u6548\u3002\n"
"\u6b63\u5728\u8fd0\u884c\u7684\u4efb\u52a1\u4fdd\u6301\u539f\u8bbe\u7f6e\u3002", None))
    # retranslateUi

