"""Smooth, subdued XY heatmap colors with bounded quantization error."""

from __future__ import annotations

import math
import operator

import numpy as np


# One threshold per image pixel, shared by all channels to avoid colored
# noise. The midpoint offsets keep quantization error strictly below one level.
_BAYER8 = (np.array([
    [0, 48, 12, 60, 3, 51, 15, 63],
    [32, 16, 44, 28, 35, 19, 47, 31],
    [8, 56, 4, 52, 11, 59, 7, 55],
    [40, 24, 36, 20, 43, 27, 39, 23],
    [2, 50, 14, 62, 1, 49, 13, 61],
    [34, 18, 46, 30, 33, 17, 45, 29],
    [10, 58, 6, 54, 9, 57, 5, 53],
    [42, 26, 38, 22, 41, 25, 37, 21],
], dtype=np.float32) + .5) / 64
_BAYER8.setflags(write=False)


def _rgb(value):
    try:
        channels = tuple(operator.index(channel) for channel in value)
    except (TypeError, ValueError) as error:
        raise ValueError("Heatmap colors require three integer RGB channels.") from error
    if len(channels) != 3 or any(channel < 0 or channel > 255 for channel in channels):
        raise ValueError("Heatmap RGB channels must be between 0 and 255.")
    return channels


def heatmap_rgb(values, limit, negative, positive, opacity, background, *, pixel_origin=(0, 0)):
    """Return a contiguous uint8 H×W×3 image already composed onto background.

    ``values`` holds model effects; ``limit`` is the positive endpoint of the
    fixed symmetric color scale. Magnitudes above that endpoint saturate. At
    zero effect the result is exactly the background. ``pixel_origin`` is the
    (x, y) location of the image's first pixel, so tiled paints use the same
    quantization pattern as a single full image. Native-size painting keeps
    the finest dither; the interactive canvas instead smoothly scales a small
    cached texture to avoid regenerating millions of pixels during navigation.
    """
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 2 or not np.all(np.isfinite(values)):
        raise ValueError("Heatmap effects must be a finite two-dimensional array.")
    limit, opacity = float(limit), float(opacity)
    if not math.isfinite(limit) or limit < 0:
        raise ValueError("Heatmap color limit must be finite and nonnegative.")
    if not math.isfinite(opacity) or not 0 <= opacity <= 1:
        raise ValueError("Heatmap opacity must be between 0 and 1.")
    negative, positive, background = map(_rgb, (negative, positive, background))
    try:
        origin_x, origin_y = (operator.index(part) for part in pixel_origin)
    except (TypeError, ValueError) as error:
        raise ValueError("Heatmap pixel origin requires two integer coordinates.") from error

    height, width = values.shape
    result = np.empty((height, width, 3), dtype=np.uint8)
    if not limit or not opacity or not values.size:
        result[:] = background
        return result

    # Retain float64 coordinate arithmetic upstream, then quantize only the
    # bounded color intensity. Reuse one float32 scratch plane per RGB channel
    # instead of allocating a large float64 H×W×3 intermediate.
    intensity = np.empty(values.shape, dtype=np.float32)
    with np.errstate(over="ignore"):
        np.divide(values, limit, out=intensity)
    np.clip(intensity, -1., 1., out=intensity)
    intensity *= opacity
    negative_pixels = intensity < 0
    rows = (np.arange(height) + origin_y % 8) % 8
    columns = (np.arange(width) + origin_x % 8) % 8
    thresholds = _BAYER8[rows[:, None], columns[None, :]]
    scratch = np.empty_like(intensity)
    for channel, (low, high, base) in enumerate(zip(negative, positive, background)):
        np.multiply(intensity, np.where(negative_pixels, np.float32(base - low),
                                        np.float32(high - base)), out=scratch)
        scratch += base
        scratch += thresholds
        np.floor(scratch, out=scratch)
        np.clip(scratch, 0, 255, out=scratch)
        result[:, :, channel] = scratch
    return result
