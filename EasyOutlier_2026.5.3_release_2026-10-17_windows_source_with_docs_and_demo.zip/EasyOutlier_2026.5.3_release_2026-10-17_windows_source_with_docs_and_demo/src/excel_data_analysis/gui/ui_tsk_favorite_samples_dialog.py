# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_favorite_samples_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QDialog,
    QHBoxLayout, QHeaderView, QLabel, QPushButton,
    QSizePolicy, QSpacerItem, QSplitter, QTableView,
    QVBoxLayout, QWidget)

class Ui_TskFavoriteSamplesDialogForm(object):
    def setupUi(self, TskFavoriteSamplesDialogForm):
        if not TskFavoriteSamplesDialogForm.objectName():
            TskFavoriteSamplesDialogForm.setObjectName(u"TskFavoriteSamplesDialogForm")
        TskFavoriteSamplesDialogForm.resize(1100, 780)
        TskFavoriteSamplesDialogForm.setMinimumSize(QSize(760, 560))
        TskFavoriteSamplesDialogForm.setModal(False)
        TskFavoriteSamplesDialogForm.setWindowFlags(Qt.WindowType.Window|Qt.WindowType.WindowTitleHint|Qt.WindowType.WindowSystemMenuHint|Qt.WindowType.WindowMinMaxButtonsHint|Qt.WindowType.WindowCloseButtonHint)
        TskFavoriteSamplesDialogForm.setProperty(u"favoriteHighlightColor", u"#0067c0")
        TskFavoriteSamplesDialogForm.setProperty(u"favoriteHighlightBackground", u"#dbeafe")
        self.matrixCopyAction = QAction(TskFavoriteSamplesDialogForm)
        self.matrixCopyAction.setObjectName(u"matrixCopyAction")
        self.matrixCopyHeadersAction = QAction(TskFavoriteSamplesDialogForm)
        self.matrixCopyHeadersAction.setObjectName(u"matrixCopyHeadersAction")
        self.detailsCopyAction = QAction(TskFavoriteSamplesDialogForm)
        self.detailsCopyAction.setObjectName(u"detailsCopyAction")
        self.detailsCopyHeadersAction = QAction(TskFavoriteSamplesDialogForm)
        self.detailsCopyHeadersAction.setObjectName(u"detailsCopyHeadersAction")
        self.dialogLayout = QVBoxLayout(TskFavoriteSamplesDialogForm)
        self.dialogLayout.setSpacing(8)
        self.dialogLayout.setObjectName(u"dialogLayout")
        self.dialogLayout.setContentsMargins(12, 12, 12, 12)
        self.contextLabel = QLabel(TskFavoriteSamplesDialogForm)
        self.contextLabel.setObjectName(u"contextLabel")
        self.contextLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.contextLabel.setWordWrap(True)

        self.dialogLayout.addWidget(self.contextLabel)

        self.availabilityLabel = QLabel(TskFavoriteSamplesDialogForm)
        self.availabilityLabel.setObjectName(u"availabilityLabel")
        self.availabilityLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.availabilityLabel.setWordWrap(True)
        self.availabilityLabel.setVisible(False)

        self.dialogLayout.addWidget(self.availabilityLabel)

        self.tablesSplitter = QSplitter(TskFavoriteSamplesDialogForm)
        self.tablesSplitter.setObjectName(u"tablesSplitter")
        self.tablesSplitter.setOrientation(Qt.Orientation.Vertical)
        self.tablesSplitter.setChildrenCollapsible(False)
        self.matrixPane = QWidget(self.tablesSplitter)
        self.matrixPane.setObjectName(u"matrixPane")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(1)
        sizePolicy.setHeightForWidth(self.matrixPane.sizePolicy().hasHeightForWidth())
        self.matrixPane.setSizePolicy(sizePolicy)
        self.matrixLayout = QVBoxLayout(self.matrixPane)
        self.matrixLayout.setSpacing(6)
        self.matrixLayout.setObjectName(u"matrixLayout")
        self.matrixLayout.setContentsMargins(0, 0, 0, 0)
        self.matrixHint = QLabel(self.matrixPane)
        self.matrixHint.setObjectName(u"matrixHint")
        self.matrixHint.setTextFormat(Qt.TextFormat.PlainText)
        self.matrixHint.setWordWrap(True)

        self.matrixLayout.addWidget(self.matrixHint)

        self.matrixTableView = QTableView(self.matrixPane)
        self.matrixTableView.setObjectName(u"matrixTableView")
        self.matrixTableView.setMinimumSize(QSize(0, 160))
        self.matrixTableView.setContextMenuPolicy(Qt.ContextMenuPolicy.ActionsContextMenu)
        self.matrixTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.matrixTableView.setAlternatingRowColors(True)
        self.matrixTableView.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.matrixTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectItems)
        self.matrixTableView.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.matrixTableView.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.matrixTableView.setWordWrap(False)
        self.matrixTableView.horizontalHeader().setMinimumSectionSize(80)
        self.matrixTableView.horizontalHeader().setDefaultSectionSize(150)
        self.matrixTableView.horizontalHeader().setHighlightSections(False)
        self.matrixTableView.verticalHeader().setVisible(False)
        self.matrixTableView.verticalHeader().setDefaultSectionSize(28)

        self.matrixLayout.addWidget(self.matrixTableView)

        self.selectionActionsLayout = QHBoxLayout()
        self.selectionActionsLayout.setSpacing(8)
        self.selectionActionsLayout.setObjectName(u"selectionActionsLayout")
        self.selectAllSamplesButton = QPushButton(self.matrixPane)
        self.selectAllSamplesButton.setObjectName(u"selectAllSamplesButton")
        self.selectAllSamplesButton.setEnabled(False)
        self.selectAllSamplesButton.setAutoDefault(False)

        self.selectionActionsLayout.addWidget(self.selectAllSamplesButton)

        self.clearSamplesButton = QPushButton(self.matrixPane)
        self.clearSamplesButton.setObjectName(u"clearSamplesButton")
        self.clearSamplesButton.setEnabled(False)
        self.clearSamplesButton.setAutoDefault(False)

        self.selectionActionsLayout.addWidget(self.clearSamplesButton)

        self.selectionActionsSpacer = QSpacerItem(16, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.selectionActionsLayout.addItem(self.selectionActionsSpacer)

        self.selectionCountLabel = QLabel(self.matrixPane)
        self.selectionCountLabel.setObjectName(u"selectionCountLabel")
        self.selectionCountLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.selectionActionsLayout.addWidget(self.selectionCountLabel)


        self.matrixLayout.addLayout(self.selectionActionsLayout)

        self.matrixLayout.setStretch(1, 1)
        self.tablesSplitter.addWidget(self.matrixPane)
        self.detailsPane = QWidget(self.tablesSplitter)
        self.detailsPane.setObjectName(u"detailsPane")
        sizePolicy.setHeightForWidth(self.detailsPane.sizePolicy().hasHeightForWidth())
        self.detailsPane.setSizePolicy(sizePolicy)
        self.detailsLayout = QVBoxLayout(self.detailsPane)
        self.detailsLayout.setSpacing(6)
        self.detailsLayout.setObjectName(u"detailsLayout")
        self.detailsLayout.setContentsMargins(0, 0, 0, 0)
        self.detailsOptionsLayout = QHBoxLayout()
        self.detailsOptionsLayout.setObjectName(u"detailsOptionsLayout")
        self.detailsHint = QLabel(self.detailsPane)
        self.detailsHint.setObjectName(u"detailsHint")
        self.detailsHint.setTextFormat(Qt.TextFormat.PlainText)
        self.detailsHint.setWordWrap(False)

        self.detailsOptionsLayout.addWidget(self.detailsHint)

        self.detailsOptionsSpacer = QSpacerItem(16, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.detailsOptionsLayout.addItem(self.detailsOptionsSpacer)

        self.onlyFavoritesCheckBox = QCheckBox(self.detailsPane)
        self.onlyFavoritesCheckBox.setObjectName(u"onlyFavoritesCheckBox")
        self.onlyFavoritesCheckBox.setChecked(False)

        self.detailsOptionsLayout.addWidget(self.onlyFavoritesCheckBox)


        self.detailsLayout.addLayout(self.detailsOptionsLayout)

        self.sampleDetailsTableView = QTableView(self.detailsPane)
        self.sampleDetailsTableView.setObjectName(u"sampleDetailsTableView")
        self.sampleDetailsTableView.setMinimumSize(QSize(0, 140))
        self.sampleDetailsTableView.setContextMenuPolicy(Qt.ContextMenuPolicy.ActionsContextMenu)
        self.sampleDetailsTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.sampleDetailsTableView.setAlternatingRowColors(True)
        self.sampleDetailsTableView.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.sampleDetailsTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectItems)
        self.sampleDetailsTableView.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.sampleDetailsTableView.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.sampleDetailsTableView.setWordWrap(True)
        self.sampleDetailsTableView.horizontalHeader().setMinimumSectionSize(80)
        self.sampleDetailsTableView.horizontalHeader().setDefaultSectionSize(180)
        self.sampleDetailsTableView.horizontalHeader().setHighlightSections(False)
        self.sampleDetailsTableView.horizontalHeader().setStretchLastSection(True)
        self.sampleDetailsTableView.verticalHeader().setVisible(False)
        self.sampleDetailsTableView.verticalHeader().setDefaultSectionSize(28)

        self.detailsLayout.addWidget(self.sampleDetailsTableView)

        self.detailsLayout.setStretch(1, 1)
        self.tablesSplitter.addWidget(self.detailsPane)

        self.dialogLayout.addWidget(self.tablesSplitter)

        self.footerLayout = QHBoxLayout()
        self.footerLayout.setSpacing(8)
        self.footerLayout.setObjectName(u"footerLayout")
        self.statusLabel = QLabel(TskFavoriteSamplesDialogForm)
        self.statusLabel.setObjectName(u"statusLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.statusLabel.sizePolicy().hasHeightForWidth())
        self.statusLabel.setSizePolicy(sizePolicy1)
        self.statusLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.statusLabel.setWordWrap(True)

        self.footerLayout.addWidget(self.statusLabel)

        self.closeButton = QPushButton(TskFavoriteSamplesDialogForm)
        self.closeButton.setObjectName(u"closeButton")
        self.closeButton.setAutoDefault(False)

        self.footerLayout.addWidget(self.closeButton)


        self.dialogLayout.addLayout(self.footerLayout)

        self.dialogLayout.setStretch(2, 1)

        self.retranslateUi(TskFavoriteSamplesDialogForm)
        self.closeButton.clicked.connect(TskFavoriteSamplesDialogForm.reject)

        QMetaObject.connectSlotsByName(TskFavoriteSamplesDialogForm)
    # setupUi

    def retranslateUi(self, TskFavoriteSamplesDialogForm):
        TskFavoriteSamplesDialogForm.setWindowTitle(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u6536\u85cf\u94fe\u8def \u00b7 \u5931\u6548\u6837\u54c1", None))
        TskFavoriteSamplesDialogForm.setProperty(u"matrixChainHeaderText", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u94fe\u8def / Sample ID", None))
        TskFavoriteSamplesDialogForm.setProperty(u"extractRowText", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u53d6\u51fa", None))
        TskFavoriteSamplesDialogForm.setProperty(u"sampleIdHeaderText", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"Sample ID", None))
        TskFavoriteSamplesDialogForm.setProperty(u"failedChainsHeaderText", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u5931\u6548\u94fe\u8def", None))
        TskFavoriteSamplesDialogForm.setProperty(u"sampleKeySeparator", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u" | ", None))
        TskFavoriteSamplesDialogForm.setProperty(u"copyText", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u590d\u5236", None))
        TskFavoriteSamplesDialogForm.setProperty(u"copyWithHeadersText", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u590d\u5236\uff08\u542b\u8868\u5934\uff09", None))
        TskFavoriteSamplesDialogForm.setProperty(u"contextFormat", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"{group} \u00b7 \u6536\u85cf {chains} \u6761\u94fe\u8def", None))
        TskFavoriteSamplesDialogForm.setProperty(u"summaryFormat", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u5171 {samples} \u4e2a\u5931\u6548\u6837\u54c1 \u00b7 \u5df2\u9009 {selected} \u4e2a", None))
        TskFavoriteSamplesDialogForm.setProperty(u"matrixCountFormat", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"{chains} \u6761\u6536\u85cf\u94fe\u8def \u00d7 {samples} \u4e2a\u5931\u6548\u6837\u54c1", None))
        TskFavoriteSamplesDialogForm.setProperty(u"sourceBatchFormat", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"{sample}\uff08\u6279\u6b21\uff1a{batch}\uff09", None))
        TskFavoriteSamplesDialogForm.setProperty(u"sourceBatchToolTipFormat", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"Sample ID\uff1a{sample}\n"
"\u539f\u6279\u6b21\uff1a{batch}", None))
        TskFavoriteSamplesDialogForm.setProperty(u"blankBatchText", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u672a\u4fdd\u5b58", None))
        TskFavoriteSamplesDialogForm.setProperty(u"copiedText", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u5df2\u590d\u5236\u9009\u533a\uff0c\u53ef\u7c98\u8d34\u5230 Excel \u5e76\u4fdd\u7559\u9ad8\u4eae\u3002", None))
        TskFavoriteSamplesDialogForm.setProperty(u"noFavoritesText", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u5f53\u524d\u6ca1\u6709\u6536\u85cf\u94fe\u8def\u3002\u8bf7\u5148\u5728 TSK \u5750\u6807\u56fe\u4e2d\u6536\u85cf\u94fe\u8def\u3002", None))
        TskFavoriteSamplesDialogForm.setProperty(u"unavailableText", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u6b64 TSK \u5feb\u7167\u672a\u9644\u5e26\u6837\u54c1\u7f16\u53f7\u3002\u70b9\u51fb\u201c\u83b7\u5f97\u5931\u6548\u6837\u54c1 ID\u201d\u53ef\u8bfb\u53d6\u5bf9\u5e94\u7684 Analyze \u5df2\u4fdd\u5b58\u660e\u7ec6\uff0c\u65e0\u9700\u91cd\u65b0\u8fd0\u884c TSK \u5206\u6790\u3002", None))
        TskFavoriteSamplesDialogForm.setProperty(u"loadingFailedSamplesText", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u6b63\u5728\u8bfb\u53d6 Analyze \u5df2\u4fdd\u5b58\u7684\u5931\u6548\u6837\u54c1\u7f16\u53f7\u2026", None))
        TskFavoriteSamplesDialogForm.setProperty(u"noFailuresText", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u5f53\u524d\u6536\u85cf\u94fe\u8def\u6ca1\u6709\u5df2\u4fdd\u5b58\u7684\u5931\u6548\u6837\u54c1\u3002", None))
        TskFavoriteSamplesDialogForm.setProperty(u"incompleteFormat", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"{chains} \u7684\u6837\u54c1\u660e\u7ec6\u4e0d\u5b8c\u6574\uff1b\u7a7a\u767d\u4ec5\u8868\u793a\u6ca1\u6709\u5df2\u4fdd\u5b58\u7684\u5931\u6548\u8bb0\u5f55\u3002", None))
        TskFavoriteSamplesDialogForm.setProperty(u"selectionHint", QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u52fe\u9009\u4e0a\u8868\u201c\u53d6\u51fa\u201d\u884c\uff0c\u5c06\u5bf9\u5e94\u6837\u54c1\u5217\u5165\u4e0b\u8868\u3002", None))
        self.matrixCopyAction.setText(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u590d\u5236", None))
        self.matrixCopyHeadersAction.setText(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u590d\u5236\uff08\u542b\u8868\u5934\uff09", None))
        self.detailsCopyAction.setText(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u590d\u5236", None))
        self.detailsCopyHeadersAction.setText(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u590d\u5236\uff08\u542b\u8868\u5934\uff09", None))
        self.contextLabel.setText(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u6536\u85cf\u94fe\u8def \u00b7 \u5931\u6548\u6837\u54c1", None))
        self.availabilityLabel.setText("")
        self.matrixHint.setText(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u884c\uff1a\u6536\u85cf\u94fe\u8def \u00b7 \u5217\uff1aSample ID \u00b7 \u2713 \u8868\u793a\u5931\u6548\uff0c\u7a7a\u767d\u8868\u793a\u65e0\u5931\u6548\u8bb0\u5f55\u3002\u52fe\u9009\u9996\u884c\u201c\u53d6\u51fa\u201d\uff0c\u6837\u54c1\u5217\u4f1a\u7f6e\u4e8e\u6700\u524d\u3002", None))
#if QT_CONFIG(tooltip)
        self.matrixTableView.setToolTip(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u652f\u6301\u591a\u9009\u5355\u5143\u683c\uff1b\u53f3\u952e\u6216 Ctrl+C \u590d\u5236\uff0c\u53ef\u7c98\u8d34\u5230 Excel \u5e76\u4fdd\u7559\u6536\u85cf\u94fe\u8def\u7684\u9ad8\u4eae\u989c\u8272\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.selectAllSamplesButton.setText(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u53d6\u51fa\u5168\u90e8\u6837\u54c1", None))
        self.clearSamplesButton.setText(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u6e05\u7a7a\u53d6\u51fa", None))
        self.selectionCountLabel.setText(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u5171 0 \u4e2a\u5931\u6548\u6837\u54c1 \u00b7 \u5df2\u9009 0 \u4e2a", None))
        self.detailsHint.setText(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u6837\u54c1\u7684\u5931\u6548\u94fe\u8def \u00b7 \u6536\u85cf\u94fe\u8def\u9ad8\u4eae", None))
        self.onlyFavoritesCheckBox.setText(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u53ea\u663e\u793a\u5f53\u524d\u6536\u85cf\u94fe\u8def", None))
#if QT_CONFIG(tooltip)
        self.sampleDetailsTableView.setToolTip(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u652f\u6301\u591a\u9009\u5355\u5143\u683c\uff1b\u53f3\u952e\u6216 Ctrl+C \u590d\u5236\uff0c\u53ef\u7c98\u8d34\u5230 Excel \u5e76\u4fdd\u7559\u6536\u85cf\u94fe\u8def\u7684\u9ad8\u4eae\u989c\u8272\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.statusLabel.setText(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u52fe\u9009\u4e0a\u8868\u201c\u53d6\u51fa\u201d\u884c\uff0c\u5c06\u5bf9\u5e94\u6837\u54c1\u5217\u5165\u4e0b\u8868\u3002", None))
        self.closeButton.setText(QCoreApplication.translate("TskFavoriteSamplesDialogForm", u"\u5173\u95ed", None))
    # retranslateUi

