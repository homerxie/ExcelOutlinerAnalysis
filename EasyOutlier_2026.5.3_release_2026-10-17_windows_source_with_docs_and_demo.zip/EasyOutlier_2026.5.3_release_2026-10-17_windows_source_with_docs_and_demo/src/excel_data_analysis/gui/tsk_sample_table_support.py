"""Rich, selection-only clipboard export for the failed-sample tables."""
from __future__ import annotations

import csv
from html import escape
from io import StringIO
from math import ceil

from PySide6.QtCore import QMimeData, QRectF, QSize, Qt
from PySide6.QtGui import QAbstractTextDocumentLayout, QBrush, QColor, QFont, QPalette, QTextDocument, QTextOption
from PySide6.QtWidgets import QApplication, QStyle, QStyledItemDelegate, QStyleOptionViewItem


# Models supply escaped, application-generated fragments in this role. Keeping
# DisplayRole plain gives accessibility and plain-text pastes the same content.
HTML_ROLE = Qt.ItemDataRole.UserRole + 101
WINDOWS_HTML_MIME = 'application/x-qt-windows-mime;value="HTML Format"'


def _html_document(fragment: str) -> str:
    return ('<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>'
            '<!--StartFragment-->' + fragment + '<!--EndFragment--></body></html>')


def cf_html_bytes(fragment: str) -> bytes:
    """Encode a Windows HTML Format payload with UTF-8 *byte* offsets."""
    document = _html_document(fragment).encode("utf-8")
    start_marker, end_marker = b"<!--StartFragment-->", b"<!--EndFragment-->"
    template = ("Version:1.0\r\nStartHTML:{start_html:010d}\r\n"
                "EndHTML:{end_html:010d}\r\nStartFragment:{start_fragment:010d}\r\n"
                "EndFragment:{end_fragment:010d}\r\n")
    header_length = len(template.format(start_html=0, end_html=0,
                                        start_fragment=0, end_fragment=0).encode("ascii"))
    header = template.format(
        start_html=header_length,
        end_html=header_length + len(document),
        start_fragment=header_length + document.index(start_marker) + len(start_marker),
        end_fragment=header_length + document.index(end_marker),
    ).encode("ascii")
    return header + document


def _display_text(index) -> str:
    value = index.data(Qt.ItemDataRole.DisplayRole)
    text = "" if value is None else str(value)
    if not text and index.data(Qt.ItemDataRole.CheckStateRole) in (Qt.CheckState.Checked, Qt.CheckState.Checked.value):
        return "✓"
    return text


def _plain_html(text: str) -> str:
    return escape(text).replace("\r\n", "\n").replace("\r", "\n").replace("\n", "<br>")


def _color_css(value):
    if isinstance(value, QBrush):
        if value.style() == Qt.BrushStyle.NoBrush:
            return None
        value = value.color()
    return value.name(QColor.NameFormat.HexRgb) if isinstance(value, QColor) and value.isValid() else None


def _cell_html(index, text: str) -> str:
    styles = ['mso-number-format:"\\@"', "white-space:pre-wrap", "color:#000000", "background-color:#ffffff"]
    if index is not None:
        for role, attribute in ((Qt.ItemDataRole.ForegroundRole, "color"),
                                (Qt.ItemDataRole.BackgroundRole, "background-color")):
            color = _color_css(index.data(role))
            if color:
                styles.append(f"{attribute}:{color}")
        font = index.data(Qt.ItemDataRole.FontRole)
        if isinstance(font, QFont):
            if font.bold():
                styles.append("font-weight:bold")
            if font.italic():
                styles.append("font-style:italic")
            if font.underline():
                styles.append("text-decoration:underline")
        fragment = index.data(HTML_ROLE)
    else:
        fragment = None
    contents = fragment if isinstance(fragment, str) and fragment else _plain_html(text)
    return f'<td x:str style="{escape(";".join(styles), quote=True)}">{contents}</td>'


def copy_table_selection(view, *, include_headers: bool = False) -> bool:
    """Copy visible selected cells as TSV and Excel-compatible rich HTML.

    The current view model supplies filtered/sorted values. Entirely unselected
    rows/columns are omitted; holes inside that selection stay empty, and their
    data is never read. Header sections follow their on-screen order. Optional
    headers are horizontal only: chain names in the matrix are ordinary cells
    in column zero, so they are copied only when explicitly selected.
    """
    selection = view.selectionModel()
    if selection is None:
        return False
    selected = {(index.row(), index.column()): index for index in selection.selectedIndexes()
                if index.isValid() and not view.isRowHidden(index.row()) and not view.isColumnHidden(index.column())}
    if not selected:
        return False
    rows = sorted({row for row, _ in selected}, key=view.verticalHeader().visualIndex)
    columns = sorted({column for _, column in selected}, key=view.horizontalHeader().visualIndex)
    plain_rows, html_rows = [], []
    if include_headers:
        headers = [view.model().headerData(column, Qt.Orientation.Horizontal, Qt.ItemDataRole.DisplayRole)
                   for column in columns]
        headers = ["" if value is None else str(value) for value in headers]
        plain_rows.append(headers)
        html_rows.append("<tr>" + "".join(_cell_html(None, value) for value in headers) + "</tr>")
    for row in rows:
        values, cells = [], []
        for column in columns:
            index = selected.get((row, column))
            value = _display_text(index) if index is not None else ""
            values.append(value)
            cells.append(_cell_html(index, value))
        plain_rows.append(values)
        html_rows.append("<tr>" + "".join(cells) + "</tr>")
    stream = StringIO(newline="")
    csv.writer(stream, delimiter="\t", lineterminator="\r\n").writerows(plain_rows)
    fragment = ('<table xmlns:x="urn:schemas-microsoft-com:office:excel" '
                'style="border-collapse:collapse">' + "".join(html_rows) + "</table>")
    mime = QMimeData()
    mime.setText(stream.getvalue())
    mime.setHtml(_html_document(fragment))
    # setHtml gives Qt's native converters the standard HTML representation.
    # The explicit Windows representation also carries correct non-ASCII byte
    # offsets when a consumer requests the registered HTML Format directly.
    mime.setData(WINDOWS_HTML_MIME, cf_html_bytes(fragment))
    QApplication.clipboard().setMimeData(mime)
    return True


class RichTextItemDelegate(QStyledItemDelegate):
    """Paint per-chain emphasis while retaining the native selection/focus UI."""

    def _document(self, option, fragment: str, width: int | None = None):
        document = QTextDocument()
        document.setDocumentMargin(0)
        document.setDefaultFont(option.font)
        group = QPalette.ColorGroup.Normal if option.state & QStyle.StateFlag.State_Enabled else QPalette.ColorGroup.Disabled
        role = QPalette.ColorRole.HighlightedText if option.state & QStyle.StateFlag.State_Selected else QPalette.ColorRole.Text
        document.setDefaultStyleSheet(f"body {{ color: {option.palette.color(group, role).name()}; }}")
        text_option = document.defaultTextOption()
        text_option.setTextDirection(option.direction)
        text_option.setAlignment(option.displayAlignment & Qt.AlignmentFlag.AlignHorizontal_Mask)
        wrap = bool(option.features & QStyleOptionViewItem.ViewItemFeature.WrapText)
        text_option.setWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere if wrap else QTextOption.WrapMode.NoWrap)
        document.setDefaultTextOption(text_option)
        document.setHtml(fragment)
        if width is not None and width > 0:
            document.setTextWidth(width)
        return document

    def paint(self, painter, option, index):
        fragment = index.data(HTML_ROLE)
        if not isinstance(fragment, str) or not fragment:
            super().paint(painter, option, index)
            return
        prepared = QStyleOptionViewItem(option)
        self.initStyleOption(prepared, index)
        style = prepared.widget.style() if prepared.widget else QApplication.style()
        text_rect = style.subElementRect(QStyle.SubElement.SE_ItemViewItemText, prepared, prepared.widget)
        document = self._document(prepared, fragment, text_rect.width())
        prepared.text = ""
        style.drawControl(QStyle.ControlElement.CE_ItemViewItem, prepared, painter, prepared.widget)
        y = float(text_rect.top())
        spare_height = max(0., text_rect.height() - document.size().height())
        if prepared.displayAlignment & Qt.AlignmentFlag.AlignBottom:
            y += spare_height
        elif prepared.displayAlignment & Qt.AlignmentFlag.AlignVCenter:
            y += spare_height / 2
        painter.save()
        painter.setClipRect(option.rect)
        painter.translate(text_rect.left(), y)
        context = QAbstractTextDocumentLayout.PaintContext()
        context.palette = prepared.palette
        context.clip = QRectF(0, 0, text_rect.width(), text_rect.height())
        document.documentLayout().draw(painter, context)
        painter.restore()

    def sizeHint(self, option, index):
        fragment = index.data(HTML_ROLE)
        size = super().sizeHint(option, index)
        if not isinstance(fragment, str) or not fragment:
            return size
        prepared = QStyleOptionViewItem(option)
        self.initStyleOption(prepared, index)
        style = prepared.widget.style() if prepared.widget else QApplication.style()
        text_rect = style.subElementRect(QStyle.SubElement.SE_ItemViewItemText, prepared, prepared.widget)
        width = text_rect.width() if text_rect.width() > 0 else None
        document = self._document(prepared, fragment, width)
        # Measure padding from a single native line. The ordinary size hint can
        # already contain several wrapped lines, which must not count as padding
        # a second time when measuring the rich document.
        single_line = QStyleOptionViewItem(prepared)
        single_line.text = "M"
        single_line.features &= ~QStyleOptionViewItem.ViewItemFeature.WrapText
        line_size = style.sizeFromContents(QStyle.ContentsType.CT_ItemViewItem, single_line, QSize(), prepared.widget)
        padding = max(0, line_size.height() - prepared.fontMetrics.height())
        return QSize(max(size.width(), ceil(document.idealWidth())),
                     max(size.height(), ceil(document.size().height()) + padding))
