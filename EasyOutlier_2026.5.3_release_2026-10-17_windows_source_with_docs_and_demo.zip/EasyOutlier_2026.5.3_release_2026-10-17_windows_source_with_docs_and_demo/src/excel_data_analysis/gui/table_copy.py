"""Bind form-defined copy actions and standard shortcuts to a result table."""
import sys

from PySide6.QtCore import QEvent, QObject, Qt
from PySide6.QtGui import QKeySequence

from .tsk_sample_table_support import copy_table_selection


class TableCopyController(QObject):
    def __init__(self, table, copy_action, copy_headers_action):
        super().__init__(table)
        self.table = table
        self.actions = (copy_action, copy_headers_action)
        self._disposed = False
        table.destroyed.connect(self._dispose)
        copy_action.triggered.connect(lambda: copy_table_selection(table))
        copy_headers_action.triggered.connect(lambda: copy_table_selection(table, include_headers=True))
        table.selectionModel().selectionChanged.connect(self._update_actions)
        table.model().modelReset.connect(self._update_actions)
        table.model().rowsRemoved.connect(self._update_actions)
        table.installEventFilter(self)
        self._update_actions()

    def _update_actions(self, *_args):
        if self._disposed:
            return
        for action in self.actions:
            action.setEnabled(self.table.selectionModel().hasSelection())

    def _dispose(self):
        self._disposed = True

    def eventFilter(self, watched, event):
        if watched is self.table and event.type() == QEvent.KeyPress:
            # Qt maps the physical Control key to MetaModifier on macOS.
            control = Qt.MetaModifier if sys.platform == "darwin" else Qt.ControlModifier
            if event.matches(QKeySequence.Copy) or (event.key() == Qt.Key_C and event.modifiers() == control):
                copy_table_selection(self.table)
                event.accept()
                return True
        return super().eventFilter(watched, event)
