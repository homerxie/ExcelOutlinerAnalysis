"""Draggable field tags; appearance and view options are defined by the forms."""
from PySide6.QtCore import QPoint, Qt, Signal
from PySide6.QtGui import QDrag, QPainter, QPalette, QPen
from PySide6.QtWidgets import QListWidget


class TskLabelTagList(QListWidget):
    tags_moved = Signal()
    MIME_TYPE = "application/x-easyoutlier-coordinate-label-field"

    def __init__(self, parent=None):
        super().__init__(parent)
        self.editor_token = None
        self._drop_index = None

    def field_keys(self):
        return [self.item(index).data(Qt.UserRole) for index in range(self.count())]

    def transfer_from(self, source, field_key, insertion_index):
        """Move exactly one item, sharing the path used by drag/drop and controls."""
        if (not isinstance(source, TskLabelTagList) or self.editor_token is None
                or source.editor_token is not self.editor_token):
            return False
        keys = source.field_keys()
        if field_key not in keys or (source is not self and field_key in self.field_keys()):
            return False
        old_index = keys.index(field_key)
        target = max(0, min(int(insertion_index), self.count()))
        if source is self:
            if old_index < target:
                target -= 1
            if old_index == target:
                return False
        item = source.takeItem(old_index)
        self.insertItem(target, item)
        self.setCurrentItem(item)
        self.scrollToItem(item)
        self.tags_moved.emit()
        return True

    def startDrag(self, supported_actions):
        item = self.currentItem()
        if item is None or self.editor_token is None:
            return
        # Retain Qt's item MIME data so its auto-scroll handling can run.
        mime = self.model().mimeData([self.indexFromItem(item)])
        mime.setData(self.MIME_TYPE, str(item.data(Qt.UserRole)).encode("utf-8"))
        drag = QDrag(self)
        drag.setMimeData(mime)
        rect = self.visualItemRect(item)
        drag.setPixmap(self.viewport().grab(rect))
        drag.setHotSpot(QPoint(min(12, rect.width() // 2), rect.height() // 2))
        # dropEvent transfers the actual item. Never delete it again on return.
        drag.exec(Qt.MoveAction)
        self._drop_index = None
        self.viewport().update()

    def _drag_field(self, event):
        source = event.source()
        if (not isinstance(source, TskLabelTagList) or self.editor_token is None
                or source.editor_token is not self.editor_token or not event.mimeData().hasFormat(self.MIME_TYPE)):
            return None
        try:
            key = bytes(event.mimeData().data(self.MIME_TYPE)).decode("utf-8")
        except UnicodeDecodeError:
            return None
        return key if key in source.field_keys() else None

    def _insertion_index(self, position):
        for index in range(self.count()):
            rect = self.visualItemRect(self.item(index))
            if position.y() < rect.top():
                return index
            if position.y() <= rect.bottom() and position.x() < rect.center().x():
                return index
        return self.count()

    def dragEnterEvent(self, event):
        if self._drag_field(event) is None:
            event.ignore()
            return
        super().dragEnterEvent(event)
        event.setDropAction(Qt.MoveAction)
        event.accept()

    def dragMoveEvent(self, event):
        if self._drag_field(event) is None:
            event.ignore()
            return
        super().dragMoveEvent(event)
        self._drop_index = self._insertion_index(event.position().toPoint())
        event.setDropAction(Qt.MoveAction)
        event.accept()
        self.viewport().update()

    def dragLeaveEvent(self, event):
        self._drop_index = None
        self.viewport().update()
        super().dragLeaveEvent(event)

    def dropEvent(self, event):
        key = self._drag_field(event)
        self._drop_index = None
        if key is None:
            event.ignore()
            return
        self.transfer_from(event.source(), key, self._insertion_index(event.position().toPoint()))
        event.setDropAction(Qt.MoveAction)
        event.accept()
        self.viewport().update()

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self.viewport())
        if not self.count():
            painter.setPen(self.palette().color(QPalette.PlaceholderText))
            painter.drawText(self.viewport().rect().adjusted(8, 4, -8, -4), Qt.AlignCenter,
                             str(self.property("emptyText") or ""))
        if self._drop_index is not None:
            if self.count():
                index = min(self._drop_index, self.count() - 1)
                rect = self.visualItemRect(self.item(index))
                x = rect.left() - 2 if self._drop_index < self.count() else rect.right() + 2
                top, bottom = rect.top(), rect.bottom()
            else:
                x, top, bottom = 5, 5, self.viewport().height() - 5
            painter.setPen(QPen(self.palette().color(QPalette.Highlight), 2))
            painter.drawLine(x, top, x, bottom)
        painter.end()
