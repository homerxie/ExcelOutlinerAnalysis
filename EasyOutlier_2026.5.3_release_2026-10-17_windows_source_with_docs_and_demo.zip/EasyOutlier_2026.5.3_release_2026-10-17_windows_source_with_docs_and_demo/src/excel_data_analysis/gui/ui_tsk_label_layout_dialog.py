# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_label_layout_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QDialog, QFrame,
    QHBoxLayout, QLabel, QListView, QListWidgetItem,
    QPlainTextEdit, QPushButton, QScrollArea, QSizePolicy,
    QSpacerItem, QVBoxLayout, QWidget)

from excel_data_analysis.gui.tsk_label_tags import TskLabelTagList

class Ui_TskLabelLayoutDialogForm(object):
    def setupUi(self, TskLabelLayoutDialogForm):
        if not TskLabelLayoutDialogForm.objectName():
            TskLabelLayoutDialogForm.setObjectName(u"TskLabelLayoutDialogForm")
        TskLabelLayoutDialogForm.resize(570, 600)
        TskLabelLayoutDialogForm.setMinimumSize(QSize(440, 420))
        TskLabelLayoutDialogForm.setModal(False)
        self.dialogLayout = QVBoxLayout(TskLabelLayoutDialogForm)
        self.dialogLayout.setSpacing(8)
        self.dialogLayout.setObjectName(u"dialogLayout")
        self.dialogLayout.setContentsMargins(12, 12, 12, 12)
        self.hintLabel = QLabel(TskLabelLayoutDialogForm)
        self.hintLabel.setObjectName(u"hintLabel")
        self.hintLabel.setWordWrap(True)

        self.dialogLayout.addWidget(self.hintLabel)

        self.rowsHeadingLayout = QHBoxLayout()
        self.rowsHeadingLayout.setObjectName(u"rowsHeadingLayout")
        self.rowsTitle = QLabel(TskLabelLayoutDialogForm)
        self.rowsTitle.setObjectName(u"rowsTitle")

        self.rowsHeadingLayout.addWidget(self.rowsTitle)

        self.rowsSpacer = QSpacerItem(20, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.rowsHeadingLayout.addItem(self.rowsSpacer)

        self.addRowButton = QPushButton(TskLabelLayoutDialogForm)
        self.addRowButton.setObjectName(u"addRowButton")

        self.rowsHeadingLayout.addWidget(self.addRowButton)


        self.dialogLayout.addLayout(self.rowsHeadingLayout)

        self.rowsScrollArea = QScrollArea(TskLabelLayoutDialogForm)
        self.rowsScrollArea.setObjectName(u"rowsScrollArea")
        self.rowsScrollArea.setWidgetResizable(True)
        self.rowsScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.rowsScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.rowsContainer = QWidget()
        self.rowsContainer.setObjectName(u"rowsContainer")
        self.rowsLayout = QVBoxLayout(self.rowsContainer)
        self.rowsLayout.setSpacing(6)
        self.rowsLayout.setObjectName(u"rowsLayout")
        self.rowsLayout.setContentsMargins(0, 0, 16, 0)
        self.rowsBottomSpacer = QSpacerItem(20, 0, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.rowsLayout.addItem(self.rowsBottomSpacer)

        self.rowsScrollArea.setWidget(self.rowsContainer)

        self.dialogLayout.addWidget(self.rowsScrollArea)

        self.hiddenTitle = QLabel(TskLabelLayoutDialogForm)
        self.hiddenTitle.setObjectName(u"hiddenTitle")
        self.hiddenTitle.setWordWrap(True)

        self.dialogLayout.addWidget(self.hiddenTitle)

        self.hiddenTags = TskLabelTagList(TskLabelLayoutDialogForm)
        self.hiddenTags.setObjectName(u"hiddenTags")
        self.hiddenTags.setMinimumSize(QSize(0, 62))
        self.hiddenTags.setMaximumSize(QSize(16777215, 76))
        self.hiddenTags.setFlow(QListView.Flow.LeftToRight)
        self.hiddenTags.setProperty(u"isWrapping", True)
        self.hiddenTags.setResizeMode(QListView.ResizeMode.Adjust)
        self.hiddenTags.setSpacing(4)
        self.hiddenTags.setDragEnabled(True)
        self.hiddenTags.setAcceptDrops(True)
        self.hiddenTags.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
        self.hiddenTags.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.hiddenTags.setDragDropOverwriteMode(False)
        self.hiddenTags.setProperty(u"showDropIndicator", False)
        self.hiddenTags.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.hiddenTags.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)

        self.dialogLayout.addWidget(self.hiddenTags)

        self.previewTitle = QLabel(TskLabelLayoutDialogForm)
        self.previewTitle.setObjectName(u"previewTitle")
        self.previewTitle.setTextFormat(Qt.TextFormat.PlainText)

        self.dialogLayout.addWidget(self.previewTitle)

        self.previewEdit = QPlainTextEdit(TskLabelLayoutDialogForm)
        self.previewEdit.setObjectName(u"previewEdit")
        self.previewEdit.setReadOnly(True)
        self.previewEdit.setMaximumSize(QSize(16777215, 76))
        self.previewEdit.setMinimumSize(QSize(0, 56))
        font = QFont()
        font.setPointSize(10)
        self.previewEdit.setFont(font)
        self.previewEdit.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)

        self.dialogLayout.addWidget(self.previewEdit)

        self.footerLayout = QHBoxLayout()
        self.footerLayout.setObjectName(u"footerLayout")
        self.resetButton = QPushButton(TskLabelLayoutDialogForm)
        self.resetButton.setObjectName(u"resetButton")

        self.footerLayout.addWidget(self.resetButton)

        self.footerSpacer = QSpacerItem(20, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.footerLayout.addItem(self.footerSpacer)

        self.closeButton = QPushButton(TskLabelLayoutDialogForm)
        self.closeButton.setObjectName(u"closeButton")

        self.footerLayout.addWidget(self.closeButton)


        self.dialogLayout.addLayout(self.footerLayout)

        self.dialogLayout.setStretch(2, 1)

        self.retranslateUi(TskLabelLayoutDialogForm)

        QMetaObject.connectSlotsByName(TskLabelLayoutDialogForm)
    # setupUi

    def retranslateUi(self, TskLabelLayoutDialogForm):
        TskLabelLayoutDialogForm.setWindowTitle(QCoreApplication.translate("TskLabelLayoutDialogForm", u"\u6807\u7b7e\u6392\u7248", None))
        TskLabelLayoutDialogForm.setProperty(u"builtinFieldLabels", QCoreApplication.translate("TskLabelLayoutDialogForm", u"tsk_id=TSK \u7c7b\u578b\n"
"instance_id=\u5b9e\u4f8b\u7f16\u53f7\n"
"chain_id=Chain\n"
"x=X \u5750\u6807\n"
"y=Y \u5750\u6807\n"
"probability=\u5b9e\u4f8b\u9884\u4f30\u5931\u6548\u7387\n"
"observed=\u94fe\u8def\u89c2\u6d4b\u5931\u6548\u7387\n"
"predicted=\u94fe\u8def\u9884\u6d4b\u5931\u6548\u7387", None))
        TskLabelLayoutDialogForm.setProperty(u"emptyPreviewText", QCoreApplication.translate("TskLabelLayoutDialogForm", u"\u5168\u90e8\u5b57\u6bb5\u5df2\u9690\u85cf\uff0c\u53ea\u663e\u793a\u70b9\u3002", None))
        TskLabelLayoutDialogForm.setProperty(u"noInstanceText", QCoreApplication.translate("TskLabelLayoutDialogForm", u"\u6682\u65e0\u53ef\u9884\u89c8\u7684\u5b9e\u4f8b\uff1b\u6392\u7248\u4f1a\u5e94\u7528\u5230\u540e\u7eed\u5750\u6807\u6570\u636e\u3002", None))
        TskLabelLayoutDialogForm.setProperty(u"previewFormat", QCoreApplication.translate("TskLabelLayoutDialogForm", u"\u9884\u89c8 \u00b7 {instance}", None))
        self.hintLabel.setText(QCoreApplication.translate("TskLabelLayoutDialogForm", u"\u62d6\u52a8\u6807\u7b7e\u8c03\u6574\u884c\u548c\u987a\u5e8f\uff1b\u540c\u4e00\u884c\u7684\u503c\u7528\u300c \u00b7 \u300d\u5206\u9694\u3002\u56fe\u4e2d\u53ea\u663e\u793a\u503c\uff0c\u4fee\u6539\u5373\u65f6\u751f\u6548\u3002", None))
        self.rowsTitle.setText(QCoreApplication.translate("TskLabelLayoutDialogForm", u"\u663e\u793a\u884c", None))
        self.addRowButton.setText(QCoreApplication.translate("TskLabelLayoutDialogForm", u"\uff0b \u6dfb\u52a0\u4e00\u884c", None))
        self.hiddenTitle.setText(QCoreApplication.translate("TskLabelLayoutDialogForm", u"\u4e0d\u663e\u793a \u00b7 \u62d6\u5230\u8fd9\u91cc\u9690\u85cf\uff0c\u62d6\u56de\u663e\u793a\u884c\u5373\u53ef\u6062\u590d", None))
        self.hiddenTags.setStyleSheet(QCoreApplication.translate("TskLabelLayoutDialogForm", u"QListWidget { border: 1px dashed palette(mid); border-radius: 6px; background: palette(base); }\n"
"QListWidget::item { padding: 6px 9px; border: 1px solid palette(mid); border-radius: 10px; background: palette(button); color: palette(button-text); }\n"
"QListWidget::item:selected { background: palette(highlight); color: palette(highlighted-text); border-color: palette(highlight); }", None))
        self.hiddenTags.setProperty(u"emptyText", QCoreApplication.translate("TskLabelLayoutDialogForm", u"\u5c06\u4e0d\u9700\u8981\u663e\u793a\u7684\u5b57\u6bb5\u62d6\u5230\u8fd9\u91cc", None))
        self.previewTitle.setText(QCoreApplication.translate("TskLabelLayoutDialogForm", u"\u9884\u89c8", None))
        self.previewTitle.setProperty(u"defaultText", QCoreApplication.translate("TskLabelLayoutDialogForm", u"\u9884\u89c8", None))
        self.resetButton.setText(QCoreApplication.translate("TskLabelLayoutDialogForm", u"\u6062\u590d\u9ed8\u8ba4", None))
        self.closeButton.setText(QCoreApplication.translate("TskLabelLayoutDialogForm", u"\u5173\u95ed", None))
    # retranslateUi

