"""Shared, read-only TSK/Chain details backed by saved analysis records."""
from __future__ import annotations

from html import escape
import json
import math

from PySide6.QtCore import QEvent, QSignalBlocker, QTimer, QUrl, Signal
from PySide6.QtGui import QPalette
from PySide6.QtWidgets import QWidget

from ..tsk_html_export import _combination_chain_index
from ..tsk_result_state import failed_sample_outcomes
from .tsk_risk_display import is_boundary_low, percentage, risk_available, valid_probability
from .ui_tsk_detail_panel import Ui_TskDetailPanelForm


def _text(value):
    if value is None:
        return "—"
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, default=str)
    return str(value)


def _escaped(value):
    return escape(_text(value), quote=True)


def _finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _condition_parts(row):
    """Keep the saved schema's X/Y coordinates separate from member features."""
    attributes = row.get("features") or {**(row.get("categories") or {}), **(row.get("numeric") or {})}
    features, coordinates = [], []
    for name, value in attributes.items():
        (coordinates if str(name).casefold() in ("x", "y") else features).append((name, value))
    return features, coordinates


class TskDetailPanel(QWidget):
    close_requested = Signal()
    chain_fit_requested = Signal(str)
    chain_location_requested = Signal(str)
    failed_samples_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskDetailPanelForm()
        self.ui.setupUi(self)
        self._apply_document_style()
        self._statuses = dict(line.split("=", 1) for line in self._label("statusTranslations").splitlines() if "=" in line)
        self._payload = {}
        self._group = {}
        self._index = {}
        self._chains = {}
        self._failed_samples = {}
        self._has_sample_outcomes = False
        self._failed_samples_loading = False
        self._failed_samples_error = ""
        self._row = None
        self._kind = None
        self._context = {}
        self._pages = {}
        self._expanded = set()
        self._disclosures = set()
        self._actions = {}
        self._reflow_pending = False
        self.ui.detailsBrowser.viewport().installEventFilter(self)
        self.ui.closeButton.clicked.connect(self.close_requested.emit)
        self.ui.detailsBrowser.anchorClicked.connect(self._activate_link)
        self.ui.searchLineEdit.textChanged.connect(self._search_changed)

    def _apply_document_style(self):
        palette = self.ui.detailsBrowser.palette()
        stylesheet = self._label("documentStyle")
        for token, role in (("@text@", QPalette.ColorRole.Text), ("@card@", QPalette.ColorRole.Window), ("@link@", QPalette.ColorRole.Link)):
            stylesheet = stylesheet.replace(token, palette.color(role).name())
        self.ui.detailsBrowser.document().setDefaultStyleSheet(stylesheet)

    def changeEvent(self, event):
        super().changeEvent(event)
        if event.type() == QEvent.Type.PaletteChange and hasattr(self, "_row"):
            QTimer.singleShot(0, self._refresh_palette)

    def _refresh_palette(self):
        self._apply_document_style()
        self._reflow()

    def eventFilter(self, watched, event):
        # QTextBrowser can retain its old horizontal range after nested tables shrink.
        # Rebind once after the viewport (including its scrollbar) settles.
        if (event.type() == QEvent.Type.Resize and watched is self.ui.detailsBrowser.viewport()
                and self._row is not None and not self._reflow_pending):
            self._reflow_pending = True
            QTimer.singleShot(0, self._reflow)
        return super().eventFilter(watched, event)

    def _reflow(self):
        self._reflow_pending = False
        scroll = self.ui.detailsBrowser.verticalScrollBar().value()
        self._render()
        self.ui.detailsBrowser.verticalScrollBar().setValue(scroll)

    def _label(self, name, **values):
        text = str(self.property(name) or "")
        return text.format(**values) if values else text

    def set_payload_group(self, payload, group):
        """Change context without recalculating or modifying any fitted result."""
        self._payload = payload or {}
        self._group = group or {}
        self._index = self._group.get("combination_chain_index") or _combination_chain_index(self._payload, self._group)
        self._chains = {str(row.get("chain_id")): row for row in self._group.get("chains", [])}
        self._failed_samples_loading = False
        self._failed_samples_error = ""
        self._index_failed_samples()
        self.clear_selection()

    def _index_failed_samples(self):
        outcomes = failed_sample_outcomes(self._group)
        self._has_sample_outcomes = outcomes is not None
        self._failed_samples = {}
        for outcome in outcomes or []:
            self._failed_samples.setdefault(str(outcome.get("chain_id")), []).append(outcome)

    def set_failed_samples_state(self, *, loading=False, error=""):
        self._failed_samples_loading = loading
        self._failed_samples_error = error
        self._reflow()

    def refresh_failed_samples(self):
        """Bind recovered identities without resetting the open Chain or scroll."""
        self._index_failed_samples()
        self.set_failed_samples_state()

    def clear_selection(self):
        self._row = None
        self._kind = None
        self._context = {}
        self._pages.clear()
        self._expanded.clear()
        self._disclosures.clear()
        self._actions.clear()
        self.ui.searchLineEdit.clear()
        self.ui.searchLineEdit.setEnabled(False)
        self.ui.detailsBrowser.setHtml(self._paragraph(self._label("emptyText")))

    def _view_identity(self):
        if self._row is None:
            return None
        if self._kind == "chain":
            return self._kind, str(self._row.get("chain_id", ""))
        return (self._kind, str(self._row.get("tsk_id", "")),
                tuple(sorted((str(name), value) for name, value in
                             (self._row.get("categories") or {}).items())))

    def capture_view_state(self):
        """Keep navigation separately from the selected record's fitted data."""
        identity = self._view_identity()
        if identity is None:
            return None
        browser = self.ui.detailsBrowser
        return {
            "identity": identity,
            "search": self.ui.searchLineEdit.text(),
            "pages": dict(self._pages),
            "expanded": set(self._expanded),
            "disclosures": set(self._disclosures),
            "scroll": (browser.horizontalScrollBar().value(), browser.verticalScrollBar().value()),
        }

    def restore_view_state(self, state):
        """Restore matching record navigation after binding the new payload."""
        if not state or self._view_identity() != state["identity"]:
            return False
        with QSignalBlocker(self.ui.searchLineEdit):
            self.ui.searchLineEdit.setText(state["search"])
        self._pages = dict(state["pages"])
        self._expanded = set(state["expanded"])
        self._disclosures = set(state["disclosures"])
        self._render()
        horizontal, vertical = state["scroll"]
        self.ui.detailsBrowser.horizontalScrollBar().setValue(horizontal)
        self.ui.detailsBrowser.verticalScrollBar().setValue(vertical)
        return True

    def _select(self, kind, row, context=None):
        self._kind = kind
        self._row = row
        self._context = context or {}
        self._pages.clear()
        self._expanded.clear()
        self._disclosures.clear()
        self.ui.searchLineEdit.blockSignals(True)
        self.ui.searchLineEdit.clear()
        self.ui.searchLineEdit.blockSignals(False)
        self.ui.searchLineEdit.setEnabled(True)
        self.ui.searchLineEdit.setPlaceholderText(self._label(kind + "SearchText"))
        self.ui.titleLabel.setText(self._label(kind + "TitleText"))
        self._render()
        self.ui.detailsBrowser.verticalScrollBar().setValue(0)

    def show_risk(self, row, context=None):
        self._select("risk", row, context)

    def show_chain(self, row):
        if not isinstance(row, dict):
            row = self._chains.get(str(row), {"chain_id": str(row), "n_tested": 0})
        self._select("chain", row)

    def _search_changed(self):
        self._pages.clear()
        self._render()
        self.ui.detailsBrowser.verticalScrollBar().setValue(0)

    def _status(self, value):
        return self._statuses.get(value, _text(value))

    def _probability(self, row):
        if not risk_available(row):
            return "—"
        return self._label("boundaryLowText") if is_boundary_low(row) else percentage(row.get("probability"))

    def _interval(self, row):
        if not risk_available(row) or not valid_probability(row.get("ci_upper")):
            return self._label("intervalUnavailableText")
        confidence = (row.get("confidence_level") or self._context.get("confidence_level")
                      or (self._group.get("prediction_context") or {}).get("confidence_level")
                      or self._group.get("diagnostics", {}).get("confidence_level") or .95)
        method = row.get("interval_method", "") or ""
        if row.get("interval_sidedness") == "upper":
            key = "upperApproxIntervalFormat" if "approximate" in method else "upperIntervalFormat"
        elif valid_probability(row.get("ci_lower")):
            key = "conservativeIntervalFormat" if method == "conservative_binomial_chain_bounds" else "twoSidedIntervalFormat"
        else:
            return self._label("intervalUnavailableText")
        return self._label(key, confidence=f"{confidence:.0%}", lower=percentage(row.get("ci_lower")), upper=percentage(row.get("ci_upper")))

    @staticmethod
    def _paragraph(value, style=""):
        return f'<p class="{style}">{_escaped(value)}</p>'

    @staticmethod
    def _named(entries):
        return " · ".join(f"{name}={_text(value)}" for name, value in entries)

    def _identity(self, row, member=False):
        features, _coordinates = _condition_parts(row)
        count = self._label("countFormat", count=_text(row.get("count"))) if member else ""
        values = "".join(" · " + _text(value) for _name, value in features)
        title = self._label("identityFormat", tsk_id=_text(row.get("tsk_id")), count=count, values=values)
        return (f'<h{4 if member else 3}>{_escaped(title)}</h{4 if member else 3}>'
                + self._paragraph(self._named(features) or self._label("noFeaturesText"), "conditions"))

    def _values(self, entries):
        return '<table width="100%" cellspacing="0">' + "".join(
            f'<tr><td valign="top">{_escaped(self._label(label))}</td><td valign="top">{_escaped(value)}</td></tr>'
            for label, value in entries) + '</table>'

    def _link(self, text, action):
        key = str(len(self._actions))
        self._actions[key] = action
        return f'<a href="tskdetail:{key}">{_escaped(text)}</a>'

    def _activate_link(self, url: QUrl):
        if url.scheme() != "tskdetail":
            return
        action = self._actions.get(url.path())
        if not action:
            return
        kind, key, *values = action
        if kind == "fit":
            self.chain_fit_requested.emit(key)
            return
        if kind == "locate":
            self.chain_location_requested.emit(key)
            return
        old_scroll = self.ui.detailsBrowser.verticalScrollBar().value()
        if kind == "page":
            self._pages[key] = values[0]
        else:
            target = self._expanded if kind == "expand" else self._disclosures
            target.remove(key) if key in target else target.add(key)
        self._render()
        self.ui.detailsBrowser.verticalScrollBar().setValue(old_scroll)
        if (kind == "disclose" and key.startswith("failed-samples:")
                and key in self._disclosures and not self._has_sample_outcomes
                and not self._failed_samples_loading):
            self.failed_samples_requested.emit()

    def _disclosure(self, key, title, content):
        opened = key in self._disclosures
        return ('<p>' + self._link(("▾ " if opened else "▸ ") + title, ("disclose", key)) + '</p>'
                + (content if opened else ""))

    def _raw(self, key, title, row):
        # Qt's preformatted blocks do not wrap; regular paragraphs preserve a narrow sidebar.
        if key not in self._disclosures:
            return self._disclosure(key, title, "")
        formatted = json.dumps(row, ensure_ascii=False, indent=2, default=str)
        content = '<p class="raw-record">' + escape(formatted).replace('\n', '<br/>') + '</p>'
        return self._disclosure(key, title, content)

    def _filtered(self, rows):
        query = self.ui.searchLineEdit.text().strip().casefold()
        return [row for row in rows if query in json.dumps(row, ensure_ascii=False, default=str).casefold()] if query else rows

    def _page(self, rows, key, render):
        if not rows:
            return self._paragraph(self._label("noMatchesText"), "caption")
        size = int(self.property("pageSize"))
        pages = max(1, math.ceil(len(rows) / size))
        page = max(0, min(self._pages.get(key, 0), pages - 1))
        parts = [self._paragraph(self._label("pageFormat", page=page + 1, pages=pages, count=len(rows)), "caption")]
        if pages > 1:
            controls = []
            if page:
                controls.append(self._link(self._label("previousText"), ("page", key, page - 1)))
            if page + 1 < pages:
                controls.append(self._link(self._label("nextText"), ("page", key, page + 1)))
            parts.append('<p>' + ' · '.join(controls) + '</p>')
        parts.extend(render(row) for row in rows[page * size:(page + 1) * size])
        return ''.join(parts)

    def _members(self, chain):
        return chain.get("members") or self._group.get("chain_members", {}).get(str(chain.get("chain_id")), [])

    def _related(self, row):
        index = self._index
        if not index.get("available"):
            return [], self._label("noRelationsText")
        dimensions = index.get("dimensions", [])
        key = json.dumps([str(row.get("tsk_id")), [str(row.get("categories", {}).get(name, "")) for name in dimensions]], ensure_ascii=False, separators=(",", ":"))
        ids = index.get("chains_by_key", {}).get(key, [])
        if not ids:
            reason = "incompleteRelationsText" if str(row.get("tsk_id")) in index.get("incomplete_types", []) else "noMatchingRelationsText"
            return [], self._label(reason)
        return [self._chains.get(str(chain_id), {"chain_id": chain_id, "n_tested": 0}) for chain_id in ids], ""

    def _chain_summary(self, chain):
        observed = percentage(chain.get("observed_probability")) if (_finite(chain.get("n_tested")) and chain["n_tested"] > 0) else self._label("noTestsText")
        content = self._values([("observedText", observed), ("predictedText", percentage(chain.get("predicted_probability"))), ("testedText", chain.get("n_tested"))])
        has_tests = _finite(chain.get("n_tested")) and chain["n_tested"] > 0
        if not has_tests or not (valid_probability(chain.get("observed_probability")) and valid_probability(chain.get("predicted_probability"))):
            reason = self._label("invalidPairText" if has_tests else "noTestsDetailText")
            content += self._paragraph(self._label("noPointFormat", reason=reason), "caption")
        return content

    def _member_card(self, member, chain_id):
        # Fitted records are replaced on batch changes; object addresses cannot
        # identify the same member's expanded raw record in the new payload.
        conditions = member.get("features") or {**(member.get("categories") or {}), **(member.get("numeric") or {})}
        key = "member:" + json.dumps([chain_id, str(member.get("tsk_id", "")), conditions],
                                     ensure_ascii=False, sort_keys=True, default=str)
        parts = [self._identity(member, True), self._values([
            ("probabilityText", self._probability(member)), ("intervalText", self._interval(member)), ("statusText", self._status(member.get("status")))])]
        for text in (member.get("reason"), self._label("intervalErrorFormat", error=member["interval_error"]) if member.get("interval_error") else "",
                     self._label("boundaryHintText") if is_boundary_low(member) and risk_available(member) else ""):
            if text:
                parts.append(self._paragraph(text, "caption"))
        if member.get("instance_ids"):
            ids = member["instance_ids"]
            parts.append(self._paragraph(self._label("instanceIdsFormat", values="、".join(map(str, ids)) if isinstance(ids, list) else _text(ids)), "caption"))
        coordinates = _condition_parts(member)[1]
        if coordinates:
            parts.append(self._paragraph(self._label("coordinatesFormat", values=self._named(coordinates)), "coordinates"))
        parts.append(self._raw(key, self._label("memberRecordText"), member))
        return '<table class="card" width="100%" cellspacing="0" cellpadding="6"><tr><td>' + ''.join(parts) + '</td></tr></table><p></p>'

    def _member_list(self, chain, search=False):
        members = self._members(chain)
        parts = [self._paragraph(self._label("memberHintText"), "caption")]
        chain_id = str(chain.get("chain_id"))
        parts.append(self._page(self._filtered(members) if search else members, "members:" + chain_id,
                                lambda member: self._member_card(member, chain_id))
                     if members else self._paragraph(self._label("noMembersText"), "caption"))
        return ''.join(parts)

    def _failed_sample(self, row):
        sample_key = row.get("sample_key")
        sample_id = (self._label("sampleKeySeparator").join(map(str, sample_key))
                     if isinstance(sample_key, (list, tuple)) else _text(sample_key))
        return self._paragraph(self._label("failedSampleFormat", sample_id=sample_id))

    def _failed_sample_list(self, chain, search=False):
        chain_id = str(chain.get("chain_id"))
        rows = self._failed_samples.get(chain_id, [])
        available = self._has_sample_outcomes and not (
            not rows and _finite(chain.get("n_failed")) and chain["n_failed"] > 0)
        key = "failed-samples:" + chain_id
        opened = key in self._disclosures
        title = self._label("collapseFailedSamplesFormat" if opened else "expandFailedSamplesFormat",
                            count=len(rows) if available else "—")
        parts = ['<p>' + self._link(title, ("disclose", key)) + '</p>']
        if opened:
            if not available:
                message = (self._label("loadingFailedSamplesText") if self._failed_samples_loading else
                           self._failed_samples_error or self._label("missingFailedSamplesText"))
                parts.append(self._paragraph(message, "caption"))
            elif not rows:
                parts.append(self._paragraph(self._label("noFailedSamplesText"), "caption"))
            else:
                parts.append(self._page(self._filtered(rows) if search else rows, key, self._failed_sample))
        return ''.join(parts)

    def _related_card(self, chain):
        chain_id = str(chain.get("chain_id"))
        members = self._members(chain)
        opened = chain_id in self._expanded
        parts = [f'<h4>{self._link(self._label("chainFormat", chain_id=chain_id), ("locate", chain_id))}</h4>', self._chain_summary(chain)]
        title = self._label("collapseMembersFormat" if opened else "expandMembersFormat", count=len(members))
        parts.append('<p>' + self._link(title, ("expand", chain_id)) + '</p>')
        parts.append(self._failed_sample_list(chain))
        if opened:
            parts.append(self._member_list(chain))
        if chain_id in self._chains:
            parts.append('<p>' + self._link(self._label("fitLinkText"), ("fit", chain_id)) + '</p>')
        parts.append(self._raw("chain:" + chain_id, self._label("chainRecordText"), chain))
        return ''.join(parts) + '<hr/>'

    def _risk_content(self):
        row = self._row
        parts = [self._identity(row), self._values([("probabilityText", self._probability(row)), ("intervalText", self._interval(row))])]
        if risk_available(row) and is_boundary_low(row):
            parts.append(self._paragraph(self._label("boundaryHintText"), "caption"))
        related, reason = self._related(row)
        parts.append('<h3>' + _escaped(self._label("relatedChainsFormat", count=len(related))) + '</h3>')
        parts.append(self._paragraph(self._label("relationHintText"), "caption"))
        if related:
            # Search both detail lists without changing stored chain records.
            query = self.ui.searchLineEdit.text().strip().casefold()
            shown = [chain for chain in related if not query or query in json.dumps({
                **chain, "members": self._members(chain),
                "failed_samples": self._failed_samples.get(str(chain.get("chain_id")), []),
            }, ensure_ascii=False, default=str).casefold()]
            parts.append(self._page(shown, "related", self._related_card))
        else:
            parts.append(self._paragraph(reason, "caption"))
        stats = self._values([
            ("probabilityText", self._probability(row)), ("intervalText", self._interval(row)), ("fitStatusText", self._status(row.get("status"))),
            ("supportText", self._label("noDataSupportText") if row.get("status") == "no_data" else self._status(row.get("support_status"))),
            ("layoutCountText", row.get("layout_instance_count", row.get("instance_count"))), ("activeCountText", row.get("active_instance_count")),
            ("chainCountText", row.get("chain_count")), ("exposureText", row.get("chain_test_exposure")), ("intervalMethodText", row.get("interval_method")),
            ("intervalErrorText", row.get("interval_error")), ("reasonText", row.get("reason"))])
        parts.extend([self._disclosure("risk-statistics", self._label("riskStatisticsText"), stats), self._paragraph(self._label("exposureHintText"), "caption"), self._raw("risk-record", self._label("riskRecordText"), row)])
        return ''.join(parts)

    def _chain_content(self):
        row = self._row
        chain_id = str(row.get("chain_id"))
        parts = ['<h3>' + self._link(self._label("chainFormat", chain_id=chain_id), ("locate", chain_id)) + '</h3>', self._chain_summary(row),
                 self._failed_sample_list(row, search=True),
                 '<h3>' + _escaped(self._label("membersTitleText")) + '</h3>', self._member_list(row, search=True)]
        passed = row.get("n_passed")
        if passed is None and _finite(row.get("n_tested")) and _finite(row.get("n_failed")):
            passed = max(0, row["n_tested"] - row["n_failed"])
        residual = row.get("residual")
        stats = self._chain_summary(row) + self._values([
            ("failedText", row.get("n_failed")), ("passedText", passed), ("missingText", row.get("n_missing")),
            ("residualText", f"{residual * 100:+.5g} pp" if _finite(residual) else "—"), ("devianceText", row.get("deviance_residual"))])
        parts.extend([self._disclosure("chain-statistics", self._label("chainStatisticsText"), stats), self._raw("chain-record", self._label("chainRecordText"), row)])
        return ''.join(parts)

    def _render(self):
        if self._row is None:
            return
        self._actions.clear()
        content = self._risk_content() if self._kind == "risk" else self._chain_content()
        self.ui.detailsBrowser.setHtml('<html><body>' + content + '</body></html>')
