"""Compact coordinate-unit values, including microscopic coordinate systems."""
from math import floor, isfinite, log10
import re

from PySide6.QtCore import Property
from PySide6.QtGui import QValidator
from PySide6.QtWidgets import QDoubleSpinBox


class CoordinateSizeSpinBox(QDoubleSpinBox):
    """Keep a wide numeric range editable without a wide decimal-only field."""

    @Property(str)
    def minimumText(self):
        return str(self.minimum())

    @minimumText.setter
    def minimumText(self, value):
        # uic rounds <double> properties to 15 decimal places. A source-defined
        # string preserves positive limits below that generated precision.
        self.setMinimum(float(value))

    def textFromValue(self, value):
        return f"{value:.6g}"

    def valueFromText(self, text):
        try:
            value = float(text.strip())
        except ValueError:
            return self.value()
        return value if isfinite(value) else self.value()

    def validate(self, text, pos):
        stripped = text.strip()
        if re.fullmatch(r"\+?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", stripped):
            value = float(stripped)
            state = (QValidator.State.Acceptable
                     if isfinite(value) and self.minimum() <= value <= self.maximum()
                     else QValidator.State.Intermediate)
        elif (stripped in ("", "+", ".", "+.")
              or re.fullmatch(r"\+?(?:\d+(?:\.\d*)?|\.\d+)[eE][+-]?", stripped)):
            state = QValidator.State.Intermediate
        else:
            state = QValidator.State.Invalid
        return state, text, pos

    def stepBy(self, steps):
        value = self.value()
        # A tenth of the current order of magnitude gives useful arrow steps
        # for both ordinary and near-zero coordinate systems.
        step = max(10. ** (floor(log10(value)) - 1), self.minimum()) if value > 0 else self.minimum()
        self.setValue(value + steps * step)
