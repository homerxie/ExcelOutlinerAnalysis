# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_delete_analysis_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
    QPushButton, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)

class Ui_TskDeleteAnalysisDialog(object):
    def setupUi(self, TskDeleteAnalysisDialog):
        if not TskDeleteAnalysisDialog.objectName():
            TskDeleteAnalysisDialog.setObjectName(u"TskDeleteAnalysisDialog")
        TskDeleteAnalysisDialog.setMinimumSize(QSize(520, 0))
        self.dialogLayout = QVBoxLayout(TskDeleteAnalysisDialog)
        self.dialogLayout.setSpacing(16)
        self.dialogLayout.setObjectName(u"dialogLayout")
        self.titleLabel = QLabel(TskDeleteAnalysisDialog)
        self.titleLabel.setObjectName(u"titleLabel")
        font = QFont()
        font.setBold(True)
        self.titleLabel.setFont(font)

        self.dialogLayout.addWidget(self.titleLabel)

        self.analysisLabel = QLabel(TskDeleteAnalysisDialog)
        self.analysisLabel.setObjectName(u"analysisLabel")
        self.analysisLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.analysisLabel.setWordWrap(True)

        self.dialogLayout.addWidget(self.analysisLabel)

        self.messageLabel = QLabel(TskDeleteAnalysisDialog)
        self.messageLabel.setObjectName(u"messageLabel")
        self.messageLabel.setWordWrap(True)

        self.dialogLayout.addWidget(self.messageLabel)

        self.buttonsLayout = QHBoxLayout()
        self.buttonsLayout.setObjectName(u"buttonsLayout")
        self.buttonsSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.buttonsLayout.addItem(self.buttonsSpacer)

        self.cancelButton = QPushButton(TskDeleteAnalysisDialog)
        self.cancelButton.setObjectName(u"cancelButton")

        self.buttonsLayout.addWidget(self.cancelButton)

        self.deleteButton = QPushButton(TskDeleteAnalysisDialog)
        self.deleteButton.setObjectName(u"deleteButton")
        self.deleteButton.setAutoDefault(False)

        self.buttonsLayout.addWidget(self.deleteButton)


        self.dialogLayout.addLayout(self.buttonsLayout)


        self.retranslateUi(TskDeleteAnalysisDialog)
        self.cancelButton.clicked.connect(TskDeleteAnalysisDialog.reject)
        self.deleteButton.clicked.connect(TskDeleteAnalysisDialog.accept)

        self.cancelButton.setDefault(True)


        QMetaObject.connectSlotsByName(TskDeleteAnalysisDialog)
    # setupUi

    def retranslateUi(self, TskDeleteAnalysisDialog):
        TskDeleteAnalysisDialog.setWindowTitle(QCoreApplication.translate("TskDeleteAnalysisDialog", u"\u5220\u9664\u5df2\u4fdd\u5b58\u5206\u6790", None))
        self.titleLabel.setText(QCoreApplication.translate("TskDeleteAnalysisDialog", u"\u786e\u5b9a\u5220\u9664\u4ee5\u4e0b TSK \u5206\u6790\u7ed3\u679c\uff1f", None))
        self.analysisLabel.setText("")
        self.messageLabel.setText(QCoreApplication.translate("TskDeleteAnalysisDialog", u"\u5220\u9664\u540e\u5982\u9700\u6062\u590d\u6b64\u7ed3\u679c\uff0c\u9700\u8981\u91cd\u65b0\u8fd0\u884c\u5206\u6790\u3002\n"
"\n"
"\u4ec5\u5220\u9664\u6240\u9009\u8bb0\u5f55\uff0c\u539f\u59cb\u6570\u636e\u3001Analyze \u7ed3\u679c\u3001\u5176\u4ed6\u5df2\u4fdd\u5b58\u5206\u6790\u548c\u5df2\u5bfc\u51fa\u7684\u6587\u4ef6\u4e0d\u53d7\u5f71\u54cd\u3002", None))
        self.cancelButton.setText(QCoreApplication.translate("TskDeleteAnalysisDialog", u"\u53d6\u6d88", None))
        self.deleteButton.setText(QCoreApplication.translate("TskDeleteAnalysisDialog", u"\u5220\u9664\u5206\u6790", None))
    # retranslateUi

