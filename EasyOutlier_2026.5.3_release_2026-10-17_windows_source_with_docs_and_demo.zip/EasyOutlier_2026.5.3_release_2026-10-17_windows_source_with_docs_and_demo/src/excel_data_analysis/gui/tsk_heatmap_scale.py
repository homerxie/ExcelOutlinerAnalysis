"""A continuous XY effect color scale with labels in the fitted model's units."""
from __future__ import annotations

import math

import numpy as np
from PySide6.QtCore import QEvent, QPointF, QRectF, QSize, Qt
from PySide6.QtGui import QColor, QFontMetricsF, QImage, QPainter, QPalette, QPen
from PySide6.QtWidgets import QWidget

from .tsk_heatmap_colors import heatmap_rgb


class TskHeatmapScale(QWidget):
    """Paint data-dependent ticks; the form owns all visual defaults and text."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.value_range = None
        self._gradient_cache_key = None
        self._gradient_cache_image = None

    def set_range(self, bounds):
        if bounds is not None:
            try:
                low, high = map(float, bounds)
                bounds = (low, high) if math.isfinite(low) and math.isfinite(high) and low <= high else None
            except (TypeError, ValueError, OverflowError):
                bounds = None
        if bounds != self.value_range:
            self.value_range = bounds
            if bounds is None:
                self._gradient_cache_key = self._gradient_cache_image = None
            self.updateGeometry()
            self.update()

    @property
    def tick_values(self):
        if self.value_range is None:
            return ()
        low, high = self.value_range
        return tuple(low * (1. - index / 4.) + high * index / 4. for index in range(5))

    @property
    def tick_labels(self):
        digits = max(1, int(self.property("significantDigits") or 1))
        return tuple(str(self.property("zeroText") or "") if value == 0 else format(value, f"+.{digits}g")
                     for value in self.tick_values)

    def _number(self, name):
        return float(self.property(name) or 0.)

    def _label_widths(self):
        metrics = QFontMetricsF(self.font())
        return [max(metrics.horizontalAdvance(text), metrics.boundingRect(text).width())
                for text in self.tick_labels]

    def minimumSizeHint(self):
        widths = self._label_widths()
        text_width = 0.
        if widths:
            interval = max((left + right) / 2. for left, right in zip(widths, widths[1:]))
            text_width = 4 * (interval + self._number("tickLabelGap")) + (widths[0] + widths[-1]) / 2.
        width = max(int(self._number("minimumScaleWidth")),
                    math.ceil(text_width + 2 * self._number("sideMargin")))
        height = sum(self._number(name) for name in (
            "topMargin", "barHeight", "tickLength", "tickLabelSpacing", "bottomMargin"))
        height += QFontMetricsF(self.font()).height()
        return QSize(width, max(self.minimumHeight(), math.ceil(height)))

    def sizeHint(self):
        size = self.minimumSizeHint()
        size.setWidth(max(size.width(), int(self._number("preferredWidth"))))
        return size

    def scale_rect(self):
        """Logical bar bounds aligned to physical pixels for an unscaled raster."""
        widths = self._label_widths()
        left = self._number("sideMargin") + (widths[0] / 2. if widths else 0.)
        right = self.width() - self._number("sideMargin") - (widths[-1] / 2. if widths else 0.)
        top = self._number("topMargin")
        ratio = self.devicePixelRatioF()
        return QRectF(round(left * ratio) / ratio, round(top * ratio) / ratio,
                      max(0., (round(right * ratio) - round(left * ratio)) / ratio),
                      round(self._number("barHeight") * ratio) / ratio)

    def tick_label_rects(self):
        bar = self.scale_rect()
        metrics = QFontMetricsF(self.font())
        top = bar.bottom() + self._number("tickLength") + self._number("tickLabelSpacing")
        return tuple(QRectF(bar.left() + bar.width() * index / 4. - width / 2., top,
                            width, metrics.height()) for index, width in enumerate(self._label_widths()))

    def changeEvent(self, event):
        super().changeEvent(event)
        if event.type() in (QEvent.FontChange, QEvent.StyleChange):
            self.updateGeometry()
        self.update()

    def event(self, event):
        result = super().event(event)
        if event.type() == QEvent.DynamicPropertyChange:
            self.updateGeometry()
            self.update()
        return result

    def paintEvent(self, event):
        painter = QPainter(self)
        if self.value_range is None:
            return
        bar = self.scale_rect()
        ratio = self.devicePixelRatioF()
        width, height = round(bar.width() * ratio), round(bar.height() * ratio)
        if width < 1 or height < 1:
            return
        painter.drawImage(bar.topLeft(), self._gradient_image(width, height, ratio))
        painter.setRenderHint(QPainter.Antialiasing)
        group = QPalette.Active if self.isEnabled() else QPalette.Disabled
        painter.setPen(QPen(self.palette().color(group, QPalette.Text), self._number("tickWidth")))
        for index, (text, rect) in enumerate(zip(self.tick_labels, self.tick_label_rects())):
            x = bar.left() + bar.width() * index / 4.
            painter.drawLine(QPointF(x, bar.bottom()), QPointF(x, bar.bottom() + self._number("tickLength")))
            painter.drawText(rect, Qt.AlignHCenter | Qt.AlignTop, text)

    def _gradient_image(self, width, height, ratio):
        """Reuse the small physical-pixel bar while only the canvas is moving."""
        negative = QColor(self.property("negativeColor")).getRgb()[:3]
        positive = QColor(self.property("positiveColor")).getRgb()[:3]
        opacity = self._number("heatmapOpacity")
        background = self.palette().color(QPalette.Base).getRgb()[:3]
        key = (self.value_range, width, height, ratio, negative, positive, opacity, background)
        if key == self._gradient_cache_key:
            return self._gradient_cache_image
        low, high = self.value_range
        values = np.broadcast_to(np.linspace(low, high, width), (height, width))
        rgb = heatmap_rgb(values, max(abs(low), abs(high)), negative, positive, opacity, background)
        image = QImage(rgb.data, width, height, rgb.strides[0], QImage.Format_RGB888).copy()
        image.setDevicePixelRatio(ratio)
        self._gradient_cache_key, self._gradient_cache_image = key, image
        return image
