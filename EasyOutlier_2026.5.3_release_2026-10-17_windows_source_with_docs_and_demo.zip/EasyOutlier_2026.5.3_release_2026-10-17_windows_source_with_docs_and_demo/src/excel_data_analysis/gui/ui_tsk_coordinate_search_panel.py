# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_coordinate_search_panel.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QComboBox, QFrame,
    QHBoxLayout, QHeaderView, QLabel, QScrollArea,
    QSizePolicy, QSpacerItem, QToolButton, QTreeWidget,
    QTreeWidgetItem, QVBoxLayout, QWidget)

class Ui_TskCoordinateSearchPanelForm(object):
    def setupUi(self, TskCoordinateSearchPanelForm):
        if not TskCoordinateSearchPanelForm.objectName():
            TskCoordinateSearchPanelForm.setObjectName(u"TskCoordinateSearchPanelForm")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        sizePolicy.setHeightForWidth(TskCoordinateSearchPanelForm.sizePolicy().hasHeightForWidth())
        TskCoordinateSearchPanelForm.setSizePolicy(sizePolicy)
        self.panelLayout = QVBoxLayout(TskCoordinateSearchPanelForm)
        self.panelLayout.setSpacing(6)
        self.panelLayout.setObjectName(u"panelLayout")
        self.panelLayout.setContentsMargins(6, 6, 6, 6)
        self.filterScopeLabel = QLabel(TskCoordinateSearchPanelForm)
        self.filterScopeLabel.setObjectName(u"filterScopeLabel")
        self.filterScopeLabel.setWordWrap(True)

        self.panelLayout.addWidget(self.filterScopeLabel)

        self.filtersScrollArea = QScrollArea(TskCoordinateSearchPanelForm)
        self.filtersScrollArea.setObjectName(u"filtersScrollArea")
        self.filtersScrollArea.setMinimumSize(QSize(0, 146))
        self.filtersScrollArea.setMaximumSize(QSize(16777215, 174))
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.filtersScrollArea.sizePolicy().hasHeightForWidth())
        self.filtersScrollArea.setSizePolicy(sizePolicy1)
        self.filtersScrollArea.setFrameShape(QFrame.NoFrame)
        self.filtersScrollArea.setWidgetResizable(True)
        self.filtersScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.filtersContents = QWidget()
        self.filtersContents.setObjectName(u"filtersContents")
        self.filtersLayout = QVBoxLayout(self.filtersContents)
        self.filtersLayout.setSpacing(4)
        self.filtersLayout.setObjectName(u"filtersLayout")
        self.filtersLayout.setContentsMargins(0, 0, 0, 0)
        self.filterSpacer = QSpacerItem(0, 0, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.filtersLayout.addItem(self.filterSpacer)

        self.filtersScrollArea.setWidget(self.filtersContents)

        self.panelLayout.addWidget(self.filtersScrollArea)

        self.sortLayout = QHBoxLayout()
        self.sortLayout.setSpacing(4)
        self.sortLayout.setObjectName(u"sortLayout")
        self.sortFieldComboBox = QComboBox(TskCoordinateSearchPanelForm)
        self.sortFieldComboBox.setObjectName(u"sortFieldComboBox")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(1)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.sortFieldComboBox.sizePolicy().hasHeightForWidth())
        self.sortFieldComboBox.setSizePolicy(sizePolicy2)
        self.sortFieldComboBox.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.sortFieldComboBox.setMinimumContentsLength(3)

        self.sortLayout.addWidget(self.sortFieldComboBox)

        self.sortDirectionComboBox = QComboBox(TskCoordinateSearchPanelForm)
        self.sortDirectionComboBox.addItem("")
        self.sortDirectionComboBox.addItem("")
        self.sortDirectionComboBox.setObjectName(u"sortDirectionComboBox")

        self.sortLayout.addWidget(self.sortDirectionComboBox)

        self.clearFiltersButton = QToolButton(TskCoordinateSearchPanelForm)
        self.clearFiltersButton.setObjectName(u"clearFiltersButton")
        self.clearFiltersButton.setEnabled(False)

        self.sortLayout.addWidget(self.clearFiltersButton)


        self.panelLayout.addLayout(self.sortLayout)

        self.resultCountLabel = QLabel(TskCoordinateSearchPanelForm)
        self.resultCountLabel.setObjectName(u"resultCountLabel")
        self.resultCountLabel.setTextFormat(Qt.PlainText)
        self.resultCountLabel.setWordWrap(True)

        self.panelLayout.addWidget(self.resultCountLabel)

        self.resultsTreeWidget = QTreeWidget(TskCoordinateSearchPanelForm)
        self.resultsTreeWidget.setObjectName(u"resultsTreeWidget")
        sizePolicy.setHeightForWidth(self.resultsTreeWidget.sizePolicy().hasHeightForWidth())
        self.resultsTreeWidget.setSizePolicy(sizePolicy)
        self.resultsTreeWidget.setMinimumSize(QSize(0, 80))
        self.resultsTreeWidget.setAlternatingRowColors(True)
        self.resultsTreeWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.resultsTreeWidget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.resultsTreeWidget.setTextElideMode(Qt.ElideRight)
        self.resultsTreeWidget.setUniformRowHeights(True)
        self.resultsTreeWidget.setHeaderHidden(True)
        self.resultsTreeWidget.setIndentation(16)

        self.panelLayout.addWidget(self.resultsTreeWidget)

        self.statusLabel = QLabel(TskCoordinateSearchPanelForm)
        self.statusLabel.setObjectName(u"statusLabel")
        self.statusLabel.setTextFormat(Qt.PlainText)
        self.statusLabel.setWordWrap(True)

        self.panelLayout.addWidget(self.statusLabel)

        self.panelLayout.setStretch(4, 1)

        self.retranslateUi(TskCoordinateSearchPanelForm)

        QMetaObject.connectSlotsByName(TskCoordinateSearchPanelForm)
    # setupUi

    def retranslateUi(self, TskCoordinateSearchPanelForm):
        TskCoordinateSearchPanelForm.setProperty(u"tskText", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"TSK ID", None))
        TskCoordinateSearchPanelForm.setProperty(u"probabilityText", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u5b9e\u4f8b\u6700\u9ad8\u5931\u6548\u7387", None))
        TskCoordinateSearchPanelForm.setProperty(u"combinationFormat", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"{tsk_id} \u00b7 {values}", None))
        TskCoordinateSearchPanelForm.setProperty(u"chainFormat", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u94fe\u8def {chain_id}", None))
        TskCoordinateSearchPanelForm.setProperty(u"scopeFormat", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u8986\u76d6 {chains} \u6761\u94fe\u8def \u00b7 {points} \u4e2a\u5750\u6807\u8bb0\u5f55", None))
        TskCoordinateSearchPanelForm.setProperty(u"riskFormat", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u5df2\u5b9a\u4f4d\u5b9e\u4f8b\u7684\u6700\u9ad8\u9884\u4f30\u5931\u6548\u7387\uff1a{risk}", None))
        TskCoordinateSearchPanelForm.setProperty(u"featureFormat", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"{name}: {value}", None))
        TskCoordinateSearchPanelForm.setProperty(u"blankText", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\uff08\u7a7a\u767d\uff09", None))
        TskCoordinateSearchPanelForm.setProperty(u"missingCoordinatesText", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u8be5\u7ec4\u5408\u6682\u65e0\u6709\u6548\u5750\u6807\uff0c\u65e0\u6cd5\u5728\u753b\u5e03\u4e2d\u5b9a\u4f4d\uff1b\u53ef\u5c55\u5f00\u5e76\u9009\u62e9\u6240\u5c5e\u94fe\u8def\u3002", None))
        TskCoordinateSearchPanelForm.setProperty(u"selectionFormat", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u5df2\u9ad8\u4eae\u8be5\u7ec4\u5408\u7684 {count} \u4e2a\u5750\u6807\u8bb0\u5f55\u3002", None))
        TskCoordinateSearchPanelForm.setProperty(u"filterHintText", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u4e0e\u98ce\u9669\u6761\u5f62\u56fe\u76f8\u540c\uff0c\u6309 TSK \u548c\u7c7b\u522b\u7279\u5f81\u7b5b\u9009\uff1b\u4e0d\u540c\u5b57\u6bb5\u540c\u65f6\u751f\u6548\u3002", None))
        TskCoordinateSearchPanelForm.setProperty(u"resultCountFormat", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"{visible} / {total} \u4e2a TSK \u7ec4\u5408", None))
        TskCoordinateSearchPanelForm.setProperty(u"noMatchesText", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u6ca1\u6709\u5339\u914d\u7684 TSK \u7ec4\u5408", None))
        TskCoordinateSearchPanelForm.setProperty(u"emptyText", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u6682\u65e0 TSK \u7ec4\u5408", None))
        self.filterScopeLabel.setText(QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u6309\u98ce\u9669\u6761\u5f62\u56fe\u7684 TSK \u548c\u7c7b\u522b\u7279\u5f81\u7b5b\u9009\uff0c\u6bcf\u4e2a\u7ec4\u5408\u53ea\u5217\u4e00\u9879\u3002", None))
#if QT_CONFIG(tooltip)
        self.filterScopeLabel.setToolTip(QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u540c\u4e00 TSK \u548c\u7c7b\u522b\u7279\u5f81\u7ec4\u5408\u7684\u6240\u6709\u5b9e\u4f8b\u5408\u5e76\u663e\u793a\u3002\u5750\u6807\u53ca\u8fde\u7eed\u6570\u503c\u7279\u5f81\u4e0d\u62c6\u5206\u7ec4\u5408\u3002", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.sortFieldComboBox.setToolTip(QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u7ed3\u679c\u6392\u5e8f\u5b57\u6bb5", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(accessibility)
        self.sortFieldComboBox.setAccessibleName(QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u7ed3\u679c\u6392\u5e8f\u5b57\u6bb5", None))
#endif // QT_CONFIG(accessibility)
        self.sortDirectionComboBox.setItemText(0, QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u5347\u5e8f \u2191", None))
        self.sortDirectionComboBox.setItemText(1, QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u964d\u5e8f \u2193", None))

#if QT_CONFIG(tooltip)
        self.sortDirectionComboBox.setToolTip(QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u7ed3\u679c\u6392\u5e8f\u65b9\u5411", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(accessibility)
        self.sortDirectionComboBox.setAccessibleName(QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u7ed3\u679c\u6392\u5e8f\u65b9\u5411", None))
#endif // QT_CONFIG(accessibility)
        self.clearFiltersButton.setText(QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u91cd\u7f6e", None))
#if QT_CONFIG(tooltip)
        self.clearFiltersButton.setToolTip(QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u6e05\u9664\u6240\u6709\u5b57\u6bb5\u7b5b\u9009", None))
#endif // QT_CONFIG(tooltip)
        self.resultCountLabel.setText(QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u6682\u65e0 TSK \u7ec4\u5408", None))
        ___qtreewidgetitem = self.resultsTreeWidget.headerItem()
        ___qtreewidgetitem.setText(0, QCoreApplication.translate("TskCoordinateSearchPanelForm", u"TSK \u7ec4\u5408\u4e0e\u94fe\u8def", None))
#if QT_CONFIG(tooltip)
        self.resultsTreeWidget.setToolTip(QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u70b9\u51fb TSK \u7ec4\u5408\u9ad8\u4eae\u6240\u6709\u5339\u914d\u5b9e\u4f8b\uff1b\u5c55\u5f00\u540e\u70b9\u51fb\u94fe\u8def\u9ad8\u4eae\u6574\u6761\u94fe\u8def\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.statusLabel.setText(QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u70b9\u51fb TSK \u7ec4\u5408\u5b9a\u4f4d\u5168\u90e8\u5339\u914d\u5b9e\u4f8b\uff1b\u5c55\u5f00\u53ef\u9009\u62e9\u6240\u5c5e\u94fe\u8def\u3002", None))
        self.statusLabel.setProperty(u"idleText", QCoreApplication.translate("TskCoordinateSearchPanelForm", u"\u70b9\u51fb TSK \u7ec4\u5408\u5b9a\u4f4d\u5168\u90e8\u5339\u914d\u5b9e\u4f8b\uff1b\u5c55\u5f00\u53ef\u9009\u62e9\u6240\u5c5e\u94fe\u8def\u3002", None))
    # retranslateUi

