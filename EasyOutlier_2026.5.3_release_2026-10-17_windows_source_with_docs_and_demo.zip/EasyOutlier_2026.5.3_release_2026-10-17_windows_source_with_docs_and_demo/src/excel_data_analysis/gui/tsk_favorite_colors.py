"""Stable bookmark colors and readable native list-item rendering."""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from hashlib import sha256
import re

from PySide6.QtCore import Qt
from PySide6.QtGui import QBrush, QColor, QIcon, QPalette, QPen
from PySide6.QtWidgets import (
    QApplication, QStyle, QStyledItemDelegate, QStyleOptionViewItem,
)

from ..tsk_sorting import natural_sort_key


def _opaque_color(value) -> QColor | None:
    if isinstance(value, QBrush):
        if value.style() == Qt.BrushStyle.NoBrush:
            return None
        value = value.color()
    if not isinstance(value, (str, QColor)):
        return None
    color = QColor(value)
    return color if color.isValid() and color.alpha() == 255 else None


def assign_favorite_colors(
    chains: Iterable[str], existing_mapping: Mapping[str, str] | None,
    palette: Iterable[str | QColor] | str,
) -> dict[str, str]:
    """Retain saved colors and assign unused form-defined colors in name order.

    The result contains only current bookmarks. When the palette runs out,
    colors derived from the chain name remain deterministic, with collisions
    checked against every color already in use.
    """
    ordered = sorted({chain for chain in chains if isinstance(chain, str) and chain},
                     key=lambda chain: (natural_sort_key(chain), chain))
    existing = existing_mapping if isinstance(existing_mapping, Mapping) else {}
    result = {}
    for chain in ordered:
        color = _opaque_color(existing.get(chain))
        if color is not None:
            result[chain] = color.name()
    used = set(result.values())
    palette_values = re.split(r"[,;\s]+", palette.strip()) if isinstance(palette, str) else palette
    available = []
    for value in palette_values:
        color = _opaque_color(value)
        if color is not None and color.name() not in used and color.name() not in available:
            available.append(color.name())
    for chain in ordered:
        if chain in result:
            continue
        if available:
            color_name = available.pop(0)
        else:
            attempt = 0
            while True:
                digest = sha256(f"{chain}\0{attempt}".encode("utf-8")).digest()
                # Moderately saturated colors stay distinguishable as both a
                # row background and a line on the light/dark plot themes.
                color = QColor.fromHsv(int.from_bytes(digest[:2], "big") % 360,
                                      150 + digest[2] % 71, 170 + digest[3] % 61)
                color_name = color.name()
                if color_name not in used:
                    break
                attempt += 1
        result[chain] = color_name
        used.add(color_name)
    return {chain: result[chain] for chain in ordered}


def contrast_text_color(color: str | QColor) -> QColor:
    """Choose black or white using WCAG relative luminance (contrast >= 4.5)."""
    background = _opaque_color(color)
    if background is None:
        raise ValueError("A valid opaque background color is required")
    channels = (background.redF(), background.greenF(), background.blueF())
    linear = [channel / 12.92 if channel <= .04045 else ((channel + .055) / 1.055) ** 2.4
              for channel in channels]
    luminance = sum(value * weight for value, weight in zip(linear, (.2126, .7152, .0722)))
    black_contrast = (luminance + .05) / .05
    white_contrast = 1.05 / (luminance + .05)
    return QColor(Qt.GlobalColor.black if black_contrast >= white_contrast else Qt.GlobalColor.white)


class FavoriteChainColorDelegate(QStyledItemDelegate):
    """Keep bookmark legends visible even under native selected-row styling.

    Item roles supply the state-dependent colors. Native style metrics retain
    checkbox, icon and text geometry; selecting a row adds a contrast outline
    instead of replacing its legend with the platform's selection color.
    """

    def paint(self, painter, option, index):
        background = _opaque_color(index.data(Qt.ItemDataRole.BackgroundRole))
        if background is None:
            super().paint(painter, option, index)
            return
        foreground = (_opaque_color(index.data(Qt.ItemDataRole.ForegroundRole))
                      or contrast_text_color(background))
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        widget = opt.widget
        style = widget.style() if widget is not None else QApplication.style()
        for group in (QPalette.ColorGroup.Active, QPalette.ColorGroup.Inactive, QPalette.ColorGroup.Disabled):
            for role in (QPalette.ColorRole.Text, QPalette.ColorRole.WindowText,
                         QPalette.ColorRole.HighlightedText):
                opt.palette.setColor(group, role, foreground)
            for role in (QPalette.ColorRole.Base, QPalette.ColorRole.AlternateBase,
                         QPalette.ColorRole.Window, QPalette.ColorRole.Highlight):
                opt.palette.setColor(group, role, background)
        painter.save()
        painter.setClipRect(opt.rect)
        painter.fillRect(opt.rect, background)
        if opt.features & QStyleOptionViewItem.ViewItemFeature.HasCheckIndicator:
            # This rect already comes from the item-view layout used by
            # QStyledItemDelegate.editorEvent. CE_CheckBox also paints a
            # standalone widget's margins/background (notably in qdarktheme),
            # leaving an offset panel inside the colored legend row.
            check = QStyleOptionViewItem(opt)
            check.rect = style.subElementRect(QStyle.SubElement.SE_ItemViewItemCheckIndicator, opt, widget)
            check.state &= ~(QStyle.StateFlag.State_HasFocus | QStyle.StateFlag.State_On
                             | QStyle.StateFlag.State_Off | QStyle.StateFlag.State_NoChange)
            check.state |= {
                Qt.CheckState.Checked: QStyle.StateFlag.State_On,
                Qt.CheckState.PartiallyChecked: QStyle.StateFlag.State_NoChange,
            }.get(opt.checkState, QStyle.StateFlag.State_Off)
            style.drawPrimitive(QStyle.PrimitiveElement.PE_IndicatorItemViewItemCheck,
                                check, painter, widget)
        if not opt.icon.isNull():
            icon_rect = style.subElementRect(QStyle.SubElement.SE_ItemViewItemDecoration, opt, widget)
            mode = QIcon.Mode.Normal if opt.state & QStyle.StateFlag.State_Enabled else QIcon.Mode.Disabled
            opt.icon.paint(painter, icon_rect, opt.decorationAlignment, mode)
        text_rect = style.subElementRect(QStyle.SubElement.SE_ItemViewItemText, opt, widget)
        painter.setFont(opt.font)
        painter.setPen(foreground)
        text = opt.fontMetrics.elidedText(opt.text, opt.textElideMode, text_rect.width())
        painter.drawText(text_rect, opt.displayAlignment, text)
        if opt.state & (QStyle.StateFlag.State_Selected | QStyle.StateFlag.State_HasFocus):
            width = max(1, style.pixelMetric(QStyle.PixelMetric.PM_DefaultFrameWidth, opt, widget))
            pen = QPen(foreground, width)
            if opt.state & QStyle.StateFlag.State_HasFocus:
                pen.setStyle(Qt.PenStyle.DotLine)
            painter.setPen(pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            inset = width / 2
            painter.drawRect(opt.rect.toRectF().adjusted(inset, inset, -inset, -inset))
        painter.restore()
