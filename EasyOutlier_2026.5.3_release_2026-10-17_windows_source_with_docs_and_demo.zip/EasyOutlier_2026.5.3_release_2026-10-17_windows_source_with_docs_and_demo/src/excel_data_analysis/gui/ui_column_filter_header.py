# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'column_filter_header.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHeaderView, QSizePolicy, QWidget)

class Ui_ColumnFilterHeader(object):
    def setupUi(self, ColumnFilterHeader):
        if not ColumnFilterHeader.objectName():
            ColumnFilterHeader.setObjectName(u"ColumnFilterHeader")
        ColumnFilterHeader.setMouseTracking(True)
        ColumnFilterHeader.setSectionsClickable(True)
        ColumnFilterHeader.setSortIndicatorShown(True)
        ColumnFilterHeader.setMinimumSectionSize(52)
        ColumnFilterHeader.setProperty(u"filterButtonWidth", 22)
        ColumnFilterHeader.setProperty(u"filterButtonMargin", 3)
        ColumnFilterHeader.setProperty(u"activeFilterIconSize", 14)
        ColumnFilterHeader.setProperty(u"activeFilterIconSvg", u"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n"
"<!-- Lucide funnel: https://lucide.dev/icons/funnel\n"
"ISC License\n"
"Copyright (c) 2026 Lucide Icons and Contributors\n"
"Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.\n"
"THE SOFTWARE IS PROVIDED \"AS IS\" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFT"
                        "WARE.\n"
"-->\n"
"<path d=\"M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z\" />\n"
"</svg>")

        self.retranslateUi(ColumnFilterHeader)

        QMetaObject.connectSlotsByName(ColumnFilterHeader)
    # setupUi

    def retranslateUi(self, ColumnFilterHeader):
        ColumnFilterHeader.setProperty(u"filterToolTip", QCoreApplication.translate("ColumnFilterHeader", u"Filter {column}", None))
        ColumnFilterHeader.setProperty(u"activeFilterToolTip", QCoreApplication.translate("ColumnFilterHeader", u"Filter {column} (active)", None))
    # retranslateUi

