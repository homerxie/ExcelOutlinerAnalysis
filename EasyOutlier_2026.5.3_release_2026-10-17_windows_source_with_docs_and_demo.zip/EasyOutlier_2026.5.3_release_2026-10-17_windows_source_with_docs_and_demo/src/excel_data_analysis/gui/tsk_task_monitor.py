"""Bind structured TSK task events to the monitor defined by the analysis form."""
from __future__ import annotations

from datetime import datetime
import math
from time import monotonic

from PySide6.QtCore import QObject, QTimer, Qt
from PySide6.QtGui import QTextCursor
from PySide6.QtWidgets import QTreeWidgetItem


_TERMINAL = {"completed", "skipped", "failed", "cancelled", "unknown"}


def _number(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)


class TskTaskMonitor(QObject):
    """The desktop clock updates elapsed/age only, never work counters."""

    def __init__(self, ui, parent=None, *, clock=None):
        super().__init__(parent)
        self.ui, self._clock = ui, clock or monotonic
        self.groups = {}
        self.active = False
        self.started = self.finished = None
        self.title = self._text("defaultTitle")
        self.final_state = None
        self.timer = QTimer(self)
        self.timer.setInterval(int(ui.taskMonitorWidget.property("timerIntervalMilliseconds")))
        self.timer.timeout.connect(self.refresh_times)
        ui.taskMonitorToggleButton.toggled.connect(self._toggle)
        ui.taskMonitorTreeWidget.currentItemChanged.connect(lambda *_: self._render_selected_detail())

    def _text(self, name):
        return str(self.ui.taskMonitorWidget.property(name) or "")

    def _toggle(self, expanded):
        self.ui.taskMonitorBody.setVisible(expanded)
        self.ui.taskMonitorToggleButton.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)

    def begin(self, title=None):
        self.timer.stop()
        self.groups.clear()
        self.ui.taskMonitorTreeWidget.clear()
        self.ui.taskMonitorLogEdit.clear()
        self.ui.taskMonitorDetailEdit.clear()
        self.active, self.started, self.finished = True, self._clock(), None
        self.final_state = None
        self.title = str(title or self._text("defaultTitle"))
        self.ui.taskMonitorToggleButton.setChecked(True)
        self._log(self.title, "running", "")
        self.refresh_times()
        self.timer.start()

    def _group(self, group_id, label=None):
        group_id = str(group_id)
        if group_id not in self.groups:
            item = QTreeWidgetItem(self.ui.taskMonitorTreeWidget)
            item.setData(0, Qt.UserRole, group_id)
            self.groups[group_id] = {"id": group_id, "label": str(label or group_id), "item": item,
                                     "tasks": {}, "started": None, "finished": None, "updated": None}
            item.setExpanded(len(self.groups) == 1)
        group = self.groups[group_id]
        if label:
            group["label"] = str(label)
        group["item"].setText(0, group["label"])
        group["item"].setToolTip(0, group["label"])
        return group

    def _task(self, group, task_id, label=None):
        task_id = str(task_id)
        if task_id not in group["tasks"]:
            item = QTreeWidgetItem(group["item"])
            item.setData(0, Qt.UserRole, task_id)
            group["tasks"][task_id] = {"id": task_id, "label": str(label or task_id), "item": item,
                "state": "queued", "progress": None, "completed": None, "total": None,
                "elapsed": 0., "updated": None, "message": "", "last_log": None,
                "last_log_message": None, "cancelled_before_start": False, "stopped_before_start": False,
                "attempt_id": None, "old_attempts": set()}
        task = group["tasks"][task_id]
        if label:
            task["label"] = str(label)
        task["item"].setText(0, task["label"])
        task["item"].setToolTip(0, task["label"])
        return task

    def update(self, event):
        if not isinstance(event, dict):
            return
        if not self.active:
            return  # Late queued signals must not revive a cancelled/finished run.
        if event.get("event") == "plan":
            for definition in event.get("groups", []):
                group = self._group(definition["id"], definition.get("label"))
                for task in definition.get("tasks", []):
                    self._task(group, task["id"], task.get("label"))
            self._log(self.title, "queued", self._text("planLogFormat").format(
                groups=len(self.groups), tasks=sum(len(group["tasks"]) for group in self.groups.values())))
        elif event.get("event") == "task":
            if "group_id" not in event or "task_id" not in event:
                return
            group = self._group(event["group_id"], event.get("group_label"))
            task = self._task(group, event["task_id"], event.get("task_label"))
            self._update_task(group, task, event)
        self.refresh_times()

    def _update_task(self, group, task, event):
        attempt = event.get("attempt_id")
        if attempt is not None and str(attempt) != task["attempt_id"]:
            attempt = str(attempt)
            if attempt in task["old_attempts"]:
                return
            if task["attempt_id"] is not None:
                task["old_attempts"].add(task["attempt_id"])
            # A new process/serial-fallback attempt is actual repeated work,
            # unlike an old in-flight event arriving after a final result.
            task.update(attempt_id=attempt, state="queued", progress=None, completed=None, total=None,
                        elapsed=0., updated=None, message="", last_log=None, last_log_message=None,
                        cancelled_before_start=False, stopped_before_start=False)
        state = event.get("state", task["state"])
        if state not in {"queued", "running", *_TERMINAL}:
            state = "unknown"
        if task["state"] in _TERMINAL and state in {"queued", "running"}:
            return  # A delayed in-flight detail cannot undo an authoritative result.
        now, old_state = self._clock(), task["state"]
        previous_elapsed = self._task_elapsed(task, now)
        task.update(state=state, updated=now, message=str(event.get("message", task["message"])))
        if _number(event.get("elapsed_seconds")):
            task["elapsed"] = max(0., float(event["elapsed_seconds"]))
        else:
            task["elapsed"] = previous_elapsed
        if "progress" in event:
            task["progress"] = max(0., min(100., event["progress"])) if _number(event["progress"]) else None
        for field in ("completed", "total"):
            if field in event:
                task[field] = max(0, int(event[field])) if _number(event[field]) else None
        group["updated"] = now
        if state != "queued":
            inferred_start = now - task["elapsed"]
            group["started"] = (inferred_start if group["started"] is None
                                else min(group["started"], inferred_start))
        group["finished"] = None
        changed = state != old_state
        interval = float(self.ui.taskMonitorWidget.property("logIntervalSeconds"))
        if changed or (task["message"] != task["last_log_message"] and
                       (task["last_log"] is None or now - task["last_log"] >= interval)):
            path = self._text("pathFormat").format(group=group["label"], task=task["label"])
            self._log(path, state, task["message"], task=task)
            task["last_log"], task["last_log_message"] = now, task["message"]

    def _duration(self, seconds):
        seconds = max(0, int(seconds))
        return self._text("durationFormat").format(hours=seconds // 3600, minutes=seconds // 60 % 60,
                                                  seconds=seconds % 60)

    def _state_text(self, state, task=None):
        if state == "cancelled" and task and task["cancelled_before_start"]:
            return self._text("notStartedStoppedText" if task["stopped_before_start"] else "notStartedCancelledText")
        return self._text(state + "Text") or self._text("unknownText")

    def _task_elapsed(self, task, now):
        extra = now - task["updated"] if self.active and task["state"] == "running" and task["updated"] is not None else 0.
        return task["elapsed"] + max(0., extra)

    def _render_task(self, task, now):
        unknown = self._text("unknownProgressText")
        if task["completed"] is not None and task["total"] is not None:
            count = self._text("countFormat").format(completed=task["completed"], total=task["total"])
        elif task["progress"] is not None:
            count = self._text("progressFormat").format(progress=task["progress"])
        else:
            count = unknown
        state = self._state_text(task["state"], task)
        elapsed = self._duration(self._task_elapsed(task, now)) if task["updated"] is not None else unknown
        age = self._duration(now - task["updated"]) if task["updated"] is not None else unknown
        task["detail"] = self._text("detailFormat").format(path=task["label"], state=state,
            elapsed=elapsed, age=age, message=task["message"])
        values = (state, count, elapsed)
        for column, value in enumerate(values, 1):
            task["item"].setText(column, value)
        for column in range(4):
            task["item"].setToolTip(column, task["detail"])

    def refresh_times(self):
        now = self.finished if self.finished is not None else self._clock()
        all_tasks = []
        for group in self.groups.values():
            tasks = list(group["tasks"].values())
            all_tasks.extend(tasks)
            for task in tasks:
                self._render_task(task, now)
            counts = {state: sum(task["state"] == state for task in tasks)
                      for state in ("queued", "running", *_TERMINAL)}
            if counts["running"]:
                state = "running"
            elif counts["failed"]:
                state = "failed"
            elif counts["unknown"]:
                state = "unknown"
            elif counts["cancelled"]:
                state = "cancelled"
            elif counts["queued"] or not tasks:
                state = "queued"
            elif counts["skipped"] == len(tasks):
                state = "skipped"
            else:
                state = "completed"
            if tasks and all(task["state"] in _TERMINAL for task in tasks) and group["finished"] is None:
                group["finished"] = group["updated"]
            elapsed = ((group["finished"] if group["finished"] is not None else now)
                       - (group["started"] if group["started"] is not None else now))
            unknown = self._text("unknownProgressText")
            values = (self._state_text(state), self._text("groupProgressFormat").format(
                completed=counts["completed"], total=len(tasks)),
                self._duration(elapsed) if group["started"] is not None else unknown)
            messages = [self._text("groupDetailFormat").format(**counts)]
            messages.extend(self._text("pathFormat").format(group=task["label"], task=task["message"])
                            for task in tasks if task["state"] == "running" and task["message"])
            group["detail"] = self._text("detailFormat").format(path=group["label"], state=values[0],
                elapsed=values[2], age=self._duration(now - group["updated"]) if group["updated"] is not None else unknown,
                message="\n".join(messages))
            for column, value in enumerate(values, 1):
                group["item"].setText(column, value)
            for column in range(4):
                group["item"].setToolTip(column, group["detail"])
        counts = {state: sum(task["state"] == state for task in all_tasks)
                  for state in ("queued", "running", *_TERMINAL)}
        elapsed = self._duration(now - self.started) if self.started is not None else self._duration(0)
        parameters = dict(title=self.title, total=len(all_tasks), elapsed=elapsed, **counts)
        if self.final_state == "completed" and counts["unknown"]:
            text = self._text("incompleteFormat").format(remaining=counts["unknown"], **parameters)
        elif self.final_state is not None:
            text = self._text("finishedFormat").format(state=self._state_text(self.final_state), **parameters)
        else:
            text = self._text("summaryFormat").format(**parameters)
        self.ui.taskMonitorSummaryLabel.setText(text)
        self._render_selected_detail()

    def _render_selected_detail(self):
        item = self.ui.taskMonitorTreeWidget.currentItem()
        if item is None:
            return
        parent = item.parent()
        if parent is None:
            record = self.groups.get(str(item.data(0, Qt.UserRole)))
            path = record["label"] if record else ""
        else:
            group = self.groups.get(str(parent.data(0, Qt.UserRole)))
            record = group["tasks"].get(str(item.data(0, Qt.UserRole))) if group else None
            path = group["label"] if group else ""
        if record is None:
            return
        text = record.get("detail", "")
        if parent is not None:
            text = self._text("pathFormat").format(group=path, task=text)
        edit = self.ui.taskMonitorDetailEdit
        if edit.toPlainText() != text:
            # Preserve reading position while the elapsed/age fields refresh.
            bar, cursor = edit.verticalScrollBar(), edit.textCursor()
            position, anchor, selected = bar.value(), cursor.anchor(), cursor.position()
            edit.setPlainText(text)
            end = len(text)
            cursor = edit.textCursor()
            cursor.setPosition(min(anchor, end))
            cursor.setPosition(min(selected, end), QTextCursor.MoveMode.KeepAnchor)
            edit.setTextCursor(cursor)
            bar.setValue(position)

    def _log(self, path, state, message, *, task=None):
        edit = self.ui.taskMonitorLogEdit
        bar = edit.verticalScrollBar()
        horizontal = edit.horizontalScrollBar()
        horizontal_position = horizontal.value()
        position, at_bottom = bar.value(), bar.value() >= bar.maximum()
        text = self._text("logFormat").format(time=datetime.now().strftime(self._text("timestampFormat")),
            path=path, state=self._state_text(state, task), message=message)
        edit.appendPlainText(text.replace("\r", " ").replace("\n", " · "))
        bar.setValue(bar.maximum() if at_bottom else position)
        horizontal.setValue(horizontal_position)

    def finish(self, state, message=""):
        if not self.active:
            return
        now = self._clock()
        for group in self.groups.values():
            for task in group["tasks"].values():
                if task["state"] in _TERMINAL:
                    continue
                elapsed = self._task_elapsed(task, now)
                before_start = task["state"] == "queued"
                if state in {"cancelled", "failed"}:
                    task["cancelled_before_start"] = before_start
                    task["stopped_before_start"] = before_start and state == "failed"
                    final = "cancelled" if before_start or state == "cancelled" else "failed"
                    reason = (self._text("cancelledBeforeStartText" if state == "cancelled" else "stoppedBeforeStartText")
                              if before_start else str(message))
                else:
                    final, reason = "unknown", self._text("missingTerminalText")
                self._update_task(group, task, {"state": final, "elapsed_seconds": elapsed, "message": reason})
        self.active, self.finished, self.final_state = False, now, state
        self.timer.stop()
        self._log(self.title, state, str(message))
        self.refresh_times()
