# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_label_layout_row.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QHBoxLayout, QLabel,
    QListView, QListWidgetItem, QSizePolicy, QToolButton,
    QWidget)

from excel_data_analysis.gui.tsk_label_tags import TskLabelTagList

class Ui_TskLabelLayoutRowForm(object):
    def setupUi(self, TskLabelLayoutRowForm):
        if not TskLabelLayoutRowForm.objectName():
            TskLabelLayoutRowForm.setObjectName(u"TskLabelLayoutRowForm")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(TskLabelLayoutRowForm.sizePolicy().hasHeightForWidth())
        TskLabelLayoutRowForm.setSizePolicy(sizePolicy)
        self.rowLayout = QHBoxLayout(TskLabelLayoutRowForm)
        self.rowLayout.setSpacing(4)
        self.rowLayout.setObjectName(u"rowLayout")
        self.rowLayout.setContentsMargins(0, 0, 0, 0)
        self.rowLabel = QLabel(TskLabelLayoutRowForm)
        self.rowLabel.setObjectName(u"rowLabel")
        self.rowLabel.setMinimumSize(QSize(48, 0))

        self.rowLayout.addWidget(self.rowLabel)

        self.tags = TskLabelTagList(TskLabelLayoutRowForm)
        self.tags.setObjectName(u"tags")
        sizePolicy.setHeightForWidth(self.tags.sizePolicy().hasHeightForWidth())
        self.tags.setSizePolicy(sizePolicy)
        self.tags.setMinimumSize(QSize(100, 48))
        self.tags.setMaximumSize(QSize(16777215, 48))
        self.tags.setFlow(QListView.Flow.LeftToRight)
        self.tags.setProperty(u"isWrapping", False)
        self.tags.setResizeMode(QListView.ResizeMode.Adjust)
        self.tags.setSpacing(4)
        self.tags.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.tags.setDragEnabled(True)
        self.tags.setAcceptDrops(True)
        self.tags.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
        self.tags.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.tags.setDragDropOverwriteMode(False)
        self.tags.setProperty(u"showDropIndicator", False)
        self.tags.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tags.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)

        self.rowLayout.addWidget(self.tags)

        self.upButton = QToolButton(TskLabelLayoutRowForm)
        self.upButton.setObjectName(u"upButton")

        self.rowLayout.addWidget(self.upButton)

        self.downButton = QToolButton(TskLabelLayoutRowForm)
        self.downButton.setObjectName(u"downButton")

        self.rowLayout.addWidget(self.downButton)

        self.removeButton = QToolButton(TskLabelLayoutRowForm)
        self.removeButton.setObjectName(u"removeButton")

        self.rowLayout.addWidget(self.removeButton)


        self.retranslateUi(TskLabelLayoutRowForm)

        QMetaObject.connectSlotsByName(TskLabelLayoutRowForm)
    # setupUi

    def retranslateUi(self, TskLabelLayoutRowForm):
        TskLabelLayoutRowForm.setProperty(u"rowFormat", QCoreApplication.translate("TskLabelLayoutRowForm", u"\u7b2c {number} \u884c", None))
        self.rowLabel.setText(QCoreApplication.translate("TskLabelLayoutRowForm", u"\u7b2c 1 \u884c", None))
        self.tags.setStyleSheet(QCoreApplication.translate("TskLabelLayoutRowForm", u"QListWidget { border: 1px solid palette(mid); border-radius: 6px; background: palette(base); }\n"
"QListWidget::item { padding: 6px 9px; border: 1px solid palette(mid); border-radius: 10px; background: palette(button); color: palette(button-text); }\n"
"QListWidget::item:selected { background: palette(highlight); color: palette(highlighted-text); border-color: palette(highlight); }", None))
        self.tags.setProperty(u"emptyText", QCoreApplication.translate("TskLabelLayoutRowForm", u"\u62d6\u5165\u5b57\u6bb5 \u00b7 \u7a7a\u884c\u4e0d\u5360\u56fe\u4e2d\u6587\u5b57", None))
        self.upButton.setText(QCoreApplication.translate("TskLabelLayoutRowForm", u"\u2191", None))
#if QT_CONFIG(tooltip)
        self.upButton.setToolTip(QCoreApplication.translate("TskLabelLayoutRowForm", u"\u6574\u884c\u4e0a\u79fb", None))
#endif // QT_CONFIG(tooltip)
        self.downButton.setText(QCoreApplication.translate("TskLabelLayoutRowForm", u"\u2193", None))
#if QT_CONFIG(tooltip)
        self.downButton.setToolTip(QCoreApplication.translate("TskLabelLayoutRowForm", u"\u6574\u884c\u4e0b\u79fb", None))
#endif // QT_CONFIG(tooltip)
        self.removeButton.setText(QCoreApplication.translate("TskLabelLayoutRowForm", u"\u00d7", None))
#if QT_CONFIG(tooltip)
        self.removeButton.setToolTip(QCoreApplication.translate("TskLabelLayoutRowForm", u"\u79fb\u9664\u6b64\u884c\uff0c\u5c06\u5b57\u6bb5\u653e\u5165\u201c\u4e0d\u663e\u793a\u201d", None))
#endif // QT_CONFIG(tooltip)
    # retranslateUi

