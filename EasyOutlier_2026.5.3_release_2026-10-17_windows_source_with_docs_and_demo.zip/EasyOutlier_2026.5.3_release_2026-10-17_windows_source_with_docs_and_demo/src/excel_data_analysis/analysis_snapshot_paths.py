"""Portable provenance for self-contained Analyze and TSK snapshots.

These strings describe where the frozen inputs came from. Restoring a snapshot
never opens them: all measurements, rules and fitted values are already saved.
Keeping their database-relative spelling also keeps a regenerated TSK input
byte-for-byte stable after moving its database.
"""
from __future__ import annotations

from pathlib import Path, PurePosixPath

from .database_paths import WORKSPACE_MARKER_FILENAME, database_root_for_storage, relative_internal_path


def portable_source_path(value: str, database_root: str | Path | None) -> str:
    if database_root is None or not value:
        return value
    storage = Path(database_root).absolute()
    root = database_root_for_storage(storage)
    # A live temp workspace represents the database being saved. Its internal
    # provenance must not retain the disposable "temp/" prefix.
    workspace = storage if storage != root else root / "temp"
    if (workspace / WORKSPACE_MARKER_FILENAME).is_file():
        relative = relative_internal_path(value, workspace)
        if relative != value:
            return relative
        # Autosave can receive the already-relative provenance of a previous
        # result. Only the explicit workspace marker makes this prefix special;
        # a normal user folder named "temp" remains part of its relative path.
        saved = PurePosixPath(value.replace("\\", "/"))
        if saved.parts[:1] == ("temp",):
            return PurePosixPath(*saved.parts[1:]).as_posix()
    return relative_internal_path(value, root)


def portable_analysis_result(result: dict, database_root: str | Path | None) -> dict:
    if database_root is None:
        return result
    saved = dict(result)
    for name in ("input", "output"):
        if isinstance(saved.get(name), str):
            saved[name] = portable_source_path(saved[name], database_root)
    return saved


def portable_tsk_provenance(provenance: dict, database_root: str | Path | None) -> dict:
    if database_root is None:
        return provenance
    saved = dict(provenance)
    for name in ("template_path", "input_path", "storage_path", "golden_path"):
        if isinstance(saved.get(name), str):
            saved[name] = portable_source_path(saved[name], database_root)
    if isinstance(saved.get("analysis_result"), dict):
        saved["analysis_result"] = portable_analysis_result(saved["analysis_result"], database_root)
    return saved


def prepare_result_provenance_updates(results: dict, database_root: str | Path) -> list[tuple[dict, dict]]:
    """Prepare small live-result updates before a successful save removes temp/.

    A save worker receives references to the displayed results and frozen fits;
    it must not mutate them or duplicate their large arrays. This preparation
    returns only target objects and replacement metadata. The GUI applies them
    after the save succeeds, preserving references held by history and panels.
    Nothing in this ephemeral update list belongs in the persisted GUI JSON.
    """
    if not isinstance(results, dict):
        return []
    updates = []
    pending = [results.get(name) for name in ("tsk_result", "tsk_live_result")]
    history = results.get("tsk_history")
    if isinstance(history, dict) and isinstance(history.get("entries"), list):
        pending.extend(entry.get("result") for entry in history["entries"] if isinstance(entry, dict))
    seen = set()
    while pending:
        result = pending.pop()
        if not isinstance(result, dict) or id(result) in seen:
            continue
        seen.add(id(result))
        provenance = result.get("provenance")
        if isinstance(provenance, dict):
            saved = portable_tsk_provenance(provenance, database_root)
            if saved != provenance:
                updates.append((result, {"provenance": saved}))
        variants = result.get("saved_analyses")
        if isinstance(variants, list):
            pending.extend(entry.get("result") for entry in variants if isinstance(entry, dict))
    coverage = results.get("golden_coverage_summary")
    if isinstance(coverage, dict):
        changes = {}
        for name in ("input", "storage", "golden"):
            value = coverage.get(name)
            if isinstance(value, str):
                saved = portable_source_path(value, database_root)
                if saved != value:
                    changes[name] = saved
        if changes:
            updates.append((coverage, changes))
    return updates


def apply_result_provenance_updates(updates: list[tuple[dict, dict]]) -> None:
    """Commit prepared metadata on the GUI thread only after its save succeeds."""
    for target, changes in updates:
        target.update(changes)
