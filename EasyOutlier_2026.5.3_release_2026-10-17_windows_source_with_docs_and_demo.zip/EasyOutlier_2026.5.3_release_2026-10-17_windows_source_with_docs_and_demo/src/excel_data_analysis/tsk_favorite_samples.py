"""Failed sample intersections for bookmarked chains in one observation group."""
from __future__ import annotations

from dataclasses import dataclass
import math
from numbers import Real
from typing import Iterable

from .tsk_result_state import failed_sample_outcomes
from .tsk_sorting import natural_sort_key


SampleIdentity = tuple[str | None, tuple[str, ...]]


@dataclass(frozen=True)
class FailureSample:
    identity: SampleIdentity
    sample_id: str
    source_batch: str | None
    failed_chains: tuple[str, ...]


@dataclass(frozen=True)
class FavoriteFailureSamples:
    chains: tuple[str, ...]
    samples: tuple[FailureSample, ...]
    details_available: bool
    incomplete_chains: tuple[str, ...]


def _name_key(value: str) -> tuple:
    return natural_sort_key(value), value


def _sample_identity(row: dict) -> SampleIdentity | None:
    raw_key = row.get("sample_key")
    if not isinstance(raw_key, (list, tuple)) or not raw_key:
        return None
    if any(value is None or isinstance(value, (dict, list, tuple, set)) for value in raw_key):
        return None
    sample_key = tuple(str(value) for value in raw_key)
    if not all(value.strip() for value in sample_key):
        return None
    source_batch = row.get("source_batch")
    return (str(source_batch) if source_batch is not None else None), sample_key


def build_favorite_failure_samples(group: dict | None, favorites: Iterable[str]) -> FavoriteFailureSamples:
    """Read only this group's Fail outcomes, preserving full sample and batch keys.

    The matrix contains all bookmarked chains and only samples failing at least
    one of them. Each sample still carries every failed chain from this group,
    so the second table can show failures beyond the current bookmarks.
    Counts describe missing or inconsistent details without fabricating samples.
    """
    chains = tuple(sorted({chain for chain in favorites if isinstance(chain, str) and chain}, key=_name_key))
    group = group if isinstance(group, dict) else {}
    rows = failed_sample_outcomes(group)
    failures: dict[SampleIdentity, set[str]] = {}
    chain_samples: dict[str, set[SampleIdentity]] = {}
    for row in rows or ():
        chain = row.get("chain_id")
        identity = _sample_identity(row)
        if not isinstance(chain, str) or not chain or identity is None:
            continue
        failures.setdefault(identity, set()).add(chain)
        chain_samples.setdefault(chain, set()).add(identity)

    favorites_set = set(chains)
    identities = sorted((identity for identity, failed in failures.items() if favorites_set.intersection(failed)),
                        key=lambda identity: (tuple(_name_key(value) for value in identity[1]),
                                              _name_key(identity[0] or "")))
    samples = tuple(FailureSample(identity=identity, sample_id=" | ".join(identity[1]),
                                 source_batch=identity[0],
                                 failed_chains=tuple(sorted(failures[identity], key=_name_key)))
                    for identity in identities)

    incomplete = set()
    counts = group.get("chains", group.get("counts", ()))
    for row in counts if isinstance(counts, (list, tuple)) else ():
        if not isinstance(row, dict):
            continue
        chain, expected = row.get("chain_id"), row.get("n_failed")
        if (isinstance(chain, str) and chain and isinstance(expected, Real) and not isinstance(expected, bool)
                and math.isfinite(expected) and expected >= 0 and int(expected) == expected
                and expected != len(chain_samples.get(chain, ()))):
            incomplete.add(chain)

    return FavoriteFailureSamples(chains, samples, rows is not None, tuple(sorted(incomplete, key=_name_key)))
