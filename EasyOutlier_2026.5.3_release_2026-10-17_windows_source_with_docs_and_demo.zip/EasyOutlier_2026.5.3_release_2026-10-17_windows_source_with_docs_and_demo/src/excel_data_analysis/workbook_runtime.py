"""Keep openpyxl's private worksheet spools with the owning database.

The allocator is installed once, while a ContextVar selects each job's private
directory. Concurrent exports never change tempfile's process-wide defaults.
User-selected export destinations and their atomic replacement files remain
owned by the explicit output operation.
"""
from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from functools import wraps
from pathlib import Path
from tempfile import NamedTemporaryFile

from openpyxl.worksheet import _writer

from .database_paths import database_root_for_storage
from .database_runtime import temporary_database_directory


@dataclass
class _WorkbookRuntime:
    root: Path
    directory: Path
    files: list[str] = field(default_factory=list)


_current_runtime: ContextVar[_WorkbookRuntime | None] = ContextVar("database_workbook_runtime", default=None)
_original_create_temporary_file = _writer.create_temporary_file


def current_database_workbook_root() -> Path | None:
    """Return the explicit owner to pass across a process boundary."""
    current = _current_runtime.get()
    return current.root if current is not None else None


def create_workbook_temporary_file(suffix: str = "") -> str:
    """Allocate a worksheet spool using the calling job's database context."""
    current = _current_runtime.get()
    if current is None:
        # Library callers without a database retain openpyxl's normal contract.
        return _original_create_temporary_file(suffix)
    with NamedTemporaryFile(mode="w+", suffix=suffix, prefix="openpyxl.",
                            dir=current.directory, delete=False) as handle:
        filename = handle.name
    _writer.ALL_TEMP_FILES.append(filename)
    current.files.append(filename)
    return filename


# Python serializes module initialization. The wrapper is never swapped on
# context entry/exit, so another thread cannot restore an obsolete allocator.
_writer.create_temporary_file = create_workbook_temporary_file


@contextmanager
def database_workbook_runtime(database_root: str | Path):
    """Contain one job's normal, staged and failed workbook spools in the DB."""
    root = database_root_for_storage(database_root).resolve()
    with temporary_database_directory(root, prefix="workbook-") as directory:
        current = _WorkbookRuntime(root, Path(directory))
        token = _current_runtime.set(current)
        try:
            yield current.directory
        finally:
            _current_runtime.reset(token)
            # Successful WorksheetWriter.cleanup already removes its entries.
            # Failed writes leave spools behind; TemporaryDirectory owns those.
            for filename in current.files:
                if filename in _writer.ALL_TEMP_FILES:
                    _writer.ALL_TEMP_FILES.remove(filename)


def database_workbook_process(function):
    """Consume explicit GUI process metadata without exposing it to analysis."""
    @wraps(function)
    def run(payload, *args, **kwargs):
        request = dict(payload)
        owner = request.pop("_database_root", None)
        if owner is None:
            return function(request, *args, **kwargs)
        with database_workbook_runtime(owner):
            return function(request, *args, **kwargs)

    return run
