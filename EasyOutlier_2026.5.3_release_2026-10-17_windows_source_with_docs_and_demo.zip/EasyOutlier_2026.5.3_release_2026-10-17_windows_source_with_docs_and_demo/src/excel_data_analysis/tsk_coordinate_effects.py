"""Read-only XY effect surfaces from the coefficients of an existing TSK fit.

The surface is a change in the shared Logistic linear predictor relative to
the saved reference coordinate. It excludes type intercepts and other
features, and is neither an instance probability nor a causal effect.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from numbers import Real
from typing import Any, Mapping

import numpy as np

from .tsk_feature_summary import summarize_tsk_features
from .tsk_spatial import DEFAULT_XY_MODEL, SPATIAL_TERMS, spatial_values, validate_spatial_transform


@dataclass(frozen=True)
class CoordinateEffectSurface:
    """Small immutable surface; no likelihood matrices or source files retained."""

    model: str
    reference: tuple[float, float]
    coordinate_scales: tuple[float, float]
    powers: tuple[tuple[int, int], ...]
    coefficients: tuple[float, ...]
    centers: tuple[float, ...]
    scales: tuple[float, ...]

    def evaluate(self, x: Any, y: Any) -> np.ndarray:
        """Evaluate broadcast coordinates without expanding sparse axis inputs."""
        x_values, y_values = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
        shape = np.broadcast_shapes(x_values.shape, y_values.shape)
        if not np.all(np.isfinite(x_values)) or not np.all(np.isfinite(y_values)):
            raise ValueError("The XY effect surface requires finite coordinates.")
        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            u, v = x_values / self.coordinate_scales[0], y_values / self.coordinate_scales[1]
            result = np.zeros(shape, dtype=float)
            for powers, coefficient, center, scale in zip(
                    self.powers, self.coefficients, self.centers, self.scales):
                # Coordinate grids arrive as 1×W and H×1 arrays. Pure-axis
                # terms stay sparse; only the mixed term needs the full grid.
                # Powers create owned arrays, so arithmetic can reuse their
                # storage without modifying the caller's coordinates.
                if powers[1] == 0:
                    term = u ** powers[0]
                elif powers[0] == 0:
                    term = v ** powers[1]
                else:
                    term = u ** powers[0] * v ** powers[1]
                term -= center
                term /= scale
                term *= coefficient
                result += term
        if not np.all(np.isfinite(result)):
            raise ValueError("Coordinates exceed the finite range of the XY effect surface.")
        return result


def _number(value: Any) -> float:
    if not isinstance(value, Real) or isinstance(value, bool) or not math.isfinite(value):
        raise ValueError("Expected a finite numeric fit value.")
    return float(value)


def coordinate_effect_surface(group: Mapping[str, Any] | None) -> tuple[CoordinateEffectSurface | None, str]:
    """Extract the original fit's complete, identifiable XY contribution.

    Saved display diagnostics already contain validated coefficients and their
    individual identifiability decisions. Reusing those decisions keeps saved
    analyses usable without loading large design matrices or rerunning a fit.
    A conditional refit from the feature-effects report is never substituted.
    """
    if not isinstance(group, Mapping):
        return None, "no_xy_fit"
    try:
        return _coordinate_effect_surface(group)
    except (KeyError, TypeError, ValueError, AttributeError, OverflowError):
        return None, "invalid_fit_data"


def _coordinate_effect_surface(group):
    diagnostics = group.get("diagnostics") or {}
    context = group.get("prediction_context") or {}
    model = diagnostics.get("model", context.get("model"))
    if model is None or model == "type_only":
        return None, "no_xy_fit"
    if (model != "instance_logistic_features" or context.get("model", model) != model
            or group.get("options", {}).get("feature_model") not in (None, "logistic")):
        return None, "unsupported_model"

    transform = diagnostics.get("spatial_transform") or context.get("spatial_transform")
    xy_model = diagnostics.get("xy_model", context.get("xy_model"))
    if xy_model not in (None, "linear", DEFAULT_XY_MODEL):
        return None, "unsupported_model"
    if (xy_model == DEFAULT_XY_MODEL and not transform) or (xy_model == "linear" and transform):
        return None, "invalid_fit_data"
    if transform:
        validate_spatial_transform(transform)
        reference = tuple(_number(transform["reference"][axis]) for axis in ("x", "y"))
        axis_scales = tuple(_number(transform["coordinate_scales"][axis]) for axis in ("x", "y"))
        names = tuple(term[0] for term in SPATIAL_TERMS)
        powers = tuple(term[1] for term in SPATIAL_TERMS)
        expected_centers = spatial_values(transform, *reference)
    else:
        names, powers, axis_scales = ("x", "y"), ((1, 0), (0, 1)), (1., 1.)
        reference, expected_centers = None, None
    scaling = diagnostics.get("feature_scaling") or {}
    coefficients = diagnostics.get("feature_coefficients") or {}
    if not any(name in scaling or name in coefficients for name in names):
        return None, "no_xy_fit"

    # Invalidated or partial fits must not publish the optimizer's representative.
    effects = group.get("feature_effects") or {}
    if effects.get("status") in {
            "full_fit_not_optimal", "fit_not_converged", "nonfinite_mle", "finite_mle_check_failed"}:
        return None, "fit_not_converged"
    if (diagnostics.get("converged", context.get("converged")) is not True
            or context.get("converged", True) is not True):
        return None, "fit_not_converged"
    for owner in (diagnostics, context):
        boundary = owner.get("boundary_fit")
        joint = owner.get("joint_boundary_fit")
        if boundary and joint:
            return None, "boundary_invalid"
        if boundary and (boundary.get("version") != 1 or boundary.get("converged") is not True
                         or boundary.get("feature_clipped") is not False):
            return None, "boundary_invalid"
        if joint and (joint.get("version") != 1 or joint.get("converged") is not True):
            return None, "boundary_invalid"

    # Do not materialize saved risk tables just to obtain a few numeric terms.
    summary = summarize_tsk_features({key: group[key] for key in (
        "diagnostics", "prediction_context", "options", "feature_effects") if key in group})
    terms = {row.get("basis_term") if transform else row.get("feature"): row
             for row in summary["coefficients"]
             if row["kind"] == ("spatial" if transform else "numeric")}
    if any(name not in terms for name in names):
        return None, "invalid_fit_data"
    rows = [terms[name] for name in names]
    statuses = {row["status"] for row in rows}
    if "boundary_unbounded" in statuses:
        return None, "boundary_invalid"
    if "fit_not_converged" in statuses:
        return None, "fit_not_converged"
    if "not_identifiable" in statuses:
        return None, "not_identifiable"
    if statuses != {"ok"}:
        return None, "invalid_fit_data"
    values = tuple(_number(row["coefficient"]) for row in rows)
    centers = tuple(_number(row["mean"]) for row in rows)
    scales = tuple(_number(row["scale"]) for row in rows)
    if any(scale <= 0 for scale in scales):
        return None, "invalid_fit_data"
    if expected_centers is not None and any(
            not math.isclose(center, expected_centers[name], rel_tol=1e-9, abs_tol=1e-12)
            for name, center in zip(names, centers)):
        return None, "invalid_fit_data"
    # Reference centering is exact here even after a harmless serialization
    # rounding difference in the saved basis centers.
    if expected_centers is not None:
        centers = tuple(expected_centers[name] for name in names)
    return CoordinateEffectSurface(
        model=DEFAULT_XY_MODEL if transform else "linear", reference=reference or centers,
        coordinate_scales=axis_scales, powers=powers, coefficients=values,
        centers=centers, scales=scales), "ok"
