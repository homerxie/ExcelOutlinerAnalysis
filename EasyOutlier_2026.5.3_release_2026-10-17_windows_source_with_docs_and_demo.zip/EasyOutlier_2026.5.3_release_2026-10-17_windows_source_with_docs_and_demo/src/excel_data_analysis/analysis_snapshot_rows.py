"""Stream row values while sharing source paths and ordered column schemas."""
from __future__ import annotations


_TABLES = ("sources", "dimensions", "values", "missing")


def _string_tuple(value, *, unique=False):
    if (not isinstance(value, (list, tuple)) or any(not isinstance(item, str) for item in value)
            or (unique and len(set(value)) != len(value))):
        raise ValueError("Invalid saved Analyze row schema")
    return tuple(value)


def write_rows(rows, output, *, database_root=None):
    from .analysis_snapshot_paths import portable_source_path
    from .analysis_snapshot_state import _encode
    from .analysis_snapshot_stream import ITEM_CHUNK, _line
    from .reporting import RowData

    _line(output, {"kind": "rows", "length": len(rows)})
    indexes = {name: {} for name in _TABLES}
    sources = {}
    for start in range(0, len(rows), ITEM_CHUNK):
        definitions = {name: [] for name in _TABLES}
        records = []

        def intern(name, value):
            index = indexes[name]
            if value not in index:
                index[value] = len(index)
                definitions[name].append(value)
            return index[value]

        for row in rows[start:start + ITEM_CHUNK]:
            if (not isinstance(row, RowData) or not isinstance(row.dataset_id, str)
                    or not isinstance(row.source_file, str) or type(row.row_number) is not int
                    or not isinstance(row.dimensions, dict) or not isinstance(row.values, dict)
                    or not isinstance(row.missing_columns, tuple)):
                raise ValueError("Invalid saved Analyze row")
            dimension_keys = _string_tuple(tuple(row.dimensions), unique=True)
            value_keys = _string_tuple(tuple(row.values), unique=True)
            missing = _string_tuple(row.missing_columns)
            if row.source_file not in sources:
                sources[row.source_file] = portable_source_path(row.source_file, database_root)
            records.append([
                intern("sources", (row.dataset_id, sources[row.source_file])), row.row_number,
                intern("dimensions", dimension_keys), [_encode(value) for value in row.dimensions.values()],
                intern("values", value_keys), [_encode(value) for value in row.values.values()],
                intern("missing", missing),
            ])
        _line(output, {"defs": definitions, "rows": records})


def read_rows(input, length):
    from .analysis_snapshot_state import _decode
    from .analysis_snapshot_stream import ITEM_CHUNK, _count, _read
    from .reporting import RowData

    remaining = _count(length)
    tables = {name: [] for name in _TABLES}
    result = []

    def reference(name, index):
        if type(index) is not int or not 0 <= index < len(tables[name]):
            raise ValueError("Invalid saved Analyze row reference")
        return tables[name][index]

    while remaining:
        chunk = _read(input)
        if not isinstance(chunk, dict) or set(chunk) != {"defs", "rows"}:
            raise ValueError("Invalid saved Analyze row chunk")
        records, definitions = chunk["rows"], chunk["defs"]
        if (not isinstance(records, list) or not 0 < len(records) <= min(ITEM_CHUNK, remaining)
                or not isinstance(definitions, dict) or set(definitions) != set(_TABLES)):
            raise ValueError("Invalid saved Analyze row chunk")
        for name in _TABLES:
            values = definitions[name]
            if not isinstance(values, list) or len(values) > len(records):
                raise ValueError("Invalid saved Analyze row definitions")
            for value in values:
                entry = _string_tuple(value, unique=name in ("dimensions", "values"))
                if name == "sources" and len(entry) != 2:
                    raise ValueError("Invalid saved Analyze row source")
                tables[name].append(entry)
        for record in records:
            if not isinstance(record, list) or len(record) != 7 or type(record[1]) is not int:
                raise ValueError("Invalid saved Analyze row record")
            source = reference("sources", record[0])
            dimensions = reference("dimensions", record[2])
            values = reference("values", record[4])
            missing = reference("missing", record[6])
            if (not isinstance(record[3], list) or len(record[3]) != len(dimensions)
                    or not isinstance(record[5], list) or len(record[5]) != len(values)):
                raise ValueError("Invalid saved Analyze row value count")
            result.append(RowData(
                dataset_id=source[0], source_file=source[1], row_number=record[1],
                dimensions={key: _decode(value) for key, value in zip(dimensions, record[3])},
                values={key: _decode(value) for key, value in zip(values, record[5])},
                missing_columns=missing,
            ))
        remaining -= len(records)
    return result
