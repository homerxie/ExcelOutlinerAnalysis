"""Conservative lifetime bounds for runtime directories made by older releases.

Older releases allocate private random directories without an OS lease. They
never reopen an existing private directory, so a directory older than every
possible owning process is abandoned. Idle windows need this lifetime check:
checking open file handles alone cannot establish that their files are unused.
"""
from __future__ import annotations

import ctypes
from dataclasses import dataclass
from datetime import datetime, timezone
import math
import json
import os
import re
import shlex
import subprocess
import sys
import time


@dataclass(frozen=True)
class _Process:
    pid: int
    started: float | None
    executable: str
    command: str | None = None


_ROUNDING_MARGIN = 2.0
_MONTHS = {name: index for index, name in enumerate(
    ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"), 1)}
_WEEKDAYS = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"}
# These identified standalone entrypoints do not run the analysis application
# in their interpreter. Unknown modules can be custom GUI launchers, so they
# must remain possible owners. No service is imported or added as a dependency.
_STANDALONE_SERVICE_MODULES = {"hermes_cli.main", "http.server"}


def _basename(executable: str) -> str:
    # Both path conventions matter when testing or inspecting packaged workers.
    name = executable.replace("\\", "/").rsplit("/", 1)[-1].casefold()
    return name.removesuffix(".exe")


def _python_executable(executable: str) -> bool:
    return _basename(executable).startswith(("python", "pypy"))


def _python_can_own_runtime(command: str | None, *, windows: bool = False) -> bool:
    if not command:
        return True
    normalized = command.casefold()
    if any(marker in normalized for marker in (
            "excel_data_analysis", "exceldataanalysis", "easyoutlier", "easy-outlier")):
        return True
    try:
        arguments = shlex.split(command, posix=not windows)
    except ValueError:
        return True
    if windows:
        arguments = [value[1:-1] if len(value) >= 2 and value[0] == value[-1] == '"'
                     else value for value in arguments]
    if not arguments or not _python_executable(arguments[0]):
        return True
    index = 1
    while index < len(arguments):
        argument = arguments[index]
        if argument == "-m":
            if index + 1 == len(arguments):
                return True
            module = arguments[index + 1]
            if not re.fullmatch(r"[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*", module):
                return True
            return module not in _STANDALONE_SERVICE_MODULES
        if argument == "-c":
            if index + 1 == len(arguments):
                return True
            return re.fullmatch(
                r"\s*from\s+multiprocessing\.resource_tracker\s+import\s+main\s*;"
                r"\s*main\(\s*\d+\s*\)\s*;?\s*", " ".join(arguments[index + 1:])) is None
        if argument in ("-W", "-X", "--check-hash-based-pycs"):
            if index + 1 == len(arguments):
                return True
            index += 2
            continue
        if re.fullmatch(r"-[bBdEiIOPqRsSuv]+", argument):
            if "i" in argument:
                return True
            index += 1
            continue
        if argument.startswith(("-W", "-X", "--check-hash-based-pycs=")):
            index += 1
            continue
        # Scripts, stdin, interactive shells and unfamiliar flags can execute
        # an application launcher; absence of its name is insufficient proof.
        return True
    return True


def _possible_owner(executable: str, command: str | None = None, *, windows: bool = False) -> bool:
    name = _basename(executable)
    branded = re.sub(r"[-_ .]", "", name)
    if "easyoutlier" in branded or "exceldataanalysis" in branded:
        return True
    if getattr(sys, "frozen", False) and name == _basename(sys.executable):
        return True
    if _python_executable(executable):
        return _python_can_own_runtime(command, windows=windows)
    return bool(name) and name == _basename(sys.executable)


def _parse_posix_processes(output: str) -> list[_Process]:
    processes = []
    for line in output.splitlines():
        if not line.strip():
            continue
        # lstart contains five columns; comm may itself contain spaces.
        fields = line.split(None, 6)
        if len(fields) != 7 or fields[1] not in _WEEKDAYS or fields[2] not in _MONTHS:
            raise ValueError("Ambiguous process inventory")
        pid = int(fields[0])
        hour, minute, second = map(int, fields[4].split(":"))
        started = datetime(int(fields[5]), _MONTHS[fields[2]], int(fields[3]),
                           hour, minute, second, tzinfo=timezone.utc).timestamp()
        if pid < 0 or not fields[6]:
            raise ValueError("Invalid process identity")
        processes.append(_Process(pid, started, fields[6]))
    return processes


def _posix_commands() -> dict[int, str]:
    try:
        result = subprocess.run(
            ["/bin/ps", "-ww", "-axo", "pid=,args="], check=True, capture_output=True,
            text=True, encoding="utf-8", errors="strict", timeout=3,
            env=dict(os.environ, LC_ALL="C", TZ="UTC"),
        )
        commands = {}
        for line in result.stdout.splitlines():
            if not line.strip():
                continue
            fields = line.split(None, 1)
            if len(fields) != 2:
                return {}
            pid = int(fields[0])
            if pid < 0 or pid in commands:
                return {}
            commands[pid] = fields[1]
        return commands
    except (OSError, ValueError, subprocess.SubprocessError):
        return {}


def _posix_processes() -> list[_Process]:
    environment = dict(os.environ, LC_ALL="C", TZ="UTC")
    result = subprocess.run(
        ["/bin/ps", "-ww", "-axo", "pid=,lstart=,comm="],
        check=True, capture_output=True, text=True, encoding="utf-8",
        errors="strict", timeout=3, env=environment,
    )
    records = _parse_posix_processes(result.stdout)
    commands = _posix_commands() if any(_python_executable(record.executable) for record in records) else {}
    return [_Process(record.pid, record.started, record.executable, commands.get(record.pid))
            for record in records]


def _windows_kernel():
    from ctypes import wintypes

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    kernel.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    kernel.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.c_void_p]
    kernel.Process32FirstW.restype = wintypes.BOOL
    kernel.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.c_void_p]
    kernel.Process32NextW.restype = wintypes.BOOL
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(wintypes.FILETIME)] * 4)]
    kernel.GetProcessTimes.restype = wintypes.BOOL
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.CloseHandle.restype = wintypes.BOOL
    return kernel


def _windows_process_records(kernel) -> list[tuple[int, str]]:
    from ctypes import wintypes

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD), ("th32DefaultHeapID", ctypes.c_size_t),
            ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", wintypes.LONG),
            ("dwFlags", wintypes.DWORD), ("szExeFile", wintypes.WCHAR * 260),
        ]

    handle = kernel.CreateToolhelp32Snapshot(0x00000002, 0)  # TH32CS_SNAPPROCESS
    if handle in (None, ctypes.c_void_p(-1).value):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        entry = PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(entry)
        available = kernel.Process32FirstW(handle, ctypes.byref(entry))
        records = []
        while available:
            records.append((int(entry.th32ProcessID), str(entry.szExeFile)))
            available = kernel.Process32NextW(handle, ctypes.byref(entry))
        error = ctypes.get_last_error()
        if error != 18:  # ERROR_NO_MORE_FILES
            raise ctypes.WinError(error)
        return records
    finally:
        kernel.CloseHandle(handle)


def _windows_process_started(kernel, pid: int) -> float:
    from ctypes import wintypes

    handle = kernel.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        created, exited, system, user = (wintypes.FILETIME() for _ in range(4))
        if not kernel.GetProcessTimes(handle, ctypes.byref(created), ctypes.byref(exited),
                                      ctypes.byref(system), ctypes.byref(user)):
            raise ctypes.WinError(ctypes.get_last_error())
        ticks = (created.dwHighDateTime << 32) | created.dwLowDateTime
        return ticks / 10_000_000 - 11_644_473_600
    finally:
        kernel.CloseHandle(handle)


def _windows_commands(identifiers: list[int]) -> dict[int, str]:
    if not identifiers:
        return {}
    query = " OR ".join(f"ProcessId = {int(pid)}" for pid in identifiers if pid > 0)
    if not query:
        return {}
    command = (
        "$ErrorActionPreference='Stop';"
        "[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false);"
        f"@(Get-CimInstance -ClassName Win32_Process -Filter '{query}' | "
        "Select-Object ProcessId,CommandLine) | ConvertTo-Json -Compress"
    )
    try:
        executable = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"),
                                  "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
        result = subprocess.run(
            [executable, "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", command],
            check=True, capture_output=True, text=True, encoding="utf-8-sig",
            errors="strict", timeout=3,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        records = json.loads(result.stdout)
        if isinstance(records, dict):
            records = [records]
        if not isinstance(records, list):
            return {}
        allowed, commands = set(identifiers), {}
        for record in records:
            if not isinstance(record, dict) or not isinstance(record.get("ProcessId"), int):
                return {}
            pid, arguments = record["ProcessId"], record.get("CommandLine")
            if pid not in allowed or pid in commands:
                return {}
            if isinstance(arguments, str) and arguments:
                commands[pid] = arguments
        return commands
    except (OSError, ValueError, subprocess.SubprocessError):
        return {}


def _windows_processes() -> list[_Process]:
    kernel = _windows_kernel()
    records = _windows_process_records(kernel)
    current_pid = os.getpid()
    commands = _windows_commands([pid for pid, name in records if _python_executable(name)])
    return [_Process(pid, _windows_process_started(kernel, pid)
                     if pid == current_pid or _possible_owner(name, commands.get(pid), windows=True)
                     else None, name, commands.get(pid))
            for pid, name in records]


def _processes() -> list[_Process]:
    if os.name == "nt":
        return _windows_processes()
    if os.name == "posix":
        return _posix_processes()
    raise OSError("Process inventory is unavailable on this platform")


def legacy_runtime_cutoff() -> float | None:
    """Return the oldest possible owner's start, including this application run.

    The current process's start also caps the boundary: collection cannot retire
    a legacy directory created during this application run. Failed or ambiguous
    inventories provide no evidence and return None.
    """
    observed = time.time()
    try:
        current_pid = os.getpid()
        records = _processes()
        identifiers = [record.pid for record in records]
        if (not math.isfinite(observed) or observed <= 0 or current_pid not in identifiers
                or len(set(identifiers)) != len(identifiers)
                or any(record.pid < 0 or not record.executable.strip() for record in records)):
            return None
        current = next(record for record in records if record.pid == current_pid)
        if (current.started is None or not math.isfinite(current.started)
                or current.started <= 0 or current.started > observed):
            return None
        cutoff = current.started
        for record in records:
            if record.pid == current_pid or not _possible_owner(
                    record.executable, record.command, windows=os.name == "nt"):
                continue
            if (record.started is None or not math.isfinite(record.started)
                    or record.started <= 0 or record.started > observed):
                return None
            cutoff = min(cutoff, record.started)
        return cutoff - _ROUNDING_MARGIN
    except (OSError, ValueError, TypeError, OverflowError, AttributeError, subprocess.SubprocessError):
        return None
