"""Publish validated risks from provably independent Chain likelihood blocks.

An unresolved block never supplies a point estimate for another query. Blocks
are separated in the full fitted-logit space, not by coefficient names, and a
Chain is indivisible. This permits shared coefficient representations while
requiring a direct-sum factorization of the actual likelihood.
"""
from __future__ import annotations

import math
from contextlib import contextmanager
from fractions import Fraction

import numpy as np
from scipy.linalg import qr

from .tsk_logistic_boundary import _plain
from .tsk_logistic_joint_boundary import (
    JointBoundaryBetterOptimumError, JointLogisticBoundaryFit, _contained, _space,
)


class SeparableJointLogisticFit:
    parameterization = "joint_logistic_components"

    def __init__(self, design, chain_index, n, k, type_count, coefficient_bound=35., progress_callback=None,
                 analysis_workers=1):
        self.full = JointLogisticBoundaryFit(design, chain_index, n, k, type_count, coefficient_bound,
                                             analysis_workers=analysis_workers)
        for name in ("design", "chain_index", "n", "k", "type_count", "width", "coefficient_bound"):
            setattr(self, name, getattr(self.full, name))
        self.progress_callback = progress_callback
        self.state = None
        self.components = []
        self.analysis_workers = self.full.analysis_workers
        self._parallel_session_depth = 0
        self._active_parallel_engine = None
        self._active_parallel_context = None
        self._contrast_union = None
        self._contrast_support = None

    @contextmanager
    def parallel_session(self):
        """Reuse only one component pool at a time, within the process budget."""
        self._parallel_session_depth += 1
        try:
            yield self
        except BaseException:
            self.close(terminate=True)
            raise
        finally:
            self._parallel_session_depth -= 1
            if self._parallel_session_depth == 0:
                self.close()

    def close(self, *, terminate=False):
        for component in self.components:
            component["engine"].close(terminate=terminate)
        if self._contrast_union is not None:
            self._contrast_union["engine"].close(terminate=terminate)
        self.full.close(terminate=terminate)
        context, self._active_parallel_context = self._active_parallel_context, None
        self._active_parallel_engine = None
        if context is not None:
            context.__exit__(None, None, None)

    @contextmanager
    def _query_session(self, engine):
        if not self._parallel_session_depth:
            with engine.parallel_session():
                yield engine
            return
        if self._active_parallel_engine is not engine:
            self.close()
            context = engine.parallel_session()
            context.__enter__()
            self._active_parallel_engine, self._active_parallel_context = engine, context
        yield engine

    def __getstate__(self):
        state = self.__dict__.copy()
        state.update(_parallel_session_depth=0, _active_parallel_engine=None,
                     _active_parallel_context=None, progress_callback=None,
                     _contrast_union=None, _contrast_support=None)
        return state

    @property
    def parallel_execution(self):
        blocks = [component["engine"].parallel_execution for component in self.components]
        return {"workers_requested": self.analysis_workers,
                "workers_used": max((block["workers_used"] for block in blocks), default=1),
                "execution_backend": "sequential_independent_blocks",
                "execution_warnings": list(dict.fromkeys(
                    warning for block in blocks for warning in block["execution_warnings"])),
                "components": blocks}

    def _partition(self):
        fitted = self.design @ self.full._design_transform
        unique, inverse = np.unique(fitted, axis=0, return_inverse=True)
        norms = np.linalg.norm(unique, axis=1)
        normalized = unique / norms[:, None]
        parent = np.arange(len(unique))

        def root(index):
            while parent[index] != index:
                parent[index] = parent[parent[index]]
                index = parent[index]
            return index

        def unite(indices):
            indices = list(indices)
            if indices:
                first = root(indices[0])
                for index in indices[1:]:
                    parent[root(index)] = first

        # A spanning set of pivot rows suffices to find the connected blocks
        # of U U^T, without allocating a quadratic instance-by-instance matrix.
        _, _, pivots = qr(normalized.T, mode="economic", pivoting=True)
        tolerance = 100 * np.finfo(float).eps * max(fitted.shape)
        for pivot in pivots[:fitted.shape[1]]:
            unite(np.flatnonzero(np.abs(normalized @ normalized[pivot]) > tolerance))
        for chain in range(len(self.n)):
            unite(np.unique(inverse[self.chain_index == chain]))
        groups = {}
        for instance, index in enumerate(inverse):
            groups.setdefault(root(index), []).append(instance)
        blocks = [np.asarray(rows, dtype=int) for rows in groups.values()]
        # Refuse a numerical split unless the fitted-logit spans form a direct
        # sum. Keeping one block is conservative in a nearly singular model.
        ranks = [len(_space(fitted[rows])[0].T) for rows in blocks]
        if sum(ranks) != fitted.shape[1]:
            return [np.arange(len(self.design))]
        return sorted(blocks, key=lambda rows: int(rows[0]))

    def _engine(self, rows):
        chains, local = np.unique(self.chain_index[rows], return_inverse=True)
        engine = JointLogisticBoundaryFit(self.design[rows], local, self.n[chains], self.k[chains],
                                           self.type_count, self.coefficient_bound,
                                           analysis_workers=self.analysis_workers)
        basis, _ = _space(self.design[rows] / self.full._column_scale)
        return {"rows": rows, "chains": chains, "engine": engine, "basis": basis}

    def _unavailable(self, component, start, error):
        """Keep numerical bookkeeping for an unavailable block, never risks."""
        engine = component["engine"]
        theta = np.asarray(start, dtype=float)
        if theta.shape != (self.width,) or not np.all(np.isfinite(theta)):
            raise ValueError("Invalid unavailable-block representative.")
        value, _, predicted, _, _ = engine._evaluate(theta)
        if not math.isfinite(value):
            theta = np.zeros(self.width)
            value, _, predicted, _, _ = engine._evaluate(theta)
        component["failure"] = str(error)
        engine.state = _plain({"converged": False, "coefficients": theta, "core_coefficients": theta,
                              "recession_direction": np.zeros(self.width), "zero_rows": [],
                              "minimum": value, "predicted": predicted,
                              "validation": {"reason_codes": ["independent_block_numerical_failure"]}})

    def _assemble(self):
        fitted = self.design @ self.full._design_transform
        def coefficients(field):
            logits = np.empty(len(self.design))
            for component in self.components:
                rows = component["rows"]
                logits[rows] = self.design[rows] @ np.asarray(component["engine"].state[field])
            result = self.full._design_transform @ (fitted.T @ logits)
            if not np.allclose(self.design @ result, logits, atol=1e-7, rtol=1e-10):
                raise RuntimeError("Independent joint blocks could not be combined without changing their logits.")
            return result
        usable = [bool(component["engine"].state.get("converged")) for component in self.components]
        zero, valid_chains = [], []
        for component, valid in zip(self.components, usable):
            if valid:
                valid_chains.extend(component["chains"].tolist())
            zero.extend(component["rows"][component["engine"].state["zero_rows"]].tolist())
        self.state = _plain({
            "version": 1, "parameterization": self.parameterization,
            "model_fingerprint": self.full._fingerprint, "type_count": self.type_count,
            "coefficient_bound": self.coefficient_bound, "converged": all(usable), "usable": any(usable),
            "partial_fit": any(usable) and not all(usable),
            "coefficients": coefficients("coefficients"), "core_coefficients": coefficients("core_coefficients"),
            "recession_direction": coefficients("recession_direction"),
            "zero_rows": sorted(zero), "active_rows": sorted(set(range(len(self.design))) - set(zero)),
            "valid_chain_indices": sorted(valid_chains),
            "components": [{"rows": component["rows"], "chains": component["chains"],
                            "state": component["engine"].state, "failure": component.get("failure")}
                           for component in self.components],
            "validation": {"reason_codes": [] if all(usable) else ["independent_component_risks_only"],
                           "likelihood_factorization_certified": True,
                           "validated_components": sum(usable), "component_count": len(usable),
                           "identifiability_scope": "Risks require one validated independent Chain block; cross-block linear contrasts require a joint full-nuisance profile of the validated factors."},
        })
        self.state["params"] = list(self.state["coefficients"])
        minimum, _, predicted, _ = self.evaluate(self.state["coefficients"])
        self.state.update(minimum=minimum, predicted=predicted.tolist())
        return self.state

    def fit(self, start):
        self._reset_contrast_recovery()
        blocks = self._partition()
        if len(blocks) < 2:
            raise RuntimeError("Unresolved joint boundary is coupled to the remaining likelihood; no independent recovery block.")
        self.components = []
        for index, rows in enumerate(blocks):
            if self.progress_callback:
                self.progress_callback({"phase": "independent_joint_block", "block": index + 1, "count": len(blocks)})
            component = self._engine(rows)
            engine = component["engine"]
            engine.progress_callback = (lambda event, block=index + 1: self.progress_callback(
                dict(event, block=block, count=len(blocks)))) if self.progress_callback is not None else None
            try:
                state = engine.fit(start)
            except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                self._unavailable(component, start, error)
                self.components.append(component)
                continue
            finally:
                engine.progress_callback = None
            reference = engine._evaluate(np.asarray(start))[0]
            if state["minimum"] > reference + max(1e-7, abs(reference) * 32 * np.finfo(float).eps):
                state["converged"] = False
                state["validation"]["reason_codes"].append("independent_block_likelihood_not_improved")
            self.components.append(component)
        return self._assemble()

    def load_state(self, state):
        self._reset_contrast_recovery()
        if (not isinstance(state, dict) or state.get("version") != 1
                or state.get("parameterization") != self.parameterization
                or state.get("model_fingerprint") != self.full._fingerprint):
            raise ValueError("Unsupported or stale independent joint Logistic state.")
        blocks = self._partition()
        saved = state.get("components", [])
        if len(blocks) < 2 or len(blocks) != len(saved):
            raise ValueError("Saved independent joint partition is inconsistent.")
        self.components = []
        for rows, entry in zip(blocks, saved):
            component = self._engine(rows)
            if (not np.array_equal(rows, entry.get("rows"))
                    or not np.array_equal(component["chains"], entry.get("chains"))):
                raise ValueError("Saved independent joint block is inconsistent.")
            if entry.get("failure") is not None:
                self._unavailable(component, entry["state"]["coefficients"], entry["failure"])
                if entry["state"].get("converged"):
                    raise ValueError("An unavailable block cannot have a validated fit.")
            else:
                component["engine"].load_state(entry["state"])
            self.components.append(component)
        rebuilt = self._assemble()
        for key in ("coefficients", "core_coefficients", "predicted", "minimum"):
            if not np.allclose(rebuilt[key], state.get(key), atol=1e-8, rtol=1e-12):
                raise ValueError("Saved independent joint likelihood or coefficients are inconsistent.")
        for key in ("converged", "usable", "partial_fit", "valid_chain_indices"):
            if rebuilt[key] != state.get(key):
                raise ValueError("Saved independent joint validation status is inconsistent.")
        return self

    def evaluate(self, params):
        theta = np.asarray(params, dtype=float)
        exact = self.state is not None and np.array_equal(theta, self.state["coefficients"])
        loss, gradient = 0., np.zeros(self.width)
        predicted, derivative = np.zeros(len(self.n)), np.zeros((len(self.n), self.width))
        for component in self.components:
            engine = component["engine"]
            value, grad, q, jacobian = engine.evaluate(engine.state["coefficients"] if exact else theta)
            loss += value
            gradient += grad
            predicted[component["chains"]], derivative[component["chains"]] = q, jacobian
        return float(loss), gradient, predicted, derivative

    def instance_hazards(self, params=None):
        result = np.empty(len(self.design))
        exact = params is None or np.array_equal(params, self.state["coefficients"])
        for component in self.components:
            result[component["rows"]] = component["engine"].instance_hazards(None if exact else params)
        return result

    def _component(self, vector):
        if self.state is None or not self.state.get("usable"):
            return None
        vector = np.asarray(vector, dtype=float)
        if vector.shape != (self.width,) or not np.all(np.isfinite(vector)):
            return None
        for component in self.components:
            if (component["engine"].state.get("converged")
                    and _contained(vector / self.full._column_scale, component["basis"],
                                   tolerance=8 * np.finfo(float).eps * self.width)):
                return component["engine"]
        return None

    def query_validated(self, vector):
        return self._component(vector) is not None

    def identifiable(self, params, vector):
        return self.risk_identifiability(params, vector)["identifiable"]

    def risk_identifiability(self, params, vector, *, verify=False):
        """Preserve the owning block's evidence, including unresolved checks."""
        def unavailable(reason, status="unresolved"):
            return {"status": status, "identifiable": False,
                    "scope": "independent_likelihood_block", "reason_codes": [reason],
                    "profile_verified": False}

        if self.state is None or not np.array_equal(params, self.state["coefficients"]):
            return unavailable("independent_joint_fit_not_current")
        if not self.state.get("usable"):
            return unavailable("independent_joint_fit_not_validated")
        vector = self.full._query(vector)
        engine = self._component(vector)
        if engine is None:
            if not _contained(vector / self.full._column_scale, self.full._scaled_design_basis):
                return unavailable("query_outside_observed_design", "not_identifiable")
            return unavailable("query_requires_unvalidated_or_multiple_blocks")
        previous_callback = engine.progress_callback
        engine.progress_callback = self.progress_callback
        try:
            with self._query_session(engine):
                result = engine.risk_identifiability(engine.state["coefficients"], vector, verify=verify)
            return {**result, "scope": "independent_block:" + result["scope"]}
        except JointBoundaryBetterOptimumError:
            self._invalidate_profile_fit()
            raise
        finally:
            engine.progress_callback = previous_callback

    def probability(self, params, vector):
        if not self.identifiable(params, vector):
            return math.nan
        engine = self._component(vector)
        return engine.probability(engine.state["coefficients"], vector)

    def estimate_kind(self, vector):
        engine = self._component(vector)
        return engine.estimate_kind(vector) if engine is not None else "unidentifiable"

    def coefficient_identifiable(self, index):
        engine = self._component(np.eye(self.width)[index])
        return engine is not None and engine.coefficient_identifiable(index)

    def _reset_contrast_recovery(self):
        if self._contrast_union is not None:
            self._contrast_union["engine"].close()
        self._contrast_union = self._contrast_support = None

    def _invalidate_profile_fit(self, reason="joint_profile_found_better_optimum"):
        self._reset_contrast_recovery()
        if self.state is not None:
            self.state.update(converged=False, usable=False)
            reasons = self.state.setdefault("validation", {}).setdefault("reason_codes", [])
            if reason not in reasons:
                reasons.append(reason)
        for component in self.components:
            child = component["engine"]
            if child.state is not None:
                child._invalidate_profile_fit()

    def _contrast_supported_exactly(self, vector, rows, signature):
        """Do not round a small contribution from an unresolved block to zero.

        The numerical span check is followed by exact arithmetic on the input
        floats when failed blocks exist. This basis is shared by all contrasts
        for the same validated blocks; it proves that omitted factors are
        constant with respect to the requested contrast.
        """
        if self._contrast_support is None or self._contrast_support[0] != signature:
            basis = []
            for row in self.design[rows]:
                value = [Fraction.from_float(float(item)) for item in row]
                for pivot, basis_row in basis:
                    amount = value[pivot]
                    if amount:
                        value = [a - amount * b for a, b in zip(value, basis_row)]
                pivot = next((i for i, item in enumerate(value) if item), None)
                if pivot is not None:
                    amount = value[pivot]
                    basis.append((pivot, tuple(item / amount for item in value)))
                    basis.sort(key=lambda item: item[0])
                if len(basis) == self.width:
                    break
            self._contrast_support = signature, basis
        value = [Fraction.from_float(float(item)) for item in vector]
        for pivot, basis_row in self._contrast_support[1]:
            amount = value[pivot]
            if amount:
                value = [a - amount * b for a, b in zip(value, basis_row)]
        return not any(value)

    def _contrast_recovery_engine(self, components, signature):
        """Refit the independent successful factors with full nuisance probes."""
        if self._contrast_union is not None and self._contrast_union["signature"] == signature:
            return self._contrast_union["engine"]
        # A previous child session may still own idle workers. The recovery
        # fit must share, rather than add to, the parent's process budget.
        self.close()
        self._reset_contrast_recovery()
        rows = np.sort(np.concatenate([component["rows"] for component in components]))
        recovery = self._engine(rows)
        engine = recovery["engine"]
        engine.progress_callback = self.progress_callback
        try:
            state = engine.fit(np.asarray(self.state["coefficients"]))
            zero = np.zeros(len(self.design), dtype=bool)
            zero[rows[np.asarray(state["zero_rows"], dtype=int)]] = True
            # Compare in each original block, avoiding both large-NLL
            # subtraction and rounding from an assembled reference vector.
            changes = [component["engine"]._loss_difference(
                np.asarray(state["core_coefficients"]), zero[component["rows"]],
                np.asarray(component["engine"].state["core_coefficients"]), component["engine"]._zero)
                for component in components]
            difference = math.fsum(changes)
            if difference < -1e-7:
                raise JointBoundaryBetterOptimumError(
                    "Independent contrast refit found a better likelihood than the stored blocks.")
            if not state.get("converged") or not math.isfinite(difference) or difference > 1e-7:
                raise RuntimeError("Independent contrast nuisance refit was not validated.")
        except BaseException:
            engine.close(terminate=True)
            raise
        finally:
            engine.progress_callback = None
        self._contrast_union = {"signature": signature, "engine": engine}
        return engine

    def contrast_result(self, vector):
        """Verify a contrast using only its validated independent factors.

        Cross-block contrasts receive the same normalized, full-nuisance
        profile checks as an ordinary joint fit. Separate component probes
        alone cannot establish the aggregate likelihood-increase threshold.
        """
        return self._contrast_query(vector)

    def contrast_inference(self, vector, confidence=.95):
        """Profile the validated factors jointly, including cross-block effects."""
        if not 0. < confidence < 1.:
            raise ValueError("Confidence level must lie between zero and one.")
        return self._contrast_query(vector, float(confidence))

    def _contrast_query(self, vector, confidence=None):
        vector = np.asarray(vector, dtype=float)
        def outcome(*args, **kwargs):
            point = JointLogisticBoundaryFit._contrast_outcome(*args, **kwargs)
            return (point if confidence is None else
                    JointLogisticBoundaryFit._contrast_inference_empty(point, confidence))
        if vector.shape != (self.width,) or not np.all(np.isfinite(vector)):
            raise ValueError("Invalid independent joint Logistic linear contrast.")
        if self.state is None or not self.state.get("usable"):
            return outcome("unavailable", "independent_joint_fit_not_validated")
        components = [component for component in self.components if component["engine"].state.get("converged")]
        if not components:
            return outcome("unavailable", "independent_joint_fit_not_validated")
        signature = tuple((id(component["engine"].state), bool(component["engine"].state.get("converged")))
                          for component in self.components)
        if self._contrast_union is not None and self._contrast_union["signature"] != signature:
            self._reset_contrast_recovery()
        magnitude = float(np.max(np.abs(vector), initial=0.))
        if magnitude == 0.:
            point = JointLogisticBoundaryFit._contrast_outcome("finite", "zero_contrast", estimate=0.)
            point["odds_ratio"] = 1.
            return point if confidence is None else JointLogisticBoundaryFit._contrast_inference_empty(point, confidence)
        normalized = vector / magnitude
        if np.any((vector != 0) & (normalized == 0)):
            return outcome("unavailable", "contrast_scaling_underflow")
        with np.errstate(over="ignore", under="ignore", invalid="ignore"):
            scaled = normalized / self.full._column_scale
        if not np.all(np.isfinite(scaled)) or np.any((normalized != 0) & (scaled == 0)):
            return outcome("unavailable", "contrast_scaling_underflow")
        rows = np.sort(np.concatenate([component["rows"] for component in components]))
        basis, _ = _space(self.design[rows] / self.full._column_scale)
        if (not _contained(scaled, basis, tolerance=8 * np.finfo(float).eps * self.width)
                or (len(components) != len(self.components)
                    and not self._contrast_supported_exactly(vector, rows, signature))):
            return outcome("not_identifiable", "contrast_requires_unvalidated_or_unobserved_component")
        engine = self._component(vector)
        try:
            if engine is None:
                engine = self._contrast_recovery_engine(components, signature)
            previous_callback = engine.progress_callback
            engine.progress_callback = self.progress_callback
            try:
                with self._query_session(engine):
                    result = (engine.contrast_result(vector) if confidence is None else
                              engine.contrast_inference(vector, confidence))
            finally:
                engine.progress_callback = previous_callback
            return {**result, "identifiability_scope": "supported_independent_blocks_full_nuisance_profile"}
        except JointBoundaryBetterOptimumError:
            self._invalidate_profile_fit("independent_contrast_found_better_optimum")
            raise
        except (ValueError, RuntimeError, FloatingPointError, OverflowError, np.linalg.LinAlgError):
            return outcome("unavailable", "independent_contrast_profile_unavailable")

    def profile_interval(self, params, vector, confidence):
        if not self.identifiable(params, vector):
            raise RuntimeError("The risk does not belong to a validated independent likelihood block.")
        engine = self._component(vector)
        previous_callback = engine.progress_callback
        engine.progress_callback = self.progress_callback
        try:
            with self._query_session(engine):
                return engine.profile_interval(engine.state["coefficients"], vector, confidence)
        except JointBoundaryBetterOptimumError:
            self._invalidate_profile_fit()
            raise
        finally:
            engine.progress_callback = previous_callback


def joint_fit_from_state(design, chain_index, n, k, type_count, state, coefficient_bound=35.):
    if not isinstance(state, dict):
        raise ValueError("Invalid joint Logistic state.")
    cls = (SeparableJointLogisticFit if state.get("parameterization") == SeparableJointLogisticFit.parameterization
           else JointLogisticBoundaryFit)
    return cls(design, chain_index, n, k, type_count, coefficient_bound).load_state(state)
