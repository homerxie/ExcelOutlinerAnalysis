"""Risk-specific identifiability evidence shared by result consumers."""
from __future__ import annotations

from copy import deepcopy

import numpy as np


def risk_evidence(status, *, identifiable=False, scope="legacy", reason_codes=(), profile_verified=False, **details):
    return {"status": status, "identifiable": bool(identifiable), "scope": scope,
            "reason_codes": list(reason_codes), "profile_verified": bool(profile_verified), **details}


def engine_risk_evidence(engine, parameters, vector, *, verify=False):
    """Keep legacy contracts explicit and numerical uncertainty distinguishable."""
    try:
        query = getattr(engine, "risk_identifiability", None)
        if callable(query):
            return deepcopy(query(parameters, vector, verify=verify))
        identified = bool(engine.identifiable(parameters, vector))
        return risk_evidence("legacy_identifiable" if identified else "not_identifiable",
                             identifiable=identified)
    except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
        if getattr(error, "invalidates_fit", False):
            raise
        return risk_evidence("unresolved", scope="query_numerical_review" if callable(query) else "legacy",
                             reason_codes=["risk_identifiability_numerical_failure"],
                             error=str(error) or type(error).__name__)
