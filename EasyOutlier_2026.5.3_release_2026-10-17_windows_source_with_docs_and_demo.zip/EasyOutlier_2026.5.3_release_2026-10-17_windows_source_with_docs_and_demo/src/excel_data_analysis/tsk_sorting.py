"""Stable display ordering for names and numerical estimates."""

from functools import lru_cache
import math
import re
from typing import Any


_NUMBER_PARTS = re.compile(r"(\d+)")


@lru_cache(maxsize=8192)
def _text_key(value: str) -> tuple:
    return tuple((0, int(part)) if part.isdecimal() else (1, part.casefold())
                 for part in _NUMBER_PARTS.split(value) if part)


def natural_sort_key(value: Any) -> tuple:
    """Compare numeric name parts by value without mixing strings and integers."""
    return _text_key("" if value is None else str(value))


def numeric_sort_key(value: Any, *, descending: bool = False) -> tuple:
    """Order signed infinities numerically, keeping unavailable values last."""
    if not isinstance(value, (int, float)) or isinstance(value, bool) or math.isnan(value):
        return (1, 0.)
    return (0, -value if descending else value)
