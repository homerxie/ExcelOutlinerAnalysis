"""Read saved TSK input settings without allocating its rows or chain states."""
from __future__ import annotations

import gzip
import io
from pathlib import Path
import zlib

from .snapshot_json_stream import JSONStream
from .template import _parse_template
from .tsk_analysis_state import FORMAT


_REQUIRED = {"format", "template", "columns", "rows", "final_status_rows", "fail_mode", "result"}


def _skip(reader):
    reader.skip()


def _row_nodes(reader, node_dimension):
    nodes = {}

    def row_dimensions(item):
        selected = item.object_fields({
            "dimensions": lambda dimensions: dimensions.object_fields({node_dimension: None}),
        })
        dimensions = selected.get("dimensions")
        if not isinstance(dimensions, dict) or node_dimension not in dimensions:
            raise ValueError("Saved Analyze input row has no reliability node")
        node = dimensions[node_dimension]
        if not isinstance(node, str):
            raise ValueError("Invalid saved Analyze input reliability node")
        return node

    for node in reader.array_items(row_dimensions):
        nodes.setdefault(node, None)
    return list(nodes)


def load_tsk_analysis_metadata(path: str | Path) -> dict:
    """Return the original parsed template and first-seen reliability nodes.

    Every skipped JSON value and the complete gzip trailer are still checked.
    The ordinary writer puts the template before rows, requiring one pass. An
    older/reordered object can put rows first; only that case needs a second
    pass, instead of retaining every row's dimensions until the template arrives.
    Full analysis and export continue to use the complete snapshot reader.
    """
    template = None
    deferred_rows = False

    def read_template(reader):
        nonlocal template
        payload = reader.value()
        if not isinstance(payload, dict):
            raise ValueError("Invalid saved Analyze input template")
        template = _parse_template(payload)
        return template

    def read_rows(reader):
        nonlocal deferred_rows
        if template is None:
            reader.skip()
            deferred_rows = True
            return None
        return _row_nodes(reader, template.report.reliability_node_dimension)

    try:
        with Path(path).open("rb") as source:
            with gzip.GzipFile(fileobj=source, mode="rb") as packed:
                with io.TextIOWrapper(packed, encoding="utf-8") as text:
                    reader = JSONStream(text)
                    selected = reader.object_fields({
                        "format": None, "template": read_template, "rows": read_rows,
                        "columns": _skip, "final_status_rows": _skip, "fail_mode": _skip, "result": _skip,
                    })
                    reader.finish()
            if selected.get("format") != FORMAT or not _REQUIRED <= selected.keys():
                raise ValueError("Unsupported or incomplete saved Analyze input")
            if deferred_rows:
                source.seek(0)
                with gzip.GzipFile(fileobj=source, mode="rb") as packed:
                    with io.TextIOWrapper(packed, encoding="utf-8") as text:
                        reader = JSONStream(text)
                        selected_rows = reader.object_fields({"rows": read_rows})
                        reader.finish()
                selected["rows"] = selected_rows["rows"]
            return {"template": template, "available_nodes": selected["rows"]}
    except (OSError, EOFError, zlib.error, UnicodeError, KeyError, TypeError, ValueError,
            OverflowError, IndexError, AttributeError) as exc:
        raise ValueError(f"Invalid saved Analyze input metadata: {exc}") from exc
