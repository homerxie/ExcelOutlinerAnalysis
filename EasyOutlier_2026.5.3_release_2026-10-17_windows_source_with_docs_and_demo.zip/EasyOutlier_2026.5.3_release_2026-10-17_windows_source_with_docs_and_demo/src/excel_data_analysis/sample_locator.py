"""Compact identities for locating sample points across Plot Inspector metrics.

Only template identity dimensions participate: ``PlotPoint.sample_id`` is a
display value and can contain a concatenation of dimensions. Original point
positions are preserved, including repeated measurements and separate nodes.
The completed index retains integer arrays and distinct dimension values, not
point objects, point-sized Python containers, or references to source series.
"""

from __future__ import annotations

from collections import OrderedDict
from concurrent.futures import CancelledError
from dataclasses import dataclass
from sys import getsizeof
from types import MappingProxyType
from typing import Callable, Hashable, Mapping

import numpy as np

from .comparison_models import PlotSeries


_MISSING = object()
_EMPTY_INDICES = np.frombuffer(b"", dtype=np.uint32)


def _immutable_array(values: np.ndarray) -> np.ndarray:
    """Return an array whose write flag cannot be re-enabled by its caller."""
    return np.frombuffer(values.tobytes(), dtype=values.dtype).reshape(values.shape)


def _retained_bytes(value: object, seen: set[int]) -> int:
    """Count compact owned objects, including the backing bytes of NumPy views.

    Mapping proxies are counted alongside their underlying dictionaries by the
    caller while those dictionaries are still accessible during index creation.
    Shared strings/integers within one index are counted once. Separate cached
    indexes count their shared objects again, conservatively bounding retention.
    """
    identity = id(value)
    if identity in seen:
        return 0
    seen.add(identity)
    size = getsizeof(value)
    if isinstance(value, np.ndarray):
        if value.base is not None:
            size += _retained_bytes(value.base, seen)
    elif isinstance(value, dict):
        size += sum(_retained_bytes(key, seen) + _retained_bytes(item, seen) for key, item in value.items())
    elif isinstance(value, (tuple, frozenset)):
        size += sum(_retained_bytes(item, seen) for item in value)
    return size


def _cache_key_bytes(key: Hashable) -> int:
    """Accept only immutable signatures that cannot retain source object graphs."""
    def validate(value: object) -> None:
        if type(value) in (tuple, frozenset):
            for item in value:
                validate(item)
        elif type(value) not in (str, int, float, bool, bytes, type(None)):
            raise TypeError("Sample index cache keys must contain only tuples, frozensets and scalar values")

    validate(key)
    return _retained_bytes(key, set())


@dataclass(frozen=True, slots=True)
class SampleSelection:
    sample_count: int
    point_count: int
    metric_keys: frozenset[str]
    indices_by_metric: Mapping[str, tuple[np.ndarray, ...]]


class SamplePointIndex:
    """Integer-coded sample identities and original-lane point membership.

    Missing identity fields are represented by zero, distinct from the literal
    empty string. Samples with the same configured dimension values (including
    missing markers) are one identity; no unsupported identity is inferred from
    a display label or source row. Queries AND exact, case-sensitive values.
    """

    __slots__ = ("_fields", "_values", "_candidates", "_identities", "_sample_ids", "_lanes", "_estimated_bytes")

    @classmethod
    def build(
        cls,
        series_by_metric: dict[str, tuple[PlotSeries, ...]],
        sample_dimensions: tuple[str, ...],
        cancelled: Callable[[], bool] | None = None,
    ) -> SamplePointIndex:
        fields = tuple(sample_dimensions)
        if not fields or any(not isinstance(field, str) or not field for field in fields):
            raise ValueError("Sample dimensions must contain non-empty field names")
        if len(set(fields)) != len(fields):
            raise ValueError("Sample dimensions must be unique")

        def check_cancelled() -> None:
            if cancelled is not None and cancelled():
                raise CancelledError("Sample locator indexing cancelled")

        check_cancelled()
        point_count = sum(len(lane.points) for lanes in series_by_metric.values() for lane in lanes)
        if point_count > np.iinfo(np.uint32).max:
            raise ValueError("Sample locator supports at most 2^32 - 1 points")
        sample_ids = np.empty(point_count, dtype=np.uint32)
        values: list[dict[str, int]] = [{} for _ in fields]
        identities: dict[tuple[int, ...], int] = {}
        lane_ranges: dict[str, tuple[tuple[int, int], ...]] = {}
        offset = 0
        for metric, series in series_by_metric.items():
            check_cancelled()
            ranges: list[tuple[int, int]] = []
            for lane in series:
                check_cancelled()
                start = offset
                for point in lane.points:
                    if offset % 2048 == 0:
                        check_cancelled()
                    codes = []
                    for field, field_values in zip(fields, values):
                        value = point.dimensions.get(field, _MISSING)
                        if value is _MISSING or value is None:
                            codes.append(0)
                        else:
                            text = value if isinstance(value, str) else str(value)
                            code = field_values.get(text)
                            if code is None:
                                code = len(field_values) + 1
                                field_values[text] = code
                            codes.append(code)
                    key = tuple(codes)
                    sample_id = identities.get(key)
                    if sample_id is None:
                        sample_id = len(identities)
                        identities[key] = sample_id
                    sample_ids[offset] = sample_id
                    offset += 1
                ranges.append((start, offset))
            lane_ranges[metric] = tuple(ranges)
        check_cancelled()
        identity_array = np.asarray(tuple(identities), dtype=np.uint32).reshape((-1, len(fields)))
        index = cls()
        index._fields = fields
        index._values = tuple(MappingProxyType(field_values) for field_values in values)
        index._candidates = tuple(tuple(sorted(field_values)) for field_values in values)
        index._identities = _immutable_array(identity_array)
        index._sample_ids = _immutable_array(sample_ids)
        index._lanes = MappingProxyType(lane_ranges)
        retained = (
            fields, index._values, index._candidates, index._identities,
            index._sample_ids, index._lanes, lane_ranges, *values,
        )
        seen: set[int] = set()
        index._estimated_bytes = getsizeof(index) + getsizeof(0) + sum(
            _retained_bytes(value, seen) for value in retained
        )
        check_cancelled()
        return index

    @property
    def fields(self) -> tuple[str, ...]:
        return self._fields

    @property
    def array_nbytes(self) -> int:
        """Retained numeric storage; approximately four bytes per source point."""
        return self._identities.nbytes + self._sample_ids.nbytes

    @property
    def estimated_bytes(self) -> int:
        """Retained arrays, identities and lane metadata, estimated once on build."""
        return self._estimated_bytes

    def values_for(self, field: str) -> tuple[str, ...]:
        try:
            field_index = self._fields.index(field)
        except ValueError as exc:
            raise ValueError(f"Unknown sample dimension: {field}") from exc
        return self._candidates[field_index]

    @staticmethod
    def _empty_selection() -> SampleSelection:
        return SampleSelection(0, 0, frozenset(), MappingProxyType({}))

    def query(self, conditions: dict[str, str]) -> SampleSelection:
        """Select exact dimension values; an empty query selects all points.

        Unknown values yield no matches. Unknown fields are caller mistakes and
        raise ValueError. Missing fields never match an explicit empty string.
        Point searches use numeric masks; source point objects are not visited.
        Only matching metrics appear in the result, preserving their lane order.
        """
        unknown = set(conditions).difference(self._fields)
        if unknown:
            raise ValueError(f"Unknown sample dimension: {sorted(unknown)[0]}")
        selected = np.ones(len(self._identities), dtype=np.bool_)
        for field, value in conditions.items():
            field_index = self._fields.index(field)
            code = self._values[field_index].get(value)
            if code is None:
                return self._empty_selection()
            selected &= self._identities[:, field_index] == code
        sample_count = int(np.count_nonzero(selected))
        if not sample_count:
            return self._empty_selection()
        indices_by_metric: dict[str, tuple[np.ndarray, ...]] = {}
        point_count = 0
        for metric, ranges in self._lanes.items():
            metric_indices = []
            metric_point_count = 0
            for start, end in ranges:
                indices = np.flatnonzero(selected[self._sample_ids[start:end]])
                metric_point_count += len(indices)
                metric_indices.append(
                    _immutable_array(indices.astype(np.uint32, copy=False)) if len(indices) else _EMPTY_INDICES
                )
            if metric_point_count:
                indices_by_metric[metric] = tuple(metric_indices)
                point_count += metric_point_count
        return SampleSelection(
            sample_count, point_count, frozenset(indices_by_metric), MappingProxyType(indices_by_metric),
        )


class SampleIndexCache:
    """Bounded in-memory history of compact indexes; never stores plot results.

    An oversized index can still be used by the caller as its current index but
    is not retained here. Byte accounting includes signature keys and a generous
    allowance for each OrderedDict entry in addition to the index's own memory.
    """

    _ENTRY_OVERHEAD = 512

    def __init__(self, max_entries: int = 8, max_bytes: int = 32 * 1024 * 1024) -> None:
        if max_entries < 0 or max_bytes < 0:
            raise ValueError("Sample index cache limits must be non-negative")
        self._max_entries = max_entries
        self._max_bytes = max_bytes
        self._entries: OrderedDict[Hashable, tuple[SamplePointIndex, int]] = OrderedDict()
        self._estimated_bytes = 0
        self._hits = 0
        self._misses = 0
        self._evictions = 0

    def get(self, key: Hashable) -> SamplePointIndex | None:
        entry = self._entries.get(key)
        if entry is None:
            self._misses += 1
            return None
        self._entries.move_to_end(key)
        self._hits += 1
        return entry[0]

    def put(self, key: Hashable, index: SamplePointIndex) -> bool:
        size = index.estimated_bytes + _cache_key_bytes(key) + self._ENTRY_OVERHEAD
        previous = self._entries.pop(key, None)
        if previous is not None:
            self._estimated_bytes -= previous[1]
        if not self._max_entries or size > self._max_bytes:
            return False
        while self._entries and (
            len(self._entries) >= self._max_entries or self._estimated_bytes + size > self._max_bytes
        ):
            _, evicted = self._entries.popitem(last=False)
            self._estimated_bytes -= evicted[1]
            self._evictions += 1
        self._entries[key] = (index, size)
        self._estimated_bytes += size
        return True

    def clear(self) -> None:
        self._entries.clear()
        self._estimated_bytes = 0

    def set_limits(self, *, max_bytes: int, max_entries: int | None = None) -> None:
        """Resize retained history, evicting oldest entries when limits shrink.

        This only releases cache references: an index currently held by the
        caller remains usable, including when memory pressure sets the limit to
        zero. Validate both limits before changing any state.
        """
        if max_bytes < 0 or (max_entries is not None and max_entries < 0):
            raise ValueError("Sample index cache limits must be non-negative")
        self._max_bytes = max_bytes
        if max_entries is not None:
            self._max_entries = max_entries
        while self._entries and (
            len(self._entries) > self._max_entries or self._estimated_bytes > self._max_bytes
        ):
            _, evicted = self._entries.popitem(last=False)
            self._estimated_bytes -= evicted[1]
            self._evictions += 1

    def cache_info(self) -> dict[str, int]:
        return {
            "entries": len(self._entries), "estimated_bytes": self._estimated_bytes,
            "max_entries": self._max_entries, "max_bytes": self._max_bytes,
            "hits": self._hits, "misses": self._misses, "evictions": self._evictions,
        }
