"""Numerical joint-logit closure for monotone all-Pass separation.

A recession direction may change every TSK intercept and every shared effect.
Only instance logits certified by a full-design linear program are removed.
Finite contrasts are fitted on the remaining likelihood face.  Certification
is sufficient and local: the nonlinear grouped-Chain likelihood is not a GLM,
and multistart/profiling do not constitute a proof of a global optimum.
"""
from __future__ import annotations

import hashlib
import math
from time import monotonic

import numpy as np
from scipy.linalg import null_space
from scipy.optimize import brentq, linprog, minimize
from scipy.special import expit
from scipy.stats import chi2

from .tsk_logistic_boundary import (
    CONSERVATIVE_EXACT_METHOD, EXACT_METHOD, _plain,
)

INTERIOR_METHOD = "profile_likelihood_approximate_joint_logistic_contrast"
BOUNDARY_METHOD = "profile_likelihood_approximate_joint_logistic_zero_boundary"


class JointBoundaryBetterOptimumError(RuntimeError):
    """A nuisance refit invalidated the likelihood used by all published queries."""
    invalidates_fit = True


def _space(matrix, absolute_tolerance=0.):
    """An orthonormal row basis and a transform with orthonormal fitted columns."""
    matrix = np.asarray(matrix, dtype=float)
    if not matrix.size:
        return np.zeros((matrix.shape[1], 0)), np.zeros((matrix.shape[1], 0))
    _, singular, right = np.linalg.svd(matrix, full_matrices=False)
    keep = singular > max(absolute_tolerance, max(matrix.shape) * np.finfo(float).eps * singular[0] * 100)
    basis = right[keep].T
    return basis, basis / singular[keep]


def _contained(vector, basis, tolerance=1e-7):
    magnitude = float(np.max(np.abs(vector), initial=0.))
    if not math.isfinite(magnitude):
        return False
    if magnitude == 0:
        return True
    normalized = vector / magnitude
    return np.linalg.norm(normalized - basis @ (basis.T @ normalized)) <= tolerance * np.linalg.norm(normalized)


class JointLogisticBoundaryFit:
    """Fit a certified monotone face while retaining joint compensation.

    ``params`` and ``coefficients`` in saved states are finite representatives;
    ``core_coefficients`` and ``zero_rows`` define the exact fitted limit.
    ``coefficient_bound`` is an initial search scale, never a statistical bound.
    """
    def __init__(self, design, chain_index, n, k, type_count, coefficient_bound=35., progress_callback=None):
        self.design = np.asarray(design, dtype=float)
        self.chain_index = np.asarray(chain_index, dtype=int)
        self.n, self.k = np.asarray(n, dtype=float), np.asarray(k, dtype=float)
        self.type_count = int(type_count)
        self.coefficient_bound = float(coefficient_bound)
        self.progress_callback = progress_callback
        if (self.design.ndim != 2 or not len(self.design) or not 0 < self.type_count <= self.design.shape[1]
                or self.chain_index.shape != (len(self.design),) or self.n.ndim != 1 or self.n.shape != self.k.shape
                or not len(self.n) or np.any(self.n <= 0) or np.any(self.k < 0) or np.any(self.k > self.n)
                or np.any(self.chain_index < 0) or np.any(self.chain_index >= len(self.n))
                or not all(np.all(np.isfinite(a)) for a in (self.design, self.n, self.k))
                or not math.isfinite(self.coefficient_bound) or self.coefficient_bound <= .1):
            raise ValueError("Invalid joint Logistic model arrays or search scale.")
        kinds = self.design[:, :self.type_count]
        if not (np.all((kinds == 0) | (kinds == 1)) and np.all(kinds.sum(axis=1) == 1)):
            raise ValueError("Joint Logistic instances require exactly one TSK indicator.")
        if np.any(np.bincount(self.chain_index, minlength=len(self.n)) == 0):
            raise ValueError("Every Chain needs at least one instance.")
        self.width = self.design.shape[1]
        self.design_basis, _ = _space(self.design)
        # Normalize source columns before SVD. A feature measured in tiny units
        # is not absent information and may require a very large coefficient.
        self._column_scale = np.linalg.norm(self.design, axis=0)
        self._column_scale[self._column_scale == 0] = 1.
        self._scaled_design_basis, scaled_transform = _space(self.design / self._column_scale)
        self._design_transform = scaled_transform / self._column_scale[:, None]
        digest = hashlib.sha256()
        for value in (self.design, self.chain_index.astype(float), self.n, self.k, np.array([self.type_count])):
            digest.update(str(value.shape).encode("ascii"))
            digest.update(np.ascontiguousarray(value, dtype="<f8").tobytes())
        self._fingerprint = digest.hexdigest()
        self.state = None
        self._profile_cache, self._identified_cache = {}, {}
        self._last_progress = monotonic()

    def _progress(self, phase, **values):
        now = monotonic()
        if self.progress_callback is not None and now - self._last_progress > 1.:
            self._last_progress = now
            self.progress_callback({"phase": phase, **values})

    def _query(self, vector):
        vector = np.asarray(vector, dtype=float)
        if vector.shape != (self.width,) or not np.all(np.isfinite(vector)):
            raise ValueError("Invalid joint Logistic contrast.")
        indicators = vector[:self.type_count]
        if np.count_nonzero(indicators) != 1 or np.max(indicators) != 1.:
            raise ValueError("A probability query must select exactly one TSK.")
        return vector

    def _evaluate(self, theta, zero_rows=None, *, hessian=False):
        logits = self.design @ theta
        if zero_rows is not None:
            logits = logits.copy()
            logits[zero_rows] = -math.inf
        probability = expit(logits)
        hazards = np.bincount(self.chain_index, weights=np.logaddexp(0., logits), minlength=len(self.n))
        predicted = -np.expm1(-hazards)
        positive = self.k > 0
        derivative = np.zeros((len(self.n), self.width))
        np.add.at(derivative, self.chain_index, probability[:, None] * self.design)
        if np.any(hazards[positive] <= 0) or not np.all(np.isfinite(hazards)):
            return math.inf, np.full(self.width, math.nan), predicted, derivative, None
        slope = self.n - self.k
        slope = slope.copy()
        loss = float(slope @ hazards)
        slope[positive] -= self.k[positive] * np.exp(-hazards[positive]) / predicted[positive]
        loss -= float(self.k[positive] @ np.log(predicted[positive]))
        gradient = derivative.T @ slope
        curvature = None
        if hessian:
            weights = np.zeros(len(self.n))
            weights[positive] = self.k[positive] * np.exp(-hazards[positive]) / predicted[positive] ** 2
            curvature = derivative.T @ (weights[:, None] * derivative)
            curvature += self.design.T @ ((slope[self.chain_index] * probability * (1 - probability))[:, None] * self.design)
        return loss, gradient, predicted, derivative, curvature

    def evaluate(self, params):
        """Evaluate the exact fitted face, using finite active-row coefficients."""
        theta = np.asarray(params, dtype=float)
        if theta.shape != (self.width,) or not np.all(np.isfinite(theta)):
            raise ValueError("Invalid joint Logistic coefficients.")
        if self.state is not None:
            # Avoid subtracting enormous compensating coefficients when the
            # caller passes the stored representative.
            if np.array_equal(theta, np.asarray(self.state["coefficients"])):
                theta = np.asarray(self.state["core_coefficients"])
            zero = np.asarray(self.state["zero_rows"], dtype=int)
        else:
            zero = None
        return self._evaluate(theta, zero)[:4]

    def fitted_evaluation(self):
        if self.state is None:
            raise RuntimeError("Fit the joint Logistic model first.")
        return self.evaluate(self.state["coefficients"])

    def instance_hazards(self, params=None):
        if self.state is None:
            raise RuntimeError("Fit the joint Logistic model first.")
        theta = np.asarray(self.state["core_coefficients"] if params is None else params, dtype=float)
        if params is not None and np.array_equal(theta, self.state["coefficients"]):
            theta = np.asarray(self.state["core_coefficients"])
        if theta.shape != (self.width,) or not np.all(np.isfinite(theta)):
            raise ValueError("Invalid joint Logistic coefficients.")
        hazards = np.logaddexp(0., self.design @ theta)
        hazards[np.asarray(self.state["zero_rows"], dtype=int)] = 0.
        return hazards

    def _face(self, constraint=None):
        """Maximal removable set within the sufficient monotone recession cone."""
        transform = self._design_transform
        reduced = self.design @ transform
        norm = np.linalg.norm(reduced, axis=1)
        rows = reduced / np.maximum(norm[:, None], 1e-300)
        failed = self.k[self.chain_index] > 0
        equalities = rows[failed]
        if constraint is not None:
            extra = np.asarray(constraint) @ transform
            if np.linalg.norm(extra) > 1e-13:
                equalities = np.vstack([equalities, extra / np.linalg.norm(extra)])
        passed = rows[~failed]
        zero = np.zeros(len(self.design), dtype=bool)
        ray = np.zeros(transform.shape[1])
        if not len(passed) or not transform.shape[1]:
            return zero, transform @ ray
        pending = np.ones(len(passed), dtype=bool)
        for _ in range(len(passed) + 1):
            if not np.any(pending):
                break
            result = linprog(passed[pending].sum(axis=0), A_ub=passed, b_ub=np.zeros(len(passed)),
                             A_eq=equalities if len(equalities) else None,
                             b_eq=np.zeros(len(equalities)) if len(equalities) else None,
                             bounds=[(-1., 1.)] * transform.shape[1], method="highs")
            if not result.success:
                raise RuntimeError("Joint monotone-face linear program failed.")
            movement = passed @ result.x
            if np.max(movement, initial=0.) > 1e-7 or (len(equalities) and np.max(np.abs(equalities @ result.x)) > 1e-7):
                raise RuntimeError("Joint monotone-face certificate is numerically infeasible.")
            removed = pending & (movement < -1e-8)
            if not np.any(removed):
                break
            ray += result.x
            pending[removed] = False
        zero[np.flatnonzero(~failed)[~pending]] = True
        full_ray = transform @ ray
        if np.any(zero):
            # Refine away equality roundoff before making a finite representative.
            retained = reduced[~zero]
            if constraint is not None:
                retained = np.vstack([retained, np.asarray(constraint) @ transform])
            active_basis, _ = _space(retained)
            ray -= active_basis @ (active_basis.T @ ray)
            full_ray = transform @ ray
            movement = self.design @ full_ray
            if np.max(movement[zero]) >= -1e-10:
                raise RuntimeError("Joint face does not retain a strict recession certificate.")
            full_ray /= -float(np.max(movement[zero]))
            retained_movement = self.design[~zero] @ full_ray
            if (np.max(np.abs(retained_movement), initial=0.) > 1e-7
                    or (constraint is not None and abs(float(np.asarray(constraint) @ full_ray)) > 1e-7)):
                raise RuntimeError("Joint recession normalization changed a retained constraint.")
        return zero, full_ray

    def _loss_change(self, new, old, zero):
        return self._loss_difference(new, zero, old, zero)

    def _loss_difference(self, new, new_zero, old, old_zero):
        new_h = np.bincount(self.chain_index, weights=np.where(new_zero, 0., np.logaddexp(0., self.design @ new)), minlength=len(self.n))
        old_h = np.bincount(self.chain_index, weights=np.where(old_zero, 0., np.logaddexp(0., self.design @ old)), minlength=len(self.n))
        if np.any(new_h[self.k > 0] <= 0):
            return math.inf
        change = new_h - old_h
        value = float((self.n - self.k) @ change)
        use = self.k > 0
        with np.errstate(over="ignore", divide="ignore", invalid="ignore"):
            log_ratio = np.log1p(np.exp(-old_h[use]) * -np.expm1(-change[use]) / -np.expm1(-old_h[use]))
        bad = ~np.isfinite(log_ratio)
        if np.any(bad):
            log_ratio[bad] = np.log(-np.expm1(-new_h[use][bad])) - np.log(-np.expm1(-old_h[use][bad]))
        return value - float(self.k[use] @ log_ratio)

    def _upper_recession(self, zero, transform):
        """Reject sufficient upper separation outside this zero-face closure."""
        all_fail = (self.n[self.chain_index] == self.k[self.chain_index]) & ~zero
        if not np.any(all_fail) or not transform.shape[1]:
            return False
        rows = self.design @ transform
        rows /= np.maximum(np.linalg.norm(rows, axis=1)[:, None], 1e-300)
        upper = rows[all_fail]
        fixed = rows[~all_fail & ~zero]
        result = linprog(-upper.sum(axis=0), A_ub=-upper, b_ub=np.zeros(len(upper)),
                         A_eq=fixed if len(fixed) else None, b_eq=np.zeros(len(fixed)) if len(fixed) else None,
                         bounds=[(-1., 1.)] * transform.shape[1], method="highs")
        if not result.success:
            raise RuntimeError("Joint upper-recession linear program failed.")
        return bool(result.fun < -1e-8)

    def _optimize(self, start, zero, offset, transform):
        columns = self.design @ transform
        # Retained fitted columns are orthonormal. Work in logits instead of
        # solving in raw coefficient units, which can differ by many orders.
        coords = columns[~zero].T @ (self.design @ (np.asarray(start) - offset))[~zero]
        bound = max(self.coefficient_bound, 45.) * math.sqrt(max(len(self.design), 1))
        bound = max(bound, float(np.max(np.abs(coords), initial=0.)) * 1.2 + 1.)
        trace = []
        upper_recession = self._upper_recession(zero, transform)
        if not len(coords):
            loss, gradient, predicted, J, _ = self._evaluate(offset, zero)
            return {"core": offset.copy(), "minimum": loss, "predicted": predicted, "converged": math.isfinite(loss), "score": 0., "stages": []}

        def objective(value):
            evaluation = self._evaluate(offset + transform @ value, zero)
            return evaluation[0], transform.T @ evaluation[1]

        def scaled_score(value):
            _, gradient, _, J, _ = self._evaluate(offset + transform @ value, zero)
            local = J @ transform
            exposure = np.maximum(np.abs(local).T @ self.n, 1.)
            return float(np.max(np.abs(transform.T @ gradient) / exposure, initial=0.))

        if not math.isfinite(objective(coords)[0]):
            coords = np.zeros_like(coords)
        if not math.isfinite(objective(coords)[0]):
            core = offset + transform @ coords
            return {"core": core, "minimum": math.inf, "predicted": self._evaluate(core, zero)[2],
                    "converged": False, "score": math.inf, "stages": [{"reason": "nonfinite_profile_start"}]}
        touched = False
        for expansion in range(4):
            fit = minimize(objective, coords, jac=True, method="L-BFGS-B", bounds=[(-bound, bound)] * len(coords),
                           options={"ftol": 1e-14, "gtol": 1e-10, "maxiter": 1500, "maxls": 50})
            if math.isfinite(fit.fun):
                coords = fit.x.copy()
            # Newton polishing compares differences of chain log likelihoods,
            # so an enormous constant NLL does not swallow small improvements.
            for _ in range(35):
                theta = offset + transform @ coords
                loss, gradient, _, _, hessian = self._evaluate(theta, zero, hessian=True)
                if hessian is None:
                    break
                g, H = transform.T @ gradient, transform.T @ hessian @ transform
                if not np.all(np.isfinite(H)):
                    break
                try:
                    eig, rotation = np.linalg.eigh(H)
                except np.linalg.LinAlgError:
                    break
                floor = max(float(np.max(np.abs(eig), initial=0.)) * 1e-10, 1e-12)
                direction = -rotation @ ((rotation.T @ g) / np.maximum(eig, floor))
                if not np.all(np.isfinite(direction)) or g @ direction >= 0:
                    break
                if np.max(np.abs(direction), initial=0.) < 1e-10:
                    break
                step = 1.
                for _ in range(40):
                    candidate = np.clip(coords + step * direction, -bound, bound)
                    if self._loss_change(offset + transform @ candidate, theta, zero) <= 1e-11:
                        coords = candidate
                        break
                    step *= .5
                else:
                    break
                if scaled_score(coords) < 1e-10:
                    break
            touched = bool(np.max(np.abs(coords), initial=0.) > bound * .99)
            trace.append({"search_radius": bound, "optimizer_success": bool(fit.success), "iterations": int(fit.nit),
                          "score_residual": scaled_score(coords), "search_radius_reached": touched})
            if not touched:
                break
            bound *= 4
        core = offset + transform @ coords
        loss, _, predicted, _, H = self._evaluate(core, zero, hessian=True)
        score = scaled_score(coords)
        # Very small probabilities alone are not a stationarity certificate.
        # Reject unresolved active saturation, including unsupported zero risks
        # within a Fail-containing Chain. Coefficients themselves are unbounded.
        active_logits = (self.design @ core)[~zero]
        exposure = self.n[self.chain_index[~zero]]
        tails = (((active_logits < -20.) & (exposure * expit(active_logits) < 1e-6))
                 | ((active_logits > 20.) & (exposure * expit(-active_logits) < 1e-6)))
        retained = self.design[~zero] @ self._design_transform
        supported_basis, _ = _space(retained[~tails])
        # A tiny probability at an extreme x can be pinned by ordinary x rows.
        # It is unresolved extra directions, not numerical tail values, that
        # indicate a boundary outside the supported monotone face.
        saturated = any(not _contained(row, supported_basis) for row in retained[tails])
        curvature = transform.T @ H @ transform if H is not None else np.full((1, 1), math.nan)
        eigen = np.linalg.eigvalsh(curvature) if np.all(np.isfinite(curvature)) else np.array([-math.inf])
        negative_curvature = float(np.min(eigen, initial=0.)) < -1e-7 * max(float(np.max(np.abs(eigen), initial=0.)), 1.)
        return {"core": core, "minimum": loss, "predicted": predicted, "score": score,
                "converged": bool(math.isfinite(loss) and score < 1e-8 and not touched and not saturated and not negative_curvature and not upper_recession),
                "active_saturation": saturated, "upper_recession": upper_recession,
                "negative_curvature": negative_curvature, "stages": trace}

    def _solve(self, starts, constraint=None):
        zero, ray = self._face(None if constraint is None else constraint[0])
        full_transform = self._design_transform
        if constraint is None:
            offset = np.zeros(self.width)
            nuisance = np.eye(full_transform.shape[1])
        else:
            vector, logit = constraint
            contrast = vector @ full_transform
            offset = full_transform @ (contrast * logit / float(contrast @ contrast))
            nuisance = null_space(contrast[None, :])
        projected = self.design[~zero] @ full_transform @ nuisance
        _, reduced_transform = _space(projected, absolute_tolerance=max(self.design.shape) * np.finfo(float).eps * 100)
        transform = full_transform @ nuisance @ reduced_transform
        candidates = []
        for index, start in enumerate(starts):
            self._progress("joint_logistic_start", start_index=index + 1)
            candidates.append(self._optimize(start, zero, offset, transform))
        finite = [item for item in candidates if math.isfinite(item["minimum"])]
        if not finite:
            raise RuntimeError("No finite joint Logistic likelihood candidate.")
        best = finite[0]
        for candidate in finite[1:]:
            if self._loss_change(candidate["core"], best["core"], zero) < -1e-10:
                best = candidate
        # Prefer a validated equally good point over an optimizer failure.
        accepted = [item for item in finite if item["converged"] and self._loss_change(item["core"], best["core"], zero) <= 1e-8]
        if accepted:
            best = accepted[0]
        return best, candidates, zero, ray

    def _starts(self, initial, *, profiles=False):
        rate = np.clip(self.k.sum() / self.n.sum(), 1e-7, 1 - 1e-7)
        multiplicity = max(float(len(self.design)) / len(self.n), 1.)
        component = -math.expm1(math.log1p(-rate) / multiplicity)
        baseline = np.r_[np.full(self.type_count, math.log(component) - math.log1p(-component)), np.zeros(self.width - self.type_count)]
        starts = [np.asarray(initial).copy(), baseline]
        # Opposite perturbations expose symmetric alternate allocations, which
        # a local Jacobian alone cannot exclude in this nonlinear likelihood.
        rng = np.random.default_rng(1079)
        for _ in range(1 if profiles else 2):
            movement = self._design_transform @ (rng.normal(size=self._design_transform.shape[1]) * math.sqrt(len(self.design)) * 2.)
            starts.extend([baseline + movement, baseline - movement])
        return starts

    def fit(self, logit_start):
        start = np.asarray(logit_start, dtype=float)
        if start.shape != (self.width,) or not np.all(np.isfinite(start)):
            raise ValueError("Joint boundary fitting needs finite initial logits.")
        best, candidates, zero, ray = self._solve(self._starts(start))
        core = best["core"]
        representative = core.copy()
        if np.any(zero):
            movement = self.design @ ray
            target = max(60., math.log(max(float(self.n.sum()), 1.)) + 35.)
            distance = float(np.max(((self.design @ core)[zero] + target) / -movement[zero]))
            representative += max(distance, 0.) * ray
        if not np.all(np.isfinite(representative)):
            raise RuntimeError("Joint Logistic face has no stable finite serialization representative.")
        equivalent = [item["core"] for item in candidates if item["converged"] and self._loss_change(item["core"], core, zero) <= 1e-7]
        reasons = [] if best["converged"] else ["joint_finite_face_stationarity_not_established"]
        if best.get("active_saturation"):
            reasons.append("unsupported_active_instance_recession")
        if best.get("upper_recession"):
            reasons.append("unsupported_positive_instance_recession")
        self.state = _plain({"version": 1, "parameterization": "joint_logistic_face", "model_fingerprint": self._fingerprint,
                            "type_count": self.type_count, "coefficient_bound": self.coefficient_bound,
                            "coefficients": representative, "params": representative, "core_coefficients": core,
                            "recession_direction": ray, "zero_rows": np.flatnonzero(zero), "active_rows": np.flatnonzero(~zero),
                            "minimum": best["minimum"], "predicted": best["predicted"], "converged": best["converged"],
                            "equivalent_core_coefficients": equivalent,
                            "trace": {"starts": candidates, "finite_representative_maximum": float(np.max(np.abs(representative)))},
                            "validation": {"reason_codes": reasons, "score_residual": best["score"], "score_threshold": 1e-8,
                                           "monotone_face_certified": True, "identifiability_scope": "sufficient monotone face, local Chain Jacobian, multistart and nuisance profile probes; not a global uniqueness proof"}})
        self._setup_geometry()
        return self.state

    def _setup_geometry(self):
        self._profile_cache.clear()
        self._identified_cache.clear()
        zero = np.zeros(len(self.design), dtype=bool)
        zero[np.asarray(self.state["zero_rows"], dtype=int)] = True
        self._zero = zero
        self._active_basis, _ = _space(self.design[~zero] @ self._design_transform)
        J = self._evaluate(np.asarray(self.state["core_coefficients"]), zero)[3]
        J = J @ self._design_transform
        norms = np.linalg.norm(J, axis=1)
        self._information_basis, _ = _space(J[norms > 0] / norms[norms > 0, None])

    def load_state(self, state):
        if (not isinstance(state, dict) or state.get("version") != 1 or state.get("parameterization") != "joint_logistic_face"
                or state.get("type_count") != self.type_count or state.get("model_fingerprint") != self._fingerprint):
            raise ValueError("Unsupported or stale joint Logistic boundary state.")
        arrays = {}
        for key in ("coefficients", "core_coefficients", "recession_direction"):
            arrays[key] = np.asarray(state.get(key), dtype=float)
            if arrays[key].shape != (self.width,) or not np.all(np.isfinite(arrays[key])):
                raise ValueError("Invalid stored joint Logistic coefficients.")
        zero, ray = self._face()
        stored_zero = np.asarray(state.get("zero_rows"), dtype=int)
        if not np.array_equal(stored_zero, np.flatnonzero(zero)):
            raise ValueError("Stored joint Logistic face does not match its model.")
        if not np.array_equal(np.asarray(state.get("active_rows"), dtype=int), np.flatnonzero(~zero)):
            raise ValueError("Invalid joint Logistic active rows.")
        if np.any(zero):
            movement = self.design @ arrays["recession_direction"]
            if np.max(movement[zero]) >= -1e-9 or np.max(np.abs(movement[~zero]), initial=0.) > 1e-7:
                raise ValueError("Invalid stored joint Logistic recession certificate.")
        if np.max(np.abs(self.design[~zero] @ (arrays["coefficients"] - arrays["core_coefficients"])), initial=0.) > 1e-6:
            raise ValueError("Finite joint representative changes the retained likelihood.")
        minimum, _, predicted, _, _ = self._evaluate(arrays["core_coefficients"], zero)
        stored_minimum = state.get("minimum")
        if (not isinstance(stored_minimum, (float, int)) or not math.isfinite(float(stored_minimum))
                or abs(minimum - stored_minimum) > max(1e-7, abs(minimum) * 1e-12)
                or np.asarray(state.get("predicted")).shape != predicted.shape
                or not np.allclose(state["predicted"], predicted, rtol=1e-9, atol=1e-12)):
            raise ValueError("Stored joint Logistic likelihood is inconsistent.")
        equivalents = state.get("equivalent_core_coefficients", [])
        for equivalent in equivalents:
            equivalent = np.asarray(equivalent, dtype=float)
            if equivalent.shape != (self.width,) or not np.all(np.isfinite(equivalent)) or abs(self._loss_change(equivalent, arrays["core_coefficients"], zero)) > 1e-6:
                raise ValueError("Invalid stored joint Logistic alternate optimum.")
        self.state = _plain(dict(state))
        self._setup_geometry()
        # A snapshot's Boolean does not substitute for current stationarity.
        if self.state.get("converged"):
            _, retained_transform = _space(self.design[~zero] @ self._design_transform)
            checked = self._optimize(arrays["core_coefficients"], zero, np.zeros(self.width), self._design_transform @ retained_transform)
            if not checked["converged"] or self._loss_change(checked["core"], arrays["core_coefficients"], zero) < -1e-7:
                raise ValueError("Stored joint Logistic fit fails current stationarity checks.")
        return self

    def _kind(self, vector):
        if self.state is None or not self.state.get("converged") or not _contained(vector / self._column_scale, self._scaled_design_basis):
            return "unidentifiable"
        if _contained(vector @ self._design_transform, self._active_basis):
            return "interior"
        if not np.any(self._zero):
            return "unidentifiable"
        transform = self._design_transform
        contrast = vector @ transform
        contrast /= max(np.linalg.norm(contrast), 1e-300)
        retained = self.design[~self._zero] @ transform
        removed = self.design[self._zero] @ transform
        removed /= np.maximum(np.linalg.norm(removed, axis=1)[:, None], 1e-300)
        if len(retained):
            retained /= np.maximum(np.linalg.norm(retained, axis=1)[:, None], 1e-300)
        arguments = dict(A_ub=removed, b_ub=np.zeros(len(removed)), A_eq=retained if len(retained) else None,
                         b_eq=np.zeros(len(retained)) if len(retained) else None,
                         bounds=[(-1., 1.)] * transform.shape[1], method="highs")
        low, high = linprog(contrast, **arguments), linprog(-contrast, **arguments)
        # Both signs are tested over the entire face cone. The direction used
        # for serialization never establishes a query's risk.
        if low.success and high.success and low.fun < -1e-7 and -high.fun <= 1e-8:
            return "zero_boundary"
        return "unidentifiable"

    def estimate_kind(self, vector):
        kind = self._kind(self._query(vector))
        return "boundary_low" if kind == "zero_boundary" else kind

    def _profile_logit(self, vector, logit):
        key = (tuple(vector), float(logit))
        if key in self._profile_cache:
            return self._profile_cache[key]
        starts = self._starts(np.asarray(self.state["coefficients"]), profiles=True)
        nearby = [(abs(value - logit), result[1]) for (query, value), result in self._profile_cache.items() if query == tuple(vector)]
        if nearby:
            starts.insert(0, min(nearby, key=lambda item: item[0])[1])
        best, _, zero, _ = self._solve(starts, (vector, logit))
        difference = self._loss_difference(best["core"], zero, np.asarray(self.state["core_coefficients"]), self._zero)
        if difference < -1e-7:
            self.state["converged"] = False
            self.state["validation"]["reason_codes"].append("joint_profile_found_better_optimum")
            self._identified_cache.clear()
            raise JointBoundaryBetterOptimumError("Joint profile found a better likelihood than the stored fit.")
        if not best["converged"]:
            raise RuntimeError("Joint profile nuisance stationarity was not established.")
        result = (max(difference, 0.), best["core"], zero)
        self._profile_cache[key] = result
        return result

    def identifiable(self, params, vector):
        vector = self._query(vector)
        if self.state is None or not np.array_equal(np.asarray(params), np.asarray(self.state["coefficients"])):
            return False
        key = tuple(vector)
        if key in self._identified_cache:
            return self._identified_cache[key]
        kind = self._kind(vector)
        identified = kind != "unidentifiable"
        core = np.asarray(self.state["core_coefficients"])
        if kind == "interior":
            identified = _contained(vector @ self._design_transform, self._information_basis)
            for alternate in self.state.get("equivalent_core_coefficients", []):
                if abs(float(vector @ (np.asarray(alternate) - core))) > 1e-4:
                    identified = False
        if identified:
            try:
                if kind == "zero_boundary":
                    # Directly observed all-Pass combinations have a strictly
                    # positive likelihood penalty at every positive query risk.
                    matching = np.all(np.isclose(self.design, vector, rtol=0., atol=1e-12), axis=1)
                    if not np.any(matching):
                        exposure = max(float(self.n.sum()), 1.)
                        p = max(1e-5, min(.01, 2. / exposure))
                        identified = self._profile_logit(vector, math.log(p) - math.log1p(-p))[0] > 1e-8
                else:
                    logit = float(vector @ core)
                    identified = all(self._profile_logit(vector, logit + step)[0] > 1e-8 for step in (-.25, .25))
            except JointBoundaryBetterOptimumError:
                raise
            except (ValueError, RuntimeError, FloatingPointError, np.linalg.LinAlgError):
                identified = False
        self._identified_cache[key] = bool(identified)
        return bool(identified)

    def probability(self, params, vector):
        vector = self._query(vector)
        if not self.identifiable(params, vector):
            return math.nan
        return 0. if self._kind(vector) == "zero_boundary" else float(expit(vector @ np.asarray(self.state["core_coefficients"])))

    def coefficient_identifiable(self, index):
        if not 0 <= int(index) < self.width or self.state is None or not self.state.get("converged"):
            return False
        vector = np.eye(self.width)[int(index)]
        if (not _contained(vector / self._column_scale, self._scaled_design_basis)
                or not _contained(vector @ self._design_transform, self._active_basis)
                or not _contained(vector @ self._design_transform, self._information_basis)):
            return False
        core = np.asarray(self.state["core_coefficients"])
        return all(abs(float(vector @ (np.asarray(other) - core))) <= 1e-4 for other in self.state.get("equivalent_core_coefficients", []))

    def _exact_zero_upper(self, vector, confidence):
        matching = np.all(np.isclose(self.design, vector, rtol=0., atol=1e-12), axis=1)
        copies = np.bincount(self.chain_index, weights=matching.astype(float), minlength=len(self.n))
        selected = copies > 0
        if not np.any(selected) or np.any(self.k[selected] > 0):
            return None
        exposure = float(self.n @ copies)
        counts = np.bincount(self.chain_index, minlength=len(self.n))
        pure = bool(np.all(copies[selected] == counts[selected]))
        return 0., -math.expm1(math.log1p(-confidence) / exposure), EXACT_METHOD if pure else CONSERVATIVE_EXACT_METHOD

    def profile_interval(self, params, vector, confidence):
        if not 0 < confidence < 1:
            raise ValueError("Confidence level must lie between zero and one.")
        vector = self._query(vector)
        if not self.identifiable(params, vector):
            raise RuntimeError("Requested joint Logistic risk is not independently estimable.")
        estimate = self.probability(params, vector)
        if estimate == 0.:
            exact = self._exact_zero_upper(vector, confidence)
            if exact is not None:
                return exact
        cutoff = float(chi2.ppf(confidence, 1)) / 2
        centre = float(vector @ np.asarray(self.state["core_coefficients"])) if estimate else -35.

        def objective(logit):
            return self._profile_logit(vector, float(logit))[0] - cutoff

        if estimate:
            # The fitted face itself is an admissible constrained nuisance fit.
            self._profile_cache[(tuple(vector), centre)] = (0., np.asarray(self.state["core_coefficients"]), self._zero.copy())
        else:
            # A derived zero contrast may approach zero much faster than an
            # observed instance. Find an interior LR bracket rather than using
            # the historical coefficient bound as an implicit risk floor.
            for step in (0., 16., 32., 64., 128., 256.):
                centre -= step
                if objective(centre) < 0:
                    break
            else:
                raise RuntimeError("Joint zero profile has no stable lower likelihood bracket.")
        upper = centre
        for step in (1., 2., 4., 8., 16., 32., 64.):
            upper = centre + step
            if objective(upper) > 0:
                upper = float(expit(brentq(objective, centre, upper, xtol=1e-8)))
                break
        else:
            raise RuntimeError("Joint profile has no certified upper likelihood crossing.")
        lower = 0.
        if estimate:
            for step in (1., 2., 4., 8., 16., 32., 64.):
                endpoint = centre - step
                if objective(endpoint) > 0:
                    lower = float(expit(brentq(objective, endpoint, centre, xtol=1e-8)))
                    break
            else:
                raise RuntimeError("Joint profile has no certified lower likelihood crossing.")
        return lower, upper, BOUNDARY_METHOD if estimate == 0 else INTERIOR_METHOD
