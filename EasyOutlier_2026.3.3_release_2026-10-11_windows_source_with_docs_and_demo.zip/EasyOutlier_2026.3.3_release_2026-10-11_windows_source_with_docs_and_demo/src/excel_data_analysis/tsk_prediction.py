"""Conditional category predictions from a frozen TSK likelihood fit.

The query is read-only: it does not classify measurements, reload a template,
or refit the unconstrained model. Confidence limits profile the original chain
likelihood; category contrasts use its joint expected information matrix.
"""

from __future__ import annotations

import math
import time
from itertools import product
from typing import Any, Callable, Mapping, Sequence

import numpy as np
from scipy.optimize import brentq
from scipy.special import expit
from scipy.stats import chi2, norm

from .tsk_analysis import _feature_loss_and_derivative, _minimize_bound_constrained, _plain
from .tsk_features import ALL_CATEGORY_COMBINATIONS, category_combination_label, category_label
from .tsk_sorting import natural_sort_key
from .tsk_parallel import ordered_parallel_map, validate_analysis_workers, worker_count
from .tsk_spatial import DEFAULT_XY_MODEL, validate_spatial_transform


PROBABILITY_INTERVAL_METHOD = "profile_likelihood_approximate_linear_contrast"
DELTA_INTERVAL_METHOD = "joint_expected_information_delta_method_pointwise"


def _row_basis_and_singular(matrix: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Return the row-space basis and its singular values from one factorization."""
    if not matrix.size:
        return np.zeros((matrix.shape[1], 0)), np.empty(0)
    _, singular, right = np.linalg.svd(matrix, full_matrices=False)
    tolerance = max(matrix.shape) * np.finfo(float).eps * singular[0] * 100
    retained = singular > tolerance
    return right[retained].T, singular[retained]


def _row_basis(matrix: np.ndarray) -> np.ndarray:
    """Return orthonormal columns spanning the parameter-space row space."""
    return _row_basis_and_singular(matrix)[0]


def _in_row_space(vector: np.ndarray, basis: np.ndarray) -> bool:
    residual = vector - basis @ (basis.T @ vector)
    return bool(np.linalg.norm(residual) <= 1e-7 * max(np.linalg.norm(vector), 1e-15))


class _FrozenFit:
    def __init__(self, context: Mapping[str, Any]):
        if context.get("version") != 1 or context.get("model") != "instance_logistic_features":
            raise ValueError("Unsupported TSK prediction context; rerun the analysis with Logistic. "
                             "Stored parameters from a removed model cannot be reused.")
        self.context = context
        if context.get("spatial_transform"):
            validate_spatial_transform(context["spatial_transform"])
        elif context.get("xy_model") == DEFAULT_XY_MODEL and context.get("converged"):
            raise ValueError("The frozen spatial fit is missing its XY transform; rerun the analysis.")
        self.interval_method = PROBABILITY_INTERVAL_METHOD
        self.design = np.asarray(context["design"], dtype=float)
        self.chain_index = np.asarray(context["chain_index"], dtype=int)
        self.n = np.asarray(context["n_tested"], dtype=float)
        self.k = np.asarray(context["n_failed"], dtype=float)
        self.theta = np.asarray(context["coefficients"], dtype=float)
        self.boundary_engine = None
        self.joint_engine = None
        self.minimum = float(context["negative_log_likelihood"])
        self.width = len(self.theta)
        self.progress_callback = None
        self._last_progress = time.monotonic()
        if not len(self.n) and not self.design.size:
            self.design = np.empty((0, self.width))
        if (self.design.ndim != 2 or self.design.shape[1] != self.width
                or self.chain_index.shape != (len(self.design),) or self.n.shape != self.k.shape
                or len(self.n) != len(context["chain_ids"]) or (not len(self.n) and context.get("converged"))
                or np.any(self.chain_index < 0) or np.any(self.chain_index >= len(self.n))
                or np.any(self.n <= 0) or np.any(self.k < 0) or np.any(self.k > self.n)
                or not all(np.all(np.isfinite(value)) for value in (self.design, self.n, self.k, self.theta))
                or not math.isfinite(self.minimum)):
            raise ValueError("The TSK prediction context contains invalid fitted arrays or counts.")
        boundary_state = context.get("boundary_fit")
        joint_state = context.get("joint_boundary_fit")
        if boundary_state is not None and joint_state is not None:
            raise ValueError("A fitted context cannot contain two different boundary parameterizations.")
        if joint_state is not None:
            from .tsk_logistic_joint_boundary import JointLogisticBoundaryFit
            self.joint_engine = JointLogisticBoundaryFit(
                self.design, self.chain_index, self.n, self.k, len(context["type_ids"]),
                coefficient_bound=float(context.get("logistic_coefficient_bound", 35.)))
            self.joint_engine.load_state(joint_state)
            if (not np.allclose(self.theta, joint_state["coefficients"], rtol=0., atol=1e-10)
                    or abs(self.minimum - joint_state["minimum"]) > max(
                        1e-8, abs(self.minimum) * 64 * np.finfo(float).eps)):
                raise ValueError("The joint boundary context disagrees with its saved likelihood or coefficients.")
            self.design_basis = _row_basis(self.design)
            self.interval_method = "profile_likelihood_approximate_joint_logistic_boundary"
        elif boundary_state is not None:
            from .tsk_logistic_boundary import LogisticBoundaryFit
            self.boundary_engine = LogisticBoundaryFit(
                self.design, self.chain_index, self.n, self.k, len(context["type_ids"]),
                coefficient_bound=float(context.get("logistic_coefficient_bound", 35.)))
            self.boundary_engine.load_state(boundary_state)
            self.design_basis = self.boundary_engine.design_basis
            self.theta = np.asarray(boundary_state["params"], dtype=float)
            self.interval_method = "profile_likelihood_approximate_odds_contrast"
        else:
            self.design_basis = _row_basis(self.design)
            self._derivative_index = (
                self.chain_index[:, None] * self.width + np.arange(self.width)[None, :]
            ).ravel()
        _, _, predicted, derivative = self.evaluate(self.theta)
        self.derivative = derivative
        self._identified_queries = {}
        self.likelihood_basis = _row_basis(derivative)
        if self.joint_engine is not None:
            self.boundary = True
            q = predicted
            survival = 1. - q
        elif self.boundary_engine is not None:
            self.boundary = bool(boundary_state["zero_type_indices"])
            q = predicted
            survival = 1. - q
        else:
            instance_hazards = np.logaddexp(0, self.design @ self.theta)
            self.boundary = False
            hazards = np.bincount(self.chain_index, weights=np.maximum(instance_hazards, 0.), minlength=len(self.n))
            q = -np.expm1(-hazards)
            survival = np.exp(-hazards)
        weights = np.divide(self.n * survival, q, out=np.zeros_like(q), where=q > 0)
        weighted_derivative = np.sqrt(weights)[:, None] * derivative
        self.information_basis, singular = _row_basis_and_singular(weighted_derivative)
        scaled_basis = self.information_basis / singular
        self.covariance = scaled_basis @ scaled_basis.T
        if self.joint_engine is not None:
            # Only likelihood-profile risk inference is supported for this
            # parameterization. A finite representative must not generate
            # ordinary Wald intervals for diverging/compensating coefficients.
            self.information_basis = np.zeros((self.width, 0))
            self.covariance = np.zeros((self.width, self.width))
        if self.joint_engine is not None:
            valid_parameterization = joint_state.get("converged")
        elif self.boundary_engine is not None:
            valid_parameterization = boundary_state.get("converged") and not boundary_state.get("feature_clipped")
        else:
            valid_parameterization = not context.get("clipped")
        self.valid_fit = bool(context.get("converged") and valid_parameterization)
        self.last_interval_method = self.interval_method

    def _heartbeat(self):
        now = time.monotonic()
        if self.progress_callback is not None and now - self._last_progress >= 1.:
            self._last_progress = now
            self.progress_callback()

    def evaluate(self, theta):
        if self.joint_engine is not None:
            return self.joint_engine.evaluate(theta)
        if self.boundary_engine is not None:
            return self.boundary_engine.evaluate(theta)
        return _feature_loss_and_derivative(
            self.design, self.chain_index, self.n, self.k, theta, self._derivative_index)

    def probability(self, vector):
        if not self.identifiable(vector):
            return None
        if self.joint_engine is not None:
            return self.joint_engine.probability(self.theta, vector)
        if self.boundary_engine is not None:
            return self.boundary_engine.probability(self.theta, vector)
        value = float(vector @ self.theta)
        return float(expit(value))

    def probability_gradient(self, probability, vector):
        if self.boundary_engine is not None:
            return self.boundary_engine.probability_gradient(self.theta, vector)
        return probability * (1 - probability) * vector

    def estimate_kind(self, vector):
        if self.joint_engine is not None and vector is not None:
            return self.joint_engine.estimate_kind(vector)
        if self.boundary_engine is not None and vector is not None:
            index = int(np.argmax(vector[:self.boundary_engine.type_count]))
            if self.theta[index] == 0:
                return "boundary_low"
        return "interior"

    def identifiable(self, vector):
        if vector is None or not self.valid_fit:
            return False
        key = tuple(vector)
        if key not in self._identified_queries:
            self._identified_queries[key] = self._query_identifiable(vector)
        return self._identified_queries[key]

    def _query_identifiable(self, vector):
        if self.joint_engine is not None:
            return bool(self.valid_fit and vector is not None
                        and self.joint_engine.identifiable(self.theta, vector))
        if self.boundary_engine is not None:
            return bool(self.valid_fit and vector is not None and _in_row_space(vector, self.design_basis)
                        and self.boundary_engine.identifiable(self.theta, vector))
        identified = (self.valid_fit and vector is not None
                      and _in_row_space(vector, self.design_basis)
                      and _in_row_space(vector, self.likelihood_basis))
        return identified

    def profile_interval(self, vector: np.ndarray, confidence: float) -> tuple[float, float]:
        """Profile eta=r theta after removing only exact design-null directions."""
        if self.joint_engine is not None:
            low, high, self.last_interval_method = self.joint_engine.profile_interval(self.theta, vector, confidence)
            return low, high
        if self.boundary_engine is not None:
            low, high, self.last_interval_method = self.boundary_engine.profile_interval(self.theta, vector, confidence)
            return low, high
        reduced = self.design_basis.T @ vector
        length = float(np.linalg.norm(reduced))
        if length <= 1e-12:
            raise RuntimeError("The requested logit contrast has no estimable direction.")
        direction = reduced / length
        # eta is the first coordinate of this orthogonal parameterization;
        # every nuisance direction is free. No individual alpha must be fixed.
        _, _, orthogonal = np.linalg.svd(direction[None, :], full_matrices=True)
        nuisance_basis = self.design_basis @ orthogonal[1:].T
        eta_direction = self.design_basis @ direction / length
        initial = nuisance_basis.T @ self.theta
        estimate = float(vector @ self.theta)
        cutoff = self.minimum + float(chi2.ppf(confidence, 1)) / 2
        cache: dict[float, float] = {}

        def objective(eta):
            key = float(eta)
            if key in cache:
                return cache[key]
            offset = eta_direction * eta

            def nuisance_objective(values):
                self._heartbeat()
                value, gradient, _, _ = self.evaluate(offset + nuisance_basis @ values)
                return value, nuisance_basis.T @ gradient

            if initial.size:
                fit, converged = _minimize_bound_constrained(
                    nuisance_objective, initial, float(self.n.sum()), -math.inf)
                if not converged:
                    raise RuntimeError("Profile nuisance optimization did not converge.")
                value = float(fit.fun)
            else:
                value = float(nuisance_objective(initial)[0])
            if not math.isfinite(value):
                raise RuntimeError("Profile likelihood became non-finite.")
            if value < self.minimum - max(1e-5, abs(self.minimum) * 1e-8):
                raise RuntimeError("Profile found a better optimum than the stored fit.")
            cache[key] = value - cutoff
            return cache[key]

        variance = float(vector @ self.covariance @ vector)
        step = max(.5, float(norm.ppf((1 + confidence) / 2)) * math.sqrt(max(variance, 0.)))

        def endpoint(sign):
            # Finite numerical limits correspond to probability 0/1 if the
            # likelihood-ratio cutoff is never crossed toward that boundary.
            boundary = min(-40., estimate - 40.) if sign < 0 else max(40., estimate + 40.)
            distance = step
            while True:
                candidate = max(boundary, estimate - distance) if sign < 0 else min(boundary, estimate + distance)
                if objective(candidate) >= 0:
                    lo, hi = sorted((estimate, candidate))
                    eta = brentq(objective, lo, hi, xtol=1e-8)
                    return float(expit(eta))
                if candidate == boundary:
                    return 0. if sign < 0 else 1.
                distance *= 2

        return endpoint(-1), endpoint(1)


def _combination_vector(width, key):
    if key is None:
        return None
    vector = np.zeros(width)
    vector[list(key)] = 1.
    return vector


def _prepare_combination_queries(common):
    context, confidence = common
    return _FrozenFit(context), confidence


def _combination_query_task(common, key, heartbeat):
    """One unique condition, with both profile endpoints kept in one worker."""
    fit, confidence = common
    fit.progress_callback = heartbeat
    if fit.joint_engine is not None:
        fit.joint_engine.progress_callback = lambda *_: fit._heartbeat()
    if fit.boundary_engine is not None:
        fit.boundary_engine.progress_callback = lambda _: fit._heartbeat()
    try:
        heartbeat()
        vector = _combination_vector(fit.width, key)
        probability = fit.probability(vector)
        result = {"probability": probability, "interval": (None, None, None, None)}
        if probability is not None:
            try:
                lower, upper = fit.profile_interval(vector, confidence)
                result["interval"] = (lower, upper, fit.last_interval_method, None)
            except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                if getattr(error, "invalidates_fit", False):
                    raise
                result["interval"] = (None, None, None, str(error) or type(error).__name__)
        return result
    finally:
        fit.progress_callback = None
        if fit.joint_engine is not None:
            fit.joint_engine.progress_callback = None
        if fit.boundary_engine is not None:
            fit.boundary_engine.progress_callback = None


def predict_tsk_combinations(
    context: Mapping[str, Any], *, dimension: str,
    fixed_categories: Mapping[str, Any] | None = None,
    reference_level: Any | None = None,
    tsk_ids: Sequence[str] | None = None,
    extrapolate: bool = True,
    analysis_workers: int = 0,
    progress_callback: Callable[[int, str], None] | None = None,
) -> dict[str, Any]:
    """Predict a category slice or every categorical combination for each TSK.

    Numeric fields stay at the frozen fit's layout means. Support counts refer
    to the exact categorical combination, not to an exact numeric mean value.
    Chain test exposure counts each matching active chain once, even if that
    chain contains several matching instances. Intervals are pointwise. With
    extrapolation disabled, combinations without active data remain blank and
    cannot serve as the reference for probability differences.
    """
    if not isinstance(context, Mapping):
        raise ValueError("A categorical TSK prediction context is required.")
    validate_analysis_workers(analysis_workers)
    categorical = context.get("categorical_features", {})
    all_combinations = dimension == ALL_CATEGORY_COMBINATIONS
    if not categorical or (not all_combinations and dimension not in categorical):
        raise ValueError(f"{dimension!r} is not a categorical dimension in this fitted model.")
    fixed = dict(fixed_categories or {})
    if all_combinations and fixed:
        raise ValueError("All categorical combinations cannot also have fixed categories.")
    if dimension in fixed:
        raise ValueError("The displayed dimension cannot also be a fixed category.")
    unknown = set(fixed) - set(categorical)
    if unknown:
        raise ValueError("Unknown fixed categorical dimensions: " + ", ".join(sorted(unknown)))
    # Stored fits can retain their original coefficient order. Sort only the
    # default display order; vector_for still uses the frozen type indices.
    all_types = sorted(context["all_type_ids"], key=natural_sort_key)
    selected_types = all_types if tsk_ids is None else list(dict.fromkeys(tsk_ids))
    if not selected_types or any(value not in all_types for value in selected_types):
        raise ValueError("Select one or more TSK IDs present in the fitted topology.")
    if all_combinations:
        combinations = [dict(zip(categorical, values))
                        for values in product(*(encoding["levels"] for encoding in categorical.values()))]
        levels = [category_combination_label(categories) for categories in combinations]
        reference = (str(reference_level) if reference_level is not None else
                     category_combination_label({name: encoding["reference"] for name, encoding in categorical.items()}))
    else:
        for name, encoding in categorical.items():
            if name == dimension:
                continue
            fixed[name] = category_label(fixed.get(name, encoding["reference"]), name)
            if fixed[name] not in encoding["levels"]:
                raise ValueError(f"Unknown category {fixed[name]!r} for {name!r}.")
        levels = list(categorical[dimension]["levels"])
        combinations = [{**fixed, dimension: level} for level in levels]
        reference = category_label(reference_level if reference_level is not None
                                   else categorical[dimension]["reference"], dimension)
    if reference not in levels:
        raise ValueError(f"Unknown reference category {reference!r} for {dimension!r}.")
    categories_by_level = dict(zip(levels, combinations))
    confidence = float(context["confidence_level"])
    if not 0 < confidence < 1:
        raise ValueError("The stored confidence level must be strictly between 0 and 1.")
    fit = _FrozenFit(context)
    progress = progress_callback or (lambda *_: None)
    progress(0, "Computing conditional TSK category combinations")
    type_index = {name: index for index, name in enumerate(context["type_ids"])}
    chain_n = dict(zip(context["chain_ids"], context["n_tested"]))
    warnings = [
        "Predictions are conditional on numeric layout means and the selected categories; they are not observed instance Fail rates or causal effects.",
        "Intervals are pointwise and assume independent chain observations; shared die/wafer effects are not included.",
        "Probability limits use profile likelihood; probability-difference limits use a joint-information normal approximation, not subtraction of endpoint limits.",
    ]
    warnings.append("Identifiability includes a local likelihood-Jacobian check; the feature fit does not guarantee a globally unique optimum.")
    if fit.boundary_engine is not None:
        warnings.append("Zero-boundary probabilities use a nonnegative-odds fit with constrained identifiability checks. "
                        "Zero estimates do not guarantee zero true risk; exact/conservative and approximate upper limits are labelled separately.")
    if fit.joint_engine is not None:
        warnings.append("TSK intercepts and shared effects retain their joint compensation at the likelihood boundary. "
                        "Each condition is checked separately; a zero prediction for one condition is not assigned "
                        "to every instance of the same TSK or feature level. Coefficient representatives are not finite effects.")
    if not fit.valid_fit:
        warnings.append("The stored feature fit did not establish a stable finite optimum; predictions are withheld.")
    if not extrapolate:
        warnings.append("Combinations without active observed categorical support are left blank; their model extrapolations and reference contrasts are withheld.")
    rows = []
    # Scan the layout once, instead of once per type/category cell. Numeric
    # means are prediction conditions, not categorical-support restrictions.
    supports = {}
    category_names = tuple(categorical)
    for entry in context["topology"]:
        categories = entry["categories"]
        if categories.keys() != categorical.keys():
            continue
        key = (entry["tsk_id"], tuple(categories[name] for name in category_names))
        support = supports.setdefault(key, {"layout": 0, "active": 0, "chains": set()})
        support["layout"] += 1
        if entry["chain_id"] in chain_n:
            support["active"] += 1
            support["chains"].add(entry["chain_id"])
    for support in supports.values():
        support["exposure"] = int(sum(chain_n[chain_id] for chain_id in support["chains"]))
    empty_support = {"layout": 0, "active": 0, "chains": set(), "exposure": 0}
    total = len(selected_types) * len(levels)
    current_progress, current_message = 0, "Preparing conditional category combinations"
    last_sent, last_time = 0, time.monotonic()

    def emit(value, message, *, force=False):
        nonlocal current_progress, current_message, last_sent, last_time
        current_progress, current_message = int(value), message
        now = time.monotonic()
        if force or current_progress != last_sent or now - last_time >= 1.:
            progress(current_progress, message)
            last_sent, last_time = current_progress, now

    # Category columns do not depend on the TSK. Compact column-index tuples
    # identify exact full vectors without retaining a dense vector per cell.
    category_columns = {
        level: tuple(index for index, (name, value) in enumerate(
            context["coefficient_columns"], start=len(type_index))
            if value is not None and categories_by_level[level][name] == value)
        for level in levels
    }

    def key_for(tsk_id, level):
        index = type_index.get(tsk_id)
        return None if index is None else (index, *category_columns[level])

    def support_for(tsk_id, level):
        categories = categories_by_level[level]
        support = supports.get((tsk_id, tuple(categories[name] for name in category_names)), empty_support)
        no_data = not len(fit.n) or (not extrapolate and not support["active"])
        return support, no_data

    jobs = {}
    if fit.valid_fit:
        for type_position, tsk_id in enumerate(selected_types):
            for level_position, level in enumerate(levels):
                _, no_data = support_for(tsk_id, level)
                key = key_for(tsk_id, level)
                if not no_data and key is not None:
                    jobs.setdefault(key, (tsk_id, level))
            emit(5 * (type_position + 1) / len(selected_types), "Indexing supported TSK category combinations")
    emit(5, "Prepared unique TSK category conditions")
    keys = list(jobs)
    query_results = {}
    execution = {"workers_requested": int(analysis_workers), "workers_used": 1,
                 "execution_backend": "serial", "execution_warnings": [],
                 "unique_queries": len(keys), "grid_cells": total}
    selected_workers = worker_count(analysis_workers, len(keys))
    completed = 0
    started = time.monotonic()
    # Small or mostly unsupported grids stay local. The completed pilot queries
    # become ordinary results, and are never submitted again to the process pool.
    while completed < len(keys):
        if analysis_workers and selected_workers > 1:
            break
        key = keys[completed]
        tsk_id, level = jobs[key]
        description = level if all_combinations else f"{dimension}={level}"
        emit(5 + 85 * completed / len(keys), f"Computing interval for TSK {tsk_id}, {description}")
        query_results[key] = _combination_query_task((fit, confidence), key,
            lambda: emit(current_progress, current_message))
        completed += 1
        emit(5 + 85 * completed / len(keys), f"Computed TSK {tsk_id}, {description}")
        remaining = len(keys) - completed
        elapsed = time.monotonic() - started
        if (analysis_workers == 0 and selected_workers > 1 and remaining >= 8
                and elapsed >= .25 and elapsed * remaining / completed >= 2.):
            selected_workers = min(4, worker_count(0, remaining))
            break
    if completed < len(keys):
        parallel_execution = {}
        last_backend_state = None

        def combination_progress(done, count):
            nonlocal last_backend_state
            backend = parallel_execution.get("execution_backend")
            workers = parallel_execution.get("workers_used", selected_workers)
            phase = parallel_execution.get("phase", "starting")
            if backend == "serial_after_process_failure":
                state = "子进程失败，已退回串行"
            elif backend == "serial":
                state = "串行计算"
            elif phase == "starting":
                state = f"启动 {workers} 个计算进程／等待首个结果"
            else:
                observed = parallel_execution.get("workers_observed", 0)
                state = f"{workers} 进程并行，已有 {observed} 个进程返回结果"
            changed = state != last_backend_state
            last_backend_state = state
            emit(5 + 85 * (completed + done) / len(keys),
                 f"TSK：{state}；组合概率与区间已完成 {completed + done}/{len(keys)}…", force=changed)
        # Workers never need the potentially large topology/support table.
        fitted_context = {key: value for key, value in context.items() if key != "topology"}
        computed = ordered_parallel_map(_combination_query_task, keys[completed:],
            common=(fitted_context, confidence), prepare_common=_prepare_combination_queries,
            workers=selected_workers, execution=parallel_execution,
            progress_callback=combination_progress)
        query_results.update(zip(keys[completed:], computed))
        execution.update(parallel_execution, workers_requested=int(analysis_workers), pilot_queries=completed)
        warnings.extend(execution["execution_warnings"])
    emit(90, "Assembling conditional TSK category results")
    unavailable = {"probability": None, "interval": (None, None, None, None)}
    delta_cutoff = float(norm.ppf((1 + confidence) / 2))
    # Reference points/gradients are reused for every comparison of this type.
    # Equal probabilities (especially zero) never merge different query vectors.
    for type_position, tsk_id in enumerate(selected_types):
        _, reference_no_data = support_for(tsk_id, reference)
        reference_key = key_for(tsk_id, reference)
        reference_vector = _combination_vector(fit.width, reference_key)
        reference_estimate = (None if reference_no_data else
                              query_results.get(reference_key, unavailable)["probability"])
        reference_gradient = (None if reference_estimate is None else
                              fit.probability_gradient(reference_estimate, reference_vector))
        for level_position, level in enumerate(levels):
            categories = categories_by_level[level]
            category_description = level if all_combinations else f"{dimension}={level}"
            key = key_for(tsk_id, level)
            vector = _combination_vector(fit.width, key)
            support, no_data = support_for(tsk_id, level)
            support_status = ("observed" if support["active"] else "no_active_support"
                              if support["layout"] else "extrapolated")
            cached = query_results.get(key, unavailable)
            probability = None if no_data else cached["probability"]
            reference_probability = None if no_data else reference_estimate
            cell_progress = 90 + 10 * (type_position * len(levels) + level_position) / total
            row = {
                "tsk_id": tsk_id, "level": level, "categories": categories,
                "probability": probability, "ci_lower": None, "ci_upper": None,
                "identifiable": probability is not None,
                "status": ("no_data" if no_data else "ok" if probability is not None
                           else "not_identifiable" if fit.valid_fit else "fit_not_converged"),
                "interval_method": None, "interval_error": None,
                "estimate_kind": fit.estimate_kind(vector) if probability is not None else None,
                "interval_sidedness": ("upper" if probability is not None and fit.estimate_kind(vector) == "boundary_low" else
                                       "lower" if probability is not None and fit.estimate_kind(vector) == "boundary_high" else "two_sided"),
                "confidence_level": confidence,
                "layout_instance_count": support["layout"], "active_instance_count": support["active"],
                "chain_count": len(support["chains"]), "chain_test_exposure": support["exposure"],
                "support_status": support_status,
                "reference_probability": reference_probability,
                "delta_probability": None, "delta_ci_lower": None, "delta_ci_upper": None,
                "delta_interval_method": None, "delta_interval_error": None,
                "delta_status": "no_data" if no_data or reference_no_data else "not_identifiable",
            }
            if probability is not None:
                if row["estimate_kind"] in {"boundary_low", "boundary_high"}:
                    row["status"] = row["estimate_kind"]
                row["ci_lower"], row["ci_upper"], row["interval_method"], row["interval_error"] = cached["interval"]
                if row["interval_error"] is not None:
                    row["status"] = "interval_unavailable"
                    warnings.append(f"TSK {tsk_id}, {category_description}: probability interval unavailable ({row['interval_error']}).")
            if probability is not None and reference_probability is not None:
                difference = probability - reference_probability
                gradient = (fit.probability_gradient(probability, vector)
                            - reference_gradient)
                row["delta_probability"] = difference
                if np.array_equal(vector, reference_vector):
                    row.update(delta_ci_lower=0., delta_ci_upper=0.,
                               delta_interval_method=DELTA_INTERVAL_METHOD, delta_status="ok")
                elif not fit.boundary and _in_row_space(gradient, fit.information_basis):
                    variance = float(gradient @ fit.covariance @ gradient)
                    half_width = delta_cutoff * math.sqrt(max(variance, 0.))
                    row.update(delta_ci_lower=max(-1., difference - half_width),
                               delta_ci_upper=min(1., difference + half_width),
                               delta_interval_method=DELTA_INTERVAL_METHOD,
                               delta_status="ok")
                else:
                    row["delta_status"] = ("boundary_interval_unavailable"
                                           if fit.boundary
                                           else "interval_unavailable")
                    row["delta_interval_error"] = (
                        "The Logistic fit has active zero-risk boundaries; the normal-approximation difference interval is unavailable."
                        if fit.boundary else
                        "The probability-difference gradient is not identifiable from the joint expected information.")
            rows.append(row)
            emit(cell_progress + 10 / total, f"Computed TSK {tsk_id}, {category_description}")
    emit(100, "Computed all conditional TSK category combinations", force=True)
    return _plain({
        "dimension": dimension, "levels": levels, "fixed_categories": fixed,
        "categorical_dimensions": list(categorical), "extrapolate": bool(extrapolate),
        "reference_level": reference, "numeric_reference": dict(context.get("numeric_reference", {})),
        "confidence_level": confidence, "rows": rows, "warnings": warnings,
        "parallel_execution": execution,
        "probability_interval_method": fit.interval_method,
        "delta_interval_method": DELTA_INTERVAL_METHOD,
        "model_scope": "Shared categorical main effects; no TSK-by-category or category-by-category interactions.",
    })
