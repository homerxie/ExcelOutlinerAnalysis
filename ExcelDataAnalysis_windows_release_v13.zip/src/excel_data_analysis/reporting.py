from __future__ import annotations

import json
import re
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .analyzer import evaluate_against_golden, evaluate_modified_zscore
from .io import extract_dimension_rows, load_table, to_float
from .models import (
    AnomalyResult,
    GoldenReference,
    MeasurementRecord,
    OutlierRatioStatConfig,
    TemplateConfig,
    ThresholdConfig,
)
from .output_paths import resolve_output_path
from .template import load_template


HEADER_FILL = PatternFill("solid", fgColor="D9E2F3")
SUBHEADER_FILL = PatternFill("solid", fgColor="EAF2F8")
FAIL_FONT = Font(color="9C0006", bold=True)
HEADER_FONT = Font(bold=True)
THIN_BORDER = Border(
    left=Side(style="thin", color="000000"),
    right=Side(style="thin", color="000000"),
    top=Side(style="thin", color="000000"),
    bottom=Side(style="thin", color="000000"),
)
CENTER = Alignment(horizontal="center", vertical="center")
PERCENT_FORMAT_2 = "0.00%"
DECIMAL_FORMAT_3 = "0.000"


@dataclass(slots=True)
class ColumnMeta:
    raw_column: str
    logical_metric: str
    group_id: str
    group_display_name: str
    header_values: list[str]
    unit: str | None
    display_order: int

    @property
    def chain_name(self) -> str:
        return self.header_values[0] if self.header_values else ""

    @property
    def test_type(self) -> str:
        return self.header_values[1] if len(self.header_values) > 1 else ""


@dataclass(slots=True)
class RowData:
    dataset_id: str
    source_file: str
    row_number: int
    dimensions: dict[str, str]
    values: dict[str, float]


@dataclass(slots=True)
class MetricValue:
    value: float | None
    threshold: float | None
    golden_value: float | None
    is_fail: bool


MetricKey = tuple[str, int, str]


def _emit_progress(callback: Any | None, value: int, message: str) -> None:
    if callback is None:
        return
    callback(value, message)


def _measurement_key(measurement: MeasurementRecord) -> MetricKey:
    return (measurement.dataset_id, measurement.row_number, measurement.raw_column)


def _anomaly_key(anomaly: AnomalyResult) -> MetricKey:
    return (anomaly.dataset_id, anomaly.row_number, anomaly.raw_column)


def _row_metric_key(row: RowData, raw_column: str) -> MetricKey:
    return (row.dataset_id, row.row_number, raw_column)


def _sample_dimension_names(template: TemplateConfig) -> list[str]:
    values = [
        str(value).strip()
        for value in template.report.sample_dimension_names
        if str(value).strip()
    ]
    if not values:
        raise ValueError(
            "report.sample_dimension_names must be configured in the template."
        )
    return values


def _sample_dimension_label(template: TemplateConfig) -> str:
    names = _sample_dimension_names(template)
    labels: list[str] = []
    for target_name in names:
        for dimension in _ordered_row_dimensions(template):
            if dimension.name == target_name:
                labels.append(dimension.display_name or dimension.name)
                break
        else:
            labels.append(target_name)
    return " + ".join(labels)


def _sample_key_from_dimensions(
    dimensions: dict[str, str],
    sample_dimension_names: list[str],
) -> tuple[str, ...]:
    return tuple(str(dimensions.get(name, "") or "") for name in sample_dimension_names)


def _sample_key_display(sample_key: tuple[str, ...]) -> str:
    return " | ".join(sample_key)


def _sample_key_sort_key(sample_key: tuple[str, ...]) -> tuple[Any, ...]:
    return tuple(_natural_sort_key(value) for value in sample_key)


def generate_chip_report(
    template_path: str | Path,
    input_path: str | Path,
    output_path: str | Path,
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
    if_exists: str = "overwrite",
    progress_callback: Any | None = None,
) -> dict[str, Any]:
    resolved_output_path = resolve_output_path(output_path, if_exists=if_exists)
    resolved_output_path.parent.mkdir(parents=True, exist_ok=True)
    _emit_progress(progress_callback, 5, "Loading template...")
    template = load_template(template_path)
    _emit_progress(progress_callback, 15, "Reading input workbook...")
    table = load_table(input_path, template=template)
    _emit_progress(progress_callback, 25, "Building measurement records...")
    measurements = _build_measurements(template, table.rows, input_path)
    _emit_progress(progress_callback, 35, "Building row view...")
    row_data = _build_rows(template, table.rows, input_path)
    _emit_progress(progress_callback, 45, "Resolving test columns...")
    columns = _build_columns(template, table.units, table.headers)
    return _generate_chip_report_from_prebuilt(
        template=template,
        source_label=str(Path(input_path).resolve()),
        output_path=resolved_output_path,
        measurements=measurements,
        row_data=row_data,
        columns=columns,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
        progress_callback=progress_callback,
    )


def generate_chip_report_from_measurements(
    template_path: str | Path,
    measurements: list[MeasurementRecord],
    output_path: str | Path,
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
    source_label: str | None = None,
    if_exists: str = "overwrite",
    progress_callback: Any | None = None,
) -> dict[str, Any]:
    resolved_output_path = resolve_output_path(output_path, if_exists=if_exists)
    resolved_output_path.parent.mkdir(parents=True, exist_ok=True)
    _emit_progress(progress_callback, 10, "Loading template...")
    template = load_template(template_path)
    _emit_progress(progress_callback, 25, "Building row view from database measurements...")
    row_data = _build_rows_from_measurements(measurements)
    _emit_progress(progress_callback, 40, "Resolving test columns...")
    columns = _build_columns(template, {}, [])
    resolved_source_label = source_label or "database-scope"
    return _generate_chip_report_from_prebuilt(
        template=template,
        source_label=resolved_source_label,
        output_path=resolved_output_path,
        measurements=measurements,
        row_data=row_data,
        columns=columns,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
        progress_callback=progress_callback,
    )


def _generate_chip_report_from_prebuilt(
    template: TemplateConfig,
    source_label: str,
    output_path: str | Path,
    measurements: list[MeasurementRecord],
    row_data: list[RowData],
    columns: list[ColumnMeta],
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
    progress_callback: Any | None = None,
) -> dict[str, Any]:
    _emit_progress(progress_callback, 55, "Calculating Z Score deviations...")
    sample_node_orders = _build_sample_node_orders(row_data, template)
    row_data.sort(key=lambda item: _row_sort_key(item, template, sample_node_orders))

    zscore_values = _build_zscore_map(
        measurements,
        template.report.zscore_thresholds,
        columns,
        zscore_threshold_override=zscore_threshold_override,
    )
    _emit_progress(progress_callback, 65, "Calculating golden deviations...")
    golden_values = _build_report_golden_values(
        measurements,
        template,
        columns,
        built_golden_path=built_golden_path,
    )
    golden_header_values = _build_column_display_values(golden_values, "golden_value")
    golden_threshold_values = _build_column_display_values(golden_values, "threshold")
    zscore_threshold_values = _build_column_display_values(zscore_values, "threshold")

    _emit_progress(progress_callback, 72, "Writing Sorted sheet...")
    workbook = Workbook()
    workbook.remove(workbook.active)
    _write_sorted_sheet(
        workbook.create_sheet("Sorted"),
        template,
        columns,
        row_data,
        golden_header_values,
    )
    if built_golden_path and _has_variable_metric_attribute(golden_values, "golden_value"):
        _emit_progress(progress_callback, 76, "Writing golden-by-point sheet...")
        _write_point_golden_sheet(
            workbook.create_sheet("golden-by-point"),
            template,
            columns,
            row_data,
            golden_values,
            golden_header_values,
        )
    _emit_progress(progress_callback, 80, "Writing Z Score sheet...")
    _write_metric_sheet(
        workbook.create_sheet("deviation-zscore"),
        template,
        columns,
        row_data,
        zscore_values,
        zscore_threshold_values,
        golden_header_values,
        "Z Threshold",
        value_number_format=DECIMAL_FORMAT_3,
        threshold_number_format=DECIMAL_FORMAT_3,
    )
    _emit_progress(progress_callback, 84, "Writing Golden Deviation sheet...")
    _write_metric_sheet(
        workbook.create_sheet("deviation-golden"),
        template,
        columns,
        row_data,
        golden_values,
        golden_threshold_values,
        golden_header_values,
        "Deviation Threshold",
        value_number_format=PERCENT_FORMAT_2,
        threshold_number_format=PERCENT_FORMAT_2,
    )
    _emit_progress(progress_callback, 88, "Building outlier summary...")
    summary_artifacts = _collect_outlier_summary_artifacts(
        template,
        columns,
        row_data,
        zscore_values,
        golden_values,
        sample_node_orders,
        outlier_fail_method_override=outlier_fail_method_override,
    )
    summary_rows = summary_artifacts["summary_rows"]
    ratio_rows = summary_artifacts["ratio_rows"]
    _emit_progress(progress_callback, 92, "Writing outliers sheet...")
    _write_outlier_sheet(
        workbook.create_sheet("outliers"),
        template,
        columns,
        row_data,
        zscore_values,
        golden_values,
        golden_header_values,
        sample_node_orders,
        summary_rows,
        outlier_fail_method_override=outlier_fail_method_override,
    )
    _emit_progress(progress_callback, 96, "Writing Outlier Summary sheet...")
    _write_summary_sheet(
        workbook.create_sheet("Outlier Summary"),
        template,
        summary_rows,
        ratio_rows,
        sample_node_orders,
    )
    _emit_progress(progress_callback, 99, "Saving workbook...")
    workbook.save(output_path)

    failing_samples = sorted(
        {item["sample_id"] for item in summary_rows},
        key=_natural_sort_key,
    )
    return {
        "input": source_label,
        "output": str(Path(output_path).resolve()),
        "row_count": len(row_data),
        "measurement_count": len(measurements),
        "outlier_sample_count": len(failing_samples),
        "outlier_event_count": len(summary_rows),
    }


def collect_report_failures(
    template_path: str | Path,
    input_path: str | Path,
    built_golden_path: str | Path | None = None,
    zscore_threshold_override: float | None = None,
) -> list[AnomalyResult]:
    template = load_template(template_path)
    table = load_table(input_path, template=template)
    measurements = _build_measurements(template, table.rows, input_path)
    columns = _build_columns(template, table.units, table.headers)
    zscore_values = _build_zscore_map(
        measurements,
        template.report.zscore_thresholds,
        columns,
        zscore_threshold_override=zscore_threshold_override,
    )
    golden_values = _build_report_golden_values(
        measurements,
        template,
        columns,
        built_golden_path=built_golden_path,
    )

    failures: list[AnomalyResult] = []
    for measurement in measurements:
        key = _measurement_key(measurement)
        z_entry = zscore_values.get(key)
        if z_entry and z_entry.is_fail:
            failures.append(
                AnomalyResult(
                    method="modified_z_score",
                    dataset_id=measurement.dataset_id,
                    source_file=measurement.source_file,
                    row_number=measurement.row_number,
                    logical_metric=measurement.logical_metric,
                    raw_column=measurement.raw_column,
                    value=measurement.value,
                    dimensions=measurement.dimensions,
                    center=None,
                    score=z_entry.value,
                    reason=(
                        "Absolute modified z-score exceeded configured threshold "
                        f"{z_entry.threshold}."
                    ),
                )
            )
        golden_entry = golden_values.get(key)
        if golden_entry and golden_entry.is_fail:
            failures.append(
                AnomalyResult(
                    method="golden_deviation",
                    dataset_id=measurement.dataset_id,
                    source_file=measurement.source_file,
                    row_number=measurement.row_number,
                    logical_metric=measurement.logical_metric,
                    raw_column=measurement.raw_column,
                    value=measurement.value,
                    dimensions=measurement.dimensions,
                    center=golden_entry.golden_value,
                    score=golden_entry.value,
                    reason=(
                        "Golden deviation exceeded configured threshold "
                        f"{golden_entry.threshold}."
                    ),
                )
            )
    return failures


def collect_outlier_summary_rows(
    template_path: str | Path,
    input_path: str | Path,
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
) -> list[dict[str, str]]:
    return collect_outlier_summary_artifacts(
        template_path,
        input_path,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
    )["summary_rows"]


def collect_outlier_ratio_rows(
    template_path: str | Path,
    input_path: str | Path,
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
) -> list[dict[str, Any]]:
    return collect_outlier_summary_artifacts(
        template_path,
        input_path,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
    )["ratio_rows"]


def collect_outlier_summary_artifacts(
    template_path: str | Path,
    input_path: str | Path,
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
    progress_callback: Any | None = None,
) -> dict[str, list[dict[str, Any]]]:
    _emit_progress(progress_callback, 5, "Loading template for outlier summary...")
    template = load_template(template_path)
    _emit_progress(progress_callback, 20, "Reading input workbook for outlier summary...")
    table = load_table(input_path, template=template)
    _emit_progress(progress_callback, 35, "Building measurement records for outlier summary...")
    measurements = _build_measurements(template, table.rows, input_path)
    _emit_progress(progress_callback, 50, "Building row view for outlier summary...")
    row_data = _build_rows(template, table.rows, input_path)
    _emit_progress(progress_callback, 65, "Resolving test columns for outlier summary...")
    columns = _build_columns(template, table.units, table.headers)
    return _collect_outlier_summary_artifacts_from_prebuilt(
        template,
        measurements,
        row_data,
        columns,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
        progress_callback=progress_callback,
    )


def collect_outlier_summary_rows_from_measurements(
    template_path: str | Path,
    measurements: list[MeasurementRecord],
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
) -> list[dict[str, str]]:
    return collect_outlier_summary_artifacts_from_measurements(
        template_path,
        measurements,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
    )["summary_rows"]


def collect_outlier_ratio_rows_from_measurements(
    template_path: str | Path,
    measurements: list[MeasurementRecord],
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
) -> list[dict[str, Any]]:
    return collect_outlier_summary_artifacts_from_measurements(
        template_path,
        measurements,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
    )["ratio_rows"]


def collect_outlier_summary_artifacts_from_measurements(
    template_path: str | Path,
    measurements: list[MeasurementRecord],
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
    progress_callback: Any | None = None,
) -> dict[str, list[dict[str, Any]]]:
    _emit_progress(progress_callback, 10, "Loading template for outlier summary...")
    template = load_template(template_path)
    _emit_progress(progress_callback, 35, "Building row view from database measurements...")
    row_data = _build_rows_from_measurements(measurements)
    _emit_progress(progress_callback, 55, "Resolving test columns for outlier summary...")
    columns = _build_columns(template, {}, [])
    return _collect_outlier_summary_artifacts_from_prebuilt(
        template,
        measurements,
        row_data,
        columns,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
        progress_callback=progress_callback,
    )


def _collect_outlier_summary_rows_from_prebuilt(
    template: TemplateConfig,
    measurements: list[MeasurementRecord],
    row_data: list[RowData],
    columns: list[ColumnMeta],
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
) -> list[dict[str, str]]:
    return _collect_outlier_summary_artifacts_from_prebuilt(
        template,
        measurements,
        row_data,
        columns,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
    )["summary_rows"]


def _collect_outlier_summary_artifacts_from_prebuilt(
    template: TemplateConfig,
    measurements: list[MeasurementRecord],
    row_data: list[RowData],
    columns: list[ColumnMeta],
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
    progress_callback: Any | None = None,
) -> dict[str, list[dict[str, Any]]]:
    _emit_progress(progress_callback, 70, "Calculating Z Score for outlier summary...")
    sample_node_orders = _build_sample_node_orders(row_data, template)
    row_data.sort(key=lambda item: _row_sort_key(item, template, sample_node_orders))
    zscore_values = _build_zscore_map(
        measurements,
        template.report.zscore_thresholds,
        columns,
        zscore_threshold_override=zscore_threshold_override,
    )
    _emit_progress(progress_callback, 82, "Calculating golden deviation for outlier summary...")
    golden_values = _build_report_golden_values(
        measurements,
        template,
        columns,
        built_golden_path=built_golden_path,
    )
    _emit_progress(progress_callback, 94, "Collecting outlier summary rows...")
    return _collect_outlier_summary_artifacts(
        template,
        columns,
        row_data,
        zscore_values,
        golden_values,
        sample_node_orders,
        outlier_fail_method_override=outlier_fail_method_override,
    )


def _build_measurements(
    template: TemplateConfig,
    rows: list[dict[str, Any]],
    input_path: str | Path,
) -> list[MeasurementRecord]:
    source_file = str(Path(input_path).resolve())
    measurements: list[MeasurementRecord] = []
    for row_number, row, dimensions in extract_dimension_rows(template, rows):
        for group in template.analysis_groups:
            for column in group.columns:
                if column.name not in row:
                    continue
                value = to_float(row.get(column.name), template.numeric_cleanup)
                if value is None:
                    continue
                logical_metric = (
                    group.id
                    if group.analysis_mode == "pooled_columns"
                    else f"{group.id}::{column.name}"
                )
                measurements.append(
                    MeasurementRecord(
                        dataset_id="ad-hoc-report",
                        source_file=source_file,
                        row_number=row_number,
                        logical_metric=logical_metric,
                        group_id=group.id,
                        group_display_name=group.display_name,
                        presentation_group=column.header_values[0] if column.header_values else None,
                        raw_column=column.name,
                        value=value,
                        dimensions=dimensions,
                    )
                )
    return measurements


def _build_rows(
    template: TemplateConfig,
    rows: list[dict[str, Any]],
    input_path: str | Path,
) -> list[RowData]:
    report_rows: list[RowData] = []
    source_file = str(Path(input_path).resolve())
    measurement_columns = {
        column.name
        for group in template.analysis_groups
        for column in group.columns
    }
    for row_number, row, dimensions in extract_dimension_rows(template, rows):
        values: dict[str, float] = {}
        for column in measurement_columns:
            if column not in row:
                continue
            value = to_float(row.get(column), template.numeric_cleanup)
            if value is not None:
                values[column] = value
        report_rows.append(
            RowData(
                dataset_id="ad-hoc-report",
                source_file=source_file,
                row_number=row_number,
                dimensions=dimensions,
                values=values,
            )
        )
    return report_rows


def _build_rows_from_measurements(measurements: list[MeasurementRecord]) -> list[RowData]:
    grouped: dict[tuple[str, str, int, tuple[tuple[str, str], ...]], RowData] = {}
    for item in measurements:
        dimension_key = tuple(sorted(item.dimensions.items()))
        row_key = (item.dataset_id, item.source_file, item.row_number, dimension_key)
        row = grouped.get(row_key)
        if row is None:
            row = RowData(
                dataset_id=item.dataset_id,
                source_file=item.source_file,
                row_number=item.row_number,
                dimensions=dict(item.dimensions),
                values={},
            )
            grouped[row_key] = row
        row.values[item.raw_column] = item.value
    return list(grouped.values())


def _build_columns(
    template: TemplateConfig,
    units: dict[str, str],
    headers: list[str],
) -> list[ColumnMeta]:
    header_set = set(headers)
    columns: list[ColumnMeta] = []
    display_order = 0
    for group in template.analysis_groups:
        for column in group.columns:
            if header_set and column.name not in header_set:
                continue
            logical_metric = (
                group.id
                if group.analysis_mode == "pooled_columns"
                else f"{group.id}::{column.name}"
            )
            columns.append(
                ColumnMeta(
                    raw_column=column.name,
                    logical_metric=logical_metric,
                    group_id=group.id,
                    group_display_name=group.display_name,
                    header_values=list(column.header_values),
                    unit=group.unit,
                    display_order=display_order,
                )
            )
            display_order += 1
    return sorted(
        columns,
        key=lambda item: (
            tuple(_natural_sort_key(value) for value in item.header_values),
            item.display_order,
        ),
    )


def _build_zscore_map(
    measurements: list[MeasurementRecord],
    thresholds: ThresholdConfig,
    columns: list[ColumnMeta],
    zscore_threshold_override: float | None = None,
) -> dict[MetricKey, MetricValue]:
    column_index = {item.raw_column: item for item in columns}
    evaluations = evaluate_modified_zscore(measurements)
    values: dict[MetricKey, MetricValue] = {}
    for entry in evaluations:
        meta = column_index.get(entry.raw_column)
        if meta is None:
            continue
        threshold = zscore_threshold_override
        if threshold is None:
            threshold = _resolve_threshold(
                thresholds,
                [entry.logical_metric, entry.raw_column, meta.group_id, meta.chain_name],
            )
        score = abs(entry.score) if entry.score is not None else 0.0
        values[_anomaly_key(entry)] = MetricValue(
            value=score,
            threshold=threshold,
            golden_value=None,
            is_fail=threshold is not None and abs(score) > threshold,
        )
    return values


def _build_golden_deviation_map(
    measurements: list[MeasurementRecord],
    template: TemplateConfig,
    columns: list[ColumnMeta],
) -> dict[MetricKey, MetricValue]:
    column_index = {item.raw_column: item for item in columns}
    values: dict[MetricKey, MetricValue] = {}
    for entry in measurements:
        meta = column_index.get(entry.raw_column)
        if meta is None:
            continue
        golden_value = _resolve_golden_value(
            template,
            [entry.logical_metric, entry.raw_column, entry.group_id, meta.chain_name],
        )
        threshold = _resolve_threshold(
            template.report.golden_deviation_thresholds,
            [entry.logical_metric, entry.raw_column, entry.group_id, meta.chain_name],
        )
        deviation: float | None = None
        is_fail = False
        if golden_value is not None:
            if golden_value == 0:
                deviation = entry.value - golden_value
            else:
                deviation = (entry.value - golden_value) / abs(golden_value)
            is_fail = threshold is not None and abs(deviation) > threshold
        values[_measurement_key(entry)] = MetricValue(
            value=deviation,
            threshold=threshold,
            golden_value=golden_value,
            is_fail=is_fail,
        )
    return values


def _build_built_golden_deviation_map(
    measurements: list[MeasurementRecord],
    golden_reference: GoldenReference,
) -> dict[MetricKey, MetricValue]:
    values: dict[MetricKey, MetricValue] = {}
    evaluations = evaluate_against_golden(measurements, golden_reference)
    for entry in evaluations:
        golden_value = entry.center
        deviation: float | None = None
        threshold: float | None = None
        if golden_value is not None:
            if golden_value == 0:
                deviation = entry.value - golden_value
                threshold = _resolve_built_absolute_threshold(entry)
            else:
                deviation = (entry.value - golden_value) / abs(golden_value)
                threshold = _resolve_built_relative_threshold(entry)
        values[_anomaly_key(entry)] = MetricValue(
            value=deviation,
            threshold=threshold,
            golden_value=golden_value,
            is_fail=entry.reason is not None,
        )
    return values


def _build_report_golden_values(
    measurements: list[MeasurementRecord],
    template: TemplateConfig,
    columns: list[ColumnMeta],
    built_golden_path: str | Path | None,
) -> dict[MetricKey, MetricValue]:
    if built_golden_path:
        golden_reference = GoldenReference.from_dict(
            json.loads(Path(built_golden_path).read_text(encoding="utf-8"))
        )
        return _build_built_golden_deviation_map(measurements, golden_reference)
    return _build_golden_deviation_map(measurements, template, columns)


def _column_header_labels(template: TemplateConfig) -> list[str]:
    return [item.name for item in sorted(template.column_header_levels, key=lambda item: item.priority)]


def _ordered_row_dimensions(template: TemplateConfig):
    return sorted(template.row_dimensions, key=lambda item: item.priority)


def _write_column_header_rows(
    worksheet,
    start_row: int,
    label_column: int,
    data_start_column: int,
    header_labels: list[str],
    columns: list[ColumnMeta],
) -> None:
    for level_index, label in enumerate(header_labels):
        worksheet.cell(start_row + level_index, label_column, label)
        for offset, column in enumerate(columns):
            worksheet.cell(
                start_row + level_index,
                data_start_column + offset,
                column.header_values[level_index],
            )


def _write_sorted_sheet(
    worksheet,
    template: TemplateConfig,
    columns: list[ColumnMeta],
    rows: list[RowData],
    golden_header_values: dict[str, Any],
) -> None:
    ordered_dimensions = _ordered_row_dimensions(template)
    dimension_labels = [item.display_name or item.name for item in ordered_dimensions]
    header_labels = _column_header_labels(template)
    label_column = len(dimension_labels)
    data_start_column = label_column + 1
    first_row = 1

    _write_column_header_rows(
        worksheet,
        first_row,
        label_column,
        data_start_column,
        header_labels,
        columns,
    )
    golden_row = first_row + len(header_labels)
    unit_row = golden_row + 1
    dimension_header_row = unit_row + 1
    worksheet.cell(golden_row, label_column, "Golden")
    for offset, column in enumerate(columns):
        cell_column = data_start_column + offset
        worksheet.cell(golden_row, cell_column, golden_header_values.get(column.raw_column))
        worksheet.cell(unit_row, cell_column, column.unit)

    for index, label in enumerate(dimension_labels, start=1):
        worksheet.cell(dimension_header_row, index, label)

    data_start_row = dimension_header_row + 1
    for row_offset, row in enumerate(rows):
        target_row = data_start_row + row_offset
        for index, dimension in enumerate(ordered_dimensions, start=1):
            worksheet.cell(
                target_row,
                index,
                _display_dimension_value(row.dimensions.get(dimension.name)),
            )
        for column_offset, column in enumerate(columns):
            worksheet.cell(target_row, data_start_column + column_offset, row.values.get(column.raw_column))

    _style_sheet(
        worksheet,
        header_rows=list(range(first_row, unit_row + 1)),
        dimension_header_row=dimension_header_row,
        start_column=label_column,
        end_column=data_start_column + len(columns) - 1,
        dimension_count=len(dimension_labels),
        table_start_row=first_row,
        table_end_row=data_start_row + len(rows) - 1,
    )
    _merge_column_header_rows(worksheet, first_row, data_start_column, columns, len(header_labels))
    _merge_dimension_values(worksheet, data_start_row, len(rows), template)
    _autosize_columns(worksheet)


def _write_metric_sheet(
    worksheet,
    template: TemplateConfig,
    columns: list[ColumnMeta],
    rows: list[RowData],
    values: dict[MetricKey, MetricValue],
    threshold_header_values: dict[str, Any],
    golden_header_values: dict[str, Any],
    threshold_label: str,
    value_number_format: str | None = None,
    threshold_number_format: str | None = None,
) -> None:
    ordered_dimensions = _ordered_row_dimensions(template)
    dimension_labels = [item.display_name or item.name for item in ordered_dimensions]
    header_labels = _column_header_labels(template)
    label_column = len(dimension_labels)
    data_start_column = label_column + 1

    _write_column_header_rows(
        worksheet,
        1,
        label_column,
        data_start_column,
        header_labels,
        columns,
    )
    threshold_row = 1 + len(header_labels)
    golden_row = threshold_row + 1
    unit_row = golden_row + 1
    dimension_header_row = unit_row + 1
    worksheet.cell(threshold_row, label_column, threshold_label)
    worksheet.cell(golden_row, label_column, "Golden")

    for offset, column in enumerate(columns):
        cell_column = data_start_column + offset
        threshold_cell = worksheet.cell(
            threshold_row,
            cell_column,
            threshold_header_values.get(column.raw_column),
        )
        if threshold_number_format and isinstance(threshold_cell.value, (int, float)):
            threshold_cell.number_format = threshold_number_format
        worksheet.cell(golden_row, cell_column, golden_header_values.get(column.raw_column))
        worksheet.cell(unit_row, cell_column, column.unit)

    for index, label in enumerate(dimension_labels, start=1):
        worksheet.cell(dimension_header_row, index, label)

    data_start_row = dimension_header_row + 1
    for row_offset, row in enumerate(rows):
        target_row = data_start_row + row_offset
        for index, dimension in enumerate(ordered_dimensions, start=1):
            worksheet.cell(
                target_row,
                index,
                _display_dimension_value(row.dimensions.get(dimension.name)),
            )
        for column_offset, column in enumerate(columns):
            entry = values.get(_row_metric_key(row, column.raw_column))
            cell = worksheet.cell(
                target_row,
                data_start_column + column_offset,
                entry.value if entry else None,
            )
            if entry and value_number_format and isinstance(cell.value, (int, float)):
                cell.number_format = value_number_format
            if entry and entry.is_fail:
                cell.font = FAIL_FONT

    _style_sheet(
        worksheet,
        header_rows=list(range(1, unit_row + 1)),
        dimension_header_row=dimension_header_row,
        start_column=label_column,
        end_column=data_start_column + len(columns) - 1,
        dimension_count=len(dimension_labels),
        table_start_row=1,
        table_end_row=data_start_row + len(rows) - 1,
    )
    _merge_column_header_rows(worksheet, 1, data_start_column, columns, len(header_labels))
    _merge_dimension_values(worksheet, data_start_row, len(rows), template)
    _autosize_columns(worksheet)


def _write_point_golden_sheet(
    worksheet,
    template: TemplateConfig,
    columns: list[ColumnMeta],
    rows: list[RowData],
    golden_values: dict[MetricKey, MetricValue],
    golden_header_values: dict[str, Any],
) -> None:
    ordered_dimensions = _ordered_row_dimensions(template)
    dimension_labels = [item.display_name or item.name for item in ordered_dimensions]
    header_labels = _column_header_labels(template)
    label_column = len(dimension_labels)
    data_start_column = label_column + 1
    first_row = 1

    worksheet.cell(first_row, 1, "Matched Built Golden For Each Data Point")
    header_start_row = first_row + 1
    _write_column_header_rows(
        worksheet,
        header_start_row,
        label_column,
        data_start_column,
        header_labels,
        columns,
    )
    golden_row = header_start_row + len(header_labels)
    unit_row = golden_row + 1
    dimension_header_row = unit_row + 1
    worksheet.cell(golden_row, label_column, "Golden")

    for offset, column in enumerate(columns):
        cell_column = data_start_column + offset
        worksheet.cell(golden_row, cell_column, golden_header_values.get(column.raw_column))
        worksheet.cell(unit_row, cell_column, column.unit)

    for index, label in enumerate(dimension_labels, start=1):
        worksheet.cell(dimension_header_row, index, label)

    data_start_row = dimension_header_row + 1
    for row_offset, row in enumerate(rows):
        target_row = data_start_row + row_offset
        for index, dimension in enumerate(ordered_dimensions, start=1):
            worksheet.cell(
                target_row,
                index,
                _display_dimension_value(row.dimensions.get(dimension.name)),
            )
        for column_offset, column in enumerate(columns):
            entry = golden_values.get(_row_metric_key(row, column.raw_column))
            worksheet.cell(
                target_row,
                data_start_column + column_offset,
                entry.golden_value if entry else None,
            )

    _style_sheet(
        worksheet,
        header_rows=[first_row] + list(range(header_start_row, unit_row + 1)),
        dimension_header_row=dimension_header_row,
        start_column=label_column,
        end_column=data_start_column + len(columns) - 1,
        dimension_count=len(dimension_labels),
        table_start_row=first_row,
        table_end_row=data_start_row + len(rows) - 1,
    )
    if data_start_column + len(columns) - 1 >= 1:
        worksheet.merge_cells(
            start_row=first_row,
            start_column=1,
            end_row=first_row,
            end_column=data_start_column + len(columns) - 1,
        )
    _merge_column_header_rows(
        worksheet,
        header_start_row,
        data_start_column,
        columns,
        len(header_labels),
    )
    _merge_dimension_values(worksheet, data_start_row, len(rows), template)
    _autosize_columns(worksheet)


def _write_outlier_sheet(
    worksheet,
    template: TemplateConfig,
    columns: list[ColumnMeta],
    rows: list[RowData],
    zscore_values: dict[MetricKey, MetricValue],
    golden_values: dict[MetricKey, MetricValue],
    golden_header_values: dict[str, Any],
    sample_node_orders: dict[tuple[str, ...], list[str]],
    summary_rows: list[dict[str, str]],
    outlier_fail_method_override: str | None = None,
) -> None:
    ordered_dimensions = _ordered_row_dimensions(template)
    dimension_labels = [item.display_name or item.name for item in ordered_dimensions]
    header_labels = _column_header_labels(template)
    sample_dimension_names = _sample_dimension_names(template)
    fail_mode = outlier_fail_method_override or template.report.outlier_fail_method
    chain_columns = defaultdict(list)
    for column in columns:
        chain_columns[column.chain_name].append(column)

    current_row = 1
    worksheet.cell(1, 1, f"Current Outlier Criteria: {_format_fail_mode(fail_mode)}")

    rows_by_sample: dict[tuple[str, ...], list[RowData]] = defaultdict(list)
    for row in rows:
        rows_by_sample[_sample_key_from_dimensions(row.dimensions, sample_dimension_names)].append(row)

    first_block = True
    for sample_key in sorted(rows_by_sample, key=_sample_key_sort_key):
        sample_rows = rows_by_sample[sample_key]
        selected_chains = sorted(
            {
                str(item["chain"])
                for item in summary_rows
                if tuple(str(value) for value in item.get("sample_key", [])) == sample_key
            },
            key=_natural_sort_key,
        )
        if not selected_chains:
            continue
        if not first_block:
            current_row += 3
        first_block = False

        label_column = len(dimension_labels) + 1
        data_start_column = label_column + 1
        block_columns = [
            column
            for chain_name in selected_chains
            for column in chain_columns[chain_name]
        ]

        _write_column_header_rows(
            worksheet,
            current_row,
            label_column,
            data_start_column,
            header_labels,
            block_columns,
        )
        golden_row = current_row + len(header_labels)
        unit_row = golden_row + 1
        dimension_header_row = unit_row + 1
        worksheet.cell(golden_row, label_column, "Golden")

        for offset, column in enumerate(block_columns):
            cell_column = data_start_column + offset
            worksheet.cell(golden_row, cell_column, golden_header_values.get(column.raw_column))
            worksheet.cell(unit_row, cell_column, column.unit)

        for index, label in enumerate(dimension_labels, start=1):
            worksheet.cell(dimension_header_row, index, label)

        block_data_start = dimension_header_row + 1
        sample_rows = sorted(
            sample_rows,
            key=lambda item: _row_sort_key(item, template, sample_node_orders),
        )
        for sample_row_index, row in enumerate(sample_rows):
            row_base = block_data_start + sample_row_index * 4
            for index, dimension in enumerate(ordered_dimensions, start=1):
                worksheet.cell(
                    row_base,
                    index,
                    _display_dimension_value(row.dimensions.get(dimension.name)),
                )

            labels = ["Value", "Z Score", "Golden Deviation", "Pass / Fail"]
            for label_offset, label in enumerate(labels):
                worksheet.cell(row_base + label_offset, label_column, label)

            failing_chains_for_row: set[str] = set()
            for chain_name in selected_chains:
                chain_fail = _row_chain_is_outlier(
                    row,
                    chain_columns[chain_name],
                    fail_mode,
                    template.report.outlier_chain_fail_rule,
                    zscore_values,
                    golden_values,
                )
                if chain_fail:
                    failing_chains_for_row.add(chain_name)

            for column_offset, column in enumerate(block_columns):
                col_idx = data_start_column + column_offset
                z_entry = zscore_values.get(_row_metric_key(row, column.raw_column))
                golden_entry = golden_values.get(_row_metric_key(row, column.raw_column))
                worksheet.cell(row_base, col_idx, row.values.get(column.raw_column))
                z_cell = worksheet.cell(row_base + 1, col_idx, z_entry.value if z_entry else None)
                g_cell = worksheet.cell(
                    row_base + 2,
                    col_idx,
                    golden_entry.value if golden_entry else None,
                )
                if z_entry and isinstance(z_cell.value, (int, float)):
                    z_cell.number_format = DECIMAL_FORMAT_3
                if golden_entry and isinstance(g_cell.value, (int, float)):
                    g_cell.number_format = PERCENT_FORMAT_2
                pass_fail = _resolve_pass_fail(
                    fail_mode,
                    z_entry,
                    golden_entry,
                )
                pf_cell = worksheet.cell(row_base + 3, col_idx, pass_fail)
                if z_entry and z_entry.is_fail:
                    z_cell.font = FAIL_FONT
                if golden_entry and golden_entry.is_fail:
                    g_cell.font = FAIL_FONT
                if pass_fail == "Fail":
                    pf_cell.font = FAIL_FONT

        _style_sheet(
            worksheet,
            header_rows=list(range(current_row, unit_row + 1)),
            dimension_header_row=dimension_header_row,
            start_column=label_column,
            end_column=data_start_column + len(block_columns) - 1,
            dimension_count=len(dimension_labels),
            table_start_row=current_row,
            table_end_row=block_data_start + len(sample_rows) * 4 - 1,
        )
        _merge_column_header_rows(
            worksheet,
            current_row,
            data_start_column,
            block_columns,
            len(header_labels),
        )
        _merge_outlier_dimension_values(
            worksheet,
            block_data_start,
            len(sample_rows),
            len(dimension_labels),
        )
        current_row = block_data_start + len(sample_rows) * 4 - 1

    _autosize_columns(worksheet)
    return None


def _write_summary_sheet(
    worksheet,
    template: TemplateConfig,
    summary_rows: list[dict[str, str]],
    ratio_rows: list[dict[str, Any]],
    sample_node_orders: dict[tuple[str, ...], list[str]],
) -> None:
    configured_node_orders = _configured_node_orders(template)
    if configured_node_orders:
        worksheet.cell(1, 1, "Configured Node Sequences")
        for row_offset, node_order in enumerate(configured_node_orders, start=1):
            worksheet.cell(1 + row_offset, 1, f"Sequence {row_offset}")
            for column_offset, node in enumerate(node_order, start=2):
                worksheet.cell(1 + row_offset, column_offset, node)
        start_row = len(configured_node_orders) + 3
    else:
        start_row = 4

    headers = [
        _sample_dimension_label(template),
        "Node",
        "Chain Name",
        "Status",
    ]
    for index, title in enumerate(headers, start=1):
        worksheet.cell(start_row, index, title)

    for row_offset, item in enumerate(
        _sort_summary_rows(summary_rows, sample_node_orders),
        start=1,
    ):
        worksheet.cell(start_row + row_offset, 1, item["sample_id"])
        worksheet.cell(start_row + row_offset, 2, item["node"])
        worksheet.cell(start_row + row_offset, 3, item["chain"])
        worksheet.cell(start_row + row_offset, 4, item["status"])

    ratio_start_row = start_row + len(summary_rows) + 3
    if ratio_rows:
        max_lot_pair_count = max(
            (len(item.get("lot_sample_pairs", [])) for item in ratio_rows),
            default=0,
        )
        ratio_headers = [
            "Stat ID",
            "Display Name",
            "Group By Dimension",
            "Group Value",
            "Numerator",
            "Outlier Sample Count",
            "Total Sample Count",
            "Outlier Ratio",
            "Filter Summary",
        ]
        for pair_index in range(1, max_lot_pair_count + 1):
            ratio_headers.extend([f"Lot {pair_index}", f"Sample IDs {pair_index}"])
        for index, title in enumerate(ratio_headers, start=1):
            worksheet.cell(ratio_start_row, index, title)
        for row_offset, item in enumerate(ratio_rows, start=1):
            worksheet.cell(ratio_start_row + row_offset, 1, item["id"])
            worksheet.cell(ratio_start_row + row_offset, 2, item["display_name"])
            worksheet.cell(ratio_start_row + row_offset, 3, item["group_by_dimension"])
            worksheet.cell(ratio_start_row + row_offset, 4, item["group_value"])
            worksheet.cell(ratio_start_row + row_offset, 5, item["numerator"])
            worksheet.cell(ratio_start_row + row_offset, 6, item["outlier_sample_count"])
            worksheet.cell(ratio_start_row + row_offset, 7, item["total_sample_count"])
            ratio_cell = worksheet.cell(ratio_start_row + row_offset, 8, item["outlier_ratio"])
            if isinstance(ratio_cell.value, (int, float)):
                ratio_cell.number_format = PERCENT_FORMAT_2
            worksheet.cell(ratio_start_row + row_offset, 9, item["filter_summary"])
            for pair_index, (lot_value, sample_ids) in enumerate(
                item.get("lot_sample_pairs", []),
                start=1,
            ):
                base_column = 10 + (pair_index - 1) * 2
                worksheet.cell(ratio_start_row + row_offset, base_column, lot_value)
                worksheet.cell(ratio_start_row + row_offset, base_column + 1, sample_ids)

    _style_sheet(
        worksheet,
        header_rows=([1] if configured_node_orders else []) + [start_row] + ([ratio_start_row] if ratio_rows else []),
        dimension_header_row=None,
        start_column=1,
        end_column=(9 + max(0, max((len(item.get("lot_sample_pairs", [])) for item in ratio_rows), default=0) * 2)) if ratio_rows else 4,
        dimension_count=0,
        table_start_row=1 if configured_node_orders else start_row,
        table_end_row=(ratio_start_row + len(ratio_rows)) if ratio_rows else (start_row + len(summary_rows)),
    )
    _autosize_columns(worksheet)


def _collect_outlier_summary_artifacts(
    template: TemplateConfig,
    columns: list[ColumnMeta],
    rows: list[RowData],
    zscore_values: dict[MetricKey, MetricValue],
    golden_values: dict[MetricKey, MetricValue],
    sample_node_orders: dict[tuple[str, ...], list[str]],
    outlier_fail_method_override: str | None = None,
) -> dict[str, list[dict[str, Any]]]:
    sample_dimension_names = _sample_dimension_names(template)
    fail_mode = outlier_fail_method_override or template.report.outlier_fail_method
    chain_columns = defaultdict(list)
    for column in columns:
        chain_columns[column.chain_name].append(column)

    rows_by_sample: dict[tuple[str, ...], list[RowData]] = defaultdict(list)
    for row in rows:
        rows_by_sample[_sample_key_from_dimensions(row.dimensions, sample_dimension_names)].append(row)

    summary_events: list[dict[str, Any]] = []
    for sample_key in sorted(rows_by_sample, key=_sample_key_sort_key):
        sample_id = _sample_key_display(sample_key)
        sample_rows = sorted(
            rows_by_sample[sample_key],
            key=lambda item: _row_sort_key(item, template, sample_node_orders),
        )
        node_rows: dict[str, list[RowData]] = defaultdict(list)
        for row in sample_rows:
            node_value = row.dimensions.get("reliability_node", "")
            if node_value:
                node_rows[node_value].append(row)

        if not node_rows:
            continue

        node_chain_fail_details = _build_sample_node_chain_fail_details(
            sample_rows,
            chain_columns,
            fail_mode,
            template.report.outlier_chain_fail_rule,
            zscore_values,
            golden_values,
        )
        node_ancestor_chains = _build_sample_node_ancestor_chains(
            {row.dimensions.get("reliability_node", "") for row in sample_rows if row.dimensions.get("reliability_node", "")},
            _configured_node_orders(template),
        )

        for node_value in sorted(
            node_rows,
            key=lambda node: _node_sort_key(node, sample_node_orders.get(sample_key, [])),
        ):
            failing_chains = sorted(
                node_chain_fail_details.get(node_value, {}).keys(),
                key=_natural_sort_key,
            )
            if not failing_chains:
                continue
            if not _sample_node_is_outlier(
                chain_columns.keys(),
                set(failing_chains),
                template.report.outlier_sample_fail_rule,
            ):
                continue
            for chain_name in failing_chains:
                status = "New"
                for predecessor in node_ancestor_chains.get(node_value, []):
                    if chain_name in node_chain_fail_details.get(predecessor, {}):
                        status = "Existed"
                        break
                detail = node_chain_fail_details.get(node_value, {}).get(chain_name, {})
                summary_events.append(
                    {
                        "sample_id": sample_id,
                        "sample_dimension_names": list(sample_dimension_names),
                        "sample_key": list(sample_key),
                        "node": node_value,
                        "chain": chain_name,
                        "status": status,
                        "dimensions": dict(
                            next(
                                (
                                    row.dimensions
                                    for row in sample_rows
                                    if row.dimensions.get("reliability_node", "") == node_value
                                ),
                                {},
                            )
                        ),
                        "raw_columns": sorted(detail.get("raw_columns", set())),
                        "logical_metrics": sorted(detail.get("logical_metrics", set())),
                        "group_ids": sorted(detail.get("group_ids", set())),
                        "group_display_names": sorted(
                            detail.get("group_display_names", set())
                        ),
                        "test_types": sorted(detail.get("test_types", set())),
                        "chain_names": sorted(detail.get("chain_names", set())),
                        "column_names": sorted(detail.get("column_names", set())),
                        "units": sorted(detail.get("units", set())),
                    }
                )

    summary_rows = _dedupe_summary_rows(
        [
            {
                "sample_id": item["sample_id"],
                "sample_key": item["sample_key"],
                "node": item["node"],
                "chain": item["chain"],
                "status": item["status"],
            }
            for item in summary_events
        ],
        template,
        sample_node_orders,
    )
    ratio_rows = _build_outlier_ratio_rows(
        template.report.outlier_ratio_stats,
        summary_events,
        rows,
        sample_node_orders,
        sample_dimension_names,
    )
    return {
        "summary_rows": summary_rows,
        "ratio_rows": ratio_rows,
    }


def _row_sort_key(
    row: RowData,
    template: TemplateConfig,
    sample_node_orders: dict[tuple[str, ...], list[str]] | None = None,
) -> tuple[Any, ...]:
    sample_dimension_names = _sample_dimension_names(template)
    sample_key = _sample_key_from_dimensions(row.dimensions, sample_dimension_names)
    node_value = row.dimensions.get("reliability_node", "")
    repeat_value = row.dimensions.get("repeat_id", "")
    node_order = []
    if sample_node_orders is not None:
        node_order = sample_node_orders.get(sample_key, [])
    if not node_order:
        configured = _configured_node_orders(template)
        node_order = configured[0] if configured else []
    return (
        _sample_key_sort_key(sample_key),
        _node_sort_key(node_value, node_order),
        _safe_int(repeat_value),
        tuple(
            _natural_sort_key(row.dimensions.get(item.name, ""))
            for item in _ordered_row_dimensions(template)
            if item.name
            not in { *sample_dimension_names, "reliability_node", "repeat_id"}
        ),
    )

def _resolve_threshold(config: ThresholdConfig, candidates: list[str]) -> float:
    for candidate in candidates:
        if candidate in config.overrides:
            return config.overrides[candidate]
    return config.default


def _resolve_golden_value(template: TemplateConfig, candidates: list[str]) -> float | None:
    for candidate in candidates:
        if candidate in template.report.golden_values:
            return template.report.golden_values[candidate]
    return None


def _resolve_built_relative_threshold(entry: AnomalyResult) -> float | None:
    if entry.center is None or entry.lower_bound is None or entry.upper_bound is None:
        return None
    if entry.center == 0:
        return None
    return max(
        abs(entry.upper_bound - entry.center),
        abs(entry.center - entry.lower_bound),
    ) / abs(entry.center)


def _resolve_built_absolute_threshold(entry: AnomalyResult) -> float | None:
    if entry.center is None or entry.lower_bound is None or entry.upper_bound is None:
        return None
    return max(
        abs(entry.upper_bound - entry.center),
        abs(entry.center - entry.lower_bound),
    )


def _sample_chain_is_outlier(
    sample_rows: list[RowData],
    columns: list[ColumnMeta],
    fail_mode: str,
    fail_rule: str,
    zscore_values: dict[MetricKey, MetricValue],
    golden_values: dict[MetricKey, MetricValue],
) -> bool:
    statuses = [
        _is_metric_fail(
            fail_mode,
            zscore_values.get(_row_metric_key(row, column.raw_column)),
            golden_values.get(_row_metric_key(row, column.raw_column)),
        )
        for row in sample_rows
        for column in columns
    ]
    if not statuses:
        return False
    if fail_rule == "all_fail":
        return all(statuses)
    return any(statuses)


def _row_chain_is_outlier(
    row: RowData,
    columns: list[ColumnMeta],
    fail_mode: str,
    fail_rule: str,
    zscore_values: dict[MetricKey, MetricValue],
    golden_values: dict[MetricKey, MetricValue],
) -> bool:
    return _sample_chain_is_outlier(
        [row],
        columns,
        fail_mode,
        fail_rule,
        zscore_values,
        golden_values,
    )


def _sample_node_is_outlier(
    all_chain_names: Iterable[str],
    failing_chain_names: set[str],
    sample_fail_rule: str,
) -> bool:
    chain_names = [str(item) for item in all_chain_names]
    if not chain_names:
        return False
    if sample_fail_rule == "all_fail":
        return all(chain_name in failing_chain_names for chain_name in chain_names)
    return any(chain_name in failing_chain_names for chain_name in chain_names)


def _resolve_pass_fail(
    fail_mode: str,
    z_entry: MetricValue | None,
    golden_entry: MetricValue | None,
) -> str:
    return "Fail" if _is_metric_fail(fail_mode, z_entry, golden_entry) else "Pass"


def _is_metric_fail(
    fail_mode: str,
    z_entry: MetricValue | None,
    golden_entry: MetricValue | None,
) -> bool:
    z_fail = bool(z_entry and z_entry.is_fail)
    golden_fail = bool(golden_entry and golden_entry.is_fail)
    if fail_mode == "modified_z_score":
        return z_fail
    if fail_mode == "golden_deviation":
        return golden_fail
    if fail_mode == "zscore_and_golden":
        return z_fail and golden_fail
    if fail_mode == "zscore_or_golden":
        return z_fail or golden_fail
    raise ValueError(f"Unsupported fail mode: {fail_mode}")


def _style_sheet(
    worksheet,
    header_rows: list[int],
    dimension_header_row: int | None,
    start_column: int,
    end_column: int,
    dimension_count: int,
    table_start_row: int | None = None,
    table_end_row: int | None = None,
) -> None:
    full_width = max(end_column, dimension_count)
    for row_index in header_rows:
        for col_index in range(start_column, end_column + 1):
            cell = worksheet.cell(row_index, col_index)
            cell.font = HEADER_FONT
            cell.fill = HEADER_FILL
            cell.alignment = CENTER
            cell.border = THIN_BORDER
    if dimension_header_row is not None:
        for col_index in range(1, full_width + 1):
            cell = worksheet.cell(dimension_header_row, col_index)
            cell.font = HEADER_FONT
            cell.fill = SUBHEADER_FILL
            cell.alignment = CENTER
            cell.border = THIN_BORDER
    if table_start_row is not None and table_end_row is not None and table_end_row >= table_start_row:
        for row_index in range(table_start_row, table_end_row + 1):
            if dimension_header_row is not None and row_index < dimension_header_row:
                column_start = start_column
            else:
                column_start = 1
            for col_index in range(column_start, full_width + 1):
                cell = worksheet.cell(row_index, col_index)
                if cell.alignment == Alignment():
                    cell.alignment = CENTER
                if cell.border == Border():
                    cell.border = THIN_BORDER
    for row in worksheet.iter_rows():
        for cell in row:
            if cell.value is None:
                continue
            if cell.alignment == Alignment():
                cell.alignment = CENTER
            if cell.border == Border():
                cell.border = THIN_BORDER


def _merge_column_header_rows(
    worksheet,
    header_row: int,
    data_start_column: int,
    columns: list[ColumnMeta],
    header_level_count: int,
) -> None:
    if not columns or header_level_count <= 0:
        return
    for level_index in range(header_level_count):
        start = data_start_column
        current = columns[0].header_values[level_index]
        current_prefix = tuple(columns[0].header_values[:level_index])
        for offset, column in enumerate(columns[1:], start=1):
            absolute_column = data_start_column + offset
            prefix = tuple(column.header_values[:level_index])
            value = column.header_values[level_index]
            if value != current or prefix != current_prefix:
                if absolute_column - 1 > start:
                    worksheet.merge_cells(
                        start_row=header_row + level_index,
                        start_column=start,
                        end_row=header_row + level_index,
                        end_column=absolute_column - 1,
                    )
                start = absolute_column
                current = value
                current_prefix = prefix
        end_column = data_start_column + len(columns) - 1
        if end_column > start:
            worksheet.merge_cells(
                start_row=header_row + level_index,
                start_column=start,
                end_row=header_row + level_index,
                end_column=end_column,
            )


def _merge_dimension_values(
    worksheet,
    start_row: int,
    row_count: int,
    template: TemplateConfig,
) -> None:
    if row_count <= 1:
        return
    dimension_names = [item.name for item in _ordered_row_dimensions(template)]
    for col_index, _dimension in enumerate(dimension_names, start=1):
        group_start = start_row
        previous = worksheet.cell(start_row, col_index).value
        for row_index in range(start_row + 1, start_row + row_count + 1):
            current = worksheet.cell(row_index, col_index).value if row_index < start_row + row_count else None
            should_merge = (
                row_index < start_row + row_count
                and current == previous
                and _same_prefix_values(worksheet, group_start, row_index, col_index)
            )
            if should_merge:
                continue
            if row_index - group_start > 1 and previous not in (None, ""):
                worksheet.merge_cells(
                    start_row=group_start,
                    start_column=col_index,
                    end_row=row_index - 1,
                    end_column=col_index,
                )
            group_start = row_index
            previous = current


def _merge_outlier_dimension_values(
    worksheet,
    start_row: int,
    row_count: int,
    dimension_count: int,
) -> None:
    if row_count <= 0:
        return

    block_height = 4
    end_row_exclusive = start_row + row_count * block_height

    for col_index in range(1, dimension_count + 1):
        group_start = start_row
        previous = worksheet.cell(start_row, col_index).value

        for row_index in range(start_row + block_height, end_row_exclusive + block_height, block_height):
            current = (
                worksheet.cell(row_index, col_index).value
                if row_index < end_row_exclusive
                else None
            )
            should_merge = (
                row_index < end_row_exclusive
                and current == previous
                and _same_prefix_values(worksheet, group_start, row_index, col_index)
            )
            if should_merge:
                continue

            if previous not in (None, ""):
                worksheet.merge_cells(
                    start_row=group_start,
                    start_column=col_index,
                    end_row=row_index - 1,
                    end_column=col_index,
                )

            group_start = row_index
            previous = current


def _same_prefix_values(worksheet, start_row: int, current_row: int, current_column: int) -> bool:
    for col_index in range(1, current_column):
        if worksheet.cell(start_row, col_index).value != worksheet.cell(current_row, col_index).value:
            return False
    return True


def _find_any_metric_value(raw_column: str, values: dict[MetricKey, MetricValue]) -> MetricValue | None:
    for (_dataset_id, _row_number, column), value in values.items():
        if column == raw_column:
            return value
    return None


def _find_any_golden_value(raw_column: str, values: dict[MetricKey, MetricValue]) -> float | None:
    entry = _find_any_metric_value(raw_column, values)
    return entry.golden_value if entry else None


def _build_column_display_values(
    values: dict[MetricKey, MetricValue],
    attribute: str,
) -> dict[str, Any]:
    grouped: dict[str, list[Any]] = defaultdict(list)
    for (_dataset_id, _row_number, raw_column), metric_value in values.items():
        value = getattr(metric_value, attribute)
        if value is None:
            continue
        grouped[raw_column].append(value)

    display_values: dict[str, Any] = {}
    for raw_column, items in grouped.items():
        normalized = _collapse_display_values(items)
        display_values[raw_column] = normalized
    return display_values


def _collapse_display_values(items: list[Any]) -> Any:
    if not items:
        return None
    if all(isinstance(item, (int, float)) for item in items):
        rounded = {round(float(item), 12) for item in items}
        if len(rounded) == 1:
            return items[0]
        return "Varies"
    unique = {str(item) for item in items}
    if len(unique) == 1:
        return items[0]
    return "Varies"


def _has_variable_metric_attribute(
    values: dict[MetricKey, MetricValue],
    attribute: str,
) -> bool:
    grouped: dict[str, set[Any]] = defaultdict(set)
    for (_dataset_id, _row_number, raw_column), metric_value in values.items():
        value = getattr(metric_value, attribute)
        if value is None:
            continue
        if isinstance(value, float):
            grouped[raw_column].add(round(value, 12))
        else:
            grouped[raw_column].add(value)
    return any(len(items) > 1 for items in grouped.values())


def _autosize_columns(worksheet) -> None:
    for index, column_cells in enumerate(worksheet.columns, start=1):
        max_length = 0
        for cell in column_cells:
            value = "" if cell.value is None else str(cell.value)
            max_length = max(max_length, len(value))
        worksheet.column_dimensions[get_column_letter(index)].width = min(max(max_length + 2, 10), 24)


def _dedupe_summary_rows(
    rows: list[dict[str, str]],
    template: TemplateConfig,
    sample_node_orders: dict[tuple[str, ...], list[str]],
) -> list[dict[str, str]]:
    seen: set[tuple[str, str, str]] = set()
    deduped: list[dict[str, str]] = []
    for item in _sort_summary_rows(rows, sample_node_orders):
        key = (item["sample_id"], item["node"], item["chain"])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(dict(item))
    return deduped


def _build_sample_node_chain_fail_details(
    sample_rows: list[RowData],
    chain_columns: dict[str, list[ColumnMeta]],
    fail_mode: str,
    fail_rule: str,
    zscore_values: dict[MetricKey, MetricValue],
    golden_values: dict[MetricKey, MetricValue],
) -> dict[str, dict[str, dict[str, set[str]]]]:
    fail_details: dict[str, dict[str, dict[str, set[str]]]] = defaultdict(dict)
    rows_by_node: dict[str, list[RowData]] = defaultdict(list)
    for row in sample_rows:
        node_value = row.dimensions.get("reliability_node", "")
        if node_value:
            rows_by_node[node_value].append(row)

    for node_value, node_rows in rows_by_node.items():
        for chain_name, columns in chain_columns.items():
            failing_columns: list[ColumnMeta] = []
            statuses: list[bool] = []
            for row in node_rows:
                for column in columns:
                    z_entry = zscore_values.get(_row_metric_key(row, column.raw_column))
                    golden_entry = golden_values.get(_row_metric_key(row, column.raw_column))
                    is_fail = _is_metric_fail(fail_mode, z_entry, golden_entry)
                    statuses.append(is_fail)
                    if is_fail:
                        failing_columns.append(column)
            if not statuses:
                continue
            chain_fail = all(statuses) if fail_rule == "all_fail" else any(statuses)
            if not chain_fail:
                continue
            fail_details[node_value][chain_name] = {
                "group_ids": {column.group_id for column in failing_columns},
                "group_display_names": {
                    column.group_display_name for column in failing_columns
                },
                "test_types": {column.test_type for column in failing_columns},
                "chain_names": {column.chain_name for column in failing_columns},
                "column_names": {column.raw_column for column in failing_columns},
                "units": {
                    str(column.unit)
                    for column in failing_columns
                    if column.unit not in {None, ""}
                },
                "raw_columns": {column.raw_column for column in failing_columns},
                "logical_metrics": {column.logical_metric for column in failing_columns},
            }
    return fail_details


def _build_sample_node_ancestor_chains(
    observed_nodes: set[str],
    configured_node_orders: list[list[str]],
) -> dict[str, list[str]]:
    ancestor_chains: dict[str, list[str]] = defaultdict(list)
    for node_order in configured_node_orders:
        for current_index, current_node in enumerate(node_order):
            if current_node not in observed_nodes:
                continue
            for previous_index in range(current_index - 1, -1, -1):
                previous_node = node_order[previous_index]
                if previous_node not in observed_nodes:
                    continue
                if previous_node not in ancestor_chains[current_node]:
                    ancestor_chains[current_node].append(previous_node)
    return ancestor_chains


def _build_outlier_ratio_rows(
    configs: list[OutlierRatioStatConfig],
    summary_events: list[dict[str, Any]],
    rows: list[RowData],
    sample_node_orders: dict[tuple[str, ...], list[str]],
    sample_dimension_names: list[str],
) -> list[dict[str, Any]]:
    if not configs:
        return []
    merged_node_order = _merge_node_orders(sample_node_orders.values())
    rows_by_dimension: dict[str, dict[tuple[str, ...], set[str]]] = defaultdict(
        lambda: defaultdict(set)
    )
    for row in rows:
        sample_key = _sample_key_from_dimensions(row.dimensions, sample_dimension_names)
        if not all(sample_key):
            continue
        for config in configs:
            group_dimensions = _effective_ratio_group_dimensions(config)
            group_key = tuple(
                str(row.dimensions.get(dimension_name, "") or "")
                for dimension_name in group_dimensions
            )
            if all(group_key):
                rows_by_dimension[config.id][group_key].add(sample_key)

    ratio_rows: list[dict[str, Any]] = []
    for config in configs:
        group_dimensions = _effective_ratio_group_dimensions(config)
        sample_ids_by_group = rows_by_dimension.get(config.id, {})
        for group_key in sorted(
            sample_ids_by_group,
            key=lambda item: _ratio_group_sort_key(
                item,
                group_dimensions,
                merged_node_order,
            ),
        ):
            total_sample_count = len(sample_ids_by_group[group_key])
            matching_events = [
                event
                for event in summary_events
                if _event_group_key(event, group_dimensions) == group_key
                and _summary_event_matches_ratio_config(event, config)
                and (
                    config.numerator != "new_outlier_samples"
                    or str(event.get("status", "")) == "New"
                )
            ]
            matched_sample_ids = {
                tuple(str(value) for value in event.get("sample_key", []))
                for event in matching_events
            }
            row_payload = {
                "id": config.id,
                "display_name": config.display_name or config.id,
                "group_by_dimension": " + ".join(group_dimensions),
                "group_value": " | ".join(group_key),
                "numerator": config.numerator,
                "outlier_sample_count": len(matched_sample_ids),
                "total_sample_count": total_sample_count,
                "outlier_ratio": (
                    len(matched_sample_ids) / total_sample_count
                    if total_sample_count
                    else 0.0
                ),
                "filter_summary": _format_ratio_filter_summary(config),
            }
            lot_sample_pairs = _build_ratio_lot_sample_pairs(matching_events)
            if lot_sample_pairs:
                row_payload["lot_sample_pairs"] = lot_sample_pairs
            ratio_rows.append(row_payload)
    return sorted(
        ratio_rows,
        key=lambda item: (
            _natural_sort_key(str(item["display_name"])),
            _ratio_group_value_display_sort_key(
                str(item["group_by_dimension"]),
                str(item["group_value"]),
                merged_node_order,
            ),
        ),
    )


def _build_ratio_lot_sample_pairs(
    matching_events: list[dict[str, Any]],
) -> list[tuple[str, str]]:
    sample_ids_by_lot: dict[str, set[str]] = defaultdict(set)
    for event in matching_events:
        dimensions = event.get("dimensions", {})
        if not isinstance(dimensions, dict):
            dimensions = {}
        lot_value = str(
            dimensions.get("lot", "")
            or dimensions.get("lot_id", "")
            or ""
        ).strip()
        sample_id_value = str(
            dimensions.get("sample_id", "")
            or event.get("sample_id", "")
            or ""
        ).strip()
        if not sample_id_value:
            continue
        sample_ids_by_lot[lot_value].add(sample_id_value)
    pairs: list[tuple[str, str]] = []
    for lot_value in sorted(sample_ids_by_lot, key=_natural_sort_key):
        sample_ids = sorted(sample_ids_by_lot[lot_value], key=_natural_sort_key)
        pairs.append((lot_value, ";".join(sample_ids)))
    return pairs


def _effective_ratio_group_dimensions(config: OutlierRatioStatConfig) -> list[str]:
    return [
        str(value).strip()
        for value in (config.group_by_dimensions or [config.group_by_dimension])
        if str(value).strip()
    ]


def _event_group_key(
    event: dict[str, Any],
    group_dimensions: list[str],
) -> tuple[str, ...]:
    dimensions = event.get("dimensions", {}) or {}
    return tuple(str(dimensions.get(dimension_name, "") or "") for dimension_name in group_dimensions)


def _ratio_group_sort_key(
    group_key: tuple[str, ...],
    group_dimensions: list[str],
    merged_node_order: list[str],
) -> tuple[Any, ...]:
    sort_values: list[Any] = []
    for dimension_name, value in zip(group_dimensions, group_key):
        if dimension_name == "reliability_node":
            sort_values.append(_node_sort_key(value, merged_node_order))
        else:
            sort_values.append(_natural_sort_key(value))
    return tuple(sort_values)


def _ratio_group_value_display_sort_key(
    group_by_dimension_label: str,
    group_value_label: str,
    merged_node_order: list[str],
) -> tuple[Any, ...]:
    dimensions = [item.strip() for item in group_by_dimension_label.split("+") if item.strip()]
    values = [item.strip() for item in group_value_label.split("|")]
    return _ratio_group_sort_key(tuple(values), dimensions, merged_node_order)


def _summary_event_matches_ratio_config(
    event: dict[str, Any],
    config: OutlierRatioStatConfig,
) -> bool:
    if config.group_ids:
        event_group_ids = set(event.get("group_ids", []))
        if not event_group_ids.intersection(config.group_ids):
            return False
    if config.group_display_names:
        event_group_display_names = set(event.get("group_display_names", []))
        if not event_group_display_names.intersection(config.group_display_names):
            return False
    if config.test_types:
        event_test_types = set(event.get("test_types", []))
        if not event_test_types.intersection(config.test_types):
            return False
    effective_chain_names = config.chain_names or config.chains
    if effective_chain_names and str(event.get("chain", "")) not in effective_chain_names:
        return False
    effective_column_names = config.column_names or config.raw_columns
    if effective_column_names:
        event_column_names = set(event.get("column_names", [])) or set(event.get("raw_columns", []))
        if not event_column_names.intersection(effective_column_names):
            return False
    if config.units:
        event_units = set(event.get("units", []))
        if not event_units.intersection(config.units):
            return False
    if config.logical_metrics:
        event_logical_metrics = set(event.get("logical_metrics", []))
        if not event_logical_metrics.intersection(config.logical_metrics):
            return False
    return True


def _format_ratio_filter_summary(config: OutlierRatioStatConfig) -> str:
    items: list[str] = []
    if config.group_ids:
        items.append("id=" + ",".join(config.group_ids))
    if config.group_display_names:
        items.append("display_name=" + ",".join(config.group_display_names))
    if config.test_types:
        items.append("test_type=" + ",".join(config.test_types))
    effective_chain_names = config.chain_names or config.chains
    if effective_chain_names:
        items.append("chain_name=" + ",".join(effective_chain_names))
    effective_column_names = config.column_names or config.raw_columns
    if effective_column_names:
        items.append("column_name=" + ",".join(effective_column_names))
    if config.units:
        items.append("unit=" + ",".join(config.units))
    if config.logical_metrics:
        items.append("logical_metric=" + ",".join(config.logical_metrics))
    return " | ".join(items) if items else "No filters"


def _merge_node_orders(node_orders: Any) -> list[str]:
    merged: list[str] = []
    for node_order in node_orders:
        for node in node_order:
            if node not in merged:
                merged.append(node)
    return merged


def _format_fail_mode(value: str) -> str:
    if value == "modified_z_score":
        return "Z Score"
    if value == "golden_deviation":
        return "Golden Deviation"
    if value == "zscore_and_golden":
        return "Z Score And Golden Deviation"
    if value == "zscore_or_golden":
        return "Z Score Or Golden Deviation"
    return value


def _build_sample_node_orders(
    rows: list[RowData],
    template: TemplateConfig,
) -> dict[tuple[str, ...], list[str]]:
    configured = _configured_node_orders(template)
    if not configured:
        return {}
    sample_dimension_names = _sample_dimension_names(template)
    nodes_by_sample: dict[tuple[str, ...], set[str]] = defaultdict(set)
    for row in rows:
        sample_id = _sample_key_from_dimensions(row.dimensions, sample_dimension_names)
        node_value = row.dimensions.get("reliability_node", "")
        if all(sample_id) and node_value:
            nodes_by_sample[sample_id].add(node_value)
    return {
        sample_id: _resolve_sample_node_order(observed_nodes, configured)
        for sample_id, observed_nodes in nodes_by_sample.items()
    }


def _configured_node_orders(template: TemplateConfig) -> list[list[str]]:
    if template.report.node_orders:
        return [list(item) for item in template.report.node_orders if item]
    if template.report.node_order:
        return [list(template.report.node_order)]
    return []


def _resolve_sample_node_order(
    observed_nodes: set[str],
    configured_node_orders: list[list[str]],
) -> list[str]:
    best_order = configured_node_orders[0]
    best_score = _node_order_match_score(observed_nodes, best_order)
    for candidate in configured_node_orders[1:]:
        score = _node_order_match_score(observed_nodes, candidate)
        if score < best_score:
            best_order = candidate
            best_score = score
    return list(best_order)


def _node_order_match_score(
    observed_nodes: set[str],
    node_order: list[str],
) -> tuple[int, int, tuple[Any, ...]]:
    configured_nodes = set(node_order)
    unknown_count = len([node for node in observed_nodes if node not in configured_nodes])
    unused_configured_count = len([node for node in node_order if node not in observed_nodes])
    return (
        unknown_count,
        unused_configured_count,
        tuple(_natural_sort_key(node) for node in node_order),
    )


def _node_sort_key(value: str, node_order: list[str]) -> tuple[int, Any]:
    if value in node_order:
        return (0, node_order.index(value))
    return (1, _natural_sort_key(value))


def _sort_summary_rows(
    rows: list[dict[str, str]],
    sample_node_orders: dict[tuple[str, ...], list[str]],
) -> list[dict[str, str]]:
    return sorted(
        rows,
        key=lambda payload: (
            tuple(
                _natural_sort_key(value)
                for value in payload.get("sample_key", [payload["sample_id"]])
            ),
            _node_sort_key(
                payload["node"],
                sample_node_orders.get(
                    tuple(str(value) for value in payload.get("sample_key", [payload["sample_id"]])),
                    [],
                ),
            ),
            _natural_sort_key(payload["chain"]),
        ),
    )


def _natural_sort_key(value: str) -> tuple[Any, ...]:
    parts = re.split(r"(\d+)", value or "")
    key: list[Any] = []
    for part in parts:
        if not part:
            continue
        if part.isdigit():
            key.append((0, int(part)))
        else:
            key.append((1, part.lower()))
    return tuple(key)


def _safe_int(value: str | None) -> int:
    if value is None:
        return 0
    match = re.search(r"\d+", str(value))
    if match:
        return int(match.group())
    return 0


def _display_dimension_value(value: str | None) -> Any:
    if value is None:
        return None
    text = str(value)
    if re.fullmatch(r"-?\d+", text):
        return int(text)
    if re.fullmatch(r"-?\d+\.\d+", text):
        return float(text)
    return text
