# Easy Outlier GUI Tutorial

这份教程面向日常使用 GUI 的同事，重点讲最常见的操作流程，不讲代码实现。

## 1. 界面分区

左侧是操作区，按 tab 分成几类：

- `Setup`
  - 选择 `Database Folder`
  - 选择 `Template File`
  - 选择 `Input Excel/CSV`
  - 配置数值文本清洗
  - 模板校验、模板导入导出、保存 debug bundle
- `Import`
  - 导入新的 Excel/CSV 数据到当前数据库工作区
  - 查看当前数据库快照
  - 删除误导入的数据行
- `Golden`
  - 配置并生成 built golden
  - 可选择中心值、阈值模式、reference dimensions、filters
- `Analyze`
  - 配置分析范围、golden 来源、outlier criteria、z threshold
  - 运行报表导出

右侧是结果区：

- `Golden Coverage`
  - 显示 built golden 覆盖了多少数据点，哪些点没有匹配到 golden
- `Outlier Summary`
  - 显示本次分析得到的 outlier 汇总和 outlier ratio 统计
- `Log`
  - 显示操作日志和报错信息

## 2. 数据库结构

一个 `Database Folder` 就是一套数据库。

数据库目录下通常会看到：

- `temp/`
  - 当前未保存的工作区
  - 导入、删行、build golden、分析等操作先写到这里
- `result/`
  - 分析导出的 Excel 结果
- `golden/`
  - built golden 文件
- 其他数据库数据文件

日常可以把它理解成：

- 上层目录 = 已保存版本
- `temp/` = 当前编辑中的版本

## 3. 最常用流程

```mermaid
flowchart TD
    A["选择 Database Folder"] --> B["选择 Template File"]
    B --> C["选择 Input Excel/CSV"]
    C --> D["Import Data"]
    D --> E{"是否需要 built golden?"}
    E -- Yes --> F["Build Golden"]
    E -- No --> G["进入 Analyze"]
    F --> G["进入 Analyze"]
    G --> H["选择 Golden Source / Outlier Criteria / Scope"]
    H --> I["Run Analysis"]
    I --> J["查看 Outlier Summary / Golden Coverage"]
    J --> K["Save Database 或 Save Database As"]
```

## 4. 第一次使用建议

### 4.1 选择数据库

先在 `Setup` 里选择 `Database Folder`。

建议：

- 新项目新建一个独立目录作为数据库
- 不要长期使用默认的 `tempDatabase`

如果打开数据库时发现：

- `temp/` 和上层已保存数据库不一致

程序会提示你选择：

- `Continue Temp Workspace`
- `Discard Temp And Reload Saved Database`

含义是：

- 继续使用上次未保存的工作区
- 或丢弃未保存改动，回到上次已保存版本

### 4.2 选择模板

`Template File` 支持：

- `.json`
- `.xlsx`

推荐：

- 日常编辑用 Excel template
- 版本管理或 debug 时保留一份 JSON template

模板里和本次新增能力最相关的两块是：

- `node_orders`
  - 定义 node sequence
  - 会影响 `Outlier Summary` 的排序和 `New / Existed` 判定
- `row_dimensions` / `numeric_cleanup`
  - 定义行维度怎么拆
  - 定义导入时是否先清洗数值文本

如果只是想快速开始，可以先使用示例模板：

- [chip_reliability_template.json](examples/chip_reliability_template.json)
- [chip_reliability_template.xlsx](examples/chip_reliability_template.xlsx)

## 5. 导入数据

### 5.1 基本导入

在 `Setup` 里选择 `Input Excel/CSV` 后，到 `Import` tab 点击导入。

如果数据库里已经有相同样品属性的数据，GUI 会提示你选择冲突处理方式：

- `Replace Existing`
- `Append And Shift Repeat`
- `Cancel`

含义：

- `Replace Existing`
  - 用新数据替换数据库中相同键的旧数据
- `Append And Shift Repeat`
  - 把新数据追加进去，并把 `repeat index` 往后顺延

### 5.3 数值文本清洗

如果输入文件里的数值列可能长这样：

- `1,234mV`
- `5.1%`
- `10E-3mA`

可以在 `Setup` 里启用：

- `Enable Numeric Text Cleanup`
- `Cleanup Mode`
- `Characters To Remove`

两种模式：

- `Remove All Non-Numeric Characters`
  - 自动去掉大多数单位和杂字符
- `Remove Specified Characters`
  - 只去掉你手工指定的字符或字符串

补充：

- 科学记数法里的 `E/e` 会被保留
- 例如 `10E-3` 会被正确解析成数字，而不是把 `E` 删除

### 5.2 删除误导入数据

如果导入错了，可以在 `Current Database Snapshot` 中选中行，然后删除。

这是数据库级删除，不只是本次分析隐藏。

如果某次 import 的所有数据都被删掉或被完全 replace，对应的 import history 记录也会自动清理。

## 6. Build Golden

如果你要用 built golden：

1. 到 `Golden` tab
2. 选择 reference dimensions
3. 选择 filters
4. 配置：
   - `Golden Center`
   - `Golden Threshold Mode`
   - `Relative Limit`
   - `Sigma Multiplier`
5. 点击 `Build Golden`

说明：

- `Relative Limit` 和报表里的默认 golden deviation threshold 是同一套值
- GUI 修改这些值后，如果和 template 不一致，程序会询问你是否回写 template

## 7. Run Analysis

在 `Analyze` tab 里，最常用的配置有：

- `Golden Source`
  - `Built Golden File`
  - `Template Direct`
- `Outlier Criteria`
  - `Modified Z Score`
  - `Golden Deviation`
  - `Modified Z Score And Golden Deviation`
  - `Modified Z Score Or Golden Deviation`
- `Z Threshold`
- `Analysis Scope`
  - `Current Input File`
  - `Entire Database`
  - `Checked Imports`

还可以加过滤条件：

- `Sample Keys`
- `Nodes`
- `Exclude Sample Keys`
- `Exclude Nodes`

这些过滤条件会统一作用在当前 scope 上。

`Sample Keys` 现在会真正按 template 里的 `sample_dimension_names` 过滤，不再默认只看 `sample_id`。

输入格式是：

- 多个 sample key 之间，用 `;` 分隔
- 如果 sample 主键是两层，例如 `lot_id + sample_id`，推荐写成按第一层分组的形式：
  - `LotA:S001,S002,S003;LotB:S001,S002,S004`
- 这表示：
  - `LotA + S001`
  - `LotA + S002`
  - `LotA + S003`
  - `LotB + S001`
  - `LotB + S002`
  - `LotB + S004`
- 显式写法也仍然支持：
  - `LotA,S001;LotB,S002`

例如如果 template 里写的是：

- `sample_dimension_names = lot_id;sample_id`

那么：

- `LotA:S001,S002;LotB:S003,S004`

表示只分析这些样品主键：

- `lot_id = LotA` 且 `sample_id = S001`
- `lot_id = LotA` 且 `sample_id = S002`
- `lot_id = LotB` 且 `sample_id = S003`
- `lot_id = LotB` 且 `sample_id = S004`

对应地：

- `Exclude Sample Keys`

也是同样格式，例如：

- `LotC:S003,S004;LotD:S005`

### 7.1 Node Sequence 会影响什么

`Analyze` 本身不需要你每次手工选 sequence，程序会按 template 里的 `node_orders` 工作。

它会影响：

- 结果里的 node 排序
- `Outlier Summary` 里 `New / Existed` 的判断

当前 `New / Existed` 的规则是：

- 先和当前 sequence 的上一项比较
- 如果上一项 node 不存在于当前 sample 的数据里，就继续往前找更早 node
- 找到第一个同一条 chain 已经 fail 的前驱 node，就判 `Existed`
- 如果前面所有 node 都没有同链路 fail，才判 `New`

也就是说，中间 node 缺失时，程序不会直接中断，而会继续往前回溯。

## 8. 结果会输出什么

每次运行分析，都会输出和目标格式一致的结果 Excel，主要包括：

- `Sorted`
- `deviation-zscore`
- `deviation-golden`
- `outliers`
- `Outlier Summary`

如果 built golden 对不同数据点的 golden 不一致，还会额外输出：

- `golden-by-point`

默认结果目录是当前数据库下的：

- `result/`

## 9. 查看 GUI 结果

### 9.1 Golden Coverage

当分析使用 `Built Golden File` 时，这里会告诉你：

- 总 measurement 数量
- 匹配到 golden 的数量
- 未匹配数量
- 未匹配示例

如果旧 golden 无法覆盖新导入数据，先看这里最方便。

### 9.2 Outlier Summary

这里会显示：

- 哪些 sample 有 fail
- 哪条 chain fail
- 从哪个 node 开始失效
- `New / Existed` 状态
- outlier ratio 统计

其中 `New / Existed` 的理解可以简单记成：

- `New`
  - 这条 chain 在当前 node 首次出现失效
- `Existed`
  - 这条 chain 在更早的 node 已经失效过

这里的“更早”不是只看上一项，而是会按对应 sequence 一路往前回溯。

### 9.3 Log

如果导入失败、模板校验失败、文件被占用、路径不对，先看这里。

## 10. Save Database 和 Save Database As

### 10.1 Save Database

适合保存到当前数据库。

作用：

- 把 `temp/` 工作区内容合并回上层数据库
- 同时保存当前 GUI 设置

### 10.2 Save Database As

适合把当前工作区另存为新的数据库目录。

作用：

- 把当前 `temp/` 内容复制到新目录
- 同时带上 GUI 设置

如果保存过程中发现某些文件被 Excel 占用，程序会提醒你先关闭 Excel 再重试。

## 11. 关闭软件前要注意什么

如果你当前仍在默认的 `tempDatabase` 上工作，而且里面已经有数据，关闭软件时会提醒你：

- 是否另存到一个正式目录

建议：

- 临时测试可以先用 `tempDatabase`
- 正式项目请尽快 `Save Database As`

## 12. Debug Bundle

如果遇到难定位的问题，可以在 `Setup` 里使用 `Save Debug Bundle`。

它会导出：

- 当前 GUI 设置
- 当前结果摘要
- 当前日志
- 当前 template / input / golden / output 文件副本
- 当前数据库快照

这很适合拿来复现问题或做 CLI debug。

## 13. 常见问题

### 13.1 为什么结果里没有某些样品？

先检查：

- `Analysis Scope`
- `Sample IDs`
- `Nodes`
- `Exclude Sample IDs`
- `Exclude Nodes`
- `Checked Imports`

### 13.2 为什么 built golden 提示有未匹配数据？

通常是因为：

- 新数据的 sample / node / reference key 不在旧 golden 里
- template 改了，logical metric key 发生变化
- reference dimensions 和 filters 变化了

先看右侧 `Golden Coverage`。

### 13.3 为什么我导入后关掉软件，再打开还是上次没保存的状态？

因为当前数据库下的 `temp/` 工作区还在。

打开数据库时可以选择：

- `Continue Temp Workspace`
- `Discard Temp And Reload Saved Database`

### 13.4 为什么结果文件没法覆盖？

如果目标 Excel 文件正被打开，Windows 常见会锁文件。

请先关闭 Excel，再重新导出或保存数据库。

## 14. 建议的团队使用方式

- 每个项目使用独立数据库目录
- template 和 database 放在同一个项目目录下
- 重要改动后及时 `Save Database`
- 定期备份数据库目录
- 遇到异常时先导出 debug bundle

## 15. 相关文件

- 使用说明： [README.md](README.md)
- 模板完整说明： [template_help.md](template_help.md)
- 示例 JSON 模板： [chip_reliability_template.json](examples/chip_reliability_template.json)
- 示例 Excel 模板： [chip_reliability_template.xlsx](examples/chip_reliability_template.xlsx)
