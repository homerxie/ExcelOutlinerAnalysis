"""Literal, case-insensitive fragment matching for user-facing searches."""

from collections.abc import Iterable
from functools import lru_cache


@lru_cache(maxsize=256)
def search_tokens(query: str) -> tuple[str, ...]:
    """Split on whitespace without interpreting punctuation or regular expressions."""
    return tuple(dict.fromkeys(query.casefold().split()))


def matches_search(values: str | Iterable[str], query: str) -> bool:
    """Match every fragment, in any order, within one searchable item or row.

    A fragment must occur within a single field, but different fragments may
    match different fields of the same item. Empty searches match all items.
    """
    tokens = search_tokens(query)
    if not tokens:
        return True
    fields = (values,) if isinstance(values, str) else values
    normalized = tuple(value.casefold() for value in fields)
    return all(any(token in value for value in normalized) for token in tokens)
