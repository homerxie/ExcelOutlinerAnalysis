"""Keep Inspector analysis, Python allocation and GC outside the main GUI.

Only settings and navigation commands cross this boundary. Measurements, plot
objects and sample indexes remain in the Inspector process. Pipe reads, writes,
process startup and shutdown never run on either Qt event thread.
"""
from __future__ import annotations

from collections import OrderedDict
from copy import deepcopy
from dataclasses import fields
import multiprocessing as mp
import os
import signal
import subprocess
import sys
from threading import Condition, Event, Thread
from time import monotonic, perf_counter
from typing import TYPE_CHECKING

from PySide6.QtCore import QObject, QTimer, Signal
from PySide6.QtWidgets import QApplication

if TYPE_CHECKING:
    from .comparison_window import PlotInspectorContext


class _Mailbox:
    """Bounded, latest-value messages; close supersedes queued GUI commands."""

    def __init__(self, capacity: int = 16):
        self._condition = Condition()
        self._messages: OrderedDict[str, dict] = OrderedDict()
        self._capacity = capacity
        self._closed = False

    def put(self, message: dict) -> bool:
        key = message["type"]
        with self._condition:
            if self._closed or "close" in self._messages:
                return False
            if key == "close":
                self._messages.clear()
            self._messages[key] = message
            if len(self._messages) > self._capacity:
                self._messages.popitem(last=False)
            self._condition.notify()
            return True

    def get(self) -> dict | None:
        with self._condition:
            self._condition.wait_for(lambda: self._messages or self._closed)
            return self._messages.popitem(last=False)[1] if self._messages else None

    def drain(self) -> list[dict]:
        with self._condition:
            messages = list(self._messages.values())
            self._messages.clear()
            return messages

    def close(self) -> None:
        with self._condition:
            self._closed = True
            self._condition.notify_all()


def _write_messages(connection, mailbox: _Mailbox) -> None:
    try:
        while (message := mailbox.get()) is not None:
            connection.send(message)
    except (BrokenPipeError, EOFError, OSError):
        pass


def _read_messages(connection, mailbox: _Mailbox, *, disconnected: dict) -> None:
    try:
        while True:
            message = connection.recv()
            if isinstance(message, dict) and isinstance(message.get("type"), str):
                mailbox.put(message)
    except (EOFError, OSError):
        mailbox.put(disconnected)


def _terminate_tree(process, *, force: bool = False) -> None:
    """Escalation runs on a supervisor thread and includes render descendants."""
    if process.pid is None or not process.is_alive():
        return
    if os.name == "nt":
        try:
            result = subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
        except OSError:
            result = None
        if result is None or result.returncode:
            process.kill() if force else process.terminate()
    else:
        try:
            if os.getpgid(process.pid) == process.pid:
                os.killpg(process.pid, signal.SIGKILL if force else signal.SIGTERM)
            elif force:
                process.kill()
            else:
                process.terminate()
        except ProcessLookupError:
            pass


class _ProcessRuntime:
    """Qt-independent lifetime owner retained until the child has been reaped."""

    def __init__(self, *, target=None, shutdown_seconds: float = 10.0):
        self.commands = _Mailbox()
        self.events = _Mailbox()
        self.process = None
        self.pid: int | None = None
        self.exitcode: int | None = None
        self._target = target or _run_inspector
        self._shutdown_seconds = shutdown_seconds
        self._closing = Event()
        self._done = Event()
        self._started = False

    def start(self, appearance: dict) -> None:
        if self._started:
            return
        self._started = True
        from ..process_logging import get_process_log_queue
        log_queue = get_process_log_queue()
        Thread(target=self._supervise, args=(appearance, log_queue),
               name="plot-inspector-supervisor", daemon=True).start()

    def close(self) -> None:
        self._closing.set()
        self.commands.put({"type": "close"})
        if not self._started:
            self._done.set()
            self.events.put({"type": "finished"})

    def _supervise(self, appearance: dict, log_queue) -> None:
        connection = child_connection = None
        try:
            if self._closing.is_set():
                return
            context = mp.get_context("spawn")
            connection, child_connection = context.Pipe(duplex=True)
            # Must not be a daemon: the Inspector owns render subprocesses.
            process = context.Process(target=self._target,
                                      args=(child_connection, os.getpid(), appearance, log_queue),
                                      name="Plot Inspector", daemon=False)
            self.process = process
            process.start()
            self.pid = process.pid
            child_connection.close()
            child_connection = None
            Thread(target=_write_messages, args=(connection, self.commands),
                   name="plot-inspector-command-writer", daemon=True).start()
            reader = Thread(target=_read_messages, args=(connection, self.events),
                            kwargs={"disconnected": {"type": "disconnected"}},
                            name="plot-inspector-event-reader", daemon=True)
            reader.start()
            deadline = None
            while process.is_alive():
                process.join(0.1)
                if self._closing.is_set():
                    if deadline is None:
                        deadline = monotonic() + self._shutdown_seconds
                    elif monotonic() >= deadline:
                        _terminate_tree(process)
                        process.join(1.0)
                        _terminate_tree(process, force=True)
                        process.join(1.0)
            # Drain the child's final error before delivering finished/deleting
            # its QObject proxy. Process exit can beat the pipe reader thread.
            reader.join(1.0)
            self.exitcode = process.exitcode
            if process.exitcode and not self._closing.is_set():
                self.events.put({"type": "error", "message":
                                 f"Plot Inspector exited unexpectedly (code {process.exitcode}). Reopen it to retry."})
        except Exception as exc:
            if not self._closing.is_set():
                self.events.put({"type": "error", "message": f"Could not start Plot Inspector: {exc}"})
        finally:
            self.commands.close()
            if connection is not None:
                connection.close()
            if child_connection is not None:
                child_connection.close()
            process = self.process
            if process is not None and process.is_alive():
                # Also clean up partial startup (for example a failed pipe
                # reader thread), not just ordinary window-close escalation.
                _terminate_tree(process)
                process.join(1.0)
                _terminate_tree(process, force=True)
                process.join(1.0)
            if process is not None and not process.is_alive():
                self.exitcode = process.exitcode
                process.close()
                self.process = None
            self._done.set()
            self.events.put({"type": "finished"})


class PlotInspectorProcess(QObject):
    """Small asynchronous window proxy; compatible with main-window reuse."""

    started = Signal()
    finished = Signal()
    error = Signal(str)
    statusChanged = Signal(str)
    diagnosticsReady = Signal(object)

    def __init__(self, context: PlotInspectorContext, parent=None, *, summary_snapshot: dict | None = None):
        super().__init__(parent)
        self._context = deepcopy(context)
        self._close_requested = False
        self._finished = False
        self.diagnostics: dict = {}
        self._runtime = _ProcessRuntime()
        self._runtime.commands.put({"type": "open", "context":
                                    deepcopy({field.name: getattr(context, field.name) for field in fields(context)}),
                                    "snapshot": deepcopy(summary_snapshot)})
        self._timer = QTimer(self)
        self._timer.setInterval(20)
        self._timer.timeout.connect(self._poll)
        self._timer.start()
        runtime = self._runtime
        self.destroyed.connect(lambda *_: runtime.close())
        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(runtime.close)

    def context(self) -> PlotInspectorContext:
        return self._context

    @property
    def is_running(self) -> bool:
        return self._runtime._started and not self._runtime._done.is_set()

    @property
    def closed(self) -> bool:
        return self._close_requested or self._finished

    @property
    def pid(self) -> int | None:
        return self._runtime.pid

    def show(self) -> None:
        if self.closed:
            return
        app = QApplication.instance()
        from ..compute_resources import get_process_limit
        self._runtime.commands.put({"type": "show"})
        self._runtime.start({"font": app.font().toString() if app is not None else "",
                             "process_limit": get_process_limit()})

    def raise_(self) -> None:
        self.show()

    def activateWindow(self) -> None:
        self.show()

    def navigate_to_summary(self, target: dict, navigation: dict, *, summary_snapshot: dict | None = None) -> None:
        if self.closed:
            return
        # Never serialize the other samples embedded in a Summary row.
        self._runtime.commands.put({"type": "navigate", "target": deepcopy(target),
                                    "navigation": deepcopy({key: value for key, value in navigation.items() if key != "targets"}),
                                    "snapshot": deepcopy(summary_snapshot)})

    def request_diagnostics(self) -> None:
        """Opt-in diagnostics return scalars/digests, never the analysis graph."""
        if not self.closed:
            self._runtime.commands.put({"type": "diagnostics"})

    def close(self) -> None:
        self._close_requested = True
        self._runtime.close()

    def _poll(self) -> None:
        for message in self._runtime.events.drain():
            kind = message["type"]
            if kind == "started":
                self.started.emit()
            elif kind == "error":
                self.error.emit(message["message"])
            elif kind == "status":
                self.statusChanged.emit(message["message"])
            elif kind == "diagnostics":
                self.diagnostics = message["data"]
                self.diagnosticsReady.emit(message["data"])
            elif kind == "closing":
                self._close_requested = True
            elif kind == "finished" and not self._finished:
                self._finished = self._close_requested = True
                self._timer.stop()
                app = QApplication.instance()
                if app is not None:
                    try:
                        app.aboutToQuit.disconnect(self._runtime.close)
                    except (RuntimeError, TypeError):
                        pass
                self.finished.emit()
                self.deleteLater()


def _validate_snapshot(context, snapshot, previous_snapshot=None) -> str:
    if snapshot is None:
        return ""
    from ..summary_snapshot import summary_plot_context, summary_snapshot_error
    from .comparison_window import PlotInspectorContext
    error = summary_snapshot_error(snapshot)
    if error:
        return error
    if PlotInspectorContext(**summary_plot_context(snapshot)) != context:
        return "The Summary context differs from this Plot Inspector. Reopen its sample link."
    if previous_snapshot is not None and (
            snapshot.get("sources") != previous_snapshot.get("sources")
            or (snapshot.get("source_digests") or {}) != (previous_snapshot.get("source_digests") or {})):
        return "The Summary source differs from this Plot Inspector. Reopen its sample link."
    return ""


def inspector_diagnostics(window) -> dict:
    """Explicit test/diagnostic hook; expensive correctness hashing stays here."""
    from hashlib import sha256
    view = window.ui.plotScrollArea
    cache = view.cache_info()
    has_sample_index = (window._sample_index is not None or (window._template is not None
                        and not window._template.report.sample_dimension_names))
    ready = bool(window._current_result is not None and has_sample_index
                 and window._pending_summary_navigation is None and not window._load_thread
                 and not window._build_threads and not window._sample_threads
                 and not window._render_timer.isActive() and not window._sample_index_timer.isActive()
                 and cache["ready"] and not view.workers_running())
    result = {"ready": ready, "ready_monotonic": perf_counter(),
              "parent_pid": os.getppid(), "child_pid": os.getpid()}
    if not ready:
        return result
    # Native windows can be occluded while the independent main window is
    # being exercised. Paint the real viewport once for explicit diagnostics;
    # this stays in memory and does not alter production rendering behavior.
    painted = not view.viewport().grab().isNull()
    cache = view.cache_info()
    result["ready_monotonic"] = perf_counter()
    data = window._current_result
    digest = sha256()
    digest.update(repr(data.summary()).encode())
    for descriptor in data.metrics:
        digest.update(repr(descriptor).encode())
    for key, lanes in sorted(data.series_by_metric.items()):
        digest.update(key.encode())
        for lane in lanes:
            digest.update(repr((lane.aggregate_id, lane.lane_values, lane.reference_ranges, lane.zscore_ranges)).encode())
            for point in lane.points:
                digest.update(repr(tuple(getattr(point, field.name) for field in fields(point))).encode())
    selection = window._sample_selection
    conditions = dict(window._sample_active_conditions)
    valid = True
    nodes = set()
    selected_point_keys = []
    if selection is not None:
        node_field = window._template.report.reliability_node_dimension
        for metric, lanes in selection.indices_by_metric.items():
            for lane_index, indices in enumerate(lanes):
                for point_index in indices:
                    point = data.series_by_metric[metric][lane_index].points[int(point_index)]
                    valid = valid and all(point.dimensions.get(key) == value for key, value in conditions.items())
                    nodes.add(point.dimensions.get(node_field, ""))
                    if len(selected_point_keys) < 16:
                        selected_point_keys.append((point.dataset_id, point.row_number, point.raw_column))
    result.update(result_summary=data.summary(), result_generation=window._result_generation,
                  selected_conditions=conditions, selected_sample_count=selection.sample_count if selection else 0,
                  selected_point_count=selection.point_count if selection else 0,
                  visible_metrics=[group.descriptor.logical_metric for group in view._groups],
                  selected_samples_valid=valid, nodes_present=sorted(nodes), result_digest=digest.hexdigest(),
                  selected_point_keys=selected_point_keys,
                  selected_point_keys_truncated=selection is not None and selection.point_count > 16,
                  data_scores_and_flags_sha256=digest.hexdigest(),
                  native_final_frame_painted=painted,
                  render_cache=cache)
    selected = window.ui.metricTreeWidget.currentItem()
    result["focus_label"] = selected.text(0) if selected is not None else ""
    return result


def _watch_parent(parent_pid: int, incoming: _Mailbox, finished: Event) -> None:
    parent = mp.parent_process()
    while not finished.wait(0.5):
        if (parent is not None and not parent.is_alive()) or os.getppid() != parent_pid:
            incoming.put({"type": "close"})
            if not finished.wait(10):
                # The child Qt thread may be stuck in native code. Its own
                # process group contains only this Inspector and its renderers.
                if os.name == "nt":
                    subprocess.run(["taskkill", "/PID", str(os.getpid()), "/T", "/F"], check=False,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                else:
                    os.killpg(os.getpid(), signal.SIGKILL)
            return


def _run_inspector(connection, parent_pid: int, appearance: dict, log_queue=None) -> None:
    """Spawn entry point; no database data leaves this process."""
    if os.name != "nt":
        os.setsid()
    from ..process_logging import install_process_logging
    install_process_logging(log_queue)
    from ..compute_resources import set_process_limit
    set_process_limit(appearance.get("process_limit", 0))
    import qdarktheme
    from PySide6.QtCore import Slot
    from PySide6.QtGui import QFont, QIcon
    from ..runtime import APP_DISPLAY_NAME, icon_png_path
    from ..workbook_runtime import database_workbook_runtime
    from . import comparison_window as inspector

    incoming, outgoing = _Mailbox(), _Mailbox()
    finished = Event()
    Thread(target=_read_messages, args=(connection, incoming),
           kwargs={"disconnected": {"type": "close"}}, daemon=True).start()
    writer = Thread(target=_write_messages, args=(connection, outgoing), daemon=True)
    writer.start()
    Thread(target=_watch_parent, args=(parent_pid, incoming, finished), daemon=True).start()
    app = QApplication(["plot-inspector"])
    app.setQuitOnLastWindowClosed(False)
    app.setApplicationDisplayName(APP_DISPLAY_NAME)
    qdarktheme.setup_theme("dark")
    if appearance.get("font"):
        font = QFont()
        if font.fromString(appearance["font"]):
            app.setFont(font)
    icon = icon_png_path()
    if icon is not None:
        app.setWindowIcon(QIcon(str(icon)))

    class DatabaseLoadWorker(inspector.PlotDataLoadWorker):
        @Slot()
        def run(self):
            # ContextVars do not propagate into a QThread. Enter the owner's
            # workbook scope in the actual load thread, not around app.exec().
            ran = False
            try:
                if self._context.storage_path:
                    with database_workbook_runtime(self._context.storage_path):
                        ran = True
                        super().run()
                else:
                    ran = True
                    super().run()
            except Exception as exc:
                self.failed.emit(str(exc))
                if not ran:
                    self._finish()

    inspector.PlotDataLoadWorker = DatabaseLoadWorker

    class Window(inspector.PlotInspectorWindow):
        def closeEvent(self, event):
            state["closing"] = True
            outgoing.put({"type": "closing"})
            super().closeEvent(event)

        def _display_status(self, message, *, busy, value=0, total=1):
            super()._display_status(message, busy=busy, value=value, total=total)
            outgoing.put({"type": "status", "message": message})

        def _on_load_failed(self, message):
            super()._on_load_failed(message)
            outgoing.put({"type": "error", "message": message})

        def _on_build_failed(self, request_id, message):
            super()._on_build_failed(request_id, message)
            if request_id == self._build_request_id:
                outgoing.put({"type": "error", "message": message})

    state = {"window": None, "snapshot": None, "context": None, "closing": False}

    def dispatch():
        priority = {"close": 0, "open": 1, "navigate": 2, "show": 3, "diagnostics": 4}
        for message in sorted(incoming.drain(), key=lambda item: priority.get(item["type"], 5)):
            kind = message["type"]
            window = state["window"]
            try:
                if kind == "close":
                    state["closing"] = True
                    if window is None:
                        app.quit()
                    else:
                        window.close()
                    return
                if state["closing"]:
                    continue
                if kind == "open":
                    context = inspector.PlotInspectorContext(**message["context"])
                    error = _validate_snapshot(context, message.get("snapshot"))
                    if error:
                        outgoing.put({"type": "error", "message": error})
                        state["closing"] = True
                        app.quit()
                        return
                    state["context"], state["snapshot"] = context, message.get("snapshot")
                    state["window"] = window = Window(context)
                    window.destroyed.connect(app.quit)
                    window.show()
                    outgoing.put({"type": "started"})
                elif kind == "show" and window is not None:
                    if window.isMinimized():
                        window.showNormal()
                    else:
                        window.show()
                    window.raise_()
                    window.activateWindow()
                elif kind == "navigate" and window is not None:
                    snapshot = message.get("snapshot") or state["snapshot"]
                    error = _validate_snapshot(state["context"], snapshot, state["snapshot"])
                    if error:
                        outgoing.put({"type": "error", "message": error})
                    else:
                        window.navigate_to_summary(message["target"], message["navigation"])
                elif kind == "diagnostics" and window is not None:
                    outgoing.put({"type": "diagnostics", "data": inspector_diagnostics(window)})
            except Exception as exc:
                outgoing.put({"type": "error", "message": str(exc)})
                if state["window"] is None:
                    app.quit()

    timer = QTimer()
    timer.setInterval(15)
    timer.timeout.connect(dispatch)
    timer.start()
    try:
        app.exec()
    finally:
        finished.set()
        outgoing.close()
        writer.join(0.5)
        connection.close()
