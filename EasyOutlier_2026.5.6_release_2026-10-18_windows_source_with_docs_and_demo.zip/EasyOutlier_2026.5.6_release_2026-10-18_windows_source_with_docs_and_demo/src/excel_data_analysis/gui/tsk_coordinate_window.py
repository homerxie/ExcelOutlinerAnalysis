"""Non-modal coordinate view synchronized with the active TSK result group."""
from contextlib import ExitStack
import math

from PySide6.QtCore import QEvent, QSignalBlocker, Qt, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QDialog, QListWidgetItem

from ..text_search import matches_search
from ..tsk_sorting import natural_sort_key
from ..tsk_result_state import failed_sample_outcomes
from ..tsk_coordinate_effects import coordinate_effect_surface
from .tsk_coordinate_plot import chain_probability, coordinate_instances
from .tsk_risk_display import percentage
from .tsk_coordinate_labels import available_field_keys, default_label_rows, normalize_label_rows
from .tsk_favorite_colors import FavoriteChainColorDelegate, assign_favorite_colors, contrast_text_color
from .search_completer import FragmentSearchCompleter
from .ui_tsk_coordinate_window import Ui_TskCoordinateWindowForm


class TskCoordinateWindow(QDialog):
    chain_selected = Signal(str)
    chain_selection_cleared = Signal()
    group_selected = Signal(int)
    settings_changed = Signal()
    failed_samples_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._settings_ready = False
        self._restoring_settings = False
        self.ui = Ui_TskCoordinateWindowForm()
        self.ui.setupUi(self)
        self._topology = []
        self._chains = {}
        self._coincident = 0
        self._label_layout_dialog = None
        self._favorite_samples_dialog = None
        self._label_layouts = {}
        self._label_features = []
        self._label_schema = ()
        self._favorite_chains = set()
        self._favorite_colors = {}
        self.ui.favoriteChainsList.setItemDelegate(FavoriteChainColorDelegate(self.ui.favoriteChainsList))
        self._available_chains = set()
        self._payload = None
        self._payload_group = None
        self._xy_heatmap_reason = "no_xy_fit"
        self._coordinate_view_initialized = False
        self._failed_samples_loading = False
        self._failed_samples_error = ""
        self._syncing_linked_selection = False
        self._selecting_search_chain = False
        self._sidebar_width = int(self.ui.coordinateSplitter.property("preferredSidebarWidth"))
        self.ui.coordinateSplitter.setStretchFactor(0, 1)
        self.ui.coordinateSplitter.setStretchFactor(1, 0)
        self._apply_sidebar_width()
        self.ui.chainComboBox.setCompleter(FragmentSearchCompleter(self.ui.chainComboBox.model(), self.ui.chainComboBox))
        self.ui.chainComboBox.lineEdit().setPlaceholderText(self.ui.chainComboBox.property("searchPlaceholderText"))
        self.ui.chainComboBox.lineEdit().returnPressed.connect(self._commit_chain_text)
        self.ui.addFavoriteButton.clicked.connect(self._add_favorite)
        self.ui.removeFavoriteButton.clicked.connect(self._remove_favorite)
        self.ui.obtainFailedSamplesButton.clicked.connect(self._open_favorite_samples)
        self.ui.favoriteChainsList.itemChanged.connect(self._favorite_highlights_changed)
        self.ui.favoriteChainsList.currentRowChanged.connect(self._update_favorite_controls)
        self.ui.favoriteChainsList.itemDoubleClicked.connect(self._favorite_activated)
        self.ui.searchPanel.instances_selected.connect(self._instances_selected)
        self.ui.searchPanel.chain_selected.connect(self._search_chain_selected)
        self.ui.sidebarToggleButton.toggled.connect(self._sidebar_visibility_changed)
        self.ui.coordinateSplitter.splitterMoved.connect(self._sidebar_resized)
        self.ui.sidebarTabs.currentChanged.connect(self._notify_settings_changed)
        self.ui.coordinatePlot.chain_selected.connect(self._point_selected)
        self.ui.coordinatePlot.view_changed.connect(self._update_status)
        self.ui.coordinatePlot.world_sizes_changed.connect(self._world_sizes_changed)
        self.ui.coordinatePlot.xy_effect_range_changed.connect(self._update_xy_heatmap_controls)
        self.ui.chainComboBox.activated.connect(self._chain_selected)
        self.ui.groupComboBox.activated.connect(self.group_selected.emit)
        self.ui.outlineComboBox.currentIndexChanged.connect(self._outline_changed)
        self.ui.labelsCheckBox.toggled.connect(self._labels_enabled_changed)
        self.ui.xyHeatmapCheckBox.toggled.connect(self._xy_heatmap_enabled_changed)
        self.ui.labelModeComboBox.currentIndexChanged.connect(self._label_options_changed)
        self.ui.labelPositionComboBox.currentIndexChanged.connect(self._label_options_changed)
        self.ui.initialLabelSizeSpinBox.valueChanged.connect(self.ui.coordinatePlot.set_label_world_height)
        self.ui.maximumLabelSizeSpinBox.valueChanged.connect(self.ui.coordinatePlot.set_maximum_label_pixel_height)
        self.ui.pointWorldDiameterSpinBox.valueChanged.connect(self.ui.coordinatePlot.set_point_world_diameter)
        self.ui.maximumPointDiameterSpinBox.valueChanged.connect(self.ui.coordinatePlot.set_maximum_point_pixel_diameter)
        self.ui.labelLayoutButton.clicked.connect(self._open_label_layout)
        self.ui.followCheckBox.toggled.connect(self.ui.coordinatePlot.set_auto_focus_enabled)
        self.ui.zoomInButton.clicked.connect(lambda: self.ui.coordinatePlot.zoom(1.5))
        self.ui.zoomOutButton.clicked.connect(lambda: self.ui.coordinatePlot.zoom(1 / 1.5))
        self.ui.resetButton.clicked.connect(self.ui.coordinatePlot.reset_view)
        self.ui.focusButton.clicked.connect(self.ui.coordinatePlot.focus_selection)
        self._labels_enabled_changed(self.ui.labelsCheckBox.isChecked())
        self._update_status(0, 0, 1.)
        self._refresh_favorites()
        self._default_settings = self.export_settings()
        for name, signal in (
            ("outlineComboBox", "currentIndexChanged"), ("labelModeComboBox", "currentIndexChanged"),
            ("labelPositionComboBox", "currentIndexChanged"), ("labelsCheckBox", "toggled"),
            ("followCheckBox", "toggled"), ("settingsToggleButton", "toggled"),
            ("xyHeatmapCheckBox", "toggled"),
            ("initialLabelSizeSpinBox", "valueChanged"), ("maximumLabelSizeSpinBox", "valueChanged"),
            ("pointWorldDiameterSpinBox", "valueChanged"), ("maximumPointDiameterSpinBox", "valueChanged"),
        ):
            getattr(getattr(self.ui, name), signal).connect(self._notify_settings_changed)
        self._last_settings = self.export_settings()
        self._settings_ready = True

    def _notify_settings_changed(self, *_):
        if self._settings_ready and not self._restoring_settings:
            settings = self.export_settings()
            # Native maximize/resize events may arrive after restoration. Only
            # persist a real preference change, not the delayed geometry event.
            if settings != self._last_settings:
                self._last_settings = settings
                self.settings_changed.emit()

    def export_settings(self):
        """Lightweight preferences; generated world defaults remain automatic."""
        plot = self.ui.coordinatePlot
        normal = self.normalGeometry().size() if self.isMaximized() else self.size()
        return {
            "version": 1,
            "label_mode": "always" if self.ui.labelModeComboBox.currentIndex() == 1 else "auto",
            "label_position": ("side", "overlay")[self.ui.labelPositionComboBox.currentIndex()],
            "labels_enabled": self.ui.labelsCheckBox.isChecked(),
            "xy_heatmap_enabled": self.ui.xyHeatmapCheckBox.isChecked(),
            "outline_metric": ("observed", "predicted", None)[self.ui.outlineComboBox.currentIndex()],
            "follow_selection": self.ui.followCheckBox.isChecked(),
            "label_world_height": plot._label_world_height() if plot._label_height_custom else None,
            "point_world_diameter": plot._point_world_diameter() if plot._point_diameter_custom else None,
            "maximum_label_pixel_height": self.ui.maximumLabelSizeSpinBox.value(),
            "maximum_point_pixel_diameter": self.ui.maximumPointDiameterSpinBox.value(),
            "label_layouts": [{"features": list(schema), "rows": [list(row) for row in rows]}
                              for schema, rows in sorted(self._label_layouts.items())],
            "options_expanded": self.ui.settingsToggleButton.isChecked(),
            "favorite_chains": sorted(self._favorite_chains, key=natural_sort_key),
            "favorite_colors": dict(sorted(self._favorite_colors.items(), key=lambda item: natural_sort_key(item[0]))),
            "sidebar_visible": self.ui.sidebarToggleButton.isChecked(),
            "sidebar_width": self._sidebar_width,
            "sidebar_tab": self.ui.sidebarTabs.currentIndex(),
            "window_size": [normal.width(), normal.height()],
            "window_maximized": self.isMaximized(),
        }

    def restore_settings(self, settings):
        """Restore before or after data binding without queuing an autosave."""
        if not isinstance(settings, dict) or settings.get("version", 1) != 1:
            settings = {}
        defaults = self._default_settings

        def choice(key, values):
            value = settings.get(key, defaults[key])
            return value if value in values else defaults[key]

        def boolean(key):
            value = settings.get(key, defaults[key])
            return value if isinstance(value, bool) else defaults[key]

        def number(key):
            value = settings.get(key, defaults[key])
            return (value if isinstance(value, (int, float)) and not isinstance(value, bool)
                    and math.isfinite(value) and value > 0 else defaults[key])

        layouts = {}
        entries = settings.get("label_layouts", [])
        for entry in entries if isinstance(entries, list) else []:
            if not isinstance(entry, dict):
                continue
            features, rows = entry.get("features"), entry.get("rows")
            if (not isinstance(features, list) or not all(isinstance(name, str) for name in features)
                    or not isinstance(rows, list)
                    or not all(isinstance(row, list) and all(isinstance(key, str) for key in row) for row in rows)):
                continue
            schema = tuple(sorted(set(features)))
            layouts[schema] = normalize_label_rows(rows, available_field_keys(schema))

        self._restoring_settings = True
        try:
            self.ui.coordinatePlot.set_auto_focus_enabled(True)
            with ExitStack() as blockers:
                for name in ("labelModeComboBox", "labelPositionComboBox", "labelsCheckBox", "outlineComboBox",
                             "xyHeatmapCheckBox",
                             "followCheckBox", "initialLabelSizeSpinBox", "maximumLabelSizeSpinBox",
                             "pointWorldDiameterSpinBox", "maximumPointDiameterSpinBox", "settingsToggleButton",
                             "sidebarToggleButton", "sidebarTabs"):
                    blockers.enter_context(QSignalBlocker(getattr(self.ui, name)))
                self.ui.labelModeComboBox.setCurrentIndex(("auto", "always").index(choice("label_mode", ("auto", "always"))))
                self.ui.labelPositionComboBox.setCurrentIndex(("side", "overlay").index(choice("label_position", ("side", "overlay"))))
                self.ui.outlineComboBox.setCurrentIndex(("observed", "predicted", None).index(choice("outline_metric", ("observed", "predicted", None))))
                self.ui.labelsCheckBox.setChecked(boolean("labels_enabled"))
                self.ui.xyHeatmapCheckBox.setChecked(boolean("xy_heatmap_enabled"))
                # Older databases used a separate canvas lock. Preserve their
                # intent to keep the view still while allowing manual navigation.
                self.ui.followCheckBox.setChecked(boolean("follow_selection") and settings.get("canvas_locked") is not True)
                self.ui.settingsToggleButton.setChecked(boolean("options_expanded"))
                self.ui.advancedOptionsWidget.setVisible(boolean("options_expanded"))
                self.ui.sidebarToggleButton.setChecked(boolean("sidebar_visible"))
                self.ui.sidebarWidget.setVisible(boolean("sidebar_visible"))
                tab = settings.get("sidebar_tab", defaults["sidebar_tab"])
                self.ui.sidebarTabs.setCurrentIndex(tab if type(tab) is int and 0 <= tab < self.ui.sidebarTabs.count()
                                                   else defaults["sidebar_tab"])
                width = settings.get("sidebar_width", defaults["sidebar_width"])
                self._sidebar_width = (width if type(width) is int and 0 < width <= 32768
                                       else defaults["sidebar_width"])
                self.ui.maximumLabelSizeSpinBox.setValue(number("maximum_label_pixel_height"))
                self.ui.maximumPointDiameterSpinBox.setValue(number("maximum_point_pixel_diameter"))
                plot = self.ui.coordinatePlot
                for key, widget, property_name, flag in (
                    ("label_world_height", self.ui.initialLabelSizeSpinBox, "labelWorldHeight", "_label_height_custom"),
                    ("point_world_diameter", self.ui.pointWorldDiameterSpinBox, "pointWorldDiameter", "_point_diameter_custom"),
                ):
                    value = number(key)
                    setattr(plot, flag, value is not None)
                    if value is not None:
                        widget.setValue(value)
                        plot.setProperty(property_name, widget.value())
            self._label_layouts = layouts
            favorites = settings.get("favorite_chains", [])
            self._favorite_chains = {value for value in favorites if isinstance(value, str) and value} if isinstance(favorites, list) else set()
            colors = settings.get("favorite_colors", {})
            self._favorite_colors = dict(colors) if isinstance(colors, dict) else {}
            self._refresh_favorites()
            plot.set_maximum_label_pixel_height(self.ui.maximumLabelSizeSpinBox.value())
            plot.set_maximum_point_pixel_diameter(self.ui.maximumPointDiameterSpinBox.value())
            # Rebind to recalculate automatic dimensions and discard the previous
            # database's cached reservations before applying the restored layout.
            plot.set_points(plot.points)
            self._bind_xy_heatmap()
            rows = layouts.get(self._label_schema, default_label_rows(self._label_features))
            plot.set_label_rows(rows, self._label_features)
            self._labels_enabled_changed(self.ui.labelsCheckBox.isChecked())
            self._outline_changed()
            self.set_selected_chain(None, focus=False)
            plot.reset_view()
            if self._label_layout_dialog is not None:
                self._bind_label_layout(rows)
            size = settings.get("window_size", defaults["window_size"])
            if (not isinstance(size, list) or len(size) != 2
                    or not all(isinstance(value, int) and not isinstance(value, bool) and 0 < value <= 32768 for value in size)):
                size = defaults["window_size"]
            state = self.windowState() & ~(Qt.WindowMaximized | Qt.WindowMinimized)
            self.setWindowState(state)
            self.resize(*size)
            self._apply_sidebar_width()
            if boolean("window_maximized"):
                self.setWindowState(state | Qt.WindowMaximized)
            plot.set_auto_focus_enabled(self.ui.followCheckBox.isChecked())
        finally:
            self._last_settings = self.export_settings()
            self._restoring_settings = False

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if getattr(self, "_settings_ready", False) and self.isVisible():
            self._notify_settings_changed()

    def changeEvent(self, event):
        super().changeEvent(event)
        if event.type() == QEvent.WindowStateChange and getattr(self, "_settings_ready", False) and self.isVisible():
            self._notify_settings_changed()

    def _text(self, name, **values):
        return str(self.property(name) or "").format(**values)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            plot = self.ui.coordinatePlot
            selected = bool(plot.selected_chains or plot.selected_instances)
            self.set_selected_chain(None, focus=False)
            if selected:
                self.chain_selection_cleared.emit()
            event.accept()
            return
        super().keyPressEvent(event)

    def _world_sizes_changed(self, label_height, point_diameter):
        with QSignalBlocker(self.ui.initialLabelSizeSpinBox), QSignalBlocker(self.ui.pointWorldDiameterSpinBox):
            self.ui.initialLabelSizeSpinBox.setValue(label_height)
            self.ui.pointWorldDiameterSpinBox.setValue(point_diameter)

    def set_payload_group(self, payload, group):
        group_changed = self._payload_group is not group
        if self._payload is not payload or group_changed:
            self.set_failed_samples_state()
        self._payload = payload
        self._payload_group = group
        points, self._topology = coordinate_instances(payload, group)
        initialize_view = bool(points) and not self._coordinate_view_initialized
        if initialize_view:
            # Fit the first layout, including its restored labels, even when
            # automatic focus was disabled in the saved preferences.
            self.ui.coordinatePlot.set_auto_focus_enabled(True)
        self._available_chains = {point.chain_id for point in points}
        self._chains = {str(row.get("chain_id")): row for row in group.get("chains", [])}
        self._coincident = len(points) - len({(p.x, p.y) for p in points})
        with QSignalBlocker(self.ui.groupComboBox):
            self.ui.groupComboBox.clear()
            for index, entry in enumerate(payload.get("groups", [])):
                self.ui.groupComboBox.addItem(str(entry.get("label") or entry.get("node") or index + 1))
                if entry is group:
                    self.ui.groupComboBox.setCurrentIndex(index)
        self.ui.groupComboBox.setEnabled(self.ui.groupComboBox.count() > 1)
        config = payload.get("provenance", {}).get("template_snapshot", {}).get("tsk_analysis", {})
        self.ui.contextLabel.setText(self._text("contextFormat", mode=self._text(payload.get("coordinate_view_mode", "fitted") + "ModeText"),
                                              unit=config.get("coordinate_unit") or self._text("unknownUnitText")))
        with QSignalBlocker(self.ui.chainComboBox):
            self.ui.chainComboBox.clear()
            self.ui.chainComboBox.addItem(self._text("allChainsText"), None)
            for chain in sorted({str(row.get("chain_id", "")) for row in self._topology} | set(self._chains), key=natural_sort_key):
                self.ui.chainComboBox.addItem(chain, chain)
        self.ui.coordinatePlot.set_points(points)
        self._bind_xy_heatmap()
        self.ui.searchPanel.set_context(points, self._topology, group, reset=group_changed, template_config=config)
        self._refresh_favorites()
        self._label_features = list(dict.fromkeys(name for row in self._topology for name in (row.get("features") or {})))
        self._label_schema = tuple(sorted(self._label_features))
        rows = self._label_layouts.get(self._label_schema, default_label_rows(self._label_features))
        self.ui.coordinatePlot.set_label_rows(rows, self._label_features)
        # Automatic group fitting includes the current schema's complete labels.
        if self.ui.labelsCheckBox.isChecked() and self.ui.coordinatePlot.auto_focus_enabled:
            self.ui.coordinatePlot.reset_view()
        if initialize_view:
            self._coordinate_view_initialized = True
            self.ui.coordinatePlot.set_auto_focus_enabled(self.ui.followCheckBox.isChecked())
        if self._label_layout_dialog is not None:
            self._bind_label_layout(rows)
        self.ui.pointLegendLabel.setText(self._range_text(self.ui.coordinatePlot.point_range))
        self._outline_changed()
        self.set_selected_chain(None)
        self._update_status(0, len(points), 1.)

    def _range_text(self, bounds):
        return (self._text("legendFormat", low=percentage(bounds[0]), high=percentage(bounds[1]))
                if bounds is not None else self._text("unavailableText"))

    def _bind_xy_heatmap(self):
        plot = self.ui.coordinatePlot
        surface, reason = coordinate_effect_surface(self._payload_group or {})
        if surface is not None and not plot.points:
            surface, reason = None, "no_coordinates"
        self._xy_heatmap_reason = reason
        bounds = plot.set_xy_effect_surface(surface)
        if surface is not None and bounds is None:
            reason = "invalid_fit_data"
        self._xy_heatmap_reason = reason
        self._xy_heatmap_enabled_changed(self.ui.xyHeatmapCheckBox.isChecked())

    def _xy_heatmap_enabled_changed(self, checked):
        plot = self.ui.coordinatePlot
        available = plot.xy_effect_range is not None
        plot.set_xy_heatmap_enabled(bool(checked and available))
        self._update_xy_heatmap_controls()

    def _update_xy_heatmap_controls(self):
        """Refresh canvas-dependent legend values without changing plot state."""
        plot = self.ui.coordinatePlot
        available = plot.xy_effect_range is not None
        self.ui.xyHeatmapCheckBox.setEnabled(available)
        checked = self.ui.xyHeatmapCheckBox.isChecked()
        self.ui.xyHeatmapGradient.set_range(plot.xy_effect_range)
        self.ui.xyHeatmapGradient.setVisible(available)
        self.ui.xyHeatmapGradient.setEnabled(bool(checked and available))
        if available:
            self.ui.xyHeatmapLegendLabel.setText(self._text("xyHeatmapLegendFormat"))
            tooltip = self._text("xyHeatmapToolTip")
        else:
            property_name = {
                "no_xy_fit": "xyHeatmapNoFitText",
                "unsupported_model": "xyHeatmapUnsupportedText",
                "fit_not_converged": "xyHeatmapNotConvergedText",
                "not_identifiable": "xyHeatmapNotIdentifiableText",
                "boundary_invalid": "xyHeatmapBoundaryInvalidText",
                "no_coordinates": "xyHeatmapNoCoordinatesText",
            }.get(self._xy_heatmap_reason, "xyHeatmapInvalidText")
            reason = self._text(property_name)
            self.ui.xyHeatmapLegendLabel.setText(reason)
            tooltip = self._text("xyHeatmapUnavailableToolTipFormat", reason=reason)
        self.ui.xyHeatmapCheckBox.setToolTip(tooltip)
        self.ui.xyHeatmapLegendLabel.setToolTip(tooltip)

    def _preview_point(self):
        plot = self.ui.coordinatePlot
        selected = plot.highlighted_indexes
        return plot.points[min(selected)] if selected else next(iter(plot.points), None)

    def _bind_label_layout(self, rows):
        self._label_layout_dialog.set_context(self._label_features, rows, self._preview_point(),
                                             str(self.ui.coordinatePlot.property("labelValueSeparator")))

    def _open_label_layout(self):
        if self._label_layout_dialog is None:
            from .tsk_label_layout_dialog import TskLabelLayoutDialog
            self._label_layout_dialog = TskLabelLayoutDialog(self)
            self._label_layout_dialog.layout_changed.connect(self._label_layout_changed)
            rows = self.ui.coordinatePlot.label_rows
            self._bind_label_layout(rows if rows is not None else default_label_rows(self._label_features))
        self._label_layout_dialog.show()
        self._label_layout_dialog.raise_()
        self._label_layout_dialog.activateWindow()

    def _label_layout_changed(self, rows):
        self._label_layouts[self._label_schema] = [list(row) for row in rows]
        self.ui.coordinatePlot.set_label_rows(rows, self._label_features)
        self._notify_settings_changed()

    def _labels_enabled_changed(self, enabled):
        self.ui.coordinatePlot.set_labels_enabled(enabled)
        self._label_options_changed()

    def _label_options_changed(self, *_):
        enabled = self.ui.labelsCheckBox.isChecked()
        always = self.ui.labelModeComboBox.currentIndex() == 1
        self.ui.labelModeLabel.setEnabled(enabled)
        self.ui.labelModeComboBox.setEnabled(enabled)
        for widget in (self.ui.labelPositionLabel, self.ui.labelPositionComboBox,
                       self.ui.initialLabelSizeLabel, self.ui.initialLabelSizeSpinBox,
                       self.ui.maximumLabelSizeLabel, self.ui.maximumLabelSizeSpinBox):
            widget.setEnabled(enabled)
        plot = self.ui.coordinatePlot
        plot.set_label_mode("always" if always else "auto")
        plot.set_label_position(("side", "overlay")[self.ui.labelPositionComboBox.currentIndex()])

    def _outline_changed(self, *_):
        plot = self.ui.coordinatePlot
        plot.set_outline_metric(("observed", "predicted", None)[self.ui.outlineComboBox.currentIndex()])
        self.ui.ringLegendTitle.setText(self.ui.ringLegendTitle.property("formatText").format(metric=self.ui.outlineComboBox.currentText()))
        self.ui.ringLegendLabel.setText(self._range_text(plot.ring_range))
        self.ui.ringGradient.setVisible(plot.outline_metric is not None)
        self.ui.ringLegendLabel.setVisible(plot.outline_metric is not None)

    def _apply_sidebar_width(self):
        if self.ui.sidebarToggleButton.isChecked():
            splitter = self.ui.coordinateSplitter
            splitter.setSizes([max(1, splitter.width() - self._sidebar_width - splitter.handleWidth()),
                               self._sidebar_width])

    def _sidebar_visibility_changed(self, visible):
        if visible:
            self._apply_sidebar_width()
        self._notify_settings_changed()

    def _sidebar_resized(self, *_):
        if self.ui.sidebarToggleButton.isChecked() and self.ui.coordinateSplitter.sizes()[1] > 0:
            self._sidebar_width = self.ui.coordinateSplitter.sizes()[1]
            self._notify_settings_changed()

    def _refresh_favorites(self):
        widget = self.ui.favoriteChainsList
        self._favorite_colors = assign_favorite_colors(self._favorite_chains, self._favorite_colors,
                                                       self.property("favoriteChainPalette"))
        self.ui.coordinatePlot.set_chain_highlight_colors(self._favorite_colors)
        current = widget.currentItem().data(Qt.UserRole) if widget.currentItem() else None
        with QSignalBlocker(widget):
            widget.clear()
            for chain in sorted(self._favorite_chains, key=natural_sort_key):
                available = chain in self._available_chains
                item = QListWidgetItem(self._text("favoriteItemFormat" if available else "favoriteUnavailableFormat", chain=chain))
                item.setData(Qt.UserRole, chain)
                color = QColor(self._favorite_colors[chain])
                item.setBackground(color)
                item.setForeground(contrast_text_color(color))
                item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | (Qt.ItemIsUserCheckable if available else Qt.NoItemFlags))
                item.setCheckState(Qt.Checked if available and chain in self.ui.coordinatePlot.selected_chains else Qt.Unchecked)
                item.setToolTip(self._text("favoriteToolTipFormat", chain=chain) if available else self._text("favoriteUnavailableToolTip"))
                widget.addItem(item)
                if chain == current:
                    widget.setCurrentItem(item)
        self._update_favorite_controls()
        if self._favorite_samples_dialog is not None:
            self._favorite_samples_dialog.set_context(self._payload_group or {}, self._favorite_chains)
            self._favorite_samples_dialog.set_failed_samples_state(
                loading=self._failed_samples_loading, error=self._failed_samples_error)

    def set_failed_samples_state(self, *, loading=False, error=""):
        self._failed_samples_loading = loading
        self._failed_samples_error = error
        if self._favorite_samples_dialog is not None:
            self._favorite_samples_dialog.set_failed_samples_state(loading=loading, error=error)

    def refresh_failed_samples(self):
        """Refresh recovered identities without rebinding the coordinate plot."""
        if self._favorite_samples_dialog is not None:
            self._favorite_samples_dialog.set_context(self._payload_group or {}, self._favorite_chains)
        self.set_failed_samples_state()

    def _open_favorite_samples(self):
        if self._favorite_samples_dialog is None:
            from .tsk_favorite_samples_dialog import TskFavoriteSamplesDialog
            self._favorite_samples_dialog = TskFavoriteSamplesDialog(self)
        self._favorite_samples_dialog.set_context(self._payload_group or {}, self._favorite_chains)
        self._favorite_samples_dialog.set_failed_samples_state(
            loading=self._failed_samples_loading, error=self._failed_samples_error)
        self._favorite_samples_dialog.show()
        self._favorite_samples_dialog.raise_()
        self._favorite_samples_dialog.activateWindow()
        if failed_sample_outcomes(self._payload_group or {}) is None and not self._failed_samples_loading:
            self.failed_samples_requested.emit()

    def _update_favorite_controls(self, *_):
        chain = self.ui.coordinatePlot.selected_chain
        self.ui.addFavoriteButton.setEnabled(bool(chain is not None and chain not in self._favorite_chains))
        self.ui.removeFavoriteButton.setEnabled(self.ui.favoriteChainsList.currentItem() is not None)
        self.ui.obtainFailedSamplesButton.setEnabled(bool(self._favorite_chains))
        self.ui.favoriteStatusLabel.setText(self._text("favoriteStatusFormat", total=len(self._favorite_chains),
            selected=len(self._favorite_chains.intersection(self.ui.coordinatePlot.selected_chains)))
            if self._favorite_chains else self._text("favoritesEmptyText"))

    def _sync_favorite_checks(self):
        widget = self.ui.favoriteChainsList
        selected = self.ui.coordinatePlot.selected_chains
        with QSignalBlocker(widget):
            for index in range(widget.count()):
                item = widget.item(index)
                item.setCheckState(Qt.Checked if item.data(Qt.UserRole) in selected else Qt.Unchecked)
        self._update_favorite_controls()

    def _add_favorite(self):
        chain = self.ui.coordinatePlot.selected_chain
        if chain is not None and chain not in self._favorite_chains:
            self._favorite_chains.add(chain)
            self._refresh_favorites()
            self._notify_settings_changed()

    def _remove_favorite(self):
        item = self.ui.favoriteChainsList.currentItem()
        if item is None:
            return
        chain = item.data(Qt.UserRole)
        self._favorite_chains.discard(chain)
        selected = self.ui.coordinatePlot.selected_chains - {chain}
        self._refresh_favorites()
        if chain in self.ui.coordinatePlot.selected_chains:
            self._select_chains(selected, focus=False)
        self._notify_settings_changed()

    def _favorite_highlights_changed(self, *_):
        widget = self.ui.favoriteChainsList
        chains = {widget.item(index).data(Qt.UserRole) for index in range(widget.count())
                  if widget.item(index).checkState() == Qt.Checked}
        self._select_chains(chains.intersection(self._available_chains))

    def _favorite_activated(self, item):
        chain = item.data(Qt.UserRole)
        if chain in self._available_chains:
            self._activate_chain(chain)

    def _clear_linked_chain_selection(self):
        # Clearing the result table echoes set_selected_chain(None) back here.
        # Keep the map's independently selected instances or multiple chains.
        self._syncing_linked_selection = True
        try:
            self.chain_selection_cleared.emit()
        finally:
            self._syncing_linked_selection = False

    def _select_chains(self, chains, *, focus=None):
        plot = self.ui.coordinatePlot
        chains = set(chains)
        changed = chains != plot.selected_chains or bool(plot.selected_instances)
        plot.set_highlighted_chains(chains, focus=changed and (self.ui.followCheckBox.isChecked() if focus is None else focus))
        self.ui.searchPanel.clear_selection()
        self._sync_selection_controls()
        if plot.selected_chain is not None:
            self.chain_selected.emit(plot.selected_chain)
        else:
            self._clear_linked_chain_selection()

    def _instances_selected(self, indexes):
        plot = self.ui.coordinatePlot
        plot.set_selected_instances(indexes, focus=self.ui.followCheckBox.isChecked())
        self._sync_selection_controls()
        self._clear_linked_chain_selection()

    def _search_chain_selected(self, chain_id):
        # Both this activation and the result table's synchronous echo must keep
        # the clicked result row, so keyboard navigation continues from it.
        self._selecting_search_chain = True
        try:
            self._activate_chain(chain_id)
        finally:
            self._selecting_search_chain = False

    def set_selected_chain(self, chain_id, *, focus=None):
        if self._syncing_linked_selection:
            return
        plot = self.ui.coordinatePlot
        changed = plot.selected_chains != ({str(chain_id)} if chain_id is not None else set()) or bool(plot.selected_instances)
        plot.set_selected_chain(chain_id, focus=changed and (self.ui.followCheckBox.isChecked() if focus is None else focus))
        if not self._selecting_search_chain:
            self.ui.searchPanel.clear_selection()
        self._sync_selection_controls()

    def _sync_selection_controls(self):
        plot = self.ui.coordinatePlot
        chain_id = plot.selected_chain
        with QSignalBlocker(self.ui.chainComboBox):
            if len(plot.selected_chains) > 1 or plot.selected_instances:
                self.ui.chainComboBox.setCurrentIndex(-1)
                self.ui.chainComboBox.setEditText("")
            else:
                self.ui.chainComboBox.setCurrentIndex(max(0, self.ui.chainComboBox.findData(chain_id)))
        selected = [plot.points[index] for index in sorted(plot.highlighted_indexes)]
        self.ui.focusButton.setEnabled(bool(selected))
        self._sync_favorite_checks()
        if self._label_layout_dialog is not None:
            self._label_layout_dialog.set_preview_point(self._preview_point())
        if plot.selected_instances and selected:
            current = self.ui.searchPanel.ui.resultsTreeWidget.currentItem()
            data = current.data(0, Qt.UserRole) if current is not None else {}
            if data and data.get("kind") == "combination":
                self.ui.selectionLabel.setText(self._text("combinationSelectionFormat", combination=current.text(0),
                    count=len(selected), chains=len({point.chain_id for point in selected})))
            else:
                self.ui.selectionLabel.setText(self._text("instanceSelectionFormat",
                    tsk=", ".join(dict.fromkeys(point.tsk_id for point in selected)),
                    instance=", ".join(dict.fromkeys(point.instance_id for point in selected)),
                    chain=", ".join(sorted({point.chain_id for point in selected}, key=natural_sort_key))))
        elif len(plot.selected_chains) > 1:
            self.ui.selectionLabel.setText(self._text("multiSelectionFormat", chains=len(plot.selected_chains), shown=len(selected)))
        elif chain_id is None:
            self.ui.selectionLabel.setText(self._text("noSelectionText"))
        else:
            chain = self._chains.get(chain_id, {})
            self.ui.selectionLabel.setText(self._text("selectionFormat", chain=chain_id, shown=len(selected),
                total=sum(str(row.get("chain_id", "")) == chain_id for row in self._topology),
                observed=percentage(chain_probability(chain, "observed_probability")),
                predicted=percentage(chain_probability(chain, "predicted_probability"))))

    def _activate_chain(self, chain_id):
        self.set_selected_chain(chain_id)
        if chain_id is not None:
            self.chain_selected.emit(chain_id)
        else:
            self._clear_linked_chain_selection()

    def _chain_selected(self):
        self._activate_chain(self.ui.chainComboBox.currentData())

    def _commit_chain_text(self):
        text = self.ui.chainComboBox.currentText().strip().casefold()
        if text == self._text("allChainsText").casefold() or not text:
            self._activate_chain(None)
            return
        choices = [self.ui.chainComboBox.itemData(index) for index in range(self.ui.chainComboBox.count())
                   if self.ui.chainComboBox.itemData(index) is not None]
        matches = [chain for chain in choices if chain.casefold() == text]
        if not matches:
            matches = [chain for chain in choices if matches_search(chain, text)]
        if len(matches) == 1:
            self._activate_chain(matches[0])
        else:
            self.ui.selectionLabel.setText(self._text("chainSearchAmbiguousText" if matches else "chainSearchNoMatchText"))

    def _point_selected(self, chain_id):
        # Keep the clicked point under the cursor, including coincident chains.
        self.set_selected_chain(chain_id, focus=False)
        self.chain_selected.emit(chain_id)

    def _update_status(self, labels, visible, zoom):
        plot = self.ui.coordinatePlot
        shown, total = len(plot.points), len(self._topology)
        minimum, maximum = plot.zoom_limits()
        relative_zoom = plot.relative_zoom()
        maximum_relative_zoom = maximum / minimum
        self.ui.zoomRangeLabel.setText(self._text("zoomRangeFormat", maximum=f"{maximum_relative_zoom:g}"))
        self.ui.zoomOutButton.setEnabled(bool(shown) and relative_zoom > 1. + 1e-9)
        self.ui.zoomInButton.setEnabled(bool(shown) and relative_zoom < maximum_relative_zoom - 1e-9)
        self.ui.statusLabel.setText(self._text("statusFormat", shown=shown, total=total, missing=total - shown,
            coincident=self._coincident, zoom=f"{relative_zoom:.2g}", labels=labels, visible=visible))
