"""Shared display-value column filters for direct and proxy table models."""
from __future__ import annotations

import math
import re

from PySide6.QtCore import QModelIndex, QSortFilterProxyModel, Qt


class ColumnFilterMixin:
    """Implement filters using source-row, display-value and refresh hooks."""

    def _init_column_filters(self):
        self._column_filters = {}

    def column_filter(self, column):
        return self._column_filters.get(column)

    def set_column_filter(self, column, values):
        if not 0 <= column < self.columnCount():
            return
        selected = None if values is None else frozenset(str(value) for value in values)
        if selected == self.column_filter(column):
            return
        self._before_column_filters_change()
        if selected is None:
            self._column_filters.pop(column, None)
        else:
            self._column_filters[column] = selected
        self._apply_column_filters()
        self.headerDataChanged.emit(Qt.Horizontal, column, column)

    def clear_column_filters(self):
        if not self._column_filters:
            return
        self._before_column_filters_change()
        columns = list(self._column_filters)
        self._column_filters.clear()
        self._apply_column_filters()
        self.headerDataChanged.emit(Qt.Horizontal, min(columns), max(columns))

    def has_column_filters(self):
        return bool(self._column_filters)

    def column_values(self, column):
        """Offer the full source column so selections never depend on filter order."""
        values = self.all_column_values(column)
        return sorted(values, key=lambda value: (self._natural_sort_key(value), value))

    def all_column_values(self, column):
        if not 0 <= column < self.columnCount():
            return set()
        return {self._filter_value(row, column) for row in self._filter_source_rows()}

    def total_row_count(self):
        return len(self._filter_source_rows())

    def _matches_column_filters(self, row, excluding=None):
        return all(self._filter_value(row, column) in values
                   for column, values in self._column_filters.items() if column != excluding)

    def _matches_search(self, row):
        return True

    def _before_column_filters_change(self):
        pass

    def _prune_column_filters(self):
        self._column_filters = {column: values for column, values in self._column_filters.items()
                                if 0 <= column < self.columnCount()}

    @staticmethod
    def _natural_sort_key(value):
        return tuple((0, int(part)) if part.isdigit() else (1, part.lower())
                     for part in re.split(r"(\d+)", value) if part)


class ColumnFilterProxyModel(ColumnFilterMixin, QSortFilterProxyModel):
    """Keep Qt sorting and index mapping while filtering displayed cell values."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_column_filters()
        self._filter_schema = ()

    def setSourceModel(self, source_model):
        previous = self.sourceModel()
        if previous is source_model:
            return
        if previous is not None:
            for signal in (previous.modelReset, previous.columnsInserted, previous.columnsRemoved,
                           previous.columnsMoved, previous.headerDataChanged):
                signal.disconnect(self._source_schema_changed)
        self._column_filters.clear()
        super().setSourceModel(source_model)
        self._filter_schema = self._source_schema()
        if source_model is not None:
            for signal in (source_model.modelReset, source_model.columnsInserted, source_model.columnsRemoved,
                           source_model.columnsMoved, source_model.headerDataChanged):
                signal.connect(self._source_schema_changed)

    def _source_schema(self):
        source = self.sourceModel()
        if source is None:
            return ()
        return tuple(source.headerData(column, Qt.Horizontal, Qt.DisplayRole)
                     for column in range(source.columnCount()))

    def _source_schema_changed(self, *_args):
        schema = self._source_schema()
        if schema != self._filter_schema:
            self._filter_schema = schema
            self.clear_column_filters()

    def _filter_source_rows(self):
        source = self.sourceModel()
        return range(source.rowCount()) if source is not None else range(0)

    def _filter_value(self, row, column):
        source = self.sourceModel()
        value = source.data(source.index(row, column), Qt.DisplayRole)
        return "" if value is None else str(value)

    def _matches_search(self, row):
        return QSortFilterProxyModel.filterAcceptsRow(self, row, QModelIndex())

    def _apply_column_filters(self):
        if hasattr(self, "endFilterChange"):
            self.endFilterChange(QSortFilterProxyModel.Direction.Rows)
        else:
            self.invalidateFilter()

    def _before_column_filters_change(self):
        if hasattr(self, "endFilterChange"):
            self.beginFilterChange()

    def filterAcceptsRow(self, source_row, source_parent):
        return (QSortFilterProxyModel.filterAcceptsRow(self, source_row, source_parent)
                and self._matches_column_filters(source_row))


class MissingLastColumnFilterProxyModel(ColumnFilterProxyModel):
    """Keep unavailable estimates last when Qt reverses the comparison order."""

    def lessThan(self, left, right):
        left_value, right_value = left.data(self.sortRole()), right.data(self.sortRole())
        left_missing = left_value is None or isinstance(left_value, float) and math.isnan(left_value)
        right_missing = right_value is None or isinstance(right_value, float) and math.isnan(right_value)
        if left_missing or right_missing:
            if left_missing == right_missing:
                return False
            return left_missing if self.sortOrder() == Qt.DescendingOrder else right_missing
        return super().lessThan(left, right)
