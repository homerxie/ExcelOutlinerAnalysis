"""Completion choices use the same fragment matching as text searches."""
from __future__ import annotations

from PySide6.QtCore import QSortFilterProxyModel, Qt
from PySide6.QtWidgets import QCompleter

from ..text_search import matches_search


class _FragmentSearchProxyModel(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._query = ""

    def set_query(self, query):
        if query != self._query:
            if hasattr(self, "endFilterChange"):
                self.beginFilterChange()
            self._query = query
            if hasattr(self, "endFilterChange"):
                self.endFilterChange(QSortFilterProxyModel.Direction.Rows)
            else:
                self.invalidateFilter()

    def filterAcceptsRow(self, row, parent):
        model = self.sourceModel()
        value = model.data(model.index(row, 0, parent), Qt.DisplayRole)
        return matches_search("" if value is None else str(value), self._query)


class FragmentSearchCompleter(QCompleter):
    """A standard completer whose prefix can contain separated fragments.

    Keep the original model intact and filter a proxy before Qt builds its
    completion list. An empty Qt prefix prevents a second contiguous match.
    """

    def __init__(self, model, parent=None):
        self._search_proxy = _FragmentSearchProxyModel()
        self._search_proxy.setSourceModel(model)
        super().__init__(self._search_proxy, parent)
        self._search_proxy.setParent(self)
        self.setCaseSensitivity(Qt.CaseInsensitive)
        self.setCompletionRole(Qt.DisplayRole)
        self.setCompletionMode(QCompleter.PopupCompletion)

    def splitPath(self, path):
        self._search_proxy.set_query(path)
        return [""]
