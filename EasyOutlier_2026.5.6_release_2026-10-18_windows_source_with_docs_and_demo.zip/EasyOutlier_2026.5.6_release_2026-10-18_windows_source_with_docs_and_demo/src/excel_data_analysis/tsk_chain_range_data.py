"""Observed chain data for heatmaps, without fitting a TSK probability model."""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path

from .tsk_coordinate_data import coordinate_preview_from_snapshot
from .tsk_features import category_combination_label, category_label
from .tsk_observations import read_analysis_snapshot
from .tsk_sorting import natural_sort_key


def load_chain_range_preview(*, template_path, analysis_template=None, source="database",
                             storage_path=None, input_path=None, golden_path=None,
                             settings=None, analysis_snapshot_path=None, progress_callback=None):
    """Read saved classifications or classify the current data solely in memory.

    Node and sample choices select the finished observations. Keeping their
    predecessors and the analysis population during classification preserves
    Analyze's New/Existed history and Modified Z Score reference scope.
    """
    progress = progress_callback or (lambda *_args: None)
    options = deepcopy(settings or {})
    if analysis_snapshot_path and Path(analysis_snapshot_path).is_file():
        progress(10, "读取已保存的链路判定…")
        snapshot = read_analysis_snapshot(analysis_snapshot_path)
        observation_source = "analyze"
        warnings = []
    else:
        if source == "analyze":
            # A caller explicitly bound to a saved run must not silently
            # replace that run with classifications from a different source.
            read_analysis_snapshot(analysis_snapshot_path)
        from .reporting import analyze_outlier_report_from_measurements
        from .template import load_template
        from .tsk_service import _load_tsk_selection

        template = deepcopy(analysis_template) if analysis_template is not None else load_template(template_path)
        # Explicit live Analyze filters replace the template's saved defaults.
        # The loader still applies any filter family without a live override.
        for name in ("dimension_filters", "column_filters"):
            if name in options:
                attribute = "analysis_" + name
                setattr(template.report, attribute, type(getattr(template.report, attribute))())
        progress(5, "读取链路观测所需的测量数据…")
        measurements, rows, warnings = _load_tsk_selection(
            template, source=source, storage_path=storage_path, input_path=input_path,
            options={**options, "nodes": [], "sample_ids": [], "dataset_ids": options.get("dataset_ids") or []},
        )
        if options.get("dimension_filters") or options.get("column_filters"):
            from .reporting import _build_rows_from_measurements
            from .service import _filter_measurements

            missing_columns = {row.dataset_id: row.missing_columns for row in rows}
            measurements = _filter_measurements(
                measurements, dimension_filters=options.get("dimension_filters"),
                column_filters=options.get("column_filters"), template=template, compact=True,
            )
            rows = _build_rows_from_measurements(measurements, missing_columns)
            if not rows:
                raise ValueError("所选范围没有可用于链路观测的样品数据。")
        snapshot = analyze_outlier_report_from_measurements(
            template_path, measurements, built_golden_path=golden_path,
            analysis_template=template, input_rows=rows,
            zscore_threshold_override=template.report.zscore_thresholds.default,
            progress_callback=lambda value, message: progress(10 + int(value * .8), message),
        )
        observation_source = "measurements"
    progress(95, "汇总链路观测失效率…")
    payload = coordinate_preview_from_snapshot(snapshot, options)
    payload["observation_source"] = observation_source
    if warnings:
        payload["warnings"] = list(warnings)
    progress(100, "链路观测失效率已准备完成。")
    return payload


def heatmap_preview_from_observations(payload, categorical_names=None):
    """Add only the TSK/category combinations present in the retained layout.

    The returned rows describe observations, not model estimates. An instance
    missing any requested category cannot establish a matching combination.
    """
    preview = deepcopy(payload or {})
    config = (preview.get("provenance") or {}).get("template_snapshot", {}).get("tsk_analysis", {})
    names = list(dict.fromkeys(config.get("categorical_feature_columns", [])
                              if categorical_names is None else categorical_names))
    combinations = {}
    type_ids = set()
    for instance in preview.get("topology") or []:
        tsk_id, chain_id = instance.get("tsk_id"), instance.get("chain_id")
        if tsk_id is None or not str(tsk_id).strip() or chain_id is None or not str(chain_id).strip():
            continue
        tsk_id = str(tsk_id)
        type_ids.add(tsk_id)
        values = {**(instance.get("features") or {}), **(instance.get("categories") or {})}
        try:
            categories = {name: category_label(values.get(name), name) for name in names}
        except ValueError:
            continue
        key = (tsk_id, tuple(categories.values()))
        if key not in combinations:
            combinations[key] = {
                "tsk_id": tsk_id, "categories": categories,
                "level": category_combination_label(categories),
                "layout_instance_count": 0, "observation_only": True,
            }
        combinations[key]["layout_instance_count"] += 1
    keys = sorted(combinations, key=lambda key: (natural_sort_key(key[0]),
                  tuple(natural_sort_key(value) for value in key[1]), key))
    rows = [combinations[key] for key in keys]
    categories = {name: {"levels": sorted({row["categories"][name] for row in rows}, key=natural_sort_key)}
                  for name in names}
    preview["observation_only"] = True
    for group in preview.get("groups") or []:
        group["observation_only"] = True
        group["types"] = [{"tsk_id": tsk_id} for tsk_id in sorted(type_ids, key=natural_sort_key)]
        group["observation_rows"] = deepcopy(rows)
        group["observation_categories"] = deepcopy(categories)
    return preview
