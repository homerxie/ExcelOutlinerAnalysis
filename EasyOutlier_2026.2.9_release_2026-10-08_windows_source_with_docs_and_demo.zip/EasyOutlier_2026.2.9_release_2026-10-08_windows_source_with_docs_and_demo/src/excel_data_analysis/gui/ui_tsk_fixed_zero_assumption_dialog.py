# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_fixed_zero_assumption_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog, QDialogButtonBox,
    QPlainTextEdit, QSizePolicy, QVBoxLayout, QWidget)

class Ui_TskFixedZeroAssumptionDialogForm(object):
    def setupUi(self, TskFixedZeroAssumptionDialogForm):
        if not TskFixedZeroAssumptionDialogForm.objectName():
            TskFixedZeroAssumptionDialogForm.setObjectName(u"TskFixedZeroAssumptionDialogForm")
        TskFixedZeroAssumptionDialogForm.resize(540, 350)
        TskFixedZeroAssumptionDialogForm.setMinimumSize(QSize(320, 220))
        TskFixedZeroAssumptionDialogForm.setSizeGripEnabled(True)
        self.dialogLayout = QVBoxLayout(TskFixedZeroAssumptionDialogForm)
        self.dialogLayout.setSpacing(8)
        self.dialogLayout.setObjectName(u"dialogLayout")
        self.dialogLayout.setContentsMargins(12, 12, 12, 12)
        self.detailsTextEdit = QPlainTextEdit(TskFixedZeroAssumptionDialogForm)
        self.detailsTextEdit.setObjectName(u"detailsTextEdit")
        self.detailsTextEdit.setReadOnly(True)

        self.dialogLayout.addWidget(self.detailsTextEdit)

        self.buttonBox = QDialogButtonBox(TskFixedZeroAssumptionDialogForm)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.StandardButton.Close)

        self.dialogLayout.addWidget(self.buttonBox)


        self.retranslateUi(TskFixedZeroAssumptionDialogForm)
        self.buttonBox.rejected.connect(TskFixedZeroAssumptionDialogForm.reject)

        QMetaObject.connectSlotsByName(TskFixedZeroAssumptionDialogForm)
    # setupUi

    def retranslateUi(self, TskFixedZeroAssumptionDialogForm):
        TskFixedZeroAssumptionDialogForm.setWindowTitle(QCoreApplication.translate("TskFixedZeroAssumptionDialogForm", u"\u56fa\u5b9a\u96f6\u98ce\u9669\u5047\u8bbe\u8be6\u60c5", None))
        self.detailsTextEdit.setProperty(u"displayFormat", QCoreApplication.translate("TskFixedZeroAssumptionDialogForm", u"\u56fa\u5b9a\u96f6\u98ce\u9669\u5047\u8bbe\u4e0b\u7684\u6761\u4ef6\u5206\u6790\n"
"\n"
"\u56fa\u5b9a\u4e3a 0 \u7684 TSK\uff1a{tsk_ids}\n"
"\n"
"{warning}\n"
"\n"
"{scope}", None))
        self.detailsTextEdit.setProperty(u"defaultWarning", QCoreApplication.translate("TskFixedZeroAssumptionDialogForm", u"\u8fd9\u4e9b TSK \u7684\u771f\u5b9e\u5355\u5b9e\u4f8b\u5931\u6548\u6982\u7387\u5047\u5b9a\u4e3a 0\u3002\u82e5\u5b9e\u9645\u98ce\u9669\u975e\u96f6\uff0c\u53ea\u662f\u6837\u672c\u4e0d\u8db3\u800c\u672a\u89c2\u6d4b\u5230\u5931\u6548\uff0c\u5176\u4ed6\u56e0\u7d20\u7684\u6548\u5e94\u53ca\u533a\u95f4\u53ef\u80fd\u6709\u504f\u5dee\uff1b\u533a\u95f4\u672a\u5305\u542b\u8be5\u5047\u8bbe\u4e0d\u6210\u7acb\u7684\u4e0d\u786e\u5b9a\u6027\u3002", None))
    # retranslateUi

