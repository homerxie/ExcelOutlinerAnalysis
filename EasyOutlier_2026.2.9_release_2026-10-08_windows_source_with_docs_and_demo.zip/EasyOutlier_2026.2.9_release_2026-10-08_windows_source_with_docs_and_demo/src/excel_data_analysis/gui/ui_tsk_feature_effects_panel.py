# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_feature_effects_panel.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QComboBox, QHBoxLayout,
    QHeaderView, QLabel, QPlainTextEdit, QPushButton,
    QScrollArea, QSizePolicy, QSpacerItem, QSplitter,
    QTableView, QVBoxLayout, QWidget)

from excel_data_analysis.gui.current_page_tabs import CurrentPageTabWidget
from excel_data_analysis.gui.tsk_feature_effects_plot import TskFeatureEffectsPlot

class Ui_TskFeatureEffectsPanelForm(object):
    def setupUi(self, TskFeatureEffectsPanelForm):
        if not TskFeatureEffectsPanelForm.objectName():
            TskFeatureEffectsPanelForm.setObjectName(u"TskFeatureEffectsPanelForm")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(1)
        sizePolicy.setHeightForWidth(TskFeatureEffectsPanelForm.sizePolicy().hasHeightForWidth())
        TskFeatureEffectsPanelForm.setSizePolicy(sizePolicy)
        self.panelLayout = QVBoxLayout(TskFeatureEffectsPanelForm)
        self.panelLayout.setSpacing(6)
        self.panelLayout.setObjectName(u"panelLayout")
        self.panelLayout.setContentsMargins(0, 0, 0, 0)
        self.assumptionWidget = QWidget(TskFeatureEffectsPanelForm)
        self.assumptionWidget.setObjectName(u"assumptionWidget")
        self.assumptionWidget.setVisible(False)
        self.assumptionLayout = QHBoxLayout(self.assumptionWidget)
        self.assumptionLayout.setSpacing(8)
        self.assumptionLayout.setObjectName(u"assumptionLayout")
        self.assumptionLayout.setContentsMargins(8, 6, 8, 6)
        self.assumptionLabel = QLabel(self.assumptionWidget)
        self.assumptionLabel.setObjectName(u"assumptionLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.assumptionLabel.sizePolicy().hasHeightForWidth())
        self.assumptionLabel.setSizePolicy(sizePolicy1)
        self.assumptionLabel.setWordWrap(True)
        self.assumptionLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.assumptionLayout.addWidget(self.assumptionLabel)

        self.assumptionDetailsButton = QPushButton(self.assumptionWidget)
        self.assumptionDetailsButton.setObjectName(u"assumptionDetailsButton")

        self.assumptionLayout.addWidget(self.assumptionDetailsButton)


        self.panelLayout.addWidget(self.assumptionWidget)

        self.explanationLabel = QLabel(TskFeatureEffectsPanelForm)
        self.explanationLabel.setObjectName(u"explanationLabel")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.explanationLabel.sizePolicy().hasHeightForWidth())
        self.explanationLabel.setSizePolicy(sizePolicy2)
        self.explanationLabel.setWordWrap(True)
        self.explanationLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.panelLayout.addWidget(self.explanationLabel)

        self.statusLabel = QLabel(TskFeatureEffectsPanelForm)
        self.statusLabel.setObjectName(u"statusLabel")
        self.statusLabel.setWordWrap(True)
        self.statusLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.panelLayout.addWidget(self.statusLabel)

        self.featureSelectionLayout = QHBoxLayout()
        self.featureSelectionLayout.setSpacing(6)
        self.featureSelectionLayout.setObjectName(u"featureSelectionLayout")
        self.featureLabel = QLabel(TskFeatureEffectsPanelForm)
        self.featureLabel.setObjectName(u"featureLabel")

        self.featureSelectionLayout.addWidget(self.featureLabel)

        self.featureComboBox = QComboBox(TskFeatureEffectsPanelForm)
        self.featureComboBox.setObjectName(u"featureComboBox")
        self.featureComboBox.setEnabled(False)
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy3.setHorizontalStretch(1)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.featureComboBox.sizePolicy().hasHeightForWidth())
        self.featureComboBox.setSizePolicy(sizePolicy3)
        self.featureComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.featureComboBox.setMinimumContentsLength(8)

        self.featureSelectionLayout.addWidget(self.featureComboBox)


        self.panelLayout.addLayout(self.featureSelectionLayout)

        self.effectsTabWidget = CurrentPageTabWidget(TskFeatureEffectsPanelForm)
        self.effectsTabWidget.setObjectName(u"effectsTabWidget")
        self.overviewTab = QWidget()
        self.overviewTab.setObjectName(u"overviewTab")
        self.overviewLayout = QVBoxLayout(self.overviewTab)
        self.overviewLayout.setSpacing(6)
        self.overviewLayout.setObjectName(u"overviewLayout")
        self.overviewLayout.setContentsMargins(6, 6, 6, 6)
        self.overviewHintLabel = QLabel(self.overviewTab)
        self.overviewHintLabel.setObjectName(u"overviewHintLabel")
        sizePolicy2.setHeightForWidth(self.overviewHintLabel.sizePolicy().hasHeightForWidth())
        self.overviewHintLabel.setSizePolicy(sizePolicy2)
        self.overviewHintLabel.setWordWrap(True)

        self.overviewLayout.addWidget(self.overviewHintLabel)

        self.overviewTableView = QTableView(self.overviewTab)
        self.overviewTableView.setObjectName(u"overviewTableView")
        self.overviewTableView.setMinimumSize(QSize(0, 160))
        sizePolicy.setHeightForWidth(self.overviewTableView.sizePolicy().hasHeightForWidth())
        self.overviewTableView.setSizePolicy(sizePolicy)
        self.overviewTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.overviewTableView.setAlternatingRowColors(True)
        self.overviewTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.overviewTableView.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.overviewTableView.setSortingEnabled(True)
        self.overviewTableView.setWordWrap(False)
        self.overviewTableView.setProperty(u"textColumnMinimumWidth", 85)
        self.overviewTableView.setProperty(u"textColumnMaximumWidth", 240)
        self.overviewTableView.horizontalHeader().setStretchLastSection(False)

        self.overviewLayout.addWidget(self.overviewTableView)

        self.notesTextEdit = QPlainTextEdit(self.overviewTab)
        self.notesTextEdit.setObjectName(u"notesTextEdit")
        self.notesTextEdit.setReadOnly(True)
        self.notesTextEdit.setMaximumSize(QSize(16777215, 120))

        self.overviewLayout.addWidget(self.notesTextEdit)

        self.overviewLayout.setStretch(1, 1)
        self.effectsTabWidget.addTab(self.overviewTab, "")
        self.levelsTab = QWidget()
        self.levelsTab.setObjectName(u"levelsTab")
        self.levelsLayout = QVBoxLayout(self.levelsTab)
        self.levelsLayout.setSpacing(6)
        self.levelsLayout.setObjectName(u"levelsLayout")
        self.levelsLayout.setContentsMargins(6, 6, 6, 6)
        self.featureDetailLabel = QLabel(self.levelsTab)
        self.featureDetailLabel.setObjectName(u"featureDetailLabel")
        self.featureDetailLabel.setWordWrap(True)
        sizePolicy2.setHeightForWidth(self.featureDetailLabel.sizePolicy().hasHeightForWidth())
        self.featureDetailLabel.setSizePolicy(sizePolicy2)

        self.levelsLayout.addWidget(self.featureDetailLabel)

        self.orderLayout = QHBoxLayout()
        self.orderLayout.setObjectName(u"orderLayout")
        self.orderLabel = QLabel(self.levelsTab)
        self.orderLabel.setObjectName(u"orderLabel")

        self.orderLayout.addWidget(self.orderLabel)

        self.levelOrderComboBox = QComboBox(self.levelsTab)
        self.levelOrderComboBox.addItem("")
        self.levelOrderComboBox.addItem("")
        self.levelOrderComboBox.addItem("")
        self.levelOrderComboBox.setObjectName(u"levelOrderComboBox")

        self.orderLayout.addWidget(self.levelOrderComboBox)

        self.orderSpacer = QSpacerItem(20, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.orderLayout.addItem(self.orderSpacer)


        self.levelsLayout.addLayout(self.orderLayout)

        self.levelsSplitter = QSplitter(self.levelsTab)
        self.levelsSplitter.setObjectName(u"levelsSplitter")
        self.levelsSplitter.setOrientation(Qt.Orientation.Vertical)
        self.levelsSplitter.setChildrenCollapsible(False)
        self.levelsSplitter.setHandleWidth(6)
        self.levelsPlotScrollArea = QScrollArea(self.levelsSplitter)
        self.levelsPlotScrollArea.setObjectName(u"levelsPlotScrollArea")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy4.setHorizontalStretch(1)
        sizePolicy4.setVerticalStretch(2)
        sizePolicy4.setHeightForWidth(self.levelsPlotScrollArea.sizePolicy().hasHeightForWidth())
        self.levelsPlotScrollArea.setSizePolicy(sizePolicy4)
        self.levelsPlotScrollArea.setWidgetResizable(True)
        self.levelsPlotScrollArea.setMinimumSize(QSize(0, 130))
        self.levelsPlot = TskFeatureEffectsPlot()
        self.levelsPlot.setObjectName(u"levelsPlot")
        sizePolicy.setHeightForWidth(self.levelsPlot.sizePolicy().hasHeightForWidth())
        self.levelsPlot.setSizePolicy(sizePolicy)
        self.levelsPlot.setMinimumSize(QSize(0, 150))
        self.levelsPlot.setProperty(u"preferredCanvasWidth", 520)
        self.levelsPlot.setProperty(u"preferredCanvasHeight", 240)
        self.levelsPlot.setProperty(u"minimumRowHeight", 40)
        self.levelsPlot.setProperty(u"labelMaximumWidth", 230)
        self.levelsPlot.setProperty(u"drawBars", True)
        self.levelsPlotScrollArea.setWidget(self.levelsPlot)
        self.levelsSplitter.addWidget(self.levelsPlotScrollArea)
        self.levelsTableView = QTableView(self.levelsSplitter)
        self.levelsTableView.setObjectName(u"levelsTableView")
        sizePolicy.setHeightForWidth(self.levelsTableView.sizePolicy().hasHeightForWidth())
        self.levelsTableView.setSizePolicy(sizePolicy)
        self.levelsTableView.setMinimumSize(QSize(0, 115))
        self.levelsTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.levelsTableView.setAlternatingRowColors(True)
        self.levelsTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.levelsTableView.setSortingEnabled(True)
        self.levelsTableView.setWordWrap(False)
        self.levelsTableView.setProperty(u"textColumnMinimumWidth", 85)
        self.levelsTableView.setProperty(u"textColumnMaximumWidth", 260)
        self.levelsSplitter.addWidget(self.levelsTableView)

        self.levelsLayout.addWidget(self.levelsSplitter)

        self.levelsLayout.setStretch(2, 1)
        self.effectsTabWidget.addTab(self.levelsTab, "")
        self.pairwiseTab = QWidget()
        self.pairwiseTab.setObjectName(u"pairwiseTab")
        self.pairwiseLayout = QVBoxLayout(self.pairwiseTab)
        self.pairwiseLayout.setSpacing(6)
        self.pairwiseLayout.setObjectName(u"pairwiseLayout")
        self.pairwiseLayout.setContentsMargins(6, 6, 6, 6)
        self.pairwiseHintLabel = QLabel(self.pairwiseTab)
        self.pairwiseHintLabel.setObjectName(u"pairwiseHintLabel")
        self.pairwiseHintLabel.setWordWrap(True)
        sizePolicy2.setHeightForWidth(self.pairwiseHintLabel.sizePolicy().hasHeightForWidth())
        self.pairwiseHintLabel.setSizePolicy(sizePolicy2)

        self.pairwiseLayout.addWidget(self.pairwiseHintLabel)

        self.pairwiseSplitter = QSplitter(self.pairwiseTab)
        self.pairwiseSplitter.setObjectName(u"pairwiseSplitter")
        self.pairwiseSplitter.setOrientation(Qt.Orientation.Vertical)
        self.pairwiseSplitter.setChildrenCollapsible(False)
        self.pairwiseSplitter.setHandleWidth(6)
        self.pairwisePlotScrollArea = QScrollArea(self.pairwiseSplitter)
        self.pairwisePlotScrollArea.setObjectName(u"pairwisePlotScrollArea")
        sizePolicy4.setHeightForWidth(self.pairwisePlotScrollArea.sizePolicy().hasHeightForWidth())
        self.pairwisePlotScrollArea.setSizePolicy(sizePolicy4)
        self.pairwisePlotScrollArea.setWidgetResizable(True)
        self.pairwisePlotScrollArea.setMinimumSize(QSize(0, 130))
        self.pairwisePlot = TskFeatureEffectsPlot()
        self.pairwisePlot.setObjectName(u"pairwisePlot")
        sizePolicy.setHeightForWidth(self.pairwisePlot.sizePolicy().hasHeightForWidth())
        self.pairwisePlot.setSizePolicy(sizePolicy)
        self.pairwisePlot.setMinimumSize(QSize(0, 150))
        self.pairwisePlot.setProperty(u"preferredCanvasWidth", 520)
        self.pairwisePlot.setProperty(u"preferredCanvasHeight", 240)
        self.pairwisePlot.setProperty(u"minimumRowHeight", 40)
        self.pairwisePlot.setProperty(u"labelMaximumWidth", 230)
        self.pairwisePlot.setProperty(u"drawBars", False)
        self.pairwisePlotScrollArea.setWidget(self.pairwisePlot)
        self.pairwiseSplitter.addWidget(self.pairwisePlotScrollArea)
        self.pairwiseTableView = QTableView(self.pairwiseSplitter)
        self.pairwiseTableView.setObjectName(u"pairwiseTableView")
        sizePolicy.setHeightForWidth(self.pairwiseTableView.sizePolicy().hasHeightForWidth())
        self.pairwiseTableView.setSizePolicy(sizePolicy)
        self.pairwiseTableView.setMinimumSize(QSize(0, 115))
        self.pairwiseTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.pairwiseTableView.setAlternatingRowColors(True)
        self.pairwiseTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.pairwiseTableView.setSortingEnabled(True)
        self.pairwiseTableView.setWordWrap(False)
        self.pairwiseTableView.setProperty(u"textColumnMinimumWidth", 85)
        self.pairwiseTableView.setProperty(u"textColumnMaximumWidth", 260)
        self.pairwiseSplitter.addWidget(self.pairwiseTableView)

        self.pairwiseLayout.addWidget(self.pairwiseSplitter)

        self.pairwiseLayout.setStretch(1, 1)
        self.effectsTabWidget.addTab(self.pairwiseTab, "")

        self.panelLayout.addWidget(self.effectsTabWidget)

        self.panelLayout.setStretch(4, 1)
#if QT_CONFIG(shortcut)
        self.featureLabel.setBuddy(self.featureComboBox)
        self.orderLabel.setBuddy(self.levelOrderComboBox)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(TskFeatureEffectsPanelForm)

        self.effectsTabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(TskFeatureEffectsPanelForm)
    # setupUi

    def retranslateUi(self, TskFeatureEffectsPanelForm):
        TskFeatureEffectsPanelForm.setProperty(u"significantText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u663e\u8457", None))
        TskFeatureEffectsPanelForm.setProperty(u"notSignificantText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u4e0d\u663e\u8457\uff08\u8bc1\u636e\u4e0d\u8db3\uff09", None))
        TskFeatureEffectsPanelForm.setProperty(u"unavailableText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u65e0\u6cd5\u5224\u65ad", None))
        TskFeatureEffectsPanelForm.setProperty(u"referenceText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u53c2\u8003\u6863\uff08\u56fa\u5b9a 0\uff09", None))
        TskFeatureEffectsPanelForm.setProperty(u"estimatedText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u53ef\u4f30\u8ba1", None))
        TskFeatureEffectsPanelForm.setProperty(u"conditionalEstimatedText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6761\u4ef6\u53ef\u4f30\u8ba1", None))
        TskFeatureEffectsPanelForm.setProperty(u"conditionalOrScope", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u672c\u9875 OR \u53ca\u5176\u533a\u95f4\u4ec5\u89e3\u91ca\u5176\u4f59 TSK \u7684\u5171\u4eab\u6548\u5e94\uff1b\u56fa\u5b9a\u96f6\u98ce\u9669 TSK \u5728\u6240\u6709\u6761\u4ef6\u4e0b\u5747\u4e3a 0\uff0c\u4e0d\u9002\u7528\u8fd9\u4e9b OR\u3002", None))
        TskFeatureEffectsPanelForm.setProperty(u"pointEstimateOnlyText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u4ec5\u70b9\u4f30\u8ba1", None))
        TskFeatureEffectsPanelForm.setProperty(u"uncalibratedText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u8fb9\u754c\u68c0\u9a8c\u672a\u6821\u51c6", None))
        TskFeatureEffectsPanelForm.setProperty(u"pairPointEstimateOnlyText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u4ec5\u70b9\u4f30\u8ba1\uff1b\u5dee\u5f02\u5c1a\u672a\u68c0\u9a8c", None))
        TskFeatureEffectsPanelForm.setProperty(u"categoricalText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7c7b\u522b", None))
        TskFeatureEffectsPanelForm.setProperty(u"numericText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6570\u503c", None))
        TskFeatureEffectsPanelForm.setProperty(u"intervalFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"[{lower}, {upper}]", None))
        TskFeatureEffectsPanelForm.setProperty(u"pairFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"{b} \u2212 {a}", None))
        TskFeatureEffectsPanelForm.setProperty(u"pairHigherFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"{b} \u9ad8\u4e8e {a}", None))
        TskFeatureEffectsPanelForm.setProperty(u"pairLowerFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"{b} \u4f4e\u4e8e {a}", None))
        TskFeatureEffectsPanelForm.setProperty(u"pairNotSignificantText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5c1a\u672a\u68c0\u51fa\u660e\u786e\u5dee\u5f02\uff1b\u5148\u540e\u4e0d\u786e\u5b9a", None))
        TskFeatureEffectsPanelForm.setProperty(u"featureDetailFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"{feature} \u00b7 {kind} \u00b7 \u6574\u4f53\u68c0\u9a8c\uff1a{decision}\u3002{reason}", None))
        TskFeatureEffectsPanelForm.setProperty(u"numericScaleFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6570\u503c\u5747\u503c {mean}\uff0cscale {scale}\uff1b\u7cfb\u6570\u5bf9\u5e94\u589e\u52a0\u4e00\u4e2a scale\u3002", None))
        TskFeatureEffectsPanelForm.setProperty(u"referenceFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u53c2\u8003\u6863\uff1a{reference}\u3002\u53c2\u8003\u6863\u7cfb\u6570 0\u3001OR = 1 \u662f\u7f16\u7801\u5b9a\u4e49\uff0c\u4e0d\u4ee3\u8868\u8be5\u6863\u5931\u6548\u6982\u7387\u4e3a 0\u3002", None))
        TskFeatureEffectsPanelForm.setProperty(u"oddsExplanation", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"odds = p/(1-p) = \u5931\u6548\u7387/\u901a\u8fc7\u7387\u3002\n"
"OR\uff08\u4f18\u52bf\u6bd4\uff09\u8868\u793a odds \u7684\u500d\u6570\uff0c\u4e0d\u662f\u5dee\u503c\uff1bOR = 2 \u4e0d\u4ee3\u8868\u5931\u6548\u7387\u53d8\u4e3a 2 \u500d\u3002", None))
        TskFeatureEffectsPanelForm.setProperty(u"orIntervalExplanation", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"OR \u533a\u95f4\u662f\u4f18\u52bf\u6bd4\u7684\u9010\u9879\u7f6e\u4fe1\u533a\u95f4\uff1b\u5305\u542b 1 \u8868\u793a\u8be5\u533a\u95f4\u5141\u8bb8\u65e0\u5dee\u5f02\u3002\u6700\u7ec8\u663e\u8457\u6027\u4ee5 Holm \u6821\u6b63 p \u503c\u4e3a\u51c6\u3002\u4ec5\u70b9\u4f30\u8ba1\u65f6\u6ca1\u6709\u5df2\u6821\u51c6\u7684\u533a\u95f4\u6216\u663e\u8457\u6027\u7ed3\u8bba\u3002", None))
        TskFeatureEffectsPanelForm.setProperty(u"levelOrHeaderFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"OR = \u5f53\u524d\u6863\u4f4d\u7684 odds / \u53c2\u8003\u6863 {reference} \u7684 odds = exp(\u7cfb\u6570\u5dee)\u3002", None))
        TskFeatureEffectsPanelForm.setProperty(u"levelOrTooltipFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"OR = odds({level}) / odds({reference}) = exp(\u7cfb\u6570\u5dee)\uff1b\u53c2\u8003\u6863\uff1a{reference}\u3002", None))
        TskFeatureEffectsPanelForm.setProperty(u"pairOrHeaderText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"OR\uff08B / A\uff09= \u540e\u6863 B \u7684 odds / \u524d\u6863 A \u7684 odds = exp(B\u2212A \u7684\u7cfb\u6570\u5dee)\u3002", None))
        TskFeatureEffectsPanelForm.setProperty(u"pairOrTooltipFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"OR\uff08B / A\uff09= odds({b}) / odds({a}) = exp(\u7cfb\u6570\u5dee)\uff1bB\uff1a{b}\uff0cA\uff1a{a}\u3002", None))
        TskFeatureEffectsPanelForm.setProperty(u"numericOrTooltipFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"OR = {feature} \u589e\u52a0\u4e00\u4e2a scale\uff08{scale}\uff09\u540e\u7684 odds / \u589e\u52a0\u524d\u7684 odds = exp(\u7cfb\u6570)\u3002", None))
        self.assumptionWidget.setStyleSheet(QCoreApplication.translate("TskFeatureEffectsPanelForm", u"QWidget#assumptionWidget { background-color: #fff3d8; border: 1px solid #d3ae60; border-radius: 5px; } QLabel#assumptionLabel { color: #513b13; }", None))
        self.assumptionLabel.setText(QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u56fa\u5b9a\u96f6\u98ce\u9669\u7684\u6761\u4ef6\u5206\u6790\uff1a\u533a\u95f4\u4f9d\u8d56\u6b64\u5047\u8bbe\uff0c\u5047\u8bbe\u4e0d\u6210\u7acb\u65f6\u53ef\u80fd\u6709\u504f\u5dee\u3002", None))
        self.assumptionLabel.setProperty(u"displayFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5df2\u5c06 {count} \u4e2a\u96f6\u98ce\u9669 TSK \u56fa\u5b9a\u4e3a 0\uff1b\u533a\u95f4\u4f9d\u8d56\u6b64\u5047\u8bbe\uff0c\u5047\u8bbe\u4e0d\u6210\u7acb\u65f6\u53ef\u80fd\u6709\u504f\u5dee\u3002", None))
        self.assumptionDetailsButton.setText(QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u67e5\u770b\u8be6\u60c5", None))
        self.assumptionDetailsButton.setStyleSheet(QCoreApplication.translate("TskFeatureEffectsPanelForm", u"QPushButton { color: #513b13; background-color: #fffaf0; border: 1px solid #b99a58; border-radius: 4px; padding: 4px 10px; } QPushButton:hover { background-color: #f8e7bf; } QPushButton:pressed { background-color: #efd398; } QPushButton:focus { border: 2px solid #806020; padding: 3px 9px; }", None))
#if QT_CONFIG(tooltip)
        self.assumptionDetailsButton.setToolTip(QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u67e5\u770b\u56fa\u5b9a\u96f6\u98ce\u9669 TSK \u6e05\u5355\u3001\u5047\u8bbe\u53ca\u6761\u4ef6\u533a\u95f4\u7684\u9002\u7528\u8303\u56f4\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.explanationLabel.setText(QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6574\u4f53\u68c0\u9a8c\u6bd4\u8f83\u4fdd\u7559\u4e0e\u5220\u9664\u8be5\u7279\u5f81\u7684\u6a21\u578b\uff0c\u663e\u8457\u6027\u4f7f\u7528 Holm \u6821\u6b63\u3002\u5220\u9664\u540e\u7684\u9884\u6d4b\u53d8\u5316\u8861\u91cf\u5f71\u54cd\u5927\u5c0f\uff1b\u4e0e\u7edf\u8ba1\u663e\u8457\u6027\u5206\u5f00\u67e5\u770b\u3002\n"
"\u7cfb\u6570\u548c OR \u8868\u793a\u63a7\u5236\u5176\u4ed6\u7279\u5f81\u540e\u7684\u6a21\u578b\u5173\u8054\uff1b\u70b9\u4f30\u8ba1\u6392\u5e8f\u4e0d\u4ee3\u8868\u987a\u5e8f\u5df2\u6709\u7edf\u8ba1\u8bc1\u636e\uff0c\u4e5f\u4e0d\u4ee3\u8868\u56e0\u679c\u5f71\u54cd\u3002\u8fb9\u754c\u4e0b\u53ef\u4fdd\u7559\u53ef\u8fa8\u8bc6\u7684\u70b9\u4f30\u8ba1\u53ca\u5220\u9664\u9884\u6d4b\u53d8\u5316\uff0c\u68c0\u9a8c\u672a\u6821\u51c6\u65f6\u4e0d\u62a5\u544a\u663e\u8457\u6027\u3002", None))
        self.explanationLabel.setProperty(u"conditionalText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u672c\u9875\u5728\u56fa\u5b9a\u6240\u5217 TSK \u98ce\u9669\u4e3a 0 \u540e\uff0c\u91cd\u65b0\u62df\u5408\u5176\u4f59 TSK \u7684\u5171\u4eab\u7279\u5f81\u6548\u5e94\u3002\u533a\u95f4\u4e0e\u68c0\u9a8c\u5747\u4ee5\u8be5\u5047\u8bbe\u6210\u7acb\u4e3a\u6761\u4ef6\uff0c\u663e\u8457\u6027\u4f7f\u7528 Holm \u6821\u6b63\u3002\n"
"\u7cfb\u6570\u548c OR \u8868\u793a\u63a7\u5236\u5176\u4ed6\u7279\u5f81\u540e\u7684\u6a21\u578b\u5173\u8054\uff1b\u5220\u9664\u9884\u6d4b\u53d8\u5316\u8861\u91cf\u6a21\u578b\u5f71\u54cd\u5927\u5c0f\uff0c\u4e0d\u4ee3\u8868\u56e0\u679c\u8d21\u732e\u3002", None))
        self.statusLabel.setText(QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u8fd0\u884c\u542b\u7279\u5f81\u7684 TSK \u5206\u6790\u540e\u663e\u793a\u7279\u5f81\u5f71\u54cd\u3002", None))
        self.statusLabel.setProperty(u"emptyText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u8fd0\u884c\u542b\u7279\u5f81\u7684 TSK \u5206\u6790\u540e\u663e\u793a\u7279\u5f81\u5f71\u54cd\u3002", None))
        self.statusLabel.setProperty(u"missingReportText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u672c\u7ec4\u672a\u4fdd\u5b58\u7279\u5f81\u5f71\u54cd\u7ed3\u679c\uff1b\u8bf7\u91cd\u65b0\u8fd0\u884c TSK \u5206\u6790\u3002", None))
        self.statusLabel.setProperty(u"summaryFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"{count} \u4e2a\u7279\u5f81 \u00b7 {estimated} \u4e2a\u6709\u70b9\u4f30\u8ba1 \u00b7 {deletion} \u4e2a\u6709\u5220\u9664\u9884\u6d4b\u53d8\u5316 \u00b7 {significant} \u4e2a\u6574\u4f53\u663e\u8457 \u00b7 {uncalibrated} \u4e2a\u68c0\u9a8c\u672a\u6821\u51c6 \u00b7 {unavailable} \u4e2a\u65e0\u6cd5\u5224\u65ad\uff08\u6574\u4f53\u68c0\u9a8c\uff09", None))
        self.statusLabel.setProperty(u"intervalSummaryFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u" \u00b7 \u5df2\u8ba1\u7b97\u533a\u95f4\u4e3a {confidence} \u9010\u9879\u533a\u95f4", None))
        self.statusLabel.setProperty(u"conditionalIntervalSummaryFormat", QCoreApplication.translate("TskFeatureEffectsPanelForm", u" \u00b7 \u5df2\u8ba1\u7b97\u533a\u95f4\u4e3a {confidence} \u6761\u4ef6\u9010\u9879\u533a\u95f4", None))
        self.featureLabel.setText(QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u67e5\u770b\u7279\u5f81", None))
        self.overviewHintLabel.setText(QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u70b9\u51fb\u5217\u6807\u9898\u53ef\u6392\u5e8f\uff1b\u9009\u4e2d\u4e00\u884c\u5207\u6362\u67e5\u770b\u7279\u5f81\u3002\u5220\u9664\u540e\u7684\u53d8\u5316\u6309\u6709\u89c2\u6d4b\u7684\u5e03\u5c40\u5b9e\u4f8b\u7b49\u6743\u5e73\u5747\uff0c\u5355\u4f4d\u4e3a\u767e\u5206\u70b9\uff1b\u4e0d\u8868\u793a\u771f\u5b9e\u5220\u9664\u67d0\u7269\u7406\u7279\u5f81\u7684\u56e0\u679c\u6536\u76ca\u3002", None))
        self.overviewTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7279\u5f81", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7c7b\u578b", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6574\u4f53\u7ed3\u8bba\uff08Holm\uff09", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u4f3c\u7136\u6bd4\u7edf\u8ba1\u91cf", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u81ea\u7531\u5ea6", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"p \u503c", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"Holm \u6821\u6b63 p", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5220\u9664\u540e\u5e73\u5747\u7edd\u5bf9\u53d8\u5316\uff08\u767e\u5206\u70b9\uff09", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5220\u9664\u540e\u6700\u5927\u53d8\u5316\uff08\u767e\u5206\u70b9\uff09", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5220\u9664\u540e RMS \u53d8\u5316\uff08\u767e\u5206\u70b9\uff09", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6709\u6548\u5b9e\u4f8b\u6570", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u8bf4\u660e", None)])
        self.overviewTableView.setProperty(u"conditionalColumnHeaders", [
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7279\u5f81", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7c7b\u578b", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6761\u4ef6\u6574\u4f53\u7ed3\u8bba\uff08Holm\uff09", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6761\u4ef6\u4f3c\u7136\u6bd4\u7edf\u8ba1\u91cf", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u81ea\u7531\u5ea6", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6761\u4ef6 p \u503c", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6761\u4ef6 Holm \u6821\u6b63 p", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5220\u9664\u540e\u5e73\u5747\u7edd\u5bf9\u53d8\u5316\uff08\u767e\u5206\u70b9\uff09", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5220\u9664\u540e\u6700\u5927\u53d8\u5316\uff08\u767e\u5206\u70b9\uff09", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5220\u9664\u540e RMS \u53d8\u5316\uff08\u767e\u5206\u70b9\uff09", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6709\u6548\u5b9e\u4f8b\u6570", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u8bf4\u660e", None)])
        self.overviewTableView.setProperty(u"columnTooltips", [
            "",
            "",
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u53ef\u68c0\u9a8c\u65f6\uff0cHolm p \u2264 {threshold} \u5224\u4e3a\u663e\u8457\uff1b\u4e0d\u663e\u8457\u4ec5\u8868\u793a\u8bc1\u636e\u4e0d\u8db3\uff0c\u4e0d\u80fd\u8bc1\u660e\u6ca1\u6709\u5f71\u54cd\u3002\u8fb9\u754c\u68c0\u9a8c\u672a\u6821\u51c6\u65f6\u4e0d\u62a5\u544a\u663e\u8457\u6027\uff1b\u65e0\u6cd5\u5224\u65ad\u65f6\u8bf7\u67e5\u770b\u539f\u56e0\u3002", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"D = 2 \u00d7\uff08\u5220\u53bb\u8be5\u7279\u5f81\u5e76\u91cd\u62df\u5408\u540e\u7684\u8d1f\u5bf9\u6570\u4f3c\u7136 \u2212 \u5b8c\u6574\u6a21\u578b\u7684\u8d1f\u5bf9\u6570\u4f3c\u7136\uff09\u3002\u8d8a\u5927\u8868\u793a\u5220\u53bb\u540e\u62df\u5408\u635f\u5931\u8d8a\u5927\uff1b\u4e0d\u662f\u5931\u6548\u7387\u767e\u5206\u6bd4\u3002\u8fb9\u754c\u4e0b\u53ef\u663e\u793a D\uff0c\u4f46\u672a\u7ecf\u5206\u5e03\u6821\u51c6\u4e0d\u80fd\u636e\u6b64\u5224\u65ad\u663e\u8457\u6027\u3002", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5e38\u89c4\u5185\u90e8\u89e3\u4e0b\uff0c\u4e24\u4e2a\u6a21\u578b\u72ec\u7acb\u53ef\u4f30\u8ba1\u53c2\u6570\u6570\u91cf\u4e4b\u5dee\u3002L \u4e2a\u6863\u4f4d\u7684\u7c7b\u522b\u7279\u5f81\u901a\u5e38\u4e3a L\u22121\uff0c\u6570\u503c\u7279\u5f81\u901a\u5e38\u4e3a 1\uff1b\u4e0d\u662f\u6837\u672c\u6570\u3002\u8fb9\u754c\u5206\u5e03\u672a\u6821\u51c6\u65f6\u7559\u7a7a\u3002", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5047\u8bbe\u8be5\u7279\u5f81\u6ca1\u6709\u989d\u5916\u89e3\u91ca\u80fd\u529b\uff0c\u5f97\u5230\u5f53\u524d\u6216\u66f4\u5927 D \u7684\u8fd1\u4f3c\u6982\u7387\u3002\u672a\u7ecf\u591a\u91cd\u68c0\u9a8c\u6821\u6b63\uff0c\u4e0d\u662f\u201c\u8be5\u7279\u5f81\u65e0\u5f71\u54cd\u7684\u6982\u7387\u201d\u3002\u8fb9\u754c\u5206\u5e03\u672a\u6821\u51c6\u65f6\u7559\u7a7a\u3002", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5bf9\u540c\u4e00\u8282\u70b9/\u6279\u6b21\u5168\u90e8\u7279\u5f81\u7684\u6574\u4f53\u68c0\u9a8c\u8fdb\u884c Holm \u591a\u91cd\u6821\u6b63\u540e\u7684 p \u503c\uff0c\u51cf\u5c11\u540c\u65f6\u68c0\u9a8c\u591a\u9879\u7684\u8bef\u62a5\uff1b\u6574\u4f53\u7ed3\u8bba\u4ee5\u6b64\u4e3a\u51c6\u3002", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5220\u53bb\u8be5\u7279\u5f81\u5e76\u91cd\u62df\u5408\u5176\u4f59\u53c2\u6570\u540e\uff0c\u5728\u539f\u6709\u6548\u5e03\u5c40\u5b9e\u4f8b\u4e0a\u9010\u4e2a\u6bd4\u8f83\u9884\u6d4b\u7684\u5355\u5b9e\u4f8b\u5931\u6548\u7387\uff0c\u7edd\u5bf9\u5dee\u7b49\u6743\u5e73\u5747\uff0c\u5355\u4f4d\u4e3a\u767e\u5206\u70b9\uff1b\u4e0d\u662f\u5b9e\u6d4b\u53d8\u5316\u6216\u56e0\u679c\u6536\u76ca\u3002", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5728\u540c\u4e00\u6709\u6548\u5e03\u5c40\u5b9e\u4f8b\u8303\u56f4\u5185\uff0c\u5220\u53bb\u8be5\u7279\u5f81\u5e76\u91cd\u62df\u5408\u540e\u7684\u9884\u6d4b\u5355\u5b9e\u4f8b\u5931\u6548\u7387\u7edd\u5bf9\u5dee\u7684\u6700\u5927\u503c\uff0c\u5355\u4f4d\u4e3a\u767e\u5206\u70b9\uff0c\u53cd\u6620\u53d8\u5316\u6700\u5927\u7684\u5b9e\u4f8b\uff1b\u4e0d\u662f\u6574\u4f53\u6216\u5b9e\u6d4b\u5931\u6548\u7387\u7684\u63d0\u9ad8\u3002", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5220\u53bb\u8be5\u7279\u5f81\u5e76\u91cd\u62df\u5408\u540e\uff0c\u9884\u6d4b\u5355\u5b9e\u4f8b\u5931\u6548\u7387\u5dee\u503c\u7684\u5e73\u65b9\u7b49\u6743\u5e73\u5747\u518d\u5f00\u65b9\uff08RMS\uff09\uff0c\u5355\u4f4d\u4e3a\u767e\u5206\u70b9\uff1b\u5bf9\u8f83\u5927\u7684\u5b9e\u4f8b\u53d8\u5316\u66f4\u654f\u611f\uff0c\u4e0d\u662f\u5b9e\u6d4b\u53d8\u5316\u3002", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7528\u4e8e\u5220\u9664\u524d\u540e\u9884\u6d4b\u6bd4\u8f83\u7684\u539f\u6709\u6548\u5e03\u5c40\u5b9e\u4f8b\u6570\uff0c\u6bcf\u4e2a\u5b9e\u4f8b\u7b49\u6743\uff1b\u4e0d\u662f\u5931\u6548\u6570\u6216\u94fe\u6761\u89c2\u6d4b\u6b21\u6570\u3002", None),
            ""])
        self.notesTextEdit.setPlaceholderText(QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u8ba1\u7b97\u65b9\u6cd5\u3001\u6a21\u578b\u8303\u56f4\u4e0e\u4e0d\u53ef\u5224\u65ad\u7684\u539f\u56e0\u5728\u8fd9\u91cc\u663e\u793a\u3002", None))
        self.notesTextEdit.setProperty(u"baseNotes", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u201c\u4e0d\u663e\u8457\u201d\u8868\u793a\u76ee\u524d\u8bc1\u636e\u4e0d\u8db3\uff0c\u4e0d\u8868\u793a\u5df2\u8bc1\u660e\u6ca1\u6709\u5f71\u54cd\u3002\u201c\u8fb9\u754c\u68c0\u9a8c\u672a\u6821\u51c6\u201d\u8868\u793a\u5c1a\u672a\u68c0\u9a8c\uff0c\u4ecd\u53ef\u67e5\u770b\u53ef\u8fa8\u8bc6\u7684\u70b9\u4f30\u8ba1\u548c\u53ef\u7528\u7684\u5220\u9664\u9884\u6d4b\u53d8\u5316\u3002\u201c\u65e0\u6cd5\u5224\u65ad\u201d\u8bf7\u67e5\u770b\u5404\u9879\u539f\u56e0\u3002\n"
"\u56fe\u548c\u8868\u4e2d\u7684\u533a\u95f4\u4e3a\u9010\u9879\u533a\u95f4\uff1b\u662f\u5426\u663e\u8457\u4ee5\u8868\u4e2d Holm \u6821\u6b63\u540e\u7684\u7ed3\u8bba\u4e3a\u51c6\u3002\u7c7b\u522b\u53c2\u8003\u7cfb\u6570\u56fa\u5b9a\u4e3a 0\uff0c\u4e0d\u53c2\u4e0e\u72ec\u7acb\u663e\u8457\u6027\u5224\u65ad\u3002\n"
"\u96f6\u98ce\u9669\u8fb9\u754c\u4e0b\uff0c\u5171\u4eab OR \u7531\u6709\u4fe1\u606f\u7684\u6761\u4ef6\u652f\u6301\uff0c\u4e0d\u80fd\u89c6\u4e3a\u5df2\u9a8c\u8bc1\u4e86\u8be5\u96f6\u98ce\u9669 TSK \u7684\u98ce\u9669\u500d\u6570\u3002", None))
        self.effectsTabWidget.setTabText(self.effectsTabWidget.indexOf(self.overviewTab), QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6574\u4f53\u5f71\u54cd", None))
        self.featureDetailLabel.setText(QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u9009\u62e9\u4e00\u4e2a\u7279\u5f81\uff0c\u67e5\u770b\u6863\u4f4d\u7cfb\u6570\u4e0e\u533a\u95f4\u3002", None))
        self.featureDetailLabel.setProperty(u"emptyText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u9009\u62e9\u4e00\u4e2a\u7279\u5f81\uff0c\u67e5\u770b\u6863\u4f4d\u7cfb\u6570\u4e0e\u533a\u95f4\u3002", None))
        self.orderLabel.setText(QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u56fe\u8868\u987a\u5e8f", None))
        self.levelOrderComboBox.setItemText(0, QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6a21\u578b\u6863\u4f4d\u987a\u5e8f", None))
        self.levelOrderComboBox.setItemText(1, QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7cfb\u6570\u70b9\u4f30\u8ba1\uff1a\u7531\u9ad8\u5230\u4f4e", None))
        self.levelOrderComboBox.setItemText(2, QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7cfb\u6570\u70b9\u4f30\u8ba1\uff1a\u7531\u4f4e\u5230\u9ad8", None))

#if QT_CONFIG(tooltip)
        self.levelOrderComboBox.setToolTip(QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6392\u5e8f\u4ec5\u6bd4\u8f83\u70b9\u4f30\u8ba1\uff0c\u4e0d\u80fd\u8bc1\u660e\u6863\u4f4d\u5dee\u5f02\u6216\u540d\u6b21\u663e\u8457\uff1b\u8bf7\u67e5\u770b\u4e24\u4e24\u6bd4\u8f83\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.levelsPlot.setProperty(u"axisLabel", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7cfb\u6570\uff08log odds\uff09\uff1b\u6a2a\u7ebf\u4e3a\u9010\u9879\u7f6e\u4fe1\u533a\u95f4", None))
        self.levelsPlot.setProperty(u"conditionalAxisLabel", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7cfb\u6570\uff08log odds\uff09\uff1b\u6a2a\u7ebf\u4e3a\u6761\u4ef6\u9010\u9879\u7f6e\u4fe1\u533a\u95f4", None))
        self.levelsPlot.setProperty(u"emptyText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6682\u65e0\u53ef\u663e\u793a\u7684\u6863\u4f4d\u7cfb\u6570\u3002", None))
        self.levelsPlot.setProperty(u"missingText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u65e0\u6cd5\u4f30\u8ba1", None))
        self.levelsPlot.setProperty(u"pointOnlyText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u70b9\u4f30\u8ba1\uff1b\u533a\u95f4\u4e0d\u53ef\u7528", None))
        self.levelsPlot.setProperty(u"referenceText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u53c2\u8003\u6863\uff08\u56fa\u5b9a 0\uff09", None))
        self.levelsPlot.setProperty(u"positiveColor", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"#c45d4c", None))
        self.levelsPlot.setProperty(u"negativeColor", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"#3b82ad", None))
        self.levelsTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6863\u4f4d / \u6570\u503c\u53d8\u5316", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7cfb\u6570", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6807\u51c6\u8bef", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7cfb\u6570\u533a\u95f4", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"OR", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"OR \u533a\u95f4", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u4f30\u8ba1\u72b6\u6001", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u8bf4\u660e", None)])
        self.levelsTableView.setProperty(u"conditionalColumnHeaders", [
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6863\u4f4d / \u6570\u503c\u53d8\u5316", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7cfb\u6570", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6807\u51c6\u8bef", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6761\u4ef6\u9010\u9879\u7cfb\u6570\u533a\u95f4", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"OR", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6761\u4ef6\u9010\u9879 OR \u533a\u95f4", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u4f30\u8ba1\u72b6\u6001", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u8bf4\u660e", None)])
        self.effectsTabWidget.setTabText(self.effectsTabWidget.indexOf(self.levelsTab), QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6863\u4f4d\u7cfb\u6570", None))
        self.pairwiseHintLabel.setText(QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5dee\u503c\u4e3a\u540e\u6863 B \u51cf\u524d\u6863 A \u7684 log odds\uff0cOR \u4e3a B \u76f8\u5bf9 A \u7684\u4f18\u52bf\u6bd4\uff1b\u6b63\u503c\u8868\u793a B \u7684\u6a21\u578b\u5931\u6548\u503e\u5411\u66f4\u9ad8\u3002\u663e\u8457\u6027\u4f7f\u7528\u540c\u4e00\u7279\u5f81\u5185\u7684 Holm \u6821\u6b63\u3002", None))
        self.pairwiseHintLabel.setProperty(u"defaultText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5dee\u503c\u4e3a\u540e\u6863 B \u51cf\u524d\u6863 A \u7684 log odds\uff0cOR \u4e3a B \u76f8\u5bf9 A \u7684\u4f18\u52bf\u6bd4\uff1b\u6b63\u503c\u8868\u793a B \u7684\u6a21\u578b\u5931\u6548\u503e\u5411\u66f4\u9ad8\u3002\u663e\u8457\u6027\u4f7f\u7528\u540c\u4e00\u7279\u5f81\u5185\u7684 Holm \u6821\u6b63\u3002", None))
        self.pairwiseHintLabel.setProperty(u"numericText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6570\u503c\u7279\u5f81\u6ca1\u6709\u79bb\u6563\u6863\u4f4d\u4e24\u4e24\u6bd4\u8f83\uff1b\u8bf7\u67e5\u770b\u201c\u6863\u4f4d\u7cfb\u6570\u201d\u4e2d\u589e\u52a0\u4e00\u4e2a scale \u5bf9\u5e94\u7684\u7cfb\u6570\u548c\u533a\u95f4\u3002", None))
        self.pairwisePlot.setProperty(u"axisLabel", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6863\u4f4d\u7cfb\u6570\u5dee B \u2212 A\uff08log odds\uff09\uff1b\u6a2a\u7ebf\u4e3a\u9010\u9879\u7f6e\u4fe1\u533a\u95f4", None))
        self.pairwisePlot.setProperty(u"conditionalAxisLabel", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6863\u4f4d\u7cfb\u6570\u5dee B \u2212 A\uff08log odds\uff09\uff1b\u6a2a\u7ebf\u4e3a\u6761\u4ef6\u9010\u9879\u7f6e\u4fe1\u533a\u95f4", None))
        self.pairwisePlot.setProperty(u"emptyText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u8be5\u7279\u5f81\u6682\u65e0\u53ef\u663e\u793a\u7684\u6863\u4f4d\u4e24\u4e24\u6bd4\u8f83\u3002", None))
        self.pairwisePlot.setProperty(u"missingText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u65e0\u6cd5\u4f30\u8ba1", None))
        self.pairwisePlot.setProperty(u"pointOnlyText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u70b9\u4f30\u8ba1\uff1b\u533a\u95f4\u4e0d\u53ef\u7528", None))
        self.pairwisePlot.setProperty(u"referenceText", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u53c2\u8003\u6863\uff08\u56fa\u5b9a 0\uff09", None))
        self.pairwisePlot.setProperty(u"positiveColor", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"#c45d4c", None))
        self.pairwisePlot.setProperty(u"negativeColor", QCoreApplication.translate("TskFeatureEffectsPanelForm", u"#3b82ad", None))
        self.pairwiseTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6bd4\u8f83\uff08B \u2212 A\uff09", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7cfb\u6570\u5dee", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u5dee\u503c\u533a\u95f4", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"OR\uff08B / A\uff09", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"OR \u533a\u95f4", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"p \u503c", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"Holm \u6821\u6b63 p", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7ed3\u8bba\uff08Holm\uff09", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u8bf4\u660e", None)])
        self.pairwiseTableView.setProperty(u"conditionalColumnHeaders", [
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6bd4\u8f83\uff08B \u2212 A\uff09", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7cfb\u6570\u5dee", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6761\u4ef6\u9010\u9879\u5dee\u503c\u533a\u95f4", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"OR\uff08B / A\uff09", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6761\u4ef6\u9010\u9879 OR \u533a\u95f4", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6761\u4ef6 p \u503c", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6761\u4ef6 Holm \u6821\u6b63 p", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u7ed3\u8bba\uff08Holm\uff09", None),
            QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u8bf4\u660e", None)])
        self.effectsTabWidget.setTabText(self.effectsTabWidget.indexOf(self.pairwiseTab), QCoreApplication.translate("TskFeatureEffectsPanelForm", u"\u6863\u4f4d\u4e24\u4e24\u6bd4\u8f83", None))
    # retranslateUi

