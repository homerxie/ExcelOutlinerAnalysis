# Independent TSK risk analysis

TSK Analysis is a separate workbench tab. It uses the paths in Setup and the current effective Fail rules from Analyze, including unsaved changes in the Analyze controls. You do not need to run Analyze first. TSK keeps its own data source, import selection, node/sample scope, batch grouping and XY/feature selection; it does not provide a separate Fail-method or classification-pool selector. Running Analyze does not run TSK estimation, and TSK Results does not replace existing Analyze results.

当前 Logistic 模型的正向概率、实例特征与反向估计见 [TSK 概率估算数学原理](tsk-probability-estimation-mathematics.md)。此前的 [详细数学说明](tsk-risk-mathematical-principles.md) 保留历史模型与验证记录，不作为当前算法选择说明。

## Try the hypothetical example

1. In Setup, select `examples/tsk_risk_demo/template.xlsx` (or `template.json`) and `examples/tsk_risk_demo/data.csv` as the input.
2. In Analyze, use the demo's Modified Z-score method and threshold 3.5. Then open **TSK Analysis**, choose **Input · Setup 中的输入文件**, and click **运行 TSK 风险分析**. No prior Analyze run, Golden file or database import is needed for this example.
3. Select T0 or T1 in **TSK Results → 风险结果**. Risk bars show single-instance probabilities; whiskers show 95% intervals. The second page, **拟合检查**, compares observed and predicted chain proportions and reports residuals in percentage points.
4. Optionally enable XY or select numeric/categorical attributes. **Logistic** is the only feature model. Run again after changing the selected features. Feature-model type risks refer to numeric attributes at their training-layout means and categorical attributes at their reference levels, not an average of the probabilities across the type's actual instances. The existing demo uses numeric attributes only.
5. Export XLSX for type estimates, bounds, chain counts, sample outcomes, topology, diagnostics and the configuration snapshot. Long JSON metadata is split into ordered parts to avoid Excel truncation.

The demo has 12 chains, three TSK types, 400 samples and two nodes. Its topology and values are invented and clearly labelled. The bundled ordinary template contains disabled EXAMPLE placeholders; replace them with real topology before enabling TSK analysis.

## Result navigation

**TSK Results** has five main pages in this order. The selected node/batch group remains visible above them; **查看诊断** opens that group's diagnostic report directly.

| Page | What it shows |
| --- | --- |
| **风险结果** | The current group's complete combination risks, with shared conditions and filters across **条形图**, **热力图** and **明细表**. |
| **拟合检查** | **观察与预测** for the selected group, plus **模板实例组成** for the complete template topology. |
| **联合风险** | Identifiable joint configurations when individual contributions cannot be separated. |
| **特征影响** | Overall feature tests, within-feature level effects/pairwise comparisons and the prediction change after removing a feature. |
| **模型与诊断** | **模型说明** for coefficients, reference categories and numeric scaling; **诊断与提示** for the full diagnostic report and warnings. |

There is no separate condition-probability or combination-analysis page. The **特征影响** page compares shared model effects and statistical evidence; **风险结果** presents conditional probabilities. To inspect one categorical dimension, use the shared filters in **风险结果** to hold the other categories fixed. This selects existing results without a new calculation or a change to the fitted model.

The compact header keeps the TSK/chain counts and convergence status visible. **详情** expands the model, batch and saved-result summary; the analysis-warning count opens the full diagnostics. **说明** opens the complete probability reference, interval interpretation, heatmap legend and axis instructions without reducing the chart viewport. Filters use single-line field/selection buttons, and the heatmap places its X/Y selectors and probability/support selector together. Charts take the remaining page height and scroll independently; inactive result pages no longer determine the active page's minimum height.

Click a risk bar, heatmap cell or risk-table row to open its TSK and related Chain details in a third panel on the right. Chain points and rows open the saved member details in the same panel. Opening it temporarily collapses the left Setup/Import/Analyze area; closing it or leaving TSK Results restores that area's prior state and width. **展开设置 / 收起设置** remains available for manual control, and **侧栏** reopens the current selection's details.

The GUI detail panel follows the HTML report's information order: TSK ID and feature values together, smaller full `name=value` conditions below, and coordinates at the end. Related chains expand their saved members inline, with search and pagination. **查看拟合结果** selects the matching table row and outlines its scatter point; chains without valid observed/predicted pairs explain why no point can be shown. Changing result groups or filtering out the selected risk clears stale details.

<a id="feature-effects-page"></a>

## Feature influence and level comparisons

Open **TSK Results → 特征影响** after a new analysis with XY or other numeric/categorical features selected. Each node/batch group receives its own report automatically. Choose a feature to inspect its effects and comparisons. These estimates describe the selected feature's association with **single-instance TSK failure**, conditional on the other selected features; they do not assign a share of observed chain failures to a physical cause.

Read the page in this order:

1. **整体影响** compares the saved full model with a model that removes every coefficient belonging to that feature and refits the remaining parameters against the same chain counts. It reports the likelihood-ratio statistic, degrees of freedom, raw p value, Holm-adjusted p value and the inference status. It does not rank all features by importance.
2. **档位系数** shows each categorical level's estimated log-odds effect relative to its coding reference, with a pointwise confidence interval. Higher coefficients imply higher predicted single-instance failure probability when other conditions are fixed. The reference coefficient is fixed at zero by coding; it does not mean zero failure probability or a known baseline risk. Numeric effects represent a one-training-standard-deviation increase, including X/Y when selected.
3. **档位两两比较** directly compares every pair of categorical levels using their joint covariance: coefficient difference, pointwise interval, odds ratio (OR), raw p value and Holm-adjusted p value. Read the stated direction of the contrast. A positive log-odds difference, or OR above 1, means the first stated target is estimated to have higher failure odds than its comparison level. OR is not a probability ratio or a percentage-point increase.
4. The delete-feature change columns in **整体影响** describe the absolute change in fitted probabilities on the original observed topology instances. Mean, maximum and RMS changes use equal weight per layout instance. The saved report also retains signed mean changes and a breakdown by TSK; ranges containing non-identifiable instance probabilities remain unavailable. These are changes between two model predictions, not held-out prediction errors or a causal intervention result. Probability differences are displayed in percentage points.

The default inference level is 5%, corresponding to the fit's 95% confidence setting. Overall feature tests use Holm correction across all requested features in that node/batch group. Pairwise tests use a separate correction family containing every planned pair for that category. Unavailable tests still occupy their planned family positions internally with a p-value placeholder of 1; displayed p values remain blank with a reason. There is no extra correction across all nodes, batches and category families together.

Final significance uses the adjusted p value. The displayed confidence intervals remain **pointwise**, so a usual 95% interval excluding zero does not guarantee the Holm-adjusted test is significant. Do not infer a pairwise result from whether two coefficient error bars overlap. “C differs from A, while B does not differ detectably from A” does not establish that C differs from B; read the C/B row directly.

A point-estimate order such as A < B < C can coexist with “A/B order uncertain.” “尚未检出显著独立影响” means insufficient evidence under this test, not proof of no effect or equivalence. Small delete-feature prediction changes may be useful engineering evidence, but the program does not choose a business threshold for an ignorable change. Missing levels, confounding and unreliable fits produce explicit unavailable results rather than a non-significant label. Wald comparisons require a reliable finite-interior full fit and identifiable contrasts; each ordinary overall test additionally requires a reliable reduced fit and an appropriate information-rank difference. A failed reduced fit alone does not invalidate an otherwise usable pairwise comparison.

When a new analysis has validated exact-zero TSK risks, the feature-effects report now uses **固定零风险假设下的条件分析**. It fixes those types' contributions to zero, removes their risk parameters, and refits the remaining type intercepts and shared feature coefficients. All original Chain counts are retained, including mixed chains; pure fixed-zero chains with any observed failure are incompatible with this assumption. Full and delete-feature fits use the same fixed-zero types. Reliable finite and identifiable remaining effects receive conditional Wald coefficient/OR intervals and conditional tests. The GUI and HTML show a short assumption warning with **查看详情** opening a small dialog containing the fixed-zero list and full explanation; the Excel feature tables retain the full metadata.

**These intervals assume the listed types' true risks are exactly zero. If the zero estimates instead reflect insufficient samples, the remaining effects and intervals can be biased; the intervals do not include uncertainty about the zero assumption or the data-driven choice of fixed types.** They are pointwise approximate intervals, not a calibrated unconditional boundary procedure. Shared ORs describe the remaining TSKs; they are not odds ratios within the fixed-zero types, where both odds are zero. Original risk estimates and their probability intervals are not replaced by this conditional feature-effects analysis. Deletion-change summaries retain the original layout denominator, with zero change for the fixed-zero instances.

Historical **仅点估计** / **边界检验未校准** reports remain readable. The backend's explicit `zero_risk_policy="boundary"` retains the previous descriptive mode, allowing zero odds to become positive during deletion refits and withholding uncalibrated intervals and significance. Invalid fits, separation, non-identifiable contrasts and coefficients reaching numerical bounds still withhold the affected inference in either mode. Boundary simulation calibration is not implemented. Rerun the analysis to obtain the new conditional report; opening or exporting a saved snapshot does not refit it.

A linear-program check also looks for a sufficient monotone-separation certificate in the full and reduced models, including all-Pass/all-Fail patterns that can make an MLE infinite before coefficients reach the numerical bounds. A detected certificate or failed certificate check withholds the corresponding ordinary inference; finding no certificate is not proof that a finite global MLE exists.

All results assume the same independent chain-count model as the original fit. They share feature effects across TSK types and contain no TSK-by-feature interactions. Same-die/wafer dependence is not corrected by Holm adjustment, and no cluster-robust or bootstrap inference is included here.

Calculated reports are retained in display snapshots and exported to XLSX and the offline HTML report. Reopening, selecting a group or viewing exported results does not refit either model. Older live results and restored snapshots without the report show that a fresh TSK analysis is required; the page does not silently fill in a missing report.

Formulas and worked examples are in [the new feature-effects chapter](tsk-probability-estimation-mathematics.md#feature-effects). Detailed chi-square theory is in [Appendix K](tsk-probability-estimation-mathematics.md#chi-square); parameter variance/covariance derivation and its limits are in [Appendix L](tsk-probability-estimation-mathematics.md#parameter-covariance).

## Offline HTML report

Use **TSK Analysis → 保存结果为 HTML** at the bottom of the analysis panel. The button becomes available after a result is calculated or a saved result is restored; it is disabled while a task is running. Choose a destination to save one UTF-8 `.html` file, then open it directly in a browser. No server, installation or network access is needed.

The report includes all node/batch groups and all already calculated display records: risk bars and intervals, heatmaps, full detail tables, observed/predicted chain fits and members, global template topology, joint risks, model coefficients, calculated feature-influence reports and diagnostics. The current group, filters, ordering, heatmap axes and metric are retained as the initial view; filtering and pagination never remove the other records from the file. HTML controls can switch groups, filter and sort existing rows, change complementary heatmap axes and inspect details offline. Missing full grids or reports remain explicitly unavailable; the HTML never runs fitting or fills them in.

In the HTML report, selecting a TSK bar, heatmap cell or risk row shows its related chains in a right-hand detail panel; selecting a chain point or row shows its TSK members there. The main view stays in place, and the panel scrolls independently. Relationship lists wrap within the panel and remain searchable and paginated. On narrow windows, the panel becomes a closable drawer from the right. Filters, extrapolation policy and group changes refresh or clear the selection so details always correspond to the current results.

Each related chain can expand its complete saved TSK member list directly inside the risk sidebar, including actual conditions, instance counts, probabilities and intervals. The optional **查看拟合结果** action opens that chain's fit page, marks its scatter point with a box and label, and selects its table row, locating the relevant pages automatically. Chains without valid observed/predicted pairs show an explanation instead of a fabricated point.

HTML sidebar member headings show the TSK ID, instance count and non-coordinate feature values in the same dark color. A smaller line below lists the full `name=value` conditions. X/Y coordinates appear at the end of each member's details.

In both the desktop and HTML heatmaps, feature names appear once in shared axis headers above and to the left of the matrix. Row and column labels show only their values, in the same order as the shared names. Hover text retains full `name=value` conditions; axis rearrangement and pagination preserve each result's original identity.

Live and restored results can both be exported. The report uses the saved display schema, which omits sample outcomes and fitting matrices. HTML presents readable fields, charts and tables without raw-record disclosures, internal debug dumps or a JSON download button. Numeric reference conditions and key analysis settings remain readable fields. **打印当前视图** prints the current group/page and visible pagination, rather than every hidden report section. The existing XLSX export remains available in TSK Results.

## Original batches and parent batches

Choose an existing row dimension such as `lot_id` as the batch field. It must be different from the reliability-node dimension. This field also preserves original-batch identity in mode `none`, so the same sample number in two lots remains two observations. Batch settings determine which final counts are fitted together. They do not rename source data, change the template's sample identity, replace batch values used to match Golden references, or change the shared Fail rules.

| Batch mode | Fit groups |
| --- | --- |
| `none` — no batch split; combine selected lots | Sum final counts from all selected original batches within each node, then fit one common model. |
| `separate` — original batches | Fit each original batch separately within each node. |
| `parent` — parent batches | Map original batches to parent IDs, sum their final chain counts within each node, then run maximum likelihood again. |

The batch controls are the only way to split TSK fits beyond the reliability node. There is no additional temperature, voltage or other condition-grouping control. Legacy `group_by_dimensions` values in templates or saved TSK settings are ignored.

For a runnable example, use [batch_data.csv](../examples/tsk_risk_demo/batch_data.csv) with the same demo template. It contains L001 with 100 samples, L002 with 150, and L003 with 150, at both T0 and T1. Sample numbers restart within each batch. The run settings are also provided in [batch_settings.json](../examples/tsk_risk_demo/batch_settings.json), and expected counts in [batch_expected_counts.csv](../examples/tsk_risk_demo/batch_expected_counts.csv).

To combine L001 and L002 while keeping L003 separate:

1. Select the intended data/imports, nodes and samples in **TSK Analysis**.
2. Select original-batch mode with `lot_id` as the batch field to inspect L001, L002 and L003 separately.
3. To fit parent batches, choose parent-batch mode and enter `L001 → M001`, `L002 → M001`, `L003 → M002`. Every original batch present in the selected analysis scope needs a nonempty parent ID; an unmapped batch is not silently dropped.
4. Check the shared Fail rules in Analyze, run TSK analysis, and inspect **Batch Counts** in the export alongside the parent results. Risk results retain `parent_batch_id` and `source_batches` for traceability.

For this complete-data example, separate mode yields six groups. Parent mode yields four groups: M001 at each node has 250 effective samples per chain, and M002 has 150. Mode `none` combines the three selected batches and yields two node groups, each with 400 effective samples per chain. These files illustrate aggregation and repeated sample numbers across batches; they do not introduce or prove a separate batch-effect model.

The Fail method, empty-value handling, sample identity and merge rules/order come from Analyze's current effective report settings. Analyze's current default Z-score threshold is applied as the run-wide override; old per-item Z-score overrides do not supersede it. Golden references use the shared file in Setup. Modified Z-scores follow Analyze's logical-measurement pooling across the whole selected data scope; they are not recalculated separately for each original batch, parent batch or final fit group. Batch mode changes the fit groups, not the classification rule. Legacy `fail_method` and `classification_pool` values saved inside TSK settings are ignored.

Shared rules do not mean reusing labels from the last Analyze result. TSK recomputes the same classifier for its selected data. Different import, node or sample selections can change the Z-score pool and therefore the labels.

Aggregation happens **after each original batch has merged its repeats and resolved Pass / Fail / Missing**. Sample `S01` from L001 and sample `S01` from L002 remain different observations. Parent mode combines batches with the same parent ID; mode `none` combines all selected lots within each node. For each chain, sum Fail and Pass counts to obtain the effective denominator; sum Missing separately and exclude it from that denominator. The engine fits these summed counts, never an average of fitted TSK probabilities.

Pooling assumes a common TSK probability vector within the parent/node group, or common type and feature coefficients when features are enabled, using the same chain topology. Unequal batches contribute according to their valid counts in the binomial likelihood. A larger batch therefore contributes more information than a smaller batch. The mapping itself neither verifies this common-risk assumption nor removes differences between heterogeneous batches. The mathematical derivation and an unequal-size example are in [§6.6 of the mathematical guide](tsk-risk-mathematical-principles.md#batch-likelihood).

The corresponding runtime settings are:

```python
settings = {
    "batch_mode": "parent",  # none | separate | parent
    "batch_dimension": "lot_id",
    "batch_mapping": {"L001": "M001", "L002": "M001", "L003": "M002"},
}
```

These controls are TSK run settings. Calls without `batch_mode` use `none`: all selected batches are fitted together for each node. Every batch mode uses the shared Analyze classification rules and whole-scope Z-score pool.

## Template

The JSON `tsk_analysis` section corresponds to the Excel `tsk_analysis` settings sheet and `tsk_instances` table. Each instance row contains `CHAIN_ID`, `TSK_instance_ID`, `TSK_ID`, numeric `X`/`Y`, an optional explicit `CHAIN_KEY`, and declared numeric or categorical feature columns. `CHAIN_KEY` is a JSON array containing the complete column header path through the Chain level. A unique Chain name can be resolved automatically; ambiguous names require explicit paths and distinct external IDs.

Repeated TSK types are counted, not deduplicated. An instance ID must be unique within its chain. Coordinates must use a common coordinate system and unit. Density values require a consistent fraction/percentage convention and measurement window. The optional settings are `enabled`, `use_xy`, `coordinate_unit`, `feature_columns`, `categorical_feature_columns` and `feature_model`. `feature_model` is retained for schema compatibility and accepts only `logistic` (the default when omitted). Legacy `linear_hazard` configurations are rejected with an explicit instruction to change the setting and rerun; saved coefficients from that model are never reinterpreted as Logistic. Settings, fitted diagnostics and exports retain model provenance. A legacy TSK `group_by_dimensions` field no longer changes the analysis.

### Numeric and categorical attributes

`feature_columns` lists all optional attributes. `categorical_feature_columns` explicitly identifies the categorical subset; all other listed attributes remain numeric. This preserves existing numeric templates and avoids guessing a model from a column's formatting.

| Bump-size input | Declaration | Model interpretation |
| --- | --- | --- |
| `large`, `small` or `medium`; material labels such as `copper`, `aluminum` | Explicitly categorical | Text labels with no numeric magnitude or equal-spacing assumption. |
| `40`, `60`, `80` | Numeric, not in `categorical_feature_columns` | A continuous size measurement. Equal size changes have equal effects on log-odds, holding other inputs fixed. |
| `40`, `60`, `80` | Explicitly categorical | Three levels with separately estimated contrasts; no size ordering or equal-spacing assumption. |
| `40um`, `60um`, `80um` or `M`, `L` | Explicitly categorical | Category labels. Text is not automatically parsed as a physical size or converted into units. |

For example, these are partial template settings, not a replacement for the topology:

```json
{
  "feature_columns": ["metal_A_density", "bump_size", "material"],
  "categorical_feature_columns": ["bump_size", "material"]
}
```

An instance's `features` can then contain `{"metal_A_density": 0.35, "bump_size": "large", "material": "copper"}`. Other instances can use `"small"` and `"aluminum"`; these labels do not need numeric substitutes. In Excel, declare both setting rows in `tsk_analysis`, and use the corresponding attribute columns in `tsk_instances`. X/Y are always numeric. Missing or invalid selected category values are not silently treated as a baseline category.

Category labels are trimmed nonempty text or finite numbers. Numeric `40` and `40.0` share the label `"40"`; text `"40.0"` remains a different text label. Boolean, null and nonfinite values are rejected. Use a consistent label convention across the entire template.

The runtime `feature_names` selection can contain both kinds of attribute. The service derives the selected categorical subset from the template and passes it as `categorical_feature_names` to the model. Selecting a category does not split observations into additional fit groups: grouping remains node plus the selected lot/parent mode.

## Observation and missing-data rules

- One observation is a unique sample at a node for one chain. Repeats, sites and measurement columns follow Analyze's current effective merge order and any/all definitions; they do not increase the number of independent dies.
- Nodes are always fitted separately. The selected original-batch field preserves batch boundaries while merging repeats; only completed counts are combined for parent fits or for the all-lot fit in mode `none`. Temperature, voltage, site and other row fields do not create additional TSK fit groups; their measurements follow the shared merge rules.
- Fail and Pass use Analyze's current effective rules, including unsaved UI values. TSK's data scope, batch mode and XY/features remain independently selected.
- With `empty_as_fail=True`, an empty numeric cell is directly classified as Fail. With `empty_as_fail=False`, the empty leaf is skipped: it does not take part in any/all merging and does not propagate an unknown state. A known sample/node/chain with no remaining leaf at all is reported as Missing and excluded from the valid denominator.
- For nonempty measurements, Modified Z-score pools with fewer than three values or zero MAD have an effective score of 0 under Analyze's classifier; missing Golden matches produce `golden_fail=False`. Z-score/Golden AND and OR use ordinary Boolean logic. These cases do not become Missing simply because the statistical reference is uninformative or absent.
- Original input files preserve identified all-empty sample rows. Measurement-only databases cannot recover rows with no numeric measurements at import; the result explicitly warns about that exposure limitation.

## Model and intervals

### Logistic feature model

Logistic uses standardized numeric columns and reference-category indicators with effects shared across TSK types: `p = sigmoid(D θ)`. Three starting points are used; chain-level optimization does not guarantee a global optimum. No explicit TSK-by-feature or feature-by-feature interactions are fitted.

With no selected numeric/XY/category features, the equivalent type-only model uses nonnegative negative-log-survival parameters for stable numerical fitting and exact endpoint handling. This is a parameterization of one free probability per TSK type, not a second selectable feature algorithm.

### Likelihood and uncertainty

For each node and configured original or parent batch, or all selected batches together in mode `none`, the type-only model uses `q_i = 1 - product_t((1-p_t)**C_it)`, where C is the instance-count matrix. Nonnegative log-survival parameters are fitted by binomial maximum likelihood. Rank and realized-likelihood checks suppress unidentifiable type estimates.

In the Logistic feature model, each instance uses a type intercept, centered/standardized numeric effects, and categorical indicator effects on the logit scale. A category with L levels uses L−1 uncentered indicator columns. Levels are collected from the complete template topology and sorted consistently; the first is the reference. Its indicators are all zero. The choice is a coding reference, not a claim that this level is smallest, safest or most common. Instance survival probabilities are then multiplied within each chain. Logistic uses multiple starts without a global optimality guarantee. It does not automatically add a nonlinear spatial surface.

The original type estimates describe conditional probability at numeric means and every category's reference level. They are not feature-independent risks: for example, with bump and stack features, the reference estimate applies to one stated bump/stack combination. For categorical GUI runs, **风险结果** instead shows the full Cartesian grid of TSK/category combinations, with no 200-cell limit; the complete condition is part of each row's label. Its bars, heatmap and details share this complete result set, and display filters do not replace it with a separately calculated slice. Neither view represents average risk across category frequencies or actual instances. Diagnostics include `categorical_features`, with levels and references, alongside numeric `feature_scaling`. The same template retains category references across batches; a batch missing a level receives a diagnostic instead of silently changing its reference. Missing support or a category perfectly tied to `TSK_ID` can make reference type probabilities unidentifiable. Encoding categories does not remove these data limitations or establish independence between physical instances.

Intervals are profile-likelihood approximations, with appropriate exact transformations or bounds in supported boundary cases. Parent fits recompute intervals from their summed-count likelihood; the intervals are not averaged from the original batches and do not estimate between-batch variability. Each type row records its interval method. Nonconvergence, boundary estimates and unavailable intervals are explicit. A probability of zero is not evidence that true risk is exactly zero.

### Logistic coefficient limits and zero boundaries

**TSK Analysis → Logistic 系数绝对值上限** controls the initial Logistic coefficient box. Its default is 35; values from 1 to 700 are accepted and saved with the analysis settings. For example, 70 permits a candidate intercept below −35. A larger box does not supply missing information, remove parameter confounding, or establish convergence. The report records the actual box, the coefficients approaching its edges and their raw and projected gradients.

If a profile fit reaches a coefficient limit before a reliable interval is established, the interval stays blank and identifies the affected parameter and limit. A finite coefficient limit is not converted into a probability endpoint of zero or one.

When very low type risks or coefficient limits warrant further checking, the engine refits the same model with nonnegative reference odds, `r_t >= 0`, so an exact zero boundary can be represented without inventing a finite logit intercept. For an instance, `p = r_t * exp(features) / (1 + r_t * exp(features))`. Convergence, feasible parameter directions and each requested probability are checked before publishing a boundary result. Shared feature coefficients still have the selected numerical limit. Logistic optimization remains local; this check is not a proof of the global optimum.

A validated zero estimate is labelled **零边界估计**, with an upper confidence limit where available. Its TSK logit coefficient is blank with `boundary_unbounded`, because the zero boundary corresponds to `alpha_t -> -infinity`; the numerical starting-box value is not published as its coefficient. Other identifiable type risks and finite feature coefficients remain available. Small positive estimates use scientific notation when ordinary percentage formatting would hide them. A zero estimate does not establish permanent immunity to failure.

If all observations in the design-defined supporting chains are Pass, an exact one-sided bound is available from their exposure. A pure matching-design subset gives an exact binomial bound; including chains with other instances gives a conservative bound under the same independence model. Other validated zero-boundary upper limits use a profile-likelihood approximation and are explicitly labelled **近似**. These limits are pointwise, not simultaneous guarantees across all TSKs. An unavailable upper limit retains the point estimate and its boundary label, with a specific `interval_error`. Normal-approximation difference intervals are withheld when the fit has a zero boundary; identical-condition comparison remains exactly zero.

The approximate boundary branch retains the conventional profile-likelihood confidence-set cutoff `chi2.ppf(confidence, 1) / 2` (about 1.9207 at 95%). Its interval has the shape `[0, upper]`, but it has not been separately calibrated as a one-sided 95% bound. It is therefore labelled **近似上限（95% 轮廓似然阈值）**; the exact branch keeps **单侧 95% 上限**. A regular one-sided 95% likelihood threshold would be smaller, but applying that calibration automatically is not justified for every boundary/confounded model. These labels distinguish the methods without changing the computed endpoints.

A zero-boundary error bar spans **zero to a one-sided confidence upper limit**, not a symmetric standard deviation around zero. Zero observed failures do not establish a zero upper limit: for `n` independent direct Bernoulli observations, all Pass, the exact 95% upper bound is `1 - 0.05**(1/n)`. This is about 2.95% at `n=100` and 0.30% at `n=1000` ([NIST exact binomial limits](https://itl.nist.gov/div898/software/dataplot/refman2/auxillar/exacbino.htm)). Those sample counts cannot simply be replaced by the number of distinct chains. When a TSK risk is inferred from mixed chains, profile intervals also allow the other fitted parameters to change; weak separation of their contributions can give a wide upper limit despite a zero optimum. The graph's automatic probability-axis scale can make a small absolute interval look long. Inspect the numeric upper limit, confidence level and interval method in the tooltip before interpreting its visual size.

The inference assumes that a chain's Fail event is the OR of its instance failures, with conditional independence. Multi-instance accumulated drift or correlated defects can violate that assumption. Intervals currently assume independent chain observations; correlations between chains on the same die or between repeated nodes are not corrected by a cluster bootstrap. The data and paired sample outcomes remain available for follow-up validation. Fits estimate risk under these assumptions, not a directly observed root cause.

## Complete combination risks

**风险结果** answers questions such as “For TSK A, what is the predicted risk with a small bump and copper material?” It uses the same fitted main-effects model. It does not fit a separate model for every category combination, add interaction terms, or change the shared Analyze Fail rules or lot groups.

After fitting with the desired categorical features:

1. GUI runs automatically prepare all categorical combinations with **关闭外插（无数据组合留空）** enabled by default. Select the fitted node/batch group in **TSK Results → 风险结果** to see every TSK × bump × stack combination. There is no fixed total-combination count limit; 19 TSKs × 4 bumps × 3 stacks produces all 228 rows. Unsupported or unidentifiable rows retain their positions with blank estimates and explicit status.
2. Switch between **条形图**, **热力图** and **明细表** to inspect the same complete result set. The condition summary and TSK/category filters remain above these views. X/Y and other numeric values are never expanded into combination dimensions.
3. To focus on one condition, filter a TSK or category value; to compare levels of one category, hold the other categories fixed with those filters. Filtering and changing views do not recalculate probabilities or intervals.
4. Click a heatmap cell to open and select its combination row in **明细表**, including its probability, interval, support and status. Full warnings and diagnostics are available through **查看诊断**. Scrolling keeps large charts readable without removing calculated rows from the tables or export.

Hover a combination in the heatmap, bar chart or detail table to see the chains containing matching TSK/category instances, with each chain's observed and predicted failure rates for the selected node/batch group. Each chain appears once, including chains without valid tests, which are labelled accordingly. These rates describe the whole chain. Saved results retain this information; hovering does not recalculate the fit.

Numeric features, including X/Y, are held at their fitted group means. Each cell reports a single-instance conditional probability for its TSK and category combination, together with a 95% profile-likelihood interval. The GUI no longer exposes a separate calculation-condition form, category-comparison view or comparison-baseline selector.

The underlying combination API and XLSX export retain support for selected-condition queries and comparison fields. For those queries, `delta_probability = probability - baseline_probability` compares the same TSK at fixed other categories, with a covariance-aware, joint-information delta-method interval. This comparison baseline does not change the template's coding reference or refit the main model. Removing the GUI comparison page does not change these calculations or export fields.

Each combination has both a statistical estimation status and a separate support status:

| Support field/status | Meaning |
| --- | --- |
| `layout_instance_count` | Matching TSK/category instances in the complete template topology. |
| `active_instance_count` | Matching instances on chains with valid tests in the fitted group. |
| `chain_count` | Distinct validly tested chains containing those matching instances. |
| `chain_test_exposure` | Sum of valid tested counts over those distinct chains, counting each chain once. This is not a count of independent samples or observed instance outcomes. |
| `observed` | At least one matching layout instance belongs to an actively tested chain. Its individual Fail outcome is still latent; the risk is inferred from chain data. |
| `no_active_support` | Matching layout exists, but none of its chains has valid tests in this fitted group. |
| `extrapolated` | The requested TSK/category combination does not occur in the template layout. An estimable result is a model extrapolation. |

Support matching uses the TSK and all selected categories; it does not assert that any actual instance lies at the numeric mean values. Support and identifiability are different questions. A combination can be estimable through shared effects without direct matching layout, and a supported combination can still be statistically unidentifiable. Unavailable probabilities or intervals remain blank/null, never zero. The engine checks the combination contrast itself, so it can retain an identifiable prediction even when individual coefficients cannot be separated.

The **关闭外插（无数据组合留空）** control remains visible at the top of the risk page in both the GUI and HTML report. Groups without categorical features show it disabled with an explanation. Saved results can switch between their cached complete grids without recalculating; a missing policy is explicitly reported.

The GUI's default **关闭外插（无数据组合留空）** behavior keeps both absent-layout and inactive-layout combinations in the grid with `status=no_data` and blank probability/interval fields. In API queries, differences requiring an unsupported reference are also blank; disabling the no-extrapolation setting allows explicitly labelled model extrapolations. The setting is saved with each query and exported, and does not change the fitted coefficients or classify an unsupported combination as zero risk.

`interval_unavailable` means a point estimate exists but its interval could not be established reliably. Probability-profile failures include nuisance optimization nonconvergence, finding a better optimum than the stored fit, non-finite arithmetic or root-finding failure. The row's `interval_error` gives the specific reason. `delta_interval_error` separately explains a failed probability-difference interval. These statuses differ from `no_data` and `not_identifiable`; the latter can also withhold the probability itself.

Probability intervals are profile-likelihood approximations. Difference intervals, when available, use the joint expected information matrix of the same fit and include covariance between both predictions; they are not obtained by subtracting probability-interval endpoints. Logistic fits with active zero-odds boundaries withhold non-self normal-approximation difference intervals. Intervals are pointwise, not simultaneous coverage for the whole heatmap. Heatmap intensity is relative to the current view; compare probability values and intervals across queries rather than color strength alone. Large differences between probability-scale deltas across TSKs do not establish interactions: a shared category effect on the log-odds scale can produce different absolute probability changes at different baseline risks.

Completed analyses and combination queries automatically save a compressed display snapshot in the database's `.excel_data_analysis_gui_state.json`. Save Database and Save As also retain that snapshot. It preserves calculated risks, confidence intervals, chain members, topology, feature coefficients, joint risks, calculated feature-influence reports and cached comparisons without rounding probabilities. Per-sample outcomes, likelihood design matrices, raw optimizer traces and the duplicate full template are omitted. Reopening restores these displays without fitting, reclassifying data or automatically calculating missing combinations. Saved results remain exportable to XLSX; calculating a missing complete grid after reopening requires a fresh TSK analysis. The live session keeps its full fit for combination calculation and full-fit XLSX exports; the underlying API retains its additional query options.

Within a live analysis, a missing combination grid still asks before calculation. **稍后计算** is the default; use **TSK Results → 风险结果 → 计算完整组合** later. This calculates all TSKs and all selected categorical combinations for the current node/batch group, with numeric features at their fitted means, regardless of display filters. Reopened snapshots display only their previously calculated grids; group switching, filtering, sorting and changing risk views remain available without computation.

**风险结果** has a separate checkbox dropdown for **TSK ID** and each categorical dimension. Search, select or clear values within each dropdown; different dimensions combine with AND. Selecting no values shows no matching rows. **清除筛选** restores all rows. The filters apply to **条形图**, **热力图** and **明细表**, and remain selected when switching views. The chart defaults to natural TSK order (`1, 2, …, 19`); choose probability for high-to-low sorting, or sort a TSK/category field ascending or descending. Unavailable estimates remain last in probability order. Table headers retain their own sorting. These display controls do not start calculations or change the saved results or XLSX contents.

The heatmap's **X 轴** and **Y 轴** dropdowns assign **TSK ID** and the selected categorical dimensions to either display axis. By default, categories form the columns and TSK IDs form the rows. Checking a dimension on one axis removes it from the other; unchecking moves it to the other axis. Every dimension belongs to exactly one axis, so each cell still represents one original conditional risk. Select a checked dimension and use **上移 ↑** or **下移 ↓** to change the combination order. Values use natural ordering within each dimension, with the first selected dimension taking precedence. An empty axis produces a single row or column without averaging probabilities. These are display axes, not the numeric X/Y model features.

The heatmap uses an opaque Plasma-style deep-blue–purple–orange–yellow gradient from low to high values, scaled from zero to the current page’s maximum for the selected probability/support metric. Cell text switches between black and white to contrast with the fill; blank no-data cells, grey unavailable estimates and extrapolation hatching retain their separate meanings.

Axis assignments and order remain when changing filters or switching between groups with the same dimensions. When dimensions change, shared assignments remain and new categorical dimensions go to the X axis. Both axes paginate for large grids, and long row and column labels wrap without covering cells. Clicking a cell continues to select its original TSK/category record in **明细表**, regardless of the display-axis assignment.

## Fit checks and template instances

The second main page, **拟合检查**, places the current group's **观察与预测** beside a **模板实例组成** subpage. Observed chain failure proportions, predicted proportions, valid counts and residuals belong to the selected node/batch group. The instance table describes the complete template topology; it does not change when switching groups and must not be read as evidence that every listed chain has valid tests in the current group.

Chain names use natural numeric order, such as `Chain1, Chain2, Chain10`, in results and topology displays. Hover over a chain's failure-rate point to inspect its constituent TSKs, instance counts and inferred single-instance probabilities. These probabilities use each physical instance's actual categorical and numeric conditions; they need not equal the risk grid's probabilities at numeric means. The same TSK appearing with different conditions is listed separately. Unidentifiable contributions are explicitly unavailable even when the chain's combined probability is identifiable. The model combines instance risks as `1 - product(1-p_instance)`; a member probability is not the probability that this member caused a particular observed chain failure. The XLSX **Chain Members** sheet exports these conditional member estimates. **TSK Risk** retains the original reference estimates with explicit `risk_conditions` and `reference_environment`; **Combination Risk** contains the calculated combination rows.

## Model coefficients

**模型与诊断 → 模型说明** displays fitted coefficients, the model formula, categorical reference levels and numeric scaling. Conditional probabilities and their intervals are available in **风险结果**. To compare one categorical feature, filter the other categories to fixed levels there. The former feature-risk subpage duplicated a reference slice of those combination results and has been removed.

The coefficient table includes identifiable TSK intercepts, numeric coefficients, categorical effects and reference levels. Logistic uses `logit(p) = alpha_t + sum(beta_j * z_j) + category effects`, followed by `p = sigmoid(logit(p))`. Numeric coordinates are standardized as `z_j = (x_j-mean_j)/scale_j`; means and scales are shown alongside their coefficients. A reference category's coefficient of zero is a coding convention. An effect that cannot be independently estimated stays blank. XLSX exports continue to include **Feature Risk** (the reference slices) and **Feature Coefficients** when those results are available.

The separate [text-category demo](../examples/tsk_risk_demo/README.md#文本类别与组合预测的独立示例) provides [a template](../examples/tsk_risk_demo/categories/template.xlsx) and [input data](../examples/tsk_risk_demo/categories/data.csv) for `large/small` bumps and `aluminum/copper` materials. It deliberately omits `TSK_C + small + copper` from the layout so an estimable extrapolation can be distinguished from directly supported combinations. The original numeric demo remains unchanged.

## Joint risk for inseparable parameters

**TSK Results → 联合风险** retains the main fit and reports identifiable whole configurations when their individual parameters cannot be separated. Re-run analysis to generate this page for older saved results. The page distinguishes two meanings:

- **Joint conditions on one instance:** a TSK and its selected bump/stack conditions share one instance probability. In Logistic mode this is `sigmoid(alpha_TSK + feature effects)`. The coefficients are not separate components with separate failure events.
- **Multiple instances together:** a bundle fails when at least one member fails. Its probability is `1 - product((1-p_j)**m_j)`, using the displayed member counts and conditions. For `2 × A + 1 × B`, the two copies of A remain part of the definition; the risk is not divided equally among members or averaged into an individual probability.

For example, a chain containing only A and B may identify their combined risk as 10% while leaving both individual probabilities blank. Another example has observed compositions AB and BC: those two configurations can be reported, but their connection through B does not establish the risk of ABC. Merging parameters is not itself evidence of identifiability.

The calculation groups identical observed instance designs into conditional instance types and records their counts in each chain. A candidate bundle must have a verified representation as a linear combination of the observed chain hazard compositions. It also checks whether the observed Fail/Pass counts leave the package risk free to vary along equal-likelihood allocations; a structural certificate alone is insufficient. These checks go beyond a locally insensitive Jacobian direction. Automatic candidates comprise fixed-ratio groups, observed complete-chain compositions reduced to their integer ratios, and supported single-instance conditions with confounded coefficients. They are useful configurations, not a claim that there is one unique or minimal grouping. Unsupported conditions are not filled, and numeric/XY grids are not expanded. A failed or unstable main fit remains unavailable on this page.

Point estimates use the original fitted model. Intervals use the observed chain counts: directly matching compositions can use transformed exact binomial intervals; other cases combine chain intervals conservatively through the verified composition relation. The latter applies a Bonferroni correction within each reported group and can be wide. Suitable all-Pass support supplies a one-sided upper bound. These are pointwise intervals for each displayed group, not simultaneous coverage of every row, and they retain the model's within-chain independence assumption. The interval construction uses [exact binomial limits](https://itl.nist.gov/div898/software/dataplot/refman2/auxillar/exacbino.htm) and the [Bonferroni inequality](https://itl.nist.gov/div898/handbook/prc/section4/prc473.htm).

The main model's estimate can disagree with an interval derived from the directly observed chain evidence; both values are retained with an explicit mismatch status. Incompatible or numerically unavailable intervals stay blank with their reason. A zero estimate remains a boundary estimate, not a guarantee of zero failures.

The detail area records members, ratios, conditions, the probability formula, supporting chains and the composition certificate. Computation limits and omitted groups are reported rather than silently expanding an unbounded search. Results are saved with the workspace. XLSX exports contain **Joint Risk** summaries and the losslessly split full JSON in **Joint Risk Details**, ordered by `group_index` and one-based `part`; concatenate `value` without separators to reconstruct each report.

## Logistic fit debug report

Open **TSK Results → 模型与诊断 → 诊断与提示**, or click the top-level **查看诊断** button, to inspect the selected group's full Logistic fit report. Use **复制诊断文本** or **保存诊断 TXT** to retain the complete report. It records the parameter definitions, objective and gradient diagnostics, solver status, rank and identifiability checks, and the optimization trajectory. For the main fit, each starting point and optimization phase retains its complete candidate coefficient vector and sampled accepted iterations. It does not record every trial evaluated during a line search. During the fit, the progress message shows the current starting point, phase, iteration and gradient-to-threshold ratio. The report includes numerical details for investigating the fit, without copying the original sample records or complete topology into the text report.

Candidate coefficients in this report can come from failed, nonconverged or unidentifiable fits. They are diagnostic values, not validated feature effects or risk results. Recording them does not relax convergence/identifiability thresholds, add regularization, or change the coefficients shown in **模型说明** or the probabilities in the risk views.

For a deficient-rank, near-limit or very-low-probability candidate, **参数不敏感与共同变化范围** adds two checks:

- Change one coefficient while holding the others fixed, and report the sampled range over which the observed chain probabilities and likelihood remain within tolerance.
- Move coefficients together along a numerical null direction, listing each parameter and its change per unit of the main parameter. Instance-design null directions and local Chain Jacobian directions are labelled separately. Both are checked by recalculating the nonlinear chain probabilities; a Jacobian direction alone does not establish equivalence over a finite range.

The current diagnostic requires every chain's absolute probability change to be at most `1e-8 + 1e-5 * abs(original_probability)` and absolute NLL change to be at most `1e-4`. Reported ranges contain the current candidate and pass finite sampled checks; they are not confidence intervals or a proof between sample points. The report gives the tolerances, parameter ratios, endpoints and observed changes. Scans respect the selected coefficient box and cover at most 24 parameters and six coupled directions, prioritizing weak and confounded parameters; omitted counts are explicit. These checks describe the original logit candidate before any zero-boundary review, and do not authorize predictions at unsupported combinations.

XLSX exports retain the full text in **Diagnostics**, under `fit_debug_report`, and the structured strict JSON under `fit_debug`. Long values are split into ordered rows to avoid Excel's cell-length limit, including for Chinese text and emoji. Reassemble a value by selecting its zero-based `group_index` and `item`, sorting by the one-based `part`, checking the declared `parts` count, and concatenating `value` without separators. Parse the joined `fit_debug` text as JSON; unavailable/nonfinite numeric diagnostics are represented by `null`. The group index distinguishes groups even when their display labels match. Old results without debug fields remain exportable, and the existing **Prediction Context** snapshot and its export format are unchanged.

## Runtime and development

NumPy and SciPy are declared project dependencies. Install through the existing `pip install -e .` setup. The UI uses PySide6/QPainter and adds no browser/chart runtime. All controls and layouts are defined in `.ui` and checked-in generated modules.

Automated coverage includes known-risk recovery, repeated instances, identifiability, zero/all-failure boundaries, feature scaling, JSON/XLSX round trips, shared Analyze classification and empty-value handling, node/batch separation, independent execution, persistence and export. Native macOS Cocoa geometry and horizontal expansion are checked separately. Windows execution and frozen distributions require validation on Windows; this change does not claim a newly tested Windows executable.
